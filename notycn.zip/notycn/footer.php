﻿	<script type="text/javascript">
	<!--if ( top.location !== self.location ) { top.location=self.location;}//-->
	</script>
	</div><!--/bd -->

</div><!--/docXcol(s) -->



<div class="footer">

	<div class="footerleft">
		GWthem Theme is created by:<a href="http://www.notycn.com/">notycn</a><br />
		Copyright &copy; 2008 - <?php bloginfo('name'); ?> - is proudly powered by <a href="http://www.wordpress.org/">WordPress</a>
	</div>

	<div class="footerright">
		<?php wp_loginout(); ?><br />
	</div>

</div>
			

</body>
</html>