<?php get_header(); ?>
	
	<?php if (have_posts()) : ?>

		<?php while (have_posts()) : the_post(); ?>

		<div class="post" id="post-<?php the_ID(); ?>">
			<h2 class="posttitle"><strong><a href="<?php the_permalink() ?>" rel="bookmark" title="到《<?php the_title(); ?>》的永久链接">» <?php the_title(); ?></a></strong></h2>
			<p class="authordate">
				<span><?php the_time('Y') ?>年<?php the_time('m') ?>月<?php the_time('j') ?>日 <?php the_time('A') ?> <?php the_time('i') ?>:<?php the_time('s') ?> | 作者：<?php the_author_posts_link(); ?></span>
			</p>
			<div class="entry">
				<?php the_content('<br />查看全文 &raquo;'); ?>
			</div>
			<p class="postmetadata"><?php the_tags('Article Tags»  ', ' | ' , ''); ?></p>
			<div class="metadata">
					<span><!--<?php the_author() ?> | -->时间：<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_time('g:i A') ?></a> | 分类：<?php the_category(', ') ?></span><?php edit_post_link('编辑', ' | ', ''); ?> | <?php comments_popup_link("没有评论","评论(1)","评论(%)"); ?>
			</div>
		</div>

		<!--
		<?php trackback_rdf(); ?>
		-->

		<?php endwhile; ?>

		<div class="navigation">
	<?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } else { ?>
			<div class="wp-pagenavi2"><span class="l"><?php next_posts_link('&laquo; 上一页') ?></span><span class="r"><?php previous_posts_link('下一页 &raquo;') ?></span><div class="clear"></div></div>
		<?php } ?>
        </div>
	
	<?php else : ?>

		<br /><h2 class="center">没有找到结果。您可在右侧搜索框中重新尝试</h2>

	<?php endif; ?>

	</div>
</div><!--/content_inner -->

<?php get_sidebar(); ?>

<?php get_footer(); ?>