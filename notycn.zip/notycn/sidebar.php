<div id="sidebar">
<!--内容-->
	<div class="sidebarBlock">
		<h5>站内搜索</h5>
			<div class="sidebarsearch">
				<?php include (TEMPLATEPATH . '/searchform.php'); ?>
			</div>
	</div>

	<div class="sidebarBlock">
		<h5>最新文章</h5>
			<div class="sidebarContent">
					<ul>
				<?php get_archives('postbypost', 10); ?>
					</ul>
			</div>
	</div>

	<div class="sidebarBlock">
		<h5>文章分类</h5>
			<div class="sidebarContent">
					<ul>
				<?php wp_list_cats(); ?>
					</ul>
			</div>
	</div>

  	<div class="sidebarBlock">
		<h5>最新评论</h5>
			<div class="sidebarreply">
<?php 
global $wpdb; 
$sql = "SELECT DISTINCT ID, post_title, post_password, comment_ID, 
comment_post_ID, comment_author, comment_date_gmt, comment_approved, 
comment_type,comment_author_url, 
SUBSTRING(comment_content,1,30) AS com_excerpt 
FROM $wpdb->comments 
LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID = 
$wpdb->posts.ID) 
WHERE comment_approved = '1' AND comment_type = '' AND 
post_password = '' 
ORDER BY comment_date_gmt DESC 
LIMIT 10"; 
$comments = $wpdb->get_results($sql); 
$output = $pre_HTML; 
$output .= "\n<ul>"; 
foreach ($comments as $comment) { 
$output .= "\n<li>" . "<a href=\"" . get_permalink($comment->ID) . 
"#comment-" . $comment->comment_ID . "\" title=\"on " . 
$comment->post_title . "\">". strip_tags($comment->comment_author) 
."</a>"." : " . strip_tags($comment->com_excerpt) 
."</li>"; 
} 
$output .= "\n</ul>"; 
$output .= $post_HTML; 
echo $output;?>
			</div>
	</div>

	<div class="sidebarBlock">
		<h5>日志存档</h5>
			<div class="sidebarContent">
					<ul>
				<?php wp_get_archives('type=monthly'); ?>
					</ul>
			</div>
	</div>

	<div class="sidebarBlock">
		<h5>链接</h5>
			<div class="sidebarContent">
					<ul>
				<?php get_links($category = -1,$before = '<li>',$after = '</li>',$between = ' ',$show_images = true,$orderby = 'name',$show_description = true,$show_rating = false,$limit = -1,$show_updated = 1,$echo = true) ; ?>
					</ul>
			</div>
	</div>
<!--结束-->
</div>