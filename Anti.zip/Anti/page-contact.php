<?php 
/*
Template Name: Page Contact
*/
get_header(); 
?>
	<article>        
			<div id="border-container"></div>	
			<div id="content">
			 <div id="left-entry">	<div class="default-page">			
				    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>													
				     <div class="entry-post">
				      
					   <h2 class="title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h2> 	
					  	 
  				
				        <div class="entry">
 <?php the_content();?>
</div><form id="contactForm" method="post" action="#">
<div class="contactform">
<label for="contactName">Name:</label>
<input id="contactName" class="required requiredField" type="text" value="" name="contactName">
<label for="emaill">Email:</label>
<input id="emaill" class="required requiredField email" type="text" value="" name="emaill">
<label for="comments">Message:</label>
<textarea id="commentsText" class="required requiredField" name="comments"></textarea>
<input class="btn" type="submit" value="Submit Message" name="submit">
</div>
<input id="submitted" type="hidden" value="true" name="submitted">
</form>
                        <div class="clear"></div>
					

					
				
				<?php endwhile; endif;?>    
				
				<div class="clear"></div></div></div></div><?php get_sidebar(); ?>
			</div>
		
			
		<div class="clear"></div>  
		
	</article>
	  <?php get_footer(); ?>