<div id="sidebar">
      <div class="widget-notice">您好，这里是Wordpress主题anti的演示站点，目前主题还在开发中，欢迎您反馈BUG，如果您有更好的想法也欢迎留言，谢谢您的支持。</div>
    <div id="sidebarwidgit">
	  
	
	<?php if ( ! dynamic_sidebar( 'Sidebar' )) : ?>
	
	<?php endif; ?>
	</div>
   

</div>

