<?php get_header(); ?>

<article>
<div id="border-container"></div>
  <div id="content">
  <div id="left-entry">
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <div class="post">
      <div class="post-entry"><?php post_thumbnail( 260,150 ); ?>
        <h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark">
          <?php the_title(); ?>
          </a></h2>
        
        <!--.postMeta-->
        <div class="post-content">
           <?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 140,"……"); ?>
        </div><div class="post-meta"> <span>
          <?php the_time('D,g:h A'); ?>
          </span><span>
          <?php comments_popup_link('No comment', 'Only 1 comment', '% comments'); ?>
          </span></div><div class="sright">
<a class="read_more" href="<?php the_permalink() ?>"></a>
</div>
      </div>
    </div>
    <?php endwhile; endif;?>
    <nav class="pagenavi cf">
      <?php if (  $wp_query->max_num_pages > 1 ) : ?>
      <div id="pagenavi">
	  <div id="navcontent">
        <?php pagenavi(); ?>
      </div></div>
      <?php endif; ?>
    </nav>
  </div><?php get_sidebar(); ?></div>
  <!--#end content-->
  
</article>
<?php get_footer(); ?>
