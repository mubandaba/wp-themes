<?php get_header(); ?>
	<article>      
			<div id="border-container"></div>	
			<div id="content">	<div id="left-entry">	<div class="default-page">	
<div class="entry-post">
				      
					   <h2 class="title">404-404</h2> 			
					<p>找不到页面？没关系，Anti也没有找到男盆友</p>
					<img src="<?php bloginfo('template_directory'); ?>/images/404.jpg" alt="404">
						<p>要不还是回<a href="<?php bloginfo('url');?>">首页</a>吧	</p>				
				</div></div>	</div><?php get_sidebar(); ?>		</div>	
						
			
		 </article>
	
		<?php get_footer(); ?>
	