<?php
$themename = $dname.'主题';

$options = array (

	//基本设置
	array( "name" => "基本设置","type" => "section","desc" => "主题的基本设置，包括模块是否开启等"),
	array( "name" => "网站描述(一般不超过200个字符，显示在顶部logo右边)","type" => "tit"),
	array( "id" => "anti_description","type" => "text","std" => "Wordpress Theme Anti By Fatesinger And SmallButterfly."),
	array( "type" => "endtag"),


	


	//首尾代码
	array( "name" => "首尾代码","type" => "section" ),	
	
	array( "name" => "流量统计代码(贴入百度统计、CNZZ、51啦、量子统计代码等等)","type" => "tit"),	
	array( "id" => "anti_track_b","type" => "checkbox" ),
	array( "id" => "anti_track","type" => "textarea","std" => ""),

	array( "name" => "头部描述代码2(将显示在网站描述右边)","type" => "tit"),	
	array( "id" => "anti_headcode_b","type" => "checkbox" ),
	array( "id" => "anti_headcode","type" => "textarea","std" => "Here you can find a selection of my latest work for your appraisal.<br>As you will see, my portfolio reflects my skills in usability and user experience."),

	array( "name" => "底部版权信息","type" => "tit"),	
	array( "id" => "anti_footcode_b","type" => "checkbox" ),
	array( "id" => "anti_footcode","type" => "textarea","std" => "Copyright © 2013. All right reserved."),

	array( "type" => "endtag"),


	
);

function mytheme_add_admin() {
	global $themename, $options;
	if ( $_GET['page'] == basename(__FILE__) ) {
		if ( 'save' == $_REQUEST['action'] ) {
			foreach ($options as $value) {
				update_option( $value['id'], $_REQUEST[ $value['id'] ] ); 
			}
			/*
			foreach ($options as $value) {
				if( isset( $_REQUEST[ $value['id'] ] ) ) { update_option( $value['id'], $_REQUEST[ $value['id'] ]  ); }
				else { delete_option( $value['id'] ); } 
			}
			*/
			header("Location: admin.php?page=option.php&saved=true");
			die;
		}
		else if( 'reset' == $_REQUEST['action'] ) {
			foreach ($options as $value) {delete_option( $value['id'] ); }
			header("Location: admin.php?page=option.php&reset=true");
			die;
		}
	}
	add_theme_page($themename." Options", $themename."设置", 'edit_themes', basename(__FILE__), 'mytheme_admin');
}

function mytheme_admin() {
	global $themename, $options;
	$i=0;
	if ( $_REQUEST['saved'] ) echo '<div class="anti_message">'.$themename.'修改已保存</div>';
	if ( $_REQUEST['reset'] ) echo '<div class="anti_message">'.$themename.'已恢复设置</div>';
?>

 
 <style type="text/css">
 .logo {
    float: left;
    height: 120px;
    
    position: relative;
    width: 120px;
    z-index: 100;
text-indent:-9999px;background:url("<?php bloginfo('template_directory'); ?>/images/logo.png") no-repeat}
html{background-image:url("<?php bloginfo('template_directory'); ?>/images/bg-body.png")} 
a,input,button,select,textarea{outline:none}

.anti_wrap{position: relative;font-family:'microsoft yahei';}
.anti_wrap h2{font-family:'microsoft yahei';border-bottom: solid 1px #ddd;padding-bottom: 10px;}

.anti_message{position:absolute;top:0;right:0;border-radius:0 0 0 4px;background-color: #000;opacity: 0.6;-moz-opacity: 0.6;filter:alpha(opacity=6);padding:6px 20px 8px 20px;color: #fff;}

.anti_themedesc{font-size:12px;margin-left:20px;}

.anti_desc:after{content:".";display:block;height:0;clear:both;visibility:hidden}
.anti_desc{height:1%}

.anti_formwrap{padding-left: 140px;position: relative;border-radius: 3px;}
.anti_tab{width: 140px;text-align: right;position: absolute;top: 0;left: 0;border-right: solid 1px #ddd;height: 100%;box-shadow:inset -2px 0 0 #f9f9f9;}
.anti_tab ul{margin: 7px 0;}
.anti_tab ul li{padding: 8px 25px 8px 0;cursor: pointer;color: #444;}
.anti_tab ul li:hover{color:#222}
.anti_tab ul li.anti_tab_on{background:#f5f5f5;border-left:#C62627 3px solid;color:#222;font-weight: bold;}

.anti_mainbox{display:none;}

.anti_desc{margin: 10px 5px 0 25px;}
.anti_desc .button-primary{}


.anti_inner{padding:0 0 10px 25px;min-height:500px}
.anti_inner .anti_li{}
.anti_inner h4{font-size:12px;color:#333;position:relative;margin: 0 0 10px;padding-top: 15px}

.anti_line{background:#e4e4e4;height:1px;overflow:hidden;display:block;clear:both;margin:15px 15px 20px -115px}

#wpcontent .anti_inner select{border:#BED1DD 1px solid;padding:4px;height:29px;line-height:24px;border-radius:2px;width:100px;margin-right:5px;color:#444}

.anti_tip{display: none;}
.anti_tips{color: #bbb;}

.anti_inner input[type="text"] {border: solid 1px #dadada;
	border-left-color: #ccc;
	border-top-color: #ccc;
	box-shadow: inset 0 1px 0 #eee;
	background-color: #fff;
	padding: 4px 6px;
	height: 30px;
	line-height: 20px;
	color: #888;
	font-size: 12px;margin-bottom:6px;margin-right:5px;width:98%;border-radius:1px;font-family:'microsoft yahei';}
.anti_inner input[type="text"].anti_inp_short{width:360px;display:inline}
.anti_inner input[type="text"].anti_inp_four{width:100px;display:inline}

.anti_check{border:solid 1px #CCCCCC;border-radius:2px 2px 0 0;padding:4px 6px;display: inline-block;width:44px;margin:0 20px -2px 1px;color: #666;}
.anti_check input{vertical-align: -3px;margin-right:3px;}

.anti_number{color: #444;}
.anti_num{width:60px;border-color:#BED1DD;}

.anti_tarea{width:98%;min-height:64px;border: solid 1px #dadada;
	border-left-color: #ccc;
	border-top-color: #ccc;
	box-shadow: inset 0 1px 0 #eee;
	background-color: #fff;padding:5px 6px;border-radius:2px;line-height:18px;color:#444;display:block;font-family:microsoft yahei;font-size:12px}

.anti_inner input,.anti_inner textarea{color:#888;}
.anti_inner input:focus,.anti_inner textarea:focus{border-color: #95C8F1;
	box-shadow: 0 0 4px #95C8F1;color: #444;}

.anti_inner .anti_inp, .anti_inner .anti_tarea{display: block;}

.anti_port_btn{font-size:12px;font-weight:normal; display:inline-block}
.anti_port_btn a{margin-left:12px;cursor:pointer}

.anti_popup_mask{width:100%;height:100%;background:#000;opacity:.3;position:fixed;top:0;left:0;z-index:99998}
.anti_popup{position:fixed;top:50%;left:50%;margin:-200px 0 0 -300px;width:600px;height:400px;border:#4E7D9A 1px solid;background:#fff;padding:12px;display:none;z-index:99999;box-shadow:0 0 10px #666}
.anti_popup h3{border-bottom:#D1E5EE 1px solid;box-shadow:inset 1px 1px 1px #298CBA;background:#23769D;height:32px;font:bold 14px/32px microsoft yahei;margin:-12px -12px 0;color:#fff;position:relative;padding-left:12px;text-shadow:0 0 2px #195571}
.anti_popup h3 input{float:right;margin:4px 12px 0 0}
.anti_popup h4{margin:10px 0;font-weight:normal;font-size:12px}
.anti_popup textarea{width:99%;min-height:330px;border:#D1E5EE 1px solid;border-left-color:#BED1DD;border-top-color:#BED1DD;background:#fff;padding:8px 10px;border-radius:2px;line-height:18px;color:#444}
.anti_popup textarea:focus{border:#EDC97F 2px solid;background:#fff;padding:7px 9px}
.anti_btn_this{text-align:center}

.anti_the_desc{background:#EFF8FF;border:#BED1DD 1px solid;border-bottom-color:#D1E5EE;border-top-left-radius:3px;border-bottom-left-radius:3px;padding:5px 8px;color:#21759B;margin-right:-3px;position:relative;z-index:10;vertical-align:middle;top:-2px}

.anti_adviewcon{width:96%;padding-top:5px;overflow:hidden}
#container-bottom {
    width: 100%;
}

#slogan {
    height: 120px;
    margin: 0 auto;
    max-width: 1200px;
    min-width: 920px;
    padding: 0;
}
#smargin {
    margin: 0;
    padding: 0 20px;
}.tagline {
    float: left;
    height: 80px;
    margin: 37px 0 0 20px;
    position: relative;
    width: 210px;
    z-index: 100;}.tagline h3 {
    font-size: 13px;
    line-height: 1.3em;font-weight:400;font-family:Verdana;color:#666
}

</style>


<script type="text/javascript">
jQuery(document).ready(function($) {
	//tab tit
	$('.anti_mainbox:eq(0)').show();
	$('.anti_tab ul li').each(function(i) {
		$(this).click(function(){
			$(this).addClass('anti_tab_on').siblings().removeClass('anti_tab_on');
			$($('.anti_mainbox')[i]).show().siblings('.anti_mainbox').hide();
		})
	});

	
	
	


	$.fn.extend({
		insertAtCaret: function(myValue){
			var $t=$(this)[0];
			if (document.selection) {
				this.focus();
				sel = document.selection.createRange();
				sel.text = myValue;
				this.focus();
			}
			else 
			if ($t.selectionStart || $t.selectionStart == '0') {
				var startPos = $t.selectionStart;
				var endPos = $t.selectionEnd;
				var scrollTop = $t.scrollTop;
				$t.value = $t.value.substring(0, startPos) + myValue + $t.value.substring(endPos, $t.value.length);
				this.focus();
				$t.selectionStart = startPos + myValue.length;
				$t.selectionEnd = startPos + myValue.length;
				$t.scrollTop = scrollTop;
			}
			else {
				this.value += myValue;
				this.focus();
			}
		}
	}) 

	
	
})
</script>



<div class="wrap anti_wrap">
	<div id="slogan"><div id="smargin">
<h1><a href="<?php bloginfo('url');?>" title="<?php bloginfo('name');?>" class="logo">
      <?php bloginfo('name');?>
      </a></h1><div id="top" class="tagline"><h3>
Wordpress Theme Anti By Fatesinger And SmallButterfly.</h3>
</div>
</div></div>
	
	<form method="post" class="anti_formwrap">
		<div class="anti_tab">
			<ul>
				<li class="anti_tab_on">基本设置</li>
				
				<li>首尾代码</li>
				
			</ul>
		</div>
		<?php foreach ($options as $value) { switch ( $value['type'] ) { case "": ?>
			<?php break; case "tit": ?>
			</li><li class="anti_li">
			<h4><?php echo $value['name']; ?>：</h4>
			
			
			<?php break; case 'text': ?>
			<input class="anti_inp <?php echo $value['class']; ?>" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" value="<?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id'])  ); } else { echo $value['std']; } ?>" />

			<?php break; case 'number': ?>
			<label class="anti_number"><?php echo $value['txt']; ?><input class="anti_num <?php echo $value['class']; ?>" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" value="<?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id'])  ); } else { echo $value['std']; } ?>" /></label>
			
			<?php break; case 'textarea': ?>
			<textarea class="anti_tarea" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" cols="" rows=""><?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id']) ); } else { echo $value['std']; } ?></textarea>
			
			<?php break; case 'select': ?>
			<?php if ( $value['desc'] != "") { ?><span class="anti_the_desc" id="<?php echo $value['id']; ?>_desc"><?php echo $value['desc']; ?></span><?php } ?><select class="anti_sel" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>">
				<?php foreach ($value['options'] as $option) { ?>
				<option <?php if (get_settings( $value['id'] ) == $option) { echo 'selected="selected" class="anti_sel_opt"'; } ?>><?php echo $option; ?></option>
				<?php } ?>
			</select>
			
			<?php break; case "checkbox": ?>
			<?php if(get_settings($value['id']) != ""){ $checked = "checked=\"checked\""; }else{ $checked = "";} ?>
			<label class="anti_check"><input type="checkbox" id="<?php echo $value['id']; ?>" name="<?php echo $value['id']; ?>" <?php echo $checked; ?> />开启</label>
			
			<?php break; case "section": $i++; ?>
			<div class="anti_mainbox" id="anti_mainbox_<?php echo $i; ?>">
				<ul class="anti_inner">
					<li class="anti_li">
				
			<?php break; case "endtag": ?>
			</li></ul>
			<div class="anti_desc"><input class="button-primary" name="save<?php echo $i; ?>" type="submit" value="保存设置" /></div>
			</div>
			
		<?php break; }} ?>
				
		<input type="hidden" name="action" value="save" />

	</form>

</div>
 
<?php } ?>
<?php add_action('admin_menu', 'mytheme_add_admin');?>