<?php

class anti_widget1 extends WP_Widget {
     function anti_widget1() {
         $widget_ops = array('description' => '主题自带的标签云小工具');
         $this->WP_Widget('anti_widget1', 'Anti-标签云', $widget_ops);
     }
     function widget($args, $instance) {
         extract($args);
         $limit = strip_tags($instance['limit']);
         echo $before_widget;
?> 
         <h3 class="sidebar_title">Tags</h3>
		 <div class="tagcloud"><?php wp_tag_cloud( array( 'unit' => 'px', 'smallest' => 12, 'largest' => 12, 'number' => $limit, 'format' => 'flat', 'orderby' => 'count', 'order' => 'DESC' )); ?></div>		
<?php		 
         echo $after_widget;
     }
     function update($new_instance, $old_instance) {
         if (!isset($new_instance['submit'])) {
             return false;
         }
         $instance = $old_instance;
         $instance['limit'] = strip_tags($new_instance['limit']);
         return $instance;
     }
     function form($instance) {
         global $wpdb;
         $instance = wp_parse_args((array) $instance, array('limit' => ''));
         $limit = strip_tags($instance['limit']);
 ?>
         <p><label for="<?php echo $this->get_field_id('limit'); ?>">显示数量：<input class="widefat" id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="text" value="<?php echo $limit; ?>" /></label></p>
         <input type="hidden" id="<?php echo $this->get_field_id('submit'); ?>" name="<?php echo $this->get_field_name('submit'); ?>" value="1" />
 <?php
     }
 }
 add_action('widgets_init', 'anti_widget1_init');
 function anti_widget1_init() {
     register_widget('anti_widget1');
 }

///////////////////
class anti_widget2 extends WP_Widget {
     function anti_widget2() {
         $widget_ops = array('description' => '最新评论');
         $this->WP_Widget('anti_widget2', 'Anti-最新评论', $widget_ops);
     }
     function widget($args, $instance) {
         extract($args);
         $title = apply_filters('widget_title',esc_attr($instance['title']));
         $limit = strip_tags($instance['limit']);
		 $email = strip_tags($instance['email']);
         echo $before_widget;
?> <h3 class="sidebar_title">Comments</h3><div class="siderbarcom">
        		 <ul class="commm">
						<?php
						global $wpdb;
						$my_email ="'" . $email . "'";
						$rc_comms = $wpdb->get_results("
						 SELECT ID, post_title, comment_ID, comment_author,comment_author_email, comment_content
						 FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts
						 ON ($wpdb->comments.comment_post_ID  = $wpdb->posts.ID)
						 WHERE comment_approved = '1'
						 AND comment_type = ''
						 AND post_password = ''
						 AND comment_author_email != $my_email
						 ORDER BY comment_date_gmt
						 DESC LIMIT $limit
						 ");
						$rc_comments = '';
						foreach ($rc_comms as $rc_comm) {  
						$rc_comments .= "<li><a href='"
						. get_permalink($rc_comm->ID) . "#comment-" . $rc_comm->comment_ID
						. "' title='在 " . $rc_comm->post_title . " 发表的评论'><span class='comer'>".get_avatar(get_comment_author_email(''), 46).$rc_comm->comment_author." : <br></span><span style='text-indent:50px'>". htmlspecialchars($rc_comm->comment_content) ."</span></a></li>\n";
						}
						
						echo $rc_comments;
						?>	

		</ul></div>
		 
<?php		 
         echo $after_widget;
     }
     function update($new_instance, $old_instance) {
         if (!isset($new_instance['submit'])) {
             return false;
         }
         $instance = $old_instance;
         $instance['title'] = strip_tags($new_instance['title']);
         $instance['limit'] = strip_tags($new_instance['limit']);
		 $instance['email'] = strip_tags($new_instance['email']);
         return $instance;
     }
     function form($instance) {
         global $wpdb;
         $instance = wp_parse_args((array) $instance, array('title'=> '', 'limit' => '', 'email' => ''));
         $title = esc_attr($instance['title']);
         $limit = strip_tags($instance['limit']);
		 $email = strip_tags($instance['email']);
 ?>
         <p>
             <label for="<?php echo $this->get_field_id('title'); ?>">标题：<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></label>
         </p>
         <p>
             <label for="<?php echo $this->get_field_id('limit'); ?>">显示数量：<input class="widefat" id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="text" value="<?php echo $limit; ?>" /></label>
         </p>
		 <p>
             <label for="<?php echo $this->get_field_id('email'); ?>">输入你的邮箱以排除显示你的回复: <br>（留空则不排除）<input class="widefat" id="<?php echo $this->get_field_id('email'); ?>" name="<?php echo $this->get_field_name('email'); ?>" type="text" value="<?php echo $email; ?>" /></label>
         </p>
         <input type="hidden" id="<?php echo $this->get_field_id('submit'); ?>" name="<?php echo $this->get_field_name('submit'); ?>" value="1" />
 <?php
     }
 }
 add_action('widgets_init', 'anti_widget2_init');
 function anti_widget2_init() {
     register_widget('anti_widget2');
 }
 


  
 
 
/////////////随机文章////////////

class anti_widget4 extends WP_Widget {
     function anti_widget4() {
         $widget_ops = array('description' => '随机文章小工具');
         $this->WP_Widget('anti_widget4', 'Anti-随机文章', $widget_ops);
     }
     function widget($args, $instance) {
         extract($args);
         
         $limit = strip_tags($instance['limit']);
         echo $before_widget;
?> <h3 class="sidebar_title">Random Posts</h3>
<ul id="last-posts">
			<?php $posts =query_posts(array(
"post__not_in"	 =>	get_option("sticky_posts"),
"orderby"	 =>	rand,
"showposts"	 =>	$limit  
));
  ?>  
				<?php while(have_posts()) : the_post(); ?> 
                <li><a title="Title" href="<?php the_permalink() ?>">
 <img src="<?php echo the_first_img() ?>" width="50px" height="50px" alt="<?php the_title(); ?>"/>
 </a><div class="side-title"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?> | Category: <?php foreach((get_the_category()) as $category) { echo $category->cat_name . ' '; }?>" ><?php the_title_attribute(); ?></a></div><div>
<h4 style="color:#0099CC"><?php  the_time('M j, Y') ; ?> 
<span>·</span>
<a title="Comments on <?php the_title(); ?>" href="<?php the_permalink() ?>#comments"><?php comments_number('0', '1', '%' );?> <?php _e(' Comments','Anti'); ?></a></h4> 
</div></li> 
        <?php endwhile;wp_reset_query(); ?> 
		</ul>
		
		 
<?php		 
         echo $after_widget;
     }
     function update($new_instance, $old_instance) {
         if (!isset($new_instance['submit'])) {
             return false;
         }
         $instance = $old_instance;
        
         $instance['limit'] = strip_tags($new_instance['limit']);
         return $instance;
     }
     function form($instance) {
         global $wpdb;
         $instance = wp_parse_args((array) $instance, array('limit' => ''));
        
         $limit = strip_tags($instance['limit']);
 ?>
        
         <p>
             <label for="<?php echo $this->get_field_id('limit'); ?>">显示数量：<input class="widefat" id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="text" value="<?php echo $limit; ?>" /></label>
         </p>
         <input type="hidden" id="<?php echo $this->get_field_id('submit'); ?>" name="<?php echo $this->get_field_name('submit'); ?>" value="1" />
 <?php
     }
 }
 add_action('widgets_init', 'anti_widget4_init');
 function anti_widget4_init() {
     register_widget('anti_widget4');
 }
 /////////////////
 
 
 /////////////友情链接/////////
class  anti_widget5 extends WP_Widget {
     function anti_widget5() {
         $widget_ops = array('description' => '双栏的友情链接');
         $this->WP_Widget('anti_widget5', 'anti-友情链接', $widget_ops);
     }
     function widget($args, $instance) {
         extract($args);
        
         $limit = strip_tags($instance['limit']);
		 $orderby = strip_tags($instance['orderby']);
		 $cats = strip_tags($instance['cats']);
        echo $before_widget;
?> 
<h3 class="sidebar_title">Sitelinks</h3>
         <ul  class="tworow clearfix">
			<?php wp_list_bookmarks( array(
			'limit' => $limit,
			'hide_empty' => 1,
			'category'  => $cats,
			'categorize' => 0,
			'title_li' => '',
			'orderby' => $orderby,
			'order' => 'ASC',
			'echo' => 1
			)
			);
		?>
		</ul>		
		 
<?php		 
         echo $after_widget;
     }
     function update($new_instance, $old_instance) {
         if (!isset($new_instance['submit'])) {
             return false;
         }
         $instance = $old_instance;          
         $instance['limit'] = strip_tags($new_instance['limit']);
		 $instance['orderby'] = strip_tags($new_instance['orderby']);
		 $instance['cats'] = strip_tags($new_instance['cats']);
         return $instance;
     }
     function form($instance) {
         global $wpdb;
         $instance = wp_parse_args((array) $instance, array('limit' => '-1', 'cats' => '', 'orderby' => 'name'));        
         $limit = strip_tags($instance['limit']);
		 $orderby = strip_tags($instance['orderby']);
		 $cats = strip_tags($instance['cats']);
 ?>
         
         <p>
             <label for="<?php echo $this->get_field_id('limit'); ?>">数量：默认“-1”为全部显示。<br>如果需要限时数量，输入具体数值<input class="widefat" id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="text" value="<?php echo $limit; ?>" /></label>
         </p>
		  <p>
             <label for="<?php echo $this->get_field_id('cats'); ?>">显示分类：<br>● 默认不填写即显示所有分类里的链接<br>● 填写某分类的ID，显示此分类下的链接<input class="widefat" id="<?php echo $this->get_field_id('cats'); ?>" name="<?php echo $this->get_field_name('cats'); ?>" type="text" value="<?php echo $cats; ?>" /></label>
         </p>
		 <p>
             <label for="<?php echo $this->get_field_id('orderby'); ?>">排序：<br>● 默认“name”按名称排列<br>● 如果需要其他排列，输入相应的排序形式。<a target="_blank" href="http://codex.wordpress.org/Function_Reference/wp_list_bookmarks">查看orderby排序参数</a><input class="widefat" id="<?php echo $this->get_field_id('orderby'); ?>" name="<?php echo $this->get_field_name('orderby'); ?>" type="text" value="<?php echo $orderby; ?>" /></label>
         </p>
         <input type="hidden" id="<?php echo $this->get_field_id('submit'); ?>" name="<?php echo $this->get_field_name('submit'); ?>" value="1" />
 <?php
     }
 }
 add_action('widgets_init', 'anti_widget_init5');
 function anti_widget_init5() {
     register_widget('anti_widget5');
 }


class anti_widget8 extends WP_Widget {
    function anti_widget8() {
        $widget_ops = array('description' => '热门文章小工具');
        $this->WP_Widget('anti_widget8', 'Anti-热门文章', $widget_ops);
    }
    function widget($args, $instance) {
        extract($args);
        $limit = strip_tags($instance['limit']);
		$poptime = strip_tags($instance['poptime']);
        echo $before_widget;	
?>
		<h3 class="sidebar_title">Popular Posts</h3>
<ul id="last-posts">
			<?php $posts =query_posts(array(
"post__not_in"	 =>	get_option("sticky_posts"),
"orderby"	 =>	comment_count,
"showposts"	 =>	$limit  
));
  ?>  
				<?php while(have_posts()) : the_post(); ?> 
                <li><a title="Title" href="<?php the_permalink() ?>">
<img src="<?php echo the_first_img() ?>" width="50px" height="50px" alt="<?php the_title(); ?>"/>
</a><div class="side-title"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?> | Category: <?php foreach((get_the_category()) as $category) { echo $category->cat_name . ' '; }?>" ><?php the_title_attribute(); ?></a></div><div>
<h4 style="color:#0099CC"><?php  the_time('M j, Y') ; ?> 
<span>·</span>
<a title="Comments on <?php the_title(); ?>" href="<?php the_permalink() ?>#comments"><?php comments_number('0', '1', '%' );?> <?php _e(' Comments','Anti'); ?></a></h4> 
</div></li> 
        <?php endwhile;wp_reset_query(); ?> 
		</ul>
		  
<?php	
        echo $after_widget;
    }
	
    function update($new_instance, $old_instance) {
        if (!isset($new_instance['submit'])) {
            return false;
        }
        $instance = $old_instance;
        $instance['limit'] = strip_tags($new_instance['limit']);
		$instance['poptime'] = strip_tags($new_instance['poptime']);
        return $instance;
    }
    function form($instance) {
        global $wpdb;
        $instance = wp_parse_args((array) $instance, array('limit' => ''));
        $limit = strip_tags($instance['limit']);
		$poptime = strip_tags($instance['poptime']);
?>
        
    <p><label for="<?php echo $this->get_field_id('limit'); ?>">文章数量：<input id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="text" value="<?php echo $limit; ?>" /></label></p>
	<p><label for="<?php echo $this->get_field_id('poptime'); ?>" >热评文章时间范围:<br>（例如希望Popular栏目显示90天内评论最多的文章，则输入“90”）<input id="<?php echo $this->get_field_id('poptime'); ?>" name="<?php echo $this->get_field_name('poptime'); ?>" type="text" value="<?php echo $poptime; ?>" /></label></p>
    <input type="hidden" id="<?php echo $this->get_field_id('submit'); ?>" name="<?php echo $this->get_field_name('submit'); ?>" value="1" />
<?php
    }
}
add_action('widgets_init', 'anti_widget8_init');
function anti_widget8_init() {
    register_widget('anti_widget8');
}

class anti_widget9 extends WP_Widget {
    function anti_widget9() {
        $widget_ops = array('description' => '主题自带的文章分类小工具');
        $this->WP_Widget('anti_widget9', 'Anti-文章分类', $widget_ops);
    }
    function widget($args, $instance) {
        extract($args);
        echo $before_widget;	
?>
		<h3 class="sidebar_title">Categories</h3>

		<ul class="tworow clearfix"><?php wp_list_categories('&title_li='); ?></ul>
<?php	
        echo $after_widget;
    }
    function form($instance) {
        global $wpdb;
?>
    <p>该工具没有选项!</p>
<?php
    }
}
add_action('widgets_init', 'anti_widget9_init');
function anti_widget9_init() {
    register_widget('anti_widget9');
}
class anti_widget10 extends WP_Widget {
    function anti_widget10() {
        $widget_ops = array('description' => '最近文章小工具');
        $this->WP_Widget('anti_widget10', 'anti-最近文章', $widget_ops);
    }
    function widget($args, $instance) {
        extract($args);
        $limit = strip_tags($instance['limit']);
        echo $before_widget;
?>
		<h3 class="footer_title">Recent Posts</h3>

		<ul id="last-posts">
			<?php $posts =query_posts(array(
"post__not_in"	 =>	get_option("sticky_posts"),
"orderby"	 =>	date,
"showposts"	 =>	$limit  
));
  ?>   
				<?php while(have_posts()) : the_post(); ?> 
                <li><a title="Title" href="<?php the_permalink() ?>">
<img src="<?php echo the_first_img() ?>" width="50px" height="50px" alt="<?php the_title(); ?>"/>
</a><div class="side-title"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?> | Category: <?php foreach((get_the_category()) as $category) { echo $category->cat_name . ' '; }?>" ><?php the_title_attribute(); ?></a></div><div>
<h4 style="color:#0099CC"><?php  the_time('M j, Y') ; ?> 
<span>·</span>
<a title="Comments on <?php the_title(); ?>" href="<?php the_permalink() ?>#comments"><?php comments_number('0', '1', '%' );?> <?php _e(' Comments','Anti'); ?></a></h4> 
</div></li> 
        <?php endwhile;wp_reset_query(); ?> 
		</ul>
<?php	
        echo $after_widget;
    }
	
    function update($new_instance, $old_instance) {
        if (!isset($new_instance['submit'])) {
            return false;
        }
        $instance = $old_instance;
        $instance['limit'] = strip_tags($new_instance['limit']);
        return $instance;
    }
    function form($instance) {
        global $wpdb;
        $instance = wp_parse_args((array) $instance, array('limit' => ''));
        $limit = strip_tags($instance['limit']);
?>  
    <p><label for="<?php echo $this->get_field_id('limit'); ?>">文章数量：<input id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="text" value="<?php echo $limit; ?>" /></label></p>
    <input type="hidden" id="<?php echo $this->get_field_id('submit'); ?>" name="<?php echo $this->get_field_name('submit'); ?>" value="1" />
<?php
    }
}
add_action('widgets_init', 'anti_widget10_init');
function anti_widget10_init() {
    register_widget('anti_widget10');
}

?>