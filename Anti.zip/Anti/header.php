<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="UTF-8">
<title>
<?php
        /*
       * Print the <title> tag based on what is being viewed.
       */
        global $page, $paged;

        wp_title('|', true, 'right');

        // Add the blog name.
        bloginfo('name');

        // Add the blog description for the home/front page.
        $site_description = get_bloginfo('description', 'display');
        if ($site_description && (is_home() || is_front_page()))
            echo " | $site_description";

        // Add a page number if necessary:
        if ($paged >= 2 || $page >= 2)
            echo ' | ' . sprintf(__('Page %s', 'android'), max($paged, $page));

        ?>
</title>
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="all" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<link rel="alternate" type="application/rss+xml" title="RSS 2.0 - All Posts" href="<?php bloginfo( 'rss2_url' ); ?>" />
<link rel="alternate" type="application/rss+xml" title="RSS 2.0 - All Comments" href="<?php bloginfo('comments_rss2_url'); ?>" />
<link rel="Shortcut Icon" href="<?php bloginfo('template_directory');?>/images/favicon.ico" type="image/x-icon" />
<link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/jquery.js"></script>
<!--[if IE 6]>
<html id="ie6" class="is_ie" <?php language_attributes(); ?>>
<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>	
<![endif]-->
<!--[if IE 7]>
<html id="ie7" class="is_ie" <?php language_attributes(); ?>>
<link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/hack/ie7.css" type="text/css" media="all" />
<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>	
<![endif]-->
<!--[if IE 8]>
<html id="ie8" class="is_ie" <?php language_attributes(); ?>>
<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>	
<![endif]-->
<!--[if IE 9]>
<html id="ie9" class="is_ie" <?php language_attributes(); ?>>
<![endif]-->
<?php wp_head(); ?>
<?php if ( is_singular() ){ ?>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/comments-ajax.js"></script>
<?php } ?>
<?php if( dopt('anti_track_b') != '' ) echo dopt('anti_track'); ?>
</head>
<body <?php body_class(); ?>>
<header>  

  <div class="header-inner">
    
    <ul id="nav"><li<?php if (is_home() || is_front_page()) echo ' class="current_page_item"'; ?>><a href="<?php bloginfo('url');?>" rel="home" title="<?php bloginfo('name');?>">HOME</a></li></ul>
      <?php wp_nav_menu( array( 'theme_location' => 'header-menu','menu_id'=>'nav','container'=>'ul','fallback_cb' => 'link_to_menu_editor')); ?>

    <div id="topsearch"><form id="searchform" action="" method="get" name="searchform">
<input id="search" type="text" onfocus="if (this.value == 'To search type and hit enter') {this.value = '';}" onblur="if (this.value == '') {this.value = 'To search type and hit enter';}" name="s" value="To search type and hit enter">
<input id="searchsubmit" type="hidden">
</form></div>
	
  </div>

</header>
<div id="container-bottom"><div id="slogan"><div id="smargin">
<h1><a href="<?php bloginfo('url');?>" title="<?php bloginfo('name');?>" class="logo">
      <?php bloginfo('name');?>
      </a></h1><div id="top" class="tagline">
<h3>
<?php if( dopt('anti_description') != '' ) {echo dopt('anti_description');}  else {echo'Wordpress Theme Anti By Fatesinger And SmallButterfly.' ;}?>
</h3>
</div><div class="slogan">
<h1>
<?php if( dopt('anti_headcode_b') != '' ) {echo dopt('anti_headcode');}  else {echo'Here you can find a selection of my latest work for your appraisal.<br>As you will see, my portfolio reflects my skills in usability and user experience.' ;}?>
</h1></div>
</div></div> 	 </div> 