<?php get_header(); ?>
	<article>        
			<div id="border-container"></div>	
			<div id="content">
			 <div id="left-entry">	<div class="default-page">			
				    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>													
				     <div class="entry-post">
				      
					   <h2 class="title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h2> 	
					  	 
  				
				        <div class="post-content">									
					        <?php the_content(__('Read More'));?>
						</div>
                        <div class="clear"></div>
					
                        <div class="single_tags">													
					
								
						</div>
						
					<?php comments_template( '', true ); ?>

					
				
				<?php endwhile; endif;?>    
				
				<div class="clear"></div></div></div></div><?php get_sidebar(); ?>
			</div>
		
			
		<div class="clear"></div>  
		
	</article>
	  <?php get_footer(); ?>