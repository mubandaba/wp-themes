$(function() {
	$('#content h2 a').click(function(e) {
		e.preventDefault();
		var htm = '假装异步加载ing',
		i = 9,
		t = $(this).html(htm).unbind('click'); (function ct() {
			i < 0 ? (i = 9, t.html(htm), ct()) : (t[0].innerHTML += '.', i--, setTimeout(ct, 200))
		})();
		window.location = this.href
	})
});
$(".pingpart").click(function() {
	$(this).css({
		color: "#b3b3b3"
	});
	$(".commentshow").hide(400);
	$(".pingtlist").show(400);
	$(".commentpart").css({
		color: "#A0A0A0"
	})
});
$(".commentpart").click(function() {
	$(this).css({
		color: "#b3b3b3"
	});
	$(".pingtlist").hide(400);
	$(".commentshow").show(400);
	$(".pingpart").css({
		color: "#A0A0A0"
	})
});
$('.report, .report1').click(function() {
	$body.animate({
		scrollTop: $('#comment').offset().top
	},
	400)
});
jQuery(document).ready(function($) {
	$body = (window.opera) ? (document.compatMode == "CSS1Compat" ? $('html') : $('body')) : $('html,body');//commentnav ajax
	$('.commentnav a').live('click',function(e) {
		e.preventDefault();
		$.ajax({
			type: "GET",
			url: $(this).attr('href'),
			beforeSend: function() {
				$('.commentnav').remove();
				$('.commentlist').remove();
				$('#loading-comments').slideDown();
			},
			dataType: "html",
			success: function(out) {
				result = $(out).find('.commentlist');
				nextlink = $(out).find('.commentnav');
				$('#loading-comments').slideUp(550);
				$('#loading-comments').after(result.fadeIn(800));
				$('.commentlist').after(nextlink);
				$(".reply").ajaxReply();//绑定@事件
				$(".text p a").bigfaCom();
				$(".commentsgood").bigfaReply();
			}
		});
	});	
});
jQuery.fn.ajaxReply = function(){$(this).click(//@ + username
	function(){	
    var atname = $(this).parent().find('.name').text();
$("#comment").attr("value","@" + atname + "：").focus();
});
$('.cancel_comment_reply a').click(function() {
$("#comment").attr("value",'');
	});
};
$(".reply").ajaxReply();
jQuery.fn.bigfaCom = function(){
var id = /^#comment-/;
var at = /^@/;
$(this).each(function() {
	if ($(this).attr('href').match(id) && $(this).text().match(at)) {
		$(this).addClass('atreply');
	}
});
$('.atreply').hover(function() {
	$($(this).attr('href')).find('div:first').clone().hide().insertAfter("body").attr('id', '').addClass('tip').fadeIn(200);
},
function() {
	$('.tip').fadeOut(400,
	function() {
		$(this).remove();
	});
});
$('.atreply').mousemove(function(e) {
	$('.tip').css({
		left: (e.pageX + 18),
		top: (e.pageY + 18)
	})
});
};
$(".text p a").bigfaCom();
jQuery.fn.bigfaReply = function(){
$(this).hover(function(){$(this).find(".reply").fadeIn(0);},function(){$(this).find(".reply").fadeOut(0);});
};
$(".commentsgood").bigfaReply();
jQuery(document).ready(function($) {
	$('.reply').click(function() {
		var atid = '"#' + $(this).parent().parent().attr("id") + '"';
		var atname = $(this).parent().find('.name').text();
		$("#comment").attr("value", "@" + atname + " ：").focus();
	});
	$('.cancel_comment_reply a').click(function() {
		$("#comment").attr("value", '');
	});
})
$("#nav ul").css({
		display: "none"
	});
$("#nav li").hover(function() {
		$(this).find('ul:first').css({
			display: "none"
		}).filter(":not(:animated)").animate({
			opacity: "show",
			height: "show"
		}, "fast ")
	}, function() {
		$(this).find('ul:first').animate({
			opacity: "hide",
			height: "hide"
		}, "100")
	});	
$(".link-back2top a").click(function() {
	$("body,html").animate({
		scrollTop: 0
	},
	800);
	return false;
});	