<div id="footerwrap-top"></div>
<footer>
  <div class="footer-inner">
    <div id="footerinfo"> 
	
	<div class="ToolText" onmouseout="javascript:this.className='ToolText'" onmouseover="javascript:this.className='ToolTextHover'"><div class="link-back2top"><a href="#"> <img class="logo-footer" alt="Sense" src="<?php bloginfo('template_directory'); ?>/images/logo.png"> </a></div><span></span></div>
      <?php if ( ! dynamic_sidebar( 'sidebar2' )) : ?>
      <?php endif; ?>
      
	  
      <div class="last-footer widget_iuliann_flickr">
        <h3 class="footer_title">Flickr</h3>
        <div class="flickr"> <a href="http://www.flickr.com/photos/shlomikremer/8624343652/"> <img width="75" height="75" title="Jaffa" alt="Flickr 上的一張相片" src="http://farm9.staticflickr.com/8103/8624343652_054d8d39dd_s.jpg"> </a> <a href="http://www.flickr.com/photos/shlomikremer/8623223539/"> <img width="75" height="75" title="The Port of Jaffa" alt="Flickr 上的一張相片" src="http://farm9.staticflickr.com/8544/8623223539_2ed1ecf6de_s.jpg"> </a> <a href="http://www.flickr.com/photos/shlomikremer/8623223539/"> <img width="75" height="75" title="The Port of Jaffa" alt="Flickr 上的一張相片" src="http://farm9.staticflickr.com/8544/8623223539_2ed1ecf6de_s.jpg"> </a> <a href="http://www.flickr.com/photos/shlomikremer/8623223539/"> <img width="75" height="75" title="The Port of Jaffa" alt="Flickr 上的一張相片" src="http://farm9.staticflickr.com/8544/8623223539_2ed1ecf6de_s.jpg"> </a> <a href="http://www.flickr.com/photos/shlomikremer/8623223539/"> <img width="75" height="75" title="The Port of Jaffa" alt="Flickr 上的一張相片" src="http://farm9.staticflickr.com/8544/8623223539_2ed1ecf6de_s.jpg"> </a> <a href="http://www.flickr.com/photos/shlomikremer/8623223539/"> <img width="75" height="75" title="The Port of Jaffa" alt="Flickr 上的一張相片" src="http://farm9.staticflickr.com/8544/8623223539_2ed1ecf6de_s.jpg"> </a> <a href="http://www.flickr.com/photos/shlomikremer/8623223539/"> <img width="75" height="75" title="The Port of Jaffa" alt="Flickr 上的一張相片" src="http://farm9.staticflickr.com/8544/8623223539_2ed1ecf6de_s.jpg"> </a> <a href="http://www.flickr.com/photos/shlomikremer/8623223539/"> <img width="75" height="75" title="The Port of Jaffa" alt="Flickr 上的一張相片" src="http://farm9.staticflickr.com/8544/8623223539_2ed1ecf6de_s.jpg"> </a> <a href="http://www.flickr.com/photos/shlomikremer/8623223539/"> <img width="75" height="75" title="The Port of Jaffa" alt="Flickr 上的一張相片" src="http://farm9.staticflickr.com/8544/8623223539_2ed1ecf6de_s.jpg"> </a> </div>
      </div>
      <!-- end #flicker -->
    </div>
  </div>
  <!-- end #footer -->
</footer>
<div id="footer-bottom">
  <div id="footer-bottom-container">
    <div id="footer-bottom-entry">
      <div class="sleft"><?php if( dopt('anti_footcode_b') != '' ) {echo dopt('anti_footcode');}  else {echo'Copyright © 2013. All right reserved.' ;}?>

</div>
      <div class="sright">Anti By <a target="_blank" href="http://fatesinger.com/">Fatesinger</a> And <a target="_blank" href="http://xiaohudie.net/">SmallButterfly</a>.  </div>
    </div>
  </div>
</div>
<?php wp_footer(); ?>
<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/xBorder.js"></script>
</body></html>