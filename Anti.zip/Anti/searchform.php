<form method="get" id="searchform" class="search" action="<?php bloginfo('home');?>/">
  <input id="search" type="text" value="To search type and hit enter" name="s" onblur="if (this.value == '') {this.value = 'To search type and hit enter';}" onfocus="if (this.value == 'To search type and hit enter') {this.value = '';}">
  <input id="searchsubmit" type="hidden">
</form>
