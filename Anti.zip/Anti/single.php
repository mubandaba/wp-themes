<?php get_header(); ?>
<?php $options = get_option('Newer_options'); ?>
	<article>        
		<div id="border-container"></div>		
			<div id="content">
			<div id="share-right">
			 
			 
	<?php if ( ! dynamic_sidebar( 'sidebar3' )) : ?>
	
	<?php endif; ?>
			</div>
			<div id="center-entry">
			 	<div class="single_post">				
				    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>													
				     <div class="entry-post">
				      
					   <h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h2> 	
					  	 <div class="single-meta"> <div class="single-calendar"><?php the_time('D,g:h A'); ?></div>
      
      <div class="single-author">
<?php the_author();?>
</div><div class="single-comm">
<?php comments_popup_link('还没有评论', '只有1条评论', '已有%条评论'); ?>
</div><div class="single-cat">
<?php the_category(', ') ?>
</div> </div>
    <!--.postMeta-->				
				        <div class="post-content">									
					        <?php the_content(__('Read More'));?><?php wp_link_pages( array( 'before' => '<div class="page-link"><span>' . __( 'Pages:', 'falla' ) . '</span>', 'after' => '</div>' ) ); ?>
						</div>
                        <div class="clear"></div>
					<div class="author-wrap">
<div class="author-avatar">
<?php echo get_avatar( get_the_author_meta( 'user_email' ), apply_filters( 'android_author_bio_avatar_size', 68 ) ); ?>
</div><div class="author-info">
<div class="author-name">
<a title="Visit Bigfa’s website" href="http://fatesinger.com"><?php  the_author(); ?></a>
</div>
<div class="author-description">
<?php   the_author_meta( 'description' ) ; ?>
</div>
</div></div>
                        <div class="single_tags">													
					
								
						</div>
						
					<?php comments_template( '', true ); ?>

					
				
				<?php endwhile; endif;?>    
				
				<div class="clear"></div></div></div></div><?php get_sidebar(); ?>
			</div>
		
			
		<div class="clear"></div>  
		
	</article>
	  <?php get_footer(); ?>