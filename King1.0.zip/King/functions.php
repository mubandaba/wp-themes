<?php
require get_template_directory() . '/inc/setting.php';   //setting
require get_template_directory() . '/inc/views.php';   //views
require get_template_directory() . '/inc/like.php';   //文章点赞
require get_template_directory() . '/inc/rewrite.php';   //页面伪静态
?>