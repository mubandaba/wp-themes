                    <footer class="footer reveal">
                        <p>版权所有 © <?php the_time('Y') ?> <?php bloginfo('name'); ?> · Theme By <a href="http://ztomo.com/downloads/king" title="King">King</a> · <?php echo  stripslashes(get_option('king_zztj'));?></p>
                    </footer>
                    <script>
$(document).ready(function() { 
$.fn.postLike = function() {
 if ($(this).hasClass('done')) {
 return false;
 } else {
 $(this).addClass('done');
 var id = $(this).data("id"),
 action = $(this).data('action'),
 rateHolder = $(this).children('.count');
 var ajax_data = {
 action: "bigfa_like",
 um_id: id,
 um_action: action
 };
 $.post("<?php echo get_option('home'); ?>/wp-admin/admin-ajax.php", ajax_data,
 function(data) {
 $(rateHolder).html(data);
 });
 return false;
 }
};
$(document).on("click", ".favorite",
function() {
 $(this).postLike();
});
}); 
</script>
                </div>
            </div>
        </main>
    </body>
</html>