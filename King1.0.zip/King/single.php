<?php get_header(); ?>
<?php if (have_posts()) : the_post(); update_post_caches($posts); ?>
<?php setPostViews(get_the_ID()); ?>  
                    <article class="article reveal">
                        <header class="article-header">
                             <h2><?php the_title(); ?></h2>
                            <p></p>
                            <div class="article-list-footer"> <span class="article-list-date"><?php the_time('Y-n-j') ?></span>
 <span class="article-list-divider">-</span>
 <span class="article-list-minutes"><?php echo getPostViews(get_the_ID()); ?>  </span>
                            </div>
                        </header>
                         <div class="article-content">
                          <?php the_content(); ?>
                          <div class="post-like">
         <a href="javascript:;" data-action="ding" data-id="<?php the_ID(); ?>" class="favorite<?php if(isset($_COOKIE['bigfa_ding_'.$post->ID])) echo ' done';?>"><i class="czs-heart-l"></i><span class="count">
            <?php if( get_post_meta($post->ID,'bigfa_ding',true) ){            
                    echo get_post_meta($post->ID,'bigfa_ding',true);
                 } else {
                    echo '0';
                 }?></span>
        </a>
 </div>
                         </div>
                    </article>
<?php endif; ?>
<?php get_footer(); ?>