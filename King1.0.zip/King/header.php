<html>
    <head>
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title><?php if ( is_home() ) {
		bloginfo('name'); echo " - "; bloginfo('description');
	} elseif ( is_category() ) {
		single_cat_title(); echo " - "; bloginfo('name');
	} elseif (is_single() || is_page() ) {
		single_post_title();
	} elseif (is_search() ) {
		echo "搜索结果"; echo " - "; bloginfo('name');
	} elseif (is_404() ) {
		echo '没有找到页面';
	} else {
		wp_title('',true);
	} ?></title>
	    <meta name="keywords" content="<?php echo get_option('king_gjc');?>"/>
        <meta name="description" content="<?php echo get_option('king_ms');?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link type="text/css" rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>">
        <link type="text/css" rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/caomei-cion.css">
        <script src="<?php bloginfo('template_url'); ?>/js/jquery.min.js"></script>
    </head>
        <body>
        <main role="main">
            <div class="grid grid-centered">
                <div class="grid-cell">
                    <nav class="header-nav reveal"> <a href="<?php echo get_option('home'); ?>" class="header-logo" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a></nav>