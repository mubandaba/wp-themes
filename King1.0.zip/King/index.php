<?php get_header(); ?>
                    <ul class="article-list">
                        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                        <li class="article-list-item reveal">
                            <a href="<?php the_permalink(); ?>" title="BootCDN 昨晚遭到严重的 CC 攻击，现在已恢复">
                                 <h5><?php the_title(); ?><span class="icon icon-ios-arrow-thin-right"></span></h5>
                            </a>
                            <p>
                                <p><?php echo wp_trim_words(get_the_excerpt(), 90); ?></p>
                            </p>
                            <div class="article-list-footer">
                                <span class="article-list-date"><?php the_time('Y-n-j') ?></span>
                                <span class="article-list-divider">-</span>
                                <span class="article-list-minutes"><?php echo getPostViews(get_the_ID()); ?></span>
                        </li>
                        <?php endwhile; ?>
                        <?php else : ?>
                        <h3 class="title"><a href="#" rel="bookmark">未找到</a></h3>
                        <p>没有找到任何文章！</p>
                        <?php endif; ?>
                    </ul>
<?php get_footer(); ?>