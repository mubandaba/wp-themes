<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title><?php echo bzg_seo_title(); ?></title>
	<?php
		$bzg_description = bzg_seo_description();
		if( ! empty( $bzg_description ) ) {
			echo '<meta name="description" content="' . $bzg_description . '" />';
			echo "\n";
		}
	?>
	<link rel="profile" href="http://gmpg.org/xfn/11" />	
	<?php wp_head(); ?>
	<?php if( is_home() ) : ?>
	<script type="text/javascript">
		jQuery(document).ready(function(){
			jQuery('#slider').unslider({
				animation: 'vertical',
				autoplay: true,
				arrows: []
			});
		});
	</script>
	<?php endif; ?>
</head>

<body <?php body_class(); ?>>
<header id="branding" role="banner">
	<nav class="bar" role="navigation">
		<h1>页面导航</h1>
		<ul>
		<?php
			function bzg_page_nav() {
				wp_list_pages( 'sort_column=menu_order&depth=1&title_li=' );
			}
			wp_nav_menu( array( 'depth' => 1, 'container' => false, 'menu' => false, 'menu_class' => false, 'theme_location' => 'itmw_top_nav', 'items_wrap' => '%3$s', 'fallback_cb' => 'bzg_page_nav' ) );
		?>
		</ul>
	</nav>
	<div class="top">
		<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo get_option('site_logo') ? get_option('site_logo') : get_bloginfo('template_url') . '/img/logo.png'; ?>" alt="<?php echo get_option('blogname'); ?>" width="245" height="70" /></a></h1>
		<nav id="primary-nav" role="navigation">
			<h1 class="nav-toggle dashicons-before dashicons-menu"><span>网站导航</span></h1>
			<ul>
			<?php
				function bzg_primary_nav() {
					echo '<li class="menu-item-home"><a href="' . esc_url( home_url( '/' ) ) . '" rel="home">首页</a></li>';
					wp_list_categories( 'orderby=id&title_li=&show_count=0&depth=1&hide_empty=0&hierarchical=1&use_desc_for_title=' );
				}
				wp_nav_menu( array( 'depth' => 1, 'container' => false, 'menu' => false, 'menu_class' => false, 'theme_location' => 'itmw_primary_nav', 'items_wrap' => '%3$s', 'fallback_cb' => 'bzg_primary_nav' ) );
			?>
			</ul>
		</nav>
	</div>
	<div class="bottom">
		<div class="notice">
			<i class="dashicons dashicons-controls-volumeon"></i>
			<?php
				if( get_option( 'site_notice' ) ) {
					echo get_option( 'site_notice' );
				} else {
					echo '欢迎访问' . get_option('blogname');
				}
			?>
		</div>
		<div class="contact">
			<ul>
				<li><a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo get_option('company_qq'); ?>&site=qq&menu=yes" target="_blank"><img src="<?php bloginfo('template_url'); ?>/img/qq.png" alt="联系QQ" /></a></li>
				<li><a href="mailto:<?php echo get_option('company_email'); ?>" target="_blank"><img src="<?php bloginfo('template_url'); ?>/img/email.png" alt="联系邮箱" /></a></li>
				<li><img src="<?php bloginfo('template_url'); ?>/img/tel.png" alt="联系电话" /><span class="tel"><?php echo get_option('company_tel'); ?><span></li>
			</ul>
		</div>
	</div>
</header>

<?php if( ! is_home() && ! is_404() ) : ?>
	<div id="page-banner">
		<img src="<?php bloginfo('template_url'); ?>/img/page-banner.jpg" alt="内页Banner" />
	</div>
<?php endif; ?>
		
<div id="wrapper">