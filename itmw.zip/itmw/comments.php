<?php 
if ( post_password_required() || !comments_open() )
	return;

if( is_singular() )
	$comment_title = '评论';
else
	$comment_title = '留言';
?>

<div id="comments" class="comments-area">
<?php if ( have_comments() ) : ?>
	<h2 class="comment-title"><?php echo '用户' . $comment_title; ?></h2>
	<ol class="comment-list">
		<?php
			$comments = get_comments( array(
				'post_id' => $id,
				'orderby' => 'comment_date',
				'order' => 'ASC',
				'type' => 'comment',
			) );
			foreach($comments as $comment) {
		?>

		<li id="comment-<?php comment_ID(); ?>">
			<article id="div-comment-<?php comment_ID(); ?>" class="comment-body">
				<footer class="comment-meta">
					<div class="comment-author vcard">
						<?php echo get_avatar( $comment, 36 ); ?>
						<?php printf( __( '%s <span class="says">says:</span>' ), sprintf( '<b class="fn">%s</b>', get_comment_author_link( $comment ) ) ); ?>
					</div><!-- .comment-author -->

					<div class="comment-metadata">
						<time datetime="<?php comment_time( 'c' ); ?>">
							<?php
								/* translators: 1: comment date, 2: comment time */
								printf( __( '%1$s at %2$s' ), get_comment_date( '', $comment ), get_comment_time() );
							?>
						</time>
						<?php
							comment_reply_link( array(
								'add_below' => 'div-comment',
								'depth'     => -1,
								'max_depth' => 0,
								'before'    => '<span class="reply">',
								'after'     => '</span>'
							));
						?>
						<?php edit_comment_link( __( 'Edit' ), '<span class="edit-link">', '</span>' ); ?>
					</div><!-- .comment-metadata -->

					<?php if ( '0' == $comment->comment_approved ) : ?>
						<p class="comment-awaiting-moderation"><?php _e( 'Your comment is awaiting moderation.' ); ?></p>
					<?php endif; ?>
				</footer><!-- .comment-meta -->

				<div class="comment-content">
					<?php if( $comment->comment_parent ) : ?>
						<blockquote class="parent-comment">
							<p class="parent-author"><?php comment_author( $comment->comment_parent ); ?> 发表于 <?php comment_date( 'Y-m-d', $comment->comment_parent ); ?></p>
							<p class="parent-content"><?php comment_excerpt( $comment->comment_parent ); ?></p>
						</blockquote>
					<?php endif; ?>
					<?php comment_text(); ?>
				</div><!-- .comment-content -->
			</article>
		</li>
	<?php } ?>
	</ol>
<?php endif; ?><!-- .comment-list -->
	
	<?php 
		comment_form( array(
			'id_form' => 'commentform',
			'id_submit' => 'submit',
			'title_reply' => '发表' . $comment_title,
			'title_reply_to' => '回复',
			'cancel_reply_link' => '取消回复',
			'label_submit' => '提交' . $comment_title,'comment_notes_before' => '',
			'comment_notes_after' => '',
			'fields' => apply_filters( 'comment_form_default_fields', array(
				'author' => '<p class="comment-form-author"><label for="author">昵称' . ( $req ? '<span class="required"> (必填)</span>' : '' ) . '</label><input placeholder="昵称" id="author" name="author" type="text" size="30" value="' . esc_attr( $commenter['comment_author'] ) . '"' . ( $req ? ' aria-required="true"' : '' ) . ' /></p>',
				'email' => '<p class="comment-form-email"><label for="email">邮箱' . ( $req ? '<span class="required"> (必填)</span>' : '' ) . '</label><input placeholder="邮箱" id="email" name="email" type="email" size="30" value="' . esc_attr(  $commenter['comment_author_email'] ) . '"' . ( $req ? ' aria-required="true"' : '' ) . ' /></p>',
				'url' => '<p class="comment-form-url"><label for="url">网址</label><input placeholder="网址" id="url" name="url" type="url" size="30" value="' . esc_attr( $commenter['comment_author_url'] ) . '" /></p>',
				)
			),
			'comment_field' =>  '<p class="comment-form-comment"><label for="comment">' . $comment_title . '</label><textarea placeholder="我要吐槽..." id="comment" name="comment" cols="45" rows="4" aria-required="true"></textarea></p>',
		) );
	?>
</div>