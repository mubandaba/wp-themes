<div id="secondary" role="complementary">
	<aside id="product-cat">
		<h3>产品分类</h3>
		<ul>
			<?php wp_list_categories( 'orderby=id&title_li=&show_count=0&hide_empty=0&hierarchical=1&use_desc_for_title=&child_of=' . get_option('itmw_product_cat') ); ?>
		</ul>
	</aside>
	<aside id="hot">
		<h3>热门资讯</h3>
		<ul>
			<?php bzg_get_most_viewed(10, 40); ?>
		</ul>
	</aside>
</div>