<?php if( have_posts() ) : ?>
<?php while( have_posts() ) : the_post(); ?>
	<article class="entry">
		<h1><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title_attribute(); ?></a></h1>
		<footer class="post-meta">
			<time class="dashicons-before dashicons-clock" datetime="<?php the_time( 'c' ); ?>" pubdate><?php the_time( 'Y-m-d' ); ?></time>
			<span class="views dashicons-before dashicons-visibility">阅读(<?php echo bzg_post_views(); ?>)</span>
			
			<?php if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) : ?>
				<span class="comments-links dashicons-before dashicons-admin-comments">评论(<?php comments_popup_link( '0', '1', '%' ); ?>)</span>
			<?php endif; ?>
			
			<?php edit_post_link( '编辑', '<span class="edit dashicons-before dashicons-edit">', '</span>' ); ?>
		</footer>
		<p class="excerpt"><?php echo mb_strimwidth(wp_strip_all_tags($post->post_content, true), 0, 200, '...' ); ?></p>
	</article>
	<?php endwhile; ?>
	<?php bzg_paging_nav(); ?>
	<?php wp_reset_query(); ?>
<?php endif; ?>