<?php get_header(); ?>

	<div id="slider">
		<ul>
		<?php
		$slides = get_option('slide');
		$slides = unserialize($slides);
		if($slides) {
			foreach($slides as $slide) {
				echo '<li><a href="' . $slide['link'] . '" target="_blank"><img src="' . $slide['img'] . '" alt="' . $slide['alt'] . '" /></a></li>';
			}
		} else {
			echo '<li><img src="' . get_bloginfo('template_url') . '/img/banner_1.jpg" alt="幻灯片" /></li>';
			echo '<li><img src="' . get_bloginfo('template_url') . '/img/banner_2.jpg" alt="幻灯片" /></li>';
		}
		?>
		</ul>
	</div>
	
	<div id="container" role="main">
		<div id="service">
			<div class="contact-span">
				<img src="<?php bloginfo('template_url'); ?>/img/tel_4.png" alt="联系方式" />
				<span class="text-cn">联系方式</span>
				<span class="text-us">Contact Us</span>
			</div>
			<div class="contact-us">
				<p><strong>Mobile：</strong><span><?php echo get_option('company_tel'); ?></span></p>
				<p>Email：<a href="mailto:<?php echo get_option('company_email'); ?>" target="_blank"><?php echo get_option('company_email'); ?></a>&nbsp;&nbsp;QQ：<a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo get_option('company_qq'); ?>&site=qq&menu=yes" target="_blank"><?php echo get_option('company_qq'); ?></a></p>
			</div>
			<div class="slogan">
				<strong>金牌售后技术服务高枕无忧</strong>
				<p>提供尽善尽美的售前售后服务，推出12大金牌服务<span>“</span></p>
			</div>
		</div>
		
		<div id="column" class="pure-g">
			<div class="post-plan plan pure-u-9-24">
			<div class="inner">
				<section class="column-one">
					<ul>
						<?php bzg_column_list('itmw_column_one', 3, 32, 26, 70, 'thumbnail', true); ?>
					</ul>
				</section>
				<section class="column-two">
					<ul>
						<?php bzg_column_list('itmw_column_two', 3, 32, 26, 70, 'thumbnail', true); ?>
					</ul>
				</section>
			</div>
			</div>
			
			<div class="post-plan plan pure-u-9-24">
			<div class="inner">
				<section class="column-three">
					<ul>
						<?php bzg_column_list('itmw_column_three', 3, 32, 26, 70, 'thumbnail', true); ?>
					</ul>
				</section>
				<section class="column-four">
					<ul>
						<?php bzg_column_list('itmw_column_four', 3, 32, 26, 70, 'thumbnail', true); ?>
					</ul>
				</section>
			</div>
			</div>
			
			<div class="contact plan pure-u-6-24">
			<div class="inner">
				<p><img src="<?php bloginfo('template_url'); ?>/img/plan-contact.png" alt="联系我们" /></p>
				<p class="tel"><img src="<?php bloginfo('template_url'); ?>/img/tel_2.png" alt="服务热线" /><strong>服务热线：</strong><br />&nbsp;&nbsp;<?php echo get_option('company_tel'); ?></p>
				<p>公司名称：<?php echo get_option('company_name'); ?></p>
				<p>公司地址：<?php echo get_option('company_address'); ?></p>
				<!--百度地图容器-->
				<div style="width:242px;height:120px;border:#ccc solid 1px;" id="dituContent"></div>
				<script type="text/javascript" src="http://api.map.baidu.com/api?key=&v=1.1&services=true"></script>
				<script type="text/javascript">
					//创建和初始化地图函数：
					function initMap(){
						createMap();//创建地图
						setMapEvent();//设置地图事件
						addMapControl();//向地图添加控件
					}
					
					//创建地图函数：
					function createMap(){
						var map = new BMap.Map("dituContent");//在百度地图容器中创建一个地图
						var point = new BMap.Point(<?php $map = get_option( 'footer_code' ); echo $map ? $map : '106.558434,29.568996'; ?>);//定义一个中心点坐标
						map.centerAndZoom(point,12);//设定地图的中心点和坐标并将地图显示在地图容器中
						window.map = map;//将map变量存储在全局
					}
					
					//地图事件设置函数：
					function setMapEvent(){
						map.enableDragging();//启用地图拖拽事件，默认启用(可不写)
						map.enableScrollWheelZoom();//启用地图滚轮放大缩小
						map.enableDoubleClickZoom();//启用鼠标双击放大，默认启用(可不写)
						map.enableKeyboard();//启用键盘上下左右键移动地图
					}
					
					//地图控件添加函数：
					function addMapControl(){
						//向地图中添加缩放控件
					var ctrl_nav = new BMap.NavigationControl({anchor:BMAP_ANCHOR_TOP_LEFT,type:BMAP_NAVIGATION_CONTROL_LARGE});
					map.addControl(ctrl_nav);
						//向地图中添加缩略图控件
					var ctrl_ove = new BMap.OverviewMapControl({anchor:BMAP_ANCHOR_BOTTOM_RIGHT,isOpen:1});
					map.addControl(ctrl_ove);
						//向地图中添加比例尺控件
					var ctrl_sca = new BMap.ScaleControl({anchor:BMAP_ANCHOR_BOTTOM_LEFT});
					map.addControl(ctrl_sca);
					}
					
					
					initMap();//创建和初始化地图
				</script>
			</div>
			</div>
		</div>
		
	</div>
<?php get_footer(); ?>