<?php
require('include/ThemeSetting.php');
//主题控制
$themeControlOptions = array(
	'welcome' => array(
		'id' => 'welcome',
		'heading' => '欢迎',
		'type' => 'page',
		'content' => '<div style="width: 96%; padding: 2%; margin-top: 15px; text-align: center; background-color: #ff6666;"><h2 style="margin: 10px;"><a style="font-size: 32px; font-family: \'Microsoft YaHei\'; color: #ffffff; text-decoration: none;" href="https://my.laoxuehost.net/aff.php?aff=5938" target="_blank">老薛主机7折优惠码：beizigen</a></h2><p style="font-size: 18px; color: #ffffff; margin: 0;">10年PHP主机提供商，WordPress圈知名品牌，完美运行WordPress程序</p></div><p style="font-size: 14px;">欢迎使用<a href="http://www.beizigen.com" target="_blank">背字根</a>主题，本主题由<a href="https://my.laoxuehost.net/aff.php?aff=5938" target="_blank">老薛主机</a>赞助，免费开源给大家使用，制作主题需要牺牲作者大量休息时间，为了生计作者早9晚9工作也非常辛苦，希望大家多多支持作者！</p><p style="font-size: 14px;">您可以使用上面红色区域中的优惠码购买老薛主机，或者在<a href="http://shop.beizigen.com" target="_blank">背字根商店</a>购买作者提供的优质虚拟主机或VPS，以给予作者继续开发新主题的动力。</p><p style="font-size: 14px;">背字根主题简单易用，无需修改任何代码，在WordPress后台即可所见所得操作完成主题的所有设置。主题充分考虑SEO设计，相关的调用原理如下：</p><ul style="font-size: 14px; list-style-type: square; margin-left: 2em;"><li style="margin: 1em 0;">首页Title标签：主题设置的常规选项中进行设置，否则输出WordPress常规设置中“站点标题 - 副标题”；</li><li style="margin: 1em 0;">首页描述标签：主题设置的常规选项中进行设置；</li><li>分类页Title标签：添加或编辑分类时的SEO标题选项；</li><li style="margin: 1em 0;">分类页描述标签：添加或编辑分类时的图像描述选项；</li><li style="margin: 1em 0;">标签页：与分类的设置方法相同；</li><li style="margin: 1em 0;">关键词标签：该标签在多年以前就失去了SEO的作用，因此弃用；</li></ul><p style="font-size: 14px;">如果您在使用中有任何问题，请加入WordPress问题解答群讨论 <a target="_blank" href="//shang.qq.com/wpa/qunwpa?idkey=fd89f61fb0f84254ae58f2bcd225eaf7df8eeda0406c9dc15cced9837952e8b3"><img border="0" src="//pub.idqqimg.com/wpa/images/group.png" alt="WordPress问题解答" title="WordPress问题解答"></a></p>',
	),
	'routine' => array(
		'id' => 'routine',
		'heading' => '常规',
		'feild' => array(
			'site_logo' => array(
				'type' => 'file',
				'label' => '网站LOGO',
				'name' => 'site_logo',
				'width' => 200,
				'height' => 57,
				'default' => get_bloginfo('template_url') . '/img/logo.png',
			),
			'home_title' => array(
				'type' => 'input',
				'label' => '首页SEO标题',
				'name' => 'home_title',
				'dsc' => '首页title标签的内容，只显示在首页title标签中',
			),
			'home_description' => array(
				'type' => 'textarea',
				'label' => '首页SEO描述',
				'name' => 'home_description',
				'dsc' => '首页description描述标签的内容，只显示在首页description标签中',
			),
			'company_qq' => array(
				'type' => 'input',
				'label' => '客服QQ',
				'name' => 'company_qq',
				'dsc' => '',
			),
			'company_name' => array(
				'type' => 'input',
				'label' => '公司名称',
				'name' => 'company_name',
				'dsc' => '',
			),
			'company_tel' => array(
				'type' => 'input',
				'label' => '公司电话',
				'name' => 'company_tel',
				'dsc' => '',
			),
			'company_email' => array(
				'type' => 'input',
				'label' => '公司邮箱',
				'name' => 'company_email',
				'dsc' => '',
			),
			'company_address' => array(
				'type' => 'input',
				'label' => '公司地址',
				'name' => 'company_address',
				'dsc' => '',
			),
			'site_notice' => array(
				'type' => 'input',
				'label' => '公告通知',
				'name' => 'site_notice',
				'dsc' => '',
			),
			'footer_code' => array(
				'type' => 'textarea',
				'label' => '页脚输出代码',
				'name' => 'footer_code',
				'dsc' => '可以是网站统计代码、在线客服代码，以及其他内容，将在页脚输出。',
			),
			'baidu_map' => array(
				'type' => 'input',
				'label' => '百度地图坐标',
				'name' => 'baidu_map',
				'dsc' => '填写百度地图坐标，例如：106.558434,29.568996 在<a href="http://api.map.baidu.com/lbsapi/getpoint/index.html" target="_blank">百度地图拾取坐标系统中</a>获取。',
			),
		),
	),
	'column' => array(
		'id' => 'column',
		'heading' => '栏目',
		'dsc' => '<p>指定首页栏目分类以及产品分类，首页4个栏目将按照以下指定输出相应分类的文章，指定的产品分类及其子分类页面将以图片列表的方式输出内容。</p>',
		'feild' => array(
			'itmw_column_one' => array(
				'type' => 'select',
				'label' => '首页栏目一',
				'name' => 'itmw_column_one',
				'option' => bzg_cat_ids(),
			),
			'itmw_column_two' => array(
				'type' => 'select',
				'label' => '首页栏目二',
				'name' => 'itmw_column_two',
				'option' => bzg_cat_ids(),
			),
			'itmw_column_three' => array(
				'type' => 'select',
				'label' => '首页栏目三',
				'name' => 'itmw_column_three',
				'option' => bzg_cat_ids(),
			),
			'itmw_column_four' => array(
				'type' => 'select',
				'label' => '首页栏目四',
				'name' => 'itmw_column_four',
				'option' => bzg_cat_ids(),
			),
			'itmw_product_cat' => array(
				'type' => 'select',
				'label' => '产品分类',
				'name' => 'itmw_product_cat',
				'option' => bzg_cat_ids(),
			),
		),
	),
	'slide' => array(
		'id' => 'slide',
		'heading' => '幻灯片',
		'type' => 'slide',
		'name' => 'slide',
		'width' => 200,
		'height' => 80,
	),
);
$themeControl = new ThemeSetting();
$themeControl->options = $themeControlOptions;
$themeControl->themeControl();

//分类元数据
$catMetaOptions = array(
	'upload' => false,
	'feild' => array(
		'seo_title' => array(
			'type' => 'input',
			'label' => 'SEO标题',
			'name' => 'seo_title',
		),
	),
);
$catMeta = new ThemeSetting();
$catMeta->options = $catMetaOptions;
$catMeta->catMeta();


//缩略图
add_theme_support( 'post-thumbnails' );

global $pagenow;
if ( is_admin() && isset( $_GET['activated'] ) && $pagenow == 'themes.php' ) {
	update_option( 'thumbnail_size_w', 400 );
	update_option( 'thumbnail_size_h', 300 );
	wp_redirect( admin_url( 'admin.php?page=themeControl' ) );
}

//获取所有分类ID
function bzg_cat_ids() {
	$args = array(
		'hide_empty' => false,
	);
	$categories = get_categories($args);
	$catids = array();
	if($categories) {
		foreach ($categories as $category) {
			$catids[$category->term_id] = $category->name;
		}
	}
	return $catids;
}

//获取根分类ID
function bzg_get_category_root_id( $cat ) {
	$this_category = get_category( $cat );
	while( $this_category->category_parent ) {
		$this_category = get_category( $this_category->category_parent );
	}
	return $this_category->term_id;
}

//翻页
function bzg_paging_nav() {
	if ( $GLOBALS['wp_query']->max_num_pages < 2 )
		return;

	$paged = get_query_var( 'paged' ) ? intval( get_query_var( 'paged' ) ) : 1;
	$pagenum_link = html_entity_decode( get_pagenum_link() );
	$query_args = array();
	$url_parts = explode( '?', $pagenum_link );

	if ( isset( $url_parts[1] ) )
		wp_parse_str( $url_parts[1], $query_args );

	$pagenum_link = remove_query_arg( array_keys( $query_args ), $pagenum_link );
	$pagenum_link = trailingslashit( $pagenum_link ) . '%_%';

	$format  = $GLOBALS['wp_rewrite']->using_index_permalinks() && ! strpos( $pagenum_link, 'index.php' ) ? 'index.php/' : '';
	$format .= $GLOBALS['wp_rewrite']->using_permalinks() ? user_trailingslashit( 'page/%#%', 'paged' ) : '?paged=%#%';

	$links = paginate_links( array(
		'base'     => $pagenum_link,
		'format'   => $format,
		'total'    => $GLOBALS['wp_query']->max_num_pages,
		'current'  => $paged,
		'mid_size' => 1,
		'add_args' => array_map( 'urlencode', $query_args ),
		'prev_text' => '上一页',
		'next_text' => '下一页',
	) );

	if ( ! $links )
		return;
	
	echo '<nav class="paging-nav" role="navigation">
			<h1>分页导航</h1>
			<div class="loop-pagination">'
			. $links .
		'</div></nav>';
}

//文章阅读数
function bzg_set_post_views() {
	global $post;
	if( ! isset( $post->ID ) || ! is_singular()  )
		return;
	
	$cookie_name = 'views_' . $post->ID;
	if( isset( $_COOKIE[$cookie_name] ) )
		return;
	
	
	$post_views = (int) get_post_meta( $post->ID, 'views', true );
	
	if( empty( $post_views ) ) {
		$post_views = 1;
	} else {
		$post_views = $post_views + 1;
	}
	
	update_post_meta( $post->ID, 'views', $post_views );
	
	setcookie( $cookie_name, 'yes', ( current_time( 'timestamp' ) + 86400 ) );
}
add_action( 'get_header', 'bzg_set_post_views' );

function bzg_post_views($post_ID = '') {
	global $post;
	
	$post_id = $post_ID;
	
	if( ! $post_id )
		$post_id = $post->ID;
	
	if( ! $post_id )
		return;
	
	$post_views = (int) get_post_meta( $post_id, 'views', true );
	
	if( empty( $post_views ) )
		$post_views = 0;
	
	return $post_views;
}

//阅读最多的文章
function bzg_get_most_viewed( $limit = 10, $length = 32 ) {
	$args = array(
		'posts_per_page' => $limit,
		'order' => 'DESC',
		'post_status' => 'publish',
		'orderby'    => 'meta_value_num',
		'meta_key' => 'views',
	);
	
	$postlist = wp_cache_get('hot_post', 'bzg');
	if(false === $postlist) {
		$postlist = get_posts( $args );
		wp_cache_set('hot_post', $postlist, 'bzg', 86400);
	}
	
	foreach ( $postlist as $post ) {
		echo '<li class="dashicons-before dashicons-arrow-right"><a href="' . get_permalink($post->ID) . '" rel="bookmark">' . mb_strimwidth( $post->post_title, 0, $length, '' ) . '</a></li>';
	}
	wp_reset_postdata();
}

/**
* 相关文章
*/
function bzg_related_post($limit = 10, $length = 32) {
	$posttags = get_the_tags();
	$postcats = get_the_category();
	
	if( ! $posttags && ! $postcats ) return;
	
	if($posttags) {
		foreach($posttags as $tag) {
			$tagid[] = $tag->term_id;
		}
	} else {
		foreach($postcats as $cat) {
			$catid[] = $cat->term_id;
		}
	}
	
	$args = array(
		'posts_per_page' => $limit,
		'post_status' => 'publish',
		'post__not_in' => array(get_the_ID()),
	);
	if( ! empty($tagid) ) {
		$args['tag__in'] = $tagid;
	} else {
		$args['category__in'] = $catid;
	}
	
	$postlist = wp_cache_get('related_post', 'bzg');
	if(false === $postlist) {
		$postlist = get_posts( $args );
		wp_cache_set('related_post', $postlist, 'bzg', 86400);
	}
	foreach ( $postlist as $post ) {
		echo '<li class="dashicons-before dashicons-arrow-right"><a href="' . get_permalink($post->ID) . '" rel="bookmark">' . mb_strimwidth( $post->post_title, 0, $length, '' ) . '</a></li>';
	}
	wp_reset_postdata();
}

//面包屑导航
function bzg_breadcrumb_nav() {
	global $cat, $s, $post;
	if( !is_single() || is_attachment() )
		return;
	
	echo '<nav id="path" role="navigation"><h1>面包屑导航</h1>您的位置：<ol><li class="home"><a href="' . esc_url( home_url( '/' ) ) . '">首页</a></li>';
	$the_category = get_the_category();
	$category_ID = $the_category[0]->term_id;
	$category_name = get_category_parents($category_ID, false, ',');
	$category_name = explode(',', $category_name);	
	foreach ($category_name as $cat_name) {
		if($cat_name) {
			$cat_ID = get_cat_ID($cat_name);
			$cat_link = get_category_link( $cat_ID );
			echo '<li class="dashicons-before dashicons-arrow-right-alt2"><a href="' . $cat_link . '">' . $cat_name . '</a></li>';
		}
	}
	
	echo '<li class="dashicons-before dashicons-arrow-right-alt2">' . the_title_attribute('echo=0') . '</li>';
	echo '</ol></nav>';
}

//栏目列表
function bzg_column_list( $var_name = '', $limit = 10, $length = 32, $header = 16, $word = 60, $size = 'thumbnail', $date = false ) {
	$cat = get_option( $var_name );
	if( empty( $cat ) ) {
		echo '<li>请在后台主题设置的栏目选项中设置对应分类</li>';
		return false;
	}
	
	$first_args = array(
		'cat' => $cat,
		'posts_per_page' => 1,
		'post_status' => 'publish',
	);
	$first_post = wp_cache_get('column_firstlist_' . $cat, 'bzg');
	if(false === $first_post) {
		$first_post = get_posts( $first_args );
		wp_cache_set('column_firstlist_' . $cat, $first_post, 'bzg', 86400);
	}
	foreach($first_post as $post) {
		if ( has_post_thumbnail($post->ID) ) {
			$thumbnail_url = wp_get_attachment_image_url( get_post_thumbnail_id( $post->ID ), $size );
		} else {
			$thumbnail_url = get_bloginfo('template_url') . '/img/thumbnail.png';
		}
		echo '<li class="header"><dl><dd><a class="post-thumbnail" href="' . get_permalink( $post->ID ) . '" rel="bookmark">';
		echo '<img src="' . $thumbnail_url . '" width="96" height="72" alt="' . $post->post_title . '" />';
		echo '</a></dd>';
		echo '<dt><a href="' . get_permalink( $post->ID ) . '" rel="bookmark">' . mb_strimwidth( $post->post_title, 0, $header, '' ) . '</a></dt>';
		echo '<dd>' . mb_strimwidth(wp_strip_all_tags($post->post_content, true), 0, $word, '...') . ' <span class="detailed"><a href="' . get_permalink($post->ID) . '" rel="bookmark">详细&raquo;</a></span></dd>';
		echo '</dl></li>';
		
	}
	wp_reset_postdata();
		
	$args = array(
		'cat' => $cat,
		'posts_per_page' => $limit,
		'post_status' => 'publish',
		'offset' => 1,
	);
	$postlist = wp_cache_get('column_postlist_' . $cat, 'bzg');
	if(false === $postlist) {
		$postlist = get_posts( $args );
		wp_cache_set('column_postlist_' . $cat, $postlist, 'bzg', 86400);
	}
    foreach($postlist as $post) {
		if( $date ) {
			$datetime = '<time datetime="' . get_the_time('c', $post->ID) . '">' . get_the_time('Y-m-d', $post->ID) . '</time>';
		}
		echo '<li><a href="' . get_permalink($post->ID) . '" rel="bookmark">' . mb_strimwidth( $post->post_title, 0, $length, '' ) . '</a>' . $datetime . '</li>';
	}
	wp_reset_postdata();
}

//Title标题
function bzg_filter_title( $title ) {
	$title['site'] = '';
	$title['tagline'] = '';
	$title['page'] = '';
	return $title;
}
add_filter( 'document_title_parts', 'bzg_filter_title', 10, 1 );

function bzg_seo_title() {
	global $cat, $tag_id, $page, $paged;
	$page_num = '';
	if ( $paged >= 2 || $page >= 2 )
		$page_num = '_' . sprintf( '第%s页', max( $paged, $page ) );
	
	$title = wp_get_document_title();
	if( is_author() )
		$title = '作者：' . $title;
	if( is_category() && get_term_meta( $cat , 'seo_title', true ) )
		$title = get_term_meta( $cat , 'seo_title', true );
	if( is_tag() && get_term_meta( $tag_id , 'seo_title', true ) )
		$title = get_term_meta( $tag_id , 'seo_title', true );
	if ( ! is_home() ) {
		$title .= $page_num . ' - ';
		$title .= get_option('blogname');
	} else {
		$description = get_option( 'blogdescription' );
		$home_title = get_option( 'home_title' );
		if ( $home_title ) {
			$title = $home_title;
		} elseif($description) {
			$title .= ' - ' . $description;
		}
		$title .= $page_num;
	}
	
	return $title;
}

//Description标签
function bzg_seo_description() {
	global $post;
	$description = '';
	if ( is_home() )
		$description = get_option( 'home_description' );
	
	if ( ( is_category() || is_tag() ) && category_description() )
		$description = wp_strip_all_tags( category_description(), true );
	
	if ( is_single() || is_page() ) {
		if ( $post->post_excerpt ) {
			$description = $post->post_excerpt;
		} else {
			$description = mb_strimwidth(esc_html(wp_strip_all_tags($post->post_content, true)), 0, 200);
		}
	}
	
	return $description;
}

// 自定义导航菜单
register_nav_menus(
	array(
		'itmw_primary_nav' => '主导航',
		'itmw_top_nav' => '顶部导航',
	)
);

//表单
add_theme_support( 'html5', array(
	'search-form', 'comment-form', 'comment-list',
) );

//加载dashicons图标、CSS、JS
function bzg_scripts() {
	wp_enqueue_style( 'pure', get_template_directory_uri() . '/css/pure-min.css' );
    wp_enqueue_style( 'style', get_stylesheet_uri(), array( 'pure', 'dashicons' ) );
	wp_enqueue_script( 'js', get_template_directory_uri() . '/js/default.js', array( 'jquery' ) );
	if( is_home() ) {
		wp_enqueue_script( 'slide', get_template_directory_uri() . '/js/unslider.js' );
	}
}
add_action( 'wp_enqueue_scripts', 'bzg_scripts' );
?>