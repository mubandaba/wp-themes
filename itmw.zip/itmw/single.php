<?php get_header(); ?>
	<div id="main" role="main">
	<?php while (have_posts()) : the_post(); ?>
		<?php bzg_breadcrumb_nav(); ?>
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<header>
				<h1><?php the_title_attribute(); ?></h1>
				<div class="post-meta">
					<time class="dashicons-before dashicons-clock" datetime="<?php the_time( 'c' ); ?>" pubdate><?php the_time( 'Y-m-d' ); ?></time>
					<?php if ( get_option( 'users_can_register' ) ) : ?>
						<span class="author-links dashicons-before dashicons-businessman">作者：<?php the_author_posts_link(); ?></span>
					<?php endif; ?>
					<span class="cat-links dashicons-before dashicons-category">分类：<?php the_category( ' ', '' ); ?></span>
					<?php the_tags( '<span class="tag-links dashicons-before dashicons-tag">标签：', ', ', '</span>' ); ?>
					<span class="views dashicons-before dashicons-visibility">阅读(<?php echo bzg_post_views(); ?>)</span>
					
					<?php if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) : ?>
						<span class="comments-links dashicons-before dashicons-admin-comments">评论(<?php comments_popup_link( '0', '1', '%' ); ?>)</span>
					<?php endif; ?>
					
					<?php edit_post_link( '编辑', '<span class="edit dashicons-before dashicons-edit">', '</span>' ); ?>
				</div>
			</header>
			<div class="post-content content">
				<?php the_content(); ?>
			</div>
			<footer>
				<div class="copy">
					转载请注明出处：<a href="<?php the_permalink(); ?>"><?php the_title_attribute(); ?></a>
				</div>
				
				<div class="bdsharebuttonbox">
					分享： 
					<a class="bds_qzone" data-cmd="qzone"></a>
					<a class="bds_tsina" data-cmd="tsina"></a>
					<a class="bds_weixin" data-cmd="weixin"></a>
					<a class="bds_tqq" data-cmd="tqq"></a>
					<a class="bds_sqq" data-cmd="sqq"></a>
					<a class="bds_renren" data-cmd="renren"></a>
					<a class="bds_douban" data-cmd="douban"></a>
					<a class="bds_fbook" data-cmd="fbook"></a>
					<span class="bds_count" data-cmd="count"></span>
					<script type="text/javascript">
						window._bd_share_config = {
							common : {
								bdText : '<?php the_title_attribute(); ?>',
								bdDesc : '<?php echo $post->post_excerpt ? $post->post_excerpt : mb_strimwidth(esc_html(wp_strip_all_tags($post->post_content, true)), 0, 240, ''); ?>',
								bdUrl : '<?php the_permalink(); ?>',
								bdPic : '<?php echo has_post_thumbnail() ? wp_get_attachment_url( get_post_thumbnail_id( $id ) ) : ''; ?>',
							},
							share : [{
								'bdSize' : 24,
							}]
						}
						with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?cdnversion='+~(-new Date()/36e5)];
					</script>
				</div>
			</footer>
		</article>
		
		<nav id="post-navigation" role="navigation">
			<h1>文章导航</h1>
			<div class="nav-links pure-g">
				<?php previous_post_link('<span class="previous-article pure-u-12-24">上一篇：%link</span>', '%title', true); ?>
				<?php next_post_link('<span class="next-article pure-u-12-24">下一篇：%link</span>', '%title', true); ?>
			</div>
		</nav>
		
		<aside class="related">
			<h3>推荐阅读</h3>
			<ul>
				<?php bzg_related_post( 10 ); ?>
			</ul>
		</aside>
		
		<?php comments_template(); ?>
	<?php endwhile; ?>
	</div>

	<?php get_sidebar(); ?>
<?php get_footer(); ?>