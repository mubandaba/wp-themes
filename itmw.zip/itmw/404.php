<?php get_header(); ?>
	<div id="container">
		<div class="error">
			<img src="<?php echo get_template_directory_uri(); ?>/img/404.jpg" alt="Not Found" />
			<h1>404 . Not Found</h1>
			<h2>您所访问的页面不在地球上...</h2>
			<p>没有发现您要找的页面，经专家仔细研究结果如下：</p>
			<p>1、资源不存在</p>
			<p>2、资源不存在</p>
			<p>3、资源不存在</p>
			<p><a class="primary-button" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">返回首页</a></p>
		</div>
	</div>
	
<?php get_footer(); ?>