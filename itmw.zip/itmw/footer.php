</div><!-- wrapper end -->

<div id="bookmarks">
	<h3>友情链接：</h3>
	<ul>
	<?php
		$bookmarks = get_bookmarks( 'orderby=rand&limit=-1' );
		foreach( $bookmarks as $bm ) {
			if($bm->link_image) continue;
			echo '<li><a href="' . $bm->link_url . '" target="_blank">' . $bm->link_name . '</a></li>';
		}
	?>
	</ul>
</div>
	
<footer id="colophon" role="contentinfo">
	Copyright &copy; 2017
	<?php 
		$tyear = (int) current_time('Y');
		if($tyear > 2017)
			echo ' - ' . $tyear;
	?>
	<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo get_option('blogname'); ?></a>
	<?php 
		if ( get_option( 'zh_cn_l10n_icp_num' ) )
			echo ' <a class="icp" href="http://www.miibeian.gov.cn" rel="nofollow" target="_blank">' . get_option( 'zh_cn_l10n_icp_num' ) . '</a>';
	?>
	Theme By <a href="http://www.beizigen.com">背字根</a>
	<?php echo get_option( 'footer_code' ); ?>
	
	<?php wp_footer(); ?>
</footer>

</body>
</html>