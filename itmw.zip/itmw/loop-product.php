<?php if( have_posts() ) : ?>
	<div id="product-list">
		<ul class="pure-g">
		<?php
			$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
			$args = array(
				'posts_per_page' => 20,
				'paged' => $paged,
				'post_status' => 'publish',
				'cat' => $cat,
			);
			query_posts($args);
			while (have_posts()) : the_post();
			echo '<li class="pure-u-6-24">';
			if ( has_post_thumbnail() ) {
				$thumbnail_url = wp_get_attachment_image_url( get_post_thumbnail_id(), $size );
			} else {
				$thumbnail_url = get_bloginfo('template_url') . '/img/thumbnail.png';
			}
			echo '<a href="' . get_permalink() . '" target="_blank"><img src="' . $thumbnail_url . '" width="180" height="135" alt="' . get_the_title() . '" /></a>';
			echo '<h2><a href="' . get_permalink() . '" target="_blank">' . get_the_title() . '</a></h2>';
			echo '</li>';
			endwhile;
		?>
		</ul>
	</div>
	<?php bzg_paging_nav(); ?>
	<?php wp_reset_query(); ?>
<?php endif; ?>