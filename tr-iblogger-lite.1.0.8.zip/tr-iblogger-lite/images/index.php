<?php 

//Silence is Golden