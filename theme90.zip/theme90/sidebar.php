<div id="sidebar" class="sidebar">
<ul>
<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar() ) : else : ?>
		<li>
			<h2><?php _e('Categories'); ?></h2>
			<ul>
					<?php wp_list_cats('sort_column=name&hierarchical=0&depth=0'); ?>
			</ul>
		</li>
		<li>
			<h2><?php _e('Popular Posts'); ?></h2>
			<ul>
			<?php popular_post(); ?>
			</ul>
		</li>
		<li>
			<h2><?php _e('Tags'); ?></h2>
			<ul>
			<?php /*wp_cumulus_insert();*/ ?>
			</ul>
		</li>


<?php endif;?>
</ul>
<div id="clear"></div>
</div>