<?php get_header(); ?>
<div id="contents">
	<div class="container">
          <?php if(have_posts()) : ?><?php while(have_posts()) : the_post(); ?>
         <div class="post">
		 	<div class="postdata">
             <h2>404 Error - Not Found</h2>
		 	</div>
		</div>
        <div id="clear"></div>
    </div>
	<?php get_sidebar();?>
	<div id="clear"></div>
</div>
<?php get_footer();?>
<div id="clear"></div>
</div>

</body>
</html>