<?php get_header(); ?>
<div id="contents">
	<div class="container">
          <?php if(have_posts()) : ?><?php while(have_posts()) : the_post(); ?>
         <div class="post">
		 	<div class="postdata">
				<h2><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
				<div class="postmetadata">
					<span><?php _e('Category: '); ?><?php the_category(', '); ?></span>
					<span class="last"><?php _e('By: '); ?><?php the_author_link(); ?></span>
					<?php edit_post_link('Edit', '<span class="last">', '</span>'); ?>
				</div>
			</div>
			<div id="clear"></div>
			<div class="entry">
                 <?php the_content(__('<div class="readmore">Readmore...</div>')); ?>
				 <?php link_pages('<p><strong>Pages:</strong> ', '</p>', 'number'); ?>
				<div id="clear"></div>
			</div>
			  <div class="comments-template">
                  <?php comments_template(); ?>
              </div>
			<div id="clear"></div>
          </div>
             <?php endwhile; ?>
			      
                <?php else: ?>
                <div class="post" id="post-<?php the_ID();?>">
					<h2><?php _e('Not Found');?></h2>
		  		</div>		
             <?php endif; ?>
		<div id="clear"></div>
    </div>
	<?php get_sidebar();?>
<div id="clear"></div>
</div>
<?php get_footer();?>
<div id="clear"></div>
</div>
</body>
</html>