<?php

/**

 * Template Name: 标签

 *

 */

 get_header(); ?>

<div id="gongaobox"><div id="gongao">当前位置：<?php the_title(); ?></div>

<div id="gongaor">最后更新：<strong><?php $last = $wpdb->get_results("SELECT MAX(post_modified) AS MAX_m FROM $wpdb->posts WHERE (post_type = 'post' OR post_type = 'page') AND (post_status = 'publish' OR post_status = 'private')");$last = date('Y-n-j', strtotime($last[0]->MAX_m));echo $last; ?></strong></div>

</div>

<div id="divcom">

<div class="main">

<?php if (get_option('lovnvns_banner_ad_on') == '1') { ?>

<div id="turn" class="turn">

	<div class="turn-loading"><img src="<?php bloginfo('template_directory'); ?>/images/loading.gif" /></div>

	<ul class="turn-pic">

			<?php if(get_option('lovnvns_banner_ad')!="") echo get_option('lovnvns_banner_ad'); ?>

		</ul>

	</div><script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/banner.js"></script>

<?php { echo ''; } ?><?php } else { } ?>

<?php if(have_posts()) : ?><?php while(have_posts()) : the_post(); ?>

<div id="divleft">

<div id="single_list">

<h2><?php the_title(); ?></h2>

<div class="hr"></div>

<div class="single_content">

<?php wp_tag_cloud('number=5000');?>

</div></div></div>

<?php comments_template(); ?>

</div><?php endwhile; ?>

        <?php endif; ?>

<?php get_sidebar(); ?></div>

<div class="clear"></div>

<?php get_footer(); ?>