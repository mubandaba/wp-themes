<?php get_header(); ?>
<div id="gongaobox"><div id="gongao">当前位置：<?php $categories = get_the_category(); echo(get_category_parents($categories[0]->term_id, TRUE, ' > '));  ?>正文</div>
<div id="gongaor">最后更新：<strong><?php $last = $wpdb->get_results("SELECT MAX(post_modified) AS MAX_m FROM $wpdb->posts WHERE (post_type = 'post' OR post_type = 'page') AND (post_status = 'publish' OR post_status = 'private')");$last = date('Y-n-j', strtotime($last[0]->MAX_m));echo $last; ?></strong></div>
</div>
<div id="divcom">
<div class="main">
<?php if (get_option('lovnvns_banner_ad_on') == '1') { ?>
<div id="turn" class="turn">
	<div class="turn-loading"><img src="<?php bloginfo('template_directory'); ?>/images/loading.gif" /></div>
	<ul class="turn-pic">
			<?php if(get_option('lovnvns_banner_ad')!="") echo get_option('lovnvns_banner_ad');else echo "<li><a href='http://www.bofaziran.com/112/' target='_blank'><img src='http://www.caidaoke.com/ad/banner-4.jpg' /></a></li><li><a href='http://www.1188sj.com/?Intr=37648' target='_blank'><img src='http://www.caidaoke.com/ad/xsj1.jpg' border='0' /></a></li>
<li><a href='http://www.1188sj.com/?Intr=37648' target='_blank'><img src='http://www.caidaoke.com/ad/xsj2.jpg' border='0' /></a></li>" ?>
		</ul>
	</div><script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/banner.js"></script>
<?php { echo ''; } ?><?php } else { } ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div id="divleft">
<div id="single_list">
<em><?php comments_popup_link ('0°','+1°','+%°'); ?></em><h2><?php the_title(); ?></h2><div class="hr"></div>
<p><?php the_time('Y年m月d日') ?>　|　作者: <?php the_author (); ?></p>
<?php if(get_option('lovnvns_single_ad')!="")
				echo '<div id="lovnvns_ad">'.get_option('lovnvns_single_ad').'</div>';
			?>
<div class="single_content"><?php the_content(); ?><script type="text/javascript">
/*728*90，创建于2013-6-16*/
var cpro_id = "u1303840";
</script>
<script src="http://cpro.baidustatic.com/cpro/ui/c.js" type="text/javascript"></script></div></div></div>
<?php wp_link_pages(); ?>
<div id="divleft">
<div id="single_list"><div class="single_listl"><?php  if (get_next_post()) {next_post_link('%link'); } else { echo "已经最新的文章！"; }; ?></div>
<div class="single_listr"><?php  if (get_previous_post()) {previous_post_link('%link'); } else { echo "后面已经没有文章了"; }; ?></div></div></div>
<div id="divleft">
<div id="single_list">
<!-- Baidu Button BEGIN -->
    <div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare">
        <a class="bds_qzone"></a>
        <a class="bds_tqq"></a>
        <a class="bds_tsina"></a>
        <a class="bds_renren"></a>
        <a class="bds_ty"></a>
        <a class="bds_ff"></a>
        <a class="bds_fbook"></a>
        <a class="bds_baidu"></a>
        <a class="bds_hi"></a>
        <a class="bds_zx"></a>
        <a class="bds_douban"></a>
        <a class="bds_t163"></a>
        <a class="bds_xg"></a>
        <a class="bds_qq"></a>
		<a class="bds_tieba"></a>
        <span class="bds_more">更多</span>
		<a class="shareCount"></a>
    </div>
<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=730973" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
	document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + new Date().getHours();
</script>
<!-- Baidu Button END --></div></div>
<?php comments_template('', true); ?>
    <?php endwhile; ?>
    <?php endif; ?>		
</div>
<?php get_sidebar(); ?></div>
<div class="clear"></div>
<?php get_footer(); ?>