<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<?php include('includes/seo.php'); ?>
<link rel="shortcut icon" href="favicon.ico">
<link type="text/css" rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" />
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/highlight.css" />	
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name'); ?> Atom Feed" href="<?php bloginfo('atom_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<?php wp_enqueue_script('jquery'); ?>
<?php wp_head(); ?>
<?php if ( is_singular() ){ ?>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/comments-ajax.js"></script>
<?php } ?>
</head>
<body>

<!-- 禁止复制网页内容 -->
<!-- <body onmousemove=\HideMenu()\ oncontextmenu="return false" ondragstart="return false" onselectstart ="return false" onselect="document.selection.empty()" oncopy="document.selection.empty()" onbeforecopy="return false" onmouseup="document.selection.empty()"> -->
<!-- 禁止复制网页内容 -->

<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/lovnvns.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.lazyload.js"></script>
<SCRIPT src="<?php bloginfo('template_url'); ?>/js/mobanwang.js" type=text/javascript></SCRIPT>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/scrolltopcontrol.js"></script>
<script type="text/javascript">
	jQuery(document).ready(
		function($){
			$("img").lazyload({
			placeholder : "<?php bloginfo('template_url'); ?>/images/grey.gif",
			effect      : "fadeIn"
		});
	});
</script>
<div id="nav">
    <div class="wrap">
        <ul id="navleft">
            <li><a href="<?php bloginfo('siteurl'); ?>/"><span class="leadBg">首 页</span></a></li>
            <li><a href="http://www.wujisu.com/category/creative-things" target="_blank">最有创意的产品</a></li>
	    <li><a href="http://www.wujisu.com/category/successful" target="_blank">励志名言网</a></li>
	    <li><a href="http://www.wujisu.com/category/interestings-sites" target="_blank">收集有趣的网站</a></li>
 	    <li><a href="http://www.wujisu.com/category/recycling" target="_blank">手工小制作</a></li>
	    <li><a href="http://www.wujisu.com/category/famous-books" target="_blank">世界名著下载</a></li>
            <li><a href="http://www.wujisu.com/category/healthy" target="_blank">天天养生之道</a></li>
	    <li><a href="http://www.wujisu.com/post-2" target="_blank">我要投稿</a></li>
        </ul>
  </div>
</div>
<!--
<div id="search_bg1"></div>
-->

<?php wp_nav_menu( array( 'container' => '','items_wrap' => '<ul id="menu" class="menu">%3$s</ul>','fallback_cb'     => '' ) ); ?></div>
</div>
</div>