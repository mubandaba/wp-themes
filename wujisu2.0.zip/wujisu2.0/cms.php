<?php

 get_header(); ?><div id="gongaobox"><div id="gongao"><ul><li><span></span><?php if(get_option('lovnvns_announce')!='') echo get_option('lovnvns_announce'); ?></li></ul></div>

<div id="gongaor">最后更新：<strong><?php $last = $wpdb->get_results("SELECT MAX(post_modified) AS MAX_m FROM $wpdb->posts WHERE (post_type = 'post' OR post_type = 'page') AND (post_status = 'publish' OR post_status = 'private')");$last = date('Y-n-j',strtotime($last[0]->MAX_m));echo $last; ?></strong></div>

</div>

<div id="divcom">

<?php if ( is_home() ) { ?><div class="banner_top">

<?php if(get_option('lovnvns_banner_top')!="")

    	echo '<div  class=banner>'.get_option('lovnvns_banner_top').'</div>'

	?></div><?php } ?>

	<div class="main">

<?php if (get_option('lovnvns_banner_ad_on') == '1') { ?><div id="turn" class="turn">

	<div class="turn-loading"><img src="<?php bloginfo('template_directory'); ?>/images/loading.gif" /></div>

	<ul class="turn-pic">

			<?php if(get_option('lovnvns_banner_ad')!='') echo get_option('lovnvns_banner_ad'); ?>		</ul>

	</div><script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/banner.js"></script>

<?php {echo '';} ?><?php }else {} ?><?php if (get_option('lovnvns_zhiding') == '1') { ?><div id="divleft1">

<DIV id=imgPlay><UL class=imgs id=actor><?php $previous_posts = get_posts('numberposts=8&meta_key=banner&meta_value=on');foreach($previous_posts as $post) : setup_postdata($post); ?><li><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php echo get_the_post_thumbnail($post->ID,'medium'); ?></a></li>

<?php endforeach; ?></UL><DIV class=num>

<P class=lc></P>

<P class=mc></P>

<P class=rc></P></DIV>

<DIV class=num id=numInner></DIV>

<DIV class=prev>上一张</DIV>

<DIV class=next>下一张</DIV></DIV>

<div class="zt_con">

<?php    

        $sticky = get_option('sticky_posts');

        rsort( $sticky );

        $sticky = array_slice( $sticky, 0, 1);

		

query_posts('showposts=1');

        if (have_posts()) :

        while (have_posts()) : the_post();

?><h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>

<p>分类：<?php the_category(', ') ?> | <?php comments_popup_link ('评论数：0','评论数：1','评论数：%'); ?> | <?php if(function_exists('the_views')) { print '被围观 '; the_views();  } ?><?php edit_post_link('编辑', ' | '); ?></p>

<span><?php echo wp_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 122,"……"); ?></span><?php endwhile; ?><?php endif; ?><div class="hr"></div>

<ul>

<?php 

$sticky = get_option('sticky_posts');

rsort( $sticky );

$sticky = array_slice( $sticky,1,6);

query_posts( array( 'post__in'=>$sticky,

'caller_get_posts'=>1 ) );

if (have_posts()) :

while (have_posts()) : the_post();

?><li>

<a href="<?php the_permalink(); ?>"

title="<?php the_title(); ?>">

<?php the_title(); ?></a>

</li><?php endwhile;endif; ?></ul>

</div></div><?php {echo '';} ?><?php }else {} ?><?php if (get_option('lovnvns_show_on') == '1') { ?><div id="divleft">

<ul class="artist_l">

<?php query_posts( array('showposts'=>12,'cat'=>get_option('lovnvns_show')));$i=1; ?><?php while (have_posts()) : the_post(); ?><li class="a<?php echo $i;$i++; ?>"><?php echo get_the_post_thumbnail($post->ID,'thumbnail'); ?><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></li>

<?php endwhile; ?></ul>

</div><?php {echo '';} ?><?php }else {} ?><!-- cms up -->

<div id="divleftcms">

<?php $display_categories = explode(',',get_option('lovnvns_up') );foreach ($display_categories as $category) { ?>

<?php 

query_posts( array(

'showposts'=>1,

'cat'=>$category,

'post__not_in'=>$do_not_duplicate

)

);

?><div id="divleftl">

<?php while (have_posts()) : the_post(); ?><div id="titlebg">

<h3><a href="<?php echo get_category_link($category); ?>" rel="bookmark" title="更多<?php single_cat_title(); ?>的文章"><?php single_cat_title(); ?></a></h3><span class="counts">共有<span class="red"><?php echo wt_get_category_count(); ?></span>篇</span></div>

<div id="textlist">

<h4><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h4>

<p><?php the_time('Y年m月d日')  ?> | <?php comments_popup_link ('评论数：0','评论数：1','评论数：%'); ?> | <?php if(function_exists('the_views')) {print '被围观 ';the_views();} ?></p>

<div id="textlistl"><?php include('includes/thumbnail.php'); ?></div>

<div id="textlistr"><?php echo mb_strimwidth(strip_tags(apply_filters('the_content',$post->post_content)),0,132,'……'); ?><?php endwhile; ?></div>

<div class="hr"></div>

<?php 

query_posts( array(

'showposts'=>get_option('lovnvns_n'),

'cat'=>$category,

'offset'=>1,

'post__not_in'=>$do_not_duplicate

)

);

?><ul>

<?php while (have_posts()) : the_post(); ?><li><em><?php the_time('m/d')  ?></em><a href="<?php the_permalink()  ?>"  title="<?php the_title(); ?>"><?php echo cut_str($post->post_title,40); ?></a></li>

<?php endwhile; ?></ul></div></div><?php } ?></div>

<!-- end: cms up -->

<?php if(get_option('lovnvns_cms_ad')!='')

echo '<div class=cms_ad>'.get_option('lovnvns_cms_ad').'</div>';

?><!-- cms un -->

<div id="divleftcms">

<?php $display_categories = explode(',',get_option('lovnvns_un') );foreach ($display_categories as $category) { ?>		

<?php 

query_posts( array(

'showposts'=>1,

'cat'=>$category,

'post__not_in'=>$do_not_duplicate

)

);

?>

<?php while (have_posts()) : the_post(); ?><div id="divleftl">

<div id="titlebg">

<h3><a href="<?php echo get_category_link($category); ?>" rel="bookmark" title="更多<?php single_cat_title(); ?>的文章"><?php single_cat_title(); ?></a></h3><span class="counts">共有<span class="red"><?php echo wt_get_category_count(); ?></span>篇</span></div>

<div id="textlist">

<h4><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h4>

<p><?php the_time('Y年m月d日')  ?> | <?php comments_popup_link ('评论数：0','评论数：1','评论数：%'); ?> | <?php if(function_exists('the_views')) {print '被围观 ';the_views();} ?></p>

<div id="textlistl"><?php include('includes/thumbnail.php'); ?></div>

<div id="textlistr"><?php echo mb_strimwidth(strip_tags(apply_filters('the_content',$post->post_content)),0,132,'……'); ?><?php endwhile; ?></div>

<div class="hr"></div>

<?php 

query_posts( array(

'showposts'=>get_option('lovnvns_n'),

'cat'=>$category,

'offset'=>1,

'post__not_in'=>$do_not_duplicate

)

);

?><ul>

<?php while (have_posts()) : the_post(); ?><li><em><?php the_time('m/d')  ?></em><a href="<?php the_permalink()  ?>"  title="<?php the_title(); ?>"><?php echo cut_str($post->post_title,40); ?></a></li>

<?php endwhile; ?></ul></div></div><?php } ?></div>

<!-- end: cms un -->

</div>

<?php get_sidebar(); ?></div>

<div id="botcont">

<div id="botcontbar"><span><a href="<?php if(get_option('lovnvns_links')!='') echo get_option('lovnvns_links')  ?>">更多链接</a></span>
<h3>友情链接</h3>
</div>

<div id="botcontbody">
<a href="http://www.wujisu.com/category/interestings-sites">最有趣的网站</a>
<a href="http://www.wujisu.com/category/famous-books">世界名著下载</a>
<a href="http://www.wujisu.com/category/creative-things">最有创意的产品</a>
<a href="http://www.wujisu.com/category/successful">励志故事名言网</a>
<a href="http://www.wujisu.com/category/recycling">手工小制作</a>
<a href="http://www.wujisu.com/category/healthy">养生之道网</a>
<a href="http://www.aimaipu.com" target="_blank">折800</a>
<a href="http://www.sup555.com" target="_blank">儿童被子</a>
<a href="http://www.ppf5.com" target="_blank">翩翩飞舞软件站</a>
<a href="http://www.frees-hp.com" target="_blank">进销存软件</a>
<a href="http://www.pianyimp.com" target="_blank">500元左右的手机</a>
<a href="http://www.wujisu.com" target="_blank">无极速</a>
<a href="http://www.tjshouji.com" target="_blank">1500元以下智能手机</a>
<a href="http://www.5001000sp.com" target="_blank">500元手机</a>
<a href=" http://www.yao59.com/" target="_blank">碳晶地暖</a>
<a href=" http://www.weiyuanshebei.com" target="_blank">橡胶挤出机</a>
<a href=" http://www.wodt.net" target="_blank">电台在线收听</a>
<a href=" http://www.tishengji999.com/" target="_blank">斗式提升机</a>
<a href=" http://www.dianqing.net" target="_blank">自然通风器</a>
<a href=" http://www.rxlvhuamei.com" target="_blank">氯化镁</a>
<a href=" http://www.hbtek.cn" target="_blank">集成灶</a>
<a href=" http://bbs.258en.com" target="_blank">英语社区</a>
<a href=" http://www.qdysjy.com" target="_blank">全脑开发</a>
</div>
</div>

<div class="clear"></div>
<?php get_footer(); ?>