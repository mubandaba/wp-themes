<div id="footer">

<div id="bot_main"><div id="bot_mainf">
<p align="center">2013&copy;无极速 京ICP备13016006<script src="http://s25.cnzz.com/stat.php?id=5076985&web_id=5076985" language="JavaScript"></script></p>
<p><?php if(get_option('lovnvns_statistics')!="") echo get_option('lovnvns_statistics'); ?></p></div><div id="bot_mainr"></div>
</div></div>













</body>

</html>