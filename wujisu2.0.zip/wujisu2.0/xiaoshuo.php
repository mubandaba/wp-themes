<?php
 get_header(); ?><div id="gongaobox"><div id="gongao">当前位置：<a href="<?php bloginfo('siteurl'); ?>/" title="返回首页">首页</a> > <?php echo get_category_parents( get_query_var('cat') ,true ,' > '); ?>文章
</div>
<div id="gongaor">建站日期：<strong><?php echo get_option('lovnvns_date'); ?></strong>　运行天数：<strong><?php echo floor((time()-strtotime(get_option('lovnvns_date')))/86400); ?></strong> 天　最后更新：<strong><?php $last = $wpdb->get_results("SELECT MAX(post_modified) AS MAX_m FROM $wpdb->posts WHERE (post_type = 'post' OR post_type = 'page') AND (post_status = 'publish' OR post_status = 'private')");$last = date('Y-n-j',strtotime($last[0]->MAX_m));echo $last; ?></strong></div>
</div>
<div id="divcom">
<div class="main">
<?php if (get_option('lovnvns_banner_ad_on') == '1') { ?><div id="turn" class="turn">
	<div class="turn-loading"><img src="<?php bloginfo('template_directory'); ?>/images/loading.gif" /></div>
	<ul class="turn-pic">
			<?php if(get_option('lovnvns_banner_ad')!='') echo get_option('lovnvns_banner_ad'); ?>		</ul>
	</div><script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/banner.js"></script>
<?php {echo '';} ?><?php }else {} ?>
<?php 
$categories = get_categories('child_of='.$cat .'&depth=0&hide_empty=0&orderby=id&order=asc');
foreach ($categories as $category) {
$now_cat = $category->term_id;
$cat_name = $category->cat_name;
$description = $category->description;
 ?>
 <div id="divleft">
<div id="post_list"><?php echo '<h2><a href="'.get_category_link( $category->term_id ) .'" '.'>'.$cat_name .'</a></h2>'; ?><div class="hr"></div>
<div class="xiaoshuo_box">
<div class="xiaoshuo">
<?php echo '<a href="'.get_category_link( $category->term_id ) .'" title="'.$cat_name .'" '.'><img src=/caticon/'.$category->slug .'.jpg /></a>'
 ?></div>
</div>
<p><?php echo $description; ?></p>
<div class="clear"></div>
<div class="xiaoshuoinfo"></div>
<div id="xiaoshuo_list_more"><a href="<?php the_permalink()  ?>" title="详细阅读 <?php the_title(); ?>" rel="bookmark" class="title">详细阅读</a></div>
</div></div>
<?php } ?></div>
<?php get_sidebar(); ?></div>
<div class="clear"></div>
<?php get_footer(); ?>