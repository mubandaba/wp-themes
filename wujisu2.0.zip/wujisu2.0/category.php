<?php
$post = $wp_query->post;
if ( is_category('5') ) {
include(TEMPLATEPATH . '/show.php');
}
else if ( is_category('102') ) {
include(TEMPLATEPATH . '/xiaoshuo.php');
}
else if ( is_category('103')|| is_category('104')) {
include(TEMPLATEPATH . '/chapter.php');
}
else {
include(TEMPLATEPATH . '/archive.php');
}
?>