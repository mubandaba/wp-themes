<?php
 get_header(); ?><div id="gongaobox"><div id="gongao">当前位置：<a href="<?php bloginfo('siteurl'); ?>/" title="返回首页">首页</a> > <?php echo get_category_parents( get_query_var('cat') ,true ,' > '); ?>正文
</div>
<div id="gongaor">建站日期：<strong><?php echo get_option('lovnvns_date'); ?></strong>　运行天数：<strong><?php echo floor((time()-strtotime(get_option('lovnvns_date')))/86400); ?></strong> 天　最后更新：<strong><?php $last = $wpdb->get_results("SELECT MAX(post_modified) AS MAX_m FROM $wpdb->posts WHERE (post_type = 'post' OR post_type = 'page') AND (post_status = 'publish' OR post_status = 'private')");$last = date('Y-n-j',strtotime($last[0]->MAX_m));echo $last; ?></strong></div>
</div>
<div id="divcom">
<div class="main">
<?php if (get_option('lovnvns_banner_ad_on') == '1') { ?><div id="turn" class="turn">
	<div class="turn-loading"><img src="<?php bloginfo('template_directory'); ?>/images/loading.gif" /></div>
	<ul class="turn-pic">
			<?php if(get_option('lovnvns_banner_ad')!='') echo get_option('lovnvns_banner_ad'); ?>		</ul>
	</div><script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/banner.js"></script>
<?php {echo '';} ?><?php }else {} ?><div id="divleft">
<div id="xiaoshuo_cat">
<h2><?php single_cat_title(); ?></h2>
<div class="clear"></div>
        <div class="xiaoshuo_context">
		<ul>
<?php 
global $query_string;
query_posts($query_string.'&showposts=999&caller_get_posts=1&order=ASC'); ?>
<?php if(have_posts()) :  ?><?php while(have_posts()) : the_post(); ?> <li><a href="<?php the_permalink()  ?>" rel="bookmark" title="详细阅读 <?php the_title_attribute(); ?>"><?php the_title(); ?></a></li>
 
 <?php endwhile; ?>		<?php endif; ?></ul></div>
</div></div></div>
<?php get_sidebar(); ?></div>
<div class="clear"></div>
<?php get_footer(); ?>