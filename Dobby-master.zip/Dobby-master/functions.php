<?php

define( 'DOBBY_VERSION', '1.0' );

require_once( get_template_directory() . '/inc/core.php');
require_once( get_template_directory() . '/inc/smtp.php');
require_once( get_template_directory() . '/inc/global.php');
require_once( get_template_directory() . '/inc/images.php');
require_once( get_template_directory() . '/inc/widget.php');
require_once( get_template_directory() . '/inc/single.php');
require_once( get_template_directory() . '/inc/comments.php');
require_once( get_template_directory() . '/inc/navwalker.php');
require_once( get_template_directory() . '/inc/shortcode.php');