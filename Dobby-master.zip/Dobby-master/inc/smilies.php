<?php

/**
 * Output smilies button
 *
 * @author Vtrois <seaton@vtrois.com>
 * @license GPL-3.0
 * @since 1.0
 */
$smilies = '
<a href="javascript:grin(\':razz:\')"><img src="'.get_bloginfo("template_url").'/static/images/smilies/razz.png" alt="" class="d-block"/></a>
<a href="javascript:grin(\':evil:\')"><img src="'.get_bloginfo("template_url").'/static/images/smilies/evil.png" alt="" class="d-block"/></a>
<a href="javascript:grin(\':exclaim:\')"><img src="'.get_bloginfo("template_url").'/static/images/smilies/exclaim.png" alt="" class="d-block"/></a>
<a href="javascript:grin(\':smile:\')"><img src="'.get_bloginfo("template_url").'/static/images/smilies/smile.png" alt="" class="d-block"/></a>
<a href="javascript:grin(\':redface:\')"><img src="'.get_bloginfo("template_url").'/static/images/smilies/redface.png" alt="" class="d-block"/></a>
<a href="javascript:grin(\':biggrin:\')"><img src="'.get_bloginfo("template_url").'/static/images/smilies/biggrin.png" alt="" class="d-block"/></a>
<a href="javascript:grin(\':eek:\')"><img src="'.get_bloginfo("template_url").'/static/images/smilies/eek.png" alt="" class="d-block"/></a>
<a href="javascript:grin(\':confused:\')"><img src="'.get_bloginfo("template_url").'/static/images/smilies/confused.png" alt="" class="d-block"/></a>
<a href="javascript:grin(\':idea:\')"><img src="'.get_bloginfo("template_url").'/static/images/smilies/idea.png" alt="" class="d-block"/></a>
<a href="javascript:grin(\':lol:\')"><img src="'.get_bloginfo("template_url").'/static/images/smilies/lol.png" alt="" class="d-block"/></a>
<a href="javascript:grin(\':mad:\')"><img src="'.get_bloginfo("template_url").'/static/images/smilies/mad.png" alt="" class="d-block"/></a>
<a href="javascript:grin(\':twisted:\')"><img src="'.get_bloginfo("template_url").'/static/images/smilies/twisted.png" alt="" class="d-block"/></a>
<a href="javascript:grin(\':rolleyes:\')"><img src="'.get_bloginfo("template_url").'/static/images/smilies/rolleyes.png" alt="" class="d-block"/></a>
<a href="javascript:grin(\':wink:\')"><img src="'.get_bloginfo("template_url").'/static/images/smilies/wink.png" alt="" class="d-block"/></a>
<a href="javascript:grin(\':cool:\')"><img src="'.get_bloginfo("template_url").'/static/images/smilies/cool.png" alt="" class="d-block"/></a>
<a href="javascript:grin(\':arrow:\')"><img src="'.get_bloginfo("template_url").'/static/images/smilies/arrow.png" alt="" class="d-block"/></a>
<a href="javascript:grin(\':neutral:\')"><img src="'.get_bloginfo("template_url").'/static/images/smilies/neutral.png" alt="" class="d-block"/></a>
<a href="javascript:grin(\':cry:\')"><img src="'.get_bloginfo("template_url").'/static/images/smilies/cry.png" alt="" class="d-block"/></a>
<a href="javascript:grin(\':mrgreen:\')"><img src="'.get_bloginfo("template_url").'/static/images/smilies/mrgreen.png" alt="" class="d-block"/></a>
<a href="javascript:grin(\':drooling:\')"><img src="'.get_bloginfo("template_url").'/static/images/smilies/drooling.png" alt="" class="d-block"/></a>
<a href="javascript:grin(\':persevering:\')"><img src="'.get_bloginfo("template_url").'/static/images/smilies/persevering.png" alt="" class="d-block"/></a>
'?>