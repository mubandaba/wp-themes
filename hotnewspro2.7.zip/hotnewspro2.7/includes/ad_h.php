<div class="ad_h">
		<div class="ad_h_c">
			<p align="center"><?php echo stripslashes(get_option('swt_adh_c')); ?></p>
			<div class="clear"></div>
		</div>
	<i class="lt"></i>
	<i class="rt"></i>
</div>
<div class="entry_box_b">
	<i class="lb"></i>
	<i class="rb"></i>
</div>