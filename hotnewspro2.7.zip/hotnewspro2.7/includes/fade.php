<script type="text/javascript">
//页面淡入淡出
	if(!+[1,]);else
	$(document).ready(function() {
	$('#wrapper').hide().fadeIn(1000);
});
</script>