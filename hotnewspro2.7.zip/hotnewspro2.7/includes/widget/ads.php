<div class="ad">
	<div class="ads">
	<div class="box_top">
		<i class="rt"></i>
		<i class="lt"></i>
	</div>
		<div class="ads_c"><p align="center"><?php echo stripslashes(get_option('swt_adsc')); ?></p>
			<div class="clear"></div>
		</div>
		<div class="box-bottom">
			<i class="lb"></i>
			<i class="rb"></i>
		</div>
	</div>
</div>