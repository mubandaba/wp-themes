<div id="sidebar">
      
    <div id="sidebarwidgit">
	  
	
	<?php if ( ! dynamic_sidebar( 'Sidebar' )) : ?>
	
	<?php endif; ?>
	</div>
   

</div>
<div id="sidebar2">
      
    <div id="sidebarwidgit">
	  
	
	<?php if ( ! dynamic_sidebar( 'Sidebar2' )) : ?>
	
	<?php endif; ?>
	</div>
   

</div>
