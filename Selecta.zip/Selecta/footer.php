<footer>
<div class="footer-inner">
<div id="footerinfo">
Selecta In Fatesinger
</div>
</div><!-- end #footer -->
</footer>

<?php wp_footer(); ?>

    
	<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/xBorder.js"></script>	
	
</body>
</html>