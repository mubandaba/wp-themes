<?php get_header(); ?>
	<article>      
						
						
				<div id="content">	<div class="post">				
					
						对不起，你请求的页面不存在！请 <a href="<?php bloginfo('url');?>"> 返回首页 </a>					
				</div>	</div>			
						
			
		 </article>
	
		<?php get_footer(); ?>
	