<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php if (is_home()) { echo bloginfo('name'); echo (' - '); bloginfo('description');} else if (is_404()) { bloginfo('name'); echo ' - Oops, This is a 404 Page'; } else if (is_search()) { bloginfo('name'); echo (' - Search Results');} else {bloginfo('name'); echo (' - '); wp_title(''); } ?></title>
<link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet" type="text/css" />
<link href="<?php bloginfo('template_directory'); ?>/css/dropmenu.css" rel="stylesheet" type="text/css" />
<link href="<?php bloginfo('template_directory'); ?>/css/comments.css" rel="stylesheet" type="text/css" />
<?php $featured_slider_activate = get_theme_option('featured_activate'); if($featured_slider_activate == 'Yes') { ?> 
<link href="<?php bloginfo('template_directory'); ?>/css/gallery.css" rel="stylesheet" type="text/css" />
<?php } else { ?><?php { /* nothing */ } ?><?php } ?> 
<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
<link rel="alternate" type="application/atom+xml" title="Atom 1.0" href="<?php bloginfo('atom_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<?php wp_get_archives('type=monthly&format=link'); ?>
<link rel="icon" href="<?php bloginfo('stylesheet_directory');?>/favicon.ico" type="images/x-icon" />
<?php $featured_slider_activate = get_theme_option('featured_activate'); if($featured_slider_activate == 'Yes') { ?>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/mootools.v1.11.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/jd.gallery.v2.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/jd.gallery.set.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/jd.gallery.transitions.js"></script>
<?php } else { ?><?php { /* nothing */ } ?><?php } ?> 
<?php remove_action( 'wp_head', 'wp_generator' ); ?>
<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
<?php wp_head(); ?>
<?php $g_analytics = get_theme_option('google_analytics'); echo stripcslashes($g_analytics); ?>
</head>

<body>

<div id="wrapper">
<div id="container">

<div id="header">
<div id="siteinfo">
<?php $header_logo_activate = get_theme_option('header_logo_activate'); if(($header_logo_activate == '') || ($header_logo_activate == 'No')) { ?>
<h1><a href="<?php echo home_url( '/' ); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a></h1>
<h2><?php bloginfo('description'); ?></h2>
<?php } else { ?>
<a href="<?php echo home_url( '/' ); ?>" title="<?php bloginfo('name'); ?>"><img src="<?php echo get_theme_option('logo_url'); ?>" alt="<?php bloginfo('name'); ?>" /></a>
<?php } ?>
</div><!-- SITEINFO END -->
<div id="topbanner">
<?php $header_banner = get_theme_option('header_banner'); if($header_banner == '') { ?>
<?php } else { ?>
<?php echo get_theme_option('header_banner'); ?>
<?php } ?>
</div><!-- TOPBANNER END -->
<div class="clearfix"></div>
</div><!-- HEADER END -->

<div id="navigation">
<div id="navigation-wrap">
<?php if ( function_exists( 'wp_nav_menu' ) ) { // Added in 3.0 ?>
<?php wp_nav_menu( array(
	'theme_location' => 'primary', 
	'menu_id' => 'dropmenu', 
	'container' => '', 
	'container_id' => '', 
	'fallback_cb' => 'revert_wp_menu_page',
	'link_before' => '',
	'link_after' => '',
	'depth' => '0'
	)); ?>
<?php } else { ?>
<ul id="dropmenu">
<li id="<?php if (is_home()) { ?>home<?php } else { ?>page_item<?php } ?>"><a href="<?php bloginfo('url'); ?>" title="Home">Home</a></li>
<?php wp_list_pages('title_li=&depth=0&sort_column=menu_order'); ?>
</ul><!-- DROPMENU END -->
<?php } ?>
<ul id="date">
<li>Today is <?php echo date('l, F j, Y'); ?></li>
</ul><!-- DATE END -->
<div class="clearfix"></div>
</div><!-- NAVIGATION WRAP-->
</div><!-- NAVIGATION END -->

<div id="main">

<?php include (TEMPLATEPATH . '/breadcrumbs.php'); ?>