<?php $featured_category = get_theme_option('featured_category'); $featured_number = get_theme_option('featured_number'); ?>
	
<?php if(($featured_category == "Choose a category:") || ($featured_number == 'Number of post:')) { ?>
	
<?php { /* nothing */ } ?>

<?php } else { ?>

<div id="featured">
<div id="featured-title">Featured News</div>
<div id="Gallerybox">
<script type="text/javascript">
function startGallery() {
var myGallery = new gallery($('myGallery'), {
timed: true,
showArrows: true,
showCarousel: false,
embedLinks: true
});
document.gallery = myGallery;
}
window.onDomReady(startGallery);
</script>	

<div id="myGallery">

<?php
$my_query = new WP_Query('cat='. $featured_category . '&' . 'showposts='. $featured_number . '&' . 'orderby=date');
while ($my_query->have_posts()) : $my_query->the_post();
$do_not_duplicate = $post->ID;
$the_post_ids = get_the_ID();
?>

<div class="imageElement post-<?php the_ID(); ?>">

<?php echo get_featured_post_image("", "", 600, 600, "alignnone full", "large", the_title_attribute('echo=0') ,the_title_attribute('echo=0'), true); ?>

<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
<p><?php the_featured_excerpt(); ?></p>
<a href="<?php the_permalink(); ?>" title="open image" class="open"></a>
</div><!-- IMAGE ELEMENT POST <?php the_ID(); ?> END -->

<?php endwhile;?>

</div><!-- MYGALLERY END -->
</div><!-- GALLERBOX END -->
</div><!-- FEATURED END -->

<?php } ?> 