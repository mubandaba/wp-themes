<div id="sidebar">
<div id="sidebarinner">

<div id="sidebar-left">
<ul class="sidebar_list">

<?php include (TEMPLATEPATH . '/searchform.php'); ?>

<?php if(is_single()) { ?>
<?php include (TEMPLATEPATH . '/related.php'); ?> 
<?php } ?>

<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar(1)) : ?>


<?php $featured_category_active = get_theme_option('featured_category_activate'); if(($featured_category_active == '') || ($featured_category_active == 'No')) { ?>
<?php { /* nothing */ } ?>
<?php } else { ?>
<?php if(is_home()) { ?>
<?php include (TEMPLATEPATH . '/featured-category.php'); ?> 
<?php } ?> 
<?php } ?>


<li class="widget_calendar">
<h6><?php _e('Calendar'); ?></h6>
<?php get_calendar(); ?>
</li>

<li class="widget_categories">
<h6><?php _e('Categories'); ?></h6>
<ul>
<?php wp_list_categories('orderby=id&show_count=1&use_desc_for_title=0&title_li='); ?>
</ul>
</li>

<li class="widget_archive">
<h6><?php _e('Archives'); ?></h6>
<ul>
<?php wp_get_archives('type=monthly&limit=&show_post_count=1'); ?>
</ul>	
</li>

<?php endif; ?>

</ul><!-- SIDEBAR LIST LEFT END -->
</div><!-- SIDEBAR LEFT END -->

<div id="sidebar-right">
<ul class="sidebar_list">

<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar(2)) : ?>

<?php $emvideo_activate = get_theme_option('emvideo_activate'); if(($emvideo_activate == '') || ($emvideo_activate == 'No')) { ?>
<?php { /* nothing */ } ?>
<?php } else { ?>
<?php include (TEMPLATEPATH . '/video.php'); ?>
<?php } ?>

<?php $sponsor_activate = get_theme_option('sponsor_activate'); if(($sponsor_activate == '') || ($sponsor_activate == 'No')) { ?>
<?php { /* nothing */ } ?>
<?php } else { ?>
<?php include (TEMPLATEPATH . '/sponsor.php'); ?>
<?php } ?>

<li class="widget_pages">
<h6><?php _e('Pages'); ?></h6>
<ul>
<?php wp_list_pages('title_li=&depth=0&sort_column=menu_order'); ?>
</ul>
</li>

<li class="widget_recentcomments_gravatar">
<h6><?php _e('Recent Comments'); ?></h6>
	<ul>
		<?php get_avatar_recent_comment(); ?>
	</ul>
</li>


<li class="widget_hottopics">
<h6><?php _e('Hot Topics'); ?></h6>
	<ul>
		<?php get_hottopics(); ?>
	</ul>
</li>


<li class="widget_tag_cloud">
<h6><?php _e('Popular Tags'); ?></h6>
<div>
<?php if(function_exists("wp_tag_cloud")) { ?>
<?php wp_tag_cloud('smallest=8&largest=20&'); ?>
<?php } ?>
</div>
</li>



<?php endif; ?>

</ul><!-- SIDEBAR LIST RIGHT END -->
</div><!-- SIDEBAR RIGHT END -->

</div><!-- SIDEBARINNER END -->
</div><!-- SIDEBAR END -->