<li id="sponsorbox">
<h6><?php _e('Advertisements'); ?></h6>
<div id="sponsor-inner">
<ul>

<?php $sponsor_banner = get_theme_option('sponsor_banner_one'); if($sponsor_banner == '') { ?>
<?php { /* nothing */ } ?>
<?php } else { ?>
<li><?php echo stripcslashes($sponsor_banner); ?></li>
<?php } ?>

<?php $sponsor_banner = get_theme_option('sponsor_banner_two'); if($sponsor_banner == '') { ?>
<?php { /* nothing */ } ?>
<?php } else { ?>
<li><?php echo stripcslashes($sponsor_banner); ?></li>
<?php } ?>

<?php $sponsor_banner = get_theme_option('sponsor_banner_three'); if($sponsor_banner == '') { ?>
<?php { /* nothing */ } ?>
<?php } else { ?>
<li><?php echo stripcslashes($sponsor_banner); ?></li>
<?php } ?>

<?php $sponsor_banner = get_theme_option('sponsor_banner_four'); if($sponsor_banner == '') { ?>
<?php { /* nothing */ } ?>
<?php } else { ?>
<li><?php echo stripcslashes($sponsor_banner); ?></li>
<?php } ?>

<?php $sponsor_banner = get_theme_option('sponsor_banner_five'); if($sponsor_banner == '') { ?>
<?php { /* nothing */ } ?>
<?php } else { ?>
<li><?php echo stripcslashes($sponsor_banner); ?></li>
<?php } ?>

<?php $sponsor_banner = get_theme_option('sponsor_banner_six'); if($sponsor_banner == '') { ?>
<?php { /* nothing */ } ?>
<?php } else { ?>
<li><?php echo stripcslashes($sponsor_banner); ?></li>
<?php } ?>

</ul>
<div class="clearfix"></div>
</div>
</li><!-- SPONSORBOX END -->