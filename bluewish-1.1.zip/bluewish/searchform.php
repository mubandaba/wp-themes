<li id="searchbox">
<form method="get" action="<?php bloginfo('home'); ?>" id="searchform">
<input name="s" type="text" class="sbm-b" value="Search Here..." onfocus="if (this.value == 'Search Here...') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Search Here...';}" />
</form>
</li><!-- SEARCHBOX END -->