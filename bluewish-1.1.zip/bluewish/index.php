<?php get_header(); ?>

<div id="content">

<?php $featured_slider_activate = get_theme_option('featured_activate'); if(($featured_slider_activate == '') || ($featured_slider_activate == 'No')) { ?>
<?php { /* nothing */ } ?>
<?php } else { ?>
<?php if((is_home())&& ($paged < 1)) { ?>
<?php include (TEMPLATEPATH . '/featured.php'); ?> 
<?php } ?>
<?php } ?>

<div id="post-entry">

<?php $postcounter = 1; if (have_posts()) : ?>

<?php while (have_posts()) : $postcounter = $postcounter + 1; the_post(); $do_not_duplicate = $post->ID; $the_post_ids = get_the_ID(); ?>

<div class="post-meta" id="post-<?php the_ID(); ?>">
<div class="post-info">
<h2><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
<div class="post-date">
Posted By <?php the_author_posts_link(); ?> On <?php the_time('F jS Y') ?>. Under&nbsp;<?php the_category(', ') ?>&nbsp;&nbsp;<?php if(function_exists("the_tags")) : ?><?php the_tags('Tags:&nbsp;') ?><?php endif; ?>&nbsp;&nbsp;<?php edit_post_link('Edit Post'); ?>.
</div><!-- POST DATE END -->
</div><!-- POST INFO END -->

<div class="post-content">

<?php $values = get_post_custom_values("post-img"); if (isset($values[0])) : ?>

<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><img src="<?php $values = get_post_custom_values("post-img"); echo $values[0]; ?>" alt="<?php the_title(); ?>" width="<?php $thumbwidth = get_theme_option('thumb_width');  if($thumbwidth == '') { ?>200<?php } else { ?><?php echo stripcslashes($thumbwidth); ?><?php } ?>" height="<?php $thumbheight = get_theme_option('thumb_height');  if($thumbheight == '') { ?>150<?php } else { ?><?php echo stripcslashes($thumbheight); ?><?php } ?>" class="alignleft" /></a>

<?php else: ?>

<?php echo get_featured_post_image("<div class='post-thumb in-archive'>".$thepostlink, "</a></div>", 150, 150, "alignleft", "thumbnail", get_singular_cat('false') ,the_title_attribute('echo=0'), false); ?>


<?php endif; ?>

<?php echo get_custom_the_excerpt(40,''); ?>

</div><!-- POST CONTENT END -->

</div><!-- POST META <?php the_ID(); ?> END -->

<?php $get_google_activate = get_theme_option('adsense_loop_activate'); if(($get_google_activate == '') || ($get_google_activate == 'Disable')) { ?>
<?php } else { ?>
<?php $get_google_code = get_theme_option('adsense_loop'); if($get_google_code == '') { ?>
<?php } else { ?>
<?php if($postcounter <= 4){ ?>
<div class="adsense-loop">
<?php echo stripcslashes($get_google_code); ?>
</div>
<?php } ?>
<?php } ?>
<?php } ?>

<?php endwhile; ?>

<?php else : ?>

<p class="center">NOT FOUND</p>

<p class="center">Sorry, but you are looking for something that isn't here.</p>

<?php endif; ?>

</div><!-- POST ENTRY END -->

<?php include (TEMPLATEPATH . '/paginate.php'); ?>

</div><!-- CONTENT END -->

<?php get_sidebar(); ?>

<?php get_footer(); ?>