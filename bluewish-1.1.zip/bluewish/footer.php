<div class="clearfix"></div>
</div><!-- MAIN END -->

<div id="footer">
<div id="footer-wrap">
<div id="footer-left"><?php _e('Copyright &copy;', TEMPLATE_DOMAIN); ?> <?php echo gmdate(__('Y', TEMPLATE_DOMAIN)); ?>. <?php bloginfo('name'); ?><br /><a href="http://www.magpress.com/wordpress-themes/bluewish.html" title="Bluewish WordPress Theme">Bluewish WordPress Theme</a> By MagPress
</div>

<?php
if( has_nav_menu('footer') ) {
echo '<div id="footer-right">';
wp_nav_menu( array(
    'theme_location' => 'footer',
    'container' => false,
    'depth' => 1,
    'fallback_cb' => ''
    ));
echo '</div>';
}
?>



<div class="clearfix"></div>
</div><!--FOOTER WRAP -->
</div><!-- FOOTER END -->

</div><!-- CONTAINER END -->
</div><!-- WRAPPER END -->

<?php wp_footer(); ?>

</body>

</html>