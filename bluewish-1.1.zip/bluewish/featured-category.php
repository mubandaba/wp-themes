<li id="featured-category">

<?php $featured_category = get_theme_option('featured_category_id1'); $featured_number = get_theme_option('featured_number1'); ?>

<?php if(($featured_category == 'Choose a category:') || ($featured_number == 'Number of post:')) { ?>

<?php { /* nothing */ } ?>

<?php } else { ?>

<div class="featured-cat-entry">
<h5>Latest Articles On <?php $cat_id = get_cat_id($featured_category); $category = get_cat_name($cat_id); echo $category; ?></h5>

<?php
$category_id = get_cat_id($featured_category);
$my_query = new WP_Query('cat='. $category_id . '&' . 'offset=' . '&' . 'showposts='. $featured_number);
while ($my_query->have_posts()) : $my_query->the_post(); $do_not_duplicate = $post->ID; $the_post_ids = get_the_ID();
?>

<div class="featured-cat-meta post-<?php the_ID(); ?>">

<?php echo get_featured_post_image("<div class='featured-cat-img'>", "</div>", 60, 60, "alignleft", "thumbnail", the_title_attribute('echo=0') ,the_title_attribute('echo=0'), false); ?>

<h2><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>

<span class="featured-cat-date">Posted On <?php the_time('d M Y'); ?>&nbsp;&nbsp;<?php edit_post_link('Edit'); ?></span>

<p><?php the_excerpt_feat_cat(); ?></p>

<div class="clearfix"></div>
</div><!-- FEATURED CATEGORY META <?php the_ID(); ?> END -->

<?php endwhile;?> 

</div><!-- FEATURED CATEGORY 1 ENTRY END -->

<?php } ?>


<?php $featured_category = get_theme_option('featured_category_id2'); $featured_number = get_theme_option('featured_number2'); ?>

<?php if(($featured_category == 'Choose a category:') || ($featured_number == 'Number of post:')) { ?>

<?php { /* nothing */ } ?>

<?php } else { ?>

<div class="featured-cat-entry">
<h5>Latest Articles On <?php $cat_id = get_cat_id($featured_category); $category = get_cat_name($cat_id); echo $category; ?></h5>

<?php
$category_id = get_cat_id($featured_category);
$my_query = new WP_Query('cat='. $category_id . '&' . 'offset=' . '&' . 'showposts='. $featured_number);
while ($my_query->have_posts()) : $my_query->the_post(); $do_not_duplicate = $post->ID; $the_post_ids = get_the_ID();
?>

<div class="featured-cat-meta post-<?php the_ID(); ?>">

<?php echo get_featured_post_image("<div class='featured-cat-img'>", "</div>", 60, 60, "alignleft", "thumbnail", the_title_attribute('echo=0') ,the_title_attribute('echo=0'), false); ?>

<h2><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>

<span class="featured-cat-date">Posted On <?php the_time('d M Y') ?>&nbsp;&nbsp;<?php edit_post_link('Edit'); ?></span>

<p><?php the_excerpt_feat_cat(); ?></p>

<div class="clearfix"></div>
</div><!-- FEATURED CATEGORY META <?php the_ID(); ?> END -->

<?php endwhile;?> 

</div><!-- FEATURED CATEGORY 2 ENTRY END -->

<?php } ?>

<?php $featured_category = get_theme_option('featured_category_id3'); $featured_number = get_theme_option('featured_number3'); ?>

<?php if(($featured_category == 'Choose a category:') || ($featured_number == 'Number of post:')) { ?>

<?php { /* nothing */ } ?>

<?php } else { ?>

<div class="featured-cat-entry">
<h5>Latest Articles On <?php $cat_id = get_cat_id($featured_category); $category = get_cat_name($cat_id); echo $category; ?></h5>

<?php
$category_id = get_cat_id($featured_category);
$my_query = new WP_Query('cat='. $category_id . '&' . 'offset=' . '&' . 'showposts='. $featured_number);
while ($my_query->have_posts()) : $my_query->the_post(); $do_not_duplicate = $post->ID; $the_post_ids = get_the_ID();
?>

<div class="featured-cat-meta post-<?php the_ID(); ?>">

<?php echo get_featured_post_image("<div class='featured-cat-img'>", "</div>", 60, 60, "alignleft", "thumbnail", the_title_attribute('echo=0') ,the_title_attribute('echo=0'), false); ?>       

<h2><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>

<span class="featured-cat-date">Posted On <?php the_time('d M Y') ?>&nbsp;&nbsp;<?php edit_post_link('Edit'); ?></span>

<p><?php the_excerpt_feat_cat(); ?></p>

<div class="clearfix"></div>
</div><!-- FEATURED CATEGORY META <?php the_ID(); ?> END -->

<?php endwhile;?> 

</div><!-- FEATURED CATEGORY 3 ENTRY END -->

<?php } ?>

</li><!-- FEATURED CATEGORY END -->