<?php
$this_post = $post;
$category = get_the_category(); $category = $category[0]; $category = $category->cat_ID;
$posts = get_posts('numberposts=6&offset=0&orderby=post_date&order=DESC&category='.$category);
$count = 0;
foreach ( $posts as $post ) {
if ( $post->ID == $this_post->ID || $count == 5) {
unset($posts[$count]);
}else{
$count ++;
}
}
?>


<?php if ( $posts ) : ?> 

<li id="related-category">

<div class="related-cat-entry">
<h5><?php _e('Related Articles From This Category'); ?></h5>

<?php foreach ( $posts as $post ) : ?>
<?php setup_postdata($post); ?>

<div class="related-cat-meta post-<?php the_ID(); ?>">

<?php echo get_featured_post_image("<div class='related-cat-img'>", "</div>", 60, 60, "alignleft", "thumbnail", the_title_attribute('echo=0') ,the_title_attribute('echo=0'), false); ?>

<h2><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>

<span class="related-cat-date">Published On <?php the_time('d M Y') ?>&nbsp;&nbsp;<?php edit_post_link('Edit'); ?></span>

<p><?php the_excerpt_feat_cat(); ?></p>

<div class="clearfix"></div>
</div><!-- RELATED CAT META <?php the_ID(); ?> END -->

<?php endforeach // $posts as $post ?>

</div><!-- RELATED ENTRY END -->

</li><!-- RELATED CATEGORY END -->

<?php else : ?>

<?php { /* nothing */ } ?>

<?php endif // $posts ?>

<?php
$post = $this_post;
unset($this_post);
?>