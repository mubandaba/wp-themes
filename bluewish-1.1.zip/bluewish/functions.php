<?php
define('TEMPLATE_DOMAIN', 'bluewish'); // do not change this, its for translation and options string
if ( !isset( $content_width ) ) { $content_width = 550; }
////////////////////////////////////////////////////////////////////////////////
// Global Setup
////////////////////////////////////////////////////////////////////////////////
function mp_theme_setup() {
//Add Language Support
load_theme_textdomain( TEMPLATE_DOMAIN, get_template_directory() . '/languages' );
add_theme_support( "title-tag" );
add_theme_support( 'post-thumbnails' );
add_theme_support( 'automatic-feed-links' );
add_editor_style();
add_theme_support( 'menus' );
if( class_exists('woocommerce') ) { add_theme_support('woocommerce'); }

register_nav_menus( array(
'primary' => __( 'Page Navigation', TEMPLATE_DOMAIN ),
'footer' => __( 'Footer Navigation', TEMPLATE_DOMAIN ),
));

$custom_background_support = array(
	'default-color'          => '',
	'default-image'          => '',
	'wp-head-callback'       => '_custom_background_cb',
	'admin-head-callback'    => '',
	'admin-preview-callback' => ''
);
add_theme_support( 'custom-background', $custom_background_support );

// Add support for custom headers.
$custom_header_support = array(
// The default header text color.
		'default-text-color' => 'ffffff',
        'default-image' => '',
        'header-text'  => true,
		// The height and width of our custom header.
		'width' => 1440,
		'height' => '',
		// Support flexible heights.
		'flex-height' => true,
		// Random image rotation by default.
	   'random-default'	=> false,
		// Callback for styling the header.
		'wp-head-callback' => '',
		// Callback for styling the header preview in the admin.
		'admin-head-callback' => '',
		// Callback used to display the header preview in the admin.
		'admin-preview-callback' => '',
);
add_theme_support( 'custom-header', $custom_header_support );

remove_theme_support( 'custom-header' );
remove_theme_support( 'custom-background' );
}
add_action( 'after_setup_theme', 'mp_theme_setup' );

function revert_wp_menu_page() { //revert back to normal if in wp 3.0 and menu not set ?>
<ul id="dropmenu">
  <li id="<?php if (is_home()) { ?>home<?php } else { ?>page_item<?php } ?>">
    <a href="<?php bloginfo('url'); ?>" title="Home"><?php _e('Home', TEMPLATE_DOMAIN); ?></a>
  </li>
  <?php wp_list_pages('title_li=&depth=0&sort_column=menu_order'); ?>
</ul>
<?php }
////////////////////////////////////////////////////////////////////////////////
// Get Featured Post Image
////////////////////////////////////////////////////////////////////////////////
function get_featured_slider_image() {
global $post, $posts;
$first_img = '';
ob_start();
ob_end_clean();
$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
$first_img = $matches [1] [0];
if(empty($first_img)){ //Defines a default image
$img_dir = get_bloginfo('template_directory');
$first_img = $img_dir . '/images/feat-default.jpg';
}
return $first_img;
}
////////////////////////////////////////////////////////////////////////////////
// Get Standard Post Image
////////////////////////////////////////////////////////////////////////////////
function get_post_image() {
global $post, $posts;
$first_img = '';
ob_start();
ob_end_clean();
$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
$first_img = $matches [1] [0];
if(empty($first_img)){ //Defines a default image
$img_dir = get_bloginfo('template_directory');
$first_img = $img_dir . '/images/post-default.jpg';
}
return $first_img;
}
////////////////////////////////////////////////////////////////////////////////
// Get Featured Category Image
////////////////////////////////////////////////////////////////////////////////
function get_featcat_image() {
global $post, $posts;
$first_img = '';
ob_start();
ob_end_clean();
$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
$first_img = $matches [1] [0];
if(empty($first_img)){ //Defines a default image
$img_dir = get_bloginfo('template_directory');
$first_img = $img_dir . '/images/feat-cat-default.jpg';
}
return $first_img;
}

////////////////////////////////////////////////////////////////////////////////
// get featured images
////////////////////////////////////////////////////////////////////////////////
if( !function_exists( 'get_featured_post_image' )):
function get_featured_post_image($before,$after,$width,$height,$class,$size,$alt,$title,$default) { //$size - full, large, medium, thumbnail
global $blog_id,$wpdb, $post, $posts;
$image_id = get_post_thumbnail_id();
$image_url = wp_get_attachment_image_src($image_id,$size);
$image_url = $image_url[0];
$current_theme = wp_get_theme();
$first_img = '';
ob_start();
ob_end_clean();
$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);

if( isset($matches[1][0] ) ): $first_img = $matches[1][0]; endif;

if( has_post_thumbnail( $post->ID ) ) {
return $before . "<img width='" . $width . "' height='auto' class='" . $class . "' src='" . $image_url . "' alt='" . $alt . "' title='" . $title . "' />" . $after;
} else {
if($first_img) {
return $before . "<img width='" . $width . "' height='auto' class='" . $class . "' src='" . $first_img . "' alt='" . $alt . "' title='" . $title . "' />" . $after;
} else {
if($default == 'true'):
return $before . "<img width='" . $width . "' height='auto' class='" . $class . "' src='" . get_template_directory_uri() . '/images/noimage.png' . "' alt='" . $alt . "' title='" . $title . "' />" . $after;
endif;
}
}
}
endif;

////////////////////////////////////////////////////////////////////////////////
// excerpt the_content()
////////////////////////////////////////////////////////////////////////////////
if( !function_exists( 'get_custom_the_excerpt' )):
function get_custom_the_excerpt($limit='',$more='') {
global $post;
if($limit == 'disable' || $limit == '0') {
$excerpt = '';

} else {

$thepostlink = '<a class="readmore" href="'. get_permalink() . '" title="' . the_title_attribute('echo=0') . '">';
$custom_text = get_post_field('post_excerpt',$post->ID);
$all_content = get_the_content();
//Regular expression that strips the header tags and their content.
$regex = '#(<h([1-6])[^>]*>)\s?(.*)?\s?(<\/h\2>)#';
$content = preg_replace($regex,'', $all_content);

//if use manual excerpt
if($custom_text) {
if($more) {
    $excerpt = $custom_text . $thepostlink . $more . '</a>';
    } else {
    $excerpt = $custom_text;
    }

} else {

//check if its chinese character input
$chinese_output = preg_match_all("/\p{Han}+/u", $post->post_content, $matches);
if($chinese_output) {

if($more) {
$excerpt = mb_substr( get_the_excerpt(), 0, $limit*2 ) . '...' . $thepostlink . $more.'</a>';
} else {
$excerpt = mb_substr( get_the_excerpt(), 0, $limit*2 ) . '...';
}

} else {

//remove caption tag
$content_filter_cap = strip_shortcodes( $content );
//remove email tag
$pattern = "/[^@\s]*@[^@\s]*\.[^@\s]*/";
$replacement = "";
$content_filter = preg_replace($pattern, $replacement, $content_filter_cap);

if($more) {
    $excerpt = wp_trim_words($content_filter, $limit) . $thepostlink.$more.'</a>';
    } else {
    $excerpt = wp_trim_words($content_filter, $limit);
    }
}
}
}
return apply_filters('mp_get_custom_excerpt',$excerpt);
}
endif;


////////////////////////////////////////////////////////////////////////////////
// Featured Content Excerpt Post
////////////////////////////////////////////////////////////////////////////////

function the_featured_excerpt($excerpt_length=30, $allowedtags='', $filter_type='none', $use_more_link=false, $more_link_text="Read More", $force_more_link=false, $fakeit=1, $fix_tags=true) {
if (preg_match('%^content($|_rss)|^excerpt($|_rss)%', $filter_type)) {
$filter_type = 'the_' . $filter_type;
}
$text = apply_filters($filter_type, get_the_featured_excerpt($excerpt_length, $allowedtags, $use_more_link, $more_link_text, $force_more_link, $fakeit));
$text = ($fix_tags) ? balanceTags($text) : $text;
echo $text;
}


function get_the_featured_excerpt($excerpt_length, $allowedtags, $use_more_link, $more_link_text, $force_more_link, $fakeit) {
global $id, $post;
$output = '';
$output = $post->post_excerpt;
if (!empty($post->post_password)) { // if there's a password
if ($_COOKIE['wp-postpass_'.COOKIEHASH] != $post->post_password) {  // and it doesn't match the cookie
$output = __('There is no excerpt because this is a protected post.');
return $output;
}
}
// If we haven't got an excerpt, make one.
if ((($output == '') && ($fakeit == 1)) || ($fakeit == 2)) {
$output = $post->post_content;
$output = strip_tags($output, $allowedtags);
$output = preg_replace( '|\[(.+?)\](.+?\[/\\1\])?|s', '', $output );
$blah = explode(' ', $output);
if (count($blah) > $excerpt_length) {
$k = $excerpt_length;
$use_dotdotdot = 1;
} else {
$k = count($blah);
$use_dotdotdot = 0;
}
$excerpt = '';
for ($i=0; $i<$k; $i++) {
$excerpt .= $blah[$i] . ' ';
}
if (($use_more_link && $use_dotdotdot) || $force_more_link) {
$excerpt .= "...&nbsp;<a href=\"". get_permalink() . "#more-$id\" class=\"more-link\">$more_link_text</a>";
} else {
$excerpt .= ($use_dotdotdot) ? '...' : '';
}
$output = $excerpt;
} // end if no excerpt
return $output;
}


////////////////////////////////////////////////////////////////////////////////
// get/show single category only
////////////////////////////////////////////////////////////////////////////////
function get_singular_cat($link = '') {
global $post;
$category_check = get_the_category();
$category = isset( $category_check ) ? $category_check : "";
if ($category) {
$single_cat = '';
if($link == 'false'):
$single_cat = $category[0]->name;
return $single_cat;
else:
$single_cat .= '<a href="' . get_category_link( $category[0]->term_id ) . '" title="' . sprintf( __( "View all posts in %s", TEMPLATE_DOMAIN ), $category[0]->name ) . '" ' . '>';
$single_cat .= $category[0]->name;
$single_cat .= '</a>';
return $single_cat;
endif;
} else {
return NULL;
}
}

////////////////////////////////////////////////////////////////////////////////
// GET SINGLE CATEGORY NAME ONLY
////////////////////////////////////////////////////////////////////////////////
if( !function_exists('get_singular_cat_name') ) {
function get_singular_cat_name() {
global $post;
$category = get_the_category();
if ( $category ) { $single_cat = $category[0]->name; }
return $single_cat;
}
}




////////////////////////////////////////////////////////////////////////////////
// Standard Post Excerpt
////////////////////////////////////////////////////////////////////////////////
function the_post_excerpt($excerpt_length=50, $allowedtags='', $filter_type='none', $use_more_link=true, $more_link_text="Read More", $force_more_link=true, $fakeit=1, $fix_tags=true) {
if (preg_match('%^content($|_rss)|^excerpt($|_rss)%', $filter_type)) {
$filter_type = 'the_' . $filter_type;
}
$text = apply_filters($filter_type, get_the_post_excerpt($excerpt_length, $allowedtags, $use_more_link, $more_link_text, $force_more_link, $fakeit));
$text = ($fix_tags) ? balanceTags($text) : $text;
echo $text;
}
function get_the_post_excerpt($excerpt_length, $allowedtags, $use_more_link, $more_link_text, $force_more_link, $fakeit) {
global $id, $post;
$output = '';
$output = $post->post_excerpt;
if (!empty($post->post_password)) { // if there's a password
if ($_COOKIE['wp-postpass_'.COOKIEHASH] != $post->post_password) {  // and it doesn't match the cookie
$output = __('There is no excerpt because this is a protected post.');
return $output;
}
}
// If we haven't got an excerpt, make one.
if ((($output == '') && ($fakeit == 1)) || ($fakeit == 2)) {
$output = $post->post_content;
$output = strip_tags($output, $allowedtags);
$output = preg_replace( '|\[(.+?)\](.+?\[/\\1\])?|s', '', $output );
$blah = explode(' ', $output);
if (count($blah) > $excerpt_length) {
$k = $excerpt_length;
$use_dotdotdot = 1;
} else {
$k = count($blah);
$use_dotdotdot = 0;
}
$excerpt = '';
for ($i=0; $i<$k; $i++) {
$excerpt .= $blah[$i] . ' ';
}
if (($use_more_link && $use_dotdotdot) || $force_more_link) {
$excerpt .= "...&nbsp;<a href=\"". get_permalink() . "#more-$id\" class=\"more-link\">$more_link_text</a>";
} else {
$excerpt .= ($use_dotdotdot) ? '...' : '';
}
$output = $excerpt;
} // end if no excerpt
return $output;
}
////////////////////////////////////////////////////////////////////////////////
// Excerpt Feature Category
////////////////////////////////////////////////////////////////////////////////
function the_excerpt_feat_cat($excerpt_length=15, $allowedtags='', $filter_type='none', $use_more_link=false, $more_link_text="Read More", $force_more_link=false, $fakeit=1, $fix_tags=true) {
if (preg_match('%^content($|_rss)|^excerpt($|_rss)%', $filter_type)) {
$filter_type = 'the_' . $filter_type;
}
$text = apply_filters($filter_type, get_the_excerpt_feat_cat($excerpt_length, $allowedtags, $use_more_link, $more_link_text, $force_more_link, $fakeit));
$text = ($fix_tags) ? balanceTags($text) : $text;
echo $text;
}
function get_the_excerpt_feat_cat($excerpt_length, $allowedtags, $use_more_link, $more_link_text, $force_more_link, $fakeit) {
global $id, $post;
$output = '';
$output = $post->post_excerpt;
if (!empty($post->post_password)) { // if there's a password
if ($_COOKIE['wp-postpass_'.COOKIEHASH] != $post->post_password) {  // and it doesn't match the cookie
$output = __('There is no excerpt because this is a protected post.');
return $output;
}
}
// If we haven't got an excerpt, make one.
if ((($output == '') && ($fakeit == 1)) || ($fakeit == 2)) {
$output = $post->post_content;
$output = strip_tags($output, $allowedtags);
$output = preg_replace( '|\[(.+?)\](.+?\[/\\1\])?|s', '', $output );
$blah = explode(' ', $output);
if (count($blah) > $excerpt_length) {
$k = $excerpt_length;
$use_dotdotdot = 1;
} else {
$k = count($blah);
$use_dotdotdot = 0;
}
$excerpt = '';
for ($i=0; $i<$k; $i++) {
$excerpt .= $blah[$i] . ' ';
}
if (($use_more_link && $use_dotdotdot) || $force_more_link) {
$excerpt .= "...&nbsp;<a href=\"". get_permalink() . "#more-$id\">$more_link_text</a>";
} else {
$excerpt .= ($use_dotdotdot) ? '...' : '';
}
$output = $excerpt;
} // end if no excerpt
return $output;
}
////////////////////////////////////////////////////////////////////////////////
// WP-PageNavi
////////////////////////////////////////////////////////////////////////////////
function custom_wp_pagenavi($before = '', $after = '', $prelabel = '', $nxtlabel = '', $pages_to_show = 5, $always_show = false) {
global $request, $posts_per_page, $wpdb, $paged;
if(empty($prelabel)) {
$prelabel  = '<strong>&laquo;</strong>';
}
if(empty($nxtlabel)) {
$nxtlabel = '<strong>&raquo;</strong>';
}
$half_pages_to_show = round($pages_to_show/2);
if (!is_single()) {
if(!is_category()) {
preg_match('#FROM\s(.*)\sORDER BY#siU', $request, $matches);
} else {
preg_match('#FROM\s(.*)\sGROUP BY#siU', $request, $matches);
}
$fromwhere = $matches[1];
$numposts = $wpdb->get_var("SELECT COUNT(DISTINCT ID) FROM $fromwhere");
$max_page = ceil($numposts /$posts_per_page);
if(empty($paged)) {
$paged = 1;
}
if($max_page > 1 || $always_show) {
echo "$before <div class=\"wp-pagenavi\"><span class=\"pages\">Page $paged of $max_page:</span>";
if ($paged >= ($pages_to_show-1)) {
echo '<a href="'.get_pagenum_link().'">&laquo; First</a>&nbsp;';
}
previous_posts_link($prelabel);
for($i = $paged - $half_pages_to_show; $i  <= $paged + $half_pages_to_show; $i++) {
if ($i >= 1 && $i <= $max_page) {
if($i == $paged) {
echo "<strong class='current'>$i</strong>";
} else {
echo ' <a href="'.get_pagenum_link($i).'">'.$i.'</a> ';
}
}
}
next_posts_link($nxtlabel, $max_page);
if (($paged+$half_pages_to_show) < ($max_page)) {
echo '&nbsp;<a href="'.get_pagenum_link($max_page).'">Last &raquo;</a>';
}
echo "</div> $after";
}
}
}
////////////////////////////////////////////////////////////////////////////////
// Get Recent Comments With Avatar
////////////////////////////////////////////////////////////////////////////////
function get_avatar_recent_comment() {
global $wpdb;
$sql = "SELECT DISTINCT ID, post_title, post_password, comment_ID,
comment_post_ID, comment_author, comment_author_email, comment_date_gmt, comment_approved,
comment_type,comment_author_url,
SUBSTRING(comment_content,1,50) AS com_excerpt
FROM $wpdb->comments
LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID =
$wpdb->posts.ID)
WHERE comment_approved = '1' AND comment_type = '' AND
post_password = ''
ORDER BY comment_date_gmt DESC LIMIT 5";
$comments = $wpdb->get_results($sql);
$output = $pre_HTML;
$gravatar_status = 'on'; /* off if not using */
foreach ($comments as $comment) {
$email = $comment->comment_author_email;
$grav_name = $comment->comment_author;
$grav_url = "http://www.gravatar.com/avatar.php?gravatar_id=".md5($email). "&amp;size=32"; ?>
<li class="noarrow">
  <?php if($gravatar_status == 'on') { ?>
  <img src="<?php echo $grav_url; ?>" alt="<?php echo $grav_name; ?>" />
  <?php } ?>
  <div class="com-info">
    <span class="comy">
      <span>
        <?php echo strip_tags($comment->comment_author); ?>
      </span>&nbsp;Says:
    </span>
    <span class="comtext">
      <a href="<?php echo get_permalink($comment->ID); ?>#comment-<?php echo $comment->comment_ID; ?>" title="on <?php echo $comment->post_title; ?>">
        <?php echo strip_tags($comment->com_excerpt); ?>...
      </a>
    </span>
  </div>
  <div class="clearfix">
  </div>
</li>
<?php
}
}
////////////////////////////////////////////////////////////////////////////////
// Most Comments
////////////////////////////////////////////////////////////////////////////////
function get_hottopics($limit = 5) {
global $wpdb, $post;
$mostcommenteds = $wpdb->get_results("SELECT  $wpdb->posts.ID, post_title, post_name, post_date, COUNT($wpdb->comments.comment_post_ID) AS 'comment_total' FROM $wpdb->posts LEFT JOIN $wpdb->comments ON $wpdb->posts.ID = $wpdb->comments.comment_post_ID WHERE comment_approved = '1' AND post_date_gmt < '".gmdate("Y-m-d H:i:s")."' AND post_status = 'publish' AND post_password = '' GROUP BY $wpdb->comments.comment_post_ID ORDER  BY comment_total DESC LIMIT $limit");
foreach ($mostcommenteds as $post) {
$post_title = htmlspecialchars(stripslashes($post->post_title));
$comment_total = (int) $post->comment_total;
echo "<li><a href=\"".get_permalink()."\">$post_title</a><br /><span class=\"total-com\">$comment_total comments received</span></li>";
}
}
////////////////////////////////////////////////////////////////////////////////
// Comment And Ping Setup
////////////////////////////////////////////////////////////////////////////////
function list_pings($comment, $args, $depth) {
$GLOBALS['comment'] = $comment; ?>
<li id="comment-<?php comment_ID(); ?>">
  <?php comment_author_link(); ?>
  <?php }
add_filter('get_comments_number', 'comment_count', 0);
function comment_count( $count ) {
global $id;
$comments_by_type = &separate_comments(get_comments('post_id=' . $id));
return count($comments_by_type['comment']);
}
////////////////////////////////////////////////////////////////////////////////
// Comment and pingback separate controls
////////////////////////////////////////////////////////////////////////////////
$bm_trackbacks = array();
$bm_comments = array();
function split_comments( $source ) {
if ( $source ) foreach ( $source as $comment ) {
global $bm_trackbacks;
global $bm_comments;
if ( $comment->comment_type == 'trackback' || $comment->comment_type == 'pingback' ) {
$bm_trackbacks[] = $comment;
} else {
$bm_comments[] = $comment;
}
}
}
////////////////////////////////////////////////////////////////////////////////
// Sidebar Widget
////////////////////////////////////////////////////////////////////////////////
if ( function_exists('register_sidebar') ) {
register_sidebar(array('name'=>'Sidebar Left',
'before_widget' => '<li id="%1$s" class="widget %2$s">',
'after_widget' => '</li>',
'before_title' => '<h6>',
'after_title' => '</h6>',
));
register_sidebar(array('name'=>'Sidebar Right',
'before_widget' => '<li id="%1$s" class="widget %2$s">',
'after_widget' => '</li>',
'before_title' => '<h6>',
'after_title' => '</h6>',
));
}
////////////////////////////////////////////////////////////////////////////////
// Custom Recent Comments With Gravatar Widget
////////////////////////////////////////////////////////////////////////////////
function widget_mytheme_myrecentcoms() { ?>
<li class="widget_recentcomments_gravatar">
  <h6>
    <?php _e('Recent Comments'); ?>
  </h6>
  <ul>
    <?php if(function_exists("get_avatar_recent_comment")) : ?>
    <?php get_avatar_recent_comment(); ?>
    <?php else : ?>
    <?php mw_recent_comments(10, false, 55, 35, 35, 'all', '<li><a href="%permalink%" title="%title%">%author_name%</a>&nbsp;in&nbsp;%title%</li>','d.m.y, H:i'); ?>
    <?php endif; ?>
  </ul>
</li>
<?php }
if ( function_exists('register_sidebar_widget') )
register_sidebar_widget(__('Recent Comments(Gravatar)'), 'widget_mytheme_myrecentcoms');
////////////////////////////////////////////////////////////////////////////////
// Custom Hot Topics Widget
////////////////////////////////////////////////////////////////////////////////
function widget_mytheme_myhottopic() { ?>
<?php if(function_exists("get_hottopics")) : ?>
<li class="widget_hottopics">
  <h6>
    <?php _e('Hot Topics'); ?>
  </h6>
  <ul>
    <?php get_hottopics(); ?>
  </ul>
</li>
<?php endif; ?>
<?php }
if ( function_exists('register_sidebar_widget') )
register_sidebar_widget(__('Hot Topics'), 'widget_mytheme_myhottopic');
////////////////////////////////////////////////////////////////////////////////
// Custom Featured Category Widget
////////////////////////////////////////////////////////////////////////////////
function widget_mytheme_featcat() { ?>
<?php $featured_category_active = get_theme_option('featured_category_activate'); if(($featured_category_active == '') || ($featured_category_active == 'No')) { ?>
<?php { /* nothing */ } ?>
<?php } else { ?>
<?php if(is_home()) { ?>
<?php include (TEMPLATEPATH . '/featured-category.php'); ?>
<?php } ?>
<?php } ?>
<?php }
if ( function_exists('register_sidebar_widget') )
register_sidebar_widget(__('Featured Categories'), 'widget_mytheme_featcat');
////////////////////////////////////////////////////////////////////////////////
// Custom YouTube Video Widget
////////////////////////////////////////////////////////////////////////////////
function widget_mytheme_video() { ?>
<?php $emvideo_activate = get_theme_option('emvideo_activate'); if(($emvideo_activate == '') || ($emvideo_activate == 'No')) { ?>
<?php { /* nothing */ } ?>
<?php } else { ?>
<?php include (TEMPLATEPATH . '/video.php'); ?>
<?php } ?>
<?php }
if ( function_exists('register_sidebar_widget') )
register_sidebar_widget(__('YouTube Video'), 'widget_mytheme_video');

////////////////////////////////////////////////////////////////////////////////
// Custom 125x125 Banner Widget
////////////////////////////////////////////////////////////////////////////////
function widget_mytheme_sponsors() { ?>
<?php $sponsor_activate = get_theme_option('sponsor_activate'); if(($sponsor_activate == '') || ($sponsor_activate == 'No')) { ?>
<?php { /* nothing */ } ?>
<?php } else { ?>
<?php include (TEMPLATEPATH . '/sponsor.php'); ?>
<?php } ?>
<?php }
if ( function_exists('register_sidebar_widget') )
register_sidebar_widget(__('Sponsors'), 'widget_mytheme_sponsors');
////////////////////////////////////////////////////////////////////////////////
// Theme Option
////////////////////////////////////////////////////////////////////////////////
$themename = "Bluewish";
$shortname = str_replace(' ', '_', strtolower($themename));
function get_theme_option($option)
{
global $shortname;
return stripslashes(get_option($shortname . '_' . $option));
}
function get_theme_settings($option)
{
return stripslashes(get_option($option));
}
$wp_dropdown_rd_admin = $wpdb->get_results("SELECT $wpdb->term_taxonomy.term_id,name,description,count FROM $wpdb->term_taxonomy LEFT JOIN $wpdb->terms ON $wpdb->term_taxonomy.term_id = $wpdb->terms.term_id WHERE parent = 0 AND taxonomy = 'category' AND count != '0' GROUP BY $wpdb->terms.name ORDER by $wpdb->terms.name ASC");
$wp_getcat = array();
foreach ($wp_dropdown_rd_admin as $category_list) {
$wp_getcat[$category_list->term_id] = $category_list->name;
}
$category_bulk_list = array_unshift($wp_getcat, "Choose a category:");
$number_entries = array("Number of post:","1","2","3","4","5","6","7","8","9","10");
$crop_position = array("Choose Crop Position","middle","middleleft","middleright","topcenter","topleft","topright","bottomcenter","bottomleft","bottomright");
$options = array (
array(	"name" => "Blog Header Settings",
"type" => "heading",
),
array(	"name" => "Use Custom Logo On The Blog Header?<br /><em>*Disable by default, Choose Yes to enable it.</em>",
"id" => $shortname."_header_logo_activate",
"type" => "select",
"std" => "No",
"options" => array("No", "Yes")),
array(	"name" => "Insert The Full URL Location Of Your Logo Here <br /><em>*leave blank if not use</em>",
"id" => $shortname."_logo_url",
"type" => "text",
"box" => "social",
"std" => "",
),
array(	"name" => "Insert Header Banner HTML Code (Header)
<br /><em>*Recommended Size 728 x 90</em>
<br /><em>*leave blank if not use</em>",
"id" => $shortname."_header_banner",
"type" => "textarea",
"std" => "",
),
array(	"name" => "</div></div>",
"type" => "close",
),

array(	"name" => "Featured Content Slider Settings",
"type" => "heading",
),
array(	"name" => "Enable <strong>Featured Content Slider</strong> On Homepage?<br /><em>*Disable by default, Choose Yes to enable it.</em>",
"id" => $shortname."_featured_activate",
"type" => "select",
"std" => "No",
"options" => array("No", "Yes")),
array(	"name" => "Choose Which <strong>Category IDs</strong> To Put On The Featured Slider?",
"id" => $shortname."_featured_category",
"type" => "select",
"type" => "text",
"std" => "",
),
array(	"name" => "Choose How Many <strong>Post</strong> To Show On The Featured Slider?",
"id" => $shortname."_featured_number",
"type" => "text",
"std" => "",
),
array(	"name" => "</div></div>",
"type" => "close",
),
array(	"name" => "Featured Category Settings",
"type" => "heading",
),
array(	"name" => "Enable <strong>Featured Category Showcase On Sidebar</strong>?<br /><em>*Disable by default, Choose Yes to enable it.</em>",
"id" => $shortname."_featured_category_activate",
"type" => "select",
"std" => "No",
"options" => array("No", "Yes")),
array(	"name" => "Choose Category To Feature On 1st Block?<br /><em>*Leave it as default if not use.</em>",
"id" => $shortname."_featured_category_id1",
"type" => "select",
"std" => "Choose a category:",
"options" => $wp_getcat),
array(	"name" => "Choose How Many <strong>Post</strong> To Display On 1st Block?<br /><em>*Leave it as default if not use.</em>",
"id" => $shortname."_featured_number1",
"type" => "select",
"std" => "Number of post:",
"options" => $number_entries),
array(	"name" => "Choose Category To Feature On 2nd Block?<br /><em>*Leave it as default if not use.</em>",
"id" => $shortname."_featured_category_id2",
"type" => "select",
"std" => "Choose a category:",
"options" => $wp_getcat),
array(	"name" => "Choose How Many <strong>Post</strong> To Display On 2nd Block?<br /><em>*Leave it as default if not use.</em>",
"id" => $shortname."_featured_number2",
"type" => "select",
"std" => "Number of post:",
"options" => $number_entries),
array(	"name" => "Choose Category To Feature On 3rd Block?<br /><em>*Leave it as default if not use.</em>",
"id" => $shortname."_featured_category_id3",
"type" => "select",
"std" => "Choose a category:",
"options" => $wp_getcat),
array(	"name" => "Choose How Many <strong>Post</strong> To Display On 3rd Block?<br /><em>*Leave it as default if not use.</em>",
"id" => $shortname."_featured_number3",
"type" => "select",
"std" => "Number of post:",
"options" => $number_entries),
array(	"name" => "</div></div>",
"type" => "close",
),
array(	"name" => "Google Adsense & Analytics Settings",
"type" => "heading",
),
array(	"name" => "Enable Google Adsense Loops Within Posts<br /><em>*default are disable, you can activate it by choosing enable</em>",
"id" => $shortname."_adsense_loop_activate",
"type" => "select",
"std" => "Disable",
"options" => array("Disable", "Enable")),
array(	"name" => "Insert Google Adsense Code For Loops Here<br />
<em>*Copy &amp; Paste Your Google Code Or CPA Network Banner Code Here</em>",
"id" => $shortname."_adsense_loop",
"type" => "textarea",
"std" => "",
),
array(	"name" => "Enable Google Adsense On Single Page<br /><em>*default are disable, you can activate it by choosing enable</em>",
"id" => $shortname."_adsense_single_activate",
"type" => "select",
"std" => "Disable",
"options" => array("Disable", "Enable")),
array(	"name" => "Insert Google Adsense Code For Single Page Here<br /><em>*Copy &amp; Paste Your Google Code Or CPA Network Banner Code Here</em>",
"id" => $shortname."_adsense_single",
"type" => "textarea",
"std" => "",
),
array(	"name" => "Insert Google Analytics code <br /><em>*optional - leave it blank if not using</em>",
"id" => $shortname."_google_analytics",
"type" => "textarea",
"std" => "",
),
array(	"name" => "</div></div>",
"type" => "close",
),
array( 	"name" => "YouTube Video Settings",
"type" => "heading",
),
array(	"name" => "Enable <strong>YouTube Video</strong> On Sidebar?<br /><em>*Disable by default, Choose Yes to enable it.</em>",
"id" => $shortname."_emvideo_activate",
"type" => "select",
"std" => "No",
"options" => array("No", "Yes")),
array(	"name" => "Insert YouTube Video Unique Code<br /><em>*You can find videos to embed on <a href=\"http://www.youtube.com\" target=\"_blank\">YouTube</a> site.</em><br /><em>i.e. Youtube - http://www.youtube.com/watch?v=<span class=\"redbold\">Hr0Wv5DJhuk</span></em><br /><em>*Only Insert The Red Bolded Code Inside Below Setting Box.</em>",
"id" => $shortname."_emvideo",
"std" => "",
"type" => "text"),
array(	"name" => "</div></div>",
"type" => "close",
),




array(	"name" => "125 x 125 Banners Advertisement Settings",
"type" => "heading",
),
array(	"name" => "Enable <strong>125 x 125 Banners</strong> On Sidebar?<br /><em>*Disable by default, Choose Yes to enable it.</em>",
"id" => $shortname."_sponsor_activate",
"type" => "select",
"std" => "No",
"options" => array("No", "Yes")),
array(	"name" => "Insert Sponsor Banner One HTML Code<br /><em>*leave blank if not use</em>",
"id" => $shortname."_sponsor_banner_one",
"type" => "textarea",
"std" => "",
),
array(	"name" => "Insert Sponsor Banner Two HTML Code<br /><em>*leave blank if not use</em>",
"id" => $shortname."_sponsor_banner_two",
"type" => "textarea",
"std" => "",
),
array(	"name" => "Insert Sponsor Banner Three HTML Code<br /><em>*leave blank if not use</em>",
"id" => $shortname."_sponsor_banner_three",
"type" => "textarea",
"std" => "",
),
array(	"name" => "Insert Sponsor Banner Four HTML Code<br /><em>*leave blank if not use</em>",
"id" => $shortname."_sponsor_banner_four",
"type" => "textarea",
"std" => "",
),
array(	"name" => "Insert Sponsor Banner Five HTML Code<br /><em>*leave blank if not use</em>",
"id" => $shortname."_sponsor_banner_five",
"type" => "textarea",
"std" => "",
),
array(	"name" => "Insert Sponsor Banner Six HTML Code<br /><em>*leave blank if not use</em>",
"id" => $shortname."_sponsor_banner_six",
"type" => "textarea",
"std" => "",
),
array(	"name" => "</div></div>",
"type" => "close",
),
);
function mytheme_admin_panel(){
echo "<div id=\"admin-options\"> ";
global $themename, $shortname, $options;
if ( $_REQUEST['saved'] ) echo '<div id="update-option" class="updated fade"><strong>'.$themename.' settings saved.</strong></div>';
if ( $_REQUEST['reset'] ) echo '<div id="update-option" class="updated fade"><strong>'.$themename.' settings reset.</strong></div>';
?>
<h4>
  <?php echo "$themename"; ?> Theme Options
</h4>
<form action="" method="post">
  <?php foreach ($options as $value) { ?>
  <?php switch ( $value['type'] ) { case 'heading': ?>
  <div class="get-option">
    <h2>
      <?php echo $value['name']; ?>
    </h2>
    <div class="option-save">
      <?php
break;
case 'text':
?>
      <div class="description">
        <?php echo $value['name']; ?>
      </div>
      <p>
        <input name="<?php echo $value['id']; ?>" class="myfield" id="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" value="<?php if (
                                                                                                                                               get_settings( $value['id'] ) != "") { echo get_settings( $value['id'] ); } else { echo $value['std']; } ?>" />
      </p>
      <?php
break;
case 'select':
?>
      <div class="description">
        <?php echo $value['name']; ?>
      </div>
      <p>
        <select name="<?php echo $value['id']; ?>" class="myselect" id="<?php echo $value['id']; ?>">
          <?php foreach ($value['options'] as $option) { ?>
          <option
                  <?php if ( get_settings( $value['id'] ) == $option) { echo ' selected="selected"'; } elseif ($option == $value['std']) { echo ' selected="selected"'; } ?>>
          <?php echo $option; ?>
          </option>
        <?php } ?>
      </select>
    </p>
  <?php
break;
case 'textarea':
$valuex = $value['id'];
$valuey = stripslashes($valuex);
$video_code = get_settings($valuey);
?>
  <div class="description">
    <?php echo $value['name']; ?>
  </div>
  <p>
    <textarea name="<?php echo $valuey; ?>" class="mytext" cols="40%" rows="8" />
    <?php if ( get_settings($valuey) != "") { echo stripslashes($video_code); }
else { echo $value['std']; } ?>
  </textarea>
</p>
<?php
break;
case 'close':
?>
<div class="clearfix">
</div>
</div>
<!-- OPTION SAVE END -->
<div class="clearfix">
</div>
</div>
<!-- GET OPTION END -->
<?php
break;
default;
?>
<?php
break; } ?>
<?php } ?>
<p class="save-p">
  <input name="save" type="submit" class="sbutton" value="Save Options" />
  <input type="hidden" name="action" value="save" />
</p>
</form>
<form method="post">
  <p class="save-p">
    <input name="reset" type="submit" class="sbutton" value="Reset Options" />
    <input type="hidden" name="action" value="reset" />
  </p>
</form>
</div>
<!-- ADMIN OPTIONS END -->
<?php }
function mytheme_admin_register() {
global $themename, $shortname, $options;
if ( $_GET['page'] == basename(__FILE__) ) {
if ( 'save' == $_REQUEST['action'] ) {
foreach ($options as $value) {
update_option( $value['id'], $_REQUEST[ $value['id'] ] ); }
foreach ($options as $value) {
if( isset( $_REQUEST[ $value['id'] ] ) ) { update_option( $value['id'], $_REQUEST[ $value['id'] ]  ); } else { delete_option( $value['id'] ); } }
header("Location: themes.php?page=functions.php&saved=true");
die;
} else if( 'reset' == $_REQUEST['action'] ) {
foreach ($options as $value) {
delete_option( $value['id'] ); }
header("Location: themes.php?page=functions.php&reset=true");
die;
}
}
add_theme_page($themename." Options", "Theme Options", 'edit_themes', basename(__FILE__), 'mytheme_admin_panel');
}
function mytheme_admin_head() { ?>
<link href="<?php bloginfo('template_directory'); ?>/css/admin-panel.css" rel="stylesheet" type="text/css" />
<?php }
add_action('admin_head', 'mytheme_admin_head');
add_action('admin_menu', 'mytheme_admin_register');
?>