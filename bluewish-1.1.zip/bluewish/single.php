<?php get_header(); ?>

<div id="content">

<div id="post-entry">

<?php $postcounter = 1; if (have_posts()) : ?>

<?php while (have_posts()) : $postcounter = $postcounter + 1; the_post(); $do_not_duplicate = $post->ID; $the_post_ids = get_the_ID(); ?>

<div class="post-meta" id="post-<?php the_ID(); ?>">
<div class="post-info">
<h1><?php the_title(); ?></h1>
<div class="post-date">
Posted By <?php the_author_posts_link(); ?> On <?php the_time('F jS Y') ?>. Under&nbsp;<?php the_category(', ') ?>&nbsp;&nbsp;<?php if(function_exists("the_tags")) : ?><?php the_tags('Tags:&nbsp;') ?><?php endif; ?>&nbsp;&nbsp;<?php edit_post_link('Edit Post'); ?>.
</div><!-- POST DATE END -->
</div><!-- POST INFO END -->

<?php $get_google_activate = get_theme_option('adsense_single_activate'); if(($get_google_activate == '') || ($get_google_activate == 'Disable')) { ?>
<?php } else { ?>
<?php $get_google_code = get_theme_option('adsense_single'); if($get_google_code == '') { ?>
<?php } else { ?>
<div class="adsense-single">
<?php echo stripcslashes($get_google_code); ?>
</div>
<?php } ?>
<?php } ?>

<div class="post-content">

<?php the_content(); ?>
<?php wp_link_pages('before=<div id="page-links">&after=</div>'); ?>

</div><!-- POST CONTENT END -->

<?php $get_google_activate = get_theme_option('adsense_single_activate'); if(($get_google_activate == '') || ($get_google_activate == 'Disable')) { ?>
<?php } else { ?>
<?php $get_google_code = get_theme_option('adsense_single'); if($get_google_code == '') { ?>
<?php } else { ?>
<div class="adsense-single">
<?php echo stripcslashes($get_google_code); ?>
</div>
<?php } ?>
<?php } ?>

<div class="clearfix"></div>
</div><!-- POST META <?php the_ID(); ?> END -->

<?php endwhile; ?>

<?php comments_template( '', true ); ?>

<?php else : ?>

<p class="center">NOT FOUND</p>

<p class="center">Sorry, but you are looking for something that isn't here.</p>

<?php endif; ?>

</div><!-- POST ENTRY END -->

<?php include (TEMPLATEPATH . '/paginate.php'); ?>

</div><!-- CONTENT END -->

<?php get_sidebar(); ?>

<?php get_footer(); ?>