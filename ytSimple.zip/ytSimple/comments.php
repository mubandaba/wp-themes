<?php
    if (!empty($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
        die ('请不要使用別的途径查看本档案，谢谢。');
 
    if ( post_password_required() ) { ?>
        <p class="nocomments">本文需要密码才能查看，请输入密码。</p>
    <?php
        return;
    }
?>

<?php if ( have_comments() ) : ?>
<h3 id="res_title"><?php comments_number('沒有评论', '评论 (1)', '评论 (%)' );?> </h3>
<ol class="commentlist">
    <?php wp_list_comments('type=comment&callback=mytheme_comment'); ?>
</ol>
<div class="clear"></div>
<div class="comment-navigation">
    <div class="older"><?php previous_comments_link() ?></div>
    <div class="newer"><?php next_comments_link() ?></div>
</div>
<?php else :  ?>
<?php if ( comments_open() ) : ?>
 <?php else : ?>
    <p class="nocomments">本文不开放评论。</p>
<?php endif; ?>
<?php endif; ?>

<?php if ( comments_open() ) : ?>
<div id="respond">

<h3 id="res_title"><?php comment_form_title( '留下评论', '回应给  %s' ); ?></h3>

<div class="cancel-comment-reply">
    <?php cancel_comment_reply_link(); ?>
</div>
<?php if ( get_option('comment_registration') && !is_user_logged_in() ) : ?>
<p> 你需要先  <a href="<?php echo wp_login_url( get_permalink() ); ?>">登陆 </a> 才能留下评论 。</p>
<?php else : ?>
 
<form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform">
 
<?php if ( is_user_logged_in() ) : ?>
 
<p>登陆为 <a href="<?php echo get_option('siteurl'); ?>/wp-admin/profile.php"><?php echo $user_identity; ?></a>. <a href="<?php echo wp_logout_url(get_permalink()); ?>" title="Log out of this account">Log out &raquo;</a></p>

<?php else : ?>
 
<p>&nbsp;<label for="author"><small>您的名称<?php if ($req) echo "(必填)"; ?></small></label><br />
<input type="text" name="author" id="author" value="<?php echo esc_attr($comment_author); ?>" size="22" tabindex="1" <?php if ($req) echo "aria-required='true'"; ?> />
</p>
 
<p>&nbsp;<label for="email"><small>邮箱地址<?php if ($req) echo "(必填)"; ?></small></label><br />
<input type="text" name="email" id="email" value="<?php echo esc_attr($comment_author_email); ?>" size="22" tabindex="2" <?php if ($req) echo "aria-required='true'"; ?> /></p>
 
<p>&nbsp;<label for="url"><small>网站</small></label><br />
<input type="text" name="url" id="url" value="<?php echo esc_attr($comment_author_url); ?>" size="22" tabindex="3" /></p>
 
<?php endif; ?>


 
<p><textarea name="comment" id="comment" cols="60%" rows="10" tabindex="4" onkeydown="if(event.ctrlKey&&event.keyCode==13) {document.getElementById('submit').click();return false};"></textarea></p>
<p><input type="image" name="submit" id="submit" src="<?php bloginfo('template_directory'); ?>/images/submit.gif" class="send"></p>
<p>可以使用 CTRL + ENTER 光速发表回复</p>
<?php comment_id_fields(); ?>
</p>
<?php do_action('comment_form', $post->ID); ?>

</form>

<?php endif; ?>
</div>

<?php endif; ?>

