 <div class="fbg">
    <div class="fbg_resize">
      <div class="col c1">
        <h3>热评文章</h3>
        <ul>
		<?php simple_get_most_viewed(); ?>
		</ul>
      </div>
      <div class="col c2">
	   <h3>随机文章</h3>
		<ul>
		<?php $rand_posts = get_posts('numberposts=5&orderby=rand');
		foreach( $rand_posts as $post ) : ?>
		   <li>
				<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		   </li>
		<?php endforeach; ?>
		</ul>
      </div>
      <div class="col c3">
      	<?php include('includes/r_statistics.php'); ?>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="footer">
    <div class="footer_resize">
      <p class="lf">Copyright © 2012 <?php bloginfo(’name’); ?>.Theme by <a href="http://www.seogyt.com/" rel="external">SEOGYT</a>.
 <?php if (get_option('swt_beian') == 'Display') { ?><a href="http://www.miitbeian.gov.cn/" rel="nofollow" target="_blank"><?php echo stripslashes(get_option('swt_beianhao')); ?></a><?php { echo '.'; } ?><?php } else { } ?> <?php if (get_option('swt_tj') == 'Display') { ?><?php echo stripslashes(get_option('swt_tjcode')); ?><?php { echo '.'; } ?>	<?php } else { } ?></p>
      <ul class="fmenu">
        
        <?php wp_nav_menu('container_id=navmenu'); ?>
      </ul>
      <div class="clr"></div>
    </div>
  </div>
<?php include('db.php'); ?>
<div style="display: none;" id="gotop"></div>
<script type='text/javascript'>
    backTop=function (btnId){
        var btn=document.getElementById(btnId);
        var d=document.documentElement;
        var b=document.body;
        window.onscroll=set;
        btn.onclick=function (){
            btn.style.display="none";
            window.onscroll=null;
            this.timer=setInterval(function(){
                d.scrollTop-=Math.ceil((d.scrollTop+b.scrollTop)*0.1);
                b.scrollTop-=Math.ceil((d.scrollTop+b.scrollTop)*0.1);
                if((d.scrollTop+b.scrollTop)==0) clearInterval(btn.timer,window.onscroll=set);
            },10);
        };
        function set(){btn.style.display=(d.scrollTop+b.scrollTop>100)?'block':"none"}
    };
    backTop('gotop');
</script>