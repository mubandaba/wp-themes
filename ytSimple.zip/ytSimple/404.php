<?php get_header();?>

  <div class="content">
    <div class="content_resize">
      <div class="mainbar">	  	
        <div class="article">	
		  <h3>抱歉，您打开的页面未能找到。<br />您可以使用本站的搜索框搜索您想要的内容，如有不便深感抱歉！</h3>
        </div>		
      </div>
      <?php get_sidebar();?>
      <div class="clr"></div>
    </div>
  </div>

<?php get_footer();?>
<?php wp_footer(); ?>
</div>
</body>
</html>
