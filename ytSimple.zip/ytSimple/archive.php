<?php get_header();?>

  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
	  	<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
        <div class="article">	
		  <?php if(is_sticky()) : ?>
		  <div <?php post_class(); ?> class="post">
		  <h2><?php _e('[置顶]'); ?><a href="<?php the_permalink() ?>" rel="bookmark" title="详细阅读 <?php the_title_attribute(); ?>" target="_blank"><?php the_title(); ?></a></h2>
		  </div>
		  <?php else : ?>
          <h2><a href="<?php the_permalink() ?>" rel="bookmark" title="详细阅读 <?php the_title_attribute(); ?>" target="_blank"><?php the_title(); ?></a></h2>
          <div class="lm"><span class="date">Date: <?php the_date_xml()?></span> &nbsp;|&nbsp; by <?php the_author(); ?> &nbsp;|&nbsp; 分类：<?php the_category(', ') ?> &nbsp;|&nbsp; <?php comments_number('暂无评论', '1条评论', '% 评论' );?> &nbsp;|&nbsp;<?php the_tags('标签： ', ', ', ''); ?></div>
		  
          	<?php if (get_option('swt_thumbnail') == 'Display') { ?>
        	<?php if (get_option('swt_articlepic') == 'Display') { ?>
			<?php include('includes/articlepic.php'); ?>
    		<?php { echo ''; } ?>
			<?php } else { include(TEMPLATEPATH . '/includes/thumbnail.php'); } ?>
			<?php { echo ''; } ?><?php } else { } ?>
          <?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 200,"……"); ?>
          <p class="spec"><a href="<?php the_permalink() ?>" class="com"><?php if(function_exists(the_views)) { the_views(' 次', true);}?> </a> <a href="<?php the_permalink() ?>" rel="bookmark" title="详细阅读 <?php the_title_attribute(); ?>">Read more &raquo;</a></p>
		  <?php endif; ?>
        </div>
		
		<?php endwhile; ?>
		<?php endif;?>

        <!--导航-->
        
		<div id="navigation"><?php pagination($query_string); ?></div>
      </div>
      <?php get_sidebar();?>
      <div class="clr"></div>
    </div>
  </div>

<?php get_footer();?>
<?php wp_footer(); ?>
</div>
</body>
</html>
