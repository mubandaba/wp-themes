<?php get_header();?>

  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
	  	<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
        <div class="article">	
		  <?php if(is_sticky()) : ?>
		  <div <?php post_class(); ?> class="post">
		  <h2><?php _e('[置顶]'); ?><?php the_title(); ?></h2>
		  <div class="fl"> by <?php the_author(); ?> &nbsp;•&nbsp; 分类：<?php the_category(', ') ?> &nbsp;•&nbsp; <?php comments_number('暂无评论', '1条评论', '% 评论' );?> &nbsp;•&nbsp;　<?php if(function_exists('the_views')){the_views('次',true);}?>　&nbsp;•&nbsp;<?php the_tags('标签： ', ', ', ''); ?></div>
		  <div class="post"><?php the_content(); ?></div>
		  <div style="padding:0 0 8px 0">
		  版权所属：<a href="<?php bloginfo('siteurl'); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo(’name’); ?></a>，转载请注明本文链接：<a href="<?php the_permalink() ?>"><?php the_permalink() ?></a>
		  </div><br />
		  <div style="padding:0 0 8px 0"><?php previous_post_link('【上一篇】%link') ?><br/><?php next_post_link('【下一篇】%link') ?></div>
		  <div class="xgwz"><h3>您可能还会对这些文章感兴趣！</h3><?php include('xgwz.php'); ?></div>
          <div><?php comments_template(); ?></div>
		  </div>
		  
		  <?php else : ?>
          <h2><?php the_title(); ?></h2>
          <div class="fl">by <?php the_author(); ?> &nbsp;•&nbsp; 分类：<?php the_category(', ') ?> &nbsp;•&nbsp; <?php comments_number('暂无评论', '1条评论', '% 评论' );?> &nbsp;•&nbsp;　<?php if(function_exists('the_views')){the_views('次',true);}?> &nbsp;•&nbsp; <?php the_tags('标签： ', ', ', ''); ?></div>
          
          <div class="post">
		<?php if (get_option('swt_adb') == 'Display') { ?><div style="float:right;border:1px #ccc solid;padding:2px;overflow:hidden;margin:12px 0 1px 2px;"><?php echo stripslashes(get_option('swt_adbcode')); ?></div><?php { echo ''; } ?><?php } else { } ?>
	  <?php the_content(); ?></div>
		  <div style="padding:0 0 8px 0">
		  版权所属：<a href="<?php bloginfo('siteurl'); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo(’name’); ?></a>，转载请注明本文链接：<a href="<?php the_permalink() ?>"><?php the_permalink() ?></a>
		  </div><br />
		  <div style="padding:0 0 8px 0"><?php previous_post_link('【上一篇】%link') ?><br/><?php next_post_link('【下一篇】%link') ?></div>
		  <div class="xgwz"><h3>您可能还会对这些文章感兴趣！</h3><?php include('xgwz.php'); ?></div>
		  
          <div><?php comments_template(); ?></div>
		  <?php endif; ?>
        </div>
		
		<?php endwhile; ?>
		<?php endif;?>

        <!--导航-->
        
		<div id="navigation"><?php pagination($query_string); ?></div>
      </div>
      <?php get_sidebar();?>
      <div class="clr"></div>
    </div>
  </div>

<?php get_footer();?>
<?php wp_footer(); ?>
</div>
</body>
</html>