<div class="sidebar">
        <div class="searchform">
          <form id="formsearch" name="formsearch" method="get" action="<?php bloginfo('home'); ?>">		  
            <span><input type="text" class="editbox_search" value="<?php the_search_query(); ?>" name="s" id="s" title="searchfield" onFocus="clearText(this)" onBlur="clearText(this)" /></span>
            <input src="<?php bloginfo('template_directory'); ?>/images/search_btn.gif" class="button_search" type="image" value="<?php _e("Search"); ?>"/>
          </form>
        </div>
		
		<?php if (get_option('swt_ada') == 'Display') { ?>
		<div class="gadget"><?php echo stripslashes(get_option('swt_adacode')); ?></div><?php { echo ''; } ?><?php } else { } ?>
		
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>
		
		<?php endif; ?>  
		   
		<div class="gadget"><?php include('includes/r_comment.php'); ?></div>
		
</div>