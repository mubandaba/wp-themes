# WordPress主题 Clien
### 说明
咱趁着假期，多做些练习<br>
便诞生出了这个主题 Clien<br>
全站pjax，无后台设置，更改链接请自行修改header.php文件
### 展示
![](https://biantan.org/wp-content/uploads/2017/09/clien.png "我是笨蛋小扁担")
[WordPress简约主题 Clien](https://biantan.org/295.html "我是笨蛋小扁担")  <br>
[主题演示](https://biantan.org/?themedemo=Clien "主题演示")
