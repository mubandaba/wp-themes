<?php

function zib_cat_cover()
{
    $desc = trim(strip_tags(category_description()));
    if (is_super_admin() && !$desc) {
        $desc = '请在Wordress后台-文章-文章分类中添加分类描述！';
    }

    $desc .=zib_get_admin_edit('编辑此分类');

    global $wp_query;
    $cat_id = get_queried_object_id();;
    $cat = get_category($cat_id);
    $count = $cat->count;
    $title = '<i class="fa fa-folder-open em12 mr10 ml6" aria-hidden="true"></i>' . $cat->cat_name;
    $title .= '<span class="icon-spot">共' . $count . '篇</span>';
    //$title .='<pre>'. json_encode($cat) .'</pre>';
    $img = zib_get_taxonomy_img_url();
    if (_pz('page_cover_cat_s',true)) {
        zib_page_cover($title, $img, $desc);
    }else{
        echo '<div class="main-bg text-center box-body radius8 main-shadow theme-box">';
        echo '<h4 class="title-h-center">'.$title.'</h4>';
        echo '<div class="muted-2-color">'.$desc.'</div>';
        echo '</div>';
    }

}

function zib_tag_cover()
{
    $desc = trim(strip_tags(tag_description()));
    if (is_super_admin() && !$desc) {
        $desc = '请在Wordress后台-文章-文章分类中添加标签描述！';
    }

    $desc .=zib_get_admin_edit('编辑此标签');
    global $wp_query;
    $tag_id = get_queried_object_id();
    $tag = get_tag($tag_id);
    $count = $tag->count;
    $title = '<i class="fa fa-tag em12 mr10 ml6" aria-hidden="true"></i>' . $tag->name;
    $title .= '<span class="icon-spot">共' . $count . '篇</span>';
    $img = zib_get_taxonomy_img_url();
    if (_pz('page_cover_tag_s',true)) {
        zib_page_cover($title, $img, $desc);
    }else{
        echo '<div class="main-bg text-center box-body radius8 main-shadow theme-box">';
        echo '<h4 class="title-h-center">'.$title.'</h4>';
        echo '<div class="muted-2-color">'.$desc.'</div>';
        echo '</div>';
    }
}

function zib_page_cover($title, $img, $desc)
{
    $paged = (get_query_var('paged', 1));
    if ($paged && $paged > 1) {
        $title .= ' <small class="icon-spot">第' . $paged . '页</small>';
    }

    $img = $img ? $img : _pz('page_cover_img', get_stylesheet_directory_uri() . '/img/user_t.jpg');
?>
    <div class="page-cover theme-box radius8 main-shadow">
        <img class="fit-cover" data-src="<?php echo $img; ?>">
        <div class="list-inline box-body page-cover-con">
            <div class="title-h-left">
                <b><?php echo $title; ?></b>
            </div>
            <div class="em09 page-desc"><?php echo $desc; ?></div>
        </div>
    </div>
<?php }

function zib_option_cat()
{
    $all_cat = zib_get_all_cat_link('ajax-next text-ellipsis');
    $all_tag = zib_get_all_tags_link('ajax-next text-ellipsis');
    $op_cat = zib_get_option_cat_link('ajax-next text-ellipsis');
    $op_tag = zib_get_option_tags_link('ajax-next text-ellipsis');
    if (is_super_admin()) {
        $op_cat = $op_cat ? $op_cat : '<span style="color:#f73636;">（！列表为空）请在后台-主题设置-分类、标签页：勾选"分类菜单列表"</sapn>';
        $op_tag = $op_tag ? $op_tag : '<span style="color:#f73636;">（！列表为空）请在后台-主题设置-分类、标签页：勾选"分类菜单列表"</sapn>';
    }
?>
    <div class="ajax-option">
        <div class="option-dropdown splitters-this-r">分类
        <?php if(_pz('option_list_alllist_s')){
            ?>
            <i class="fa fa-fw fa-sort ml6" aria-hidden="true"></i>
            <div class="option-dropdown-items main-shadow radius8 main-bg scroll-y mini-scrollbar">
                <?php echo $all_cat; ?>
            </div>
        <?php } ?>
        </div>
        <ul class="list-inline scroll-x mini-scrollbar option-items">
            <?php echo $op_cat; ?>
        </ul>

        <div class="option-dropdown splitters-this-r">标签
        <?php if(_pz('option_list_alllist_s')){ ?>
            <i class="fa fa-fw fa-sort ml6" aria-hidden="true"></i>
            <div class="option-dropdown-items main-shadow radius8 main-bg scroll-y mini-scrollbar">
                <?php echo $all_tag; ?>
            </div>
            <?php } ?>
        </div>
        <ul class="list-inline scroll-x mini-scrollbar option-items">
            <?php echo $op_tag; ?>
        </ul>

    </div>
    <div></div>
<?php }

function zib_get_option_cat_link($link_class = '', $before = '', $after = '', $shou_count = false)
{

    $cats = _pz('option_list_cats');
    $links = '';

    if ($cats) {
        foreach ($cats as $key => $value) {
            if ($value) {
                $cat = get_category($key);
                $links .= $before . '<a ajax-replace="true" class="' . $link_class . '" title="查看更多分类文章" href="' . get_category_link($cat->cat_ID) . '">' . $cat->cat_name . ($shou_count ? ' ' . $cat->count : '') . '</a>' . $after;
            }
        }
    }
    return $links;
}

function zib_get_all_cat_link($link_class = '', $before = '', $after = '', $shou_count = false)
{
    $cats = get_categories();
    $links = '';
    if (!empty($cats[0])) {
        foreach ($cats as $cat) {
            $links .= $before . '<a ajax-replace="true" class="' . $link_class . '" title="查看此分类更多文章" href="' . get_category_link($cat->cat_ID) . '">' . $cat->cat_name . ($shou_count ? ' ' . $cat->count : '') . '</a>' . $after;
        }
    }
    return $links;
}
function zib_get_option_tags_link($link_class = '', $before = '', $after = '', $shou_count = false)
{

    $tags_id = _pz('option_list_tags');
    $links = '';
    $tags = array();
    if ($tags_id) {
        foreach ($tags_id as $key => $value) {
            if ($value) {
                $tags[] = get_tag($key);
            }
        }
    }
    return zib_get_tags($tags, $link_class, $before, $after, 0, true);
}
function zib_get_all_tags_link($link_class = '', $before = '', $after = '', $shou_count = false)
{
    $tags = get_tags();
    $links = '';

    // return $links ;
    return zib_get_tags($tags, $link_class, $before, $after, 0, true);
}
