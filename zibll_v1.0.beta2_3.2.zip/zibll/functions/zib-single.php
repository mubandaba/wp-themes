<?php

function zib_breadcrumbs()
{
    if (!is_single()) return false;
    $categorys = get_the_category();
    if ($categorys) {
        $category = $categorys[0];
        $lin =  '<ul class="breadcrumb">
		<li><a href="' . get_bloginfo('url') . '"><i class="fa fa-map-marker"></i> ' . get_bloginfo('name') . '</a></li><li>
		' . get_category_parents($category->term_id, true, ' </li><li> ') . (!_pz('breadcrumbs_single_text') ? get_the_title() : '正文') . '</li></ul>';
        return $lin;
    } else {
        return false;
    }
}

function zib_single_header()
{
    $user_id = get_the_author_meta('ID');
    $user_img = zib_get_data_avatar($user_id);
    $title = get_the_title() . get_the_subtitle();
    $author = get_the_author();
    $time_up = zib_get_time_ago(get_the_modified_time('U'));
    $time = zib_get_time_ago(get_the_time('U'));
    $category = get_the_category();
    $posts_meta = zib_get_posts_meta();
    if (!empty($category[0])) {
        $category = '<span class="icon-circle">' . $category[0]->cat_name . '</span>';
    }
    if ((get_the_modified_time('Y') * 365 + get_the_modified_time('z')) > (get_the_time('Y') * 365 + get_the_time('z'))) {
        $time_html = '<span data-toggle="tooltip" data-placement="bottom" title="' . get_the_time('Y年m月d日 H:i') . '发布" class="article-avatar">' . $time_up . '更新</span>';
    } else {
        $time_html = '<span data-toggle="tooltip" data-placement="bottom" title="' . get_the_time('Y年m月d日 H:i') . '发布" class="article-avatar">' . $time . '发布</span>';
    }

?>
    <div class="article-header theme-box clearfix">
        <div class="article-title em12">
            <a href="<?php the_permalink() ?>"><?php echo $title; ?></a>
            <span class="smail"><?php zib_get_admin_edit('编辑此文章','posts'); ?></span>
        </div>
        <div class="article-avatar">
            <ul class="list-inline">
                <li>
                    <div class="avatar-img"><?php echo $user_img; ?></div>
                </li>
                <li>
                    <dl>
                        <dt class="avatar-name"> <a href="<?php echo get_author_posts_url($user_id); ?>">
                                <?php echo $author; ?>
                            </a></dt>
                        <dd class="meta-time em09 muted-2-color"><?php echo $time_html; ?></dd>
                    </dl>
                </li>
                <li class="avatar-button">
                    <?php echo zib_get_user_follow('btn ml6 but c-red', $user_id); ?>
                    <?php echo zib_get_rewards_button($user_id); ?>
                </li>
            </ul>
            <div class="relative">
                <i class="line-form-line"></i>
               <div class="article-meta abs-right muted-color radius">
                    <?php echo $posts_meta; ?>
                </div>
            </div>
        </div>
    </div>
<? }

function zib_is_show_posts_nav()
{
    global $post;
    $show_nav = get_post_meta($post->ID, "no_article-navs", true);
    if (_pz('article_nav') && !($show_nav)) {
        return true;
    }
    return false;
}

function zib_single_content()
{
    global $post;
    $show_nav = zib_is_show_posts_nav();
    $is_max_height = get_post_meta($post->ID, "article_maxheight_xz", true);
    $max_height_style = '';
    $max_height_class = '';
    $show_nav_data = '';
    if ($show_nav) {
        $show_nav_data .= 'data-nav="posts"';
    }
    if (_pz('article_maxheight_kg') || $is_max_height) {
        $max_height_class .= ' limit-height';
        $max_height_style = ' style="max-height:' . (_pz('article_maxheight') + 80) . 'px;" data-maxheight="' . _pz('article_maxheight') . '"';
    }
?>
    <div class="article-content<?php echo $max_height_class; ?>" <?php echo $max_height_style; ?>>
        <?php zib_single_content_header(); ?>
        <div <?php echo $show_nav_data; ?>class="theme-box wp-posts-content">
            <?php 
            echo _pz('post_front_content');
            the_content();
            echo _pz('post_after_content');
            ?>
            <?php tb_xzh_render_tail(); ?>
        </div>
        <?php zib_single_content_footer(); ?>
    </div>

<? }

function zib_single_content_header()
{
    if (_pz('yiyan_single_content_header')) {
        zib_yiyan('article-yiyan theme-box text-center radius8 main-shadow yiyan-box');
    }
}


function zib_single_content_footer()
{$user_id = get_the_author_meta('ID');
    $cat = zib_get_cat_tags('but ml6 radius', '<i class="fa fa-folder-open-o" aria-hidden="true"></i>');
    $tags = zib_get_posts_tags('but ml6 radius', '# ');


    $like_button = zib_get_post_like($class = 'action action-like');
    $favorite_button = zib_get_post_favorite($class = 'action action-favorite');

    $rewards_button = zib_get_rewards_button($user_id,'action action-rewards');
    $share_button = '<a href="javascript:;" id="posts-share-01" data-trigger="hover" data-container="#posts-share-01" data-placement="top" data-toggle="html-popover" data-target=".share-popover" class="action action-share">
    ' . zib_svg('share') . '<text>分享</text></a>';

    $share_button .= '<div class="hide share-popover"><div class="share-button">' . zib_get_share() . '</div></div>';

    if ( _pz('yiyan_single_content_footer')) {
        zib_yiyan('article-yiyan theme-box text-center radius8 main-shadow yiyan-box');
    }

    if (_pz('post_copyright_s')) {
        echo '<div class="em09 muted-3-color"><div><span>©</span> 版权声明</div><div class="posts-copyright">' . _pz('post_copyright') . '</div></div>';
    }

    echo '<div class="text-center theme-box muted-3-color box-body separator em09">THE END</div>';
    if ($cat || $tags) {
        echo '<div class="theme-box article-tags">' . $cat . '<br>' . $tags . '</div>';
    }

    echo '<div class="text-center muted-3-color box-body em09">' . _pz('post_button_toptext', '喜欢就支持以下吧') . '</div>';
    echo '<div class="text-center post-actions">';
    if (_pz('post_like_s')) {
        echo $like_button;
    }
    if (_pz('post_rewards_s')) {
        echo $rewards_button;
    }
    if (_pz('share_s')) {
        echo $share_button;
    }

    echo $favorite_button;
    echo '</div>';
}
