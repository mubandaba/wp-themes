<?php

function zib_is_update()
{
	$latest = 0;
	$theme_data = wp_get_theme();
	return ($latest && version_compare($theme_data['Version'],$latest) == -1) ? true : false;
}
