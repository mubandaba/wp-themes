== Description ==
Zomer is a clean, light and elegant theme with a balanced design which will give your readers an immersive reading experience. Beautifully crafted and specifically designed to help you create a stunning magazine or personal blog.

Zomer WordPress Theme, Copyright 2017 Taras Dashkevych.
Zomer is distributed under the terms of the GNU GPL.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Credits ==

* Based on Underscores http://underscores.me/, (C) 2012-2016 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)

* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2016 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)
 
* JavaScript Plugin: bigSlide.js ( by Adam D. Scott: http://ascott1.github.io/bigSlide.js/ ) - Licensed under the MIT license

* This theme uses Bootstrap Grid - Licensed under the MIT : https://github.com/twbs/bootstrap/blob/master/LICENSE

* Font: Noto Serif by Google - Apache License, Version 2.0

* Font: Noto Sans by Google - Apache License, Version 2.0
 
* All images that are used on the screenshot are licensed under the License CC0 Public Domain : https://creativecommons.org/publicdomain/zero/1.0/
 - https://unsplash.com/photos/uSdtHAt7E1Q
 - https://unsplash.com/photos/cWhLlFB2IGI
 - https://unsplash.com/photos/y7rGTFyOzxc
 - https://unsplash.com/photos/8jqna7aA-vs
 - https://unsplash.com/photos/j1V42MKpJ2k
 - https://unsplash.com/photos/eQQDRilCZEM