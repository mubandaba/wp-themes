<?php
/**
 * Template part for displaying page content in single.php.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Zomer
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	
	<div class="entry-content">
        <?php the_content(); ?>
	</div><!-- .entry-content -->
	
	<footer class="entry-footer">        
    <?php 
        zomer_entry_footer(); 
        zomer_author_bio();
    ?>		
	</footer><!-- .entry-footer -->
</article><!-- #post-## -->
