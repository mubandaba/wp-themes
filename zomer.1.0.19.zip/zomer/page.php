<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Zomer
 */

get_header(); ?>

<div class="container">
	
	<?php while ( have_posts() ) : the_post(); ?>
	   
		<?php get_template_part( 'template-parts/single/page', 'header' ); ?>
	
	<div id="primary" class="content-area row">
		<main id="main" class="site-main <?php echo esc_attr( zomer_get_blog_primary_class() ); ?>" role="main">

			<?php
				get_template_part( 'template-parts/content', 'page' );

				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif;
			?>
			
	<?php endwhile; ?>
			
		</main><!-- #main -->
		
		<?php if ( ! zomer_is_hidden_sidebar() ) : ?>
		<div class="col-lg-4 col-md-4 sidebar-section">
			<?php get_sidebar(); ?>
		</div><!-- .sidebar-section -->
		<?php endif; ?>
		
	</div><!-- #primary -->
</div><!-- .container -->

<?php
get_footer();
