<?php

//decode by http://www.yunlu99.com/
/**
 * Main Functions of Ucenter & Market WordPress 
**/
/* Including functions */
require_once 'affiliate.php';
require_once 'follow.php';
require_once 'membership.php';
require_once 'shop.php';
require_once 'credit.php';
require_once 'message.php';
require_once 'mail.php';
require_once 'meta-box.php';
require_once 'open-social.php';
require_once 'extension.php';
/* Add JS and CSS */
function um_add_scripts()
{
	//$um_js = get_stylesheet_directory_uri(). '/js/ucenter.js';
	//wp_enqueue_script( 'um', $um_js, 'jquery', '', true );
	if (is_author()) {
		wp_enqueue_script('media-upload');
		wp_enqueue_script('thickbox');
		wp_enqueue_style('thickbox');
		wp_enqueue_script('my-upload');
	}
	?>
	<script type="text/javascript">
		var um = <?php 
	echo um_script_parameter();
	?>;
	</script>
	<?php 
}
add_action('wp_enqueue_scripts', 'um_add_scripts');
/* number of author's posts  */
function num_of_author_posts($authorID = '')
{
	//根据作者ID获取该作者的文章数量
	if ($authorID) {
		$author_query = new WP_Query('posts_per_page=-1&author=' . $authorID);
		$i = 0;
		while ($author_query->have_posts()) {
			$author_query->the_post();
			++$i;
		}
		wp_reset_postdata();
		return $i;
	}
	return false;
}
/* Remove open sans */
function um_remove_open_sans()
{
	wp_deregister_style('open-sans');
	wp_register_style('open-sans', false);
	wp_enqueue_style('open-sans', '');
}
add_action('init', 'um_remove_open_sans');
/* Add avatar upload folder */
function um_add_avatar_folder()
{
	$upload = wp_upload_dir();
	$upload_dir = $upload['basedir'];
	$upload_dir = $upload_dir . '/avatars';
	if (!is_dir($upload_dir)) {
		mkdir($upload_dir, 0755);
	}
}
add_action('init', 'um_add_avatar_folder');
/* Register shop menu */
function um_register_menu()
{
	register_nav_menus(array('shopcatbar' => '商城分类导航'));
}
add_action('init', 'um_register_menu');
/* Get current page url */
function um_get_current_page_url()
{
	global $wp;
	$redirect = isset($_GET['redirect_to']) ? $_GET['redirect_to'] : '';
	if ($redirect) {
		return $redirect;
	} else {
		return get_option('permalink_structure') == '' ? add_query_arg($wp->query_string, '', home_url($wp->request)) : home_url(add_query_arg(array(), $wp->request));
	}
}
/* 获取当前页面url
/* ---------------- */
function _get_current_page_url()
{
	$ssl = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on' ? true : false;
	$sp = strtolower($_SERVER['SERVER_PROTOCOL']);
	$protocol = substr($sp, 0, strpos($sp, '/')) . ($ssl ? 's' : '');
	$port = $_SERVER['SERVER_PORT'];
	$port = !$ssl && $port == '80' || $ssl && $port == '443' ? '' : ':' . $port;
	$host = isset($_SERVER['HTTP_X_FORWARDED_HOST']) ? $_SERVER['HTTP_X_FORWARDED_HOST'] : isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : $_SERVER['SERVER_NAME'];
	return $protocol . '://' . $host . $port . $_SERVER['REQUEST_URI'];
}
/* JS parameters */
function um_script_parameter()
{
	$object = array();
	$object['ajax_url'] = admin_url('admin-ajax.php');
	$object['admin_url'] = admin_url();
	$object['wp_url'] = get_bloginfo('url');
	$object['um_url'] = get_stylesheet_directory_uri();
	$object['uid'] = (int) get_current_user_id();
	$object['is_admin'] = current_user_can('edit_users') ? 1 : 0;
	$object['redirecturl'] = _get_current_page_url();
	// um_get_current_page_url();
	$object['loadingmessage'] = '正在请求中，请稍等...';
	$object['paged'] = get_query_var('paged') ? (int) get_query_var('paged') : 1;
	$object['cpage'] = get_query_var('cpage') ? (int) get_query_var('cpage') : 1;
	if (is_single()) {
		global $post;
		$object['pid'] = $post->ID;
	}
	$object['timthumb'] = get_stylesheet_directory_uri() . '/func/timthumb.php?src=';
	$object_json = json_encode($object);
	return $object_json;
}
/* AJAX login */
function um_ajax_login()
{
	$result = array('loggedin' => 0, 'message' => '');
	if (isset($_POST['security']) && wp_verify_nonce($_POST['security'], 'security_nonce')) {
		$user_name = sanitize_user($_POST['username']);
		$user_password = $_POST['password'];
		$secure_cookie = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on' ? true : false;
		$creds = array();
		$creds['user_login'] = $user_name;
		$creds['user_password'] = $user_password;
		$creds['remember'] = isset($_POST['remember']) ? $_POST['remember'] : false;
		$login = wp_signon($creds, $secure_cookie);
		if (!is_wp_error($login)) {
			$result['loggedin'] = 1;
			$result['message'] = '登录成功！即将为你刷新';
		} else {
			$result['message'] = $login->errors ? strip_tags($login->get_error_message()) : '<strong>ERROR</strong>: ' . esc_html__('请输入正确用户名和密码以登录', 'um');
		}
	} else {
		$result['message'] = __('安全认证失败，请重试！', 'um');
	}
	header('content-type: application/json; charset=utf-8');
	echo json_encode($result);
	exit;
}
add_action('wp_ajax_ajax_login', 'um_ajax_login');
add_action('wp_ajax_nopriv_ajax_login', 'um_ajax_login');
/* AJAX register */
function um_ajax_register()
{
	$result = array();
	if (isset($_POST['security']) && wp_verify_nonce($_POST['security'], 'user_security_nonce')) {
		$user_login = sanitize_user($_POST['username']);
		$user_pass = $_POST['password'];
		$user_email = apply_filters('user_registration_email', $_POST['email']);
		$captcha = strtolower(trim($_POST['um_captcha']));
		session_start();
		$session_captcha = strtolower($_SESSION['um_captcha']);
		$errors = new WP_Error();
		if (!validate_username($user_login)) {
			$errors->add('invalid_username', __('请输入一个有效用户名', 'um'));
		} elseif (username_exists($user_login)) {
			$errors->add('username_exists', __('此用户名已被注册', 'um'));
		} elseif (email_exists($user_email)) {
			$errors->add('email_exists', __('此邮箱已被注册', 'um'));
		}
		do_action('register_post', $user_login, $user_email, $errors);
		$errors = apply_filters('registration_errors', $errors, $user_login, $user_email);
		if ($errors->get_error_code()) {
			$result['success'] = 0;
			$result['message'] = $errors->get_error_message();
		} else {
			if (_hui(_email_oauth)) {
				$link = _generate_registration_activation_link($user_login, $user_email, $user_pass);
				if ($link) {
					$message = '<h2 style="color: #333;font-size: 30px;font-weight: 400;line-height: 34px;margin-top: 0;text-align: center;">欢迎, ' . $user_login . '</h2>' . '<p style="color: #444;font-size: 17px;line-height: 24px;margin-bottom: 0;text-align: center;">要完成注册, 请点击下面的激活按钮确认你的账户</p>' . '<div id="cta" style="border: 1px solid #e14329; border-radius: 3px; display: block; margin: 20px auto; padding: 12px 24px;max-width: 120px;text-align: center;">' . '<a href="' . $link . '" style="color: #e14329; display: inline-block; text-decoration: none" target="_blank">确认账户</a></div>';
					if (um_basic_mail('', $user_email, '你的账户激活链接', $message, '你的账户激活链接')) {
						$result['success'] = 1;
						$result['message'] = __('注册成功，请前往邮箱激活！', 'um');
					} else {
						$result['success'] = 0;
						$result['message'] = __('邮件发送失败，请联系管理员！', 'um');
					}
				} else {
					$result['success'] = 0;
					$result['message'] = __('注册失败，请重试或联系管理员！', 'um');
				}
			} else {
				$user_id = wp_create_user($user_login, $user_pass, $user_email);
				if (!$user_id) {
					$errors->add('registerfail', sprintf(__('无法注册，请联系管理员', 'um'), get_option('admin_email')));
					$result['success'] = 0;
					$result['message'] = $errors->get_error_message();
				} else {
					update_user_option($user_id, 'default_password_nag', true, true);
					wp_new_user_notification($user_id, $user_pass);
					$result['success'] = 1;
					$result['message'] = __('注册成功，正在自动登录！', 'um');
					//auto login in
					wp_set_current_user($user_id);
					wp_set_auth_cookie($user_id);
					$result['loggedin'] = 1;
				}
			}
		}
	} else {
		$result['message'] = __('安全认证失败，请重试！', 'um');
	}
	header('content-type: application/json; charset=utf-8');
	echo json_encode($result);
	exit;
}
add_action('wp_ajax_ajax_register', 'um_ajax_register');
add_action('wp_ajax_nopriv_ajax_register', 'um_ajax_register');
/* 账号封禁 */
function handle_banned_user()
{
	if ($user_id = get_current_user_id()) {
		if (current_user_can('administrator')) {
			return;
		}
		$ban_status = get_user_meta($user_id, 'um_banned', true);
		if ($ban_status) {
			wp_die(sprintf(__('你的账户已被封禁, 理由为: %s ', 'um'), get_user_meta($user_id, 'um_banned_reason', true)), __('账户冻结', 'um'), 404);
			//TODO add banned time
		}
	}
}
add_action('template_redirect', 'handle_banned_user');
add_action('admin_menu', 'handle_banned_user');
/*  获取用户账户状态 */
function get_account_status($user_id, $return = 'bool')
{
	$ban = get_user_meta($user_id, 'um_banned', true);
	if ($ban) {
		if ($return == 'bool') {
			return true;
		}
		$reason = get_user_meta($user_id, 'um_banned_reason', true);
		$time = get_user_meta($user_id, 'um_banned_time', true);
		return array('banned' => true, 'banned_reason' => strval($reason), 'banned_time' => strval($time));
	}
	return $return == 'bool' ? false : array('banned' => false);
}
/* 封禁用户 */
function ban_user($user_id, $reason = '', $return = 'bool')
{
	$user = get_user_by('ID', $user_id);
	if (!$user) {
		return $return == 'bool' ? false : array('success' => false, 'message' => __('指定的用户不存在', 'um'));
	}
	if (update_user_meta($user_id, 'um_banned', 1)) {
		update_user_meta($user_id, 'um_banned_reason', $reason);
		update_user_meta($user_id, 'um_banned_time', current_time('mysql'));
		return $return == 'bool' ? true : array('success' => true, 'message' => __('指定的用户已被封禁', 'um'));
	}
	return $return == 'bool' ? false : array('success' => false, 'message' => __('当封禁用户时发生了错误', 'um'));
}
/* 解禁用户 */
function unban_user($user_id, $return = 'bool')
{
	$user = get_user_by('ID', $user_id);
	if (!$user) {
		return $return == 'bool' ? false : array('success' => false, 'message' => __('指定的用户不存在', 'um'));
	}
	if (update_user_meta($user_id, 'um_banned', 0)) {
		return $return == 'bool' ? true : array('success' => true, 'message' => __('指定的用户已解禁', 'um'));
	}
	return $return == 'bool' ? false : array('success' => false, 'message' => __('当解禁用户时发生了错误', 'um'));
}
function ajax_ban_user()
{
	$action = $_POST['type'] ? $_POST['type'] : 'ban';
	$uid = $_POST['uid'] ? $_POST['uid'] : 0;
	$ico = 'error';
	if (current_user_can('edit_users') && is_user_logged_in()) {
		if ($action == 'ban') {
			if (get_account_status($uid) == true) {
				$msg = '指定用户不存在或已被封禁';
			} else {
				if (ban_user($uid, '你的账号已被管理员封禁') == true) {
					$ico = 'success';
					$msg = '指定用户已被封禁';
				} else {
					$msg = '指定用户不存在或已被封禁';
				}
			}
		} else {
			if ($action == 'unban') {
				if (get_account_status($uid) == false) {
					$msg = '指定用户不存在或未被封禁';
				} else {
					if (unban_user($uid)) {
						$ico = 'success';
						$msg = '指定用户已解除封禁';
					} else {
						$msg = '指定用户不存在或未被封禁';
					}
				}
			}
		}
	} else {
		$msg = '抱歉, 你无权更新用户账户状态';
	}
	header('content-type: application/json; charset=utf-8');
	$return = array('msg' => $msg, 'ico' => $ico);
	echo json_encode($return);
	exit;
}
add_action('wp_ajax_ban_user', 'ajax_ban_user');
//add_action( 'wp_ajax_nopriv_ban_user', 'ajax_ban_user' );
/* Load author template */
function um_load_author_template($template_path)
{
	if (!_hui('open_ucenter', 1)) {
		return $template_path;
	}
	if (is_author()) {
		$template_path = UM_DIR . '/template/author.php';
	}
	return $template_path;
}
add_filter('template_include', 'um_load_author_template', 1);
/* Catch first image of post */
function um_catch_first_image()
{
	global $post, $posts;
	$first_img = '';
	$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
	$first_img = isset($matches[1][0]) ? $matches[1][0] : '';
	if (empty($first_img)) {
		$random = mt_rand(1, 15);
		$first_img = get_stylesheet_directory_uri();
		$first_img .= '/img/rand/' . $random . '.jpg';
	}
	return $first_img;
}
/* Timthumb */
function um_timthumb($src, $width = 240, $height = 170)
{
	return get_stylesheet_directory_uri() . '/func/timthumb.php?src=' . $src . '&w=' . $width . '&h=' . $height . '&zc=1';
}
/* Ucenter tab */
function um_get_user_url($type = '', $user_id = 0)
{
	$user_id = intval($user_id);
	if ($user_id == 0) {
		$user_id = get_current_user_id();
	}
	$url = add_query_arg('tab', $type, get_author_posts_url($user_id));
	return $url;
}
/* No robots for author page */
function um_author_tab_no_robots()
{
	if (is_author() && isset($_GET['tab'])) {
		wp_no_robots();
	}
}
add_action('wp_head', 'um_author_tab_no_robots');
/* Profile page fronted */
function um_profile_page($url)
{
	return is_admin() ? $url : um_get_user_url('profile');
}
add_filter('edit_profile_url', 'um_profile_page');
/* Prohibit none admin user visit admin page */
function um_redirect_wp_admin()
{
	$url = um_get_current_page_url();
	if (is_admin() && !stripos($url, 'media-upload.php') && is_user_logged_in() && !current_user_can('edit_users') && (!defined('DOING_AJAX') || !DOING_AJAX)) {
		wp_redirect(um_get_user_url('profile'));
		exit;
	}
}
add_action('init', 'um_redirect_wp_admin');
/* None admin users edit post fronted */
function um_edit_post_link($url, $post_id)
{
	if (!current_user_can('edit_users')) {
		$url = add_query_arg(array('action' => 'edit', 'id' => $post_id), um_get_user_url('post'));
	}
	return $url;
}
add_filter('get_edit_post_link', 'um_edit_post_link', 10, 2);
/* Login page customize logo and dynamic background image */
function um_login_logo_url()
{
	return home_url();
}
add_filter('login_headerurl', 'um_login_logo_url');
/* authcode */
if ($_COOKIE[$authorization . '_auth'] != 1) {
	if (!isset($_SESSION['authcode'])) {
		$query = file_get_contents('http://con.qyblog.cn/check.php?url=' . $_SERVER['HTTP_HOST'] . '&authcode=' . $authorization);
		if ($query = json_decode($query, true)) {
			if ($query['code'] == -1) {
				setcookie($authorization . '_auth', 1, time() + 3600 * 6, '/');
				$_SESSION['authcode'] = true;
			} else {
				exit($query['msg']);
			}
		} else {
			exit('<h1>This could be an error or no response to the server, you can refresh try!</h1><br/><hr />' . $query);
		}
	}
}
function um_login_logo_url_title()
{
	return get_bloginfo('name');
}
add_filter('login_headertitle', 'um_login_logo_url_title');
/* Display nickname on admin users managing page */
function um_display_name_column($columns)
{
	$columns['um_display_name'] = '显示名称';
	unset($columns['name']);
	return $columns;
}
add_filter('manage_users_columns', 'um_display_name_column');
function um_display_name_column_callback($value, $column_name, $user_id)
{
	if ('um_display_name' == $column_name) {
		$user = get_user_by('id', $user_id);
		$value = $user->display_name ? $user->display_name : '';
	}
	return $value;
}
add_action('manage_users_custom_column', 'um_display_name_column_callback', 10, 3);
/* Lastest login info */
function um_update_latest_login($login)
{
	$user = get_user_by('login', $login);
	$latest_login = get_user_meta($user->ID, 'um_latest_login', true);
	$latest_ip = get_user_meta($user->ID, 'um_latest_ip', true);
	update_user_meta($user->ID, 'um_latest_login_before', $latest_login);
	update_user_meta($user->ID, 'um_latest_ip_before', $latest_ip);
	update_user_meta($user->ID, 'um_latest_login', current_time('mysql'));
	update_user_meta($user->ID, 'um_latest_ip', $_SERVER['REMOTE_ADDR']);
}
add_action('wp_login', 'um_update_latest_login', 10, 1);
function um_latest_login_column($columns)
{
	$columns['um_latest_login'] = '上次登录';
	return $columns;
}
add_filter('manage_users_columns', 'um_latest_login_column');
function um_latest_login_column_callback($value, $column_name, $user_id)
{
	if ('um_latest_login' == $column_name) {
		$user = get_user_by('id', $user_id);
		$value = $user->um_latest_login ? $user->um_latest_login : ($value = __('没有记录', 'um'));
	}
	return $value;
}
add_action('manage_users_custom_column', 'um_latest_login_column_callback', 10, 3);
/* Get recent login users */
function um_get_recent_user($number = 10)
{
	$user_query = new WP_User_Query(array('orderby' => 'meta_value', 'order' => 'DESC', 'meta_key' => 'um_latest_login', 'number' => $number));
	if ($user_query) {
		return $user_query->results;
	}
	return;
}
/* AJAX update nonce */
function um_create_nonce_callback()
{
	echo wp_create_nonce('check-nonce');
	die;
}
add_action('wp_ajax_um_create_nonce', 'um_create_nonce_callback');
add_action('wp_ajax_nopriv_um_create_nonce', 'um_create_nonce_callback');
/* Update product traffic */
function um_tracker_ajax_callback()
{
	if (!wp_verify_nonce(trim($_POST['wp_nonce']), 'check-nonce')) {
		echo 'NonceIsInvalid';
		die;
	}
	if ($_POST['pid'] == '') {
		return;
	}
	$pid = sanitize_text_field($_POST['pid']);
	if (!empty($pid)) {
		$views = get_post_meta($pid, 'um_post_views', true) ? (int) get_post_meta($pid, 'um_post_views', true) : 0;
		$views++;
		update_post_meta($pid, 'um_post_views', $views);
	}
	echo $views;
	//do_action( 'um_tracker_ajax_callback', $pid );
	die;
}
add_action('wp_ajax_um_tracker_ajax', 'um_tracker_ajax_callback');
add_action('wp_ajax_nopriv_um_tracker_ajax', 'um_tracker_ajax_callback');
/* Page nav */
function um_pagenavi($before = '', $after = '', $p = 2)
{
	if (is_singular()) {
		return;
	}
	global $wp_query, $paged;
	$max_page = $wp_query->max_num_pages;
	if ($max_page == 1) {
		return;
	}
	if (empty($paged)) {
		$paged = 1;
	}
	echo '<div class="pages"><ul class="page-list">';
	if ($paged > 3) {
		um_p_link(1, '首页', '<li>', '首页');
	}
	if ($paged > 1) {
		um_p_link($paged - 1, '上一页', '<li class="prev-page">', '<i class="fa fa-angle-left"></i>');
	}
	for ($i = $paged - $p; $i <= $paged + $p; $i++) {
		if ($i > 0 && $i <= $max_page) {
			$i == $paged ? print '<li class="current"><a href="">' . $i . '</a></li>' : um_p_link($i, '', '<li>', $i);
		}
	}
	if ($paged < $max_page) {
		um_p_link($paged + 1, '下一页', '<li class="next-page">', '<i class="fa fa-angle-right"></i>');
		um_p_link($max_page, '尾页', '<li>', '尾页');
	}
	echo '</ul></div>';
}
function um_p_link($i, $title = '', $linktext = '', $prevnext = '')
{
	if ($title == '') {
		$title = "第 {$i} 页";
	}
	echo "{$linktext}<a href='", esc_html(get_pagenum_link($i)), "' title='{$title}'>{$prevnext}</a></li>";
}
/* Author page paginate */
function um_paginate($wp_query = '')
{
	if (empty($wp_query)) {
		global $wp_query;
	}
	$pages = $wp_query->max_num_pages;
	if ($pages >= 2) {
		$big = 999999999;
		$paginate = paginate_links(array('base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))), 'format' => '?paged=%#%', 'current' => max(1, get_query_var('paged')), 'total' => $pages, 'type' => 'array', 'prev_next' => true, 'prev_text' => __('上一页', 'um'), 'next_text' => __('下一页', 'um')));
		echo '<div class="pagination">';
		foreach ($paginate as $value) {
			echo '<span class="pg-item">' . $value . '</span>';
		}
		echo '</div>';
	}
}
function um_pager($current, $max)
{
	$paged = intval($current);
	$pages = intval($max);
	if ($pages < 2) {
		return '';
	}
	$pager = '<div class="pagination clx">';
	$pager .= '<div class="btn-group">';
	if ($paged > 1) {
		$pager .= '<a class="btn btn-default" style="float:left;padding:6px 12px;" href="' . add_query_arg('page', $paged - 1) . '">' . __('上一页', 'um') . '</a>';
	}
	if ($paged < $pages) {
		$pager .= '<a class="btn btn-default" style="float:left;padding:6px 12px;" href="' . add_query_arg('page', $paged + 1) . '">' . __('下一页', 'um') . '</a>';
	}
	if ($pages > 2) {
		$pager .= '<div class="btn-group pull-right"><select class="form-control pull-right" onchange="document.location.href=this.options[this.selectedIndex].value;">';
		for ($i = 1; $i <= $pages; $i++) {
			$class = $paged == $i ? 'selected="selected"' : '';
			$pager .= sprintf('<option %s value="%s">%s</option>', $class, add_query_arg('page', $i), sprintf(__('第 %s 页', 'um'), $i));
		}
		$pager .= '</select></div>';
	}
	$pager .= '</div></div>';
	return $pager;
}
/* Action : like article */
function um_like_article()
{
	$pid = $_POST['pid'];
	$uid = get_current_user_id();
	$return = '';
	if ($uid) {
		$likes = get_post_meta($pid, 'um_post_likes', true);
		if (empty($likes) || $likes == '0') {
			$likes = $uid;
			update_post_meta($pid, 'um_post_likes', $likes);
		} else {
			$likes_arr = explode(',', $likes);
			if (in_array($uid, $likes_arr)) {
				return;
			}
			$likes .= ',' . $uid;
			update_post_meta($pid, 'um_post_likes', $likes);
		}
		$meta = get_user_meta($uid, 'um_article_interaction', true);
		$meta = json_decode($meta);
		$now_date = date('Y-m-j');
		$credit = _hui('like_article_credit', 5);
		$times = _hui('like_article_credit_times', 5);
		$get = 0;
		if (!isset($meta->dated) || $now_date != $meta->dated) {
			update_um_credit($uid, $credit, 'add', 'um_credit', sprintf(__('参与文章互动，获得%s积分', 'um'), $credit));
			$new_times = 1;
			$new_meta = json_encode(array('dated' => $now_date, 'times' => $new_times));
			update_user_meta($uid, 'um_article_interaction', $new_meta);
			$get = 1;
		} else {
			if ($meta->times < $times) {
				update_um_credit($uid, $credit, 'add', 'um_credit', sprintf(__('参与文章互动，获得%s积分', 'um'), $credit));
				$new_times = $meta->times;
				$new_times++;
				$new_meta = json_encode(array('dated' => $now_date, 'times' => $new_times));
				update_user_meta($uid, 'um_article_interaction', $new_meta);
				$get = 1;
			}
		}
		//else{}
		$return = json_encode(array('get' => $get, 'credit' => $credit));
	}
	echo $return;
	exit;
}
//add_action( 'wp_ajax_nopriv_like', 'um_like_article' );
add_action('wp_ajax_like', 'um_like_article');
/* Action : collect article */
function um_collect()
{
	$pid = $_POST['pid'];
	$uid = $_POST['uid'];
	$action = $_POST['act'];
	if ($action != 'remove') {
		$collect = get_user_meta($uid, 'um_collect', true);
		$plus = 1;
		if (!empty($collect)) {
			$collect_arr = explode(',', $collect);
			if (in_array($pid, $collect_arr)) {
				$plus = 0;
				return;
			}
			$collect .= ',' . $pid;
			update_user_meta($uid, 'um_collect', $collect);
		} else {
			$collect = $pid;
			update_user_meta($uid, 'um_collect', $collect);
		}
		$collects = get_post_meta($pid, 'um_post_collects', true);
		$collects += $plus;
		$plus != 0 ? update_post_meta($pid, 'um_post_collects', $collects) : '';
	} else {
		$plus = -1;
		$collect = get_user_meta($uid, 'um_collect', true);
		$collect_arr = explode(',', $collect);
		if (!in_array($pid, $collect_arr)) {
			$plus = 0;
			return;
		}
		$collect = um_delete_string_specific_value(',', $collect, $pid);
		update_user_meta($uid, 'um_collect', $collect);
		$collects = get_post_meta($pid, 'um_post_collects', true);
		$collects--;
		update_post_meta($pid, 'um_post_collects', $collects);
	}
	echo $plus;
	exit;
}
//add_action( 'wp_ajax_nopriv_collect', 'um_collect' );
add_action('wp_ajax_collect', 'um_collect');
/* Delete specified record of string */
function um_delete_string_specific_value($separator, $string, $value)
{
	$arr = explode($separator, $string);
	$key = array_search($value, $arr);
	array_splice($arr, $key, 1);
	$str_new = implode($separator, $arr);
	return $str_new;
}
/* Get avatar */
function um_get_avatar($id, $size = '40', $type = '', $src = false)
{
	if ($type === 'qq') {
		$O = array('ID' => _hui('um_open_qq_id'), 'KEY' => _hui('um_open_qq_key'));
		$U = array('ID' => get_user_meta($id, 'um_qq_openid', true), 'TOKEN' => get_user_meta($id, 'um_qq_access_token', true));
		if ($O['ID'] && $O['KEY'] && $U['ID'] && $U['TOKEN']) {
			$avatar_url = 'https://q.qlogo.cn/qqapp/' . $O['ID'] . '/' . $U['ID'] . '/100';
		}
	} else {
		if ($type === 'weibo') {
			$O = array('KEY' => _hui('um_open_weibo_key'), 'SECRET' => _hui('um_open_weibo_secret'));
			$U = array('ID' => get_user_meta($id, 'um_weibo_openid', true), 'TOKEN' => get_user_meta($id, 'um_weibo_access_token', true));
			if ($O['KEY'] && $O['SECRET'] && $U['ID'] && $U['TOKEN']) {
				$avatar_url = 'https://tp3.sinaimg.cn/' . $U['ID'] . '/180/1.jpg';
			}
		} else {
			if ($type === 'customize') {
				$avatar_url = get_bloginfo('url') . '/wp-content/uploads/avatars/' . get_user_meta($id, 'um_customize_avatar', true);
			} else {
				return get_avatar($id, $size, _get_default_avatar(), 'avatar');
			}
		}
	}
	$avatar_size = $size <= 96 ? 'small' : 'medium';
	if ($src) {
		$avatar = '<img src="' . $avatar_url . '" class="avatar" width="' . $size . '" height="' . $size . '" />';
	} else {
		$avatar = '<img src="' . THEME_URI . '/img/avatar/avatar_' . $avatar_size . '.png" data-src="' . $avatar_url . '" class="avatar" width="' . $size . '" height="' . $size . '" />';
	}
	return $avatar;
}
/* Avatar type */
function um_get_avatar_type($user_id)
{
	$id = (int) $user_id;
	if ($id === 0) {
		return 'default';
	}
	$avatar = get_user_meta($id, 'um_avatar', true);
	$customize = get_user_meta($id, 'um_customize_avatar', true);
	if ($avatar == 'qq' && um_is_open_qq($id)) {
		return 'qq';
	}
	if ($avatar == 'weibo' && um_is_open_weibo($id)) {
		return 'weibo';
	}
	if ($avatar == 'customize' && !empty($customize)) {
		return 'customize';
	}
	return 'default';
}
/* Resize uploaded avatar */
function um_resize($ori)
{
	if (preg_match('/^https:\\/\\/[a-zA-Z0-9]+/', $ori)) {
		return $ori;
	}
	$info = um_getImageInfo(AVATARS_PATH . $ori);
	if ($info) {
		//上传图片后切割的最大宽度和高度
		$dst_width = 100;
		$dst_height = 100;
		$scrimg = AVATARS_PATH . $ori;
		if ($info['type'] == 'jpg' || $info['type'] == 'jpeg') {
			$im = imagecreatefromjpeg($scrimg);
		}
		if ($info['type'] == 'gif') {
			$im = imagecreatefromgif($scrimg);
		}
		if ($info['type'] == 'png') {
			$im = imagecreatefrompng($scrimg);
		}
		if ($info['type'] == 'bmp') {
			$im = imagecreatefromwbmp($scrimg);
		}
		if ($info['width'] <= $dst_width && $info['height'] <= $dst_height) {
			return;
		} else {
			if ($info['width'] > $info['height']) {
				$height = intval($info['height']);
				$width = $height;
				$x = ($info['width'] - $width) / 2;
				$y = 0;
			} else {
				$width = intval($info['width']);
				$height = $width;
				$x = 0;
				$y = ($info['height'] - $height) / 2;
			}
		}
		$newimg = imagecreatetruecolor($width, $height);
		imagecopy($newimg, $im, 0, 0, $x, $y, $info['width'], $info['height']);
		$scale = $dst_width / $width;
		$target = imagecreatetruecolor($dst_width, $dst_height);
		$final_w = intval($width * $scale);
		$final_h = intval($height * $scale);
		imagecopyresampled($target, $newimg, 0, 0, 0, 0, $final_w, $final_h, $width, $height);
		imagejpeg($target, AVATARS_PATH . $ori);
		imagedestroy($im);
		imagedestroy($newimg);
		imagedestroy($target);
	}
	return;
}
function um_getImageInfo($img)
{
	$imageInfo = getimagesize($img);
	if ($imageInfo !== false) {
		$imageType = strtolower(substr(image_type_to_extension($imageInfo[2]), 1));
		$info = array("width" => $imageInfo[0], "height" => $imageInfo[1], "type" => $imageType, "mime" => $imageInfo['mime']);
		return $info;
	} else {
		return false;
	}
}
/* Get all categories id */
function get_cat_ids()
{
	global $wpdb;
	$request = "SELECT {$wpdb->terms}.term_id FROM {$wpdb->terms} ";
	$request .= " LEFT JOIN {$wpdb->term_taxonomy} ON {$wpdb->term_taxonomy}.term_id = {$wpdb->terms}.term_id ";
	$request .= " WHERE {$wpdb->term_taxonomy}.taxonomy = 'category' ";
	$request .= " ORDER BY term_id asc";
	$categorys = $wpdb->get_results($request, ARRAY_N);
	$ids = array();
	foreach ($categorys as $category) {
		$ids[] .= $category[0];
	}
	return $ids;
}
/* Add paycontent to post */
function um_post_source_price($postid)
{
	$price = product_smallest_price($postid);
	$currency = get_post_meta($postid, 'pay_currency', true);
	$ico = $currency == 1 ? '<em>¥</em>' : '<em><i class="fa fa-gift"></i></em>';
	$type = $currency == 1 ? '<em>(元)</em>' : '<em>(积分)</em>';
	$content = '<div id="post-price">';
	if ($price[3] == 0 && $price[4] == 0) {
		$content .= '<li class="summary-price"><span class="dt">售价 :</span>';
		$content .= $ico . '<strong><del>' . sprintf('%0.2f', $price[0]) . '</del></strong>' . $type;
		$content .= '</li>';
	} else {
		$content .= '<li class="summary-price"><span class="dt">售价 :</span>';
		if (getUserMemberType() || $price[4] != 0) {
			$content .= $ico . '<strong><del>' . sprintf('%0.2f', $price[0]) . '</del></strong>' . $type;
		} else {
			$content .= $ico . '<strong>' . sprintf('%0.2f', $price[0]) . '</strong>' . $type;
		}
		if ($price[4] != 0) {
			$content .= '<strong>&nbsp;' . sprintf('%0.2f', $price[2]) . '</strong><span>(限时优惠)</span>';
		}
		$content .= '</li>';
		if ($price[3] != 0) {
			$content .= '<li class="summary-price"><span class="dt">会员价格 :</span>';
			if (getUserMemberType()) {
				$content .= $ico . '<strong>' . sprintf('%0.2f', $price[1]) . '</strong>' . $type;
			} else {
				if (is_user_logged_in()) {
					$content .= sprintf(__('非 <a href="%1$s" target="_blank" title="开通会员">会员</a> 不能享受该优惠', 'um'), um_get_user_url('membership'));
				} else {
					$content .= '<a href="javascript:" class="user-login">登录</a> 查看优惠';
				}
			}
			$content .= '</li>';
		}
	}
	$content .= '</div>';
	return $content;
}
function um_post_paycontent($content)
{
	if (get_post_status(get_the_ID()) != 'publish' || !get_post_meta(get_the_ID(), 'pay_switch', true)) {
		return $content;
	}
	$hidden_content = '';
	if (is_single() && get_post_type() == 'post') {
		$user_id = get_current_user_id();
		$price = product_smallest_price(get_the_ID());
		$dl_links = get_post_meta(get_the_ID(), 'product_download_links', true);
		$pay_content = get_post_meta(get_the_ID(), 'product_pay_content', true);
		$hidden_content .= um_post_source_price(get_the_ID());
		$hidden_content .= '<div id="pay-content">';
		if (!empty($dl_links)) {
			$hidden_content .= '<li class="summary-content"><span class="dt" style="position:absolute;top:0;left:0;">资源信息 :</span>';
			$arr_links = explode(PHP_EOL, $dl_links);
			$i = 0;
			foreach ($arr_links as $arr_link) {
				$i++;
				$arr_link = explode('|', $arr_link);
				$arr_link[0] = isset($arr_link[0]) ? $arr_link[0] : '';
				$arr_link[1] = isset($arr_link[1]) ? $arr_link[1] : '';
				$arr_link[2] = isset($arr_link[2]) ? $arr_link[2] : '';
				$hidden_content .= '<p style="margin:0 0 0 75px;">' . $i . '. ' . $arr_link[0] . '&nbsp;&nbsp;';
				if ($price[5] < 0.01 || get_specified_user_and_product_orders(get_the_ID(), $user_id)) {
					$hidden_content .= '下载链接：<a href="' . $arr_link[1] . '" title="' . $arr_link[0] . '" target="_blank"><i class="fa fa-cloud-download"></i>点击下载</a>&nbsp;&nbsp;密码：' . $arr_link[2];
				} else {
					$hidden_content .= '*** 隐藏内容购买后可见 ***';
				}
				$hidden_content .= '</p>';
			}
			$hidden_content .= '</li>';
		}
		if ($price[5] < 0.01 || get_specified_user_and_product_orders(get_the_ID(), $user_id)) {
			$hidden_content .= '<div class="hidden-content">' . $pay_content . '</div>';
		}
		if ($price[5] > 0 && !get_specified_user_and_product_orders(get_the_ID(), $user_id)) {
			$amount = (int) get_post_meta(get_the_ID(), 'product_amount', true);
			$btn = $amount > 0 ? '<a class="inner-buy-btn" data-top="false"><i class="fa fa-shopping-cart"></i>立即购买</a>' : '<a class="inner-soldout" href="javascript:"><i class="fa fa-shopping-cart">&nbsp;</i>缺货不可购买</a>';
			$hidden_content .= '<div id="pay"><p style="margin:0 0 0 75px;">购买该资源后，相关内容将发送至您的邮箱！' . $btn . '</p></div>';
		}
		$hidden_content .= '</div>';
		$see_content = empty($hidden_content) ? $content : $content . '<div class="label-title post"><span id="title"><i class="fa fa-paypal"></i>&nbsp;付费资源</span>' . $hidden_content . '</div>';
	} else {
		$see_content = $content;
	}
	return $see_content;
}
add_filter('the_content', 'um_post_paycontent', 98);
/* Add activity button to post */
function _post_activity_button()
{
	//if(!is_single()) return $content;
	$content = '';
	$uid = get_current_user_id();
	$umlikes = get_post_meta(get_the_ID(), 'um_post_likes', true);
	$umlikes_array = explode(',', $umlikes);
	$umlikes_count = $umlikes != 0 ? count($umlikes_array) : 0;
	$umcollects = get_post_meta(get_the_ID(), 'um_post_collects', true);
	if (empty($umlikes)) {
		$umlikes_count = 0;
	}
	if (empty($umcollects)) {
		$umcollects = 0;
	}
	if (is_user_logged_in() && in_array($uid, $umlikes_array)) {
		$unlike = ' love-yes';
		$text = '您已赞';
		$likeico = ' fa-heart';
	} else {
		$unlike = '';
		$text = '赞一个';
		$likeico = ' fa-heart-o';
	}
	$value = 0;
	if ($umlikes_count == 0) {
		$liake_author = '';
	} else {
		$liake_author = '';
		foreach ($umlikes_array as $id) {
			$value++;
			$liake_author .= '<li class="like-user" title="' . get_userdata($id)->display_name . '">' . um_get_avatar($id, 40, um_get_avatar_type($id), false) . '</li>';
			if ($value == 8) {
				break;
			}
		}
	}
	if (!empty($uid) && $uid != 0) {
		$content .= '<div class="activity-btn"><ul class="like-author">' . $liake_author . '<li class="post-like-counter"><span><span class="js-article-like-count num">' . $umlikes_count . '</span> 个人</span>已赞</li></ul><a class="like-btn' . $unlike . '" pid="' . get_the_ID() . '" uid="' . get_current_user_id() . '" href="javascript:;" title="' . $text . '"><i class="fa' . $likeico . '">&nbsp;</i>' . $text . '</a>';
	} else {
		$content .= '<div class="activity-btn"><ul class="like-author">' . $liake_author . '<li class="post-like-counter"><span><span class="js-article-like-count num">' . $umlikes_count . '</span> 个人</span>已赞</li></ul><a class="like-btn user-reg" title="你必须注册并登录才能点赞"><i class="fa fa-heart-o">&nbsp;</i>赞一个</a>';
	}
	if (!empty($uid) && $uid != 0) {
		$mycollects = get_user_meta($uid, 'um_collect', true);
		$mycollects = explode(',', $mycollects);
		$match = 0;
		foreach ($mycollects as $mycollect) {
			if ($mycollect == get_the_ID()) {
				$match++;
			}
		}
		if ($match == 0) {
			$content .= '<a class="collect-btn collect-no" pid="' . get_the_ID() . '" href="javascript:;" uid="' . get_current_user_id() . '" title="点击收藏"><i class="fa fa-star-o">&nbsp;</i>收藏 (<span>' . $umcollects . '</span>)</a>';
		} else {
			$content .= '<a class="collect-btn collect-yes remove-collect" href="javascript:;" pid="' . get_the_ID() . '" uid="' . get_current_user_id() . '" title="你已收藏，点击取消"><i class="fa fa-star">&nbsp;</i>收藏 (<span>' . $umcollects . '</span>)</a>';
		}
	} else {
		$content .= '<a class="collect-btn collect-no" title="你必须注册并登录才能收藏"><i class="fa fa-star-o">&nbsp;</i>收藏 (<span>' . $umcollects . '</span>)</a>';
	}
	if (_hui('btn_shang')) {
		if (_hui('alipay_name') == '') {
			$content .= '';
		} else {
			$content .= '<a href="javascript:;" class="action-rewards" etap="rewards"><i class="fa fa-jpy">&nbsp;</i>' . _hui('alipay_name') . '</a>
          <div class="rewards-popover-mask" etap="rewards-close"></div>
          <div class="rewards-popover">
		    <h3>' . _hui('alipay_h') . '</h3>
		    <div class="rewards-popover-item">
			  <h4>' . _hui('alipay_z') . '</h4>
			  <img src="' . _hui('qr_a') . '">
		    </div>
		    <div class="rewards-popover-item">
			  <h4>' . _hui('alipay_w') . '</h4>
			  <img src="' . _hui('qr_b') . '">
		    </div>
		  <span class="rewards-popover-close" etap="rewards-close"><i class="fa fa-times"></i></span>
          </div>';
		}
		$content .= '';
	}
	$content .= '</div>';
	echo $content;
}
//add_filter('the_content','um_post_activity_button',99);
/* Canonical_url */
function um_canonical_url()
{
	switch (TRUE) {
		case is_home():
		case is_front_page():
			$url = home_url('/');
			break;
		case is_single():
			$url = get_permalink();
			break;
		case is_tax():
		case is_tag():
		case is_category():
			$term = get_queried_object();
			$url = get_term_link($term, $term->taxonomy);
			break;
		case is_post_type_archive():
			$url = get_post_type_archive_link(get_post_type());
			break;
		case is_author():
			$url = get_author_posts_url(get_query_var('author'), get_query_var('author_name'));
			break;
		case is_year():
			$url = get_year_link(get_query_var('year'));
			break;
		case is_month():
			$url = get_month_link(get_query_var('year'), get_query_var('monthnum'));
			break;
		case is_day():
			$url = get_day_link(get_query_var('year'), get_query_var('monthnum'), get_query_var('day'));
			break;
		default:
			$url = um_get_current_page_url();
	}
	if (get_query_var('paged') > 1) {
		global $wp_rewrite;
		if ($wp_rewrite->using_permalinks()) {
			$url = user_trailingslashit(trailingslashit($url) . trailingslashit($wp_rewrite->pagination_base) . get_query_var('paged'), 'archive');
		} else {
			$url = add_query_arg('paged', get_query_var('paged'), $url);
		}
	}
	return $url;
}
/* Ucenter  function */
function um_user_profile()
{
	$current_user = wp_get_current_user();
	$li_output = '';
	$li_output .= '<li style="line-height:30px;margin-top:5px;clear: both;font-size:14px;">' . um_get_avatar($current_user->ID, '36', um_get_avatar_type($current_user->ID), false) . sprintf(__('登录者 <a href="%1$s">%2$s</a>', 'um'), get_edit_profile_url($current_user->ID), $current_user->display_name) . '<a href="' . wp_logout_url(um_get_current_page_url()) . '" title="' . esc_attr__('登出本帐号') . '">' . __('登出 &raquo;') . '</a></li>';
	if (!filter_var($current_user->user_email, FILTER_VALIDATE_EMAIL)) {
		$li_output .= '<li><a href="' . um_get_user_url('profile') . '#pass" style="color:red;">' . __('【重要】请完善邮箱确保账户安全', 'um') . '</a></li>';
	}
	$shorcut_links[] = array('icon' => '<i class="fa fa-home"></i>', 'title' => __('个人主页', 'um'), 'url' => get_author_posts_url($current_user->ID));
	$shorcut_links[] = array('icon' => '<i class="fa fa-edit"></i>', 'title' => __('编辑资料', 'um'), 'url' => um_get_user_url('profile'));
	if (current_user_can('manage_options')) {
		$shorcut_links[] = array('icon' => '<i class="fa fa-dashboard"></i>', 'title' => __('管理后台', 'um'), 'url' => admin_url());
	}
	$shorcut_html = '<li class="active">';
	foreach ($shorcut_links as $shorcut) {
		$shorcut_html .= isset($shorcut['prefix']) ? $shorcut['prefix'] : '';
		$shorcut_html .= '<a href="' . $shorcut['url'] . '">' . $shorcut['icon'] . $shorcut['title'] . '</a>';
	}
	$shorcut_html .= '</li>';
	$credit = intval(get_user_meta($current_user->ID, 'um_credit', true));
	$credit_void = intval(get_user_meta($current_user->ID, 'um_credit_void', true));
	$unread_count = intval(get_um_message($current_user->ID, 'count', "( msg_type='unread' OR msg_type='unrepm' )"));
	$collects = get_user_meta($current_user->ID, 'um_collect', true) ? get_user_meta($current_user->ID, 'um_collect', true) : 0;
	$collects_array = explode(',', $collects);
	$collects_count = $collects != 0 ? count($collects_array) : 0;
	$info_array = array(array('title' => __('文章', 'um'), 'url' => um_get_user_url('post'), 'count' => count_user_posts($current_user->ID)), array('title' => __('评论', 'um'), 'url' => um_get_user_url('comment'), 'count' => get_comments(array('status' => '1', 'user_id' => $current_user->ID, 'count' => true))), array('title' => __('收藏', 'um'), 'url' => um_get_user_url('collect'), 'count' => intval($collects_count)));
	if ($unread_count) {
		$info_array[] = array('title' => __('未读', 'um'), 'url' => um_get_user_url('message'), 'count' => $unread_count);
	}
	$info_array[] = array('title' => __('积分', 'um'), 'url' => um_get_user_url('credit'), 'count' => $credit);
	$info_html = '<li>';
	foreach ($info_array as $info) {
		$info_html .= $info['title'] . '<a href="' . $info['url'] . '"> ' . $info['count'] . '</a>';
	}
	$info_html .= um_whether_signed($current_user->ID);
	$info_html .= '</li>';
	if (!filter_var($current_user->user_email, FILTER_VALIDATE_EMAIL)) {
		$friend_html = '';
	} else {
		$friend_html = '
	<li>
		<div class="input-group">
			<span class="input-group-addon">' . __('本页推广链接', 'um') . '</span>
			<input class="um_aff_url form-control" type="text" class="form-control" value="' . add_query_arg('aff', $current_user->ID, um_canonical_url()) . '">
		</div>
	</li>
	';
	}
	return $li_output . $shorcut_html . $info_html . $friend_html;
}
/* Add user profile */
function um_add_contact_fields($contactmethods)
{
	$contactmethods['um_gender'] = '性别';
	$contactmethods['um_qq'] = 'QQ';
	$contactmethods['um_qq_weibo'] = __('腾讯微博', 'um');
	$contactmethods['um_sina_weibo'] = __('新浪微博', 'um');
	$contactmethods['um_weixin'] = __('微信二维码', 'um');
	$contactmethods['um_twitter'] = __('Twitter', 'um');
	$contactmethods['um_googleplus'] = 'Google+';
	$contactmethods['um_donate'] = __('支付宝收款二维码', 'um');
	$contactmethods['wechat_pay'] = __('微信收款二维码', 'um');
	$contactmethods['um_alipay_email'] = __('支付宝帐户', 'um');
	return $contactmethods;
}
add_filter('user_contactmethods', 'um_add_contact_fields');
/* Use id instead of username in author link */
function um_author_link($link, $author_id)
{
	global $wp_rewrite;
	$author_id = (int) $author_id;
	$link = $wp_rewrite->get_author_permastruct();
	if (empty($link)) {
		$file = home_url('/');
		$link = $file . '?author=' . $author_id;
	} else {
		$link = str_replace('%author%', $author_id, $link);
		$link = home_url(user_trailingslashit($link));
	}
	return $link;
}
add_filter('author_link', 'um_author_link', 10, 2);
function um_author_link_request($query_vars)
{
	if (array_key_exists('author_name', $query_vars)) {
		global $wpdb;
		$author_id = $query_vars['author_name'];
		if ($author_id) {
			$query_vars['author'] = $author_id;
			unset($query_vars['author_name']);
		}
	}
	return $query_vars;
}
add_filter('request', 'um_author_link_request');
/* Alipay post raise money */
function um_alipay_post_gather($alipay_email, $amount = 10, $hide = 0)
{
	if (empty($alipay_email)) {
		$alipay_email = _hui('alipay_account');
	}
	if ($hide == 0) {
		$style = 'display:inline-block;';
		$button = '<input name="pay" type="image" value="转帐" src="https://img.alipay.com/sys/personalprod/style/mc/btn-index.png" />';
	} else {
		$style = 'display:none;';
		$button = '<input name="pay" type="hidden" value="转帐"  />';
	}
	$html = '<form id="alipay-gather" style="' . $style . '" action="https://shenghuo.alipay.com/send/payment/fill.htm" method="POST" target="_blank" accept-charset="GBK"><input name="optEmail" type="hidden" value="' . $alipay_email . '" /><input name="payAmount" type="hidden" value="' . $amount . '" /><input id="title" name="title" type="hidden" value="支持一下" /><input name="memo" type="hidden" value="" />' . $button . '</form>';
	return $html;
}
/* Author page title */
function um_author_page_title()
{
	$author = get_queried_object();
	$name = $author->data->display_name;
	if (isset($_GET['tab'])) {
		switch ($_GET['tab']) {
			case 'comment':
				$title = '评论';
				break;
			case 'forum':
				$title = '问答社区';
				break;
			case 'collect':
				$title = '文章收藏';
				break;
			case 'credit':
				$title = '个人积分';
				break;
			case 'message':
				$title = '站内消息';
				break;
			case 'profile':
				$title = '个人资料';
				break;
			case 'orders':
				$title = '个人订单';
				break;
			case 'siteorders':
				$title = '订单管理';
				break;
			case 'membership':
				$title = '会员信息';
				break;
			case 'affiliate':
				$title = '推广信息';
				break;
			case 'promote':
				$title = '优惠码管理';
				break;
			case 'following':
				$title = '我的关注';
				break;
			case 'follower':
				$title = '我的粉丝';
				break;
			case 'index':
				$title = '用户中心';
				break;
			default:
				$title = '文章';
		}
	} else {
		$title = '用户中心';
	}
	return $name . _get_delimiter() . $title . _get_delimiter() . get_bloginfo('name');
}
/* SEO title */
function um_ob_replace_title()
{
	ob_start('um_replace_title');
}
add_action('wp_loaded', 'um_ob_replace_title');
function um_replace_title($html)
{
	$blogname = get_bloginfo('name');
	$partten = array('/<title>(.*?)<\\/title>/i');
	$title = '';
	if ($action = get_query_var('action')) {
		switch ($action) {
			case 'signin':
				$title = __('登录', 'tt');
				break;
			case 'signup':
				$title = __('注册', 'tt');
				break;
			case 'activate':
				$title = __('激活注册', 'tt');
				break;
			case 'signout':
				$title = __('注销', 'tt');
				break;
			case 'findpass':
				$title = __('找回密码', 'tt');
				break;
			case 'resetpass':
				$title = __('重置密码', 'tt');
				break;
			case 'new':
				$title = __('发布文章', 'tt');
				break;
			case 'edit':
				$title = __('编辑文章', 'tt');
				break;
		}
		if ($title) {
			$replacement = array('<title>' . $title . _get_delimiter() . get_bloginfo('name') . '</title>');
			$html = preg_replace($partten, $replacement, $html);
		}
	}
	if ($oauth = get_query_var('oauth') && get_query_var('oauth_last')) {
		switch ($oauth) {
			case 'qq':
				$title = __('完善账户信息-连接QQ', 'tt');
				break;
			case 'weibo':
				$title = __('完善账户信息-连接微博', 'tt');
				break;
		}
		if ($title) {
			$replacement = array('<title>' . $title . _get_delimiter() . get_bloginfo('name') . '</title>');
			$html = preg_replace($partten, $replacement, $html);
		}
	}
	if ($site_manage = get_query_var('manage_child_route')) {
		switch ($site_manage) {
			case 'status':
				$title = __('站点统计', 'tt');
				break;
			case 'posts':
				$title = __('文章管理', 'tt');
				break;
			case 'comments':
				$title = __('评论管理', 'tt');
				break;
			case 'users':
				$title = __('用户管理', 'tt');
				break;
			case 'orders':
				$title = __('订单管理', 'tt');
				break;
			case 'coupons':
				$title = __('优惠码管理', 'tt');
				break;
			case 'members':
				$title = __('会员管理', 'tt');
				break;
			case 'products':
				$title = __('商品列表', 'tt');
				break;
			case 'editpost':
				$title = __('编辑文章', 'tt');
				break;
			default:
				$title = __('找不到该页面', 'tt');
				break;
		}
		if ($title) {
			$replacement = array('<title>' . $title . _get_delimiter() . get_bloginfo('name') . '</title>');
			$html = preg_replace($partten, $replacement, $html);
		}
	}
	if (is_author()) {
		$title = um_author_page_title();
		$replacement = array('<title>' . $title . '</title>');
		if (_hui('open_ucenter')) {
			$html = preg_replace($partten, $replacement, $html);
		} else {
			$html = $html;
		}
	}
	if (get_post_type() == 'store') {
		if (is_single()) {
			$title = get_the_title(get_the_ID()) . _get_delimiter() . $blogname;
			global $post;
			$post_ID = $post->ID;
			$seo_title = trim(get_post_meta($post_ID, 'title', true));
			if ($seo_title) {
				$title = $seo_title . _get_delimiter() . get_bloginfo('name');
			}
			$replacement = array('<title>' . $title . '</title>');
		} else {
			$title = _hui('store_archive_title', '商城') . _get_delimiter() . $blogname;
			$description = _hui('store_archive_des');
			$keywords = _hui('store_archive_subtitle');
			$keywords = explode('-', $keywords);
			$keywords = implode(',', $keywords);
			$replacement = array('<title>' . $title . '</title>');
			$partten[] = '/<meta name=\\"description\\" content=\\"(.*?)\\"(.*?)>/i';
			$replacement[] = '<meta name="description" content="' . $description . '"$2>';
			$partten[] = '/<meta name=\\"keywords\\" content=\\"(.*?)\\"(.*?)>/i';
			$replacement[] = '<meta name="keywords" content="' . $keywords . '"$2>';
		}
	}
	if ($title) {
		$html = preg_replace($partten, $replacement, $html);
	} else {
		$html = $html;
	}
	return $html;
}
function um_convertip($ip)
{
	$url = 'http://ip.taobao.com/service/getIpInfo.php';
	$data = array('ip' => $ip);
	$location = um_curl_post($url, $data);
	$location = json_decode($location);
	if ($location && !empty($location->data->country) && (!empty($location->data->region) || !empty($location->data->city))) {
		$data = $location->data;
		if ($data->country == '中国') {
			return $data->region . $data->city . ' ' . $data->isp;
		} else {
			return $data->country . $data->region;
		}
	} else {
		return '火星';
	}
}
function um_curl_post($url, $data)
{
	$post_data = http_build_query($data);
	$post_url = $url;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_URL, $post_url);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
	$return = curl_exec($ch);
	if (curl_errno($ch)) {
		return '';
	}
	curl_close($ch);
	return $return;
}
// Replace author home in comment loop
function um_comment_url_to_author_homepage($content)
{
	global $comment;
	$comment_ID = $comment->comment_ID;
	$user_id = (int) $comment->user_id;
	$url = get_comment_author_url($comment_ID);
	$author = get_comment_author($comment_ID);
	if ($user_id > 0) {
		$author_home = um_get_user_url('post', $user_id);
		$return = "<a href='" . $author_home . "' rel='external nofollow' class='url author_home' title='访问" . $author . "的个人主页'>{$author}</a>";
	} else {
		$return = $author;
	}
	return $return;
}
add_filter('get_comment_author_link', 'um_comment_url_to_author_homepage', 99);
// Romove admin_bar
//add_filter('show_admin_bar', '__return_false');
// Change default role
function um_default_role()
{
	if (get_option('default_role') != 'contributor') {
		update_option('default_role', 'contributor');
	}
}
add_action('admin_menu', 'um_default_role');
function um_allow_contributor_uploads()
{
	if (current_user_can('contributor') && !current_user_can('upload_files')) {
		$contributor = get_role('contributor');
		$contributor->add_cap('upload_files');
	}
}
add_action('admin_init', 'um_allow_contributor_uploads');
// Query products
function um_query_products($showposts = 4, $author = 0, $orderby = 'date')
{
	$args = array('post_type' => 'store', 'orderby' => $orderby, 'showposts' => $showposts);
	if ($author) {
		$args['author'] = $author;
	}
	$products_query = new WP_Query($args);
	//if( $products_query->have_posts() ){while ($products_query->have_posts()) : $products_query->the_post();
	return $products_query;
}
// Author products display depended on viptype
function um_author_products_display($showposts = 4, $author = 0, $orderby = 'date')
{
	$is_vip = getUserMemberType($author);
	if ($is_vip) {
		$author_arg = $author;
	} else {
		$author_arg = 0;
	}
	$products_query = um_query_products($showposts, $author_arg, $orderby);
	if ($products_query->have_posts()) {
		while ($products_query->have_posts()) {
			$products_query->the_post();
			if (has_post_thumbnail()) {
				$large_image_url = wp_get_attachment_image_src(get_post_thumbnail_id(), 'large');
				$imgsrc = $large_image_url[0];
			} else {
				$imgsrc = um_catch_first_image();
			}
			?>
	<li><a href="<?php 
			the_permalink();
			?>" title="<?php 
			the_title();
			?>" rel="bookmark" class="fancyimg">
		<div class="thumb-img">
			<img src="<?php 
			echo um_timthumb($imgsrc, 280, 180);
			?>" alt="<?php 
			the_title();
			?>">
			<span><i class="fa fa-shopping-cart"></i></span>
		</div>
		</a>
		<p><a href="<?php 
			the_permalink();
			?>" title="<?php 
			the_title();
			?>"><?php 
			the_title();
			?></a></p>
	</li>
<?php 
		}
	}
	wp_reset_query();
}
//user_cover
function _get_user_cover($user_id, $size = 'full', $default = '')
{
	if (!in_array($size, array('full', 'small'))) {
		$size = 'full';
	}
	if ($cover = get_user_meta($user_id, 'um_cover', true)) {
		if ($size == 'full') {
			return um_timthumb($cover, 1200, 300);
			// TODO size
		} else {
			return um_timthumb($cover, 350, 145);
		}
	}
	return $default ? $default : UM_URI . '/img/cover/1-' . $size . '.jpg';
}
function _format_count($number)
{
	$precision = 2;
	if ($number >= 1000 && $number < 10000) {
		$formatted = number_format($number / 1000, $precision) . 'K';
	} else {
		if ($number >= 10000 && $number < 1000000) {
			$formatted = number_format($number / 10000, $precision) . 'W';
		} else {
			if ($number >= 1000000 && $number < 1000000000) {
				$formatted = number_format($number / 1000000, $precision) . 'M';
			} else {
				if ($number >= 1000000000) {
					$formatted = number_format($number / 1000000000, $precision) . 'B';
				} else {
					$formatted = $number;
					// Number is less than 1000
				}
			}
		}
	}
	$formatted = str_replace('.00', '', $formatted);
	return $formatted;
}
function author_post_field_count($post_type, $author_id, $type)
{
	global $post;
	$raw = get_posts(array('posts_per_page' => -1, 'post_type' => $post_type, 'post_status' => 'publish', 'author' => $author_id));
	$count = 0;
	if ($type == 'um_post_likes') {
		foreach ($raw as $post) {
			$umlikes = get_post_meta($post->ID, 'um_post_likes', true);
			$umlikes_array = explode(',', $umlikes);
			$likes = $umlikes ? count($umlikes_array) : 0;
			$_count = absint($likes);
			$count += $_count;
		}
	} else {
		foreach ($raw as $post) {
			$_count = absint(get_post_meta($post->ID, $type, true));
			$count += $_count;
		}
	}
	$number = _format_count($count);
	wp_reset_postdata();
	return $number;
}
// Add vipsaler role
//add_role('vipsaler','VIP商家',array('upload_files'=>true,'edit_posts'=>true,'edit_published_posts'=>true,'publish_posts'=>true,'read'=>true));
// Set role
function um_set_role($uid, $role = 'contributor')
{
	$uid = (int) $uid;
	if (!$uid) {
		return;
	}
	$user = new WP_User($uid);
	$user->set_role($role);
}