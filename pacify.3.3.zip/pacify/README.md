Pacify is a clean, responsive theme that can be used for all kinds of blogs. It is a two column theme that uses subtle image patterns for background and some beautiful Google fonts across the board. 
Pacify WordPress Theme is derived from Underscores Theme(_s).
Pacify WordPress Theme is distributed under the terms of the GNU GPL
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Image Sources(All Images licensed under CC0): 
-Large Images in Thumbnail taken from unsplash.com: https://unsplash.com/photos/EhqI7RRwHrE/download and https://unsplash.com/photos/M3CIuMoFkAY/download(License Information: https://unsplash.com/license)
-Background pattern licensed under the terms of CC0
-Icons from: http://pixabay.com/en/comments-posts-speak-talk-97860/ and http://pixabay.com/en/icon-set-zoom-map-pin-weather-594380/

Fonts:
Pacify uses Lobster and Raleway fonts via Google Web Fonts. Licensed under SIL Open Font License. http://www.google.com/fonts/specimen/Lato 

