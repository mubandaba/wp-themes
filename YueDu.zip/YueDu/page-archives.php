<?php
/*
Template Name: Archives
*/
?>
<?php get_header(); ?>

</head><body>

<div class="container">
	<div id="wrap">
	<div id="widget">
	<div class="logo"><a href="/"></a></div>
		<div class="thumb">
		<img src="<?php bloginfo('stylesheet_directory'); ?>/images/green.jpg" />
		</div>
		<div class="cover"></div>
<?php get_footer(); ?>
	</div>
	</div>
	<div id="content">
		<div class="title">
		<?php the_title(); ?>
		</div>
<script type="text/javascript">
jQuery(document).ready(
function($){
/* 存档页面 jQ伸缩 */
 $('#expand_collapse,.archives-yearmonth').css({cursor:"s-resize"});
 $('#archives ul li ul.archives-monthlisting').hide();
 $('#archives ul li ul.archives-monthlisting:first').show();
 $('#archives ul li span.archives-yearmonth').click(function(){$(this).next().slideToggle('fast');return false;});
 //以下下是全局的操作
 $('#expand_collapse').toggle(
 function(){
 $('#archives ul li ul.archives-monthlisting').slideDown('fast');
 },
 function(){
 $('#archives ul li ul.archives-monthlisting').slideUp('fast');
 });
});
</script>
		<div class="info">
		
		</div>
		<div class="entry">
		<a id="expand_collapse" href="#">全部展开/收缩</a>
		<div id="archives"><?php archives_list_SHe(); ?></div>
		</div>
		<div class="mark"></div>
		<div id="bottom">
		<div class="share">
		<span>分享</span>
		<ul class="sns">
		<div class="bshare-custom">
		<li><a title="分享到QQ空间" class="bshare-qzone"></a></li>
		<li><a title="分享到新浪微博" class="bshare-sinaminiblog"></a></li>
		<li><a title="分享到人人网" class="bshare-renren"></a></li>
		<li><a title="分享到腾讯微博" class="bshare-qqmb"></a></li>
		<li><a title="分享到豆瓣" class="bshare-douban"></a></li>
		<li><a title="更多平台" class="bshare-more bshare-more-icon more-style-addthis"></a></li></div>
		</ul>
		</div>
		</div>
	</div>	
<script type="text/javascript" charset="utf-8" src="http://static.bshare.cn/b/buttonLite.js#style=-1&amp;uuid=&amp;pophcol=1&amp;lang=zh"></script><script type="text/javascript" charset="utf-8" src="http://static.bshare.cn/b/bshareC0.js"></script>
</div>
</body>
</html>