<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html">
<meta charset="utf-8">
<title><?php if ( is_tag() ) {
echo wp_title('Tag:');if($paged > 1) printf(' - 第%s页',$paged);echo ' | '; bloginfo( 'name' );
} elseif ( is_archive() ) {
echo wp_title('');  if($paged > 1) printf(' - 第%s页',$paged);    echo ' | ';    bloginfo( 'name' );
} elseif ( is_search() ) {
echo '&quot;'.wp_specialchars($s).'&quot;的搜索结果 | '; bloginfo( 'name' );
} elseif ( is_home() ) {
bloginfo( 'name' );$paged = get_query_var('paged'); if($paged > 1) printf(' - 第%s页',$paged);
}  elseif ( is_404() ) {
echo '页面不存在！ | '; bloginfo( 'name' );
} else {
echo wp_title( ' | ', false, right )  ; bloginfo( 'name' );
} ?></title> 
<?php
if(is_single()) {
if($post->post_excerpt) {
$description = $post->post_excerpt;
} else {
$description = mb_strimwidth(strip_tags($post->post_content), 0, 220);
}

$keywords = "";
$tags = wp_get_post_tags($post->ID);

foreach($tags as $tag) {
$keywords = $keywords . $tag->name . ", ";
}
} else {
if($options['description']) {
$description = $options['description'];
} else {
$description = get_bloginfo('description');
}

$keywords = "阅读";
}
?>
<meta name="keywords" content="<?php echo $keywords?>">
<meta name="description" property="og:description" itemprop="description" content="<?php echo $description?>">
<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_directory'); ?>/style.css" />
<link rel="alternate" type="application/rss+xml" title="木偶·阅读 RSS Feed" href="http://mooo.me/feed" />
<link rel="alternate" type="application/atom+xml" title="木偶·阅读 Atom Feed" href="http://mooo.me/feed/atom" />
<link rel="pingback" href="http://mooo.me/xmlrpc.php" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.min.js"></script>
<script type="text/javascript">
//页面淡入淡出
$(document).ready(function(){
$("#content").css("display","none");
$("#content").fadeIn("fast");
$("a[target],a[href*='javascript'],a.lightbox-processed,a[href*='#']").addClass("speciallinks");
$("a:not(.speciallinks)").click(function(){
$("#content").fadeOut("fast");
$("object,embed").css("","hidden");
});
});
</script>