<?php get_header(); ?>

</head><body>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="container">
	<div id="wrap">
	<div id="widget">
	<div class="logo"><a href="/"></a></div>
		<div class="thumb">
		<?php if ( has_post_thumbnail() ) { the_post_thumbnail('thumb',array('alt' => trim(strip_tags( $post->post_title )))); } else {echo '<img border="0" src="'.get_bloginfo('template_url').'/images/noimage.jpg" />'; } ?>
		</div>
		<div class="cover"></div>
<?php get_footer(); ?>
	</div>
	</div>
	<div id="content">
	<div class="next">
	<a href="<?php echo get_option('home'); ?>/next">
	</a>		
	</div>
		<div class="title">
		<?php the_title(); ?>
		</div>
		<div class="info">
		□ 来自:文·<?php if ( get_post_meta($post->ID, 'author', true) ) : echo get_post_meta($post->ID, 'author', true); else: the_author_nickname(); endif; ?> 来源·<?php if ( get_post_meta($post->ID, 'from', true) ) : echo get_post_meta($post->ID, 'from', true); else: bloginfo( 'name' ); endif; ?>
		</div>
		<div class="entry">
		<?php the_content(); ?>
		</div>
		<div class="mark"></div>
		<div id="bottom">
		<div class="share">
		<span>分享</span>
		<ul class="sns">
		<div class="bshare-custom">
		<li><a title="分享到QQ空间" class="bshare-qzone"></a></li>
		<li><a title="分享到新浪微博" class="bshare-sinaminiblog"></a></li>
		<li><a title="分享到人人网" class="bshare-renren"></a></li>
		<li><a title="分享到腾讯微博" class="bshare-qqmb"></a></li>
		<li><a title="分享到豆瓣" class="bshare-douban"></a></li>
		<li><a title="更多平台" class="bshare-more bshare-more-icon more-style-addthis"></a></li></div>
		</ul>
		</div>
		</div>
	</div>	
<script type="text/javascript" charset="utf-8" src="http://static.bshare.cn/b/buttonLite.js#style=-1&amp;uuid=&amp;pophcol=1&amp;lang=zh"></script><script type="text/javascript" charset="utf-8" src="http://static.bshare.cn/b/bshareC0.js"></script>
</div>
<?php endwhile; endif; ?>
</body>
</html>