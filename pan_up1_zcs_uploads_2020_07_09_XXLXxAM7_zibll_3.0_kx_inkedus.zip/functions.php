<?php
require get_stylesheet_directory() . '/functions-theme.php';

/**
 * 子比主题
 * Zibll Theme
 * 官方网站：https://www.zibll.com/
 * 作者QQ：770349780
 * 感谢您使用子比主题，主题源码有详细的注释，支持二次开发
 * 如您需要定制功能、或者其它任何交流欢迎加QQ
 */

 /**
  * 此文件是存放主题自定义函数的地方
  * 请将您的代码放置在下方
  * 主题更新请自行备份您的自定义代码
  */
