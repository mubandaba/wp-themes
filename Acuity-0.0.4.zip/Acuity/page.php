<?php get_header(); ?>
			<div class="page">
				<div class="uk-container uk-container-center">
                    <?php
                    $um_ad_top = _umtu('um_ad_top');
                    if (!empty($um_ad_top['um_ad_top_title_1'])){
                        $um_ad_top_title_1 = $um_ad_top['um_ad_top_title_1'];
                    }
                    if (!empty($um_ad_top['um_ad_top_img_1'])){
                        $um_ad_top_img_1 = $um_ad_top['um_ad_top_img_1'];
                        $um_ad_top_img_1_id = $um_ad_top['um_ad_top_img_1']['id'];
                        $um_ad_top_img_1_url =  wp_get_attachment_image_url($um_ad_top_img_1_id,'full');
                    }
                    if (!empty($um_ad_top['um_ad_top_link_1'])){
                        $um_ad_top_link_1 = $um_ad_top['um_ad_top_link_1'];
                    }
                    if (!empty($um_ad_top['um_ad_top_title_2'])){
                        $um_ad_top_title_2 = $um_ad_top['um_ad_top_title_2'];
                    }
                    if (!empty($um_ad_top['um_ad_top_img_2'])){
                        $um_ad_top_img_2 = $um_ad_top['um_ad_top_img_2'];
                        $um_ad_top_img_2_id = $um_ad_top['um_ad_top_img_2']['id'];
                        $um_ad_top_img_2_url =  wp_get_attachment_image_url($um_ad_top_img_2_id,'full');
                    }
                    if (!empty($um_ad_top['um_ad_top_link_2'])){
                        $um_ad_top_link_2 = $um_ad_top['um_ad_top_link_2'];
                    }
                    ?>
                    <div class="uk-grid uk-hidden-small">
                        <?php if($um_ad_top_img_1):?>
                            <div class="uk-width-1-2">
                                <div class="category-zz uk-padding-small">
                                    <a href="<?php echo $um_ad_top_link_1?>" target="_blank">
                                        <img src="<?php echo $um_ad_top_img_1_url?>" class="b-r-4">
                                    </a>
                                </div>
                            </div>
                        <?php endif;if ($um_ad_top_img_1):?>
                            <div class="uk-width-1-2">
                                <div class="category-zz uk-padding-small">
                                    <a href="" target="_blank">
                                        <img src="<?php echo $um_ad_top_img_2_url?>" class="b-r-4">
                                    </a>
                                </div>
                            </div>
                        <?php endif;?>
                    </div>
                    <?php umtu_breadcrumbs();?>
					<div class="uk-block-default b-r-4">
						<?php while ( have_posts() ) : the_post(); ?>

						<div class="single-content">
							<?php the_content(); ?>
						</div>
						<?php endwhile; ?>

					</div>

				</div>
				<div class="uk-container uk-container-center uk-margin-large-top">
					<?php comments_template( '', true ); ?>
				</div>
			</div>

<?php get_footer(); ?>