<footer id="footer" class="footer uk-block-secondary uk-overflow-hidden uk-margin-large-top">
    <div class="uk-container uk-container-center">
        <div class="foot uk-grid">
            <?php
            wp_nav_menu( array(
                'theme_location' => 'foot_menu',
                'menu'   => 'foot_menu',
                'container'  => 'nav',
                'container_class' => 'foot-nav uk-overflow-container uk-width-1-1 uk-width-large-1-2',//ul父节点class值
                'menu_id'   => '',
                'echo'  => true,
                'depth' => 1,
            ) );
            ?>
            <div class="foot-social uk-width-1-2 uk-text-right uk-hidden-small">

                <?php
                    $um_foot_icp = _umtu('um_foot_icp');
                    $um_foot_email = _umtu('um_foot_email');
                    $um_foot_qq = _umtu('um_foot_qq');
                    $um_foot_weibo = _umtu('um_foot_weibo');
                    if ($um_foot_email):
                ?>
                <a href="mailto:<?php echo $um_foot_email;?>"><i class="iconfont icon-email"></i></a>
                <?php endif;if ($um_foot_qq):?>
                <a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $um_foot_qq?>&site=qq&menu=yes" target="_blank"><i class="iconfont icon-QQ"></i></a>
                <?php endif;if ($um_foot_weibo):?>
                <a href="<?php echo $um_foot_weibo?>"><i class="iconfont icon-weibo"></i></a>
                <?php endif?>
            </div>
        </div>

        <div class="foot-cop uk-text-center uk-overflow-container">
            <?php if ($um_foot_icp):?>
            <span><a href="http://www.beian.miit.gov.cn/state/outPortal/loginPortal.action"><?php echo $um_foot_icp?></a></span>
            <?php endif; global $user_ID; if( $user_ID && current_user_can('level_10') ) : ?>
                <span>加载时间：<?php timer_stop(1); ?></span>
            <?php endif; ?>
            <span> 2019 - Copyright <a href="<?php bloginfo('url');?>" target="_blank"><?php bloginfo('name');?></a></span>
            <span>本站主题 <?php echo get_template()?> By <a href="https://www.joytheme.com" target="_blank">JOYtheme&阿叶</a></span>
        </div>
    </div>
    <div class="go-top uk-animation-slide-bottom">
        <a id="go-top">
            <i class="iconfont icon-icon-test23"></i>
        </a>
        <a href="#wx" data-uk-modal>
            <i class="iconfont icon-wechat-fill"></i>
        </a>
        <a id="go-bottom">
            <i class="iconfont icon-icon-test25"></i>
        </a>
    </div>
    <!-- gotop -->
    <!-- 微信弹窗 -->
    <div id="wx" class="uk-modal">
        <div class="uk-modal-dialog b-r-4">
            <a class="uk-modal-close uk-close"></a>
            <div class="part-title uk-text-center">
                <?php
                    $qrcode_modal = _umtu('qrcode_modal');
                    $qrcode_title = $qrcode_modal['qrcode_title'];
                    $qrcode_img = $qrcode_modal['qrcode_img'];
                    $qrcode_img_url = wp_get_attachment_image_url($qrcode_img['id']);
                ?>
                <h3 class="uk-display-inline-block uk-position-relative"><?php echo $qrcode_title?></h3>
                <p class="uk-text-center">
                    <img src="<?php echo $qrcode_img_url;?>">
                </p>
            </div>
        </div>
    </div>
    <!-- 微信弹窗 -->

    <div id="search" class="uk-modal">
        <div class="uk-modal-dialog b-r-4">
            <a class="uk-modal-close uk-close"></a>
            <div class="part-title uk-text-center">
                <h3 class="uk-display-inline-block uk-position-relative">搜索</h3>
            </div>
            <div class="search">
                <?php
                    $search_placeholder = _umtu('search_placeholder');
                    if (empty($search_placeholder)){$search_placeholder='输入关键词进行搜索...';}
                    $hot_keys = _umtu('hot_key');
                ?>
                <form method="get" class="uk-form uk-position-relative" action="<?php bloginfo('url');?>">
                    <input type="search" placeholder="<?php echo $search_placeholder?>" autocomplete="off" value="" name="s"
                           required="required" class="search-input uk-form-large">
                    <button type="submit" class="search-button uk-position-absolute">
                        <i class="iconfont icon-sousuo"></i>
                    </button>
                </form>
                <div class="home-seach-hot seach-hot uk-margin-top uk-margin-bottom">
                    <?php  if ($hot_keys):?>
                    <strong>热搜: </strong>
                    <?php foreach ($hot_keys as $hot_key):?>
                        <a href="<?php bloginfo('url');?>/?s=<?php echo $hot_key['hot_search_key']?>" target="_blank"><?php echo $hot_key['hot_search_key']?></a>
                    <?php endforeach;endif;?>
                </div>
            </div>
        </div>
    </div>
    <!-- 搜索弹窗 -->
</footer>
</div>
<?php wp_footer();?>
</body>
</html>
