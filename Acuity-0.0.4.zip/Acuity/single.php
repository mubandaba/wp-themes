<?php
    get_header();
    if (have_posts()):while (have_posts()):the_post();
    $cats = get_the_category()[0]->term_id;
?>
        <main>
            <div class="single">
                <div class="uk-container uk-container-center ">
                    <?php 
                        $um_ad_top = _umtu('um_ad_top');
                        if (!empty($um_ad_top['um_ad_top_title_1'])){
                            $um_ad_top_title_1 = $um_ad_top['um_ad_top_title_1'];
                        }
                        if (!empty($um_ad_top['um_ad_top_img_1'])){
                            $um_ad_top_img_1 = $um_ad_top['um_ad_top_img_1'];
                            $um_ad_top_img_1_id = $um_ad_top['um_ad_top_img_1']['id'];
                            $um_ad_top_img_1_url =  wp_get_attachment_image_url($um_ad_top_img_1_id,'full');
                        }
                        if (!empty($um_ad_top['um_ad_top_link_1'])){
                            $um_ad_top_link_1 = $um_ad_top['um_ad_top_link_1'];
                        }
                        if (!empty($um_ad_top['um_ad_top_title_2'])){
                            $um_ad_top_title_2 = $um_ad_top['um_ad_top_title_2'];
                        }
                        if (!empty($um_ad_top['um_ad_top_img_2'])){
                            $um_ad_top_img_2 = $um_ad_top['um_ad_top_img_2'];
                            $um_ad_top_img_2_id = $um_ad_top['um_ad_top_img_2']['id'];
                            $um_ad_top_img_2_url =  wp_get_attachment_image_url($um_ad_top_img_2_id,'full');
                        }
                        if (!empty($um_ad_top['um_ad_top_link_2'])){
                            $um_ad_top_link_2 = $um_ad_top['um_ad_top_link_2'];
                        }
                        if (!empty($um_ad_top_img_1_url)||!empty($um_ad_top_img_2_url)):
                    ?>
                    <div class="uk-grid uk-hidden-small">
                        <?php if($um_ad_top_img_1):?>
                        <div class="uk-width-1-2">
                            <div class="category-zz uk-padding-small">
                                <a href="<?php echo $um_ad_top_link_1?>" target="_blank">
                                    <img src="<?php echo $um_ad_top_img_1_url?>" class="b-r-4">
                                </a>
                            </div>
                        </div>
                        <?php endif;if ($um_ad_top_img_1):?>
                        <div class="uk-width-1-2">
                            <div class="category-zz uk-padding-small">
                                <a href="" target="_blank">
                                    <img src="<?php echo $um_ad_top_img_2_url?>" class="b-r-4">
                                </a>
                            </div>
                        </div>
                        <?php endif;?>
                    </div>
                    <?php endif;?>
                    <div class="crumb">
                        <?php umtu_breadcrumbs();?>
                    </div>
                    <div class="uk-grid">
                        <?php
                            $um_sidebar_set = _umtu('um_sidebar_set');
                            if ($um_sidebar_set =='0'){
                                $width = '';
                            }else{
                                $width = 'uk-width-medium-7-10 uk-width-large-7-10';
                            }
                        ?>
                        <div class="uk-width-1-1 uk-width-small-1-1 <?php echo $width?>">
                            <div class="uk-block-default b-r-4">

                                <header class="single-head b-b uk-nbfc">
                                    <div class="uk-grid">
                                        <div class="uk-width-1-1">
                                            <div class="single-title">
                                                <h2><?php the_title()?></h2>
                                                <div class="single-data">
                                                    <span><i class="iconfont icon-rili"></i><?php the_time('Y-m-d');?></span>
                                                    <span class="uk-hidden-small"><i class="iconfont icon-message"></i><?php comments_number('0','1','% '); ?></span>
                                                    <span><i class="iconfont icon-eye"></i><?php post_views('', ''); ?></span>
                                                    <span><?php edit_post_link('<i class="iconfont icon-bianji"></i>编辑'); ?></span>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </header>

                                <div class="single-content">
                                    <?php
                                        $um_ad_cont = _umtu('um_ad_cont');
                                        if (!empty($um_ad_cont['um_ad_cont_title'])){
                                            $um_ad_cont_title = $um_ad_cont['um_ad_cont_title'];
                                        }
                                        if (!empty($um_ad_cont['um_ad_cont_img'])){
                                            $um_ad_cont_img = $um_ad_cont['um_ad_cont_img'];
                                            $um_ad_cont_img_id = $um_ad_cont['um_ad_cont_img']['id'];
                                            $um_ad_cont_img_url =  wp_get_attachment_image_url($um_ad_cont_img_id,'full');
                                        }
                                        if (!empty($um_ad_cont['um_ad_cont_link'])){
                                            $um_ad_cont_link = $um_ad_cont['um_ad_cont_link'];
                                        }
                                        if($um_ad_cont_img_id):
                                    ?>
                                    <div>
                                        <a href="<?php echo $um_ad_cont_link?>" target="_blank">
                                            <img src="<?php echo $um_ad_cont_img_url?>" class="b-r-4">
                                        </a>
                                    </div>
                                    <?php endif;
                                        the_content();
                                        $um_reward_set = _umtu('um_reward_set');
                                        $um_zan_set = _umtu('um_zan_set');
                                        $um_article_set = _umtu('um_article_set');
                                        $um_poster_set = _umtu('um_poster_set');
                                    ?>
                                    <div class="zan uk-margin-large-top">
                                        <?php if ($um_zan_set=='1'){?>
                                        <a href="javascript:;" data-action="topTop" data-id="<?php echo get_the_ID(); ?>" class="b-r-4 dotGood <?php echo isset($_COOKIE['dotGood_' . get_the_ID()]) ? 'done' : ''; ?>">
                                            <i class="iconfont icon-like-fill"></i>(<span class="count"><?php echo ($dot_good=get_post_meta(get_the_ID(), 'dotGood', true)) ? $dot_good : '0'; ?></span>)
                                        </a>
                                        <?php } if ($um_zan_set == '1'){?>
                                        <a href="#reward" data-uk-modal=""  class="reward more b-r-4">
                                            <i class="iconfont icon-icon-test20"></i><span class="count">打赏</span>
                                        </a>
                                        <?php }if($um_poster_set){
                                            xyz_poster_share();
                                        }?>

                                    </div>

                                    <div id="reward" class="uk-modal">
                                        <div class="uk-modal-dialog b-r-4">
                                            <a class="uk-modal-close uk-close"></a>
                                            <div class="part-title uk-text-center">
                                                <?php
                                                    $um_reward_code = _umtu('um_reward_code');
                                                    if ($um_reward_code){
                                                        $qrcode_img_url = wp_get_attachment_image_url($um_reward_code['id']);
                                                    }
                                                ?>
                                                <p class="uk-text-center"><img src="<?php echo $qrcode_img_url;?>"></p>
                                            </div>
                                        </div>
                                    </div>

                                    <?php if(has_tag()){?>
                                    <div class="single-tags uk-text-left uk-margin-large-top">
                                        <i class="iconfont icon-tag"></i><?php the_tags('', ',') ?>
                                    </div>
                                    <?php } if ($um_article_set=='1'){ $um_article_cop =_umtu('um_article_cop');?>
                                    <div class="uk-alert uk-alert-warning single-warning uk-text-left b-r-4 uk-margin-large-top uk-text-break" data-uk-alert="">
                                        <a href="" class="uk-alert-close uk-close"></a>
                                        <p class="uk-margin-remove">标题：<?php the_title()?></p>
                                        <p class="uk-margin-remove">分类：<?php the_category(' ') ?></p>
                                        <p class="uk-margin-remove">链接：<?php echo get_the_permalink()?></p>
                                        <p class="uk-margin-remove">版权：<?php if ($um_article_cop){echo $um_article_cop;}else{echo '本文部分图文来源于网络，如有侵权，请及时联系我们，我们将在24小时内删除，或联系作者征求允许。';}?></p>
                                    </div>
                                    <?php }?>
                                </div>


                            </div>
                            <?php $next_post = get_next_post();$prev_post = get_previous_post();?>
                            <div class="turn-page">
                                <div class="uk-grid">
                                    <?php if ($prev_post){?>
                                    <div class="uk-width-1-2 mb-per">
                                        <figure class="turn-page-thumb uk-overlay uk-overlay-hover b-r-4">
                                            <img width="1024" height="1003" src="<?php umtu_thumb('full');?>" class="attachment- size- wp-post-image" alt=""/>
                                            <a href="<?php echo get_permalink( $prev_post )?>" >
                                                <figcaption class="uk-overlay-panel uk-ignore uk-overlay-background">
                                                    <p class="uk-margin-bottom">上一篇</p>
                                                    <i class="iconfont icon-icon-test24"></i><?php echo $prev_post->post_title?>
                                                </figcaption>
                                            </a>
                                        </figure>
                                    </div>
                                    <?php }if ($next_post){?>
                                    <div class="uk-width-1-2 mb-per mb-per2">
                                        <figure class="turn-page-thumb uk-overlay uk-overlay-hover b-r-4">
                                            <img width="1024" height="1008" src="<?php umtu_thumb('full');?>" class="attachment- size- wp-post-image" alt=""/>
                                            <a href="<?php echo get_permalink( $next_post )?>">
                                                <figcaption class="uk-overlay-panel uk-ignore uk-overlay-background uk-text-right">
                                                    <p class="uk-margin-bottom">下一篇</p>
                                                    <?php echo $next_post->post_title?>
                                                    <i class="iconfont icon-icon-test26"></i>
                                                </figcaption>
                                            </a>
                                        </figure>
                                    </div>
                                    <?php }?>
                                </div>
                            </div>
                            <div class="single-bottom uk-margin-top">
                                <?php include 'template_parts/single_recommend.php';comments_template('', true); ?>
                            </div>
                        </div>
                        <?php if ($um_sidebar_set=='1'){get_sidebar();}?>
                    </div>
                </div>
            </div>
        </main>
<?php endwhile;endif;get_footer();?>