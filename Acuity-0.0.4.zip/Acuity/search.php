<?php get_header(); ?>
	<div class="search">
		<div class=" uk-block-default b-t">
			<div class="uk-container uk-container-center">
				<div class="page-top part-title">
					<h3><?php printf( __( ' %s', 'tanhaibonet' ), '<span>' . get_search_query() . '</span>' ); ?></h3>
					<p class="uk-text-muted"><?php printf( __( '搜索「%s」的结果如下：', 'tanhaibonet' ), '<span>' . get_search_query() . '</span>' ); ?></p>
				</div>
			</div>
		</div>

		<div class="uk-container uk-container-center">
			<?php umtu_breadcrumbs();?>
			<div class="pic-list uk-grid uk-grid-medium" data-uk-grid >
				<?php if (have_posts()) : while (have_posts()) : the_post();$author_id = get_post_field( 'post_author', $post_id );?>
				<div class="uk-width-1-1 uk-width-small-1-1 uk-width-medium-1-2 uk-width-large-1-4 uk-margin-bottom">
                    <figure class="pic-item shadow uk-block-default uk-margin-bottom uk-nbfc b-r-4">

                        <div class="uk-overlay pic-item-cover uk-overlay-hover">
                            <a href="<?php the_permalink();?>" target="_blank">
                                <img class="uk-overlay-scale" src="<?php the_post_thumbnail_url();?>" alt="<?php the_title()?>">
                            </a>
                        </div>
                        <div class="item-info uk-margin-left uk-margin-right">
                            <div class="author">
                        <span class="s-avatar rotate uk-display-block">
                            <a href="<?php echo get_author_posts_url($author_id)?>" target="_blank">
                                <img src="<?php umtu_author_img($author_id);?>"
                                     class="avatar avatar-200 photo" height="200" width="200"/>
                            </a>
                        </span>
                                <span class="uk-text-muted uk-margin-small-left uk-margin-small-top"><?php the_author_meta('nickname',$author_id);?></span>
                            </div>
                            <div class="category uk-margin-small-top">
                                <?php $cat_lists = get_the_category();if ($cat_lists):foreach ($cat_lists as $cat_list):$cat_list_link= get_category_link($cat_list->term_id)?>
                                    <a href="<?php echo $cat_list_link?>" rel="category tag"><?php echo $cat_list->name?></a>
                                <?php endforeach;endif;?>
                            </div>
                            <h3 class="uk-margin-top">
                                <a href="<?php the_permalink();?>" target="_blank"><?php the_title()?></a>
                            </h3>
                            <p class="uk-text-muted"></p>
                            <div class="data uk-text-small uk-margin-bottom uk-margin-top">
                                <span class="uk-margin-right"><i class="iconfont icon-rili"></i><?php the_time('Y-m-d');?></span>
                                <span class="uk-margin-right"><i class="iconfont icon-eye"></i>80</span>
                                <span class="uk-hidden-small"><i class="iconfont icon-message"></i>0</span>
                            </div>
                        </div>
                    </figure>
				</div>
				<?php endwhile; else: ?>
			</div>
			<div class="uk-alert uk-alert-warning uk-text-center">抱歉，您搜索的内容暂时没有任何收录！</div>
				<?php endif; ?>
			<div class="fenye">
				<?php umtu_pagenavi(); ?>
			</div>
		</div>
	</div>
<?php get_footer(); ?>



