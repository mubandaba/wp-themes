<?php get_header();?>
    <main>
        <?php include 'template_parts/search.php'?>
        <div class="uk-container uk-container-center">
            <?php
            include 'template_parts/cat_list.php';
            $cat_cms = _umtu('cat_cms');
            if ($cat_cms){
                foreach ($cat_cms as $cms){
                    $cms_layout = $cms['cms_layout'];
                    switch ($cms_layout) {
                        case 'grid':
                            include 'template_parts/grid.php';
                            break;
                        case 'list':
                            include 'template_parts/list.php';
                            break;
                        case 'waterfall':
                            include 'template_parts/waterfall.php';
                            break;
                        default:
                            include 'template_parts/grid.php';
                    }
                }
            }
            $um_homelink_set = _umtu('um_homelink_set');
            if ($um_homelink_set=='1'){
                include 'template_parts/friend_link.php';
            }
            ?>
        </div>
    </main>
<?php get_footer();?>