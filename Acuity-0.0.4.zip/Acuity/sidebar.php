<div class="uk-width-3-10 uk-hidden-small">
    <?php include 'template_parts/author-info.php'?>
    <div class="uk-margin-large-top">
        <div class="box uk-block-default  b-r-4">
            <div class="box-title b-b b-t">
                <h3><i class="iconfont icon-dingdan"></i> 热门文章</h3>
            </div>
            <div class="box-main">
                <div class="box-list">
                    <?php
                    $args = array('showposts' => 8,'meta_key' => 'umtu_view','orderby' => 'meta_value_num',);
                    $query_posts = new WP_Query();
                    $query_posts->query($args);
                    while ($query_posts->have_posts()) : $query_posts->the_post();?>
                        <li class="b-b">
                            <a href="<?php the_permalink(); ?>" ><?php the_title(); ?></a>
                        </li>
                    <?php endwhile; wp_reset_query(); ?>
                </div>
            </div>
        </div>
        <div class="box uk-block-default b-r-4">
            <div class="box-title b-b b-t">
                <h3><i class="iconfont icon-dingdan"></i> 最新评论</h3>
            </div>
            <div class="box-main new-comment">
                <?php umtu_recent_comments()?>
            </div>
        </div>
    </div>
</div>