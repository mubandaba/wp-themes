/* http://prismjs.com/download.html?themes=prism-okaidia&languages=markup+css+clike+javascript+c+java+json+markdown+php+python+sql&plugins=line-numbers+highlight-keywords+remove-initial-line-feed+data-uri-highlight */
var _self = "undefined" != typeof window ? window : "undefined" != typeof WorkerGlobalScope && self instanceof WorkerGlobalScope ? self : {}
    , Prism = function() {
    var e = /\blang(?:uage)?-(\w+)\b/i
        , t = 0
        , n = _self.Prism = {
            manual: _self.Prism && _self.Prism.manual,
            disableWorkerMessageHandler: _self.Prism && _self.Prism.disableWorkerMessageHandler,
            util: {
                encode: function(e) {
                    return e instanceof a ? new a(e.type,n.util.encode(e.content),e.alias) : "Array" === n.util.type(e) ? e.map(n.util.encode) : e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ")
                },
                type: function(e) {
                    return Object.prototype.toString.call(e).match(/\[object (\w+)\]/)[1]
                },
                objId: function(e) {
                    return e.__id || Object.defineProperty(e, "__id", {
                        value: ++t
                    }),
                        e.__id
                },
                clone: function(e) {
                    var t = n.util.type(e);
                    switch (t) {
                        case "Object":
                            var a = {};
                            for (var r in e)
                                e.hasOwnProperty(r) && (a[r] = n.util.clone(e[r]));
                            return a;
                        case "Array":
                            return e.map(function(e) {
                                return n.util.clone(e)
                            })
                    }
                    return e
                }
            },
            languages: {
                extend: function(e, t) {
                    var a = n.util.clone(n.languages[e]);
                    for (var r in t)
                        a[r] = t[r];
                    return a
                },
                insertBefore: function(e, t, a, r) {
                    r = r || n.languages;
                    var l = r[e];
                    if (2 == arguments.length) {
                        a = arguments[1];
                        for (var i in a)
                            a.hasOwnProperty(i) && (l[i] = a[i]);
                        return l
                    }
                    var o = {};
                    for (var s in l)
                        if (l.hasOwnProperty(s)) {
                            if (s == t)
                                for (var i in a)
                                    a.hasOwnProperty(i) && (o[i] = a[i]);
                            o[s] = l[s]
                        }
                    return n.languages.DFS(n.languages, function(t, n) {
                        n === r[e] && t != e && (this[t] = o)
                    }),
                        r[e] = o
                },
                DFS: function(e, t, a, r) {
                    r = r || {};
                    for (var l in e)
                        e.hasOwnProperty(l) && (t.call(e, l, e[l], a || l),
                            "Object" !== n.util.type(e[l]) || r[n.util.objId(e[l])] ? "Array" !== n.util.type(e[l]) || r[n.util.objId(e[l])] || (r[n.util.objId(e[l])] = !0,
                                n.languages.DFS(e[l], t, l, r)) : (r[n.util.objId(e[l])] = !0,
                                n.languages.DFS(e[l], t, null, r)))
                }
            },
            plugins: {},
            highlightAll: function(e, t) {
                var a = {
                    callback: t,
                    selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
                };
                n.hooks.run("before-highlightall", a);
                for (var r, l = a.elements || document.querySelectorAll(a.selector), i = 0; r = l[i++]; )
                    n.highlightElement(r, e === !0, a.callback)
            },
            highlightElement: function(t, a, r) {
                for (var l, i, o = t; o && !e.test(o.className); )
                    o = o.parentNode;
                o && (l = (o.className.match(e) || [, ""])[1].toLowerCase(),
                    i = n.languages[l]),
                    t.className = t.className.replace(e, "").replace(/\s+/g, " ") + " language-" + l,
                t.parentNode && (o = t.parentNode,
                /pre/i.test(o.nodeName) && (o.className = o.className.replace(e, "").replace(/\s+/g, " ") + " language-" + l));
                var s = t.textContent
                    , g = {
                    element: t,
                    language: l,
                    grammar: i,
                    code: s
                };
                if (n.hooks.run("before-sanity-check", g),
                !g.code || !g.grammar)
                    return g.code && (n.hooks.run("before-highlight", g),
                        g.element.textContent = g.code,
                        n.hooks.run("after-highlight", g)),
                        n.hooks.run("complete", g),
                        void 0;
                if (n.hooks.run("before-highlight", g),
                a && _self.Worker) {
                    var u = new Worker(n.filename);
                    u.onmessage = function(e) {
                        g.highlightedCode = e.data,
                            n.hooks.run("before-insert", g),
                            g.element.innerHTML = g.highlightedCode,
                        r && r.call(g.element),
                            n.hooks.run("after-highlight", g),
                            n.hooks.run("complete", g)
                    }
                        ,
                        u.postMessage(JSON.stringify({
                            language: g.language,
                            code: g.code,
                            immediateClose: !0
                        }))
                } else
                    g.highlightedCode = n.highlight(g.code, g.grammar, g.language),
                        n.hooks.run("before-insert", g),
                        g.element.innerHTML = g.highlightedCode,
                    r && r.call(t),
                        n.hooks.run("after-highlight", g),
                        n.hooks.run("complete", g)
            },
            highlight: function(e, t, r) {
                var l = n.tokenize(e, t);
                return a.stringify(n.util.encode(l), r)
            },
            matchGrammar: function(e, t, a, r, l, i, o) {
                var s = n.Token;
                for (var g in a)
                    if (a.hasOwnProperty(g) && a[g]) {
                        if (g == o)
                            return;
                        var u = a[g];
                        u = "Array" === n.util.type(u) ? u : [u];
                        for (var c = 0; c < u.length; ++c) {
                            var h = u[c]
                                , f = h.inside
                                , d = !!h.lookbehind
                                , m = !!h.greedy
                                , p = 0
                                , y = h.alias;
                            if (m && !h.pattern.global) {
                                var v = h.pattern.toString().match(/[imuy]*$/)[0];
                                h.pattern = RegExp(h.pattern.source, v + "g")
                            }
                            h = h.pattern || h;
                            for (var b = r, k = l; b < t.length; k += t[b].length,
                                ++b) {
                                var w = t[b];
                                if (t.length > e.length)
                                    return;
                                if (!(w instanceof s)) {
                                    h.lastIndex = 0;
                                    var _ = h.exec(w)
                                        , P = 1;
                                    if (!_ && m && b != t.length - 1) {
                                        if (h.lastIndex = k,
                                            _ = h.exec(e),
                                            !_)
                                            break;
                                        for (var A = _.index + (d ? _[1].length : 0), j = _.index + _[0].length, x = b, O = k, N = t.length; N > x && (j > O || !t[x].type && !t[x - 1].greedy); ++x)
                                            O += t[x].length,
                                            A >= O && (++b,
                                                k = O);
                                        if (t[b]instanceof s || t[x - 1].greedy)
                                            continue;
                                        P = x - b,
                                            w = e.slice(k, O),
                                            _.index -= k
                                    }
                                    if (_) {
                                        d && (p = _[1].length);
                                        var A = _.index + p
                                            , _ = _[0].slice(p)
                                            , j = A + _.length
                                            , S = w.slice(0, A)
                                            , C = w.slice(j)
                                            , M = [b, P];
                                        S && (++b,
                                            k += S.length,
                                            M.push(S));
                                        var E = new s(g,f ? n.tokenize(_, f) : _,y,_,m);
                                        if (M.push(E),
                                        C && M.push(C),
                                            Array.prototype.splice.apply(t, M),
                                        1 != P && n.matchGrammar(e, t, a, b, k, !0, g),
                                            i)
                                            break
                                    } else if (i)
                                        break
                                }
                            }
                        }
                    }
            },
            tokenize: function(e, t) {
                var a = [e]
                    , r = t.rest;
                if (r) {
                    for (var l in r)
                        t[l] = r[l];
                    delete t.rest
                }
                return n.matchGrammar(e, a, t, 0, 0, !1),
                    a
            },
            hooks: {
                all: {},
                add: function(e, t) {
                    var a = n.hooks.all;
                    a[e] = a[e] || [],
                        a[e].push(t)
                },
                run: function(e, t) {
                    var a = n.hooks.all[e];
                    if (a && a.length)
                        for (var r, l = 0; r = a[l++]; )
                            r(t)
                }
            }
        }
        , a = n.Token = function(e, t, n, a, r) {
            this.type = e,
                this.content = t,
                this.alias = n,
                this.length = 0 | (a || "").length,
                this.greedy = !!r
        }
    ;
    if (a.stringify = function(e, t, r) {
        if ("string" == typeof e)
            return e;
        if ("Array" === n.util.type(e))
            return e.map(function(n) {
                return a.stringify(n, t, e)
            }).join("");
        var l = {
            type: e.type,
            content: a.stringify(e.content, t, r),
            tag: "span",
            classes: ["token", e.type],
            attributes: {},
            language: t,
            parent: r
        };
        if (e.alias) {
            var i = "Array" === n.util.type(e.alias) ? e.alias : [e.alias];
            Array.prototype.push.apply(l.classes, i)
        }
        n.hooks.run("wrap", l);
        var o = Object.keys(l.attributes).map(function(e) {
            return e + '="' + (l.attributes[e] || "").replace(/"/g, "&quot;") + '"'
        }).join(" ");
        return "<" + l.tag + ' class="' + l.classes.join(" ") + '"' + (o ? " " + o : "") + ">" + l.content + "</" + l.tag + ">"
    }
        ,
        !_self.document)
        return _self.addEventListener ? (n.disableWorkerMessageHandler || _self.addEventListener("message", function(e) {
            var t = JSON.parse(e.data)
                , a = t.language
                , r = t.code
                , l = t.immediateClose;
            _self.postMessage(n.highlight(r, n.languages[a], a)),
            l && _self.close()
        }, !1),
            _self.Prism) : _self.Prism;
    var r = document.currentScript || [].slice.call(document.getElementsByTagName("script")).pop();
    return r && (n.filename = r.src,
    n.manual || r.hasAttribute("data-manual") || ("loading" !== document.readyState ? window.requestAnimationFrame ? window.requestAnimationFrame(n.highlightAll) : window.setTimeout(n.highlightAll, 16) : document.addEventListener("DOMContentLoaded", n.highlightAll))),
        _self.Prism
}();
"undefined" != typeof module && module.exports && (module.exports = Prism),
"undefined" != typeof global && (global.Prism = Prism);
Prism.languages.markup = {
    comment: /<!--[\s\S]*?-->/,
    prolog: /<\?[\s\S]+?\?>/,
    doctype: /<!DOCTYPE[\s\S]+?>/i,
    cdata: /<!\[CDATA\[[\s\S]*?]]>/i,
    tag: {
        pattern: /<\/?(?!\d)[^\s>\/=$<]+(?:\s+[^\s>\/=]+(?:=(?:("|')(?:\\[\s\S]|(?!\1)[^\\])*\1|[^\s'">=]+))?)*\s*\/?>/i,
        inside: {
            tag: {
                pattern: /^<\/?[^\s>\/]+/i,
                inside: {
                    punctuation: /^<\/?/,
                    namespace: /^[^\s>\/:]+:/
                }
            },
            "attr-value": {
                pattern: /=(?:("|')(?:\\[\s\S]|(?!\1)[^\\])*\1|[^\s'">=]+)/i,
                inside: {
                    punctuation: [/^=/, {
                        pattern: /(^|[^\\])["']/,
                        lookbehind: !0
                    }]
                }
            },
            punctuation: /\/?>/,
            "attr-name": {
                pattern: /[^\s>\/]+/,
                inside: {
                    namespace: /^[^\s>\/:]+:/
                }
            }
        }
    },
    entity: /&#?[\da-z]{1,8};/i
},
    Prism.languages.markup.tag.inside["attr-value"].inside.entity = Prism.languages.markup.entity,
    Prism.hooks.add("wrap", function(a) {
        "entity" === a.type && (a.attributes.title = a.content.replace(/&amp;/, "&"))
    }),
    Prism.languages.xml = Prism.languages.markup,
    Prism.languages.html = Prism.languages.markup,
    Prism.languages.mathml = Prism.languages.markup,
    Prism.languages.svg = Prism.languages.markup;
Prism.languages.css = {
    comment: /\/\*[\s\S]*?\*\//,
    atrule: {
        pattern: /@[\w-]+?.*?(?:;|(?=\s*\{))/i,
        inside: {
            rule: /@[\w-]+/
        }
    },
    url: /url\((?:(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1|.*?)\)/i,
    selector: /[^{}\s][^{};]*?(?=\s*\{)/,
    string: {
        pattern: /("|')(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
        greedy: !0
    },
    property: /[\w-]+(?=\s*:)/i,
    important: /\B!important\b/i,
    "function": /[-a-z0-9]+(?=\()/i,
    punctuation: /[(){};:]/
},
    Prism.languages.css.atrule.inside.rest = Prism.util.clone(Prism.languages.css),
Prism.languages.markup && (Prism.languages.insertBefore("markup", "tag", {
    style: {
        pattern: /(<style[\s\S]*?>)[\s\S]*?(?=<\/style>)/i,
        lookbehind: !0,
        inside: Prism.languages.css,
        alias: "language-css"
    }
}),
    Prism.languages.insertBefore("inside", "attr-value", {
        "style-attr": {
            pattern: /\s*style=("|')(?:\\[\s\S]|(?!\1)[^\\])*\1/i,
            inside: {
                "attr-name": {
                    pattern: /^\s*style/i,
                    inside: Prism.languages.markup.tag.inside
                },
                punctuation: /^\s*=\s*['"]|['"]\s*$/,
                "attr-value": {
                    pattern: /.+/i,
                    inside: Prism.languages.css
                }
            },
            alias: "language-css"
        }
    }, Prism.languages.markup.tag));
Prism.languages.clike = {
    comment: [{
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0
    }, {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0
    }],
    string: {
        pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
        greedy: !0
    },
    "class-name": {
        pattern: /((?:\b(?:class|interface|extends|implements|trait|instanceof|new)\s+)|(?:catch\s+\())[\w.\\]+/i,
        lookbehind: !0,
        inside: {
            punctuation: /[.\\]/
        }
    },
    keyword: /\b(?:if|else|while|do|for|return|in|instanceof|function|new|try|throw|catch|finally|null|break|continue)\b/,
    "boolean": /\b(?:true|false)\b/,
    "function": /[a-z0-9_]+(?=\()/i,
    number: /\b-?(?:0x[\da-f]+|\d*\.?\d+(?:e[+-]?\d+)?)\b/i,
    operator: /--?|\+\+?|!=?=?|<=?|>=?|==?=?|&&?|\|\|?|\?|\*|\/|~|\^|%/,
    punctuation: /[{}[\];(),.:]/
};
Prism.languages.javascript = Prism.languages.extend("clike", {
    keyword: /\b(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|var|void|while|with|yield)\b/,
    number: /\b-?(?:0[xX][\dA-Fa-f]+|0[bB][01]+|0[oO][0-7]+|\d*\.?\d+(?:[Ee][+-]?\d+)?|NaN|Infinity)\b/,
    "function": /[_$a-zA-Z\xA0-\uFFFF][_$a-zA-Z0-9\xA0-\uFFFF]*(?=\s*\()/i,
    operator: /-[-=]?|\+[+=]?|!=?=?|<<?=?|>>?>?=?|=(?:==?|>)?|&[&=]?|\|[|=]?|\*\*?=?|\/=?|~|\^=?|%=?|\?|\.{3}/
}),
    Prism.languages.insertBefore("javascript", "keyword", {
        regex: {
            pattern: /(^|[^\/])\/(?!\/)(\[[^\]\r\n]+]|\\.|[^\/\\\[\r\n])+\/[gimyu]{0,5}(?=\s*($|[\r\n,.;})]))/,
            lookbehind: !0,
            greedy: !0
        },
        "function-variable": {
            pattern: /[_$a-zA-Z\xA0-\uFFFF][_$a-zA-Z0-9\xA0-\uFFFF]*(?=\s*=\s*(?:function\b|(?:\([^()]*\)|[_$a-zA-Z\xA0-\uFFFF][_$a-zA-Z0-9\xA0-\uFFFF]*)\s*=>))/i,
            alias: "function"
        }
    }),
    Prism.languages.insertBefore("javascript", "string", {
        "template-string": {
            pattern: /`(?:\\[\s\S]|[^\\`])*`/,
            greedy: !0,
            inside: {
                interpolation: {
                    pattern: /\$\{[^}]+\}/,
                    inside: {
                        "interpolation-punctuation": {
                            pattern: /^\$\{|\}$/,
                            alias: "punctuation"
                        },
                        rest: Prism.languages.javascript
                    }
                },
                string: /[\s\S]+/
            }
        }
    }),
Prism.languages.markup && Prism.languages.insertBefore("markup", "tag", {
    script: {
        pattern: /(<script[\s\S]*?>)[\s\S]*?(?=<\/script>)/i,
        lookbehind: !0,
        inside: Prism.languages.javascript,
        alias: "language-javascript"
    }
}),
    Prism.languages.js = Prism.languages.javascript;
Prism.languages.c = Prism.languages.extend("clike", {
    keyword: /\b(?:_Alignas|_Alignof|_Atomic|_Bool|_Complex|_Generic|_Imaginary|_Noreturn|_Static_assert|_Thread_local|asm|typeof|inline|auto|break|case|char|const|continue|default|do|double|else|enum|extern|float|for|goto|if|int|long|register|return|short|signed|sizeof|static|struct|switch|typedef|union|unsigned|void|volatile|while)\b/,
    operator: /-[>-]?|\+\+?|!=?|<<?=?|>>?=?|==?|&&?|\|\|?|[~^%?*\/]/,
    number: /\b-?(?:0x[\da-f]+|\d*\.?\d+(?:e[+-]?\d+)?)[ful]*\b/i
}),
    Prism.languages.insertBefore("c", "string", {
        macro: {
            pattern: /(^\s*)#\s*[a-z]+(?:[^\r\n\\]|\\(?:\r\n|[\s\S]))*/im,
            lookbehind: !0,
            alias: "property",
            inside: {
                string: {
                    pattern: /(#\s*include\s*)(?:<.+?>|("|')(?:\\?.)+?\2)/,
                    lookbehind: !0
                },
                directive: {
                    pattern: /(#\s*)\b(?:define|defined|elif|else|endif|error|ifdef|ifndef|if|import|include|line|pragma|undef|using)\b/,
                    lookbehind: !0,
                    alias: "keyword"
                }
            }
        },
        constant: /\b(?:__FILE__|__LINE__|__DATE__|__TIME__|__TIMESTAMP__|__func__|EOF|NULL|SEEK_CUR|SEEK_END|SEEK_SET|stdin|stdout|stderr)\b/
    }),
    delete Prism.languages.c["class-name"],
    delete Prism.languages.c["boolean"];
Prism.languages.java = Prism.languages.extend("clike", {
    keyword: /\b(?:abstract|continue|for|new|switch|assert|default|goto|package|synchronized|boolean|do|if|private|this|break|double|implements|protected|throw|byte|else|import|public|throws|case|enum|instanceof|return|transient|catch|extends|int|short|try|char|final|interface|static|void|class|finally|long|strictfp|volatile|const|float|native|super|while)\b/,
    number: /\b0b[01]+\b|\b0x[\da-f]*\.?[\da-fp\-]+\b|\b\d*\.?\d+(?:e[+-]?\d+)?[df]?\b/i,
    operator: {
        pattern: /(^|[^.])(?:\+[+=]?|-[-=]?|!=?|<<?=?|>>?>?=?|==?|&[&=]?|\|[|=]?|\*=?|\/=?|%=?|\^=?|[?:~])/m,
        lookbehind: !0
    }
}),
    Prism.languages.insertBefore("java", "function", {
        annotation: {
            alias: "punctuation",
            pattern: /(^|[^.])@\w+/,
            lookbehind: !0
        }
    });
Prism.languages.json = {
    property: /"(?:\\.|[^\\"\r\n])*"(?=\s*:)/i,
    string: {
        pattern: /"(?:\\.|[^\\"\r\n])*"(?!\s*:)/,
        greedy: !0
    },
    number: /\b-?(?:0x[\dA-Fa-f]+|\d*\.?\d+(?:[Ee][+-]?\d+)?)\b/,
    punctuation: /[{}[\]);,]/,
    operator: /:/g,
    "boolean": /\b(?:true|false)\b/i,
    "null": /\bnull\b/i
},
    Prism.languages.jsonp = Prism.languages.json;
Prism.languages.markdown = Prism.languages.extend("markup", {}),
    Prism.languages.insertBefore("markdown", "prolog", {
        blockquote: {
            pattern: /^>(?:[\t ]*>)*/m,
            alias: "punctuation"
        },
        code: [{
            pattern: /^(?: {4}|\t).+/m,
            alias: "keyword"
        }, {
            pattern: /``.+?``|`[^`\n]+`/,
            alias: "keyword"
        }],
        title: [{
            pattern: /\w+.*(?:\r?\n|\r)(?:==+|--+)/,
            alias: "important",
            inside: {
                punctuation: /==+$|--+$/
            }
        }, {
            pattern: /(^\s*)#+.+/m,
            lookbehind: !0,
            alias: "important",
            inside: {
                punctuation: /^#+|#+$/
            }
        }],
        hr: {
            pattern: /(^\s*)([*-])(?:[\t ]*\2){2,}(?=\s*$)/m,
            lookbehind: !0,
            alias: "punctuation"
        },
        list: {
            pattern: /(^\s*)(?:[*+-]|\d+\.)(?=[\t ].)/m,
            lookbehind: !0,
            alias: "punctuation"
        },
        "url-reference": {
            pattern: /!?\[[^\]]+\]:[\t ]+(?:\S+|<(?:\\.|[^>\\])+>)(?:[\t ]+(?:"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\((?:\\.|[^)\\])*\)))?/,
            inside: {
                variable: {
                    pattern: /^(!?\[)[^\]]+/,
                    lookbehind: !0
                },
                string: /(?:"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\((?:\\.|[^)\\])*\))$/,
                punctuation: /^[\[\]!:]|[<>]/
            },
            alias: "url"
        },
        bold: {
            pattern: /(^|[^\\])(\*\*|__)(?:(?:\r?\n|\r)(?!\r?\n|\r)|.)+?\2/,
            lookbehind: !0,
            inside: {
                punctuation: /^\*\*|^__|\*\*$|__$/
            }
        },
        italic: {
            pattern: /(^|[^\\])([*_])(?:(?:\r?\n|\r)(?!\r?\n|\r)|.)+?\2/,
            lookbehind: !0,
            inside: {
                punctuation: /^[*_]|[*_]$/
            }
        },
        url: {
            pattern: /!?\[[^\]]+\](?:\([^\s)]+(?:[\t ]+"(?:\\.|[^"\\])*")?\)| ?\[[^\]\n]*\])/,
            inside: {
                variable: {
                    pattern: /(!?\[)[^\]]+(?=\]$)/,
                    lookbehind: !0
                },
                string: {
                    pattern: /"(?:\\.|[^"\\])*"(?=\)$)/
                }
            }
        }
    }),
    Prism.languages.markdown.bold.inside.url = Prism.util.clone(Prism.languages.markdown.url),
    Prism.languages.markdown.italic.inside.url = Prism.util.clone(Prism.languages.markdown.url),
    Prism.languages.markdown.bold.inside.italic = Prism.util.clone(Prism.languages.markdown.italic),
    Prism.languages.markdown.italic.inside.bold = Prism.util.clone(Prism.languages.markdown.bold);
Prism.languages.php = Prism.languages.extend("clike", {
    keyword: /\b(?:and|or|xor|array|as|break|case|cfunction|class|const|continue|declare|default|die|do|else|elseif|enddeclare|endfor|endforeach|endif|endswitch|endwhile|extends|for|foreach|function|include|include_once|global|if|new|return|static|switch|use|require|require_once|var|while|abstract|interface|public|implements|private|protected|parent|throw|null|echo|print|trait|namespace|final|yield|goto|instanceof|finally|try|catch)\b/i,
    constant: /\b[A-Z0-9_]{2,}\b/,
    comment: {
        pattern: /(^|[^\\])(?:\/\*[\s\S]*?\*\/|\/\/.*)/,
        lookbehind: !0
    }
}),
    Prism.languages.insertBefore("php", "class-name", {
        "shell-comment": {
            pattern: /(^|[^\\])#.*/,
            lookbehind: !0,
            alias: "comment"
        }
    }),
    Prism.languages.insertBefore("php", "keyword", {
        delimiter: {
            pattern: /\?>|<\?(?:php|=)?/i,
            alias: "important"
        },
        variable: /\$\w+\b/i,
        "package": {
            pattern: /(\\|namespace\s+|use\s+)[\w\\]+/,
            lookbehind: !0,
            inside: {
                punctuation: /\\/
            }
        }
    }),
    Prism.languages.insertBefore("php", "operator", {
        property: {
            pattern: /(->)[\w]+/,
            lookbehind: !0
        }
    }),
Prism.languages.markup && (Prism.hooks.add("before-highlight", function(e) {
    "php" === e.language && /(?:<\?php|<\?)/gi.test(e.code) && (e.tokenStack = [],
        e.backupCode = e.code,
        e.code = e.code.replace(/(?:<\?php|<\?)[\s\S]*?(?:\?>|$)/gi, function(a) {
            for (var n = e.tokenStack.length; -1 !== e.backupCode.indexOf("___PHP" + n + "___"); )
                ++n;
            return e.tokenStack[n] = a,
            "___PHP" + n + "___"
        }),
        e.grammar = Prism.languages.markup)
}),
    Prism.hooks.add("before-insert", function(e) {
        "php" === e.language && e.backupCode && (e.code = e.backupCode,
            delete e.backupCode)
    }),
    Prism.hooks.add("after-highlight", function(e) {
        if ("php" === e.language && e.tokenStack) {
            e.grammar = Prism.languages.php;
            for (var a = 0, n = Object.keys(e.tokenStack); a < n.length; ++a) {
                var t = n[a]
                    , r = e.tokenStack[t];
                e.highlightedCode = e.highlightedCode.replace("___PHP" + t + "___", '<span class="token php language-php">' + Prism.highlight(r, e.grammar, "php").replace(/\$/g, "$$$$") + "</span>")
            }
            e.element.innerHTML = e.highlightedCode
        }
    }));
Prism.languages.python = {
    comment: {
        pattern: /(^|[^\\])#.*/,
        lookbehind: !0
    },
    "triple-quoted-string": {
        pattern: /("""|''')[\s\S]+?\1/,
        greedy: !0,
        alias: "string"
    },
    string: {
        pattern: /("|')(?:\\.|(?!\1)[^\\\r\n])*\1/,
        greedy: !0
    },
    "function": {
        pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
        lookbehind: !0
    },
    "class-name": {
        pattern: /(\bclass\s+)\w+/i,
        lookbehind: !0
    },
    keyword: /\b(?:as|assert|async|await|break|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|nonlocal|pass|print|raise|return|try|while|with|yield)\b/,
    builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
    "boolean": /\b(?:True|False|None)\b/,
    number: /\b-?(?:0[bo])?(?:(?:\d|0x[\da-f])[\da-f]*\.?\d*|\.\d+)(?:e[+-]?\d+)?j?\b/i,
    operator: /[-+%=]=?|!=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]|\b(?:or|and|not)\b/,
    punctuation: /[{}[\];(),.:]/
};
Prism.languages.sql = {
    comment: {
        pattern: /(^|[^\\])(?:\/\*[\s\S]*?\*\/|(?:--|\/\/|#).*)/,
        lookbehind: !0
    },
    string: {
        pattern: /(^|[^@\\])("|')(?:\\[\s\S]|(?!\2)[^\\])*\2/,
        greedy: !0,
        lookbehind: !0
    },
    variable: /@[\w.$]+|@(["'`])(?:\\[\s\S]|(?!\1)[^\\])+\1/,
    "function": /\b(?:COUNT|SUM|AVG|MIN|MAX|FIRST|LAST|UCASE|LCASE|MID|LEN|ROUND|NOW|FORMAT)(?=\s*\()/i,
    keyword: /\b(?:ACTION|ADD|AFTER|ALGORITHM|ALL|ALTER|ANALYZE|ANY|APPLY|AS|ASC|AUTHORIZATION|AUTO_INCREMENT|BACKUP|BDB|BEGIN|BERKELEYDB|BIGINT|BINARY|BIT|BLOB|BOOL|BOOLEAN|BREAK|BROWSE|BTREE|BULK|BY|CALL|CASCADED?|CASE|CHAIN|CHAR VARYING|CHARACTER (?:SET|VARYING)|CHARSET|CHECK|CHECKPOINT|CLOSE|CLUSTERED|COALESCE|COLLATE|COLUMN|COLUMNS|COMMENT|COMMIT|COMMITTED|COMPUTE|CONNECT|CONSISTENT|CONSTRAINT|CONTAINS|CONTAINSTABLE|CONTINUE|CONVERT|CREATE|CROSS|CURRENT(?:_DATE|_TIME|_TIMESTAMP|_USER)?|CURSOR|DATA(?:BASES?)?|DATE(?:TIME)?|DBCC|DEALLOCATE|DEC|DECIMAL|DECLARE|DEFAULT|DEFINER|DELAYED|DELETE|DELIMITER(?:S)?|DENY|DESC|DESCRIBE|DETERMINISTIC|DISABLE|DISCARD|DISK|DISTINCT|DISTINCTROW|DISTRIBUTED|DO|DOUBLE(?: PRECISION)?|DROP|DUMMY|DUMP(?:FILE)?|DUPLICATE KEY|ELSE|ENABLE|ENCLOSED BY|END|ENGINE|ENUM|ERRLVL|ERRORS|ESCAPE(?:D BY)?|EXCEPT|EXEC(?:UTE)?|EXISTS|EXIT|EXPLAIN|EXTENDED|FETCH|FIELDS|FILE|FILLFACTOR|FIRST|FIXED|FLOAT|FOLLOWING|FOR(?: EACH ROW)?|FORCE|FOREIGN|FREETEXT(?:TABLE)?|FROM|FULL|FUNCTION|GEOMETRY(?:COLLECTION)?|GLOBAL|GOTO|GRANT|GROUP|HANDLER|HASH|HAVING|HOLDLOCK|IDENTITY(?:_INSERT|COL)?|IF|IGNORE|IMPORT|INDEX|INFILE|INNER|INNODB|INOUT|INSERT|INT|INTEGER|INTERSECT|INTO|INVOKER|ISOLATION LEVEL|JOIN|KEYS?|KILL|LANGUAGE SQL|LAST|LEFT|LIMIT|LINENO|LINES|LINESTRING|LOAD|LOCAL|LOCK|LONG(?:BLOB|TEXT)|MATCH(?:ED)?|MEDIUM(?:BLOB|INT|TEXT)|MERGE|MIDDLEINT|MODIFIES SQL DATA|MODIFY|MULTI(?:LINESTRING|POINT|POLYGON)|NATIONAL(?: CHAR VARYING| CHARACTER(?: VARYING)?| VARCHAR)?|NATURAL|NCHAR(?: VARCHAR)?|NEXT|NO(?: SQL|CHECK|CYCLE)?|NONCLUSTERED|NULLIF|NUMERIC|OFF?|OFFSETS?|ON|OPEN(?:DATASOURCE|QUERY|ROWSET)?|OPTIMIZE|OPTION(?:ALLY)?|ORDER|OUT(?:ER|FILE)?|OVER|PARTIAL|PARTITION|PERCENT|PIVOT|PLAN|POINT|POLYGON|PRECEDING|PRECISION|PREV|PRIMARY|PRINT|PRIVILEGES|PROC(?:EDURE)?|PUBLIC|PURGE|QUICK|RAISERROR|READ(?:S SQL DATA|TEXT)?|REAL|RECONFIGURE|REFERENCES|RELEASE|RENAME|REPEATABLE|REPLICATION|REQUIRE|RESTORE|RESTRICT|RETURNS?|REVOKE|RIGHT|ROLLBACK|ROUTINE|ROW(?:COUNT|GUIDCOL|S)?|RTREE|RULE|SAVE(?:POINT)?|SCHEMA|SELECT|SERIAL(?:IZABLE)?|SESSION(?:_USER)?|SET(?:USER)?|SHARE MODE|SHOW|SHUTDOWN|SIMPLE|SMALLINT|SNAPSHOT|SOME|SONAME|START(?:ING BY)?|STATISTICS|STATUS|STRIPED|SYSTEM_USER|TABLES?|TABLESPACE|TEMP(?:ORARY|TABLE)?|TERMINATED BY|TEXT(?:SIZE)?|THEN|TIMESTAMP|TINY(?:BLOB|INT|TEXT)|TOP?|TRAN(?:SACTIONS?)?|TRIGGER|TRUNCATE|TSEQUAL|TYPES?|UNBOUNDED|UNCOMMITTED|UNDEFINED|UNION|UNIQUE|UNPIVOT|UPDATE(?:TEXT)?|USAGE|USE|USER|USING|VALUES?|VAR(?:BINARY|CHAR|CHARACTER|YING)|VIEW|WAITFOR|WARNINGS|WHEN|WHERE|WHILE|WITH(?: ROLLUP|IN)?|WORK|WRITE(?:TEXT)?)\b/i,
    "boolean": /\b(?:TRUE|FALSE|NULL)\b/i,
    number: /\b-?(?:0x)?\d*\.?[\da-f]+\b/,
    operator: /[-+*\/=%^~]|&&?|\|\|?|!=?|<(?:=>?|<|>)?|>[>=]?|\b(?:AND|BETWEEN|IN|LIKE|NOT|OR|IS|DIV|REGEXP|RLIKE|SOUNDS LIKE|XOR)\b/i,
    punctuation: /[;[\]()`,.]/
};
!function() {
    if ("undefined" != typeof self && self.Prism && self.document) {
        var e = "line-numbers"
            , t = function(e) {
            var t = n(e)
                , r = t["white-space"];
            if ("pre-wrap" === r || "pre-line" === r) {
                var s = e.querySelector("code")
                    , l = e.querySelector(".line-numbers-rows")
                    , a = e.querySelector(".line-numbers-sizer")
                    , i = e.textContent.split("\n");
                a || (a = document.createElement("span"),
                    a.className = "line-numbers-sizer",
                    s.appendChild(a)),
                    a.style.display = "block",
                    i.forEach(function(e, t) {
                        a.textContent = e || "\n";
                        var n = a.getBoundingClientRect().height;
                        l.children[t].style.height = n + "px"
                    }),
                    a.textContent = "",
                    a.style.display = "none"
            }
        }
            , n = function(e) {
            return e ? window.getComputedStyle ? getComputedStyle(e) : e.currentStyle || null : null
        };
        window.addEventListener("resize", function() {
            Array.prototype.forEach.call(document.querySelectorAll("pre." + e), t)
        }),
            Prism.hooks.add("complete", function(e) {
                if (e.code) {
                    var n = e.element.parentNode
                        , r = /\s*\bline-numbers\b\s*/;
                    if (n && /pre/i.test(n.nodeName) && (r.test(n.className) || r.test(e.element.className)) && !e.element.querySelector(".line-numbers-rows")) {
                        r.test(e.element.className) && (e.element.className = e.element.className.replace(r, " ")),
                        r.test(n.className) || (n.className += " line-numbers");
                        var s, l = e.code.match(/\n(?!$)/g), a = l ? l.length + 1 : 1, i = new Array(a + 1);
                        i = i.join("<span></span>"),
                            s = document.createElement("span"),
                            s.setAttribute("aria-hidden", "true"),
                            s.className = "line-numbers-rows",
                            s.innerHTML = i,
                        n.hasAttribute("data-start") && (n.style.counterReset = "linenumber " + (parseInt(n.getAttribute("data-start"), 10) - 1)),
                            e.element.appendChild(s),
                            t(n)
                    }
                }
            })
    }
}();
!function() {
    "undefined" != typeof self && !self.Prism || "undefined" != typeof global && !global.Prism || Prism.hooks.add("wrap", function(e) {
        "keyword" === e.type && e.classes.push("keyword-" + e.content)
    })
}();
!function() {
    "undefined" != typeof self && self.Prism && self.document && Prism.hooks.add("before-sanity-check", function(e) {
        if (e.code) {
            var s = e.element.parentNode
                , n = /\s*\bkeep-initial-line-feed\b\s*/;
            !s || "pre" !== s.nodeName.toLowerCase() || n.test(s.className) || n.test(e.element.className) || (e.code = e.code.replace(/^(?:\r?\n|\r)/, ""))
        }
    })
}();
!function() {
    if (("undefined" == typeof self || self.Prism) && ("undefined" == typeof global || global.Prism)) {
        var i = function(i) {
            return Prism.plugins.autolinker && Prism.plugins.autolinker.processGrammar(i),
                i
        }
            , a = {
            pattern: /(.)\bdata:[^\/]+\/[^,]+,(?:(?!\1)[\s\S]|\\\1)+(?=\1)/,
            lookbehind: !0,
            inside: {
                "language-css": {
                    pattern: /(data:[^\/]+\/(?:[^+,]+\+)?css,)[\s\S]+/,
                    lookbehind: !0
                },
                "language-javascript": {
                    pattern: /(data:[^\/]+\/(?:[^+,]+\+)?javascript,)[\s\S]+/,
                    lookbehind: !0
                },
                "language-json": {
                    pattern: /(data:[^\/]+\/(?:[^+,]+\+)?json,)[\s\S]+/,
                    lookbehind: !0
                },
                "language-markup": {
                    pattern: /(data:[^\/]+\/(?:[^+,]+\+)?(?:html|xml),)[\s\S]+/,
                    lookbehind: !0
                }
            }
        }
            , n = ["url", "attr-value", "string"];
        Prism.plugins.dataURIHighlight = {
            processGrammar: function(i) {
                i && !i["data-uri"] && (Prism.languages.DFS(i, function(i, e, r) {
                    n.indexOf(r) > -1 && "Array" !== Prism.util.type(e) && (e.pattern || (e = this[i] = {
                        pattern: e
                    }),
                        e.inside = e.inside || {},
                        "attr-value" == r ? Prism.languages.insertBefore("inside", e.inside["url-link"] ? "url-link" : "punctuation", {
                            "data-uri": a
                        }, e) : e.inside["url-link"] ? Prism.languages.insertBefore("inside", "url-link", {
                            "data-uri": a
                        }, e) : e.inside["data-uri"] = a)
                }),
                    i["data-uri"] = a)
            }
        },
            Prism.hooks.add("before-highlight", function(n) {
                if (a.pattern.test(n.code))
                    for (var e in a.inside)
                        if (a.inside.hasOwnProperty(e) && !a.inside[e].inside && a.inside[e].pattern.test(n.code)) {
                            var r = e.match(/^language-(.+)/)[1];
                            Prism.languages[r] && (a.inside[e].inside = {
                                rest: i(Prism.languages[r])
                            })
                        }
                Prism.plugins.dataURIHighlight.processGrammar(n.grammar)
            })
    }
}();
