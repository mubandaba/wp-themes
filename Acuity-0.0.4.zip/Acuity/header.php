<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="shortcut icon" href="<?php echo _umtu_img( 'web_favicon' )?>">
    <?php wp_head();?>
</head>
<body>
<?php $umtu_framework = get_option('umtu_framework');if ($umtu_framework['web_logo']){$web_logo = $umtu_framework['web_logo']['id'];}?>
<div id="umtu" class="uk-position-relative uk-nbfc">
    <header class="uk-block-default">
        <!--PC端导航-->
        <div class="navbar uk-container uk-container-center uk-grid uk-grid-collapse">
            <div class="uk-width-1-3 uk-width-small-1-2 uk-width-medium-5-10 uk-width-large-1-10">
                <a href="<?php bloginfo('url');?>">
                    <?php $url = get_template_directory_uri()?>
                    <img src="<?php echo xyz_src($web_logo);?>" alt="<?php bloginfo('name');?>">
                </a>

            </div>
            <div class="uk-width-7-10 uk-visible-large">
                <nav class="nav">
                    <ul class="menu">
                        <?php xyz_menu_with_walker('main_menu', new  Walker_Nav_Menu())?>
                    </ul>
                </nav>
            </div>
            <div class="head-menu uk-text-right uk-width-2-3 uk-width-small-1-2 uk-width-medium-5-10 uk-width-large-2-10">
                <a href="#search" data-uk-modal class="uk-margin-left">
                    <i class="iconfont icon-sousuo uk-border-circle"></i>
                </a>
                <a href="#head-locker" data-uk-offcanvas class="uk-margin-left uk-hidden-large"><i class="iconfont icon-align-right uk-border-circle"></i></a>
            </div>
        </div>
        <!--移动端导航-->
        <div id="head-locker" class="uk-offcanvas">
            <div class="head-locker-bg uk-offcanvas-bar uk-offcanvas-bar-flip">
                <div class="side-main">
                    <div class="uk-flex-center uk-text-center uk-margin-top uk-margin-bottom">
                        <a href="<?php bloginfo('url');?>" target="_blank" class="uk-display-inline-block uk-margin-bottom">
                            <img src="<?php echo xyz_src($web_logo);?>">
                        </a>
                        <h3 class="uk-margin-remove"><?php bloginfo('name');?></h3>
                    </div>
                    <nav class="side-nav b-t">
                        <ul class="menu">
                            <?php xyz_menu_with_walker('main_menu', new  Walker_Nav_Menu())?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>

    </header>
