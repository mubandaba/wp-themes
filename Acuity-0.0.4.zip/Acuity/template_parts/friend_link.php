<div class="part link">
    <div class="part-title">
        <h3>友情链接</h3>
    </div>
    <ul class="uk-panel uk-block-default b-r-4 uk-margin-remove">
        <?php
        $friend_links = _umtu('friend_links');
        if ($friend_links):foreach ($friend_links as $friend_link):
            ?>
            <li class="uk-margin-right"><a href="<?php echo $friend_link['friend_url']?>" target="_blank"><?php echo $friend_link['friend_title']?></a></li>
        <?php endforeach;endif;?>
    </ul>
</div>
