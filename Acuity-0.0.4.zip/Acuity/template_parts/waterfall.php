<!--waterfall-->
<?php
$cms_title = $cms['cms_title'];
$cms_cat_id = $cms['cms_cat_id'];
$cat_link = get_category_link($cms_cat_id);
$cms_cat_num = $cms['cms_cat_num'];
$posts = get_posts('category='.$cms_cat_id.'&numberposts='.$cms_cat_num.'');
?>
<div class="part">
    <div class="part-title uk-text-center">
        <h3><?php echo $cms_title?></h3>
    </div>
    <div class="uk-grid uk-grid-medium" data-uk-grid>
        <?php foreach ($posts as $post):setup_postdata($post);$post_id = $post->ID;?>
        <div class="uk-width-1-1 uk-width-small-1-2 uk-width-medium-1-2 uk-width-large-1-4 uk-margin-bottom">

            <figure class="pic-item shadow uk-block-default uk-margin-bottom uk-nbfc b-r-4">
                <div class="uk-overlay uk-overlay-hover">
                    <a href="<?php the_permalink();?>" target="_blank">
                        <img class="uk-overlay-scale" src="<?php umtu_thumb('full');?>" alt="<?php the_title()?>">
                    </a>
                </div>
                <div class="item-info uk-margin-left uk-margin-right">
                    <div class="author">
                        <span class="s-avatar rotate uk-display-block">
                            <a href="<?php echo get_author_posts_url($author_id)?>">
                                <img src="<?php umtu_author_img($author_id);?>" class='avatar avatar-200 photo'  height='200' width='200'/>
                            </a>
                        </span>
                        <span class="uk-text-muted uk-margin-small-left uk-margin-small-top"><?php the_author_meta('nickname',$author_id);?></span>
                    </div>
                    <div class="category uk-margin-small-top">
                        <?php $cat_lists = get_the_category();if ($cat_lists):foreach ($cat_lists as $cat_list):$cat_list_link= get_category_link($cat_list->term_id)?>
                            <a href="<?php echo $cat_list_link?>" rel="category tag"><?php echo $cat_list->name?></a>
                        <?php endforeach;endif;?>
                    </div>
                    <h3 class="uk-margin-top">
                        <a href="<?php the_permalink();?>"><?php the_title()?></a>
                    </h3>
                    <?php $excerpt = str_replace(' ','',get_the_excerpt());?>
                    <p class="uk-text-muted"><?php echo wp_trim_words(str_replace(' ','',get_the_excerpt()),'30','…');?></p>
                    <div class="data uk-text-small uk-margin-bottom uk-margin-top">
                        <span class="uk-margin-right"><i class="iconfont icon-rili"></i><?php echo time_since(get_the_date())?></span>
                        <span class="uk-margin-right"><i class="iconfont icon-eye"></i><?php post_views('', ''); ?></span>
                        <span class="uk-hidden-small"><i class="iconfont icon-message"></i><?php comments_number('0','1','% '); ?></span>
                    </div>
                </div>
            </figure>
        </div>
        <?php endforeach;wp_reset_postdata();?>
    </div>
    <div class="uk-text-center uk-margin-large">
        <a href="<?php echo $cat_link?>" class="more vary-bg uk-display-inline-block uk-text-contrast b-r-4 uk-box-shadow-hover-large" target="_blank">查看更多<i class="iconfont icon-icon-test26 uk-margin-small-left"></i></a>
    </div>
</div>