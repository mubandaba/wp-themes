<?php
    $um_recommend_set = _umtu('um_recommend_set');
    if ($um_recommend_set == '1'):
    $um_recommend_title = _umtu('um_recommend_title');
    $um_recommend_num = _umtu('um_recommend_num');
    $um_sidebar_set = _umtu('um_sidebar_set');
    if ($um_sidebar_set == '0') {
        $width = 'uk-width-large-1-4';
    } else {
        $width = 'uk-width-large-1-3';
    }?>
    <div class="part-title">
        <h3><?php echo $um_recommend_title?></h3>
    </div>
    <div class="pic-list uk-grid uk-grid-medium" data-uk-grid="" style="position: relative; height: 1847.19px;">
        <?php
        $cat = get_the_category();
        foreach($cat as $key=>$category){
            $catid = $category->term_id;
        }
        $args = array('showposts' => $um_recommend_num,'cat' => $catid,'meta_key' => 'umtu_view','orderby' => 'meta_value_num',);
        $query_posts = new WP_Query();
        $query_posts->query($args);
        while ($query_posts->have_posts()) : $query_posts->the_post();
            $author_id = get_post_field( 'post_author', get_the_ID() );
            ?>
            <div class="uk-width-1-1 uk-width-small-1-2 uk-width-medium-1-2 <?php echo $width?>"
                 data-grid-prepared="true"
                 style="position: absolute; box-sizing: border-box; top: 0px; left: 0px; opacity: 1;">

                <figure class="pic-item shadow uk-block-default uk-margin-bottom uk-nbfc b-r-4">
                    <div class="uk-overlay uk-overlay-hover">
                        <div class="uk-overlay pic-item-cover uk-overlay-hover">
                            <a href="<?php the_permalink();?>" target="_blank">
                                <img class="uk-overlay-scale" src="<?php umtu_thumb('post_thumb');?>">
                            </a>
                        </div>
                        <div class="item-info uk-margin-left uk-margin-right">
                            <div class="author">
                                <span class="s-avatar rotate uk-display-block">
                                    <a href="<?php echo get_author_posts_url($author_id)?>" target="_blank">
                                        <img src="<?php umtu_author_img($author_id);?>" class="avatar avatar-200 photo" height="200" width="200">
                                    </a>
                                </span>
                                <span class="uk-text-muted uk-margin-small-left uk-margin-small-top"><?php the_author_meta('nickname',$author_id);?></span>
                            </div>
                            <div class="category uk-margin-small-top">
                                <?php $cat_lists = get_the_category();if ($cat_lists):foreach ($cat_lists as $cat_list):$cat_list_link= get_category_link($cat_list->term_id)?>
                                    <a href="<?php echo $cat_list_link?>" rel="category tag"><?php echo $cat_list->name?></a>
                                <?php endforeach;endif;?>
                            </div>
                            <h3 class="uk-margin-top">
                                <a href="<?php the_permalink();?>"><?php the_title()?></a>
                            </h3>
                            <div class="data uk-text-small uk-margin-bottom uk-margin-top">
                                <span class="uk-margin-right"><i class="iconfont icon-rili"></i><?php echo time_since($post->post_date);?></span>
                                <span class="uk-margin-right"><i class="iconfont icon-eye"></i><?php post_views('', ''); ?></span>
                                <span class="uk-hidden-small"><i class="iconfont icon-message"></i><?php comments_number('0','1','% '); ?></span>
                            </div>
                        </div>
                    </div>
                </figure>
            </div>
        <?php endwhile; wp_reset_postdata(); ?>
    </div>
<?php endif;?>