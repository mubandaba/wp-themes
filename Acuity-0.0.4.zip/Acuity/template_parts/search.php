<div class="part home-seach uk-position-relative">
    <?php
    if (_umtu('bg_search')){
        $bg_search = _umtu('bg_search')['id'];
    }
    if (_umtu('search_title')){
        $search_title = _umtu('search_title');
    }
    if (_umtu('search_placeholder')){
        $search_placeholder = _umtu('search_placeholder');
    }
    if (empty($search_placeholder)){$search_placeholder='输入关键词，回车...';}
    $hot_keys = _umtu('hot_key');
    ?>
    <div class="bg" style="background: url(<?php echo xyz_src($bg_search);?>) center fixed;background-size: 100%;"></div>
    <div class="tip uk-position-relative"><?php echo $search_title?></div>
    <div class="home-search-form uk-container-center">
        <div class="uk-margin-left uk-margin-right uk-position-relative">
            <form method="get" class="uk-form" action="<?php bloginfo('url');?>">
                <input type="search" placeholder="<?php echo $search_placeholder;?>" autocomplete="off" value="" name="s" required="required" class="uk-form-large">
                <button type="submit" class="home-search-button uk-position-absolute"><i class="iconfont icon-sousuo"></i></button>
            </form>
            <?php if (!empty($hot_keys)){?>
                <div class="home-seach-hot">
                    <strong class="uk-text-contrast">热搜: </strong>
                    <?php foreach ($hot_keys as $hot_key):?>
                        <a href="<?php bloginfo('url');?>/?s=<?php echo $hot_key['hot_search_key']?>" target="_blank"><?php echo $hot_key['hot_search_key']?></a>
                    <?php endforeach;?>
                </div>
            <?php }?>
        </div>
    </div>
</div>