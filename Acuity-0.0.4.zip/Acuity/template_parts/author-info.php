<?php
if (is_author()){
    $author = get_queried_object();
    $author_id = $author->ID;
}elseif (is_singular()){
    $author_id = get_post_field( 'post_author', $post_id );
}
$user = new WP_User($author_id);
$user_roles = $user->roles;
$user_role = array_shift($user_roles);
if ($user_role == 'administrator') {
    $user_role = '网站管理员';
} elseif ($user_role == 'editor') {
    $user_role = '特约编辑';
} elseif ($user_role == 'author') {
    $user_role = '作者';
} elseif ($user_role == 'contributor') {
    $user_role = '贡献者';
} elseif ($user_role == 'subscriber') {
    $user_role = '订阅者';
} else {
    echo $user_role;
}
?>
<div class="author uk-position-relative uk-block-default b-r-4">
    <div class="author-bg uk-overflow-hidden">
        <img src="<?php umtu_author_img($author_id);?>"
             class="avatar avatar-200 current-author photo" height='200' width='200'/>
    </div>
    <div class="author-avatar l-avatar rotate uk-container-center uk-position-relative">
        <img src="<?php umtu_author_img($author_id);?>"
             class="avatar avatar-200 current-author photo" height='200' width='200'/>
    </div>
    <div class="author-name uk-text-center uk-margin-small-top"><?php the_author_meta('nickname',$author_id);?>
        <em class="uk-display-inline-block">
            <?php
            if ($user_role=='网站管理员'){
                $author_badge = get_template_directory_uri().'/static/images/img_admin.gif';
            }else{
                $author_badge = get_template_directory_uri().'/static/images/img_edit.gif';
            }?>
            <img src="<?php echo $author_badge?>" data-uk-tooltip title="<?php echo $user_role?>">
        </em>
    </div>
    <div class="author-description uk-text-center uk-text-muted uk-margin-top">
        <?php the_author_meta( 'description', $author_id); ?>
    </div>
    <div class="author-data uk-container-center">
        <div class="author-data-item uk-text-center uk-text-muted">
            <strong class="uk-panel"><?php echo count_user_posts($author_id,'post',true); ?></strong>文章
        </div>
        <div class="author-data-item uk-text-center uk-text-muted">
            <strong class="uk-panel"><?php  echo umtu_author_posts_views($author_id)?></strong>浏览
        </div>
        <div class="author-data-item uk-text-center uk-text-muted">
            <div class="author-data-item uk-text-center uk-text-muted">
                <strong class="uk-panel"><?php commentCount(); ?></strong>评论
            </div>
        </div>
    </div>
</div>
<div class="tools uk-block-default">
    <div class="tools-title b-t b-b">
        <i class="iconfont icon-icon-test15"></i> Ta的信息
    </div>
    <div class="author-info">
        <ul class=" uk-list">
            <li class="b-b">UID：<?php echo $author_id?></li>
            <li class="b-b">微信：<?php if ( get_the_author_meta( 'weixin' ) ){echo get_the_author_meta( 'weixin' );}else {echo '暂无';}?></li>
            <li class="b-b">QQ ：<?php if ( get_the_author_meta( 'qq' ) ){echo get_the_author_meta( 'qq' );}else {echo '暂无';}?></li>
            <li class="b-b">站点：<?php if ( get_the_author_meta( 'site_url' ) ){echo get_the_author_meta( 'site_url' );}else {echo '暂无';}?></li>
            <li>邮箱：<?php echo get_the_author_meta('user_email',$author_id)?></li>

        </ul>
    </div>
</div>