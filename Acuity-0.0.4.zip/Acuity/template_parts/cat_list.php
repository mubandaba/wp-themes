<div class="part">
    <div class="part-title uk-text-center">
        <h3><?php echo _umtu('cats_title')?></h3>
    </div>
    <div class="category">
        <div class="category-container uk-position-relative uk-nbfc">
            <div class="swiper-wrapper">
                <?php
                $include_cat = _umtu('selected_cats');
                $terms = get_terms( array(
                    'taxonomy' => 'category',
                    'include' => $include_cat,
                    'hide_empty' => false,
                ) );
                foreach ($terms as $term):
                $term_id = $term->term_id;
                $term_link = get_term_link($term_id);
                $cat_gallery = get_term_meta( $term_id, 'cat_gallery', true );
                $cat_gallery = explode(',',$cat_gallery);
                $cat_img_1 = current($cat_gallery);
                $cat_img_2 = array_slice($cat_gallery,1,1)[0];
                $cat_img_3 = end($cat_gallery);
                ?>
                <div class="swiper-slide">
                    <div class="category-item uk-grid uk-grid-collapse b-r-4">
                        <div class="category-img-l uk-width-7-10">
                            <a href="<?php echo $term_link?>" target="_blank" class="uk-position-relative">
                                <img src="<?php echo xyz_src($cat_img_1);?>"/>
                                <div class="cover uk-position-absolute">
                                    <h3><?php echo $term->name;?></h3>
                                </div>
                            </a>
                        </div>
                        <div class="uk-width-3-10">
                            <div class="category-img-s">
                                <img src="<?php echo xyz_src($cat_img_2);?>"/>
                            </div>
                            <div class="category-img-s uk-position-relative">
                                <img src="<?php echo xyz_src($cat_img_3);?>"/>
                                <a href="<?php echo $term_link?>" target="_blank">
                                    <div class="cover uk-text-contrast uk-position-absolute">
                                        更多<i class="iconfont icon-icon-test26"></i>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach;?>
            </div>
            <div class="category-pagination uk-text-center uk-margin-top"></div>
        </div>
    </div>
</div>