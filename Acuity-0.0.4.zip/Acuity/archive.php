<?php get_header();?>
<main>
    <div class="category">
            <div class="uk-block-default b-t">
                <div class="uk-container uk-container-center">
                    <div class="page-top part-title">
                        <h3><?php the_archive_title();?></h3>
                        <p><?php echo category_description()?></p>
                    </div>
                </div>
            </div>
            <div class="category-list b-t uk-block-default">
                <ul class="uk-container uk-container-center uk-overflow-container">
                    <?php
                    $category = get_category( get_query_var( 'cat' ) );
                    $cat_id = $category->cat_ID;
                    $cats = get_terms( array(
                        'taxonomy'   => 'category',
                        'hide_empty' => true,
                        'parent'     => 0
                    ) );
                    foreach($cats as $cat){
                        $cat_link=get_term_link($cat->term_id);
                        if($cat_id==$cat->term_id){
                            $class='current-cat';
                        }else{
                            $class='';
                        }
                        echo '<li class="cat-item cat-item-'.$cat->term_id.' '. $class.'"><a href="'.$cat_link.'">'.$cat->name.'</a></li>';
                    }
                    ?>
                </ul>
            </div>

            <div class="uk-container uk-container-center">
                <?php umtu_breadcrumbs();?>
                <div class="article-main uk-grid">

                    <div class="uk-width-1-1 uk-width-medium-7-10 uk-width-large-7-10">
                        <div class="uk-grid uk-grid-medium" data-uk-grid >
                            <?php if (have_posts()):while (have_posts()):the_post();$author_id = get_post_field( 'post_author', get_the_ID() ); ?>
                            <div class="uk-width-1-1 uk-width-small-1-2 uk-width-medium-1-2 uk-width-large-1-3 uk-margin-bottom">
                                <figure class="pic-item shadow uk-block-default uk-margin-bottom uk-nbfc b-r-4">
                                    <div class="uk-overlay uk-overlay-hover">
                                        <div class="uk-overlay pic-item-cover uk-overlay-hover">
                                            <a href="<?php the_permalink();?>">
                                                <img class="uk-overlay-scale" src="<?php umtu_thumb('post_thumb');?>">
                                            </a>
                                        </div>
                                        <div class="item-info uk-margin-left uk-margin-right">
                                            <div class="author">
                                                <span class="s-avatar rotate uk-display-block">
                                                    <a href="<?php echo get_author_posts_url($author_id)?>">
                                                        <img src="<?php echo get_avatar_url($author_id);?>" class="avatar avatar-200 photo" height="200" width="200" />
                                                    </a>
                                                </span>
                                                <span class="uk-text-muted uk-margin-small-left uk-margin-small-top"><?php the_author_meta('nickname',$author_id);?></span>
                                            </div>
                                            <div class="category uk-margin-small-top">
                                                <?php $cat_lists = get_the_category();if ($cat_lists):foreach ($cat_lists as $cat_list):$cat_list_link= get_category_link($cat_list->term_id)?>
                                                    <a href="<?php echo $cat_list_link?>" rel="category tag"><?php echo $cat_list->name?></a>
                                                <?php endforeach;endif;?>
                                            </div>
                                            <h3 class="uk-margin-top">
                                                <a href="<?php the_permalink();?>"><?php the_title()?></a>
                                            </h3>
                                            <div class="data uk-text-small uk-margin-bottom uk-margin-top">
                                                <span class="uk-margin-right"><i class="iconfont icon-rili"></i><?php the_time('Y-m-d');?></span>
                                                <span class="uk-margin-right"><i class="iconfont icon-eye"></i><?php post_views('', ''); ?></span>
                                                <span class="uk-hidden-small"><i class="iconfont icon-message"></i>0</span>
                                            </div>
                                        </div>
                                </figure>
                            </div>
                            <?php endwhile;endif;?>
                        </div>
                        <?php if (_umtu('page_type')=='center'){$page_type = 'uk-text-center';}?>
                        <div class="fenye uk-margin-large-top <?php echo $page_type?>">
                            <?php umtu_pagenavi(); ?>
                        </div>
                    </div>
                    <div class="uk-width-3-10 uk-hidden-small">
                        <div class="shadow">
                            <div class="box uk-block-default  b-r-4">
                                <div class="box-title b-b b-t">
                                    <h3><i class="iconfont icon-dingdan"></i> 热门文章</h3>
                                </div>
                                <div class="box-main">
                                    <div class="box-list">
                                        <?php
                                        $cat = get_the_category();
                                        foreach($cat as $key=>$category){
                                            $catid = $category->term_id;
                                        }
                                        $args = array('showposts' => 8,'cat' => $catid,'meta_key' => 'umtu_view','orderby' => 'meta_value_num',);
                                        $query_posts = new WP_Query();
                                        $query_posts->query($args);
                                        while ($query_posts->have_posts()) : $query_posts->the_post();?>
                                            <li class="b-b">
                                                <a href="<?php the_permalink(); ?>" ><?php the_title(); ?></a>
                                            </li>
                                        <?php endwhile; wp_reset_postdata(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="box uk-block-default b-r-4">
                                <div class="box-title b-b b-t">
                                    <h3><i class="iconfont icon-dingdan"></i> 最新评论</h3>
                                </div>
                                <div class="box-main new-comment">
                                    <?php umtu_recent_comments()?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</main>
<?php get_footer();?>