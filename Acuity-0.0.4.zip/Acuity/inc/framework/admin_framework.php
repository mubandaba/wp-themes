<?php
if( class_exists( 'CSF' ) ) {
    $prefix = 'umtu_framework';
    CSF::createOptions( $prefix, array(
        'menu_title' => '主题设置',
        'menu_slug'  => 'theme_setting',
        'theme'      => 'light',
    ) );
    //
// 基本设置
//
    CSF::createSection( $prefix, array(
        'title'  => '基本设置',
        'icon'   => 'fa fa-tachometer',
        'fields' => array(

            array(
                'id'      => 'web_logo',
                'type'    => 'media',
                'title'   => '网站logo',
                'library' => 'image',
                'url'     => false,
            ),
            array(
                'id'      => 'web_favicon',
                'type'    => 'media',
                'title'   => 'favicon图标',
                'library' => 'image',
                'url'     => false,
            ),
            array(
                'id'         => 'avatar_type',
                'type'       => 'radio',
                'title'      => '用户头像',
                'subtitle'   => '建议使用自定义头像，禁用Gravatar头像能稍微改善访问速度',
                'options'    => array(
                    'gravatar' => 'Gravatar头像',
                    'custom' => '自定义头像',
                ),
                'default'    => 'custom'
            ),
            array(
                'id'         => 'page_type',
                'type'       => 'radio',
                'title'      => '分页按钮位置',
                'options'    => array(
                    'center' => '居中对齐',
                    'left'  => '居左对齐',
                ),
                'default'    => 'left'
            ),
            array(
                'id'         => 'default_thumb',
                'type'       => 'media',
                'title'      => '默认缩略图',
                'subtitle'   => '在文章没有设置特色图片的情况下将显示此图片',
                'library'    => 'image',
                'url'        => false,
            ),
            array(
                'id'     => 'qrcode_modal',
                'type'   => 'fieldset',
                'title'  => '二维码弹窗',
                'fields' => array(
                    array(
                        'id'         => 'qrcode_title',
                        'type'       => 'text',
                        'title'      => '弹窗标题',
                    ),
                    array(
                        'id'         => 'qrcode_img',
                        'type'       => 'media',
                        'title'      => '二维码',
                        'subtitle'   => '多用途，例如微信二维码，微信/支付宝收钱码',
                        'library'    => 'image',
                        'url'        => false,
                    ),
                ),
            ),
            array(
                'id'    => 'um_homelink_set',
                'type'  => 'switcher',
                'text_on' => '开',
                'text_off'=> '关',
                'title' => '开启/关闭首页友情链接',
            ),
        )
    ) );

    //
// 首页设置
//
    CSF::createSection( $prefix, array(
        'id'    => 'index_fields',
        'title' => '首页设置',
        'icon'  => 'fa fa-home',
    ));
    //
// 首页搜索模块
//
    CSF::createSection( $prefix, array(
        'parent' => 'index_fields',
        'title'  => '首页搜索模块',
        'icon'   => 'fa fa-search',
        'fields'      => array(
            array(
                'id'    => 'search_title',
                'type'  => 'text',
                'title' => '搜索框标题',
            ),
            array(
                'id'    => 'search_placeholder',
                'type'  => 'text',
                'title' => '自定义placeholder',
                'subtitle' => '修改搜索框的占位符',
            ),
            array(
                'id'    => 'bg_search',
                'type'  => 'media',
                'title' => '首页搜索框背景',
                'url'   => false,
            ),
            array(
                'id'     => 'hot_key',
                'type'   => 'repeater',
                'title'  => '首页热搜词',
                'subtitle' => '如果不想显示热搜词，此处留空即可',
                'fields' => array(
                    array(
                        'id'    => 'hot_search_key',
                        'type'  => 'text',
                    ),

                ),
            ),

        ),
    ) );
    //
// 分类推荐模块
//
    CSF::createSection( $prefix, array(
        'parent' => 'index_fields',
        'title'  => '分类推荐模块',
        'icon'   => 'fa fa-star',
        'fields' => array(
            array(
                'id'      => 'cats_title',
                'type'    => 'text',
                'title'   => '分类推荐模块标题',
                'default' => '热门分类',
            ),
            array(
                'id'          => 'selected_cats',
                'type'        => 'select',
                'title'       => '分类推荐',
                'placeholder' => '请选择',
                'chosen'      => true,
                'multiple'    => true,
                'options'     => 'categories',
            ),
        )
    ) );
    //
// 分类CMS展示
//
    CSF::createSection( $prefix, array(
        'parent'      => 'index_fields',
        'title'       => '分类CMS展示',
        'icon'        => 'fa fa-newspaper-o',
        'description' => '此处设置内容为首页分类CMS展示模块，可以设置无限个',
        'fields'      => array(

            array(
                'id'     => 'cat_cms',
                'type'   => 'group',
                'title'  => '无限分类CMS',
                'fields' => array(
                    array(
                        'id'      => 'cms_title',
                        'type'    => 'text',
                        'title'   => 'CMS标题',
                        'default' => 'CMS资源展示',
                    ),
                    array(
                        'id'        => 'cms_layout',
                        'type'      => 'image_select',
                        'title'     => '展示样式',
                        'options'   => array(
                            'grid'      => get_template_directory_uri().'/static/images/grid.png',
                            'list'      => get_template_directory_uri().'/static/images/list.png',
                            'waterfall' => get_template_directory_uri().'/static/images/waterfall.png',
                        ),
                        'default'   => 'grid'
                    ),
                    array(
                        'id'          => 'cms_cat_id',
                        'type'        => 'select',
                        'title'       => '文章分类',
                        'placeholder' => '选择分类',
                        'options'     => 'categories',
                    ),
                    array(
                        'id'      => 'cms_cat_num',
                        'type'    => 'slider',
                        'title'   => 'CMS显示文章数量',
                        'desc'    => '默认为8',
                        'default' => 8,
                    ),
                ),
            ),

        ),
    ) );
    //
// 友情链接
//
    CSF::createSection( $prefix, array(
        'parent' => 'index_fields',
        'title'  => '友情链接',
        'icon'   => 'fa fa-link',
        'fields' => array(

            array(
                'id'     => 'friend_links',
                'type'   => 'group',
                'fields' => array(
                    array(
                        'id'      => 'friend_title',
                        'type'    => 'text',
                        'title'   => '友链标题',
                        'default' => 'JOYtheme',
                    ),
                    array(
                        'id'      => 'friend_url',
                        'type'    => 'text',
                        'title'   => 'URL',
                        'default' => 'https://www.joytheme.com/',
                    ),
                ),
            ),
        )
    ) );
    //
// 文章设置
//
    CSF::createSection( $prefix, array(
        'title'  => '文章设置',
        'icon'   => 'fa fa-book',
        'fields' => array(
            array(
                'id'      => 'um_sidebar_set',
                'type'    => 'switcher',
                'text_on' => '开',
                'text_off'=> '关',
                'title'   => '文章页侧边栏',
            ),
            array(
                'id'      => 'um_reward_set',
                'type'    => 'switcher',
                'text_on' => '开',
                'text_off'=> '关',
                'title'   => '开启文章打赏',
            ),
            array(
                'id'      => 'um_reward_code',
                'type'    => 'media',
                'title'   => '收钱码',
                'library' => 'image',
                'url'     => false,
                'dependency' => array( 'um_reward_set', '==', 'true' ),
            ),
            array(
                'id'      => 'um_zan_set',
                'type'    => 'switcher',
                'text_on' => '开',
                'text_off'=> '关',
                'title'   => '开启文章点赞',
            ),

            array(
                'id'      => 'um_article_set',
                'type'    => 'switcher',
                'text_on' => '开',
                'text_off'=> '关',
                'title'   => '文章底部版权',
            ),
            array(
                'id'      => 'um_article_cop',
                'type'    => 'textarea',
                'title'   => '版权信息',
                'subtitle'  => '留下你想说的话',
                'default'   => '转载文章时请以链接形式标注原文出处',
                'dependency' => array( 'um_article_set', '==', 'true' ),
            ),
            array(
                'id'      => 'um_recommend_set',
                'type'    => 'switcher',
                'text_on' => '开',
                'text_off'=> '关',
                'title'   => '文章底部推荐',
            ),
            array(
                'id'      => 'um_recommend_title',
                'type'    => 'text',
                'title'   => '推荐标题',
                'subtitle'  => '例如：猜你喜欢、相关文章、热门文章等',
                'default'   => '猜你喜欢',
                'dependency' => array( 'um_recommend_set', '==', 'true' ),
            ),
            array(
                'id'      => 'um_recommend_num',
                'type'    => 'slider',
                'title'   => '推荐文章数量',
                'min'     => 3,
                'max'     => 12,
                'step'    => 3,
                'unit'    => '篇',
                'default' => 3,
                'subtitle'  => '这个版块采用的是3列布局，建议显示3篇或6篇，亲测显示太多会影响阅读体验',
                'dependency' => array( 'um_recommend_set', '==', 'true' ),
            ),
            array(
                'id'      => 'um_poster_set',
                'type'    => 'switcher',
                'text_on' => '开',
                'text_off'=> '关',
                'title'   => '生成海报',
            ),
            array(
                'id'        => 'poster_logo',
                'type'      => 'media',
                'title'     => '海报logo（尺寸：200*50）',
                'desc'      => '显示在海报图片底部，建议与网站Logo保持一致。',
                'add_title' => '上传 LOGO',
                'url'       => false,
                'dependency' => array( 'um_poster_set', '==', 'true' ),

            ),
            array(
                'id'		=> 'poster_desc',
                'type'		=> 'text',
                'title'		=> '海报Logo下面的一段文字描述',
                'attributes'=> array('style'=> 'width: 100%;'),
                'dependency' => array( 'um_poster_set', '==', 'true' ),

            ),
        )
    ) );

//
// 广告设置
//
    CSF::createSection( $prefix, array(
        'title'  => '广告设置',
        'icon'   => 'fa fa-volume-up',
        'fields' => array(
            array(
                'id'     => 'um_ad_top',
                'type'   => 'fieldset',
                'title'  => '文章页顶部双栏',
                'fields' => array(
                    array(
                        'type'    => 'submessage',
                        'style'   => 'info',
                        'content' => '文章页顶部双栏广告位——A1，图片尺寸：548*76   <a href="'.get_template_directory_uri().'/static/images/adshow.png" target="_blank">查看图示</a>',
                    ),
                    array(
                        'id'    => 'um_ad_top_title_1',
                        'type'  => 'text',
                        'title' => '标题',
                    ),
                    array(
                        'id'      => 'um_ad_top_img_1',
                        'type'    => 'media',
                        'title'   => '图片',
                        'library' => 'image',
                        'url'     => false,
                    ),
                    array(
                        'id'    => 'um_ad_top_link_1',
                        'type'  => 'text',
                        'title' => '链接',
                    ),
                    array(
                        'type'    => 'submessage',
                        'style'   => 'info',
                        'content' => '文章页顶部双栏广告位——A1，图片尺寸：548*76   <a href="'.get_template_directory_uri().'/static/images/adshow.png" target="_blank">查看图示</a>',
                    ),
                    array(
                        'id'    => 'um_ad_top_title_2',
                        'type'  => 'text',
                        'title' => '标题',
                    ),
                    array(
                        'id'      => 'um_ad_top_img_2',
                        'type'    => 'media',
                        'title'   => '图片',
                        'library' => 'image',
                        'url'     => false,
                    ),
                    array(
                        'id'    => 'um_ad_top_link_2',
                        'type'  => 'text',
                        'title' => '链接',
                    ),
                ),
            ),
            array(
                'id'     => 'um_ad_cont',
                'type'   => 'fieldset',
                'title'  => '文章内容顶部单栏',
                'fields' => array(
                    array(
                        'type'    => 'submessage',
                        'style'   => 'info',
                        'content' => '文章内容顶部单栏广告位——B1，图片尺寸：1070*100   <a href="'.get_template_directory_uri().'/static/images/adshow.png" target="_blank">查看图示</a>',
                    ),
                    array(
                        'id'    => 'um_ad_cont_title',
                        'type'  => 'text',
                        'title' => '标题',
                    ),
                    array(
                        'id'      => 'um_ad_cont_img',
                        'type'    => 'media',
                        'title'   => '图片',
                        'library' => 'image',
                        'url'     => false,
                    ),
                    array(
                        'id'    => 'um_ad_cont_link',
                        'type'  => 'text',
                        'title' => '链接',
                    ),
                ),
            ),
        )
    ) );
//
// 首页SEO
//
    CSF::createSection( $prefix, array(
        'title'  => '首页SEO',
        'id	'    => 'seo',
        'icon'   => 'fa fa-rocket',
        'fields' => array(
            array(
                'type'    => 'submessage',
                'style'   => 'danger',
                'content' => '此处只适用于设置首页SEO，本主题有完备的SEO优化，其他页面的SEO分别在各自的创建页面</br>例如：分类页的SEO设置在"文章->分类目录->创建分类目录处"，文章页的SEO设置在每篇文章的编辑页面都可以自行设置</br>
                如果您觉得这样设置太过繁琐，不用担心，我们还有备选方案，在您没有填写这些SEO选项时，代码会自动抓取相应的内容作为标题、关键词、描述等。',
            ),
            array(
                'id'    => 'index_title',
                'type'  => 'text',
                'title' => '标题',
            ),
            array(
                'id'    => 'index_keywords',
                'type'  => 'text',
                'title' => '关键词',
            ),
            array(
                'id'    => 'index_description',
                'type'  => 'textarea',
                'title' => '描述',
            ),

        )
    ) );

//
// SMTP设置
//
    CSF::createSection($prefix, array(
        'title'       => 'SMTP设置',
        'icon'        => 'fa fa-envelope',
        'description' => 'SMTP设置可以解决wordpress无法发送邮件问题，建议用QQ邮箱，注意QQ邮箱的密码是独立密码。不是QQ密码！',
        'fields'      => array(

            array(
                'id'      => 'mail_smtps',
                'type'    => 'switcher',
                'text_on' => '开',
                'text_off'=> '关',
                'title'   => '是否启用SMTP服务',
                'label'   => '该设置主题自带，不能与插件重复开启',
                'default' => false,
            ),
            array(
                'id'       => 'mail_name',
                'type'     => 'text',
                'title'    => '发信邮箱',
                'subtitle' => '请填写发件人邮箱帐号',
                'default'  => '88888888@qq.com',
                'validate' => 'csf_validate_email',
                'dependency' => array( 'mail_smtps', '==', 'true' ),

            ),

            array(
                'id'       => 'mail_host',
                'type'     => 'text',
                'title'    => '邮件服务器',
                'subtitle' => '请填写SMTP服务器地址',
                'default'  => 'smtp.qq.com',
                'dependency' => array( 'mail_smtps', '==', 'true' ),

            ),
            array(
                'id'       => 'mail_port',
                'type'     => 'text',
                'title'    => '服务器端口',
                'subtitle' => '请填写SMTP服务器端口',
                'default'  => '465',
                'dependency' => array( 'mail_smtps', '==', 'true' ),

            ),
            array(
                'id'       => 'mail_passwd',
                'type'     => 'text',
                'title'    => '邮箱密码',
                'subtitle' => '请填写SMTP服务器邮箱密码',
                'default'  => '88888888',
                'dependency' => array( 'mail_smtps', '==', 'true' ),

            ),
            array(
                'id'      => 'mail_smtpauth',
                'type'    => 'switcher',
                'text_on' => '启用',
                'text_off'=> '禁用',
                'title'   => '启用SMTPAuth服务',
                'label'   => '是否启用SMTPAuth服务',
                'default' => true,
                'dependency' => array( 'mail_smtps', '==', 'true' ),

            ),
            array(
                'id'       => 'mail_smtpsecure',
                'type'     => 'text',
                'title'    => 'SMTPSecure设置',
                'subtitle' => '若启用SMTPAuth服务则填写ssl，若不启用则留空',
                'default'  => 'ssl',
                'dependency' => array( 'mail_smtps', '==', 'true' ),
            ),

        ),
    ));

    //
// 底部信息
//
    CSF::createSection( $prefix, array(
        'title'  => '底部信息',
        'icon'        => 'fa fa-window-minimize',
        'fields' => array(

            array(
                'id'    => 'um_foot_icp',
                'type'  => 'text',
                'title' => '网站备案',
            ),
            array(
                'id'    => 'um_foot_email',
                'type'  => 'text',
                'title' => '邮箱',
            ),
            array(
                'id'    => 'um_foot_qq',
                'type'  => 'text',
                'title' => 'QQ',
            ),
            array(
                'id'    => 'um_foot_weibo',
                'type'  => 'text',
                'title' => '微博',
            ),
            array(
                'id'       => 'um_foot_tj',
                'type'     => 'code_editor',
                'title'    => '网站统计',
                'settings' => array(
                    'theme'  => 'monokai',
                    'mode'   => 'javascript',
                ),
                'default'  => 'console.log("Hello world");',
            ),
            array(
                'id'       => 'um_foot_code',
                'type'     => 'code_editor',
                'title'    => '页底代码',
                'settings' => array(
                    'theme'  => 'monokai',
                    'mode'   => 'javascript',
                ),
                'default'  => 'console.log("Hello world");',
            ),
        )
    ) );

//
// 备份恢复
//
    CSF::createSection( $prefix, array(
        'title'  => '备份恢复',
        'icon'   => 'fa fa-shield',
        'fields' => array(
            array(
                'type' => 'backup',
            ),
        )
    ) );
}