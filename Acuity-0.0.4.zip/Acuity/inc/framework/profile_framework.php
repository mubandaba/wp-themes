<?php
if( class_exists( 'CSF' ) ) {

    $prefix = 'umtu_profile_options';

    CSF::createProfileOptions( $prefix, array(
        'data_type' => 'unserialize',
    ) );

    CSF::createSection( $prefix, array(
        'fields' => array(

            array(
                'id'    => 'user_img',
                'type'  => 'media',
                'title' => '用户头像',
                'url'   => false,
            ),
            array(
                'id'    => 'author_top_img',
                'type'  => 'media',
                'title' => '背景图片',
                'subtitle' => '用作用户文章归档页头部的背景图片',
                'url'   => false,
            ),

        )
    ) );

}