<?php
if( class_exists( 'CSF' ) ) {
    $prefix = 'umtu_taxonomy_options';
    CSF::createTaxonomyOptions( $prefix, array(
        'taxonomy'  => 'category',
        'data_type' => 'unserialize',
    ) );
    CSF::createSection( $prefix, array(
        'fields' => array(
            array(
                'id'          => 'cat_gallery',
                'type'        => 'gallery',
                'title'       => '分类相册',
                'add_title'   => '添加图片',
                'edit_title'  => '编辑相册',
                'clear_title' => '移除图片',
            ),

        )
    ) );

//    CSF::createSection( $prefix, array(
//        'fields' => array(
//            array(
//                'id'        => 'single_layout',
//                'type'      => 'image_select',
//                'title'     => '此分类下文章详情页样式',
//                'options'   => array(
//                    'normal'=> get_template_directory_uri().'/static/images/single-normal.png',
//                    'tx'    => get_template_directory_uri().'/static/images/single-tx.png',
//                ),
//                'default'   => 'grid'
//            ),
//        )
//    ) );
}