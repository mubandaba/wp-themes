<?php
if( class_exists( 'CSF' ) ) {
    $post_meta = 'post_meta';
    CSF::createMetabox($post_meta, array(
        'title'     => '文章统计',
        'post_type' => 'post',
        'data_type' => 'unserialize',
        'context'   => 'side',
        'priority'  => 'high',
        'theme'     => 'light',
    ));
    CSF::createSection($post_meta, array(
        'fields'    => array(
            array(
                'id'          => 'dotGood',
                'title'       => '点赞数',
                'type'        => 'text',
                'default'     => '0',

            ),
            array(
                'id'          => 'umtu_view',
                'title'       => '浏览量',
                'type'        => 'text',
                'default'     => '0',

            ),
        )
    ) );

}