<?php
function joytheme_enqueue_sources() {
    wp_enqueue_style ( 'style'   ,get_template_directory_uri()."/static/css/style.css"        ,array(), false, 'all');
    wp_enqueue_style ( 'social'   ,get_template_directory_uri()."/static/css/social.css"        ,array(), false, 'all');
    wp_enqueue_style ( 'uikit'   ,get_template_directory_uri()."/static/css/uikit.css"        ,array(), false, 'all');
    //wp_enqueue_style ( 'add'     ,get_template_directory_uri()."/static/css/add.css"          ,array(), false, 'all');
    if(is_singular()){
    wp_enqueue_style ( 'slidenav',get_template_directory_uri()."/static/css/slidenav.min.css" ,array(), false, 'all');
    }
    wp_enqueue_style ( 'tooltip' ,get_template_directory_uri()."/static/css/tooltip.min.css"  ,array(), false, 'all');
    wp_enqueue_style ( 'notify'  ,get_template_directory_uri()."/static/css/notify.min.css"   ,array(), false, 'all');
    wp_enqueue_style ( 'swiper'  ,get_template_directory_uri()."/static/css/swiper.min.css"   ,array(), false, 'all');
    wp_enqueue_style ( 'icon'    ,get_template_directory_uri()."/static/css/icon.css"         ,array(), false, 'all');
    wp_enqueue_style ( 'prism'   ,get_template_directory_uri()."/static/css/prism.css"        ,array(), false, 'all');
    wp_enqueue_script( 'jquery'  ,get_template_directory_uri()."/static/js/jquery.js"         ,array(), false, false);
    wp_enqueue_script( 'swiper'  ,get_template_directory_uri()."/static/js/swiper.min.js"     ,array(), false, true);
    wp_enqueue_script( 'uikit'   ,get_template_directory_uri()."/static/js/uikit.min.js"      ,array(), false, true);
    wp_enqueue_script( 'notify'  ,get_template_directory_uri()."/static/js/notify.min.js"     ,array(), false, true);
    wp_enqueue_script( 'grid'    ,get_template_directory_uri()."/static/js/grid.min.js"       ,array(), false, true);
    if (is_singular()||is_page()){
    wp_enqueue_script( 'lightbox',get_template_directory_uri()."/static/js/lightbox.min.js"   ,array(), false, true);
    }
    wp_enqueue_script( 'tooltip' ,get_template_directory_uri()."/static/js/tooltip.min.js"    ,array(), false, true);
    wp_enqueue_script( 'prism' ,get_template_directory_uri()."/static/js/prism.js"    ,array(), false, true);
    wp_enqueue_script( 'index'   ,get_template_directory_uri()."/static/js/index.js"          ,array(), false, true);
}
add_action('wp_enqueue_scripts' , 'joytheme_enqueue_sources' , 2);
