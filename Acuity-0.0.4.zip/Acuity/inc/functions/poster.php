<?php
//分享海报
function xyz_poster() {
    $directory_url = get_stylesheet_directory_uri();
    $bt = get_the_title();
    $zy = wp_trim_words(get_the_excerpt() , 80);
    $xyz_poster = get_option('umtu_framework');
    $poster_logo = $xyz_poster['poster_logo']['url'];
    $poster_desc = $xyz_poster['poster_desc'];
    if ($poster_logo) {$lo = $poster_logo;} else {$lo = $directory_url. "/inc/functions/images/logo.png";}
    $bg                = $directory_url. "/inc/functions/images/timebg.png";
    $xux               = $directory_url. "/inc/functions/images/xuxian.png";
    $sj                = get_the_time('Y/m d'); //时间
    $zz                = "作者：" . get_the_author_meta('nickname');
    $describe          = $poster_desc;
    $qr                = $directory_url. "/inc/functions/public/qrcode?data=".get_permalink();
    $the_post_category = get_the_category(get_the_ID());
    $im                = $directory_url. '/inc/functions/public/image?pic=' . get_the_post_thumbnail_url('',array(648, 450)). '&title=' . $bt . '&excerpt=' . $zy . '&line=' . $xux . '&logo=' . $lo . '&timebg=' . $bg . '&time=' . $sj . '&author=' . $zz . '  发布于：「' . $the_post_category[0]->cat_name . '」&describe=' . $describe . '&code=' . $qr;
    return $im;
}

//在所有文章底部添加自定义内容
function xyz_poster_share() {
    if(!is_feed() && !is_home() && is_singular() && is_main_query()) {
        $xyz_poster = xyz_poster();
        $share_title = get_the_title();
        $share_link = get_permalink();
        $share_excerpt = get_the_excerpt();
        $weibo='http://service.weibo.com/share/share.php?title='.$share_title.'&url='.$share_link.'&source='.$share_excerpt.'&pic='.$xyz_poster;
        $qq   ='http://connect.qq.com/widget/shareqq/index.html?url='.$share_link.'&desc='.$share_excerpt.'&summary='.$share_title.'&site=zeshlife&pics='.$xyz_poster;
        $qzone='https://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url='.$share_link.'&title='.$share_title.'&desc=&summary='.$share_excerpt.'&site=zeshlife&pics='.$xyz_poster;
        $content ='';
        $content.= '<a href="#umtu_poster" data-uk-modal="" class="reward b-r-4">';
        $content.= '<i class="iconfont icon-plane"></i><span class="count">生成海报</span>';
        $content.= '</a>';
        $content.= '<div id="umtu_poster" class="uk-modal">';
        $content.= '<div class="uk-modal-dialog b-r-4">';
        $content.= '<div class="part-title uk-text-center uk-grid">';
        $content.= '<p class="uk-text-center uk-width-2-3">';
        $content.= '<img src="'.$xyz_poster.'">';
        $content.= '</p>';
        $content.= '<p class="uk-text-center uk-width-1-3 uk-child-width-1-1" style="padding-left: 0px; padding-top: 150px">';
        $content.= '<a target="_blank" href="'.$weibo.'" class="more vary-bg  uk-text-contrast b-r-4 uk-display-inline-block" target="_blank" style="margin-left: 15px;margin-bottom: 15px;">新浪微博<i class="iconfont  icon-plane uk-margin-small-left"></i></a>';
        $content.= '<a target="_blank" href="'.$qq.'" class="more vary-bg  uk-text-contrast b-r-4 uk-display-inline-block" target="_blank" style="margin-left: 15px;margin-bottom: 15px;">QQ 分享<i class="iconfont  icon-plane uk-margin-small-left"></i></a>';
        $content.= '<a target="_blank" href="'.$qzone.'" class="more vary-bg  uk-text-contrast b-r-4 uk-display-inline-block" target="_blank" style="margin-left: 15px;margin-bottom: 15px;">QQ 空间<i class="iconfont  icon-plane uk-margin-small-left"></i></a>';
        $content.= '<a target="_blank" href="'.$xyz_poster.'" download="'.$share_title.'.png" class="more vary-bg  uk-text-contrast b-r-4 uk-display-inline-block" target="_blank" style="margin-left: 15px;margin-bottom: 15px;">下载海报<i class="iconfont icon-xiazai uk-margin-small-left"></i></a>';
        $content.= '</p>';
        $content.= '</div>';
        $content.= '</div>';
        $content.= '</div>';
        echo $content;
    }
}




