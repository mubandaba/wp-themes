<?php
# 定义函数
# ----------------------------------------------------------------------------------------------------------------------
if ( ! function_exists( '_umtu' ) ) {
    function _umtu( $option = '', $default = null ) {
        $options = get_option('umtu_framework');
        return ( isset( $options[$option] ) ) ? $options[$option] : $default;
    }
}
if (!function_exists('_umtu_img')) {
    function _umtu_img($option = '', $default = '')
    {
        $options = get_option('umtu_framework');
        $_umtu_img_id = $options[$option]['id'];
        $_umtu_img_url = wp_get_attachment_image_url($_umtu_img_id,'full');
        return ( isset( $options[$option] ) ) ? $_umtu_img_url : $default;
    }
}
if (!function_exists('_umtu_user_img')) {
    function _umtu_user_img($option, $author_id ,$default=''){
        $user_banner_id = get_user_meta($author_id,$option,true)['id'];
        $user_banner_url = wp_get_attachment_image_url($user_banner_id,'full');
        return ($user_banner_url) ? $user_banner_url : $default;
    }
}


# 支持特色图像并添加自定义裁剪尺寸
# ----------------------------------------------------------------------------------------------------------------------
add_theme_support('post-thumbnails');
add_image_size('post_thumb', '420', '380', true);
# 自定义名称
# ----------------------------------------------------------------------------------------------------------------------
function xyz_archive_title($title){

    if (is_category()) {
        $title = single_cat_title('', false);
    } elseif (is_tag()) {
        $title = single_tag_title('', false);
    } elseif (is_author()) {
        $title = '<span class="vcard">' . get_the_author() . '</span>';
    } elseif (is_post_type_archive()) {
        $title = post_type_archive_title('', false);
    } elseif (is_tax()) {
        $title = single_term_title('', false);
    }
    return $title;
}

add_filter('get_the_archive_title', 'xyz_archive_title');
# 调用图像
# ----------------------------------------------------------------------------------------------------------------------
function xyz_src($img_id = '', $size = '',$default=''){

    if ($img_id) {
        $img_src = wp_get_attachment_image_src($img_id, $size);
        $img_url = $img_src[0];
    } elseif($default) {
        $img_url = $default;
    }else {
        $img_url = get_template_directory_uri().'/static/images/noimg.png';
    }
    return $img_url;
}

# 获取用户角色
# ----------------------------------------------------------------------------------------------------------------------
function get_user_role($id)
{
    $user = new WP_User($id);
    return array_shift($user->roles);
}

# 修改用户角色名称和添加新用户角色
# ----------------------------------------------------------------------------------------------------------------------
function umtu_change_role_name() {
    global $wp_roles;

    if ( ! isset( $wp_roles ) )
        $wp_roles = new WP_Roles();
    $wp_roles->roles['administrator']['name'] = '网站管理员';
    $wp_roles->roles['editor']['name'] = '特约编辑';
    $wp_roles->role_names['editor'] = '特约编辑';
    $wp_roles->role_names['administrator'] = '网站管理员';
}
add_action('init', 'umtu_change_role_name');
# AJAX点赞
# ----------------------------------------------------------------------------------------------------------------------
function dotGood()
{
    global $wpdb, $post;
    $id = $_POST["um_id"];
    if ($_POST["um_action"] == 'topTop') {
        $specs_raters = get_post_meta($id, 'dotGood', true);
        $expire = time() + 99999999;
        $domain = ($_SERVER['HTTP_HOST'] != 'localhost') ? $_SERVER['HTTP_HOST'] : false;
        setcookie('dotGood_' . $id, $id, $expire, '/', $domain, false);
        if (!$specs_raters || !is_numeric($specs_raters)) update_post_meta($id, 'dotGood', 1);
        else update_post_meta($id, 'dotGood', ($specs_raters + 1));
        echo get_post_meta($id, 'dotGood', true);
    }
    die;
}

add_action('wp_ajax_nopriv_dotGood', 'dotGood');
add_action('wp_ajax_dotGood', 'dotGood');

# 分页
# ----------------------------------------------------------------------------------------------------------------------
function umtu_pagenavi(){
    $args = array(
        'prev_next'          => 0,
        'format'       => '?paged=%#%',
        'before_page_number' => '',
        'mid_size'           => 2,
        'current' => max( 1, get_query_var('paged') ),
        'prev_next'    => True,
        'prev_text'    => '上一页',
        'next_text'    => '下一页',

    );
    $page_arr=paginate_links($args);
    if ($page_arr) {
        echo $page_arr;
    }
}

# 最新评论
# ----------------------------------------------------------------------------------------------------------------------
function umtu_recent_comments($no_comments = 5, $comment_len = 80, $avatar_size = 24) {
    $comments_query = new WP_Comment_Query();
    $comments = $comments_query->query( array( 'number' => $no_comments ) );
    $comm = '';
    if ( $comments ) : foreach ( $comments as $comment ) :
        $comm .= '<li class="b-b">' . get_avatar( $comment->comment_author_email, $avatar_size );
        $comm .= get_comment_author( $comment->comment_ID ). ' 评论: ';
        $comm .= '<p class="content"><a href="' . esc_url( get_comment_link($comment->comment_ID) ) . '">' . $comment->comment_content . '</a></p></li>';
    endforeach; else :
        $comm .= '暂时没有评论！';
    endif;
    echo $comm;
}

# 浏览量统计
# ----------------------------------------------------------------------------------------------------------------------
function record_visitors(){
    if (is_singular()) {
        global $post;
        $post_ID = $post->ID;
        if($post_ID){
            $post_views = (int)get_post_meta($post_ID, 'umtu_view', true);
            if(!update_post_meta($post_ID, 'umtu_view', ($post_views+1)))
            {
                add_post_meta($post_ID, 'umtu_view', 1, true);
            }
        }
    }
}
add_action('wp_head', 'record_visitors');
function post_views($before = '(点击 ', $after = ' 次)', $echo = 1)
{
    global $post;
    $post_ID = $post->ID;
    $views = (int)get_post_meta($post_ID, 'umtu_view', true);
    if ($echo) echo $before, number_format($views), $after;
    else return $views;
};
# 获取作者文章的浏览总数
# ----------------------------------------------------------------------------------------------------------------------
if(!function_exists('umtu_author_posts_views')) {
    function umtu_author_posts_views($author_id = 1 ,$display = true) {
        global $wpdb;
        $sql = "SELECT SUM(meta_value+0) FROM $wpdb->posts left join $wpdb->postmeta on (
        $wpdb->posts.ID = $wpdb->postmeta.post_id) WHERE meta_key = 'views' AND post_author =$author_id";
        $comment_views = intval($wpdb->get_var($sql));
        if($display) {
            echo number_format_i18n($comment_views);
        } else {
            return $comment_views;
        }
    }
}
# 获取作者文章总数
# ----------------------------------------------------------------------------------------------------------------------
function num_of_author_posts($authorID=''){ //根据作者ID获取该作者的文章数量
    if ($authorID) {
        $author_query = new WP_Query( 'posts_per_page=-1&author='.$authorID );
        $i=0;
        while ($author_query->have_posts()) : $author_query->the_post(); ++$i; endwhile; wp_reset_postdata();
        return $i;
    }
    return false;
}

# 获取作者文章总数和评论总数
# ----------------------------------------------------------------------------------------------------------------------
function commentCount() {
    global $wpdb, $current_user;
    get_currentuserinfo();
    $userId = $current_user->ID;
    $count = $wpdb->get_var('
             SELECT COUNT(comment_ID) 
             FROM ' . $wpdb->comments. ' 
             WHERE user_id = "' . $userId . '"');
    echo $count;
}

# 获取作者文章总数和评论总数
# ----------------------------------------------------------------------------------------------------------------------
if(is_search()){
    add_filter('posts_orderby_request', 'search_orderby_filter');
}
function search_orderby_filter($orderby = ''){
    global $wpdb;
    $keyword = $wpdb->prepare($_REQUEST['s']);
    return "((CASE WHEN {$wpdb->posts}.post_title LIKE '%{$keyword}%' THEN 2 ELSE 0 END) + (CASE WHEN {$wpdb->posts}.post_content LIKE '%{$keyword}%' THEN 1 ELSE 0 END)) DESC,
{$wpdb->posts}.post_modified DESC, {$wpdb->posts}.ID ASC";
}
# 获取作者文章总数和评论总数
# ----------------------------------------------------------------------------------------------------------------------
function umtu_author_img($author_id){
    $type = _umtu('avatar_type');
    if ($type =='gravatar'){
       echo get_avatar_url($author_id);
    }else{
       echo get_user_meta($author_id,'user_img',true)['url'];
    }
}


# 修改发布时间格式
# ----------------------------------------------------------------------------------------------------------------------
function dopt($e){
    return stripslashes(get_option($e));
}

function time_since($older_date, $newer_date = false)
{
    $chunks = array(
        array(60 * 60 * 24 * 365 , '年'),
        array(60 * 60 * 24 * 30 , '月'),
        array(60 * 60 * 24 * 7, '周'),
        array(60 * 60 * 24 , '天'),
        array(60 * 60 , '小时'),
        array(60 , '分钟'),
    );

    $newer_date = ($newer_date == false) ? (time()+(60*60*get_settings("gmt_offset"))) : $newer_date;
    $since = $newer_date - abs(strtotime($older_date));

    //根据自己的需要调整时间段，下面的24则表示小时，根据需要调整吧
    if($since < 60 * 60 * 24){
        for ($i = 0, $j = count($chunks); $i < $j; $i++)
        {
            $seconds = $chunks[$i][0];
            $name = $chunks[$i][1];

            if (($count = floor($since / $seconds)) != 0)
            {
                break;
            }
        }

        $out = ($count == 1) ? '1 '.$name : "$count {$name}";
        return $out."前";
    }else{
        the_time(get_option('date_format'));
    }
}


# 设置默认缩略图
# ----------------------------------------------------------------------------------------------------------------------
function umtu_thumb($size){
    $default_thumb = _umtu('default_thumb');
    if ($default_thumb){
        $default_thumb_id = $default_thumb['id'];
    }
    if (has_post_thumbnail()){
        $thumb_url = get_the_post_thumbnail_url('',$size);
    }elseif ($default_thumb_id){
        $thumb_url = wp_get_attachment_image_url( $default_thumb_id, $size );
    }else{
        $random = mt_rand(1, 2);
        $thumb_url = get_bloginfo('template_url').'/static/images/'.$random.'.png';
    }
    echo $thumb_url;
}
# 添加代码插入按钮
# ----------------------------------------------------------------------------------------------------------------------
add_action('admin_init', 'insert_code_button');
function insert_code_button(){
    if ( ! current_user_can('edit_posts') && ! current_user_can('edit_pages') ) {
        return;
    }
    add_filter( 'mce_external_plugins', 'add_highlight_button_plugin' );
    add_filter( 'mce_buttons', 'register_highlight_button' );
}
function register_highlight_button( $buttons ) {
    array_push( $buttons, "|", "highlight" );
    return $buttons;
}
function add_highlight_button_plugin(){
    $plugin_array['highlight'] = get_bloginfo( 'template_url' ) . '/static/js/highlight.js';
    return $plugin_array;
}

# SMTP集成
# ----------------------------------------------------------------------------------------------------------------------
function mail_smtp($phpmailer)
{
    if (_umtu('mail_smtps')) {
        $phpmailer->IsSMTP();
        $mail_name             = _umtu('mail_name');
        $mail_host             = _umtu('mail_host');
        $mail_port             = _umtu('mail_port');
        $mail_username         = _umtu('mail_name');
        $mail_passwd           = _umtu('mail_passwd');
        $mail_smtpsecure       = _umtu('mail_smtpsecure');
        $phpmailer->FromName   = $mail_name ? $mail_name : 'idowns';
        $phpmailer->Host       = $mail_host ? $mail_host : 'smtp.qq.com';
        $phpmailer->Port       = $mail_port ? $mail_port : '465';
        $phpmailer->Username   = $mail_username ? $mail_username : '88888888@qq.com';
        $phpmailer->Password   = $mail_passwd ? $mail_passwd : '123456789';
        $phpmailer->From       = $mail_username ? $mail_username : '88888888@qq.com';
        $phpmailer->SMTPAuth   = _umtu('mail_smtpauth') == 1 ? true : false;
        $phpmailer->SMTPSecure = $mail_smtpsecure ? $mail_smtpsecure : 'ssl';

    }
}
add_action('phpmailer_init', 'mail_smtp');