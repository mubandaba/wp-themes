<?php
function get_pagenavi( $range = 4 ) {
    global $paged,$wp_query;
    if ( !$max_page ) {
        $max_page = $wp_query->max_num_pages;
    }
    if( $max_page >1 ) {
        if( !$paged ){
            $paged = 1;
        }
        previous_posts_link('上一页');
        if ( $max_page >$range ) {
            if( $paged <$range ) {
                for( $i = 1; $i <= ($range +1); $i++ ) {
                    echo "<a class=\"page-numbers\" href=".get_pagenum_link($i) .">$i</a>";
                }
            }elseif($paged >= ($max_page -ceil(($range/2)))){
                for($i = $max_page -$range;$i <= $max_page;$i++){
                    echo "<a class=\"page-numbers\" href=".get_pagenum_link($i) .">$i</a>";
                    if($i==$paged)echo "<span aria-current=\"page\" class=\"page-numbers current\">$i</span>";
                }
            }elseif($paged >= $range &&$paged <($max_page -ceil(($range/2)))){
                for($i = ($paged -ceil($range/2));$i <= ($paged +ceil(($range/2)));$i++){
                    echo "<a class=\"page-numbers\" href=".get_pagenum_link($i) .">$i</a>";
                    if($i==$paged)echo "<span aria-current=\"page\" class=\"page-numbers current\">$i</span>";
                }
            }
        }else{
            for($i = 1;$i <= $max_page;$i++){
                echo "<a class=\"page-numbers\" href=".get_pagenum_link($i) .">$i</a>";
            }
        }
        next_posts_link('下一页');
    }
}