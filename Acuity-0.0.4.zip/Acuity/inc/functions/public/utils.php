<?php
/**
 *
 * Get option
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'xintheme' ) ) {
    function xintheme( $option_name = '', $default = '' ) {

        $options = apply_filters( 'xintheme', get_option('iso_framework'), $option_name, $default );

        if( ! empty( $option_name ) && ! empty( $options[$option_name] ) ) {
            return $options[$option_name];
        } else {
            return ( ! empty( $default ) ) ? $default : null;
        }

    }
}

function xintheme_img ($id,$default){
    $cs_id= xintheme($id);
    if (!empty($cs_id )){
        $id_url= wp_get_attachment_image_src( $cs_id, 'full' );
        return $id_url[0];
    }
    elseif (empty($cs_id )){
        return $default;
    }
}

//分享海报
function isolation_poster() {
    $bt = get_the_title(); //标题
    $zy = wp_trim_words(get_the_excerpt() , 80); //摘要
    $iso_framework = get_option('iso_framework');
    $xintheme_post_haibao_logo = $iso_framework['xintheme_post_haibao_logo']['url'];
	if ($xintheme_post_haibao_logo) {
		$lo = $xintheme_post_haibao_logo;
    } else {
        $lo = get_stylesheet_directory_uri() . "/static/images/logo.png";
    } //logo
    $bg = get_stylesheet_directory_uri() . "/static/images/timebg.png"; //时间背景
    $xux = get_stylesheet_directory_uri() . "/static/images/xuxian.png"; //虚线
    $sj = get_the_time('Y/m d'); //时间
    $zz = "作者：" . get_the_author_meta('nickname'); //作者
	$describe= xintheme('xintheme_post_haibao_txt'); //副标题
    $qr = get_stylesheet_directory_uri() . "/public/qrcode?data=".get_permalink(); //二维码
    $the_post_category = get_the_category(get_the_ID());
	$im = get_stylesheet_directory_uri() . '/public/image?pic=' . get_the_post_thumbnail_url('',array(648, 450)). '&title=' . $bt . '&excerpt=' . $zy . '&line=' . $xux . '&logo=' . $lo . '&timebg=' . $bg . '&time=' . $sj . '&author=' . $zz . '  发布于：「' . $the_post_category[0]->cat_name . '」&describe=' . $describe . '&code=' . $qr;
    return $im;
}



