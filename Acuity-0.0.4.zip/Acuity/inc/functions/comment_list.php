<?php
# 自定义评论模板
# ------------------------------------------------------------------------------

if ( ! function_exists( 'janezen_comment' ) ) :
    function janezen_comment( $comment, $args, $depth ) {
        $GLOBALS['comment'] = $comment;
        switch ( $comment->comment_type ) :
            case 'pingback' :
            case 'trackback' :
                ?>
                <li <?php comment_class(); ?> id="comment-<?php comment_ID(); ?>">
                <p><?php _e( 'Pingback:', 'janezen' ); ?> <?php comment_author_link(); ?> <?php edit_comment_link( __( '(Edit)', 'janezen' ), '<span class="edit-link">', '</span>' ); ?></p>
                <?php
                break;
            default :
                global $post;
                ?>
            <li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
                <article id="comment-<?php comment_ID(); ?>" class="">
                    <header class="comment-header">
                        <?php
                        if($comment->user_id!=0){
                            $author_posts_url=get_author_posts_url($comment->user_id);
                            $author_posts_url='<h5 class="uk-display-block">';
                        }else{
                            $author_posts_url='</h5>';
                        }
                        echo get_avatar( $comment, 44 );
                        printf( '%1$s %2$s',
                            $author_posts_url.get_comment_author( $commentdata['comment_parent'] ).'</a>',
                            ( $comment->user_id === $post->post_author ) ? '<em class="uk-text-small b-r-4">作者</em>' : ''
                        );
                        printf( '<span class="uk-float-right uk-text-small uk-text-muted"><time datetime="%2$s">%3$s</time></span>',
                            esc_url( get_comment_link( $comment->comment_ID ) ),
                            get_comment_time( 'c' ),
                            sprintf('%1$s at %2$s', get_comment_date(), get_comment_time() )
                        );
                        ?>
                    </header>

                    <?php if ( '0' == $comment->comment_approved ) : ?>
                        <p class="comment-awaiting-moderation"><span class="uk-text-muted">你的评论正在审核中...<span></p>
                    <?php endif; ?>

                    <section class="comment-content">
                        <?php comment_text(); ?>
                        <div class="reply">
                            <span class="uk-float-left"><?php comment_reply_link( array_merge( $args, array( 'reply_text' => '回复', 'after' => '', 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?></span>
                            <span class="uk-float-right"><?php edit_comment_link('编辑', '<p>', '</p>' ); ?></span>
                        </div>

                    </section>
                </article>
                <?php
                break;
        endswitch;
    }
endif;