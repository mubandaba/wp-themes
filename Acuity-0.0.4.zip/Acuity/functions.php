<?php
include ('inc/functions/xyz-install.php');
if($xyz_status) {
# 引用功能
# ------------------------------------------------------------------------------
    require_once(dirname(__FILE__) . '/inc/functions/enqueue.php');
    require_once(dirname(__FILE__) . '/inc/functions/menu.php');
    require_once(dirname(__FILE__) . '/inc/functions/menu_walker.php');
    require_once(dirname(__FILE__) . '/inc/functions/pagination.php');
    require_once(dirname(__FILE__) . '/inc/functions/seo.php');
    require_once(dirname(__FILE__) . '/inc/functions/wp-breadcrumb.php');
    require_once(dirname(__FILE__) . '/inc/functions/functions-add.php');
    require_once(dirname(__FILE__) . '/inc/functions/pagination.php');
    require_once(dirname(__FILE__) . '/inc/functions/poster.php');
    require_once(dirname(__FILE__) . '/inc/functions/comment_list.php');
    require_once(dirname(__FILE__) . '/inc/framework/meta_framework.php');
    require_once(dirname(__FILE__) . '/inc/framework/taxonomy_framework.php');
    require_once(dirname(__FILE__) . '/inc/framework/admin_framework.php');
    require_once(dirname(__FILE__) . '/inc/framework/profile_framework.php');
    xyz_theme_upgrader();

    add_filter('next_posts_link_attributes', 'nex_posts_link_attributes');
    add_filter('previous_posts_link_attributes', 'per_posts_link_attributes');

    function per_posts_link_attributes() {
        return 'class="prev page-numbers"';
    }
    function nex_posts_link_attributes() {
        return 'class="next page-numbers"';
    }
}