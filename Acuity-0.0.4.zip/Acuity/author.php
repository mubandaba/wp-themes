<?php
    get_header();
    if (is_author()){
        $author = get_queried_object();
        $author_id = $author->ID;
    }
$user = new WP_User($author_id);
$user_roles = $user->roles;
$user_role = array_shift($user_roles);
if ($user_role == 'administrator') {
    $user_role = '网站管理员';
} elseif ($user_role == 'editor') {
    $user_role = '特约编辑';
} elseif ($user_role == 'author') {
    $user_role = '作者';
} elseif ($user_role == 'contributor') {
    $user_role = '贡献者';
} elseif ($user_role == 'subscriber') {
    $user_role = '订阅者';
} else {
    echo $user_role;
} ?>
    <main>
        <div class="author">
            <div class="author-top uk-block-default uk-position-relative b-t">
                <div class="author-top-bg uk-position-absolute">
                    <img src="<?php echo _umtu_user_img('author_top_img',$author_id,get_template_directory_uri().'/static/images/banner.png')?>" alt="umtu">
                </div>
                <div class="uk-h1 uk-position-relative uk-text-contrast uk-text-center uk-margin-large-top">#<?php the_author_meta('nickname',$author_id);?></div>
            </div>
            <div class="author-main uk-container uk-container-center uk-position-relative">
                <div class="uk-grid">
                    <div class="uk-width-1-1 uk-width-small-1-1 uk-width-medium-7-10 uk-width-large-7-10">
                        <div class="box-title uk-block-default b-b">
                            <i class="iconfont icon-aixin"></i> Ta的动态
                        </div>
                        <div class="ajax-ul">
                            <?php if(have_posts()) : while (have_posts()) : the_post(); ?>
                            <div class="uk-block-default ajax-li b-b">
                                <div class="box-main">
                                    <div class="item-info">
                                        <h3><a href="<?php the_permalink();?>" target="_blank"><?php the_title()?></a>
                                        </h3>
                                        <div class="data uk-text-small uk-margin-top">
                                            <span class="uk-margin-right"><i class="iconfont icon-rili"></i><?php echo time_since($post->post_date);?></span>
                                            <span class="uk-margin-right"><i class="iconfont icon-xiaoxi"></i><?php post_views('', ''); ?></span>
                                            <span class="uk-margin-right"><i class="iconfont icon-eye"></i><?php comments_number('0','1','% '); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile;else:?>
                            <div class="uk-block-default ajax-li b-b">
                                <div class="box-main">
                                    <div class="item-info">
                                        <h3><?php the_author_meta('nickname',$author_id);?>还没有发布过文章，去看看别的作者吧！</h3>
                                    </div>
                                </div>
                            </div>
                            <?php endif;?>
                        </div>

                        <div class="uk-margin-top">
                            <div id="pagination" class="ajax-btn uk-display-block">
                                <?php next_posts_link('点击查看更多'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="uk-width-3-10 uk-hidden-small">
                        <?php include 'template_parts/author-info.php'?>
                    </div>
                </div>
            </div>
        </div>

    </main>
<?php get_footer();?>