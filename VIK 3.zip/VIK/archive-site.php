<?php get_header();?>

<div id="content " class="flex mt-3">
    <div class="page-content " id="page-content">


        <section class="list_post_section mt-4 mb-3">
            <header class="heading py-2 d-flex">
                <div>
                    <div class="text-muted text-sm sr-item"></div>
                    <h5 class="text-highlight sr-item">
                        <?php the_archive_title();?>
                    </h5>
                </div>
                <span class="flex"></span>
            </header>

            <div class="row">

        <?php if (have_posts()):while (have_posts()):the_post();?>

            <div class="col-12 col-md-4 col-lg-2">
                <a href="<?php the_site_link()?>" class="simple_item">
                    <div class="card" >
                        <div class="card-body list-row">
                            <div class="list-item ">
                                <div>
                                 <span class="w-40 avatar gd-success">
                                     <img src="<?php the_site_logo_url(); ?>" alt="<?php the_title(); ?>">
                                 </span>
                                </div>
                                <div class="flex">
                                    <div class="item_title text-muted h-1x"><?php the_title(); ?></div>
                                    <div class="item_sub text-muted">
                                        <?php the_site_desc()?>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </a>
            </div>


        <?php endwhile;endif;?>

    </div>

            
</section>


    </div>
</div>
<?php get_footer();?>
