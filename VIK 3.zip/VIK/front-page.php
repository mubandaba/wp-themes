<?php get_header();?>
<div id="content " class="flex mt-3">
    <div class="page-content " id="page-content">

             <?php

             $options = get_option('vik_customize');
             $front_page_sections = isset($options['index_content_group']) ?$options['index_content_group'] : '首页布局';

             if (is_array($front_page_sections)) {
                 foreach ($front_page_sections as $section){

                     $the_title = $section['section_title'] ? $section['section_title']:'';
                     $section_category = $section['section_category'];

                     switch ($section_category) {
                         case 'banner':
                             include 'template_parts/banner.php';
                             break;

                         case 'site':
                             include 'template_parts/list_site.php';
                             break;

                         case 'post':
                             include 'template_parts/list_post.php';
                             break;


                     }
                 }
             }

             ?>
    </div>
</div>
<?php get_footer();?>
