<?php get_header();

$site_tax = get_queried_object();
$site_id = $site_tax->term_id;
$termchildren = get_term_children( $site_id,'site_tax' );// 获取当前的id
?>
<?php
if(sizeof($termchildren)>0){
    // 判断如果有子分类
foreach ($termchildren as $termchild):?>
            <section>

                <header class="mt-5 mb-3 ">
                    <h1 class="h4 font-weight-300 ml-1 mb-2 mt-2">
                        <?php
                        $site_tax_name = get_term_by('id' , $termchild,'site_tax');
                        echo $site_tax_name->name;
                        ?>
                    </h1>
                </header>
                <div class="row ">
                    <?php
                    $site_query = new WP_Query(array(
                        'post_type'      => 'site',
                        'tax_query'      => array( //(数组) - 使用自定义分类法查询参数 (3.1及以后版本可用).
                            'relation'   => 'AND', //(字符串) - 可用的值有 'AND' 或 'OR' 和 SQL 的 JOIN 作用是相同的
                            array(
                                'taxonomy' => 'site_tax',
                                'field'    => 'id',
                                'terms'    => $termchild,
                                'include_children' => true, //(布尔值) - 是否包含自分类，默认为真
                                'operator' => 'IN' //(字符串) - 测试条件，可用值为 'IN', 'NOT IN', 'AND'.
                            )
                        ),
                    ));
                    if($site_query->have_posts()):  while($site_query->have_posts()):$site_query->the_post();
                        $web_id = get_the_ID();
                        $web_desc = get_post_meta($web_id,'web_desc',true);
                        $web_logo_url = get_post_meta($web_id,'web_logo',true)['url'];
                        $link = get_the_permalink();
                        include 'template_parts/loop/site_block.php';
                        endwhile; endif;
                        wp_reset_query();
                        ?>
                </div>

            </section>
<?php
endforeach;
}else{ // 判断如果没有子分类
?>
    <header class="mt-5 mb-3 ">
            <h1 class="h4 font-weight-300 ml-1 mb-2 mt-2">
                <?php
                $tax = get_taxonomy( get_queried_object()->taxonomy );
                $title = sprintf( $tax->labels->singular_name, single_term_title( '', false ) );
                echo $title;
                ?>
            </h1>
        </header>
        <section>

            <div class="row ">
                <?php
                if (have_posts() ) : while (have_posts() ) :the_post();
                $web_id = get_the_ID();
                $web_desc = get_post_meta($web_id,'web_desc',true);
                $web_logo_url = get_post_meta($web_id,'web_logo',true)['url'];
                $link = get_the_permalink();
                    include 'template_parts/loop/site_block.php';
                endwhile;
                endif;
                wp_reset_postdata();
                ?>
            </div>
        </section>
<?php
}
?>

<?php
get_footer();
?>
