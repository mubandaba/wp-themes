<div id="footer" class="page-footer">
    <div class="d-flex p-3">
        <span class="text-sm text-muted flex">Copyright &copy; <?php bloginfo('name');?></span>
        <div class="text-sm text-muted">
            <?php // 版权只在首页显示！！！开发不易，VIK主题我更是多次放弃又多次捡起来，留一个版权链接吧。
            if(is_front_page()||is_home()):
            ?>
            网站程序由<a href="https://weixingv.com/">魏星</a>开发
            <?php endif;?>
        </div>
    </div>
</div>
</main>

<?php wp_footer();?>

</body>
</html>