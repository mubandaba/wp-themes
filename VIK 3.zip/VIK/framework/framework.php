<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access directly.
require_once plugin_dir_path(__FILE__) . 'classes/setup.class.php';
include 'config/meta_framework.php';
include 'config/customize_framework.php';