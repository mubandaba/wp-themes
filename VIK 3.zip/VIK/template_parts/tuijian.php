<section class="mt-5 border-top">
    <header class="mt-3">
        <h3 class="h4 font-weight-300 ml-1 mb-2 mt-2">
            推荐导航
        </h3>
    </header>
    <div class="row">
        <?php
        $site_query = new WP_Query(array(
            'post_type'      => 'site',
            'posts_per_page' => '4',
        ));
        if($site_query->have_posts()):while($site_query->have_posts()):$site_query->the_post();
            $web_id = get_the_ID();
            $web_desc = get_post_meta($web_id,'web_desc',true);
            $web_logo_url = get_post_meta($web_id,'web_logo',true)['url'];
            $link = get_the_permalink();
        ?>

            <div class="col-3">
                <div class="card">
                    <div class="card-body list-row">
                        <div class="list-item ">
                            <div>
                                <a href="<?php echo $link;?>">
                        <span class="w-40 avatar gd-success">
                            <img src="<?php echo $web_logo_url;?>" alt="<?php the_title();?>">
                        </span>
                                </a>
                            </div>
                            <div class="flex">
                                <a href="<?php echo $link;?>" class="item-author text-color">
                                    <?php the_title();?>
                                </a>
                                <a href="<?php echo $link;?>" class="item-company text-muted h-1x">
                                    <?php echo $web_desc?>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        <?php
        endwhile;endif;
        wp_reset_query();
        ?>
    </div>
</section>
