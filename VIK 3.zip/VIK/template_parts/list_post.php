<?php

$args = array(
    'post_type' => 'post',
    'tax_query' => array(
        array(
            'taxonomy' => 'category',
            'field' => 'term_id',
            'terms' => $section['section_site_category_data']
        )
    )
);
$post_category_selected_query = new WP_Query($args);

?>

<section class="list_post_section mt-4 mb-3">
    <header class="heading py-2 d-flex">
        <div>
            <div class="text-muted text-sm sr-item"></div>
            <h5 class="text-highlight sr-item">
                <?php echo $the_title;?>
            </h5>
        </div>
        <span class="flex"></span>
    </header>
    <div class="row">
        
        <?php  if($post_category_selected_query->have_posts()):while($post_category_selected_query->have_posts()):$post_category_selected_query->the_post(); ?>
        <div class="col-4 col-sm-4 col-md-3" >
            <div class="list-item">
                <div class="media media-16x9">
                    <a href="<?php the_permalink();?>" class=" media-content" style="background-image:url('<?php echo get_the_post_thumbnail_url()?>')" ></a>
                </div>
                <div class="list-content">
                    <div class="list-body">
                        <a href="<?php the_permalink();?>" class="list-title title h-1x" >
                            <?php the_title();?>
                        </a>
                    </div>
                    <div class="list-footer">
                        <div class="text-muted text-sm">
                            <?php the_time('Y-m-d');?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endwhile;endif;?>

    </div>
</section>
