<?php

$args = array(
    'post_type' => 'site',
    'tax_query' => array(
        array(
            'taxonomy' => 'site_category',
            'field' => 'term_id',
            'terms' => $section['section_site_category_data']
        )
    )
);
$site_category_selected_query = new WP_Query($args);

?>

<section class="list_site_section mt-4 mb-3">
    <header class="heading py-2 d-flex">
        <div>
            <div class="text-muted text-sm sr-item"></div>
            <h5 class="text-highlight sr-item">
                <?php echo $the_title;?>
            </h5>
        </div>
        <span class="flex"></span>
    </header>
    <div class="row">
        <?php  if($site_category_selected_query->have_posts()):while($site_category_selected_query->have_posts()):$site_category_selected_query->the_post(); ?>

        <div class="col-12 col-md-6 col-lg-3">
            <a href="<?php the_site_link()?>" class="simple_item">
                <div class="card" >
                    <div class="card-body list-row">
                        <div class="list-item ">
                            <div>
                                 <span class="w-40 avatar gd-success">
                                     <img src="<?php the_site_logo_url(); ?>" alt="<?php the_title(); ?>">
                                 </span>
                            </div>
                            <div class="flex">
                                <div class="item_title text-muted h-1x"><?php the_title(); ?></div>
                                <div class="item_sub text-muted">
                                    <?php the_site_desc()?>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </a>
        </div>

        <?php endwhile;endif;?>

    </div>
</section>
