<?php

$the_subtitle =  $section['banner_subtitle'] ? $section['banner_subtitle']:'';
$banner_link =  $section['banner_link'] ? $section['banner_link']:'';
$banner_background =  $section['banner_background']['url'] ? $section['banner_background']['url'] :'';

?>
<section class="banner_section mt-4 mb-3">
    <div class="list-item list-overlay mb-3"  style="visibility: visible; transform: none; opacity: 1; transition: none 0s ease 0s;">
        <div class="media media-4x3">
            <a href="<?php echo $banner_link ?>" class="media-content" style="background-image:url('<?php echo $banner_background ?>'); background-size: cover;background-position:center" ></a>
            <div class="media-action"></div>
        </div>
        <div class="list-content p-5">
            <div class="list-body">
                <a href="<?php echo $banner_link ?>" class="list-title title  h4 font-weight-bold" ><?php echo $the_title ?> </a>
                <a href="<?php echo $banner_link ?>" class="list-subtitle d-block text-muted subtitle  h-1x" ><?php echo $the_subtitle ?></a>
            </div>
        </div>
    </div>
</section>
