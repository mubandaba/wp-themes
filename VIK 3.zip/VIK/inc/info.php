<script>
    window.location.href = 'https://www.weixingv.com/';
</script>