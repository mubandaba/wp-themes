<?php

# 常量定义[Constants]
# ------------------------------------------------------------------------------
define( 'WEIXING_THEME_VERSION', '0.0.1');

# 精简wordpress
# ==================================
include 'inc/remove.php';

# 主题核心函数
# ==================================
include 'inc/core.php';

# 引用自制函数
# ==================================
include 'inc/lab.php';

# 引用自制函数
# ==================================
include 'inc/seo.php';

# 注册post type
# ==================================
include 'inc/post_type/site.php';

# 引用codestar
# ==================================
include 'framework/framework.php';

# 引用css和js
# ==================================
include 'inc/enqueue.php';

# 引用自定义菜单
# ==================================
include 'inc/menu.php';


