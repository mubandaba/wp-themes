<?php
get_header();
if (have_posts()):while (have_posts()):the_post();

    $web_id = get_the_ID();
    $web_sub = get_post_meta($web_id,'web_sub',true);
    $web_desc = get_post_meta($web_id,'web_desc',true);

    $web_logo_url = get_post_meta($web_id,'web_logo',true)['url'];
    $web_logo_id = get_post_meta($web_id,'web_logo',true)['id'];

    $web_qrcode_array = get_post_meta($web_id,'web_qrcode',true);
    if(is_array($web_qrcode_array)){
        $web_qrcode_url = get_post_meta($web_id,'web_qrcode',true)['url'];
    }else{
        $web_qrcode_url ='';
    }
    $web_link = get_post_meta($web_id,'web_link',true);

    ?>

<div class="row mt-5" style="min-height: calc(100vh - 32px - 69px - 50px - 48px - 48px)">
    <div class="col-12 col-md-4 col-xl-3">
        <div class="tool-image">

            <div class="rounded">
                <img style="width: 100%" src="<?php echo $web_logo_url?>" alt="<?php the_title()?>">
            </div>

        </div>
    </div>
    <div class="col-12 col-md-8 col-xl-9 mt-4 mt-md-0">
        <div class="tool-body p-xl-4">

            <div class="mt-2 mt-md-3">

                <div class="tool-info text-sm text-muted">

                    <h1 class="single_heading h4 font-weight-bold mb-0 text-highlight title">
                        <?php the_title()?>
                    </h1>
                    <small>
                        <?php echo $web_sub?>
                    </small>
                </div>
                <div class="tool-go mt-4">

                    <?php if(isset($web_link)&&!empty($web_link)):?>

                    <a id="modal_link_switch" data-toggle="modal" data-target="#modal_link" title="<?php the_title()?>" class="btn-mark btn btn-light">
                        网站
                    </a>
                    <div id="modal_link" class="vik_modal modal fade show" data-backdrop="true" aria-modal="true" >
                        <div class="modal-dialog modal-sm">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button class="close" data-dismiss="modal">×</button>
                                </div>
                                <div class="modal-body">
                                    <div class="p-4 text-center">
                                        <div class="time_remain" id="time_remain">
                                            10
                                        </div>
                                        <p>
                                            你将离开本站，访问<?php the_title();?>
                                        </p>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button id="cancel_button" type="button" class="btn btn-light" data-dismiss="modal">取消</button>
                                    <button id="now_go_button" type="button" class="btn btn-primary" >确定</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <script>
                        jQuery(document).on('click', '#modal_link_switch    ', function (event) {
                            event.preventDefault();
                            that = jQuery('#time_remain');
                            var num = 5;
                            that.html(num);

                            var sms_t = window.setInterval(function () {
                                num = num - 1;
                                if (num > 0) {
                                    that.html(num);
                                } else {
                                    window.location.href = '<?php echo $web_link?>';
                                    clearInterval(sms_t)
                                }
                            }, 1000);

                            jQuery(document).on('click', '#cancel_button', function (event) {
                                clearInterval(sms_t)
                            });
                            jQuery(document).on('click', '#now_go_button', function (event) {
                                window.location.href = '<?php echo $web_link?>';
                            });

                        });
                    </script>

                    <?php endif;?>

                    <?php if(isset($web_qrcode_url)&&!empty($web_qrcode_url)):?>
                    <a data-toggle="modal" data-target="#modal_qrcode" title="<?php the_title()?>" class="btn-watch btn btn-light">
                        二维码
                    </a>
                    <div id="modal_qrcode" class="vik_modal modal fade show" data-backdrop="true" aria-modal="true" >
                        <div class="modal-dialog modal-sm">
                            <div class="modal-content">

                                <div class="modal-body pt-5">
                                    <div class="text-center">
                                        <p>
                                            微信扫码 即可关注
                                        </p>
                                        <img src="<?php echo $web_qrcode_url;?>" alt="">
                                    </div>
                                </div>
                                <p style="position:relative;bottom: -5em;text-align: center; ">
                                    <button style="display: inline-block;background: white;border-radius: 100%;width: 40px;height:40px" class="close" data-dismiss="modal">×</button>
                                </p>


                            </div>
                        </div>
                    </div>
                    <?php endif;?>

                </div>
            </div>

        </div>
    </div>
</div>

<?php
//include 'template_parts/tuijian.php';
endwhile;endif;get_footer();?>
