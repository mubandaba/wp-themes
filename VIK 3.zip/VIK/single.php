<?php
get_header();
if (have_posts()):while (have_posts()):the_post();

?>

<article class="p-4">
    <div class="post_header">
        <h1 class="mt-3">
            <?php the_title();?>
        </h1>
        <div class="post_info">
            <span class="time">
                <?php the_time('Y-m-d');?>
            </span>
            <span class="sep">/</span>
            <span class="category">
                in &nbsp;
                <?php foreach((get_the_category()) as $category){
                    echo $category->cat_name;
                };?>
            </span>
        </div>
    </div>
    <div class="post-content border-bottom py-4 py-lg-5">
        <?php the_content();?>
    </div>

</article>
<?php endwhile;endif;get_footer();?>
