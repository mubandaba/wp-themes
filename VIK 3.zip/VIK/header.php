<!DOCTYPE html>
<html lang="zh-hans">
<head>
    <meta charset="utf-8">
    <meta name="description" content="Responsive, Bootstrap, BS4">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">

    <?php wp_head();
    $options = get_option('vik_customize');
    $logo_array = $options['logo'];
    ?>

</head>
<body class="layout-row">
<div id="aside" class="page-sidenav no-shrink bg-light nav-dropdown fade" aria-hidden="true">
    <div class="sidenav h-100 modal-dialog bg-light">
        <!-- sidenav top -->
        <div class="navbar">

            <!-- brand -->
            <a href="<?php bloginfo('url');?>" class="navbar-brand">
                <?php if(is_array($logo_array) && $logo_array['url']){?>
                    <img src="<?php echo $logo_array['url'];?>" alt="<?php bloginfo('name');?>">
                <?php }else{?>
                    <svg width="32" height="32" viewbox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" fill="currentColor"><g class="loading-spin" style="transform-origin: 256px 256px"><path d="M200.043 106.067c-40.631 15.171-73.434 46.382-90.717 85.933H256l-55.957-85.933zM412.797 288A160.723 160.723 0 0 0 416 256c0-36.624-12.314-70.367-33.016-97.334L311 288h101.797zM359.973 134.395C332.007 110.461 295.694 96 256 96c-7.966 0-15.794.591-23.448 1.715L310.852 224l49.121-89.605zM99.204 224A160.65 160.65 0 0 0 96 256c0 36.639 12.324 70.394 33.041 97.366L201 224H99.204zM311.959 405.932c40.631-15.171 73.433-46.382 90.715-85.932H256l55.959 85.932zM152.046 377.621C180.009 401.545 216.314 416 256 416c7.969 0 15.799-.592 23.456-1.716L201.164 288l-49.118 89.621z"></path></g></svg><!-- <img src="static/picture/logo.png" alt="..."> -->
                    <span class="hidden-folded d-inline l-s-n-1x"><?php bloginfo('name');?></span>
                <?php }?>
            </a>
            <!-- / brand -->
        </div>


        <!-- Flex nav content -->
        <div class="flex scrollable hover">

            <div class="nav-active-primary auto-nav" >

                <ul class="nav">

                    <?php
                    $menu_array = xyz_get_menu_array('main_menu');
                    if(is_array($menu_array)):
                    foreach ($menu_array as $menu_item):
                    ?>

                    <li>
                        <a href="<?php echo $menu_item['url'];?>" >
                            <span class="nav-icon">
                                <i class="<?php echo implode(" ", $menu_item['classes']); ?>"></i>
                            </span>
                            <span class="nav-text">
                                 <?php echo $menu_item['title'];?>
                            </span>
                            <?php if(is_array($menu_item['children']) && sizeof($menu_item['children']) > 0):?>
                            <span class="nav-caret"></span></a>
                            <ul class="nav-sub nav-mega">

                                <?php foreach ($menu_item['children'] as $submenu_item):?>

                                <li>
                                    <a href="<?php echo $submenu_item['url'];?>" class="">
                                        <span class="nav-text">
                                            <?php echo $submenu_item['title'];?>
                                        </span>
                                    </a>
                                </li>

                                <?php endforeach;?>

                            </ul>
                            <?php endif;?>

                    </li>

                    <?php
                    endforeach;
                    endif
                    ?>

                </ul>
            </div>
        </div>
        <!-- sidenav bottom -->
        <div class="no-shrink">
            <div class="p-3 d-flex align-items-center">
                <div class="text-sm hidden-folded text-muted">

                    <div class="btn-group social_list mr-2">

                        <a href="<?php echo $options['weibo'];?>" class="btn btn-white">
                            <i class="iconfont icon-weibo"></i>
                        </a>
                        <a href="<?php echo $options['bilibili'];?>" class="btn btn-white">
                            <i class="iconfont icon-bilibili"></i>
                        </a>
                        <a href="<?php echo $options['qq'];?>" class="btn btn-white">
                            <i class="iconfont icon-qq"></i>
                        </a>
                        <a href="<?php echo $options['zhihu'];?>" class="btn btn-white">
                            <i class="iconfont icon-zhihu"></i>
                        </a>

                    </div>


                </div>
            </div>
        </div>
    </div>
</div>
<main id="main" class="layout-column flex p-3">
    <div id="header" class="page-header bg-body sticky border-bottom" >
        <div class="navbar navbar-expand-lg ">
            <!-- brand -->

            <a href="<?php bloginfo('url');?>" class="navbar-brand d-lg-none" >
                <svg width="32" height="32" viewbox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" fill="currentColor"><g class="loading-spin" style="transform-origin: 256px 256px"><path d="M200.043 106.067c-40.631 15.171-73.434 46.382-90.717 85.933H256l-55.957-85.933zM412.797 288A160.723 160.723 0 0 0 416 256c0-36.624-12.314-70.367-33.016-97.334L311 288h101.797zM359.973 134.395C332.007 110.461 295.694 96 256 96c-7.966 0-15.794.591-23.448 1.715L310.852 224l49.121-89.605zM99.204 224A160.65 160.65 0 0 0 96 256c0 36.639 12.324 70.394 33.041 97.366L201 224H99.204zM311.959 405.932c40.631-15.171 73.433-46.382 90.715-85.932H256l55.959 85.932zM152.046 377.621C180.009 401.545 216.314 416 256 416c7.969 0 15.799-.592 23.456-1.716L201.164 288l-49.118 89.621z"></path></g></svg><!--
                <img src="../assets/img/logo.png" alt="..."> -->
                <span class="hidden-folded d-inline l-s-n-1x d-lg-none">
                    <?php bloginfo('name');?>
                </span>
            </a>

            <?php
            if($options['weather_switcher']):?>
            <div class="collapse navbar-collapse order-2 order-lg-1" id="" style="position:relative;">

                <div id="he-plugin-simple"></div>
                <script>
                    WIDGET = {
                        CONFIG: {
                            "modules": "01234",
                            "background": 5,
                            "tmpColor": "4A4A4A",
                            "tmpSize": 16,
                            "cityColor": "4A4A4A",
                            "citySize": 16,
                            "aqiSize": 16,
                            "weatherIconSize": 24,
                            "alertIconSize": 18,
                            "padding": "10px 10px 10px 10px",
                            "shadow": "0",
                            "language": "auto",
                            "fixed": "false",
                            "vertical": "middle",
                            "horizontal": "center",
                            "key": "3c347e59434844e4bcfa9419a16f38f1"
                        }
                    }
                </script>
                <script src="https://widget.heweather.net/simple/static/js/he-simple-common.js?v=1.1"></script>
            </div>
            <?php endif;?>

            <ul class="nav navbar-menu order-1 order-lg-2">
                <li class="nav-item d-lg-none"><a class="nav-link px-1" data-toggle="modal" data-target="#aside" ><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewbox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-menu"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg></a></li>
            </ul>
        </div>
    </div>


