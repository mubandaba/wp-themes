<?php get_header();?>
<div class="container">
	<?php if (get_option('strive_gg') == 'Display') { ?>
	<div class="subsidiary row box">
		<div class="bulletin fourfifth">
			<span class="sixth">站点公告：</span>
            <marquee class="fivesixth" direction=left onmouseout=start(); onmouseover=stop(); scrollAmount=2 scrollDelay=15;>
            	<?php echo get_option('strive_announce'); ?>
            </marquee>
         </div>
         <div class="bdshare_small fifth">
         <?php if (get_option('strive_bdshare') == 'Display') { ?>
			<!-- Baidu Button BEGIN -->
                    <div class="bdsharebuttonbox">
                        <a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a>
                        <a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a>
                        <a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a>
                        <a href="#" class="bds_renren" data-cmd="renren" title="分享到人人网"></a>
                        <a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a>
                        <a href="#" class="bds_huaban" data-cmd="huaban" title="分享到花瓣"></a>
                    	<a href="#" class="bds_more" data-cmd="more"></a>
                    </div>
			<script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"0","bdSize":"16"},"share":{}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script>
			<!-- Baidu Button END -->
			<?php } else { } ?>
        </div>
	</div>
    <?php } else { echo '<div class="row"></div>';} ?>
    <?php if (get_option('strive_slidebar') == 'Display') { ?>
    <?php get_sidebar();?>
    	<?php if (get_option('strive_slides') == 'Display'&& $post==$posts[0] && !is_paged()) { ?>
        	<?php include('includes/slides.php'); ?>
            <?php { echo ''; } ?>
    <?php } else { } ?><?php } else { } ?>

    <div class="mainleft">
    <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('首页幻灯区域') ) :; endif;?>
        <ul id="post_container" class="masonry clearfix">
        <?php query_posts($query_string.'&cat='.get_option('strive_leiid')); ?>
			<?php include('includes/list_post.php'); ?>
    	</ul>
		<div class="clear"></div>
		</div>
	</div>
	<div class="navigation container"><?php pagination(5);?></div>
<div class="clear"></div>
<?php get_footer()?>
