<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<meta charset="UTF-8">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type');?>" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<?php include('includes/seo.php');?>
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory')?>/css/kube.css" />
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory')?>/css/reset.css" />
<?php if (get_option('strive_alt_stylesheet')==''):?>
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory')?>/style.css" />
<?php endif;?>
<?php if ( is_singular() ){ ?>
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url');?>/images/lightbox/pirobox.css" target="_blank" />
<?php } ?>
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name');?> RSS Feed" href="<?php bloginfo('rss2_url');?>" />
<link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name');?> Atom Feed" href="<?php bloginfo('atom_url');?>" />
<link rel="shortcut icon" href="<?php echo stripslashes(get_option('strive_favicon')); ?>" type="image/x-icon" />
<link rel="pingback" href="<?php bloginfo('pingback_url');?>" />
<?php my_scripts_method; wp_head()?>
<?php flush()?>
<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
</head>
<body  class="custom-background">

	<div id="page">
		<div id="head" class="row">
			<div class="container row">
            	<div class="row">
					<div id="topbar">
						<?php if(function_exists('wp_nav_menu')) {
                        wp_nav_menu(array(
                        'theme_location'=>'toolbar',
                        'menu_id'=>'toolbar',
                        'container'=>'ul')
                        );}
                        ?>
                    </div>
					<div id="rss">
                    	<ul>
							<li><a href="<?php bloginfo('rss2_url')?>" target="_blank" class="icon1" title="欢迎订阅<?php bloginfo('name');?>"></a></li>
							<?php if (get_option('strive_sbaidu') == 'Display') { ?>
							<li><a href="<?php echo stripslashes(get_option('strive_sbaidumap')); ?>" target="_blank" class="icon5" title="百度站点地图"></a></li><?php } else { } ?>
							 <?php if(get_option('strive_tqq') == 'Display') { ?>
							<li><a href="<?php echo stripslashes(get_option('strive_tqqurl')); ?>" target="_blank" class="icon2" title="我的腾讯微博" rel="nofollow"></a></li><?php } else { } ?>
							<?php if(get_option('strive_weibo') == 'Display') { ?>
							<li><a href="<?php echo stripslashes(get_option('strive_weibourl')); ?>" target="_blank" class="icon3" title="我的新浪微博" rel="nofollow"></a></li><?php } else { } ?>
							<?php if(get_option('strive_site') == 'Display') { ?>
							<li><a href="<?php echo stripslashes(get_option('strive_sitemap')); ?>" target="_blank" class="icon6" title="站点地图"></a></li><?php } else { } ?>
							<li><a href="http://mail.qq.com/cgi-bin/feed?u=<?php bloginfo('rss2_url');?>" target="_blank" class="icon4" title="用QQ邮箱阅读空间订阅本站" rel="nofollow"></a></li>
						</ul>
                    </div>
                 </div>
             </div>
					<div class="clear"></div>
				<div class="container">
					<div id="blogname" class="third">
                    	<a href="<?php bloginfo('siteurl');?>/" title="<?php bloginfo('name');?>"><?php if ( is_home() || is_search() || is_category() || is_month() || is_author() || is_archive() ) { ?><h1><?php bloginfo('name');?></h1><?php } ?>
                        <img src="<?php echo stripslashes(get_option('strive_mylogo')); ?>" alt="<?php bloginfo('name');?>" /></a>
                    </div>
                 	<?php if (get_option('strive_logoadc') == 'Display') { ?>
                 	<div class="banner push-right">
                 	<?php echo stripslashes(get_option('strive_logoadccode')); ?>
					</div>
                	<?php { echo ''; } ?><?php } else { } ?> 
                </div>
				<div class="clear"></div>
		</div>
		<div class="mainmenus container">
			<div class="mainmenu">
				<div class="topnav">
                     <!-- menus START -->
                    <script type="text/javascript" language="javascript">
                     function gaoliangfenlei()
                     { 
                      var nav = document.getElementById("menus");    
                      var links = nav.getElementsByTagName("li");    
                      var lilen = nav.getElementsByTagName("a");    
                      var currenturl = document.location.href;    
                      var last = 0;    
                      for (var i=0;i<links.length;i++)    
                      {    
                       var linkurl = lilen[i].getAttribute("href");    
                       if(currenturl.indexOf(linkurl)!=-1)    
                       {    
                        last = i;    
                       }    
                      } 
                     links[last].className = "current_page_item";
                     }
                    </script> 
                    <script type="text/javascript" language="javascript">
                     function gaoliangwenzhangfenlei(catname)
                     {
                      var caidan ="<?php echo $caidan ?>" ;
                      var fenleiming ="<?php echo $catname ?>" ;
                      var nav = document.getElementById("menus");    
                      var links = nav.getElementsByTagName("li");  
                      var as = nav.getElementsByTagName("a");  
                      var last = 0;    
                      for (var i=0;i<links.length;i++)    
                      {    
                       var li = links[i].innerHTML;
                       var ai=as[i].innerHTML;        
                       if(ai==catname)    
                       {    
                        last = i;
                        links[last].className = "current_page_item";
                       } 
                      }         
                     }
                    </script> 
					<?php if (get_option('strive_home') == 'Display') { ?>
                		<a href="<?php bloginfo('siteurl');?>" title="首页" class="<?php if ( is_home() ){ ?>home <?php } else {echo 'home_none'; } ?>">首页</a>
    				<?php } else { } ?>
                    <ul id="menus">
						<?php 
                        $caidan=wp_nav_menu(array('theme_location' => 'nav','menu_id'=>'nav','container' => 'ul','echo' => false,'items_wrap'=> '%3$s', ) ); 
                        $catname = '';
                        if(!is_page() && !is_home()) {
                            $cat = get_the_category();
                            $catid = $cat[0]->cat_ID;
                            $catname = $cat[0]->cat_name;
                         if(is_category() ){
                             echo $caidan;
                             echo "<script type='text/javascript' language='javascript'>gaoliangfenlei()</script>";
                         }
                         else{
                          echo $caidan;
                          echo "<script type='text/javascript' language='javascript'>gaoliangwenzhangfenlei('$catname')</script>";
                         }
                        }
                        else{
                         echo $caidan;
                        }
                        ?>
                    </ul>
               <?php if (get_option('strive_menusearch') == 'Display') { ?>     
                <ul class="menu-right">
                    <li class="menu-search">
                    	<a href="#" id="menu-search" title="搜索"></a>
                    	<div class="menu-search-form ">
							<form action="<?php bloginfo('home');?>" method="get">
                            	<input name="s" type="text" id="search" value="" maxlength="150" placeholder="请输入搜索内容" x-webkit-speech>
                            </form>
                        </div>
                    </li>
                </ul> 
                <?php } else { } ?>
                 <!-- menus END -->                    
                   <div id="select_menu">
					<?php //get a separate drop down menu for responsive
                    $menu_name = 'nav';
                    if ( ( $locations = get_nav_menu_locations() ) && isset( $locations[ $menu_name ] ) ) {
                        $menu = wp_get_nav_menu_object( $locations[ $menu_name ] );
                    
                        $menu_items = wp_get_nav_menu_items($menu->term_id);
                    
                        $menu_list = '<select onChange="document.location.href=this.options[this.selectedIndex].value;" id="select-menu-' . $menu_name . '"><option value="#">'.'站点导航'.'</option>';
                    
                        foreach ( (array) $menu_items as $key => $menu_item ) {
                            $title = $menu_item->title;
                            $url = $menu_item->url;
                            $parentid = $menu_item->menu_item_parent;
                            $indent = '';
                            if($parentid!=0) { //see if this item needs to be indented
                                $indent .= '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';							
                            }
                            $objectid = $menu_item->object_id;
                            $type = $menu_item->type;
                            $selected = '';
                            $selectedoption = '';
                            if((is_tax() || is_category() || is_tag()) && $type=='taxonomy') { //see if this is the currently displayed taxonomy
                                $termid = get_queried_object()->term_id;
                                if($termid == $objectid) {
                                    $selected = "selected";
                                    $selectedoption = 'selected="selected"';
                                }
                            } elseif($objectid == $post->ID && ($type == 'post_type')) { //see if this is the currently displayed page/post
                                $selected = "selected";
                                $selectedoption = 'selected="selected"';
                            }
                            
                            $menu_list .= '<option ';
                            if($selectedoption!='') {
                                $menu_list .= $selectedoption;
                            }
                            $menu_list .= ' ';
                            if($selected!='') {
                                $menu_list .= 'class="' . $selected . '"';
                            }
                            $menu_list .= ' value="' . $url . '">' . $indent . $title . '</option>';
                        }
                        $menu_list .= '</select>';
                    } else {
                        $menu_list = '<ul><li>Menu "' . $menu_name . '" not defined.</li></ul>';
                    }
                    
                    echo $menu_list;
                    ?>                            
              	</div> 
            </div>
				</div>
				<div class="clear"></div>
			</div>
		</div>
<div class="container">
    <div class="subsidiary row box">
		<div class="bulletin fourfifth">
        	当前位置：<a href="<?php bloginfo('siteurl');?>/" title="返回首页">首页</a> > 未知页面
        </div>
	</div>
    <div class="mainleft">
		<div class="article_container row  box">
           <div class="third centered" style="text-align:center; margin:50px auto;">
				<h2><center>抱歉，您打开的页面未能找到。</center></h2>
        		<div class="context">
       			  <center><a href="<?php bloginfo('siteurl');?>" title="返回首页"><img src="<?php bloginfo('template_directory'); ?>/images/404.gif" alt="Error 404 - Not Found" /></a></center>
            	</div>
			</div>
        </div>
	</div>
</div>
</body>
<?php get_footer();?>