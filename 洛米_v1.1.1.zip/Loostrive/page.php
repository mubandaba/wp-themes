<?php get_header();?>
<div class="container">
	<?php if (have_posts()) : while (have_posts()) : the_post();?>
        <div class="row">
			<?php if (get_option('strive_breadcrumb') == 'Display') { ?>
                <div class="subsidiary box">
                    <div class="bulletin fourfifth">
                        <span class="sixth">当前位置：</span><?php loo_breadcrumbs(); ?>
                     </div>
                </div>
            <?php } else {} ?>
        </div>
<?php get_sidebar();?>
    <div class="mainleft">
		<div class="article_container row  box">
			<h2><?php the_title();?></h2>
        <div class="context" id="post_content"><?php the_content('Read more...');?></div>
	</div>
    <div id="comments_box">
		<?php comments_template();?>
    </div>    
	<?php endwhile;else: ;endif;?>
</div>
</div>
<?php get_footer();?>