<div id="sidebar">
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('侧边栏') ) :; endif;?>
	<div id="sidebar-follow">
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('滚动边栏') ) :; endif;?>
	</div>
</div>