<footer id="footer">
    <p>©<a href="<?php bloginfo(’url’); ?>" title="<?php bloginfo(’name’); ?>"><?php bloginfo(’name’); ?></a> 
	   Powered by Wordpress | Theme by <a href="http://lizimu.net" title="子木">子木</a>
    </p>
</footer>

<!-- footer -->

<script type="text/javascript">

$(document).on("click", ".st-tabs .tabs-title a",function(e) {
        e.preventDefault();
        $(this).parents('li').addClass('active').siblings('li.active').removeClass('active');
        var tab_id = $(this).parents('li').index();
        $(this).parents('.st-tabs').find('.tabs-content').eq(tab_id).show().siblings('.tabs-content').hide();
        return false;
    });

	$(window).bind('scroll', function(){
	
		if ($(this).scrollTop() > 230) { $('.scrollTop').show(); } else { $('.scrollTop').hide();}			
 
	});
	
	$('.scrollTop').click(function(e){
		e.stopPropagation();
		$('body,html').animate({scrollTop: 0}, 800);
		return false;
	});
$('.tga').click(function() {
	if ($(this).hasClass('icon-minus')) {
		$(this).removeClass('icon-minus');
		$(this).addClass('icon-plus');
	} else {
		$(this).removeClass('icon-plus');
		$(this).addClass('icon-minus');
	}
	return false;
});
$('.tga').click(function(){$(this).next('.tgb').slideToggle(400)}); 

</script>
</div><!--wrapper -->
<?php wp_footer(); ?>

</body>
</html>