<?php get_header(); ?>
	<div id="content">
		<article class="error">
			<p>404</p>
		</article>
	</div><!--content-->
<?php get_footer(); ?>