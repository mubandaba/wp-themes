<div class="pos-r pd10 post-list content box mar10-b">
    <div class="pos-r cart-list">
        <?php
            $ads = zrz_get_ads_settings('home_list');
            echo zrz_get_html_code($ads['str']);
        ?>
    </div>
</div>
