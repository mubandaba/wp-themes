<?php
/*
* vip，侧边栏
*/
?>
<section id="pages-2" class="widget widget_write mar10-b">
    <h2 class="widget-title l1 pd10 box-header">提示</h2>
    <div class="box">
        <ul>
            <li>
                <b>为什么要成为VIP？</b>
                <p>您可以免费查看（下载）会员专属内容</p>
				<p>您可以享受商品的会员专属价格</p>
				<p>您可以获得更多特权</p>
            </li>
        <ul>
    </div>
</section>
