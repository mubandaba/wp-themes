<?php get_header(); ?>
<!-- Article begin -->
<div class="article">
	<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
			<div class="post">
                    <h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
                    <span class="pcomments"><em><?php comments_popup_link('0 ', '1 ', '% '); ?></em>个评论</span>
                    <div class="clear"></div>
                    	<?php
							if ( (function_exists('has_post_thumbnail')) && (has_post_thumbnail()) ) {
						?>
							<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" ><?php the_post_thumbnail( 'thumbnail', array('class' => 'post-thumbnail')); ?></a>
                        <?php } else {?>
                        	<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
								<img src="<?php echo catch_that_image() ?>" alt="<?php the_title(); ?>" title="<?php the_title(); ?>" class="post-thumbnail" />
                            </a>
                        <?php } ?>
                        <div class="pcontent">
                            <?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 290,"..."); ?>
                        </div>
						<div class="clear"></div>
                    	<div class="pmeta">
							<?php the_time('Y-m-d'); ?> / <?php the_category(', ') ?> / <?php if(function_exists('the_views')) { the_views(); } ?>浏览
                        </div>
                        <a href="<?php the_permalink() ?>" title="阅读全文" class="readmore">阅读全文</a>
           </div>
		<?php endwhile; ?>
	<?php else : ?>
            <div class="post">
            	<h2>抱歉,没有找到合适的文章.</h2>
                <div class="clear"></div>
            	<p>请您<a href="<?php echo get_settings('home'); ?>">返回首页</a>或在搜索中查找您所需的信息.带来不便,敬请谅解!</p>
            </div>
    <?php endif; ?>
    <!-- Navigation begin -->
    <div class="page_navi">
    	<?php if(
			function_exists('wp_pagenavi')) { wp_pagenavi();
		}
		else { ?>
            <div class="pageleft"><?php previous_post_link('<strong>上一篇: </strong> %link') ?></div>
       		<div class="pageright"><?php next_post_link('<strong>下一篇: </strong> %link') ?></div>
        <?php } ?>
    </div>
    <!-- Navigation end -->
</div>
<!-- Article end -->
<!-- Sidebar begin -->
	<?php include (TEMPLATEPATH . '/sidebar.php'); ?>
<!-- Sidebar end -->
<?php get_footer(); ?>