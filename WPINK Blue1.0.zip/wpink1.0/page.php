<?php get_header(); ?>
<!-- Article begin -->
<div class="article">
	<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
			<div class="post single page">
                    <h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
                    <div class="pmeta">
						时间: <?php the_time('Y-m-d'); ?> / 浏览次数: <?php if(function_exists('the_views')) { the_views(); } ?> <?php edit_post_link('编辑本文', '', ''); ?>
                    </div>
                    <div class="clear"></div>
                    <div class="pcontent">
                        <?php the_content(); ?>
                    </div>
           </div>
		<?php endwhile; ?>
	<?php else : ?>
            <div class="post single">
            	<h2>抱歉,没有找到合适的文章.</h2>
            	<p>请您<a href="<?php echo get_settings('home'); ?>">返回首页</a>或在搜索中查找您所需的信息.带来不便,敬请谅解!</p>
            </div>
    <?php endif; ?>
</div>
<!-- Article end -->
<!-- Sidebar begin -->
	<?php include (TEMPLATEPATH . '/sidebar.php'); ?>
<!-- Sidebar end -->
<?php get_footer(); ?>