<div class="foot"><div class="foot_inner"><br>免责声明：本站所有资源均收集自互联网，没有提供影片资源存储，也未参与录制、上传。若本站收录的资源涉及您的版权或知识产权或其他利益，请附上版权证明邮件告知，我们会尽快确认后作出删除等处理措施。<br><?php echo qzt_get_option( 'copyright', '' ); ?> 管理员邮箱：<?php echo qzt_get_option( 'email', '' ); ?><br><?php echo qzt_get_option( 'tongji', '' ); ?></div></div>
</body>
</html>
