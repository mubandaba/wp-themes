
<?php  
	$args=array(  
		'cat' => qzt_get_option("movie") ,   // 分类ID 
		'posts_per_page' => 15, // 显示篇数
	);  
	query_posts($args);  	
			?> 
<div class="col-lg-wide-25 hidden-md hidden-sm hidden-xs">
					<div class="stui-pannel_hd">
						<div class="stui-pannel__head clearfix"><a class="more text-muted pull-right" href="/?m=vod-type-id-1.html">更多 <i class="icon iconfont icon-more"></i></a>
							<h3 class="title"><img src="<?php bloginfo('template_url') ?>/images/icon_12.png">热播榜</h3>
						</div>
					</div>
				<?php $display_categories =  explode(',',qzt_get_option('list-left') ); foreach ($display_categories as $category) { ?>
				<?php query_posts( array( 'showposts' => 1, 'cat' => $category, 'post__not_in' => $do_not_duplicate ) ); ?>
					<div class="stui-pannel_bd">
						<ul class="stui-vodlist__media active col-pd clearfix">
							<?php while ( have_posts() ) : the_post(); ?>
							<li>
								<div class="thumb"><a class="m-thumb stui-vodlist__thumb lazyload" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" data-original="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php post_thumbnail_src(); ?>&h=228&w=152&zc=1" style="background-image: url(<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php post_thumbnail_src(); ?>&h=228&w=152&zc=1);"></a>
								</div>
								<div class="detail detail-side">
									<h4 class="title"><a href="<?php the_permalink(); ?>"><?php echo cut_str($post->post_title,15); ?></a></h4>
									<p class="font-12"><span class="text-muted">类型：</span>喜剧 <span class="text-muted">地区：</span><a target="_blank" href="/index.php?m=vod-search-area-%E5%A4%A7%E9%99%86">大陆</a>&nbsp;</p>
									<p class="font-12 margin-0"><span class="text-muted">主演：</span>梁朝伟,白百何,...</p>
								</div>
							</li>
							<?php endwhile; ?>
						</ul>
						<ul class="stui-vodlist__rank col-pd clearfix">
							<ol start="2">
							<?php query_posts( array( 'showposts' => 15, 'cat' => $category, 'offset' => 1, 'post__not_in' => $do_not_duplicate ) ); ?>
							<?php while ( have_posts() ) : the_post(); ?>
							<li><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><span class="text-muted pull-right">BD1280高清中字</span><?php echo cut_str($post->post_title,15); ?></a>
							</li>
							<?php endwhile; ?>
						<?php wp_reset_query(); ?>
							</ol> 
						</ul>
					</div>
				<?php } ?>
				</div>
