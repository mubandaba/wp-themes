<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE10"/>
	<meta name="renderer" content="webkit|ie-comp|ie-stand">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<?php include('inc/seo.php');?>
	<link rel="shortcut icon" href="<?php bloginfo('template_url') ?>/img/favicon.ico" type="image/x-icon"/>
	<link rel="stylesheet" href="//at.alicdn.com/t/font_623526_cric9zc08xfg8pvi.css" type="text/css"/>
	<link rel="stylesheet" href="<?php bloginfo('template_url') ?>/css/block.css" type="text/css"/>
	<link rel="stylesheet" href="<?php bloginfo('template_url') ?>/css/default.css" type="text/css"/>
	<link rel="stylesheet" href="<?php bloginfo('template_url') ?>/css/custom.css" type="text/css"/>
	<link rel="stylesheet" href="<?php bloginfo('template_url') ?>/css/slider.css" type="text/css"/>
	<script type="text/javascript" src="<?php bloginfo('template_url') ?>/js/slider.js"></script>
	<script>
		var SitePath = '/',
			SiteAid = '10',
			SiteTid = '',
			SiteId = '';
	</script>
	<!--[if lt IE 9]><script src="<?php bloginfo('template_url') ?>/js/html5shiv.min.js"></script><script src="<?php bloginfo('template_url') ?>/js/respond.min.js"></script><![endif]-->
</head>

<body>
	<header class="stui-header__top clearfix" id="header-top">
		<div class="container">
			<div class="row">
				<div class="stui-header_bd clearfix">
					<div class="stui-header__logo">
						<a href="<?php bloginfo('url'); ?>" class="logo" alt="<?php bloginfo('name'); ?>">
							<?php if( qzt_get_option('logo') ) { ?>
							<img src="<?php echo qzt_get_option('logo'); ?>" alt="<?php bloginfo('name'); ?>"/>
							<?php }else{ ?>
							<img src="<?php bloginfo('template_url'); ?>/images/logo.png" alt="<?php bloginfo('name'); ?>" title="<?php bloginfo('name'); ?>"/>
							<?php }?>
						</a>
					</div>
					<div class="stui-header__side">
						<nav class="sidenav" data-sidenav data-sidenav-toggle="#sidenav-toggle">


			    <div class="sidenav-header">
			      <?php echo str_replace("</ul></div>", "", preg_replace("{<div[^>]*><ul[^>]*>}", "", wp_nav_menu(array('theme_location' => 'main', 'echo' => false)) )); ?>
			    </div>

	    
	  </nav>

	  <a href="javascript:;" class="toggle" id="sidenav-toggle">
	    <i class="iconfont icon-icon-test"></i>
	  </a>
	
	<script src="<?php bloginfo('template_url') ?>/js/jquery-1.11.0.min.js" type="text/javascript"></script>
	<script src="<?php bloginfo('template_url') ?>/js/sidenav.min.js"></script>
  	<script>$('[data-sidenav]').sidenav();</script>
						<div class="stui-header__search">
							 <form method="get" class="site-search-form" id="formsearch" action="<?php echo esc_url( home_url( '/' ) ); ?>" >
							  <input class="form-control" name="s" type="text" placeholder="搜索一下">
							  <button class="submit" type="submit">搜索</button>
							</form>
						</div>
					</div>

		

					<ul class="stui-header__menu type-slide">
						<?php echo str_replace("</ul></div>", "", preg_replace("{<div[^>]*><ul[^>]*>}", "", wp_nav_menu(array('theme_location' => 'main', 'echo' => false)) )); ?>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</header>