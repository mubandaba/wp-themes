<div class="stui-pannel stui-pannel-bg clearfix">
<div class="stui-pannel-box clearfix">
<div class="swiper-container">
	<div class="swiper-wrapper">
			<?php for($i=1;$i<7;$i++) {
			if (qzt_get_option("slidermedia$i") == "" ) break;
			?>
			<?php if (qzt_get_option("sliderurl$i") == "" ) { ?>
			<div class="swiper-slide"><a href="<?php echo qzt_get_option("sliderurl$i"); ?>"><img src="<?php echo qzt_get_option("slidermedia$i"); ?>"  alt="<?php echo qzt_get_option("slidertitle$i"); ?>" width="100%" /></a></div>
			<?php } else { ?>
			<div class="swiper-slide"><a href="<?php echo qzt_get_option("sliderurl$i"); ?>"><img src="<?php echo qzt_get_option("slidermedia$i"); ?>"  alt="<?php echo qzt_get_option("slidertitle$i"); ?>" width="100%" /></a></div>
			<?php } ?>
		<?php } ?>

	</div>
	<!-- Add Pagination -->
	<div class="swiper-pagination"></div>
</div>
	</div></div>
    <script>
    		var swiper = new Swiper('.swiper-container', {
		        pagination: '.swiper-pagination',
		        paginationClickable: true
		    });
    </script>