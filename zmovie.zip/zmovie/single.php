<?php get_header();?>
<div class="container">
	<div class="row">
		<div class="stui-pannel stui-pannel-bg clearfix">
			<div class="stui-pannel-box clearfix">
				<div class="stui-pannel_bd clearfix">
					<div class="col-md-wide-75 col-xs-1">
						<div class="stui-content clearfix">
							<div class="stui-content__thumb">
								<a class="stui-vodlist__thumb v-thumb lazyload" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" data-original="<?php post_thumbnail_src(); ?>" style="background-image: url(<?php post_thumbnail_src(); ?>);"><span class="play active hidden-xs"></span><span class="pic-text text-right"><?php echo get_post_meta($post->ID,"version_value",true);?></span></a>
							</div>
							<div class="stui-content__detail">
								<h3 class="title"><?php the_title(); ?></h3>
								<p class="data">
									<span class="text-muted">主演：</span><?php the_tags('',',',''); ?>
								</p>
								<p class="data">
									<span class="text-muted">导演：</span><?php echo get_post_meta($post->ID,"vod_director_value",true);?>
								</p>
								<p class="data">
									<span class="text-muted">类型：</span><?php echo get_post_meta($post->ID,"vod_type_value",true);?>
									<span class="split-line"></span><span class="text-muted hidden-xs">地区：</span><?php echo get_post_meta($post->ID,"vod_area_value",true);?><span class="split-line"></span>
									<span class="text-muted hidden-xs">年份：</span><?php echo get_post_meta($post->ID,"vod_year_value",true);?>
								</p>    
								<div id="box" style="width:500px;line-height:20px;overflow:hidden;position:relative">
							        <div class="nei" style="position:absolute;width:100%;color:#333">
							          <span class="left nei text-muted">简介：</span>
									 <?php echo get_post_meta($post->ID,"vod_blurb_value",true);?>  
							        </div>
							    </div>
								<a href="javascript:void(0)" class="showa"><i class="iconfont icon-gengduo1"></i>展开</a>
								<script src="http://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
								<script type="text/javascript">
								    $(document).ready(function(){
								        var oHeight = $('.nei').height();//获取里面div的高度
								        oldHeight=oHeight;//把里面div的高度赋值给外面的div
								        var newHeight = $("#box").css({height:"100px"});//这个是加载后给外面div设置的一个高度(显示内容的区域)
								        if(oHeight<100){//如果里面div的高度小于100的话也就是说内容不多的时候把更多按钮隐藏
								            $('.showa').css('display','none')
								        }
								        $(".showa").click(function(){
								        if(parseInt($("#box").height())==oldHeight){
								        $("#box").animate({height:"100px"});
								        $(this).html("展开");
								        }else{
								        $("#box").animate({height:oldHeight});
								        $(this).html("收起");
								        }
								        });
								    });
								</script>
							</div>
						</div>
					</div>
					<div class="col-md-wide-25 hidden-md hidden-sm hidden-xs">
						<div class="text-center" style="padding: 45px;">
							<p>
								<img class="qrcode" width="180" height="180" src="<?php bloginfo('template_url'); ?>/images/wximg.png">
							</p>
							<p class="font-12">
								扫码关注我们
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- 详细信息-->
		<?php if (have_posts()) : while (have_posts()) : the_post();?>
		<div id="nucms_downlist">
			<div class="p_list">
				<h2>《<?php the_title(); ?>》迅雷下载地址</h2>
				<ul class="p_list_02">
				<?php the_content(); ?>
				</ul>
			</div>
		</div>
		<?php endwhile;endif;?>
		<!-- 播放列表-->
		<div class="stui-pannel stui-pannel-bg clearfix">
			<div class="stui-pannel-box">
				<div class="stui-pannel_hd">
					<div class="stui-pannel__head clearfix">
						<h3 class="title"><img src="<?php bloginfo('template_url') ?>/images/icon_6.png">猜你喜欢</h3>
					</div>
				</div>
				<div class="stui-pannel_bd">
					<ul class="stui-vodlist__bd clearfix">
					<?php
					global $post;
					$cats = wp_get_post_categories($post->ID);
					if ($cats) {
					    $args = array(
							  'category__in' => array( $cats[0] ),
							  'post__not_in' => array( $post->ID ),
							  'showposts' => 12,
							  'caller_get_posts' => 1
						  );
					  query_posts($args);

					  if (have_posts()) {
					    while (have_posts()) {
					      the_post(); update_post_caches($posts); ?>
						<li class="col-md-6 col-sm-4 col-xs-3">
						<div class="stui-vodlist__box">
							<a class="stui-vodlist__thumb lazyload" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" data-original="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php post_thumbnail_src(); ?>&h=228&w=152&zc=1" style="background-image: url(<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php post_thumbnail_src(); ?>&h=228&w=152&zc=1);"><span class="play hidden-xs"></span><span class="pic-text text-right"><?php echo get_post_meta($post->ID,"version_value",true);?></span></a>
							<div class="stui-vodlist__detail">
										<h4 class="title text-overflow"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h4>
										<p class="text text-overflow text-muted hidden-xs"><?php the_tags('',',',''); ?></p>
									</div>
						</div>
						</li>
						<?php
						    }
						  } 
						  else {
						    echo '<li>* 暂无相关文章</li>';
						  }
						  wp_reset_query(); 
						}
						else {
						  echo '<li>* 暂无相关文章</li>';
						}
						?>
					</ul>
				</div>
			</div>
		</div>
		<!-- 猜你喜欢-->
	</div>
</div>
<?php get_footer(); ?>
