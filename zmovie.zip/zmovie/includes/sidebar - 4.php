<div class="col-lg-wide-25 hidden-md hidden-sm hidden-xs">
					<div class="stui-pannel_hd">
						<div class="stui-pannel__head clearfix"><a class="more text-muted pull-right" href="<?php echo get_category_link( qzt_get_option("variety") ); ?>">更多 <i class="iconfont icon-xiangyou1"></i></a>
							<h3 class="title"><img src="<?php bloginfo('template_url') ?>/images/icon_12.png">热播榜</h3>
						</div>
					</div>
					<?php $args=array('cat' => qzt_get_option("variety") , ); query_posts($args); ?> 
					<div class="stui-pannel_bd">
						<ul class="stui-vodlist__rank col-pd clearfix">
							<ol start="2">
							<?php if(have_posts()) : while (have_posts()) : the_post();  ?> 
							<li><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><span class="text-muted pull-right"><?php echo get_post_meta($post->ID,"version_value",true);?></span><?php echo cut_str($post->post_title,22); ?></a>
							</li>
							<?php  endwhile; endif; wp_reset_query(); ?>
							</ol> 
						</ul>
					</div>
				</div>
