<?php if(qzt_get_option("variety")){?>
<?php  
	$args=array(  
		'cat' => qzt_get_option("variety") ,   // 分类ID    
	);  
	query_posts($args);  	
			?> 
<div class="stui-pannel stui-pannel-bg clearfix">
			<div class="stui-pannel-box clearfix">
				<div class="col-lg-wide-75 col-xs-1 padding-0">
					<div class="stui-pannel_hd">
						<div class="stui-pannel__head clearfix"><a class="more text-muted pull-right" href="<?php echo get_category_link( qzt_get_option("variety") ); ?>">更多 <i class="icon iconfont icon-more"></i></a>
							<h3 class="title"><img src="<?php bloginfo('template_url') ?>/images/icon_1.png"><a href="<?php echo get_category_link( qzt_get_option("variety") ); ?>"><?php single_cat_title(); ?></a></h3>
							
						</div>
					</div>
					<div class="stui-pannel_bd clearfix">
						<ul class="stui-vodlist clearfix">
						<?php if(have_posts()) : while (have_posts()) : the_post();  ?> 
							<li class="col-md-5 col-sm-4 col-xs-3">
								<div class="stui-vodlist__box">
									<a class="stui-vodlist__thumb lazyload" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" data-original="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php post_thumbnail_src(); ?>&h=228&w=152&zc=1" style="background-image: url(<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php post_thumbnail_src(); ?>&h=228&w=152&zc=1);"><span class="play hidden-xs"></span><span class="pic-text text-right"><?php echo get_post_meta($post->ID,"vod_version_value",true);?></span></a>
									<div class="stui-vodlist__detail">
										<h4 class="title text-overflow"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h4>
										<p class="text text-overflow text-muted hidden-xs"><?php the_tags('',',',''); ?></p>
									</div>
								</div>
							</li>
						<?php  endwhile; endif; wp_reset_query(); ?>
						</ul>
					</div>
				</div>
				<?php include(TEMPLATEPATH.'/includes/sidebar - 4.php');?>
			</div>
		</div>
<?php } ?>