<?php get_header(); ?>
<div class="container">
<div class="row">
<?php include(TEMPLATEPATH.'/modules/slider.php');?>
<?php include( 'includes/excerpt - 1.php' ); ?>
<?php include( 'includes/excerpt - 2.php' ); ?>
<?php include( 'includes/excerpt - 3.php' ); ?>
<?php include( 'includes/excerpt - 4.php' ); ?>
</div>
</div>
<?php get_footer(); ?>