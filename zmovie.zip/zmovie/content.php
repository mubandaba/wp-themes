<li class="col-md-6 col-sm-4 col-xs-3">
							<div class="stui-vodlist__box">
									<a class="stui-vodlist__thumb lazyload" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" data-original="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php post_thumbnail_src(); ?>&h=228&w=152&zc=1" style="background-image: url(<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php post_thumbnail_src(); ?>&h=228&w=152&zc=1);"><span class="play hidden-xs"></span><span class="pic-text text-right"><?php echo get_post_meta($post->ID,"vod_version_value",true);?></span></a>
									<div class="stui-vodlist__detail">
										<h4 class="title text-overflow"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h4>
										<p class="text text-overflow text-muted hidden-xs"><?php the_tags('',',',''); ?></p>
									</div>
								</div>
						</li>