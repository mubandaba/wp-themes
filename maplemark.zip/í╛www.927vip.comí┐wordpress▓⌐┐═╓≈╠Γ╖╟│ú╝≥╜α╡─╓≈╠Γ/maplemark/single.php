<?php get_header(); ?>
<div class="clear"></div>
<div id="content">
	<div class="test_right">
		<div id="nav_map">
			<div class="browse">现在的位置: <a title="返回首页" href="<?php echo get_settings('Home'); ?>/"><?php bloginfo('name')?>首页</a> ＞<?php the_category(', ') ?>＞正文<!-- <?php the_title();?> --></div>
		</div>
		<div id="d_con">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<div class="entry_box_s">				
				<div class="entry_title_box">
					<div class="entry_title"><?php the_title(); ?></div>
					<div class="archive_info">
						<span class="date"><?php the_time('Y年m月d日') ?></span>
						<span class="category"> &#8260; <?php the_category(', ') ?></span>
						<?php include('includes/source.php'); ?>
						<span class="comment"> &#8260; <?php comments_popup_link('暂无评论', '评论数 1', '评论数 %'); ?></span>
						<?php if(function_exists('the_views')) { print ' &#8260; 被围观 '; the_views(); print '+';  } ?>
					</div>
				</div>
				<div class="entry">
					<div id="entry">
						<?php the_content('Read more...'); ?>
						<?php wp_link_pages( array( 'before' => '<p class="pages">' . __( '日志分页:'), 'after' => '</p>' ) ); ?>
						<div class="clear"></div>
					</div>
					<div class="clear"></div>
				</div>			
				<div style="color:#588524;font-size:16px;">喜欢这篇文章？赶快分享给好友吧！</div>
				<div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare">
				<a class="bds_qzone"></a>
				<a class="bds_tsina"></a>
				<a class="bds_tqq"></a>
				<a class="bds_renren"></a>
				<a class="bds_t163"></a>
				<span class="bds_more"></span>
				<a class="shareCount"></a>
				</div>
				<script type="text/javascript" id="bdshare_js" data="type=tools&amp;mini=1&amp;uid=732271" ></script>
				<script type="text/javascript" id="bdshell_js"></script>
				<script type="text/javascript">
				document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000)
				</script>
				<!-- Baidu Button END -->
				<!--百度分享结束-->
				<div class="clear"></div>
				<i class="lt"></i>
				<i class="rt"></i>
			</div>
			<div class="entry_sb">
				<i class="lb"></i>
				<i class="rb"></i>
			</div>
			本文固定链接地址：<a href="<?php  the_permalink(); echo $custom_value[1] ?>" ><strong><?php  the_permalink();  echo $custom_value[1] ?></strong></a>
					<!-- entrymeta -->
		
					<div class="entry_sb">
						<i class="lb"></i>
						<i class="rb"></i>
					</div>
					<!-- end: entrymeta -->
				<div class="context_b">
					<?php previous_post_link('【上篇】%link') ?><br/><?php next_post_link('【下篇】%link') ?>
					<i class="lt"></i>
					<i class="rt"></i>
					<i class="lb"></i>
					<i class="rb"></i>
				</div>
				<div class="ct"></div>
				<?php comments_template(); ?>
				<?php endwhile; else: ?>
				<?php endif; ?>
		</div>
	</div>
	<div class="test_left">
		<div class="test_left1">
			<div class="newarticles">
					<h3>最新推荐阅读</h3>	
					<div class="box_r">
						<ul>
							<li>
								<?php
								global $post;
								$args = array( 'numberposts' => 12, 'offset'=> 0, 'caller_get_posts' => 20 );
								$myposts = get_posts( $args );
								foreach( $myposts as $post ) :	setup_postdata($post); ?>
								<a href="<?php the_permalink(); ?>"><?php echo mb_strimwidth(get_the_title(), 0, 31, '');?></a>
								<?php endforeach; ?>
							</li>
						</ul>
						<div class="clear"></div>
					</div>
					<div class="box-bottom">
						<i class="lb"></i>
						<i class="rb"></i>
					</div>
			</div>
			<div class="test_left2" id="float">
				<!--广告位展示-->
				<div id="right_adlayout">
					<img src="<?php bloginfo('template_url'); ?>/images/myblog.png" name="枫叶林图片" alt="枫叶网站" width="230px" height="100px">
				</div>
				<!--本站导航目录-->
				<div id="right_content">
						<div style="float:left; margin-left:20px;">
						  <!--This is the second division of right-->
						  <h3 class="menu_title">茫茫人海哪里去!</h3>
						  <div class="menu_list" id="secondpane">
							<!--Code for menu starts here-->
							<p class="menu_head">枫叶技术</p>
							<div class="menu_body"> <a href="/cache/tag/wordpress"target="_blank">wordpress</a> <a href="/cache/tag/安卓开发"target="_blank">安卓开发</a>  <a href="/cache/tag/电脑软件"target="_blank">电脑软件</a> <a href="/cache/tag/安卓软件"target="_blank">安卓软件</a><a href="/cache/tag/SEO"target="_blank">SEO</a> <a href="/cache/tag/VPS"target="_blank">VPS</a> <a href="/cache/tag/域名"target="_blank">域名</a> </div>
							<p class="menu_head">互联网吧</p>
							<div class="menu_body"> <a href="/cache/tag/Google"target="_blank">Google</a> <a href="/cache/tag/Apple"target="_blank">Apple</a> <a href="/cache/tag/Iphone"target="_blank">Iphone</a> <a href="/cache/tag/Ipad"target="_blank">Ipad</a> <a href="/cache/tag/创业"target="_blank">创业</a>   </div>
							<p class="menu_head">手机异族</p>
							<div class="menu_body"><a href="/cache/tag/Samsung"target="_blank">Samsung</a> <a href="/cache/tag/索尼"target="_blank">索尼</a> <a href="/cache/tag/wt19i"target="_blank">wt19i</a> <a href="/cache/tag/魅族"target="_blank">魅族</a> <a href="/cache/tag/小米"target="_blank">小米</a> <a href="/cache/tag/锤子"target="_blank">锤子</a>  </div>
							<p class="menu_head">三星乐园</p>
							<div class="menu_body"> <a href="/cache/tag/CM10"target="_blank">CM10</a> <a href="/cache/tag/P3100"target="_blank">P3100</a> <a href="/cache/tag/P3110"target="_blank">P3110</a> <a href="/cache/tag/P3108"target="_blank">P3108</a> <a href="/cache/tag/P3113"target="_blank">P3113</a>   </div>
							<p class="menu_head">好好学习</p>
							<div class="menu_body"> <a href="/cache/tag/汽车"target="_blank">汽车</a> <a href="/cache/tag/电影"target="_blank">电影</a> <a href="/cache/tag/转载"target="_blank">转载</a> <a href="/cache/tag/考研"target="_blank">考研</a>   </div>
						  </div>
						  <!--Code for menu ends here-->
						</div>
				</div>
				<div id="right_flash">	
						<embed src="<?php bloginfo('template_url'); ?>/images/hamster.swf" quality=high pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="230" height="180"></embed>
				</div>
				<!--邮件订阅本站-->
				  <div id="email_feed">	
					小白鼠好可怜 快饿死了
					</div>
				</div>
			</div>
		</div>
	</div>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/notmove.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/plugin.client.js" ></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/right_content.js" ></script>
</div>
<?php get_footer(); ?>
</body>
</html>
