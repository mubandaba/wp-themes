<?php get_header(); ?>
<div id="roll"><div title="回到顶部" id="roll_top"></div><div title="转到底部" id="fall"></div></div>
<div id="content">
	<div id="map">
		<div class="browse">现在位置 ＞<a title="返回首页" href="<?php echo get_settings('Home'); ?>/">枫叶首页</a> ＞未知页面</div>
		<div id="feed"><a href="<?php bloginfo('rss2_url'); ?>" title="RSS">RSS</a></div>
	</div>
	<!-- end: menu -->
	<div class="entry_box_s">
		 <div class="entry">
			<div class="error">
 				 <h2>对不起！这个真没有，等等这里好像有只青蛙。</h2>
<object codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" height="460" width="680" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"><param name="_cx" value="10583"><param name="_cy" value="7938"><param name="FlashVars" value=""><param name="Movie" value="/images/404.swf"><param name="Src" value="/images/404.swf"><param name="WMode" value="Window"><param name="Play" value="-1"><param name="Loop" value="-1"><param name="Quality" value="High"><param name="SAlign" value=""><param name="Menu" value="-1"><param name="Base" value=""><param name="AllowScriptAccess" value=""><param name="Scale" value="ShowAll"><param name="DeviceFont" value="0"><param name="EmbedMovie" value="0"><param name="BGColor" value=""><param name="SWRemote" value=""><param name="MovieData" value=""><param name="SeamlessTabbing" value="1"><param name="Profile" value="0"><param name="ProfileAddress" value=""><param name="ProfilePort" value="0">
<embed src="/images/404.swf" width="680" height="460" play="true" loop="false" menu="true" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash">
</object>
				<div class="search_c">
					<h3>搜索</h3>
					<?php if (get_option('swt_search') == 'google') { ?>
					<?php include('includes/g_search.php'); ?>
					<?php } else { include(TEMPLATEPATH . '/includes/w_search.php'); } ?>
				</div>
 			</div>
 		  </div>
 			<div id="expand_collapse">展开收缩</div>
			<div id="archives">
				<?php archives_list_SHe(); ?>
			</div>		
		<div class="clear"></div>
		<!-- end: entry -->
		<i class="lt"></i>
		<i class="rt"></i>
	</div>
	<div class="entry_sb">
		<i class="lb"></i>
		<i class="rb"></i>
	</div>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
<script type="text/javascript">
jQuery(function($){
	$('#expand_collapse,.archives-yearmonth').css({cursor:"pointer"});
	$('#archives ul li ul.archives-monthlisting').hide();
	$('#archives ul li ul.archives-monthlisting:first').show();
	$('#archives ul li span.archives-yearmonth').click(function(){$(this).next().slideToggle('fast');return false;});
	//以下是全局的操作
	$('#expand_collapse').toggle(
	function(){
	$('#archives ul li ul.archives-monthlisting').slideDown('fast');
	},
	function(){
	$('#archives ul li ul.archives-monthlisting').slideUp('fast');
	});
	});
</script>