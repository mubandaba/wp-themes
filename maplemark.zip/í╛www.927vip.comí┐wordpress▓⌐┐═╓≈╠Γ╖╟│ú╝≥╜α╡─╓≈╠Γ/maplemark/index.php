<?php get_header(); ?>
<div id="content">
 <div id="post">
	<div class="nav_map">
		<div class="browse"> 现在位置: <a title="返回首页" href="<?php echo get_settings('Home'); ?>/"><?php bloginfo('name')?></a></div>
	</div>
	<div class="clear"></div>
		<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
	<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
		<div class="entry_box">
			<div class="box_entry">
				<div class="box_entry_title">
						<h4><a href="<?php the_permalink() ?>" rel="bookmark" title="详细阅读 <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h4>
						<div class="post_time">
							<span class="date"><?php the_time('Y年m月d日') ?></span>
							<span class="category"> &#8260; <?php the_category(', ') ?></span>&nbsp						
							<?php if(function_exists('the_views')) { print ' &#8260; 被围观 '; the_views(); print '+';  } ?>
						</div>
				</div>
				<div class="new"><?php include('inc/new.php'); ?></div>
					<?php if (is_sticky()) {echo '<div class="sticky-post"></div>';} ?>
				<div class="clear"></div>
				<div class="thumbnail_box">
						<?php include('inc/thumbnail.php'); ?>
				</div>
				<div class="post_entry">
						<?php if (has_excerpt())
						{ ?> 
							<?php the_excerpt() ?>
						<?php
						}
						else{
							echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0,280,"...");
						} 
						?>
				</div>
			</div>
			<i class="lt"></i>
			<i class="rt"></i>
		</div>	
		<div class="entry_box_b">
			<i class="lb"></i>
			<i class="rb"></i>
		</div>
	</div>
		<?php endwhile; ?>
		<?php endif; ?>
	<div class="navigation"><?php pagination($query_string); ?></div>
	<div class="clear"></div>
 </div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>