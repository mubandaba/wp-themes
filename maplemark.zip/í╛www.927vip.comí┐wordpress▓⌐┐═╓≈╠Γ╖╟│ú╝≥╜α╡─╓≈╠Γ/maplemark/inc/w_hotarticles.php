<div class="hotarticles">
	<h3>年度排行</h3>
	<div class="box_r">
		<ul>
			<?php simple_get_most_vieweds(); ?>
		</ul>
		<div class="clear"></div>
	</div>
	<div class="box-bottom">
		<i class="lb"></i>
		<i class="rb"></i>
	</div>
</div>