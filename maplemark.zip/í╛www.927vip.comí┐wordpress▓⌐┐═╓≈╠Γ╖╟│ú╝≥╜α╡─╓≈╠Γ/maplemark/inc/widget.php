<?php
// 最新文章
class news extends WP_Widget{
	function news(){
		$widget_options = array('classname'=>'set_contact','description'=>'主题自带的最新文章');
		$this->WP_Widget( false,'主题小工具&nbsp;&nbsp;&nbsp;&nbsp;最新文章',$widget_options );
    }
	function widget($instance){
		include("w_newarticles.php");
?>
<?php
}
}
add_action('widgets_init',create_function('', 'return register_widget("news");'));


// 随机文章
class random extends WP_Widget{
    function random(){
		$widget_options = array('classname'=>'set_contact','description'=>'主题自带的随机文章');
		$this->WP_Widget(false,'主题小工具&nbsp;&nbsp;&nbsp;&nbsp;随机文章',$widget_options);
    }
	function widget($instance){
		include("w_random.php");
?>
<?php
}
}
add_action('widgets_init',create_function('', 'return register_widget("random");'));



?>