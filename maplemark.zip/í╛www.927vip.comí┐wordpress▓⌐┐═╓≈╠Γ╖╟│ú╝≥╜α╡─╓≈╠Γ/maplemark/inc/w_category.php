<h3>分类目录</h3>	
<div class="categories">
	<div class="categories_c">
		<ul><?php wp_list_cats('sort_column=name&hierarchical=0&exclude='.get_option('swt_cat_exclude')); ?></ul>
	</div>
	<div class="clear"></div>
</div>
<div class="box-bottom">
	<i class="lb"></i>
	<i class="rb"></i>
</div>