<!-- 首页页脚 -->
<?php wp_reset_query();if ( is_home()){ ?>
<div class="link">
	<?php
		if(function_exists('wp_hto_get_links')){
		wp_hot_get_links();
		}else{
		wp_list_bookmarks('title_li=&categorize=1&category=&orderby=rand&limit=38&show_images=');
		}
	?>
	<div class="clear"></div>
</div>
<div class="link_b">
	<big class="lb"></big>
	<big class="rb"></big>
</div>
<!-- end: link -->

<?php } ?>
 <div class="clear"></div>
</div>


<div id="my_footer_wrapper">
	<div id="my_footer">
        
        <span>【</span><a href="/" rel="nofollow" target="_blank">枫叶林</a><span>】</span> <span>【</span><a href="/" target="_blank">枫叶网站</a><span>】</span> <span>【</span><a href="/sitemap.html" target="_blank">本站地图</a><span>】</span> <span>【</span><a href="/sitemap_baidu.xml" target="_blank">百度地图</a><span>】</span>  <span>【</span><a href="/sitemap.xml" target="_blank">谷歌地图</a><span>】</span> <span>【</span><a href="http://3g.maplemark.cn/" target="_blank">手机版</a><span>】</span>     <span>【</span><a href="/" target="_blank">客户端</a><span>】</span>  
	
     
    </div> <!-- end of footer -->
</div> <!-- end of footer wrapper -->    

<div id="my_copyright_wrapper">
	<div id="my_copyright">
    
		本站交流QQ群108929182欢迎加入 Copyright © 2010-2015 <a href="/">枫叶林网站</a>
</div> <!-- end of copyright -->
</div>
<!--流量统计代码-->
<div style="visibility:hidden">
 <script src="http://s95.cnzz.com/stat.php?id=4766923&web_id=4766923&show=pic1" language="JavaScript"></script>
</div>
</div>
<?php wp_footer(); ?>

</body></html>