<div id="sidebar">

	<div class="widget">
		<?php wp_reset_query();if ( is_home()){ ?>
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('首页小工具') ) : ?>
		<?php endif; ?>
		<?php } ?>
	</div>

	<div class="widget">
		<?php wp_reset_query();if (is_single() || is_page() || is_archive() || is_search()) { ?>
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('其他小工具') ) : ?>
		<?php endif; ?>
		<?php } ?>
	</div>
</div>

</div>