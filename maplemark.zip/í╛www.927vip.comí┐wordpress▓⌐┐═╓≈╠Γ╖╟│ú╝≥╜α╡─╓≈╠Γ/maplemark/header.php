<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes() ?>>
<head>
<meta name="keywords"  content="枫叶|枫叶林|枫叶网|个人博客|博客网站|枫叶网络|枫叶网站|移动互联|移动终端|网络技术|枫叶物语|汽车生活|影视宝库" />
<meta name="description"  content="枫叶林是一个提供IT行业移动互联网发展信息网站,提供网站建设信息,分享个人经验和总结,值得大家收藏的互联生活类优秀个人博客网站" />
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<link rel="alternate" type="application/vnd.wap.xhtml+xml" media="handheld" href="http://3g.maplemark.cn"/>
<link rel="shortcut icon" href="<?php bloginfo('template_directory'); ?>/images/favicon.ico" />
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/style.css" />
<?php if (function_exists('wp_enqueue_script') && function_exists('is_singular')) : ?>
<script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/jquery.min.js" ></script>
<?php wp_head(); ?>
<?php if ( is_singular() ){ ?>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/comments-ajax.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/reply.js"></script>
<?php } ?>
<?php endif; ?>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/custom.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/superfish.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/muscript.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/images/fixed/base.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/images/fixed/index.js"></script>
<script type="text/javascript"><!--//--><![CDATA[//><!--
sfHover = function() {
	if (!document.getElementsByTagName) return false;
	var sfEls = document.getElementById("menu").getElementsByTagName("li");
	for (var i=0; i<sfEls.length; i++) {
		sfEls[i].onmouseover=function() {
			this.className+=" sfhover";
		}
		sfEls[i].onmouseout=function() {
			this.className=this.className.replace(new RegExp(" sfhover\\b"), "");
		}
	}	
	var sfEls = document.getElementById("topnav").getElementsByTagName("li");
	for (var i=0; i<sfEls.length; i++) {
		sfEls[i].onmouseover=function() {
			this.className+=" sfhover";			}
	}
}
if (window.attachEvent) window.attachEvent("onload", sfHover);
//--><!]]></script>
</head>
<body>
<div id="wrapper">
	<div id="fixed">
		<div class="f_reset">
			<a href="<?php bloginfo('url')?>"><img src="<?php bloginfo('template_directory')?>/images/fixed/logo.png"/ title="枫叶林" width="127px" height="29px"></a>
			<div class="message">
				<a target="_blank" href="http://sighttp.qq.com/authd?IDKEY=c833177cee5e5d6286e8448464bfe2da6920d54255633416" title="QQ消息">消息传达门</a>
			</div>
			<div class="tencent">
				<a target="_blank" href="http://wp.qq.com/wpa/qunwpa?idkey=c21c28f0cb525a7878568257ee2e691c609d95ffd7163e5c1dc97332eb58cd5c"><img border="0" src="http://pub.idqqimg.com/wpa/images/group.png" alt="WP网站交流群" title="WP网站交流群"></a>
			</div>
			<div class="navi" title="本站直达">本站直达
				<ul class="navi_list">
					<?php wp_list_categories('orderby=id&hide_empty=0&title_li='); ?>	
				</ul>
			</div>	
			<div class="screen_more" title="内容开发中，敬请关注...">发现更多</div>
		</div>
	</div>
	<div class="clear"></div>
	<div id="d">
	  <?php 
	  if(has_nav_menu('nav-menu')){
	  	wp_nav_menu( array(  'theme_location'  => 'nav-menu', 'container' => '', 'menu_class' => 'nav', )	);
	  }else{echo "<ul class='nav'><li><a href='".get_bloginfo('url')."/wp-admin/nav-menus.php'>还没有设置导航菜单，请到点击这里到后台 外观->菜单 设置一个导航菜单</a></li></ul>"; }
	 ?>
	</div>
<!--site app声明代码-->
<script src="http://siteapp.baidu.com/static/webappservice/uaredirect.js" type="text/javascript"></script><script type="text/javascript">uaredirect("http://3g.maplemark.cn", "http://www.maplemark.cn");</script>