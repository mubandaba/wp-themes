$(document).ready(function(){
	$('#post-menu li').tooltip();
});