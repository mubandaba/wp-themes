<div class="container">
	<footer>
		Copyright 2011-2013 www.mao01.com allright reserved. 网站设计 <a href="http://www.mao01.com/" title="wordpress建站">猫猫工作室</a>
	</footer>
</div>
<!-- Load JS here for greater good =============================-->
<script src="<?php bloginfo('template_directory'); ?>/js/jquery.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/bootstrap.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/cat.js"></script>
</body>
<?php wp_footer(); ?>
</html>