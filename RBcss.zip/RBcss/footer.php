		<div id="footer">
		<span>由 <a href="http://wordpress.org">WordPress</a>提供动力  </span> 
 <a href="http://marslau.com/archives/330.html" title="RBcss" target="_blank"> RBcss</a> 主题由 <a href="http://marslau.com" title="MarsLau's Blog" target="_blank">Mars Lau</a> 设计，通过 <a href="http://validator.w3.org/check?uri=referer"> XHTML 1.1 </a> 和 <a href="http://jigsaw.w3.org/css-validator/"> CSS 3 </a> 验证。 <script type="text/javascript" src="http://js.tongji.linezing.com/1363932/tongji.js"></script><noscript><a href="http://www.linezing.com"><img src="http://img.tongji.linezing.com/1363932/tongji.gif"/></a></noscript>
		</div>
	</div>
</body>
</html>