<?php get_header(); ?>
		<?php global $options;

		if (O('sidebar-pos') == 'left' || O('no-sidebar')) get_sidebar();
		if (O('sidebar-card') && O('sidebar-pos') == 'right' && !O('no-sidebar')) get_template_part('module', 'cardtop');
		?>

		<div id="content" class="wp left">
			<h1 class="search-title post-title">
				<?php printf(__('Search Results for: %s', 'twentyfifteen'), get_search_query()); ?>
			</h1>
			<?php if(have_posts()) {
				while(have_posts()) {
					the_post();
					get_template_part('content', get_post_format());
				}
			} else {
				get_template_part('content', 'none');
			} ?>

			<?php if ($wp_query->max_num_pages > 1) { ?>
				<div id="p-nav" class="clf"><?php pagenavi(); ?></div>
			<?php } ?>
		</div><!-- #content.wp.center -->

		<?php if (O('sidebar-pos') == 'right' && !O('no-sidebar')) get_sidebar(); ?>

	</div><!-- #container.wc.center -->

<?php get_footer(); ?>
