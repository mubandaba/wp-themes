<?php
if (O('sidebar-card')) { ?>
<div id="cardtop">
	<div class="gr center">
		<?php
		if (substr(O('sidebar-avatar'), 0 , 7) == 'http://' || substr(O('sidebar-avatar'), 0 , 8) == 'https://') {
			echo '<img src="' . O('sidebar-avatar') . '" width="112" height="112">';
		} else {
			if(preg_match('/^[_.0-9a-z-]+@([0-9a-z][0-9a-z-]+.)+[a-z]{2,3}$/', O('sidebar-avatar'))) {
				echo get_avatar(O('sidebar-avatar'), 112);
			} else {
				echo get_avatar(1, 112);
			}
		} ?>
	</div>
	<div class="blogname"><?php echo(empty($GLOBALS['o']['card-title']) ? get_bloginfo('name') : $GLOBALS['o']['card-title']); ?></div>
	<div class="blogdesc"><?php echo(empty($GLOBALS['o']['card-desc']) ? get_bloginfo('description') : $GLOBALS['o']['card-desc']); ?></div>
	<div class="sbmenu"><?php
		wp_nav_menu(array(
			'theme_location' => 'sbmenu',
			'depth' => 1,
			'fallback_cb' => '__return_null'
		));
	?></div>
</div>
<?php } ?>