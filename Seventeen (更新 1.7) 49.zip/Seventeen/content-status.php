<div id="post-<?php the_ID();?>" <?php post_class(); ?>>
	<div class="status-avatar"><?php echo get_avatar(get_the_author_meta('email'), 70); ?></div>
	<div class="status-content">
		<div class="status-body">
			<?php the_content('阅读全文→'); ?>
		</div>
		<div class="status-meta">
			<span><?php the_author_link(); ?></span>
			<span><?php the_time('Y-m-j'); ?></span>
			<span><?php comments_popup_link('没有评论', '1个评论', '%个评论'); ?></span>
			<?php edit_post_link(__('Edit'), '', ''); ?>
		</div>
	</div>
</div><!-- #post-ID -->