<?php
// Silence is golden.
if(!empty($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME'])) exit();
if(post_password_required() || (!comments_open() && (get_comments_number() == 0))) return;
?>

<div id="comments" class="comments-area">

	<div id="loading-comments">
		<img src="<?php echo get_template_directory_uri(); ?>/images/loading-comment.gif">
		<span>Loading...</span>
	</div>

	<?php if (have_comments()) { ?>
		<ol class="comment-list">
			<?php
				wp_list_comments(array(
					'callback'          => 'st_list_comments',
					'type'              => 'all',
					'max_depth'         => '9999',
				));
			?>
		</ol><!-- .comment-list -->
	<?php } // have_comments() ?>

	<div class="comments-nav">
		<?php paginate_comments_links('prev_text=前一页&next_text=后一页'); ?>
	</div>

	<?php if(comments_open()) {
		$req = get_option('require_name_email');
		comment_form(array(
			'comment_field'        => '<div style="clear:both;"></div><p></p><p class="comment-form-comment"><textarea id="comment" name="comment" cols="45" rows="8" aria-required="true"' . (O('comment-placeholder') != '' ? ' placeholder="' . O('comment-placeholder') . '"' : '') . '></textarea></p>',
			'title_reply'          => '', //__('Leave a Reply'),
			'title_reply_to'       => '', //__('Leave a Reply to %s'),
			'cancel_reply_link'    => __('Cancel reply'),
			'label_submit'         => __('Post Comment')
    	));
	} else { ?>
		<em class="comment-closed"><?php _e('Comments are closed.'); ?></em>
	<?php } ?>

</div>