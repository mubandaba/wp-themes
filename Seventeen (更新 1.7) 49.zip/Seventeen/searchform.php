<form role="search" method="get" id="searchform" action="<?php echo home_url('/'); ?>">
	<div>
		<input type="text" value="" name="s" id="s" placeholder="<?php echo(O('search-placeholder') != '' ? O('search-placeholder') : '输入，回车搜索'); ?>" />
		<input type="submit" id="searchsubmit" value="Search" />
	</div>
</form>