<?php get_header(); ?>
		<?php
		if (O('sidebar-pos') == 'left' || O('no-sidebar')) get_sidebar();
		if (O('sidebar-card') && O('sidebar-pos') == 'right' && !O('no-sidebar')) get_template_part('module', 'cardtop');
		?>

		<div id="content" class="wp left">
			<?php dimox_breadcrumbs(); ?>
			<?php while(have_posts()) {
				the_post();
				?>
				<div id="post-<?php the_ID();?>" <?php post_class(); ?>>
					<h1 class="post-title">
						<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title();?></a>
					</h1>
					<div class="post-content">
						<?php the_content(''); ?>
					</div>
				</div><!-- #post-ID -->
			<?php } ?>
			
			<?php comments_template(); ?>

		</div><!-- #content.wp.center -->

		<?php if (O('sidebar-pos') == 'right' && !O('no-sidebar')) get_sidebar(); ?>

	</div><!-- #container.wc.center -->

<?php get_footer(); ?>
