<?php get_header(); ?>
		<?php global $options;

		if (O('sidebar-pos') == 'left' || O('no-sidebar')) get_sidebar();
		if (O('sidebar-card') && O('sidebar-pos') == 'right' && !O('no-sidebar')) get_template_part('module', 'cardtop');
		?>

		<div id="content" class="wp">
			<?php dimox_breadcrumbs(); ?>
			<?php while(have_posts()) {
				the_post();
				if (get_post_format() == 'status') get_template_part('content', 'status');
				else get_template_part('content');
			} ?>
			
			<?php comments_template(); ?>

		</div><!-- #content.wp.center -->

		<?php if (O('sidebar-pos') == 'right' && !O('no-sidebar')) get_sidebar(); ?>

	</div><!-- #container.wc.center -->

<?php get_footer(); ?>
