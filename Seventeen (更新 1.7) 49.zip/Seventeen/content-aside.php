<div id="post-<?php the_ID();?>" <?php post_class(); ?>>
	<div class="post-content<?php if (!is_singular()) echo ' inpl'; ?>">
		<?php the_content('阅读全文→'); ?>
	</div>
	<?php st_post_meta(); ?>
</div><!-- #post-ID -->