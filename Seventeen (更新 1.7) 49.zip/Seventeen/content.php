<div id="post-<?php the_ID();?>" <?php post_class(); ?>>
	<?php if (has_post_thumbnail()) { ?>
		<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="post-thumbnail fw">
			<?php the_post_thumbnail(); ?>
		</a>
	<?php } ?>
	<?php if (get_the_title() != '') { ?>
		<?php echo(is_single() ? '<h1 class="post-title">' : '<h2 class="post-title">'); ?>
			<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title();?></a>
		<?php echo(is_single() ? '</h1>' : '</h2>'); ?>
	<?php } ?>
	<div class="post-content">
		<?php the_content('阅读全文→'); ?>
		<?php if (is_single()) {
			if (!empty($GLOBALS['o']['post-copy'])) {
				$copycode = str_replace(array("{{title}}", "{{link}}"), array(get_the_title(), get_the_permalink()), O('post-copy'));
				echo '<br><div class="post-about"><p>' . stripcslashes($copycode) . '</p></div class="post-about">';
			}
			if (!empty($GLOBALS['o']['share-code'])) echo '<br>' . stripcslashes(O('share-code'));
		} ?>
	</div>
	
	<?php if (is_singular()) {
		wp_link_pages(array(
			'before' => '<div class="post-pagenavi">',
			'after' => '',
			'next_or_number' => 'next',
			'previouspagelink' => '<span class="page-numbers prev fa fa-angle-left"></span>',
			'nextpagelink' => ""
		));
		wp_link_pages(array(
			'before' => '',
			'after' => '',
			'next_or_number' => 'number',
			'link_before' =>'<span class="page-numbers">',
			'link_after'=>'</span>'
		));
		wp_link_pages(array(
			'before' => '',
			'after' => '</div>',
			'next_or_number' => 'next',
			'previouspagelink' => '',
			'nextpagelink' => '<span class="page-numbers next fa fa-angle-right"></span>'
		));
	}
	st_post_meta(); ?>
</div><!-- #post-ID -->
<?php if (is_singular()) { ?>
	<?php the_tags('<div class="post-tags"><span class="tagtip">' . __('Tags') . ':</span>', '', '</div>'); ?>
<?php } ?>