<?php
query_posts(array('post_type' => 'st_slider'));
if(O('slider') && have_posts()) { ?>

<div class="banner hentry">
    <ul>
	<?php while(have_posts()) {
	    the_post();
	    
		$image_url = get_post_meta($post->ID, 'slider_imgurl', true);
		$image_link = get_post_meta($post->ID, 'slider_link', true);
		
		if ($image_url != '') { ?>
		<li>
			<a href="<?php echo(empty($image_link) ? "#" : $image_link); ?>">
				<img src="<?php echo $image_url; ?>" alt="<?php the_title(); ?>" />
			</a>
		</li>
	    <?php }
    } ?>
    </ul>
</div>

<?php }

wp_reset_query();
