<div id="post-<?php the_ID();?>" <?php post_class(); ?>>
	<h1 class="post-title">
		<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title();?></a>
	</h1>
	<div class="post-content">
		<?php the_content('阅读全文→'); ?>
	</div>
	<?php st_post_meta(); ?>
</div><!-- #post-ID -->