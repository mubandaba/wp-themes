<?php
/*
  Template Name: Link page
 */
	get_header(); ?>
		<?php
		if (O('sidebar-pos') == 'left' || O('no-sidebar')) get_sidebar();
		if (O('sidebar-card') && O('sidebar-pos') == 'right' && !O('no-sidebar')) get_template_part('module', 'cardtop');
		?>

		<div id="content" class="wp left">
			<?php dimox_breadcrumbs(); ?>
			<?php while(have_posts()) {
				the_post();
				?>
				<div id="post-<?php the_ID();?>" <?php post_class(); ?>>
					<h1 class="post-title">
						<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title();?></a>
					</h1>
					<div class="post-content" id="page-links">
						<?php global $options;
						$default_ico = get_template_directory_uri().'/images/links_default.png'; //默认 ico 图片位置
						if (O('linkpage-sort-by-cat')) {
							$cats = get_terms('link_category');
							if (!empty($cats)) {
								foreach ($cats as $cat) {
									$bookmarks = get_bookmarks('title_li=&categorize=0&category=' . $cat->term_id . '&orderby=rand');
									echo '<div class="link-cat"><h3 class="link-cat-title">' . $cat->name . '</h3><ul class="clf">';
									foreach ($bookmarks as $bookmark) {
										echo '<li><img src="', $bookmark->link_url , '/favicon.ico" /><a href="' , $bookmark->link_url , '" title="' , $bookmark->link_description , '" target="' , $bookmark->link_target , '" >' , $bookmark->link_name , '</a></li>';
									}
									echo '</ul></div>';
								}
							}
						} else {
							echo '<ul class="clf">';
							$bookmarks = get_bookmarks('title_li=&orderby=rand');
							if (!empty($bookmarks)) {
								foreach ($bookmarks as $bookmark) {
									echo '<li><img src="', $bookmark->link_url , '/favicon.ico" onerror="javascript:this.src=\'' , $default_ico , '\';" /><a href="' , $bookmark->link_url , '" title="' , $bookmark->link_description , '" target="' , $bookmark->link_target , '" >' , $bookmark->link_name , '</a></li>';
								}
							}
							echo '</ul>';
						}
						the_content(''); ?>
						<script type="text/javascript">
							$("#page-links img").bind("error", function() {
								this.src = "<?php echo $default_ico; ?>";
							});
						</script>
					</div>
				</div><!-- #post-ID -->
			<?php } ?>
			
			<?php comments_template(); ?>

		</div><!-- #content.wp.center -->

		<?php if (O('sidebar-pos') == 'right' && !O('no-sidebar')) get_sidebar(); ?>
		
	</div><!-- #container.wc.center -->

<?php get_footer(); ?>
