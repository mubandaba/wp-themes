<?php

/**
 * WordPress 內置嵌套評論專用 Ajax comments >> WordPress-jQuery-Ajax-Comments v1.3 by Willin Kan.
 *
 * 說明: 這個文件是由 WP 3.0 根目錄的 wp-comment-post.php 修改的, 修改的地方有注解. 當 WP 升級, 請注意可能有所不同.
 */

/** 
 * 由 轻歌 修改升级至适合 WordPress 3.6+ 的版本，目前使用的是 WP 4.3 的 wp-comment-post.php
 * 
 * 主要修改部位如下：
 * 1. 禁止缓存的头部输出改为使用 nocache_headers() 函数
 * 2. 评论者cookies设置改为使用WordPress钩子
 * 3. WordPress 3.6 已弃用 wpdb::escape() 方法，根据升级后的文件应改为使用 wp_slash() 函数
 * 4. 判断用户登录改为使用 user::exists() 方法，同时判断用户是否存在，以避免伪造cookies攻击
 * 
 * https//i.qaq.cat
 */
 
/**
 * Handles Comment Post to WordPress and prevents duplicate comment posting.
 *
 * @package WordPress
 */

if ( 'POST' != $_SERVER['REQUEST_METHOD'] ) {
	header('Allow: POST');
	header('HTTP/1.1 405 Method Not Allowed');
	header('Content-Type: text/plain');
	exit;
}

/** Sets up the WordPress Environment. */
// require( dirname(__FILE__) . '/wp-load.php' );
// 此 comments-ajax.php 位於主題資料夾,所以位置已不同
require( dirname(__FILE__) . '/../../../wp-load.php' );

nocache_headers();

$comment_post_ID = isset($_POST['comment_post_ID']) ? (int) $_POST['comment_post_ID'] : 0;

$post = get_post($comment_post_ID);

if ( empty( $post->comment_status ) ) {
	/**
	 * Fires when a comment is attempted on a post that does not exist.
	 *
	 * @since 1.5.0
	 *
	 * @param int $comment_post_ID Post ID.
	 */
	do_action( 'comment_id_not_found', $comment_post_ID );
	// exit;
	// 將 exit 改為錯誤提示
	err(__('Invalid comment status.'));
}

// get_post_status() will get the parent status for attachments.
$status = get_post_status($post);

$status_obj = get_post_status_object($status);

if ( ! comments_open( $comment_post_ID ) ) {
	/**
	 * Fires when a comment is attempted on a post that has comments closed.
	 *
	 * @since 1.5.0
	 *
	 * @param int $comment_post_ID Post ID.
	 */
	do_action( 'comment_closed', $comment_post_ID );
	// wp_die( __( 'Sorry, comments are closed for this item.' ), 403 );
	// 將 wp_die 改為錯誤提示
	err( __( 'Sorry, comments are closed for this item.' ) );
} elseif ( 'trash' == $status ) {
	/**
	 * Fires when a comment is attempted on a trashed post.
	 *
	 * @since 2.9.0
	 *
	 * @param int $comment_post_ID Post ID.
	 */
	do_action( 'comment_on_trash', $comment_post_ID );
	// exit;
	// 將 exit 改為錯誤提示
	err(__('Invalid comment status.'));
} elseif ( ! $status_obj->public && ! $status_obj->private ) {
	/**
	 * Fires when a comment is attempted on a post in draft mode.
	 *
	 * @since 1.5.1
	 *
	 * @param int $comment_post_ID Post ID.
	 */
	do_action( 'comment_on_draft', $comment_post_ID );
	// exit;
	// 將 exit 改為錯誤提示
	err(__('Invalid comment status.'));
} elseif ( post_password_required( $comment_post_ID ) ) {
	/**
	 * Fires when a comment is attempted on a password-protected post.
	 *
	 * @since 2.9.0
	 *
	 * @param int $comment_post_ID Post ID.
	 */
	do_action( 'comment_on_password_protected', $comment_post_ID );
	// exit;
	// 將 exit 改為錯誤提示
	err(__('Invalid comment status.'));
} else {
	/**
	 * Fires before a comment is posted.
	 *
	 * @since 2.8.0
	 *
	 * @param int $comment_post_ID Post ID.
	 */
	do_action( 'pre_comment_on_post', $comment_post_ID );
}

$comment_author       = ( isset($_POST['author']) )  ? trim(strip_tags($_POST['author'])) : null;
$comment_author_email = ( isset($_POST['email']) )   ? trim($_POST['email']) : null;
$comment_author_url   = ( isset($_POST['url']) )     ? trim($_POST['url']) : null;
$comment_content      = ( isset($_POST['comment']) ) ? trim($_POST['comment']) : null;

// 提取 edit_id
$edit_id              = ( isset($_POST['edit_id']) ) ? $_POST['edit_id'] : null; 

// If the user is logged in
$user = wp_get_current_user();
if ( $user->exists() ) {
	if ( empty( $user->display_name ) )
		$user->display_name=$user->user_login;
	$comment_author       = wp_slash( $user->display_name );
	$comment_author_email = wp_slash( $user->user_email );
	$comment_author_url   = wp_slash( $user->user_url );
	if ( current_user_can( 'unfiltered_html' ) ) {
		if ( ! isset( $_POST['_wp_unfiltered_html_comment'] )
			|| ! wp_verify_nonce( $_POST['_wp_unfiltered_html_comment'], 'unfiltered-html-comment_' . $comment_post_ID )
		) {
			kses_remove_filters(); // start with a clean slate
			kses_init_filters(); // set up the filters
		}
	}
} else {
	if ( get_option( 'comment_registration' ) || 'private' == $status ) {
		// wp_die( __( 'Sorry, you must be logged in to post a comment.' ), 403 );
		// 將 wp_die 改為錯誤提示
		err( __( 'Sorry, you must be logged in to post a comment.' ) );
	}
}

$comment_type = '';

if ( get_option('require_name_email') && !$user->exists() ) {
	if ( 6 > strlen( $comment_author_email ) || '' == $comment_author ) {
		// wp_die( __( '<strong>ERROR</strong>: please fill the required fields (name, email).' ), 200 );
		// 將 wp_die 改為錯誤提示
		err( __( '<strong>ERROR</strong>: please fill the required fields (name, email).' ) );
	} elseif ( ! is_email( $comment_author_email ) ) {
		//wp_die( __( '<strong>ERROR</strong>: please enter a valid email address.' ), 200 );
		// 將 wp_die 改為錯誤提示
		err( __( '<strong>ERROR</strong>: please enter a valid email address.' ) );
	}
}

if ( '' == $comment_content ) {
	// wp_die( __( '<strong>ERROR</strong>: please type a comment.' ), 200 );
	// 將 wp_die 改為錯誤提示
	err( __( '<strong>ERROR</strong>: please type a comment.' ) );
}

// 增加: 檢查重覆評論功能
$dupe = "SELECT comment_ID FROM $wpdb->comments WHERE comment_post_ID = '$comment_post_ID' AND ( comment_author = '$comment_author' ";
if ( $comment_author_email ) $dupe .= "OR comment_author_email = '$comment_author_email' ";
$dupe .= ") AND comment_content = '$comment_content' LIMIT 1";
if ( $wpdb->get_var($dupe) ) {
    err(__('Duplicate comment detected; it looks as though you&#8217;ve already said that!'));
}

// 增加: 檢查評論太快功能
if ( $lasttime = $wpdb->get_var( $wpdb->prepare("SELECT comment_date_gmt FROM $wpdb->comments WHERE comment_author = %s ORDER BY comment_date DESC LIMIT 1", $comment_author) ) ) { 
$time_lastcomment = mysql2date('U', $lasttime, false);
$time_newcomment  = mysql2date('U', current_time('mysql', 1), false);
$flood_die = apply_filters('comment_flood_filter', false, $time_lastcomment, $time_newcomment);
if ( $flood_die ) {
    err(__('You are posting comments too quickly. Please wait a moment.'));
	}
}

$comment_parent = isset($_POST['comment_parent']) ? absint($_POST['comment_parent']) : 0;

$commentdata = compact('comment_post_ID', 'comment_author', 'comment_author_email', 'comment_author_url', 'comment_content', 'comment_type', 'comment_parent', 'user_ID');

// $comment_id = wp_new_comment( $commentdata );

// 增加: 檢查評論是否正被編輯, 更新或新建評論
if ( $edit_id ) {
$comment_id = $commentdata['comment_ID'] = $edit_id;
	wp_update_comment( $commentdata );
} else {
	$comment_id = wp_new_comment( $commentdata );
}

if ( ! $comment_id ) {
	// wp_die( __( "<strong>ERROR</strong>: The comment could not be saved. Please try again later." ) );
	// 將 wp_die 改為錯誤提示
	err( __( "<strong>ERROR</strong>: The comment could not be saved. Please try again later." ) );
}

$comment = get_comment( $comment_id );

/**
 * Perform other actions when comment cookies are set.
 *
 * @since 3.4.0
 *
 * @param object $comment Comment object.
 * @param WP_User $user   User object. The user may not exist.
 */
do_action( 'set_comment_cookies', $comment, $user );

// $location = empty($_POST['redirect_to']) ? get_comment_link($comment_id) : $_POST['redirect_to'] . '#comment-' . $comment_id;

/**
 * Filter the location URI to send the commenter after posting.
 *
 * @since 2.0.5
 *
 * @param string $location The 'redirect_to' URI sent via $_POST.
 * @param object $comment  Comment object.
 */
// $location = apply_filters( 'comment_post_redirect', $location, $comment );

// wp_safe_redirect( $location );
// 取消原有的刷新重定向
// exit;

// 增加: 錯誤提示函数
function err($ErrMsg) {
    header('HTTP/1.1 405 Method Not Allowed');
    echo $ErrMsg;
    exit;
}

// 返回评论输出内容
$comment_depth = 1;  
$tmp_c = $comment;
while($tmp_c->comment_parent != 0){
$comment_depth++;
$tmp_c = get_comment($tmp_c->comment_parent);
}

?>

<li id="commentli-<?php comment_ID(); ?>" <?php comment_class(); ?>>
	<div id="comment-<?php comment_id(); ?>" class="comment-container">
		<div class="comment-avatar left"><?php echo get_avatar($comment, (!$comment->comment_parent ? 56 : 42)); ?></div>
		<div class="comment-body clf">
			<div class="comment-meta">
				<span class="comment-author"><?php comment_author_link(); ?></span>
				<span class="comment-time">
					<?php if ($comment->comment_approved == '0') { ?>
						<em class="comment-awaiting-moderation">初次评论需要等待审核</em>
					<?php } else { ?>
						<time>
						<?php if (current_time('timestamp') - get_comment_time('U') < 2592000) {
							echo human_time_diff(get_comment_time('U'), current_time('timestamp')) . '前';
						} else {
							echo comment_time('Y-n-j H:i');
						} ?>
						</time>
					<?php } ?>
				</span>
			</div>
			<div class="comment-content"><?php comment_text(); ?></div>
		</div>
	</div>
</li>
