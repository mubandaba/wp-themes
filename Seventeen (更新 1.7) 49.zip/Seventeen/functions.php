<?php
include_once('functions/settings.php');
include_once('functions/update.php');
include_once('functions/slider.php');

function seventeen_setup() {
	add_filter('pre_option_link_manager_enabled', '__return_true'); //启用链接功能
	remove_filter('the_content', 'wptexturize'); //禁止自动转换全半角符号
	add_filter('login_errors', '__return_null'); //隐藏登陆错误信息
	add_filter( 'use_default_gallery_style', '__return_false' ); //禁用自带相册样式

	// 注册菜单
	register_nav_menus(array(
		'sbmenu' => __('Sidebar') . __('Navigation'),
		'topmenu' => __('Header') . __('Navigation')
	));

	if (function_exists('add_theme_support')) {
		// 添加文章格式支持
		add_theme_support('post-formats', array('status', 'audio', 'video', 'image', 'gallery', 'quote', 'aside', 'link', 'chat'));
		// 添加缩略图支持
		add_theme_support('post-thumbnails');
		set_post_thumbnail_size( 700, 210, true );
	}
}
add_action('after_setup_theme', 'seventeen_setup');

// 注册 SB
if (function_exists('register_sidebar')) {
	register_sidebar(array(
		'id'=> 'footsb',
		'name' => '页脚小工具（放四个）',
		'before_widget' => '<div id="%1$s" class="widget-item %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>'
	));
	register_sidebar(array(
		'id'=> 'sb',
		'name' => '侧边栏',
		'before_widget' => '<div id="%1$s" class="clf widget-item %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>'
	));
	if (O('pin-widget')) {
		register_sidebar(array(
			'id'=> 'sbpin',
			'name' => '侧边栏固定小工具',
			'before_widget' => '<div id="%1$s" class="clf widget-item %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h3 class="widget-title">',
			'after_title' => '</h3>'
		));
	}
}

$icskin = '';
switch (O('color-theme')) {
	case 'lightgreen': $icskin = 'green'; break;
	case 'greengrey': $icskin = 'aero'; break;
	case 'darkblue': case 'lightblue': $icskin = 'blue'; break;
	default: $icskin = O('color-theme'); break;
}

// 加载静态文件
function st_load_libs() {
	$jq = '';
	switch (O('jquery-cdn')) {
		case 'moe': $jq = '//cdn.moefont.com/ajax/ajax/libs/jquery/1.9.1/jquery.min.js'; break;
		case 'google': $jq = '//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js'; break;
		case 'microsoft': $jq = '//ajax.aspnetcdn.com/ajax/jQuery/jquery-1.9.1.min.js'; break;
		case 'sae': $jq = '//lib.sinaapp.com/js/jquery/1.9.1/jquery-1.9.1.min.js'; break;
		case 'upyun': $jq = '//upcdn.b0.upaiyun.com/libs/jquery/jquery-1.9.1.min.js'; break;
		case 'none': default: $jq = get_template_directory_uri() . '/js/jquery-1.9.1.min.js'; break;
	}
	$fa = '';
	switch (O('fa-cdn')) {
		case 'bae': $fa = '//libs.baidu.com/fontawesome/4.2.0/css/font-awesome.min.css'; break;
		case 'bootcss': $fa = '//cdn.bootcss.com/font-awesome/4.4.0/css/font-awesome.min.css'; break;
		case 'bdimg': $fa = 'http://apps.bdimg.com/libs/fontawesome/4.4.0/css/font-awesome.min.css'; break;
		case 'none': default: $fa = get_template_directory_uri() . '/fonts/font-awesome.min.css'; break;
	}
	$noto = '';
	switch (O('font-cdn')) {
		case 'moe': $noto = '//cdn.moefont.com/fonts/css?family=Noto+Sans:400,400italic'; break;
		case 'google': $noto = '//fonts.googleapis.com/css?family=Noto+Sans:400,400italic'; break;
		case '360': $noto = '//fonts.useso.com/css?family=Noto+Sans:400,400italic'; break;
		case 'none': default: $noto = get_template_directory_uri() . '/fonts/notosans.css'; break;
	}
	$color = get_template_directory_uri() . '/functions/color-themes/' . O('color-theme') . '.css';
	if (empty($GLOBALS['o']['color-theme'])) {
		$color = get_template_directory_uri() . '/functions/color-themes/lightblue.css';
	}
	global $icskin, $ver;
	$v = "" . $ver;
	
	wp_deregister_script('jquery');
	wp_register_script('jquery', $jq, array(), '1.9.1', false); // 某些插件未遵循WP规范，导致其js比jQuery先加载而失效，故改为false

	wp_enqueue_style('st-main-style', get_stylesheet_uri(), array(), $v);
	wp_enqueue_style('st-color-theme', $color, array('st-main-style'), $v);
	wp_enqueue_style('font-awesome', $fa);
	wp_enqueue_style('noto-sans-font', $noto);
	wp_enqueue_style('icheck-style', get_template_directory_uri() . '/js/icheck-skin-square/' . $icskin . '.css');

	wp_enqueue_script('jquery');
	wp_enqueue_script('jquery-libs', get_template_directory_uri() . '/js/jquery.libs.js', array('jquery'), $v, false);
	wp_enqueue_script('jquery-icheck', get_template_directory_uri() . '/js/icheck.min.js', array('jquery'), '1.0', true);
	if (O('comments-ajax-post')) {
		wp_enqueue_script('ajax-comment', get_template_directory_uri() . '/comments-ajax.js', array('jquery'), '1.3', true);
	}
	wp_enqueue_script('st-script', get_template_directory_uri() . '/js/script.js', array('jquery', 'jquery-libs', 'jquery-icheck'), $v, true);
}
add_action('wp_enqueue_scripts', 'st_load_libs');

// 在头部输出的代码
function st_head_custom_code() {
	// 图标设置
	if (O('favicon') != '') echo '<link rel="shortcut icon" href="' . O('favicon') . '" type="image/x-icon">';
	if (O('webapp-icon') != '') {
		echo '<link rel="icon" sizes="192x192" href="' . O('webapp-icon') . '">';
		echo '<link rel="apple-touch-icon" sizes="192x192" href="' . O('webapp-icon') . '">';
	}
	// CSS相关设置项开始
	echo '<style type="text/css">';
	// 禁用侧边栏
	if (O('no-sidebar')) { ?>
			#sidebar { float: none; width: 100%; margin-bottom: 21px; }
			#abovesb { margin: 0; }
			#sb { display: none; }
			.wp { width: 100%; }
			@media screen and (max-width: 1028px) {
				#sidebar { float: none; width: 100%; margin-bottom: 21px; }
				#abovesb { margin: 0; }
				#sb { display: none; }
				.wp { width: 100%; }
			}
			@media screen and (max-width: 920px) {
				#sidebar { float: none; width: 100%; margin-bottom: 21px; }
				#abovesb { margin: 0; }
				#sb { display: none; }
				.wp { width: 100%; }
			}
	<?php }
	// 侧边栏放右侧
	if (O('sidebar-pos') == 'right') { ?>
			#abovesb, #sb { margin-left: 40px; margin-right: 0; }
			@media screen and (max-width: 799px) {
				#abovesb { display: none; }
				#cardtop { display: block; }
			}
	<?php }
	// 自定义背景
	if (O('bg-style') == 'image') { ?>
			body { background-image: url(<?php echo O('bg-url'); ?>); }
	<?php } elseif (O('bg-style') == 'color') { ?>
			body { background-color: <?php echo O('bg-color'); ?>; }
	<?php }
	// 透明度
	?>
			#top, #foot { opacity: <?php echo(O('header-footer-opacity') / 100); ?>; filter: Alpha(opacity=<?php echo(O('header-footer-opacity')); ?>) }
			#container { opacity: <?php echo(O('sidebar-content-opacity')) / 100; ?>; filter: Alpha(opacity=<?php echo(O('sidebar-content-opacity')); ?>) }
	<?php
	// 背景图展示类型
	if (O('bg-img-style') == 'fixed') { ?>
			body { background-attachment: fixed; }
	<?php } elseif (O('bg-img-style') == 'cover') { ?>
			body { background-image: none; }
	<?php }
	// 文字加框
	if (O('text-box')) { ?>
			.status-content { }
	<?php }
	// 自定义CSS
	if (!empty($GLOBALS['o']['custom-css'])) echo stripcslashes(O('custom-css'));
	// CSS相关设置项结束
	echo '</style>';
	// 自定义头部代码
	if (!empty($GLOBALS['o']['custom-headcode'])) echo stripcslashes(O('custom-headcode'));
	// 新窗口打开评论者网站
	if (O('comment-url-target')) { ?>
		<script type="text/javascript">jQuery("#comments a.url").attr("target", "_blank");</script><?php
	}
	// iCheck
	global $icskin;
	?><script type="text/javascript">
	var iCheckInit = function($){
		$("input").iCheck({
			checkboxClass: "icheck icheckbox_square-<?php echo $icskin; ?>",
			radioClass: "icheck iradio_square-<?php echo $icskin; ?>",
			increaseArea: '20%' // optional
		});
	}
	</script><?php
	// Chrome theme on Lollipop
	?><meta name="theme-color" content="<?php
		switch (O('color-theme')) {
			case 'lightgreen': echo 'bg:"#11A664",'; break;
			case 'darkblue': echo 'bg:"#002E42",'; break;
			case 'greengrey': echo 'bg:"#20333C",'; break;
			case 'red': echo 'bg:"#E74C3C",'; break;
			case 'orange': echo 'bg:"#FF8800",'; break;
			case 'pink': echo 'bg:"#A77A94",'; break;
			case 'purple': echo 'bg:"#6A5A8C",'; break;
			default: case 'lightblue': echo 'bg:"#3C8DBC",'; break;
		}
	?>"><?php
	// 禁止搜索引擎索引评论分页
	if(is_single() || is_page()) {
		if(function_exists('get_query_var')) {
			$cpage = intval(get_query_var('cpage'));
			$commentPage = intval(get_query_var('comment-page'));
		}
		if(!empty($cpage) || !empty($commentPage)) {
			echo '<meta name="robots" content="noindex, nofollow">';
			echo "\n";
		}
	}
	// 加载动画模糊背景
	if (O('load-animation')) {
		?><style type="text/css" id="bulr">
			#pageframe { z-index: 100; -webkit-filter: blur(2px); -moz-filter: blur(2px); -o-filter: blur(2px); -ms-filter: blur(2px); filter: blur(2px); position: relative; }
		</style><?php
	}
	// Ajax 判断需要，输出 WordPress 后台地址正则
	?><script type="text/javascript">var wpau = new RegExp("<?php echo admin_url(); ?>", "i");</script><?php
	// pjax 
	?><script type="text/javascript">var trigglerList = "<?php echo O('pjax-triggler'); ?>"</script><?php
}

// Ajax 启动控制
function st_ajax_class($classes) {
	if (O('pjax')) $classes[] = 'pjax';
	if (O('comments-ajax-page')) $classes[] = 'comments-ajax-page';
	if (O('comments-ajax-post')) $classes[] = 'comments-ajax-post';
	return $classes;
}
add_filter('body_class', 'st_ajax_class');

// 解决国内 Gravatar 被墙
function st_unblock_gravatar($avatar) {
	if (O('unblock-gravatar') == 'moe') {
		$avatar = str_replace(array('www.gravatar.com', '0.gravatar.com', '1.gravatar.com', '2.gravatar.com'), 'gravatar.moefont.com', $avatar);
		$avatar = str_replace('secure.gravatar.com', 'gravatar-ssl.moefont.com', $avatar);
	} elseif (O('unblock-gravatar') == 'duoshuo') {
		$avatar = str_replace(array('www.gravatar.com', '0.gravatar.com', '1.gravatar.com', '2.gravatar.com'), 'gravatar.duoshuo.com', $avatar);
	} elseif (O('unblock-gravatar') == 'grcn') {
		$avatar = str_replace(array('www.gravatar.com', '0.gravatar.com', '1.gravatar.com', '2.gravatar.com'), 'cn.gravatar.com', $avatar);
	}
	return $avatar;
}
add_filter('get_avatar', 'st_unblock_gravatar');

// 强制静态文件支持HTTPS
function force_static_support_https($text) {
	return str_replace('http://', '//', $text);
}
if (O('force-static-https') && ($_SERVER['HTTPS'] === 1 || $_SERVER['HTTPS'] === 'on' || $_SERVER['SERVER_PORT'] == 443)) {
	add_filter('style_loader_tag', 'force_static_support_https');
	add_filter('script_loader_src', 'force_static_support_https');
}

// 获取文章第一张图片
function get_first_image($before = '', $after = '') {
	global $post;
	ob_start();
	ob_end_clean();
	$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
	return $before . $matches[1][0] . $after;
}

// 获取文章第一个链接
function get_first_link() {
	$content = get_the_content();
	$has_url = get_url_in_content($content);
	return ($has_url) ? $has_url : apply_filters('the_permalink', get_permalink());
}

// Post-Meta
function st_post_meta() {
	$icons = array(
		'audio' => 'music',
		'video' => 'film',
		'image' => 'image',
		'gallery' => 'camera-retro',
		'quote' => 'quote-left',
		'aside' => 'file-text-o',
		'link' => 'link',
		'chat' => 'comments-o',
		'none' => 'file-o'
	);
	$icon = 'file-o';
	if (get_post_format()) {
		$icon = $icons[get_post_format()];
	}
	$i = 0;
	$j = 0;
	?><div class="post-meta clf">
		<?php if (O('postmeta-author')) { ?><span class="<?php echo(($i++ < 2 ? 'pmt ' : '') . ($j++ < 3 ? 'pms ' : '')); ?>fa-user"><?php echo get_the_author_link(); ?></span><?php } ?>
		<?php if (O('postmeta-format')) { ?><span class="<?php echo(($i++ < 2 ? 'pmt ' : '') . ($j++ < 3 ? 'pms ' : '')); ?>fa-<?php echo $icon; ?>"><a class="entry-format" href="<?php echo esc_url(get_post_format_link(get_post_format())); ?>"><?php echo get_post_format_string(get_post_format()); ?></a></span><?php } ?>
		<?php if (O('postmeta-cat')) { ?><span class="<?php echo(($i++ < 2 ? 'pmt ' : '') . ($j++ < 3 ? 'pms ' : '')); ?>fa-book"><?php the_category(', '); ?></span><?php } ?>
		<?php if (O('postmeta-date')) { ?><span class="<?php echo(($i++ < 2 ? 'pmt ' : '') . ($j++ < 3 ? 'pms ' : '')); ?>fa-clock-o"><?php the_time('Y-m-j'); ?></span><?php } ?>
		<?php if (O('postmeta-comment')) { ?><span class="<?php echo(($i++ < 2 ? 'pmt ' : '') . ($j++ < 3 ? 'pms ' : '')); ?>fa-comment"><?php comments_popup_link('没有评论', '1个评论', '%个评论'); ?></span><?php } ?>
		<?php if (O('postmeta-views') && function_exists('the_views')) the_views(true, '<span class="' . (($i++ < 2 ? 'pmt ' : '') . ($j++ < 3 ? 'pms ' : '')) . 'fa-eye">','</span>'); ?>
		<?php if (O('postmeta-edit')) edit_post_link(__('Edit'), '<span class="' . (($i++ < 2 ? 'pmt ' : '') . ($j++ < 3 ? 'pms ' : '')) . 'fa-edit">', '</span>'); ?>
	</div><?php
}

// Mini Pagenavi v1.0 by Willin Kan.
function pagenavi($p = 2) {
	if (is_singular()) return;
	global $wp_query, $paged;
	$max_page = $wp_query->max_num_pages;
	if (empty($paged)) $paged = 1;
	echo '<span class="p-count">Page ' . $paged . ' of ' . $max_page . ' </span> ';
	if ($paged > $p + 1) p_link(1, '第 1 页');
	if ($paged > $p + 2) echo '... ';
	for($i = $paged - $p; $i <= $paged + $p; $i++) {
		if ($i > 0 && $i <= $max_page) $i == $paged ? print "<span class='p-num current'>{$i}</span> " : p_link( $i );
	}
	if ($paged < $max_page - $p - 1) echo '... ';
	if ($paged < $max_page - $p) p_link($max_page, '最末页');
}
function p_link($i, $title = '') {
	if ($title == '') $title = "第 {$i} 页";
	echo "<a class='p-num' href='", esc_html(get_pagenum_link($i)), "' title='{$title}'>{$i}</a> ";
}
// Wordpress Stock Navigation
function st_stock_paging_nav() { ?>
	<div class="navigation paging-navigation" role="navigation">
		<h1 class="screen-reader-text"><?php _e('Posts navigation'); ?></h1>
		<div class="nav-links">
			<?php if (get_next_posts_link()) { ?>
			<div class="nav-previous"><?php next_posts_link(__('<span class="meta-nav">&larr;</span> Older posts')); ?></div>
			<?php } ?>
			<?php if (get_previous_posts_link()) { ?>
			<div class="nav-next"><?php previous_posts_link(__('Newer posts <span class="meta-nav">&rarr;</span>')); ?></div>
			<?php } ?>
		</div><!-- .nav-links -->
	</div><!-- .navigation -->
	<?php
}
function st_wp_new_paging_nav() {
	if (function_exists('get_the_posts_pagination')) {
		echo get_the_posts_pagination(array(
			'mid_size'           => 1,
			'prev_text'          => __('Previous page'),
			'next_text'          => __('Next page'),
			'before_page_number' => '<span class="meta-nav screen-reader-text">第</span>',
			'after_page_number' => '<span class="meta-nav screen-reader-text">页</span>',
			'screen_reader_text' => ' '
		));
	} else {
		pagenavi(7);
	}
}
function st_page_nav() {
	global $wp_query;
	// Don't print empty markup if there's only one page.
	if ($wp_query->max_num_pages < 2) return;
	switch (O('nav-type')) {
		case 'old': st_stock_paging_nav(); break;
		case 'new': st_wp_new_paging_nav(); break;
		case 'kan': default: pagenavi(7); break;
	}
}

// 面包屑导航
function dimox_breadcrumbs() {
	$delimiter = '&raquo;';
	$beforetext = '您的位置: ';
	//$beforetext = '';
	$name = __('Home'); //text for the 'Home' link
	$currentBefore = '<span>';
	$currentAfter = '</span>';
	if (!is_home() && !is_front_page() || is_paged()) {
		echo '<div id="breadcrumbs">';
		global $post;
		$home = get_bloginfo('url');
		echo $beforetext . '<a href="' . $home . '">' . $name . '</a> ' . $delimiter . ' ';
		if (is_category()) {
			global $wp_query;
			$cat_obj = $wp_query->get_queried_object();
			$thisCat = $cat_obj->term_id;
			$thisCat = get_category($thisCat);
			$parentCat = get_category($thisCat->parent);
			if ($thisCat->parent != 0) echo(get_category_parents($parentCat, TRUE, ' ' . $delimiter . ' '));
			echo $currentBefore . 'Archive by category &#39;';
			single_cat_title();
			echo '&#39;' . $currentAfter;
		} elseif (is_day()) {
			echo '' . get_the_time('Y') . ' ' . $delimiter . ' ';
			echo '' . get_the_time('F') . ' ' . $delimiter . ' ';
			echo $currentBefore . get_the_time('d') . $currentAfter;
		} elseif (is_month()) {
			echo '' . get_the_time('Y') . ' ' . $delimiter . ' ';
			echo $currentBefore . get_the_time('F') . $currentAfter;
		} elseif (is_year()) {
			echo $currentBefore . get_the_time('Y') . $currentAfter;
		} elseif (is_single()) {
			if (!is_attachment()) {
				$cat = get_the_category();
				$cat = $cat[0];
				echo get_category_parents($cat, TRUE, ' ' . $delimiter . ' ');
			} else {
				echo __('Attachment Page') . ' ' . $delimiter . ' ';
			}
			echo $currentBefore;
			the_title();
			echo $currentAfter;
		} elseif (is_page() && !$post->post_parent) {
			echo $currentBefore;
			the_title();
			echo $currentAfter;
		} elseif (is_page() && $post->post_parent) {
			$parent_id  = $post->post_parent;
			$breadcrumbs = array();
			while ($parent_id) {
				$page = get_page($parent_id);
				$breadcrumbs[] = '' . get_the_title($page->ID) . '';
				$parent_id  = $page->post_parent;
			}
			$breadcrumbs = array_reverse($breadcrumbs);
			foreach ($breadcrumbs as $crumb) echo $crumb . ' ' . $delimiter . ' ';
			echo $currentBefore;
			the_title();
			echo $currentAfter;
		} elseif (is_search()) {
			echo $currentBefore . 'Search results for &#39;' . get_search_query() . '&#39;' . $currentAfter;
		} elseif (is_tag()) {
			echo $currentBefore . 'Posts tagged &#39;';
			single_tag_title();
			echo '&#39;' . $currentAfter;
		} elseif (is_author()) {
			global $author;
			$userdata = get_userdata($author);
			echo $currentBefore . 'Articles posted by ' . $userdata->display_name . $currentAfter;
		} elseif (is_404()) {
			echo $currentBefore . 'Error 404' . $currentAfter;
		}
		if ( get_query_var('paged') ) {
			if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ' (';
			echo __('Page') . ' ' . get_query_var('paged');
			if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ')';
		}
		echo '</div>';
	}
}

// 在评论中解析<code>标签
function st_encode_code_in_comment($source) {
	$encoded = preg_replace_callback('/<code>(.*?)<\/code>/ims', create_function('$matches', '$matches[1] = preg_replace(array("/^[\r|\n]+/i", "/[\r|\n]+$/i"), "", $matches[1]); return "<code>" . htmlentities($matches[1]) . "</"."code>";'), $source);
	if ($encoded) return $encoded;
	else return $source;
}
add_filter('pre_comment_content', 'st_encode_code_in_comment');

// 评论回复邮件
function comment_mail_notify($comment_id) {
	$admin_notify = '1'; // admin 要不要收回复通知 ( '1'=要 ; '0'=不要 )
	$admin_email = get_bloginfo('admin_email'); // $admin_email 可改为你指定的 e-mail.
	$comment = get_comment($comment_id);
	$comment_author_email = trim($comment->comment_author_email);
	$parent_id = $comment->comment_parent ? $comment->comment_parent : '';
	global $wpdb;
	if ($wpdb->query("Describe {$wpdb->comments} comment_mail_notify") == '')
		$wpdb->query("ALTER TABLE {$wpdb->comments} ADD COLUMN comment_mail_notify TINYINT NOT NULL DEFAULT 0;");
	if (($comment_author_email != $admin_email && isset($_POST['comment_mail_notify'])) || ($comment_author_email == $admin_email && $admin_notify == '1'))
		$wpdb->query("UPDATE {$wpdb->comments} SET comment_mail_notify='1' WHERE comment_ID='$comment_id'");
	$notify = $parent_id ? get_comment($parent_id)->comment_mail_notify : '0';
	$spam_confirmed = $comment->comment_approved;
	if ($parent_id != '' && $spam_confirmed != 'spam' && $notify == '1') {
		$wp_email = 'no-reply@' . preg_replace('#^www.#', '', strtolower($_SERVER['SERVER_NAME'])); // e-mail 发出点, no-reply 可改为可用的 e-mail.
		$to = trim(get_comment($parent_id)->comment_author_email);
		$subject = '您在 [' . get_option("blogname") . '] 的留言有了回复';
		$message = '<table style="width: 99.8%;height:99.8% "><tbody><tr><td style="background:#FAFAFA url(http://labimg-labimg.stor.sinaapp.com/original/a873524e5ac9465dc4d6fd6d133bc58d.png)"><div style="background-color:white;border-top:2px solid #12ADDB;box-shadow:0 1px 3px #AAAAAA;line-height:180%;padding:0 15px 12px;width:500px;margin:50px auto;color:#555555;font-family:Century Gothic,Trebuchet MS,Hiragino Sans GB,微软雅黑,Microsoft Yahei,Tahoma,Helvetica,Arial,SimSun,sans-serif;font-size:12px;"><h2 style="border-bottom:1px solid #DDD;font-size:14px;font-weight:normal;padding:13px 0 10px 8px;"><span style="color: #12ADDB;font-weight: bold;">&gt; </span>您在<a style="text-decoration:none;color: #12ADDB;" href="' . get_option('home') . '"> ' . get_option('blogname') . ' </a>博客上的留言有回复啦！</h2><div style="padding:0 12px 0 12px;margin-top:18px"><p>' . trim(get_comment($parent_id)->comment_author) . ' 同学，您曾在文章《' . get_the_title($comment->comment_post_ID) . '》上发表评论:</p><p style="background-color: #f5f5f5;border: 0px solid #DDD;padding: 10px 15px;margin:18px 0">' . nl2br(get_comment($parent_id)->comment_content) . '</p><p>' . trim($comment->comment_author) . '  给您的回复如下:</p><p style="background-color: #f5f5f5;border: 0px solid #DDD;padding: 10px 15px;margin:18px 0">' . nl2br($comment->comment_content) . '</p><p>您可以点击 <a style="text-decoration:none; color:#12addb" href="' . htmlspecialchars(get_comment_link($parent_id)) . '">查看回复的完整內容 </a>，欢迎再次光临 <a style="text-decoration:none; color:#12addb" href="' . get_option('home') . '">' . get_option('blogname') . ' </a>。</p></div></div></td></tr></tbody></table>';
		$from = "From: \"" . get_option('blogname') . "\" <$wp_email>";
		$headers = "$from\nContent-Type: text/html; charset=" . get_option('blog_charset') . "\n";
		wp_mail($to, $subject, $message, $headers);
	}
}
if (O('comment-mail-notify')) add_action('comment_post', 'comment_mail_notify');
// 添加评论提醒勾选框
function add_checkbox() { ?>
	<p class="mail-checkbox">
		<input type="checkbox" name="comment_mail_notify" id="comment_mail_notify" value="comment_mail_notify" checked="checked" />
		<label for="comment_mail_notify">有人回复时邮件通知我</label>
	</p>
<?php }
add_action('comment_form', 'add_checkbox');

// 修改默认评论表单
function st_fields($fields) {
	$commenter = wp_get_current_commenter();
	$req = get_option('require_name_email');
	$aria_req = ($req ? " aria-required='true'" : '');
	$fields = array(
		'author' => '<div class="comment-form-author comment-info"><span class="form-tip"><label for="author">' . ($req ? '<span class="required">*</span>' : '') . '昵称' . ': </label> ' . '</span>' .
		'<input id="author" name="author" type="text" value="' . esc_attr($commenter['comment_author']) . '" size="30"' . $aria_req . ' /></div>',
		'email' => '<div class="comment-form-email comment-info"><span class="form-tip"><label for="email">' . ($req ? '<span class="required">*</span>' : '') . '邮箱' . ': </label> ' . '</span>' .
		'<input id="email" name="email" type="text" value="' . esc_attr($commenter['comment_author_email']) . '" size="30"' . $aria_req . ' /></div>',
		'url' => '<div class="comment-form-url comment-info"><span class="form-tip"><label for="url">' . '站点' . ': </label>' . '</span>' .
		'<input id="url" name="url" type="text" value="' . esc_attr($commenter['comment_author_url']) . '" size="30" /></div>',
	);
	return $fields;
}
add_filter('comment_form_default_fields', 'st_fields');

// 评论列表callback
function st_list_comments($comment, $args, $depth) {
	$GLOBALS['comment'] = $comment;

	if ($comment->comment_type == 'pingback' || $comment->comment_type == 'trackback') { ?>
		<p class="pingback"><?php comment_author_link(); ?></p>
	<?php } else { ?>
		<li id="commentli-<?php comment_ID(); ?>" <?php comment_class(); ?>>
			<div id="comment-<?php comment_id(); ?>" class="comment-container">
				<div class="comment-avatar left"><?php echo get_avatar($comment, (!$comment->comment_parent ? 56 : 42)); ?></div>
				<div class="comment-body">
					<div class="comment-meta">
						<span class="comment-author"><?php comment_author_link(); ?></span>
						<span class="comment-time">
							<?php if ($comment->comment_approved == '0') { ?>
								<em class="comment-awaiting-moderation">初次评论需要等待审核</em>
							<?php } else { ?>
								<time>
								<?php if (current_time('timestamp') - get_comment_time('U') < 2592000) {
									echo human_time_diff(get_comment_time('U'), current_time('timestamp')) . '前';
								} else {
									echo comment_time('Y-n-j H:i');
								} ?>
								</time>
							<?php } ?>
						</span>
						<span class="comment-edit fade"><?php edit_comment_link(__('Edit')); ?></span></span>
						<span class="right fade"><?php comment_reply_link(array_merge($args, array('reply_text' => __('Reply'), 'depth' => $depth, 'max_depth' => $args['max_depth']))) ?></span>
					</div>
					<div class="comment-content"><?php comment_text(); ?></div>
				</div>
				<div class="clear"></div>
			</div>
		</li>
	<?php }
}
