<div id="post-<?php the_ID();?>" <?php post_class(); ?>>
	<div class="media-content"><?php echo get_first_image('<p><img src="', '" alt="" class="alignnone size-full"></p>'); ?></div>
	<h1 class="post-title">
		<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title();?></a>
	</h1>
	<?php st_post_meta(); ?>
</div><!-- #post-ID -->