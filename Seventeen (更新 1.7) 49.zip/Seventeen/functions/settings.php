<?php
// 设置项定义
include_once('options-define.php');

// 全局设置项获取函数
$o = stOptions::getOptions();
function O($id) {
	return $GLOBALS['o'][$id];
}

class stOptions {
	public static function getOptions() {
		global $items;
		$options = get_option('st_options');
		if (!is_array($options)) {
			self::resetOptions();
		} else {
			foreach ($items as $value) {
				if (!preg_match('/(before|after|subtitle|desc)/', $value['type']) && !isset($options[$value['id']])) {
					$options[$value['id']] = $value['std'];
				}
			}
		}
		return $options;
	}
	protected static function resetOptions() {
		global $items;
		$options = array();
		foreach ($items as $value) {
			if (isset($value['std'])) $options[$value['id']] = $value['std'];
		}
		update_option('st_options', $options);
		add_settings_error('st_options', 'st_options-reseted', __('Settings reseted.'), 'updated');
	}
	protected static function saveOptions() {
		global $items;
		$options = get_option('st_options');
		if (!is_array($options)) {
			$options = array();
		}
		foreach ($items as $value) {
			if (preg_match('/(before|after|subtitle|desc)/', $value['type'])) {
				// boom shakalaka
			} elseif (isset($_POST[$value['id']])) {
				$options[$value['id']] = $_POST[$value['id']];
			} else {
				unset($options[$value['id']]);
			}
		}
		update_option('st_options', $options);
		add_settings_error('st_options', 'st_options-updated', __('Settings saved.'), 'updated');
	}
	public static function notice() {
		settings_errors('st_options');
	}
	public static function init() {
		if (isset($_POST['saveopts'])) {
			self::saveOptions();
		} elseif (isset($_POST['resetopts'])) {
			self::resetOptions();
		} else {
			self::getOptions();
		}
		add_theme_page(__('Theme Options'), __('Theme Options'), 'edit_themes', basename(__FILE__), array('stOptions', 'display'));
	}

	public static function display() {
		global $themename, $items;
		$options = self::getOptions();
?>

<style type="text/css">
	.clear { clear: both; }
	#optpage { font-family: 'Microsoft Yahei'; }
	#optwrap { width: 100%; background: #FFF; border-radius: 2px; box-shadow: 0 2px 6px 0 rgba(0, 0, 0, .21); margin: 14px 0; padding: 0 0 1px; }
	#optnav { list-style: none; display: block; height: 42px; text-align: center; font-size: 0; border-bottom: 1px solid #EEE; padding-bottom: 1px; }
	#optnav li { display: inline-block; margin: 0 2px; line-height: 42px; font-size: 14px; }
	#optnav li a { display: block; padding: 0 16px; font-weight: bold; color: #757575; text-decoration: none; box-shadow: none; }
	#optnav i { display: none; }
	#optnav .currnav { border-bottom: 2px solid #00BCD4; }
	#optnav .currnav a { color: #00BCD4; }
	#optcont { padding: 7px 0 14px; }
	.optmain { display: none; padding-top: 14px; }
	.optcurr { display: block; }

	.optitem { padding: 7px 14px; margin: 0 14px; }
	.subtitle { padding-top: 14px }
	.desc p { margin: 0; }
	.optitem h3 { color: #757575; font-size: 14px; margin: 0; }
	.item-title { float: left; width: 200px; margin-right: 10px; }
	.item-content { margin-left: 210px; overflow: hidden; *zoom: 1; }
	.item-content .control { float: left; width: 350px; margin-right: 10px; }
	.item-content .desc { display: block; padding: 2px 0 0 360px; color: #A0A0A0; }
	.smallcontrol .item-content .control { width: 65px; }
	.smallcontrol .item-content .desc { padding-left: 76px; }

	.color-radio input[type="radio"] { display: none; }
	.color-block { color: #FFF; width: 63px; line-height: 63px; text-align: center; display: inline-block; border: 4px solid #FFF; }
	.color-current { border-color: #0074A2;}

	.formsubmit { text-align: center; padding: 0 14px; margin: 14px 0 21px; }
	.formsubmit input { display: inline-block; padding: 14px 28px; margin: 0 7px; background: #FFF; border: none; cursor: pointer; border-radius: 3px; }
	.formsubmit input:hover { color: #FFF; }
	.formsubmit .reset:hover { background: #C24C4C; }
	.formsubmit .save { background: #EEE; }
	.formsubmit .save:hover { background: #3B9DD8; }
	
	@media screen and (max-width: 849px) {
		.item-title { width: 140px; }
		.item-content { margin-left: 150px; }
		.item-content .control { width: 100%; float: none; margin-right: 0; }
		.item-content .desc { padding: 0; }
		.smallcontrol .item-content .control { float: left; }
	}
	
	@media screen and (max-width: 599px) {
		.item-title { float: none; width: auto; }
		.item-content { margin-left: 0; padding: 7px 0; }
		#optnav li a { padding: 0 10px; }
		#optnav span { display: none; }
		#optnav i { display: inline-block; }
		#nav-opt-general i:before { content: "\f1de"; }
		#nav-opt-appearance i:before { content: "\f0d0"; }
		#nav-opt-header i:before { content: "\f176"; }
		#nav-opt-footer i:before { content: "\f175"; }
		#nav-opt-template i:before { content: "\f016"; }
		#nav-opt-slider i:before { content: "\f03e"; }
		#nav-opt-advanced i:before { content: "\f085"; }
	}
</style>

<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/fonts/font-awesome.min.css" type="text/css" />

<div class="wrap" id="optpage">
<?php echo '<h2>' . $themename . ' ' . __('Theme Options') . '</h2>'; ?>

<form method="post" name="st_form" id="st_form">
	<input type="hidden" value="" name="lasttab" id="lasttab">
	<div id="optwrap">
		<ul id="optnav">
			<?php $i = 0;
			foreach ($items as $value) {
				if ($value['type'] == 'before') {
					echo '<li' . ($i == 0 ? ' class="currnav"' : '') . ' id="nav-' . $value['id'] . '"><a href="#' . $value['id'] . '"><span>' . $value['title'] . '</span><i class="fa"></i></a></li>';
					$i++;
				}
			} ?>
		</ul>

		<div id="optcont">

<?php
$i = 0;
foreach ($items as $value) {
	switch ($value['type']) {
		case 'before':
			echo '<div class="optmain' . ($i == 0 ? ' optcurr' : '') . '" id="' . $value['id'] . '" >';
			$i++;
			break;
		case 'after':
			echo '</div>';
			break;
		case 'subtitle':
			echo '<div class="optitem subtitle"><h3>' . $value['title'] . '</h3></div>';
			break;
		case 'desc':
			echo '<div class="optitem desc"><p>' . $value['title'] . '</p></div>';
			break;

		case 'text':
	?>
<div class="optitem">
	<div class="item-title"><label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label></div>
	<div class="item-content">
		<label>
		<input name="<?php echo $value['id']; ?>" class="regular-text control" id="<?php echo $value['id']; ?>" type='text' value="<?php echo(isset($options[$value['id']]) ? stripslashes($options[$value['id']]) : $value['std']); ?>" />
		<span class="desc"><?php echo $value['desc']; ?></span>
		</label>
	</div>
</div>
	<?php
		break;
		case 'number':
	?>
<div class="optitem smallcontrol">
	<div class="item-title"><label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label></div>
	<div class="item-content">
		<label>
		<input name="<?php echo $value['id']; ?>" class="small-text control" id="<?php echo $value['id']; ?>" type="number" value="<?php echo(isset($options[$value['id']]) ? $options[$value['id']] : $value['std']); ?>" />
		<span class="desc"><?php echo $value['desc']; ?></span>
		</label>
	</div>
</div>
	<?php
		break;
		case 'textarea':
	?>
<div class="optitem">
	<div class="item-title"><label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label></div>
	<div class="item-content">
		<label for="<?php echo $value['id']; ?>">
			<textarea name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" rows="10" cols="50" class="large-text code control"><?php echo(isset($options[$value['id']]) ? stripslashes($options[$value['id']]) : $value['std']); ?></textarea>
				<span class="desc"><?php echo $value['desc']; ?></span>
		</label>
	</div>
</div>
	<?php
		break;
		case 'select':
	?>
<div class="optitem">
	<div class="item-title"><label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label></div>
	<div class="item-content">
		<label>
			<select name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" class="control">
				<?php foreach ($value['options'] as $name => $option) { ?>
				<option value="<?php echo $option; ?>" <?php selected((isset($options[$value['id']]) ? $options[$value['id']] : $value['std']), $option); ?>><?php echo $name; ?></option>
				<?php } ?>
			</select>
			<span class="desc"><?php echo $value['desc']; ?></span>
		</label>
	</div>
</div>
	<?php
		break;
		case 'radio':
	?>
<div class="optitem">
	<div class="item-title"><?php echo $value['name']; ?></div>
	<div class="item-content">
		<div class="control">
		<?php foreach ($value['options'] as $name => $option) { ?>
		<label>
			<input type="radio" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" value="<?php echo $option; ?>" <?php checked((isset($options[$value['id']]) ? $options[$value['id']] : $value['std']), $option); ?>>
			<?php echo $name; ?>
		</label>&nbsp;&nbsp;
		<?php } ?>
		</div>
		<span class="desc"><?php echo $value['desc']; ?></span>
	</div>
</div>
	<?php
		break;
		case 'color': // 由radio修改而来
	?>
<div class="optitem">
	<div class="item-title"><?php echo $value['name']; ?></div>
	<div class="item-content">
		<div class="control">
		<?php foreach ($value['options'] as $name => $option) { ?>
		<label class="color-radio">
			<input type="radio" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" value="<?php echo $option[0]; ?>" <?php checked((isset($options[$value['id']]) ? $options[$value['id']] : $value['std']), $option[0]); ?>>
			<span class="color-block <?php if ((isset($options[$value['id']]) ? $options[$value['id']] : $value['std']) == $option[0]) echo 'color-current'; ?>" style="background-color:<?php echo $option[1]; ?>"><?php echo $name; ?></span>
		</label>
		<?php } ?>
		</div>
		<span class="desc"><?php echo $value['desc']; ?></span>
	</div>
</div>
	<?php
		break;
		case 'checkbox':
	?>
<div class="optitem">
	<div class="item-title"><?php echo $value['name']; ?></div>
	<div class="item-content">
		<label>
			<input type="hidden" name="<?php echo $value['id']; ?>" value="0"></input><? // 未选中的checkbox不会POST数据，所以要加这个 ?>
			<input type='checkbox' name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" value="1" <?php echo checked((isset($options[$value['id']]) ? $options[$value['id']] : $value['std']), 1); ?> />
			<span><?php echo $value['desc']; ?></span>
		</label>
	</div>
</div>
	<?php
		break;
	}
} ?>
		</div><!-- .optcont -->
		<div class="clear"></div>
		<div class="formsubmit">
			<input name="saveopts" type="submit" class="save" value="保存设置">
			<input name="resetopts" type="submit" class="reset" value="重置设置" onclick="return confirm('你确定要重置所有的设置吗？');">
		</div>
	</div><!-- #optwrap -->

</form>

</div><!-- .wrap -->
<div class="clear"></div>

<script>
jQuery(function($) {
	$('#optnav li a').click(function() {
		$('.currnav').removeClass('currnav');
		$(this).parent().addClass('currnav');
		$('.optcurr').hide().removeClass('optcurr');
		$($(this).attr('href')).fadeIn(300).addClass('optcurr');
		$('#lasttab').attr('value', $(this).attr('href'))
		return false;
	});
	$('.color-block').click(function() {
		$('.color-current').removeClass('color-current');
		$(this).addClass('color-current');
	});
});
</script>
		<?php if (!empty($_POST['lasttab'])) echo '<script type="text/javascript">jQuery(function($){$(\'a[href="' . $_POST['lasttab'] . '"]\').click();});</script>';
	}
}
	
// 登记初始化方法
add_action('admin_menu', array('stOptions', 'init'));

// 显示提示信息
add_action('admin_notices', array('stOptions', 'notice'));

// 添加顶部工具条主题设置链接
function add_theme_settings_link($wp_admin_bar) {
	$args = array(
		'parent' => 'appearance',
		'id'     => 'theme_settings_link',
		'title'  => __('Theme Options'), 
		'href'   => admin_url('themes.php?page=settings.php'), 
		'meta'   => array(
			'class' => 'theme_settings_link', 
			'title' => __('Theme Options')
		)
	);
	$wp_admin_bar->add_node($args);
}
if (!is_admin()) add_action('admin_bar_menu', 'add_theme_settings_link', 999);
