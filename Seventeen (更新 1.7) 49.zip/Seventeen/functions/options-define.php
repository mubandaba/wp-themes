<?php
$themename = "Seventeen";
$items = array(
	array(
		'title' => __('General'),
		'id'	=> 'opt-general',
		'type'  => 'before'
	),
	array(
		'title' => '网站图标设置',
		'type'  => 'subtitle'
	),
	array(
		'name'  => 'Favicon 图标',
		'desc'  => '.ico 格式，尺寸 16x16',
		'id'	=> 'favicon',
		'type'  => 'text',
		'std'   => get_template_directory_uri() . '/favicon.ico'
	),
	array(
		'name'  => 'WebApp 图标',
		'desc'  => '.png 格式，尺寸 192x192',
		'id'	=> 'webapp-icon',
		'type'  => 'text',
		'std'   => get_template_directory_uri() . '/images/icon192.png'
	),
	array(
		'title' => 'SEO设置',
		'type'  => 'subtitle'
	),
	array(
		'name'  => '自定义首页关键字/描述',
		'desc'  => '启用',
		'id'	=> 'custom-meta',
		'type'  => 'checkbox',
		'std'   => false
	),
	array(
		'name'  => '首页关键字',
		'desc'  => '各关键字间用半角逗号","分割，数量在5个以内最佳。',
		'id'	=> 'meta-keyword',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => '首页描述',
		'desc'  => '用简洁的文字描述本站点，字数建议在120个字以内。',
		'id'	=> 'meta-desc',
		'type'  => 'textarea',
		'std'   => ''
	),
	array(
		'title' => 'Ajax',
		'type'  => 'subtitle'
	),
	array(
		'name'  => 'Ajax 评论分页',
		'desc'  => '启用评论 Ajax 分页切换（地址栏URL不改变）',
		'id'	=> 'comments-ajax-page',
		'type'  => 'checkbox',
		'std'   => true
	),
	array(
		'name'  => 'Ajax 评论提交',
		'desc'  => '启用评论 Ajax 分页提交',
		'id'	=> 'comments-ajax-post',
		'type'  => 'checkbox',
		'std'   => true
	),
	array(
		'name'  => '全站 pjax',
		'desc'  => '启用全站 pushState+Ajax 跳转',
		'id'	=> 'pjax',
		'type'  => 'checkbox',
		'std'   => false
	),
	array(
		'name'  => 'pjax triggler',
		'desc'  => '',
		'id'	=> 'pjax-triggler',
		'type'  => 'textarea',
		'std'   => ''
	),
	array(
		'title' => __('Comment'),
		'type'  => 'subtitle'
	),
	array(
		'name'  => '评论邮件提醒',
		'desc'  => '在评论被回复时发邮件提醒评论者。如果你已经使用了相关插件，请禁用。在一些不支持mail()函数的服务器上可能无法发出邮件，请联系您的服务器提供商解决，或者使用第三方SMTP插件。',
		'id'	=> 'comment-mail-notify',
		'type'  => 'checkbox',
		'std'   => true
	),
	array(
		'name'  => '评论作者网站',
		'desc'  => '在新窗口中打开评论作者的网站',
		'id'	=> 'comment-url-target',
		'type'  => 'checkbox',
		'std'   => true
	),
	array(
		'title' => __('Text'),
		'type'  => 'subtitle'
	),
	array(
		'name'  => '名片标题',
		'desc'  => '名片中的那堆字比较大的那部分，留空则使用站点标题',
		'id'	=> 'card-title',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => '名片描述',
		'desc'  => '名片中的那堆字比较小的那部分，留空则使用站点描述',
		'id'	=> 'card-desc',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => '搜索框占位文字',
		'desc'  => '当搜索框没有输入内容时，里面的提示文字',
		'id'	=> 'search-placeholder',
		'type'  => 'text',
		'std'   => '输入，回车搜索'
	),
	array(
		'name'  => '404 页面',
		'desc'  => '404页面的标题',
		'id'	=> '404-title',
		'type'  => 'text',
		'std'   => 'Not Found'
	),
	array(
		'name'  => '',
		'desc'  => '404页面的内容，可以使用HTML标签进行排版',
		'id'	=> '404-content',
		'type'  => 'textarea',
		'std'   => "<p><img src=\"" . get_template_directory_uri() . "/images/404.gif\"></p>\n<p>哎呀，这个页面貌似被路过的外星人捡走了呢~</p>\n<p>如果是博主把你带到这里来的，请把这个问题反馈给他</p>"
	),
	array(
		'name'  => '评论框占位文字',
		'desc'  => '当评论框没有输入内容时，里面的提示文字',
		'id'	=> 'comment-placeholder',
		'type'  => 'textarea',
		'std'   => '猫主席说我们之所以胜利是因为敌人看了文章从不评论'
	),
	array(
		'type'  => 'after'
	),
	
	
	array(
		'title' => __('Appearance'),
		'id'	=> 'opt-appearance',
		'type'  => 'before'
	),
	array(
		'name'  => '颜色主题',
		'desc'  => '',
		'id'	=> 'color-theme',
		'type'  => 'color',
		'options' => array(
			'晴空' => array('lightblue', '#6BB6D3'),
			'夜幕' => array('darkblue', '#004462'),
			'黛蓝' => array('greengrey', '#2C4652'),
			'葱青' => array('lightgreen', '#259351')
		),
		'std'   => 'darkblue'
	),
	// radio类项目较多时，可以使之分多行显示，把两个radio项设置成同样的id即可
	array(
		'name'  => '',
		'desc'  => '',
		'id'	=> 'color-theme',
		'type'  => 'color',
		'options' => array(
			'海棠' => array('red', '#DD0E0E'),
			'粗粮' => array('orange', '#FF8800'),
			'藕荷' => array('pink', '#A77A94'),
			'丁香' => array('purple', '#6A5A8C')
		),
		'std'   => 'darkblue'
	),
	array(
		'name'  => 'Logo',
		'desc'  => '尺寸 260x77，你也可以直接替换主题文件夹/images/logo.png',
		'id'	=> 'logo',
		'type'  => 'text',
		'std'   => get_template_directory_uri() . '/images/logo.png'
	),
	array(
		'name'  => '背景类型',
		'desc'  => '',
		'id'	=> 'bg-style',
		'type'  => 'radio',
		'options' => array(
			'默认颜色' => 'default',
			'自定义图片' => 'image',
			'自定义颜色' => 'color'
		),
		'std'   => 'default'
	),
	array(
		'name'  => '自定义背景图',
		'desc'  => '',
		'id'	=> 'bg-url',
		'type'  => 'text',
		'std'   => get_template_directory_uri() . '/images/bg.png'
	),
	array(
		'name'  => '背景图显示方式',
		'desc'  => '',
		'id'	=> 'bg-img-style',
		'type'  => 'radio',
		'options' => array(
			'平铺' => 'scroll',
			'平铺且固定' => 'fixed',
			'自适应' => 'cover'
		),
		'std'   => 'scroll'
	),
	array(
		'name'  => '自定义背景色',
		'desc'  => '',
		'id'	=> 'bg-color',
		'type'  => 'text',
		'std'   => '#000000'
	),
	array(
		'name'  => '顶栏和页脚透明度',
		'desc'  => '',
		'id'	=> 'header-footer-opacity',
		'type'  => 'number',
		'std'   => '100'
	),
	array(
		'name'  => '侧边栏和主体透明度',
		'desc'  => '',
		'id'	=> 'sidebar-content-opacity',
		'type'  => 'number',
		'std'   => '100'
	),
	array(
		'name'  => '内容加框（暂不可用）',
		'desc'  => '如果你在上面换了颜色较深的背景导致看不清部分文字，请勾选',
		'id'	=> 'text-box',
		'type'  => 'checkbox',
		'std'   => false
	),
	array(
		'name'  => '加载动画',
		'desc'  => '在页面打開時显示加载动画',
		'id'	=> 'load-animation',
		'type'  => 'checkbox',
		'std'   => false
	),
	array(
		'name'  => '加载动画图案',
		'desc'  => '',
		'id'	=> 'load-animation-style',
		'type'  => 'radio',
		'options' => array(
			'<i class="fa fa-2x fa-spinner fa-spin"></i>' => 'fa-spinner',
			'<i class="fa fa-2x fa-circle-o-notch fa-spin"></i>' => 'fa-circle-o-notch',
			'<i class="fa fa-2x fa-refresh fa-spin"></i>' => 'fa-refresh',
			'<i class="fa fa-2x fa-cog fa-spin"></i>' => 'fa-cog'
		),
		'std'   => 'fa-circle-o-notch'
	),
	array(
		'title' => __('Navigation'),
		'type'  => 'subtitle'
	),
	array(
		'name'  => '分页导航',
		'desc'  => 'WP4.1新版分页导航函数仅支持WP4.1或更新版本，Wordpress 4.0及以下的版本选择此项会显示 Mini-PageNavi by Willan Kan',
		'id'	=> 'nav-type',
		'type'  => 'radio',
		'options' => array(
			'WP4.1新版' => 'new',
			'Mini-PageNavi' => 'kan',
			'WP旧版' => 'old'
		),
		'std'   => 'new'
	),
	array(
		'name'  => '面包屑导航',
		'desc'  => '启用（在手机上会自动隐藏）',
		'id'	=> 'breadcrumb',
		'type'  => 'checkbox',
		'std'   => true
	),
	array(
		'name'  => '“返回顶部”按钮',
		'desc'  => '启用（在手机上会自动隐藏）',
		'id'	=> 'gotop',
		'type'  => 'checkbox',
		'std'   => true
	),
	array(
		'title' => __('Sidebar'),
		'type'  => 'subtitle'
	),
	array(
		'name'  => '边栏头像',
		'desc'  => '填写Gravatar邮箱地址或者图片URL，图片尺寸112x112',
		'id'	=> 'sidebar-avatar',
		'type'  => 'text',
		'std'   => get_the_author_meta('user_email', 1)
	),
	array(
		'name'  => '侧边栏博客名片',
		'desc'  => '启用',
		'id'	=> 'sidebar-card',
		'type'  => 'checkbox',
		'std'   => true
	),
	array(
		'name'  => '单栏模式',
		'desc'  => '禁用侧边栏',
		'id'	=> 'no-sidebar',
		'type'  => 'checkbox',
		'std'   => false
	),
	array(
		'name'  => '侧边栏位置',
		'desc'  => '',
		'id'	=> 'sidebar-pos',
		'type'  => 'radio',
		'options' => array(
			'左侧' => 'left',
			'右侧' => 'right'
		),
		'std'   => 'left'
	),
	array(
		'name'  => '固定小工具容器',
		'desc'  => '启用后，在小工具页面把想要固定的小工具移动到“固定小工具”容器中，这些小工具会在页面滚动到相应位置时钉在页面顶部',
		'id'	=> 'pin-widget',
		'type'  => 'checkbox',
		'std'   => true
	),
	array(
		'type'  => 'after'
	),
	

	array(
		'title' => __('Header'),
		'id'	=> 'opt-header',
		'type'  => 'before'
	),
	array(
		'title' => '顶部社交网络图标&nbsp;&nbsp;<span style="font-weight:500;">如果顶部导航菜单项和图标都比较多，会导致菜单被挤到第二行导致页面变形，可以考虑把社交网络图标放在页脚，请前往“底部设置”选项卡进行设置</span>',
		'type'  => 'subtitle'
	),
	array(
		'title' => '',
		'type'  => 'subtitle'
	),
	array(
		'name'  => '显示搜索图标',
		'desc'  => '启用',
		'id'	=> 'show-topsearch',
		'type'  => 'checkbox',
		'std'   => true
	),
	array(
		'name'  => '显示RSS图标',
		'desc'  => '启用',
		'id'	=> 'show-rss',
		'type'  => 'checkbox',
		'std'   => false
	),
	array(
		'name'  => '新浪微博',
		'desc'  => '留空则不显示，下同',
		'id'	=> 'icon-weibo',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => '腾讯微博',
		'desc'  => '',
		'id'	=> 'icon-txweibo',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => '人人网',
		'desc'  => '',
		'id'	=> 'icon-renren',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => 'Twitter',
		'desc'  => '',
		'id'	=> 'icon-twitter',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => 'Facebook',
		'desc'  => '',
		'id'	=> 'icon-facebook',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => 'Google+',
		'desc'  => '',
		'id'	=> 'icon-gplus',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => 'GitHub',
		'desc'  => '',
		'id'	=> 'icon-github',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => 'LinkedIn',
		'desc'  => '',
		'id'	=> 'icon-linkedin',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => 'Flickr',
		'desc'  => '',
		'id'	=> 'icon-flickr',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => 'Dribbble',
		'desc'  => '',
		'id'	=> 'icon-dribbble',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => 'Last.fm',
		'desc'  => '',
		'id'	=> 'icon-lastfm',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => 'Twitch',
		'desc'  => '',
		'id'	=> 'icon-twitch',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => 'Wordpress.com',
		'desc'  => '',
		'id'	=> 'icon-wpcom',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'type'  => 'after'
	),
	

	array(
		'title' => __('Footer'),
		'id'	=> 'opt-footer',
		'type'  => 'before'
	),
	array(
		'name'  => '页脚文字信息',
		'desc'  => '用来放版权声明、备案号等等，可以使用HTML标签进行排版',
		'id'	=> 'footer-text',
		'type'  => 'textarea',
		'std'   => '<p>CC:BY-NC-SA 4.0 <a href="' . get_bloginfo('url') . '">' . get_bloginfo('name') . '</a> 2015. Proudly powered by <a href="http://wordpress.org" target="_blank">Wordpress</a>. Theme Seventeen. 京ICP备23333333号</p>'
	),
	array(
		'name'  => '统计代码',
		'desc'  => '隐藏统计代码产生的图片',
		'id'	=> "hide-analyst",
		'type'  => 'checkbox',
		'std'   => false
	),
	array(
		'name'  => '',
		'desc'  => '不对管理员添加统计代码',
		'id'	=> "analyst-noadmin",
		'type'  => 'checkbox',
		'std'   => true
	),
	array(
		'name'  => '',
		'desc'  => '',
		'id'	=> 'analyst-code',
		'type'  => 'textarea',
		'std'   => ''
	),
	array(
		'title' => '底部社交网络图标',
		'type'  => 'subtitle'
	),
	array(
		'name'  => 'RSS图标',
		'desc'  => '显示',
		'id'	=> 'show2-rss',
		'type'  => 'checkbox',
		'std'   => true
	),
	array(
		'name'  => '新浪微博',
		'desc'  => '留空则不显示，下同',
		'id'	=> 'icon2-weibo',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => '腾讯微博',
		'desc'  => '',
		'id'	=> 'icon2-txweibo',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => '人人网',
		'desc'  => '',
		'id'	=> 'icon2-renren',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => 'Twitter',
		'desc'  => '',
		'id'	=> 'icon2-twitter',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => 'Facebook',
		'desc'  => '',
		'id'	=> 'icon2-facebook',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => 'Google+',
		'desc'  => '',
		'id'	=> 'icon2-gplus',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => 'GitHub',
		'desc'  => '',
		'id'	=> 'icon2-github',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => 'LinkedIn',
		'desc'  => '',
		'id'	=> 'icon2-linkedin',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => 'Flickr',
		'desc'  => '',
		'id'	=> 'icon2-flickr',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => 'Dribbble',
		'desc'  => '',
		'id'	=> 'icon2-dribbble',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => 'Last.fm',
		'desc'  => '',
		'id'	=> 'icon2-lastfm',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => 'Twitch',
		'desc'  => '',
		'id'	=> 'icon2-twitch',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => 'Wordpress.com',
		'desc'  => '',
		'id'	=> 'icon2-wpcom',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'type'  => 'after'
	),


	array(
		'title' => __('Template'),
		'id'	=> 'opt-template',
		'type'  => 'before'
	),
	array(
		'title' => '注意：文章信息在移动端只显示 三个。',
		'type'  => 'subtitle'
	),
	array(
		'name'  => '要显示的文章信息',
		'desc'  => '文章作者',
		'id'	=> 'postmeta-author',
		'type'  => 'checkbox',
		'std'   => true
	),
	array(
		'name'  => '',
		'desc'  => '文章格式',
		'id'	=> 'postmeta-format',
		'type'  => 'checkbox',
		'std'   => true
	),
	array(
		'name'  => '',
		'desc'  => '分类目录',
		'id'	=> 'postmeta-cat',
		'type'  => 'checkbox',
		'std'   => true
	),
	array(
		'name'  => '',
		'desc'  => '发表日期',
		'id'	=> 'postmeta-date',
		'type'  => 'checkbox',
		'std'   => true
	),
	array(
		'name'  => '',
		'desc'  => '评论数',
		'id'	=> 'postmeta-comment',
		'type'  => 'checkbox',
		'std'   => true
	),
	array(
		'name'  => '',
		'desc'  => '编辑链接',
		'id'	=> 'postmeta-edit',
		'type'  => 'checkbox',
		'std'   => true
	),
	array(
		'name'  => '',
		'desc'  => '浏览数 (需安装 <a href="' . get_admin_url() . 'plugin-install.php?tab=plugin-information&amp;plugin=wp-postviews&amp;TB_iframe=true&amp;width=772&amp;height=356" class="thickbox" aria-label="WP-PostViews" data-title="WP-PostViews">WP-PostViews</a> 插件)',
		'id'	=> 'postmeta-views',
		'type'  => 'checkbox',
		'std'   => true
	),
	array(
		'name'  => '文章页版权声明',
		'desc'  => '位于文章页正文下方（不会在“状态”格式的文章中显示），不需要则留空。<br>文章标题：<code>{{title}}</code><br>文章链接：<code>{{link}}</code>',
		'id'	=> 'post-copy',
		'type'  => 'textarea',
		'std'   => '<a href="' . get_bloginfo('url') . '">' . get_bloginfo('name') . '</a>原创文章，转载请注明来自：<a href="{{link}}">{{title}}</a>'
	),
	array(
		'name'  => '分享代码',
		'desc'  => '位于文章页正文下方（不会在“状态”格式的文章中显示），不需要则留空。',
		'id'	=> 'share-code',
		'type'  => 'textarea',
		'std'   => ''
	),
	array(
		'name'  => '搜索页格式',
		'desc'  => '搜索页文章列表显示摘要(暂不可用)',
		'id'	=> 'search-excerpt',
		'type'  => 'checkbox',
		'std'   => true
	),
	array(
		'name'  => '链接页面',
		'desc'  => '按分类显示 (未分类的链接不会显示)',
		'id'	=> 'linkpage-sort-by-cat',
		'type'  => 'checkbox',
		'std'   => true
	),
	array(
		'name'  => '读者墙',
		'desc'  => '排除特定邮箱（多个邮箱用 <code>|</code> 分隔）',
		'id'	=> "guestbook-exclude-emails",
		'type'  => 'text',
		'std'   => get_bloginfo('admin_email')
	),
	array(
		'name'  => '读者墙显示留言者数量',
		'desc'  => '小于等于0表示无限制',
		'id'	=> "guestbook-count",
		'type'  => 'number',
		'std'   => 28
	),
	
	array(
		'title' => '此页的幻灯片设置已失效，请转至“幻灯片”选项卡查看新的设置方式',
		'type'  => 'subtitle'
	),
	array(
		'name'  => '幻灯片1图片地址',
		'desc'  => '填多少个图片项就显示多少个幻灯片，最多五个',
		'id'	=> 'slider-pic-1',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => '幻灯片1链接',
		'desc'  => '图片建议宽700px高280px',
		'id'	=> 'slider-link-1',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => '幻灯片2图片地址',
		'desc'  => '',
		'id'	=> 'slider-pic-2',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => '幻灯片2链接',
		'desc'  => '',
		'id'	=> 'slider-link-2',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => '幻灯片3图片地址',
		'desc'  => '',
		'id'	=> 'slider-pic-3',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => '幻灯片3链接',
		'desc'  => '',
		'id'	=> 'slider-link-3',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => '幻灯片4图片地址',
		'desc'  => '',
		'id'	=> 'slider-pic-4',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => '幻灯片4链接',
		'desc'  => '',
		'id'	=> 'slider-link-4',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => '幻灯片5图片地址',
		'desc'  => '',
		'id'	=> 'slider-pic-5',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'name'  => '幻灯片5链接',
		'desc'  => '',
		'id'	=> 'slider-link-5',
		'type'  => 'text',
		'std'   => ''
	),
	array(
		'type'  => 'after'
	),
	
	
	array(
		'title' => '幻灯片',
		'id'	=> 'opt-slider',
		'type'  => 'before'
	),
	array(
		'name'  => '首页幻灯片',
		'desc'  => '启用幻灯片轮播',
		'id'	=> 'slider',
		'type'  => 'checkbox',
		'std'   => true
	),
	array(
		'title' => '幻灯片现在被视为一种文章格式来管理，管理页面在仪表盘菜单“Slider”进入，或者<a href="' . admin_url('edit.php?post_type=st_slider') . '" target="_blank">点击这里</a>进入',
		'type'  => 'desc'
	),
	array(
		'title' => '“页面模板”选项卡中关于幻灯片的内容将会被暂时保留以方便数据迁移。Seventeen 1.7 版本后它将会被移除',
		'type'  => 'desc'
	),
	array(
		'type'  => 'after'
	),


	array(
		'title' => __('Advanced'),
		'id'	=> 'opt-advanced',
		'type'  => 'before'
	),
	array(
		'title' => '如果你不知道本页的设置项有什么作用，请不要随意填写、更改！',
		'type'  => 'subtitle'
	),
	array(
		'name'  => 'jQuery CDN',
		'desc'  => '选择加载jQuery库时使用的CDN',
		'id'	=> 'jquery-cdn',
		'type'  => 'select',
		'options' => array(
			'不使用CDN' => 'none',
			'MoeNet Public CDN' => 'moe',
			'又拍云' => 'upyun',
			'新浪SAE' => 'sae',
			'Google (中国大陆无法访问)' => 'google',
			'微软ASP.NET' => 'microsoft'
		),
		'std'   => 'moe'
	),
	array(
		'name'  => 'Font-Awesome CDN',
		'desc'  => '选择加载Font-Awesome时使用的CDN',
		'id'	=> 'fa-cdn',
		'type'  => 'select',
		'options' => array(
			'不使用CDN' => 'none',
			'百度BAE' => 'bae',
			'Bootstrap中文网' => 'bootcss',
			'百度公共库 (不支持HTTPS)' => 'bdimg'
		),
		'std'   => 'bae'
	),
	array(
		'name'  => 'Noto Sans Webfont CDN',
		'desc'  => '选择加载Noto Sans字体时使用的CDN',
		'id'	=> 'font-cdn',
		'type'  => 'select',
		'options' => array(
			'不使用CDN' => 'none',
			'MoeNet Public CDN' => 'moe',
			'Google (中国大陆部分地区已解封)' => 'google',
			'360网站卫士 (不支持HTTPS)' => '360'
		),
		'std'   => 'moe'
	),
	array(
		'name'  => 'Gravatar服务器替换',
		'desc'  => '解决国内Gravatar被墙的问题，如果你已经使用其他插件，请禁用',
		'id'	=> 'unblock-gravatar',
		'type'  => 'select',
		'options' => array(
			'禁用' => 'disable',
			'MoeNet Public CDN' => 'moe',
			'Gravatar 中国服务器 (不支持HTTPS)' => 'grcn',
			'多说 (不支持HTTPS)' => 'duoshuo'
		),
		'std'   => 'moe'
	),
	array(
		'name'  => 'HTTPS (慎用！)',
		'desc'  => '静态文件强制支持HTTPS (把http://替换成//)',
		'id'	=> 'force-static-https',
		'type'  => 'checkbox',
		'std'   => false
	),
	array(
		'name'  => '自定义CSS',
		'desc'  => '代码会被追加至<code>&lt;head&gt;...&lt;/head&gt;</code>标签内的<code>&lt;style&gt;</code>标签内，不需要请留空',
		'id'	=> 'custom-css',
		'type'  => 'textarea',
		'std'   => ''
	),
	array(
		'name'  => '自定义头部代码',
		'desc'  => '代码会被追加至<code>&lt;head&gt;...&lt;/head&gt;</code>标签内，不需要请留空',
		'id'	=> 'custom-headcode',
		'type'  => 'textarea',
		'std'   => ''
	),
	array(
		'type'  => 'after'
	)
);
