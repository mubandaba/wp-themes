<?php

add_action('init', 'st_slider_post_type');
function st_slider_post_type() {
    register_post_type('st_slider',
        array(
            'labels' => array(
                'name' => _x('Sliders', '幻灯片'),
                'singular_name' => _x('Slider', '幻灯片'),
                'add_new' => '添加',
                'add_new_item' => '添加新幻灯片',
                'edit_item' => '编辑幻灯片',
                'new_item' => '新幻灯片'
            ),
            'public' => false,
            'show_ui' => true,
            'has_archive' => false,
            'menu_position' => 65,
            'supports' => array('title')
        )
    );
}

add_action('add_meta_boxes', 'st_slider_informations');
function st_slider_informations() {
    add_meta_box(
        'st_slider_information',
        '幻灯片信息',
        'st_slider_form',
        'st_slider',
        'advanced',
        'high'
    );
}

function st_slider_form($post) {
    wp_nonce_field('st_slider_form', 'st_slider_form_nonce');
    ?>
    
    <style type="text/css">
        .st_slider_form { width: 100%; margin: 0 0 0.7em; }
    </style>

    <input class="st_slider_form" type="url" id="st_image_url" name="st_image_url" value="<?php echo esc_attr(get_post_meta($post->ID, 'slider_imgurl', true)); ?>" placeholder="图片URL" required />

    <input class="st_slider_form" type="url" id="st_link_url" name="st_link_url" value="<?php echo esc_attr(get_post_meta($post->ID, 'slider_link', true)); ?>" placeholder="超链接" />

    <?php
}

add_action('save_post', 'st_slider_save');
function st_slider_save($post_id){
    if (!isset( $_POST['st_slider_form_nonce'])) {
        return;
    }
    if (!wp_verify_nonce($_POST['st_slider_form_nonce'], 'st_slider_form')) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    update_post_meta($post_id, 'slider_imgurl', sanitize_text_field($_POST['st_image_url']));
    update_post_meta($post_id, 'slider_link', sanitize_text_field($_POST['st_link_url']));
}

add_filter( 'manage_st_slider_posts_columns', 'set_custom_edit_st_slider_columns' );
add_action( 'manage_st_slider_posts_custom_column' , 'custom_st_slider_column', 10, 2 );

function set_custom_edit_st_slider_columns($columns) {
    $columns = array(
        'cb' => '<input type="checkbox" />',
        'title' => '名称',
        'imglink' => '链接网址',
        'imgurl' => '图片URL',
        'imgpreview' => '预览'
    );
    return $columns;
}

function custom_st_slider_column($column, $post_id) {
    global $post;
    switch($column) {
        case "imgurl":
            if(get_post_meta($post->ID, "slider_imgurl", true)) {
                echo get_post_meta($post->ID, "slider_imgurl", true);
            } else {
                echo '----';
            }
            break;
        case "imglink":
            if(get_post_meta($post->ID, "slider_link", true)) {
                echo get_post_meta($post->ID, "slider_link", true);
            } else {
                echo '----';
            }
            break;
        case "imgpreview":
            $slider_pic = get_post_meta($post->ID, "slider_imgurl", true);
            echo '<img src="'.$slider_pic.'" width="95" height="41" alt="" />';
            break;
    }
}

add_action('admin_head', 'st_column_css');
function st_column_css() { ?>
<style type="text/css">
    @media screen and (max-width: 782px) {
        .column-imglink, .column-imgurl { display: none; }
        .post-type-st_slider .column-title { width: 60%; }
    }
</style>
<?php
}