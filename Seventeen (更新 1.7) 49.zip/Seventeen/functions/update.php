<?php
$themeinfo = wp_get_theme();
$ver = $themeinfo->get('Version');
$url = 'http://theme-update-repo.codingapp.com/seventeen.json';
$context = stream_context_create(array('http' => array('method'=>"GET", 'timeout'=>1)));
$json = @file_get_contents($url, false, $context);
if (!$json) return;
$arr = json_decode($json, true);
if (is_null($arr) || $arr['version'] <= $ver) return;

function notice_update() {
	add_settings_error('st_update', 'st_theme_update', 'Seventeen 主题有新版本。<a href="' . admin_url('themes.php?page=update.php') . '">查看详情</a>', 'updated');
	settings_errors('st_update');
}
add_action('admin_notices', 'notice_update');

function add_theme_update_page() { // 更新说明页
	add_theme_page('更新详情', '更新详情', 'edit_theme_options', basename(__FILE__) , 'theme_update_description');
}
add_action('admin_menu', 'add_theme_update_page');

function theme_update_description() {
	global $ver, $arr;
	remove_action('admin_footer', 'notice_update');
	?>
	<div class="wrap" id="optpage">
		<h2>主题更新</h2><div class="tool-box">

		<h3 class="title">新版本 <?php echo $arr['version']; ?></h3>
		<p>当前版本 <?php echo $ver; ?></p>
		<p>更新发布时间 <?php echo $arr['time']; ?></p>

		<h3 class="title">更新说明：</h3>
		<ol><li><?php echo str_replace('|', '</li><li>', $arr['description']); ?></li></ol>

		<p>该主题为收费主题，已购买的用户请前往<a href="http://www.wpdaxue.com/wordpress-theme-seventeen.html#主题购买" target="_blank">WordPress大学主题介绍页</a>或者在售后服务QQ群共享下载更新。</p>
		<p>升级主题请先删除旧版主题，然后在<a href="<?php admin_url('theme-install.php?upload'); ?>" target="_blank">这个页面</a>上传新的版本。当然，你也可以直接用FTP替换主题文件。</p>
		<p>为保证升级后新增、改动的功能正常可用，最好到<a href="<?php admin_url('themes.php?page=settings.php') ?>" target="_blank">主题设置页</a>点一次“保存设置”</p>
	</div>

<?php }
