<?php global $options; ?>
<div id="sidebar" class="fl">
	<?php get_template_part('module', 'card'); ?>
	<script type="text/javascript">nanobar.go(40);</script>
	<?php if(function_exists('dynamic_sidebar')) { ?>
		<div id="sb"> 
		<?php if (is_active_sidebar('sb')) { ?>
			<div id="sbnormal"><?php dynamic_sidebar('sb'); ?></div>
		<?php }
		if (is_active_sidebar('sbpin')) { ?>
			<div id="sbpin"><?php dynamic_sidebar('sbpin'); ?></div>
		<?php } ?>
		</div>
	<?php } ?>
</div>