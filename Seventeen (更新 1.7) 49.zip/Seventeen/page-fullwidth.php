<?php
/*
  Template Name: Full width page
 */
	get_header(); ?>

		<div id="content" class="fw">
			<?php dimox_breadcrumbs(); ?>
			<?php while(have_posts()) {
				the_post();
				get_template_part('content', 'page');
			} ?>
			
			<?php comments_template(); ?>

		</div><!-- #content.wp.center -->
	</div><!-- #container.wc.center -->

<?php get_footer(); ?>
