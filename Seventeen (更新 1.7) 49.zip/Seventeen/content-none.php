<?php if (is_search()) { ?>
	<p style="color:#9DACB2;text-align:center;">未找到符合条件的搜索结果</p>
<?php } else { ?>
<div id="post-<?php the_ID();?>" class="hentry">
	<h1 class="post-title"><?php echo(O('404-title') != '' ? O('404-title') : 'Not Found'); ?></h1>
	<div class="post-content">
		<?php if (O('404-content') != '') {
			echo stripslashes(O('404-content'));
		} else { ?>
			<p><img src="<?php bloginfo('template_url'); ?>/images/404.gif"></p>
			<p>哎呀，这个页面貌似被路过的外星人捡走了呢</p>
			<p>如果是博主把你带到这里来的，请把这个问题反馈给他</p>
		<?php } ?>
	</div>
	<div class="post-meta">
		<span class="fa-chevron-left"><a href="javascript:history.go(-1);">返回上一页</a></span>
		<span class="fa-home"><a href="<?php bloginfo('url'); ?>">返回首页</a></span>
	</div>
</div><!-- #post-ID -->
<?php } ?>