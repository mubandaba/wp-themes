<!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) | !(IE 8) ]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width">
	<title><?php wp_title(' | ', true, 'right'); ?><?php bloginfo('name'); ?> - <?php bloginfo('description'); ?></title>
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">
	<!-- 禁止百度等搜索引擎自动转码 -->
	<meta http-equiv="Cache-Control" content="no-transform">
	<meta http-equiv="Cache-Control" content="no-siteapp">
	<!--[if lt IE 9]>
	<script src="<?php echo get_template_directory_uri(); ?>/js/html5.js"></script>
	<![endif]-->
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<?php wp_head(); ?>
	<?php st_head_custom_code(); ?>
	<?php
	// SEO设置, 不知何故加入上面的函数无法输出内容
	if (!is_singular() && O('custom-meta')) {
		echo '<meta name="description" content="' . O('meta-desc') . '">';
		echo '<meta name="keywords" content="' . O('meta-keyword') . '">';
	}
	if (is_singular()) {
		$description = '';
		$keywords = '';
		$tags = get_the_tags();
		$categories = get_the_category();
		if ($tags) {
			foreach($tags as $tag) {
				$keywords .= $tag->name . ','; 
			};
		};
		if ($categories) {
			foreach($categories as $category) {
				$keywords .= $category->name . ','; 
			};
		};
		$description = mb_strimwidth(str_replace("\r\n", '', strip_tags($post->post_content)), 0, 240, '…');
		echo '<meta name="keywords" content="' . $keywords . '">';
		echo '<meta name="description" content="' . $description . '">';
	} ?>
	<script type="text/javascript">
	/* nanobar | https://github.com/jacoborus/nanobar/ | MIT LICENSE */
	var Nanobar=function(){var c,d,e,f,g,h,k={width:"100%",height:"8px",zIndex:9999,top:"0"},l={width:0,height:"100%",clear:"both",transition:"height .28s"};c=function(a,b){for(var c in b)a.style[c]=b[c];a.style["float"]="left"};f=function(){var a=this,b=this.width-this.here;0.1>b&&-0.1<b?(g.call(this,this.here),this.moving=!1,100==this.width&&(this.el.style.height=0,setTimeout(function(){a.cont.el.removeChild(a.el)},300))):(g.call(this,this.width-b/4),setTimeout(function(){a.go()},16))};g=function(a){this.width=
	a;this.el.style.width=this.width+"%"};h=function(){var a=new d(this);this.bars.unshift(a)};d=function(a){this.el=document.createElement("div");this.el.style.backgroundColor=a.opts.bg;this.here=this.width=0;this.moving=!1;this.cont=a;c(this.el,l);a.el.appendChild(this.el)};d.prototype.go=function(a){a?(this.here=a,this.moving||(this.moving=!0,f.call(this))):this.moving&&f.call(this)};e=function(a){a=this.opts=a||{};var b;a.bg=a.bg||"#000";this.bars=[];b=this.el=document.createElement("div");c(this.el,
	k);a.id&&(b.id=a.id);b.style.position=a.target?"absolute":"fixed";a.target?a.target.insertBefore(b,a.target.firstChild):document.getElementsByTagName("body")[0].appendChild(b);h.call(this)};e.prototype.go=function(a){this.bars[0].go(a);100==a&&h.call(this)};return e}();
	</script>
</head>

<body <?php body_class(); ?>>
<div id="load-cover"<?php echo(O('load-animation') ? '' : ' style="display:none;"'); ?>>
	<div id="load-spinner"><i class="fa <?php echo O('load-animation-style'); ?> fa-spin"></i></div>
</div>
<?php if (O('bg-style') == 'image' && O('bg-img-style') == 'cover') { ?>
	<script type="text/javascript">jQuery.backstretch("<?php echo O('bg-url'); ?>");</script>
<?php } ?>
<div id="pageframe" class="fw">
	<?php 
	echo '<script type="text/javascript">var inbopts={';
	switch (O('color-theme')) {
		case 'lightgreen': echo 'bg:"#025F27",'; break;
		case 'darkblue': echo 'bg:"#003A54",'; break;
		case 'greengrey': echo 'bg:"#2C4652",'; break;
		case 'red': echo 'bg:"#B51506",'; break;
		case 'orange': echo 'bg:"#E23300",'; break;
		case 'pink': echo 'bg:"#7B4967",'; break;
		case 'purple': echo 'bg:"#453A5E",'; break;
		default: case 'lightblue': echo 'bg:"#BEDBEC",'; break;
	}
	echo 'target:document.getElementById("pageframe"),id:"inb"};var nanobar = new Nanobar(inbopts);</script>'
	?>
	<div id="top" class="fw clf">
		<div id="header" class="wc center">
			<div class="logo-container left"><div class="logo left">
				<a href="<?php bloginfo('url'); ?>"><img src="<?php echo(empty($GLOBALS['o']['logo']) ? get_template_directory_uri() . '/images/logo.png' : O('logo')); ?>"></a>
			</div></div>
			<div class="social right">
				<?php
					if (O('show-topsearch')) { ?>
					<div class="ico right" id="tg-s"><a href="javascript:void()" class="fa fa-search"></a></div>
					<form role="search" method="get" id="searchform-top" action="<?php echo home_url('/'); ?>">
						<input type="text" value="" name="s" id="s-top" placeholder="<?php echo(O('search-placeholder') != '' ? O('search-placeholder') : '输入，回车搜索'); ?>" />
					</form>
				<?php } ?>
				<div id="toggler" class="right"><?php
					if (!empty($GLOBALS['o']['icon-weibo'])) echo '<div class="ico"><a href="' . O('icon-weibo') . '" target="_blank" class="fa fa-weibo"></a></div>';
					if (!empty($GLOBALS['o']['icon-txweibo'])) echo '<div class="ico"><a href="' . O('icon-txweibo') . '" target="_blank" class="fa fa-tencent-weibo"></a></div>';
					if (!empty($GLOBALS['o']['icon-renren'])) echo '<div class="ico"><a href="' . O('icon-renren') . '" target="_blank" class="fa fa-renren"></a></div>';
					if (!empty($GLOBALS['o']['icon-twitter'])) echo '<div class="ico"><a href="' . O('icon-twitter') . '" target="_blank" class="fa fa-twitter"></a></div>';
					if (!empty($GLOBALS['o']['icon-facebook'])) echo '<div class="ico"><a href="' . O('icon-facebook') . '" target="_blank" class="fa fa-facebook"></a></div>';
					if (!empty($GLOBALS['o']['icon-gplus'])) echo '<div class="ico"><a href="' . O('icon-gplus') . '" target="_blank" class="fa fa-google-plus"></a></div>';
					if (!empty($GLOBALS['o']['icon-github'])) echo '<div class="ico"><a href="' . O('icon-github') . '" target="_blank" class="fa fa-github"></a></div>';
					if (!empty($GLOBALS['o']['icon-linkedin'])) echo '<div class="ico"><a href="' . O('icon-linkedin') . '" target="_blank" class="fa fa-linkedin"></a></div>';
					if (!empty($GLOBALS['o']['icon-flickr'])) echo '<div class="ico"><a href="' . O('icon-flickr') . '" target="_blank" class="fa fa-flickr"></a></div>';
					if (!empty($GLOBALS['o']['icon-dribbble'])) echo '<div class="ico"><a href="' . O('icon-dribbble') . '" target="_blank" class="fa fa-dribbble"></a></div>';
					if (!empty($GLOBALS['o']['icon-lastfm'])) echo '<div class="ico"><a href="' . O('icon-lastfm') . '" target="_blank" class="fa fa-lastfm"></a></div>';
					if (!empty($GLOBALS['o']['icon-twitch'])) echo '<div class="ico"><a href="' . O('icon-twitch') . '" target="_blank" class="fa fa-twitch"></a></div>';
					if (!empty($GLOBALS['o']['icon-wpcom'])) echo '<div class="ico"><a href="' . O('icon-wpcom') . '" target="_blank" class="fa fa-wordpress"></a></div>';
					if (O('show-rss')) echo '<div class="ico"><a href="' . get_bloginfo('rss2_url') . '" target="_blank" class="fa fa-rss"></a></div>';
				?></div>
				<div class="ico right" id="tg-m"><a href="javascript:void()" class="fa fa-bars"></a></div>
			</div>
			<div class="topmenu left"><?php
				wp_nav_menu(array(
					'theme_location' => 'topmenu',
					'depth' => 2,
					'fallback_cb' => 'st_page_menu'
				));
				function st_page_menu() {
					wp_page_menu(array(
						'depth' => 2,
						'show_home' => true
					));
				}
			?></div><div class="left clf"></div>
		</div>
	</div>
	<div id="container" class="wc center clf">
	<script type="text/javascript">nanobar.go(20);</script>
