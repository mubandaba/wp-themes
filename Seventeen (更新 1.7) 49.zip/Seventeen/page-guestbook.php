<?php
/*
  Template Name: Guestbook page
 */
	get_header(); ?>

		<div id="content" class="fw">
			<?php while(have_posts()) {
				the_post();
				?>
				<div id="post-<?php the_ID();?>">
					<h1 class="guestbook-title">
						<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title();?></a>
					</h1>
					<div class="guestbook clf">
						<ul class="wall">
						<?php
							global $wpdb;
							$excemails = '|' . O('guestbook-exclude-emails');
							$counts = O('guestbook-count') > 0 ? O('guestbook-count') : 99999;
							$my_email = "'" . get_bloginfo ('admin_email') . "'";
							$query = "SELECT COUNT(comment_ID) AS cnt, comment_author, comment_author_url, comment_author_email FROM (SELECT * FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->posts.ID=$wpdb->comments.comment_post_ID) WHERE comment_date > date_sub( NOW(), INTERVAL 10 MONTH ) AND user_id='0' AND comment_author_email != $my_email AND post_password='' AND comment_approved='1' AND comment_type='') AS tempcmt GROUP BY comment_author_email ORDER BY cnt DESC LIMIT " . $counts;
							$wall = $wpdb->get_results($query);
							$output = "";
							foreach ($wall as $comment) {
								if (stripos($excemails, $comment->comment_author_email) <= 0) {
									if( $comment->comment_author_url ) $url = $comment->comment_author_url;
									else $url="javascript:void();";
									$output .= "<li><p><a href='" . $url . "' target='_blank' rel='nofollow' title='" . $comment->cnt . " 条评论'>" . get_avatar($comment->comment_author_email, 70) . "</a></p><p>" . $comment->comment_author . " (" . $comment->cnt . ")</p></li>";
								}
							}
							echo $output;
						?>
						</ul>
					</div>
				</div><!-- #post-ID -->
				<?php }

			comments_template(); ?>

		</div><!-- #content.wp.center -->
	</div><!-- #container.wc.center -->

<?php get_footer(); ?>
