
	<div id="foot" class="fw">
		<div id="footsb" class="wc center clf">
			<?php if(function_exists('dynamic_sidebar') && is_active_sidebar('footsb')) { ?>
				<?php dynamic_sidebar('footsb'); ?>
			<?php } ?>
		</div>
		<div id="bottom" class="fw">
			<div id="footer" class="wc center clf">
				<div class="info">
					<div class="icon2-container"><?php
						if (O('show2-rss')) echo '<div class="ico"><a href="' . get_bloginfo('rss2_url') . '" target="_blank" class="fa fa-rss"></a></div>';
						if (!empty($GLOBALS['o']['icon2-weibo'])) echo '<div class="ico"><a href="' . O('icon2-weibo') . '" target="_blank" class="fa fa-weibo"></a></div>';
						if (!empty($GLOBALS['o']['icon2-txweibo'])) echo '<div class="ico"><a href="' . O('icon2-txweibo') . '" target="_blank" class="fa fa-tencent-weibo"></a></div>';
						if (!empty($GLOBALS['o']['icon2-renren'])) echo '<div class="ico"><a href="' . O('icon2-renren') . '" target="_blank" class="fa fa-renren"></a></div>';
						if (!empty($GLOBALS['o']['icon2-twitter'])) echo '<div class="ico"><a href="' . O('icon2-twitter') . '" target="_blank" class="fa fa-twitter"></a></div>';
						if (!empty($GLOBALS['o']['icon2-facebook'])) echo '<div class="ico"><a href="' . O('icon2-facebook') . '" target="_blank" class="fa fa-facebook"></a></div>';
						if (!empty($GLOBALS['o']['icon2-gplus'])) echo '<div class="ico"><a href="' . O('icon2-gplus') . '" target="_blank" class="fa fa-google-plus"></a></div>';
						if (!empty($GLOBALS['o']['icon2-github'])) echo '<div class="ico"><a href="' . O('icon2-github') . '" target="_blank" class="fa fa-github"></a></div>';
						if (!empty($GLOBALS['o']['icon2-linkedin'])) echo '<div class="ico"><a href="' . O('icon2-linkedin') . '" target="_blank" class="fa fa-linkedin"></a></div>';
						if (!empty($GLOBALS['o']['icon2-flickr'])) echo '<div class="ico"><a href="' . O('icon2-flickr') . '" target="_blank" class="fa fa-flickr"></a></div>';
						if (!empty($GLOBALS['o']['icon2-dribbble'])) echo '<div class="ico"><a href="' . O('icon2-dribbble') . '" target="_blank" class="fa fa-dribbble"></a></div>';
						if (!empty($GLOBALS['o']['icon2-lastfm'])) echo '<div class="ico"><a href="' . O('icon2-lastfm') . '" target="_blank" class="fa fa-lastfm"></a></div>';
						if (!empty($GLOBALS['o']['icon2-twitch'])) echo '<div class="ico"><a href="' . O('icon2-twitch') . '" target="_blank" class="fa fa-twitch"></a></div>';
						if (!empty($GLOBALS['o']['icon2-wpcom'])) echo '<div class="ico"><a href="' . O('icon2-wpcom') . '" target="_blank" class="fa fa-wordpress"></a></div>';

						if (!empty($GLOBALS['o']['analyst-code'])) {
							if (!(O('analyst-noadmin') && !current_user_can('edit_dashboard'))) {
								echo stripcslashes(O('analyst-code'));
							}
						}
					?></div>
					<?php if (!empty($GLOBALS['o']['footer-text'])) echo stripcslashes(O('footer-text'));
						else echo('<p>CC:BY-NC-SA 4.0 <a href="' . get_bloginfo('url') . '">' . get_bloginfo('name') . '</a> 2015. Proudly powered by <a href="http://wordpress.org" target="_blank">Wordpress</a>. Theme Seventeen.</p>'); ?>
				</div>
			</div>
		</div>
	</div>
	
</div><!-- #pageframe.fw -->
<script type="text/javascript">nanobar.go(80);</script>
<?php if (O('gotop')) echo '<div id="gotop"><span class="fa fa-angle-up"></span></div>'; ?>
<script type="text/javascript">jQuery('#bulr').remove();jQuery('#load-cover').fadeOut(700,function(){jQuery('#la').remove()})</script>
<?php wp_footer(); ?>
<script type="text/javascript">nanobar.go(100);</script>
</body>
</html>