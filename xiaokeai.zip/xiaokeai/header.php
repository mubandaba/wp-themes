<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0"/>
    <?php wp_head();?>
    <link rel="stylesheet" href="https://raw.githubusercontent.com/daneden/animate.css/master/animate.css">
</head>
<body class="home blog">
<div id="top"></div>

<a href="<?php bloginfo("url")?>" class="logo" style="background-image: url(<?php echo joy_img("logo") ; ?>)"></a>
<header class="main-header">
    <a href="#" class="main-header-mobile jQ_toggleMenu"><i class="ion-navicon-round"></i></a>
    <div class="menu-main-menu-container">
        <ul id="menu-main-menu" class="menu">
            <?php wp_menu('main_menu');?>
            <div class="copyright">
                Copyright &copy; <?php the_time("Y");?>
                <a href="<?php bloginfo("url")?>" target="_blank">
                    <?php bloginfo("name")?>
                </a>
            </div>
        </ul>
    </div>
</header>









