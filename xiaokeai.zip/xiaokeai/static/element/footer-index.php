<?php
$icp_num=joy("icp_num");

?>


<footer class="footer" role="contentinfo">
    <?php  include 'friendlink.php';?>

    <div class="footer-copyright">

        <?php joy_if_empty($icp_num,'<a href="http://www.miitbeian.gov.cn">','</a>.')?>
<?php
/*
  * 留下作者链接只为SEO，如不喜欢你可以在后台选择隐藏版权
  * */
?>
   <div class="autor" <?php if(joy("cp_switcher")){ echo 'style="display:none;"';}?>>
       Theme by <a href="http://weixing.io/" >魏星</a>.
   </div>


</div>

</footer>

</div>