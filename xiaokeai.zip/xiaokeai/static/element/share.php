<footer class="post-share">
    <span class="post-share-text">分享</span>

    <span class="share-links">



                <a class="qzone" href="http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=<?php the_permalink(); ?>&amp;title=<?php the_title_attribute(); ?>" data-tooltip="qzone" data-placement="top" target="_blank">
                    <i class="fa fa-qq"></i>
                </a>
                <a class="weibo" href="http://service.weibo.com/share/share.php?title=<?php the_title_attribute(); ?>&amp;url=<?php the_permalink(); ?>" data-tooltip="weibo" data-placement="top" target="_blank">
                    <i class="fa fa-weibo"></i>
                </a>
                <a class="twitter" href="http://twitter.com/share?url=<?php the_permalink(); ?>&amp;text=<?php the_title_attribute(); ?>" data-tooltip="twitter" data-placement="top" target="_blank">
                    <i class="fa fa-twitter"></i>
                </a><a class="wechat">
                    <i class="fa fa-wechat"></i>
                </a>

                <div class="qr-container">
                    <img src="http://qr.liantu.com/api.php?text=<?php the_permalink(); ?>" class="qr-img">
                </div>
            </span>
</footer>