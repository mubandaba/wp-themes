<?php $friend_options=cs_get_option('friend_options')?>
<?php if (!empty($friend_options)):?>
    <div class="friend_link footer-copyright">
        友情链接:
        <?php foreach ( joy('friend_options') as $value ):?>
            <a href='<?php echo $value['friend_link'];?>' target='_blank'><?php echo $value['friend_title'];?></a>
        <?php endforeach;?>
    </div>
<?php endif;?>