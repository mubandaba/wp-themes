<article class="post-says" id="post-<?php the_ID(); ?>" style="background-image: url(<?php if ( has_post_thumbnail() ) { echo get_the_post_thumbnail_url(); } ?>)">
    <a class="mask" href="<?php the_permalink();?>" title="<?php the_title();?>"></a>
    <h2 class="post-title"><?php the_excerpt("50");?></h2>
    <p class="post-date"><?php the_time('Y-m-d') ?></p>
</article>