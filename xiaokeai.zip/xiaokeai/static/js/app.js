$('.wechat').click(function () {
    $(".qr-container").addClass("active");
})
$(".qr-container").click(function () {
    $(".qr-container").removeClass("active");
})

$('.pay-switcher').hover(function () {
    $(".pay_qr_container").addClass("active");
},function () {
    $(".pay_qr_container").removeClass("active");
})
