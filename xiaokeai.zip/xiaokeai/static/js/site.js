(function ($) {


	$(document).ready(function () {

		$('a[href*="#"]:not([href="#"])').click(function() {
			if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
				var target = $(this.hash);
				target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
				if (target.length) {
					$('html, body').animate({
						scrollTop: target.offset().top
					}, 1000);
					return false;
				}
			}
		});

		var $body = $('body');

		$('.jQ_toggleMenu').on('click', function(){
			$body.toggleClass('has-menu-opened');

			return false;
		});

		$('.jQ_toggleSearch').on('click', function(){
			if(!$body.hasClass('has-search-opened')) {
				$('.jQ_searchInput').val('').focus();
			}

			$body.toggleClass('has-search-opened');

			return false;
		});


		$(window).on('keyup', function(e){
			if(e.keyCode == 27) {
				$('body').removeClass('has-search-opened');
			}
		});

		function validateEmail(email) {
			var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
			return re.test(email);
		}

		$('.jQ_newsletter').on('submit', function(){
			var $input = $('.jQ_newsletterInput'),
				inputVal = $input.val();

			$input.removeClass('error');

			if(!inputVal || !validateEmail(inputVal)) {
				$input.addClass('error');
				return false;
			}

		});


		// $('.wp-caption>a').magnificPopup({
		// 	type:'image'
		// });
	});





})(jQuery);