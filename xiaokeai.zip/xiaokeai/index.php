<?php get_header();?>
<div class="wrapper">

    <div class="posts">
<?php $i=0;  while ( have_posts() ) : the_post();?>

    <article class="post-simple animated fadeInRight" id="post-<?php the_ID(); ?>"
             style="background-image: url(<?php joy_thumb() ;?>);animation-delay:<?php echo 0+(0.6*$i);?>s;">
    <a href="<?php the_permalink();?>" title="<?php the_title();?>">

            <h2 class="post-title">
                <?php the_title();?>
            </h2>
            <p class="post-date">
                <?php the_time('Y-m-d') ?>
            </p>

        </a>
    </article>

<?php $i++; endwhile; ?>
    </div>

    <a href="#top" class="go-top"><i class="ion-chevron-up"></i></a>


    <?php joy_pagenavi();?>

<?php get_footer();?>
