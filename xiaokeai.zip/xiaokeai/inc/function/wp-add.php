<?php



# Remove Support
# ------------------------------------------------------------------------------
remove_theme_support( 'menus' );
