<?php


/**
 *
 * Get option
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'joy' ) ) {
    function joy( $option_name = '', $default = '' ) {

        $options = apply_filters( 'joy', get_option( CS_OPTION ), $option_name, $default );

        if( ! empty( $option_name ) && ! empty( $options[$option_name] ) ) {
            return $options[$option_name];
        } else {
            return ( ! empty( $default ) ) ? $default : null;
        }

    }
}
/*获取框架image图片地址*/
function joy_img ($id,$default=JOY_DEFAULT_IMG_PATH){
    $cs_id= joy($id);
    if (!empty($cs_id )){
        $id_url= wp_get_attachment_image_src( $cs_id, 'full' );
        return $id_url[0];
    }
	elseif (empty($cs_id )){
        return $default;
    }
}

function joy_if_empty($var_name,$before='',$after=''){

    if(!empty($var_name)){
        echo $before.$var_name.$after;
    }

}
function joy_thumb(){
    global $post;
    $thumbnail_default=joy_img("thumbnail_default");
    if( has_post_thumbnail() ){    //如果有特色缩略图，则输出缩略图地址
        $thumbnail_src = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
        $post_thumbnail_src = $thumbnail_src [0];
    } elseif($thumbnail_default) {
        $post_thumbnail_src = $thumbnail_default;
    }
   // else{
   //    $num=mt_rand(1, 7);
   //    $name=$num.".jpeg";
   //    $post_thumbnail_src = JOY_DEFAULT_IMG_PATH.$name;
   // }
    echo $post_thumbnail_src;
}

?>
