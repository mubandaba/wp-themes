<?php $friend_options=cs_get_option('friend_options')?>
<?php if (!empty($friend_options)):?>
<div class="powered_by_metinfo"> 友情链接:
    <?php foreach ( the4('friend_options') as $value ):?>
    <a href='<?php echo $value['friend_link'];?>' target='_blank'><?php echo $value['friend_title'];?></a>
    <?php endforeach;?>
</div>
<?php endif;?>