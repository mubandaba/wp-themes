<?php

# 加载CSS到<head>中  [Enqueue css]
function JOY_enqueue_styles()
{
    wp_enqueue_style('si-layout-css',       JOY_CSS_PATH ."style.css",              array(), JOY_THEME_VERSION, 'all');
    wp_enqueue_style('si-post-css',         JOY_CSS_PATH ."post.css",               array(), JOY_THEME_VERSION, 'all');
    wp_enqueue_style('si-font-awesome-css', JOY_CSS_PATH ."font-awesome.min.css",   array(), JOY_THEME_VERSION, 'all');
    wp_enqueue_style('si-custom-css', JOY_CSS_PATH ."custom.css",   array(), JOY_THEME_VERSION, 'all');
}

# Add CSS to the theme
add_action('wp_enqueue_scripts', 'JOY_enqueue_styles', 3);


