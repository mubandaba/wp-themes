<?php
# 加载JavaScript到footer [Add JavaScript to footer]
function JOY_enqueue_scripts() {
    wp_deregister_script('jquery');

//加载头部
   wp_enqueue_script( 'jquery' , JOY_JS_PATH . "jquery.js",                  array() , false , false );
   wp_enqueue_script( 'migrate-min' ,JOY_JS_PATH . "jquery-migrate.min.js",      array() , false , false );
   wp_enqueue_script( 'site' ,       JOY_JS_PATH . "site.js",                    array() , false , false );
   wp_enqueue_script( 'app' ,        JOY_JS_PATH . "app.js",                    array() , false , true );

//加载底部



}
# Add JS to the theme
add_action( 'wp_enqueue_scripts' , 'JOY_enqueue_scripts' , 4);
