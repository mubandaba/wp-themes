<?php


/**
 * 添加站点图标
 */
function add_fav(){

    $apple_icon=cs_get_option("apple_icon");
    $favicon=cs_get_option("favicon");

    echo  <<<EOT
<link rel="shortcut icon" href="$favicon" title="Favicon">
<link rel="apple-touch-icon" href="$apple_icon" />   

EOT;

}

add_action('wp_head', 'add_fav');

/**
 * 添加站点图标
 */
function add_pop(){

    require_once( get_stylesheet_directory(). '/static/element/words-pop.php');

}
if(cs_get_option('pop_switcher')==true) {

    add_action('wp_footer', 'add_pop');

}

/**
 * 添加站点图标
 */
function add_nest(){
        $opacity=cs_get_option('nest_opacity')/100;
        $count=cs_get_option('nest_count');


        echo '<script type="text/javascript" color="#000" opacity='.$opacity.' zIndex="-3" count="'.$count.'" src="'.JOY_JS_PATH.'nest.min.js"></script>';
}
if(cs_get_option('nest_switcher')==true) {

    add_action('wp_footer', 'add_nest');
}



