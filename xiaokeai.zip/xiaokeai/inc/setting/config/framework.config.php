<?php if (!defined('ABSPATH')) {
    die;
} // 不能直接访问网页.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// 主题框架设置
// -----------------------------------------------------------------------------------------------
// ===============================================================================================

$settings = array(
    'menu_title' => '主题设置',
    'menu_type' => 'menu', // menu, submenu, options, theme, etc.
    'menu_slug' => 'the4-theme' . '-' . wp_get_theme()->display('Name'),
    'menu_position' => 59,
    'ajax_save' => true,
    'show_reset_all' => false,
    'menu_icon' => 'dashicons-hammer',
    'framework_title' => wp_get_theme()->display('Name') . '<small class="oldVer" data-vs="' . JOY_THEME_VERSION . '" style="color:#979797;margin-left:10px">Release ' . JOY_THEME_VERSION . '</small>',
);
// ---------------------------------------
// 常规  --------------------------------
// ---------------------------------------
$options[] = array(
    'name' => 'overwiew',
    'title' => '常规设置',
    'icon' => 'fa fa-list',
    'fields' => array(

        array(
            'id' => 'logo',
            'type' => 'image',
            'title' => '上传 Logo',
            'help' => '上传您的站点logo <br>（推荐尺寸为:150*150 px）',
            'add_title' => '上传',
        ),
        array(
            'id' => 'favicon',
            'type' => 'image',
            'title' => '上传 Favicon',
            'help' => '上传您的站点logo <br>（尺寸为：60*60 px）',
            'add_title' => '上传',
        ),
        array(
            'id' => 'icp_num',
            'type' => 'text',
            'title' => '备案号',
        ),
        array(
            'id' => 'cp_switcher',
            'type' => 'switcher',
            'title' => '是否隐藏主题作者版权',
        ),

        array(
            'id' => 'thumbnail_default',
            'type' => 'image',
            'title' => '默认缩略图',
        ),

    ),
);
//// ----------------------------------------
//// 公告------------------------------------
//// ----------------------------------------
//$options[] = array(
//    'name' => 'notice',
//    'title' => '公告设置',
//    'icon' => 'fa fa-bullhorn',
//    'fields' => array(
//        array(
//            'type' => 'notice',
//            'class' => 'info',
//            'content' => '公告栏设置',
//        ),
//        array(
//            'id' => 'notice_switcher',
//            'type' => 'switcher',
//            'title' => '公告栏开关',
//            'default' => true,
//        ),
//        array(
//            'id' => 'notice',
//            'type' => 'group',
//            'title' => '添加自定义公告栏',
//            'button_title' => '添加',
//            'accordion_title' => '新添加公告栏',
//            'fields' => array(
//                array(
//                    'id' => 'notice_switcher',
//                    'type' => 'switcher',
//                    'title' => '公告栏内容',
//                    'default' => true,
//                ),
//                array(
//                    'id' => 'notice_content',
//                    'type' => 'textarea',
//                    'title' => '公告栏内容',
//                ),
//                array(
//                    'id' => 'notice_url',
//                    'type' => 'text',
//                    'title' => '链接地址',
//                ),
//            )
//        ),
//    )
//);
// ----------------------------------------
// SEO-------------------------------------
// ----------------------------------------
$options[] = array(
    'name' => 'speed',
    'title' => 'SEO设置',
    'icon' => 'fa fa-server',
    'fields' => array(
        array(
            'type' => 'notice',
            'class' => 'info',
            'content' => 'SEO',
        ),
        array(
            'id' => 'site_seo_switch',
            'type' => 'switcher',
            'title' => '主题自带SEO',
            'help' => '开启后将使用主题自带SEO设置',
            'default' => true
        ),

        array(
            'type' => 'notice',
            'class' => 'info',
            'content' => '全局SEO功能设定',
        ),
        array(
            'id' => 'seo_auto_des',
            'type' => 'switcher',
            'title' => '文章页描述',
            'help' => '开启后将自动截取文章内容作为文章description标签',
            'default' => true
        ),

        array(
            'id' => 'seo_auto_des_num', // this is must be unique
            'type' => 'text',
            'title' => '自动截取字节数',
            'default' => '120',
            'dependency' => array('seo_auto_des', '==', true),
        ),

        array(
            'id' => 'seo_sep', // this is must be unique
            'type' => 'text',
            'title' => 'Title后缀分隔符',
            'default' => ' - ',
        ),

        array(
            'type' => 'notice',
            'class' => 'info',
            'content' => '首页SEO设置',
        ),
        array(
            'id' => 'seo_home_title', // this is must be unique
            'type' => 'text',
            'title' => '首页标题',
            'help' => '关键词使用英文逗号隔开',
        ),

        array(
            'id' => 'seo_home_keywords', // this is must be unique
            'type' => 'text',
            'title' => '首页关键词',
        ),

        array(
            'id' => 'seo_home_desc', // this is must be unique
            'type' => 'textarea',
            'title' => '首页描述',
        ),


    ),
);
// ----------------------------------------
// 文章设置--------------------------------
// ----------------------------------------
$options[] = array(
    'name' => 'article',
    'title' => '文章设置',
    'icon' => 'fa fa-server',
    'fields' => array(

        array(
            'id' => 'share_switcher',
            'type' => 'switcher',
            'title' => '显示分享功能',
            'default' => true,
        ),
        array(
            'id' => 'article_copyright',
            'type' => 'switcher',
            'title' => '显示文章版权',
            'default' => true,
        ),
        array(
            'id' => 'article_support_switcher',
            'type' => 'switcher',
            'title' => '显示打赏功能',
            'default' => true,
        ),

        array(
            'id' => 'article_support_alipay',
            'type' => 'image',
            'title' => '支付宝收款二维码',
            'desc' => '上传支付宝收款二维码图片',
            'dependency' => array("article_support_switcher", "==", "true"),
        ),
        array(
            'id' => 'article_support_wechat',
            'type' => 'image',
            'title' => '微信收款二维码',
            'desc' => '上传微信收款二维码图片',
            'dependency' => array("article_support_switcher", "==", "true"),
        ),
    ),
);
// ----------------------------------------
// 友情链接--------------------------------
// ----------------------------------------
$options[]      = array(
    'name'        => 'friend_links',
    'title'       => '友情链接',
    'icon'        => 'fa fa-external-link-square',
    'fields'      => array(
        array(
            'type'    => 'notice',
            'class'   => 'info',
            'content' => '设置网站的友情链接',
        ),
        array(
            'id'              => 'friend_options',
            'type'            => 'group',
            'title'           => '添加友情链接',
            'button_title'    => '添加友情链接',
            'accordion_title' => '添加友情链接',
            'fields'          => array(
                array(
                    'id'      => 'friend_title',
                    'type'    => 'text',
                    'title'   => '友链名称',
                ),
                array(
                    'id'      => 'friend_link',
                    'type'    => 'text',
                    'title'   => '跳转链接',
                    'desc'    => '需要带上http://(或者https://)',
                ),
            )
        ),
    ),
);
// ----------------------------------------
// 社交信息--------------------------------
// ----------------------------------------
// $options[] = array(
//     'name' => 'follow',
//     'title' => '社交信息',
//     'icon' => 'fa fa-wechat',
//     'fields' => array(
//         // follow us
//
//         array(
//             'id' => 'ma_so_name',
//             'type' => 'text',
//             'default' => 'name',
//             'title' => '昵称',
//         ),
//
//
//         array(
//             'type' => 'notice',
//             'class' => 'success',
//             'content' => '微信公众号设置',
//         ),
//
//         array(
//             'id' => 'i_follow_wechat',
//             'type' => 'upload',
//             'title' => '微信公众号二维码',
//             'default' => get_template_directory_uri() . "/assets/images/wechat_official_account.png",
//             'help' => '上传微信公众号二维码',
//         ),
//
//         array(
//             'id' => 'i_follow_weibo',
//             'type' => 'text',
//             'title' => '微博地址',
//         ),
//         array(
//             'id' => 'i_follow_qq',
//             'type' => 'text',
//             'default' => '164903112',
//             'title' => 'qq号',
//
//             array(
//                 'id' => 'ma_so_bili',
//                 'type' => 'text',
//                 'default' => '#',
//                 'title' => 'bilibili',
//             ),
//
//
//             array(
//                 'id' => 'ma_so_mail',
//                 'type' => 'text',
//                 'default' => '123#345.com',
//                 'title' => '邮箱',
//             ),
//
//
//             array(
//                 'id' => 'ma_so_facebook',
//                 'type' => 'text',
//                 'default' => '#',
//                 'title' => 'facebook',
//             ),
//
//             array(
//                 'id' => 'ma_so_lofter',
//                 'type' => 'text',
//                 'default' => '#',
//                 'title' => 'lofter',
//             ),
//
//             array(
//                 'id' => 'ma_so_qq',
//                 'type' => 'text',
//                 'default' => '#',
//                 'title' => 'QQ',
//             ),
//
//             array(
//                 'id' => 'ma_so_weibo',
//                 'type' => 'text',
//                 'default' => '#',
//                 'title' => '微博',
//             ),
//
//             array(
//                 'id' => 'ma_so_twitter',
//                 'type' => 'text',
//                 'default' => '#',
//                 'title' => 'twitter',
//             ),
//
//             array(
//                 'id' => 'ma_so_zcool',
//                 'type' => 'text',
//                 'default' => '#',
//                 'title' => '站酷',
//             ),
//
//         ),
//     )
// );


// ----------------------------------------
// 小功能 -20171026 上午 wex写
// ----------------------------------------
$options[]      = array(
    'name'        => '小功能',
    'title'       => '小功能',
    'icon'        => 'fa fa-star',

    // begin: fields
    'fields'      => array(
        array(
            'id'    	=> 'pop_switcher',
            'type'      => 'switcher',
            'title'     => '是否开启词汇泡泡功能',
        ),
        array(
            'id'    	=> 'pop_color',
            'type'      => 'color_picker',
            'title'     => '词汇颜色',
            'dependency' => array( 'pop_switcher', '==', 'true' ),

        ),

        array(
            'id'              => 'pop_words',
            'type'            => 'group',
            'title'           => '添加冒泡词汇',
            'button_title'    => '添加',
            'accordion_title' => '添加',
            'dependency' => array( 'pop_switcher', '==', 'true' ),
            'fields'          => array(

                array(
                    'id'      => 'word',
                    'type'    => 'text',
                    'title'   => '冒泡词汇',
                ),



            )
        ),

        array(
            'id'    	=> 'nest_switcher',
            'type'      => 'switcher',
            'title'     => '是否开启背景nest动画',
        ),

        array(
            'id'    	=> 'nest_opacity',
            'type'      => 'number',
            'title'     => '线条透明度',
            'desc'     => '取值范围是0-100',
            'dependency' => array( 'nest_switcher', '==', 'true' ),
        ),
        array(
            'id'    	=> 'nest_count',
            'type'      => 'number',
            'title'     => '线条疏密',
            'desc'     => '取值范围是0-150',
            'dependency' => array( 'nest_switcher', '==', 'true' ),
        ),



    ),
);



// ----------------------------------------
// 自定义代码------------------------------
// ----------------------------------------
$options[] = array(
    'name' => 'code',
    'title' => '自定义',
    'icon' => 'fa fa-code',
    'fields' => array(

        array(
            'class' => 'info',
            'type' => 'notice',
            'content' => '自定义代码',
        ),
        array(
            'id' => 'code_footer',
            'type' => 'textarea',
            'title' => 'footer自定义代码',
            'desc' => '显示在网站版权之前'
        ),
        array(
            'id' => 'code_css',
            'type' => 'textarea',
            'title' => '自定义样式css代码',
            'desc' => '不要添加< style &gt;标签',
        ),
    )
);
// ----------------------------------------
// 备份------------------------------------
// ----------------------------------------
$options[] = array(
    'name' => 'advanced',
    'title' => '备份',
    'icon' => 'fa fa-shield',
    'fields' => array(

        array(
            'type' => 'notice',
            'class' => 'danger',
            'content' => '您可以保存当前的选项，下载一个备份和导入.（此操作会清除网站数据，请谨慎操作）',
        ),

        // 备份
        array(
            'type' => 'backup',
        ),

    )
);


CSFramework::instance($settings, $options);


