<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// METABOX OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options[]    = array(
    'id'        => 'product_options',
    'title'     => '产品详情',
    'post_type' => 'product',
    'context'   => 'normal',
    'priority'  => 'high',
    'sections'  => array(
        array(
            'name'   => 'product_options_section_1',
            'fields' => array(
                array(
                    'id'        => 'product_main_gallery',
                    'type'      => 'gallery',
                    'add_title' => '添加产品主图片集',
                    'edit_title'=> '编辑产品主图片集（调整顺序）',
                    'title'     => '产品主图片集',
                ),
                array(
                    'id'        => 'product_description',
                    'type'      => 'textarea',
                    'title'     => '产品描述',
                    'desc'      => ''
                ),
                array(
                    'id'        => 'product_xq',
                    'type'      => 'wysiwyg',
                    'title'     => '产品详情',
                    'desc'      => ''
                ),
            ),
        ),
        array(
            'name'  => 'post_seo',
            'title' => 'SEO 设置',
            'icon'  => 'fa fa-magic',
            'fields' => array(
                array(
                    'id'    => 'seo_custom_title', // this is must be unique
                    'type'  => 'text',
                    'title' => '自定义标题',
                    'help'  => '留空则调用默认全局SEO设置'
                ),
                array(
                    'id'    => 'seo_custom_keywords', // this is must be unique
                    'type'  => 'text',
                    'title' => '自定义关键词',
                    'help'  => '留空则调用默认全局SEO设置'
                ),
                array(
                    'id'    => 'seo_custom_desc', // this is must be unique
                    'type'  => 'textarea',
                    'title' => '自定义描述',
                    'help'  => '留空则调用默认全局SEO设置'
                ),
            ),
        ),
    ),
);
$options[]    = array(
    'id'        => 'page_options',
    'title'     => '页面设置',
    'post_type' => 'page',
    'context'   => 'normal',
    'priority'  => 'high',
    'sections'  => array(
        array(
            'name'   => 'page_options_section',
            'fields' => array(
                array(
                    'id'        => 'page_banner',
                    'type'      => 'image',
                    'title'     => '上传背景图片',
                ),
            ),
        ),
        array(
            'name'  => 'post_seo',
            'title' => 'SEO 设置',
            'icon'  => 'fa fa-magic',
            'fields' => array(
                array(
                    'id'    => 'seo_custom_title', // this is must be unique
                    'type'  => 'text',
                    'title' => '自定义标题',
                    'help'  => '留空则调用默认全局SEO设置'
                ),
                array(
                    'id'    => 'seo_custom_keywords', // this is must be unique
                    'type'  => 'text',
                    'title' => '自定义关键词',
                    'help'  => '留空则调用默认全局SEO设置'
                ),
                array(
                    'id'    => 'seo_custom_desc', // this is must be unique
                    'type'  => 'textarea',
                    'title' => '自定义描述',
                    'help'  => '留空则调用默认全局SEO设置'
                ),
            ),
        ),
    ),
);
$options[]    = array(
    'id'        => 'post_options',
    'title'     => '文章设置',
    'post_type' => 'post',
    'context'   => 'normal',
    'priority'  => 'high',
    'sections'  => array(

        array(
            'name'  => 'post_seo',
            'title' => 'SEO 设置',
            'icon'  => 'fa fa-magic',
            'fields' => array(
                array(
                    'id'    => 'seo_custom_title', // this is must be unique
                    'type'  => 'text',
                    'title' => '自定义标题',
                    'help'  => '留空则调用默认全局SEO设置'
                ),
                array(
                    'id'    => 'seo_custom_keywords', // this is must be unique
                    'type'  => 'text',
                    'title' => '自定义关键词',
                    'help'  => '留空则调用默认全局SEO设置'
                ),
                array(
                    'id'    => 'seo_custom_desc', // this is must be unique
                    'type'  => 'textarea',
                    'title' => '自定义描述',
                    'help'  => '留空则调用默认全局SEO设置'
                ),
            ),
        ),
    ),
);


CSFramework_Metabox::instance( $options );
