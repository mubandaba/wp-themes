
<!--右侧开始-->
<div class="col-md-3">
    <div class="row">
        <div class="panel product-hot">
            <div class="panel-body">
                <h4 class="example-title">热门推荐</h4>
                <div class="row">
                    <?php
                        $QueryBySwitcher=new WP_Query(array(
                            'post_type'  =>'product',
                            'showposts'  => 5,
                            'meta_query' => array(
                            'key'        => 'putToSideBar',
                            'value'      => 'true'
                            )
                        ));
                        if($QueryBySwitcher->have_posts()):while($QueryBySwitcher->have_posts()):$QueryBySwitcher->the_post();
                    ?>
                    <div class="product-hot-list col-md-12 col-sm-4 col-xs-4 text-center margin-bottom-10">
                        <a href="<?php the_permalink()?>" class="img" title="<?php the_title()?>">
                            <img data-original="<?php the4_thumb()?>"
                                 class="img-responsive" style='height:250px' alt="<?php the_title()?>">
                        </a>
                        <a href="<?php the_permalink()?>"
                           class="txt" title="<?php the_title()?>"><?php the_title()?>
                        </a>
                    </div>
                    <?php endwhile;endif;?>
                </div>
            </div>
        </div>
    </div>
</div>
<!--右侧结束-->