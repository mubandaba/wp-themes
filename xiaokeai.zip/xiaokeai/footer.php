<!-- FOOTER -->
<?php
if(is_home()||is_front_page()){
    include "static/element/footer-index.php";
}
wp_footer();
?>

</body>
</html>



