<?php get_header();?>
<?php while( have_posts() ): the_post(); ?>


    <div class="wrapper">

    <article class="post">





        <h1 class="post-title" style="text-align: center"><?php the_title();?></h1>

        <div class="post-content">
            <?php the_content(); ?>
        </div>

        <div class="post-tags"><?php the_tags('', ' '); ?></div>

        <?php if(cs_get_option('share_switcher')== true){
            include "static/element/share.php";
        } ?>

    </article>


    <footer class="footer-single" role="contentinfo" style="text-align: right;padding-top: 1rem;margin-bottom: 2rem">
        <div class="footer-copyright" style="text-align: right;padding-top: 0" >
            <?php the_author()?>&nbsp;⋅&nbsp;<?php the_time("Y-n-j")?>
        </div>
    </footer>


<?php endwhile; ?>
    <script>
        $('.wechat').click(function () {
            $(".qr-container").addClass("active");
        })
    </script>
<?php get_footer();?>