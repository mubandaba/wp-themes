<?php get_header();?>
<?php while( have_posts() ): the_post(); ?>


<header class="site-header" role="banner" style="background-image: url('<?php joy_thumb();?>');"></header>

<div class="wrapper">

    <article class="post">





        <h1 class="post-title" style="text-align: center"><?php the_title();?></h1>
        <div class="post-content">
                <?php the_content(); ?>

        </div>

        <div class="post-tags"><?php the_tags('', ' '); ?></div>

        <?php if(cs_get_option('share_switcher')== true){
            include "static/element/share.php";
        } ?>

    </article>

<?php if(cs_get_option("article_copyright")):?>
    <div class="post_copyright">
        转载原创文章请注明，转载自: <?php bloginfo("name")?> - <?php the_title();?> (<?php the_permalink()?>)
    </div>
<?php endif;?>


<?php if(cs_get_option("article_support_switcher")):?>

    <div class="pay_container">
        <button class="pay-switcher">
            <i class="fa fa-rmb"></i>
        </button>
        <div class="pay_qr_container">
            <div class="alipay">
                <img src="<?php echo joy_img("article_support_alipay")?>">
                <div>支付宝</div>
            </div>
            <div class="wechat">
                <img src="<?php echo joy_img("article_support_wechat")?>">
                <div>微信</div>

            </div>
        </div>
    </div>
<?php endif;?>


    <footer class="footer-single" role="contentinfo" style="text-align: right;padding-top: 1rem;margin-bottom: 2rem">
        <div class="footer-copyright" style="text-align: right;padding-top: 0" >
            <?php the_author()?>&nbsp;⋅&nbsp;<?php the_time("Y-n-j")?>
        </div>
    </footer>


<?php endwhile; ?>

<?php get_footer();?>