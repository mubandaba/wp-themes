<!--侧边栏在这开始-->
				<div id="sidebar" class="clear fix">
		<div class="listItem">
                <?php if ( !function_exists('dynamic_sidebar')
        || !dynamic_sidebar() ) : ?>

		  <div id="secondary" class="widget-area" role="complementary">
		</div>
        <?php endif; ?>
</div>
   </div>
  </div>
                  <!--侧边栏在这结束-