<div id="footer">
               	<div class="main">
               	   <div class="inside clearfix">
               	   <div class="newcopy">
               	   Copyright © 2013-2014 U设计 All Rights Reserved.<br>
               	   Designed by <a href="<?php echo get_option('home'); ?>"><?php bloginfo('name'); ?></a>.Our <a href="<?php bloginfo('url');?>/sitemap.html" target="_blank">Sitemap</a>.<?php timer_stop(1); ?><br>
               	   QQ群：646471</div><!--newcopy-->
               	    </div>
               	    </div>
               	    </div>
</body></html>