<?php get_header();?>
        <div id="middle" class="clearfix">
        
        	<div id="inner">
            	<div id="content">
                <?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>
<div class="post small odd">
                        	<div class="inside">
                        <div class="listImage">
                        <div style="height:140px; width:100%">
                                                  <a href="<?php the_permalink() ?>"><img alt="<?php the_title_attribute(); ?>"

class="qq"

src="<?php echo hot_thumbnail_image() ?>"

/></a></div><!--结束调取缩略图-->
                        </div>
                        
                        <h2><a href="<?php the_permalink() ?>"><?php the_title_attribute(); ?></a></h2><!--调出日志标题-->
                        <div class="meta clearfix">
                        <?php the_author_posts_link(); ?>/
						<?php the_time('Y-m-d') ?>/
<?php the_category(', ') ?>
                        </div>
                        <p><?php the_excerpt("Read More..."); ?></p>
                        <p class="moreLink"><a href="<?php the_permalink() ?>" target="_blank">[ 查看全部 ]</a></p>
                        <p></p> <!--调出日志内容-->
                        
							</div>
                            
                            </div>
                                                    <?php endwhile; ?>
<?php else : ?>


            	<h2>未查找到相关结果</h2>


<?php endif; ?>

                            
            <div class="pagination clearfix">
                        	<div class="wp-pagenavi">
                            <div class="page_navi"><?php par_pagenavi(9); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!--侧边栏在这开始-->
			<?php get_sidebar();?>
                  <!--侧边栏在这结束-->
 </div>
</div>
        <!--底部文件开始-->
<?php get_footer();?>