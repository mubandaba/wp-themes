<?php get_header();?>
		<div id="middle" class="clearfix">
        
            	<div id="inner">
       <a href="<?php bloginfo('url');?>"><img src="<?php bloginfo('template_url');?>/images/404.png" alt="CU设计404页面" height="583px" width="1020px"></a>
       	  </div>
                
            
            <!--sildebar here-->
       
      </div>
<?php get_footer();?>