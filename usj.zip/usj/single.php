<?php get_header();?>
		<div id="middle" class="clearfix">
        	<div id="inner">
            	<div id="content">
               	  <div class="txtCon">
                                
    	<article class="" id="post-21231">
        	<header class="article-title">
            	<h2 class="myh2"><?php the_title_attribute(); ?></h2>
                <div class="article-info clearfix">
                
                     <div class="meta clearfix">
                  <?php the_time('Y,m,d') ?>/<?php the_category(', ') ?>
                  </div>
                  
                  <!-- 博客相关属性 -->
            </div>
            </header>
<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>
            <div class="article-text">
				<p><?php the_content("Read More..."); ?></p>
<div style="clear:both; margin-top:5px; margin-bottom:5px;"></div><div style="float:left"><!-- JiaThis Button BEGIN -->

<div id="jiathis_style_32x32">
<!--分享代码-->
<div class="bdsharebuttonbox"><a href="#" class="bds_more" data-cmd="more"></a><a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a><a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a><a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a><a href="#" class="bds_renren" data-cmd="renren" title="分享到人人网"></a><a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a></div>
<script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"0","bdSize":"32"},"share":{},"selectShare":{"bdContainerClass":null,"bdSelectMiniList":["qzone","tsina","tqq","renren","weixin"]}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script>
<!--分享代码-->
</div>
<script type="text/javascript" src="./images/jia.js" charset="utf-8"></script>
<!-- JiaThis Button END --></div><div style="clear:both; margin-top:5px; margin-bottom:5px;"></div><div style="clear:both;"></div>                                
            </div>
          <?php endwhile; ?>
<?php else : ?>
<?php endif; ?>
        </article>
        

		
			<div id="comments">



								<div id="respond" class="comment-respond">						
<?php comments_template(); ?>
							</div><!-- #respond -->
			
</div><!-- #comments -->
        
        
                  </div>
                  
            </div>
			<?php get_sidebar();?>
	</div><!--解决IE8问题的标签-->
            <!--sildebar here-->
</div>
</div>
  
     <?php get_footer();?>