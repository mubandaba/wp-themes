<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php bloginfo( 'charset' ); ?>" />
<link rel="shortcut icon" href="/favicon.ico" mce_href="/favicon.ico" type="image/x-icon">
<title><?php if (is_home()||is_search()) { bloginfo('name'); } else { wp_title(''); print " - "; bloginfo('name'); } ?> </title>
<meta name="description" content="描述">
<meta name="keywords" content="关键词">
<link href="<?php bloginfo( 'stylesheet_url' ); ?>" rel="stylesheet" type="text/css">
<style>
             #top{
				 						position:fixed;
bottom:10px;
right:15px;
cursor:pointer;
opacity:0.4;
height=45px;
 width=45px;
z-index:99999				}
		#top:hover{
			position:fixed;
bottom:10px;
right:15px;
cursor:pointer;
opacity:1.0;
height=45px;
 width=45px;
z-index:99999		}
             </style>
<?php wp_head(); ?>
</head>
<body id="J_body">
	<div class="container">
		<div class="header clearfix">
        	<div class="inside">
            	<div class="logo"><h1><a href="<?php echo get_option('home'); ?>"><img src="<?php bloginfo('template_url');?>/images/logo.png" width="136" height="37" alt="U设计"></a> </h1></div>
                <div class="right">
                	<div class="searchBox sidebarBox">
                    <div style="float: left">
                    <form id="search" action="<?php bloginfo('url'); ?>/" target="_blank">
<input id="s" name="s"  class="searchInput"  style="border-style:none" type="text" value="<?php the_search_query(); ?>"/>
</form>
</div>
<div style="float: left;"> <a href="<?php bloginfo('url'); ?>/wp-admin"><img src="<?php bloginfo('template_url');?>/images/denglu.jpg"></a></div>
</div>
                    <div class="other clearfix">
                    	<ul>
                        	<li><a href="#"><img src="<?php bloginfo('template_url');?>/images/ico_weix.png" width="38" height="38"></a></li>
                            <li><a href="#" target="_blank"><img src="<?php bloginfo('template_url');?>/images/ico_header.png" width="38" height="38"></a></li>
                            <li><a href="mailto:admin@yunrui.co"><img src="<?php bloginfo('template_url');?>/images/ico_email.png" width="38" height="38"></a></li>
                        </ul>
                    </div>
                </div>
        	</div>
        </div>
