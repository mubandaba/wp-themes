<?php 
/*
 	template name: 标签云
*/
get_header();
?>
<div class="main">
<h1 style="color:#333;border-bottom:1px dashed #333;height:40px;text-align:center;">标签云</h1>
<div style="text-align:center;height:30px;">
发布：<?php the_time('Y-m-d H:i') ?> &nbsp; 标签云All Tags &nbsp; 阅读：<?php post_views('', '次'); ?> &nbsp; 标签：<?php echo $count_tags = wp_count_terms('post_tag'); ?>个 &nbsp; <?php edit_post_link('编辑', ' [ ', ' ] '); ?>
</div>
	<ul class="tag-clouds">
		<?php $tags_list = get_tags('orderby=count&order=DESC');
		if ($tags_list) { 
			foreach($tags_list as $tag) {
				echo '<li><a class="tag-link" href="'.get_tag_link($tag).'">'. $tag->name .'</a><strong>'. $tag->count .'+</strong><p class="tag-posts">'; 
				$posts = get_posts( "tag_id=". $tag->term_id ."&numberposts=1" );
				if( $posts ){
					foreach( $posts as $post ) {
						setup_postdata( $post );
						echo '<a href="'.get_permalink().'">'.get_the_title().'</a></p><div style="float: right;">'.get_the_time('Y-m-d').'</div>';
					}
				}
				echo '</li>';
			} 
		} 
		?>
	</ul>
</div>
</div>
<?php get_footer(); ?>