<?php
/* 
Theme: Gsky Pro
Name: 天空团Gsky Pro主题
Site: http://www.gsky.org
*/
include('option/theme.php');

function dopt($e){
    return stripslashes(get_option($e));
}
    //定义菜单
    if (function_exists('register_nav_menus')){
        register_nav_menus( array(
            'nav' => __('站点导航'),
            'menu' => __('贴边菜单')
        ) );
    }

//去除头部冗余代码
remove_action( 'wp_head',   'feed_links_extra', 3 ); // 额外的feed,例如category, tag页
remove_action( 'wp_head',   'rsd_link' ); //额外的RSD
remove_action( 'wp_head',   'wlwmanifest_link' ); //离线编辑接口
remove_action( 'wp_head',   'index_rel_link' ); //当前文章的索引
remove_action( 'wp_head',   'start_post_rel_link', 10, 0 ); 
remove_action( 'wp_head',   'wp_generator' ); 
//取消标点符号转义
remove_filter('the_content', 'wptexturize');
//取消登录错误提示
add_filter('login_errors', create_function('$a', "return null;"));
//添加特色缩略图支持
if ( function_exists('add_theme_support') )add_theme_support('post-thumbnails');
//隐藏版本更新提示 - 注！
add_filter('pre_site_transient_update_core', create_function('$a', "return null;"));
//评论贴图
function embed_images($content) {
  $content = preg_replace('/\[img=?\]*(.*?)(\[\/img)?\]/e', '"<img src=\"$1\" alt=\"" . basename("$1") . "\" />"', $content);
  return $content;
}
add_filter('comment_text', 'embed_images');
//自定义登录页面LOGO
function custom_login_logo() { echo '<style type="text/css">h1 a{background-image:url('.get_bloginfo('template_directory').'/images/logo.png) !important; background-size: auto !important;height:0;width:0; !important;}</style>';}
add_action('login_head', 'custom_login_logo');
//获取缩略图地址
if ( function_exists('add_theme_support') )
 add_theme_support('post-thumbnails');
 function catch_first_image() {
  global $post, $posts;
  $first_img = '';
  ob_start();
  ob_end_clean();
  $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
  $first_img = $matches [1] [0];
  if(empty($first_img)){
		$random = mt_rand(1, 10);
		echo get_bloginfo ( 'stylesheet_directory' );
		echo '/images/thumbnail.png';//指定一张图
		//echo '/images/random/sky'.$random.'.jpg';//10张随机图片(图片自备)
  }
  return $first_img;
 }

//分页
function pagination($query_string){
global $posts_per_page, $paged;
$my_query = new WP_Query($query_string ."&posts_per_page=-1");
$total_posts = $my_query->post_count;
if(empty($paged))$paged = 1;
$prev = $paged - 1;							
$next = $paged + 1;	
$range = 3; // 显示分页链接个数
$showitems = ($range * 2)+1;
$pages = ceil($total_posts/$posts_per_page);
if(1 != $pages){
	echo "<div class='pagination'>";
	echo ($paged > 2 && $paged+$range+100 > $pages && $showitems < $pages)? "<a href='".get_pagenum_link(1)."' class='fir_las'>最前</a>":"";
	for ($i=1; $i <= $pages; $i++){
	if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems )){
	echo ($paged == $i)? "<span class='current'>".$i."</span>":"<a href='".get_pagenum_link($i)."' class='inactive' >".$i."</a>"; 
	}
	}
	echo ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) ? "<a href='".get_pagenum_link($pages)."' class='fir_las'>最后</a>":"";
	echo "</div>\n";
	}
}

//修改评论表情默认路径
function theme_smilies_src ($img_src, $img, $siteurl){
return get_bloginfo('template_directory').'/images/smilies/'.$img;
}
add_filter('smilies_src','theme_smilies_src',1,10); 
//阻止站内文章互相Pingback 
function theme_noself_ping( &$links ) {
  $home = get_option( 'home' );
  foreach ( $links as $l => $link )
  if ( 0 === strpos( $link, $home ) )
  unset($links[$l]);   
}
add_action('pre_ping','theme_noself_ping');
//禁止自动保存修订版
function theme_disable_autosave() {
  wp_deregister_script('autosave');
}
add_action('wp_print_scripts','theme_disable_autosave' );
remove_action('pre_post_update','wp_save_post_revision' );
//垃圾评论拦截
class anti_spam {
  function anti_spam() {
if ( !current_user_can('level_0') ) {
  add_action('template_redirect', array($this, 'w_tb'), 1);
  add_action('init', array($this, 'gate'), 1);
  add_action('preprocess_comment', array($this, 'sink'), 1);
    }
  }
  function w_tb() {
    if ( is_singular() ) {
      ob_start(create_function('$input','return preg_replace("#textarea(.*?)name=([\"\'])comment([\"\'])(.+)/textarea>#",
      "textarea$1name=$2w$3$4/textarea><textarea name=\"comment\" cols=\"100%\" rows=\"4\" style=\"display:none\"></textarea>",$input);') );
    }
  }
  function gate() {
    if ( !empty($_POST['w']) && empty($_POST['comment']) ) {
      $_POST['comment'] = $_POST['w'];
    } else {
      $request = $_SERVER['REQUEST_URI'];
      $referer = isset($_SERVER['HTTP_REFERER'])         ? $_SERVER['HTTP_REFERER']         : '隐瞒';
      $IP      = isset($_SERVER["HTTP_X_FORWARDED_FOR"]) ? $_SERVER["HTTP_X_FORWARDED_FOR"] . ' (透过代理)' : $_SERVER["REMOTE_ADDR"];
      $way     = isset($_POST['w'])                      ? '手动操作'                       : '未经评论表格';
      $spamcom = isset($_POST['comment'])                ? $_POST['comment']                : null;
      $_POST['spam_confirmed'] = "请求: ". $request. "\n来路: ". $referer. "\nIP: ". $IP. "\n方式: ". $way. "\n內容: ". $spamcom. "\n -- 已记录在案 --";
    }
  }
  function sink( $comment ) {
    if ( !empty($_POST['spam_confirmed']) ) {
      if ( in_array( $comment['comment_type'], array('pingback', 'trackback') ) ) return $comment;
      //方法一: 直接挡掉, 將 die(); 前面两斜线刪除即可.
      die();
      //方法二: 标记为 spam, 留在资料库检查是否误判.
      //add_filter('pre_comment_approved', create_function('', 'return "spam";'));
      //$comment['comment_content'] = "[ 小墙判断这是 Spam! ]\n". $_POST['spam_confirmed'];
    }
    return $comment;
	  }
	}
	$anti_spam = new anti_spam();
//屏蔽纯英文留言//英文留言会导致主题错位
function scp_comment_post( $incoming_comment ) {
$pattern = '/[一-龥]/u';
if(!preg_match($pattern, $incoming_comment['comment_content'])) {
die();//直接挡掉，无提示
}
return( $incoming_comment );
}
add_filter('preprocess_comment', 'scp_comment_post');
//提高搜索结果相关性
if(is_search()){ 
add_filter('posts_orderby_request', 'search_orderby_filter');
}
function search_orderby_filter($orderby = ''){
	global $wpdb;
	$keyword = $wpdb->prepare($_REQUEST['s']);
	return "((CASE WHEN {$wpdb->posts}.post_title LIKE '%{$keyword}%' THEN 2 ELSE 0 END) + (CASE WHEN {$wpdb->posts}.post_content LIKE '%{$keyword}%' THEN 1 ELSE 0 END)) DESC, 
{$wpdb->posts}.post_modified DESC, {$wpdb->posts}.ID ASC";
}
//默认编辑器增强
 function enable_more_buttons($buttons) {   
     $buttons[] = 'hr';   
     $buttons[] = 'del';   
     $buttons[] = 'sub';   
     $buttons[] = 'sup';    
     $buttons[] = 'fontselect';   
     $buttons[] = 'fontsizeselect';   
     $buttons[] = 'cleanup';      
     $buttons[] = 'styleselect';   
     $buttons[] = 'wp_page';   
     $buttons[] = 'anchor';   
     $buttons[] = 'backcolor';   
     return $buttons;   
     }   
add_filter("mce_buttons_3", "enable_more_buttons");  

//评论邮件通知
function comment_mail_notify($comment_id) {
$comment = get_comment($comment_id);
$parent_id = $comment->comment_parent ? $comment->comment_parent : '';
$spam_confirmed = $comment->comment_approved;
if (($parent_id != '') && ($spam_confirmed != 'spam')) {
$wp_email = 'no-reply@' . preg_replace('#^www\.#', '', strtolower($_SERVER['SERVER_NAME']));//发件人e-mail地址
$to = trim(get_comment($parent_id)->comment_author_email);
$subject = '您在 [' . get_option("blogname") . '] 的留言有了回應';
$message = '
<div style="background-color:#fff; border:1px solid #666666; color:#111;
-moz-border-radius:8px; -webkit-border-radius:8px; -khtml-border-radius:8px;
border-radius:8px; font-size:12px; width:702px; margin:0 auto; margin-top:10px;
font-family:微软雅黑, Arial;">
<div style="background:#666666; width:100%; height:60px; color:white;
-moz-border-radius:6px 6px 0 0; -webkit-border-radius:6px 6px 0 0;
-khtml-border-radius:6px 6px 0 0; border-radius:6px 6px 0 0; ">
<span style="height:60px; line-height:60px; margin-left:30px; font-size:12px;">
您在<a style="text-decoration:none; color:#00bbff;font-weight:600;"
href="' . get_option('home') . '">' . get_option('blogname') . '
</a>博客上的留言有回复啦！</span></div>
<div style="width:90%; margin:0 auto">
<p>' . trim(get_comment($parent_id)->comment_author) . ', 您好!</p>
<p>您曾在 [' . get_option("blogname") . '] 的文章
《' . get_the_title($comment->comment_post_ID) . '》 上发表评论:
<p style="background-color: #EEE;border: 1px solid #DDD;
padding: 20px;margin: 15px 0;">' . nl2br(get_comment($parent_id)->comment_content) . '</p>
<p>' . trim($comment->comment_author) . ' 给您的回复如下:
<p style="background-color: #EEE;border: 1px solid #DDD;padding: 20px;
margin: 15px 0;">' . nl2br($comment->comment_content) . '</p>
<p>您可以点击 <a style="text-decoration:none; color:#00bbff"
href="' . htmlspecialchars(get_comment_link($parent_id)) . '">查看回复的完整內容</a></p>
<p>欢迎再次光临 <a style="text-decoration:none; color:#00bbff"
href="' . get_option('home') . '">' . get_option('blogname') . '</a></p>
<p>(此邮件由系统自动发出, 请勿回复.)</p>
</div>
</div>';
$from = "From: \"" . get_option('blogname') . "\" <$wp_email>";
$headers = "$from\nContent-Type: text/html; charset=" . get_option('blog_charset') . "\n";
wp_mail( $to, $subject, $message, $headers );
//echo 'mail to ', $to, '<br/> ' , $subject, $message; // for testing
}
}
add_action('comment_post', 'comment_mail_notify');

//文章阅读次数统计与调用
function record_visitors(){
if (is_singular()){
global $post;
$post_ID = $post->ID;
if($post_ID){
$post_views = (int)get_post_meta($post_ID, 'views', true);
if(!update_post_meta($post_ID, 'views', ($post_views+1))){
add_post_meta($post_ID, 'views', 1, true);
}}}}
add_action('wp_head', 'record_visitors');
function post_views($before = '(', $after = ')', $echo = 1)
{
global $post;
$post_ID = $post->ID;
$views = (int)get_post_meta($post_ID,'views', true);
if ($echo) echo $before, number_format($views), $after;
else return $views;
}

//自定义头像
add_filter( 'avatar_defaults', 'fb_addgravatar' );
function fb_addgravatar( $avatar_defaults ) {
$myavatar = get_bloginfo('template_directory') . '/images/gravatar.jpg';
  $avatar_defaults[$myavatar] = '自定义头像';
  return $avatar_defaults;
}
//楼层/回复/头像缓存
function gsky_comment($comment, $args, $depth) {
   $GLOBALS['comment'] = $comment;
global $commentcount,$wpdb, $post;
     if(!$commentcount) { //初始化楼层计数器
          $comments = $wpdb->get_results("SELECT * FROM $wpdb->comments WHERE comment_post_ID = $post->ID AND comment_type = '' AND comment_approved = '1' AND !comment_parent");
          $cnt = count($comments);//获取主评论总数量
          $page = get_query_var('cpage');//获取当前评论列表页码
          $cpp=get_option('comments_per_page');//获取每页评论显示数量
         if (ceil($cnt / $cpp) == 1 || ($page > 1 && $page  == ceil($cnt / $cpp))) {
             $commentcount = $cnt + 1;//如果评论只有1页或者是最后一页，初始值为主评论总数
         } else {
             $commentcount = $cpp * $page + 1;
         }
     }
?>
<li <?php comment_class(); ?> id="comment-<?php comment_ID() ?>">
   <div id="div-comment-<?php comment_ID() ?>" class="comment-body">
      <?php $add_below = 'div-comment'; ?>
		<div class="comment-author vcard">
			<?php $f = md5(strtolower($comment->comment_author_email)); ?>
			<img src='http://www.gravatar.com/avatar/<?php echo $f ?>?s=42&d=&r=G' alt='' class='avatar' />
                <?php { echo ''; } ?>
					<div class="floor">
					<span style="color:yellowgreen;"><?php
 if(!$parent_id = $comment->comment_parent){
   switch ($commentcount){
     case 2 :echo "高富帅！";--$commentcount;break;
     case 3 :echo "老二真二";--$commentcount;break;
     case 4 :echo "又见小三";--$commentcount;break;
     default:printf('%1$s楼', --$commentcount);
   }
 }
 ?>　　</span>
 
 <span class="datetime"><?php comment_date('Y-m-d H:i') ?>　<?php get_author_class($comment->comment_author_email,$comment->user_id)?>
					<?php edit_comment_link('[编辑]','&nbsp;','&nbsp;'); ?>
					
					</span>
         </div><spans><?php comment_author_link() ?><?php if(user_can($comment->user_id, 1)){echo "<a title='认证用户' class='vip'></a>";}; ?></spans>:</div>
		<div style="padding: 0 0px 0 22px;width:460px;"><?php if ( $comment->comment_approved == '0' ) : ?></div>
			<span style="color:#C00; font-style:inherit">你提交的神马东西，还要我亲自检查...</span>
			<br />			
		<?php endif; ?>
		<?php comment_text() ?>
        
		<div class="clear"></div>
		
  </div>
  <span class="reply"><?php comment_reply_link(array_merge( $args, array('reply_text' => '回复', 'add_below' =>$add_below, 'depth' => $depth, 'max_depth' => $args['max_depth']))); ?></span>
<?php
}
function gsky_end_comment() {
		echo '</li>';
}
//img图像缓冲加载
add_filter('the_content','lazyload');
function lazyload($content){
if(!is_feed()){
$content=preg_replace(
'/<img(.+)scr=[\'"]([^\'"]+)[\'"](.*)>/i',
"<img\$1data-origina=\"\$2\"scr=\"get_bloginfo('template_directory'). loading.gif\"\$3>\n<noscript>\$0</noscript>",
$content);}
return $content;}

//HTTP响应拆分漏洞   
$redirect = trim(str_replace("\r","",str_replace("\r\n","",strip_tags(str_replace("'","",str_replace("\n", "", str_replace(" ","",str_replace("\t","",trim($redirect))))),""))));

//获取当前网页的完整URL
function curPageURL(){
    $pageURL = 'http';
    if ($_SERVER["HTTPS"] == "on"){$pageURL .= "s";}
    $pageURL .= "://";
    if ($_SERVER["SERVER_PORT"] != "80"){$pageURL .= $_SERVER["SERVER_NAME"] . ":" . $_SERVER["SERVER_PORT"] . $_SERVER["REQUEST_URI"];}
    else{$pageURL .= $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"];}
    return $pageURL;}

//获取访客VIP样式
function get_author_class($comment_author_email,$user_id){
global $wpdb;
$author_count = count($wpdb->get_results(
"SELECT comment_ID as author_count FROM $wpdb->comments WHERE comment_author_email = '$comment_author_email' "));
/*如果不需要管理员显示VIP标签，就把下面一行的“//”去掉*/
//$adminEmail = get_option('admin_email');if($comment_author_email ==$adminEmail) return;
if($author_count>=10 && $author_count<20)
echo '<a class="vip1" title="评论达人 LV.1"></a>';
else if($author_count>=20 && $author_count<100) 
echo '<a class="vip2" title="评论达人 LV.2"></a>';
else if($author_count>=100 && $author_count<200)
echo '<a class="vip3" title="评论达人 LV.3"></a>'; 
else if($author_count>=200 && $author_count<300) 
echo '<a class="vip4" title="评论达人 LV.4"></a>'; 
else if($author_count>=300 &&$author_count<450) 
echo '<a class="vip5" title="评论达人 LV.5"></a>'; 
else if($author_count>=450 && $author_count<700) 
echo '<a class="vip6" title="评论达人 LV.6"></a>'; 
else if($author_count>=1000) 
echo '<a class="vip7" title="评论达人 LV.7"></a>'; 
}

///设置结束。

?>