<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8" />
<meta content="width=device-width,initial-scale=1.0,maximum-scale=1.0,minimum-scale=1.0,user-scalable=no" name="viewport">
<?php include('inc/seo.php'); ?>
<?php wp_head(); ?>
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/style.css" media="all" />
<script src="<?php bloginfo('template_url'); ?>/js/jquery.min.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/func.js"></script>

<?php if ( is_singular() ){ ?>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/comments-ajax.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/gravatar.js"></script>
<?php };if ( dopt('sky_pajax_b' )!=='' ) { ?>
<?php if ( is_singular()&&!is_page() ){ ?>
<![if !IE]>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/singular.js"></script>
<![endif]>
<?php }?><?php } ?>
<script type="text/javascript" src="<?php bloginfo('template_directory');?>/js/lazyload.js"></script>
<script type="text/javascript">
jQuery(function() {          
jQuery("img").not("#respond_box img").lazyload({
placeholder:"<?php bloginfo('template_url'); ?>/images/image.gif",
effect:"fadeIn",threshold:-50});});
</script>
<?php flush(); //顶部预加载 ?>
</head>
<body class="inner-page">
<div class="wrapper-holder">
<div id="wrapper">
<div id="header">
<div class="header-area">
<ul id="nav">
<?php echo str_replace("</ul></div>", "", ereg_replace("<div[^>]*><ul[^>]*>", "", wp_nav_menu(array('theme_location' => 'nav', 'echo' => false)) )); ?>
</ul>
</div>
<div class="toplogo">
<a href="<?php bloginfo('siteurl'); ?>" title="<?php bloginfo('name'); ?> - <?php bloginfo('description'); ?>"><div class="logo"></div></a>
</div>
<div class="search-form">
<form method="get" action="<?php bloginfo('siteurl'); ?>">
<input type="text" value="" name="s" id="s" placeholder="噼里啪啦。。" class="txt-field" x-webkit-speech/>
<input class="search-submit" type="submit" value="　搜索　">
</form>
</div>

</div>
<!-- /header -->