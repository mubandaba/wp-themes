<?php get_header(); ?>
<div id="content" class="right_sidebar">
<div class="inner" style="padding-bottom: 447px;">
<div class="general_content">
<div class="main_content">
<div class="block_breadcrumbs" style="_display:none;">
<div class="text"><p>正在阅读：</p></div>
<ul>
<li><?php the_category(', '); ?></li><li><?php the_title(); ?></li>
</ul><span><a href="/random">探索发现</a></span></div>
<div class="separator" style="height:10px;_display:none;"></div>
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<h2 style="_border-bottom:5px solid #AAA;color:#333;height:30px;text-align:center;"><?php the_title(); ?></h2>
<div class="saysays" style="margin-top:-2px;"></div>
<div class="info" style="text-align:center;">
作者：<?php the_author() ?> &nbsp; 发布：<?php the_time('Y-m-d H:i') ?> &nbsp; 栏目：<?php the_category(', ') ?> &nbsp; 阅读：<?php post_views('', '次'); ?> &nbsp; <?php comments_popup_link ('抢沙发','1条评论','%条评论'); ?> &nbsp; <?php edit_post_link('编辑', ' [ ', ' ] '); ?>
</div>
<div style="height:10px;_display:none;"></div>
<div class="context">
<?php the_content('Read more...'); ?><hr style="border-top: 1px solid #666;"><p>本文固定链接: <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_permalink() ?> | <?php bloginfo('name');?></a>
<!-- Baidu Button BEGIN -->
<div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare">
<a class="bds_tsina">新浪微博</a>
<a class="bds_qzone">QQ空间</a>
<a class="bds_tqq">腾讯微博</a>
<a class="bds_douban">豆瓣网</a>
<a class="bds_hi">百度空间</a>
<a class="bds_mail">邮件分享</a>
<a class="bds_print">打印</a>
<a class="bds_copy">复制网址</a>
<span class="bds_more">更多</span>
<a class="shareCount"></a>
</div>
<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=4520644" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000);
</script>
<!-- Baidu Button END -->
</p>
</div>
		<?php endwhile;endif; ?>

<div class="articles">
<ul class="related_img">
<?php
foreach(get_the_category() as $category){
$cat = $category->cat_ID;
}
query_posts('cat=' . $cat . '&orderby=rand&showposts=5'); //控制相关文章排序为随机，显示相关文章数量
while (have_posts()) : the_post();
$thumbnail = wp_get_attachment_image_src(get_post_thumbnail_id(), 'large');
?>
	<li class="related_box">
	<div class="r_pic img_5">
	<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" target="_blank">
	<img src="<?php if ( dopt('sky_ximage_b' )!=='' ) { ?><?php bloginfo('template_directory'); ?>/timthumb.php?w=100&h=100&src=<?php } ?><?php echo catch_first_image() ?><?php if( dopt('sky_apiximg_2_b')!=='' ) echo dopt('sky_apiximg_2'); ?>" alt="<?php the_title(); ?>" class="thumbnail">
	</a>
	</div>
	<div class="r_title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" target="_blank"><?php echo mb_strimwidth(get_the_title(), 0, 35, '…'); ?></a></div>
	</li>
	<?php endwhile; wp_reset_query(); ?>
	</ul>

<div style="display: none;"><script type="text/javascript" id="wumiiRelatedItems"></script></div>

</div>

<div class="block_pager">
<?php pagination($query_string); //分页 ?>
<div class="clearboth" style="margin:0 0 20px;"></div>
<div class="articles">
<?php comments_template(); ?>
</div>
<div class="clearboth" style="margin:0 0 20px;"></div>
</div>


</div>
<?php get_sidebar(); ?>
<div class="clearboth"></div>
</div>
</div>
</div>
</div>
</div>
</div>
<?php get_footer(); ?>