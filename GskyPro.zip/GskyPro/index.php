<?php get_header(); ?>
<?php if ( dopt('sky_hajax_b' )!=='' ) { ?>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/category.js"></script>
<?php }?>
<div id="content" class="right_sidebar">
<div class="inner" style="padding-bottom: 447px;">
<div class="general_content">
<div class="main_content">
<div class="block_breadcrumbs" style="_display:none;">
<div class="text"><p>最近更新：</p></div>
<ul>
<li><?php the_category(', '); ?></li><li><?php the_title(); ?></li>
</ul>
<span><a href="/random">探索发现</a></span>
</div>
<div style="margin:0 0 10px;_display:none;"></div>
<div id="commenty"></div>
<div id="main" style="float:left;width:660px;">
<div id="loading-comments"><span>真正的Ajax异步加载翻页中...</span></div>
</div>
<div class="main">
<?php if ( is_paged() ) { ?>
<script src="<?php bloginfo('template_directory'); ?>/js/func.js"></script>
<?php }?>
<?php $count = 1; ?>
<?php if (have_posts()) : ?>
	<?php while (have_posts()) : the_post(); ?>
<div class="block_topic_post_feature">
<?php if(($count == 1||$count == 2||$count == 3)) : ?>
<div class="f_pic"><a href="<?php the_permalink() ?>" class="general_pic_hover scale initialized">
<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
<img src="<?php if ( dopt('sky_ximage_b' )!=='' ) { ?><?php bloginfo('template_directory'); ?>/timthumb.php?w=290&h=170&src=<?php } ?><?php echo catch_first_image() ?><?php if( dopt('sky_apiximg_1_b')!=='' ) echo dopt('sky_apiximg_1'); ?>"></a></div>
<div class="content">
<h2 class="title"><a href="<?php the_permalink() ?>"><?php echo mb_strimwidth(get_the_title($post->comment_post_ID),0,38,'...'); ?></a></h2>
<div class="info">
<div class="date"><p><?php the_time('Y-m-d H:i') ?></p></div>
<div class="r_part">
<div class="category"><p><?php comments_popup_link ('抢沙发','1条评论','%条评论'); ?></p></div>
<a href="<?php the_permalink() ?>" class="views"><?php post_views('', ''); ?></a>
</div>
</div>
<p class="text"><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 200,"..."); ?></p>
</div>
<div class="clearboth"></div>
</div>
<div class="line_2" style="margin:15px 0 20px 0"></div>


<?php else: ?>


<div class="content">
<h2 class="title"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<div class="info">
<div class="date"><p><?php the_time('Y-m-d H:i') ?></p></div>
<div class="r_part">
<div class="category"><p><?php comments_popup_link ('抢沙发','1条评论','%条评论'); ?></p></div>
<a href="<?php the_permalink() ?>" class="views"><?php post_views('', ''); ?></a>
</div>
</div>
<p class="text"><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 400,"..."); ?></p>
</div>
<div class="clearboth"></div>
</div>
<div class="line_2" style="margin:15px 0 20px 0"></div><?php endif;$count++; ?>
		<?php endwhile; ?>
		<?php endif; ?>
<div class="block_pager">
<div class="pagination"><?php pagination($query_string); //分页 ?></div>
<div class="line_2" style="margin:20px 0 20px;"></div>
</div>
<div class="clearboth" style="margin:0 0 20px;"></div>
</div>
</div>
<?php get_sidebar(); ?>
</div>
</div>
</div>
</div>
</div>
<?php get_footer(); ?>