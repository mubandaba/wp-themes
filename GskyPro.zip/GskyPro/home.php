<?php get_header(); ?>
<?php if ( dopt('sky_hajax_b' )!=='' ) { ?>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/category.js"></script>
<?php }?>
<div id="content" class="right_sidebar">
<div class="inner" style="padding-bottom: 447px;">
<div class="general_content">
<div class="main_content">

<div class="block_breadcrumbs" style="_display:none;">
<div class="text"><p>最近更新：</p></div>
<ul>
<li><?php the_category(', '); ?></li><li><?php the_title(); ?></li>
</ul>
<span><a href="/random" title="随机为您推荐一篇精彩日志">探索发现</a></span>
</div>
<div style="height:10px;_display:none;"></div>

<div class="saysay">
<?php $page_ID=stripslashes(get_option('sky_likesay')); //填写页面ID ?>
<h2>心情说<?php if ($user_ID) echo '<span><a href="'. get_page_link($page_ID). '#respond">写心情</a></span>'; ?></h2>
<span class="saysays"></span>
<p><?php $comments = get_comments("number=1&post_id=$page_ID");$announcement = $comments[0]->comment_content;
if ($announcement) echo $announcement; else echo '这是第一条心情，你在后台可以删除或者编辑它，当然，你也可以登陆后点击“写心情”';?></p>
</div>
<div id="commenty"></div>
<div id="main" style="float:left;width:660px;">
<div id="loading-comments"><span>真正的Ajax异步加载翻页中...</span></div>
</div>
<div class="main">
<div class="separator"></div>
<?php if ( is_paged() ) { ?>
<script src="<?php bloginfo('template_directory'); ?>/js/func.js"></script>
<?php }?>
<?php $count = 1; ?>
<?php if (have_posts()) : ?>
	<?php while (have_posts()) : the_post(); ?>
<div class="block_topic_post_feature">
<?php if(($count == 1)) : ?>
<div class="f_pic"><a href="<?php the_permalink() ?>" class="general_pic_hover scale initialized">
<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
<img src="<?php if ( dopt('sky_ximage_b' )!=='' ) { ?><?php bloginfo('template_directory'); ?>/timthumb.php?w=290&h=170&src=<?php } ?><?php echo catch_first_image() ?><?php if( dopt('sky_apiximg_1_b')!=='' ) echo dopt('sky_apiximg_1'); ?>"></a></div>
<div class="content">
<h2 class="title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php echo mb_strimwidth(get_the_title($post->comment_post_ID),0,38,'...'); ?></a></h2>
<div class="info">
<div class="date"><p><?php the_time('Y-m-d H:i') ?></p></div>
<div class="r_part">
<div class="category"><p><?php comments_popup_link ('抢沙发','1条评论','%条评论'); ?></p></div>
<a href="<?php the_permalink() ?>" class="views"><?php post_views('', ''); ?></a>
</div>
</div>
<p class="text"><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 200,"..."); ?></p>
</div>
<div class="clearboth"></div>
</div>
<div class="line_2" style="margin:15px 0 20px 0"></div>

<div class="block_topic_news">
<?php else: ?>

<div class="block_topic_post">
<h2 class="title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php echo mb_strimwidth(get_the_title($post->comment_post_ID),0,40,'...'); ?></a></h2>
<div class="f_pics"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" class="general_pic_hover scale initialized">
<img src="<?php if ( dopt('sky_ximage_b' )!=='' ) { ?><?php bloginfo('template_directory'); ?>/timthumb.php?w=290&h=170&src=<?php } ?><?php echo catch_first_image() ?><?php if( dopt('sky_apiximg_1_b')!=='' ) echo dopt('sky_apiximg_1'); ?>" alt=""><span class="hover"><span class="icon"></span></span></a></div>
<p class="text"><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 260,"..."); ?></p>
<div class="infos">
<div class="date"><p><?php the_time('Y-m-d H:i') ?></p></div>
<div class="r_part">
<div class="category"><p><?php comments_popup_link ('抢沙发','1条评论','%条评论'); ?></p></div>
<a href="<?php the_permalink() ?>" class="views"><?php post_views('', ''); ?></a>
</div>
</div>
</div>
</div><?php endif;$count++; ?>
		<?php endwhile; ?>
		<?php endif; ?>
<div class="line_2"></div>
<div class="block_pager" style="margin:20px 0 20px;">
<?php pagination($query_string); //分页 ?>
</div>
</div>
</div>
</div>
<?php get_sidebar(); ?>
<div class="clearboth"></div>
</div>
</div>
</div>
</div>
</div>
<?php get_footer(); ?>