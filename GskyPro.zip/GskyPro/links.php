<?php 
/*
	template name: 友情链接
*/
?>
<?php get_header(); ?>

<div id="content" class="right_sidebar">
<div class="inner" style="padding-bottom: 447px;">
<div class="general_content">
<div class="main_content">
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<h2 style="_border-bottom:5px solid #AAA;color:#333;height:30px;text-align:center;"><?php the_title(); ?></h2>
<div class="saysays" style="margin-top:-2px;"></div>
<div class="info" style="text-align:center;">
作者：<?php the_author() ?> &nbsp; 发布：<?php the_time('Y-m-d H:i') ?> &nbsp; 栏目：<?php the_category(', ') ?> &nbsp; 阅读：<?php post_views('', '次'); ?> &nbsp; <?php comments_popup_link ('抢沙发','1条评论','%条评论'); ?> &nbsp; <?php edit_post_link('编辑', ' [ ', ' ] '); ?>
</div>
<div style="height:10px;_display:none;"></div>

<?php my_list_bookmarks('categorize=1&amp;category_orderby=id&amp;before=<li>&amp;after=&amp;show_images=1&amp;show_description=1&amp;orderby=name&amp;title_before=<h3>&amp;title_after=</h3>'); ?>

<div class="context">
<?php the_content(); ?>
</div>
<script type="text/javascript">
// 评论AJAX分页
$body=(window.opera)?(document.compatMode=="CSS1Compat"?$('html'):$('body')):$('html,body');
// 点击分页导航链接时触发分页
$('.pagination a').live('click', function(e){
    e.preventDefault();
    $.ajax({
        type: "GET",
        url: $(this).attr('href'),
        beforeSend: function(){
            $('.pagination').remove();
            $('.articles').remove();
            $('#loading-comments').slideDown();
            $body.animate({scrollTop: $('#commenty').offset().top - 65}, 800 );
        },
        dataType: "html",
        success: function(out){
            result = $(out).find('.articles');
            $('#loading-comments').slideUp('fast');
            $('#loading-comments').after(result.fadeIn(500));
            $('.articles').after(nextlink);
        }
    });
});
</script>
<div id="commenty"></div>
<div id="main" style="float:left;width:660px;">
<div id="loading-comments"><span>真正的Ajax异步加载翻页中...</span></div>
</div>
<div class="block_pager">
<?php pagination($query_string); //分页 ?>
<div class="clearboth" style="margin:0 0 20px;"></div>
<div class="articles">
<?php comments_template(); ?>
</div>
<div class="clearboth" style="margin:0 0 20px;"></div>
</div>
	<?php endwhile; else: ?>
	<?php endif; ?>

</div>
<?php get_sidebar(); ?>
<div class="clearboth"></div>
</div>
</div>
</div>
</div>
</div>
</div>
<?php
function my_bookmarks($bookmarks, $args = '' ) {
	$defaults = array(
		'show_updated' => 0, 'show_description' => 0,
		'show_images' => 1, 'show_name' => 0,
		'before' => '<li>', 'after' => '</li>', 'between' => "\n",
		'show_rating' => 0, 'link_before' => '', 'link_after' => '','nofollow' =>0
	);
	$r = wp_parse_args( $args, $defaults );
	extract( $r, EXTR_SKIP );
	$output = ''; // Blank string to start with.
	foreach ( (array) $bookmarks as $bookmark ) {
		if ( !isset($bookmark->recently_updated) )
			$bookmark->recently_updated = false;
		$output .= $before;
		if ( $show_updated && $bookmark->recently_updated )
			$output .= get_option('links_recently_updated_prepend');
		$the_link = '#';
		if ( !empty($bookmark->link_url) )
			$the_link = esc_url($bookmark->link_url);
		$rel = ' rel="external';
		if ($nofollow)
			$rel .= ' nofollow';
		if ( '' != $bookmark->link_rel )
			$rel .= ' ' . $bookmark->link_rel;
		$rel .= '"';
		$desc = esc_attr(sanitize_bookmark_field('link_description', $bookmark->link_description, $bookmark->link_id, 'display'));
		$name = esc_attr(sanitize_bookmark_field('link_name', $bookmark->link_name, $bookmark->link_id, 'display'));
 		$title = $desc;
		if ( $show_updated )
			if ( '00' != substr($bookmark->link_updated_f, 0, 2) ) {
				$title .= ' (';
				$title .= sprintf(__('Last updated: %s'), date(get_option('links_updated_date_format'), $bookmark->link_updated_f + (get_option('gmt_offset') * 3600)));
				$title .= ')';
			}
		if ( '' != $title )
			$title = ' title="' . $title . '"';
		$alt = ' alt="' . $name . '"';
		$target = $bookmark->link_target;
		if ( '' != $target )
			$target = ' target="' . $target . '"';
		$output .= '<a href="' . $the_link . '"' . $rel . $title . $target. '>';
		$output .= $link_before;
		if ( $show_images ) {
			if ( $bookmark->link_image != null) {
				if ( strpos($bookmark->link_image, 'http') !== false )
					$output .= "<img width='16' height='16' src=\"$bookmark->link_image\" $alt $title />";
				else // If it's a relative path
					$output .= "<img width='16' height='16' src=\"" . get_option('siteurl') . "$bookmark->link_image\" $alt $title />";
			} else {//否则显示网站的Favicon
				if (preg_match('/^(https?:\/\/)?([^\/]+)/i',$the_link,$URI)) {//提取域名
					$domains = $URI[2];
				}else{//域名提取失败，显示默认小地球
					$domains = "example.com";
				}
				$output .= "<img width='16' height='16' src=\"http://www.google.com/s2/favicons?domain=$domains\" $alt $title />";
			}
		}
		$output .= $name;
		$output .= $link_after;
		$output .= '</a>';
		if ( $show_updated && $bookmark->recently_updated )
			$output .= get_option('links_recently_updated_append');
		if ( $show_description && '' != $desc )
			$output .= $between . $desc;
		if ($show_rating) {
			$output .= $between . sanitize_bookmark_field('link_rating', $bookmark->link_rating, $bookmark->link_id, 'display');
		}
		$output .= "$after\n";
	} // end while
	return $output;
}
function my_list_bookmarks($args = '') {
	$defaults = array(
		'orderby' => 'name',
		'order' => 'ASC',
		'limit' => -1,
		'category' => '',
		'exclude_category' => '',
		'category_name' => '',
		'hide_invisible' => 1,
		'show_updated' => 0,
		'echo' => 1,
		'categorize' => 1,
		'title_li' => __('Bookmarks'),
		'category_orderby' => 'name',
		'category_order' => 'ASC',
		'class' => 'linkcat',
		'category_before' => '<li id="%id" class="%class">',
		'category_after' => '</li>',
		'nofollow' => 0
	);
	$r = wp_parse_args( $args, $defaults );
	extract( $r, EXTR_SKIP );
	$output = '';
	if ( $categorize ) {
		//Split the bookmarks into ul's for each category
		$cats = get_terms('link_category', array('name__like' => $category_name, 'include' => $category, 'exclude' => $exclude_category, 'orderby' => $category_orderby, 'order' => $category_order, 'hierarchical' => 0));
		foreach ( (array) $cats as $cat ) {
			$params = array_merge($r, array('category'=>$cat->term_id));
			$bookmarks = get_bookmarks($params);
			if ( empty($bookmarks) )
				continue;
			$output .= str_replace(array('%id', '%class'), array("linkcat-$cat->term_id", $class), $category_before);
			$catname = apply_filters( "link_category", $cat->name );
			$output .= "$title_before$catname$title_after\n\t<ul>\n";
			$output .= my_bookmarks($bookmarks, $r);
			$output .= "\n\t</ul>\n$category_after\n";
		}
	} else {
		//output one single list using title_li for the title
		$bookmarks = get_bookmarks($r);
		if ( !empty($bookmarks) ) {
			if ( !empty( $title_li ) ){
				$output .= str_replace(array('%id', '%class'), array("linkcat-$category", $class), $category_before);
				$output .= "$title_before$title_li$title_after\n\t<ul>\n";
				$output .= my_bookmarks($bookmarks, $r);
				$output .= "\n\t</ul>\n$category_after\n";
			} else {
				$output .= my_bookmarks($bookmarks, $r);
			}
		}
	}
	$output = apply_filters( 'wp_list_bookmarks', $output );
	if ( !$echo )
		return $output;
	echo $output;
}
?>
<?php get_footer(); ?>