<?php
/*
Template Name: 读者墙
*/
?>
<?php get_header(); ?>
<div id="content" class="right_sidebar">
<div class="inner" style="padding-bottom: 447px;">
<div class="general_content">
<div class="main_content">
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<h2 style="_border-bottom:5px solid #AAA;color:#333;height:30px;text-align:center;"><?php the_title(); ?></h2>
<div class="saysays" style="margin-top:-2px;"></div>
<div class="info" style="text-align:center;">
作者：<?php the_author() ?> &nbsp; 发布：<?php the_time('Y-m-d H:i') ?> &nbsp; 栏目：<?php the_category(', ') ?> &nbsp; 阅读：<?php post_views('', '次'); ?> &nbsp; <?php comments_popup_link ('抢沙发','1条评论','%条评论'); ?> &nbsp; <?php edit_post_link('编辑', ' [ ', ' ] '); ?>
</div>
<div style="height:10px;_display:none;"></div>
<?php
    $query="SELECT COUNT(comment_ID) AS cnt, comment_author, comment_author_url, comment_author_email FROM (SELECT * FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->posts.ID=$wpdb->comments.comment_post_ID) WHERE comment_date > date_sub( NOW(), INTERVAL 24 MONTH ) AND user_id='0' AND comment_author_email != '742206125@qq.com' AND post_password='' AND comment_approved='1' AND comment_type='') AS tempcmt GROUP BY comment_author_email ORDER BY cnt DESC LIMIT 72";//显示数量
    $wall = $wpdb->get_results($query);
    $maxNum = $wall[0]->cnt;
    foreach ($wall as $comment)
    {
        if( $comment->comment_author_url )
        $url = $comment->comment_author_url;
        else $url="#";
        $tmp = "<li><a title=\"$comment->comment_author - $comment->cnt ℃\" target=\"_blank\" rel=\"external nofollow\" href=\"".$comment->comment_author_url."\">
		<img src=http://www.gravatar.com/avatar/".md5(strtolower($comment->comment_author_email))."?s=40&d=&r=G></a></li>";
        $output .= $tmp;
     }
    $output = "<div class=\"readerwall\">".$output."<div class=\"clear\" style=\"margin:0 0 200px\"></div></div>";
    echo $output ;
?>
<!-- end 读者墙 -->
<![if !IE]>
<script type="text/javascript">
// 评论AJAX分页
$body=(window.opera)?(document.compatMode=="CSS1Compat"?$('html'):$('body')):$('html,body');
// 点击分页导航链接时触发分页
$('.pagination a').live('click', function(e){
    e.preventDefault();
    $.ajax({
        type: "GET",
        url: $(this).attr('href'),
        beforeSend: function(){
            $('.pagination').remove();
            $('.articles').remove();
            $('#loading-comments').slideDown();
            $body.animate({scrollTop: $('#commenty').offset().top - 65}, 800 );
        },
        dataType: "html",
        success: function(out){
            result = $(out).find('.articles');
            $('#loading-comments').slideUp('fast');
            $('#loading-comments').after(result.fadeIn(500));
            $('.articles').after(nextlink);
        }
    });
});
</script>
<![endif]>
<div id="commenty"></div>
<div id="main" style="float:left;width:660px;">
<div id="loading-comments"><span>真正的Ajax异步加载翻页中...</span></div>
</div>
<div class="block_pager">
<?php pagination($query_string); //分页 ?>
<div class="clearboth" style="margin:0 0 20px;"></div>
<div class="articles">
<?php comments_template(); ?>
</div>
<div class="clearboth" style="margin:0 0 20px;"></div>
</div>
	<?php endwhile; else: ?>
	<?php endif; ?>

</div>
<?php get_sidebar(); ?>
<div class="clearboth"></div>
</div>
</div>
</div>
</div>
</div>
</div>
<?php get_footer(); ?>