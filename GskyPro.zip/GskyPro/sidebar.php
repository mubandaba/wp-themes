<div class="sidebar">

<div class="block_popular_posts">
<?php if ( is_home() ) { ?>
<h4>热门文章</h4>
<div class="article">
<?php query_posts(array('posts_per_page' => 5,'caller_get_posts' =>1,'orderby' =>comment_count,)); 
while ( have_posts() ) : the_post(); ?>
<div class="pic">
<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
<img src="<?php if ( dopt('sky_ximage_b' )!=='' ) { ?><?php bloginfo('template_directory'); ?>/timthumb.php?w=100&h=100&src=<?php } ?><?php echo catch_first_image() ?><?php if( dopt('sky_apiximg_2_b')!=='' ) echo dopt('sky_apiximg_2'); ?>" alt="">
<span></span>
</a>
</div>
<div class="text">
<p class="title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php echo mb_strimwidth(get_the_title($post->comment_post_ID),0,30,'...'); ?></a></p>
<div class="date"><p><?php the_time('Y-m-d') ?></p></div>
<div class="icons">
<ul>
<li><?php comments_popup_link('???','1人评','%人评'); ?></li>
<li><a href="<?php the_permalink() ?>" class="views"><?php post_views('', ''); ?></a></li>
</ul>
</div>
</div>
<?php endwhile;wp_reset_query();?>
</div>
<div class="separator" style="height:10px;"></div>
<?php if( dopt('sky_adpost_01_b')!=='' ) echo '<h4>广而告之</h4><div class="gads">'.dopt('sky_adpost_01').'</div>'; ?>
<?php };if ( !is_home() ) { ?>
<h4>最新文章</h4>
<div class="article">
<?php query_posts(array('posts_per_page' => 5,'caller_get_posts' =>1,'orderby' =>date,));
while ( have_posts() ) : the_post(); ?>
<div class="pic">
<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
<img src="<?php if ( dopt('sky_ximage_b' )!=='' ) { ?><?php bloginfo('template_directory'); ?>/timthumb.php?w=100&h=100&src=<?php } ?><?php echo catch_first_image() ?><?php if( dopt('sky_apiximg_2_b')!=='' ) echo dopt('sky_apiximg_2'); ?>" alt="">
<span></span>
</a>
</div>
<div class="text">
<p class="title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php echo mb_strimwidth(get_the_title($post->comment_post_ID),0,30,'...'); ?></a></p>
<div class="date"><p><?php the_time('Y-m-d') ?></p></div>
<div class="icons">
<ul>
<li><?php comments_popup_link('???','1人评','%人评'); ?></li>
<li><a href="<?php the_permalink() ?>" class="views"><?php post_views('', ''); ?></a></li>
</ul>
</div>
</div>
<?php endwhile;wp_reset_query();?>
</div>
<div class="separator" style="height:10px;"></div>
<?php if( dopt('sky_adpost_02_b')!=='' ) echo '<h4>广而告之</h4><div class="gads">'.dopt('sky_adpost_02').'</div>'; ?>
<?php }?>
<h4>随机文章</h4>
<div class="article">
<?php query_posts(array('posts_per_page' => 5,'caller_get_posts' =>1,'orderby' =>rand,)); 
while ( have_posts() ) : the_post(); ?>
<div class="pic">
<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
<img src="<?php if ( dopt('sky_ximage_b' )!=='' ) { ?><?php bloginfo('template_directory'); ?>/timthumb.php?w=100&h=100&src=<?php } ?><?php echo catch_first_image() ?><?php if( dopt('sky_apiximg_2_b')!=='' ) echo dopt('sky_apiximg_2'); ?>" alt="">
<span></span>
</a>
</div>
<div class="text">
<p class="title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php echo mb_strimwidth(get_the_title($post->comment_post_ID),0,30,'...'); ?></a></p>
<div class="date"><p><?php the_time('Y-m-d') ?></p></div>
<div class="icons">
<ul>
<li><?php comments_popup_link('???','1人评','%人评'); ?></li>
<li><a href="<?php the_permalink() ?>" class="views"><?php post_views('', ''); ?></a></li>
</ul>
</div>
</div>
<?php endwhile;wp_reset_query();?>
</div>
<div class="separator" style="height:10px;"></div>
<?php if ( is_single() ) { ?>
<?php if( dopt('sky_adpost_03_b')!=='' ) echo '<h4>广而告之</h4><div class="gads">'.dopt('sky_adpost_03').'</div>'; ?>
<?php }?>
<?php if ( is_home()&&!is_paged() ) { ?>
<h4>友情链接</h4>
<div class="article">
<div class="v-links">
<ul><?php wp_list_bookmarks('orderby=link_id&categorize=0&category='.get_option('sky_links').'&title_li='); ?></ul>
</div></div>
<?php } ?>
<div class="separator"  style="margin:0 0 20px;"></div>
</div>