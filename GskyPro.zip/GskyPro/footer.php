<div class="doc-ft" style="_height:45px;_border-top:5px solid #aaa;">
<div class="in">

<section class="middle">
<div class="inner">
<div class="line_1"></div>

<div class="block_footer_widgets">
<div style="_display:none;">
<div class="column_ph">
<h3>读者排行</h3>

<div class="block_flickr_footer">
<ul>
<?php
$counts = $wpdb->get_results("SELECT COUNT(comment_ID) AS cnt, comment_author, comment_author_url, comment_author_email FROM (SELECT * FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->posts.ID=$wpdb->comments.comment_post_ID) WHERE comment_date > date_sub( NOW(), INTERVAL 1 MONTH ) AND user_id='0' AND comment_author_email != '' AND post_password='' AND comment_approved='1' AND comment_type='') AS tempcmt GROUP BY comment_author_email ORDER BY cnt DESC LIMIT 16");//显示个数
foreach ($counts as $count) {
$a = 'http://www.gravatar.com/avatar/' . md5(strtolower($count->comment_author_email)) . '?s=42&d=&r=G';
$c_url = $count->comment_author_url;
$mostactive .= '<li class="mostactive">' . '<a href="'. $c_url . '" title="' . $count->comment_author . ' (留下'. $count->cnt . '个脚印)" target="_blank" rel="external nofollow"><img src="' . $a . '" width="42px" height="42px" alt="' . $count->comment_author . '" class="avatar"/></a></li>';
}
echo $mostactive;
?>
</ul>
</div>
</div>

<div class="column_tag">
<h3>标签云集</h3>

<div class="block_tags">
<?php wp_tag_cloud('smallest=12&largest=10&unit=px&number=16&orderby=count&order=RAND');?>
</div>
</div>

<div class="f_comment">
<h3>最新评论</h3>
<ul>
<?php
global $wpdb;
$sql = "SELECT DISTINCT ID, post_title, post_password, comment_ID, comment_post_ID, comment_author, comment_date_gmt, comment_approved, comment_type,comment_author_url,comment_author_email, SUBSTRING(comment_content,1,16) AS com_excerpt FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID = $wpdb->posts.ID) WHERE comment_approved = '1' AND comment_type = '' AND post_password = '' AND user_id='0' ORDER BY comment_date_gmt DESC LIMIT 5";
$comments = $wpdb->get_results($sql);
$output = $pre_HTML;
foreach ($comments as $comment) {
$a= 'http://www.gravatar.com/avatar/'.md5(strtolower($comment->comment_author_email)).'?s=42&d=&r=G';
$output .= "\n<li><img src='". $a ."'  alt=\"$comment->comment_author\" class='avatar'/>$comment->comment_author:<br /><a href=\"" . get_permalink($comment->ID) . "#comment-" . $comment->comment_ID . "\" title=\"查看 " .$comment->post_title . "\">" . strip_tags($comment->com_excerpt)."</a></li>";
}
$output .= $post_HTML;
$output = convert_smilies($output);
echo $output;
?>
</ul>
</div>

<?php echo stripslashes('<div class="gads">'.get_option('sky_adpost_04').'</div>'); ?>

<div class="line_2"></div>
</div>
<div class="block_social_footer">
<p>Theme <a href="http://www.gsky.org/" target="_blank">Gsky Pro</a><?php if( dopt('sky_tongji_b')!=='' ) echo ' | '.dopt('sky_tongji').' | '; ?><?php if( dopt('sky_icps_b')!=='' ) echo dopt('sky_icps'); ?></p>
</div>
<div class="block_copyrights"><p>Copyright 2012-2013 <a href="<?php bloginfo('siteurl'); ?>"><?php bloginfo('name'); ?></a> | Power by WordPress.</p></div>

</div>
</div>

</div>
<div style="_display:none;">
<p class="link-back2top"><a href="#">返回顶部</a></p>
<script>
$(".link-back2top").hide();
$(window).scroll(function() {
	if ($(this).scrollTop() > 100) {
		$(".link-back2top").fadeIn();
	} else {
		$(".link-back2top").fadeOut();
	}
});
$(".link-back2top a").click(function() {
	$("body,html").animate({
		scrollTop: 0
	},
	800);
	return false;
});
</script>
</div>
<div id="sticky">

<ul id="example-2" class="sticklr">
<li>
<a class="icon-tag" title="站内导航"></a>
<ul>
<li class="sticklr-title">
<a>导航菜单 / NavMenu</a>
</li>
<?php if(function_exists('wp_nav_menu')) { wp_nav_menu(array( 'theme_location' => 'menu','container_class'=>'slogan') ); } ?>
</ul>
</li>

<li>
<a class="icon-sitemap" title="显示当前页面基本概况"></a>
<ul>
<?php if ( is_single() ){ ?>
<li class="sticklr-title">
<a>文章概况 / Preview</a>
</li>
<li>
<a><?php post_views('热度 ', '℃'); ?></a>
</li>
<li>
<?php comments_popup_link ('发表评论','评论 1条','评论 %条'); ?>
</li>
<li>
<?php the_category('分类 ',',') ?>
</li>
<li>
<a><?php the_time('Y-m-d H:i') ?></a>
</li>
<?php }?>
<?php if ( !is_single() ){ ?>
<li class="sticklr-title">
<a>站内统计 / NumericalStat</a>
</li>
<li>
<a>日志:<?php $count_posts = wp_count_posts(); echo $published_posts = $count_posts->publish;?> 篇</a>
</li>
<li>
<a>评论:<?php echo $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->comments");?> 评</a>
</li>
<li>
<a>链接:<?php $link = $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->links WHERE link_visible = 'Y'"); echo $link; ?> 条</a>
</li>
<li>
<a>搭建:<?php echo get_option('sky_webed'); ?></a>
</li>
<li>
<a>运行:<?php echo floor((time()-strtotime(get_option('sky_webed')))/86400); ?> 天</a>
</li>
<?php }?>
</ul>
</li>

<li>
<a class="icon-login" title="快捷登录Wordpress入口"></a>
<ul>
<li class="sticklr-title">
<a>登录 / Login</a>
</li>
<?php if ( !$user_ID ) { ?>
<li>
<form action="<?php bloginfo('siteurl'); ?>/wp-login.php?redirect_to=<?php echo curPageURL(); ?>" method="post" id="loginform">
<div class="loginblock">
<input type="text" name="log" id="log" size="" tabindex="11">
<input type="password" name="pwd" id="pwd" size="" tabindex="12">
<input type="submit" name="wp-submit" value="登 录" />
</div>
<input type="hidden" name="redirect_to" value="<?php echo curPageURL(); ?>">
<div class="logblog">
<a href="<?php bloginfo('siteurl'); ?>/wp-login.php?action=register" target="_blank">注 册</a>
</div>
</form>
</li>
<?php } else { ?>
<li><a href="<?php bloginfo('siteurl'); ?>/wp-admin/" target="_blank">管理</a></li>
<li><a href="<?php bloginfo('siteurl'); ?>/wp-admin/post-new.php" target="_blank">写文章</a></li>
<li><a href="<?php bloginfo('siteurl'); ?>/wp-admin/themes.php" target="_blank">主题</a></li>
<li><a href="<?php bloginfo('siteurl'); ?>/wp-admin/options-general.php" target="_blank">设置</a></li>
<li><?php wp_loginout( $_SERVER["REQUEST_URI"]); ?></li>
<?php } ?>
</ul>
</li>
<li>
<a class="icon-twitter" title="关注我们"></a>
<ul>
<li class="sticklr-title">
<a>关注我们</a>
</li>
<li>
<a href="<?php echo stripslashes(get_option('sky_tqq')); ?>" target="_blank" class="icon-twitter">腾讯微博</a>
</li>
<li>
<a href="<?php echo stripslashes(get_option('sky_weibo')); ?>" target="_blank" class="icon-delicious">新浪微博</a>
</li>
<li>
<a href="<?php echo stripslashes(get_option('sky_feed')); ?>" target="_blank" class="icon-zoom">订阅我们</a>
</li>
</ul>
</li>
<li>
<a class="icon-calendar" href="<?php echo stripslashes(get_option('sky_mony')); ?>" target="_blank" title="捐赠共勉"><span class="notification-count">New</span></a>
<!--<ul>
<li class="sticklr-title">
<a>捐赠共勉</a>
</li>
<li>
<a>支付宝</a>
</li>
</ul>-->
</li>
</ul>
</div>
</body>
</html>