<?php get_header(); ?>
<div id="content" class="right_sidebar">
<div class="inner" style="padding-bottom: 447px;">
<div class="general_content">
<div class="main_content">
<div class="block_breadcrumbs"><div class="text"><p>正在阅读：</p></div>
<ul>
<li><?php the_title(); ?></li>
</ul><span><a href="/random">探索发现</a></span></div>
<div class="separator" style="height:10px;"></div>
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<h2 style="color:#333;border-bottom:1px dashed #333;height:30px;text-align:center;"><?php the_title(); ?></h2>
<div class="info" style="text-align:center;">
作者：<?php the_author() ?> &nbsp; 发布：<?php the_time('Y-m-d H:i') ?> &nbsp; 栏目：<?php the_category(', ') ?> &nbsp; 点击：<?php post_views('', '次'); ?> &nbsp; <?php comments_popup_link ('抢沙发','1条评论','%条评论'); ?> &nbsp; <?php edit_post_link('编辑', ' [ ', ' ] '); ?>
</div>
<div style="height:10px;"></div>
<div class="context">
<?php the_content('Read more...'); ?><hr style="border-top: 1px solid #666;"><p>本文固定链接: <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_permalink() ?> | <?php bloginfo('name');?></a></p>
</div>
		<?php endwhile;endif; ?>
<div class="block_pager">
<div class="pagination"><?php pagination($query_string); //分页 ?></div>
<div class="clearboth" style="margin:0 0 20px;"></div>
<div class="articles">
<?php comments_template(); ?>
</div>
<div class="clearboth" style="margin:0 0 20px;"></div>
</div>


</div>
<?php get_sidebar(); ?>
<div class="clearboth"></div>
</div>
</div>
</div>
</div>
</div>
</div>
<?php get_footer(); ?>