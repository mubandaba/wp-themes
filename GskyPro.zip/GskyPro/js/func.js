jQuery(document).ready(function(){
jQuery('h2 a').click(function(){
    jQuery(this).text('正在建立链接...');
    window.location = jQuery(this).attr('href');
    });
});
//Tooltip效果
$(function() {
  $("a").each(function(b) {
    if (this.title) {
      var c = this.title;
      var a = 30;
      $(this).mouseover(function(d) {
        this.title = "";
        $("body").append('<div id="tooltip">' + c + "</div>");
        $("#tooltip").css({
          left: (d.pageX + a) + "px",
          top: d.pageY + "px",
          opacity: "0.8"
        }).fadeIn(250)
      }).mouseout(function() {
        this.title = c;
        $("#tooltip").remove()
      }).mousemove(function(d) {
        $("#tooltip").css({
          left: (d.pageX + a) + "px",
          top: d.pageY + "px"
        })
      })
    }
  })
});
//新窗口打开
jQuery(document).ready(function(){
  jQuery("a[rel='external'],a[rel='external nofollow']").click(
  function(){window.open(this.href);return false})
});


