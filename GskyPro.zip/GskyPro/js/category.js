// 评论AJAX分页
$body=(window.opera)?(document.compatMode=="CSS1Compat"?$('html'):$('body')):$('html,body');
// 点击分页导航链接时触发分页
$('.pagination a').live('click', function(e){
    e.preventDefault();
    $.ajax({
        type: "GET",
        url: $(this).attr('href'),
        beforeSend: function(){
            $('.pagination').remove();
            $('.main').remove();
            $('#loading-comments').slideDown();
            $body.animate({scrollTop: $('#commenty').offset().bottom - 65}, 800 );
        },
        dataType: "html",
        success: function(out){
            result = $(out).find('.main');
            $('#loading-comments').slideUp('fast');
            $('#loading-comments').after(result.fadeIn(500));
            $('.main').after(nextlink);
        }
    });
});