<?php

$themename = 'Gsky Pro';

$options = array (

	//基本设置
	array( "name" => "基本设置","type" => "section","desc" => "主题的基本设置"),
	
	array( "name" => "网站描述","type" => "tit"),
	array( "id" => "sky_description","type" => "text","std" => "输入你的网站描述，一般不超过200个字符"),
	
	array( "name" => "网站关键字","type" => "tit"),	
	array( "id" => "sky_keywords","type" => "text","std" => "输入你的网站关键字，一般不超过100个字符。 关键字之间用 ',' 隔开"),
	
	array( "name" => "建站日期","type" => "tit"),
	array( "id" => "sky_webed","type" => "text","class" => "d_inp_short","std" => "2012-07-25"),

	array( "name" => "友情链接分类ID","type" => "tit"),	
	array( "id" => "sky_links","type" => "text","class" => "d_inp_short","std" => "2"),

	array( "name" => "心情说页面ID","type" => "tit"),
	array( "id" => "sky_likesay","type" => "text","class" => "d_inp_short","std" => "99"),

	array( "name" => "备案号","type" => "tit"),	
	array( "id" => "sky_icps_b","type" => "checkbox" ),
	array( "id" => "sky_icps","type" => "text","std" => "备案号码"),

	array( "name" => "统计代码","type" => "tit"),	
	array( "id" => "sky_tongji_b","type" => "checkbox" ),
	array( "id" => "sky_tongji","type" => "textarea","std" => "统计代码"),

	array( "type" => "endtag"),
	
	//其他设置
	array( "name" => "其它选项","type" => "section","desc" => "主题功能开关及社交更能"),
	
	array( "name" => "腾讯微博","type" => "tit"),	
	array( "id" => "sky_tqq","type" => "text","class" => "d_inp_short","std" => "http://t.qq.com/tokinx"),
	
	array( "name" => "新浪微博","type" => "tit"),	
	array( "id" => "sky_weibo","type" => "text","class" => "d_inp_short","std" => "http://weibo.com/irickys"),
	
	array( "name" => "订阅地址","type" => "tit"),	
	array( "id" => "sky_feed","type" => "text","class" => "d_inp_short","std" => "http://www.gsky.org/feed"),
	
	array( "name" => "捐赠地址","type" => "tit"),	
	array( "id" => "sky_mony","type" => "text","class" => "d_inp_short","std" => "https://me.alipay.com/gsky"),

	array( "name" => "首页Ajax翻页","type" => "tit"),	
	array( "id" => "sky_hajax_b","type" => "checkbox" ),
	
	array( "name" => "评论Ajax翻页","type" => "tit"),	
	array( "id" => "sky_pajax_b","type" => "checkbox" ),
	
	array( "name" => "本地图片裁剪","type" => "tit"),	
	array( "id" => "sky_ximage_b","type" => "checkbox" ),
	
	array( "name" => "Api图片裁剪-1","type" => "tit"),
	array( "id" => "sky_apiximg_1_b","type" => "checkbox" ),
	array( "id" => "sky_apiximg_1","type" => "text","std" => "?imageView/1/w/290/h/170"),

	array( "name" => "Api图片裁剪-2","type" => "tit"),
	array( "id" => "sky_apiximg_2_b","type" => "checkbox" ),
	array( "id" => "sky_apiximg_2","type" => "text","std" => "?imageView/1/w/100/h/100"),
	
	array( "type" => "endtag"),

	//广告系统
	array( "name" => "广告系统","type" => "section","desc" => "站点的广告展示，包括图片广告、Google广告、百度联盟、淘宝联盟等，将代码贴入即可"),	
	
	array( "name" => "首页边栏1","type" => "tit"),
	array( "id" => "sky_adpost_01_b","type" => "checkbox" ),
	array( "id" => "sky_adpost_01","type" => "textarea","std" => "宽300px广告代码1"),
		
	array( "name" => "文章边栏2","type" => "tit"),
	array( "id" => "sky_adpost_02_b","type" => "checkbox" ),
	array( "id" => "sky_adpost_02","type" => "textarea","std" => "宽300px广告代码2"),
		
	array( "name" => "分类边栏3","type" => "tit"),
	array( "id" => "sky_adpost_03_b","type" => "checkbox" ),
	array( "id" => "sky_adpost_03","type" => "textarea","std" => "宽300px广告代码3"),

	array( "name" => "网站底部4","type" => "tit"),
	array( "id" => "sky_adpost_04","type" => "textarea","std" => "页脚底部250x250，请务必开启。"),

	array( "type" => "endtag"),

);

function mytheme_add_admin() {
	global $themename, $options;
	if ( $_GET['page'] == basename(__FILE__) ) {
		if ( 'save' == $_REQUEST['action'] ) {
			foreach ($options as $value) {
				update_option( $value['id'], $_REQUEST[ $value['id'] ] ); 
			}
			/*
			foreach ($options as $value) {
				if( isset( $_REQUEST[ $value['id'] ] ) ) { update_option( $value['id'], $_REQUEST[ $value['id'] ]  ); }
				else { delete_option( $value['id'] ); } 
			}
			*/
			header("Location: admin.php?page=theme.php&saved=true");
			die;
		}
		else if( 'reset' == $_REQUEST['action'] ) {
			foreach ($options as $value) {delete_option( $value['id'] ); }
			header("Location: admin.php?page=theme.php&reset=true");
			die;
		}
	}
	add_theme_page($themename." Options", $themename."设置", 'edit_themes', basename(__FILE__), 'mytheme_admin');
}

function mytheme_admin() {
	global $themename, $options;
	$i=0;
	if ( $_REQUEST['saved'] ) echo '<div class="d_message">'.$themename.'修改已保存</div>';
	if ( $_REQUEST['reset'] ) echo '<div class="d_message">'.$themename.'已恢复设置</div>';
?>

<div class="wrap d_wrap">
	<link rel="stylesheet" href="<?php bloginfo('template_url') ?>/option/theme.css"/>
	<h2><?php echo $themename; ?>设置
		<span class="d_themedesc">主题设计+技术支持：<a href="http://www.gsky.org/" target="_blank">Tokin</a> &nbsp;&nbsp; 
		<script type="text/javascript" src="http://www.gsky.org/dandelion.js"></script>
		</span>
	</h2>
	
	<form method="post">
		<div class="d_tab"><a class="d_tab_on">主题设置</a><a>其它设置</a><a>广告系统</a></div>
		<?php foreach ($options as $value) { switch ( $value['type'] ) { case "": ?>
			<?php break; case "tit": ?>
			
			</li><li class="d_li">
			<h4><?php echo $value['name']; ?>：</h4>
			
			<?php break; case 'text': ?>
			<input class="d_inp <?php echo $value['class']; ?>" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" value="<?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id'])  ); } else { echo $value['std']; } ?>" />

			<?php break; case 'number': ?>
			<label class="d_number"><?php echo $value['txt']; ?><input class="d_num <?php echo $value['class']; ?>" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" value="<?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id'])  ); } else { echo $value['std']; } ?>" /></label>
			
			<?php break; case 'textarea': ?>
			<textarea class="d_tarea" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" cols="" rows=""><?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id']) ); } else { echo $value['std']; } ?></textarea>
			
			<?php break; case 'select': ?>
			<?php if ( $value['desc'] != "") { ?><span class="d_the_desc" id="<?php echo $value['id']; ?>_desc"><?php echo $value['desc']; ?></span><?php } ?><select class="d_sel" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>">
				<?php foreach ($value['options'] as $option) { ?>
				<option <?php if (get_settings( $value['id'] ) == $option) { echo 'selected="selected" class="d_sel_opt"'; } ?>><?php echo $option; ?></option>
				<?php } ?>
			</select>
			
			<?php break; case "checkbox": ?>
			<?php if(get_settings($value['id']) != ""){ $checked = "checked=\"checked\""; }else{ $checked = "";} ?>
			<label class="d_check"><input type="checkbox" id="<?php echo $value['id']; ?>" name="<?php echo $value['id']; ?>" <?php echo $checked; ?> />开启</label>
			
			<?php break; case "section": $i++; ?>
			<div class="d_mainbox" id="d_mainbox_<?php echo $i; ?>">
				<div class="d_desc"><input class="button-primary" name="save<?php echo $i; ?>" type="submit" value="保存设置" /><?php echo $value['desc']; ?></div>
				<ul class="d_inner">
					<li class="d_li">
				
			<?php break; case "endtag": ?>
			</li></ul>
			<div class="d_desc d_desc_b"><input class="button-primary" name="save<?php echo $i; ?>" type="submit" value="保存设置" /></div>
			</div>
			
		<?php break; }} ?>
				
		<input type="hidden" name="action" value="save" />

	</form>
<script src="<?php bloginfo('template_url') ?>/js/jquery.min.js"></script>
<script src="<?php bloginfo('template_url') ?>/option/theme.js"></script>
</div>
<?php } ?>
<?php add_action('admin_menu', 'mytheme_add_admin');?>