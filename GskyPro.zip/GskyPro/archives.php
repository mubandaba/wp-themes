<?php
/*
template name: 文章归档
*/
get_header(); ?>
<style type="text/css">
.archives table{border-left: solid 2px green}
.archives td{padding: 6px 10px 8px;}
.archives table{padding:10px 0 20px}
.meta-tit{border-bottom: solid 1px #e6e6e6;padding: 0 0 10px;margin-bottom: 20px}
</style>
<div class="content-wrap">
	<div class="content">
<h1 class="meta-tit" style="color:#333;border-bottom:1px dashed #333;height:30px;text-align:center;">文章归档</h1>
<div style="text-align:center;">下面是按照年/月份自动整理出的文章列表归档</div>
<div class="archives">
		<?php
$previous_year = $year = 0;
$previous_month = $month = 0;
$ul_open = false;
$myposts = get_posts('numberposts=-1&orderby=post_date&order=DESC');
foreach($myposts as $post) :
setup_postdata($post);
$year = mysql2date('Y', $post->post_date);
$month = mysql2date('n', $post->post_date);
$day = mysql2date('j', $post->post_date);
if($year != $previous_year || $month != $previous_month) :
if($ul_open == true) : 
echo '</table>';
endif;
echo '<h3>'; echo the_time('F Y'); echo '</h3>';
echo '<table>';
$ul_open = true;
endif;
$previous_year = $year; $previous_month = $month;
?>
<tr>
<td width="40" style="text-align:right;"><?php the_time('j'); ?>日</td>
<td width="700"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></td>
<td width="110"><a class="comm" href="<?php comments_link(); ?>" title="查看 <?php the_title(); ?> 的评论"><?php comments_number('0', '1', '%'); ?>人评论</a></td>
<td width="110"><span class="view"><?php post_views('', ''); ?>次浏览</span></td>
</tr>
<?php endforeach; ?>
</table>
</div>
</div>
</div>
</div>
<?php get_footer(); ?>