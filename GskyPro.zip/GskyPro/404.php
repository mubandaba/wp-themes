<?php get_header(); ?>
<div id="content" class="right_sidebar">
<div class="inner" style="padding-bottom: 447px;">
<div class="general_content">
<div class="main_content">
<div class="block_breadcrumbs"><div class="text"><p>啊偶，有情况：</p></div>
<ul>
<li>你好象迷路了耶！</li>
</ul><span><a href="/random">探索发现</a></span></div>
<div class="separator" style="height:10px;"></div>
<h2 style="color:#333;border-bottom:1px dashed #333;height:30px;text-align:center;">这是一个404页面[公益]</h2>
<div class="info" style="text-align:center;">付出1分钟，安装1个公益广告位，轻松支持100项公益事业！</div>
<div style="height:10px;"></div>
<div class="context">
<h3>抱歉，您打开的页面未能找到。</h3>
<p>您可以使用本站的搜索框搜索您想要的内容。给你带来的不便敬请谅解！</p>
<div style="text-align: center;margin:0 auto;width:640px;"><iframe scrolling='no' frameborder='0' src='http://yibo.iyiyun.com/js/yibo404/key/2705' width='640' height='464' style='display:block;'></iframe></div>
<br>
<h3>我要报错</h3>
<div id="qqwb_comment__" data-appkey="801185565" data-width="100%" data-height="450"></div>
<script src="http://mat1.gtimg.com/app/openjs/openjs.js#debug=yes&autoboot=no"></script>
</div>
<div class="block_pager">
<div class="pagination"><?php pagination($query_string); //分页 ?></div>
<div class="clearboth" style="margin:0 0 20px;"></div>
<div class="articles">
<?php comments_template(); ?>
</div>
<div class="clearboth" style="margin:0 0 20px;"></div>
</div>


</div>
<?php get_sidebar(); ?>
<div class="clearboth"></div>
</div>
</div>
</div>
</div>
</div>
</div>
<?php get_footer(); ?>