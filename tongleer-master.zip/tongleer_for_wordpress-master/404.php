<?php get_header(); ?>
<?php include "templates/404_include.php";?>
<?php get_footer(); ?>