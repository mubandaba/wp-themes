                    <footer class="footer reveal" style="<?php if(wp_is_mobile()) echo 'display:none;' ?>">
                        <p>Copyright © 2018 <?php echo get_bloginfo('name'); ?> · Theme Tony | Designed By <a href="https://www.ouorz.com">TonyHe</a></p>
                    </footer>
                    <script src="https://static.ouorz.com/bootstrap.min.js"></script>
                </div>
            </div>
        </main>
    </body>
</html>