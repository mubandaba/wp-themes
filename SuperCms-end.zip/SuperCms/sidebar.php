<div id="sidebar">

<?php dynamic_sidebar('Sidebar2'); ?>
<?php if(get_option('T_recommend') == "On" || get_option('T_recommend') == "") {?>
<h3 class="sub">推荐阅读</h3>
<ul class="spy">
<?php query_posts( array('posts_per_page' => 5,'orderby' => 'rand','caller_get_posts' => 1) ); while ( have_posts() ) : the_post();?>
<li><?php if ( has_post_thumbnail() ) { ?><div class="img"><?php the_post_thumbnail('thumbnail', array( 'alt' => trim(strip_tags( $post->post_title )), 'title'	=> trim(strip_tags( $post->post_title )), )); ?></div><?php } ?>
<h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
</li>
<?php endwhile; wp_reset_query();?>
</ul>
<?php }?>
<?php dynamic_sidebar('Sidebar'); ?>
</div>