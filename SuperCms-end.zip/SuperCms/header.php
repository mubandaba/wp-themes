<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes( 'xhtml' ); ?>>
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php wp_title( '-', true, 'right' ); echo esc_html( get_bloginfo('name'), 1 ); ?></title>
<?php if(get_option('T_auto_description') == "On"){ auto_description(); }?>
<?php if(get_option('T_auto_keywords') == "On"){ auto_keywords(); } echo a();?>
<meta name="viewport" content="width=device-width" />
<link rel="shortcut icon" href="<?php bloginfo('template_directory'); ?>/favicon.ico" type="image/x-icon">
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
<?php wp_head(); ?>
</head>
<body <?php body_class();echo hd();?>>
<div id="head">
<div id="logo">
<?php if(get_option('T_logo') == "On") {?>
<?php if ( is_single() || is_page() ){ ?><h2><a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a></h2><?php }else{ ?><h1><a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a></h1><?php } ?><?php bloginfo('description'); ?>
<?php } else {?>
<a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?> - <?php bloginfo('description'); ?>"><img src="<?php bloginfo('template_url'); ?>/images/logo.png" alt="<?php bloginfo('name'); ?>" /></a>
<?php } ?>
</div><?php get_search_form(); ?>
</div>
<div id="menu">
<?php wp_nav_menu(array('theme_location' => 'nav', 'depth' => 2, 'container' => 'ul', 'menu_id' => "menunav", 'menu_class' => 'menunav',)); ?>

<?php if(get_option('T_socialicon') == "On") {?><div class="icon">
<a href="<?php if(get_option('T_feed') != "") { echo get_option('T_feed'); } else { ?>http://www.jeffstudio.net/feed/<?php } ?>" title="订阅" target="_blank"><img src="<?php bloginfo('template_directory'); ?>/images/rss.png" alt="订阅" /></a>
<?php if(get_option('T_mail') != "") {?><a href="<?php echo get_option('T_mail'); ?>" title="邮件" target="_blank"><img src="<?php bloginfo('template_directory'); ?>/images/mail.png" alt="邮件" /></a><?php } ?>
<?php if(get_option('T_sina') != "") {?><a href="<?php echo get_option('T_sina'); ?>" title="新浪微博" target="_blank"><img src="<?php bloginfo('template_directory'); ?>/images/weibo.png" alt="新浪微博" /></a><?php } ?>
<?php if(get_option('T_qq') != "") {?><a href="<?php echo get_option('T_qq'); ?>" title="腾讯微博" target="_blank"><img src="<?php bloginfo('template_directory'); ?>/images/qq.png" alt="腾讯微博" /></a><?php } ?>
<?php if(get_option('T_qqzone') != "") {?><a href="<?php echo get_option('T_qqzone'); ?>" title="QQ空间" target="_blank"><img src="<?php bloginfo('template_directory'); ?>/images/qqzone.png" alt="QQ空间" /></a><?php } ?>
<?php if(get_option('T_twitter') != "") {?><a href="<?php echo get_option('T_twitter'); ?>" title="Twitter" target="_blank"><img src="<?php bloginfo('template_directory'); ?>/images/twitter.png" alt="Twitter" /></a><?php } ?>
<?php if(get_option('T_renren') != "") {?><a href="<?php echo get_option('T_renren'); ?>" title="人人网" target="_blank"><img src="<?php bloginfo('template_directory'); ?>/images/renren.png" alt="人人网" /></a><?php } ?><?php if(get_option('T_taobao') != "") {?><a href="<?php echo get_option('T_taobao'); ?>" title="淘宝网店" target="_blank"><img src="<?php bloginfo('template_directory'); ?>/images/taobao.png" alt="淘宝网店" /></a><?php } ?>
<?php if(get_option('T_douban') != "") {?><a href="<?php echo get_option('T_douban'); ?>" title="豆瓣网" target="_blank"><img src="<?php bloginfo('template_directory'); ?>/images/douban.png" alt="豆瓣网" /></a>
<?php } ?>
</div>
<?php } ?>
</div>

<div id="container-inner" class="clear">