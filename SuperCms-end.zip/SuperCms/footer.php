<div class="clear"></div><?php echo c();?>
<div class="footbar">
</div>

<div class="copyright">
<?php echo e();echo 'a>';function c(){echo base64_decode('PC9kaXY+PGRpdiBpZD0nZm9vdGVyJz4=');};if(get_option('T_tongji') != "") {?><div class="clear"></div><?php echo stripslashes(get_option('T_tongji'));?><?php } ?>
</div>
<div class="clear"></div>
<ul id="floater">
<li class="floaticon" id="gototop"><a href="#" title="返回顶部">返回顶部</a></li>
</ul>
</div>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/scripts.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/comments-ajax.js"></script>

<?php wp_footer();?>
</body>
</html>