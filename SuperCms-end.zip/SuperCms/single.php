<?php get_header(); ?>
<div id="primary">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<h1 class="sub"><?php the_title(); ?></h1>
<div class="postinfo"><div class="left">分类：<?php the_category(', ') ?> | <?php if(get_option('T_author') == "On") {?>作者：<a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ) ?>"><?php echo get_the_author() ?></a> <?php } ?>发表于 <?php the_date(get_option('date_format')); ?></div><div class="right"><a href="#respond" title="发表评论"><?php comments_number('发表评论', '1 条评论', '% 条评论'); ?></a></div>
<div class="clear"></div>
</div>

<div id="content" class="artext">
<?php the_content();?>
</div>

<div class="postmetadata">
<?php edit_post_link('编辑本文', '', ''); ?><?php if(function_exists('wp_print')) { print ' | <span>'; print_link(); print '</span>'; } ?> <span><?php the_tags( ' | 标签：', ', ', ' ' ) ?><?php if(function_exists('the_views')) { " | " .the_views(); } ?></span>
</div>
<div class="clear"></div><br />


<?php comments_template('', true); ?>
<?php endwhile; endif; ?>

</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>