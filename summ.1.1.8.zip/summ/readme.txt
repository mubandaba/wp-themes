=== Summ Wordpress Theme ===
Description: A theme with two columns, fixed-width, mainly in blue and white, widgets supported, custom-menu supported, custom header-image and custom background available, no plugins required. For WordPress version 3.0+
Version: 1.1.2
Author: Axiu
Author URI: http://axiu.me/
Tags: white, blue, two-columns, threaded-comments, right-sidebar
License: GNU General Public License v2.0
License URI: http://www.gnu.org/licenses/gpl-2.0.html

For questions, comments or bug reports, please go to
http://axiu.me/learning_notes/summ_submitted/



== Installation ==

= Via WordPress Admin =
1. From your sites admin, go to Themes > Install Themes
1. In the search box, type 'Summ' and press enter
1. Locate the entry for 'Summ' (there should be only one) and click the 'Install' link
1. When installation is finished, click the 'Activate' link

= Manual Install =
1. Unzip this file into your mywebsite.com/wp-content/themes/ directory, should look like mywebsite.com/wp-content/themes/Summ/
2. Go into your Wordpress Admin, navigate to 'Appearance > Themes'
3. Find the Summ listing on this page and click 'Activate'


== Changelog ==

= 1.1.0 =
* Mostly text domain changes.

= 1.1.0 =
Remove function_exists() conditional from calls to the several functions.

= 1.1.8 =
Navigator stylesheet issues fixed.
