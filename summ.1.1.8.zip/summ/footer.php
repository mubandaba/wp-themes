</div>
<div id="footer"><div id="footerbox"><div class="return"><a href="#header"><?php _e('TOP','summ'); ?></a></div><p class="support">       Copyright&nbsp;&copy;&nbsp;<?php echo date("Y"); ?>&nbsp;<strong><?php bloginfo('name'); ?></strong>		<br/>		Theme summ by <a href="http://axiu.me" title="designed by Axiu">Axiu</a> and Powered by <a href="http://wordpress.org/">WordPress</a>
</p></div>
</div><?php	wp_footer(); ?>
</body>
</html>