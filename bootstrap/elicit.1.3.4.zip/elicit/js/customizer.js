
jQuery( document ).ready( function( $ ){
    $('#customize-info .accordion-section-title').append('<a target="_blank" style="text-transform: uppercase; background: #005695; color: #fff; font-size: 16px; line-height: 14px; padding: 10px; display: inline-block;" href="http://themesmob.com/themes/elicit-pro/">UPGRADE TO PRO</a>');
} );
