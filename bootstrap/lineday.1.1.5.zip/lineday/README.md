== LineDay ==
=========

An responsive elegant magazine style WordPress theme based on Twitter Bootstrap and Automattic Underscore(_s). Supporting Font Awesome, multi level dropdown navigation, Schema.org markup.

If you want to change/remove the theme background follow steps below:
1. Go to your front-end page
2. Click "Customize" button on the Admin Bar
3. Select "Background Image" on the side menu
4. Change or remove the background :)

== Information ==
-----------------

Theme Name: LineDay

Theme URI: https://wordpress.org/themes/lineday/

Author: johnthemes

Author URI: https://wordpress.org/themes/lineday/

Requires WordPress at least: 3.6

Tested up to: 5.4.1

Stable tag: 1.1.5

License: GPLv2 or later

License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Copyright & License ==
-------------

LineDay WordPress Theme, Copyright 2020 Zack
LineDay is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see http://www.gnu.org/licenses/gpl-2.0.html.

LineDay WordPress Theme is derived from Underscores WordPress Theme, Copyright 2013 Automattic, Inc.
Underscores WordPress Theme is distributed under the terms of the GNU GPL

LineDay WordPress Theme incorporates code from ZackLive WordPress Theme, Copyright 2015 Zack
ZackLive WordPress Theme is licensed under the terms of the GNU GPL, Version 2 (or later)

LineDay WordPress Theme bundles the following third-party resources:

Bootstrap
Bootstrap is licensed under the MIT license.
Source: http://getbootstrap.com

Font Awesome 4.0.3
Font Awesome is licensed under SIL Open Font License.
Source: http://fontawesome.io

== Changelog ==
---------------

= 1.1.4 =

Editable subscription Widget (via Customizer!)
Tested up to WordPress 5.4.1

= 1.1.3 =

Automated sidebars widgets for visitors

= 1.1.2 =

Design improvements
Added customizable share aside widget

= 1.1.1 =

Design improvements
Added custom aside form

= 1.1.0 =

Fixed Font Awesome usage
Added easy-change background
Rounded posts
Improved widgets display
Improved navigation style
Changed dividers in widgets

= 1.0.8 =

Update Font Awesome to 4.6.3
Update Bootstrap to 3.3.7

= 1.0 =

05.04.2015
Initial Release
