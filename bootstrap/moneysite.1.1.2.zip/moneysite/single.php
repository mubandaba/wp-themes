<?php get_header(); ?>
<div class="clearfix"></div>
<!-- =========================
     Page Content Section      
============================== -->
<main id="content">
  <div class="container">
    <div class="row"> 
      <!--/ Main blog column end -->
      <div class="<?php echo ( !is_active_sidebar( 'sidebar-1' ) ? 'col-md-12 col-sm-12' :'col-md-9 col-sm-8' ); ?>">
        <div class="row">
		      <?php if(have_posts())
		      {
		      while(have_posts()) { the_post(); ?>
          <div class="col-md-12">
            <div class="ms-blog-post-box"> 
              <div class="ms-blog-thumb">
  			        <?php if(has_post_thumbnail()): ?>
  			         <?php $defalt_arg =array('class' => "img-responsive"); ?>
  			         <?php the_post_thumbnail('', $defalt_arg); ?>
  			        <?php endif; ?>

                <!-- Date Meta Data -->
                <span class="ms-blog-date"> 
                  <span class="h3"><?php echo get_the_date('j'); ?></span> 
                    <span><?php echo get_the_date('M').', '.get_the_date('Y'); ?></span>
                </span>
                <!-- Autor Meta Data -->
                <a href="<?php echo esc_url(get_author_posts_url( get_the_author_meta( 'ID' ) ));?>">
                  <span class="ms-blog-author img-circle"> <?php echo get_avatar( get_the_author_meta( 'ID') , 64); ?> </span>
                </a>
              </div>
              <div class="clearfix"></div>
              <article class="small">
                <h2><a><?php the_title(); ?></a></h2>
                <div class="ms-blog-category">
                  <i class="fa fa-folder"></i>
                  <?php $cat_list = get_the_category_list();
				          if(!empty($cat_list)) { ?> <?php the_category(', '); ?>
                  <?php } ?> 
                  <br>
                </div>
                <?php the_content(); ?>
                <?php wp_link_pages( array( 'before' => '<div class="link page-break-links">' . __( 'Pages:', 'moneysite' ), 'after' => '</div>' ) ); ?>
                <?php the_tags( 'Tags: ', ', ', '<br />' ); ?> 
              </article>
            </div>
          </div>
		      <?php } ?>
          <div class="col-md-12">
            <div class="media ms-info-author-block"> <a href="<?php echo esc_url(get_author_posts_url( get_the_author_meta( 'ID' ) ));?>" class="ms-author-pic"> <?php echo get_avatar( get_the_author_meta( 'ID') , 150); ?> </a>
              <div class="media-body">
                <h4 class="media-heading"><span><b>About :</b> </span><a href="<?php echo esc_url(get_author_posts_url( get_the_author_meta( 'ID' ) ));?>"><?php the_author(); ?></a></h4>
                <p><?php the_author_meta( 'description' ); ?></p>
                <div class="row">
                  <div class="col-md-6 col-pad7">
                    <ul class="list-inline info-author-social">
          					<?php 
          					$facebook_profile = get_the_author_meta( 'facebook_profile' );
          					if ( $facebook_profile && $facebook_profile != '' ) {
          					echo '<li class="facebook"><a href="' . esc_url($facebook_profile) . '"><i class="fa fa-facebook-square"></i></a></li>';
          					} 
					
          					$twitter_profile = get_the_author_meta( 'twitter_profile' );
          					if ( $twitter_profile && $twitter_profile != '' ) 
          					{
          					echo '<li class="twitter"><a href="' . esc_url($twitter_profile) . '"><i class="fa fa-twitter-square"></i></a></li>';
          					}
					
          					$google_profile = get_the_author_meta( 'google_profile' );
          					if ( $google_profile && $google_profile != '' ) {
          					echo '<li class="googleplus"><a href="' . esc_url($google_profile) . '" rel="author"><i class="fa fa-google-plus-square"></i></a></li>';
          					}
          					$linkedin_profile = get_the_author_meta( 'linkedin_profile' );
          					if ( $linkedin_profile && $linkedin_profile != '' ) {
          					echo '<li class="linkedin"><a href="' . esc_url($linkedin_profile) . '"><i class="fa fa-linkedin-square"></i></a></li>';
          					}
          					?>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
		      <?php } ?>
         <?php comments_template('',true); ?>
        </div>
      </div>
      <div class="col-md-3 col-sm-4">
      <?php get_sidebar(); ?>
      </div>
    </div>
    <!--/ Row end --> 
  </div>
</main>
<?php get_footer(); ?>