jQuery(function () {
    'use strict';

    /**
     * Scroll top
     */
    jQuery('#scroll-top').on('click', function () {
        jQuery('body').animate({
            scrollTop: 0
        }, 'slow');

        return false;
    });

    /**
     * Main Content
     * min-height
     */
    jQuery(window).load(function () {
        var htmlHeight = jQuery('html').outerHeight(true);
        var bodyHeight = jQuery('body').outerHeight(true);

        var $mainContent = jQuery('.main-content');
        var mainContentHeight = $mainContent.outerHeight(true);

        var otherHeight = bodyHeight - mainContentHeight;

        var mainContentMinHeight = Math.floor(htmlHeight - otherHeight);

        if ($mainContent.length && mainContentMinHeight > mainContentHeight) {
            $mainContent.css('min-height', mainContentMinHeight + 'px');
        }
    });
});
