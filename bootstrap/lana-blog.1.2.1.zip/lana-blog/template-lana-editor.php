<?php
/**
 * Template Name: Lana Editor Page
 * Description: Page Template for Lana Editor
 */
?>

<?php get_header(); ?>

<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

    <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

		<?php the_content(); ?>

		<?php if ( comments_open() || get_comments_number() ) : ?>
            <div class="row">
                <div class="col-md-12">
                    <hr/>
                    <div class="panel-footer">
						<?php comments_template(); ?>
                    </div>
                </div>
            </div>
		<?php endif; ?>

    </div>

<?php endwhile; ?>

<?php else : ?>
    <p><?php _e( 'Sorry, this page does not exist.', 'lana-blog' ); ?></p>
<?php endif; ?>

<?php get_footer(); ?>