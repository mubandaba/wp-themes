<?php
defined( 'ABSPATH' ) or die();

/**
 * Bootstrap menu
 * Scripts
 */
function lana_blog_menu_scripts() {

	/** jquery smartmenus */
	wp_register_script( 'smartmenus', get_template_directory_uri() . '/js/smartmenus.min.js', array( 'jquery' ), '1.0.0', true );
	wp_enqueue_script( 'smartmenus' );

	/** jquery smartmenus bootstrap addons */
	wp_register_script( 'smartmenus-bootstrap', get_template_directory_uri() . '/js/smartmenus-bootstrap.min.js', array(
		'jquery',
		'smartmenus'
	), '1.0.0', true );
	wp_enqueue_script( 'smartmenus-bootstrap' );
}

add_action( 'wp_enqueue_scripts', 'lana_blog_menu_scripts' );

/**
 * Bootstrap menu
 * Styles
 */
function lana_blog_menu_styles() {

	/** jquery smartmenus bootstrap addons */
	wp_register_style( 'smartmenus-bootstrap', get_template_directory_uri() . '/css/smartmenus-bootstrap.min.css', array( 'bootstrap' ), '1.0.0' );
	wp_enqueue_style( 'smartmenus-bootstrap' );
}

add_action( 'wp_enqueue_scripts', 'lana_blog_menu_styles' );

/**
 * Lana Main Navigation Menu
 * with Bootstrap
 *
 * @param array $args
 */
function lana_blog_main_nav_menu( $args = array() ) {

	$args = array_merge( array(
		'theme_location' => 'lana_main',
		'menu_class'     => 'nav navbar-nav',
		'container'      => false,
		'walker'         => new Lana_Blog_Walker_Nav_Menu()
	), $args );

	wp_nav_menu( apply_filters( 'lana_blog_main_nav_menu_args', $args ) );
}

register_nav_menu( 'lana_main', __( 'Lana Main Menu', 'lana-blog' ) );

/**
 * Lana Blog
 * main fallback nav menu args
 *
 * @param $args
 *
 * @return array
 */
function lana_blog_main_fallback_nav_menu_args( $args ) {

	/** fallback nav */
	if ( ! has_nav_menu( 'lana_main' ) ) {
		$args = wp_parse_args( $args, array(
			'menu_class'  => 'nav navbar-nav fallback-nav',
			'fallback_cb' => 'Lana_Blog_Walker_Nav_Menu::fallback'
		) );
	}

	return $args;
}

add_filter( 'lana_blog_main_nav_menu_args', 'lana_blog_main_fallback_nav_menu_args' );

/**
 * Add empty menu hidden class to main navbar
 *
 * @param $classes
 *
 * @return array
 */
function lana_blog_empty_menu_hidden_class_to_main_navbar( $classes ) {

	$theme_locations = get_nav_menu_locations();


	/** check theme locations */
	if ( ! isset( $theme_locations['lana_main'] ) ) {
		return $classes;
	}

	$lana_menu = get_term( $theme_locations['lana_main'], 'nav_menu' );

	/** check theme location */
	if ( is_wp_error( $lana_menu ) ) {
		return $classes;
	}

	$nav_menu_items = wp_get_nav_menu_items( $lana_menu->slug );

	if ( is_a( $lana_menu, 'WP_Term' ) && empty( $nav_menu_items ) ) {
		$classes[] = 'hidden';
	}

	return $classes;
}

add_filter( 'lana_blog_main_navbar_in_header_class', 'lana_blog_empty_menu_hidden_class_to_main_navbar' );
add_filter( 'lana_blog_main_navbar_in_content_class', 'lana_blog_empty_menu_hidden_class_to_main_navbar' );


/**
 * Lana Nav Walker
 * with Bootstrap
 */
class Lana_Blog_Walker_Nav_Menu extends Walker_Nav_Menu {

	/**
	 * Starts the list before the elements are added
	 *
	 * @param string $output
	 * @param int $depth
	 * @param array $args
	 */
	function start_lvl( &$output, $depth = 0, $args = array() ) {

		$indent = str_repeat( "\t", $depth );

		$classes = array( 'dropdown-menu', 'animated', 'slideInUp', 'depth_' . $depth );

		$class_names = join( ' ', apply_filters( 'nav_children_element_css_class', array_filter( $classes ), $args, $depth ) );
		$class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';

		$output .= $indent . '<ul' . $class_names . '>';
	}

	/**
	 * Starts the element output
	 *
	 * @param string $output
	 * @param object $item
	 * @param int $depth
	 * @param object|array $args
	 * @param int $id
	 */
	function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {

		/**
		 * Filter
		 * args
		 */
		$args = apply_filters( 'nav_menu_item_args', $args, $item, $depth );

		/**
		 * Indent
		 */
		$indent = '';

		if ( $depth ) {
			$indent = str_repeat( "\t", $depth );
		}

		/**
		 * <li> tag
		 * attributes
		 */
		$classes = array();

		if ( ! empty( $item->classes ) ) {
			$classes = (array) $item->classes;
		}

		$classes[] = 'menu-item-' . $item->ID;

		if ( $item->current || $item->current_item_ancestor ) {
			$classes[] = 'active';
		}

		/**
		 * <li> tag - classes
		 * filters the CSS class(es)
		 */
		$class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args, $depth ) );
		$class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';

		/**
		 * <li> tag - id
		 * filters the ID
		 */
		$id = apply_filters( 'nav_menu_item_id', 'menu-item-' . $item->ID, $item, $args, $depth );
		$id = $id ? ' id="' . esc_attr( $id ) . '"' : '';

		$output .= $indent . '<li' . $id . $class_names . '>';

		/**
		 * <a> tag
		 * attributes
		 */
		$atts = array();

		$atts['title']  = ! empty( $item->attr_title ) ? $item->attr_title : '';
		$atts['target'] = ! empty( $item->target ) ? $item->target : '';
		$atts['rel']    = ! empty( $item->xfn ) ? $item->xfn : '';
		$atts['href']   = ! empty( $item->url ) ? $item->url : '';

		/**
		 * <a> tag
		 * attributes filter
		 */
		$atts = apply_filters( 'nav_menu_link_attributes', $atts, $item, $args, $depth );

		$attributes = '';
		foreach ( $atts as $attr => $value ) {
			if ( ! empty( $value ) ) {
				$value      = ( 'href' === $attr ) ? esc_url( $value ) : esc_attr( $value );
				$attributes .= ' ' . $attr . '="' . $value . '"';
			}
		}

		/**
		 * Filter
		 * title
		 */
		$title = apply_filters( 'the_title', $item->title, $item->ID );
		$title = apply_filters( 'nav_menu_item_title', $title, $item, $args, $depth );

		$item_output = $args->before;
		$item_output .= '<a' . $attributes . '>';
		$item_output .= $args->link_before . $title . $args->link_after;

		if ( isset( $args->walker->has_children ) && $args->walker->has_children ) {
			$item_output .= ' <span class="caret"></span> ';
		}

		$item_output .= '</a>';
		$item_output .= $args->after;

		$output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
	}

	/**
	 * Fallback function
	 * to: fallback_cb
	 *
	 * @param $args
	 */
	public static function fallback( $args ) {

		$output = '';

		$list_args = $args;

		/** home */
		$class = '';

		if ( is_front_page() && ! is_paged() ) {
			$class = ' class="active"';
		}

		$output .= '<li' . $class . '><a href="' . esc_url( home_url( '/' ) ) . '">' . $args['link_before'] . __( 'Home', 'lana-blog' ) . $args['link_after'] . '</a></li>';

		/** If the front page is a page, add it to the exclude list */
		if ( get_option( 'show_on_front' ) == 'page' ) {
			if ( ! empty( $list_args['exclude'] ) ) {
				$list_args['exclude'] .= ',';
			} else {
				$list_args['exclude'] = '';
			}
			$list_args['exclude'] .= get_option( 'page_on_front' );
		}

		/** pages */
		$output .= wp_list_pages( wp_parse_args( array(
			'echo'     => false,
			'title_li' => '',
			'walker'   => new Lana_Blog_Walker_Page()
		), $list_args ) );

		/** add a menu in admin */
		if ( current_user_can( 'manage_options' ) ) {
			$output .= '<li class="pull-right"><a href="' . esc_url( admin_url( 'nav-menus.php' ) ) . '">' . $args['link_before'] . __( 'Add a menu', 'lana-blog' ) . $args['link_after'] . ' <span class="label label-right label-default">' . __( 'admin', 'lana-blog' ) . '</span></a></li>';
		}

		$container = 'ul';

		$attrs = '';
		if ( ! empty( $args['menu_id'] ) ) {
			$attrs .= ' id="' . esc_attr( $args['menu_id'] ) . '"';
		}

		if ( ! empty( $args['menu_class'] ) ) {
			$attrs .= ' class="' . esc_attr( $args['menu_class'] ) . '"';
		}

		$output = '<' . $container . $attrs . '>' . $output . '</' . $container . '>';

		echo $output;
	}
}

/**
 * Lana Page Walker
 * with Bootstrap
 */
class Lana_Blog_Walker_Page extends Walker_Page {

	/**
	 * Outputs the beginning of the current level in the tree before elements are output
	 *
	 * @param string $output
	 * @param int $depth
	 * @param array $args
	 */
	public function start_lvl( &$output, $depth = 0, $args = array() ) {
		if ( isset( $args['item_spacing'] ) && 'preserve' === $args['item_spacing'] ) {
			$t = "\t";
			$n = "\n";
		} else {
			$t = '';
			$n = '';
		}
		$indent = str_repeat( $t, $depth );

		$classes = array( 'children', 'dropdown-menu', 'depth_' . $depth );

		$class_names = join( ' ', $classes );
		$class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';

		$output .= $n . $indent . '<ul ' . $class_names . '>' . $n;
	}

	/**
	 * Outputs the beginning of the current element in the tree
	 *
	 * @param string $output
	 * @param WP_Post $page
	 * @param int $depth
	 * @param array $args
	 * @param int $current_page
	 */
	public function start_el( &$output, $page, $depth = 0, $args = array(), $current_page = 0 ) {

		/** add caret */
		if ( isset( $args['pages_with_children'][ $page->ID ] ) ) {
			$args['link_after'] .= ' <span class="caret"></span> ';
		}

		/** add nav item class to li */
		add_filter( 'page_css_class', array( $this, 'add_nav_item_class' ), 10, 4 );

		/** add nav link class to a */
		add_filter( 'page_menu_link_attributes', array( $this, 'add_nav_link_class' ), 10, 5 );

		parent::start_el( $output, $page, $depth, $args, $current_page );
	}

	/**
	 * Add nav item class to current page item
	 *
	 * @param $css_class
	 * @param $page
	 * @param $depth
	 * @param $args
	 *
	 * @return array
	 */
	public static function add_nav_item_class( $css_class, $page, $depth, $args ) {

		/** current element */
		$is_current = array_intersect( array(
			'current_page_item',
			'current_page_parent',
			'current_page_ancestor'
		), $css_class );

		if ( ! empty( $is_current ) ) {
			$css_class[] = 'active';
		}

		return $css_class;
	}

	/**
	 * Add link class
	 *
	 * @param $atts
	 * @param WP_Post $page
	 * @param $depth
	 * @param $args
	 * @param $current_page
	 *
	 * @return mixed
	 */
	public static function add_nav_link_class( $atts, $page, $depth, $args, $current_page ) {

		if ( ! isset( $atts['class'] ) ) {
			$atts['class'] = array();
		}

		if ( empty( $atts['class'] ) ) {
			$atts['class'] = array();
		}

		if ( is_string( $atts['class'] ) ) {
			$atts['class'] = explode( ' ', $atts['class'] );
		}

		/** child element */
		if ( $depth > 0 ) {
			/** current element */
			if ( ! empty( $current_page ) ) {
				$_current_page = get_post( $current_page );
				if ( $_current_page && in_array( $page->ID, $_current_page->ancestors ) ) {
					$atts['class'][] = 'active';
				}
				if ( $page->ID == $current_page ) {
					$atts['class'][] = 'active';
				} elseif ( $_current_page && $page->ID == $_current_page->post_parent ) {
					$atts['class'][] = 'active';
				}
			} elseif ( $page->ID == get_option( 'page_for_posts' ) ) {
				$atts['class'][] = 'active';
			}
		}

		$atts['class'] = implode( ' ', $atts['class'] );

		return $atts;
	}
}