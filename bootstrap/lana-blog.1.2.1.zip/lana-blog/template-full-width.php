<?php
/**
 * Template Name: Full Width Page
 * Description: Page Template without a main sidebar.
 */
?>

<?php get_header(); ?>

    <div class="row">

        <div class="col-md-12">

			<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

                <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

                    <h3 class="page-title">
						<?php the_title(); ?>
                    </h3>

                    <div class="panel panel-primary">
                        <div class="panel-body">
							<?php the_content(); ?>
                        </div>

						<?php wp_link_pages(); ?>

						<?php if ( comments_open() || get_comments_number() ) : ?>
                            <div class="panel-footer">
								<?php comments_template(); ?>
                            </div>
						<?php endif; ?>
                    </div>

                </div>

			<?php endwhile; ?>

			<?php else : ?>
                <p><?php _e( 'Sorry, this page does not exist.', 'lana-blog' ); ?></p>
			<?php endif; ?>

        </div>

    </div>

<?php get_footer(); ?>