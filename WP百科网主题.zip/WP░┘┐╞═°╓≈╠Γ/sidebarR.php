<div class="sidebarR">
     <ul>
	<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(3) ) : else : ?>
        <li>
        <h3><?php _e('Archives'); ?></h3>
            <ul>
            <?php wp_get_archives('type=monthly'); ?>
            </ul>
        </li>
	<?php endif; ?>
	</ul>
</div>