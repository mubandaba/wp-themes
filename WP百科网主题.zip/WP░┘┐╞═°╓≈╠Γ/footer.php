</div>
<!-- Content end -->
<div class="clear"></div>
<!-- Footer begin -->
<div id="footer">
    <p>Copyright &copy; <?php echo date("Y"); ?> Powered by <a href="http://www.wordpress.org/" target="_blank">Wordpress</a> | Theme by <a href="http://www.wp百科网.com/"  target="_blank">WP百科网</a> 
    <?php if (get_option('wpyou_site_analytics')) { ?>
		 | <?php echo get_option('wpyou_site_analytics'); ?>
	<?php } ?>
  </p>
    <span><a href="#header" class="anchorLink">返回顶部</a></span>
</div>
<!-- Footer end -->
<?php wp_footer(); ?>
</body>
</html>