<?php get_header(); ?>
<!-- Article begin -->
<div class="article">
            <div class="post archive">
            	<h2>抱歉,没有找到合适的文章.</h2>
                <div class="clear"></div>
            	<p>请您<a href="<?php echo get_settings('home'); ?>">返回首页</a>或在搜索中查找您所需的信息.带来不便,敬请谅解!</p>
            </div>
    <!-- Navigation begin -->
    <div class="page_navi">
    	<a href="<?php echo get_settings('home'); ?>">&laquo; 返回首页</a>
    </div>
    <!-- Navigation end -->
</div>
<!-- Article end -->
<!-- Sidebar begin -->
	<?php include (TEMPLATEPATH . '/sidebar.php'); ?>
<!-- Sidebar end -->
<?php get_footer(); ?>