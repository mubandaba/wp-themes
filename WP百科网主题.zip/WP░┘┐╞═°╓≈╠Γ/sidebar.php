<div class="sidebar">
	<?php include (TEMPLATEPATH . '/topbar.php'); ?>
    <?php include (TEMPLATEPATH . '/sidebarL.php'); ?>
    <?php include (TEMPLATEPATH . '/sidebarR.php'); ?>
</div>