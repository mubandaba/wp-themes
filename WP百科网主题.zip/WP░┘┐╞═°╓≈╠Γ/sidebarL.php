<div class="sidebarL">
	<ul>
	<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(2) ) : else : ?>           
        <li>
        <h3><?php _e('Meta'); ?></h3>
            <ul>
            <?php wp_register(); ?>
            <li><?php wp_loginout(); ?></li>
            <?php wp_meta(); ?>
            </ul>
        </li>
        <li>
        <h3><?php _e('Links'); ?></h3>
            <ul>
             <?php get_links('', '<li>', '</li>', '', TRUE, 'url', FALSE); ?>
             </ul>
        </li>
	<?php endif; ?>  
	</ul>
</div>