<?php
	get_header(); 
	get_template_part( 'template-parts/loop/loop', 'search' );
	get_template_part( 'template-parts/home/home', 'card' );
	get_template_part( 'template-parts/loop/loop', 'nav' );
?>


<?php get_template_part( 'template-parts/home/home', 'site' ); ?>



<?php get_footer();?>