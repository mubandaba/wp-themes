<section class="uk-margin-top uk-position-relative uk-padding-remove-bottom uk-margin-bottom">
	<div class="search uk-container uk-padding uk-padding-remove-horizontal">
		<ul class="search-tmenu uk-text-center" uk-switcher>
		    <li class="uk-display-inline-block"><a>本站</a></li>
		    <li class="uk-display-inline-block"><a>常用</a></li>
		    <li class="uk-display-inline-block"><a>工具</a></li>
		    <li class="uk-display-inline-block"><a>社区</a></li>
		    <li class="uk-display-inline-block"><a>灵感</a></li>
		</ul>
		<form id="searchForm" class="shadow b-r-4 uk-form uk-flex uk-position-relative uk-overflow-hidden" action="/?s=" method="get" target="_blank">
		    <input id="searchinput" class="uk-input uk-text-small" type="text" placeholder="站内搜索"  autocomplete="off">
		    <button id="searc-submit" class="uk-text-bold" type="submit">搜索</button>
    		<i class="iconfont icon-sousuo uk-position-center-left uk-margin-small-left"></i>
		</form>
		<ul id="subnav"  class="uk-switcher uk-margin uk-text-center">
		    <div class="subnav-item">
		    	<ul class="search-bmenu uk-padding-remove">
		    		<li class="search-item on uk-display-inline-block" url="/?post_type=post&s=">文章</li>
		    		<li class="search-item uk-display-inline-block" url="/?post_type=sites&s=">网站</li>
		    	</ul>
		    </div>
		    <div class="subnav-item">
		    	<ul class="search-bmenu uk-padding-remove">
		    		<li class="search-item on uk-display-inline-block" url="https://www.baidu.com/s?wd=">百度</li>
		    		<li class="search-item uk-display-inline-block" url="https://www.google.com/search?q=">Google</li>
		    		<li class="search-item uk-display-inline-block" url="https://www.so.com/s?q=">360</li>
		    		<li class="search-item uk-display-inline-block" url="https://www.sogou.com/web?query=">搜狗</li>
		    		<li class="search-item uk-display-inline-block" url="https://cn.bing.com/search?q=">必应</li>
		    		<li class="search-item uk-display-inline-block" url="https://yz.m.sm.cn/s?q=">神马</li>
		    	</ul>
		    </div>
		    <div class="subnav-item">
		    	<ul class="search-bmenu uk-padding-remove">
		    		<li class="search-item on uk-display-inline-block" url="http://rank.chinaz.com/all/">权重查询</li>
		    		<li class="search-item uk-display-inline-block" url="http://link.chinaz.com/">友链检测</li>
		    		<li class="search-item uk-display-inline-block" url="https://icp.aizhan.com/">备案查询</li>
		    		<li class="search-item uk-display-inline-block" url="http://ping.chinaz.com/">PING检测</li>
		    		<li class="search-item uk-display-inline-block" url="http://tool.chinaz.com/Links/?DAddress=">死链检测</li>
		    	</ul>
		    </div>
		    <div class="subnav-item">
		    	<ul class="search-bmenu uk-padding-remove">
		    		<li class="search-item on uk-display-inline-block" url="https://www.zhihu.com/search?type=content&q=">知乎</li>
		    		<li class="search-item uk-display-inline-block" url="http://weixin.sogou.com/weixin?type=2&query=">微信</li>
		    		<li class="search-item uk-display-inline-block" url="http://s.weibo.com/weibo/">微博</li>
		    		<li class="search-item uk-display-inline-block" url="https://www.douban.com/search?q=">豆瓣</li>
		    	</ul>
		    </div>
		    <div class="subnav-item">
		    	<ul class="search-bmenu uk-padding-remove">
		    		<li class="search-item on uk-display-inline-block" url="https://www.huaban.com/search/?q=">花瓣</li>
		    		<li class="search-item uk-display-inline-block" url="https://dribbble.com/search/">dribbble</li>
		    		<li class="search-item uk-display-inline-block" url="https://www.behance.net/search?search=">behance</li>
		    		<li class="search-item uk-display-inline-block" url="http://www.zcool.com.cn/search/content?&word=">站酷</li>
		    	</ul>
		    </div>
		</ul>
	</div>
</section>