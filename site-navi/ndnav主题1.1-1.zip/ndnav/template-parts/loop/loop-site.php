<?php 
    $thumb = get_post_meta(get_the_ID(), '_thumbnail', true); 
    $default_thumb = _aye('default_thum');
?>
<div class="site b-r-4 shadow uk-padding-small uk-position-relative uk-overflow-hidden uk-background-default">
	<a class="item b-b uk-grid-collapse" href="<?php the_permalink(); ?>" target="_blank" uk-grid>
		<i class="icon uk-width-auto uk-display-block" style="background-image: url(<?php if(!$thumb) { echo $default_thumb;}else{echo $thumb;} ?>);"></i>
		<div class="uk-width-expand uk-margin-small-left uk-text-small">
			<h3 class="uk-display-block"><?php the_title(); ?></h3>
			<div class="desc uk-text-truncate"><?php echo wp_trim_words( get_the_content(), 66 ); ?></div>
		</div>
	</a>

	<div class=" uk-flex uk-flex-1">
		<div class="info uk-text-small uk-width-1-1">
			<span><i class="iconfont icon-see"></i><?php post_views('', ''); ?></span>
			<span class="uk-float-right"><a href="<?php echo get_post_meta(get_the_ID(), '_sites_link', true) ?>" target="_blank" rel="nofollow" uk-tooltip="点击直达"><i class="iconfont icon-go"></i></a></span>
		</div>
	</div>
</div>