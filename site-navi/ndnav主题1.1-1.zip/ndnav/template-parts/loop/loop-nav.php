<section class="nav shadow b-r-4 uk-flex uk-flex-middle uk-background-default uk-position-relative uk-margin-top">
	<ul class="uk-flex-1">
		<?php aye_menu('main-nav'); ?>
	</ul>
</section>