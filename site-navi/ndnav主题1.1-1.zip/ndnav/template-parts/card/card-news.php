<div class="card shadow uk-margin-bottom">
	<div class="b-r-4 uk-height-1-1 uk-flex-middle uk-background-default uk-overflow-hidden">
		<div class="title uk-flex uk-flex-middle">
			<i class="uk-display-inline-block"><img src="<?php bloginfo('template_url'); ?>/static/images/icon-time.png"/></i>
			<span class="uk-text-small">最新</span>
		</div>
		<ul class="notice uk-margin-remove">
            <?php
			$args = array( 'post_type' => 'sites', 'posts_per_page' => 5 );
			$loop = new WP_Query( $args );
			while ( $loop->have_posts() ) : $loop->the_post(); 
			$thumb = get_post_meta(get_the_ID(), '_thumbnail', true); 
            $default_thumb = get_bloginfo('template_url').'/static/images/default-thumb.png';
			?>
            <li class="uk-flex uk-flex-middle">
                <i class="uk-display-inline-block"><img src="<?php if(!$thumb) { echo $default_thumb;}else{echo $thumb;} ?>" class="uk-height-1-1" /></i>
                <a class="uk-flex-1 uk-display-block uk-text-truncate" href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a>
                <span class="uk-text-small uk-text-muted uk-margin-small-right"><?php echo time_since($post->post_date);?></span>
            </li>
            <?php endwhile; wp_reset_query(); ?>
			
		</ul>
	</div>
</div>