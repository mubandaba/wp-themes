<div class="card shadow uk-margin-bottom">
	<div class="b-r-4 uk-height-1-1 uk-background-default uk-overflow-hidden">
		<div class="title uk-flex uk-flex-middle">
			<div class="uk-flex-1 uk-flex uk-flex-middle">
				<i class="uk-display-inline-block"><img src="<?php bloginfo('template_url'); ?>/static/images/icon-tags.png"/></i>
				<span class="uk-text-small">工具</span>
			</div>
		</div>
		<div class="tags uk-margin-remove">
		    <?php 
		    $tool = _aye('tool');
		    if ($tool) { 
            	foreach ( $tool as $key => $value) {
            ?>
            <a href="<?php echo $value['link']; ?>" target="_blank" rel="nofollow"><?php echo $value['title']; ?></a>
            <?php } }?>
		</div>
	</div>
</div>