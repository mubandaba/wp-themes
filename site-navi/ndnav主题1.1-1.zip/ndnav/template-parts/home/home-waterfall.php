<section class="images">
	<div class="ajaxMain uk-grid-small uk-margin-top" uk-grid="masonry: true">
		<?php if ( have_posts() ) :  while ( have_posts() ) : the_post(); ?>
		<div class="ajaxItem uk-width-1-2 uk-width-1-3@m  uk-width-1-4@l  uk-width-1-5@xl">
			<?php get_template_part( 'template-parts/loop/loop', 'card' );?>
		</div>
		<?php endwhile; endif; ?>
	</div>
	<div class="fenye uk-text-center uk-margin-medium uk-width-1-1 uk-margin-large-top">
		<?php fenye(); ?>
	</div>
</section>