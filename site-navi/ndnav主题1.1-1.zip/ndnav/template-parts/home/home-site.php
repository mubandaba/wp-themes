<section>
	<ul class="site-title b-b uk-padding-remove-left uk-margin-medium-top" uk-switcher>
		<li class="uk-display-inline-block uk-position-relative uk-margin-right uk-active" aria-expanded="true">
			<span>最新收录</span>
		</li>
		<li class="uk-display-inline-block uk-position-relative" aria-expanded="false">
			<span>热门网址</span>
		</li>
	</ul>
	<ul id="site" class="uk-switcher">
		<div class="uk-animation-slide-left-small">
			<div uk-grid>
				<?php
				$args = array( 
				    'post_type' => 'sites',
				    'posts_per_page' => 8 
				);
				$loop = new WP_Query( $args );
				while ( $loop->have_posts() ) : $loop->the_post(); 
				?>

				<div class="uk-width-1-1@s uk-width-1-4@m uk-width-1-4@l uk-width-1-4@xl">
					<?php get_template_part( 'template-parts/loop/loop', 'site' ); ?>

				</div>
				<?php endwhile; ?>
			</div>
		</div>
		<div class="uk-animation-slide-left-small">
			<div uk-grid>
				<?php
				$args = array( 
					'post_type' => 'sites', 
					'meta_key' => 'views',
					'orderby' => 'meta_value_num',
					'posts_per_page' => 8,
					//'orderby' => 'rand',
				);
				$loop = new WP_Query( $args );
				while ( $loop->have_posts() ) : $loop->the_post(); 
				?>

				<div class="uk-width-1-1@s uk-width-1-4@m uk-width-1-4@l uk-width-1-4@xl">
					<?php get_template_part( 'template-parts/loop/loop', 'site' ); ?>

				</div>
				<?php endwhile; ?>
			</div>
		</div>
	</ul>
</section>
<section class="uk-margin-medium-top uk-margin-medium-bottom">
    <?php
    	$args=array(
    		'taxonomy' => 'favorites',
    		'hide_empty'=>'0',
    		'hierarchical'=>1,
    		'parent'=>'0',
    	);
    	$categories=get_categories($args);
    	foreach($categories as $category){
    		$cat_id = $category->term_id;
    ?>
	<div class="uk-margin-medium-bottom">
		<div class="site-title uk-flex uk-flex-middle" id="site<?php echo $category->term_id; ?>" >
		<h2 class="uk-flex-1"><?php echo $category->name;?></h2>
		<a class="uk-text-small" href="<?php echo get_category_link( $category->term_id )?>" target="_blank">查看更多<i class="iconfont  icon-arrow-right"></i></a>
		</div>
		<div class="uk-grid-medium" uk-grid>
			<?php
				$salong_posts = new WP_Query(
					array(
						'post_type' => 'sites',//自定义文章类型，这里为video
						'ignore_sticky_posts' => 1,//忽略置顶文章
						'posts_per_page' => 8,//显示的文章数量
						'meta_key' => 'views', //访问量
						'orderby' => 'meta_value_num', //访问量排序
						'tax_query' => array(
							array(
								'taxonomy' => 'favorites',//分类法名称
								'field'    => 'id',//根据分类法条款的什么字段查询，这里设置为ID
								'terms'    => $cat_id,//分类法条款，输入分类的ID，多个ID使用数组：array(1,2)
							)
						),
					)
				);
				if ($salong_posts->have_posts()): while ($salong_posts->have_posts()): $salong_posts->the_post(); 
			?>
			<div class="uk-width-1-1@s uk-width-1-4@m uk-width-1-4@l uk-width-1-4@xl">
				<?php get_template_part( 'template-parts/loop/loop', 'site' ); ?>
			</div>
			<?php endwhile; endif; ?>

		</div>
	</div>
    <?php }?>
</section>

