<?php
	get_header(); 
	get_template_part( 'template-parts/loop/loop', 'nav' );
?>

<style>
	.page404 {}
	.page404 .btn {
		padding: 12px 30px;
    border-radius: 50px;
	}
	.page404 h1 {
		font-size: 10rem;
	}
	
</style>
<section class="uk-flex uk-flex-middle">
	<div class="uk-container uk-padding-large">
		<div class="page404 uk-text-center uk-padding-large">
			<h1 class="uk-text-bolder">404</h1>
			<p class="uk-text-muted uk-h4 uk-margin-bottom uk-margin-remove-top">Sorry，页面丢失了，要不返回首页吧？</p>
		</div>
	</div>
</section>
<?php get_footer(); ?>