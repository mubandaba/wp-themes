<?php
/*
Template Name: 投稿模板
*/
    get_header(); 
    get_template_part( 'template-parts/loop/loop', 'search' );
    $categories= get_categories(array(
      'taxonomy'     => 'favorites',
      'meta_key'     => '_term_order',
      'orderby'      => 'meta_value_num',
      'order'        => 'desc',
      'hide_empty'   => 0,
      )
    ); 
?>
<section class="tougao uk-container">
    <div class="panel-tougao b-a b-r-4 uk-background-default uk-padding">
        <h1 class="uk-h4 b-b"><?php echo get_the_title() ?></h1>
        <div class="panel-body mt-2">
            <div class="row">
                <div class="col-sm-12">
                    <?php while( have_posts() ): the_post(); ?>
    	            <?php the_content();?>
                    <?php endwhile; ?> 
                </div> 
            </div>
        </div>
        <form id="tougao" class="uk-form" method="post" action="<?php echo $_SERVER["REQUEST_URI"]?>">
            <div class="uk-margin-bottom">
                <label for="tougao_sites_ico">网站图标：</label>
                <input type="hidden" value="" id="tougao_sites_ico" class="b-r-4 uk-input" name="tougao_sites_ico" />
                <div class="upload_img b-a b-r-4 uk-margin-small-top">
                    <div class="show_ico">
                        <img id="show_sites_ico" src="https://nav.iowen.cn/wp-content/themes/webstackpro/images/add.png' ?>" alt="网站图标">
                        <i id="remove_sites_ico" class="fa fa-times-circle remove" data-id="" data-type="sites_ico" style="display: none;"></i>
                    </div> 
                    <input type="file" id="upload_sites_ico" data-type="sites_ico" accept="image/*" onchange="uploadImg(this)" >
                </div>
            </div>
            <div class="uk-grid-small" uk-grid>
                <div class="input-group uk-inline uk-width-1-1 uk-width-1-1@s uk-width-1-2@m uk-width-1-2@l uk-width-1-2@lx">
                    <input type="text" class="b-r-4 b-a form-control uk-input" value="" id="tougao_title" name="tougao_title" placeholder="网站名称 *" maxlength="30"/>
                </div>
                <div class="input-group uk-inline uk-width-1-1 uk-width-1-1@s uk-width-1-2@m uk-width-1-2@l uk-width-1-2@lx">
                    <input type="text" class="b-r-4 b-a form-control uk-input" value="" id="tougao_sites_link" name="tougao_sites_link" placeholder="网站链接 *"/>
                </div>
            </div>
            <div class="uk-grid-small" uk-grid>
                <div class="input-group uk-inline uk-width-1-1 uk-width-1-1@s uk-width-1-2@m uk-width-1-2@l uk-width-1-2@lx">
                    <input type="text" class="b-r-4 b-a form-control uk-input" value="" id="tougao_sites_sescribe" name="tougao_sites_sescribe"  placeholder="网站关键字，请用英语逗号分隔" maxlength="50"/>
                </div>
                
                <div class="input-group uk-inline uk-width-1-1 uk-width-1-1@s uk-width-1-2@m uk-width-1-2@l uk-width-1-2@lx">
                    <?php
                    $cat_args = array(
                        'show_option_all'     => "选择分类 *",
                        'hide_empty'          => 0,
                        'id'                  => 'tougaocategorg',
                        'taxonomy'            => 'favorites',
                        'name'                => 'tougao_cat',
                        'class'               => 'form-control',
                        'show_count'          => 1,
                        'hierarchical'        => 1,
                    );
                    wp_dropdown_categories($cat_args);
                    ?>
                </div>
            </div>
            <div class="uk-margin-top">
                <textarea rows="6" cols="55" id="tougao_content" class="b-r-4 b-a uk-textarea" name="tougao_content" placeholder="网站描述 (不少于6字)"></textarea>
            </div>
            <div class="input-group uk-margin-top uk-width-1-2 uk-width-1-5@xl uk-flex uk-flex-middle">
                <input type="text" name="tougao_form"  class="b-r-4 b-a form-control uk-input" id="inputVeri" maxlength="4" placeholder="输入验证码">
                <div id="verification-text" class="uk-margin-small-left">0000</div>
            </div>
            <div class="uk-margin-top">
                <button id="submit" type="submit" class="btn b-r-4 uk-button">提交</button>
            </div>
        </form> 
    </div>
</section>
<style>
    .alert-body {
        min-width: 160px;
    }
    .alert {
        padding: 12px;
        border-radius: 4px;
        color: #fff;
    }
    .alert-success {
        background: #32d296;
    }
    .alert-info {
        background: #1e87f0;
    }
    .alert-warning {
        background: #faa05a;
    }
    .alert-danger {
        background: #f0506e
    }
</style>
<script> 
    var verification = Math.floor(Math.random()*(9999-1000+1)+1000);
    $('#verification-text').text(verification);

    $('#tougao').submit(function() {
        if($('#inputVeri').val() != verification){
            showAlert(JSON.parse('{"status":3,"msg":"验证码错误！"}'));
            return false;
        }
		$.ajax({
    	    url: ayetheme.ajaxurl,
            type:     'POST',
            dataType: 'json',
            data:     $(this).serialize() + "&action=contribute_post", 
        }).done(function (result) {
            if(result.status == 1){
                verification = Math.floor(Math.random()*(9999-1000+1)+1000);
                $('#verification-text').text(verification);
            }
            showAlert(result);
        }).fail(function (result) {
            showAlert(JSON.parse('{"status":3,"msg":"网络连接错误！"}'));
        });
        return false;
    });
    function showAlert(data) {
        var alert,ico;
        switch(data.status) {
            case 1: 
                alert='success';
               break;
            case 2: 
                alert='info';
               break;
            case 3: 
                alert='warning';
               break;
            case 4: 
                alert='danger';
               break;
            default: 
        } 
        var msg = data.msg;
        $html = $('<div class="alert-body" style="display:none;"><div class="alert alert-'+alert+'"><span>'+msg+'</span></div></div>');
        $('#alert_placeholder').append( $html );//prepend
        $html.show(100).delay(3000).hide(200, function(){ $(this).remove() }); 
    }
    function uploadImg(file) {
        var doc_id=file.getAttribute("data-type");
        if (file.files != null && file.files[0] != null) {
            if (!/\.(jpg|jpeg|png|JPG|PNG|ico)$/.test(file.files[0].name)) {    
                showAlert(JSON.parse('{"status":3,"msg":"图片类型只能是jpeg,jpg,png！"}'));   
                return false;    
            } 
            if(file.files[0].size > (1000 * 1024)){
                showAlert(JSON.parse('{"status":3,"msg":"图片大小不能超过1M"}'));
                return false;
            }
            var formData = new FormData();
            formData.append('files', file.files[0]);
            formData.append('action','img_upload');
    	    $.ajax({
    	        url: ayetheme.ajaxurl,
                type: 'POST',
                data: formData,
                dataType: 'json',
                cache: false,
                processData: false,
                contentType: false
            }).done(function (result) {
                //console.log('--->>>'+JSON.stringify(result));
                showAlert(result);
                if(result.status == 1){
                    $("#show_"+doc_id).attr("src", result.data.src);
                    $("#tougao_"+doc_id).val(result.data.src);
                    $("#remove_"+doc_id).data('id',result.data.id).show();
                    $(file).attr("disabled","disabled").parent().addClass('disabled');
                }
            }).fail(function (result) {
                showAlert(JSON.parse('{"status":3,"msg":"网络连接错误！"}'));
            });
        }else{
            showAlert(JSON.parse('{"status":2,"msg":"请选择文件！"}'));
            return false;
        }
    }
    $('.fa.remove').click(function() {
        if(!confirm('确定要删除图片吗?')){
            return false;
        }
        var doc_id = $(this).data('type');
		$.ajax( {
			url: ayetheme.ajaxurl,
            type: 'POST',
            dataType: 'json',
            data: {
				action: "img_remove",
				id: $(this).data("id")
			}
        }).done(function (result) {
            showAlert(result);
            if(result.status == 1){
                $("#show_"+doc_id).attr("src", theme.addico);
                $("#tougao_"+doc_id).val('');
                $("#remove_"+doc_id).data('id','').hide();
                $("#upload_"+doc_id).removeAttr("disabled").val("").parent().removeClass('disabled');
            }
        }).fail(function (result) {
            showAlert(JSON.parse('{"status":3,"msg":"网络连接错误！"}'));
        });
    });
</script>

<?php get_footer(); ?>
<div id="alert_placeholder" style="position: fixed;bottom: 20px;right:20px;z-index: 1000;"></div>
