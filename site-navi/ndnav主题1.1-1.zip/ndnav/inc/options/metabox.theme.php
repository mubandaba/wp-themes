<?php if (! defined('ABSPATH')) {
    die;
}
$prefix_page_opts = 'my_post_options';
CSF::createMetabox($prefix_page_opts, array(
    'title' => '网站信息',
    'post_type' => 'site',
    'data_type' => 'serialize',
    'show_restore' => true,
));

CSF::createSection($prefix_page_opts, array(
    'title' => '基本设置',
    'fields' => array(
        array(
            'id'    => 'site_link',
            'type'  => 'text',
            'title' => '网站链接',
        ),
        array(
          'id'           => 'site_ico',
          'type'         => 'upload',
          'title'        => '网站favicon',
          'library'      => 'image',
          'placeholder'  => 'http://',
          'button_title' => '添加favicon',
          'remove_title' => '删除favicon',
        ),
    )
));