<?php

/*
 * ------------------------------------------------------------------------------
 * WordPress开启友情链接管理
 * ------------------------------------------------------------------------------
 */

add_filter( 'pre_option_link_manager_enabled', '__return_true' );


/*
 * ------------------------------------------------------------------------------
 * WordPress搜索结果排除所有页面、自定义分类
 * ------------------------------------------------------------------------------
 */

//搜索结果排除所有页面
function search_filter_page($query) {
	if ($query->is_search) {
		$query->set('post_type', 'post');
	}
	return $query;
}
add_filter('pre_get_posts','search_filter_page');


//让搜索支持所有自定义文章类型
function include_post_types_in_search($query) {
	if(is_search()) {
		$post_types = get_post_types(array('public' => true, 'exclude_from_search' => false), 'objects');
		$searchable_types = array();
		if($post_types) {
			foreach( $post_types as $type) {
				$searchable_types[] = $type->name;
			}
		}
		$query->set('post_type', $searchable_types);
	}
	return $query;
}
add_action('pre_get_posts', 'include_post_types_in_search');


//WordPress文章标签以id方式展示
add_action('generate_rewrite_rules','tag_rewrite_rules');
add_filter('term_link','tag_term_link',10,3);
add_action('query_vars', 'tag_query_vars');

function tag_rewrite_rules($wp_rewrite){

    $new_rules = array(
        'tag/(\d+)/feed/(feed|rdf|rss|rss2|atom)/?$' => 'index.php?tag_id=$matches[1]&feed=$matches[2]',
        'tag/(\d+)/(feed|rdf|rss|rss2|atom)/?$' => 'index.php?tag_id=$matches[1]&feed=$matches[2]',
        'tag/(\d+)/embed/?$' => 'index.php?tag_id=$matches[1]&embed=true',
        'tag/(\d+)/page/(\d+)/?$' => 'index.php?tag_id=$matches[1]&paged=$matches[2]',
        'tag/(\d+)/?$' => 'index.php?tag_id=$matches[1]',
    );
    $wp_rewrite->rules = $new_rules + $wp_rewrite->rules;
}

function tag_term_link($link,$term,$taxonomy){
    if($taxonomy=='post_tag'){
        return home_url('/tag/'.$term->term_id);
    }
    return $link;
}

function tag_query_vars($public_query_vars){
    $public_query_vars[] = 'tag_id';
    return $public_query_vars;

}