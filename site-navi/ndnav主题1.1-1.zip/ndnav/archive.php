<?php
	get_header(); 
	get_template_part( 'template-parts/loop/loop', 'search' );
	get_template_part( 'template-parts/loop/loop', 'nav' );
?>
<section class="uk-margin-medium-top uk-margin-medium-bottom">
    <div class="uk-grid-medium" uk-grid>
        <?php while (have_posts()) : the_post(); ?>	
        <div class="uk-width-1-1@s uk-width-1-4@m uk-width-1-4@l uk-width-1-4@xl">
        	<?php get_template_part( 'template-parts/loop/loop', 'site' ); ?>
        </div>
        <?php endwhile; ?> 
    </div>
    <div class="uk-margin-top">
        <?php if( _aye('cat_load' ) == 1){?>
    	<div class="fenye uk-text-center uk-margin-medium uk-width-1-1 uk-margin-large-top">
    		<?php fenye(); ?>
    	</div>
    	<? }else{ ?>
    	<div id="pagination" class="ajaxBtn uk-text-center uk-margin-large-top uk-margin-large-bottom">
    		<?php next_posts_link(__('点击查看更多')); ?>
    	</div>
    	<?php } ?>
    </div>
    <?php 
        $cat_ad_show = _aye('cat_ad_show');
        if ($cat_ad_show) {
    ?>
    <a class="b-r-4 uk-overflow-hidden  uk-display-block uk-margin-bottom" hhref="<?php echo _aye('cat_ad_link'); ?>" target="_blank"><img src="<?php echo _aye('cat_ad_img'); ?>" /></a>
    <?php } ?>
</section>
<?php get_footer();?>