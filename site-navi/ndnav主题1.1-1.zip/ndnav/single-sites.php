<?php get_header(); ?>
<?php get_template_part( 'template-parts/loop/loop', 'search' );?>
<?php get_template_part( 'template-parts/loop/loop', 'nav' );?>
<section class="uk-grid-small uk-margin-top" uk-grid>
	<div class="uk-width-1-1 uk-width-1-1@m uk-width-expand@l uk-width-expand@xl">
		<div class="single b-r-4 shadow uk-background-default">
		    <?php while ( have_posts() ) : the_post(); ?>
			<div class="b-b uk-padding">
				<h1 class="uk-h5 uk-margin-remove"><?php the_title(); ?></h1>
				<div class="info uk-margin-small-top uk-flex uk-flex-middle uk-text-small">
			        <span class="uk-margin-right uk-text-muted"><?php the_time('Y-m-d') ?> 收录</span>
			        <span class="uk-flex uk-flex-middle uk-text-muted"><i class="iconfont icon-see"></i><?php post_views('', ''); ?></span>
			        <?php edit_post_link(__('编辑','i_owen'), '<span class="edit-link uk-flex-1 uk-text-right">', '</span>' ); ?>
			    </div>
			</div>
			<div class="siteSingle uk-padding">
			    <div cclass="uk-grid" uk-grid>
			        <div class="uk-width-1-1 uk-width-1-1@s uk-width-auto@m uk-width-auto@l uk-width-auto@xl">
			            <div class="icon b-r-4 uk-cover-container">
			                <img class="bg" src="<?php echo get_post_meta( get_the_ID(), '_thumbnail', true) ?>" uk-cover />
			                <i class="uk-border-circle uk-overflow-hidden uk-position-center">
			                    <img src="<?php echo get_post_meta( get_the_ID(), '_thumbnail', true) ?>" />
			                </i>
			            </div>
			        </div>
			        <div class="uk-width-1-1 uk-width-1-1@s uk-width-expand@m uk-width-expand@l uk-width-expand@xl">
			            <?php if(_aye('site_cat')) : ?>
			            <div class="cat uk-margin-bottom">
		                    <?php 
    		                    $terms = get_the_terms( get_the_ID(), 'favorites' );
                                if( !empty( $terms ) ){
                                	foreach( $terms as $term ){
                                        $name = $term->name;
                                        $link = esc_url( get_term_link( $term, 'res_category' ) );
                                        echo "<a href='$link' target='_blan'>".$name."</a>";
                                    }
                                }  
		                    ?>
			            </div>
			            <?php endif; ?>
			            <div class="desc b-r-4 uk-margin-bottom">
			                <?php the_content(); ?>
			            </div>
			            <?php if(_aye('site_tag')): ?>
			            <div class="tags uk-margin-small-bottom uk-flex uk-flex-middle">
			                <i class="iconfont icon-discount uk-margin-small-right"></i>
                            <?php the_terms( get_the_ID(), 'sitetag','', '' ); ?>
                        </div>
                        <?php endif; ?>
                        <div class="join uk-light uk-margin-top">
            			    <a class="b-r-4" href="<?php echo get_post_meta(get_the_ID(), '_sites_link', true) ?>" target="_blank" rel="nofollow" uk-tooltip="访问网站">访问网站<i class="iconfont icon-go uk-margin-small-left"></i></a>
            			</div>
			        </div>
			    </div>
			</div>
			<?php endwhile; ?>
		</div>
		<?php
    		$xg_show = _aye('xg_show');
    		$xg_title = _aye('xg_title');
    		$xg_num = _aye('xg_num');
    		if($xg_show) {
		?>  
	    
		<h4><?php echo $xg_title; ?></h4>
		<div class="uk-grid-small uk-margin-top" uk-grid> 
            <?php
                $custom_taxterms = wp_get_object_terms( $post->ID,'favorites', array('fields' => 'ids') );
                $args = array(
                'post_type' => 'sites',// 文章类型
                'post_status' => 'publish',
                'posts_per_page' => $xg_num, // 文章数量
                'orderby' => 'rand', // 随机排序
                'tax_query' => array(
                    array(
                        'taxonomy' => 'favorites', // 分类法
                        'field' => 'id',
                        'terms' => $custom_taxterms
                    )
                ),
                'post__not_in' => array ($post->ID), // 排除当前文章
                );
                $related_items = new WP_Query( $args ); 
                if ($related_items->have_posts()) :
                    while ( $related_items->have_posts() ) : $related_items->the_post();
                    $link_url = get_post_meta($post->ID, '_sites_link', true); 
            ?>
            <div class="uk-width-1-1@s uk-width-1-2@m uk-width-1-3@l uk-width-1-3@xl">
            <?php get_template_part( 'template-parts/loop/loop', 'site' ); ?>
            </div>
            <?php  endwhile; endif; wp_reset_postdata();?>
        </div>
        <?php } ?>
	</div>
	<div class="uk-width-1-1 uk-width-1-1@m uk-width-auto@l uk-width-auto@lx">
		<?php get_sidebar(); ?>
	</div>
</section>
<?php get_footer(); ?>
