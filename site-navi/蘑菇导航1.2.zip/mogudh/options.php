<?php
/**
 * A unique identifier is defined to store the options in the database and reference them from the theme.
 * By default it uses the theme name, in lowercase and without spaces, but this can be changed if needed.
 * If the identifier changes, it'll appear as if the options have been reset.
 */

function optionsframework_option_name() {

	// 从样式表获取主题名称
	$themename = wp_get_theme();
	$themename = preg_replace("/\W/", "_", strtolower($themename) );

	$optionsframework_settings = get_option( 'optionsframework' );
	$optionsframework_settings['id'] = $themename;
	update_option( 'optionsframework', $optionsframework_settings );
}

/**
 * Defines an array of options that will be used to generate the settings page and be saved in the database.
 * When creating the 'id' fields, make sure to use all lowercase and no spaces.
 *
 * If you are making your theme translatable, you should replace 'options_framework_theme'
 * with the actual text domain for your theme.  请阅读:
 * http://codex.wordpress.org/Function_Reference/load_theme_textdomain
 */

function optionsframework_options() {
	// 将所有分类（categories）加入数组
    $options_categories = array();
    $options_categories_obj = get_categories();
    foreach ($options_categories_obj as $category) {
        $options_categories[$category->cat_ID] = $category->cat_name;
    }
    $options = array();
    $options[] = array(
        'name' => __('全站设置', 'GJ') ,
        'type' => 'heading'
    );
    $options[] = array(
		'name' => '首页关键词',
		'id' => 'keywords',
		'type' => 'text'
	);
	
	$options[] = array(
		'name' => '网站描述',
		'id' => 'description',
		'type' => 'text'
	);
    $options[] = array(
        'name' => __('顶部LOGO设置', 'GJ') ,
        'id' => 'dh_logo',
		"std" =>'http://www.mogudh.com/wp-content/themes/mogudh/images/logo.png',
        'type' => 'upload'
    );
	$options[] = array(
	    'name' => __('首页LOGO设置', 'GJ') ,
	    'id' => 'home_logo',
		"std" =>'http://www.mogudh.com/wp-content/uploads/2020/01/b1b474386.gif',
	    'type' => 'upload'
	);
	$options[] = array(
	    'name' => __('侧边栏广告位1', 'GJ') ,
	    'desc' => __('图片', 'GJ') ,
	    'id' => 'propaganda1',
	    "std" =>'http://www.mogudh.com/wp-content/themes/mogudh/images/wphexin.jpg',
	    'type' => 'upload'
	);
	$options[] = array(
	    'desc' => __('链接', 'GJ') ,
	    'id' => 'ad_link1',
	    'type' => 'text'
	);
	$options[] = array(
	    'name' => __('侧边栏广告位2', 'GJ') ,
	    'desc' => __('图片', 'GJ') ,
	    'id' => 'propaganda2',
	    "std" =>'http://www.mogudh.com/wp-content/themes/mogudh/images/wphexin.jpg',
	    'type' => 'upload'
	);
	$options[] = array(
	    'desc' => __('链接', 'GJ') ,
	    'id' => 'ad_link2',
	    'type' => 'text'
	);
	$options[] = array(
	    'name' => __('打赏二维码', 'GJ') ,
	    'id' => 'qrcode',
	    "std" =>'http://www.mogudh.com/wp-content/themes/mogudh/images/icon.png',
	    'type' => 'upload'
	);
	$options[] = array(
	    'name' => __('favicon图标', 'GJ') ,
	    'id' => 'favicon',
	    "std" =>'http://www.mogudh.com/wp-content/themes/mogudh/images/favicon.ico',
	    'type' => 'upload'
	);
	/*分隔*/
    $options[] = array(
        'name' => __('移动端菜单图标', 'GJ') ,
        'type' => 'heading'
    );
    $options[] = array(
        'name' => __('仅在首页宽度小于680px时显示 , 请提前在“菜单-外观”内添加移动端菜单', 'GJ') ,
    );
    $options[] = array(
        'id' => 'm_menu_1',
        'desc' => __('图标1', 'GJ') ,
		'std' => 'http://www.mogudh.com/wp-content/themes/mogudh/images/posts.png',
        'type' => 'upload'
    );
	$options[] = array(
	    'id' => 'm_menu_2',
	    'desc' => __('图标2', 'GJ') ,
		'std' => 'http://www.mogudh.com/wp-content/themes/mogudh/images/vip.png',
	    'type' => 'upload'
	);
	$options[] = array(
	    'id' => 'm_menu_3',
	    'desc' => __('图标3', 'GJ') ,
		'std' => 'http://www.mogudh.com/wp-content/themes/mogudh/images/music.png',
	    'type' => 'upload'
	);
	$options[] = array(
	    'id' => 'm_menu_4',
	    'desc' => __('图标4', 'GJ') ,
		'std' => 'http://www.mogudh.com/wp-content/themes/mogudh/images/img.png',
	    'type' => 'upload'
	);
	$options[] = array(
	    'id' => 'm_menu_5',
	    'desc' => __('图标5', 'GJ') ,
		'std' => 'http://www.mogudh.com/wp-content/themes/mogudh/images/blog.png',
	    'type' => 'upload'
	);
	/*分隔*/
	$options[] = array(
	    'name' => __('其他设置', 'GJ') ,
	    'type' => 'heading'
	);
	$options[] = array(
	    'name' => __('将鼠标移到分类目录的“编辑”处，在显示的链接中，“ID=”后面的既是当前目录ID', 'GJ') ,
	);
	$options[] = array(
	    'name' => __('单栏页面', 'GJ') ,
		'desc' => __('设置宽屏文章及列表，可多选，例:"1,2"', 'GJ') ,
	    'id' => 'singlecolumn',
	    "std" =>'1',
	    'type' => 'text'
	); 
	$options[] = array(
	    'name' => __('双栏页面', 'GJ') ,
	    'desc' => __('设置双栏文章及列表，可多选，例:"1,2"', 'GJ') ,
	    'id' => 'doublecolumn',
	    "std" =>'14',
	    'type' => 'text'
	);
	$options[] = array(
	    'name' => __('导航目录', 'GJ') ,
	    'desc' => __('即首页“生活休闲”上方的导航目录，可多选，例:"1,2"', 'GJ') ,
	    'id' => 'navigation',
	    "std" =>'6',
	    'type' => 'text'
	);
	if ( $options_categories ) {
		$options[] = array(
			'name' => __('首页文章', 'GJ') ,
			'desc' => __('选择一项在首页站长推荐前展示', 'GJ') ,
			'id' => 'article',
			'type' => 'select',
			'class' => 'mini',
			'options' => $options_categories
		);
	}
	if ( $options_categories ) {
		$options[] = array(
			'name' => __('随机文章', 'GJ') ,
			'desc' => __('选择一项在侧边栏展示', 'GJ') ,
			'id' => 'random',
			'type' => 'select',
			'class' => 'mini',
			'options' => $options_categories
		);
	}
	$options[] = array(
	    'name' => __('侧边栏部件是否显示', 'GJ') ,
	);
	$options[] = array(
		'desc' => __( '广告位1', 'GJ' ),
		'id' => 'checkbox_img1',
		'std' => '0',
		'type' => 'checkbox'
	);
	$options[] = array(
		'desc' => __( '广告位2', 'GJ' ),
		'id' => 'checkbox_img2',
		'std' => '0',
		'type' => 'checkbox'
	);
	$options[] = array(
		'desc' => __( '随机文章', 'GJ' ),
		'id' => 'checkbox_article',
		'std' => '1',
		'type' => 'checkbox'
	);
	$options[] = array(
		'desc' => __( '热门标签', 'GJ' ),
		'id' => 'checkbox_label',
		'std' => '1',
		'type' => 'checkbox'
	);
	$options[] = array(
		'desc' => __( '最新评论', 'GJ' ),
		'id' => 'checkbox_comment',
		'std' => '1',
		'type' => 'checkbox'
	);
	/*分隔*/
	$options[] = array(
        'name' => __('代码', 'GJ') ,
        'type' => 'heading'
    );
	$options[] = array(
	    'name' => __('菜单按钮', 'Solome') ,
		'desc' => __('位于网站顶部右侧的按钮，可添加a链接', 'Solome') ,
	    'id' => 'btncode',
	    'std' => '<a href="/included">网址收录</a>',
	    'type' => 'textarea'
	); 
    $options[] = array(
        'name' => __('网站统计代码', 'Solome') ,
        'desc' => __('位于底部，用于添加第三方流量数据统计代码', 'Solome') ,
        'id' => 'trackcode',
        'type' => 'textarea'
    );
	$options[] = array(
	    'name' => __('自定义代码', 'Solome') ,
		'desc' => __('位于网站底部，可用于添加自定义代码', 'Solome') ,
	    'id' => 'customcode',
	    'std' => '<a href="/sitemap_baidu.xml" title="网站地图">网站地图</a>',
	    'type' => 'textarea'
	); 
	return $options;
}