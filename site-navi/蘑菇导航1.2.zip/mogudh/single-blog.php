	<div class="container crumbs">
		当前位置：<a href="<?php echo esc_url( home_url( '/' ) ); ?>">首页</a> » <?php the_category(' ');?>  » <span><?php the_title(); ?></span>
	</div>
	<div class="container clearfix">
		<div class="single single-left fl">
			<div class="single-cont">
				<h1><?php the_title(); ?></h1>
				<p class="head-excerpt"></p>
				<div class="other clearfix">
					<span class="item-date"><?php the_time('Y-m-d'); ?></span>
					<span class="reading fr"><?php get_post_views($post -> ID); ?>次阅读</span>
				</div>
				<div class="the-content">
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
					<?php the_content(); ?>
				<?php endwhile; endif; ?>
				</div>
				<div class="social clearfix">
				    <div class="post-like fl">
				       <a href="javascript:;" title="点赞" data-action="ding" data-id="<?php the_ID(); ?>" class="favorite<?php if(isset($_COOKIE['bigfa_ding_'.$post->ID])) echo ' done';?>"><i class="iconfont">&#xe605;</i>赞 <span class="count">
				       <?php if( get_post_meta($post->ID,'bigfa_ding',true) ) {
				        echo get_post_meta($post->ID,'bigfa_ding',true);
				        } else {
				        echo '0';
				        }?></span></a>
				    </div>
				    <div class="post-shang fl">
                      	<div class="shang-main">
                            <img src="<?php echo of_get_option( 'qrcode'); ?>" alt="打赏二维码">
                            <p>扫一扫赞助</p>
                        </div>
				    	<span>
				      		<a href="javascript:;">赏</a>
				      	</span>
				  	</div>
				    <div class="post-share fl">
						<div class="bdshare bdsharebuttonbox tx-float">
				            <a href="javascript:;" class="bds_tsina" data-cmd="tsina" title="分享到微博"></a>
				            <a href="javascript:;" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a>
				            <a href="javascript:;" class="bds_tieba" data-cmd="tieba" title="分享到贴吧"></a>
				            <a href="javascript:;" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a>
				            <a href="javascript:;" class="bds_copy" data-cmd="copy" title="复制网址"></a>
				        </div>
				        <script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"1","bdMiniList":false,"bdPic":"","bdStyle":"0","bdSize":"32"},"share":{}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script>
				        <a href="javascript:;"><i class="iconfont">&#xe60f;</i>分享</a>
				    </div>
				</div>
				<div class="list-tag"><?php the_tags('<strong>标签：</strong> ', '' , ''); ?></div>
				<p class="head-excerpt"></p>
			</div>
			<ul class="related clearfix">
				<?php $posts = query_posts('cat=' . of_get_option( 'doublecolumn') . '&showposts=4&order=DESC&orderby=date' . '&paged=' . get_query_var('paged'));
				if ($posts) : foreach( $posts as $post ) : setup_postdata( $post );{?>
					<li><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
							<div style="overflow: hidden;"><?php if ( has_post_thumbnail() ) { ?>
								<img src="<?php echo wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large')[0]; ?>" alt="<?php the_title(); ?>">
							<?php } else {?>
								<img src="<?php bloginfo('template_url'); ?>/images/list-pic.jpg" alt="<?php the_title(); ?>">
							<?php } ?></div>
							<h3 class="ell-2"><?php the_title(); ?></h3>
					</a></li>
				<?php } endforeach; endif; wp_reset_query(); ?>
			</ul>
			<p class="head-excerpt"></p>
			<?php comments_template(); ?>
			<ul class="roundSocial">
                <li class="round-up">
                    <a href="#respond" title="返回顶部">
                        <i class="iconfont">&#xe646;</i>
                    </a>
                </li>
                <li class="go-respond">
                    <a href="#respond" title="评论">
                        <i class="iconfont">&#xe62f;</i>
                    </a>
                </li>
            </ul>
		</div>
		<?php get_template_part('sidebar');  ?>
	</div>
