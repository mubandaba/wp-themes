	<div class="container crumbs">
		当前位置：<a href="<?php echo esc_url( home_url( '/' ) ); ?>">首页</a> » <?php the_category(' ');?> » <span><?php the_title(); ?></span>
	</div>
 	<div class="single-nav container">
		<div class="nav-tie">
			<strong>网站名称</strong>
		</div>
		<div class="nav-con">
			<div class="clearfix">
				<div class="nav-img fl">
					<img src="http://mini.s-shot.ru/?<?php echo get_post_meta($post->ID,"web_link_value",true);?>">
				</div>
				<div class="nav-right fr">
					<h3><?php the_title(); ?></h3>
					<ul class="clearfix">
						<li>所属分类：<?php the_category(' ');?></li>
						<li class="nav-web">网址：<?php echo get_post_meta($post->ID,"web_link_value",true);?></li>
						<li>浏览量：<?php get_post_views($post -> ID); ?>次</li>
						<li>收录时间：<?php the_time('Y-m-d'); ?></li>
						<li class="nav-chinaz"><a href="/" target="_blank" rel="nofollow"><i class="iconfont">&#xe6ff;</i>站长查询</a></li>
						<li class="nav-aizhan"><a href="/" target="_blank" rel="nofollow"><i class="iconfont">&#xe6ff;</i>爱站查询</a></li>
                        <script>
                            $(function() {
                                var $web = $('.nav-web').html().split('//')[1];
                                $('.nav-chinaz a').attr("href",'https://seo.chinaz.com/' + $web);
                                $('.nav-aizhan a').attr("href",'https://www.aizhan.com/seo/' + $web);
                            })
                        </script>
					</ul>
					<div class="nav-access">
						<a href="<?php echo get_post_meta($post->ID,"web_link_value",true);?>" rel="nofollow">直接访问</a>
					</div>
				</div>
			</div>

		</div>
	</div>
	<div class="recommend container">
		<div class="rec-tie">
			<strong>网站介绍</strong>
		</div>
		<div class="rec-con">
			<div class="show-content">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				<?php the_content(); ?>
			<?php endwhile; endif; ?>
			</div>
		</div>
	</div>
	
	<div class="recommend container">
		<div class="rec-tie">
            <strong>相似网站</strong>
        </div>
		<div class="rec-con">
			<ul class="clearfix">
				<?php $posts = query_posts('cat=' . get_the_category()[0]->cat_ID . '&showposts=10&order=DESC&orderby=date' . '&paged=' . get_query_var('paged'));
				if ($posts) : foreach( $posts as $post ) : setup_postdata( $post );{?>
					<li>
						<a class="rec-link" href="<?php the_permalink(); ?>">
							<img src="<?php echo get_post_meta($post->ID,"web_ico_value",true);?>" alt="<?php the_title(); ?>">
							<h3><?php the_title(); ?></h3>
							<p><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 150, '……'); ?></p>
						</a>
                      	<a class="linkDirect" href="<?php echo get_post_meta($post->ID,"web_link_value",true);?>" target="_blank" title="直达链接"><i class="iconfont">&#xe618;</i></a>
					</li>
				<?php } endforeach; endif; wp_reset_query(); ?>
			</ul>
		</div>
	</div>

	<div class="single-nav container" style="margin-top: 30px;">
		<div class="nav-tie">
            <strong>发表评论</strong>
        </div>
		<div class="nav-con">
			<?php comments_template(); ?>
		</div>
	</div>