	<div class="bgc"></div>
	<div class="list">
		<?php
			$sticky = get_option('sticky_posts');
			query_posts( array('post__in' => $sticky,'caller_get_posts' =>1,'cat'=>get_the_category()[0]->cat_ID,'showposts'=>99));
			static $case_num=0;
			while (have_posts()) : the_post();  ?>
				<!--置顶文章-->
				<div class="item clearfix">
					<div class="item-left fl">
						<a href="<?php the_permalink(); ?>">
						<?php if ( has_post_thumbnail() ) { ?>
							<img src="<?php echo wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large')[0]; ?>" alt="<?php the_title(); ?>">
						<?php } else {?>
							<img src="<?php bloginfo('template_url'); ?>/images/list-pic.jpg" alt="<?php the_title(); ?>">
						<?php } ?>
						</a>
					</div>
					<div class="item-right fl">
						<a href="<?php the_permalink(); ?>"><h3><?php the_title(); ?></h3></a>
						<span class="zhiding">置顶</span>
						<span class="item-content ell-3"><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 150, '……'); ?></span>
						<div class="other">
							<span class="item-date"><?php the_time('Y-m-d'); ?></span>
							<span class="reading"><?php get_post_views($post -> ID); ?>次阅读</span>
							<span class="item-zan count"><?php if( get_post_meta($post->ID,'bigfa_ding',true) ) { echo get_post_meta($post->ID,'bigfa_ding',true);} else {echo '0';}?>个赞</span>
						</div>
					</div>
				</div>
		<?php
			$case_num++;
		    endwhile; wp_reset_query();  
			$case_num=99-$case_num;
			query_posts( array( 'post__not_in' => get_option( 'sticky_posts'),'cat'=>get_the_category()[0]->cat_ID,'showposts'=>$case_num ));
			while (have_posts()) : the_post(); ?>
				<!--非置顶文章-->
				<div class="item clearfix">
					<div class="item-left fl">
						<a href="<?php the_permalink(); ?>">
						<?php if ( has_post_thumbnail() ) { ?>
							<img src="<?php echo wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large')[0]; ?>" alt="<?php the_title(); ?>">
						<?php } else {?>
							<img src="<?php bloginfo('template_url'); ?>/images/list-pic.jpg" alt="<?php the_title(); ?>">
						<?php } ?>
						</a>
					</div>
					<div class="item-right fl">
						<a href="<?php the_permalink(); ?>"><h3><?php the_title(); ?></h3></a>
						<span class="item-content ell-3"><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 150, '……'); ?></span>
						<div class="other">
							<span class="item-date"><?php the_time('Y-m-d'); ?></span>
							<span class="reading"><?php get_post_views($post -> ID); ?>次阅读</span>
							<span class="item-zan count"><?php if( get_post_meta($post->ID,'bigfa_ding',true) ) { echo get_post_meta($post->ID,'bigfa_ding',true);} else {echo '0';}?>个赞</span>
						</div>
					</div>
				</div>
		<?php endwhile; wp_reset_query(); ?>
	</div>
	<div class="page-code">
		<?php echo paginate_links(); ?>
	</div>
	