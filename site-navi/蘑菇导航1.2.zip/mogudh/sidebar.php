	<div class="list-right fl">
    	<div id="listFollow">
			<?php if(of_get_option( 'checkbox_img1')== 1): ?>
			<div class="media-img"><a href="<?php echo of_get_option( 'ad_link1'); ?>" target="_blank"><img src="<?php echo of_get_option( 'propaganda1'); ?>"></a></div>
			<?php endif; ?>
			<?php if(of_get_option( 'checkbox_img2')== 1): ?>
			<div class="media-img"><a href="<?php echo of_get_option( 'ad_link2'); ?>" target="_blank"><img src="<?php echo of_get_option( 'propaganda2'); ?>"></a></div>
			<?php endif; ?>
			<?php if(of_get_option( 'checkbox_article')== 1): ?>
				<div class="hotArticles">
					<h2>随机文章</h2>
					<ul>
						<?php $posts = query_posts('cat=' . of_get_option( 'random') . '&showposts=4&order=DESC&orderby=rand' . '&paged=' . get_query_var('paged'));
						if ($posts) : foreach( $posts as $post ) : setup_postdata( $post );{?>
						<li>
							<a href="<?php the_permalink(); ?>" class="clearfix">
								<?php if ( has_post_thumbnail() ) { ?>
								<img src="<?php echo wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large')[0]; ?>" alt="<?php the_title(); ?>" class="fl">
								<?php } else {?>
								<img src="<?php bloginfo('template_url'); ?>/images/list-pic.jpg" alt="<?php the_title(); ?>" class="fl">
								<?php } ?>
								<h4 class="fr ell-2"><?php the_title(); ?></h4>
							</a>
						</li>
						<?php } endforeach; endif; wp_reset_query(); ?>
					</ul>
				</div>
			<?php endif; ?>
			<?php if(of_get_option( 'checkbox_label')== 1): ?>
			<div class="hotTags">
				<h2>热门标签</h2>
				<ul class="clearfix">
					<?php wp_tag_cloud('number=20&orderby=count&order=DESC&smallest=14&largest=14&unit=px'); ?>
				</ul>
			</div>
			<?php endif; ?>
			<?php if(of_get_option( 'checkbox_comment')== 1): ?>
			<div class="newsComments">
				<h2>最新评论</h2>
				<ul>
					<?php bg_recent_comments(); ?>
				</ul>
			</div>
			<?php endif; ?>
        </div>
	</div>