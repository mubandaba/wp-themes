	<div class="container list-blog clearfix">
		<div class="list-left fl">
			<div class="rec-con">
				<ul class="clearfix">
					<?php
						$sticky = get_option('sticky_posts');
						query_posts( array('post__in' => $sticky,'caller_get_posts' =>1,'cat'=>get_the_category()[0]->cat_ID,'showposts'=>99));
						static $case_num=0;
						while (have_posts()) : the_post();  ?>
							<!--置顶文章-->
							<li>
								<a class="rec-link" href="<?php the_permalink(); ?>">
									<img src="<?php echo get_post_meta($post->ID,"web_ico_value",true);?>" alt="<?php the_title(); ?>">
									<h3><?php the_title(); ?></h3>
									<p><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 150, '……'); ?></p>
								</a>
								<a class="linkDirect" href="<?php echo get_post_meta($post->ID,"web_link_value",true);?>" target="_blank" rel="nofollow" title="直达链接"><i class="iconfont">&#xe618;</i></a>
							</li>
					<?php
						$case_num++;
					    endwhile; wp_reset_query();  
						$case_num=99-$case_num;
						query_posts( array( 'post__not_in' => get_option( 'sticky_posts'),'cat'=>get_the_category()[0]->cat_ID,'showposts'=>$case_num ));
						while (have_posts()) : the_post(); ?>
							<!--非置顶文章-->
							<li>
								<a class="rec-link" href="<?php the_permalink(); ?>">
									<img src="<?php echo get_post_meta($post->ID,"web_ico_value",true);?>" alt="<?php the_title(); ?>">
									<h3><?php the_title(); ?></h3>
									<p><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 150, '……'); ?></p>
								</a>
								<a class="linkDirect" href="<?php echo get_post_meta($post->ID,"web_link_value",true);?>" target="_blank" rel="nofollow" title="直达链接"><i class="iconfont">&#xe618;</i></a>
							</li>
					<?php endwhile; wp_reset_query(); ?>
				</ul>
			</div>
            <div class="page-code">
				<?php echo paginate_links(); ?>
			</div>
		</div>
		<?php get_template_part('sidebar');  ?>
	</div>
