<!DOCTYPE html>
<html lang="zh-CN">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta http-equiv="Cache-Control" content="no-transform" />
	<meta http-equiv="Cache-Control" content="no-siteapp" />
	<link rel="shortcut icon" href="<?php echo of_get_option( 'favicon'); ?>" type="image/x-icon" />
	<link rel="stylesheet" href="https://cdn.bootcss.com/Swiper/4.5.0/css/swiper.min.css">
	<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/reset.css">
	<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/style.css">
	<script src="https://cdn.bootcss.com/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://cdn.bootcss.com/Swiper/4.5.0/js/swiper.min.js"></script>
	<script src="<?php bloginfo('template_url'); ?>/js/index.js"></script>
	<?php
	$description = '';
	$keywords = '';
	if (is_home() || is_page()) {
	   $description = of_get_option( 'description');
	   $keywords = of_get_option( 'keywords');
	}
	elseif (is_single()) {
	   $description1 = get_post_meta($post->ID, "description_value", true);
	   $description2 = str_replace("\n","",mb_strimwidth(strip_tags($post->post_content), 0, 200, "…", 'utf-8'));
	   $description = $description1 ? $description1 : $description2;
	   $keywords = get_post_meta($post->ID,"keywords_value",true);
	   if($keywords == '') {
	      $tags = wp_get_post_tags($post->ID);    
	      foreach ($tags as $tag ) {        
	         $keywords = $keywords . $tag->name . ", ";    
	      }
	      $keywords = rtrim($keywords, ', ');
	   }
	}
	elseif (is_category()) {
	   $description = category_description();
	   $keywords = single_cat_title('', false);
	}
	elseif (is_tag()){
	   $description = tag_description();
	   $keywords = single_tag_title('', false);
	}
	$description = trim(strip_tags($description));
	$keywords = trim(strip_tags($keywords));
	?>
	<meta name="keywords" content="<?php echo $keywords; ?>" />
	<meta name="description" content="<?php echo $description; ?>" />
	<?php wp_head(); ?>
	<title></title>
</head>
<body>
	<header>
		<div class="container clearfix">
			<div class="logo fl">
				<a href="<?php echo get_option('home'); ?>">
					<img src="<?php echo of_get_option( 'dh_logo'); ?>" alt="<?php bloginfo('name'); ?>">
				</a>
			</div>
			<?php wp_nav_menu( array( 'theme_location' => 'header-menu','container_class' => 'nav fl','menu_class' => "clearfix")); ?>
			<div class="other fr">
              	<?php echo of_get_option( 'btncode'); ?>
			</div>
		</div>
	</header>