<?php 
if ( !post_password_required() ) {
get_header('fullscreen');
$all_likes = gt3pb_get_option("likes");
the_post();
$gt3_theme_pagebuilder = gt3_get_theme_pagebuilder(get_the_ID());
$featured_image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'single-post-thumbnail');
$pf = get_post_format();
$post_views = (get_post_meta(get_the_ID(), "post_views", true) > 0 ? get_post_meta(get_the_ID(), "post_views", true) : "0");
update_post_meta(get_the_ID(), "post_views", (int)$post_views + 1);	
wp_enqueue_script('gt3_fsGallery_js', get_template_directory_uri() . '/js/fs_gallery.js', array(), false, true);
?>
    <div class="site_wrapper fs_site_wrapper model_page">
	    <div class="main_wrapper">

            <div class="content_wrapper">
                <div class="container fs_page">
                    <div class="content_block row">
                        <div class="fl-container">
                            <div class="row">
                                <div class="posts-block">
                                <?php if (!isset($gt3_theme_pagebuilder['settings']['show_title']) || $gt3_theme_pagebuilder['settings']['show_title'] !== "no") { ?>
                                    <div class="page_title_block">
                                        <h1 class="title"><?php the_title(); ?></h1>
                                    </div>
                                <?php } ?>                    
                                    <div class="contentarea">
                                        <?php
                                        the_content(__('Read more!', 'theme_localization'));
                                        wp_link_pages(array('before' => '<div class="page-link">' . __('Pages', 'theme_localization') . ': ', 'after' => '</div>'));
                                        if (gt3_get_theme_option('page_comments') == "enabled") {?>
                                        <hr class="comment_hr"/>
                                        <div class="row">
                                            <div class="span12">
                                                <?php comments_template(); ?>
                                            </div>
                                        </div>							
                                        <?php }?>							
                                    </div>
                                </div>
                            </div><!-- .row -->
                            <div class="row models_row">
                                <div class="span4 module_cont module_text_area">
	                                <div class="bg_title">
                                    	<h3 class="headInModule" style=""><?php _e('Model Parameters', 'theme_localization'); ?></h3>
                                    </div>
                                    <div class="module_content">
										<div class="model_parameters">
                                        	<?php
												if (isset($gt3_theme_pagebuilder['page_settings']['model']['params']) && is_array($gt3_theme_pagebuilder['page_settings']['model']['params'])) {
													foreach ($gt3_theme_pagebuilder['page_settings']['model']['params'] as $skillkey => $skillvalue) {
											?>
                                            	<div class="model_param_item">
		                                        	<span class="content_highlight"><?php echo esc_attr($skillvalue['name']); ?></span> - <?php echo esc_attr($skillvalue['value']); ?>
                                                </div>
                                            <?php 
													}
												}												
											?>											
                                        </div>
                                    </div>
                                </div><!-- .module_cont -->
                                <div class="span8  module_number_8 module_cont module_diagramm">
	                                <div class="bg_title">
                                    	<h3 class="headInModule" style=""><?php _e('Model Skills', 'theme_localization'); ?></h3>
                                    </div>
                                    <div class="module_content">
										<div class="model_skills">
                                        	<?php
												if (isset($gt3_theme_pagebuilder['page_settings']['model']['skills']) && is_array($gt3_theme_pagebuilder['page_settings']['model']['skills'])) {
													foreach ($gt3_theme_pagebuilder['page_settings']['model']['skills'] as $skillkey => $skillvalue) {
													$diag_title = $skillvalue['name'];
													$percent = (int)$skillvalue['value'];
											?>
                                                <div class="skill_wrapper">
                                                    <div class="skill_item">
                                                        <h4 class="skill_label"><?php echo $diag_title; ?></h4>
                                                        <h4 class="skill_percent"><?php echo $percent; ?>%</h4>
                                                    </div>
                                                    <div class="skill_bar_wrapper">
                                                        <div class="skill_bar" data-width="<?php echo $percent; ?>"></div>
                                                    </div>
                                                </div>
                                            <?php 
													}
												}												
											?>											
                                        </div>
										<script>
                                            jQuery(document).ready(function($) {
												jQuery('.skill_bar').each(function(){
													jQuery(this).css('width', jQuery(this).attr('data-width')+'%');
												});
												if (jQuery(window).width() < 760) {
													jQuery('.model_page').css('margin-top', jQuery(window).height()- header_h);
												}												
                                            });
                                        </script>                                        
                                    </div>                                   
                                </div><!-- .module_cont -->
                            </div>                            
                            
                        </div><!-- .fl-container -->
                    </div>
                </div>
            </div><!-- .content_wrapper -->
            
        </div>
	</div>
	<?php 
        $sliderCompile = "";
        if (isset($gt3_theme_pagebuilder['post-formats']['images']) && is_array($gt3_theme_pagebuilder['post-formats']['images'])) {
            if (isset($gt3_theme_pagebuilder['sliders']['fit_style'])) {
                $fit_style = $gt3_theme_pagebuilder['sliders']['fit_style'];
            } else {
                $fit_style = "no_fit";
            }
            $sliderCompile .= '<script>gallery_set = [';
            foreach ($gt3_theme_pagebuilder['post-formats']['images'] as $imageid => $image) {
                $uniqid = mt_rand(0, 9999);
                $photoTitle = "";
                $photoCaption = "";
                $titleColor = "ffffff";
                $captionColor = "ffffff";
                
                $sliderCompile .= '{type: "image", image: "' . wp_get_attachment_url($image['attach_id']) . '", thmb: "'.aq_resize(wp_get_attachment_url($image['attach_id']), "104", "104", true, true, true).'", alt: "' . str_replace('"', "'",  $photoTitle) . '", title: "' . str_replace('"', "'", $photoTitle) . '", description: "' . str_replace('"', "'",  $photoCaption) . '", titleColor: "#'.$titleColor.'", descriptionColor: "#'.$captionColor.'"},';
            }
        $sliderCompile .= "]
        jQuery(document).ready(function(){
            jQuery('.custom_bg').remove();
            jQuery('body').fs_gallery({
                fx: 'fade',
                fit: '". $fit_style ."',
                slide_time: 3000,
                autoplay: 0,
                show_controls: 1,
                slides: gallery_set
            });
        });
        </script>";
        }
    echo $sliderCompile;
    ?>
    <div class="fs_controls">
    </div>
    <script>
        jQuery(document).ready(function(){
            jQuery('.main_header').removeClass('hided');
            jQuery('html').addClass('single-gallery');
            <?php if ($controls == 'false') {
                echo "jQuery('html').addClass('hide_controls');";				
            } ?>
            <?php if ($thmbs == 0) {
                echo "jQuery('html').addClass('without_thmb');";
            } ?>
            jQuery('.share_toggle').click(function(){
                jQuery('.share_block').toggleClass('show_share');
            });
        });	
    </script>
            
<script>
	jQuery(document).ready(function(){
		setUpWindow();
	});
	jQuery(window).load(function(){
		setUpWindow();
	});
	jQuery(window).resize(function(){
		setUpWindow();
		setTimeout('setUpWindow()',500);
		setTimeout('setUpWindow()',1000);
	});
	function setUpWindow() {
		main_wrapper.css('min-height', window_h-parseInt(site_wrapper.css('padding-top')) - parseInt(site_wrapper.css('padding-bottom'))+'px');
		if (jQuery(window).width() < 760) {
			jQuery('.model_page').css('margin-top', jQuery(window).height()- header_h);
		}		
	}
</script>
<?php
	get_footer('fullscreen');
} else {
	get_header('fullscreen');
?>
    <div class="pp_block unloaded">
        <h1 class="pp_title"><?php  _e('This Content is Password Protected', 'theme_localization') ?></h1>
        <div class="pp_wrapper">
            <?php the_content(); ?>
        </div>
    </div>
    <script>
		jQuery(document).ready(function(){
			jQuery('.post-password-form').find('label').find('input').attr('placeholder', 'Enter The Password...');
			setTimeout('jQuery(".pp_block").removeClass("unloaded")',350);
		});
	</script>
<?php 
	get_footer('fullscreen');
} ?>