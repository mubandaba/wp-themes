<?php 
if ( !post_password_required() ) {
/* LOAD PAGE BUILDER ARRAY */
$gt3_theme_pagebuilder = gt3_get_theme_pagebuilder(get_the_ID());
$featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'single-post-thumbnail' );
$pf = get_post_format();
$gt3_current_page_sidebar = $gt3_theme_pagebuilder['settings']['layout-sidebars'];

/* ADD 1 view for this post */
$post_views = (get_post_meta(get_the_ID(), "post_views", true) > 0 ? get_post_meta(get_the_ID(), "post_views", true) : "0");
update_post_meta(get_the_ID(), "post_views", (int)$post_views + 1);
wp_enqueue_script('gt3_cookie_js', get_template_directory_uri() . '/js/jquery.cookie.js', array(), false, true);
wp_enqueue_script('gt3_fsGallery_js', get_template_directory_uri() . '/js/fs_gallery.js', array(), false, true);

get_header();
$all_likes = gt3pb_get_option("likes");
the_post();

$pft = get_post_format();
if ($pft !== "image" && $pft !== "video") {
	$pft = "standart";
}

		$sliderCompile = "";
		if ($pft == "image" && (isset($gt3_theme_pagebuilder['post-formats']['images']) && is_array($gt3_theme_pagebuilder['post-formats']['images']))) {						    
            if (isset($gt3_theme_pagebuilder['sliders']['fullscreen']['anim_style']) && $gt3_theme_pagebuilder['sliders']['fullscreen']['anim_style'] !== 'default') {
                $fx = $gt3_theme_pagebuilder['sliders']['fullscreen']['anim_style'];
            } else {
                $fx = gt3_get_theme_option("default_slider_anim");
            }
            if (isset($gt3_theme_pagebuilder['sliders']['fullscreen']['fit_style']) && $gt3_theme_pagebuilder['sliders']['fullscreen']['fit_style'] !== 'default') {
                $fit_style = $gt3_theme_pagebuilder['sliders']['fullscreen']['fit_style'];
            } else {
                $fit_style = gt3_get_theme_option("default_fit_style");
            }
            if (isset($gt3_theme_pagebuilder['sliders']['fullscreen']['controls']) && $gt3_theme_pagebuilder['sliders']['fullscreen']['controls'] !== 'default') {
                $controls = $gt3_theme_pagebuilder['sliders']['fullscreen']['controls'];
            } else {
                $controls = gt3_get_theme_option("default_controls");
            }
            if ($controls == 'on' || $controls == 'yes') {
                $controls = 'true';
            } else {
                $controls = 'false';
            }
			$thmbs = 1;
            if (isset($gt3_theme_pagebuilder['sliders']['fullscreen']['autoplay']) && $gt3_theme_pagebuilder['sliders']['fullscreen']['autoplay'] !== 'default') {
                $autoplay = $gt3_theme_pagebuilder['sliders']['fullscreen']['autoplay'];
            } else {
                $autoplay = gt3_get_theme_option("default_autoplay");
            }
            if ($autoplay == 'on' || $autoplay == 'yes') {
                $autoplay = 'true';
            } else {
                $autoplay = 'false';
            }
   			if (count($gt3_theme_pagebuilder['post-formats']['images']) < 2) {
				$autoplay = 'false';
				$thmbs = 0;
			}

            $interval = gt3_get_theme_option("gallery_interval");
    
            $sliderCompile .= '<script>gallery_set = [';
			$script_compile = '';
            foreach ($gt3_theme_pagebuilder['post-formats']['images'] as $imageid => $image) {
                $uniqid = mt_rand(0, 9999);
				$sliderCompile .= '{type: "image", image: "' . wp_get_attachment_url($image['attach_id']) . '", thmb: "'.aq_resize(wp_get_attachment_url($image['attach_id']), "130", "130", true, true, true).'", alt: "", title: "", description: "", titleColor: "", descriptionColor: ""},';
            }
            $sliderCompile .= "]" . $script_compile . "
            jQuery(document).ready(function(){
                header.addClass('fixed_header');
                jQuery('body').fs_gallery({
                    fx: '". $fx ."', /*fade, slip*/
                    fit: '". $fit_style ."',
                    slide_time: ". $interval .", /*This time must be < then time in css*/
                    autoplay: ".$autoplay.",
                    show_controls: ". $controls .",
                    slides: gallery_set
                });
        
                jQuery('.close_controls').click(function(){
                    html.toggleClass('hide_controls');
                });			
            });
            </script>";
        
		echo $sliderCompile;?>        
		<?php } ?>
	<div class="fs_controls_append" style="display:none"></div>

    <div class="content_wrapper">
        <div class="container is_post post_page <?php echo esc_attr($gt3_theme_pagebuilder['settings']['layout-sidebars']) ?>">
            <div class="content_block row">
                <div class="fl-container <?php echo(($gt3_theme_pagebuilder['settings']['layout-sidebars'] == "right-sidebar") ? "hasRS" : ""); ?>">
                    <div class="row">
                        <div class="posts-block <?php echo($gt3_theme_pagebuilder['settings']['layout-sidebars'] == "left-sidebar" ? "hasLS" : ""); ?>">
                                <div class="preview_top">
                                    <div class="preview_title">
                                            <?php if (!isset($gt3_theme_pagebuilder['settings']['show_title']) || $gt3_theme_pagebuilder['settings']['show_title'] !== "no") { ?>
                                                <h1 class="blogpost_title"><?php the_title(); ?></h1>
                                            <?php } ?>  
                                        <div class="listing_meta">
                                            <span><i class="icon-calendar time-icon"></i><?php the_time("F d, Y") ?></span>
                                            <span><i class="icon-folder"></i>
                                                <?php 
                                                    $terms = get_the_terms( get_the_ID(), 'portcat' );
                                                    if ( $terms && ! is_wp_error( $terms ) ) {
                                                        $draught_links = array();
                                                        $tmp_categ = "";
                                                        foreach ( $terms as $term ) {
                                                            $tmp_categ .= $term -> term_id .",";
                                                            $draught_links[] = '<a href="'.get_term_link($term->slug, "portcat").'">'.$term->name.'</a>';
                                                        }
                                                        $tmp_categ = mb_substr($tmp_categ, 0, -1);
                                                        
                                                        $on_draught = join( ", ", $draught_links );
                                                        $show_cat = true;
                                                    }
                                                    if ($terms !== false) {
                                                        echo $on_draught;
                                                        $tmp_categ = $tmp_categ;
                                                    } else {
                                                        echo "Uncategorized";
                                                        $tmp_categ = "";
                                                    }
                                                ?>
                                            </span>
											<?php 
                                                if (isset($gt3_theme_pagebuilder['page_settings']['icons']) ? $socicons = $gt3_theme_pagebuilder['page_settings']['icons'] : $socicons = false);
                                                if (is_array($socicons)) {
                                                    foreach ($socicons as $key => $value) {
                                                        //$compile .= $value['data-icon-code'] . $value['name'] . $value['link'];
                                                        if ($value['link'] == '') {
                                                            echo '<span class="skill_ico"><i class="'.$value['data-icon-code'].'"></i>'.$value['name'].'</span>';
                                                        } else {
                                                            echo '<span class="skill_ico"><a href="'.$value['link'].'" title="'.$value['name'].'"><i class="'.$value['data-icon-code'].'"></i>'.$value['name'].'</a></span>';
                                                        }
                                                    }
                                                }												
                                            ?>
                                            <span><i class="icon-comments"></i><a href="<?php echo get_comments_link(); ?>"><?php echo get_comments_number(get_the_ID())?></a></span>                                                    
                                        </div>
                                    </div><!-- .preview_title -->
                                </div>
                                <div class="contentarea">
									<?php
                                    the_content(__('Read more!', 'theme_localization')); ?>
                                    
                                    <div class="ground_meta">
                                        <div class="page_navigation">
                                            <?php
                                                previous_post_link('<div class="post_prev">%link</div>', '<i class="icon-angle-left"></i>' . __('Previous Post', 'theme_localization'));
                                                next_post_link('<div class="post_next">%link</div>', __('Next Post', 'theme_localization'). '<i class="icon-angle-right"></i>');
                                            ?>
                                        </div>
                                        <div class="right_side">
                                            <div class="post_views">
                                                <i class="stand_icon icon-eye"></i>&nbsp;&nbsp;<?php echo $post_views; ?>
                                            </div>                                    
                                            <div class="gallery_likes_add <?php echo (isset($_COOKIE['like_port'.get_the_ID()]) ? "already_liked" : "") ?>" data-attachid="<?php get_the_ID(); ?>" data-modify="like_port">
                                                <i class="stand_icon <?php echo (isset($_COOKIE['like_port'.get_the_ID()]) ? "icon-heart" : "icon-heart-o"); ?>"></i>&nbsp;&nbsp;<span><?php echo ((isset($all_likes[get_the_ID()]) && $all_likes[get_the_ID()]>0) ? $all_likes[get_the_ID()] : 0); ?></span>
                                            </div>
                                            <div class="blogpost_share">
                                                <?php _e('Share this:', 'theme_localization'); ?>
                                                <a target="_blank"
                                                   href="http://www.facebook.com/share.php?u=<?php echo get_permalink(); ?>"
                                                   class="top_socials share_facebook"><i class="stand_icon icon-facebook"></i></a>
                                                <a target="_blank"
                                                   href="https://twitter.com/intent/tweet?text=<?php echo get_the_title(); ?>&amp;url=<?php echo get_permalink(); ?>"
                                                   class="top_socials share_tweet"><i class="stand_icon icon-twitter"></i></a>
                                                <a target="_blank"
                                                   href="https://plus.google.com/share?url=<?php echo get_permalink(); ?>"
                                                   class="top_socials share_gplus"><i class="icon-google-plus"></i></a>
                                                <a target="_blank"
                                                   href="http://pinterest.com/pin/create/button/?url=<?php echo get_permalink(); ?>&media=<?php echo (strlen($featured_image[0])>0) ? $featured_image[0] : gt3_get_theme_option("logo"); ?>" class="top_socials share_pinterest"><i class="stand_icon icon-pinterest"></i></a>                                               
                                                <div class="clear"></div>
                                            </div>                                        
                                        </div>
                                    </div>
                                    <?php
									$showRelated = gt3_get_theme_option("related_posts");
									if (isset($gt3_theme_pagebuilder['settings']['pf-related']) && $gt3_theme_pagebuilder['settings']['pf-related'] !== 'def') {
										$showRelated = $gt3_theme_pagebuilder['settings']['pf-related'];
									}
									if ($showRelated == "on") {
                                        if ($gt3_theme_pagebuilder['settings']['layout-sidebars'] == "no-sidebar") {
                                            $posts_per_line = 3;
                                        } else {
                                            $posts_per_line = 2;
                                        }

                                        if (is_gt3_builder_active()) {
                                            echo '<div class="row"><div class="span12 single_post_module module_cont module_small_padding featured_items single_feature featured_posts">';
                                            echo do_shortcode("[feature_portfolio
									heading_color=''
									heading_size='h3'
									heading_text='".__('Related Works', 'theme_localization')."'
									number_of_posts=" . $posts_per_line . "
									posts_per_line=" . $posts_per_line . "
									selected_categories='" . $tmp_categ . "'
									sorting_type='random'
									related='yes'
									post_type='post'][/feature_portfolio]");
                                            echo '</div></div>';
                                        }
                                    }
	                                wp_link_pages(array('before' => '<div class="page-link">' . __('Pages', 'theme_localization') . ': ', 'after' => '</div>'));
									if ( comments_open() && gt3_get_theme_option("portfolio_comments") == "enabled" ) { ?>
                                    <div class="row">
                                        <div class="span12">
                                            <?php comments_template(); ?>
                                        </div>
                                    </div>
								<?php } ?>
                            </div><!-- .contentarea -->
                        </div>
                        <?php get_sidebar('left'); ?>
                    </div>
                </div>
                <?php get_sidebar('right'); ?>
            </div>
        </div>
    </div>
	<script>
	    var content = jQuery('.site_wrapper'),
		<?php if (get_the_content() !== '' || (isset($gt3_theme_pagebuilder['modules']) && is_array($gt3_theme_pagebuilder['modules']) && count($gt3_theme_pagebuilder['modules'])>0)) { ?> 
			content_w = content.width()+parseInt(content.css('padding-left'))+parseInt(content.css('padding-right'));
		<?php } else {?>
			content_w = 0;
		<?php } ?>
		if (jQuery(window).width() < 760) {
			content_w = 0;
		}		
        jQuery(document).ready(function() {
			<?php if (get_the_content() !== '' || (isset($gt3_theme_pagebuilder['modules']) && is_array($gt3_theme_pagebuilder['modules']) && count($gt3_theme_pagebuilder['modules'])>0)) { ?> 
				content_w = content.width()+parseInt(content.css('padding-left'))+parseInt(content.css('padding-right'));
			<?php } else {?>
            	content_w = 0;
			<?php } ?>
			if (jQuery(window).width() < 760) {
				content_w = 0;
			}
            html.addClass('post_page');
			<?php if ($pft == "standart") { ?>
				jQuery('.custom_bg').css('background-image', 'url("<?php echo $featured_image[0]; ?>")');
			<?php } ?>
			<?php if ($pft == "image") { ?>	
				jQuery('.custom_bg').addClass('justBG');		
				if (jQuery('.fs_gallery_container').size() > 0) {
					<?php if (isset($thmbs) && $thmbs == 0) {?>
						jQuery('.fs_thmb_viewport').remove();
					<?php }?>
					console.log(content_w);
					jQuery('.fs_gallery_container').width(jQuery(window).width() - content_w);
					jQuery('.toggle_fullview').click(function(){
						if (html.hasClass('fullview')) {
							jQuery('.fs_gallery_container').width(jQuery(window).width() - content_w);
						} else {
							jQuery('.fs_gallery_container').width(jQuery(window).width());
						}
						setTimeout("setUpWindow()",500);
					});
				}
			<?php } ?>
			<?php if ($pft == "video") { 				
				$video_url = $gt3_theme_pagebuilder['post-formats']['videourl'];
			
				#YOUTUBE
				$is_youtube = substr_count($video_url, "youtu");
				if ($is_youtube > 0) {
					$videoid = substr(strstr($video_url, "="), 1);?>
					body.append("<div class='fullscreen_block fw_background post_video_bg bg_video'><iframe width='100%' height='100%' src='http://www.youtube.com/embed/'<?php echo $videoid; ?> ?controls=0&autoplay=1&showinfo=0&modestbranding=1&wmode=opaque&rel=0' frameborder='0' allowfullscreen></iframe></div>");
					<?php
				}
			
				#VIMEO
				$is_vimeo = substr_count($video_url, "vimeo");
				if ($is_vimeo > 0) {
					$videoid = substr(strstr($video_url, "m/"), 2);
					?>
					body.append("<div class='fullscreen_block fw_background bg_video'><iframe src='http://player.vimeo.com/video/<?php echo $videoid; ?>?autoplay=1&loop=1' width='100' height='100%' frameborder='0' webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe></div>");
					<?php
				}
			?>			
			
				jQuery('.custom_bg').css('background','#000000');				
				jQuery('.fw_background').height(jQuery(window).height());
				jQuery('.fullscreen_block').addClass('loaded');
				if (jQuery(window).width() > 1024) {
					if (jQuery('.bg_video').size() > 0) {
						if (((jQuery(window).height()+150)/9)*16 > jQuery(window).width()) {				
							jQuery('iframe').height(jQuery(window).height()+150).width(((jQuery(window).height()+150)/9)*16);
							jQuery('iframe').css({'margin-left' : (-1*jQuery('iframe').width()/2)+'px', 'top' : "-75px", 'margin-top' : '0px'});
						} else {
							jQuery('iframe').width(jQuery(window).width()).height(((jQuery(window).width())/16)*9);
							jQuery('iframe').css({'margin-left' : (-1*jQuery('iframe').width()/2)+'px', 'margin-top' : (-1*jQuery('iframe').height()/2)+'px', 'top' : '50%'});
						}
					}
				} else if (jQuery(window).width() < 760) {
					jQuery('.bg_video').height(window_h-header.height()).width(jQuery(window).width()).css({
						'top': '0px',
						'left': '0px',
						'margin-left': '0px',
						'margin-top': '0px'
					});
					jQuery('iframe').height(window_h-header.height()).width(jQuery(window).width()).css({
						'top': '0px',
						'left': '0px',
						'margin-left': '0px',
						'margin-top': '0px'
					});
				} else {
					jQuery('.bg_video').height(window_h).width(jQuery(window).width()).css({
						'top': '0px',
						'margin-left' : '0px',
						'left' : '0px',
						'margin-top': '0px'
					});				
					jQuery('iframe').height(window_h).width(jQuery(window).width()).css({
						'top': '0px',
						'margin-left' : '0px',
						'left' : '0px',
						'margin-top': '0px'
					});			
				}			
			
			<?php } ?>
            if (jQuery('.hasRS').size() > 0 || jQuery('.hasLS').size() > 0) {
                content.addClass('has_sidebar');
            }
			<?php if (get_the_content() !== '' || (isset($gt3_theme_pagebuilder['modules']) && is_array($gt3_theme_pagebuilder['modules']) && count($gt3_theme_pagebuilder['modules'])>0)) { } else {?>
				jQuery('.site_wrapper').hide();
			<?php } ?>
			setUpWindow();
			setTimeout("setUpWindow()",500);
        });
        jQuery(window).load(function() {
            //jQuery('.fs_gallery_container').width(jQuery(window).width() - content_w);
			setUpWindow();
        });
        jQuery(window).resize(function() {		
			<?php if (get_the_content() !== '' || (isset($gt3_theme_pagebuilder['modules']) && is_array($gt3_theme_pagebuilder['modules']) && count($gt3_theme_pagebuilder['modules'])>0)) { ?> 
				content_w = content.width()+parseInt(content.css('padding-left'))+parseInt(content.css('padding-right'));
			<?php } else {?>
            	content_w = 0;
			<?php } ?>		
			if (jQuery(window).width() < 760) {
				content_w = 0;
			}
			setUpWindow();
			setTimeout("setUpWindow()",500);
			<?php if ($pft == "video") { ?>
				jQuery('.fw_background').height(jQuery(window).height());
				if (jQuery(window).width() > 1024) {
					if (jQuery('.bg_video').size() > 0) {
						if (((jQuery(window).height()+150)/9)*16 > jQuery(window).width()) {				
							jQuery('iframe').height(jQuery(window).height()+150).width(((jQuery(window).height()+150)/9)*16);
							jQuery('iframe').css({'margin-left' : (-1*jQuery('iframe').width()/2)+'px', 'top' : "-75px", 'margin-top' : '0px'});
						} else {
							jQuery('iframe').width(jQuery(window).width()).height(((jQuery(window).width())/16)*9);
							jQuery('iframe').css({'margin-left' : (-1*jQuery('iframe').width()/2)+'px', 'margin-top' : (-1*jQuery('iframe').height()/2)+'px', 'top' : '50%'});
						}
					}
				} else if (jQuery(window).width() < 760) {
					jQuery('.bg_video').height(window_h-header.height()).width(jQuery(window).width()).css({
						'top': '0px',
						'left': '0px',
						'margin-left': '0px',
						'margin-top': '0px'
					});
					jQuery('iframe').height(window_h-header.height()).width(jQuery(window).width()).css({
						'top': '0px',
						'left': '0px',
						'margin-left': '0px',
						'margin-top': '0px'
					});
				} else {
					jQuery('.bg_video').height(window_h).width(jQuery(window).width()).css({
						'top': '0px',
						'margin-left' : '0px',
						'left' : '0px',
						'margin-top': '0px'
					});				
					jQuery('iframe').height(window_h).width(jQuery(window).width()).css({
						'top': '0px',
						'margin-left' : '0px',
						'left' : '0px',
						'margin-top': '0px'
					});			
				}			
			
			<?php } ?>			
        });
        function setUpWindow() {
			if (html.hasClass('fullview')) {
				jQuery('.fs_gallery_container').width(jQuery(window).width());
			} else {
				jQuery('.fs_gallery_container').width(jQuery(window).width() - content_w);
			}
			if (jQuery(window).width() < 760) {
				jQuery('.custom_bg').addClass('custom_absolute');
				jQuery('.site_wrapper').css('margin-top', jQuery(window).height()- header_h);
			}
            main_wrapper.css('min-height', window_h-parseInt(site_wrapper.css('padding-top')) - parseInt(site_wrapper.css('padding-bottom'))+'px');
        }
    </script>
        
<?php 	
	get_footer();} 
else {
	get_header('fullscreen');
?>
    <div class="pp_block unloaded">
        <h1 class="pp_title"><?php  _e('This Content is Password Protected', 'theme_localization') ?></h1>
        <div class="pp_wrapper">
            <?php the_content(); ?>
        </div>
    </div>
    <script>
		jQuery(document).ready(function(){
			jQuery('.post-password-form').find('label').find('input').attr('placeholder', 'Enter The Password...');
			setTimeout('jQuery(".pp_block").removeClass("unloaded")',350);
		});
	</script>
<?php 
	get_footer('fullscreen');
} ?>