        </div><!-- .main_wrapper -->
	</div>
	<?php
		gt3_the_pb_custom_bg_and_color(gt3_get_theme_pagebuilder(@get_the_ID()));
		gt3_the_theme_option("code_before_body"); wp_footer();
    ?>
</body>
</html>