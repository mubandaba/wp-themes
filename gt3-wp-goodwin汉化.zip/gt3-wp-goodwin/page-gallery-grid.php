<?php 
/*
Template Name: Gallery - Grid
*/
if ( !post_password_required() ) {
get_header('fullscreen');
the_post();

$imgCounter = 0;

$gt3_theme_pagebuilder = gt3_get_theme_pagebuilder(get_the_ID());
$featured_image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'single-post-thumbnail');
$pf = get_post_format();
wp_enqueue_script('gt3_cookie_js', get_template_directory_uri() . '/js/jquery.cookie.js', array(), false, true);
wp_enqueue_script('gt3_dmLightBox_js', get_template_directory_uri() . '/js/dm_lightbox.js', array(), false, true);
if (isset($gt3_theme_pagebuilder['gallery']['inrow'])) {
	$items_size = 100/$gt3_theme_pagebuilder['gallery']['inrow'];
} else {
	$items_size = 25;
}
if (isset($gt3_theme_pagebuilder['gallery']['interval'])) {
	$setPad = $gt3_theme_pagebuilder['gallery']['interval'];
} else {
	$setPad = '0px';
}
if ((int)$setPad > 0) {
	$hasPad = "with_padding";
} else {
	$hasPad = "without_padding";
}

	$hasFilter = '';
	if (isset($gt3_theme_pagebuilder['settings']['show_by']) && $gt3_theme_pagebuilder['settings']['show_by'] == 'by_category') {	
		global $wp_query_in_shortcodes, $paged;
		
		if(empty($paged)){
			$paged = (get_query_var('page')) ? get_query_var('page') : 1;
		}			
		if (isset($gt3_theme_pagebuilder['settings']['cat_ids']) && (is_array($gt3_theme_pagebuilder['settings']['cat_ids']))) {
			$compile_cats = array();
			foreach ($gt3_theme_pagebuilder['settings']['cat_ids'] as $catkey => $catvalue) {
				array_push($compile_cats, $catkey);
			}
			$selected_categories = implode(",", $compile_cats);
		} else {
			$selected_categories = "";
			$post_type_filter = "";
		}
		$post_type_terms = array();
		if (isset($selected_categories) && strlen($selected_categories) > 0) {
			$post_type_terms = explode(",", $selected_categories);
			$post_type_filter = explode(",", $selected_categories);
			$post_type_field = "id";
		}
		
		$wp_query_in_shortcodes = new WP_Query();
		$args = array(
			'post_type' => 'gallery',
			'order' => 'DESC',
			'paged' => $paged,
			'posts_per_page' => -1
		);

		if (isset($_GET['slug']) && strlen($_GET['slug']) > 0) {
			$post_type_terms = esc_attr($_GET['slug']);
			$selected_categories = esc_attr($_GET['slug']);
			$post_type_field = "slug";
		}
		if (count($post_type_terms) > 0) {
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'gallerycat',
					'field' => $post_type_field,
					'terms' => $post_type_terms
				)
			);
		}
	
		if (!isset($gt3_theme_pagebuilder['settings']['filter']) || $gt3_theme_pagebuilder['settings']['filter'] == 'on') {
			$hasFilter = 'has_filter';
			$compile = '';
			$compile .= showGalleryCats($post_type_filter);
			echo $compile;
		}
	}
?>
    <div class="preloader">
        <div class="preloader_content">
            <span><?php echo gt3_get_theme_option("preloader_text"); ?></span>
            <div class="preloader_line">
                <div class="preloader_line_bar1"></div>
                <div class="preloader_line_bar2"></div>
            </div>
        </div>
    </div>
    <div class="fw_grid_gallery <?php echo $hasFilter; ?> fadeOnLoad dm_faded <?php echo $hasPad; ?>">
        <style>
			.fw-portPreview {
				padding:0 <?php echo $setPad; ?> <?php echo $setPad; ?> 0;
			}
			.fw_grid_gallery .fw_grid_item {
				width:<?php echo $items_size; ?>%;
			}
		</style>  
        <div class="fw_grid_module" style="padding-top:<?php echo $setPad; ?>; margin-left:<?php echo $setPad; ?>;">  
		<?php 
			if (isset($gt3_theme_pagebuilder['settings']['show_by']) && $gt3_theme_pagebuilder['settings']['show_by'] == 'by_category') {
		?>	    
		<?php 
	        $wp_query_in_shortcodes->query($args);
			$imgCounter = 0;
	        while ($wp_query_in_shortcodes->have_posts()) : $wp_query_in_shortcodes->the_post();
				$all_likes = gt3pb_get_option("likes");
				$gt3_theme_post = get_plugin_pagebuilder(get_the_ID());
				$featured_image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'single-post-thumbnail');
				$pf = get_post_format();
				$echoallterm = '';
				$new_term_list = get_the_terms(get_the_id(), "gallerycat");
				$sliderCompile = "";
				foreach ($gt3_theme_post['sliders']['fullscreen']['slides'] as $imageid => $image) { 
					$imgCounter++;
					if (isset($image['title']['value']) && strlen($image['title']['value'])>0) {$photoTitle = $image['title']['value'];} else {$photoTitle = "";}
					if (isset($image['caption']['value']) && strlen($image['caption']['value'])>0) {$photoCaption  = $image['caption']['value'];} else {$photoCaption = "";}				
				?>                

				<div class="fw_grid_item">
					<div class="fw_grid_content" style="margin-bottom:<?php echo $setPad; ?>; margin-right:<?php echo $setPad; ?>;">
                        <div class="img_block wrapped_img fs_port_item gallery_item_wrapper">
							<?php
							$img4work = wp_get_attachment_image_src($image["attach_id"], 'original');
							$img_width = $img4work[1];
							$img_height = $img4work[2];
							$img_ratio = $img_width/$img_height;
							
							if ($image['slide_type'] == 'image') {								
								 echo '<a class="dm_link" id="dm_image'.$imgCounter .'" data-count="'.$imgCounter .'" data-width="'.$img_width.'" data-height="'.$img_height.'" data-ratio="'.$img_ratio.'" data-thmb="'.aq_resize($img4work[0], "104", "104", true, true, true).'" data-type="image" href="'. $img4work[0] .'" title="'.esc_attr($photoTitle).'"></a>';
							} else if ($image['slide_type'] == 'video') {
								#YOUTUBE
								$is_youtube = substr_count($image['src'], "youtu");				
								if ($is_youtube > 0) {
									$videoid = substr(strstr($image['src'], "="), 1);					
									echo '<a class="dm_link" id="dm_image'.$imgCounter .'" data-count="'.$imgCounter .'" data-thmb="'.aq_resize($img4work[0], "104", "104", true, true, true).'" data-type="youtube" href="'. $videoid .'" title="'.esc_attr($photoTitle).'"></a>';
								}
								#VIMEO
								$is_vimeo = substr_count($image['src'], "vimeo");
								if ($is_vimeo > 0) {
									$videoid = substr(strstr($image['src'], "m/"), 2);
									echo '<a class="dm_link" id="dm_image'.$imgCounter .'" data-count="'.$imgCounter .'" data-thmb="'.aq_resize($img4work[0], "104", "104", true, true, true).'" data-type="vimeo" href="'. $videoid .'" title="'.esc_attr($photoTitle).'"></a>';
								}
							}
							?>							
                            <img width="960" class="img2preload" height="960" data-title = "<?php echo esc_attr($photoTitle); ?>" data-caption = "<?php echo esc_attr($photoCaption); ?>"  data-img="<?php echo $img4work[0]; ?>" src="<?php echo aq_resize($img4work[0], "960", "960", true, true, true); ?>" alt="<?php echo esc_attr($photoTitle); ?>" />
                            <div class="gallery_fadder"></div>
                            <div class="gal_content">
                            	<?php if (strlen(trim($photoTitle)) > 0) {
	                            	echo "<h3>" . $photoTitle . "</h3>";
                                } ?>
	                            <span class="gal_plus_ico"></span>
                            </div>
                        </div>                    
                    </div>
                </div>                                                
                                                       
				<?php } ?>
			<?php endwhile;
			} else {
				if (!isset($gt3_theme_pagebuilder['gallery']['selected_gallery'])) {
					$tmp_query = null;
					$tmp_query = new WP_Query();
					$tmp_args = array(
						'post_type' => 'gallery',
						'posts_per_page' => -1,
					);
					$tmp_query->query($tmp_args);			        
					while ($tmp_query->have_posts()) : $tmp_query->the_post();
						$selected_gallery = get_the_ID();
						continue;
					endwhile;
				} else {
					$selected_gallery = $gt3_theme_pagebuilder['gallery']['selected_gallery'];
				}
				$galleryPageBuilder = get_plugin_pagebuilder($selected_gallery);
				?>
				<?php if (isset($galleryPageBuilder['sliders']['fullscreen']['slides']) && is_array($galleryPageBuilder['sliders']['fullscreen']['slides'])) {
					foreach ($galleryPageBuilder['sliders']['fullscreen']['slides'] as $imageid => $image) {						
						$imgCounter++;
						if (isset($image['title']['value']) && strlen($image['title']['value'])>0) {$photoTitle = $image['title']['value'];} else {$photoTitle = "";}
						if (isset($image['caption']['value']) && strlen($image['caption']['value'])>0) {$photoCaption  = $image['caption']['value'];} else {$photoCaption = "";}						
					?>
				<div class="fw_grid_item">
					<div class="fw_grid_content" style="margin-bottom:<?php echo $setPad; ?>; margin-right:<?php echo $setPad; ?>;">
                        <div class="img_block wrapped_img fs_port_item gallery_item_wrapper">
							<?php
							$img4work = wp_get_attachment_image_src($image["attach_id"], 'original');
							$img_width = $img4work[1];
							$img_height = $img4work[2];
							$img_ratio = $img_width/$img_height;							
							if ($image['slide_type'] == 'image') {								
								 echo '<a class="dm_link" id="dm_image'.$imgCounter .'" data-count="'.$imgCounter .'" data-width="'.$img_width.'" data-height="'.$img_height.'" data-ratio="'.$img_ratio.'" data-thmb="'.aq_resize($img4work[0], "104", "104", true, true, true).'" data-type="image" href="'. $img4work[0] .'" title="'. esc_attr($photoTitle) .'">';
							} else if ($image['slide_type'] == 'video') {
								#YOUTUBE
								$is_youtube = substr_count($image['src'], "youtu");				
								if ($is_youtube > 0) {
									$videoid = substr(strstr($image['src'], "="), 1);					
									echo '<a class="dm_link" id="dm_image'.$imgCounter .'" data-count="'.$imgCounter .'" data-thmb="'.aq_resize($img4work[0], "104", "104", true, true, true).'" data-type="youtube" href="'. $videoid .'" title="'. esc_attr($photoTitle) .'">';
								}
								#VIMEO
								$is_vimeo = substr_count($image['src'], "vimeo");
								if ($is_vimeo > 0) {
									$videoid = substr(strstr($image['src'], "m/"), 2);
									echo '<a class="dm_link" id="dm_image'.$imgCounter .'" data-count="'.$imgCounter .'" data-thmb="'.aq_resize(wp_get_attachment_url($image["attach_id"]), "104", "104", true, true, true).'" data-type="vimeo" href="'. $videoid .'" title="'. esc_attr($photoTitle) .'">';
								}
							}
							?>
							</a>                            
							<img width="960" class="img2preload" height="960" data-title = "<?php echo esc_attr($photoTitle); ?>" data-caption = "<?php echo esc_attr($photoCaption); ?>"  data-img="<?php echo $img4work[0]; ?>" src="<?php echo aq_resize($img4work[0], "960", "960", true, true, true); ?>" alt="<?php echo esc_attr($photoTitle); ?>" />
                            <div class="gallery_fadder"></div>
                            <div class="gal_content">
                            	<?php if (strlen(trim($photoTitle)) > 0) {
	                            	echo "<h3>" . $photoTitle . "</h3>";
                                } ?>
	                            <span class="gal_plus_ico"></span>
                            </div>
                        </div>                    
                    </div>
                </div>                                                
						<?php						
					}
				}
			}
			?>            
        </div>
        <div class="clear"></div>
	</div>
    <div class="side_controls">
    	<a href="<?php echo esc_js("javascript:void(0)"); ?>" class="dm_ctrl_close nav_button nav-close"></a><span class="dm_span_close"><?php _e('Close', 'theme_localization') ?></span>
        <a href="<?php echo esc_js("javascript:void(0)"); ?>" class="dm_ctrl_info nav_button nav-info"></a><span class="dm_span_info"><?php _e('More Info', 'theme_localization') ?></span>
        <div class="dm_share_block">
            <a href="<?php echo esc_js("javascript:void(0)");?>" class="share_toggle nav_button nav-share"></a>
            <div class="share_box">
                <a target="_blank"
                   href="http://www.facebook.com/share.php?u=<?php echo get_permalink(); ?>" class="nav_button nav-facebook"></a>
                <a target="_blank"
                   href="https://twitter.com/intent/tweet?text=<?php echo get_the_title(); ?>&amp;url=<?php echo get_permalink(); ?>" class="nav_button nav-twitter"></a>
                <a target="_blank"
                   href="https://plus.google.com/share?url=<?php echo get_permalink(); ?>" class="nav_button nav-gplus"></a>
                <a target="_blank"
                   href="http://pinterest.com/pin/create/button/?url=<?php echo get_permalink(); ?>&media=<?php echo (strlen($featured_image[0])>0) ? $featured_image[0] : gt3_get_theme_option("logo"); ?>" class="nav_button nav-pinterest"></a>
            </div> 
        </div>        
    </div>
    <div id="dm_dragMe"></div>    
    <script>
		jQuery(document).ready(function($){
			jQuery('.custom_bg').remove();
			gal_setup();			
			jQuery('body').dm_lightbox({
				container: "fw_grid_module"
			});
			jQuery('.share_toggle').click(function(){
				jQuery('.dm_share_block').toggleClass('show_share');
			});			
		});	
		jQuery(window).load(function($){
			gal_setup();
		});	
		jQuery(window).resize(function($){
			gal_setup();
		});
		function gal_setup() {
			jQuery('.gal_content').each(function(){
				jQuery(this).css('margin-top', -1*jQuery(this).height()/2+'px');
			});				
		}			
    </script>    
	<?php 
		$GLOBALS['showOnlyOneTimeJS']['gallery_likes'] = "
		<script>
			jQuery(document).ready(function($) {
				jQuery('.gallery_likes_add').click(function(){
				var gallery_likes_this = jQuery(this);
				if (!jQuery.cookie(gallery_likes_this.attr('data-modify')+gallery_likes_this.attr('data-attachid'))) {
					jQuery.post(gt3_ajaxurl, {
						action:'add_like_attachment',
						attach_id:jQuery(this).attr('data-attachid')
					}, function (response) {
						jQuery.cookie(gallery_likes_this.attr('data-modify')+gallery_likes_this.attr('data-attachid'), 'true', { expires: 7, path: '/' });
						gallery_likes_this.addClass('already_liked');
						gallery_likes_this.find('i').removeClass('icon-heart-o').addClass('icon-heart');
						gallery_likes_this.find('span').text(response);
					});
				}
				});
			});
		</script>
		";		
	?>
    
<?php get_footer('fullscreen'); 
} else {
	get_header('fullscreen');
?>
    <div class="pp_block unloaded">
        <h1 class="pp_title"><?php  _e('This Content is Password Protected', 'theme_localization') ?></h1>
        <div class="pp_wrapper">
            <?php the_content(); ?>
        </div>
    </div>
    <script>
		jQuery(document).ready(function(){
			jQuery('.post-password-form').find('label').find('input').attr('placeholder', 'Enter The Password...');
			setTimeout('jQuery(".pp_block").removeClass("unloaded")',350);
		});
	</script>
<?php 
	get_footer('fullscreen');
} ?>