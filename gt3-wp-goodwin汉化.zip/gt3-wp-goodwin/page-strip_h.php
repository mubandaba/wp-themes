<?php
/*
Template Name: Striped Page Horizontal
*/
if ( !post_password_required() ) {
get_header('fullscreen');
?>
	<?php $gt3_theme_pagebuilder = gt3_get_theme_pagebuilder(get_the_ID());    
    if (isset($gt3_theme_pagebuilder['strips']) && is_array($gt3_theme_pagebuilder['strips'])) {
		if (isset($gt3_theme_pagebuilder['settings']['item_per_line']) && (int)$gt3_theme_pagebuilder['settings']['item_per_line'] > 0) {
        	$el_count = (int)$gt3_theme_pagebuilder['settings']['item_per_line'];
		} else {
			$el_count = 4;
		}
        $strip_height = 100/$el_count;
	?>
    	<style>
			.strip-item {
				height:<?php echo $strip_width; ?>%;				
			}
		</style>
        <div class="strip-horizontal fadeOnLoad" data-onScreen="<?php echo $el_count; ?>">
            <?php foreach ($gt3_theme_pagebuilder['strips'] as $stripid => $stripdata) {
                if (!isset($stripdata['opacity']) || $stripdata['opacity'] == '') {
                    $opacity = '1';
                } else {
                    $opacity = $stripdata['opacity'];
                }
                ?>
            <div class="hStrip-item" style="background-image:url(<?php echo $stripdata['bgimage']; ?>);">
                <div class="hStrip-fadder"></div>
                <div class="hStrip-text">
                    <?php
						if (isset($stripdata['striptitle1']) && $stripdata['striptitle1'] !== '') {?>
                    <h2 class="strip-title"><?php echo $stripdata['striptitle1']; ?></h2>
                    <?php }	?>
                </div>
                <a href="<?php echo $stripdata['link']; ?>" class="strip_link"></a>
            </div>
            <?php }?>
        </div>
        <script>
            jQuery(document).ready(function($) {
				strip_setup();
				setTimeout("strip_setup()",500);
            });	
            jQuery(window).load(function($) {
				strip_setup();
            });	
			jQuery(window).resize(function(){
				strip_setup();
				setTimeout("strip_setup()",500);
			});
			function strip_setup() {
				setHeight = (window_h - header_h)/parseInt(jQuery('.strip-horizontal').attr('data-onScreen'));
				jQuery('.strip-text').each(function(){
					jQuery(this).css('margin-top', -1 * jQuery(this).height()/2);
				});
				if (window_w < 760) {
					jQuery('.hStrip-item').height(window_h/<?php echo $el_count; ?>);
					jQuery('.hStrip-item').each(function(){
						jQuery(this).find('.hStrip-text').css('margin-top',-1*jQuery(this).find('.hStrip-text').height()/2 - 2);
					});
				} else {
					jQuery('.hStrip-item').each(function(){
						jQuery(this).height(setHeight);
						jQuery(this).find('.hStrip-text').css('margin-top',-1*jQuery(this).find('.hStrip-text').height()/2 - 2);
					});
				}
			}
        </script>
    <?php } ?> 
<?php
get_footer('fullscreen'); 
} else {
	get_header('fullscreen');
?>
    <div class="pp_block unloaded">
        <h1 class="pp_title"><?php  _e('This Content is Password Protected', 'theme_localization') ?></h1>
        <div class="pp_wrapper">
            <?php the_content(); ?>
        </div>
    </div>
    <script>
		jQuery(document).ready(function(){
			jQuery('.post-password-form').find('label').find('input').attr('placeholder', 'Enter The Password...');
			setTimeout('jQuery(".pp_block").removeClass("unloaded")',350);
		});
	</script>
<?php 
	get_footer('fullscreen');
} ?>