<?php
/*
Template Name: Gallery - Albums Ajax
*/
if ( !post_password_required() ) {
    get_header('fullscreen');
    the_post();

    $gt3_theme_pagebuilder = gt3_get_theme_pagebuilder(get_the_ID());
    $featured_image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'single-post-thumbnail');
    $pf = get_post_format();
    wp_enqueue_script('gt3_cookie_js', get_template_directory_uri() . '/js/jquery.cookie.js', array(), false, true);
	
	global $wp_query_in_shortcodes, $paged;

	if(empty($paged)){
		$paged = (get_query_var('page')) ? get_query_var('page') : 1;
	}
	if (isset($gt3_theme_pagebuilder['settings']['cat_ids']) && (is_array($gt3_theme_pagebuilder['settings']['cat_ids']))) {
		$compile_cats = array();
		foreach ($gt3_theme_pagebuilder['settings']['cat_ids'] as $catkey => $catvalue) {
			array_push($compile_cats, $catkey);
		}
		$selected_categories = implode(",", $compile_cats);
	} else {
		$selected_categories = "";
	}
	$post_type_terms = array();
	if (isset($selected_categories) && strlen($selected_categories) > 0) {
		$post_type_terms = explode(",", $selected_categories);
		$post_type_filter = explode(",", $selected_categories);
		if (count($post_type_terms) > 0) {
			$args = array(
				'post_type' => 'gallery',
				'order' => 'DESC',
				'paged' => $paged,
				'posts_per_page' => -1
			);
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'gallerycat',
					'field' => 'id',
					'terms' => $post_type_terms
				)
			);
		}
	} else {
		$post_type_filter = "";
		$args = array(
			'post_type' => 'gallery',
			'order' => 'DESC',
			'paged' => $paged,
			'posts_per_page' => -1
		);
	}
	$wp_query_in_shortcodes = new WP_Query();
	$num = 1;

	if (isset($_GET['slug']) && strlen($_GET['slug']) > 0) {
		$post_type_terms = esc_attr($_GET['slug']);
		if (count($post_type_terms) > 0) {
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'gallerycat',
					'field' => 'slug',
					'terms' => $post_type_terms
				)
			);
		}
	}
	?>        
<div class="screen_cutter">
    <div class="leftSide_Container fadeOnLoad">
			<div class="ls_listing">
				<?php
                $wp_query_in_shortcodes->query($args);
                while ($wp_query_in_shortcodes->have_posts()) : $wp_query_in_shortcodes->the_post();
                    $all_likes = gt3pb_get_option("likes");
                    $gt3_theme_post = get_plugin_pagebuilder(get_the_ID());
                    $featured_image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'single-post-thumbnail');
                    $pf = get_post_format();
                    $echoallterm = '';
                    $new_term_list = get_the_terms(get_the_id(), "gallerycat");
                    if (is_array($new_term_list)) {
                        foreach ($new_term_list as $term) {
                            $tempname = strtr($term->name, array(
                                ' ' => ', ',
                            ));
                            $echoallterm .= strtolower($tempname) . " ";
                            $echoterm = $term->name;
                        }
                    } else {
                        $tempname = 'Uncategorized';
                    }
                    $picsCount = count($gt3_theme_post['sliders']['fullscreen']['slides']);
					if ($num == 1) {
						$actClass = 'active';
						$activateID = get_the_ID();
					} else {
						$actClass = '';
					}
                    ?>               
                    <div <?php post_class("album_item"); ?>>
                        <div class="album_item_wrapper album_item<?php echo get_the_ID(); ?> <?php echo $actClass; ?>" data-postid = "<?php echo get_the_ID(); ?>" data-count = "<?php echo $num; ?>" data-link = "<?php echo get_permalink(); ?>">
	                        <a href="<?php echo get_permalink(); ?>" class="iPhone_link"></a>
	                        <div class="album_item_fadder"></div>
                            <div class="img_block">
                                <img src="<?php echo aq_resize($featured_image[0], "540", "440", true, true, true); ?>" alt="" class="fw_featured_image img2preload" width="540">
                            </div>
                            
                            <div class="fs_content_box fs_albums">
                                <h3 class="fs_blog_title"><a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a></h3>
                                <div class="albums_info">
                                    <div class="gallery_views">
                                        <i class="stand_icon icon-eye"></i>
                                        <span><?php echo (get_post_meta(get_the_ID(), "post_views", true) > 0 ? get_post_meta(get_the_ID(), "post_views", true) : "0"); ?></span>
                                    </div>
                                    <div class="gallery_likes gallery_likes_add <?php echo (isset($_COOKIE['like_album'.get_the_ID()]) ? "already_liked" : ""); ?>" data-attachid="<?php echo get_the_ID(); ?>" data-modify="like_album">
                                        <i class="stand_icon <?php echo (isset($_COOKIE['like_album'.get_the_ID()]) ? "icon-heart" : "icon-heart-o"); ?>"></i>
                                        <span><?php echo ((isset($all_likes[get_the_ID()]) && $all_likes[get_the_ID()]>0) ? $all_likes[get_the_ID()] : 0); ?></span>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="album_content">                                                    
							<?php 
                                the_content(__('Read more!', 'theme_localization'));
                                wp_link_pages(array('before' => '<div class="page-link"><span>' . __('Pages', 'theme_localization') . ': </span>', 'after' => '</div>'));?>
                                <div class="dn"><?php posts_nav_link(); ?></div>
                                <div class="side_meta">                                    
                                    <?php
                                        if (isset($gt3_theme_post['page_settings']['icons']) && is_array($gt3_theme_post['page_settings']['icons'])) {
                                            foreach ($gt3_theme_post['page_settings']['icons'] as $skillkey => $skillvalue) {
                                                echo '<div class="side_meta_item"><span><i class="'.$skillvalue['data-icon-code'].'"></i>'. esc_attr($skillvalue['name']) .':</span> '. esc_attr($skillvalue['link']) .'</div>';
                                            }
                                        }
                                    ?>                                                                                    
                                    <div class="side_meta_item">
                                        <span><i class="stand_icon icon-eye"></i><?php _e('Views', 'theme_localization')?>:</span>
                                        <?php echo (get_post_meta(get_the_ID(), "post_views", true) > 0 ? get_post_meta(get_the_ID(), "post_views", true) : "0"); ?>
                                    </div>
                                    <div class="side_meta_item">
                                        <span><i class="stand_icon <?php echo (isset($_COOKIE['like_gallery'.get_the_ID()]) ? "icon-heart" : "icon-heart-o"); ?>"></i><?php _e('Likes', 'theme_localization')?>:</span>
                                        <?php echo ((isset($all_likes[get_the_ID()]) && $all_likes[get_the_ID()]>0) ? $all_likes[get_the_ID()] : 0); ?>
                                    </div>
                                </div><!-- .side_meta -->
                            </div><!-- .album_content -->        
                        </div><!-- .album_item_wrapper -->
                    </div><!-- .album_item -->
        			<?php $num++; ?>
                <?php endwhile;?>
        	</div><!-- .ls_listing -->
	</div><!-- .leftSide_Container -->
	<div class="script_container">
    	
    </div>
    <div class="ajax_slider_wrapper">
    	<ul id="ajax_slider" class="reload">
        	
        </ul>
    </div>
    <div class="ajaxSlider_controls">
        <a href="<?php echo esc_js("javascript:void(0)"); ?>" class="nav_button nav-up nextSlide"></a>
        <a href="<?php echo esc_js("javascript:void(0)"); ?>" class="nav_button nav-info"></a>
        <div class="fs_share_block_single">
            <a href="<?php echo esc_js("javascript:void(0)");?>" class="share_toggle nav_button nav-share"></a>
            <div class="share_box">
                <a target="_blank"
                   href="http://www.facebook.com/share.php?u=<?php echo get_permalink(); ?>" class="nav_button nav-facebook"></a>
                <a target="_blank"
                   href="https://twitter.com/intent/tweet?text=<?php echo get_the_title(); ?>&amp;url=<?php echo get_permalink(); ?>" class="nav_button nav-twitter"></a>
                <a target="_blank"
                   href="https://plus.google.com/share?url=<?php echo get_permalink(); ?>" class="nav_button nav-gplus"></a>
                <a target="_blank"
                   href="http://pinterest.com/pin/create/button/?url=<?php echo get_permalink(); ?>&media=<?php echo (strlen($featured_image[0])>0) ? $featured_image[0] : gt3_get_theme_option("logo"); ?>" class="nav_button nav-pinterest"></a>
            </div> 
        </div>
        <a href="<?php echo esc_js("javascript:void(0)"); ?>" class="nav_button nav-down prevSlide"></a>
    </div><!-- .fs_content_bg -->

</div><!-- .ScreenCutter -->
<div class="fs_content_bg">
    <div class="fs_content_block reload">
        <div class="fs_content_wrapper">
        	<h1 class="side_title no_title"><?php the_title(); ?></h1>
            <div class="appended_content">
            </div>
        </div><!-- .fs_content_wrapper -->
    </div><!-- .fs_content_block -->
</div><!-- .fs_content_bg -->

	<script>
		var step = 200,
		scrollSpeed = 3,
		cols = jQuery('.leftSide_Container'),
		cols2 = jQuery('.fs_content_bg'),
		downStep = 1,
		contentBlock = jQuery('.fs_content_block'),
		side_title = jQuery('.side_title'),
		appendTo = jQuery('.appended_content');

		var slider = jQuery('#ajax_slider'),
		thisSlide = 0,
		currentSlide = 0,
		nextObj, currentObj, prevObj;
		
		jQuery(document).ready(function() {
			if (jQuery(window).width() > 760) {		
				html.addClass('ajax-albums');
				jQuery('.album_item_wrapper').click(function(){
					jQuery('.active').removeClass('active');
					jQuery(this).addClass('active');
					slider.addClass('reload');
					contentBlock.addClass('reload');
					setTimeout("gt3_get_gallery(jQuery('.active').attr('data-postid'))",500);
					
				});			
				jQuery('.custom_bg').remove();
				setSize = window_h - header_h;
				cols.height(setSize).css('top', header_h);
				cols2.height(setSize).css('top', header_h);
				
				jQuery('.toggle_fullview').click(function(){
					if (html.hasClass('fullview')) {
						setSize = window_h - header_h;
						cols.height(setSize).css('top', header_h);
						cols2.height(setSize).css('top', header_h);
						slider.width(jQuery(window).width() - cols.width());
					} else {
						setSize = window_h;
						cols.height(window_h).css('top', '0px');
						cols2.height(window_h).css('top', '0px');
						slider.width(jQuery(window).width());
					}
				});
				
				// SCROLLING
				
				jQuery('.ls_listing').on('mousewheel', function(event) {
					step = event.deltaY * 200;
					ground = setSize - jQuery(this).height();
					
					thisTop = parseInt(jQuery(this).css('top'));
					if (jQuery(this).height() > setSize) {
						if (event.deltaY < 0) {
							if ((thisTop + step) > ground) {
								jQuery(this).css('top', thisTop + step + 'px');
							} else {
								jQuery(this).css('top', ground + 'px');
							}
						}
						if (event.deltaY > 0) {
							thisTop = parseInt(jQuery(this).css('top'));
							if (thisTop + step < 0) {
								jQuery(this).css('top', thisTop + step + 'px');
							} else {
								jQuery(this).css('top', '0px');
							}
						}
					}
				});
				contentBlock.on('mousewheel', function(event) {
					if (jQuery(this).hasClass('needScroll')) {
						step = event.deltaY * 200;
						ground = setSize - jQuery(this).height();
						
						thisTop = parseInt(jQuery(this).css('top'));
						if (jQuery(this).height() > setSize) {
							if (event.deltaY < 0) {
								if ((thisTop + step) > ground) {
									jQuery(this).css('top', thisTop + step + 'px');
								} else {
									jQuery(this).css('top', ground + 'px');
								}
							}
							if (event.deltaY > 0) {
								thisTop = parseInt(jQuery(this).css('top'));
								if (thisTop + step < 0) {
									jQuery(this).css('top', thisTop + step + 'px');
								} else {
									jQuery(this).css('top', '0px');
								}
							}
						}
					}
				});
	
				jQuery('.ls_listing').bind('touchstart', function(event) {
					touch = event.originalEvent.touches[0];
					startAt = touch.pageY;
					html.addClass('touched');
					topStart = parseInt(jQuery(this).css('top'));
					ground = setSize - jQuery(this).height();
				});
				
				jQuery('.ls_listing').bind('touchmove', function(event) {
					touch = event.originalEvent.touches[0];
					movePath = -1* (startAt - touch.pageY)/1;
					curTop = topStart + movePath;
					if (jQuery(this).height() > setSize) {
						if (curTop > 0) {
							jQuery(this).css('top', '0px');
						} else if (curTop < ground) {
							jQuery(this).css('top', ground + 'px');
						} else {
							jQuery(this).css('top', curTop + 'px');
						}
					}
				});
							
				jQuery('.ls_listing').bind('touchend', function(event) {
					html.removeClass('touched');
					touch = event.originalEvent.changedTouches[0];
					topEnd = parseInt(jQuery(this).css('top'));
				});
				
				//GALLERY 
				jQuery('.share_toggle').click(function(){
					jQuery('.fs_share_block_single').toggleClass('show_share');
					html.toggleClass('shareToggled');
				});
				jQuery('.nav-info').click(function(){
					html.toggleClass('showed_info');
				});
				jQuery('.prevSlide').click(function(){
					prevSlide();
				});
				jQuery('.nextSlide').click(function(){
					nextSlide();
				});
	
				jQuery('#ajax_slider').bind('touchstart', function(event) {
					touch = event.originalEvent.touches[0];
					startAt = touch.pageY;
					html.addClass('touched');
				});
				
				jQuery('#ajax_slider').bind('touchmove', function(event) {
					touch = event.originalEvent.touches[0];
	
					movePath = (startAt - touch.pageY)/2;
					movePercent = -1* (movePath*100)/window_h;
					prevSl = jQuery('.slidePrev');
					curSl = jQuery('.slideCurrent');
					nextSl = jQuery('.slideNext');
	
					movePrev = -100 + movePercent;
					moveMain = movePercent;
					moveNext = 100 + movePercent;
	
					prevSl.css('top' , movePrev +'%');
					curSl.css('top' , moveMain +'%');
					nextSl.css('top' , moveNext +'%');
				});
							
				jQuery('#ajax_slider').bind('touchend', function(event) {
					html.removeClass('touched');
					touch = event.originalEvent.changedTouches[0];
					if (touch.pageY < startAt) {
						prevSlide();
					}
					if (touch.pageY > startAt) {
						nextSlide();
					}
				});
				jQuery(document.documentElement).keyup(function (event) {
					if ((event.keyCode == 40 || event.keyCode == 39)) {
						prevSlide();
					} else if ((event.keyCode == 38 || event.keyCode == 37)) {
						nextSlide();
					}
				});
				
				//Start First Gallery
				gt3_get_gallery(<?php echo $activateID; ?>);			
				gal_setup();
				content_setup();
			}
		});
		
		function content_setup() {			
			setTop = (window_h - contentBlock.height() - header_h)/2;
			if (setTop < 0) {
				setTop = 0;
				contentBlock.addClass('needScroll');
			} else {
				contentBlock.removeClass('needScroll');
			}
			contentBlock.css('top', setTop);
		}
		function gal_setup() {
			if (html.hasClass('fullview')) {
				setSize = window_h;
				cols.height(window_h).css('top', '0px');
				cols2.height(window_h).css('top', '0px');
				slider.width(jQuery(window).width());
			} else {
				setSize = window_h - header_h;
				cols.height(setSize).css('top', header_h);
				cols2.height(setSize).css('top', header_h);
				slider.width(jQuery(window).width() - cols.width());
			}
		}

		function prevSlide() {
			curSlide = parseInt(jQuery('.slideCurrent').attr('data-count'));
			newSlide = curSlide + 1;
			if (newSlide > slider.find('li').size()-1) {
				newSlide = 0;
			}			
			setSlide(newSlide);
		}
		function nextSlide() {
			curSlide = parseInt(jQuery('.slideCurrent').attr('data-count'));
			newSlide = curSlide - 1;
			if (newSlide < 0) {
				newSlide = slider.find('li').size()-1;
			}
			setSlide(newSlide);
		}
		
        function slider_setup(slides) {
			slider.html('');
			thisSlide = 0;
			while (thisSlide <= slides.length - 1) {
				if (slides[thisSlide].type == "image") {
					slider.append('<li class="fs_slide block2preload slide' + thisSlide + '" data-count="' + thisSlide + '" data-src="' + slides[thisSlide].image + '" data-type="' + slides[thisSlide].type + '"></li>');
				} else if (slides[thisSlide].type == "youtube") {
					slider.append('<li class="fs_slide yt_slide video_slide slide' + thisSlide + '" data-count="' + thisSlide + '" data-bg="' + slides[thisSlide].thmb + '" data-src="' + slides[thisSlide].src + '" data-type="' + slides[thisSlide].type + '"></li>');
				} else {
					slider.append('<li class="fs_slide video_slide slide' + thisSlide + '" data-id="player' + slides[thisSlide].uniqid + '" data-count="' + thisSlide + '" data-bg="' + slides[thisSlide].thmb + '" data-src="' + slides[thisSlide].src + '" data-type="' + slides[thisSlide].type + '"></li>');
				}		
				thisSlide++;
			}
			setSlide(0);
			slider.removeClass('reload');
			contentBlock.removeClass('reload');
        }
		function setSlide(cur) {
			//cur = parseInt(cur);
			allSize = slider.find('li').size()-1;
			
			slider.find('iframe').remove();
						
			jQuery('.slidePrev').removeClass('slidePrev');
			jQuery('.slideCurrent').removeClass('slideCurrent');
			jQuery('.slideNext').removeClass('slideNext');
			if (allSize > 2) {
				jQuery('.slidePrev2').removeClass('slidePrev2');
				jQuery('.slideNext2').removeClass('slideNext2');
			}

			slideCurrent = slider.find('.slide'+cur);
			if((cur+1) > allSize) {
				slideNext = slider.find('.slide0');
				slideNext2 = slider.find('.slide1');
			} else if ((cur+1) == allSize){
				slideNext = slider.find('.slide'+allSize);
				slideNext2 = slider.find('.slide0');
			} else {
				slideNext = slider.find('.slide'+(cur+1));
				slideNext2 = slider.find('.slide'+(cur+2));
			}
			if((cur-1) < 0) {
				slidePrev = slider.find('.slide'+allSize);
				slidePrev2 = slider.find('.slide'+(allSize-1));
			} else if ((cur-1) == 0){					
				slidePrev = slider.find('.slide0');
				slidePrev2 = slider.find('.slide'+allSize);
			} else {
				slidePrev = slider.find('.slide'+(cur-1));
				slidePrev2 = slider.find('.slide'+(cur-2));
			}
			
			//SetSlides
			if (slideNext.attr('data-type') == 'image') {
				slideNext.attr('style', 'background-image:url(' + slideNext.attr('data-src') + ');');
			} else {
				slideNext.attr('style', 'background-image:url(' + slideNext.attr('data-bg') + ');');
			}
			if (slideCurrent.attr('data-type') == 'image') {
				slideCurrent.attr('style', 'background-image:url(' + slideCurrent.attr('data-src') + ');');
			} else {
				slideCurrent.attr('style', 'background-image:url(' + slideCurrent.attr('data-bg') + ');');
				if (slideCurrent.attr('data-type') == 'youtube') {
					slideCurrent.append('<iframe width="100%" height="100%" src="http://www.youtube.com/embed/' + slideCurrent.attr('data-src') + '?controls=0&autoplay=1&showinfo=0&modestbranding=1&wmode=opaque&rel=0&hd=1&disablekb=1" frameborder="0" allowfullscreen></iframe>');
				} else {
					slideCurrent.append(jQuery('<iframe width="100%" height="100%" src="http://player.vimeo.com/video/' + slideCurrent.attr('data-src') + '?api=1&amp;title=0&amp;byline=0&amp;portrait=0&autoplay=1&loop=0&controls=0" frameborder="0" webkitAllowFullScreen allowFullScreen></iframe>'));
				}
				videoSetup();
			}
			if (slidePrev.attr('data-type') == 'image') {
				slidePrev.attr('style', 'background-image:url(' + slidePrev.attr('data-src') + ');');
			} else {
				slidePrev.attr('style', 'background-image:url(' + slidePrev.attr('data-bg') + ');');
			}
			if (allSize > 2) {
				if (slideNext2.attr('data-type') == 'image') {
					slideNext2.attr('style', 'background-image:url(' + slideNext2.attr('data-src') + ');');
				} else {
					slideNext2.attr('style', 'background-image:url(' + slideNext2.attr('data-bg') + ');');
				}			
				if (slidePrev2.attr('data-type') == 'image') {
					slidePrev2.attr('style', 'background-image:url(' + slidePrev2.attr('data-src') + ');');
				} else {
					slidePrev2.attr('style', 'background-image:url(' + slidePrev2.attr('data-bg') + ');');
				}
			}

			slideNext.addClass('slideNext');
			slideCurrent.addClass('slideCurrent');
			slidePrev.addClass('slidePrev');
			if (allSize > 2) {
				slidePrev2.addClass('slidePrev2');
				slideNext2.addClass('slideNext2');
			}
			
			//CleanSlides
			/*slider.find('li').each(function(){
				if (!jQuery(this).hasClass('.slidePrev2') && !jQuery(this).hasClass('.slidePrev') && !jQuery(this).hasClass('.slideCurrent') && !jQuery(this).hasClass('.slideNext') && !jQuery(this).hasClass('.slideNext2')) {
					jQuery(this).attr('style', '');
				}
				if (!jQuery(this).hasClass('.slideCurrent')) {
					jQuery(this).html('');
				}
			});*/
			
		}
		function gt3_get_gallery(current_id) {
			jQuery.post(gt3_ajaxurl, {
				action: "get_gallery_works",
				current_id: current_id
			})
			.done(function (data) {
				jQuery('.script_container').empty();
				jQuery('.script_container').append(data);
				if (show_title == 'yes') {
					side_title.removeClass('no_title');
					side_title.text(jQuery('.album_item'+setID).find('.fs_blog_title').text());
				} else {
					side_title.text('');
					side_title.addClass('no_title');
				}
				appendTo.html(jQuery('.album_item'+setID).find('.album_content').html());
				content_setup();
				setTimeout("content_setup()",500);
				
				if (gallery_status == 'ok') {
					slider_setup(new_gallery_set);
				}
				slider.removeClass('no_fit');
				slider.removeClass('fit_always');
				slider.removeClass('fit_width');
				slider.removeClass('fit_height');
				slider.addClass(fit_style);

				gal_setup();
				setTimeout("gal_setup()",500);
				content_setup();
				setTimeout("content_setup()",600);			
			});
		}		

		function videoSetup() {
			/*SETUP VIDEO*/
			if (jQuery(window).width() > 1024) {
				if (jQuery('iframe').size() > 0) {
					if (((window_h + 150) / 9) * 16 > window_w) {
						jQuery('iframe').height(window_h + 150).width(((window_h + 150) / 9) * 16);
						jQuery('iframe').css({
							'margin-left': (-1 * jQuery('iframe').width() / 2) + 'px',
							'top': "-75px",
							'margin-top': '0px'
						});
					} else {
						jQuery('iframe').width(window_w).height(((window_w) / 16) * 9);
						jQuery('iframe').css({
							'margin-left': (-1 * jQuery('iframe').width() / 2) + 'px',
							'margin-top': (-1 * jQuery('iframe').height() / 2) + 'px',
							'top': '50%'
						});
					}
				}
			} else {
				jQuery('iframe').height(window_h).width(window_w).css({
					'top': '0px',
					'margin-left' : '0px',
					'left' : '0px',
					'margin-top': '0px'
				});
			}
		}
		
		jQuery(window).load(function($){
			if (jQuery(window).width() > 760) {
				gal_setup();
				content_setup();
			}
		});	
		jQuery(window).resize(function($){
			if (jQuery(window).width() > 760) {
				gal_setup();
				setTimeout("gal_setup()",500);
				content_setup();
				setTimeout("content_setup()",600);		
			}
		});		
	</script>

	<?php 
		$GLOBALS['showOnlyOneTimeJS']['gallery_likes'] = "
		<script>
			jQuery(document).ready(function($) {
				jQuery('.gallery_likes_add').click(function(){
				var gallery_likes_this = jQuery(this);
				if (!jQuery.cookie(gallery_likes_this.attr('data-modify')+gallery_likes_this.attr('data-attachid'))) {
					jQuery.post(gt3_ajaxurl, {
						action:'add_like_attachment',
						attach_id:jQuery(this).attr('data-attachid')
					}, function (response) {
						jQuery.cookie(gallery_likes_this.attr('data-modify')+gallery_likes_this.attr('data-attachid'), 'true', { expires: 7, path: '/' });
						gallery_likes_this.addClass('already_liked');
						gallery_likes_this.find('i').removeClass('icon-heart-o').addClass('icon-heart');
						gallery_likes_this.find('span').text(response);
					});
				}
				});
			});
		</script>
		";		
	?>    
    <?php get_footer('fullwidth');
} else {
	get_header('fullscreen');
?>
    <div class="pp_block unloaded">
        <h1 class="pp_title"><?php  _e('This Content is Password Protected', 'theme_localization') ?></h1>
        <div class="pp_wrapper">
            <?php the_content(); ?>
        </div>
    </div>
    <script>
		jQuery(document).ready(function(){
			jQuery('.post-password-form').find('label').find('input').attr('placeholder', 'Enter The Password...');
			setTimeout('jQuery(".pp_block").removeClass("unloaded")',350);
		});
	</script>
<?php 
	get_footer('fullscreen');
} ?>