<?php

$gt3_tabs_admin_theme = new Tabs_admin_theme();

$gt3_tabs_admin_theme->add(new Tab_admin_theme(array(
    'name' => 'General',
    'desc' => '',
    'icon' => 'general.png',
    'icon_active' => 'general_active.png',
    'icon_hover' => 'general_hover.png'
), array(
    new UploadOption_admin_theme(array(
        'name' => '页眉 logo',
        'id' => 'logo',
        'desc' => '默认: 140px x 40px',
        'default' => THEMEROOTURL . '/img/logo.png'
    )),
    new UploadOption_admin_theme(array(
        'name' => 'Logo (视网膜)',
        'id' => 'logo_retina',
        'desc' => '默认: 280px x 80px',
        'default' => THEMEROOTURL . '/img/retina/logo.png'
    )),
    new textOption_admin_theme(array(
        'name' => '页眉LOGO宽度',
        'id' => 'header_logo_standart_width',
        'not_empty' => true,
        'width' => '100px',
        'textalign' => 'center',
        'default' => '140'
    )),
    new textOption_admin_theme(array(
        'name' => '页眉LOGO高度',
        'id' => 'header_logo_standart_height',
        'not_empty' => true,
        'width' => '100px',
        'textalign' => 'center',
        'default' => '40'
    )),
    new UploadOption_admin_theme(array(
        'type' => 'upload',
        'name' => 'Favicon',
        'id' => 'favicon',
        'desc' => '图标必须 16x16px 或 32x32px',
        'default' => THEMEROOTURL . '/img/favico.ico'
    )),
    new UploadOption_admin_theme(array(
        'type' => 'upload',
        'name' => '苹果触摸图标 (57px)',
        'id' => 'apple_touch_57',
        'desc' => '图标必须 57x57px',
        'default' => THEMEROOTURL . '/img/apple_icons_57x57.png'
    )),
    new UploadOption_admin_theme(array(
        'type' => 'upload',
        'name' => '苹果触摸图标 (72px)',
        'id' => 'apple_touch_72',
        'desc' => '图标必须 72x72px',
        'default' => THEMEROOTURL . '/img/apple_icons_72x72.png'
    )),
    new UploadOption_admin_theme(array(
        'type' => 'upload',
        'name' => '苹果触摸图标 (114px)',
        'id' => 'apple_touch_114',
        'desc' => '图标必须 114x114px',
        'default' => THEMEROOTURL . '/img/apple_icons_114x114.png'
    )),
    new TextareaOption_admin_theme(array(
        'name' => '任意代码 <br>(&lt;/head&gt;之前)',
        'id' => 'code_before_head',
        'default' => ''
    )),
    new TextareaOption_admin_theme(array(
        'name' => '任意代码 <br>(&lt;/body&gt;之前)',
        'id' => 'code_before_body',
        'default' => ''
    )),
    new AjaxButtonOption_admin_theme(array(
        'title' => '导入演示数据',
        'id' => 'action_import',
        'name' => __('Import demo content', 'theme_localization'),
        'confirm' => TRUE,
        'data' => array(
            'action' => 'ajax_import_dump'
        )
    ))
)));

$gt3_tabs_admin_theme->add(new Tab_admin_theme(array(
    'name' => 'Sidebars',
    'desc' => '',
    'icon' => 'sidebars.png',
    'icon_active' => 'sidebars_active.png',
    'icon_hover' => 'sidebars_hover.png'
), array(
    new SelectOption_admin_theme(array(
        'name' => '默认侧栏布局',
        'id' => 'default_sidebar_layout',
        'desc' => '',
        'default' => 'right-sidebar',
        'options' => array(
            'left-sidebar' => '左侧栏',
            'right-sidebar' => '右侧栏',
            'no-sidebar' => '无侧栏'
        )
    )),
    new SidebarManager_admin_theme(array(
        'name' => '侧栏管理',
        'id' => 'sidebar_manager',
        'desc' => ''
    ))
)));

$gt3_tabs_admin_theme->add(new Tab_admin_theme(array(
    'name' => 'Fonts',
    'desc' => '',
    'icon' => 'fonts.png',
    'icon_active' => 'fonts_active.png',
    'icon_hover' => 'fonts_hover.png'
), array(
    new FontSelector_admin_theme(array(
        'name' => '内容字体',
        'id' => 'main_font',
        'desc' => '',
        'default' => 'Roboto',
        'options' => get_fonts_array_only_key_name()
    )),
    new textOption_admin_theme(array(
        'name' => '主字体参数',
        'id' => 'google_font_parameters_main_font',
        'not_empty' => true,
        'default' => ':300,300italic,700',
        'width' => '100%',
        'textalign' => 'left',
        'desc' => '谷歌字体. 点击 <a href="https://developers.google.com/webfonts/docs/getting_started" target="_blank">这里</a> 寻找帮助.'
    )),
    new FontSelector_admin_theme(array(
        'name' => '主菜单字体',
        'id' => 'main_menu_font',
        'desc' => '',
        'default' => 'Roboto',
        'options' => get_fonts_array_only_key_name()
    )),
    new textOption_admin_theme(array(
        'name' => '主菜单字体参数',
        'id' => 'google_font_parameters_menu_font',
        'not_empty' => true,
        'default' => ':300',
        'width' => '100%',
        'textalign' => 'left',
        'desc' => '谷歌字体. 点击 <a href="https://developers.google.com/webfonts/docs/getting_started" target="_blank">这里</a> 寻找帮助.'
    )),
    new FontSelector_admin_theme(array(
        'name' => '页眉',
        'id' => 'text_headers_font',
        'desc' => '',
        'default' => 'Roboto',
        'options' => get_fonts_array_only_key_name()
    )),
    new textOption_admin_theme(array(
        'name' => '页眉字体参数',
        'id' => 'google_font_parameters_headers_font',
        'not_empty' => true,
        'default' => ':300,400',
        'width' => '100%',
        'textalign' => 'left',
        'desc' => '谷歌字体. 点击 <a href="https://developers.google.com/webfonts/docs/getting_started" target="_blank">这里</a> 寻找帮助.'
    )),
    new textOption_admin_theme(array(
        'name' => '内容字体加粗',
        'id' => 'content_weight',
        'not_empty' => true,
        'default' => '300',
        'width' => '100px',
        'textalign' => 'center',
        'desc' => ''
    )),
    new textOption_admin_theme(array(
        'name' => '标题字体加粗',
        'id' => 'headings_weight',
        'not_empty' => true,
        'default' => '300',
        'width' => '100px',
        'textalign' => 'center',
        'desc' => ''
    )),
    new textOption_admin_theme(array(
        'name' => '主菜单字体加粗',
        'id' => 'menu_weight',
        'not_empty' => true,
        'default' => '300',
        'width' => '100px',
        'textalign' => 'center',
        'desc' => ''
    )),
    new textOption_admin_theme(array(
        'name' => '主菜单字体大小',
        'id' => 'menu_font_size',
        'not_empty' => true,
        'default' => '14px',
        'width' => '100px',
        'textalign' => 'center',
        'desc' => ''
    )),
    new textOption_admin_theme(array(
        'name' => 'H1字体大小',
        'id' => 'h1_font_size',
        'not_empty' => true,
        'default' => '40px',
        'width' => '100px',
        'textalign' => 'center',
        'desc' => ''
    )),
    new textOption_admin_theme(array(
        'name' => 'H2字体大小',
        'id' => 'h2_font_size',
        'not_empty' => true,
        'default' => '36px',
        'width' => '100px',
        'textalign' => 'center',
        'desc' => ''
    )),
    new textOption_admin_theme(array(
        'name' => 'H3字体大小',
        'id' => 'h3_font_size',
        'not_empty' => true,
        'default' => '20px',
        'width' => '100px',
        'textalign' => 'center',
        'desc' => ''
    )),
    new textOption_admin_theme(array(
        'name' => 'H4字体大小',
        'id' => 'h4_font_size',
        'not_empty' => true,
        'default' => '14px',
        'width' => '100px',
        'textalign' => 'center',
        'desc' => ''
    )),
    new textOption_admin_theme(array(
        'name' => 'H5字体大小',
        'id' => 'h5_font_size',
        'not_empty' => true,
        'default' => '12px',
        'width' => '100px',
        'textalign' => 'center',
        'desc' => ''
    )),
    new textOption_admin_theme(array(
        'name' => 'H6字体大小',
        'id' => 'h6_font_size',
        'not_empty' => true,
        'default' => '11px',
        'width' => '100px',
        'textalign' => 'center',
        'desc' => ''
    )),
    new textOption_admin_theme(array(
        'name' => '内容字体大小',
        'id' => 'main_content_font_size',
        'not_empty' => true,
        'default' => '14px',
        'width' => '100px',
        'textalign' => 'center',
        'desc' => ''
    )),
    new textOption_admin_theme(array(
        'name' => '内容行高',
        'id' => 'main_content_line_height',
        'not_empty' => true,
        'default' => '21px',
        'width' => '100px',
        'textalign' => 'center',
        'desc' => ''
    )),
)));

$gt3_tabs_admin_theme->add(new Tab_admin_theme(array(
    'name' => 'View Options',
    'icon' => 'layout.png',
    'icon_active' => 'layout_active.png',
    'icon_hover' => 'layout_hover.png'
), array(
    new SelectOption_admin_theme(array(
        'name' => '自适应',
        'id' => 'responsive',
        'desc' => '',
        'default' => 'on',
        'options' => array(
            'on' => '开',
            'off' => '关'
        )
    )),
    new UploadOption_admin_theme(array(
        'type' => 'upload',
        'name' => '默认背景图像',
        'id' => 'bg_img',
        'desc' => '',
        'default' => THEMEROOTURL . '/img/def_bg.jpg'
    )),
    new textOption_admin_theme(array(
        'name' => '每页全屏博客项目',
        'id' => 'fw_posts_per_page',
        'not_empty' => true,
        'width' => '100px',
        'textalign' => 'center',
        'default' => '14'
    )),
    new textOption_admin_theme(array(
        'name' => '每页网格作品项目',
        'id' => 'fw_port_per_page',
        'not_empty' => true,
        'width' => '100px',
        'textalign' => 'center',
        'default' => '12'
    )),
	new SelectOption_admin_theme(array(
        'name' => '相关文章',
        'id' => 'related_posts',
        'desc' => '',
        'default' => 'on',
        'options' => array(
            'on' => '开',
            'off' => '关'
        )
    )),
    new SelectOption_admin_theme(array(
        'name' => '作品评论',
        'id' => 'portfolio_comments',
        'desc' => '',
        'default' => 'disabled',
        'options' => array(
            'disabled' => '禁用',
            'enabled' => '启用'
        )
    )),	
    new SelectOption_admin_theme(array(
        'name' => '页面评论',
        'id' => 'page_comments',
        'desc' => '',
        'default' => 'disabled',
        'options' => array(
            'disabled' => '禁用',
            'enabled' => '启用'
        )
    )),
    new TextareaOption_admin_theme(array(
        'name' => '自定义 CSS',
        'id' => 'custom_css',
        'default' => ''
    )),
    new textOption_admin_theme(array(
        'name' => '预载文本',
        'id' => 'preloader_text',
        'not_empty' => false,
        'width' => '100%',
        'textalign' => 'left',
        'default' => '加载中...'
    ))
)));

$gt3_tabs_admin_theme->add(new Tab_admin_theme(array(
    'name' => 'Gallery Options',
    'icon' => 'landing.png',
    'icon_active' => 'landing_active.png',
    'icon_hover' => 'landing_hover.png'
), array(
    new SelectOption_admin_theme(array(
        'name' => '默认文章样式',
        'id' => 'default_gallery_style',
        'desc' => '',
        'default' => 'fw-gallery-post',
        'options' => array(
            'fw-gallery-post' => '全屏滑块',
            'ribbon-gallery-post' => 'Ribbon 滑块'
        )
    )),
    new SelectOption_admin_theme(array(
        'name' => '滑块动画',
        'id' => 'default_slider_anim',
        'desc' => '',
        'default' => 'fade',
        'options' => array(
            'fade' => 'Fade',
			'slip' => 'Slip'
        )
    )),
    new SelectOption_admin_theme(array(
        'name' => 'Fit 样式',
        'id' => 'default_fit_style',
        'desc' => '',
        'default' => 'no_fit',
        'options' => array(
            'no_fit' => 'Cover Slide',
			'fit_always' => 'Fit Always',
            'fit_width' => 'Fit Horizontal',
			'fit_height' => 'Fit Vertical'
        )
    )),	
    new SelectOption_admin_theme(array(
        'name' => '显示控制',
        'id' => 'default_controls',
        'desc' => '',
        'default' => 'on',
        'options' => array(
            'on' => '是',
            'off' => '否'
        )
    )),
    new SelectOption_admin_theme(array(
        'name' => '自动播放',
        'id' => 'default_autoplay',
        'desc' => '',
        'default' => 'on',
        'options' => array(
            'on' => '是',
            'off' => '否'
        )
    )),
    new textOption_admin_theme(array(
        'name' => '幻灯片间隔时间以毫秒为单位',
        'id' => 'gallery_interval',
        'not_empty' => true,
        'width' => '100px',
        'textalign' => 'center',
        'default' => '3000'
    ))
)));

$gt3_tabs_admin_theme->add(new Tab_admin_theme(array(
    'name' => 'Color options',
    'icon' => 'colors.png',
    'icon_active' => 'colors_active.png',
    'icon_hover' => 'colors_hover.png'
), array(
    new ColorOption_admin_theme(array(
        'name' => '主体背景',
        'id' => 'body_bg',
        'desc' => '',
        'not_empty' => 'true',
        'default' => 'ffffff'
    )),
    new ColorOption_admin_theme(array(
        'name' => '页眉背景',
        'id' => 'header_bg',
        'desc' => '',
        'not_empty' => 'true',
        'default' => '1f2426'
    )),
    new ColorOption_admin_theme(array(
        'name' => '菜单背景',
        'id' => 'menu_bg',
        'desc' => '',
        'not_empty' => 'true',
        'default' => '1f2426'
    )),
    new ColorOption_admin_theme(array(
        'name' => '菜单项目颜色',
        'id' => 'menu_color',
        'desc' => '',
        'not_empty' => 'true',
        'default' => 'f6f6f6'
    )),
    new ColorOption_admin_theme(array(
        'name' => '菜单项目悬停颜色',
        'id' => 'menu_active',
        'desc' => '',
        'not_empty' => 'true',
        'default' => '979797'
    )),
    new ColorOption_admin_theme(array(
        'name' => '内容背景',
        'id' => 'content_bg',
        'desc' => '',
        'not_empty' => 'true',
        'default' => '1e1e1e'
    )),
    new ColorOption_admin_theme(array(
        'name' => '内容文本颜色',
        'id' => 'content_color',
        'desc' => '',
        'not_empty' => 'true',
        'default' => '979797'
    )),
    new ColorOption_admin_theme(array(
        'name' => '内容高亮颜色',
        'id' => 'content_highlight',
        'desc' => '',
        'not_empty' => 'true',
        'default' => 'f6f6f6'
    )),
    new ColorOption_admin_theme(array(
        'name' => '侧边信息背景',
        'id' => 'side_bg',
        'desc' => '',
        'not_empty' => 'true',
        'default' => '1f2426'
    )),
    new ColorOption_admin_theme(array(
        'name' => '标题颜色',
        'id' => 'heading_color',
        'desc' => '',
        'not_empty' => 'true',
        'default' => 'f6f6f6'
    )),
    new ColorOption_admin_theme(array(
        'name' => '标题悬停颜色',
        'id' => 'heading_hover',
        'desc' => '',
        'not_empty' => 'true',
        'default' => '979797'
    )),
    new ColorOption_admin_theme(array(
        'name' => '输入框背景',
        'id' => 'input_bg',
        'desc' => '',
        'not_empty' => 'true',
        'default' => '343434'
    )),
    new ColorOption_admin_theme(array(
        'name' => '输入框颜色',
        'id' => 'input_color',
        'desc' => '',
        'not_empty' => 'true',
        'default' => '979797'
    )),
    new ColorOption_admin_theme(array(
        'name' => '输入激活颜色',
        'id' => 'input_active',
        'desc' => '',
        'not_empty' => 'true',
        'default' => 'f6f6f6'
    )),
    new ColorOption_admin_theme(array(
        'name' => '按钮背景',
        'id' => 'button_bg',
        'desc' => '',
        'not_empty' => 'true',
        'default' => '424c50'
    )),
    new ColorOption_admin_theme(array(
        'name' => '按钮悬停背景',
        'id' => 'button_hover_bg',
        'desc' => '',
        'not_empty' => 'true',
        'default' => 'ffffff'
    )),
    new ColorOption_admin_theme(array(
        'name' => '按钮颜色',
        'id' => 'button_color',
        'desc' => '',
        'not_empty' => 'true',
        'default' => 'ffffff'
    )),
    new ColorOption_admin_theme(array(
        'name' => '按钮悬停颜色',
        'id' => 'button_hover_color',
        'desc' => '',
        'not_empty' => 'true',
        'default' => '2d2e2e'
    )),
    new ColorOption_admin_theme(array(
        'name' => '画廊淡入背景',
        'id' => 'gallery_fade',
        'desc' => '',
        'not_empty' => 'true',
        'default' => '1e1e1e'
    )),
    new ColorOption_admin_theme(array(
        'name' => 'Plus图标颜色',
        'id' => 'gallery_plus',
        'desc' => '',
        'not_empty' => 'true',
        'default' => 'ffffff'
    )),
    new ColorOption_admin_theme(array(
        'name' => '筛选和栏背景',
        'id' => 'filter_bg',
        'desc' => '',
        'not_empty' => 'true',
        'default' => '2a3033'
    )),
    new ColorOption_admin_theme(array(
        'name' => '均匀过滤背景',
        'id' => 'filter_even_bg',
        'desc' => '',
        'not_empty' => 'true',
        'default' => '343b3f'
    )),
    new textOption_admin_theme(array(
        'name' => '内容背景不透明度 (0 - 1)',
        'id' => 'content_bg_op',
        'not_empty' => true,
        'width' => '100px',
        'textalign' => 'center',
        'default' => '1'
    )),
	//Preloader
    new ColorOption_admin_theme(array(
        'name' => '预载页面背景',
        'id' => 'preloader_bg',
        'desc' => '',
        'not_empty' => 'true',
        'default' => '1e1e1e'
    )),
    new ColorOption_admin_theme(array(
        'name' => '预载文本颜色',
        'id' => 'preloader_text_color',
        'desc' => '',
        'not_empty' => 'true',
        'default' => 'f6f6f6'
    )),
    new ColorOption_admin_theme(array(
        'name' => '预载线背景',
        'id' => 'preloader_line_bg',
        'desc' => '',
        'not_empty' => 'true',
        'default' => '424c50'
    )),
    new ColorOption_admin_theme(array(
        'name' => '预载线颜色',
        'id' => 'preloader_line_color',
        'desc' => '',
        'not_empty' => 'true',
        'default' => '979797'
    )),
	
)));

?>