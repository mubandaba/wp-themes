<?php

#Frontend
if (!function_exists('css_js_register')) {
    function css_js_register()
    {
        $wp_upload_dir = wp_upload_dir();

        #CSS
        wp_enqueue_style('gt3_default_style', get_bloginfo('stylesheet_url'));
        wp_enqueue_style("gt3_theme", get_template_directory_uri() . '/css/theme.css');
        wp_enqueue_style("gt3_responsive", get_template_directory_uri() . '/css/responsive.css');
        if (gt3_get_theme_option("default_skin") == 'skin_light') {
            wp_enqueue_style('gt3_skin', get_template_directory_uri() . '/css/light.css');
        }
        wp_enqueue_style("gt3_custom", $wp_upload_dir['baseurl'] . "/" . "custom.css");

        #JS
        wp_enqueue_script("jquery");
		wp_enqueue_script('gt3_mousewheel_js', get_template_directory_uri() . '/js/jquery.mousewheel.js', array(), false, true);
		wp_enqueue_script('gt3_swipe_js', get_template_directory_uri() . '/js/jquery.event.swipe.js', array(), false, true);
        wp_enqueue_script('gt3_theme_js', get_template_directory_uri() . '/js/theme.js', array(), false, true);
    }
}
add_action('wp_enqueue_scripts', 'css_js_register');

/*#Additional files for plugin
include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
if (is_plugin_active('nextgen-gallery/nggallery.php')) {
    if (!function_exists('nextgen_files')) {
        function nextgen_files()
        {
            wp_enqueue_style("gt3_nextgen", get_template_directory_uri() . '/css/nextgen.css');
            wp_enqueue_script('gt3_nextgen_js', get_template_directory_uri() . '/js/nextgen.js', array(), false, true);
        }
    }
    add_action('wp_enqueue_scripts', 'nextgen_files');
}*/

#Admin
add_action('admin_enqueue_scripts', 'admin_css_js_register');
function admin_css_js_register()
{
    #CSS (MAIN)
    wp_enqueue_style('jquery-ui', get_template_directory_uri() . '/core/admin/css/jquery-ui.css');
    wp_enqueue_style('colorpicker_css', get_template_directory_uri() . '/core/admin/css/colorpicker.css');
    wp_enqueue_style('gallery_css', get_template_directory_uri() . '/core/admin/css/gallery.css');
    wp_enqueue_style('colorbox_css', get_template_directory_uri() . '/core/admin/css/colorbox.css');
    wp_enqueue_style('selectBox_css', get_template_directory_uri() . '/core/admin/css/jquery.selectBox.css');
    wp_enqueue_style('admin_css', get_template_directory_uri() . '/core/admin/css/admin.css');
    #CSS OTHER

    #JS (MAIN)
    wp_enqueue_script('admin_js', get_template_directory_uri() . '/core/admin/js/admin.js');
    wp_enqueue_script('ajaxupload_js', get_template_directory_uri() . '/core/admin/js/ajaxupload.js');
    wp_enqueue_script('colorpicker_js', get_template_directory_uri() . '/core/admin/js/colorpicker.js');
    wp_enqueue_script('selectBox_js', get_template_directory_uri() . '/core/admin/js/jquery.selectBox.js');
    wp_enqueue_script('backgroundPosition_js', get_template_directory_uri() . '/core/admin/js/jquery.backgroundPosition.js');
    wp_enqueue_script(array("jquery-ui-core", "jquery-ui-dialog", "jquery-ui-sortable"));
    wp_enqueue_media();
}

#Data for creating static css/js files.
$text_headers_font = gt3_get_theme_option("text_headers_font");

$main_menu_size = gt3_get_theme_option("menu_font_size");
$main_menu_height = substr(gt3_get_theme_option("menu_font_size"), 0, -2);
$main_menu_height = (int)$main_menu_height + 2;
$main_menu_height = $main_menu_height . "px";

$h1_font_size = gt3_get_theme_option("h1_font_size");
$h1_line_height = substr(gt3_get_theme_option("h1_font_size"), 0, -2);
$h1_line_height = (int)$h1_line_height + 2;
$h1_line_height = $h1_line_height . "px";

$h2_font_size = gt3_get_theme_option("h2_font_size");
$h2_line_height = substr(gt3_get_theme_option("h2_font_size"), 0, -2);
$h2_line_height = (int)$h2_line_height + 2;
$h2_line_height = $h2_line_height . "px";

$h3_font_size = gt3_get_theme_option("h3_font_size");
$h3_line_height = substr(gt3_get_theme_option("h3_font_size"), 0, -2);
$h3_line_height = (int)$h3_line_height + 2;
$h3_line_height = $h3_line_height . "px";

$h4_font_size = gt3_get_theme_option("h4_font_size");
$h4_line_height = substr(gt3_get_theme_option("h4_font_size"), 0, -2);
$h4_line_height = (int)$h4_line_height + 2;
$h4_line_height = $h4_line_height . "px";

$h5_font_size = gt3_get_theme_option("h5_font_size");
$h5_line_height = substr(gt3_get_theme_option("h5_font_size"), 0, -2);
$h5_line_height = (int)$h5_line_height + 2;
$h5_line_height = $h5_line_height . "px";

$h6_font_size = gt3_get_theme_option("h6_font_size");
$h6_line_height = substr(gt3_get_theme_option("h6_font_size"), 0, -2);
$h6_line_height = (int)$h6_line_height + 2;
$h6_line_height = $h6_line_height . "px";

$top_head = (int)gt3_get_theme_option("header_logo_standart_height")+40;
$top_head2 = (int)gt3_get_theme_option("header_logo_standart_height")+70;
$top_head_admin = (int)gt3_get_theme_option("header_logo_standart_height")+72;
$top_head_admin2 = (int)gt3_get_theme_option("header_logo_standart_height")+102;

$body_bg = gt3_get_theme_option("body_bg");
$header_bg = gt3_get_theme_option("header_bg");
$menu_bg = gt3_get_theme_option("menu_bg");
$menu_color = gt3_get_theme_option("menu_color");
$menu_active = gt3_get_theme_option("menu_active");
$content_bg = gt3_get_theme_option("content_bg");
$content_color = gt3_get_theme_option("content_color");
$content_highlight = gt3_get_theme_option("content_highlight");
$side_bg = gt3_get_theme_option("side_bg");
$heading_color = gt3_get_theme_option("heading_color");
$heading_hover = gt3_get_theme_option("heading_hover");
$input_bg = gt3_get_theme_option("input_bg");
$input_color = gt3_get_theme_option("input_color");
$input_active = gt3_get_theme_option("input_active");
$button_bg = gt3_get_theme_option("button_bg");
$button_color = gt3_get_theme_option("button_color");
$button_hover_color = gt3_get_theme_option("button_hover_color");
$button_hover_bg = gt3_get_theme_option("button_hover_bg");
$gallery_fade = gt3_get_theme_option("gallery_fade");
$gallery_plus = gt3_get_theme_option("gallery_plus");
$filter_bg = gt3_get_theme_option("filter_bg");
$filter_even_bg = gt3_get_theme_option("filter_even_bg");
$content_bg_op =  gt3_get_theme_option("content_bg_op");

$preloader_bg = gt3_get_theme_option("preloader_bg");
$preloader_text_color = gt3_get_theme_option("preloader_text_color");
$preloader_line_bg = gt3_get_theme_option("preloader_line_bg");
$preloader_line_color = gt3_get_theme_option("preloader_line_color");

$gt3_custom_css = new cssJsGenerator(
    $filename = "custom.css",
    $filetype = "css",
    $output = '
	/* SKIN COLORS */
	body,
	.leftSide_Container {
		background:#' . $body_bg . ';
	}
	.leftSide_Container .album_item_wrapper .album_item_fadder {
		background:rgba(' . gt3_HexToRGB($body_bg) . ', 0.4);
	}
	.leftSide_Container .album_item_wrapper:hover .album_item_fadder,
	.leftSide_Container .album_item_wrapper.active .album_item_fadder {
		background:rgba(' . gt3_HexToRGB($body_bg) . ', 0);
	}
	
	* {
		font-family:' . gt3_get_theme_option("main_font") . ';		
	}	
	p, td, div {
		color:#' . $content_color . ';
		font-weight:' . gt3_get_theme_option("content_weight") . ';	
	}
	.module_cont hr,
	.widget_calendar tfoot {
	    border-top: #'. $button_bg .' 1px solid;
	}
	table, th, td {
		border: #'. $button_bg .' 1px solid;
	}
	.module_cont hr.type1 {
		border-top: #' . $content_color . ' 1px solid;
	}
	.blog_post_preview {
		border-bottom:#'. $button_bg .' 1px solid;
	}
	.module_search .pagerblock li a {
		background:#'. $button_bg .';
	}
	.module_search .pagerblock li a.current {
		background:#'. $content_highlight .';
		color:#'. $content_bg .';
	}
	.module_cont hr.type2 {
		border-top: #' . $content_highlight . ' 1px solid;
	}
	.shortcode_iconbox p,
	.promoblock_wrapper h3,
	.dropcap.type1,
	.al_listing_content h3 {
		color:#' . $content_color . ';
	}
	h1, h2, h3, h4, h5, h6,
	h1 span, h2 span, h3 span, h4 span, h5 span, h6 span,
	h1 small, h2 small, h3 small, h4 small, h5 small, h6 small,
	h1 a, h2 a, h3 a, h4 a, h5 a, h6 a,
	.pseudo_stat_count,
	.promoblock_wrapper h2,
	.dropcap {
		color:#'. $heading_color .';
	}
	/*Fonts Families and Sizes*/
	p, td, div,
	input,
	textarea {
		font-family:' . gt3_get_theme_option("main_font") . ';
		font-weight:' . gt3_get_theme_option("content_weight") . ';
	}
	.recent_posts_content a {
		color:#' . $content_highlight . ';
	}
	a,
	.recent_posts_content a:hover {
		color:#' . $content_color . ';
		font-weight:' . gt3_get_theme_option("content_weight") . ';
	}
	a:hover,
	.shortcode_iconbox a:hover p,
	.content_highlight,
	.gallery_likes_add:hover,
	.comment-reply-link:after,
	.author_name,
	.author_name a,
	#mc_subheader {
		color:#' . $content_highlight . ';
	}
	.comment-reply-link:hover:after {
		color:#' . $content_color . ';
	}

	p, td, div,
	blockquote p,
	input,	
	input[type="text"],
	input[type="email"],
	input[type="password"],
	textarea {
		font-size:' . gt3_get_theme_option("main_content_font_size") . ';
		line-height:' . gt3_get_theme_option("main_content_line_height") . ';
	}
	.widget_tag_cloud a {
		font-size:' . gt3_get_theme_option("main_content_font_size") . '!important;
		line-height:' . gt3_get_theme_option("main_content_line_height") . '!important;	
	}
	h1, h2, h3, h4, h5, h6,
	h1 span, h2 span, h3 span, h4 span, h5 span, h6 span,
	h1 small, h2 small, h3 small, h4 small, h5 small, h6 small,
	h1 a, h2 a, h3 a, h4 a, h5 a, h6 a,
	h1 a:hover, h2 a:hover, h3 a:hover, h4 a:hover, h5 a:hover, h6 a:hover,
	.pseudo_stat_count,
	.dropcap {
		font-family: ' . $text_headers_font . ';
		font-weight:' . gt3_get_theme_option("headings_weight") . ';
		-moz-osx-font-smoothing:grayscale;
		-webkit-font-smoothing:antialiased;
		padding:0;
	}
	h3.headInModule,
	.al_listing_content h3,
	.sidebar_header {
		font-weight:' . gt3_get_theme_option("headings_weight") . ';
	}
	h1, h1 span, h1 a, h3.promo_title {
		font-size:' . $h1_font_size . ';
		line-height:' . $h1_line_height . ';
	}
	h2, h2 span, h2 a, .pseudo_stat_count {
		font-size:' . $h2_font_size . ';
		line-height:' . $h2_line_height . ';
	}
	.bg_title h2 {
		font-size:' . $h1_font_size . ';
		line-height:' . $h1_line_height . ';	
	}
	h3, h3 span, h3 a, h3 a:hover {
		font-size:' . $h3_font_size . ';
		line-height:' . $h3_line_height . ';
		font-weight:400;
	}
	h4, h4 span, h4 a {
		font-size:' . $h4_font_size . ';
		line-height:' . $h4_line_height . ';
	}
	h5, h5 span, h5 a {
		font-size:' . $h5_font_size . ';
		line-height:' . $h5_line_height . ';
	}
	h6, h6 span, h6 a,
	.comment_info h6:after {
		font-size:' . $h6_font_size . ';
		line-height:' . $h6_line_height . ';
	}
	h1.side_title {
		font-size:' . $h3_font_size . ';
		line-height:' . $h3_line_height . ';
	}
	.fullview header.main_header {
		top:-'. $top_head .'px;
	}
	
    /* CSS HERE */
	::selection {background:#' . $content_color . '!important; color:#'.$content_highlight.'}
	::-moz-selection {background:#' . $content_highlight . '!important; color:#'.$content_color.'}

	input[type="text"],
	input[type="email"],
	input[type="password"],
	textarea {
		background:#'. $input_bg .';
		color:#'. $input_color .';
		-moz-osx-font-smoothing: grayscale;		
		-webkit-font-smoothing: antialiased;
	}
	input[type="text"]:focus,
	input[type="email"]:focus,
	input[type="password"]:focus,
	textarea:focus,
	.widget_search .search_form:before {
		color:#'. $input_active .';
	}
	input[type="text"]::-webkit-input-placeholder,
	input[type="email"]::-webkit-input-placeholder,
	input[type="password"]::-webkit-input-placeholder,
	textarea::-webkit-input-placeholder {
		color: #'. $input_color .';
		-webkit-font-smoothing: antialiased;
	}
	textarea::-moz-placeholder {
		color: #'. $input_color .';
		opacity: 1;
		-moz-osx-font-smoothing: grayscale;
	}
	input[type="text"]::-moz-placeholder {
		color: #'. $input_color .';
		opacity: 1;
		-moz-osx-font-smoothing: grayscale;
	}
	input[type="email"]::-moz-placeholder {
		color: #'. $input_color .';
		opacity: 1;
		-moz-osx-font-smoothing: grayscale;
	}
	input[type="password"]::-moz-placeholder {
		color: #'. $input_color .';
		opacity: 1;
		-moz-osx-font-smoothing: grayscale;
	}	
	input[type="text"]:-ms-input-placeholder,
	input[type="email"]:-ms-input-placeholder,
	input[type="password"]:-ms-input-placeholder,
	textarea:-ms-input-placeholder {
		color: #'. $input_color .';
	}
	input[type="button"],
	input[type="reset"],
	input[type="submit"],
	.widget_tag_cloud a {
		color:#'. $button_color .';
		background:#'. $button_bg .';
	}
	input[type="button"]:hover,
	input[type="reset"]:hover,
	input[type="submit"]:hover,
	.widget_tag_cloud a:hover {
		color:#'. $button_hover_color .';
		background:#'. $button_hover_bg .';
	}
	
	header.main_header {
		background:#'. $header_bg .';
	}
	nav.main_nav ul.menu,
	nav.main_nav ul.sub-menu,
	nav.main_nav:before,
	ul.mobile_menu,
	.main_nav > div.menu ul {
		background:#'. $menu_bg .';
	}
	nav.main_nav:before {
		/*box-shadow:0 10px 5px #'. $menu_bg .';*/
	}
	
	ul.mobile_menu li a,
	nav.main_nav ul.menu li a {
		color:#'. $menu_color .';
		font-weight: '. gt3_get_theme_option("menu_weight").';
		display:block;
		font-size: '. $main_menu_size .';
		line-height: '. $main_menu_height.';
	}
	ul.mobile_menu li a span i,
	ul.mobile_menu li a span,
	nav.main_nav ul.mobile_menu li a span i,
	nav.main_nav ul.mobile_menu li a span {
		font-size: '. $main_menu_size .';
		line-height: '. $main_menu_height.';	
	}

	ul.mobile_menu li:hover > a,
	ul.mobile_menu li.current-menu-ancestor > a,
	ul.mobile_menu li.current-menu-item > a,
	ul.mobile_menu li.current-menu-parent > a,
	nav.main_nav ul li:hover > a,
	nav.main_nav ul li.current-menu-ancestor > a,
	nav.main_nav ul li.current-menu-item > a,
	nav.main_nav ul li.current-menu-parent > a {
		color:#'. $menu_active .';
	}

	
	#dm_fullscreen .dm_list li,
	#dm_fullscreen {
		background:#'. $content_bg .';
	}
	.justBG {
		background:#'. $content_bg .'!important;
	}
	.fs_gallery_container,
	#ajax_slider,
	#ajax_slider li {
		background-color:#'. $content_bg .';
	}
	#dm_fullscreen .dm_list li,
	#dm_fullscreen {
		color:#'. $content_bg .';
	}
	.flickr_widget_wrapper .flickr_badge_image a:before {
		background:rgba(' . gt3_HexToRGB($content_bg) . ',0);
	}
	.flickr_widget_wrapper:hover .flickr_badge_image a:before {
		background:rgba(' . gt3_HexToRGB($content_bg) . ',0.7);
	}
	.flickr_widget_wrapper:hover .flickr_badge_image a:hover:before {
		background:rgba(' . gt3_HexToRGB($content_bg) . ',0);
	}
	
	blockquote:before,
	blockquote.shortcode_blockquote .author,
	.team_desc,
	a.teamlink:hover i,
	.text404,
	.pp_notify,
	.dm_span_close,
	.dm_span_info,
	span.fs_span_prev,
	span.fs_span_info,
	span.fs_span_like,
	span.fs_span_next,	
	.count_title h1,
	.count_ico i,
	.countdown-amount,
	.countdown-period,
	.strip-title,
	.side_meta span,
	.side_meta i,
	#ribbon_status .share_text,
	#ribbon_status .share_wrapper a,
	#ribbon_status .side_meta_item,
	#ribbon_status .side_meta_item span,
	#ribbon_status .status_left,
	#ribbon_status .status_middle,
	#ribbon_status .status_middle span,
	.widget_calendar caption,
	.widget_calendar th,
	.page-link {
		color:#'. $content_highlight .';
	}
	a.shortcode_social_icon:hover i,
	.gallery_filter li a:hover,
	.gallery_filter li a.current,
	.gallery_filter li.selected a {
		color:#'. $content_highlight .'!important;
	}
	a.shortcode_social_icon:hover,
	.count_ico {
		border-color:#'. $content_highlight .'!important;
	}	
	blockquote.type1:before,
	.featured_items_title a:hover,
	.fs_blog_title a:hover,
	.gallery_filter li a,
	.strip-caption,
	.page-link span {
		color:#'. $content_color .';
	}
	.site_wrapper,
	.vs_page {
		background:rgba(' . gt3_HexToRGB($content_bg) . ','.$content_bg_op.');	
	}
	.img_block {
		background-color:#'. $gallery_fade .';
	}
	.img_block .featured_item_fadder,
	.gallery_item_wrapper .gallery_fadder,
	.grid-gallery-item .gallery_fadder,
	.fs_img_block .fs_blog_fadder,
	.strip-item .strip-fadder,
	.hStrip-item .hStrip-fadder,
	.album_item_wrapper .img_block .albums_fadder,
	.ribbon_slide.currentStep .slide_fadder {
		background:rgba(' . gt3_HexToRGB($gallery_fade) . ',0);
	}
	.img_block:hover .featured_item_fadder,
	.gallery_item_wrapper:hover .gallery_fadder,
	.grid-gallery-item:hover .gallery_fadder,
	.fs_img_block:hover .fs_blog_fadder,
	.strip-item:hover .strip-fadder,
	.strip-item.touchHover .strip-fadder,
	.hStrip-item:hover .hStrip-fadder,
	.album_item_wrapper .img_block:hover .albums_fadder,
	.ribbon_slide .slide_fadder {
		background:rgba(' . gt3_HexToRGB($gallery_fade) . ',0.9);
	}
	@media only screen and (max-width: 760px) {	
		.strip-item .strip-fadder,
		.hStrip-item .hStrip-text {
			background:rgba(' . gt3_HexToRGB($gallery_fade) . ',0.9);
		}		
	}
	.ribbon_list,
	.ribbon_list .ribbon_slide,
	.ribbon_main_wrapper,
	#cols_wrapper {
		background:#'. $gallery_fade .'; 
	}
	.featured_items .img_block span,
	.gallery_item_wrapper span.featured_items_ico,
	.fs_img_block .fs_blog_icon,
	span.gal_plus_ico,
	.album_item_wrapper .img_block span.gal_plus_ico {
		border-color:#'. $gallery_plus .';
	}
	.featured_items .img_block span:before,
	.featured_items .img_block span:after,
	.gallery_item_wrapper span.featured_items_ico:before,
	.gallery_item_wrapper span.featured_items_ico:after,
	.fs_img_block .fs_blog_icon:before,
	.fs_img_block .fs_blog_icon:after,
	.gal_plus_ico:before,
	.gal_plus_ico:after {
		background:#'. $gallery_plus .';
	}
	.fs_content_box,
	.fs_content_bg {
		background:#'. $side_bg .';
	}
	.gallery_filter,
	#ribbon_status,
	div.filter_label {
		background:#'. $filter_bg .';
	}
	div.filter_label.even,
	.load_more_works {
		background:#'. $filter_even_bg .';
	}
	
	/* PRELOADER */
	.preloader,
	.fs_bg {
		background:#'. $preloader_bg .';
	}
	.preloader span {
		color:#'. $preloader_text_color .';
	}		
	.preloader_line {
		background:#'. $preloader_line_bg .';
	}	
	.preloader_line_bar1,
	.preloader_line_bar2 {
		background:#'. $preloader_line_color .';
	}
	
	/*Header Size*/	
	.strip-menu,
	.strip-horizontal,
	.fw_grid_gallery {
		padding-top: '. $top_head .'px;
	}
	.fullscreen_blog,
	.gallery_albums {
		padding-top: '. $top_head2 .'px;
	}

	.admin-bar .fw_grid_gallery,
	.admin-bar .strip-horizontal {
		padding-top: '. $top_head_admin .'px;
	}	
	.admin-bar .gallery_albums,
	.admin-bar .fullscreen_blog {
		padding-top: '. $top_head_admin2 .'px;
	}
    '
);
?>