<?php

#Upload images
add_action('wp_ajax_mix_ajax_post_action', 'mix_theme_upload_images');
function mix_theme_upload_images()
{
    if (is_admin()) {
        $save_type = $_POST['type'];

        if ($save_type == 'upload') {

            $clickedID = esc_attr($_POST['data']);
            $filename = $_FILES[$clickedID];
            $filename['name'] = preg_replace('/[^a-zA-Z0-9._\-]/', '', $filename['name']);

            $override['test_form'] = false;
            $override['action'] = 'wp_handle_upload';
            $uploaded_file = wp_handle_upload($filename, $override);
            $upload_tracking[] = $clickedID;
            gt3_update_theme_option($clickedID, $uploaded_file['url']);
            if (!empty($uploaded_file['error'])) {
                echo 'Upload Error: ' . $uploaded_file['error'];
            } else {
                echo esc_url($uploaded_file['url']);
            }
        }
    }

    die();
}

#Upload images
add_action('wp_ajax_gt3_get_blog_posts', 'gt3_get_blog_posts');
add_action('wp_ajax_nopriv_gt3_get_blog_posts', 'gt3_get_blog_posts');
function gt3_get_blog_posts()
{
    $setPad = esc_attr($_REQUEST['set_pad']);
    if ($_REQUEST['template_name'] == "fw_blog_template") {
        $wp_query_get_blog_posts = new WP_Query();
        $args = array(
            'post_type' => esc_attr($_REQUEST['post_type']),
            'offset' => absint($_REQUEST['posts_already_showed']),
            'post_status' => 'publish',
            'cat' => esc_attr($_REQUEST['categories']),
            'posts_per_page' => absint($_REQUEST['posts_count'])
        );
        $wp_query_get_blog_posts->query($args);
        while ($wp_query_get_blog_posts->have_posts()) : $wp_query_get_blog_posts->the_post();
            $all_likes = gt3pb_get_option("likes");
            $gt3_theme_pagebuilder = get_post_meta(get_the_ID(), "pagebuilder", true);

            if (get_the_category()) $categories = get_the_category();
            $post_categ = '';
            $separator = ', ';
            if ($categories) {
                foreach ($categories as $category) {
                    $post_categ = $post_categ . '<a href="' . get_category_link($category->term_id) . '">' . $category->cat_name . '</a>' . $separator;
                }
            }

            ?>
            <div <?php post_class("blogpost_preview_fw newLoaded anim_el loading"); ?>>
                <div class="fw_preview_wrapper featured_items">
                    <div class="fs_img_block wrapped_img">
                        <?php if (get_post_format() !== 'video' && get_post_format() !== 'audio') {
                            echo '<a href="'. get_permalink() .'"></a>';
                        } ?>
                        <?php echo get_pf_type_output(array("pf" => get_post_format(), "gt3_theme_pagebuilder" => $gt3_theme_pagebuilder, "width" => '585', "height" => '', "fw_post" => true)); ?>
                    </div>
                    <div class="fs_content_box">
                        <h3 class="fs_blog_title"><a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a></h3>
                        <div class="fs_blog_content">
                        <?php 
                            $post = get_post();
                            $post_excerpt = ((strlen($post->post_excerpt) > 0) ? smarty_modifier_truncate($post->post_excerpt, 80, "") : smarty_modifier_truncate(get_the_content(), 80, ""));
                            echo $post_excerpt;
                        ?>
                        </div>
                        <div class="featured_items_meta">
                            <span class="preview_meta_data"><i class="icon-calendar"></i><?php echo get_the_time("F d, Y") ?></span>
                            <span><?php echo trim($post_categ, ', ') ?></span>
                            <span><i class="icon-comments"></i><a href="<?php echo get_comments_link() ?>"><?php echo get_comments_number(get_the_ID()); _e(' comments', 'theme_localization') ?></a></span>
                        </div>
                    </div>
                </div>
            </div>
        <?php endwhile;
    }
    die();
}

#Get last slide ID
add_action('wp_ajax_get_unused_id_ajax', 'get_unused_id_ajax');
if (!function_exists('get_unused_id_ajax')) {
    function get_unused_id_ajax()
    {
        $lastid = gt3_get_theme_option("last_slide_id");
        if ($lastid < 3) {
            $lastid = 2;
        }
        $lastid++;

        $mystring = home_url();
        $findme = 'gt3themes';
        $pos = strpos($mystring, $findme);

        if ($pos === false) {
            echo $lastid;
        } else {
            echo str_replace(array("/", "-", "_"), "", substr(wp_get_theme()->get('ThemeURI'), -4, 3)) . date("d") . date("m") . $lastid;
        }

        gt3_update_theme_option("last_slide_id", $lastid);

        die();
    }
}


add_action('wp_ajax_add_like_post', 'gt3_add_like_post');
add_action('wp_ajax_nopriv_add_like_post', 'gt3_add_like_post');
function gt3_add_like_post()
{
    $post_id = absint($_POST['post_id']);
    $post_likes = (get_post_meta($post_id, "post_likes", true) > 0 ? get_post_meta($post_id, "post_likes", true) : "0");
    $new_likes = absint($post_likes) + 1;
    update_post_meta($post_id, "post_likes", $new_likes);
    echo $new_likes;
    die();
}

#Load portfolio works
add_action('wp_ajax_get_portfolio_works', 'get_portfolio_works');
add_action('wp_ajax_nopriv_get_portfolio_works', 'get_portfolio_works');
if (!function_exists('get_portfolio_works')) {
    function get_portfolio_works() {	
	    $setPad = esc_attr($_REQUEST['set_pad']);	
		
        $html_template = esc_attr($_POST['template_name']);
        $now_open_works = absint($_POST['posts_already_showed']);
        $works_per_load = absint($_POST['posts_count']);
        $category = esc_attr($_POST['categories']);
		$post_type_field = esc_attr($_POST['post_type_field']);
        $wp_query = new WP_Query();
        $args = array(
            'post_type' => 'port',
            'order' => 'DESC',
            'post_status' => 'publish',
            'offset' => $now_open_works,
            'posts_per_page' => $works_per_load,
        );

        if (strlen($category) > 0) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'portcat',
                    'field' => $post_type_field,
                    'terms' => ($post_type_field == "slug" ? $category : explode(",", $category) )
                )
            );
        }

        $wp_query->query($args);
        //$i = 1;
		
        while ($wp_query->have_posts()) : $wp_query->the_post();
            $pf = get_post_format();
            if (empty($pf)) $pf = "text";
            $pagebuilder = gt3_get_theme_pagebuilder(get_the_ID());

            $featured_image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_id()), 'single-post-thumbnail');
            if (strlen($featured_image[0]) < 1) {
                $featured_image[0] = IMGURL . "/core/your_image_goes_here.jpg";
            }

            if (isset($pagebuilder['settings']['external_link']) && strlen($pagebuilder['settings']['external_link']) > 0) {
                $linkToTheWork = $pagebuilder['settings']['external_link'];
                $target = "target='_blank'";
            } else {
                $linkToTheWork = get_permalink();
                $target = "";
            }

            if (isset($pagebuilder['settings']['time_spent']) && strlen($pagebuilder['settings']['time_spent']) > 0) {
                $time_spent_value = $pagebuilder['settings']['time_spent'];
                $time_spent_html = '<div class="portfolio_descr_time">' . ((get_theme_option("translator_status") == "enable") ? get_text("translator_time_spent") : __('Time spent', 'theme_localization')) . ': <span>' . $time_spent_value . '</span></div>';
            } else {
                $time_spent_value = '';
                $time_spent_html = '';
            }

            if (!isset($echoallterm)) {
                $echoallterm = '';
            }
            $new_term_list = get_the_terms(get_the_id(), "portcat");
            if (is_array($new_term_list)) {
                foreach ($new_term_list as $term) {
                    $tempname = strtr($term->name, array(
                        ' ' => '-',
                    ));
                    $echoallterm .= strtolower($tempname) . " ";
                    $echoterm = $term->name;
                }
            }

            #Portfolio grid
            $all_likes = gt3pb_get_option("likes");
            $gt3_theme_post = get_plugin_pagebuilder(get_the_ID());
            $featured_image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'single-post-thumbnail');
            $pf = get_post_format();
            $target = (isset($gt3_theme_post['settings']['new_window']) && $gt3_theme_post['settings']['new_window'] == "on" ? "target='_blank'" : "");
            if (isset($gt3_theme_post['page_settings']['portfolio']['work_link']) && strlen($gt3_theme_post['page_settings']['portfolio']['work_link']) > 0) {
                $linkToTheWork = esc_url($gt3_theme_post['page_settings']['portfolio']['work_link']);
            } else {
                $linkToTheWork = get_permalink();
            }
            $echoallterm = '';
			$portCateg = '';
            $new_term_list = get_the_terms(get_the_id(), "portcat");
            if (is_array($new_term_list)) {
                foreach ($new_term_list as $term) {
                    $tempname = strtr($term->name, array(
                        ' ' => ', ',
                    ));
                    $echoallterm .= strtolower($tempname) . " ";
                    $echoterm = $term->name;
					$portCateg .= $term->name . ", ";
                }
				$portCateg = substr($portCateg, 0, -2);
            } else {
                $tempname = 'Uncategorized';
				$portCateg = 'Uncategorized';
            }
			$photoTitle = get_the_title();
            			
		    if ($_REQUEST['template_name'] == "port_masonry_isotope") { ?>
                <div <?php post_class("fw_grid_item loading anim_el newLoaded element " . $echoallterm); ?>
                    data-category="<?php echo $echoallterm ?>">
					<div class="fw_grid_content" style="margin-bottom:<?php echo $setPad; ?>; margin-right:<?php echo $setPad; ?>;">
                        <div class="img_block wrapped_img fs_port_item gallery_item_wrapper">
							<a href="<?php echo $linkToTheWork; ?>" target="<?php echo $target; ?>"></a>
                            <img width="960" class="img2preload" height="960" src="<?php echo aq_resize($featured_image[0], "540", "", true, true, true) ?>" alt="<?php echo esc_attr($photoTitle); ?>" />
                            <div class="gallery_fadder"></div>
                            <div class="gal_content">
                            	<?php if (strlen(trim($photoTitle)) > 0) {
	                            	echo "<h3>" . $photoTitle . "</h3>";
                                } ?>
	                            <span class="gal_plus_ico"></span>
                            </div>
                        </div>                    
                    </div>
                </div>      
			<?php }

		    if ($_REQUEST['template_name'] == "port_masonry_template") { ?>
            <div <?php post_class("fw_grid_item newLoaded loading anim_el"); ?>>
                <div class="fw_grid_content" style="margin-bottom:<?php echo $setPad; ?>; margin-right:<?php echo $setPad; ?>;">
                    <div class="img_block wrapped_img fs_port_item gallery_item_wrapper">
                        <a href="<?php echo $linkToTheWork; ?>" target="<?php echo $target; ?>"></a>
                        <img width="960" class="img2preload" height="960" src="<?php echo aq_resize($featured_image[0], "540", "", true, true, true) ?>" alt="<?php echo esc_attr($photoTitle); ?>" />
                        <div class="gallery_fadder"></div>
                        <div class="gal_content">
                            <?php if (strlen(trim($photoTitle)) > 0) {
                                echo "<h3>" . $photoTitle . "</h3>";
                            } ?>
                            <span class="gal_plus_ico"></span>
                        </div>
                    </div>                    
                </div>
            </div>      
            <?php 
			}
			/* G R I D   P O R T F O L I O */
			/* PORTFOLIO ISOTOPE */
			if ($_REQUEST['template_name'] == "port_grid_isotope") { ?>
				<div <?php post_class("fw_grid_item loading anim_el newLoaded element " . $echoallterm); ?> 
					data-category="<?php echo $echoallterm ?>">
					<div class="fw_grid_content" style="margin-bottom:<?php echo $setPad; ?>; margin-right:<?php echo $setPad; ?>;">
                        <div class="img_block wrapped_img fs_port_item gallery_item_wrapper">
							<a href="<?php echo $linkToTheWork; ?>" target="<?php echo $target; ?>"></a>
                            <img width="960" class="img2preload" height="960" src="<?php echo aq_resize($featured_image[0], "540", "540", true, true, true) ?>" alt="<?php echo esc_attr($photoTitle); ?>" />
                            <div class="gallery_fadder"></div>
                            <div class="gal_content">
                            	<?php if (strlen(trim($photoTitle)) > 0) {
	                            	echo "<h3>" . $photoTitle . "</h3>";
                                } ?>
	                            <span class="gal_plus_ico"></span>
                            </div>
                        </div>                    
                    </div>
                </div>      
			<?php }
		    if ($_REQUEST['template_name'] == "port_grid_template") { ?>
                <div <?php post_class("fw_grid_item newLoaded loading anim_el"); ?>>
					<div class="fw_grid_content" style="margin-bottom:<?php echo $setPad; ?>; margin-right:<?php echo $setPad; ?>;">
                        <div class="img_block wrapped_img fs_port_item gallery_item_wrapper">
							<a href="<?php echo $linkToTheWork; ?>" target="<?php echo $target; ?>"></a>
                            <img width="960" class="img2preload" height="960" src="<?php echo aq_resize($featured_image[0], "540", "540", true, true, true) ?>" alt="<?php echo esc_attr($photoTitle); ?>" />
                            <div class="gallery_fadder"></div>
                            <div class="gal_content">
                            	<?php if (strlen(trim($photoTitle)) > 0) {
	                            	echo "<h3>" . $photoTitle . "</h3>";
                                } ?>
	                            <span class="gal_plus_ico"></span>
                            </div>
                        </div>                    
                    </div>
                </div>      
			<?php }
			
			
            #END

            //$i++;
            //unset($echoallterm, $pf);
        endwhile;

        die();
    }
}

#Load gallery works
add_action('wp_ajax_get_gallery_works', 'get_gallery_works');
add_action('wp_ajax_nopriv_get_gallery_works', 'get_gallery_works');
if (!function_exists('get_gallery_works')) {
    function get_gallery_works() {	
		$sliderCompile = "";
        $openID = absint($_POST['current_id']);
		$pagebuilder = gt3_get_theme_pagebuilder($openID);
		if (isset($pagebuilder['sliders']['fullscreen']['fit_style']) && $pagebuilder['sliders']['fullscreen']['fit_style'] !== 'default') {
			$fit_style = $pagebuilder['sliders']['fullscreen']['fit_style'];
		} else {
			$fit_style = gt3_get_theme_option("default_fit_style");
		}
		?>
        <script>
			<?php if (isset($pagebuilder['sliders']['fullscreen']['slides']) && is_array($pagebuilder['sliders']['fullscreen']['slides'])) { ?>
			var	gallery_status = "ok",
			show_title = "<?php echo $pagebuilder['settings']['show_title']; ?>",
			setID = <?php echo $openID; ?>,
			show_content_area = "<?php echo $pagebuilder['settings']['show_content_area']; ?>",
			fit_style = "<?php echo $fit_style; ?>",
			
			<?php
				$sliderCompile .= 'new_gallery_set = [';
				foreach ($pagebuilder['sliders']['fullscreen']['slides'] as $imageid => $image) {
					$uniqid = mt_rand(0, 9999);
					if (isset($image['title']['value']) && strlen($image['title']['value'])>0) {$photoTitle = $image['title']['value'];} else {$photoTitle = "";}
					if (isset($image['caption']['value']) && strlen($image['caption']['value'])>0) {$photoCaption  = $image['caption']['value'];} else {$photoCaption = "";}
					$titleColor = "f6f6f6";
					$captionColor = "979797";
					if ($image['slide_type'] == 'image') {
						$sliderCompile .= '{type: "image", image: "' . wp_get_attachment_url($image['attach_id']) . '", thmb: "'.aq_resize(wp_get_attachment_url($image['attach_id']), "130", "130", true, true, true).'", alt: "' . str_replace('"', "'",  $photoTitle) . '", title: "' . str_replace('"', "'", $photoTitle) . '", description: "' . str_replace('"', "'",  $photoCaption) . '", titleColor: "#'.$titleColor.'", descriptionColor: "#'.$captionColor.'"},';
					} else if ($image['slide_type'] == 'video') {
						#YOUTUBE
						$is_youtube = substr_count($image['src'], "youtu");				
						if ($is_youtube > 0) {
							$videoid = substr(strstr($image['src'], "="), 1);					
							$thmb = "http://img.youtube.com/vi/".$videoid."/0.jpg";
							$sliderCompile .= '{type: "youtube", uniqid: "' . $uniqid . '", src: "' . $videoid . '", thmb: "'.$thmb.'", alt: "' . str_replace('"', "'",  $photoTitle) . '", title: "' . str_replace('"', "'", $photoTitle) . '", description: "' . str_replace('"', "'",  $photoCaption) . '", titleColor: "#'.$titleColor.'", descriptionColor: "#'.$captionColor.'"},';
						}
						#VIMEO
						$is_vimeo = substr_count($image['src'], "vimeo");				
						if ($is_vimeo > 0) {
							$videoid = substr(strstr($image['src'], "m/"), 2);
							$thmbArray = json_decode(file_get_contents("http://vimeo.com/api/v2/video/".$videoid.".json"));
							if (!empty($thmbArray))
							$thmb = $thmbArray[0]->thumbnail_large;
							$sliderCompile .= '{type: "vimeo", uniqid: "' . $uniqid . '", src: "' . $videoid . '", thmb: "'.$thmb.'", alt: "' . str_replace('"', "'",  $photoTitle) . '", title: "' . str_replace('"', "'", $photoTitle) . '", description: "' . str_replace('"', "'",  $photoCaption) . '", titleColor: "#'.$titleColor.'", descriptionColor: "#'.$captionColor.'"},';
						}				
					}
				}
				$sliderCompile .= "]";
				echo $sliderCompile;
			?>										
			<?php } else { ?>
				//No Gallery Images Found
				var	gallery_status = "error";
			<?php } ?>
		</script>
		<?php
        die();
    }
}

#Ajax import xml
add_action('wp_ajax_ajax_import_dump', 'ajax_import_dump');
if (!function_exists('ajax_import_dump')) {
    function ajax_import_dump()
    {
        if (is_admin()) {
            if (!defined('WP_LOAD_IMPORTERS')) {
                define('WP_LOAD_IMPORTERS', true);
            }

            require_once(TEMPLATEPATH . '/core/xml-importer/importer.php');

            try {
                ob_start();
                $importer = new WP_Import();
                $importer->import(TEMPLATEPATH . '/core/xml-importer/import.xml');
                ob_clean();
            } catch (Exception $e) {
                die(json_encode(array(
                    'message' => $e->getMessage()
                )));
            }
            die(json_encode(array(
                'message' => 'Data was imported successfully'
            )));
        }
    }
}

?>