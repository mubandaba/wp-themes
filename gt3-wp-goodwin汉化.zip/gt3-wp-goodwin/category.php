<?php get_header('fullscreen');
wp_enqueue_script('gt3_masonry_js', get_template_directory_uri() . '/js/masonry.min.js', array(), false, true);
wp_enqueue_script('gt3_cookie_js', get_template_directory_uri() . '/js/jquery.cookie.js', array(), false, true);

#Emulate default settings for page without personal ID
$gt3_theme_pagebuilder = gt3_get_default_pb_settings();
$gt3_current_page_sidebar = $gt3_theme_pagebuilder['settings']['layout-sidebars'];
if ($gt3_theme_pagebuilder['settings']['layout-sidebars'] == "right-sidebar" || $gt3_theme_pagebuilder['settings']['layout-sidebars'] == "left-sidebar") {
	echo '<div class="bg_sidebar is_'. $gt3_theme_pagebuilder['settings']['layout-sidebars'] .'"></div>';
}
?>
<div class="fullscreen_blog fadeOnLoad">
    <div class="fs_blog_module is_masonry this_is_blog">
        <?php 
        while (have_posts()) : the_post();
            get_template_part("bloglisting");
        endwhile;?>
    </div>
</div>
<?php gt3_get_theme_pagination(); ?>

<script>
	jQuery(window).resize(function () {
		jQuery('.is_masonry').masonry();
		iframe16x9(jQuery('.fs_blog_module'));
	});
	jQuery(window).load(function () {
		jQuery('.is_masonry').masonry();
		iframe16x9(jQuery('.fs_blog_module'));
	});
	jQuery(document).ready(function($){
		if (jQuery('.pagerblock').size() > 0) {
			jQuery('.fullscreen_blog').addClass('has_filter');
			jQuery('.pagerblock').addClass('gallery_filter').removeClass('pagerblock ');
		}		
		iframe16x9(jQuery('.fs_blog_module'));
		jQuery('.custom_bg').remove();
		jQuery('.is_masonry').masonry();
		setTimeout("jQuery('.is_masonry').masonry();",1000);
		setTimeout("jQuery('.is_masonry').masonry();",2000);			

		jQuery('.gallery_likes_add').bind('click',function(){
			var gallery_likes_this = jQuery(this);
			if (!jQuery.cookie(gallery_likes_this.attr('data-modify')+gallery_likes_this.attr('data-attachid'))) {
				jQuery.post(gt3_ajaxurl, {
					action:'add_like_attachment',
					attach_id:jQuery(this).attr('data-attachid')
				}, function (response) {
					jQuery.cookie(gallery_likes_this.attr('data-modify')+gallery_likes_this.attr('data-attachid'), 'true', { expires: 7, path: '/' });
					gallery_likes_this.addClass('already_liked');
					gallery_likes_this.find('i').removeClass('icon-heart-o').addClass('icon-heart');
					gallery_likes_this.find('span').text(response);
				});
			}
		});
		jQuery('.nivoSlider').each(function(){
			jQuery(this).nivoSlider({
				directionNav: false,
				controlNav: true,
				effect:'fade',
				pauseTime:4000,
				slices: 1
			});
		});			
	});
	function iframe16x9fb(container) {
		container.find('iframe').each(function(){
			jQuery(this).height((jQuery(this).width()/16)*9);
		});
	}		
</script>

<div class="preloader">
    <div class="preloader_content">
        <span><?php echo gt3_get_theme_option("preloader_text"); ?></span>
        <div class="preloader_line">
            <div class="preloader_line_bar1"></div>
            <div class="preloader_line_bar2"></div>
        </div>
    </div>
</div>

<?php get_footer('fullscreen'); ?>