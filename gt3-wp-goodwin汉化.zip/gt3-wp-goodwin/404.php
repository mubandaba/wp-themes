<?php get_header('fullscreen');?>
    <div class="wrapper404 unloaded">
        <div class="container404">
        	<h1 class="title404"><?php echo __('Oops! 404 Error!', 'theme_localization'); ?></span></h1>
            <div class="text404"><?php echo __('Apologies, but we were unable to find what you were looking for.', 'theme_localization'); ?></div>
            <form name="search_field" method="get" action="<?php echo home_url(); ?>" class="search_form search404">
                <input type="text" name="s" value="" class="field_search" placeholder="<?php _e('Search', 'theme_localization'); ?>">
                <a href="<?php echo esc_js("javascript:document.search_field.submit()");?>" class="search_button"><?php _e('Search', 'theme_localization'); ?></a>
            </form>
            <div class="clear"></div>
        </div>        
    </div>
    <script>
		var wrapper404 = jQuery('.wrapper404');
		jQuery(document).ready(function(){
			centerWindow();
			setTimeout('wrapper404.removeClass("unloaded")',350);
		});
		jQuery(window).load(function(){
			centerWindow();
		});
		jQuery(window).resize(function(){
			setTimeout('centerWindow()',500);
			setTimeout('centerWindow()',1000);			
		});
		function centerWindow() {
			set404Top = -1*(wrapper404.height()/2 - jQuery('header').height()/2);
			wrapper404.css('margin-top', set404Top +'px');
		}
	</script>
<?php get_footer('fullscreen'); ?>