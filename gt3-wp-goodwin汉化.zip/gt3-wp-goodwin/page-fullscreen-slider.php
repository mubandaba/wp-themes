<?php 
/*
Template Name: Fullscreen Slider
*/
if ( !post_password_required() ) {
get_header('fullscreen');
the_post();

$gt3_theme_pagebuilder = gt3_get_theme_pagebuilder(get_the_ID());
$featured_image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'single-post-thumbnail');
$pf = get_post_format();			
	wp_enqueue_script('gt3_fsGallery_js', get_template_directory_uri() . '/js/fs_gallery.js', array(), false, true);
	
?>
	<?php 
        $sliderCompile = "";
	if (isset($gt3_theme_pagebuilder['sliders']['fullscreen']['slides']) && is_array($gt3_theme_pagebuilder['sliders']['fullscreen']['slides'])) {
		if (isset($gt3_theme_pagebuilder['sliders']['fullscreen']['thumbnails']) && $gt3_theme_pagebuilder['sliders']['fullscreen']['thumbnails'] == "off") {
			$thumbs_state = $gt3_theme_pagebuilder['sliders']['fullscreen']['thumbnails'];
			$thmb_class = 'pag-hided';
			$pag_class = 'show-pag';
		} else {
			$thumbs_state = "on";
			$thmb_class = '';
			$pag_class = '';
		}		
		if (isset($gt3_theme_pagebuilder['sliders']['fullscreen']['controls']) && $gt3_theme_pagebuilder['sliders']['fullscreen']['controls'] !== 'on') {
			$controls = 0;
		} else {
			$controls = 1;
		}
		if (isset($gt3_theme_pagebuilder['sliders']['fullscreen']['thumbs']) && $gt3_theme_pagebuilder['sliders']['fullscreen']['thumbs'] !== 'off') {
			$thmbs = 1;
		} else {
			$thmbs = 0;
		}		
		if (isset($gt3_theme_pagebuilder['sliders']['fullscreen']['autoplay']) && $gt3_theme_pagebuilder['sliders']['fullscreen']['autoplay'] == "off") {
			$autoplay = 0;
		} else {
			$autoplay = 1;
		}
		if (isset($gt3_theme_pagebuilder['sliders']['fullscreen']['interval']) && $gt3_theme_pagebuilder['sliders']['fullscreen']['interval'] > 0) {
			$interval = $gt3_theme_pagebuilder['sliders']['fullscreen']['interval'];
		} else {
			$interval = 3300;
		}
		if (isset($gt3_theme_pagebuilder['sliders']['fullscreen']['fit_style'])) {
			$fit_style = $gt3_theme_pagebuilder['sliders']['fullscreen']['fit_style'];
		} else {
			$fit_style = "no_fit";
		}
		if (isset($gt3_theme_pagebuilder['sliders']['fullscreen']['anim_style'])) {
			$fx = $gt3_theme_pagebuilder['sliders']['fullscreen']['anim_style'];
		} else {
			$fx = 'slip';
		}
		
		$sliderCompile .= '<script>gallery_set = [';
		$preloadCompile = ''; 
		foreach ($gt3_theme_pagebuilder['sliders']['fullscreen']['slides'] as $imageid => $image) {
			$uniqid = mt_rand(0, 9999);
			if (isset($image['title']['value']) && strlen($image['title']['value'])>0) {$photoTitle = $image['title']['value'];} else {$photoTitle = "";}
			if (isset($image['caption']['value']) && strlen($image['caption']['value'])>0) {$photoCaption  = $image['caption']['value'];} else {$photoCaption = "";}
			if (isset($image['title']['color']) && strlen($image['title']['color'])>0) {$titleColor = $image['title']['color'];} else {$titleColor = "f6f6f6";}
			if (isset($image['caption']['color']) && strlen($image['caption']['color'])>0) {$captionColor  = $image['caption']['color'];} else {$captionColor = "979797";}
			
			if ($image['slide_type'] == 'image') {
				$sliderCompile .= '{type: "image", image: "' . wp_get_attachment_url($image['attach_id']) . '", thmb: "'.aq_resize(wp_get_attachment_url($image['attach_id']), "104", "104", true, true, true).'", alt: "' . str_replace('"', "'",  $photoTitle) . '", title: "' . str_replace('"', "'", $photoTitle) . '", description: "' . str_replace('"', "'",  $photoCaption) . '", titleColor: "#'.$titleColor.'", descriptionColor: "#'.$captionColor.'"},';
				$preloadCompile .= '"'. wp_get_attachment_url($image['attach_id']) .'",';
			} else if ($image['slide_type'] == 'video') {
				#YOUTUBE
				$is_youtube = substr_count($image['src'], "youtu");				
				if ($is_youtube > 0) {
					$videoid = substr(strstr($image['src'], "="), 1);					
					$sliderCompile .= '{type: "youtube", uniqid: "' . $uniqid . '", src: "' . $videoid . '", thmb: "'.aq_resize(wp_get_attachment_url($image['attach_id']), "400", "400", true, true, true).'", alt: "' . str_replace('"', "'",  $photoTitle) . '", title: "' . str_replace('"', "'", $photoTitle) . '", description: "' . str_replace('"', "'",  $photoCaption) . '", titleColor: "#'.$titleColor.'", descriptionColor: "#'.$captionColor.'"},';
				}
				#VIMEO
				$is_vimeo = substr_count($image['src'], "vimeo");				
				if ($is_vimeo > 0) {
					$videoid = substr(strstr($image['src'], "m/"), 2);
					$sliderCompile .= '{type: "vimeo", uniqid: "' . $uniqid . '", src: "' . $videoid . '", thmb: "'.aq_resize(wp_get_attachment_url($image['attach_id']), "400", "400", true, true, true).'", alt: "' . str_replace('"', "'",  $photoTitle) . '", title: "' . str_replace('"', "'", $photoTitle) . '", description: "' . str_replace('"', "'",  $photoCaption) . '", titleColor: "#'.$titleColor.'", descriptionColor: "#'.$captionColor.'"},';
				}				
			}
		}
	$sliderCompile .= "]
	var fsImg = [". $preloadCompile ."]
	jQuery(document).ready(function(){
		header.addClass('fixed_header');
		jQuery('.custom_bg').remove();
		jQuery('body').fs_gallery({
			fx: '". $fx ."', /*fade, slip*/
			fit: '". $fit_style ."',
			slide_time: ". $interval .", /*This time must be < then time in css*/
			autoplay: ".$autoplay.",
			show_controls: ". $controls .",
			slides: gallery_set
		});
		jQuery('.fs_share').click(function(){
			jQuery('.fs_fadder').removeClass('hided');
			jQuery('.fs_sharing_wrapper').removeClass('hided');
			jQuery('.fs_share_close').removeClass('hided');
		});
		jQuery('.fs_share_close').click(function(){
			jQuery('.fs_fadder').addClass('hided');
			jQuery('.fs_sharing_wrapper').addClass('hided');
			jQuery('.fs_share_close').addClass('hided');
		});
		jQuery('.close_controls').click(function(){
			html.toggleClass('hide_controls');
		});			
	});
	</script>";

	echo $sliderCompile;?>

    <div class="preloader fs_preloader">
        <div class="preloader_content">
            <span><?php echo gt3_get_theme_option("preloader_text"); ?></span>
            <div class="preloader_line">
                <div class="preloader_line_bar1"></div>
                <div class="preloader_line_bar2"></div>
            </div>
        </div>
    </div>
    <div class="fs_bg"></div>
    
    <div class="fs_title_wrapper fadeOnLoad">
        <h1 class="fs_title"><?php echo the_title(); ?>&nbsp;</h1>
        <h3 class="fs_descr"></h3>
    </div>
    <div class="fs_share_block fs_template">
        <a href="<?php echo esc_js("javascript:void(0)");?>" class="share_toggle nav_button nav-share"></a>
        <div class="share_box">
            <a target="_blank"
               href="http://www.facebook.com/share.php?u=<?php echo get_permalink(); ?>" class="nav_button nav-facebook"></a>
            <a target="_blank"
               href="https://twitter.com/intent/tweet?text=<?php echo get_the_title(); ?>&amp;url=<?php echo get_permalink(); ?>" class="nav_button nav-twitter"></a>
            <a target="_blank"
               href="https://plus.google.com/share?url=<?php echo get_permalink(); ?>" class="nav_button nav-gplus"></a>
            <a target="_blank"
               href="http://pinterest.com/pin/create/button/?url=<?php echo get_permalink(); ?>&media=<?php echo (strlen($featured_image[0])>0) ? $featured_image[0] : gt3_get_theme_option("logo"); ?>" class="nav_button nav-pinterest"></a>
        </div> 
    </div>

    <div class="fs_controls_append"></div>
    <script>
		jQuery(document).ready(function(){
			jQuery('.main_header').removeClass('hided');
			jQuery('html').addClass('single-gallery');
			<?php if ($controls == 'false') {
				echo "jQuery('html').addClass('fullview');";				
			} ?>
			jQuery('.share_toggle').click(function(){
				jQuery('.fs_share_block').toggleClass('show_share');
			});
		});	
	</script>

	<?php } else { ?>

    <script>
		var wrapper404 = jQuery('.wrapper404');
		jQuery(document).ready(function(){
			centerWindow();
			html.addClass('error404');
		});
		jQuery(window).resize(function(){
			setTimeout('centerWindow()',500);
			setTimeout('centerWindow()',1000);			
		});
		function centerWindow() {
			setTop = (window_h - wrapper404.height())/2;
			wrapper404.css('top', setTop +'px');
			wrapper404.removeClass('fixed');
		}
	</script>
			
	<?php 
	}
	?>
<?php get_footer('none'); 
} else {
	get_header('fullscreen');
?>
    <div class="pp_block unloaded">
        <h1 class="pp_title"><?php  _e('This Content is Password Protected', 'theme_localization') ?></h1>
        <div class="pp_wrapper">
            <?php the_content(); ?>
        </div>
    </div>
    <script>
		jQuery(document).ready(function(){
			jQuery('.post-password-form').find('label').find('input').attr('placeholder', 'Enter The Password...');
			setTimeout('jQuery(".pp_block").removeClass("unloaded")',350);
		});
	</script>
<?php 
	get_footer('fullscreen');
} ?>