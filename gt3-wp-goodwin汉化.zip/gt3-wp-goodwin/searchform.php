<form name="search_form" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="search_form">
    <input type="text" name="s" value="" placeholder="<?php _e('Search the site...','theme_localization'); ?>" class="field_search">
</form>