<?php 
/* Template Name: Vertically Stretched Page */
if ( !post_password_required() ) {
get_header('fullscreen'); 
the_post();
$gt3_theme_pagebuilder = gt3_get_theme_pagebuilder(get_the_ID());
?>
<?php if (!isset($gt3_theme_pagebuilder['settings']['show_title']) || $gt3_theme_pagebuilder['settings']['show_title'] !== "no") { 
	$TitleClass = "hasTitle";
} else {
	$TitleClass = "noTitle";
}
?>
<div class="vs_page fadeOnLoad container">
	<div class="vs_page_content">
        <div class="content_block row no-sidebar">
            <div class="fl-container">
                <div class="row">
                    <div class="posts-block">
                    <?php if (!isset($gt3_theme_pagebuilder['settings']['show_title']) || $gt3_theme_pagebuilder['settings']['show_title'] !== "no") { ?>
                        <div class="page_title_block">
                            <h1 class="title"><?php the_title(); ?></h1>
                        </div>
                    <?php } ?>                    
                        <div class="contentarea">
                            <?php
                            the_content(__('Read more!', 'theme_localization'));
                            wp_link_pages(array('before' => '<div class="page-link">' . __('Pages', 'theme_localization') . ': ', 'after' => '</div>'));
                            if (gt3_get_theme_option('page_comments') == "enabled") {?>
                            <hr class="comment_hr"/>
                            <div class="row">
                                <div class="span12">
                                    <?php comments_template(); ?>
                                </div>
                            </div>							
                            <?php }?>							
                        </div>
                    </div>
                </div>
            </div>
		</div>
	</div>
</div>

<script>
	var vs_page = jQuery('.vs_page'),
	setCenterTop = 0;
	jQuery(document).ready(function(){
		centerWindow();
		body.addClass('centered_page');		
	});
	jQuery(window).load(function(){
		centerWindow();
	});
	jQuery(window).resize(function(){
		centerWindow();
		setTimeout('centerWindow()',500);
		setTimeout('centerWindow()',1000);
	});
	function centerWindow() {
		setCenterTop = (jQuery(window).height() - vs_page.height() - header_h)/2 + header_h;
		if (setCenterTop < header_h) {
			setCenterTop = header_h;
		}		
		vs_page.css('top', setCenterTop);
	}
</script>

<?php get_footer('fullscreen'); 
} else {
	get_header('fullscreen');
	echo "<div class='fixed_bg' style='background-image:url(".gt3_get_theme_option('bg_img').")'></div>";
?>
    <div class="pp_block">
        <h1 class="pp_title"><?php  _e('THIS CONTENT IS PASSWORD PROTECTED', 'theme_localization') ?></h1>
        <div class="pp_wrapper">
            <?php the_content(); ?>
        </div>
    </div>
    <div class="global_center_trigger"></div>	
    <script>
		jQuery(document).ready(function(){
			jQuery('.post-password-form').find('label').find('input').attr('placeholder', 'Enter The Password...');
		});
	</script>
<?php 
	get_footer('fullscreen');
} ?>