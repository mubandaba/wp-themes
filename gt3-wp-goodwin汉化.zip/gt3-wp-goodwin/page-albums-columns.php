<?php 
/*
Template Name: Gallery - Albums Masonry Rolls
*/
if ( !post_password_required() ) {
get_header('fullscreen');
the_post();

$gt3_theme_pagebuilder = gt3_get_theme_pagebuilder(get_the_ID());
$featured_image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'single-post-thumbnail');
$pf = get_post_format();
wp_enqueue_script('gt3_cookie_js', get_template_directory_uri() . '/js/jquery.cookie.js', array(), false, true);
wp_enqueue_script('gt3_dmLightBox_js', get_template_directory_uri() . '/js/dm_lightbox.js', array(), false, true);

	$hasFilter = '';
		global $wp_query_in_shortcodes, $paged;
		
		if(empty($paged)){
			$paged = (get_query_var('page')) ? get_query_var('page') : 1;
		}			
		if (isset($gt3_theme_pagebuilder['settings']['cat_ids']) && (is_array($gt3_theme_pagebuilder['settings']['cat_ids']))) {
			$compile_cats = array();
			foreach ($gt3_theme_pagebuilder['settings']['cat_ids'] as $catkey => $catvalue) {
				array_push($compile_cats, $catkey);
			}
			$selected_categories = implode(",", $compile_cats);
		} else {
			$selected_categories = "";
			$post_type_filter = "";
		}
		$post_type_terms = array();
		if (isset($selected_categories) && strlen($selected_categories) > 0) {
			$post_type_terms = explode(",", $selected_categories);
			$post_type_filter = explode(",", $selected_categories);
			$post_type_field = "id";
		}		

	$getArgs = array('taxonomy' => 'Category', 'include' => $post_type_filter);
	$getTerms = get_terms('gallerycat', $getArgs);
	$colCount = count($getTerms);
	$colSize = 100/$colCount;
	
	$wp_query_in_shortcodes = new WP_Query();
	$args = array(
		'post_type' => 'gallery',
		'order' => 'DESC',
		'paged' => $paged,
		'posts_per_page' => -1
	);

	if (isset($_GET['slug']) && strlen($_GET['slug']) > 0) {
		$post_type_terms = esc_attr($_GET['slug']);
		$selected_categories = esc_attr($_GET['slug']);
		$post_type_field = "slug";
	}
	if (count($post_type_terms) > 0) {
		$args['tax_query'] = array(
			array(
				'taxonomy' => 'gallerycat',
				'field' => $post_type_field,
				'terms' => $post_type_terms
			)
		);
	}
	
?>
    <div class="preloader">
        <div class="preloader_content">
            <span><?php echo gt3_get_theme_option("preloader_text"); ?></span>
            <div class="preloader_line">
                <div class="preloader_line_bar1"></div>
                <div class="preloader_line_bar2"></div>
            </div>
        </div>
    </div>

	<div class="screen_cutter">
    <div id="cols_wrapper" class="fadeOnLoad">
    
    	<?php
		$i = 1;
		$permalink = '';
		if (is_array($getTerms)) {
			foreach ($getTerms as $term) {
				$wp_query_in_shortcodes = new WP_Query();
				$args = array(
					'post_type' => 'gallery',
					'order' => 'DESC',
					'paged' => $paged,
					'posts_per_page' => -1
				);	
					
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'gallerycat',
						'field' => 'id',
						'terms' => $term->term_id
					)
				);
					
				$permalink = esc_url(add_query_arg("slug", $term->slug, $permalink));
							
			?>
                <?php if ($i % 2) {
					$evenClass = '';
				} else {
					$evenClass = 'even';
				}?>
                <div class="filter_label <?php echo $evenClass; ?>" style="width:<?php echo $colSize; ?>%; left:<?php echo ($colSize*$i) - $colSize;?>%" data-ata="<?php echo $i ?>">
                    <h3><?php echo $term->name ?></h3>
                </div><!-- .inner_col_wrapper -->
				<div class="inner_col_wrapper" style="width:<?php echo $colSize; ?>%; left:<?php echo ($colSize*$i) - $colSize;?>%" data-ata="<?php echo $i ?>">
					<div class="inner_col">
					<?php
						$wp_query_in_shortcodes->query($args);
						$imgCounter = 0;									
						while ($wp_query_in_shortcodes->have_posts()) : $wp_query_in_shortcodes->the_post();
							$gt3_theme_post = get_plugin_pagebuilder(get_the_ID());
							$featured_image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'single-post-thumbnail');
							$new_term_list = get_the_terms(get_the_id(), "gallerycat");
							$sliderCompile = "";
							?>                

                            <div class="fw_grid_item">
                                <div class="fw_grid_content">
                                    <div class="img_block wrapped_img fs_port_item gallery_item_wrapper">
                                        <a href="<?php echo get_permalink(); ?>"></a>
                                        <img width="570" height="" class="img2preload" src="<?php echo aq_resize($featured_image[0], "570", "", true, true, true); ?>" alt="<?php the_title(); ?>" />
                                        <div class="gallery_fadder"></div>
                                        <div class="gal_content">
                                            <h3><?php the_title(); ?></h3>
                                            <span class="gal_plus_ico"></span>
                                        </div>
                                    </div>                    
                                </div>
                            </div>                                                
																							   
						<?php endwhile; ?>
					</div>
                </div><!-- .inner_col_wrapper -->
                
                <?php
				$i++;
			} 
		} ?>
    </div><!-- #cols_wrapper -->
	<div class="filter_labels">
    	<?php
			$i = 1;
			foreach ($getTerms as $term) {
				$wp_query_in_shortcodes = new WP_Query();
				$args = array(
					'post_type' => 'gallery',
					'order' => 'DESC',
					'paged' => $paged,
					'posts_per_page' => -1
				);	
					
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'gallerycat',
						'field' => 'id',
						'terms' => $term->term_id
					)
				);
					
				$permalink = esc_url(add_query_arg("slug", $term->slug, $permalink));
			?>
                <?php
				$i++;
			}
		?>    
    </div>

	<script>
		var step = 200,
		scrollSpeed = 3,
		cols = jQuery('#cols_wrapper'),
		fLabels = jQuery('.filter_labels'),
		downStep = 1;
		jQuery(document).ready(function(){
			jQuery('.custom_bg').remove();
			setSize = window_h - header_h - fLabels.height();
			cols.height(setSize).css('top', header_h);
			
			jQuery('.toggle_fullview').click(function(){
				if (html.hasClass('fullview')) {
					setSize = window_h - header_h - fLabels.height();
					cols.height(setSize).css('top', header_h);					
				} else {
					setSize = window_h;
					cols.height(window_h).css('top', '0px');					
				}
			});			
			
			jQuery('.inner_col').on('mousewheel', function(event) {
				step = event.deltaY * 200;
				ground = setSize - jQuery(this).height();
				
				thisTop = parseInt(jQuery(this).css('top'));
				if (jQuery(this).height() > setSize) {
					if (event.deltaY < 0) {
						if ((thisTop + step) > ground) {
							jQuery(this).css('top', thisTop + step + 'px');
						} else {
							jQuery(this).css('top', ground + 'px');
						}
					}
					if (event.deltaY > 0) {
						thisTop = parseInt(jQuery(this).css('top'));
						if (thisTop + step < 0) {
							jQuery(this).css('top', thisTop + step + 'px');
						} else {
							jQuery(this).css('top', '0px');
						}
					}
				}
			});

			jQuery('.inner_col').bind('touchstart', function(event) {
				touch = event.originalEvent.touches[0];
				startAt = touch.pageY;
				html.addClass('touched');
				topStart = parseInt(jQuery(this).css('top'));
				ground = setSize - jQuery(this).height();
			});
			
			jQuery('.inner_col').bind('touchmove', function(event) {
				touch = event.originalEvent.touches[0];
				movePath = -1* (startAt - touch.pageY)/1;
				curTop = topStart + movePath;
				if (jQuery(this).height() > setSize) {
					if (curTop > 0) {
						jQuery(this).css('top', '0px');
					} else if (curTop < ground) {
						jQuery(this).css('top', ground + 'px');
					} else {
						jQuery(this).css('top', curTop + 'px');
					}
				}
			});
			
			jQuery('.inner_col').bind('touchend', function(event) {
				html.removeClass('touched');
				touch = event.originalEvent.changedTouches[0];
				topEnd = parseInt(jQuery(this).css('top'));
			});
			
			gal_setup();
		});
		function gal_setup() {
			jQuery('.gal_content').each(function(){
				jQuery(this).css('margin-top', -1*jQuery(this).height()/2+'px');
			});
			if (html.hasClass('fullview')) {
				setSize = window_h;
				cols.height(window_h).css('top', '0px');					
			} else {
				setSize = window_h - header_h - fLabels.height();
				cols.height(setSize).css('top', header_h);					
			}				
		}
		jQuery(window).load(function($){
			gal_setup();
		});	
		jQuery(window).resize(function($){
			gal_setup();
			setTimeout("gal_setup()",500);
		});		
	</script>
    </div>
<?php get_footer('fullscreen'); 
} else {
	get_header('fullscreen');
?>
    <div class="pp_block unloaded">
        <h1 class="pp_title"><?php  _e('This Content is Password Protected', 'theme_localization') ?></h1>
        <div class="pp_wrapper">
            <?php the_content(); ?>
        </div>
    </div>
    <script>
		jQuery(document).ready(function(){
			jQuery('.post-password-form').find('label').find('input').attr('placeholder', 'Enter The Password...');
			setTimeout('jQuery(".pp_block").removeClass("unloaded")',350);
		});
	</script>
<?php 
	get_footer('fullscreen');
} ?>