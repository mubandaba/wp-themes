<?php 
if ( !post_password_required() ) {
get_header('fullscreen');
$all_likes = gt3pb_get_option("likes");
the_post();
$gt3_theme_pagebuilder = gt3_get_theme_pagebuilder(get_the_ID());
$featured_image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'single-post-thumbnail');
$pf = get_post_format();			

$galleryType = gt3_get_theme_option('default_gallery_style');
if (isset($gt3_theme_pagebuilder['settings']['gallery_style'])) {	
	if ($gt3_theme_pagebuilder['settings']['gallery_style'] == 'fw-gallery-post') { 
		$galleryType = 'fw-gallery-post';
	}
	if ($gt3_theme_pagebuilder['settings']['gallery_style'] == 'ribbon-gallery-post') { 
		$galleryType  = 'ribbon-gallery-post';
	}	
}
	/* ADD 1 view for this post */
	$post_views = (get_post_meta(get_the_ID(), "post_views", true) > 0 ? get_post_meta(get_the_ID(), "post_views", true) : "0");
	update_post_meta(get_the_ID(), "post_views", (int)$post_views + 1);	
	wp_enqueue_script('gt3_cookie_js', get_template_directory_uri() . '/js/jquery.cookie.js', array(), false, true);
	$all_likes = gt3pb_get_option("likes");
?>
<?php
	if ($galleryType == 'fw-gallery-post') { ?>
		<?php 
		wp_enqueue_script('gt3_fsGallery_js', get_template_directory_uri() . '/js/fs_gallery.js', array(), false, true);		
		$sliderCompile = "";
        if (isset($gt3_theme_pagebuilder['sliders']['fullscreen']['slides']) && is_array($gt3_theme_pagebuilder['sliders']['fullscreen']['slides'])) {
			    
            if (isset($gt3_theme_pagebuilder['sliders']['fullscreen']['anim_style']) && $gt3_theme_pagebuilder['sliders']['fullscreen']['anim_style'] !== 'default') {
                $fx = $gt3_theme_pagebuilder['sliders']['fullscreen']['anim_style'];
            } else {
                $fx = gt3_get_theme_option("default_slider_anim");
            }
            if (isset($gt3_theme_pagebuilder['sliders']['fullscreen']['fit_style']) && $gt3_theme_pagebuilder['sliders']['fullscreen']['fit_style'] !== 'default') {
                $fit_style = $gt3_theme_pagebuilder['sliders']['fullscreen']['fit_style'];
            } else {
                $fit_style = gt3_get_theme_option("default_fit_style");
            }
            if (isset($gt3_theme_pagebuilder['sliders']['fullscreen']['controls']) && $gt3_theme_pagebuilder['sliders']['fullscreen']['controls'] !== 'default') {
                $controls = $gt3_theme_pagebuilder['sliders']['fullscreen']['controls'];
            } else {
                $controls = gt3_get_theme_option("default_controls");
            }
            if ($controls == 'on' || $controls == 'yes') {
                $controls = 'true';
            } else {
                $controls = 'false';
            }
            if (isset($gt3_theme_pagebuilder['sliders']['fullscreen']['thumbs']) && $gt3_theme_pagebuilder['sliders']['fullscreen']['thumbs'] !== 'no') {
                $thmbs = 1;
            } else {
                $thmbs = 0;
            }
            if (isset($gt3_theme_pagebuilder['sliders']['fullscreen']['autoplay']) && $gt3_theme_pagebuilder['sliders']['fullscreen']['autoplay'] !== 'default') {
                $autoplay = $gt3_theme_pagebuilder['sliders']['fullscreen']['autoplay'];
            } else {
                $autoplay = gt3_get_theme_option("default_autoplay");
            }
            if ($autoplay == 'on' || $autoplay == 'yes') {
                $autoplay = 'true';
            } else {
                $autoplay = 'false';
            }
    
            $interval = gt3_get_theme_option("gallery_interval");
    
            $sliderCompile .= '<script>gallery_set = [';
			$script_compile = '';
			$preloadCompile = ''; 			
            foreach ($gt3_theme_pagebuilder['sliders']['fullscreen']['slides'] as $imageid => $image) {
                $uniqid = mt_rand(0, 9999);
                if (isset($image['title']['value']) && strlen($image['title']['value'])>0) {$photoTitle = $image['title']['value'];} else {$photoTitle = "";}
                if (isset($image['caption']['value']) && strlen($image['caption']['value'])>0) {$photoCaption  = $image['caption']['value'];} else {$photoCaption = "";}
                $titleColor = "f6f6f6";
                $captionColor = "979797";
                if ($image['slide_type'] == 'image') {
                    $sliderCompile .= '{type: "image", image: "' . wp_get_attachment_url($image['attach_id']) . '", thmb: "'.aq_resize(wp_get_attachment_url($image['attach_id']), "104", "104", true, true, true).'", alt: "' . str_replace('"', "'",  $photoTitle) . '", title: "' . str_replace('"', "'", esc_attr($photoTitle)) . '", description: "' . str_replace('"', "'",  esc_attr($photoCaption)) . '", titleColor: "#'.$titleColor.'", descriptionColor: "#'.$captionColor.'"},';
					$preloadCompile .= '"'. wp_get_attachment_url($image['attach_id']) .'",';
                } else if ($image['slide_type'] == 'video') {
                    #YOUTUBE
                    $is_youtube = substr_count($image['src'], "youtu");				
                    if ($is_youtube > 0) {
                        $videoid = substr(strstr($image['src'], "="), 1);					
                        $thmb = "http://img.youtube.com/vi/".$videoid."/0.jpg";
                        $sliderCompile .= '{type: "youtube", uniqid: "' . $uniqid . '", src: "' . $videoid . '", thmb: "'.$thmb.'", alt: "' . str_replace('"', "'",  $photoTitle) . '", title: "' . str_replace('"', "'", esc_attr($photoTitle)) . '", description: "' . str_replace('"', "'",  esc_attr($photoCaption)) . '", titleColor: "#'.$titleColor.'", descriptionColor: "#'.$captionColor.'"},';
                    }
                    #VIMEO
                    $is_vimeo = substr_count($image['src'], "vimeo");				
                    if ($is_vimeo > 0) {
                        $videoid = substr(strstr($image['src'], "m/"), 2);
                        $thmbArray = json_decode(file_get_contents("http://vimeo.com/api/v2/video/".$videoid.".json"));
                        if (!empty($thmbArray))
                        $thmb = $thmbArray[0]->thumbnail_large;
                        $sliderCompile .= '{type: "vimeo", uniqid: "' . $uniqid . '", src: "' . $videoid . '", thmb: "'.$thmb.'", alt: "' . str_replace('"', "'",  $photoTitle) . '", title: "' . str_replace('"', "'", esc_attr($photoTitle)) . '", description: "' . str_replace('"', "'",  esc_attr($photoCaption)) . '", titleColor: "#'.$titleColor.'", descriptionColor: "#'.$captionColor.'"},';
                    }				
                }
            }
            $sliderCompile .= "]" . $script_compile . "
			var fsImg = [". $preloadCompile ."]
			
            jQuery(document).ready(function(){
                header.addClass('fixed_header');
                jQuery('body').fs_gallery({
                    fx: '". $fx ."', /*fade, slip*/
                    fit: '". $fit_style ."',
                    slide_time: ". $interval .", /*This time must be < then time in css*/
                    autoplay: ".$autoplay.",
                    show_controls: ". $controls .",
                    slides: gallery_set
                });
        		if (jQuery(window).width() < 760) {
					jQuery('.fs_content_bg').css('margin-top', jQuery(window).height()- header_h);
				}
                jQuery('.close_controls').click(function(){
                    html.toggleClass('hide_controls');
                });			
            });
            </script>";
        
		echo $sliderCompile;?>
        <div class="preloader fs_preloader">
            <div class="preloader_content">
                <span><?php echo gt3_get_theme_option("preloader_text"); ?></span>
                <div class="preloader_line">
                    <div class="preloader_line_bar1"></div>
                    <div class="preloader_line_bar2"></div>
                </div>
            </div>
        </div>
        <div class="fs_bg"></div>
        
		<div class="fs_title_wrapper">
			<h1 class="fs_title"><?php echo the_title(); ?>&nbsp;</h1>
			<h3 class="fs_descr"></h3>
		</div>
        <div class="fs_side_controls">
            <a href="<?php echo esc_js("javascript:void(0)"); ?>" class="fs_ctrl_prevPost nav_button nav-prev fs_show_tooltip"></a><span class="fs_span_prev"><?php _e('Previous Project', 'theme_localization') ?></span>
            <a href="<?php echo esc_js("javascript:void(0)"); ?>" class="fs_ctrl_info nav_button nav-info fs_show_tooltip"></a><span class="fs_span_info"><?php _e('About Project', 'theme_localization') ?></span>
            <a href="<?php echo esc_js("javascript:void(0)"); ?>" class="fs_ctrl_like nav_button <?php echo (isset($_COOKIE['like_gallery'.get_the_ID()]) ? "nav-liked" : "nav-like"); ?> fs_show_tooltip gallery_likes_add <?php echo (isset($_COOKIE['like_gallery'.get_the_ID()]) ? "already_liked" : ""); ?>" data-attachid="<?php echo get_the_ID(); ?>" data-modify="like_gallery"></a><span class="fs_span_like"><?php echo ((isset($all_likes[get_the_ID()]) && $all_likes[get_the_ID()]>0) ? $all_likes[get_the_ID()] : 0); ?></span>        
            <div class="fs_share_block_single">
                <a href="<?php echo esc_js("javascript:void(0)");?>" class="share_toggle nav_button nav-share"></a>
                <div class="share_box">
                    <a target="_blank"
                       href="http://www.facebook.com/share.php?u=<?php echo get_permalink(); ?>" class="nav_button nav-facebook"></a>
                    <a target="_blank"
                       href="https://twitter.com/intent/tweet?text=<?php echo get_the_title(); ?>&amp;url=<?php echo get_permalink(); ?>" class="nav_button nav-twitter"></a>
                    <a target="_blank"
                       href="https://plus.google.com/share?url=<?php echo get_permalink(); ?>" class="nav_button nav-gplus"></a>
                    <a target="_blank"
                       href="http://pinterest.com/pin/create/button/?url=<?php echo get_permalink(); ?>&media=<?php echo (strlen($featured_image[0])>0) ? $featured_image[0] : gt3_get_theme_option("logo"); ?>" class="nav_button nav-pinterest"></a>
                </div> 
            </div>
            <a href="<?php echo esc_js("javascript:void(0)"); ?>" class="fs_ctrl_nextPost nav_button nav-next fs_show_tooltip"></a><span class="fs_span_next"><?php _e('Next Project', 'theme_localization') ?></span>
            <?php previous_post_link('<div class="fs_prevPost_link">%link</div>', '');
            next_post_link('<div class="fs_nextPost_link">%link</div>', '') ?>
		</div>
        
        <div class="fs_content_bg">
        	<div class="fs_content_block">
            	<div class="fs_content_wrapper">
					<?php if (!isset($gt3_theme_pagebuilder['settings']['show_title']) || $gt3_theme_pagebuilder['settings']['show_title'] !== "no") { ?>
						<h1 class="side_title"><?php the_title(); ?></h1>
					<?php } ?>
					<?php
                    global $contentAlreadyPrinted;
                    if ($contentAlreadyPrinted !== true) {
                        the_content(__('Read more!', 'theme_localization'));
                    }
                    wp_link_pages(array('before' => '<div class="page-link"><span>' . __('Pages', 'theme_localization') . ': </span>', 'after' => '</div>'));
                    ?>
                    <div class="dn"><?php posts_nav_link(); ?></div>
					<div class="side_meta">
                    	<div class="side_meta_item"><span><i class="icon-calendar"></i><?php _e('Release Date', 'theme_localization')?>:</span> <?php the_time("F d, Y") ?></div>
                        <div class="side_meta_item"><span><i class="icon-folder"></i><?php _e('Album', 'theme_localization')?>:</span> 
							<?php
                                $terms = get_the_terms( get_the_ID(), 'gallerycat' );
                                if ( $terms && ! is_wp_error( $terms ) ) {
                                    $draught_links = array();
                                    $tmp_categ = "";
                                    foreach ( $terms as $term ) {
                                        $tmp_categ .= $term -> term_id .",";
                                        $draught_links[] = '<a href="'.get_term_link($term->slug, "gallerycat").'">'.$term->name.'</a>';
                                    }
                                    $tmp_categ = mb_substr($tmp_categ, 0, -1);
                                    
                                    $on_draught = join( ", ", $draught_links );
                                    $show_cat = true;
                                }
                                if ($terms !== false) {
                                    echo $on_draught;
                                    $tmp_categ = $tmp_categ;
                                } else {
                                    echo "Uncategorized";
                                    $tmp_categ = "";
                                }
                            ?>
                        </div>
						<?php 
                            if (isset($gt3_theme_pagebuilder['page_settings']['icons']) && is_array($gt3_theme_pagebuilder['page_settings']['icons'])) {
                                foreach ($gt3_theme_pagebuilder['page_settings']['icons'] as $skillkey => $skillvalue) {
									echo '<div class="side_meta_item"><span><i class="'.$skillvalue['data-icon-code'].'"></i>'. esc_attr($skillvalue['name']) .':</span> '. esc_attr($skillvalue['link']) .'</div>';
                                }
                            }
                        ?>                                                    
                        
                        <div class="side_meta_item">
                        	<span><i class="stand_icon icon-eye"></i><?php _e('Views', 'theme_localization')?>:</span>
                            <?php echo $post_views; ?>
                        </div>
                        <div class="side_meta_item">
                        	<span><i class="stand_icon <?php echo (isset($_COOKIE['like_gallery'.get_the_ID()]) ? "icon-heart" : "icon-heart-o"); ?>"></i><?php _e('Likes', 'theme_localization')?>:</span>
                            <?php echo ((isset($all_likes[get_the_ID()]) && $all_likes[get_the_ID()]>0) ? $all_likes[get_the_ID()] : 0); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
		<div class="fs_controls_append"></div>
		<script>
			vs_page = jQuery('.fs_content_block');
			jQuery(document).ready(function(){
				
				jQuery('.fs_ctrl_info').click(function(){
					html.toggleClass('show_fs_content')
				});
				centerWindow();
				
				jQuery('.main_header').removeClass('hided');
				jQuery('html').addClass('single-gallery');
				<?php if ($controls == 'false') {
					echo "jQuery('html').addClass('fullview');";				
				} ?>
				jQuery('.share_toggle').click(function(){
					jQuery('.fs_share_block_single').toggleClass('show_share');
				});
				
				jQuery('.fs_show_tooltip').hover(function(){
					jQuery(this).next('span').addClass('hovered');
				},function(){
					jQuery(this).next('span').removeClass('hovered');
				});
				
				if (jQuery('.fs_prevPost_link').size() > 0) {
					jQuery('.fs_ctrl_prevPost').attr('href', jQuery('.fs_prevPost_link').find('a').attr('href'))
				} else {
					jQuery('.fs_side_controls').addClass('no_prev_link');
				}
				if (jQuery('.fs_nextPost_link').size() > 0) {
					jQuery('.fs_ctrl_nextPost').attr('href', jQuery('.fs_nextPost_link').find('a').attr('href'))
				} else {
					jQuery('.fs_side_controls').addClass('no_next_link');
				}			
	
				jQuery('.gallery_likes_add').click(function(){
					var gallery_likes_this = jQuery(this);
					if (!jQuery.cookie(gallery_likes_this.attr('data-modify')+gallery_likes_this.attr('data-attachid'))) {
						jQuery.post(gt3_ajaxurl, {
							action:'add_like_attachment',
							attach_id:jQuery(this).attr('data-attachid')
						}, function (response) {
							jQuery.cookie(gallery_likes_this.attr('data-modify')+gallery_likes_this.attr('data-attachid'), 'true', { expires: 7, path: '/' });
							gallery_likes_this.addClass('already_liked');
							gallery_likes_this.removeClass('nav-like').addClass('nav-liked');
							jQuery('.fs_span_like').text(response);
						});
					}
				});
				
				jQuery('.custom_bg').remove();				
			});	
			jQuery(window).resize(function(){
				centerWindow();
			});
			jQuery(window).load(function(){
				centerWindow();
			});
			
			function centerWindow() {
				setTop = (window_h - vs_page.height() - header_h)/2 + header_h;
				if (setTop < header_h) {
					setTop = header_h;
				}
				vs_page.css('margin-top', setTop);
			}
			
		</script>
		<?php } else { ?>
			<script>
                var wrapper404 = jQuery('.wrapper404');
                jQuery(document).ready(function(){
                    centerWindow();
                    html.addClass('error404');
                });
                jQuery(window).resize(function(){
                    setTimeout('centerWindow()',500);
                    setTimeout('centerWindow()',1000);			
                });
                function centerWindow() {
                    setTop = (window_h - wrapper404.height())/2;
                    wrapper404.css('top', setTop +'px');
                    wrapper404.removeClass('fixed');
                }
            </script>                   
        <?php 
        }
	} else if ($galleryType  == 'ribbon-gallery-post') {?>

    <div class="preloader">
        <div class="preloader_content">
            <span><?php echo gt3_get_theme_option("preloader_text"); ?></span>
            <div class="preloader_line">
                <div class="preloader_line_bar1"></div>
                <div class="preloader_line_bar2"></div>
            </div>
        </div>
    </div>
    
	<?php
	//Ribbon POST
		if (isset($gt3_theme_pagebuilder['sliders']['fullscreen']['slides']) && is_array($gt3_theme_pagebuilder['sliders']['fullscreen']['slides'])) {
			$imgi = 1;
			$script_compile = '';
            foreach ($gt3_theme_pagebuilder['sliders']['fullscreen']['slides'] as $imageid => $image) {
				if (isset($image['title']['value']) && strlen($image['title']['value'])>0) {$photoTitle = ': '. $image['title']['value'];} else {$photoTitle = " ";}
				if (isset($image['title']['value']) && strlen($image['title']['value'])>0) {$photoAlt = $image['title']['value'];} else {$photoAlt = " ";}
				if (isset($image['caption']['value']) && strlen($image['caption']['value'])>0) {$photoCaption  = $image['caption']['value'];} else {$photoCaption = " ";}				
				$photoCaption = "";
				if ($image['slide_type'] == 'image') {
						$compile_slides .= "<li data-count='".$imgi."' data-title='". $photoTitle ."' data-caption='". $photoCaption ."' class='ribbon_slide slide".$imgi."'><img src='" . aq_resize(wp_get_attachment_url($image['attach_id']), null, "910", true, true, true) . "' alt='" . $photoAlt ."' class='img2preload'/><div class='slide_fadder'></div></li>";
					} else {
	
					#YOUTUBE
					$is_youtube = substr_count($image['src'], "youtu");
					if ($is_youtube > 0) {
						$videoid = substr(strstr($image['src'], "="), 1);
						$compile_slides .= "<li data-count='".$imgi."' data-title='". $photoTitle ."' data-caption='". $photoCaption ."' class='ribbon_slide slide".$imgi."'><iframe width='100%' height='100%' src='http://www.youtube.com/embed/" . $videoid . "?controls=1&autoplay=0&showinfo=0&modestbranding=1&wmode=opaque&rel=0&hd=1&disablekb=1' frameborder='0' allowfullscreen></iframe><div class='slide_fadder'></div></li>";
					}
					#VIMEO
					$is_vimeo = substr_count($image['src'], "vimeo");				
					if ($is_vimeo > 0) {
						$videoid = substr(strstr($image['src'], "m/"), 2);
						$compile_slides .= "<li data-count='".$imgi."' data-title='". $photoTitle ."' data-caption='". $photoCaption ."' class='ribbon_slide slide".$imgi."'><iframe src='http://player.vimeo.com/video/". $videoid  ."?autoplay=0&loop=0&api=0' width='100%' height='100%' frameborder='0' webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe><div class='slide_fadder'></div></li>";
					}
				}
				$imgi++;
			}			
		} ?>
        	<script>
				<?php echo $script_compile; ?>
			</script>
            <div class="ribbon_main_wrapper fadeOnLoad">
                <ul class="ribbon_list">
                    <?php echo $compile_slides;?>
                </ul>
                <!-- <div id="dragMe"></div> -->
                <div id="ribbon_status">
                    <div class="status_left">
                    	<?php 
						if (!isset($gt3_theme_pagebuilder['settings']['show_title']) || $gt3_theme_pagebuilder['settings']['show_title'] !== "no") { ?>
                            <h1 style="display:none"><?php the_title(); ?></h1>
                            <?php 
							the_title();
						} ?>
                        <span class="slide_title"></span>
                    </div>
                    <div class="status_middle">
                        <span class="current_item">1</span> <?php  _e('of', 'theme_localization') ?> <span class="max_items"></span>
                    </div>
                    <div class="status_right">
                        <div class="side_meta_item">
                        	<span><i class="stand_icon icon-eye"></i></span>
							<?php echo $post_views; ?>
                        </div>
                        <div class="side_meta_item gallery_likes gallery_likes_add <?php echo (isset($_COOKIE['like_album'.get_the_ID()]) ? "already_liked" : ""); ?>" data-attachid="<?php echo get_the_ID(); ?>" data-modify="like_album">
                        	<i class="stand_icon <?php echo (isset($_COOKIE['like_gallery'.get_the_ID()]) ? "icon-heart" : "icon-heart-o"); ?>"></i>
                            <span><?php echo ((isset($all_likes[get_the_ID()]) && $all_likes[get_the_ID()]>0) ? $all_likes[get_the_ID()] : 0); ?></span>
                        </div>
                        <div class="share_wrapper">
                        	<span class="share_text">Share this:</span>
                            <a target="_blank"
                               href="http://www.facebook.com/share.php?u=<?php echo get_permalink(); ?>"
                               class="top_socials share_facebook"><i class="stand_icon icon-facebook"></i></a>
                            <a target="_blank"
                               href="https://twitter.com/intent/tweet?text=<?php echo get_the_title(); ?>&amp;url=<?php echo get_permalink(); ?>"
                               class="top_socials share_tweet"><i class="stand_icon icon-twitter"></i></a>
                            <a target="_blank"
                               href="https://plus.google.com/share?url=<?php echo get_permalink(); ?>"
                               class="top_socials share_gplus"><i class="icon-google-plus"></i></a>
                            <a target="_blank"
                               href="http://pinterest.com/pin/create/button/?url=<?php echo get_permalink(); ?>&media=<?php echo (strlen($featured_image[0])>0) ? $featured_image[0] : gt3_get_theme_option("logo"); ?>"
                               class="top_socials share_pinterest"><i class="stand_icon icon-pinterest"></i></a>
                        </div>                         
                    </div>                
                </div>
                <a href="<?php echo esc_js("javascript:void(0)");?>" class="nav_button nav-left rbPrev"></a>
                <a href="<?php echo esc_js("javascript:void(0)");?>" class="nav_button nav-right rbNext"></a>
            </div>
			<?php 
                $GLOBALS['showOnlyOneTimeJS']['gallery_likes'] = "
                <script>
                    jQuery(document).ready(function($) {
                        jQuery('.gallery_likes_add').click(function(){
                        var gallery_likes_this = jQuery(this);
                        if (!jQuery.cookie(gallery_likes_this.attr('data-modify')+gallery_likes_this.attr('data-attachid'))) {
                            jQuery.post(gt3_ajaxurl, {
                                action:'add_like_attachment',
                                attach_id:jQuery(this).attr('data-attachid')
                            }, function (response) {
                                jQuery.cookie(gallery_likes_this.attr('data-modify')+gallery_likes_this.attr('data-attachid'), 'true', { expires: 7, path: '/' });
                                gallery_likes_this.addClass('already_liked');
                                gallery_likes_this.find('i').removeClass('icon-heart-o').addClass('icon-heart');
                                gallery_likes_this.find('span').text(response);
                            });
                        }
                        });
                    });
                </script>
                ";		
            ?>            
            <!-- .fullscreen_content_wrapper -->            
    <script>
		var clicking = false,
			dragMe = jQuery('.ribbon_list'),
			demension = 0,
			statusBar = jQuery('#ribbon_status'),
			rList = jQuery('.ribbon_list'),
			maxSlide = rList.find('li').size(),
			status_max = jQuery('.max_items'),
			status_cur = jQuery('.current_item');

		/*dragMe.mousedown(function(e){
			clicking = true;
			startX = e.pageX;
			html.addClass('clicked');
		});		
		dragMe.mousemove(function(e){
			if(clicking == false) return;
			movePath = -1* (startX - e.pageX)/3;
			
			prevSlide2 = jQuery('.prevStep2');
			prevSlide = jQuery('.prevStep');
			curSlide = jQuery('.currentStep');
			nextSlide = jQuery('.nextStep');
			nextSlide2 = jQuery('.nextStep2');

			mainMove = ((window_w - curSlide.width()) /2) + movePath;
			nextMove = (curSlide.width() + mainOffSet) + movePath;
			prevMove = (mainOffSet - prevSlide.width()) + movePath;
			nextMove2 = (nextSlide.width() + nextOffset) + movePath;
			prevMove2 = (prevOffset - prevSlide2.width()) + movePath;

			jQuery('.prevStep2').css({'transform' : ' translateX('+ prevMove2 +'px)'});
			jQuery('.prevStep').css({'transform' : ' translateX('+ prevMove +'px)'});
			jQuery('.currentStep').css({'transform' : ' translateX('+ mainMove +'px)'});
			jQuery('.nextStep').css({'transform' : ' translateX('+ nextMove +'px)'});
			jQuery('.nextStep2').css({'transform' : ' translateX('+ nextMove2 +'px)'});
		});	
		dragMe.mouseup(function(e){
			clicking = false;			
			html.removeClass('clicked');
			if (e.pageX < startX) {
				next_slide();
			}
			if (e.pageX > startX) {
				prev_slide();
			}
		});*/
		if (jQuery(window).width() > 760) {
			dragMe.bind('touchstart', function(event) {
				touch = event.targetTouches[0];
				startAt = touch .pageX;
				html.addClass('clicked');
			});
			dragMe.bind('touchmove', function(event) {
				touch = event.targetTouches[0];
				movePath = -1* (startAt - touch.pageX)/3;
				
				prevSlide2 = jQuery('.prevStep2');
				prevSlide = jQuery('.prevStep');
				curSlide = jQuery('.currentStep');
				nextSlide = jQuery('.nextStep');
				nextSlide2 = jQuery('.nextStep2');
	
				mainMove = ((window_w - curSlide.width()) /2) + movePath;
				nextMove = (curSlide.width() + mainOffSet) + movePath;
				prevMove = (mainOffSet - prevSlide.width()) + movePath;
				nextMove2 = (nextSlide.width() + nextOffset) + movePath;
				prevMove2 = (prevOffset - prevSlide2.width()) + movePath;
	
				jQuery('.prevStep2').css({'transform' : ' translateX('+ prevMove2 +'px)'});
				jQuery('.prevStep').css({'transform' : ' translateX('+ prevMove +'px)'});
				jQuery('.currentStep').css({'transform' : ' translateX('+ mainMove +'px)'});
				jQuery('.nextStep').css({'transform' : ' translateX('+ nextMove +'px)'});
				jQuery('.nextStep2').css({'transform' : ' translateX('+ nextMove2 +'px)'});
			});
			dragMe.bind('touchend', function(event) {
				touch = event.changedTouches[0];			
	
				html.removeClass('clicked');
				if (touch.pageX < startAt) {
					next_slide();
				}
				if (touch.pageX > startAt) {
					prev_slide();
				}
			});
		}
		jQuery(document).ready(function($){
			status_max.html(maxSlide);
			jQuery('.custom_bg').remove();
			jQuery('.ribbon_list').on("swipeleft",function(){
				next_slide();
			});
			jQuery('.ribbon_list').on("swiperight",function(){
				prev_slide();
			});			
			jQuery('.rbPrev').click(function(){
				prev_slide();
			});
			jQuery('.rbNext').click(function(){
				next_slide();
			});

			jQuery(document.documentElement).keyup(function (event) {
				if ((event.keyCode == 37) || (event.keyCode == 40)) {
					prev_slide();
				} else if ((event.keyCode == 39) || (event.keyCode == 38)) {
					next_slide();
				}
			});

			jQuery('.share_toggle').click(function(){
				jQuery('.share_block').toggleClass('show_share');
			});
			
			jQuery('.slide1').addClass('currentStep');
			jQuery('.slider_caption').text(jQuery('.currentStep').attr('data-title'));
			ribbon_setup();
			
		});	
		jQuery(window).resize(function($){
			updateSlide();
			setTimeout("updateSlide()",500);
		});	
		jQuery(window).load(function($){
			setSlide(1);
		});	
		
		function ribbon_setup() {
			if (window_w > 760) {
				setHeight = window_h;
				rList.height(setHeight);
				rList.find('li').height(setHeight);				
				jQuery('.num_current').text('1');
				
				jQuery('.num_all').text(rList.size());								
				jQuery('.slider_caption').text(jQuery('.currentStep').attr('data-title'));
				rList.find('li').each(function(){
					if (jQuery(this).find('iframe').size() > 0) {
						jQuery(this).find('iframe').height(jQuery(this).height()).width((jQuery(this).height()/9)*16);
						jQuery(this).width(jQuery(this).find('iframe').width());
					} else {
						jQuery(this).width(jQuery(this).find('img').width());
					}
				});				
			}
		}
		
		function setSlide(slideNum) {
			status_cur.html(slideNum);
			jQuery('.prevStep2').removeClass('prevStep2');
			jQuery('.prevStep').removeClass('prevStep');
			jQuery('.currentStep').removeClass('currentStep');
			jQuery('.nextStep').removeClass('nextStep');
			jQuery('.nextStep2').removeClass('nextStep2');
			
			curSlide = jQuery('.slide'+slideNum);
			curSlide.addClass('currentStep');
			
			if((parseInt(slideNum)+1) > maxSlide) {
				nextSlide = jQuery('.slide1');
				nextSlide2 = jQuery('.slide2');
			} else if ((parseInt(slideNum)+1) == maxSlide){
				nextSlide = jQuery('.slide'+maxSlide);
				nextSlide2 = jQuery('.slide1');
			} else {
				nextSlide = jQuery('.slide'+(parseInt(slideNum)+1));
				nextSlide2 = jQuery('.slide'+(parseInt(slideNum)+2));
			}
			
			if((parseInt(slideNum)-1) < 1) {
				prevSlide = jQuery('.slide'+maxSlide);
				prevSlide2 = jQuery('.slide'+(maxSlide-1));
			} else if ((slideNum-1) == 1){
				prevSlide = jQuery('.slide1');
				prevSlide2 = jQuery('.slide'+maxSlide);
			} else {
				prevSlide = jQuery('.slide'+(parseInt(slideNum)-1));
				prevSlide2 = jQuery('.slide'+(parseInt(slideNum)-2));
			}

			prevSlide2.addClass('prevStep2');
			prevSlide.addClass('prevStep');
			curSlide.addClass('currentStep');
			nextSlide.addClass('nextStep');
			nextSlide2.addClass('nextStep2');
			
			mainOffSet = (window_w - curSlide.width()) /2;
			nextOffset = curSlide.width() + mainOffSet;
			prevOffset = mainOffSet - prevSlide.width();
			nextOffset2 = nextSlide.width() + nextOffset;
			prevOffset2 = prevOffset - prevSlide2.width();
			jQuery('.slide_title').text(curSlide.attr('data-title'));
			curSlide.css('transform' , 'translateX('+mainOffSet+'px)'); 
			nextSlide.css('transform' , 'translateX('+nextOffset+'px)');
			nextSlide2.css('transform' , 'translateX('+nextOffset2+'px)');
			prevSlide.css('transform' , 'translateX('+prevOffset+'px)');
			prevSlide2.css('transform' , 'translateX('+prevOffset2+'px)');
		}

		function updateSlide() {
			if (window_w > 1024) {
				setHeight = window_h;
				rList.height(setHeight);
				rList.find('li').height(setHeight);
				
				jQuery('.slider_caption').text(jQuery('.currentStep').attr('data-title'));
				rList.find('li').each(function(){
					if (jQuery(this).find('iframe').size() > 0) {
						jQuery(this).find('iframe').height(jQuery(this).height()).width((jQuery(this).height()/9)*16);
						jQuery(this).width(jQuery(this).find('iframe').width());
					} else {
						jQuery(this).width(jQuery(this).find('img').width());
					}
				});
			}
			
			prevSlide2 = jQuery('.prevStep2');
			prevSlide = jQuery('.prevStep');
			curSlide = jQuery('.currentStep');
			nextSlide = jQuery('.nextStep');
			nextSlide2 = jQuery('.nextStep2');

			mainOffSet = (window_w - curSlide.width()) /2;
			nextOffset = curSlide.width() + mainOffSet;
			prevOffset = mainOffSet - prevSlide.width();

			curSlide.css({'transform' : 'translateX('+mainOffSet+'px)'}); 
			nextSlide.css({'transform' : 'translateX('+nextOffset+'px)'});
			nextSlide2.css({'transform' : 'translateX('+nextSlide.width() + nextOffset+'px)'});
			prevSlide.css({'transform' : 'translateX('+prevOffset+'px)'});
			prevSlide2.css({'transform' : 'translateX('+prevOffset - prevSlide2.width()+'px)'});
		}

		function prev_slide() {
			curSlide = parseInt(jQuery('.currentStep').attr('data-count'));
			if (curSlide - 1 < 1) {
				curSlide = maxSlide;
			} else {
				curSlide = curSlide - 1;
			}
			setSlide(curSlide);
		}
		function next_slide() {
			curSlide = parseInt(jQuery('.currentStep').attr('data-count'));
			if (curSlide + 1 > maxSlide) {
				curSlide = 1;
			} else {
				curSlide = curSlide + 1;
			}
			setSlide(curSlide);
		}
    </script>			
<?php } ?>

<script>
	jQuery(document).ready(function(){
		jQuery('.custom_bg').remove();
	});
</script>
<?php 
	get_footer('fullscreen');
} else {
	get_header('fullscreen');
?>
    <div class="pp_block unloaded">
        <h1 class="pp_title"><?php  _e('This Content is Password Protected', 'theme_localization') ?></h1>
        <div class="pp_wrapper">
            <?php the_content(); ?>
        </div>
    </div>
    <script>
		jQuery(document).ready(function(){
			jQuery('.post-password-form').find('label').find('input').attr('placeholder', 'Enter The Password...');
			setTimeout('jQuery(".pp_block").removeClass("unloaded")',350);
		});
	</script>
<?php 
	get_footer('fullscreen');
} ?>