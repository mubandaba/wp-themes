<?php 
/* 
Template Name: Contacts 
*/
if ( !post_password_required() ) {
get_header('fullscreen');
the_post();

$gt3_theme_pagebuilder = gt3_get_theme_pagebuilder(get_the_ID());
?>
    <div class="site_wrapper fs_site_wrapper model_page contact_page">
	    <div class="main_wrapper">

            <div class="content_wrapper">
                <div class="container fs_page">
                    <div class="content_block row">
                        <div class="fl-container">
                            <div class="row">
                                <div class="posts-block">
                                <?php if (!isset($gt3_theme_pagebuilder['settings']['show_title']) || $gt3_theme_pagebuilder['settings']['show_title'] !== "no") { ?>
                                    <div class="page_title_block">
                                        <h1 class="title"><?php the_title(); ?></h1>
                                    </div>
                                <?php } ?>                    
                                    <div class="contentarea">
                                        <?php
                                        the_content(__('Read more!', 'theme_localization'));
                                        wp_link_pages(array('before' => '<div class="page-link">' . __('Pages', 'theme_localization') . ': ', 'after' => '</div>'));
                                        if (gt3_get_theme_option('page_comments') == "enabled") {?>
                                        <hr class="comment_hr"/>
                                        <div class="row">
                                            <div class="span12">
                                                <?php comments_template(); ?>
                                            </div>
                                        </div>							
                                        <?php }?>							
                                    </div>
                                </div>
                            </div><!-- .row -->

                        </div><!-- .fl-container -->
                    </div>
                </div>
            </div><!-- .content_wrapper -->
            
        </div>
	</div>

	<div class="contacts_map">
        <div class="map_block">
            <?php echo $gt3_theme_pagebuilder['contacts']['mapurl']; ?>
        </div><!-- .map_block -->
	</div>    
	<script>
        jQuery(document).ready(function(){
            setUpWindow();
        });
        jQuery(window).load(function(){
            setUpWindow();
        });
        jQuery(window).resize(function(){
            setUpWindow();
            setTimeout('setUpWindow()',500);
            setTimeout('setUpWindow()',1000);
        });
        function setUpWindow() {
            main_wrapper.css('min-height', window_h-parseInt(site_wrapper.css('padding-top')) - parseInt(site_wrapper.css('padding-bottom'))+'px');
        }
    </script>
<?php 
	get_footer('fullscreen');
} else {
	get_header('fullscreen');
?>
    <div class="pp_block unloaded">
        <h1 class="pp_title"><?php  _e('This Content is Password Protected', 'theme_localization') ?></h1>
        <div class="pp_wrapper">
            <?php the_content(); ?>
        </div>
    </div>
    <script>
		jQuery(document).ready(function(){
			jQuery('.post-password-form').find('label').find('input').attr('placeholder', 'Enter The Password...');
			setTimeout('jQuery(".pp_block").removeClass("unloaded")',350);
		});
	</script>
<?php 
	get_footer('fullscreen');
} ?>