<?php 
/*
Template Name: Portfolio - Grid Style
*/
if ( !post_password_required() ) {
get_header('fullscreen');
the_post();

$gt3_theme_pagebuilder = gt3_get_theme_pagebuilder(get_the_ID());
$featured_image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'single-post-thumbnail');
$pf = get_post_format();
wp_enqueue_script('gt3_cookie_js', get_template_directory_uri() . '/js/jquery.cookie.js', array(), false, true);

if (isset($gt3_theme_pagebuilder['portfolio']['port_type']) && $gt3_theme_pagebuilder['portfolio']['port_type'] == 'port_isotope') {
	wp_enqueue_script('gt3_isotope', get_template_directory_uri() . '/js/jquery.isotope.min.js', array(), false, true);
	wp_enqueue_script('gt3_isotope_sorting', get_template_directory_uri() . '/js/sorting.js', array(), false, true);
} else {
	wp_enqueue_script('gt3_endlessScroll_js', get_template_directory_uri() . '/js/jquery.endless-scroll.js', array(), false, true);
}
if (isset($gt3_theme_pagebuilder['fs_portfolio']['interval'])) {
	$setPad = $gt3_theme_pagebuilder['fs_portfolio']['interval'];
} else {
	$setPad = '0px';
}
if ((int)$setPad > 0) {
	$hasPad = "with_padding";
} else {
	$hasPad = "without_padding";
}
$hasFilter = '';
if (!isset($gt3_theme_pagebuilder['fs_portfolio']['filter']) || $gt3_theme_pagebuilder['fs_portfolio']['filter'] == 'on') {
	$hasFilter = 'has_filter';
}

?>
    <div class="preloader">
        <div class="preloader_content">
            <span><?php echo gt3_get_theme_option("preloader_text"); ?></span>
            <div class="preloader_line">
                <div class="preloader_line_bar1"></div>
                <div class="preloader_line_bar2"></div>
            </div>
        </div>
    </div>

    <div class="fw_grid_gallery <?php echo $hasFilter; ?> fadeOnLoad grid-portfolio dm_faded <?php echo $hasPad; ?>">
        <style>
			.fw-portPreview {
				padding:0 <?php echo $setPad; ?> <?php echo $setPad; ?> 0;
			}
			.fw_grid_gallery .fw_grid_item {
				width:25%;
			}
		</style>  
        <div class="fw_grid_module fs_grid_portfolio" style="padding-top:<?php echo $setPad; ?>; margin-left:<?php echo $setPad; ?>;">  
<?php 
			global $wp_query_in_shortcodes, $paged;
			
			if(empty($paged)){
				$paged = (get_query_var('page')) ? get_query_var('page') : 1;
			}			
			if (isset($gt3_theme_pagebuilder['settings']['cat_ids']) && (is_array($gt3_theme_pagebuilder['settings']['cat_ids']))) {
				$compile_cats = array();
				foreach ($gt3_theme_pagebuilder['settings']['cat_ids'] as $catkey => $catvalue) {
					array_push($compile_cats, $catkey);
				}
				$selected_categories = implode(",", $compile_cats);
			}
            $post_type_terms = array();
			if (isset($selected_categories) && strlen($selected_categories) > 0) {
				$post_type_terms = explode(",", $selected_categories);
				$post_type_filter = explode(",", $selected_categories);
				$post_type_field = "id";
			}
			
			$wp_query_in_shortcodes = new WP_Query();
            $args = array(
                'post_type' => 'port',
                'order' => 'DESC',
                'paged' => $paged,
                'posts_per_page' => gt3_get_theme_option('fw_port_per_page')
            );

            if (isset($_GET['slug']) && strlen($_GET['slug']) > 0) {
                $post_type_terms = esc_attr($_GET['slug']);
				$selected_categories = esc_attr($_GET['slug']);
				$post_type_field = "slug";
            }
            if (count($post_type_terms) > 0) {
                $args['tax_query'] = array(
                    array(
                        'taxonomy' => 'portcat',
                        'field' => $post_type_field,
                        'terms' => $post_type_terms
                    )
                );
            }	
		?>
		<?php 
	        $wp_query_in_shortcodes->query($args);			
	        while ($wp_query_in_shortcodes->have_posts()) : $wp_query_in_shortcodes->the_post();
				$all_likes = gt3pb_get_option("likes");
				$gt3_theme_post = get_plugin_pagebuilder(get_the_ID());
				$featured_image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'single-post-thumbnail');
				$pf = get_post_format();
                $target = (isset($gt3_theme_post['settings']['new_window']) && $gt3_theme_post['settings']['new_window'] == "on" ? "target='_blank'" : "");
				if (isset($gt3_theme_post['page_settings']['portfolio']['work_link']) && strlen($gt3_theme_post['page_settings']['portfolio']['work_link']) > 0) {
					$linkToTheWork = esc_url($gt3_theme_post['page_settings']['portfolio']['work_link']);
				} else {
					$linkToTheWork = get_permalink();
				}
				$echoallterm = '';
				$echoallterm2 = '';
				$portCateg = '';
				$new_term_list = get_the_terms(get_the_id(), "portcat");
                if (is_array($new_term_list)) {
                    foreach ($new_term_list as $term) {
                        $tempname = strtr($term->name, array(
                            ' ' => '-',
                        ));
                        $echoallterm .= strtolower($tempname) . ", ";
						$echoallterm2 .= strtolower($tempname) . " ";
						$portCateg .= $tempname . ", ";
                        $echoterm = $term->name;
                    }
                } else {
                    $portCateg = 'Uncategorized  ';
                }
				$portCateg = substr($portCateg, 0, -2);			
				$photoTitle = get_the_title();
			?>
            <?php if (isset($gt3_theme_pagebuilder['portfolio']['port_type']) && $gt3_theme_pagebuilder['portfolio']['port_type'] == 'port_isotope') { ?>
				<div <?php post_class("fw_grid_item element ". $echoallterm2); ?> data-category="<?php echo $echoallterm2 ?>">
            <?php } else { ?>
				<div <?php post_class("fw_grid_item"); ?>>
			<?php } ?>
					<div class="fw_grid_content" style="margin-bottom:<?php echo $setPad; ?>; margin-right:<?php echo $setPad; ?>;">
                        <div class="img_block wrapped_img fs_port_item gallery_item_wrapper">
							<a href="<?php echo $linkToTheWork; ?>" target="<?php echo $target; ?>"></a>
                            <img width="960" class="img2preload" height="960" src="<?php echo aq_resize($featured_image[0], "540", "540", true, true, true) ?>" alt="<?php echo esc_attr($photoTitle); ?>" />
                            <div class="gallery_fadder"></div>
                            <div class="gal_content">
                            	<?php if (strlen(trim($photoTitle)) > 0) {
	                            	echo "<h3>" . $photoTitle . "</h3>";
                                } ?>
	                            <span class="gal_plus_ico"></span>
                            </div>
                        </div>                    
                    </div>
                </div>      
			<?php endwhile; ?>
		</div>
		<?php if (isset($gt3_theme_pagebuilder['portfolio']['port_type']) && $gt3_theme_pagebuilder['portfolio']['port_type'] == 'port_isotope') { ?>
            <a href="<?php echo esc_js("javascript:void(0)");?>" class="load_more_works"><?php _e('Load More', 'theme_localization') ?></a>            
        <?php }?>        
</div>
<?php 
	if (!isset($gt3_theme_pagebuilder['fs_portfolio']['filter']) || $gt3_theme_pagebuilder['fs_portfolio']['filter'] == 'on') {
		$compile = '';
		$compile .= showAsidePortCats($post_type_filter);
		echo $compile;
	}
?>
    <script>
		jQuery(document).ready(function() {
			gal_setup();
			jQuery('.fs_port_item').hover(function(){
				html.addClass('fadeMe');
				jQuery(this).addClass('unfadeMe');
			},function(){
				html.removeClass('fadeMe');
				jQuery(this).removeClass('unfadeMe');
			});
		});
		jQuery(window).load(function($){
			gal_setup();
		});	
		jQuery(window).resize(function($){
			gal_setup();
		});
		function gal_setup() {
			jQuery('.gal_content').each(function(){
				jQuery(this).css('margin-top', -1*jQuery(this).height()/2+'px');
			});				
		}				

        var posts_already_showed = <?php gt3_the_theme_option('fw_port_per_page'); ?>,
			<?php if (isset($selected_categories) && strlen($selected_categories) > 0) {
				echo 'categories = "'. $selected_categories .'"';
			} else {
				echo 'categories = ""';
			}?>

	<?php if (isset($gt3_theme_pagebuilder['portfolio']['port_type']) && $gt3_theme_pagebuilder['portfolio']['port_type'] == 'port_isotope') {?>
        function get_works() {
            gt3_get_isotope_posts("port", <?php gt3_the_theme_option('fw_port_per_page'); ?>, posts_already_showed, "port_grid_isotope", ".fw_grid_module ", categories, '<?php echo $setPad; ?>', '<?php echo $post_type_field; ?>');
            posts_already_showed = posts_already_showed + <?php gt3_the_theme_option('fw_port_per_page'); ?>;
        }
        jQuery(document).ready(function () {
            jQuery('.load_more_works').click(function(){
				get_works();
			});
        });
	<?php } else { ?>
        function get_works() {
            <?php if (gt3_get_theme_option("demo_server") == "true") { ?> if (posts_already_showed > 14) {posts_already_showed = 0;} <?php } ?>
            gt3_get_portfolio("port", <?php gt3_the_theme_option('fw_port_per_page'); ?>, posts_already_showed, "port_grid_template", ".fw_grid_module ", categories, '<?php echo $setPad; ?>', '<?php echo $post_type_field; ?>');
            posts_already_showed = posts_already_showed + <?php gt3_the_theme_option('fw_port_per_page'); ?>;
        }	

		jQuery(function() {
		  jQuery(document).endlessScroll({
			bottomPixels: 500,
			fireDelay: 10,
			callback: function() {
				get_works();
			}
		  });
		});

	<?php } ?>

    </script>    
	<?php 
		$GLOBALS['showOnlyOneTimeJS']['gallery_likes'] = "
		<script>
			jQuery(document).ready(function($) {
				jQuery('.gallery_likes_add').click(function(){
				var gallery_likes_this = jQuery(this);
				if (!jQuery.cookie(gallery_likes_this.attr('data-modify')+gallery_likes_this.attr('data-attachid'))) {
					jQuery.post(gt3_ajaxurl, {
						action:'add_like_attachment',
						attach_id:jQuery(this).attr('data-attachid')
					}, function (response) {
						jQuery.cookie(gallery_likes_this.attr('data-modify')+gallery_likes_this.attr('data-attachid'), 'true', { expires: 7, path: '/' });
						gallery_likes_this.addClass('already_liked');
						gallery_likes_this.find('i').removeClass('icon-heart-o').addClass('icon-heart');
						gallery_likes_this.find('span').text(response);
					});
				}
				});
			});
		</script>
		";		
	?>
<?php get_footer('fullscreen'); 
} else {
	get_header('fullscreen');
?>
    <div class="pp_block unloaded">
        <h1 class="pp_title"><?php  _e('This Content is Password Protected', 'theme_localization') ?></h1>
        <div class="pp_wrapper">
            <?php the_content(); ?>
        </div>
    </div>
    <script>
		jQuery(document).ready(function(){
			jQuery('.post-password-form').find('label').find('input').attr('placeholder', 'Enter The Password...');
			setTimeout('jQuery(".pp_block").removeClass("unloaded")',350);
		});
	</script>
<?php 
	get_footer('fullscreen');
} ?>