<?php get_header();?>

<div class="row-fluid">
  <div id="main" class="span8 image-preloader">
    <?php include('inc/location.php');?>
    <h2>与 "<?php echo single_tag_title(); ?>" 有关的文章</h2>
    <?php
	 	 $ad2_close = get_option('ad2_close');
	 	 if ($ad2_close == 'open') {
	?>
    <div  class="k_ad"> <?php echo get_option('ad2');?> </div>
    <?php } ?>
    <div class="row-fluid blog-posts">
      <?php include 'inc/excerpt.php'; ?>
    </div>
  </div>
  <?php get_sidebar(); ?>
</div>
</div>
<?php get_footer(); ?>
