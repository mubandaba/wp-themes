<div id="bottom">
  <div class="container">
    <div class="row-fluid">
      <div class="span3 widget clearfix">
        <div class="header">
          <h4>声明</h4>
        </div>
        <div class="content">
          <p><?php echo get_option('statement')?></p>
        </div>
      </div>
      
      <div class="span9 widget clearfix">
      <?php if ( is_home() ) { ?>
        <div class="links-cloud">
          <div class="header">
            <h4>友情链接</h4>
            <h5 class="pull-right"><a href="<?php echo get_option('foot_links_s')?>" target="_blank">申请链接</a></h5>
          </div>
          <ul>
            <?php echo get_option('foot_link')?>
          </ul>
        </div>
        <?php }else {if (function_exists('dynamic_sidebar') && dynamic_sidebar('widget_footer')) : endif;} ?>
      </div>
    </div>
  </div>
</div>
