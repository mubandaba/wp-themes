<?php class Enews_hot_Widget extends WP_Widget { 
	function Enews_hot_Widget() {
		$widget_ops = array('description' => '分别显示最新文章、随机文章、热门文章等TAB聚合信息。');
	    parent::WP_Widget(false,$name='Enews-Tabs聚合文章',$widget_ops); 
	}
	function form($instance) {
?>

<p>
  <label> 显示数目：
    <input style="width:100%;" id="<?php echo $this->get_field_id('linum'); ?>" name="<?php echo $this->get_field_name('linum'); ?>" type="number" value="<?php echo $instance['linum']; ?>" size="24" />
  </label>
</p>

<?php
	}
	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['linum'] = strip_tags($new_instance['linum']);
		return $new_instance;
	}
	function widget($args, $instance) {
		$linum        = $instance['linum'];
		?>
		<div class="widget clearfix">
  <div class="enews-tab">
    <ul class="nav nav-tabs" id="enewsTabs">
      <li class="active"><a href="#tab-populars" data-toggle="tab">最新文章</a></li>
      <li><a href="#tab-recents" data-toggle="tab">随机文章</a></li>
      <li><a href="#tab-comments" data-toggle="tab">热门文章</a></li>
    </ul>
    <div class="tab-content">
      <div class="tab-pane active" id="tab-populars">
        <?php
$args = array(
      'post_password' => '',
          'post_status' => 'publish', // 只选公开的文章.
          'post__not_in' => array($post->ID),//排除当前文章
          'caller_get_posts' => 1, // 排除置頂文章.
          'orderby' => 'date', // 依評論數排序.
          'posts_per_page' => $linum
);
        $query_posts = new WP_Query();
        $query_posts->query($args);
        while( $query_posts->have_posts() ) { $query_posts->the_post(); ?>
        <div class="item">
          <figure class="pull-left"><div class="ih-item square effect7"><a href="<?php the_permalink(); ?>"><div class="img"><img src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo catch_first_image(); ?>&h=60&w=67&zc=1" alt="<?php the_title(); ?>" class="thumbnail"/></div></a></div></figure>
          <div class="pull-right content">
            <h4><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
              <?php the_title(); ?>
              </a></h4>
            <p class="meta"><i class="icon-time"></i>&nbsp;<?php the_time('Y-m-d') ?>&nbsp;&nbsp;<i class="icon-eye-open"></i>&nbsp;<?php echo getPostViews(get_the_ID());?>&nbsp;&nbsp;
            <?php
					if ( comments_open() || '0' != get_comments_number() )
						comments_popup_link('<i class="icon-comment"></i> 0', '<i class="icon-comment"></i> 1', '<i class="icon-comment"></i> %', '');
				?>
          </p>
          </div>
        </div>
        <?php } wp_reset_query();?>
      </div>
      <div class="tab-pane" id="tab-recents">
        <?php
$args = array(
      'post_password' => '',
          'post_status' => 'publish', // 只选公开的文章.
          'post__not_in' => array($post->ID),//排除当前文章
          'caller_get_posts' => 1, // 排除置頂文章.
          'orderby' => 'rand ', // 依評論數排序.
          'posts_per_page' => $linum
);
        $query_posts = new WP_Query();
        $query_posts->query($args);
        while( $query_posts->have_posts() ) { $query_posts->the_post(); ?>
        <div class="item">
          <figure class="pull-left"><div class="ih-item square effect7"><a href="<?php the_permalink(); ?>"><div class="img"><img src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo catch_first_image(); ?>&h=60&w=67&zc=1" alt="<?php the_title(); ?>" class="thumbnail"/></div></a></div></figure>
          <div class="pull-right content">
            <h4><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
              <?php the_title(); ?>
              </a></h4>
            <p class="meta"><i class="icon-time"></i>&nbsp;<?php the_time('Y-m-d') ?>&nbsp;&nbsp;<i class="icon-eye-open"></i>&nbsp;<?php echo getPostViews(get_the_ID());?>&nbsp;&nbsp;
            <?php
					if ( comments_open() || '0' != get_comments_number() )
						comments_popup_link('<i class="icon-comment"></i> 0', '<i class="icon-comment"></i> 1', '<i class="icon-comment"></i> %', '');
				?>
          </p>
          </div>
        </div>
        <?php } wp_reset_query();?>
        
      </div>
      <div class="tab-pane" id="tab-comments">
        <?php
$args = array(
      'post_password' => '',
          'post_status' => 'publish', // 只选公开的文章.
          'post__not_in' => array($post->ID),//排除当前文章
          'caller_get_posts' => 1, // 排除置頂文章.
          'orderby' => 'comment_count', // 依評論數排序.
          'posts_per_page' => $linum
);
        $query_posts = new WP_Query();
        $query_posts->query($args);
        while( $query_posts->have_posts() ) { $query_posts->the_post(); ?>
        <div class="item">
          <figure class="pull-left"><div class="ih-item square effect7"><a href="<?php the_permalink(); ?>"><div class="img"><img src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo catch_first_image(); ?>&h=60&w=67&zc=1" alt="<?php the_title(); ?>" class="thumbnail"/></div></a></div></figure>
          <div class="pull-right content">
            <h4><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
              <?php the_title(); ?>
              </a></h4>
            <p class="meta"><i class="icon-time"></i>&nbsp;<?php the_time('Y-m-d') ?>&nbsp;&nbsp;<i class="icon-eye-open"></i>&nbsp;<?php echo getPostViews(get_the_ID());?>&nbsp;&nbsp;
            <?php
					if ( comments_open() || '0' != get_comments_number() )
						comments_popup_link('<i class="icon-comment"></i> 0', '<i class="icon-comment"></i> 1', '<i class="icon-comment"></i> %', '');
				?>
          </p>
          </div>
        </div>
        <?php } wp_reset_query();?>
      </div>
    </div>
  </div>
</div>
	<?php }
}
register_widget('Enews_hot_Widget');?>
