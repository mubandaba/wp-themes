<?php
class plmsubscribe extends WP_Widget {
/*  Widget
/* ------------------------------------ */
	function __construct(){
		parent::__construct(false,'Enews-邮件订阅',array( 'description' => 'Enews-展示邮件订阅部件' ,'classname' => 'subscribe-widget'));
	}

	function widget($args,$instance){
		extract($args);
		$title = apply_filters('widget_name', $instance['title']);
		$emaildy_id = $instance['emaildy_id'];
		$emaildy_title = $instance['emaildy_title'];
	?>
		<?php echo $before_widget; ?>
        <?php if($instance['title'])echo $before_title.$instance['title']. $after_title; ?>
          <div class="content">
       
       <form name="subscribe-form" id="enews-subscribe-form" method="post" action="http://list.qq.com/cgi-bin/qf_compose_send">
       <input type="hidden" name="t" value="qf_booked_feedback">
              <input type="hidden" name="id" value="<?php echo $emaildy_id; ?>">
        <input type="text" id="to" name="to" placeholder="<?php echo $emaildy_title; ?>">
        <input type="submit" name="submit" value="订阅">
       </form>
      </div>
		<?php echo $after_widget; ?>
	<?php }

	function update($new_instance,$old_instance){
		return $new_instance;
	}

	function form($instance){
		$title = esc_attr($instance['title']);
		$emaildy_id = esc_attr($instance['emaildy_id']);
		?>
		<p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('标题：','Play-LM'); ?><input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></label></p>
        <p>
  <label> 邮箱订阅ID：
    <input style="width:100%;" id="<?php echo $this->get_field_id('emaildy_id'); ?>" name="<?php echo $this->get_field_name('emaildy_id'); ?>" type="text" value="<?php echo $instance['emaildy_id']; ?>" size="24" />
  </label>
</p>
<p>
  <label> 输入框提示文字：
    <input style="width:100%;" id="<?php echo $this->get_field_id('emaildy_title'); ?>" name="<?php echo $this->get_field_name('emaildy_title'); ?>" type="text" value="<?php echo $instance['emaildy_title']; ?>" size="24" />
  </label>
</p>
	<?php
	}
}
add_action('widgets_init',create_function('', 'return register_widget("plmsubscribe");'));?>