<?php  

include('E-text.php');
include('E-list.php');
include('E-adhtml.php');
include('E-tags.php');
include('E-pay.php');
include('E-emaildy.php');
include('hot.php');
?>