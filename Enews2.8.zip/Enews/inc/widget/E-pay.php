<?php

class plmdonate extends WP_Widget {
/*  Widget
/* ------------------------------------ */
	function __construct(){
		parent::__construct(false,'Enews-赞助站长',array( 'description' => 'Enews-支付宝赞助收款小工具，包含手机支付二维码与PC POST方式付款' ,'classname' => 'widget_plmdonate'));
	}

	function widget($args,$instance){
		extract($args);
		$title = apply_filters('widget_name', $instance['title']);
		$alipay_title = $instance['alipay_title'];
		$amount = $instance['amount'];
		$alipay_email = $instance['alipay_email'];
		$alipay_qr = $instance['alipay_qr'];
		$alipay_qr_img = $instance['alipay_qr_img'];
		$alipay_but_img = $instance['alipay_but_img'];
	?>
		<?php echo $before_widget; ?>
        <?php if($instance['title'])echo $before_title.$instance['title']. $after_title; ?>
		<div class="donate"><?php  if ($alipay_qr_img == 'on') {echo '<img src="'.$alipay_qr.'" title="赞助站长" alt="赞助站长" />';}?><?php
		echo '<form id="alipay-gather" action="https://shenghuo.alipay.com/send/payment/fill.htm" method="POST" target="_blank" accept-charset="GBK">
        <input name="optEmail" type="hidden" value="'.$alipay_email.'" />
        <input name="payAmount" type="hidden" value="'.$amount.'" />
        <input id="title" name="title" type="hidden" value="'.$alipay_title.'" />
        <input name="memo" type="hidden" value="" />';
        if ($alipay_but_img == 'on') {echo '<input name="pay" type="image" value="赞助支持" src="https://img.alipay.com/sys/personalprod/style/mc/btn-index.png" />';}else {
			echo '<input class="btn btn-large" name="pay" type="button" value="赞助支持" />';}
		
		echo '</form></div>';?>
		<?php echo $after_widget; ?>

	<?php }

	function update($new_instance,$old_instance){
	$instance = $old_instance;
		//数据处理   
    $instance['title'] = strip_tags(stripslashes($new_instance['title']));   
    $instance['alipay_title'] = strip_tags(stripslashes($new_instance['alipay_title']));
	$instance['amount'] = strip_tags(stripslashes($new_instance['amount']));
	$instance['alipay_email'] = strip_tags(stripslashes($new_instance['alipay_email']));
	$instance['alipay_qr'] = strip_tags(stripslashes($new_instance['alipay_qr']));
	$instance['alipay_qr_img'] = strip_tags(stripslashes($new_instance['alipay_qr_img']));
	$instance['alipay_but_img'] = strip_tags(stripslashes($new_instance['alipay_but_img']));
    //返回   
    return $instance;  
	}

	function form($instance){
		$instance = wp_parse_args((array)$instance,array(   
    'title'=>'捐赠资助','alipay_title'=>'支持一下','amount'=>10
    )); 
		$title = esc_attr($instance['title']);
		$alipay_title = esc_attr($instance['alipay_title']);
		$amount = esc_attr($instance['amount']);
		$alipay_email = esc_attr($instance['alipay_email']);
		$alipay_qr = esc_attr($instance['alipay_qr']);
		$alipay_qr_img = esc_attr($instance['alipay_qr_img']);
		$alipay_but_img = esc_attr($instance['alipay_but_img']);
		?>
		<p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('标题：','Play-LM'); ?><input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></label></p>
        <p><label for="<?php echo $this->get_field_id('alipay_title'); ?>"><?php _e('付款说明：','Play-LM'); ?></label><input class="widefat" id="<?php echo $this->get_field_id('alipay_title'); ?>" name="<?php echo $this->get_field_name('alipay_title'); ?>" type="text"  value="<?php echo $alipay_title; ?>" /></p>
        <p><label for="<?php echo $this->get_field_id('amount'); ?>"><?php _e('默认金额：','Play-LM'); ?></label><input class="widefat" id="<?php echo $this->get_field_id('amount'); ?>" name="<?php echo $this->get_field_name('amount'); ?>" type="text"  value="<?php echo $amount; ?>" /></p>
        <p><label for="<?php echo $this->get_field_id('alipay_email'); ?>"><?php _e('收款账户：','Play-LM'); ?></label><input class="widefat" id="<?php echo $this->get_field_id('alipay_email'); ?>" name="<?php echo $this->get_field_name('alipay_email'); ?>" type="text"  value="<?php echo $alipay_email; ?>" /></p>
        <p><label for="<?php echo $this->get_field_id('alipay_qr'); ?>"><?php _e('支付宝收款二维码：','Play-LM'); ?></label><input class="widefat" id="<?php echo $this->get_field_id('alipay_qr'); ?>" name="<?php echo $this->get_field_name('alipay_qr'); ?>" type="text"  value="<?php echo $alipay_qr; ?>" /></p>
        <p>
  <label>
    <input style="vertical-align:-3px;margin-right:4px;" class="checkbox" type="checkbox" <?php checked( $instance['alipay_qr_img'], 'on' ); ?> id="<?php echo $this->get_field_id('alipay_qr_img'); ?>" name="<?php echo $this->get_field_name('alipay_qr_img'); ?>">
    是否显示支付宝收款二维码？ </label>
</p>
<p>
  <label>
    <input style="vertical-align:-3px;margin-right:4px;" class="checkbox" type="checkbox" <?php checked( $instance['alipay_but_img'], 'on' ); ?> id="<?php echo $this->get_field_id('alipay_but_img'); ?>" name="<?php echo $this->get_field_name('alipay_but_img'); ?>">
    捐赠按钮显示为图片？ </label>
</p>
	<?php
	}
}
add_action('widgets_init',create_function('', 'return register_widget("plmdonate");'));?>