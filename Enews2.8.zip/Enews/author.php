<?php get_header();?>

<div class="row-fluid">
  <div id="main" class="span8 image-preloader">
    <?php include('inc/location.php');?>
    <div class="single single-post">
    <div class="row-fluid">
    <div class="post-author clearfix">
        <figure><?php echo get_avatar( get_the_author_email(), 140 ); ?></figure>
        <div class="content">
          <h5><?php the_author_posts_link(); ?></h5>
          <p>
            <?php 
		 			if(get_the_author_meta("description") != ""){
		 				the_author_meta("description");
		 			}else{
		 				echo "这家伙很懒，什么都没写！";
		 			}
		 		?>
          </p>
        </div>
      </div>
      </div>
    </div>
    <div class="sep-border margin-top10 margin-bottom10"></div>
    
    <div class="row-fluid blog-posts">
      <?php include 'inc/excerpt.php'; ?>
    </div>
  </div>
  <?php get_sidebar(); ?>
</div>
</div>
<?php get_footer(); ?>
