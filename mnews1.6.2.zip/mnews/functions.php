<?php

require_once( trailingslashit( get_template_directory() ) . 'includes/functions.php' );
require_once( trailingslashit( get_template_directory() ) . 'includes/salong.php' );
require_once( trailingslashit( get_template_directory() ) . 'includes/svg.php' );

/** 替换图片链接为 https **/

/**function my_content_manipulator($content){

if( is_ssl() ){

$content = str_replace('http://www.bloglab.cn/wp-content/uploads', 'https://www.bloglab.cn/wp-content/uploads', $content);

}

return$content;

}

add_filter('the_content', 'my_content_manipulator');**/
