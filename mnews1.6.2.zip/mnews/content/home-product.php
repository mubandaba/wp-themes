<?php global $salong;

$args=array( 'post_type'=> 'product','ignore_sticky_posts' => 1,'posts_per_page'=>$salong['home_product_count'],'tax_query'=>array(array('taxonomy'=>'product_cat','field'=>'id','terms'=>$salong['exclude_product_cat'],'operator'=>'NOT IN'),),);$temp_wp_query = $wp_query;$wp_query = null;$wp_query = new WP_Query( $args );if ( $wp_query->have_posts() ) : ?>

<section class="product_list">
    <!--标题-->
    <section class="home_title">
        <section class="title">
            <h3>
                <?php echo $salong['home_product_title']; ?>
            </h3>
            <span><?php echo $salong['home_product_desc']; ?></span>
        </section>
        <section class="button">
            <a href="<?php echo get_page_link(wc_get_page_id('shop')); ?>" title="<?php _e( '查看更多', 'salong' ); ?>" <?php echo new_open_link(); ?>><?php echo _e('更多','salong').svg_more(); ?></a>
        </section>
    </section>
    <!--标题end-->
    <ul class="layout_ul">
        <?php while ( $wp_query->have_posts() ) : $wp_query->the_post();
        wc_get_template_part( 'content', 'product' );
        endwhile; ?>
    </ul>
</section>
<?php endif; wp_reset_query(); ?>