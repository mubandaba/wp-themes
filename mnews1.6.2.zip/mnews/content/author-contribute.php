<?php global $salong; ?>
<section class="contribute">
    <?php echo salong_contribute_post('post'); ?>
</section>
