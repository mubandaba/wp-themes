<?php get_header(); ?>
<div id="wrap-left">
	<?php 
	if (get_option('h_slide_style') == 'Display') include(TEMPLATEPATH . '/includes/topslide.php');
	if (get_option('h_adt') == 'Display') include(TEMPLATEPATH . '/includes/adt.php');
	if (get_option('h_new') == 'Display') include(TEMPLATEPATH . '/includes/homenews.php'); 
	if (get_option('h_imgscroll') == 'Display') include(TEMPLATEPATH . '/includes/leftloop.php'); 
	?>

	<?php include(TEMPLATEPATH . '/includes/columns.php');?>
	<div class="cl"></div>
<!--
<div class="t">
<div class="hc">
<a href="/links" title="友情链接申请" target="_blank" class="cp fr">友情链接申请</a>
<strong>友情链接</strong></div>
<div id="links" class="cl">
<ul>
<?php wp_list_bookmarks(get_option('h_links'));?> 
</ul>
</div>
</div>-->

</div><!--wrap-left-->


<div id="wrap-right">
	<?php get_sidebar(); ?>
</div>
<div class="cl"></div>
<?php get_footer(); ?>