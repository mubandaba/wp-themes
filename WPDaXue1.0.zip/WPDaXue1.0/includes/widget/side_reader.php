<div class="t">
<div class="hc">
<span>读者排行</span>
</div>
<div class="h_widget readers cl">
<?php h_readers($outer=get_option('h_outer'),$timer=get_option('h_timer'),$limit=get_option('h_limit')); ?>
</div>
</div>