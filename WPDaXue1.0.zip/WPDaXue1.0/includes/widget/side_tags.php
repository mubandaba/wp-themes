<div class="t">
<div class="hc">
<span>热门标签</span>
</div>
<div class="sidecon">
<ul class="tagcloudy">
	<li>
	<?php wp_tag_cloud(get_option('h_side_tags_set')); ?>
	</li>
</ul>
</div>
</div>