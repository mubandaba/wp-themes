<div class="t">
<div class="hc">
<span>最新评论</span>
</div>
<div class="sidecon comment-list cl">
	<ul>
	<?php h_comments($outer=get_option('h_outer'),$limit=get_option('h_com_limit')); ?>
	</ul>
</div>
</div>