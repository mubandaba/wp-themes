	<div class="poptip" >
		<span class="poptip-arrow poptip-arrow-left" ><em>◆</em><i>◆</i></span>
		<p><?php echo stripslashes(get_option('h_notice_con')); ?></p>
	</div>