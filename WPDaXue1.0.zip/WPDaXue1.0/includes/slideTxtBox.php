<div class="slideTxtBox t">
	<div class="hd">
		<ul>
			<?php home_category("nav"); ?>
		</ul>
	</div>

	<div class="bd">
		<?php home_category("list"); ?>
	</div>
</div>

