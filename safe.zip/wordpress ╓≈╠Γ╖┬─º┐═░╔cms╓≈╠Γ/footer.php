<!-- 底部开始 -->
<div class="footer">
	<div class="container">
		<div class="f1">
			<p>联系我们 | 关于我们 | 版权声明 | 帮助中心 | 广告服务 | 站点统计 | 举报投诉 | 网站地图</p>
		</div>
		<div class="f2">
			<p>本站专业提供网站模板，网页模板，模板教程，网页制作，程序插件，网站素材等最专业的建站资源，打造专业的模板交流平台！</p>
		</div>
		<div class="f3">
			<p>Copyright @ 2010-2013 安全者 版权所有 Powered By <a href="http://v7v3.com/">wordpress</a>&nbsp;and&nbsp;<a href="http://getbootstrap.com/">BootStrap</a> | <?php echo stripslashes(get_option('cnsecer_icp')); ?> | <?php echo stripslashes(get_option('cnsecer_tongji')); ?></p> 
		</div>
	</div>
</div>
<!-- 底部结束 -->
<?php do_action("wp_footer"); ?>
<?php echo stripslashes(get_option('cnsecer_share')); ?>
</body>
</html>
