<?php
//菜单
   register_nav_menus(
      array(
         'nav-menu' => __( '导航自定义菜单' ),
         'top-menu' => __( '顶部自定义菜单' ),
		 'visit-menu' => __( '顶部右边游客菜单' ),
		 'author-menu' => __( '顶部右登录后菜单' )
      )
   );
 //添加链接页面 rel=nofollow复选框
  function admin_xfn() {
echo '<script type="text/javascript">
addLoadEvent(addNofollowTag);
function addNofollowTag() {
  tables = document.getElementsByTagName(\'table\');
  for(i=0;i<tables.length;i++) {
    if(tables[i].cellPadding=="3" && tables[i].cellSpacing=="5") {
      tr = tables[i].insertRow(0);
      th = document.createElement(\'th\');
      th.setAttribute(\'scope\',\'row\');
      th.appendChild(document.createTextNode(\'允许搜索引擎抓取吗\'));
      td = document.createElement(\'td\');
      tr.appendChild(th);
      label = document.createElement(\'label\');
      input = document.createElement(\'input\');
      input.setAttribute(\'type\',\'checkbox\');
      input.setAttribute(\'id\',\'nofollow\');
      input.setAttribute(\'value\',\'nofollow\');
      label.appendChild(input);
      label.appendChild(document.createTextNode(\' nofollow\'));
      td.appendChild(label);
      tr.appendChild(td);
      input.name = \'nofollow\';
      input.className = \'valinp\';
      if (document.getElementById(\'link_rel\').value.indexOf(\'nofollow\') != -1) {
        input.setAttribute(\'checked\',\'checked\');
      }
      return;
    }
  }
}
</script>';
}
add_action('admin_head','admin_xfn');
//获取二维码的图片地址
function leyar_qrcode($url){
     $home_url=get_template_directory_uri();
     $qrcode_tip="/<img src=\"(.*)\" \/>/";
     $qrcode_link=$home_url.'/includes/qrcode/index.php?url='.$url;
     $qrcode_content=@file_get_contents($qrcode_link);
     preg_match($qrcode_tip,$qrcode_content,$qrcode_pic);
     return $qrcode_pic[1];
}
//去除顶部工具栏
function my_function_admin_bar(){
    return false;
}
add_filter( 'show_admin_bar' , 'my_function_admin_bar');
 //投票系统
 function ludou_simplevote_content($content) {
	global $post;
	$rate = get_post_meta($post->ID, "ludou_ratings_score", true);
	$rate = ($rate == '') ? 0 : $rate;
	$content .= '<div id="useraction">
				<div id="ajax_recommendlink">
					<div title="文章评价指数" id="recommendv">'.$rate.'</div>
					<ul class="recommend_act">
						<li><a onclick="ludou_simple_vote(this, \''.get_bloginfo("wpurl").'\',' . $post->ID . ', 1);" href="javascript:void(0);" id="recommend_add" title="点击支持本文">支持</a></li>
						<li><a onclick="ludou_simple_vote(this, \''.get_bloginfo("wpurl").'\',' . $post->ID.', -1);" href="javascript:void(0);" id="recommend_subtract" title="点击反对本文">反对</a></li>
					</ul>
				</div>
			</div>';
			
	return $content;
}
function ludou_simplevote_head() {
	$css_html = '<link rel="stylesheet" href="' . get_bloginfo("wpurl") . '/wp-content/themes/leyar/includes/ludou-simple-vote/ludou-simple-vote.css' . '" type="text/css" media="screen" />';
	$script_html = '<script type="text/javascript" src="' . get_bloginfo('wpurl') . '/wp-content/themes/leyar/includes/ludou-simple-vote/ludou-simple-vote.js"></script>';
	
	echo "\n" . $css_html . "\n" . $script_html. "\n";
} 
function load_simgplevote() {
	if(is_single()) {
		add_action("wp_head", "ludou_simplevote_head");
		add_filter("the_content", "ludou_simplevote_content");
	}
}
add_action("wp", "load_simgplevote");

 //随机产生一个密码
 function get_password( $length) 
{
    $str = substr(md5(time()), 0, $length);
    return $str;
}
//登陆显示头像
function leyar_get_avatar($email, $size = 48){
return get_avatar($email, $size);
}
//关键词提示
function ls_get_delim($ref) { 
    $search_engines = array(
            'google.com.hk' => 'q',
            'google.com.tw' => 'q',
            'go.google.com' => 'q',
            'google.com' => 'q',
            'cn.bing.com' => 'q',
            'youdao.com'  => 'q',
            'one.cn.yahoo.com' => 'p',  
            'blogsearch.google.com' => 'q',  
			'baidu.com' => 'wd',
			'soso.com'  => 'w',
			'sogou.com'  => 'query'); 
    $delim = false; 
    if (isset($search_engines[$ref])) { 
        $delim = $search_engines[$ref]; 
    }
    else { 
        $sub13 = substr($ref, 0, 13); 
        if(substr($ref, 0, 7) == 'google.') 
            $delim = "q"; 
        elseif($sub13 == 'search.yahoo.') 
            $delim = "p";
    }
   return $delim; 
} 
function ls_get_terms($d) { 
    $terms       = null; 
    $query_array = array(); 
    $query_terms = null; 
    $query = explode('&'.$d.'=', $_SERVER['HTTP_REFERER']); 
    if($query[1] == '') { 
        $query = explode('?'.$d.'=', $_SERVER['HTTP_REFERER']); 
    } 
    $query = explode('&', $query[1]); 
    $query = urldecode($query[0]); 
    $query = str_replace("'", '', $query); 
    $query = str_replace('"', '', $query); 
    $query_array = preg_split('/[\s,\+\.]+/',$query); 
    $query_terms = implode(' ', $query_array); 
    $terms = htmlspecialchars(urldecode($query_terms)); 
		if (!seems_utf8($terms)){
			$terms=iconv("GBK", "UTF-8", $terms);
		}
    return $terms; 
} 
function ls_get_refer() { 
    if (!isset($_SERVER['HTTP_REFERER']) || ($_SERVER['HTTP_REFERER'] == '')) return false; 
    $referer_info = parse_url($_SERVER['HTTP_REFERER']); 
    $referer = $referer_info['host']; 
    if(substr($referer, 0, 4) == 'www.') 
        $referer = substr($referer, 4); 
    return $referer;
}
function ls_related($postid) {    
    $referer = ls_get_refer(); 
    if (!$referer) return 0; 
		global $wpdb;
		$output = '';
		$post_tags = wp_get_post_tags($postid);
		if ($post_tags) {
			foreach ($post_tags as $tag)
			{
    		$tag_list[] .= $tag->term_id;
			}
			$post_tag = $tag_list[ mt_rand(0, count($tag_list) - 1) ];
			$related = $wpdb->get_results("
				SELECT {$wpdb->prefix}posts.post_title, {$wpdb->prefix}posts.guid
				FROM {$wpdb->prefix}posts, {$wpdb->prefix}term_relationships, {$wpdb->prefix}term_taxonomy
				WHERE {$wpdb->prefix}posts.ID = {$wpdb->prefix}term_relationships.object_id
				AND {$wpdb->prefix}term_taxonomy.taxonomy = 'post_tag'
				AND {$wpdb->prefix}term_taxonomy.term_taxonomy_id = {$wpdb->prefix}term_relationships.term_taxonomy_id
				AND {$wpdb->prefix}posts.post_status = 'publish'
				AND {$wpdb->prefix}posts.post_type = 'post'
				AND {$wpdb->prefix}term_taxonomy.term_id = '" . $post_tag . "'
				AND {$wpdb->prefix}posts.ID != '" . $postid . "'
				ORDER BY RAND()
				LIMIT 5");
			if ( $related ) {
    		foreach ($related as $related_post) {
    			$output .= '<li><a href="'.$related_post->guid.'" rel="bookmark" title="'. $related_post->post_title.'">'.$related_post->post_title.'</a></li>';
				}
			}
		} 
    return $output ? $output : 0;
} 
function ls_getinfo($what) {
    $referer = ls_get_refer(); 
    if (!$referer) return false; 
    $delimiter = ls_get_delim($referer); 

    if($delimiter)  
    {  
        $terms = ls_get_terms($delimiter); 
				
        if($what == 'isref') { 
            return true; 
        }
        if($what == 'terms') { 
            if (get_bloginfo('charset') != 'UTF-8') { 
                echo htmlentities($terms, ENT_QUOTES, 'UTF-8'); 
            } else { 
                echo $terms; 
            } 
        } 
    }
}
function refer_thanks()
{
        $myfeed=get_option('swt_rsssub');
		$myurl = parse_url($_SERVER['HTTP_REFERER']);
		$host = $myurl['host'];
		return "<p>欢迎来自 {$host} 的朋友！如果您是第一次来到这里，欢迎&nbsp;<a href='{$myfeed}' target='_blank'>订阅我的博客</a>。精彩文章，一篇都不错过！</p>";
}
//通过微博通同步网站内容到微博
function send_to_wbto($post_ID) {
	$username = get_option('swt_wbto_username');
	$password = get_option('swt_wbto_password');
	$posted = get_post($post_ID);
	$weiboto_cat_name=get_the_category($posted);
	$wbt_cat_name=$weiboto_cat_name[0]->cat_name;
	$wbt_post_content=dm_strimwidth(strip_tags($posted->post_content),0,100,"...");
	$fields = array();
	$fields['source'] = 'wordpress';
	$fields['content'] = urlencode('#'.$wbt_cat_name.'#'.$wbt_post_content.''.$posted->guid);
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "http://wbto.cn/api/update.json");
	curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
	curl_setopt($ch, CURLOPT_FAILONERROR, TRUE);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,TRUE);
	curl_setopt($ch, CURLOPT_TIMEOUT, 10);
	curl_setopt($ch, CURLOPT_POST, TRUE);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
	$result = curl_exec($ch);
	curl_close($ch);  
}
add_action('publish_post', 'send_to_wbto');
//个人资料替换
function my_profile( $contactmethods ) {
    $contactmethods['telephone'] = '电话号码';
	$contactmethods['qqnum'] = 'QQ号码';
	$contactmethods['yyname'] = 'YY帐号';
	$contactmethods['qqt'] = '腾讯微博';
	$contactmethods['sinat'] = '新浪微博';
	$contactmethods['sohut'] = '搜狐微博';
    unset($contactmethods['aim']);
    unset($contactmethods['yim']);
    unset($contactmethods['jabber']);
    return $contactmethods;
}
add_filter('user_contactmethods','my_profile',10);
//后台登陆LOGO替换以及后台登陆LOGO地址替换
function leyar_loginlogo() {
echo '<style type="text/css">
h1 a {background-image: url('.get_bloginfo('template_directory').'/images/logo.png) !important; }
</style>';
}
add_action('login_head', 'leyar_loginlogo');
add_filter( 'login_headerurl', 'leyar_loginlogo_url' );
    function leyar_loginlogo_url($url) {
        return get_option('home');
    }
//添加编辑器快捷按钮
add_action('admin_print_scripts', 'leyar_quicktag');
function leyar_quicktag() {
    wp_enqueue_script(
        'leyar_quicktag',
        get_stylesheet_directory_uri().'/js/leyar_quicktag.js',
        array('quicktags')
    );
    }
//图片演示功能
function leyar_conents_replace($content) {
global $post;
$post_ID = $post->ID;
$picalt = get_post($post_ID)->post_title;
$total_pic_links = explode("\n",stripslashes(get_post_meta($post_ID, "pica_value", true)));
$totla_pic_nums=count($total_pic_links);
for($i=0;$i<$totla_pic_nums;$i++){
     $domo_links_arras.='<td><div><a rel="facebox" title="'.$picalt.'" target="_blank" href="'.$total_pic_links[$i].'"><img style="max-width:650px;max-height:500px;;" alt="'.$picalt.'" src="'.$total_pic_links[$i].'"></a></div></td>';
}
 $domo_links_arrb='<div class="imglist-button"><div class="imglist-center"><a target="_blank" class="colorbox_btn cboxElement" title="'.$picalt.'" href="'.$total_pic_links[0].'" rel="leyar"></a><div class="imglist-dots">';
for($q=1;$q<$totla_pic_nums;$q++){
$domo_links_arrc.='<a target="_blank" title="'.$picalt.'" href="'.$total_pic_links[$q].'" rel="leyar" class="cboxElement"></a>';
}
$domo_links_arrbs=$domo_links_arrb.$domo_links_arrc.'</div></div></div>';
$domo_links='<div class="imglist" id="iscroll0"><table cellpadding="0" cellspacing="0"><tbody><tr align="center">'.$domo_links_arras.'</tr></tbody></table></div>'.$domo_links_arrbs;
$demo_tip='[demopics]';
$content= str_replace($demo_tip, $domo_links, $content);
return $content;
}
add_filter( 'the_content', 'leyar_conents_replace' );
//文章目录
function article_index($content) {
  $matches = array();
    $ul_li = '';
    $r = "/<h3>([^<]+)<\/h3>/im";
   if(preg_match_all($r, $content, $matches)) {
        foreach($matches[1] as $num => $title) {
            $content = str_replace($matches[0][$num], '<h3 id="title-'.$num.'">'.$title.'</h3>', $content);
            $ul_li .= '<li><a href="#title-'.$num.'" title="'.$title.'">'.$title."</a></li>\n";
        }
        $content = "\n<div id=\"article-index\" style=\"background:#ffffff;\">
                <strong>文章目录</strong>
                <ul id=\"index-ul\">\n" . $ul_li . "</ul>
            </div>\n" . $content;
			}
   return $content;
}
add_filter( "the_content", "article_index" );
//自定义区域
if (get_option('swt_picture_power') == 'Display'||get_option('swt_down_power') == 'Display'||get_option('swt_file_power') == 'Display') {
//开启演示图片或相册功能自定义区域
if (get_option('swt_picture_power') == 'Display'&&get_option('swt_down_power') == 'Hide'&&get_option('swt_file_power') == 'Hide') {
$new_meta_boxes =
array(
    "pica" => array(
        "name" => "pica",
        "std" => "",
        "title" => "图片地址，一行一个地址，回车换行【地址要有http:// 没有图片，请务必留空，最多8张】:")
	 );
}
//开启文件信息模块自定义区域
if (get_option('swt_picture_power') == 'Hide'&&get_option('swt_down_power') == 'Hide'&&get_option('swt_file_power') == 'Display') {
$new_meta_boxes =
array(
"fileinfo" => array(
        "name" => "fileinfo",
        "std" => "",
        "title" => "请设置相关信息，一行对应一个信息，回车换行【如果信息为空，请务必留空，最多8个对应信息】<br/>注意对应信息名称，你的设置顺序为:&nbsp;&nbsp;<font color='red'>".get_option('swt_file_info')."</font>&nbsp;&nbsp;如果有对应信息为空，也请换行")
	);
}
//开启下载模块自定义区域
if (get_option('swt_picture_power') == 'Hide'&&get_option('swt_down_power') == 'Display'&&get_option('swt_file_power') == 'Hide') {
$new_meta_boxes =
array(
"thelinks" => array(
        "name" => "thelinks",
        "std" => "",
        "title" => "相关地址，一行一个地址，回车换行【地址要有http:// 没有地址，请务必留空，最多8个】<br/>注意对应链接文本，你的设置顺序为:&nbsp;&nbsp;<font color='red'>".get_option('swt_link_text')."</font>&nbsp;&nbsp;如果有链接文本地址为空，也请换行")
	);
}
//开启图片演示和文件信息模块自定义区域
if (get_option('swt_picture_power') == 'Display'&&get_option('swt_down_power') == 'Hide'&&get_option('swt_file_power') == 'Display') {
$new_meta_boxes =
array(
"pica" => array(
        "name" => "pica",
        "std" => "",
        "title" => "图片地址，一行一个地址，回车换行【地址要有http:// 没有图片，请务必留空，最多8张】:"),
	"fileinfo" => array(
        "name" => "fileinfo",
        "std" => "",
        "title" => "请设置相关信息，一行对应一个信息，回车换行【如果信息为空，请务必留空，最多8个对应信息】<br/>注意对应信息名称，你的设置顺序为:&nbsp;&nbsp;<font color='red'>".get_option('swt_file_info')."</font>&nbsp;&nbsp;如果有对应信息为空，也请换行")
	);
}
//开启图片演示和文件下载模块自定义区域
if (get_option('swt_picture_power') == 'Display'&&get_option('swt_down_power') =='Display'&&get_option('swt_file_power') == 'Hide') {
$new_meta_boxes =
array(
    "pica" => array(
        "name" => "pica",
        "std" => "",
        "title" => "图片地址，一行一个地址，回车换行【地址要有http:// 没有图片，请务必留空，最多8张】:"),	
	"thelinks" => array(
        "name" => "thelinks",
        "std" => "",
        "title" => "相关地址，一行一个地址，回车换行【地址要有http:// 没有地址，请务必留空，最多8个】<br/>注意对应链接文本，你的设置顺序为:&nbsp;&nbsp;<font color='red'>".get_option('swt_link_text')."</font>&nbsp;&nbsp;如果有链接文本地址为空，也请换行")
);
}
//开启文件下载和文件信息模块自定义区域
if (get_option('swt_picture_power') == 'Hide'&&get_option('swt_down_power') == 'Display'&&get_option('swt_file_power') == 'Display') {
$new_meta_boxes =
array(
	"fileinfo" => array(
        "name" => "fileinfo",
        "std" => "",
        "title" => "请设置相关信息，一行对应一个信息，回车换行【如果信息为空，请务必留空，最多8个对应信息】<br/>注意对应信息名称，你的设置顺序为:&nbsp;&nbsp;<font color='red'>".get_option('swt_file_info')."</font>&nbsp;&nbsp;如果有对应信息为空，也请换行"),	
	"thelinks" => array(
        "name" => "thelinks",
        "std" => "",
        "title" => "相关地址，一行一个地址，回车换行【地址要有http:// 没有地址，请务必留空，最多8个】<br/>注意对应链接文本，你的设置顺序为:&nbsp;&nbsp;<font color='red'>".get_option('swt_link_text')."</font>&nbsp;&nbsp;如果有链接文本地址为空，也请换行")
);
}
//开启全部自定义区域
if (get_option('swt_picture_power') == 'Display'&&get_option('swt_down_power') == 'Display'&&get_option('swt_file_power') == 'Display') {
$new_meta_boxes =
array(
    "pica" => array(
        "name" => "pica",
        "std" => "",
        "title" => "图片地址，一行一个地址，回车换行【地址要有http:// 没有图片，请务必留空，最多8张】:"),
	"fileinfo" => array(
        "name" => "fileinfo",
        "std" => "",
        "title" => "请设置相关信息，一行对应一个信息，回车换行【如果信息为空，请务必留空，最多8个对应信息】<br/>注意对应信息名称，你的设置顺序为:&nbsp;&nbsp;<font color='red'>".get_option('swt_file_info')."</font>&nbsp;&nbsp;如果有对应信息为空，也请换行"),	
	"thelinks" => array(
        "name" => "thelinks",
        "std" => "",
        "title" => "相关地址，一行一个地址，回车换行【地址要有http:// 没有地址，请务必留空，最多8个】<br/>注意对应链接文本，你的设置顺序为:&nbsp;&nbsp;<font color='red'>".get_option('swt_link_text')."</font>&nbsp;&nbsp;如果有链接文本地址为空，也请换行")
);
}
//在文章发布/编辑页面创建自定义字段输入框
function new_meta_boxes() {
    global $post, $new_meta_boxes;

    foreach($new_meta_boxes as $meta_box) {
        $meta_box_value = get_post_meta($post->ID, $meta_box['name'].'_value', true);

        if($meta_box_value == "")
            $meta_box_value = $meta_box['std'];
        
        echo'<input type="hidden" name="'.$meta_box['name'].'_noncename" id="'.$meta_box['name'].'_noncename" value="'.wp_create_nonce( plugin_basename(__FILE__) ).'" />';
        // 自定义字段标题
        echo '<h4>'.$meta_box['title'].'</h4>';
        // 自定义字段输入框        
		echo '<textarea cols="137" rows="8" name="'.$meta_box['name'].'_value">'.$meta_box_value.'</textarea>';
    }
}

function create_meta_box() {
    global $theme_name;

    if ( function_exists('add_meta_box') ) {
        add_meta_box( 'new-meta-boxes', '那些我们一起设置过的XX', 'new_meta_boxes', 'post', 'normal', 'high' );
    }
}
//数据库更新
function save_postdata( $post_id ) {
    global $post, $new_meta_boxes;

    foreach($new_meta_boxes as $meta_box) {
        if ( !wp_verify_nonce( $_POST[$meta_box['name'].'_noncename'], plugin_basename(__FILE__) ))  {
            return $post_id;
        }

        if ( 'page' == $_POST['post_type'] ) {
            if ( !current_user_can( 'edit_page', $post_id ))
                return $post_id;
        } 
        else {
            if ( !current_user_can( 'edit_post', $post_id ))
                return $post_id;
        }

        $data = $_POST[$meta_box['name'].'_value'];

        if(get_post_meta($post_id, $meta_box['name'].'_value') == "")
            add_post_meta($post_id, $meta_box['name'].'_value', $data, true);
        elseif($data != get_post_meta($post_id, $meta_box['name'].'_value', true))
            update_post_meta($post_id, $meta_box['name'].'_value', $data);
        elseif($data == "")
            delete_post_meta($post_id, $meta_box['name'].'_value', get_post_meta($post_id, $meta_box['name'].'_value', true));
    }
}

add_action('admin_menu', 'create_meta_box');
add_action('save_post', 'save_postdata');
}
// 去掉评论中链接
remove_filter('comment_text', 'make_clickable', 9);
//评论连接重定向
add_filter('get_comment_author_link', 'add_redirect_comment_link', 5);
add_filter('comment_text', 'add_redirect_comment_link', 99);
function add_redirect_comment_link($text = ''){
	$text=str_replace('href="', 'target="_blank" href="'.get_option('home').'/?u=', $text);
	$text=str_replace("href='", "target='_blank' href='".get_option('home')."/?u=", $text);
	return $text;
}

add_action('init', 'redirect_comment_link');
function redirect_comment_link(){
	$redirect = $_GET['u'];
	if($redirect){
		if(strpos($_SERVER['HTTP_REFERER'],get_option('home')) !== false){
			header("Location: $redirect");
			exit;
		}
		else {
			header("Location: http://www.itluren.com/");
			exit;
		}
	}
	
}
//回复链接加上nofollow
function custom_comment_reply_link_nofollow( $link ) {
	global $user_ID;
	if ( get_option( 'comment_registration' ) && ! $user_ID )
		return $link;
	else
		return str_replace( '")\'>', '")\' rel=\'nofollow\'>', $link );
}
add_filter( 'comment_reply_link', 'custom_comment_reply_link_nofollow' );
//评论替换 文明骂人
function dali_conents_replace($incoming_comment) {
$words = get_option('swt_comword');
$rules = explode('||', $words);
foreach($rules as $rule) {
$word = explode('->', trim($rule));
if(isset($word[1]))
$incoming_comment['comment_content'] = str_replace(trim($word[0]), trim($word[1]), $incoming_comment['comment_content']);
}
return $incoming_comment;
}
add_filter( 'preprocess_comment', 'dali_conents_replace' );
//注册小工具
if (function_exists('register_sidebar'))
{
    register_sidebar(array(
		'name'			=> '首页小工具1',
        'before_widget'	=> '<div class="con_box hot_box">',
        'before_title'	=> '<h3 style="color:#ffffff;">',
        'after_title'	=> '</h3>',
    	'after_widget' => '</div>',
    ));
}
{
    register_sidebar(array(
		'name'			=> '首页小工具2',
        'before_widget'	=> '<div class="con_box hot_box">',
        'before_title'	=> '<h3 style="color:#ffffff;">',
        'after_title'	=> '</h3>',
    	'after_widget' => '</div>',
    ));
}
{
    register_sidebar(array(
		'name'			=> '全部页面小工具',
       'before_widget'	=> '<div class="con_box hot_box">',
        'before_title'	=> '<h3 style="color:#ffffff;">',
        'after_title'	=> '</h3>',
    	'after_widget' => '</div>',
    ));
}
{
    register_sidebar(array(
		'name'			=> '非首页小工具',
       'before_widget'	=> '<div class="con_box hot_box">',
        'before_title'	=> '<h3 style="color:#ffffff;">',
        'after_title'	=> '</h3>',
    	'after_widget' => '</div>',
    ));
}
//截字
function dm_strimwidth($str ,$start , $width ,$trimmarker ){$output = preg_replace('/^(?:[\x00-\x7F]|[\xC0-\xFF][\x80-\xBF]+){0,'.$start.'}((?:[\x00-\x7F]|[\xC0-\xFF][\x80-\xBF]+){0,'.$width.'}).*/s','\1',$str); return $output.$trimmarker;};
//文章标题截取
function cut_str($src_str,$cut_length){$return_str='';$i=0;$n=0;$str_length=strlen($src_str);
    while (($n<$cut_length) && ($i<=$str_length))
    {$tmp_str=substr($src_str,$i,1);$ascnum=ord($tmp_str);
		if ($ascnum>=224){$return_str=$return_str.substr($src_str,$i,3); $i=$i+3; $n=$n+2;}
        elseif ($ascnum>=192){$return_str=$return_str.substr($src_str,$i,2);$i=$i+2;$n=$n+2;}
        elseif ($ascnum>=65 && $ascnum<=90){$return_str=$return_str.substr($src_str,$i,1);$i=$i+1;$n=$n+2;}
        else {$return_str=$return_str.substr($src_str,$i,1);$i=$i+1;$n=$n+1;}
    }
    if ($i<$str_length){$return_str = $return_str . '...';}
    if (get_post_status() == 'private'){ $return_str = $return_str . '（private）';}
    return $return_str;};
// 获取当前页链接
function curPageURL() {$pageURL = 'http';
    if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
    $pageURL .= "://";$this_page = $_SERVER["REQUEST_URI"];
    if (strpos($this_page, "?") !== false) $this_page = reset(explode("?", $this_page));
    if ($_SERVER["SERVER_PORT"] != "80") {$pageURL .= $_SERVER["SERVER_NAME"] . ":" .$_SERVER["SERVER_PORT"] . $this_page;} 
    else {$pageURL .= $_SERVER["SERVER_NAME"] . $this_page;}
    return $pageURL;};
//支持外链缩略图
if ( function_exists('add_theme_support') )
 add_theme_support('post-thumbnails');
 add_image_size('cms_featured', 100, 80, true);
 add_image_size('box_featured', 350, 150, true);
 add_image_size('slider_featured', 690, 296, true);
function catch_first_image() {global $post, $posts;$first_img = '';
	ob_start();
	ob_end_clean();
	$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
	$first_img = $matches [1] [0];
	if(empty($first_img)){$random = mt_rand(1, 3);
		echo get_bloginfo ( 'stylesheet_directory' );
		echo '/images/random/'.$random.'.jpg';}
  return $first_img;};
//自定义头像
add_filter( 'avatar_defaults', 'fb_addgravatar' );
function fb_addgravatar( $avatar_defaults ) {
$myavatar = get_bloginfo('template_directory') . '/images/gravatar.png';
$avatar_defaults[$myavatar] = '自定义头像';
return $avatar_defaults;};
//评论回复/头像缓存
function weisay_comment($comment, $args, $depth) {$GLOBALS['comment'] = $comment;
	global $commentcount,$wpdb, $post;
     if(!$commentcount) { 
          $comments = $wpdb->get_results("SELECT * FROM $wpdb->comments WHERE comment_post_ID = $post->ID AND comment_type = '' AND comment_approved = '1' AND !comment_parent");
          $cnt = count($comments);
          $page = get_query_var('cpage');
          $cpp=get_option('comments_per_page');
         if (ceil($cnt / $cpp) == 1 || ($page > 1 && $page  == ceil($cnt / $cpp))) {
             $commentcount = $cnt + 1;
         } else {$commentcount = $cpp * $page + 1;}
     }
?>
<li <?php comment_class(); ?> id="comment-<?php comment_ID() ?>">
   <div id="div-comment-<?php comment_ID() ?>" class="comment-body">
      <?php $add_below = 'div-comment'; ?>
		<div class="comment-author vcard"><?php if (get_option('swt_type') == 'Display') { ?>
			<?php
				$p = 'avatar/';
				$f = md5(strtolower($comment->comment_author_email));
				$a = $p . $f .'.jpg';
				$e = ABSPATH . $a;
				if (!is_file($e)){ 
				$d = get_bloginfo('wpurl'). '/avatar/default.jpg';
				$s = '40'; 
				$r = get_option('avatar_rating');
				$g = 'http://www.gravatar.com/avatar/'.$f.'.jpg?s='.$s.'&d='.$d.'&r='.$r;
                $avatarContent = file_get_contents($g);
                file_put_contents($e, $avatarContent);
				if ( filesize($e) == 0 ){ copy($d, $e); }
				};
			?>
			<img src='<?php bloginfo('wpurl'); ?>/<?php echo $a ?>' alt='' class='avatar' />
                <?php { echo ''; } ?>
			<?php } else { include(TEMPLATEPATH . '/comment_gravatar.php'); } ?>
	<div class="floor">
	<?php 
	if(!$parent_id = $comment->comment_parent){switch ($commentcount){
     case 2 :echo "沙发";--$commentcount;break;
     case 3 :echo "板凳";--$commentcount;break;
     case 4 :echo "地板";--$commentcount;break;
     default:printf('%1$s楼', --$commentcount);}}
	?>
	</div>
	<strong><?php comment_author_link() ?></strong>:<?php edit_comment_link('编辑','&nbsp;&nbsp;',''); ?></div>
	<?php if ( $comment->comment_approved == '0' ) : ?>
		<span style="color:#C00; font-style:inherit">您的评论正在等待审核中...</span>
		<br />			
		<?php endif; ?>
		<?php comment_text() ?>
		<div class="clear"></div><span class="datetime"><?php comment_date('Y-m-d') ?> <?php comment_time() ?> </span> <span class="reply"><?php comment_reply_link(array_merge( $args, array('reply_text' => '[回复]', 'add_below' =>$add_below, 'depth' => $depth, 'max_depth' => $args['max_depth']))); ?></span>
  </div>
<?php
}
function weisay_end_comment() {echo '</li>';};
//登陆显示头像
function weisay_get_avatar($email, $size = 48){
return get_avatar($email, $size);
};
//自定义表情地址
function custom_smilies_src($src, $img){return get_bloginfo('template_directory').'/images/smilies/' . $img;}
add_filter('smilies_src', 'custom_smilies_src', 10, 2);
//导航分页
function par_pagenavi($range = 9){
	global $paged, $wp_query;
	if ( !$max_page ) {$max_page = $wp_query->max_num_pages;}
	if($max_page > 1){if(!$paged){$paged = 1;}
	if($paged != 1){echo "<a href='" . get_pagenum_link(1) . "' class='extend' title='跳转到首页'> 返回首页 </a>";}
	previous_posts_link(' 上一页 ');
    if($max_page > $range){
		if($paged < $range){for($i = 1; $i <= ($range + 1); $i++){echo "<a href='" . get_pagenum_link($i) ."'";
		if($i==$paged)echo " class='current'";echo ">$i</a>";}}
    elseif($paged >= ($max_page - ceil(($range/2)))){
		for($i = $max_page - $range; $i <= $max_page; $i++){echo "<a href='" . get_pagenum_link($i) ."'";
		if($i==$paged)echo " class='current'";echo ">$i</a>";}}
	elseif($paged >= $range && $paged < ($max_page - ceil(($range/2)))){
		for($i = ($paged - ceil($range/2)); $i <= ($paged + ceil(($range/2))); $i++){echo "<a href='" . get_pagenum_link($i) ."'";if($i==$paged) echo " class='current'";echo ">$i</a>";}}}
    else{for($i = 1; $i <= $max_page; $i++){echo "<a href='" . get_pagenum_link($i) ."'";
    if($i==$paged)echo " class='current'";echo ">$i</a>";}}
	next_posts_link(' 下一页 ');
    if($paged != $max_page){echo "<a href='" . get_pagenum_link($max_page) . "' class='extend' title='跳转到最后一页'> 最后一页 </a>";}}
};
//读者排行
function leyar_readers($out,$timer,$limit){
	global $wpdb;    
	$counts = $wpdb->get_results("SELECT COUNT(comment_author) AS cnt, comment_author,comment_author_url,comment_author_email FROM {$wpdb->prefix}comments WHERE comment_date > date_sub( NOW(), INTERVAL $timer MONTH ) AND comment_approved = '1' AND comment_author_email AND comment_author_url != '".$out."' AND comment_type = ''  AND user_id = '0' GROUP BY comment_author ORDER BY cnt DESC LIMIT $limit");      
	foreach ($counts as $count) {
            $c_url = $count->comment_author_url;
			if ($c_url == '') $c_url = 'javascript:;';
            $mostactive .= '<a style="margin-bottom:5px;" rel="nofollow" href="'. $c_url . '" title="' . $count->comment_author .' 留下 '. $count->cnt . ' 个脚印" target="_blank">' . get_avatar($count->comment_author_email, 48, '', $count->comment_author . ' 留下 ' . $count->cnt . ' 个脚印') . '</a>';
        }
        echo $mostactive;
    } 
//侧边栏最新评论
function r_comments($outer){
	global $wpdb;
	$sql = "SELECT DISTINCT ID, post_title, post_password, comment_ID, comment_post_ID, comment_author, comment_date_gmt, comment_approved, comment_type,comment_author_url,comment_author_email, SUBSTRING(comment_content,1,16) AS com_excerpt FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID = $wpdb->posts.ID) WHERE comment_approved = '1' AND comment_type = '' AND post_password = '' AND user_id='0' AND comment_author != '".$outer."' ORDER BY comment_date_gmt DESC LIMIT 5";
	$comments = $wpdb->get_results($sql);
	$output = $pre_HTML;
	foreach ($comments as $comment) {$output .= "\n<li>".get_avatar( $comment, 32,'',$comment->comment_author)." <a href=\"" . get_permalink($comment->ID) ."#comment-" . $comment->comment_ID . "\" title=\"发表在： " .$comment->post_title . "\">" .strip_tags($comment->comment_author).":<br/>". strip_tags($comment->com_excerpt)."</a><br /></li>";}
	$output .= $post_HTML;
	$output = convert_smilies($output);
	echo $output;
};
//首页友情链接调用
function leyar_index_links($link_type="txt",$get_total=0) {
	global $wpdb;
	$link_select = ($link_type == "txt") ? " = ''" : " != ''";
	$get_total = ($get_total != 0) ? "LIMIT $get_total" : "";
	$request = "SELECT link_id, link_url, link_name, link_image, link_target, link_description, link_visible, link_rating FROM $wpdb->links ";
	$request .= " WHERE $wpdb->links.link_visible = 'Y' AND $wpdb->links.link_notes = '首页链接' AND $wpdb->links.link_image $link_select ";
	$request .= " ORDER BY link_rating DESC, link_id ASC $get_total";
	$links = $wpdb->get_results($request);
	foreach ($links as $link) { //调用菜单
		$output = '';
		if ($link_type == "txt") $output .= '<a target="'.$link->link_target.'" title="'.$link->link_description.'" href="'.$link->link_url.'">'.$link->link_name.'</a>';
		else $output .= '<a target="'.$link->link_target.'" title="'.$link->link_description.'" href="'.$link->link_url.'"><img src="'.$link->link_image.'" alt="'.$link->link_name.'"></a>';
		$output .= ''."\n";
		echo $output;
	}
};

//标签
function colorCloud($text) {$text = preg_replace_callback('|<a (.+?)>|i','colorCloudCallback', $text);return $text;}
function colorCloudCallback($matches) {
	$text = $matches[1];
	$color = dechex(rand(0,0));
	$pattern = '/style=(\'|\”)(.*)(\'|\”)/i';
	$text = preg_replace($pattern, "style=\"color:#{$color};$2;\"", $text);
	return "<a $text>";}
add_filter('wp_tag_cloud', 'colorCloud', 1);
// 垃圾评论拦截
class anti_spam {
  function anti_spam() {
    if ( !current_user_can('level_0') ) {
      add_action('template_redirect', array($this, 'w_tb'), 1);
      add_action('init', array($this, 'gate'), 1);
      add_action('preprocess_comment', array($this, 'sink'), 1);
    }
  }
  function w_tb() {
    if ( is_singular() ) {
      ob_start(create_function('$input','return preg_replace("#textarea(.*?)name=([\"\'])comment([\"\'])(.+)/textarea>#",
      "textarea$1name=$2w$3$4/textarea><textarea name=\"comment\" cols=\"100%\" rows=\"4\" style=\"display:none\"></textarea>",$input);') );
    }
  }
  function gate() {
    if ( !empty($_POST['w']) && empty($_POST['comment']) ) {
      $_POST['comment'] = $_POST['w'];
    } else {
      $request = $_SERVER['REQUEST_URI'];
      $referer = isset($_SERVER['HTTP_REFERER'])         ? $_SERVER['HTTP_REFERER']         : '隐瞒';
      $IP      = isset($_SERVER["HTTP_X_FORWARDED_FOR"]) ? $_SERVER["HTTP_X_FORWARDED_FOR"] . ' (透过代理)' : $_SERVER["REMOTE_ADDR"];
      $way     = isset($_POST['w'])                      ? '手动操作'                       : '未经评论表格';
      $spamcom = isset($_POST['comment'])                ? $_POST['comment']                : null;
      $_POST['spam_confirmed'] = "请求: ". $request. "\n来路: ". $referer. "\nIP: ". $IP. "\n方式: ". $way. "\n內容: ". $spamcom. "\n -- 记录成功 --";
    }
  }
  function sink( $comment ) {
    if ( !empty($_POST['spam_confirmed']) ) {
      if ( in_array( $comment['comment_type'], array('pingback', 'trackback') ) ) return $comment;
      //方法一: 直接挡掉, 將 die(); 前面两斜线刪除即可.
      die();
      //方法二: 标记为 spam, 留在资料库检查是否误判.
      //add_filter('pre_comment_approved', create_function('', 'return "spam";'));
      //$comment['comment_content'] = "[ 小墙判断这是 Spam! ]\n". $_POST['spam_confirmed'];
    }
    return $comment;
  }
}
$anti_spam = new anti_spam();
//评论邮件提醒
function comment_mail_notify($comment_id) {
  $comment = get_comment($comment_id);
  $parent_id = $comment->comment_parent ? $comment->comment_parent : '';
  $spam_confirmed = $comment->comment_approved;
  if (($parent_id != '') && ($spam_confirmed != 'spam')) {
    $wp_email = 'itluren@' . preg_replace('#^www\.#', '', strtolower($_SERVER['SERVER_NAME'])); //e-mail 发出点, no-reply 可改为可用的 e-mail.
    $to = trim(get_comment($parent_id)->comment_author_email);
    $subject = '您在 [' . get_option("blogname") . '] 的留言有了回复';
    $message = '
    <div style="background-color:#eef2fa; border:1px solid #d8e3e8; color:#111; padding:0 15px; -moz-border-radius:5px; -webkit-border-radius:5px; -khtml-border-radius:5px;">
      <p>' . trim(get_comment($parent_id)->comment_author) . ', 您好!</p>
      <p>您曾在《' . get_the_title($comment->comment_post_ID) . '》的留言:<br />'
       . trim(get_comment($parent_id)->comment_content) . '</p>
      <p>' . trim($comment->comment_author) . ' 给您的回复:<br />'
       . trim($comment->comment_content) . '<br /></p>
      <p>您可以点击 <a href="' . htmlspecialchars(get_comment_link($parent_id)) . '">查看回复完整內容</a></p>
      <p>欢迎再度光临 <a href="' . get_option('home') . '">' . get_option('blogname') . '</a></p>
      <p>(由于服务器原因,我是不能收到您直接回复的邮件的,如果您还有问题,就到我的网站进行留言.)</p>
    </div>';
    $from = "From: \"" . get_option('blogname') . "\" <$wp_email>";
    $headers = "$from\nContent-Type: text/html; charset=" . get_option('blog_charset') . "\n";
    wp_mail( $to, $subject, $message, $headers );
    //echo 'mail to ', $to, '<br/> ' , $subject, $message; // for testing
  }
}
add_action('comment_post', 'comment_mail_notify');
//访问计数
function record_visitors(){
	if (is_singular()) {global $post;
	 $post_ID = $post->ID;
	  if($post_ID) 
	  {
		  $post_views = (int)get_post_meta($post_ID, 'views', true);
		  if(!update_post_meta($post_ID, 'views', ($post_views+1))) 
		  {
			add_post_meta($post_ID, 'views', 1, true);
		  }
	  }
	}
}
add_action('wp_head', 'record_visitors');  
function post_views($before = '(点击 ', $after = ' 次)', $echo = 1)
{
  global $post;
  $post_ID = $post->ID;
  $views = (int)get_post_meta($post_ID, 'views', true);
  if ($echo) echo $before, number_format($views), $after;
  else return $views;
};
// 文章末加版权Feed
function insertFootNote($content) {
	if(is_feed()) {
		$wzbt = get_the_title();
		$wzlj = get_permalink($post->ID);
		$content.= '<p>';
		$content.= '<span style="font-weight:bold;text-shadow:0 1px 0 #ddd;">声明:</span> 本文采用 <a rel="nofollow" href="http://creativecommons.org/licenses/by-nc-sa/3.0/" title="署名-非商业性使用-相同方式共享">BY-NC-SA</a> 协议进行授权 | <a href="'.home_url().'">'.get_bloginfo('name').'</a>';
		$content.= '<br />转载请注明转自《<a rel="bookmark" title="' . $wzbt . '" href="' . $wzlj . '">' . $wzbt . '</a>》';
		$content.= '</p>';
	}
	return $content;
}
add_filter ('the_content', 'insertFootNote');
//不准内页页面相互ping
function no_self_ping( &$links ) {
	$home = get_option( 'home' );
	foreach ( $links as $l => $link )
	if ( 0 === strpos( $link, $home ) )
	unset($links[$l]);
	}
add_action( 'pre_ping', 'no_self_ping' );
//自动保存
function no_autosave() {
  wp_deregister_script('autosave');
}
add_action( 'wp_print_scripts', 'no_autosave' );
//隐藏版本更新提示
add_filter('pre_site_transient_update_core', create_function('$a', "return null;"));
//过滤代码的中文符号
remove_filter('the_content', 'wptexturize');
//移除顶部多余信息
function wpbeginner_remove_version() { 
return ; 
} add_filter('the_generator', 'wpbeginner_remove_version');//wordpress的版本号 
remove_action('wp_head', 'index_rel_link');//当前文章的索引 
remove_action('wp_head', 'feed_links_extra', 3);// 额外的feed,例如category, tag页 
remove_action('wp_head', 'start_post_rel_link', 10, 0);// 开始篇 
remove_action('wp_head', 'parent_post_rel_link', 10, 0);// 父篇 
remove_action('wp_head', 'adjacent_posts_rel_link', 10, 0); // 上、下篇. 
remove_action('wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0 );//rel=pre
remove_action('wp_head', 'wp_shortlink_wp_head', 10, 0 );//rel=shortlink 
remove_action('wp_head', 'rel_canonical' ); 
wp_deregister_script('l10n'); 
//导入主题配置文件
include("includes/ramdom-word.php");
include("includes/theme_options.php");
include("includes/shortcode.php");
//所有设置结束
?>