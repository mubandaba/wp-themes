<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
	<title><?php if (is_home() ) {?><?php bloginfo('name'); ?> - <?php bloginfo('description'); ?><?php } else {?><?php wp_title('&laquo;', true, 'right'); ?> <?php bloginfo('name'); ?> <?php } ?></title>
<?php
if (is_home())
	{
	$description = get_option('swt_description');
	$keywords = get_option('swt_keywords');
	}
	elseif (is_tag())
	{
	$description = tag_description();
    $keywords = single_tag_title('', false);
	}
	elseif (is_single())
	{
     if ($post->post_excerpt) {$description = $post->post_excerpt;} 
	 else {$description = substr(strip_tags($post->post_content),0,240);}
    $keywords = "";
    $tags = wp_get_post_tags($post->ID);
    foreach ($tags as $tag ) {$keywords = $keywords . $tag->name . ", ";}
	}
?>
    <?php include('includes/leyar_seo.php'); ?>
	<meta name="keywords" content="<?=$keywords?>" />
	<meta name="description" content="<?=$description?>" />
	<link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="http://lib.sinaapp.com/js/jquery/1.4.2/jquery.min.js"></script>
	<script type="text/javascript">window.jQuery || document.write('<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.js">\x3C/script>')</script>
	<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/index/jquery_leyar.js.php"></script>
	<?php if ( is_home() ){ ?>
	<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.cycle.all.min.js"></script>
	<?php } ?>
	<script type="text/javascript">HcmsLazyload("<?php bloginfo('template_url'); ?>/images/space.gif");</script> 
	<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/ramdom-word.js"></script>
	<?php if(is_single()){ ?>
                      <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/leyar_demopic/colorbox.css">
					  <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/leyar_demopic/jquery.lightbox-0.5.min.js.php"></script>
					  <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/leyar_demopic/jquery.lightbox-0.5.css">
					  <script type="text/javascript">$(function() {$("a[rel*=facebox]").lightBox();});</script>
					  <script type="text/javascript">$(function() {$("a[rel*=leyar]").lightBox();});</script>
					   <script type="text/javascript">$(function() {$("a[id*=leyar_qrcode]").lightBox();});</script>
                      <?php } ?>
      	<?php if ( is_home() ){ ?>
	<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/index_tabjs.js"></script>
        <?php } ?>
	<script type=text/javascript>
$(function(){$('#webmenu li').hover(function(){$(this).children('ul').stop(true,true).show('slow');},function(){$(this).children('ul').stop(true,true).hide('slow');});$('#webmenu li').hover(function(){$(this).children('div').stop(true,true).show('slow');},function(){$(this).children('div').stop(true,true).hide('slow');});});
</script>
	<!--[if IE 6]>
	<link href="<?php bloginfo('template_url'); ?>/ie6.css" rel="stylesheet" type="text/css" />
	<script src="http://letskillie6.googlecode.com/svn/trunk/letskillie6.zh_CN.pack.js"></script>
	<script src="<?php bloginfo('template_url'); ?>/js/PNG.js"></script>
	<script>DD_belatedPNG.fix('.png_bg');</script>
	<![endif]-->
	<link rel="shortcut icon" href="<?php bloginfo('url'); ?>/favicon.ico"/>
	<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name'); ?> Atom Feed" href="<?php bloginfo('atom_url'); ?>" />
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<?php wp_head(); ?>
</head>
<body>
<div id="navigation"><div id="container_nav"><?php include('includes/topnv_extend.php'); ?></div></div>
	<div id="header" class="png_bg">
		<div id="header_inner">
		  <div id="dh_say_content" class="left" style="max-width:500px;margin:4px 0 0px 0;color:#000000;height:25px;position:absolute;top:75px;left:280px;z-index:9999;overflow:hidden;">
		<p id="dh_say" title="点击可查看下一条"><?php dh_say();?></p>
	</div>
	   <div class="followBtn">
			<a rel="nofollow" target="_blank" href="http://wpa.qq.com/msgrd?V=1&Menu=yes&Uin=<?php echo stripslashes(get_option('swt_qq')); ?>" title="有急事请Q我"><img src="<?php bloginfo('template_url'); ?>/images/qqnum.png" alt="有急事请Q我"></a>			
			<a rel="nofollow" target="_blank" href="<?php echo stripslashes(get_option('swt_qqmblog')); ?>" title="收听我的腾讯微博"><img src="<?php bloginfo('template_url'); ?>/images/qqweibo.jpg" alt="收听我的腾讯微博"></a>
			<a rel="nofollow" target="_blank" href="<?php echo stripslashes(get_option('swt_sinamblog')); ?>" title="收听我的新浪微博"><img src="<?php bloginfo('template_url'); ?>/images/sinaweibo.jpg" alt="收听我的新浪微博"></a>
			<a rel="nofollow" target="_blank" href="<?php echo stripslashes(get_option('swt_twitter')); ?>" title="收听我的Twitter微博"><img src="<?php bloginfo('template_url'); ?>/images/twitter.png" alt="收听我的Twitter微博"></a>
			<a rel="nofollow" target="_blank" href="mailto:<?php echo stripslashes(get_option('swt_email')); ?>" title="发邮件给我"><img src="<?php bloginfo('template_url'); ?>/images/emailme.png" alt="发邮件给我"></a>
			<a rel="nofollow" target="_blank" href="<?php echo get_option('swt_rsssub'); ?>" title="通过RSS订阅我的博客"><img src="<?php bloginfo('template_url'); ?>/images/rssdy.png" alt="通过RSS订阅我的博客"></a>
</div>
    		<strong class="logo">
			<a href="<?php bloginfo('url'); ?>" class="png_bg" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a>
			</strong>
       <div class="header_bg png_bg"></div>
       <div class="toplinks">
       <div id="_userlogin" style="display:none;">	
			<a href="http://www.itluren.com" target="_blank">IT路人</a>
       </div>
       	<div id="top_nav">
			<?php if(stripslashes(get_option('swt_leyar_top_ad'))!=''){?><?php echo stripslashes(get_option('swt_leyar_top_ad')); ?><?php } ?>
            </div>
       </div>
	   <?php wp_nav_menu('theme_location=nav-menu&container_id=webmenu'); ?>
	   <div class="clearfix"></div>
    </div>
</div>