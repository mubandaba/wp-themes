<?php
/*
Template Name:投稿页面
*/
?>
<?php
if( isset($_POST['tougao_form']) && $_POST['tougao_form'] == 'send')
{   global $wpdb;
    $last_post = $wpdb->get_var("SELECT post_date FROM $wpdb->posts WHERE post_type = 'post' ORDER BY post_date DESC LIMIT 1");
    if ( current_time('timestamp') - strtotime($last_post) < 300 )
    {
        wp_die('您投稿也太勤快了吧，先歇会儿！');
    }
    $name = isset( $_POST['tougao_authorname'] ) ? trim(htmlspecialchars($_POST['tougao_authorname'], ENT_QUOTES)) : '';
    $email =  isset( $_POST['tougao_authoremail'] ) ? trim(htmlspecialchars($_POST['tougao_authoremail'], ENT_QUOTES)) : '';
    $blog =  isset( $_POST['tougao_authorblog'] ) ? trim(htmlspecialchars($_POST['tougao_authorblog'], ENT_QUOTES)) : '';
    $title =  isset( $_POST['tougao_title'] ) ? trim(htmlspecialchars($_POST['tougao_title'], ENT_QUOTES)) : '';
    $category =  isset( $_POST['cat'] ) ? (int)$_POST['cat'] : 0;
    $content =  isset( $_POST['tougao_content'] ) ? trim(htmlspecialchars($_POST['tougao_content'], ENT_QUOTES)) : '';
	$posted_cat=get_category($category);
    if ( empty($name) || mb_strlen($name) > 20 )
    {
        wp_die('昵称必须填写，且长度不得超过20字');
    }
    if ( empty($email) || strlen($email) > 60 || !preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix", $email))
    {
        wp_die('Email必须填写，且长度不得超过60字，必须符合Email格式');
    }
    if ( empty($title) || mb_strlen($title) > 100 )
    {
        wp_die('标题必须填写，且长度不得超过100字');
    }
    if ( empty($content) || mb_strlen($content) > 3000 || mb_strlen($content) < 100)
    {
        wp_die('内容必须填写，且长度不得超过3000字，不得少于100字');
    }
    $post_content = '昵称: '.$name.'<br/>Email: '.$email.'<br/>blog: '.$blog.'<br/>内容:<br/>'.$content;
	$post_notice_content='昵称: '.$name.'，文章标题：《'.$title.'》，内容摘要:'.dm_strimwidth(strip_tags($content),0,300,"...");
    $tougao = array(
        'post_title' => $title,
        'post_content' => $post_content,
        'post_category' => array($category)
    );
   require_once(ABSPATH . WPINC . '/registration.php');

$user_id = username_exists( $name );

if(!$user_id) {
    if(mb_strlen($name,"utf-8") != strlen($name) || email_exists($email))
        wp_die('用户名含有非英文字符，或者Email已被注册！');
    $password = get_password(10);
    $user_id = wp_create_user( $name, $password, $email );
    wp_update_user( array ('ID' => $user_id, 'user_url' => $blog, 'role' => 'contributor' ) ) ;
}
$myhome_url=get_bloginfo( 'home' );
$post_user_content="恭喜您已经投稿成功，另外，系统已经自动帮您在".get_bloginfo( 'name' )."注册了一个帐号，用户名是：".$name."，密码是：".$password."，请点击链接登录修改您的密码:".$myhome_url;
$tougao['post_author'] = $user_id;
$status = wp_insert_post( $tougao );
    if ($status != 0) 
    { 
        wp_mail(get_bloginfo('admin_email'),"你的站点上有访客投稿，请快点审核",$post_notice_content);
		wp_mail($email,"恭喜您投稿成功！",$post_user_content);
        wp_die('投稿成功，感谢投稿，已经通知管理员审核，请耐心等待！系统已经自动为您注册一个帐号！帐号：'.$name.'，密码：'.$password.'，请<a href="'.$myhome_url.'">点击此处</a>，返回首页，登录修改您的密码！', '投稿成功');
    }
    else
    {
        wp_die('投稿失败！请联系管理员，或者使用其他方式投稿');
    }
}
?>
<?php get_header(); ?>	
<div id="wrapper" class="clearfix">
	<div id="breadcrumbs" class="con_box clearfix">
		<div class="bcrumbs"><strong><a href="<?php bloginfo('home'); ?>" title="返回首页">home</a></strong>
		<a><?php the_title(); ?></a>
		</div>
	</div>
 	<div id="art_container clearfix">
 		<div id="art_main1" class="art_white_bg fl"> 
			<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
         	<div class="article_content">
				<h2>投稿提交<b style="color:#D1263F">(红色部分是必填项目)</b></h2>
			<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
    <div style="width:50%;float:left;">
	<div style="text-align: left; padding-top: 10px;">
        <label for="tougao_authorname" style='color:red;'>您的昵称:</label>
        <input type="text" size="40" value="" id="tougao_authorname" name="tougao_authorname" />
    </div>

    <div style="text-align: left; padding-top: 10px;">
        <label for="tougao_authoremail" style='color:red;'>邮箱地址:</label>
        <input type="text" size="40" value="" id="tougao_authoremail" name="tougao_authoremail" />
    </div>
                    
    <div style="text-align: left; padding-top: 10px;">
        <label for="tougao_authorblog">您的网址:</label>
        <input type="text" size="40" value="" id="tougao_authorblog" name="tougao_authorblog" />
    </div>

    <div style="text-align: left; padding-top: 10px;">
        <label for="tougao_title" style='color:red;'>文章标题:</label>
        <input type="text" size="40" value="" id="tougao_title" name="tougao_title" />
    </div>

    <div style="text-align: left; padding-top: 10px;">
        <label for="tougaocategorg" style='color:red;'>文章分类:</label>
        <?php wp_dropdown_categories('id=tougaocategorg&show_count=1&hierarchical=1'); ?>
    </div>
	</div>
	<div style="width:50%;float:right;overflow:hidden;word-break: break-word; word-wrap: break-word;white-space: -moz-pre-wrap; white-space: -hp-pre-wrap;white-space: -o-pre-wrap;white-space: -pre-wrap;white-space: pre;white-space: pre-wrap;white-space: pre-line;"><?php the_content(); ?></div>
                    
    <div style="text-align: left; padding-top: 10px;">
        <textarea style="margin-top:20px;" rows="15" cols="110" id="tougao_content" name="tougao_content">请输入文章内容……</textarea>
    </div>
                    
    <br clear="all">
    <div style="text-align: center; padding-top: 10px;">
        <input type="hidden" value="send" name="tougao_form" />
        <input type="submit" value="提交" />
        <input type="reset" value="重填" />
    </div>
</form>
			</div>       
                       
			</div><!--内容-->

			<?php endwhile; ?>

	</div>
		<div class="clear"></div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>