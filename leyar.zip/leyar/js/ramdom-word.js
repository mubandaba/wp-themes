﻿var dh_say_click='#dh_say';
var dh_say_content='#dh_say_content';
$(document).ready(function dh_say_ajax(){
	$(dh_say_click).click(function() {
		var z = $(this).attr("href");
		$.ajax({
			url: "",
			type:"POST",
			data:"action=dh_say_ajax",
			beforeSend:function()
			{
				document.body.style.cursor = 'wait';	
				//$(dh_say_content).html('<a>载入中...</a>');
				//$("#dh_say").animate({right:"300px"});
				//$("#dh_say").hide('slow');
				$("#dh_say").fadeTo("slow",0.00);
			},
			error: function(request) 
			{
				alert(request.responseText);
			},			
			success: function (data)
			{
				//$(dh_say_content).hide('slow');
				//alert(data);
				$("#dh_say").html(data);
				$("#dh_say").fadeTo("slow",1);
				document.body.style.cursor = 'auto';
				//dh_say_ajax();//翻页后DOM变化了,需要重新绑定函数
				//$(dh_say_content).show('fast');
			}
		});
		return false;
		});
})