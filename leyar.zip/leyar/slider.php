<div id="slideshow">
<div class="slideshow">
	<div id="featured_tag"></div>
	<div id="tag_c"></div>
	<div id="slider_nav"></div>
	<div id="slider" class="clearfix">
		<?php if (get_option('swt_sliders') == '特定分类的文章') { ?>
		<?php include(TEMPLATEPATH . '/includes/cat_slider.php'); ?>
		<?php } else { include(TEMPLATEPATH . '/includes/sti_slider.php'); } ?>
		<?php if (have_posts()) : ?>
			<?php while (have_posts()) : the_post(); ?>
		<div class="featured_post" >
			<div class="slider_image">			
				<?php if ( get_post_meta($post->ID, 'show', true) ) : ?>
				<?php $image = get_post_meta($post->ID, 'show', true); ?>
				<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><img src="<?php echo $image; ?>"width="690" height="296" alt="<?php the_title(); ?>"/></a>
				<?php else: ?>
					<?php if (has_post_thumbnail()) { the_post_thumbnail('home-thumb' ,array('class' => 'home-thumb')); }
				else { ?>
					<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><img class="home-thumb" src="<?php echo catch_first_image() ?>" width="690px" height="296px" alt="<?php the_title(); ?>"/></a>
				<?php } ?>
				<?php endif; ?>
			</div>
		</div>
<?php endwhile; ?>
<?php endif; ?>	
	</div>
 </div>
 </div>