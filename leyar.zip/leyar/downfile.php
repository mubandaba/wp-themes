<?php
/*
  Template Name: 文章下载
 */
?>
<?php
if ($_GET['id']==''){
$rand_post=get_posts('numberposts=1&orderby=rand');
foreach($rand_post as $post) :
$furl=$post_id;
endforeach;
}else{
$furl = $_GET['id'];
}
$title = get_post($furl)->post_title;
$postlink = get_post($furl)->guid;
$file_views = (int)get_post_meta($furl, 'views', true);
$post_time = get_post($furl)->post_date;
$post_modified=get_post($furl)->post_modified;
$comment_count=get_post($furl)->comment_count;
$postid=get_post($furl);
$pre_downlink_nums=get_option('swt_down_pre_num');
$total_link_texts=explode("|",stripslashes(get_option('swt_link_text')));
$tatal_link_addrs=explode("\n",stripslashes(get_post_meta($furl, "thelinks_value", true)));
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>IT路人 - <?php echo '下载《'.$title.'》的相关文件' ?></title>
	<meta name="keywords" content="<?php echo $title; ?>" />
	<meta name="description" content="<?php echo dm_strimwidth(strip_tags($postid->post_content),0,120,"...");?>" />
	<link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="http://lib.sinaapp.com/js/jquery/1.4.2/jquery.min.js"></script>
	<script type="text/javascript">window.jQuery || document.write('<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.js">\x3C/script>')</script>
	<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery_leyar.js.php"></script>
	<script type="text/javascript">HcmsLazyload("<?php bloginfo('template_url'); ?>/images/space.gif");</script> 
	<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/ramdom-word.js"></script>
	 <!--[弹窗]-->
       <script src="<?php bloginfo('template_url'); ?>/popupfb/jquery-1.2.2.pack.js" type="text/javascript"></script>
        <link href="<?php bloginfo('template_url'); ?>/popupfb/facebox.css" media="screen" rel="stylesheet" type="text/css" />
        <script src="<?php bloginfo('template_url'); ?>/popupfb/facebox.js" type="text/javascript"></script>
        <script type="text/javascript">
        jQuery(document).ready(function($) {
        $("a[rel*=facebox]").facebox() 
        })
        </script>
        <!--[弹窗]-->
	<script type=text/javascript>
$(function(){$('#webmenu li').hover(function(){$(this).children('ul').stop(true,true).show('slow');},function(){$(this).children('ul').stop(true,true).hide('slow');});$('#webmenu li').hover(function(){$(this).children('div').stop(true,true).show('slow');},function(){$(this).children('div').stop(true,true).hide('slow');});});
</script>
	<!--[if IE 6]>
	<link href="<?php bloginfo('template_url'); ?>/ie6.css" rel="stylesheet" type="text/css" />
	<script src="http://letskillie6.googlecode.com/svn/trunk/letskillie6.zh_CN.pack.js"></script>
	<script src="<?php bloginfo('template_url'); ?>/js/PNG.js"></script>
	<script>DD_belatedPNG.fix('.png_bg');</script>
	<![endif]-->
	<link rel="shortcut icon" href="<?php bloginfo('url'); ?>/favicon.ico"/>
	<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name'); ?> Atom Feed" href="<?php bloginfo('atom_url'); ?>" />
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<?php wp_head(); ?>
</head>
<body>
<div id="navigation"><div id="container_nav"><?php include('includes/topnv_extend.php'); ?></div></div>
	<div id="header" class="png_bg">
		<div id="header_inner">
		  <div id="dh_say_content" class="left" style="max-width:500px;margin:4px 0 0px 0;color:#000000;height:25px;position:absolute;top:75px;left:280px;z-index:9999;overflow:hidden;">
		<p id="dh_say" title="点击可查看下一条"><?php dh_say();?></p>
	</div>
	   <div class="followBtn">
			<a rel="nofollow" target="_blank" href="http://wpa.qq.com/msgrd?V=1&Menu=yes&Uin=<?php echo stripslashes(get_option('swt_qq')); ?>" title="有急事请Q我"><img src="<?php bloginfo('template_url'); ?>/images/qqnum.png" alt="有急事请Q我"></a>			
			<a rel="nofollow" target="_blank" href="<?php echo stripslashes(get_option('swt_qqmblog')); ?>" title="收听我的腾讯微博"><img src="<?php bloginfo('template_url'); ?>/images/qqweibo.jpg" alt="收听我的腾讯微博"></a>
			<a rel="nofollow" target="_blank" href="<?php echo stripslashes(get_option('swt_sinamblog')); ?>" title="收听我的新浪微博"><img src="<?php bloginfo('template_url'); ?>/images/sinaweibo.jpg" alt="收听我的新浪微博"></a>
			<a rel="nofollow" target="_blank" href="<?php echo stripslashes(get_option('swt_twitter')); ?>" title="收听我的Twitter微博"><img src="<?php bloginfo('template_url'); ?>/images/twitter.png" alt="收听我的Twitter微博"></a>
			<a rel="nofollow" target="_blank" href="mailto:<?php echo stripslashes(get_option('swt_email')); ?>" title="发邮件给我"><img src="<?php bloginfo('template_url'); ?>/images/emailme.png" alt="发邮件给我"></a>
			<a rel="nofollow" target="_blank" href="<?php echo get_option('swt_rsssub'); ?>" title="通过RSS订阅我的博客"><img src="<?php bloginfo('template_url'); ?>/images/rssdy.png" alt="通过RSS订阅我的博客"></a>
</div>
    		<strong class="logo">
			<a href="<?php bloginfo('url'); ?>" class="png_bg" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a>
			</strong>
       <div class="header_bg png_bg"></div>
       <div class="toplinks">
       <div id="_userlogin">	
			<a href="http://www.itluren.com" target="_blank">IT路人</a>
       </div>
       	<div id="top_nav">
			<?php if(stripslashes(get_option('swt_leyar_top_ad'))!=''){?><?php echo stripslashes(get_option('swt_leyar_top_ad')); ?><?php } ?>
            </div>
       </div>
	   <?php wp_nav_menu('theme_location=nav-menu&container_id=webmenu'); ?>
	   <div class="clearfix"></div>
    </div>
</div>
	
<div id="wrapper" class="clearfix">
<div id="breadcrumbs" class="con_box clearfix">
		<div class="bcrumbs"><strong><a href="<?php bloginfo('home'); ?>" title="返回首页">home</a></strong>
		<a><?php echo '下载《'.$title.'》的相关文件' ?></a>
		</div>
	</div>
 	<div id="art_container clearfix">
 		<div id="art_main1" class="art_white_bg fl"> 
		     <?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
			<div class="article_content">
			<?php the_content(); ?>
			</div>
			<?php endwhile; ?>
            <div class="art_title clearfix" style="margin-top:20px;">
				<h1>文件信息</h1>
			</div>
			<div class="article_content"><div class="filedataview">
			关注度：<?php echo $file_views; ?>  ℃&nbsp;&nbsp;&nbsp;&nbsp;评论数：<?php echo $comment_count; ?>&nbsp;&nbsp;&nbsp;&nbsp;上传时间：<?php echo $post_time; ?>&nbsp;&nbsp;&nbsp;&nbsp;更新时间：<?php echo $post_modified; ?><br/>下载地址列表：<a rel="facebox" href="#itluren">点击此处获取下载地址</a><span id="itluren" style="display:none"> <b>下载声明：</b></br/>1. 本站所有软件和资料均为软件作者提供或网友推荐发布而来，仅供学习和研究使用，不得用于任何商业用途。如本站不慎侵犯你的版权请联系站长，我们将及时处理，并撤下相关内容！<br/>
2. 访问本站的用户必须明白，本站对所提供下载的软件和程序代码不拥有任何权利，其版权归该软件和程序代码的合法拥有者所有，请用户在下载使用前必须详细阅读并遵守软件作者的“使用许可协议”。本站仅仅是一个软件使用交流的平台。<hr/><b>该文件来自于《<?php echo '<a href="'.$postlink.'" title="'.$title.'">'.$title.'</a>' ;?>》</b><br/><?php echo dm_strimwidth(strip_tags($postid->post_content),0,120,"...");?><hr/><b>下载链接:</b><?php for($i=0;$i<$pre_downlink_nums;$i++){ echo '&nbsp;&nbsp;&nbsp;&nbsp;<a href="'.$tatal_link_addrs[$i].'" target="_blank" rel="nofollow" title="点击下载《'.$title.'》上的文件">'.$total_link_texts[$i].'</a>';} ?><hr/><P style="color:red;">如果没有特殊说明，默认的解压密码为：<?php echo get_option('swt_downpage_pw'); ?></p></span></div>
			</div>	
			<div class="article_content" style="margin-top:20px;">
			<?php echo stripslashes(get_option('swt_downpage_ad')); ?>
			</div>
			<div class="art_title clearfix" style="margin-top:20px;">
				<h1>下载声明</h1>
			</div>
            <div class="article_content">
			本站所刊载内容多为网络上收集整理，并且以研究交流为目的，所有仅供大家参考、学习，不存在任何商业目的与商业用途。若您需要使用非免费的软件或服务，您应当购买正版授权并合法使用。如果你下载此文件，表示您同意只将此文件用于参考、学习使用而非任何其他用途。
			</div>			
		</div><!--内容-->
		<div class="clear"></div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>