<?php $display_categories = explode(',', get_option('swt_cat_tab_d') ); $i = 1; foreach ($display_categories as $category) { ?>   
<div class="con_box fl resouse_artile tab_qd_aritle" id="cat-<?php echo $i; ?>"  >
		<?php query_posts("cat=$category")?>
			  <h2><span><a class="more fr" rel="nofollow" href="<?php echo get_category_link($category);?>">更多 <?php single_cat_title(); ?> 文章</a></span><?php single_cat_title(); ?></h2>
	<div>	
		<ul class="index_resourse_list qd_list clearfix"> 
		<?php query_posts( array('showposts' => get_option('swt_tab_column_post'),'cat' => $category,'offset' => 0,'post__not_in' => $do_not_duplicate));?>
		<?php while (have_posts()) : the_post(); ?>
			<li> <span class="fr"><?php the_time('m-d'); ?></span>			
			<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php echo cut_str($post->post_title,40); ?></a>
			</li>
		<?php endwhile; ?>
		</ul>
	</div> 
</div>
	<?php $i++; ?>
	<?php } ?>

