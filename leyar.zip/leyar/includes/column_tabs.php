<div id="daiwowan">
    <div id="dww-menu" class="mod-tab">
		<div class="mod-hd">
			<ul class="tab-nav">
			<?php if (get_option('swt_cat_tab_a_n') != '') { ?>					
				<li class="nav_current" id="nav1" onMouseOver="javascript:doClick(this)"><?php echo get_option('swt_cat_tab_a_n');?></li>
			<?php } else { echo ''; } ?>
			<?php if (get_option('swt_cat_tab_b_n') != '') { ?>	
				<li class="nav_link" id="nav2" onMouseOver="javascript:doClick(this)"><?php echo get_option('swt_cat_tab_b_n');?></li>
			<?php } else { echo ''; } ?>
			<?php if (get_option('swt_cat_tab_c_n') != '') { ?>	
				<li class="nav_link" id="nav3" onMouseOver="javascript:doClick(this)"><?php echo get_option('swt_cat_tab_c_n');?></li>
			<?php } else { echo ''; } ?>
			<?php if (get_option('swt_cat_tab_d_n') != '') { ?>	
				<li class="nav_link" id="nav4" onMouseOver="javascript:doClick(this)"><?php echo get_option('swt_cat_tab_d_n');?></li>
			<?php } else { echo ''; } ?>
			<?php if (get_option('swt_cat_tab_e_n') != '') { ?>	
				<li class="nav_link" id="nav5" onMouseOver="javascript:doClick(this)"><?php echo get_option('swt_cat_tab_e_n');?></li>
			<?php } else { echo ''; } ?>
			</ul>
		</div>
		<div class="mod-bd">
		<?php if (get_option('swt_cat_tab_a_n') != '') { ?>
			<div class="dis" id="sub1">
					<?php include(TEMPLATEPATH . '/includes/tab_column1.php'); ?>
			</div>
		<?php } else { echo ''; } ?>
			<?php if (get_option('swt_cat_tab_b_n') != '') { ?>	
			<div class="undis" id="sub2">
				<?php include(TEMPLATEPATH . '/includes/tab_column2.php'); ?>
			</div>
		<?php } else { echo ''; } ?>
			<?php if (get_option('swt_cat_tab_c_n') != '') { ?>	
			<div class="undis" id="sub3">
				<?php include(TEMPLATEPATH . '/includes/tab_column3.php'); ?>
			</div>
		<?php } else { echo ''; } ?>
			<?php if (get_option('swt_cat_tab_d_n') != '') { ?>	
			<div class="undis" id="sub4">
				<?php include(TEMPLATEPATH . '/includes/tab_column4.php'); ?>
			</div>
		<?php } else { echo ''; } ?>
			<?php if (get_option('swt_cat_tab_e_n') != '') { ?>	
			<div class="undis" id="sub5">
				<?php include(TEMPLATEPATH . '/includes/tab_column5.php'); ?>
			</div>
		<?php } else { echo ''; } ?>
		</div>
	</div>
</div>


