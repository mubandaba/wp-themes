<?php
if (empty($_GET['id']))
  wp_die("文件不存在", '下载错误 - 文件不存在');
$furl = $_GET['id'];
$title = get_post($furl)->post_title;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
	<title><?php echo $title ; ?></title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="http://lib.sinaapp.com/js/jquery/1.4.2/jquery.min.js"></script>
	<script type="text/javascript">window.jQuery || document.write('<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.js">\x3C/script>')</script>
       <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery_cmhello.js"></script>
	<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/ramdom-word.js"></script>
        <!--[弹窗]-->
       <script src="<?php bloginfo('template_url'); ?>/popupfb/jquery-1.2.2.pack.js" type="text/javascript"></script>
        <link href="<?php bloginfo('template_url'); ?>/popupfb/facebox.css" media="screen" rel="stylesheet" type="text/css" />
        <script src="<?php bloginfo('template_url'); ?>/popupfb/facebox.js" type="text/javascript"></script>
        <script type="text/javascript">
        jQuery(document).ready(function($) {
        $("a[rel*=facebox]").facebox() 
        })
        </script>
        <!--[弹窗]-->

	<script type="text/javascript">HcmsLazyload("<?php bloginfo('template_url'); ?>/images/space.gif");</script> 
	<link rel="shortcut icon" href="<?php bloginfo('url'); ?>/favicon.ico"/>
</head>
<body>
	<div id="header" class="png_bg">
		<div id="header_inner">
		    <div id="dh_say_content" class="right" style="margin:4px 0 2px 0;color:white;height:25px;position:absolute;top:0px;left:0px;z-index:9999;overflow:hidden;">
		<p id="dh_say" title="点击可查看下一条"><?php dh_say();?></p>
	</div>
    		<strong class="logo">
			<a href="<?php bloginfo('url'); ?>" class="png_bg" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a>
			</strong>
       <div class="header_bg png_bg"></div>
       <div class="toplinks">
       <div id="_userlogin"><em>欢迎光临ShareJquery.com</em> 	
			<a target="_blank" href="http://feed.itluren.com" title="订阅sharejquery上的更新" class="boxy">订阅更新</a><span>|</span>
       </div>
       	<div id="top_nav">
			<form name="formsearch" method="get" action="<?php bloginfo('home'); ?>">
				<div class="form clearfix">
           		<label for="s" ></label>
           		<input type="text" name="s" class="search-keyword" onfocus="if (this.value == '请输入关键字进行搜索') {this.value = '';}" onblur="if (this.value == '') {this.value = '请输入关键字进行搜索';}" value="请输入关键字进行搜索" />   
         		<button type="submit" class="select_class" onmouseout="this.className='select_class'" onmouseover="this.className='select_over'" />搜索</button>
				</div>
			</form>
            </div>
			
       </div>
	   <?php wp_nav_menu('container_id=navmenu'); ?>
	   <div class="clearfix"></div>
    </div>
</div>
	
<div id="wrapper" class="clearfix">
<div id="breadcrumbs" class="con_box clearfix">
		<div class="bcrumbs"><strong><a href="<?php bloginfo('home'); ?>" title="返回首页">home</a></strong>
		<a><?php echo $filename ?></a>
		</div>
	</div>
 	<div id="art_container clearfix">
 		<div id="art_main1" class="art_white_bg fl"> 
            <div class="art_title clearfix">
				<h1><?php echo $title ; ?></h1>
			</div>
			<div class="article_content">
			<?php echo 'ID为'.$furl.'的文章标题是'.$title ;?>
			</div><!--正文-->          
		</div><!--内容-->
	</div>
		<div class="clear"></div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>