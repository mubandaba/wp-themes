﻿<div class="bio"> 
			<div class="gravatar"><?php echo get_avatar( get_the_author_email(), '78' ); ?></div>
			<div class="about">
			<div id="author-title-tip">关于本文作者</div>
				<span class="post-author"><?php the_author(); ?></span>
				<div class="data_dis" id="sub_data1"><p><?php if(get_the_author_meta('description')!=''){echo get_the_author_meta('description');} else{echo '这个家伙非常懒的，好像真的是一墨千金一样，TA什么都没有留下呢……';} ?></p></div>
                <div class="data_undis" id="sub_data2"><p><?php if(get_the_author_meta('telephone')!=''){echo '电话号码：'.get_the_author_meta('telephone').'<br/>';}else{echo '';}?>
					<?php if(get_the_author_meta('qqnum')!=''){echo 'QQ  号码：'.get_the_author_meta('qqnum').'<br/>';}else{echo '';}?>
					<?php if(get_the_author_meta('yyname')!=''){echo 'YY  帐号：'.get_the_author_meta('yyname').'<br/>';}else{echo '';}?>
					<?php if(get_the_author_meta('qqt')!=''){echo '腾讯微博：'.get_the_author_meta('qqt').'<br/>';}else{echo '';}?>
					<?php if(get_the_author_meta('sinat')!=''){echo '新浪微博：'.get_the_author_meta('sinat').'<br/>';}else{echo '';}?>
					<?php if(get_the_author_meta('sohut')!=''){echo '搜狐微博：'.get_the_author_meta('sohut').'<br/>';}else{echo '';}?>
					<?php if(get_the_author_meta('sohut')==''&&get_the_author_meta('qqnum')==''&&get_the_author_meta('yyname')==''&&get_the_author_meta('qqt')==''&&get_the_author_meta('sinat')==''&&get_the_author_meta('telephone')==''){echo '这个家伙什么也没有留下，不知道是不是外星来的。或者，TA想保持神秘？搞不懂了……';}?>
					</p></div>
				<div class="data_undis" id="sub_data3"><?php $query = new WP_Query(array('author' => $post->post_author,'posts_per_page' => 5)); $posts = $query->posts;?><p><?php foreach($posts as $k => $p): ?><a href="<?php echo get_permalink($p->ID); ?>"><?php echo $p->post_title ?></a><br/><?php endforeach; ?></p><p>点击查看 <?php the_author_posts_link();?> 的全部文章</p></div>
				<div class="data_undis" id="sub_data4"><p><?php
global $wpdb;
$myid=get_the_author_meta('ID');
$sql = "SELECT DISTINCT ID, post_title, post_password, comment_ID, comment_post_ID, comment_author, comment_date_gmt, comment_approved, comment_type,comment_author_url,comment_author_email, SUBSTRING(comment_content,1,72) AS com_excerpt FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID = $wpdb->posts.ID) WHERE comment_approved = $myid AND comment_type = '' AND post_password = '' AND user_id='1' ORDER BY comment_date_gmt DESC LIMIT 5";
$comments = $wpdb->get_results($sql);
$output = $pre_HTML;
foreach ($comments as $comment) {$output .= " <a href=\"" . get_permalink($comment->ID) ."#comment-" . $comment->comment_ID . "\" title=\"发表在： " .$comment->post_title . "\">" . strip_tags($comment->com_excerpt)."</a><br/>";}
$output .= $post_HTML;
echo $output;
if($output==''){echo '又是一只飞过天空没有留下羽毛的鸟X，你懂的……';}
?> </p></div>
				<ul class="the-author">
					<li class="nav_current_data" id="nav_data1" onMouseOver="javascript:dataClick(this)">作者简介</li>
					<li class="nav_link_data" id="nav_data2" onMouseOver="javascript:dataClick(this)">联系方式</li>
					<li class="nav_link_data" id="nav_data3" onMouseOver="javascript:dataClick(this)">TA的文章</li>
					<li class="nav_link_data" id="nav_data4" onMouseOver="javascript:dataClick(this)">TA的评论</li>
				</ul>
			</div>
			<div class="fixed"></div>
</div>
<script type="text/javascript">
function dataClick(v){
	 v.className="nav_current_data";
	 var j;
	 var id;
	 var e;
	 for(var i=1;i<=5;i++){
	   id ="nav_data"+i;
	   j = document.getElementById(id);
	   e = document.getElementById("sub_data"+i);
	   if(id != v.id){
	   	 j.className="nav_link_data";
	   	 e.style.display = "none";
	   }else{
			e.style.display = "block";
	   }
	 }
	 }
</script>