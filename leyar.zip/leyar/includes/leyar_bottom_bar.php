﻿<?php if (get_option('swt_gg') == '底部') { ?>
<div id="notice" style="display:none;">
<div class="notice-inner">
<a href="javascript:void(0);" class="open_notice">x</a>
 <h3>公告</h3>
<div class="notice-content">
<p><?php echo stripslashes(get_option('swt_ggao')); ?></p>
</div>
<div class="clear"></div>
</div>
</div>
<?php }else{?>
<?php echo '';?>
<?php } ?>
<?php if (get_option('swt_readers') == '底部') { ?>
<div id="most_comm_readers">
<div class="comm_readers">
<a href="javascript:void(0);" class="view_comm_readers">x</a>
 <h3>读者</h3>
<div class="comm_readers_pics">
<?php leyar_readers($out=get_option('swt_outer'),$timer=get_option('swt_timer'),$limit=get_option('swt_limit')); ?>
</div>
<div class="clear"></div>
</div>
</div>
<?php }else{?>
<?php echo '';?>
<?php } ?>
<div id="bottom_bar">
<div class="inner">
<?php if (get_option('swt_gg') == '底部') { ?>
<?php echo '<a href="javascript:void(0);" class="open_notice" title="点击查看网站的公告">公告</a> |';?>
<?php echo '';?>
<?php } ?>
<a href="<?php bloginfo(’rss2_url’);?>" title="RSS 2.0">网站RSS 2.0</a> 
 <?php if (get_option('swt_readers') == '底部') { ?><?php echo '|<a href="javascript:void(0);" class="view_comm_readers" title="点击查看最给力的读者">给力读者</a> ';?>
 <?php echo '';?>
<?php } ?>
</div>
</div>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/notice.js"></script>