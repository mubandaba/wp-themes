﻿<?php 
$total_file_info=explode("\n",stripslashes(get_post_meta($post->ID, "fileinfo_value", true)));
$total_info_name=explode("|",stripslashes(get_option('swt_file_info')));
$total_info_nums=count($total_info_name);
for($i=0;$i<$total_info_nums;$i++){
	echo '<li class="cl_content_titleli2" style="margin-left: 0px!important;">'.$total_info_name[$i].'：'.$total_file_info[$i].'</li>';
}
?>