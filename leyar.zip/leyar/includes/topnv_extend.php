<div class="topnv_logo"><!-- 顶部小logo -->
			<a href="<?php bloginfo('home'); ?>" title="<?php bloginfo('name'); ?>"><img src="<?php bloginfo('template_directory'); ?>/images/topnv_logo.png" alt="<?php bloginfo('name'); ?>" width="92" height="25" border="0" /></a>
		</div><!-- topnv_logo end -->
		<?php wp_nav_menu( array(
			'theme_location' => 'top-menu',
			'container' => false, 
			'menu_id' => 'topnav', 
			'fallback_cb' => 'revert_wp_menu_page'
			)); ?>			
		<div id="topsearch"><!-- 顶部搜索 -->
			<form method="get" id="searchform" action="<?php bloginfo('home'); ?>">
				<input type="text" name="s" id="s" value="输入关键字..." onfocus="if (this.value == '输入关键字...') {this.value = '';}" onblur="if (this.value == '') {this.value = '输入关键字...'}" />
			</form>
		</div>
		
<?php
	global $user_ID, $user_identity, $user_email, $user_login;
	get_currentuserinfo();
	if ($user_ID) { 
?>
<ul class="topnv_extend">
		<?php wp_nav_menu( array(
			'theme_location' => 'author-menu',
			'container' => false,
            'container_class' => false,			
			'menu' => false,
			'menu_id' => false, 
			'menu_class' => false,
			'before' => '<li>',
			'after' => '</li>',
			'items_wrap' => '%3$s',
			'depth' => 0,
			'fallback_cb' => 'revert_wp_menu_page'
			)); ?>	
		<li><a href="<?php bloginfo('url') ?>/wp-login.php?action=logout">注销</a></li>
		<li><a href="<?php bloginfo('url') ?>/wp-admin/">控制</a></li>
		<li><?php wp_list_authors(); ?></li>
		<li><?php echo leyar_get_avatar($user_email, 20); ?></li>
	</ul>
<?php } else { ?>
               <ul class="topnv_extend">
				<div id="topnv_extend_log">登录</div>
				<?php wp_nav_menu( array(
			'theme_location' => 'visit-menu',
			'container' => false,
            'container_class' => false,			
			'menu' => false,
			'menu_id' => false, 
			'menu_class' => false,
			'before' => '<li>',
			'after' => '</li>',
			'items_wrap' => '%3$s',
			'depth' => 0,
			'fallback_cb' => 'revert_wp_menu_page'
			)); ?>	
			</ul>
			
				<div id="top_login_gui">
					<div class="top_title">
						<div class="top_title_left">
							<p><span>加入我们</span>, 你的生活更精彩！</p>
						</div>
						<div class="top_title_right">
							<p>已经是 <span>会员</span>了？</p>
						</div>
					</div>
					<div class="q_register">
						<p style="font-weight:700;">不要等待机会，而要创造机会。</p>
						<p style="font-weight:700;">多一个朋友，心灵多一份阳光</p>
						<p><?php $users=$wpdb->get_var("SELECT COUNT(ID) FROM $wpdb->users");echo get_bloginfo('name')." 上面已经有 ".$users." 个志同道合的朋友。还等什么，赶快加入吧？";?></p>
						<div class="reg_button">
							<p><a href="<?php bloginfo('home'); ?>/wp-register.php" target="_blank" title="注册成为 <?php bloginfo('name'); ?> 的一员">加入我们</a></p>
						</div>
					</div>
		
					<div class="q_login">
						<form id="loginform" action="<?php echo wp_login_url( get_permalink() ); ?>" method="post">
					<p>登录帐号</p>
					<label><input class="s" type="text" name="log" id="log" value="" size="12" /></label>
					<p>登录密码</p>
					<label><input class="s" type="password" name="pwd" id="pwd" value="" size="12" /></label>
					<p><label><input class="forever_box" type="checkbox" name="rememberme" value="forever" /></label>记住我的登录信息</p>
					<input id="logi_button" type="submit" value="马上登录" />
				</form>
					</div>
				</div>
				<div class="clearfix"></div>
				<?php } ?>