﻿<?php
if ( is_category(1) ) {
$description="ID为1的分类的描述";
$keywords="软件应用,电脑软件,电脑程序,IT路人,itluren.com";
}
if ( is_page(115) ) {
$description="页面ID为115的秒速";
$keywords="软件应用,电脑软件,电脑程序,IT路人,itluren.com";
}
?>