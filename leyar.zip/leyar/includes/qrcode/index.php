<?php
include "phpqrcode.php";
?>
<?php 
	   $c = $_GET['url'];
	   if(strstr($c,'http://')){
	   $c=str_replace('http://','',$c);
	   }
	   $name=preg_replace("/[^0-9a-zA-Z_.-]/",'',$c);
	   if(strstr($name,$_SERVER['HTTP_HOST'])){
	   $name=str_replace($_SERVER['HTTP_HOST'],'',$name);
	   if($name==''){
	   $name=$_SERVER['HTTP_HOST'];
	   }
	   }
	   if(file_exists('png/'.$name.'.png'))
	   {
	   echo '<img src="http://'.$_SERVER['HTTP_HOST'].'/wp-content/themes/leyar/includes/qrcode/png/'.$name.'.png" />';
	   }else{
	   QRcode::png($c, 'png/'.$name.'.png');	
	   $sc = urlencode($c);
	   echo '<img src="http://'.$_SERVER['HTTP_HOST'].'/wp-content/themes/leyar/includes/qrcode/png/'.$name.'.png" />'; 
	   }
?>
