<div class="adt">
	<div class="ad_t"><?php echo stripslashes(get_option('swt_adtc')); ?>
	<div class="clear"></div>
	</div>
</div>