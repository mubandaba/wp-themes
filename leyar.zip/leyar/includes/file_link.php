﻿
<?php
//start: 文件相关链接
if (get_option('swt_down_power')=='Display'){
if ( get_post_meta($post->ID, "thelinks_value", true) ) { ?>
<div class="postcopyright">
				<div class="post_left_link">
		  <?php include('link_addr.php');?>
           </div>
				<div class="post_right_notice"><?php include('downpage_addr.php');?><img src="<?php bloginfo('template_url'); ?>/images/downloadnow.png" alt="点击下载相应的文件"/></a></div>
				</div>
<?php  
}  
}
//end: 文件相关链接
?>	
