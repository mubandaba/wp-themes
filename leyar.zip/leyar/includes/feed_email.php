<div class="feed-mail">
		<form action="http://list.qq.com/cgi-bin/qf_compose_send" target="_blank" method="post">
			<input type="hidden" name="t" value="qf_booked_feedback">
			<input type="hidden" name="id" value="<?php echo stripslashes(get_option('swt_emailid')); ?>">
			<input id="to" onfocus="if (this.value == '输入邮箱 订阅本站') {this.value = '';}" onblur="if (this.value == '') {this.value = '输入邮箱 订阅本站';}" value="输入邮箱 订阅本站" name="to" type="text" class="feed-mail-input"><input class="feed-mail-btn" type="submit" value="订阅">
		</form>
		<?php if (get_option('swt_gg') == '侧边') { ?>
		<?php { include(TEMPLATEPATH . '/includes/gg.php'); } ?>
		<?php } else { echo ''; } ?>
		<div class="clear"></div>
</div>