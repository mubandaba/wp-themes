<?php
/*****************************************************
点击随机加载一个句子
******************************************************/
function dh_say_ajax_action_do(){
	if( isset($_POST['action'])&& $_POST['action'] == 'dh_say_ajax'){
		echo dh_say();
		die();
	}else{
		return;
	}
}
add_action('template_redirect', 'dh_say_ajax_action_do');
function dh_say(){
	$words = explode("\n",stripslashes(get_option('swt_ramdom_word')));
	$word = $words[ mt_rand(0, count($words) - 1) ];
	echo $word;
}
?>