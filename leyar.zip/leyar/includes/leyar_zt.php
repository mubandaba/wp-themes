﻿<?php
$leyar_zt_link_text=explode("|",stripslashes(get_option('swt_zt_link_text')));
$leyar_zt_link_url=explode("\n",stripslashes(get_option('swt_zt_link_url')));
$leyar_zt_link_num=count($leyar_zt_link_text);
$leyar_template_directory_uri=get_template_directory_uri();
for($i=0;$i<$leyar_zt_link_num;$i++){
    echo '<li><a class="list-zt-ztpic" target="_blank" href="'.$leyar_zt_link_url[$i].'"><img alt="'.$leyar_zt_link_text[$i].'" src="'.$leyar_template_directory_uri.'/images/zt/leyar'.$i.'.jpg"></a><span><a target="_blank" href="'.$leyar_zt_link_url[$i].'">'.$leyar_zt_link_text[$i].'</a></span></li>';
}
?>
