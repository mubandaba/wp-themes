﻿<?php 
$total_downlink_txts=explode("|",stripslashes(get_option('swt_link_text')));
$total_link_nums=count($total_downlink_txts);
$pre_downlink_nums=get_option('swt_down_pre_num');
$total_downlink_addrs=explode("\n",stripslashes(get_post_meta($post->ID, "thelinks_value", true)));
for($i=$pre_downlink_nums;$i<$total_link_nums;$i++){
	echo '<div class="post_link_text"><a href="'.$total_downlink_addrs[$i].'" target="_blank" rel="nofollow">'.$total_downlink_txts[$i].'</a></div>';
}
?>