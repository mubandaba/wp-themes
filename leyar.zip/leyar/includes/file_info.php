﻿
<?php
//start: 资源共享entry_title_box
if (get_option('swt_file_power')=='Display'){
if ( get_post_meta($post->ID, "fileinfo_value", true) ) { ?>
<div class="clear"></div>
	<div class="archive_info cl_content_title" style="margin-top:10px;">
         <ul class="cl_content_titleul">
            <li class="cl_content_titleli" style="margin-left: 0px!important;list-style:none;">基本信息</li>
         </ul>
         <ul>
		  <?php include('file_data.php');?>
            <li class="cl_content_titleli2" style="margin-left: 0px!important;">
			其他：<a rel="nofollow" href="#itlurenfx" title="分享这个资源">分享资源</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="#respond" title="评价这个资源" rel="nofollow">我要评价</a>&nbsp;&nbsp;&nbsp;&nbsp;<a rel="nofollow" href="#relatedposts" title="相关文章">猜你喜欢</a>&nbsp;&nbsp;&nbsp;&nbsp;<a rel="nofollow" href="#lurenxz" title="下载地址">下载地址</a>
            </li>
         </ul>	
	</div>
	<div class="cl_contentads">
		<div class="adtart"><?php echo stripslashes(get_option('swt_adrc')); ?>
        </div>				
	</div>
<div class="clear"></div>
<?php  
}  
}
//end: 资源共享entry_title_box
?>	
