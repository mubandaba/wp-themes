﻿<div class="followBtn">
			<a rel="nofollow" target="_blank" href="http://wpa.qq.com/msgrd?V=1&Menu=yes&Uin=<?php echo stripslashes(get_option('swt_qq')); ?>" title="有急事请Q我"><img src="<?php bloginfo('template_url'); ?>/images/qqnum.png" alt="有急事请Q我"></a>			
			<a rel="nofollow" target="_blank" href="<?php echo stripslashes(get_option('swt_qqmblog')); ?>" title="收听我的腾讯微博"><img src="<?php bloginfo('template_url'); ?>/images/qqweibo.jpg" alt="收听我的腾讯微博"></a>
			<a rel="nofollow" target="_blank" href="<?php echo stripslashes(get_option('swt_sinamblog')); ?>" title="收听我的新浪微博"><img src="<?php bloginfo('template_url'); ?>/images/sinaqeibo.jpg" alt="收听我的新浪微博"></a>
			<a rel="nofollow" target="_blank" href="<?php echo stripslashes(get_option('swt_twitter')); ?>" title="收听我的Twitter微博"><img src="<?php bloginfo('template_url'); ?>/images/twitter.png" alt="收听我的Twitter微博"></a>
			<a rel="nofollow" target="_blank" href="mailto:<?php echo stripslashes(get_option('swt_email')); ?>" title="发邮件给我"><img src="<?php bloginfo('template_url'); ?>/images/emailme.png" alt="发邮件给我"></a>
			<a rel="nofollow" target="_blank" href="<?php echo get_option('swt_rsssub'); ?>" title="通过RSS订阅我的博客"><img src="<?php bloginfo('template_url'); ?>/images/rssdy.png" alt="通过RSS订阅我的博客"></a>
</div>