﻿<?php 
$downpage_addr=get_option('swt_downpage_addr');
if(get_option('swt_downpage_ask')=="No"){
echo '<a id="lurenxz" href="'.$downpage_addr.'?id='.$id.'" target="_blank" title="点击下载相应的文件">';
}else{
echo '<a id="lurenxz" href="'.$downpage_addr.'&id='.$id.'" target="_blank" title="点击下载相应的文件">';
}
?>