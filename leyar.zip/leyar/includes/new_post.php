<?php
	$scrollcount = get_option('swt_new_post');
 ?>
<?php query_posts('&showposts='.$scrollcount.'&caller_get_posts=10.&cat='.get_option('swt_new_exclude')); while ( have_posts() ) : the_post();$do_not_duplicate[] = $post->ID; ?>

    <div class="art_img_box clearfix">
	<div class="art_show_top">
	<div class="fl innerimg_box">
    <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="preview"><?php if ( has_post_thumbnail() ) { ?><?php the_post_thumbnail('box_featured'); ?><?php } else {?><img alt="<?php the_title(); ?>" src="<?php echo catch_first_image() ?>" width="350" height="150" /><?php } ?></a>
	</div>
    <div class="fr box_content">
					<h2><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php echo cut_str($post->post_title,40); ?></a></h2>        		
						                                              
					<p class="intro">
						<?php if(has_excerpt()) the_excerpt();  
							else  
								 echo dm_strimwidth(strip_tags($post->post_content),0,110,"..."); ?>
					</p>
                   </div>
				   </div>
     <div class="art_info_bottom">
                    	<span>日期：<?php the_time('Y年m月d日') ?></span>|                        
						<span>点击：<small><?php post_views(' ', ' 次'); ?></small></span>|
						<span><?php comments_popup_link('暂无评论', '评论： <small>1</small>', '评论：<small>%</small>'); ?></span>|
						<span>栏目：<?php the_category(', ') ?></span>|
                   		<span>标签：<?php the_tags(); ?></span>
						<span><?php edit_post_link( __('[编辑]')); ?></span>
                     
						</div>
			<div class="news"></div>
             </div>
	<!-- ad -->
	<?php if ($wp_query->current_post == 0) : ?>
	<?php if (get_option('swt_adh') == 'Hide') { ?>
	<?php { echo ''; } ?>
	<?php } else { include(TEMPLATEPATH . '/includes/ad_h.php'); } ?>
	<?php endif; ?>	
	<!-- end: ad -->
<?php endwhile; ?>