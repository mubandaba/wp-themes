﻿<?php 
    $hight_voting = $wpdb->get_results("SELECT post_title, ID FROM $wpdb->posts,$wpdb->postmeta WHERE meta_key = 'ludou_ratings_score' AND ID = post_id ORDER BY meta_value DESC LIMIT 10"); 
?>
<ul>
    <?php foreach($hight_voting as $vote_post) : ?>
    <li><a href="<?php echo get_permalink( $vote_post->ID ); ?>" title="<?php echo $vote_post->post_title; ?>"><?php echo $vote_post->post_title; ?></a></li>
    <?php endforeach; ?>
</ul>