<?php get_header(); ?>
	<div id="wrapper" class="clearfix">
	<?php
		wp_reset_query();
		if (!is_home()) :
	?>
	<div id="breadcrumbs" class="con_box clearfix">
		<div class="bcrumbs"><strong><a href="<?php bloginfo('url'); ?>" title="返回首页">home</a></strong>
		<?php if ( is_author()){ ?>
		<a><?php wp_title( '');?>发表的所有文章</a>
		<?php } ?>				
		</div>
		<div class="caterss">
			<a href="<?php echo curPageURL(); ?>/feed" title="订阅该作者的更新" target="_blank">订阅作者</a>
		</div> 
	</div>
	<?php endif; ?>
 		<div id="art_container clearfix">
 			<div id="art_main" class="fl"> 
		<?php if (get_option('swt_list') == '缩略图样式') { ?>
		<?php include(TEMPLATEPATH . '/includes/thumb_list.php');?>
		<?php } else { include(TEMPLATEPATH . '/includes/title_list.php'); } ?>
            </div><!--内容-->
<?php get_sidebar(); ?>
<?php get_footer(); ?>