<?php
/*
Template Name:友情链接
*/
?>
<?php 
function add_links() {
	if(!isset($_POST['action']))
		return false;
	$filter = array('\r\n', '\r', '\n', ' ', '\t', '\o', '\x0B','\'','"','\\','<','>');
	//链接地址
	$link_url = str_replace($filter,"",$_POST['link_url']);
	$link_url_add = $link_url;
	preg_match ( '/^(?:http|https):\/\/([0-9a-z\-\.]+)/i',$link_url,$link_url);
	$link_url = $link_url[0];
	//获取链接域名，即去掉其中的协议
    $domain = str_replace('http://','',$link_url);
	$domain = str_replace('https://','',$link_url);
	//链接类型
	$link_type_position = str_replace($filter,"",$_POST['link_type_position']);
	//获取当前日期，并格式化成XXXX-XX-XX
	$link_now_date = date("Y-m-d");
	//链接名称
	$link_name = str_replace($filter,"",$_POST['link_name']);
	//链接放置页面
	$link_page_addr = str_replace($filter,"",$_POST['link_page_addr']);
	//获取链接放置页面的内容
	$link_page_content = @file_get_contents($link_page_addr);
	//本站链接
	$my_link_index = site_url();
	//匹配本站链接1
	$my_link_tipa= 'href="'.$my_link_index;	
	//匹配本站链接2
	$my_link_tipb= "href='".$my_link_index;	
	//匹配本站链接3
	$my_link_tipc= "href=".$my_link_index;	
	//链接描述
	$link_description = str_replace($filter,"",$_POST['link_description']);
	//获取网站的SEO信息
	$domain = $domain;  /*欲查询的域名*/
	$gg_site_url='http://www.google.com.hk/search?ie=UTF-8&q=site:'.$domain;
	$gg_pr_url='http://tool.chinaz.com/ExportPR/?q='.$domain;
    $site_url = 'http://www.baidu.com/s?wd=site%3A';
	$baidu_weights_url='http://mytool.chinaz.com/baidusort.aspx?host='.$domain; /*域名百度权重查询网址*/
    $all = $site_url.$domain; /*域名所有收录的网址*/
	$gg_pr_tip="/<li><img src='\/template\/default\/images\/ranks\/Rank_(.*).gif' \/><\/li>/";
    $utf_pattern = "/找到相关结果数(.*)个/";
	$baidu_weights_tip="/<div class=\"siteinfo\">百度权重为 (.*) ，共找到/";  /*百度权重查询字符串匹配*/
    $gb2312_pattern = iconv("UTF-8","GB2312",$utf_pattern); /*因为百度为GB2312编码*/
    $kz_pattern = "/<span class=\"g\">(.*)<\/span>/"; /*用以匹配快照日期的字符串*/
    $times = "/\d{4}-\d{1,2}-\d{1,2}/"; /*匹配快照日期的正则表达式，如:2011-8-4*/
	$gg_pr_c = @file_get_contents($gg_pr_url);
    $s0 = @file_get_contents($all);    /*将site:XXXXt的网页置入$s0字符串中*/
	$baidu_weights_content = @file_get_contents($baidu_weights_url);
	preg_match($gg_pr_tip,$gg_pr_c,$gg_pr_num);
    preg_match($gb2312_pattern,$s0,$all_num); /*匹配"找到相关结果数*个"*/
    preg_match($kz_pattern,$s0,$temp);
    preg_match($times,$temp[0],$screenshot);
	preg_match($baidu_weights_tip,$baidu_weights_content,$baidu_weights_num);
	/*谷歌收录情况获取，需要curl库支持*/
	$curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $gg_site_url);
    curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
    curl_setopt($curl, CURLOPT_HTTPGET, 1);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $tempdata = curl_exec($curl); curl_close($curl);
    preg_match('#<div\s*id=resultstats>([^<]*)#i', $tempdata, $res);
    $gg_site_num = preg_replace('/[^\d]/', '', $res[1]);
	/*格式化获取的SEO信息*/
	if($gg_pr_num[1] == ""){
        $gg_pr_num[1] = 0;
		}else{
		$gg_pr_num[1] = preg_replace('/[^\d]/','',$gg_pr_num[1]);
		}
    if($all_num[1] == ""){
        $all_num[1] = 0;
		}else{
		$all_num[1] = preg_replace('/[^\d]/','',$all_num[1]);
		}
    if($screenshot[0] == "")
        $screenshot[0] = "暂无快照";
	if($baidu_weights_num[1] == ""){
        $baidu_weights_num[1] = 0;
	}else{
		$baidu_weights_num[1] = preg_replace('/[^\d]/','',$baidu_weights_num[1]);
		}
	/*首页条件*/
	$index_ggsl_num= get_option('swt_index_ggsl');
	$index_ggsl_num=preg_replace('/[^\d]/','',$index_ggsl_num);
	$index_bdsl_num= get_option('swt_index_bdsl');
	$index_bdsl_num=preg_replace('/[^\d]/','',$index_bdsl_num);
	$index_ggpr_num= get_option('swt_index_ggpr');
	$index_ggpr_num=preg_replace('/[^\d]/','',$index_ggpr_num);
	$index_bdqz_num= get_option('swt_index_bdqz');
	$index_bdqz_num=preg_replace('/[^\d]/','',$index_bdqz_num);
	$index_bdkz_num= get_option('swt_index_bdkz');
	$index_bdkz_num=preg_replace('/[^\d]/','',$index_bdkz_num);
	/*内页条件*/
    $inter_ggsl_num= get_option('swt_inter_ggsl');
	$inter_ggsl_num=preg_replace('/[^\d]/','',$inter_ggsl_num);
	$inter_bdsl_num= get_option('swt_inter_bdsl');
	$inter_bdsl_num=preg_replace('/[^\d]/','',$inter_bdsl_num);
	$inter_ggpr_num= get_option('swt_inter_ggpr');
	$inter_ggpr_num=preg_replace('/[^\d]/','',$inter_ggpr_num);
	$inter_bdqz_num= get_option('swt_inter_bdqz');
	$inter_bdqz_num=preg_replace('/[^\d]/','',$inter_bdqz_num);
	$inter_bdkz_num= get_option('swt_inter_bdkz');
	$inter_bdkz_num=preg_replace('/[^\d]/','',$inter_bdkz_num);
	//做条件和情况的对比
	/*首先判断链接类型*/
	if($link_type_position=='linkindex')
	{
	/*快照时间的判断所需变量*/
	$linkdatae_if_index = mktime(0,0,0,date("m"),date("d")-$index_bdkz_num,date("Y"));
	$link_d_if_index=date("Y-m-d", $linkdatae_if_index); 
	/*要符合全部条件哦*/
	if($gg_site_num>=$index_ggsl_num&&$all_num[1]>=$index_bdsl_num&&$gg_pr_num[1]>=$index_ggpr_num&&$baidu_weights_num[1]>=$index_bdqz_num&&date("Y-m-d",strtotime($link_now_date))>=date("Y-m-d",strtotime($link_d_if_index)))
	{
	$link_notes_content='首页链接';
	if(get_option('swt_index_link_auto')=='Yes'){
	$if_link_visible='Y';
	$email_content=<<<leyar
	<p><b>申请的域名 :</b>{$link_url_add}</p>
	<p><b>申请的名称 :</b>{$link_name}</p>
	<p><b>申请的描述 :</b>{$link_description}</p>
	<p><b>放置链接在 :</b>{$link_page_addr}</p>
	<p>经过系统判断，此网站条件符合首页链接要求。因为您要求自动审核，所以系统已经将此链接加入数据库，并予以首页显示！</p>
leyar;
	}else{
     $if_link_visible='N';	
	 $email_content=<<<leyar
	<p><b>申请的域名 :</b>{$link_url_add}</p>
	<p><b>申请的名称 :</b>{$link_name}</p>
	<p><b>申请的描述 :</b>{$link_description}</p>
	<p><b>放置链接在 :</b>{$link_page_addr}</p>
	<p>经过系统判断，此网站条件符合首页链接要求。因为您关闭了自动审核，所以系统已经将此链接加入数据库，但未予以首页显示！请您<a href="{$my_link_index}/wp-admin/link-manager.php?orderby=visible&order=asc" style="color: #DD4B39;">去审核友情链接</a></p>
leyar;
	}
	}else{
	return '您的网站的情况不符合本站首页链接要求，请选择内页链接。或者，您认为系统判断有误，请联系管理员！';
	}
	/*内页链接的判断*/
	}else{
	/*内页快照时间的判断所需变量*/
	$linkdatae_if_inter = mktime(0,0,0,date("m"),date("d")-$inter_bdkz_num,date("Y"));
	$link_d_if_inter=date("Y-m-d", $linkdatae_if_inter); 
	/*要符合全部条件哦*/
	if($gg_site_num>=$inter_ggsl_num&&$all_num[1]>=$inter_bdsl_num&&$gg_pr_num[1]>=$inter_ggpr_num&&$baidu_weights_num[1]>=$inter_bdqz_num&&date("Y-m-d",strtotime($link_now_date))>=date("Y-m-d",strtotime($link_d_if_inter)))
	{
	$link_notes_content='';
	if(get_option('swt_inter_link_auto')=='Yes'){
	$if_link_visible='Y';
	$email_content=<<<leyar
	<p><b>申请的域名 :</b>{$link_url_add}</p>
	<p><b>申请的名称 :</b>{$link_name}</p>
	<p><b>申请的描述 :</b>{$link_description}</p>
	<p><b>放置链接在 :</b>{$link_page_addr}</p>
	<p>经过系统判断，此网站条件符合内页链接要求。因为您要求自动审核，所以系统已经将此链接加入数据库，并予以内页显示！</p>
leyar;
	}else{
     $if_link_visible='N';	
	 $email_content=<<<leyar
	<p><b>申请的域名 :</b>{$link_url_add}</p>
	<p><b>申请的名称 :</b>{$link_name}</p>
	<p><b>申请的描述 :</b>{$link_description}</p>
	<p><b>放置链接在 :</b>{$link_page_addr}</p>
	<p>经过系统判断，此网站条件符合内页链接要求。因为您关闭了自动审核，所以系统已经将此链接加入数据库，但未予以内页显示！请您<a href="{$my_link_index}/wp-admin/link-manager.php?orderby=visible&order=asc" style="color: #DD4B39;">去审核友情链接</a></p>
leyar;
	}
	}else{
	return '您的网站的情况不符合本站内页链接要求。如果，您认为系统判断有误，请联系管理员！';
	}
	}
	//开始判断了
	if(!$link_url)
		return '请输入正确的网站地址!';
	if(!$link_name)
		return '请输入网站名称!';
	if(!$link_description)
		return '请输入网站描述!';
	global $wpdb;
	$sql = "SELECT link_url FROM {$wpdb->links}
			WHERE link_url LIKE ('{$link_url}%') ";
	$sql = $wpdb->get_row($sql);
	if($sql->link_url)
		return '你输入的链接已存在，可能已经显示，或仍待审核，请耐心等待管理员的审核!';
	if(!strstr($link_page_content,$my_link_tipa)&&!strstr($link_page_content,$my_link_tipb)&&!strstr($link_page_content,$my_link_tipc))
	    return '你输入的放置链接页面好像没有本站本站链接哦，请先加上本站链接再申请或者留言通知管理员!';	
	$link_add['link_url'] = $link_url;
	$link_add['link_name'] = $link_name;
	$link_add['link_image'] = '';
	$link_add['link_target'] = '_blank';
	$link_add['link_description'] = $link_description;
	$link_add['link_visible'] = $if_link_visible;
	$link_add['link_owner'] = 1;
	$link_add['link_rating'] = 0;
	$link_add['link_rel'] = '';
	$link_add['link_notes'] = $link_notes_content;
	$link_add['link_rss'] = '';
	$wpdb->insert( $wpdb->links,$link_add);
	$link_category = $_POST['link_category'];
	if(!isset($link_category[0]))
		$link_category[] = get_option( 'default_link_category' ) ;
	$link_category = array_map( 'intval', $link_category );
	$link_category = array_unique( $link_category );
	if (  ! isset( $link_category ) || 0 == count( $link_category ) || !is_array( $link_category )  ) 
		$link_category = array( get_option( 'default_link_category' ) );
	//过滤没有的分类
	foreach ( $link_category as $key=>$value ) {
		$sql = "SELECT taxonomy,term_id FROM {$wpdb->term_taxonomy}
				WHERE taxonomy = 'link_category' 
				AND  term_id = {$value} 
				";
		$sql = $wpdb->get_row($sql);
		if(!$sql->term_id)
			unset($link_category[$key]);
	}
	$link_id = (int) $wpdb->insert_id;
	wp_set_object_terms( $link_id, $link_category, 'link_category' );
	clean_bookmark_cache( $link_id );
	$content = $email_content;
	$content = convert_smilies($content);
	$headers = "$from\nContent-Type: text/html; charset=" . get_option('blog_charset') . "\n";
	wp_mail(get_bloginfo('admin_email'),'你的站点上有新的链接申请',$content,$headers );
	return true;
}
?>
<?php get_header(); ?>
<div id="wrapper" class="clearfix">
<div id="breadcrumbs" class="con_box clearfix">
<div class="bcrumbs"><strong><a href="<?php bloginfo('home'); ?>" title="返回首页">home</a></strong>
<a><?php the_title(); ?></a>
</div>
</div>
<div id="art_container clearfix">
 		<div id="art_main1" class="art_white_bg fl"> 
		<div class="article_content">
		        <div class="link_page">
				<?php wp_list_bookmarks('title_li=&category=2&category_before=&category_after=&hide_invisible=1'); ?>
				</div>
			      </div>
			<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
			<div class="article_content">
			   <div class="link_page"> <h2>友情链接申请</h2>
				<?php the_content(); ?>
				<form method="post">
<table>
<tbody>
<?php
$add_links = add_links();
if($add_links){
echo '<tr><td class="odd"></td><td>';
if($add_links === true ){
echo '<div class="yes">您的链接请求已经加入数据库，且已经通知管理员，如果自动审核，那已自动显示，否则请等待审核!</div>';
}else{
echo "<div class=\"no\">$add_links</div>";
}
echo '</td></tr>';
}
?>
<tr>
<td class="odd">链接名称</td>
<td><input type="text" class="text"  name="link_name" size="30" tabindex="1" value="<?php if(isset($_POST['link_name'])) echo $_POST['link_name'];?>" id="link_name"></td>
</tr>
<tr>
<td class="odd">链接地址</td>
<td><input type="text" class="text"  name="link_url" size="30" tabindex="1" value="<?php if(isset($_POST['link_url'])) echo $_POST['link_url'];?>" id="link_url"></td>
</tr>
<tr>
<td class="odd">本站链接放置地址</td>
<td><input type="text" class="text"  name="link_page_addr" size="30" tabindex="1" value="<?php if(isset($_POST['link_page_addr'])) echo $_POST['link_page_addr'];?>" id="link_page_addr"></td>
</tr>
<tr>
<td class="odd">链接描述</td>
<td><input type="text" class="text" name="link_description" size="30" tabindex="1" value="<?php if(isset($_POST['link_description'])) echo $_POST['link_description'];?>" id="link_description"></td>
</tr>
<tr>
<td class="odd">链接分类</td>
<td>
<?php
global $wpdb; 
$sql = "SELECT * FROM {$wpdb->term_taxonomy} taxonomy 
INNER JOIN {$wpdb->terms} term  ON taxonomy.term_id = term.term_id 
WHERE 1=1 
AND taxonomy.taxonomy = 'link_category'";
$links_cat = $wpdb->get_results ($sql);
$links_html = '';
foreach ( $links_cat as $value ) {
$checked = '';
if(isset($_POST['link_category'])){
if(is_array($_POST['link_category'])){
if(in_array($value->term_id,$_POST['link_category'])){
$checked = 'checked="checked"';
}
}
}
$links_html.= '<label for="in-link-category-'.$value->term_id.'" class="selectit"><input value="'.$value->term_id.'" type="checkbox" class="checkbox" name="link_category[]" '.$checked.' id="in-link-category-'.$value->term_id.'">'.$value->name.' </label> ';
}
echo $links_html;
?>
</td>
</tr>
<tr>
<td class="odd">链接类型</td>
<td><input type="radio" name="link_type_position" value="linkindex"/>首页&nbsp;&nbsp;&nbsp;<input type="radio" name="link_type_position" value="linkinter" checked="checked" />内页</td>
</tr>
</tbody>
</table>
<div class="submit_div">
<input type="submit" class="submit" value="添加链接">
</div>
<input type="hidden" id="name_key" name="name_key" value="<?php echo wp_create_nonce('lianyue_key'.$type);  ?>">
<input type="hidden" id="action" name="action" value="add">
</form>
			</div><!--正文--></div>          
		</div><!--内容-->
<?php endwhile; ?>
</div>
<div class="clear"></div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>