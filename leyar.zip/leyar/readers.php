<?php
/*
Template Name:读者墙
*/
?>
<?php get_header(); ?>
<div id="wrapper" class="clearfix">
<div id="breadcrumbs" class="con_box clearfix">
<div class="bcrumbs"><strong><a href="<?php bloginfo('home'); ?>" title="返回首页">home</a></strong>
<a><?php the_title(); ?></a>
</div>
</div>
<div id="art_container clearfix">
 		<div id="art_main1" class="art_white_bg fl"> 
			<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
			<div class="article_content">
			      <?php the_content(); ?>
			</div><!--正文--> 
			<div class="article_content">
			   <h2>评论最多的读者</h2>
			<?php
			$my_admin_email=get_bloginfo('admin_email');
 $query="SELECT COUNT(comment_ID) AS cnt, comment_author, comment_author_url, comment_author_email FROM (SELECT * FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->posts.ID=$wpdb->comments.comment_post_ID) WHERE comment_date > date_sub( NOW(), INTERVAL 24 MONTH ) AND comment_author_email != '".$my_admin_email."' AND post_password='' AND comment_approved='1' AND comment_type='') AS tempcmt GROUP BY comment_author_email ORDER BY cnt DESC LIMIT 45";
$wall = $wpdb->get_results($query);
 $maxNum = $wall[0]->cnt;
foreach ($wall as $comment){
 $width = round(40 / ($maxNum / $comment->cnt),2);
if( $comment->comment_author_url!='' ){
$url = $comment->comment_author_url;
}else{
 $url="http://www.itluren.com";
 }
$avatar = get_avatar( $comment->comment_author_email, $size = '36', $default = get_bloginfo('wpurl').'/wp-content/themes/leyar/images/avatar_default.jpg' );
$tmp = "<li><a target=\"_blank\" rel=\"nofollow\" href=\"".$comment->comment_author_url."\">".$avatar."<em>".$comment->comment_author."</em> <strong>+".$comment->cnt."</strong></br>".$comment->comment_author_url."</a></li>";
$output .= $tmp;
}
$output = "<ul class=\"readers-list\">".$output."</ul>";
echo $output ;
 ?>
			
			</div><!--读者墙-->   			
		</div><!--内容-->
<?php endwhile; ?>
</div>
<div class="clear"></div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>