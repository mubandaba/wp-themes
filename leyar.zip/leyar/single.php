<?php get_header(); ?>
<div id="wrapper" class="clearfix">
	<div id="breadcrumbs" class="con_box clearfix">
		<div class="bcrumbs"><strong><a href="<?php bloginfo('home'); ?>" title="返回首页">home</a></strong>
		<?php the_category(multiple); ?>
		<a><?php the_title(); ?></a>
		</div>
	</div>
 	<div id="art_container clearfix">
 		<div id="art_main1" class="art_white_bg fl"> 
		<?php if(ls_getinfo('isref')) {$se_related = ls_related($post->ID);
    if ($se_related) { 
        echo '<div id="serp">';
        echo refer_thanks();
?>
<p>您所搜索的关键词为：<em><?php ls_getinfo('terms'); ?></em></p>
<h4>您可能对以下文章感兴趣</h4>
<ul>        
<?php echo $se_related; ?>
</ul>
<?php echo '</div>'; } } ?>
			<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
            <div class="art_title clearfix">
			<span class="face_img"><?php 
                                  $leyar_qrcode_pic=get_template_directory_uri();
                                  $leyar_qrcode_pic.='/images/leyar_qrcode.gif';
                                  $the_post_link=get_permalink();
                                  $qrcode_url=leyar_qrcode($the_post_link);
                                  echo '<a id="leyar_qrcode" href="'.$qrcode_url.'" rel="nofollow"><img src="'.$leyar_qrcode_pic.'"/></a>';
                                   ?></span>
				<h1><?php the_title(); ?></h1>
				<p class="info">
				<small>时间:</small><?php the_time('y-m-d'); ?> 
				<small>栏目:</small><?php the_category(', ') ?> 
				<small>作者:</small><?php the_author(); ?> 
				<small>评论:</small><?php comments_number('0','1','%'); ?>
				<small>点击:</small><?php post_views(' ', ' 次'); ?>
				<?php edit_post_link( __('[编辑文章]')); ?>
				</p><!-- /info -->  
			</div>
			<div class="article_content">
				<div class="article-tag">
				<?php the_tags('<p><strong>本文标签</strong>： ', ' , ','</p>' ); ?>
				</div>
				<div id="file_info_view"><?php include('includes/file_info.php');?></div>
				<div class="clear"></div>
				<?php the_content(); ?> 
				
				<div class="clear"></div>
				</div><!--正文--> 
				<?php include('includes/file_link.php');?>
				<?php include('includes/about_author.php');?>
				
			<div class="con_pretext clearfix">
					<ul>
						<li class="first">上一篇：<?php previous_post_link('%link') ?> </li>
						<li class="last">下一篇：<?php next_post_link('%link') ?></li>
					</ul>
			</div><!--上一页 下一页--> 
		<div class="con_pretext clearfix">
					<?php if (get_option('swt_adc') == 'Hide') { ?>
				<?php { echo ''; } ?>
				<?php } else { include(TEMPLATEPATH . '/includes/adt.php'); } ?>
			</div>
         <div class="con_pretext clearfix">
				<?php include(TEMPLATEPATH . '/includes/related.php');?>
			</div>			
			<?php if (comments_open()) comments_template( '', true ); ?>
				<?php if (get_option('swt_adc') == 'Hide') { ?>
				<?php { echo ''; } ?>
				<?php } else { include(TEMPLATEPATH . '/includes/ad_c.php'); } ?>
				<div class="clear"></div>
			
		</div><!--内容-->

			<?php endwhile; ?>

	</div>
		<div class="clear"></div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>