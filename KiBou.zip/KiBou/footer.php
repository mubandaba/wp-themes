   <?php wp_footer(); ?>
<center>
      <footer class="blog-footer">
        <p>&copy;&nbsp;Copyright&nbsp;2017&nbsp;<a href="<?php bloginfo('url');?>"><?php bloginfo('name');?></a>
                  </p>
        <p>Theme <a style="cursor:default;" href="/">Kibou</a> made with ♥</p>
      </footer>
    </center>
    <!-- Load Theme Dedicated JS -->
    <script src="<?php bloginfo('template_url'); ?>/js/highlight.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/js/loadup.js"></script>
<script src="<?php bloginfo('template_url'); ?>/js/activate-power-mode.js"></script>
<script>
    POWERMODE.colorful = true; // ture 为启用礼花特效
    POWERMODE.shake = false; // false 为禁用震动特效
    document.body.addEventListener('input', POWERMODE);
</script>
<!-- 底部统计代码 -->
<div style="display:none">
<?php echo get_option('git_demo1'); ?>
</div>
  </body>
</html>