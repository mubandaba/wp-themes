<!DOCTYPE HTML>
<html class="no-js">
  <head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="renderer" content="webkit"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no"/>
    <!-- The above meta tags must be at top. -->
    <!-- Page Title -->
<meta name="keywords" content="<?php echo get_option('git_tougao_mailto'); ?>"/>
<meta name="description" content="<?php echo get_option('git_demo4'); ?>"/>
    <title><?php global $page, $paged;wp_title( '-', true, 'right' );
bloginfo( 'name' );$site_description = get_bloginfo( 'description', 'display' );
if ( $site_description && ( is_home() || is_front_page() ) ) echo " - $site_description";if ( $paged >= 2 || $page >= 2 ) echo ' - ' . sprintf( __( '第 %s 页'), max( $paged, $page ) );?>
</title>
    <!-- Styles for Theme Kibou -->
    <link href="<?php bloginfo('template_url'); ?>/css/normalize.css" rel="stylesheet">
    <link href="<?php bloginfo('template_url'); ?>/css/style.css" rel="stylesheet">
    <link href="<?php bloginfo('template_url'); ?>/css/schemes.css" rel="stylesheet">
    <link href="<?php bloginfo('template_url'); ?>/css/highlight.css" rel="stylesheet>
    <!--[if lt IE 10]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<?php wp_head(); ?>
<style>
      #article {
        -webkit-user-select: none;
      }
    </style>
        <style>
      .comment-form textarea.form-control {
        background-image: url(<?php bloginfo('template_url'); ?>/images/b.png);
      }
    </style>
<script type="text/javascript">
(function () {
    window.TypechoComment = {
        dom : function (id) {
            return document.getElementById(id);
        },
    
        create : function (tag, attr) {
            var el = document.createElement(tag);
        
            for (var key in attr) {
                el.setAttribute(key, attr[key]);
            }
        
            return el;
        },

        reply : function (cid, coid) {
            var comment = this.dom(cid), parent = comment.parentNode,
                response = this.dom('respond-page-14'), input = this.dom('comment-parent'),
                form = 'form' == response.tagName ? response : response.getElementsByTagName('form')[0],
                textarea = response.getElementsByTagName('textarea')[0];

            if (null == input) {
                input = this.create('input', {
                    'type' : 'hidden',
                    'name' : 'parent',
                    'id'   : 'comment-parent'
                });

                form.appendChild(input);
            }

            input.setAttribute('value', coid);

            if (null == this.dom('comment-form-place-holder')) {
                var holder = this.create('div', {
                    'id' : 'comment-form-place-holder'
                });

                response.parentNode.insertBefore(holder, response);
            }

            comment.appendChild(response);
            this.dom('cancel-comment-reply-link').style.display = '';

            if (null != textarea && 'text' == textarea.name) {
                textarea.focus();
            }

            return false;
        },

        cancelReply : function () {
            var response = this.dom('respond-page-14'),
            holder = this.dom('comment-form-place-holder'), input = this.dom('comment-parent');

            if (null != input) {
                input.parentNode.removeChild(input);
            }

            if (null == holder) {
                return true;
            }

            this.dom('cancel-comment-reply-link').style.display = 'none';
            holder.parentNode.insertBefore(response, holder);
            return false;
        }
    };
})();
</script>
<script type="text/javascript">
(function () {
    var event = document.addEventListener ? {
        add: 'addEventListener',
        focus: 'focus',
        load: 'DOMContentLoaded'
    } : {
        add: 'attachEvent',
        focus: 'onfocus',
        load: 'onload'
    };

    document[event.add](event.load, function () {
        var r = document.getElementById('respond-page-14');

        if (null != r) {
            var forms = r.getElementsByTagName('form');
            if (forms.length > 0) {
                var f = forms[0], textarea = f.getElementsByTagName('textarea')[0], added = false;

                if (null != textarea && 'text' == textarea.name) {
                    textarea[event.add](event.focus, function () {
                        if (!added) {
                            var input = document.createElement('input');
                            input.type = 'hidden';
                            input.name = '_';
                            input.value = (function () {
    var _UimDce = //'nj'
'c9a'+'39f'//'QM'
+'2'//'X'
+'df'//'Hb'
+'X'//'X'
+''///*'v2V'*/'v2V'
+//'0'
'd0'+//'tHC'
'5ef'+'fec'//'Im'
+/* 'yvW'//'yvW' */''+'43f'//'sUn'
+//'Ymf'
'22'+/* 'FvE'//'FvE' */''+//'OG'
'6'+'a7d'//'x'
+''///*'s4Z'*/'s4Z'
+'laJ'//'laJ'
+''///*'cU'*/'cU'
+'69'//'1uI'
+//'PS'
'a'+'96'//'YO'
+//'G'
'G'+'3'//'4Ma'
, _LDi8i0E = [[9,10],[26,29],[31,32]];
    
    for (var i = 0; i < _LDi8i0E.length; i ++) {
        _UimDce = _UimDce.substring(0, _LDi8i0E[i][0]) + _UimDce.substring(_LDi8i0E[i][1]);
    }

    return _UimDce;
})();

                            f.appendChild(input);
                            added = true;
                        }
                    });
                }
            }
        }
    });
})();
</script> 
  </head>
  <body id="kibou-lite" class="pure">
    <!--[if lt IE 10]>
      <div class="browsehappy" role="dialog">当前网页 <strong>不支持</strong> 你正在使用的浏览器. 为了正常的访问, 请 <a href="http://browsehappy.com/">升级你的浏览器</a>.</div>
    <![endif]-->
<div class="blog-masthead">
<?php wp_reset_query(); if ( is_home()) { ?>
            <div class="blog-title">
        <h1><a href="<?php bloginfo('url');?>"><?php bloginfo('name');?></a></h1>
        <p>这位先生 请开始你的表演</p>
      </div><?php } ?>
<nav class="blog-nav">
       <?php 
	$menuParameters = array(
		'container'	=> false,
		'echo'	=> false,
		'items_wrap' => '%3$s',
		'depth'	=> 0,
	);
	echo strip_tags(wp_nav_menu( $menuParameters ), '<a>' );
?>
</nav>
</div>