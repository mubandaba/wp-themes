    <?php get_header(); ?>
    <div class="blog-container">
      <div class="blog-row">
        <div class="blog-main">
  <article id="article" itemscope="" itemtype="http://schema.org/BlogPosting">
    <h1 class="blog-post-title" itemprop="name headline"><?php the_title(); ?></h1>
    <p class="blog-post-meta">
      分类：<?php
$category = get_the_category();
if($category[0]){
echo '<a href="'.get_category_link($category[0]->term_id ).'">'.$category[0]->cat_name.'</a>';
}
?>&nbsp;•
      <time datetime="<?php echo timeago( get_gmt_from_date(get_the_time('Y-m-d G:i:s')) )?>" itemprop="datePublished"><?php echo timeago( get_gmt_from_date(get_the_time('Y-m-d G:i:s')) )?></time>• 阅读: <?php echo get_post_views(get_the_ID()); ?>
          </p>
        <p><?php if (have_posts()) while (have_posts()) {
            the_post();
            the_content();
        }; ?> </p>
    <p itemprop="keywords" class="post-tag-holder" style="padding-top:10px;"><?php the_tags('标签：', ', ', ''); ?></p>
  </article><!-- /.blog-post -->
  <ul class="article-switch">
<li class="prev"><span><?php if (get_previous_post()) { previous_post_link('%link');} else {echo "没有更多了";} ?></span></li>
 <li class="next"><span><?php if (get_next_post()) { next_post_link('%link');} else {echo "没有更多了";} ?></span></li>
  </ul>
<?php comments_template(); ?>
<?get_footer(); ?>