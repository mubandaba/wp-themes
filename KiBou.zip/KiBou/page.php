<?php
get_header();
include("comments.php");
get_footer(); ?>
