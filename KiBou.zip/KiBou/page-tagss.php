<?php /*
Template Name: 标签云
*/ ?>
<div>
<?php get_header(); ?>
<div class="blog-container">
      <div class="blog-row">
        <div class="blog-main">
<div style="display:none">
<p><?php if (have_posts()) while (have_posts()) {
            the_post();
            the_content();
        }; ?></p>
</div>
  <article id="article" itemscope="" itemtype="http://schema.org/BlogPosting">
    <p class="blog-post-meta">
      阅读: <?php echo get_post_views(get_the_ID()); ?>     </p>
    <h1 class="blog-post-title" itemprop="name headline">Tag Cloud</h1>
    <div style="padding-top:20px;text-align:center;">
<?php wp_tag_cloud( $args ); ?>
</div>
<hr/>
<?php next_posts_link('« Older Entries') ?>
<?php previous_posts_link('Newer Entries »') ?>
<h1 class="blog-post-title" itemprop="name headline">Recent Post</h1>
    <ol class="archives-loop">
<?php $count_posts = wp_count_posts(); $published_posts = $count_posts->publish; query_posts('posts_per_page=-1' );

while ( have_posts() ) : the_post();

echo '<li><a href="'; the_permalink();

echo '"><h3>';the_title();''; 

echo '</h3><span>';the_time(get_option( 'date_format' ));'</a></li>'; $published_posts--;

endwhile; wp_reset_query(); ?>

</span></a></li>

 </div>
      </li>
</ol>
  </article>

	 
</div>
</div>
</div>

<?php get_footer(); ?>