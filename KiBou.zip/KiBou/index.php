<?php
/**
 * @package kibou
 */
get_header();
?>
<div class="blog-container">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
      <div class="blog-row">
        <div class="blog-main">
 <article id="archives" itemscope="" itemtype="http://schema.org/BlogPosting">
    <h1 class="blog-post-title" itemprop="name headline"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
<p class="blog-post-meta">
      分类：<?php
$category = get_the_category();
if($category[0]){
echo '<a href="'.get_category_link($category[0]->term_id ).'">'.$category[0]->cat_name.'</a>';
}
?>&nbsp;•
      <time datetime="<?php echo get_the_time('c');?>" itemprop="datePublished"><?php echo timeago( get_gmt_from_date(get_the_time('Y-m-d G:i:s')) )?></time>
</p>
    <p> <?php the_content('...'); ?></p>
<p class="more"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">阅读</a></p>
  </article><!-- /.blog-post -->
<hr>
<?php endwhile; ?>
<center><ul class="page-change"><li class="active"><?php if (function_exists('pagenavi')) { pagenavi(1); } ?></li></ul></center>
</div>
      </div>
	<?php else : ?>
		<h3 class="title"><a href="#" rel="bookmark">未找到</a></h3>
		<p>没有找到任何文章！</p>
		<?php endif; ?>
    </div>
<?php get_footer(); ?>