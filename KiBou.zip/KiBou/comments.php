<?php
	if (isset($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
		die ('Please do not load this page directly. Thanks!');
?>
<!– Comment’s List –>
<div id="comments">

  <!-- Default -->
      <div id="respond-post-1" class="respond">
        <div class="comments-content">
	<?php 
if ( !comments_open() ) :
// If registration required and not logged in.
elseif ( get_option('comment_registration') && !is_user_logged_in() ) : 
?>
<p>你必须 <a href="<?php echo wp_login_url( get_permalink() ); ?>">登录</a> 才能发表评论.</p>
<?php else  : ?>
<!-- Comment Form -->
<form method="post" action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" id="comment-form" class="comment-form" role="form">
    <h3 id="response">评论卡</h3>
        <?php if ( !is_user_logged_in() ) : ?>
        <input type="text" name="author" maxlength="12" id="author" class="form-control input-control" placeholder="称呼" value="<?php echo $comment_author; ?>" required>

          <input type="email" name="mail" id="mail" class="form-control input-control" placeholder="Email" value="<?php echo $comment_author_email; ?>"  required>

           <input type="url" name="url" id="url" class="form-control input-control" placeholder="网址" value="<?php echo $comment_author_url; ?>" >
       
        <?php else : ?>
         
        <?php endif; ?>
       
              <textarea name="text" id="textarea" class="form-control" placeholder="请填写您的内容。" required></textarea>
       <a><script src="https://shawnzeng.com/wp-content/themes/Beginning/js/OwO.min.js"></script>
	<script>
        	var OwO_demo = new OwO({
            		logo: 'OωO表情',
            		container: document.getElementsByClassName('OwO')[0],
            		target: document.getElementById('comment'),
            		api: '/wp-content/themes/Beginning/OwO.json',
           		position: 'up',
            		width: '100%',
            		maxHeight: '250px'
        	});
    	</script>
</a>  
            <button type="submit" id="misubmit">提交</button>
    
    <?php comment_id_fields(); ?>
    <?php do_action('comment_form', $post->ID); ?>
</form>
<ol class="comment-list">
		<?php 
    if (!empty($post->post_password) && $_COOKIE['wp-postpass_' . COOKIEHASH] != $post->post_password) { 
        // if there's a password
        // and it doesn't match the cookie
    ?>
    <li class="decmt-box">
        <p><a href="#addcomment">请输入密码再查看评论内容.</a></p>
    </li>
    <?php 
        } else if ( !comments_open() ) {
    ?>
    <li class="decmt-box">
        <p><a href="#addcomment">评论功能已经关闭!</a></p>
    </li>
    <?php 
        } else if ( !have_comments() ) { 
    ?>
    <li class="decmt-box">
        <p><a href="#addcomment">还没有任何评论，你来说两句吧</a></p>
    </li>
    <?php 
        } else {
            wp_list_comments('type=comment&callback=aurelius_comment');
        }
    ?>
	</ol>
<?php endif; ?>