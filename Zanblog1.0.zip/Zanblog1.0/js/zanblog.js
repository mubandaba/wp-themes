jQuery(function () {
    jQuery('#myTab a:last').tab('show');
  })