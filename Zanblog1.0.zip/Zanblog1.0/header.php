<!DOCTYPE html>
<html lang='cn'>
<head>
<meta charset="utf-8">
<!-- 设置标题 -->
<title>
  <?php if ( is_home() ) { ?><?php bloginfo('name') ?> | <?php bloginfo('description'); ?><?php } ?>
  <?php if ( is_search() ) { ?>Search Results | <?php bloginfo('name'); ?><?php } ?>
  <?php if ( is_author() ) { ?>Author Archives | <?php bloginfo('name'); ?><?php } ?>
  <?php if ( is_single() ) { ?><?php wp_title(''); ?> | <?php bloginfo('name'); ?><?php } ?>
  <?php if ( is_page() ) { ?><?php wp_title(''); ?> | <?php bloginfo('name'); ?><?php } ?>
  <?php if ( is_category() ) { ?><?php single_cat_title(); ?> | <?php bloginfo('name'); ?><?php } ?>
  <?php if ( is_month() ) { ?><?php the_time('F'); ?> | <?php bloginfo('name'); ?><?php } ?>
  <?php if (function_exists('is_tag')) { if ( is_tag() ) { ?><?php bloginfo('name'); ?> | Tag Archive | <?php single_tag_title("", true); } } ?>
</title> 

<!-- 设置描述性标签和关键词标签 -->
<?php
 if (is_home()){
        $description = "Zanblog是由佚站互联开发的基于Bootstrap框架的WordPress博客主题。采用扁平化设计、清新配色风格。";
        $keywords = "Zanblog, Bootstrap, WordPress, 扁平化设计";
    } elseif (is_single()){
        if ($post->post_excerpt) {
            $description  = $post->post_excerpt;
    } else {
   if(preg_match('/<p>(.*)<\/p>/iU',trim(strip_tags($post->post_content,"<p>")),$result)){
        $post_content = $result['1'];
       } else {
        $post_content_r = explode("\n",trim(strip_tags($post->post_content)));
        $post_content = $post_content_r['0'];
       }
             $description = substr($post_content,0,220); 
      }
        $keywords = "";
        $tags = wp_get_post_tags($post->ID);
        foreach ($tags as $tag ) {
           $keywords = $keywords . $tag->name . ",";
        }
    }
?>

<meta content="<?php echo trim($description); ?>" name="description"/>
<meta content="<?php echo rtrim($keywords,','); ?>" name="keywords"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- 引入CSS -->
<link href="<?php bloginfo('stylesheet_url');?>" rel="stylesheet">


<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

<?php wp_enqueue_script("jquery"); ?>
<?php wp_head(); ?>

</head>
<body>
<div id="zan-header" class="navbar navbar-inverse navbar-fixed-top bs-docs-nav">
  <div class="container">

  <a class="navbar-brand" href="<?php echo site_url(); ?>"><?php bloginfo('name'); ?></a>
  <button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".bs-navbar-collapse">
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
  </button>
    <div class="nav-collapse collapse bs-navbar-collapse">
      <?php
        $defaults = array(
          'menu_class' => 'nav navbar-nav',
        );
        wp_nav_menu( $defaults );
      ?>
          <div class="search visible-lg">
       <form method="get" id="searchform" class="form-inline" action="<?php bloginfo('url'); ?>">
            <input class="text input-small" type="text" value=" " name="s" id="s" placeholder="搜索" />
            <input type="submit" class="btn btn-default btn-small" name="submit" value="<?php _e('Search');?>" />
      </form>
    </div>
    </div>
  </div>
</div>
<!-- //zan-header -->