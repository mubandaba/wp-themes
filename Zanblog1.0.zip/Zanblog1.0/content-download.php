<?php
/*
Template Name: content-download
*/
?>

<?php get_header(); ?>
<div id="zan-bodyer">
	<div class="container">
		<div class="bs-masthead">
			<h1>Zanblog</h1>
			<p class="lead">Zanblog是由佚站互联制作的基于Bootstrap3.0的WordPress主题，采用Bootstrap3.0的扁平化设计风格，提供免费下载，希望大家能够喜欢:)有任何问题都可以在<a href="http://www.yeahzan.com/zanblog/message">留言板</a>处提出，感谢您的意见与建议。
			</p>
			<p>
				<a class="btn btn-large" onclick="_gaq.push(['_trackEvent', 'Jumbotron actions', 'Download', 'Download 3.0.0']);" href="http://pan.baidu.com/share/link?shareid=3418275486&uk=3291201722">下载Zanblog</a>
			
				<a class="btn btn-large" onclick="_gaq.push(['_trackEvent', 'Jumbotron actions', 'Download', 'Download 3.0.0']);" href="http://www.yeahzan.com/zanblog/archives/131.html">使用说明</a>
			</p>
		</div>
	</div>
</div>
<?php get_footer(); ?>
</body>
</html>