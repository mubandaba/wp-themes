<?php
if(is_admin()){
	require VICE_TEMPLATE_DIR . '/admin/inc/class-vice-about-page.php';
}

require VICE_TEMPLATE_DIR . '/admin/inc/plugin-include-control.php';
require VICE_TEMPLATE_DIR . '/admin/inc/include-companion.php';


