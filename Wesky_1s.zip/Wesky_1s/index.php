<?php get_header(); ?>
<div id="roll"><div title="回到顶部" id="roll_top"></div><div title="转到底部" id="fall"></div></div>
<div id="content">
<div class="main">
<?php if (have_posts()) : ?>

<?php if (get_option('swt_cms') == 'Display') { ?>
<?php include(TEMPLATEPATH . '/includes/slider.php'); //文章热榜 ?>
<?php if (get_option('swt_cmsadd') == 'Display') { ?>
<div class="article" style="text-align:center;overflow:hidden;margin-top:10px;margin-bottom:10px;">
<?php echo stripslashes(get_option('swt_cmsads')); ?></div>
<?php { echo ''; } ?><?php } ?><?php } ?>

<?php if (get_option('swt_cms') == 'Display') { ?>
<?php $args = array('posts_per_page' => 3,);query_posts($args);?>
<?php } ?>

	<?php while (have_posts()) : the_post(); ?>
<ul <?php post_class(); ?> id="post-<?php the_ID(); ?>">
<li>
<div class="article">
<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="详细阅读 <?php the_title_attribute(); ?>"><?php the_title(); ?></a><span class="new"><?php include('includes/new.php'); ?></span></h2>
<?php if (get_option('swt_thumbnail') == 'Display') { ?>
        <?php if (get_option('swt_articlepic') == 'Display') { ?>
<?php include('includes/articlepic.php'); ?>
    <?php { echo ''; } ?>
			<?php } else { include(TEMPLATEPATH . '/includes/thumbnail.php'); } ?>
<?php { echo ''; } ?><?php } else { } ?>
<div class="entry_post"><span><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 350,"..."); ?></span></div>
<div class="clear"></div>
<div class="info">作者：<?php the_author() ?>/<?php the_time(Y年n月d日) ?>/分类：<?php the_category(', ') ?>/阅读：<?php post_views('', '次'); ?>/<?php the_tags('标签：', ', ', ''); ?>/<?php comments_popup_link ('抢沙发','1条评论','%条评论'); ?></div>
<div class="comments_num" style="color: white;text-decoration:none;"><a href="<?php the_permalink() ?>" title="详细阅读 <?php the_title(); ?>" rel="bookmark" style="color: white;text-decoration:none;">阅读全文</a></div>
</div></li></ul>
<div class="clear"></div>
		<?php endwhile; ?>
		<?php endif; ?> 

<?php if (get_option('swt_cms') == 'Display') { ?>

<?php if (get_option('swt_recimg') == 'Display') { ?>
<?php if (get_option('swt_sliders') == '置顶文章') { ?>
<?php include(TEMPLATEPATH . '/includes/cat_slider.php'); ?>
<?php } else { include(TEMPLATEPATH . '/includes/sti_slider.php'); } ?>
<div class="cmsimg"><div class="img_listbox">
<h2><?php single_cat_title(); ?></h2>
<?php while (have_posts()) : the_post(); ?>
<ul><li><div class="img_5">
<a target="_blank" href="<?php the_permalink() ?>">
<img src="<?php if (get_option('swt_sliceimg') == 'Display') { ?>
<?php bloginfo('template_directory'); ?>/timthumb.php?w=100&h=100&src=<?php } ?><?php echo catch_first_image() ?>" width="100" height="100" title="<?php the_title(); ?>"></a></div>
<a target="_blank" href="<?php the_permalink() ?>"></a></li></ul><?php endwhile; ?>
</div></div>

<?php } ?>

<?php include(TEMPLATEPATH . '/includes/cms.php'); //CMS模式 ?>
<?php } ?>
<?php if (get_option('swt_cms') == 'Hide') { ?>
<div class="navigation"><?php pagination($query_string); //分页 ?></div>
<?php } ?>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>