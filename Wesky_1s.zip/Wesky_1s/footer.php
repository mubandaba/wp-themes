</div>
<div class="clear"></div>
<div id="footer">
Copyright 2012-2013 <?php bloginfo('name'); ?> | 
Powered by <a href="http://v7v3.com" rel="external">wordpress</a> | Theme <a href="http://www.gsky.org/" rel="external">Wesky</a> | 
<?php if (get_option('swt_tj') == 'Display') { ?><?php echo stripslashes(get_option('swt_tjcode')); ?> <?php { echo ' | '; } ?>	<?php } ?>
<?php if (get_option('swt_beian') == 'Display') { ?><?php echo stripslashes(get_option('swt_beianhao')); ?> <?php { echo ''; } ?><?php } ?> 
</div>
<?php wp_footer(); ?>
</div>
<?php if (get_option('swt_imgshare') == 'Display') { ?>
<?php if(is_single()) { ?>
<script id="bdimgshare_shell"></script>
<script>
var bdShare_config_imgshare = {
	"type":"list"
	,"size":"small"
	,"pos":"top"
	,"color":"black"
	,"list":["qzone","tsina","tqq","renren","t163"]
	,"uid":"4520644"
};
document.getElementById("bdimgshare_shell").src="http://bdimg.share.baidu.com/static/js/imgshare_shell.js?cdnversion=" + Math.ceil(new Date()/3600000);
</script>
<?php } ?><?php } ?>
<?php if (get_option('swt_ie6') == 'Display') { ?>
<!--[if IE 6]>
	<script src="//letskillie6.googlecode.com/svn/trunk/2/zh_CN.js"></script>
<![endif]-->
<?php } ?>
</body>
</html>