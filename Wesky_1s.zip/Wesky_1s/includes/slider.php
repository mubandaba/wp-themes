<div class="cmstop">
           <div class="img_topbox">
<h2>文章热榜</h2>
<?php query_posts(array('posts_per_page' => 4,'caller_get_posts' =>1,'orderby' =>comment_count,)); while ( have_posts() ) : the_post(); ?>
            	<ul>
        			<li><div class="img_5"><a href="<?php the_permalink() ?>"><img src="<?php if (get_option('swt_sliceimg') == 'Display') { ?><?php bloginfo('template_directory'); ?>/timthumb.php?w=150&h=85&src=<?php } ?><?php echo catch_first_image() ?>" width="150" height="85" title="<?php the_title(); ?>"></a></div>
<span><a target="_blank" href="<?php the_permalink() ?>"></a>
                                <span><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php echo mb_strimwidth(get_the_title($post->comment_post_ID),0,24,'...'); ?></a></span></li>
                </ul>
<?php endwhile;wp_reset_query();?>
</div></div>