<h3><span>最新文章</span><span class="selected">随机精彩</span><span>热门排行</span></h3>
	<div id="tab-content">
		<ul class="hide"><?php query_posts(array('posts_per_page' => 10,'caller_get_posts' =>1,'orderby' =>date,));
while ( have_posts() ) : the_post(); ?>
					<li><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php echo mb_strimwidth(get_the_title($post->comment_post_ID),0,34,'...'); ?></a></li>
					<?php endwhile;wp_reset_query();?></ul>

		<ul><?php query_posts(array('posts_per_page' => 10,'caller_get_posts' =>1,'orderby' =>rand,)); 
while ( have_posts() ) : the_post(); ?>
<li><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php echo mb_strimwidth(get_the_title($post->comment_post_ID),0,34,'...'); ?></a></li>
<?php endwhile;wp_reset_query();?></ul>

		<ul class="hide"><?php query_posts(array('posts_per_page' => 10,'caller_get_posts' =>1,'orderby' =>comment_count,)); 
while ( have_posts() ) : the_post(); ?>
					<li><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php echo mb_strimwidth(get_the_title($post->comment_post_ID),0,34,'...'); ?></a></li>
					<?php endwhile;wp_reset_query();?></ul>

					</div>