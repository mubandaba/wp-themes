<?php
add_action('admin_init', function () {
	remove_submenu_page('themes.php', 'theme-editor.php');
}, 999);

if(PHP_VERSION >= 7.2){
	add_filter('wpjam_pages', function ($wpjam_pages){
		global $plugin_page;

		$wpjam_pages['wpjam-sweet']	= [
			'menu_title'	=> 'SWEET',
			'icon'			=> 'dashicons-buddicons-replies',
			'capability'	=> 'manage_options',
			'position'		=> '59',
			'function'		=> 'option',
			'option_name'	=> 'wpjam_theme',
			'page_file'		=> TEMPLATEPATH .'/admin/theme-setting.php'
		];

		unset($wpjam_pages['wpjam-basic']['subs']['wpjam-thumbnail']);

		return $wpjam_pages;
	});
}

add_filter('admin_footer_text', function (){
	return 'Powered by <a href="http://www.xintheme.com" target="_blank">新主题 XinTheme</a> + <a href="https://blog.wpjam.com/" target="_blank">WordPress 果酱</a>';
});

add_filter('admin_title', function ($admin_title, $title){
	return $title.' &lsaquo; '.get_bloginfo('name');
}, 10, 2);

add_action('admin_head', function(){
	echo '<style type="text/css">  
		.wp-first-item.wp-not-current-submenu.wp-menu-separator,.hide-if-no-customize{display: none;}
	</style>';
} );

add_filter('wpjam_extends_setting', function($wpjam_setting){
	unset($wpjam_setting['fields']['related-posts.php']);
	unset($wpjam_setting['fields']['wpjam-postviews.php']);
	// unset($wpjam_setting['fields']['mobile-theme.php']);

	return $wpjam_setting;
}, 99);














