<?php
function wpjam_timeline_page(){
	$post_formats	= get_theme_support( 'post-formats' );

	$format_options	= [];

	foreach($post_formats[0] as $format) {
		$format_options[$format]	= get_post_format_string($format);
	}
	
	$form_fields	= [
		'post_format'	=> ['title'=>'',		'type'=>'select',	'options'=>$format_options]
	];

	echo '<h2>文章格式</h2>';

	wpjam_ajax_form([
		'fields'		=> $form_fields, 
		'action'		=> 'set',
		'submit_text'	=> '设置'
	]);

}


