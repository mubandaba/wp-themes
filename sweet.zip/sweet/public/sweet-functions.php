<?php
function wpjam_theme_get_setting($setting_name){
	return wpjam_get_setting('wpjam_theme', $setting_name);
}

function wpjam_theme_get_bg_img($post=null, $width=1000){
	// $default_bg_img	= wpjam_theme_get_setting('bg_img');
	// $default_bg_img	= $default_bg_img ? wpjam_get_thumbnail($default_bg_img, [$width]) : '';

	if(is_singular('post') || $post){
		$bg_img	= wpjam_get_post_thumbnail_url($post, [$width]);
		// $bg_img ?: $default_bg_img;
	}else{
		$bg_img	= '';

		if(is_category()){
			$bg_img	= wpjam_get_term_thumbnail_url(null, [$width]);
		}

		if(empty($bg_img)){
			$bg_img	= wpjam_get_post_thumbnail_url($post, [$width]);
		}
	}
	
	return $bg_img;
}

function wpjam_theme_get_random_color() {
	$colors  = array(
		'linear-gradient(90deg,#9c4dff 0,#42a7ff 100%)',
		'linear-gradient(to right,#4a00e0,#8e2de2)',
		'linear-gradient(90deg, #8466ff 0%, #8466ff 100%)'
	);

	shuffle($colors);
	return $colors[0];
}

add_action('after_setup_theme', function(){
	add_theme_support('title-tag');
	add_theme_support('post-thumbnails');

	register_nav_menus(['main'=>'主菜单']);
});

if(wpjam_get_setting('wpjam_theme', 'foot_link')){
	add_filter('pre_option_link_manager_enabled', '__return_true');	/*激活友情链接后台*/
}

add_filter('weapp_show_post_author', function(){
	return wpjam_theme_get_setting('show_post_author');
});

//载入JS\CSS
add_action('wp_enqueue_scripts', function () {
	if(!is_admin()){

		// wp_enqueue_style('style', get_stylesheet_directory_uri().'/static/css/sweet.css');
		wp_enqueue_style('fancybox', 'https://cdn.staticfile.org/fancybox/3.5.7/jquery.fancybox.min.css');
		
		if(!did_action('wpjam_static')){
			wp_enqueue_style('style', get_stylesheet_directory_uri().'/static/css/sweet.css');
			wp_enqueue_script('sweet', get_stylesheet_directory_uri().'/static/js/sweet.js', ['jquery']);
		}
		
		wp_enqueue_script('fancybox',	'https://cdn.staticfile.org/fancybox/3.5.7/jquery.fancybox.min.js', ['jquery']);

		if(is_singular() && comments_open() && get_option('thread_comments')){
			wp_enqueue_script('comment-reply');
		}
	}	
});

add_action('init', function(){
	if(did_action('wpjam_static')){
		wpjam_register_static('sweet-style', [
			'type'		=> 'style',
			'source'	=> 'file',
			'file' 		=> get_stylesheet_directory().'/static/css/sweet.css',
			'baseurl'	=> get_stylesheet_directory_uri().'/static/css/'
		]);

		wpjam_register_static('sweet-script', [
			'type'		=> 'script',
			'source'	=> 'file',
			'file' 		=> get_stylesheet_directory().'/static/js/sweet.js',
		]);
	}
});

add_filter('the_content', function($content){
	$post	= get_post();
	$format	= get_post_format($post);

	if(!$format){
		//fancybox3图片添加 data-fancybox
		$pattern		= "/<a(.*?)href=('|\")([^>]*).(bmp|gif|jpeg|jpg|png|swf)('|\")(.*?)>(.*?)<\/a>/i";
		$replacement	= '<a$1href=$2$3.$4$5 data-fancybox="images" $6>$7</a>';
		$content		= preg_replace($pattern, $replacement, $content);
		$content		= str_replace(']]>', ']]>', $content);
	}

	return $content;
});

add_filter('use_default_gallery_style', '__return_false');

//默认文章缩略图
add_filter('wpjam_default_thumbnail_url',function ($default_thumbnail){
	$default_thumbnails	= wpjam_get_setting('wpjam_theme', 'thumbnails');

	if($default_thumbnails){
		shuffle($default_thumbnails);
		return $default_thumbnails[0];
	}else{
		return $default_thumbnail;
	}
},99);

add_filter('wpjam_post_thumbnail_url', function($thumbnail_url, $post){
	$format	= get_post_format($post);

	if(!$format){
		if(!$thumbnail_url){
			if($post_first_image = wpjam_get_post_first_image_url($post)){
				return $post_first_image;
			}

			if($terms = get_the_terms($post, 'category')){
				foreach ($terms as $term) {
					if($term_thumbnail = wpjam_get_term_thumbnail_url($term)){
						return $term_thumbnail;
					}
				}
			}
		}
	}

	return $thumbnail_url;
}, 10, 2);


add_filter('register_taxonomy_args', function($args, $taxonomy){
	if($taxonomy == 'category'){
		$args['levels']		= 1;
		$args['sortable']	= true;
	}

	return $args;
}, 1, 2);

add_action('registered_post_type', function($post_type){
	if($post_type == 'post'){
		add_post_type_support($post_type, 'favs');
	}
});

function wpjam_sweet_thumbnail_option(){
	return [
		'term_thumbnail_type'		=> 'img',
		'term_thumbnail_taxonomies'	=> ['category'],
		'term_thumbnail_width'		=> 480,
		'term_thumbnail_height'		=> 640,
		'post_thumbnail_orders'		=> []
	];
}

add_filter('default_option_wpjam-thumbnail', 'wpjam_sweet_thumbnail_option');

add_filter('option_wpjam-thumbnail', function($value){
	$value	= $value ?: [];

	return array_merge($value, wpjam_sweet_thumbnail_option());
});

add_filter('wpjam_content_image_width', function(){
	return wp_is_mobile() ? 600 : 780;
});

$wpjam_extends	= get_option('wpjam-extends');
if($wpjam_extends){
	$wpjam_extends_updated	= false;
	if(!empty($wpjam_extends['related-posts.php'])){
		unset($wpjam_extends['related-posts.php']);
		$wpjam_extends_updated	= true;
	}

	if(!empty($wpjam_extends['wpjam-postviews.php'])){
		unset($wpjam_extends['wpjam-postviews.php']);
		$wpjam_extends_updated	= true;
	}

	// if(!empty($wpjam_extends['mobile-theme.php'])){
	// 	unset($wpjam_extends['mobile-theme.php']);
	// 	$wpjam_extends_updated	= true;
	// }

	if($wpjam_extends_updated){
		update_option('wpjam-extends', $wpjam_extends);
	}
}

/* 评论作者链接新窗口打开 */
add_filter('get_comment_author_link', function($return){
	return str_replace('<a ', '<a target=\'_blank\' ', $return);
});

add_action('wp_head', function (){
	if($favicon = wpjam_theme_get_setting('favicon')){
		echo '<link href="'.$favicon.'" rel="shortcut icon" type="image/x-icon">';
	}
	
	if($apple_icon = wpjam_theme_get_setting('apple-icon')){
		echo '<link href="'.$apple_icon.'" rel="apple-touch-icon">';
	}

	if(is_singular()) { 
		global $post;
		wpjam_update_post_views($post->ID);
	}
}); 

add_action('pre_get_posts', function($wp_query) {
	if($wp_query->is_main_query()){
		if(is_home()){
			if($wp_query->get('paged') < 2){
				$sticky_posts	= get_option('sticky_posts');
				if($sticky_posts){
					$wp_query->set('post__not_in', [current($sticky_posts)]);
				}
			}

			$wp_query->set('ignore_sticky_posts', true);
		}elseif(is_author()){
			$wp_query->set('posts_per_page', 10);
		}
	}
	
});

add_filter('category_description', function ($description) {
	return trim(wp_strip_all_tags($description));
});

function wpjam_theme_list_comments($comment, $args, $depth){ ?>
	<li id="comment-<?php comment_ID() ?>" <?php comment_class(); ?>>
		<div id="div-comment-<?php comment_ID() ?>" class="comment-wrapper u-clearfix">
			<div class="comment-author-avatar vcard"><?php echo get_avatar($comment, 60); ?></div>
			<div class="comment-content">
				<div class="comment-author-name vcard"><cite class="fn"><?php comment_author_link();?></cite></div>
				<div class="comment-metadata">
					<time><?php comment_date() ?> <?php comment_time() ?></time>
					<span class="reply-link"><?php comment_reply_link(array_merge($args, ['depth'=>$depth, 'max_depth'=>$args['max_depth']+1, 'reply_text'=>"回复"])); ?></span>
				</div>
				<div class="comment-body" itemprop="comment">
					<?php comment_text($comment, $args); ?>
					<?php if($comment->comment_approved == '0'){ ?><span class="unapproved">您的评论正在等待审核中...</span><?php } ?>
				</div>
			</div>
		</div>
	</li>
<?php }


