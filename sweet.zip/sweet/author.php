<?php
get_header();

get_template_part('template-parts/index', 'grid');

get_footer();