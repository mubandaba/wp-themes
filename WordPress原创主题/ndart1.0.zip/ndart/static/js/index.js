$(document).ready(function(){
	
	//文章表格添加样式
	$('.single-content table').addClass('uk-table uk-table-divider uk-text-small');

    //返回顶部
    $(window).scroll(function() {
        var scroll_top = $(window).scrollTop();
        if (scroll_top >= 200) {
            $(".gotop").fadeIn();
        } else {
            $(".gotop").fadeOut();
        }
    })

	//获取日期
	var myDate = new Date;
	var year = myDate.getFullYear(); //获取当前年
	var mon = myDate.getMonth() + 1; //获取当前月
	var date = myDate.getDate(); //获取当前日
	var week = myDate.getDay();
	var weeks = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"];
	$(".time").html(year + "年" + mon + "月" + date + "日 " + weeks[week]);

	
	//添加灯箱
	$('.wp-block-gallery').attr( 'uk-lightbox' ,'animation: fade' );
	$('.wp-block-image').attr( 'uk-lightbox' ,'animation: fade' );
	
	
});



console.log('\n' + ' %c Theme Designed by 阿叶 %c www.nuandao.cn ' + '\n', 'color: #fff; background: #00d495; padding:5px 0; font-size:12px;', 'padding:5px 0; font-size:12px;');
