<?php $term = get_category(get_query_var('cat')); ?>
<div class="part-head uk-grid-collapse uk-margin-top" uk-grid>
	<div class="uk-width-expand">
		<div class="part-head-text">
			<p class="uk-margin-remove-top uk-text-truncate"><?php single_cat_title(); ?></p>
			<span class="uk-display-inline-block uk-text-small uk-text-muted uk-text-truncate">
			    <?php 
			        $category_description= category_description();
			        if(!$category_description){
			            echo '暂无简介 - 唯美图片(wmpic.com)';
			        }else {
			            echo $category_description;
			        }
			    ?>
			</span>
		</div>
	</div>
	<div class="uk-width-auto uk-visible@s">
		<div class="part-head-img uk-text-center">
            <?php
                $args = array(
                'post_type' => 'post',
                'showposts' => 3,
                'post__in' => get_option('sticky_posts'),//获取置顶文章
                'cat' => 5,//指定分类id
                );
				$catquery = new WP_Query($args);
				while($catquery->have_posts()) : $catquery->the_post();
			?>
		    <a href="<?php the_permalink() ?>" target="_blank" class="uk-display-inline-block">
		        <img src="<?php echo post_thumbnail_src() ?>" alt="<?php single_cat_title(); ?>"/>
		    </a>
			<?php endwhile; ?>
		</div>
	</div>
</div>
<div class="part-nav b-t b-b uk-flex uk-flex-middle">
	<ul class="uk-flex-1 uk-padding-remove uk-margin-remove">
	    <li class="current-cat"><a href="<?php get_category_cat() ?>" class="all uk-text-contrast">全部</a></li>
		<?php wp_list_categories('child_of=' . get_category_root_id($cat) . '&depth=1&hide_empty=0&hierarchical=1&optioncount=1&title_li=');?>
	</ul>
	<div class="uk-visible@s">共 <b class="uk-text-warning"><?php echo aye_get_cat_postcount($term->term_id); ?></b> 篇帖子</div>
</div>