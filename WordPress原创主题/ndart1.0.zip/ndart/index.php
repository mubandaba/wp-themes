<?php get_header();?>
<?php get_template_part( 'template-parts/home', 'tx' ); ?>
<?php get_template_part( 'template-parts/home', 'wz' ); ?>
<?php get_template_part( 'template-parts/home', 'tp' ); ?>
<?php get_footer();?>
