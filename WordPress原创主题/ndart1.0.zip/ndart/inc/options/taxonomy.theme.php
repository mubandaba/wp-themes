<?php if (! defined('ABSPATH')) {
    die;
}
if (class_exists('CSF')) {
    $prefix = 'my_taxonomy_options';
    CSF::createTaxonomyOptions($prefix, array(
        'taxonomy' => 'category',
        'data_type' => 'unserialize ',
    ));
    CSF::createSection($prefix, array(
        'fields' => array(
            array(
                'id' => 'cat_theme',
                'type' => 'button_set',
                'title' => '<h3>选择分类布局样式</h3>',
                'options' => array(
                    '1' => '头像布局',
                    '2' => '图集布局',
                    '3' => '文章布局',
                ),
                'default' => '2'
            ),
        )
    ));
}