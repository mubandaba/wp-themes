<?php
# --------------------------------------------------------------------
# 禁止自动生成 768px 缩略图
# --------------------------------------------------------------------
function shapeSpace_customize_image_sizes($sizes) {
    unset($sizes['medium_large']);
    return $sizes;
  }
add_filter('intermediate_image_sizes_advanced', 'shapeSpace_customize_image_sizes');

# --------------------------------------------------------------------
# wordpress禁用图片属性srcset和sizes
# --------------------------------------------------------------------
add_filter( 'add_image_size', function(){return 1;} );
add_filter( 'wp_calculate_image_srcset_meta', '__return_false' );
add_filter( 'big_image_size_threshold', '__return_false' );

# --------------------------------------------------------------------
# 禁止WordPress自动生成缩略图
# --------------------------------------------------------------------
function ztmao_remove_image_size($sizes) {
    unset( $sizes['small'] );
    unset( $sizes['medium'] );
    unset( $sizes['large'] );
    return $sizes;
}
add_filter('image_size_names_choose', 'ztmao_remove_image_size');

# --------------------------------------------------------------------
# WordPress开启友情链接管理
# --------------------------------------------------------------------
add_filter( 'pre_option_link_manager_enabled', '__return_true' );

# --------------------------------------------------------------------
# WordPress搜索结果排除所有页面、自定义分类
# --------------------------------------------------------------------
//搜索结果排除所有页面
function search_filter_page($query) {
	if ($query->is_search) {
		$query->set('post_type', 'post');
	}
	return $query;
}
add_filter('pre_get_posts','search_filter_page');

//搜索结果排除自定义分类(post_type)
function searchAll( $query ) {
	if ( $query->is_search ) { $query->set( 'post_type', array( 'site' )); } 
	return !$query;
}
add_filter( 'the_search_query', 'searchAll' );

# --------------------------------------------------------------------
# WordPress获取全站文章浏览量
# --------------------------------------------------------------------
function all_view() {
    global $wpdb;
    $count=0;
    $views= $wpdb->get_results("SELECT * FROM $wpdb->postmeta WHERE meta_key='views'");
    foreach($views as $key=>$value)
    {
        $meta_value=$value->meta_value;
        if($meta_value!=' '){
            $count+=(int)$meta_value;
    }
}
return $count;
}

# --------------------------------------------------------------------
# 获取当前文章自定义分类法名称
# --------------------------------------------------------------------
function custom_taxonomies_terms_links(){
	$post = get_post( $post->ID );
	$post_type = $post->post_type;
	$taxonomies = get_object_taxonomies( $post_type, 'objects' );
	$out = array();
	foreach ( $taxonomies as $taxonomy_slug => $taxonomy ){
		$term_list = wp_get_post_terms($post->ID, $taxonomy_slug, array("fields" => "all"));
		echo $term_list[0]->name; //显示文章所处的分类中的第一个
	}
	return implode('', $out );
}