<?php

/*
 * ------------------------------------------------------------------------------
 * 个人资料添加字段
 * ------------------------------------------------------------------------------
 */

add_filter('user_contactmethods', 'boke112_user_contact');
function boke112_user_contact($user_contactmethods){
	$user_contactmethods['qq'] = 'QQ号';
	$user_contactmethods['weibo'] = '微博';
	$user_contactmethods['weixin'] = '微信';
	$user_contactmethods['userbg'] = '用户中心背景图';
	unset( $contactmethods['yim'] );
	unset( $contactmethods['aim'] );
	unset( $contactmethods['jabber'] );
	return $user_contactmethods;
}


/*
 * ------------------------------------------------------------------------------
 * 仅显示当前用户的文章、媒体文件
 * ------------------------------------------------------------------------------
 */
add_action('pre_get_posts', function ( $wp_query_obj ) {
	global $current_user, $pagenow;
	if( !is_a( $current_user, 'WP_User') )
		return;
	if( 'admin-ajax.php' != $pagenow || $_REQUEST['action'] != 'query-attachments' )
		return;
	if( !current_user_can( 'manage_options' ) && !current_user_can('manage_media_library') )
		$wp_query_obj->set('author', $current_user->ID );
	return;
});


/*
 * ------------------------------------------------------------------------------
 * 当前作者文章浏览总数
 * ------------------------------------------------------------------------------
 */
if(!function_exists('cx_posts_views')) {
	function cx_posts_views($author_id = 1 ,$display = true) {
		global $wpdb;
		$sql = "SELECT SUM(meta_value+0) FROM $wpdb->posts left join $wpdb->postmeta on ($wpdb->posts.ID = $wpdb->postmeta.post_id) WHERE meta_key = 'views' AND post_author =$author_id";
		$comment_views = intval($wpdb->get_var($sql));
		if($display) {
			echo number_format_i18n($comment_views);
		} else {
			return $comment_views;
		}
	}
}

/*
 * ------------------------------------------------------------------------------
 * wordpress 素材达人
 * ------------------------------------------------------------------------------

function get_talent() {
    $user_id  = get_the_author_ID(); 
    $user_count =  count_user_posts($user_id); 
    $template_url= get_template_directory_uri();
    if( $user_count > 50 ){
        echo'<img src="' .$template_url. '/static/images/medal/medal-talent.png" uk-tooltip title="「wmpic」素材达人" alt="发帖数量超过50后即可获得此勋章" class="user_role" />';
    }
}
 */


/*
 * ------------------------------------------------------------------------------
 * 获取用户角色 echo get_user_role()
 * ------------------------------------------------------------------------------

function get_user_role() {
	$template_url= get_template_directory_uri();
	$user_id=get_post($id)->post_author;   
	if(user_can($user_id,'administrator')){
		echo'<img src="' .$template_url. '/static/images/medal/medal-admin.gif" uk-tooltip title="「wmpic」管理员" alt="「wmpic」管理员" class="user_role" />';
	}elseif(user_can($user_id,'edit_others_posts')){
		echo'<img src="' .$template_url. '/static/images/medal/medal-edit.png" uk-tooltip title="「wmpic」特邀编辑" alt="「wmpic」特邀编辑" class="user_role" />';
	}elseif(user_can($user_id,'author')){
		echo'<img src="' .$template_url. '/static/images/medal/medal-author.png" uk-tooltip title="「wmpic」特邀作者" alt="「wmpic」特邀作者" class="user_role" />';
	}elseif(user_can($user_id,'delete_posts')){
		echo'';
	}elseif(user_can($user_id,'contributor')){
		echo'';
	}
	elseif(user_can($user_id,'subscriber')){
		echo'';
	}
}
 */