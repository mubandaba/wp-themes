<?php 
	$user_id  = get_the_author_ID(); 
	$args = array(
	'post_author' => $user_id 
	);
	$author_comments = get_comments($args);
?>
<div class="uk-grid-small" uk-grid>
    <div class="uk-width-auto uk-visible@s">
        <div class="author-card part uk-background-default">
            <div class="uk-background-default uk-overflow-hidden">
                <div class="b-b uk-text-center uk-padding">
                    <?php echo get_avatar( get_the_author_meta( 'ID' ),'100' ); ?>
                    <div class="uk-margin-top"><?php the_author_posts_link(); ?></div>
                </div>
            </div>
            <ul class="uk-list uk-margin-remove">
                <li><span>UID</span>: <?php the_author_ID(); ?></li>
                <li><span>帖子</span>: <?php echo count_user_posts(get_the_author_ID()); ?></li>
                <li><span>评论</span>: <?php echo count($author_comments); ?></li>
            </ul>
        </div>
    </div>
    <div class="uk-width-expand">
        <?php if(_aye('comments_close') == true ): ?>	
		<?php if ( comments_open() || get_comments_number() ) : ?>
		<?php comments_template( '', true ); ?>
		<?php endif; ?>
		<?php endif; ?>
		<div class="uk-margin uk-background-default">
		    <div class="part-title b-b">
		        <span class="uk-display-inline-block">随便看看</span>
		    </div>
		    <div class="part-content uk-grid-small" uk-grid="masonry: true">
    		    <?php
            		$side_art_num = _aye('side_art_num');
            		$cat = get_the_category();
            		foreach($cat as $key=>$category){
            			$catid = $category->term_id;
            		}
            		$args = array(
            		    'ignore_sticky_posts' => 1,
            			'meta_key' => 'views',
            			'orderby' => 'meta_value_num',
            		    'showposts' => 12 ,
            		    'cat' => $catid 
            		);
            		$query_posts = new WP_Query();
            		$query_posts->query($args);
            		while ($query_posts->have_posts()) : $query_posts->the_post();
            	?>
            	
    		    <div class="uk-width-1-2 uk-width-1-4@m uk-width-1-4@xl">
    			<?php get_template_part( 'template-parts/loop', 'tp' ); ?>
    			</div>
    		    
    	    	<?php endwhile; wp_reset_query(); ?>
	    	</div>
		</div>
    </div>
</div>