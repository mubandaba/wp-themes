<section class="part uk-background-default uk-margin-bottom">
    <div class="title b-b">
		<span><?php echo _aye('side_comment_title'); ?></span>
	</div>
	<ul class="hotCommen uk-margin-remove uk-padding-remove">
		<?php
		$side_comment_num = _aye('side_comment_num');
		$new_comment_num = $new_comment_show = $side_comment_num;
		$comments = get_comments('status=approve&order=DESC&number='.$new_comment_num);
		foreach($comments as $comment) :
		$output = '<li class="b-b"><div class="author uk-flex uk-flex-middle">'.get_avatar($comment, 24).'<span class="uk-text-small uk-text-muted uk-margin-small-left">' .get_comment_author().'：</span></div><div class="content uk-text-small"><a href="' . esc_url( get_comment_link($comment->comment_ID) ) . '">' . $comment->comment_content . '</a></div></li>';
		echo $output;
		endforeach;
		?>
	</ul>
</section>
<!-- 侧边栏热门评论模块 -->