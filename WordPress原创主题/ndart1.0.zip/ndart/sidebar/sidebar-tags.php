<section class="part uk-background-default uk-margin-bottom">
    <div class="title b-b uk-margin-bottom">
		<span><?php echo _aye('side_tag_title'); ?></span>
	</div>
	<ul class="uk-list sideTags tags uk-padding-remove uk-margin-remove">
		<?php
		$side_tag_num =  _aye('side_tag_num');
		$tags_list = get_tags( array('number' => $side_tag_num, 'hide_empty' => false) );
		shuffle($tags_list); 
		$count=0; 
		if ($tags_list) {
			foreach($tags_list as $tag) {
				$count++;
				echo '<a uk-tooltip="' . $tag->count . '个相关文章" href="'.get_tag_link($tag->term_id).'" target="_blank">'.$tag->name.'</a>';
				if( $count > $side_tag_num ) break;
			}
		}
		?>

	</ul>
</section>