<?php 
	$user_id  = get_the_author_ID(); 
	$args = array(
	'post_author' => $user_id 
	);
	$author_comments = get_comments($args);
?>

<section class="side-author b-a b-r-4 uk-background-default uk-overflow-hidden uk-margin-medium-bottom">
	<div class="user-info uk-padding-small uk-position-relative">
		<div class="uk-position-relative uk-position-z-index">
			<div class="avatar uk-text-center">
				<?php echo get_avatar( get_the_author_meta( 'ID' ),'100' ); ?>
			</div>
			<div class="uk-text-center">
				<p class="uk-text-bolder uk-margin-small-top uk-margin-small-bottom uk-h4"><?php the_author_posts_link(); ?></p>
				<p class="uk-text-small uk-text-muted uk-margin-small-top">
					<?php echo the_author_meta('description');?>
				</p>
			</div>
		</div>
		<div class="side-author-count uk-margin-top uk-position-relative uk-position-z-index">
			<ul class="uk-grid-collapse" uk-grid>
				<li class="uk-width-1-3 uk-display-inline-block uk-text-center">
					<div class="item uk-background-default ">
						<p class="uk-h4 uk-margin-remove"><?php echo count_user_posts($user_id); ?></p>
						<span>文章</span>
					</div>
				</li>
				<li class="uk-width-1-3 uk-display-inline-block uk-text-center">
					<div class="item uk-background-default ">
						<p class="uk-h4 uk-margin-remove"><?php echo cx_posts_views($user_id); ?></p>
						<span>浏览</span>
					</div>
				</li>
				<li class="uk-width-1-3 uk-display-inline-block uk-text-center">
					<div class="item uk-background-default ">
						<p class="uk-h4 uk-margin-remove"><?php echo count($author_comments); ?></p>
						<span>评论</span>
					</div>
				</li>
				<li class="uk-width-1-3 uk-display-inline-block uk-text-center">
					<div class="item uk-background-default ">
						<p class="uk-h4 uk-margin-remove"><?php echo $count_tags = wp_count_terms('post_tag'); ?></p>
						<span>标签</span>
					</div>
				</li>
				<li class="uk-width-1-3 uk-display-inline-block uk-text-center">
					<div class="item uk-background-default ">
						<p class="uk-h4 uk-margin-remove"><?php $count_pages = wp_count_posts('page'); echo $page_posts = $count_pages->publish; ?></p>
						<span>分类</span>
					</div>
				</li>

			</ul>
		</div>
	</div>
	<?php if( _aye('side_author_latest') == true ): ?>

	<div class="side-author-latest uk-background-default uk-padding-small">
		<div class="b-b uk-padding-small uk-padding-remove-top uk-padding-remove-horizontal uk-clearfix  uk-flex uk-flex-middle">
			<span class="side-title <?php if(_aye('side_title_style') == true): ?>side-title-style<?php endif; ?> uk-h5 uk-float-left uk-margin-remove uk-position-relative"><?php echo _aye('side_author_latest_title');  ?></span>
			<span class="home-time uk-float-right uk-display-inline-block uk-text-muted uk-text-small uk-flex-1 uk-text-right"></span>
		</div>
		 
		<?php
		$side_author_latest_num = _aye('side_author_latest_num');
		$query = new WP_Query(
			array(
				'author' => $post->post_author,
				'posts_per_page' => $side_author_latest_num,
				'post__not_in' => array($post->ID),
			)
		);
		$posts = $query->posts;
		?>
		<ul class="uk-padding-remove uk-margin-remove-bottom">
			<?php foreach($posts as $k => $p): ?>
			<li class="uk-margin-small-bottom uk-position-relative">
				<span><?php the_time('Y-m-d') ?></span>
				<a href="<?php echo get_permalink($p->ID); ?>" target="_blank" class="uk-display-block"><?php echo $p->post_title ?></a>
			</li>
			<?php endforeach; ?>
			
		</ul>
	</div>
	<?php endif; ?>
	
</section>
<?php if(is_single()) : ?>
<?php endif ?>