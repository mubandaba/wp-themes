<?php get_header(); ?>
<section class="part uk-background-default">
    <div class="part-head uk-grid-collapse" uk-grid>
    	<div class="uk-width-expand">
    		<div class="part-head-text">
    			<p class="uk-margin-remove-top uk-margin-small-bottom uk-text-truncate">#<?php single_tag_title(); ?></p>
    			<span class="uk-display-inline-block uk-text-small uk-text-muted uk-text-truncate">标签为 #<?php single_tag_title(); ?> 内容如下：</span>
    		</div>
    	</div>
    </div>
	<div class="part-content b-t">
		<div class="uk-grid-small" uk-grid="masonry: true">
		    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    		<div class="uk-width-1-2 uk-width-1-5@m uk-width-1-5@xl">
    		<?php get_template_part( 'template-parts/loop', 'tp' ); ?>
    		</div>
    		<?php endwhile; else: ?>
    		<div class="uk-width-1-1">
    			<div class="uk-alert-primary uk-width-1-2 uk-container" uk-alert>
    				<a class="uk-alert-close" uk-close></a>
    				<p class="uk-padding-small uk-text-center">这是一个没有灵魂的标签...</p>
    			</div>
    		</div>
    		<?php endif; ?>
		</div>
	</div>
	<div class="part-more b-t uk-flex uk-flex-middle">
    	<div class="fenye">
        	<?php fenye(); ?>
        </div>
	</div>
</section>
<?php get_footer(); ?>
