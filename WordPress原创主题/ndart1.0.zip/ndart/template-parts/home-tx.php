<?php
    $home_img_title = _aye('home_img_title');
    $home_img_cat = _aye('home_img_cat');
    $home_img_num = _aye('home_img_num');
?>
<section class="uk-background-default uk-margin-top">
	<div class="part-head uk-grid-collapse" uk-grid>
		<div class="uk-width-expand">
			<div class="part-head-text">
				<a class="uk-display-block juzi"><?php echo _aye('home_title'); ?></a>
				<span class="uk-text-small uk-text-muted"><?php echo _aye('home_des');?></span>
			</div>
		</div>
		<div class="uk-width-auto uk-visible@s">
    		<div class="part-head-img uk-text-center">
    		   <?php 
    		       $recom = _aye('recom');
    		       foreach ($recom as $key => $value) {
    		   ?>
    		    <a href="<?php echo $value['link']; ?>" target="_blank" class="uk-display-inline-block">
    		        <img src="<?php echo $value['img']; ?>" />
    		    </a>
    		   <?php } ?>
    		</div>
    	</div>
	</div>
	<div class="part-nav b-t b-b uk-grid-collapse" uk-grid>
		<span class="uk-width-auto"><?php echo $home_img_title; ?></span>
		<ul class="uk-width-expand uk-text-right uk-margin-left">
			<?php wp_list_categories('title_li=&hierarchical=1&hide_empty=0&child_of='.$home_img_cat); ?>
		</ul>
	</div>
	<div class="part-content part-tx">
		<div class="uk-grid-small" uk-grid>
		    <?php query_posts('cat='.$home_img_cat.'&showposts='.$home_img_num ); ?>
			<?php while (have_posts()) : the_post(); ?>
			<div class="uk-width-1-2 uk-width-1-5@m uk-width-1-5@xl">
			<?php get_template_part( 'template-parts/loop', 'tx' ); ?>
			</div>
			<?php endwhile; wp_reset_query(); ?>
		</div>
	</div>
	<div class="part-more b-t uk-flex uk-flex-middle">
		<a href="<?php echo get_category_link($home_img_cat); ?>" target="_blank" class="primary-btn uk-display-inline-block uk-text-small">查看更多<i class="iconfont icon-arrow-right"></i></a>
		<div class="uk-flex-1 uk-text-right uk-text-muted uk-text-small">共 <span class="uk-text-warning"><?php echo get_category($home_img_cat)->count;?></span> 帖子</div>
	</div>
</section>