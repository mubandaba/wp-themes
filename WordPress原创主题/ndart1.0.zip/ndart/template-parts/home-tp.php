<?php 
    $home_pbl_title = _aye('home_pbl_title');
    $home_pbl_num = _aye('home_pbl_num');
    $home_pbl_load =  _aye('home_pbl_load');
?>
<section class="uk-background-default uk-margin-top">
	<div class="part-nav b-t b-b uk-flex uk-flex-middle">
		<span><?php echo $home_pbl_title; ?></span>
		<ul class="uk-flex-1 uk-text-right uk-margin-remove">
			<?php wp_list_categories('title_li=&hierarchical=1&hide_empty=0&child_of='.$cat_ID); ?>
		</ul>
	</div>
	<div class="part-content part-img">
		<div class="ajax-main uk-grid-small" uk-grid="masonry: true">
		    <?php query_posts('&showposts='.$home_pbl_num ); ?>
		    <?php while (have_posts()) : the_post(); ?>
		    <div class="ajax-item uk-width-1-2 uk-width-1-4@m uk-width-1-4@xl">
			<?php get_template_part( 'template-parts/loop', 'tp' ); ?>
			</div>
			<?php endwhile; wp_reset_query(); ?>
		</div>
	</div>
	<div class="part-more b-t uk-flex uk-flex-middle">
	    <a href="<?php echo _aye('home_pbl_more'); ?>" target="_blank" class="primary-btn uk-display-inline-block uk-text-small">查看更多<i class="iconfont icon-arrow-right"></i></a>

	</div>
</section>