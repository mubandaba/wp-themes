<?php 
    $home_art_title = _aye('home_art_title');
    $home_art_cat = _aye('home_art_cat');
    $home_art_num = _aye('home_art_num');
?>
<section class="uk-background-default uk-margin-top">
	<div class="part-nav b-t b-b uk-flex uk-flex-middle">
		<span><?php echo $home_art_title; ?></span>
		<ul class="uk-flex-1 uk-text-right uk-margin-remove">
        	<?php wp_list_categories('title_li=&hierarchical=1&hide_empty=0&child_of=15'); ?>
		</ul>
	</div>
	<div class="part-content" uk-grid>
	    <?php query_posts('cat='.$home_art_cat.'&showposts='.$home_art_num ); ?>
		<?php while (have_posts()) : the_post(); ?>
		<?php get_template_part( 'template-parts/loop', 'wz' ); ?>
		<?php endwhile; wp_reset_query(); ?>
	</div>
	<div class="part-more b-t uk-flex uk-flex-middle">
		<a href="<?php echo get_category_link($home_art_cat); ?>" target="_blank" class="primary-btn uk-display-inline-block uk-text-small">查看更多<i class="iconfont icon-arrow-right"></i></a>
		<div class="uk-flex-1 uk-text-right uk-text-muted uk-text-small">共 <span class="uk-text-warning"><?php echo get_category($home_art_cat)->count;?></span> 帖子</div>
	</div>
</section>