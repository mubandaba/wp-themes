<div class="images tx b-a">
	<a href="<?php the_permalink(); ?>" target="_blank" class="thumb uk-position-relative uk-display-block">
		<img src="<?php echo post_thumbnail_src() ?>" alt="<?php the_title(); ?>" />
		<div class="cover uk-flex uk-flex-middle">
			<div class="uk-padding-small uk-width-1-1">
				<p><?php echo wp_trim_words( get_the_title(), 18 ); ?></p>
				<div class="uk-grid-collapse uk-light uk-text-small uk-margin-small-top uk-text-truncate" uk-grid>
					<div class="uk-width-1-3 uk-text-truncate"><?php the_author(); ?></div>
					<div class="uk-width-1-3 uk-text-truncate"><?php the_time('m-d') ?></div>
					<div class="uk-width-1-3 uk-text-truncate"><?php echo get_post_images_number().'图' ?></div>
				</div>
			</div>
		</div>
	</a>
</div>
