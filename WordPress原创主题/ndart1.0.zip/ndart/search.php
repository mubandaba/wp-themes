<?php get_header(); ?>
<section class="part uk-background-default">
    <div class="part-head uk-grid-collapse" uk-grid>
    	<div class="uk-width-expand">
    		<div class="part-head-text">
    		    <?php
				$allsearch = new WP_Query("s=$s&showposts=-1");
				$key = wp_specialchars($s, 1);
				$count = $allsearch->post_count;
				echo '<p class="uk-margin-remove-top uk-margin-small-bottom uk-text-truncate">「'. $key .'」</p>';
				echo '<span class="uk-display-inline-block uk-text-small uk-text-muted uk-text-truncate">共搜索到<strong> ' . $count .' </strong>条相关内容。</span>' ;
				wp_reset_query(); 
				?>
    		</div>
    	</div>
    </div>
	<div class="part-content b-t">
		<div class="uk-grid-small" uk-grid="masonry: true">
		    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		    <div class="uk-width-1-2 uk-width-1-5@m uk-width-1-5@xl">
    		<?php get_template_part( 'template-parts/loop', 'tp' ); ?>
    		</div>
    		<?php endwhile; else: ?>
    		<div class="uk-width-1-1">
    			<div class="uk-alert-primary uk-width-1-2 uk-container" uk-alert>
    				<a class="uk-alert-close" uk-close></a>
    				<p class="uk-padding-small uk-text-center">这是一个没有灵魂的搜索词...</p>
    			</div>
    		</div>
    		<?php endif; ?>
		</div>
	</div>
	<div class="part-more b-t uk-flex uk-flex-middle">
    	<div class="fenye">
        	<?php fenye(); ?>
        </div>
	</div>
</section>
<?php get_footer(); ?>