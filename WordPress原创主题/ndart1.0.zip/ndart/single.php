<?php 
	get_header(); 
	$post_id =  get_the_ID();
	$category = get_the_category();
	$user_id  = get_the_author_ID(); 
	$args = array(
	'post_author' => $user_id 
	);
	$author_comments = get_comments($args);
?>
<section class="uk-text-muted uk-text-small uk-margin-bottom">
    
</section>
<section>
    <div class="single uk-background-default">
        <?php while ( have_posts() ) : the_post(); ?>
	    <div class="single-head b-b" uk-grid>
	        <div class="uk-width-expand b-r">
    			<h1 class="uk-h2 uk-text-truncate"><?php the_title(); ?></h1>
    			<div class="uk-text-small uk-text-muted uk-flex uk-text-truncate uk-overflow-auto">
    				<span class="uk-display-inline-block uk-margin-medium-right uk-flex uk-flex-middle"><i class="iconfont icon-rili"></i><?php the_time('Y-m-d') ?></span>
    				<?php if(_aye('single_sc_num') == true): ?>
    				<?php endif; ?>
    				<span class="uk-display-inline-block uk-margin-medium-right uk-flex uk-flex-middle"><i class="iconfont icon-yanjing"></i>12<?php post_views('', ''); ?></span>
    				<span class="uk-display-inline-block uk-margin-medium-right uk-flex uk-flex-middle"><?php edit_post_link('<i class="iconfont icon-edit"></i>编辑'); ?></span>
    			</div>
			</div>
			<div class="uk-width-auto single-author uk-visible@s">
			    <div class="uk-grid-small" uk-grid>
			        <div class="uk-width-auto"><?php echo get_avatar(get_the_author_meta( 'ID' ), 68); ?></div>
			        <div class="uk-width-expand">
			            <div class="uk-flex uk-flex-middle">
    			            <?php the_author_posts_link(); ?>
    			            <!--<span><?php //echo get_user_role(); ?></span>
    			            <span><?php //get_talent(); ?></span>-->
			            </div>
			            <p class="uk-text-muted uk-text-small uk-margin-small"><?php 
                                $u_description = get_the_author_meta( 'description');
                                if(!$u_description){
                                    echo '好久不见';
                                }else {
                                    echo the_author_meta( 'description'); 
                                }
                            ?></p>
			        </div>
			    </div>
			</div>
		</div>
		<?php
            if(get_term_meta( $category[0]->cat_ID , 'cat_theme', true ) == 1) {
        ?>
        <div class="single-content part single-tx" uk-lightbox>
        <?php }elseif(get_term_meta( $category[0]->cat_ID , 'cat_theme', true ) == 3) { ?>
        <div class="single-content part single-wz single-tp" uk-lightbox>
        <?php }else{ ?>
        <div class="single-content part single-tp" uk-lightbox>
        <?php } ?>
		<?php the_content(); ?>
		</div>
		
    	<?php if (_aye('single_cop') == true ): ?>
        <div class="b-t uk-padding uk-text-muted">
        	<div class="uk-margin-remove-bottom">
        	    <p class="uk-margin-small-bottom uk-margin-remove-top">标题：<?php the_title(); ?></p>
        	    <p class="uk-margin-small-bottom uk-margin-small-top">分类：<?php $category = get_the_category();	if($category[0]){echo '<a href="'.get_category_link($category[0]->term_id ).'">'.$category[0]->cat_name.'</a>';} ?></p>
        		<p class="uk-margin-small-bottom uk-margin-small-top">链接：<?php the_permalink(); ?></p>
        		<p class="uk-margin-remove-bottom uk-margin-small-top">版权：<?php echo _aye('single_cop_text'); ?></p>
        	</div>
        </div>
        <?php endif ?>
        <?php if (_aye('single_tag') == true ): ?>
        <div class="b-t part" uk-grid>
        	<div class="uk-text-truncate uk-width-1-1 uk-width-expand@m uk-width-expand@xl uk-text-small">
        		<span>标签：</span><?php the_tags('', ' , ') ?>
        	</div>
        </div>
        <?php endif ?>
        <?php endwhile; ?>
	</div>
    <?php get_template_part( 'single/single', 'page' ); ?>
    <?php get_template_part( 'single/single', 'foot' ); ?>

</section>
<?php get_footer(); ?>
