<?php
	get_header(); 
	get_template_part( 'template-parts/loop/loop', 'search' );
	get_template_part( 'template-parts/home/home', 'card' );
	get_template_part( 'template-parts/loop/loop', 'nav' );
	get_template_part( 'template-parts/home/home', 'waterfall' );
    get_footer(); 
?>


