<section class="search uk-padding uk-margin-medium-bottom">
	<form method="get" class="shadow uk-form uk-container uk-flex  uk-position-relative" action="<?php bloginfo('url'); ?>">
		<input class="uk-input uk-text-small" type="search" placeholder="输入关键字搜索" autocomplete="off" value="" name="s" required="required">
		<button type="submit" class="uk-text-bold">搜索</button>
		<i class="iconfont icon-sousuo uk-position-center-left uk-margin-small-left"></i>
	</form>
</section>