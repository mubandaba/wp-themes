<?php 
get_header(); 
get_template_part( 'template-parts/loop/loop', 'search' );
get_template_part( 'template-parts/loop/loop', 'nav' );
?>

<main class="main">
	<div class="uk-padding-small uk-margin-top">
		<div class="uk-padding-small uk-container">
			<h3>#<?php single_tag_title(); ?></h3>
			<p class="uk-display-block uk-text-muted">标签为 #<?php single_tag_title(); ?> 内容如下：</p>
		</div>	
	</div>
	<div class="uk-container uk-container-center uk-margin-large-bottom">
		<div class="uk-margin-medium-top uk-grid-small" uk-grid>
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

			<div class="uk-width-1-1@s uk-width-1-4@m uk-width-1-4@l uk-width-1-4@xl">
				<?php get_template_part( 'template-parts/loop/loop', 'img' );?>

			</div>
			<?php endwhile; else: ?>
			<div class="uk-width-1-1">
				<div class="uk-alert" data-uk-alert>
					<p>暂无您搜索的内容...</p>
				</div>
			</div>
			<?php endif; ?>

		</div>
		<div class="fenye uk-margin-large-top">
			<?php fenye(); ?>
		</div>
	</div>
</main>

<?php get_footer(); ?>
