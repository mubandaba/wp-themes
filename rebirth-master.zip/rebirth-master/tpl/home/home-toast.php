<?php
/**
 * 响应式wordpress主题
 *
 * @package : rebirth
 * @Author: Yqchilde
 * @link  https://yqqy.top
 */
?>

<div class="toast-wrapper" aria-live="polite" aria-atomic="true">
    <div class="toast-wrapper-list"></div>
</div>
