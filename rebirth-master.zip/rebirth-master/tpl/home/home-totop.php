<?php
/**
 * 响应式wordpress主题
 *
 * @package : rebirth
 * @Author: Yqchilde
 * @link  https://yqqy.top
 */
?>

<div class="d-flex justify-content-center align-items-center flex-column animated fixed-to-top click-to-top">
    <i class="fas fa-angle-double-up"></i>
    <span class="animated progress-number"></span>
</div>
