<?php get_header();?>
<div class="site-content container">
	<div class="content-area">
		<main class="site-main">
		<div class="_404">
			<h1 class="entry-title">抱歉，这个页面不存在！</h1>
			<div class="entry-content">
				它可能已经被删除，或者您访问的URL是不正确的。也许您可以试试搜索？
			</div>
			<form method="get" class="search-form inline" action="<?php bloginfo('url'); ?>">
				<input class="search-field inline-field" placeholder="输入关键词..." autocomplete="off" value="" name="s" required type="search">
				<button type="submit" class="search-submit"><i class="iconfont icon-sousuo"></i></button>
			</form>
		</div>
		</main>
	</div>
</div>
<?php get_footer();?>