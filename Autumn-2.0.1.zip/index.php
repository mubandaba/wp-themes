<?php 
get_header();
get_template_part( 'template-parts/banner' );
?>
<div class="site-content container">
	<div class="row">
		<div class="<?php if( wpjam_theme_get_setting('list_region') == 'list' ) { echo 'col-lg-9'; }else{ echo 'col-lg-12'; }?>">
			<div class="content-area">
				<main class="site-main">
					<div class="row posts-wrapper">
					<?php
					if ( have_posts() ) {
						while ( have_posts() ) { 
							the_post();
							get_template_part('template-parts/content-list');
						}
					}
					
					get_template_part( 'template-parts/paging' );
					?>
					</div>
				</main>
			</div>
		</div>
		
		<?php if( wpjam_theme_get_setting('list_region') == 'list' ){ get_sidebar(); } ?>
		
	</div>
</div>
<?php get_footer();?>