<?php
function wpjam_theme_get_setting($setting_name){
    return wpjam_get_setting('wpjam_theme', $setting_name);
}

function wpjam_theme_post_views($before = '(点击 ', $after = ' 次)', $echo = 1){
	global $post;
	$post_ID	= $post->ID;
	$views		= (int)get_post_meta($post_ID, 'views', true);
	if ($echo) {
		echo $before, number_format($views), $after;
	}else{
		return $views;
	}
};

//点赞
function wpjam_theme_postlike(){  
    global $wpdb, $post;  
    $dot_good = get_post_meta($post->ID, 'dotGood', true) ? get_post_meta($post->ID, 'dotGood', true) : '0';  
    $done = isset($_COOKIE['dotGood_' . $post->ID]) ? 'done' : '';  
    echo '<a href="javascript:;" data-action="topTop" data-id="'.$post->ID.'" class="dotGood '.$done.'"><i class="iconfont icon-dianzan2-copy"></i><span class="count" style="font-size: 13px;padding-left: 5px;">'.$dot_good.'</span></a>';  
}  
//点赞  列表用的  图标不太一样  以后统一
function wpjam_theme_postlike2(){  
    global $wpdb, $post;  
    $dot_good = get_post_meta($post->ID, 'dotGood', true) ? get_post_meta($post->ID, 'dotGood', true) : '0';  
    $done = isset($_COOKIE['dotGood_' . $post->ID]) ? 'done' : '';  
    echo '<a href="javascript:;" data-action="topTop" data-id="'.$post->ID.'" class="dotGood '.$done.'"><i class="iconfont icon-dianzan"></i><span class="count">'.$dot_good.'</span></a>';  
}
//固定导航
if ( wpjam_get_setting('wpjam_theme', 'navbar_sticky') ){
	add_filter('body_class','wpjam_class_navbar_sticky');
	function wpjam_class_navbar_sticky($classes) {
		$classes[] = 'navbar-sticky';
		return $classes;
	}
}
//暗黑风格
$dark_mode = wpjam_get_setting('wpjam_theme', 'dark_mode');
if($dark_mode == '1'){
	add_filter('body_class','wpjam_class_dark_mode');
	function wpjam_class_dark_mode($classes) {
		$classes[] = 'dark-mode';
		return $classes;
	}
}
//头像
function wpjam_xintheme_autumn_get_avatar($uid){
	$photo = get_user_meta($uid, 'photo', true);
	if($photo) return $photo;
	else return get_bloginfo('template_url').'/static/images/avatar.jpg';
}
// 分页代码
if ( !function_exists('wpjam_theme_pagenavi') ) {
	function wpjam_theme_pagenavi( $p = 2 ) { // 取当前页前后各 2 页
		if ( is_singular() ) return; // 文章与插页不用
		global $wp_query, $paged;
		$max_page = $wp_query->max_num_pages;
		if ( $max_page == 1 ) return; // 只有一页不用
		if ( empty( $paged ) ) $paged = 1;
		
		if ( $paged > 1 ) p_link( $paged - 1, '上一页', '<i class="iconfont icon-zuo1"></i>' );/* 如果当前页大于1就显示上一页链接 */
		if ( $paged > $p + 1 ) p_link( 1, '最前页' );
		if ( $paged > $p + 2 ) echo '<li><a class="page-numbers">...</a></li>';
		for( $i = $paged - $p; $i <= $paged + $p; $i++ ) { // 中间页
			if ( $i > 0 && $i <= $max_page ) $i == $paged ? print "<li><a class='page-numbers current' href='javascript:void(0);'>{$i}</a></li> " : p_link( $i );
		}
		if ( $paged < $max_page - $p - 1 ) echo '<li><a class="page-numbers" href="javascript:void(0);">...</a></li> ';
		if ( $paged < $max_page - $p ) p_link( $max_page, '最后页' );
		if ( $paged < $max_page ) p_link( $paged + 1,'下一页', ' <i class="iconfont icon-zuo"></i>' );/* 如果当前页不是最后一页显示下一页链接 */
		//echo '<li><a class="page-numbers" href="javascript:void(0);">' . $paged . ' / ' . $max_page . ' </a></li> '; // 显示页数
	}
	function p_link( $i, $title = '', $linktype = '' ) {
		if ( $title == '' ) $title = "第 {$i} 页";
		if ( $linktype == '' ) { $linktext = $i; } else { $linktext = $linktype; }
		echo "<li><a class='page-numbers' href='", esc_html( get_pagenum_link( $i ) ), "' title='{$title}'>{$linktext}</a></li> ";
	}
}

//评论等级
function wpjam_author_class($comment_author_email){
global $wpdb; $author_count = count($wpdb->get_results( "SELECT comment_ID as author_count FROM $wpdb->comments WHERE comment_author_email = '$comment_author_email' ")); 
$adminEmail = get_option('admin_email');if($comment_author_email ==$adminEmail) return;
if($author_count>=1 && $author_count<10 && $comment_author_email!=$adminEmail)
    echo '<span class="level level-0">初来乍到</span>';
  else if($author_count>=10 && $author_count< 20)
    echo '<span class="level level-1">江湖少侠</span>';
  else if($author_count>=20 && $author_count< 40)
    echo '<span class="level level-2">崭露头角</span>';
  else if($author_count>=40 && $author_count< 60)
    echo '<span class="level level-3">自成一派</span>';
  else if($author_count>=60 && $author_count< 80)
    echo '<span class="level level-4">横扫千军</span>';
  else if($author_count>=80&& $author_count<100)
    echo '<span class="level level-5">登峰造极</span>';
  else if($author_count>=100&& $author_count< 120)
    echo '<span class="level level-6">一统江湖</span>';
}
function wpjam_comment_level($comment){
    $html = "";
    if(($vip = wpjam_author_class($comment->comment_author_email))){
        $html .= '' . $vip . '>';
        for($i = 0; $i < $vip; $i++){
            $html .= '';
        }
        $html .= '';
    };
    echo $html;
}
//评论列表
function wpjam_theme_list_comments($comment, $args, $depth) {
   $GLOBALS['comment'] = $comment;
      global $commentcount,$wpdb, $post;
      if(!$commentcount) { 
          // $comments = $wpdb->get_results("SELECT * FROM $wpdb->comments WHERE comment_post_ID = $post->ID AND comment_type = '' AND comment_approved = '1' AND !comment_parent");
          $comments = get_comments(['post_id'=>$post->ID]);
          $cnt = count($comments);
          $page = get_query_var('cpage');
          $cpp=get_option('comments_per_page');
         if (ceil($cnt / $cpp) == 1 || ($page > 1 && $page  == ceil($cnt / $cpp))) {
             $commentcount = $cnt + 1;
         } else {
             $commentcount = $cpp * $page + 1;
         }
     }
?>
<li id="comment-<?php comment_ID() ?>" <?php comment_class(); ?>>
<article id="div-comment-<?php comment_ID() ?>" class="comment-wrapper u-clearfix">
<div class="comment-author-avatar vcard">
	<?php echo get_avatar($comment,60); ?>
</div>
<div class="comment-content">
	<div class="comment-author-name vcard">
		<cite class="fn"><?php /*wpjam_comment_level($comment);*/ comment_author_link();?></cite>
	</div>
	<div class="comment-metadata">
		<time>
            <?php comment_date() ?> <?php comment_time() ?>
		</time>
		<span class="reply-link">
			<?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth'], 'reply_text' => "回复"))) ?>
		</span>
	</div>
	<div class="comment-body" itemprop="comment">
		<?php comment_text() ?>
		<?php if ( $comment->comment_approved == '0' ) : ?>
			<font style="color:#C00; font-style:inherit">您的评论正在等待审核中...</font>
		<?php endif; ?>
	</div>
</div>
</article>
<?php }
function weisay_end_comment() {
    echo '</li>';
}
// 评论邮件
add_action('comment_post','comment_mail_notify');
/* comment_mail_notify (所有回复都发邮件) */
function comment_mail_notify($comment_id) {
    $comment = get_comment($comment_id);
    $parent_id = $comment->comment_parent ? $comment->comment_parent : '';
    $spam_confirmed = $comment->comment_approved;
    if (($parent_id != '') && ($spam_confirmed != 'spam')) {
        $wp_email = 'no-reply@' . preg_replace('#^www.#', '', strtolower($_SERVER['SERVER_NAME'])); //e-mail 发出点, no-reply 可改为可用的 e-mail.
        $to = trim(get_comment($parent_id)->comment_author_email);
        $subject = '您在 [' . get_option("blogname") . '] 的留言有了回复';
        $message = '
    <table cellpadding="0" cellspacing="0" class="email-container" align="center" width="550" style="font-size: 15px; font-weight: normal; line-height: 22px; text-align: left; border: 1px solid rgb(177, 213, 245); width: 550px;">
<tbody><tr>
<td>
<table cellpadding="0" cellspacing="0" class="padding" width="100%" style="padding-left: 40px; padding-right: 40px; padding-top: 30px; padding-bottom: 35px;">
<tbody>
<tr class="logo">
<td align="center">
<table class="logo" style="margin-bottom: 10px;">
<tbody>
<tr>
<td>
<span style="font-size: 22px;padding: 10px 20px;margin-bottom: 5%;color: #65c5ff;border: 1px solid;box-shadow: 0 5px 20px -10px;border-radius: 2px;display: inline-block;">' . get_option("blogname") . '</span>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr class="content">
<td>
<hr style="height: 1px;border: 0;width: 100%;background: #eee;margin: 15px 0;display: inline-block;">
<p>Hi ' . trim(get_comment($parent_id)->comment_author) . '!<br>您评论在 "' . get_the_title($comment->comment_post_ID) . '":</p>
<p style="background: #eee;padding: 1em;text-indent: 2em;line-height: 30px;">' . trim(get_comment($parent_id)->comment_content) . '</p>
<p>'. $comment->comment_author .' 给您的答复:</p>
<p style="background: #eee;padding: 1em;text-indent: 2em;line-height: 30px;">' . trim($comment->comment_content) . '</p>
</td>
</tr>
<tr>
<td align="center">
<table cellpadding="12" border="0" style="font-family: Lato, \'Lucida Sans\', \'Lucida Grande\', SegoeUI, \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 16px; font-weight: bold; line-height: 25px; color: #444444; text-align: left;">
<tbody><tr>
<td style="text-align: center;">
<a target="_blank" style="color: #fff;background: #65c5ff;box-shadow: 0 5px 20px -10px #44b0f1;border: 1px solid #44b0f1;width: 200px;font-size: 14px;padding: 10px 0;border-radius: 2px;margin: 10% 0 5%;text-align:center;display: inline-block;text-decoration: none;" href="' . htmlspecialchars(get_comment_link($parent_id)) . '">查看详情</a>
</td>
</tr>
</tbody></table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>

<table border="0" cellpadding="0" cellspacing="0" align="center" class="footer" style="max-width: 550px; font-family: Lato, \'Lucida Sans\', \'Lucida Grande\', SegoeUI, \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 15px; line-height: 22px; color: #444444; text-align: left; padding: 20px 0; font-weight: normal;">
<tbody><tr>
<td align="center" style="text-align: center; font-size: 12px; line-height: 18px; color: rgb(163, 163, 163); padding: 5px 0px;">
</td>
</tr>
<tr>
<td style="text-align: center; font-weight: normal; font-size: 12px; line-height: 18px; color: rgb(163, 163, 163); padding: 5px 0px;">
<p>Please do not reply to this message , because it is automatically sent.</p>
<p>© '.date("Y").' <a name="footer_copyright" href="' . home_url() . '" style="color: rgb(43, 136, 217); text-decoration: underline;" target="_blank">' . get_option("blogname") . '</a></p>
</td>
</tr>
</tbody>
</table>';
        $from = "From: \"" . get_option('blogname') . "\" <$wp_email>";
        $headers = "$from\nContent-Type: text/html; charset=" . get_option('blog_charset') . "\n";
        wp_mail( $to, $subject, $message, $headers );
    }
}
// -- END ----------------------------------------