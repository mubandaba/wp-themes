<style>.entry-header .entry-title{text-overflow:ellipsis; white-space:nowrap; overflow:hidden;}
.status{margin-right: 10px;color:var(--accent-color)}
.status.published{color: #aaa;}
.pagenavi li{float: left;list-style: none;}
.pagenavi li a{margin: 0 3px 20px 3px;padding: 8px 12px;color: #202226;border-width: 1px;border-style: solid;border-color: #e3e3e9;border-radius: 3px;font-size: 13px;font-weight: 600;line-height: 1;}
.pagenavi li a.current{background: var(--accent-color);border-color: var(--accent-color);color: #fff;}
</style>
<div class="col-lg-9">
	<div class="row">
    <?php if( have_posts() ){ ?>
    <?php while( have_posts() ) : the_post(); $p_id = get_the_ID(); ?>
		<article class="col-md-6 col-lg-4 col-xl-4 grid-item">
			<div class="post <?php if( get_post_meta($post->ID, 'feature_list', true) ) {?>cover lazyloaded<?php } ?>" <?php if( get_post_meta($post->ID, 'feature_list', true) ) {?>style='background-image: url("<?php echo wpjam_get_post_thumbnail_src($post,array(840,1120), $crop=1);?>");'<?php } ?>>
			<div class="entry-media with-placeholder" style="padding-bottom: 61.904761904762%;">
				<?php if( !get_post_meta($post->ID, 'feature_list', true) ) {?>
				<a href="<?php the_permalink(); ?>">
					<img class="lazyloaded" data-srcset="<?php echo wpjam_get_post_thumbnail_src($post,array(420,260), $crop=1);?>" srcset="<?php echo wpjam_get_post_thumbnail_src($post,array(420,260), $crop=1);?>">
				</a>
				<?php } ?>
				<?php if( has_post_format( 'gallery' )) { //相册 ?>
				<div class="entry-format">
					<i class="iconfont icon-xiangce"></i>
				</div>
				<?php } else if ( has_post_format( 'video' )) { //视频 ?>
				<div class="entry-format">
					<i class="iconfont icon-shipin"></i>
				</div>
				<?php } else if ( has_post_format( 'audio' )) { //音频 ?>
				<div class="entry-format">
					<i class="iconfont icon-yinpin"></i>
				</div>
				<?php } ?>
			</div>
			<div class="entry-wrapper">
				<header class="entry-header">
				<div class="entry-category">
					<?php  
						$category = get_the_category();
						if($category[0]){
						echo '<a href="'.get_category_link($category[0]->term_id ).'" rel="category">'.$category[0]->cat_name.'</a>';
						};
					?>
				</div>
				<h2 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
				</header>
				<div class="entry-excerpt">
					<p>
						<?php
							$meta_data = get_post_meta($post->ID, 'post_abstract', true);
							$post_abstract = isset($meta_data) ?$meta_data : '';
							if(!empty($post_abstract)){
								echo mb_strimwidth($post_abstract, 0, 85,"...");
							}else{
								echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 85,"……");
							}
						?>
					</p>
				</div>
			</div>
			<div class="entry-action">
				<div>
					<?php if( $post->post_status == 'publish' ){ ?>
					<span class="status published">已发布</span>
					<?php }else if( $post->post_status == 'pending' ){ ?>
					<span class="status">等待审核</span>
					<?php }else if( $post->post_status == 'draft' ){ ?>
					<span class="status">草稿</span>
					<?php } ?>
					<?php if( $post->post_status == 'draft' ){  ?>
					<span class="status"><a style="color:var(--accent-color)" href="<?php echo home_url(user_trailingslashit('/user/contribute'));?>?post_id=<?php echo $post->ID; ?>"><i class="iconfont icon-zuozhe" style="font-size: 14px;"></i> 编辑文章</a></span>
					<?php } ?>
					<?php if( wpjam_get_setting('wpjam_theme', 'list_like') ) : ?><?php wpjam_theme_postlike2();?><?php endif; ?>
					<?php if( wpjam_get_setting('wpjam_theme', 'list_read') ) : ?><a class="view" href="<?php the_permalink(); ?>"><i class="iconfont icon-liulan"></i><span class="count"><?php wpjam_theme_post_views('',''); ?></span></a><?php endif; ?>
					<?php if( wpjam_get_setting('wpjam_theme', 'list_comment') ) : ?><a class="comment" href="<?php the_permalink(); ?>#comments"><i class="iconfont icon-pinglun"></i><span class="count"><?php echo get_post($post->ID)->comment_count; ?></span></a><?php endif; ?>
				</div>
				<div>
					<a class="share" href="<?php the_permalink(); ?>" data-url="<?php the_permalink(); ?>" data-title="<?php the_title(); ?>" data-thumbnail="<?php echo wpjam_get_post_thumbnail_src($post,array(150,150), $crop=1);?>" data-image="<?php echo wpjam_get_post_thumbnail_src($post,array(1130,848), $crop=1);?>">
					<i class="iconfont icon-icon_share_normal"></i>
					<span>Share</span>
					</a>
				</div>
			</div>
			</div>
			<?php if( get_post_meta($post->ID, 'feature_list', true) ) {?>
				<a class="u-permalink" href="<?php the_permalink(); ?>"></a>
			<?php } ?>
		</article>
    <?php endwhile; ?>  
    <?php }else{ ?>
        <p>您还没有发布文章</p>
    <?php } ?>  
    </div>
	<div class="pagenavi">
    <?php wpjam_theme_pagenavi();?>
	</div>
</div>
