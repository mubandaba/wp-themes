<?php function xintheme_strip_tags($content){
	if($content){
		$content = preg_replace("/\[.*?\].*?\[\/.*?\]/is", "", $content);
	}
	return strip_tags($content);
} ?>
<style>
.col-lg-9 .posts-wrapper form{width: 100%;}
.col-lg-9 .posts-wrapper form .avatar{background-size: contain;float: left !important;width: 80px;height: 80px;margin-right: 20px;border: 3px solid #fff;border-radius: 50%;}
.account-form .avatar-editor .edit {color: var(--accent-color);line-height: 80px;right: 0;top: 20px;}
a[class*="upload"] input {position: absolute;width: 100%;height: 100%;opacity: 0;left: 0;top: 0;cursor: pointer;}
input[type="file"] {display: block;}
.col-lg-9 .posts-wrapper{background-color: #fff;padding: 30px;border-radius: 5px;box-shadow: 0 0 10px rgba(0,0,0,.05);margin-bottom: 30px;overflow: hidden;position: relative;}
.form-horizontal{padding-top: 30px;}
.form-group .form-control {width: 100%;margin-top: 10px;height: 32px;padding: 6px 12px;background-color: #fff;border: 1px solid #e4e4e4;-webkit-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;}
.col-lg-9{padding-left: 30px;padding-right: 30px;}
.cg-notify-message{position:fixed;left:50%;top:0;z-index:9999;max-width:400px;text-align:center;background-color:var(--accent-color);color:#fff;padding:15px;border:1px solid var(--accent-color);border-radius:4px;-webkit-transition:top .5s ease-out,opacity .2s ease-out;transition:top .5s ease-out,opacity .2s ease-out;visibility:hidden;box-shadow:0 6px 12px rgba(0,0,0,.175)}
.list-group-item li{list-style: none;margin-bottom: 25px;padding-bottom: 25px;border-bottom: 1px solid #efefef;overflow: hidden;color: #bababa;}
.list-group-item li .comment{color: #333;font-size: 16px;}
.ng-scope{width: 100%;}
.plp2{margin-top: 10px;}
</style>
<div class="col-lg-9">
	<div class="row posts-wrapper">
          <div class="favorite-wrapper ng-scope">
            <?php 
				$counts = $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->comments WHERE user_id=" . get_current_user_id());
				$perpage = 10;
				$pages = ceil($counts / $perpage);
				$paged = (get_query_var('paged')) ? $wpdb->escape(get_query_var('paged')) : 1;
				
				$args = array('user_id' => get_current_user_id(), 'number' => 10, 'offset' => ($paged - 1) * 10);
				$lists = get_comments($args);
				
			?>
            <div class="ng-isolate-scope loading-content-wrap loading-show loading-show-active">
              <?php
              	if($lists) {
			  ?>
              <div class="list-group ng-scope">
                <div class="list-group-item content-list-item ng-scope">
                  <?php foreach($lists as $value){ ?>
					<li>
						<a class="comment" href="<?php echo get_permalink($value->comment_post_ID);?>#comments"><?php echo mb_strimwidth( xintheme_strip_tags( $value->comment_content ), 0, 50,"...");?></a>
						<div class="plp2"><span><?php echo $value->comment_date; ?>　</span><span>评论文章：<a style="color: #bababa;" target="_blank" href="<?php echo get_permalink($value->comment_post_ID);?>#comments"><?php echo get_post($value->comment_post_ID)->post_title;?></a></span></div>
					</li>
                  <?php }?>
                </div>
              </div>
              <!--div class="text-center">
                <nav class="text-center comp-pagination">
                  分页
                </nav>
              </div-->
			  <?php }?>
            </div>
          </div>
	</div>
</div>