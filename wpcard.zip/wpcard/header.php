<!DOCTYPE HTML>
<html>

<head>

    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <script>
        (adsbygoogle = window.adsbygoogle || []).push({
            google_ad_client: "ca-pub-4792046100400447",
            enable_page_level_ads: true
        });
    </script>

  
    <!---<base target="_blank" />--->
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php bloginfo('name'); ?> - <?php echo get_bloginfo('description'); ?></title>

    <meta name="description" content="<?php echo get_bloginfo('description'); ?>">

    <meta name="keywords" content="主机测评,主机优惠码,香港CN2,美国CN2,香港CN2 GIA,美国CN2 GIA,香港CN2直连,美国CN2直连,洛杉矶CN2,圣何塞CN2,圣何塞CN2 GIA,洛杉矶CN2 GIA,洛杉矶CN2直连,圣何塞CN2直连,韩国CN2,韩国CN2 GIA,新加坡CN2,新加坡CN2 GIA,新加坡CN2直连,韩国CN2直连,香港三网直连,美国三网直连,香港直连,美国直连,新加坡直连,香港PCCW直连,香港HKT,日本软银直连,大阪软银直连,东京软银直连,香港高防VPS,美国高防,洛杉矶高防,韩国高防,日本高防,新加坡高防,实惠VPS,实惠域名,实惠虚拟主机,免费活动,免费空间,免费域名,VPS使用教程,建站教程,免费资源,便宜VPS,免费VPS,云服务器,国内云服务器,国外云服务器,国外VPS,香港VPS,美国VPS,欧洲VPS,北美VPS,独立服务器,建站主机,香港云服务器,香港独立服务器,美国独立服务器,高防VPS,DDoS防御,抗投诉VPS,离岸VPS,无版权VPS,无DMCA,洛杉矶VPS,圣何塞VPS,KVM VPS,OpenVZ VPS,不限流量VPS,CN2 GIA,CN2 GT,亚洲优化线路,CN2直连,回程CN2优化,Hyper-V架构,洛杉矶CN2,圣何塞CN2直连,韩国VPS,台湾VPS,日本VPS,新加坡VPS,软银直连,双向CN2,往返CN2,VPS建站教程,XEN架构,XEN VPS,建站VPS,建站云服务器,国内独立服务器,DDoS硬防">

    <?php wp_head(); ?>

    <link rel='dns-prefetch' href='//cdntiger.com' />

    <link rel="stylesheet" href="https://cdntiger.com/css/bootstrap.min.css">

    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style.css">
    <link href="https://cdntiger.com/css/font-awesome.min.css" rel="stylesheet">

    <script src="https://cdntiger.com/js/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdntiger.com/js/popper.min.js"></script>
    <script src="https://cdntiger.com/js/bootstrap.min.js"></script>
</head>



<div class="row col-md-12 navbar" id="navbar">

    <div class="col-md-3">
        <b style="font-size:1.8em;"><a href="/"><?php bloginfo('name'); ?></a></b>
    </div>
    <div class="col-md-6">
        <?php wp_nav_menu('id=navbar'); ?>
    </div>


    <div class="col-md-3">
        <form class="form-inline my-2 my-lg-0" action="/">
            <input name="s" class="form-control mr-sm-2" type="search" placeholder="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
        </form>
    </div>
</div>

<div class="container">