<?php get_header(); ?>


<div class="row  mt-4">

    <div class="col-xs-12 col-md-9">

        <?php if (have_posts()) : ?>

            <?php while (have_posts()) : the_post(); ?>


                <div class="card mb-4 box-shadow">

                    <div class="card-body">
                        <div class="row  mt-2">

                            <div class="col-xs-12 col-md-3"><a href="#"><img src="<?php echo post_thumbnail_src(); ?>" width="100%" height="150" /></a></div>



                            <div class="col-xs-12 col-md-9 mt-2">

                                <h6> <a style="font-size:1.6em;" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title();  ?></a>

                                </h6>


                                <p class="mt-2"><?php echo esc_attr(wp_trim_words(get_the_content(), 200)); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="card-header">
                        <div style="font-size: 1em;color: #999;">
                            <span class="mb-2" id="avator_css"><?php echo get_avatar(get_the_author_meta('user_email')); ?>&nbsp;&nbsp; <?php the_author(); ?>&nbsp;&nbsp;</span>
                            <span class="mb-2"><i class="fa fa-bookmark-o"></i>&nbsp;&nbsp; <?php echo get_the_date('Y-m-d'); ?></span>
                            <span class="mb-2 ml-3"><i class="fa fa-eye"></i>&nbsp;&nbsp;<?php post_views(); ?>&nbsp;&nbsp;</span>
                            <span class="mb-2 ml-3"><i class="fa fa-comment-o"></i>&nbsp;&nbsp;<?php comments_popup_link('0', '1', '%'); ?> 评论</span>

                            <span class="mb-2 float-right"><i class="fa fa-tag"></i>&nbsp;&nbsp;<?php echo get_the_tag_list('Tags: ', ', ', '</span>'); ?>
                        </div>
                    </div>


                </div>

            <?php endwhile; ?>

        <?php endif; ?>


        <div class="pagination">
            <ul>
                <?php get_pagenavi(); ?>
            </ul>
        </div>




    </div>

    <div class="col-xs-12 col-md-3">
        <?php get_sidebar(); ?>
    </div>




    <?php get_footer(); ?>