<div class="row mt-2">
    <div class="col-xs-12 col-md-12" style="margin: 10px 0;">
        <h2 style="color:#0B0B0B;margin: 20px 0;">域名出售/Domain name for sale</h2>

    </div>

    <div class="col-xs-12 col-md-12"><img src="<?php echo get_template_directory_uri(); ?>/images/domains.png" width="100%" /></div>
</div>


</div><!-- end container -->





<div class="mt-4 pb-4 border-top">



    <footer class="container">


        <div class="row">



            <div class="col-xs-12 col-md-4 mt-4 mb-4">
                <h5 class="text-dark">网站声明</h3>
                    <br />
                    <p class="text-secondary"><?php bloginfo('name'); ?>博客建立于2018年，主要以香港、美国等国外VPS信息发布为主，还包括少量独立服务器优惠信息。本站仅做资料收集，不对商家任何信息及交易做信用担保，有交易纠纷请自行解决。</p>
                    <br />
            </div>
            <div class="col-xs-12 col-md-4 mt-4 mb-4">
                <h5 class="text-dark">技术支持</h3>
                    <br />
                    <p class="text-secondary">&copy;<?php echo date('Y'); ?> Copyright <?php bloginfo('name'); ?> • Powered by <a href="https://wordpress.org/">WordPress</a> • Theme by <a href="https://affdalao.com/258.html" target="_blank">Affdalao（ WPCard ）</a>. <a href="/sitemap.xml" class="text-secondary">sitemap</a>
                    </p>
                    <br />
                    <p class="text-secondary">Hosting By:
                        <img class="ml-2" src="<?php echo get_template_directory_uri(); ?>/images/ovh.png" width="200px" height="80px;">
                    </p>

                    <br />
                    <p class="text-secondary">CDN By:
                        <img class="ml-2" src="https://cdntiger.com/images/cdntiger-logo-blue.png" width="220px" height="80px;">
                    </p>



            </div>


            <div class="col-xs-12 col-md-4  pt-4">
                <h5 class="text-dark">投稿/主题/域名购买</h5>
                <br />
                <p class="text-secondary">TG：<a href="https://t.me/affdalao" target="_blank">affdalao</a></p>
                <br />
            </div>

        </div>


    </footer><!-- end #footer -->

</div>

<?php wp_footer(); ?>


</body>

</html>