<!---文章页边栏AD1---->

<div class="col-xs-12 col-md-12" style="margin:0px;padding:0px;">



    <div class="card mb-4 box-shadow">


        <div class="card-header">

            <h6> <a href="#" title="">本站CDN由CdnTiger提供</a> </h6>

        </div>


        <div class="card-body">
            <div class="row  mt-2">
                <div class="col-xs-12 col-md-12">

                    <div class="mt-2"><a href="https://cdntiger.com" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/cdntiger.png" width="100%" height="150"></a></div>

                </div>
            </div>
        </div>

    </div>


    <div class="card mb-4 box-shadow">


        <div class="card-header">

            <h6> <a href="#" title="">域名展示</a> </h6>

        </div>


        <div class="card-body">
            <div class="row  mt-2">
                <div class="col-xs-12 col-md-12">

                    <div class="mt-2"><img src="<?php echo get_template_directory_uri(); ?>/images/d2.png" width="100%" height="150"></div>

                </div>
            </div>
        </div>

    </div>





    <div class="card mb-4 box-shadow">


        <div class="card-header">

            <ol>

                <h6> <a href="#" title="">热门文章</a> </h6>
            </ol>

        </div>


        <div class="card-body">
            <div class="row  mt-2">
                <div class="col-xs-12 col-md-12">

                    <?php
                    $post_num = 10; // 设置调用条数 
                    $args = array(
                        'post_password' => '',
                        'post_status' => 'publish', // 只选公开的文章. 
                        'post__not_in' => array($post->ID), //排除当前文章 
                        'caller_get_posts' => 1, // 排除置顶文章. 
                        'orderby' => 'comment_count', // 依评论数排序. 
                        'posts_per_page' => $post_num
                    );
                    $query_posts = new WP_Query();
                    $query_posts->query($args);
                    while ($query_posts->have_posts()) {
                        $query_posts->the_post(); ?>
                        <li><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></li>
                    <?php }
                wp_reset_query(); ?>
                </div>
            </div>
        </div>


    </div>



    <!---文章页边栏AD2---->

    <div class="col-xs-12 col-md-12" style="margin:0px;padding:0px;">


        <div class="card mb-4 box-shadow">


            <div class="card-header">

                <h6> <a href="#" title="">域名展示</a> </h6>

            </div>



            <div class="card-body">
                <div class="row  mt-2">
                    <div class="col-xs-12 col-md-12">

                        <div class="mt-2"><img src="<?php echo get_template_directory_uri(); ?>/images/d3.png" width="100%" height="150"></div>
                        <br />
                        <div class="mt-2"><img src="<?php echo get_template_directory_uri(); ?>/images/d6.png" width="100%" height="150"></div>
                        <br />
                        <div class="mt-2"><img src="<?php echo get_template_directory_uri(); ?>/images/d1.png" width="100%" height="150"></div>


                    </div>
                </div>
            </div>


        </div>







        <div class="card mb-4 box-shadow">


            <div class="card-header">

                <h6> <a href="#" title="">标签云</a> </h6>

            </div>



            <div class="card-body">
                <div class="row  mt-2">
                    <div class="col-xs-12 col-md-12">

                        <?php wp_tag_cloud('smallest=15&largest=40&number=50&orderby=count'); ?>

                    </div>
                </div>
            </div>


        </div>







        <!---文章页边栏AD3---->

        <div class="col-xs-12 col-md-12" style="margin:0px;padding:0px;">


            <div class="card mb-4 box-shadow">


                <div class="card-header">

                    <h6> <a href="#" title="">域名展示</a> </h6>

                </div>



                <div class="card-body">
                    <div class="row  mt-2">
                        <div class="col-xs-12 col-md-12">

                            <div class="mt-2"><img src="<?php echo get_template_directory_uri(); ?>/images/d4.png" width="100%" height="150"></div>

                            <br />
                            <div class="mt-2"><img src="<?php echo get_template_directory_uri(); ?>/images/d6.png" width="100%" height="150"></div>
                            <br />
                            <div class="mt-2"><img src="<?php echo get_template_directory_uri(); ?>/images/d8.png" width="100%" height="150"></div>


                        </div>
                    </div>
                </div>


            </div>




        </div><!-- end #sidebar -->
    </div><!-- end #main-->

</div>
</div>