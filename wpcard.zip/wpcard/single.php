<!DOCTYPE HTML>
<html>

<head>

    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <script>
        (adsbygoogle = window.adsbygoogle || []).push({
            google_ad_client: "ca-pub-4792046100400447",
            enable_page_level_ads: true
        });
    </script>


    <!---<base target="_blank" />--->
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php the_title(); ?> - <?php echo get_bloginfo( 'description' );?></title>

    <meta name="description" content="<?php echo get_bloginfo( 'description' );?>">

    <meta name="keywords" content="主机测评,主机优惠码,香港CN2,美国CN2,香港CN2 GIA,美国CN2 GIA,香港CN2直连,美国CN2直连,洛杉矶CN2,圣何塞CN2,圣何塞CN2 GIA,洛杉矶CN2 GIA,洛杉矶CN2直连,圣何塞CN2直连,韩国CN2,韩国CN2 GIA,新加坡CN2,新加坡CN2 GIA,新加坡CN2直连,韩国CN2直连,香港三网直连,美国三网直连,香港直连,美国直连,新加坡直连,香港PCCW直连,香港HKT,日本软银直连,大阪软银直连,东京软银直连,香港高防VPS,美国高防,洛杉矶高防,韩国高防,日本高防,新加坡高防,实惠VPS,实惠域名,实惠虚拟主机,免费活动,免费空间,免费域名,VPS使用教程,建站教程,免费资源,便宜VPS,免费VPS,云服务器,国内云服务器,国外云服务器,国外VPS,香港VPS,美国VPS,欧洲VPS,北美VPS,独立服务器,建站主机,香港云服务器,香港独立服务器,美国独立服务器,高防VPS,DDoS防御,抗投诉VPS,离岸VPS,无版权VPS,无DMCA,洛杉矶VPS,圣何塞VPS,KVM VPS,OpenVZ VPS,不限流量VPS,CN2 GIA,CN2 GT,亚洲优化线路,CN2直连,回程CN2优化,Hyper-V架构,洛杉矶CN2,圣何塞CN2直连,韩国VPS,台湾VPS,日本VPS,新加坡VPS,软银直连,双向CN2,往返CN2,VPS建站教程,XEN架构,XEN VPS,建站VPS,建站云服务器,国内独立服务器,DDoS硬防">

    <?php wp_head(); ?>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style.css">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>



<div class="row col-md-12 navbar" id="navbar">

    <div class="col-md-3">
        <b style="font-size:1.8em;"><a href="/"><?php bloginfo('name'); ?></a></b>
    </div>
    <div class="col-md-6">
        <?php wp_nav_menu('id=navbar'); ?>
    </div>


    <div class="col-md-3">
        <form class="form-inline my-2 my-lg-0" action="/">
            <input name="s" class="form-control mr-sm-2" type="search" placeholder="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
        </form>
    </div>
</div>

<div class="container">



<div class="row  mt-4">

    <div class="col-xs-12 col-md-9">

        <?php if (have_posts()) : ?>

            <?php while (have_posts()) : the_post(); ?>

                <div class="card mb-4 box-shadow">

                    <div class="card-header mb-2">

                        <?php if (function_exists('cmp_breadcrumbs')) cmp_breadcrumbs(); ?>
                    </div>

                    <div class="card-header">

                        <div style="font-size: 0.8em;">
                            <h3 class="mt-2"><?php the_title(); ?></h3>
                        </div>

                        <div class="mt-2">

                            <div style="font-size: 1em;color: #999;">
                                <span class="mb-2" id="avator_css"><?php echo get_avatar(get_the_author_meta('user_email')); ?>&nbsp;&nbsp; <?php the_author(); ?>&nbsp;&nbsp;</span>
                                <span class="mb-2"><i class="fa fa-clock-o"></i>&nbsp;&nbsp; <?php echo get_the_date('Y年m月d日'); ?></span>
                                <span class="mb-2 ml-3"><i class="fa fa-eye"></i>&nbsp;&nbsp;<?php post_views(); ?>&nbsp;&nbsp;</span>
                                <span class="mb-2 ml-3"><i class="fa fa-comment-o"></i>&nbsp;&nbsp;<?php comments_popup_link('0', '1', '%'); ?> 评论</span>

                                <span class="mb-2 float-right"><i class="fa fa-tag"></i>&nbsp;&nbsp;<?php echo get_the_tag_list('Tags: ', ', ', '</span>'); ?>
                            </div>

                        </div>
                    </div>

                    <div class="card-body">
                        <div class="row  mt-2">

                            <article>

                                <?php the_content(); ?>

                            </article>
                        </div>
                    </div>




                <?php endwhile; ?>

            <?php endif; ?>


            <div class="card-header col-md-12 mt-4 mb-4 border-bottom border-top">
                <span class="float-left"> <?php previous_post_link('上一篇: %link') ?></span>
                <span class="float-right"> <?php next_post_link('下一篇: %link') ?></span>
            </div>









            <!-- 相关文章开始 -->
            <div class="card-body row" id="hotarticle">


                <div class="col-md-9  col-xs-12">
                    <ul class="related_posts" style="list-style-type: disc;">
                        <?php
                        $post_num = 8;
                        $exclude_id = $post->ID;
                        $posttags = get_the_tags();
                        $i = 0;
                        if ($posttags) {
                            $tags = '';
                            foreach ($posttags as $tag) $tags .= $tag->term_id . ',';
                            $args = array(
                                'post_status' => 'publish',
                                'tag__in' => explode(',', $tags),
                                'post__not_in' => explode(',', $exclude_id),
                                'caller_get_posts' => 1,
                                'orderby' => 'comment_date',
                                'posts_per_page' => $post_num,
                            );
                            query_posts($args);
                            while (have_posts()) {
                                the_post(); ?>
                                <li><a rel="bookmark" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" target="_blank"><?php the_title(); ?></a></li>
                                <?php
                                $exclude_id .= ',' . $post->ID;
                                $i++;
                            }
                            wp_reset_query();
                        }
                        if ($i < $post_num) {
                            $cats = '';
                            foreach (get_the_category() as $cat) $cats .= $cat->cat_ID . ',';
                            $args = array(
                                'category__in' => explode(',', $cats),
                                'post__not_in' => explode(',', $exclude_id),
                                'caller_get_posts' => 1,
                                'orderby' => 'comment_date',
                                'posts_per_page' => $post_num - $i
                            );
                            query_posts($args);
                            while (have_posts()) {
                                the_post(); ?>
                                <li><a rel="bookmark" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" target="_blank"><?php the_title(); ?></a></li>
                                <?php $i++;
                            }
                            wp_reset_query();
                        }
                        if ($i  == 0)  echo '<li>没有相关文章!</li>';
                        ?>

                    </ul>
                </div>



                <br />


                <div class="card-header col-md-12 mt-4 mb-4 border-bottom border-top">
                    <li><strong>版权声明：</strong>本文版权归<a href="<?php echo network_site_url( '/' );?>"><?php bloginfo('name'); ?></a>和原作者所有，未经许可不得转载。文章部分来源于网络仅代表作者看法，如有不同观点，欢迎进行交流。除非注明，文章均由 <a href="https://affdalao.com"><?php bloginfo('name'); ?></a> 整理发布，欢迎转载，转载请带版权。</li><br />
                    <li class="reprinted"><strong>来源：</strong> <?php bloginfo('name'); ?>( <?php echo network_site_url( '/' );?> )，分享编程和计算机技术。</li>
                    <li class="reprinted"><strong>链接：</strong>本文链接:<a href="<?php the_permalink(); ?>" rel="bookmark" title="本文固定链接 <?php the_permalink(); ?>"><?php the_permalink(); ?></a></li>

                </div>
            </div>














            <div class="col-md-12 mt-4">
                <?php comments_template(); ?>
            </div>

        </div>
    </div>















    <div class="col-xs-12 col-md-3">
        <?php get_sidebar(); ?>
    </div>



    <?php get_footer(); ?>