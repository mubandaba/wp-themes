<?php
/*--------------------------------------------
Description: add top header ads
---------------------------------------------*/
function add_topheader_ads() {
$header_banner = get_theme_option('ads_top_header');
if($header_banner != '') {
echo '<div id="topbanner">';
echo stripcslashes($header_banner);
echo '</div>';
}
}
add_action('bp_inside_header','add_topheader_ads');

/*--------------------------------------------
Description: add featured article
---------------------------------------------*/
function add_article_slider_header() {
global $page, $paged;
$paged = get_query_var( 'paged' );
if( ( is_home() || is_front_page() || is_page_template('page-templates/template-blog.php')) && get_theme_option('slider_on') == 'Enable') {
if ( !$paged ) {
get_template_part( 'lib/sliders/gallery-slider' );
}
}
}
add_action('bp_before_blog_home','add_article_slider_header');


/*--------------------------------------------
Description: add headline
---------------------------------------------*/
function add_header_headline() {
if( is_archive() && get_post_type() == 'post' ) {
get_template_part( 'lib/templates/headline' );
}
}
add_action('bp_before_blog_home','add_header_headline');

/*--------------------------------------------
Description: add breadcrumbs
---------------------------------------------*/


function add_header_breadcrumbs() {
if( !is_home() && !is_front_page() ) { mp_the_breadcrumb(); }
}
add_action('bp_before_blog_home','add_header_breadcrumbs');


/*--------------------------------------------
Description: add left sidebar
---------------------------------------------*/
function add_mp_sidebar_left() {
global $in_bbpress, $bp_active;
if( is_singular() || ($bp_active == 'true' && function_exists('bp_is_blog_page') && !bp_is_blog_page() ) || (function_exists('is_in_woocommerce_page') && is_in_woocommerce_page() )  || ($in_bbpress == 'true') ) {
} else {
get_sidebar( 'left' );
}
}
//add_action('bp_after_blog_home','add_mp_sidebar_left');


/*--------------------------------------------
Description: add mobile nav
---------------------------------------------*/
function mp_add_mobile_nav() {
echo '<div id="mobile-nav">';
get_mobile_navigation( $type='top', $nav_name="primary" );
echo '</div>';
}
add_action('bp_inside_nav','mp_add_mobile_nav');


/*--------------------------------------------
Description: add search in nav
---------------------------------------------*/
function mp_add_nav_search() {
echo '<div id="nav-searchform">';
echo get_search_form();
echo '</div>';

}
add_action('bp_inside_nav','mp_add_nav_search');

/*--------------------------------------------
Description: add ads in post loop
---------------------------------------------*/
function mp_add_ads_post_loop() {
global $postcount;
$paged = get_query_var( 'paged' );
$get_ads_code_one = get_theme_option('ads_loop_one');
$get_ads_code_two = get_theme_option('ads_loop_two');
$infinate_scroll = get_theme_option('infinate_scroll');
if($infinate_scroll == 'Enable') {
if( !is_singular() && !$paged) {
if( $get_ads_code_one == '' && $get_ads_code_two == '') {
} else {
if( 3 == $postcount && $get_ads_code_one ){
echo '<article class="home-post loop-entry"><div class="mansory-post"><div class="ad-loop-post">';
echo stripcslashes(do_shortcode($get_ads_code_one));
echo '</div></div></article>';
} elseif( 9 == $postcount && $get_ads_code_two ){
echo '<article class="home-post loop-entry"><div class="mansory-post"><div class="ad-loop-post">';
echo stripcslashes(do_shortcode($get_ads_code_two));
echo '</div></div></article>';
}
}
}
} else {
if( !is_singular() ) {
if( $get_ads_code_one == '' && $get_ads_code_two == '') {
} else {
if( 3 == $postcount && $get_ads_code_one ){
echo '<article class="home-post loop-entry"><div class="mansory-post"><div class="ad-loop-post">';
echo stripcslashes(do_shortcode($get_ads_code_one));
echo '</div></div></article>';
} elseif( 9 == $postcount && $get_ads_code_two ){
echo '<article class="home-post loop-entry"><div class="mansory-post"><div class="ad-loop-post">';
echo stripcslashes(do_shortcode($get_ads_code_two));
echo '</div></div></article>';
}
}
}
}
}
add_action('bp_after_blog_post','mp_add_ads_post_loop');


/*--------------------------------------------
Description: disable index for paginate comments
---------------------------------------------*/
function mp_seo_for_comments() {
 global $cpage, $post;
 if ( $cpage > 1 && is_single() ) {
  echo "\n";
  echo "<meta name='robots' content='noindex,follow' />";
  echo "\n";
}
}
add_action( 'wp_head', 'mp_seo_for_comments' );

/*--------------------------------------------
Description: remove pingback for interlink
---------------------------------------------*/
function mp_disable_self_ping( &$links ) {
foreach ( $links as $l => $link )
if ( 0 === strpos( $link, get_option( 'home' ) ) )
unset($links[$l]);
}
add_action( 'pre_ping', 'mp_disable_self_ping' );


/*--------------------------------------------
Description: alter comment_form
---------------------------------------------*/
function mp_alter_comment_form_fields($fields){
$fields['author'] = '<p class="comment-form-author"><i class="fa fa-user"></i><input id="author" name="author" type="text" placeholder="" value="' . esc_attr( $commenter['comment_author'] ) . '" size="30"' . $aria_req . ' /></p>';
$fields['email'] = '<p class="comment-form-email"><i class="fa fa-envelope"></i><input id="email" name="email" ' . ( $html5 ? 'type="email"' : 'type="text"' ) . ' value="' . esc_attr(  $commenter['comment_author_email'] ) . '" size="30"' . $aria_req . ' /></p>';
$fields['url'] = '<p class="comment-form-url"><i class="fa fa-link"></i><input id="url" name="url" ' . ( $html5 ? 'type="url"' : 'type="text"' ) . ' value="' . esc_attr( $commenter['comment_author_url'] ) . '" size="30" /></p>';
return $fields;
}

add_filter('comment_form_default_fields','mp_alter_comment_form_fields');

function mp_alter_comment_form_default($default){
$default['comment_notes_before'] = '';
$default['comment_notes_after'] = '';
$default['comment_field'] = '<p class="comment-form-comment"><textarea id="comment" name="comment" cols="45" rows="8" aria-required="true"></textarea></p>';
return $default;
}
add_filter('comment_form_defaults','mp_alter_comment_form_default');



/*--------------------------------------------
Description: add schema for post
---------------------------------------------*/
function mp_add_itemtype_article() {
 echo ' itemscope="" itemtype="http://schema.org/Article"';
}
add_action('bp_article_start','mp_add_itemtype_article');

function mp_add_itemtype_post_title() {
 echo ' itemprop="name headline"';
}
add_action('bp_article_post_title','mp_add_itemtype_post_title');

function mp_add_itemtype_post_content() {
 echo ' itemprop="articleBody"';
}
add_action('bp_article_post_content','mp_add_itemtype_post_content');


if( !function_exists('mp_out_custom_excerpt') ) {
function mp_out_custom_excerpt($text,$limit) {
global $post;
$output = strip_tags($text);
$output = strip_shortcodes($output);
$output = preg_replace( '|\[(.+?)\](.+?\[/\\1\])?|s', '', $output );
$output = str_replace( '"', "'", $output);
$output = explode(' ', $output, $limit);
if (count($output)>=$limit) {
array_pop($output);
$output = implode(" ",$output).'...';
} else {
$output = implode(" ",$output);
}
return trim($output);
}
}

if(!function_exists('mp_get_user_role')) {
function mp_get_user_role($id) {
$user = new WP_User( $id );
if ( !empty( $user->roles ) && is_array( $user->roles ) ) {
foreach ( $user->roles as $role )
return ucfirst($role);
} else {
return 'User';
}
}
}


function mp_add_custom_schema($content) {
global $post,$aioseop_options;
if( is_single() ) {
$post_aioseo_title = get_post_meta($post->ID, '_aioseop_title', true);
$author_id = get_the_author_meta('ID');
$author_email = get_the_author_meta('user_email');
$author_displayname = get_the_author_meta('display_name');
$author_nickname = get_the_author_meta('nickname');
$author_firstname = get_the_author_meta('first_name');
$author_lastname = get_the_author_meta('last_name');
$author_url = get_the_author_meta('user_url');
$author_status = get_the_author_meta('user_level');
$author_description = get_the_author_meta('user_description');
$author_role = mp_get_user_role($author_id);
// get post thumbnail
$thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), "thumbnail" );
$large_src = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), "large" );
$schema = '';
?>
<?php
$schema .=  '<!-- start data:schema --><span class="post-schema">';
$schema .= '<a itemprop="url" href="'. get_permalink() . '" rel="bookmark" title="' . the_title_attribute('echo=0') . ' ">' . get_permalink() . '</a>';

if($post_aioseo_title):
$schema .= '<span itemprop="alternativeHeadline">' . $post_aioseo_title . '</span>';
endif;

if($large_src):
$schema .= '<span itemprop="image">' . $large_src[0] . '</span>';
endif;
if($thumbnail_src):
$schema .= '<span itemprop="thumbnailUrl">' . $thumbnail_src[0] . '</span>';
endif;
$getmodtime = get_the_modified_time();
if( $getmodtime > get_the_time() ) {
$modtime = get_the_modified_time('c');
} else {
$modtime = get_the_time('c');
}
$schema .= '<time datetime="'.get_the_time('Y-m-d') . '" itemprop="datePublished"><span class="date updated">'. $modtime . '</span></time><span class="vcard author"><span class="fn">'.get_the_author().'</span></span>';
$categories = get_the_category();
$separator = ', ';
$output = '';
if($categories){
foreach($categories as $category) {
$schema .= '<span itemprop="articleSection">' . $category->cat_name . '</span>';
}
}
$posttags = get_the_tags();
$post_tags_list = '';
if ($posttags) {
$schema .= '<span itemprop="keywords">';
foreach($posttags as $tag) {
$post_tags_list .= $tag->name . ',';
}
$schema .= substr( $post_tags_list,0,-1 );
$schema .= '</span>';
}
$schema .= '<div itemprop="description">'. mp_out_custom_excerpt(get_the_content(),50) .'</div>';
$schema .= '<span itemprop="author" itemscope="" itemtype="http://schema.org/Person">';
if($author_googleplus_profile):
$schema .= '<span itemprop="name">'.$author_displayname.'</span><a href="'. $author_googleplus_profile. '?rel=author" itemprop="url">'. $author_googleplus_profile . '</a>';
endif;
$schema .= '<span itemprop="givenName">'.$author_firstname.'</span>
<span itemprop="familyName">'.$author_lastname.'</span><span itemprop="email">'.$author_email . '</span><span itemprop="jobTitle">'. $author_role . '</span>';
if($author_description):
$schema .= '<span itemprop="knows">'.stripcslashes($author_description).'</span>';
endif;
$schema .= '<span itemprop="brand">'. get_bloginfo('name').'</span>';
$schema .= '</span>';
$schema .= '</span><!-- end data:schema -->';
return $content . $schema;
} else {
return $content;
}
}

if( !function_exists('sj_add_google_author_schema') ) {
add_filter('the_content', 'mp_add_custom_schema');
}



?>