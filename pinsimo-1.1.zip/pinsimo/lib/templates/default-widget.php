<?php $get_right_ads_code = get_theme_option('ads_right_sidebar'); if($get_right_ads_code != '') { ?>
<aside class="widget ctr-ad">
<div class="textwidget adswidget"><?php echo stripcslashes(do_shortcode($get_right_ads_code)); ?></div>
</aside>
<?php } ?>

<?php if( get_theme_option('twitter_widget_id') ) { ?>
<aside id="twitter-blk">
<h3 class="widget-title"><span><?php _e('Recent Tweets', TEMPLATE_DOMAIN); ?></span></h3>
<div class="textwidget" id="twitter-news"></div>
</aside>
<?php } ?>

<aside class="widget">
<h3 class="widget-title"><span><?php _e('Topics', TEMPLATE_DOMAIN); ?></span></h3>
<ul><?php wp_list_categories('orderby=name&show_count=1&title_li='); ?></ul>
</aside>
<aside class="widget widget_recent_entries">
<h3 class="widget-title"><span><?php _e('Recent Posts', TEMPLATE_DOMAIN); ?></span></h3>
<ul><?php wp_get_archives('type=postbypost&limit=5'); ?></ul>
</aside>
<aside class="widget">
<h3 class="widget-title"><span><?php _e('Popular Posts', TEMPLATE_DOMAIN); ?></span></h3>
<?php get_hot_topics(5); ?>
</aside>
<!--<aside class="widget">
<h3 class="widget-title"><span><?php _e('Archives', TEMPLATE_DOMAIN); ?></span></h3>
<?php get_calendar(true); ?>
</aside>-->
<aside class="widget">
<h3 class="widget-title"><span><?php _e('Tags', TEMPLATE_DOMAIN); ?></span></h3>
<div class="tagcloud"><?php wp_tag_cloud('smallest=8&largest=21&'); ?></div>
</aside>

