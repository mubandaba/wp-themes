<?php
$infinate_scroll = get_theme_option('infinate_scroll');
if (is_single()) { ?>

<div class="post-nav-archive" id="post-navigator-single">
<div class="alignleft"><?php previous_post_link('&laquo;&nbsp;%link') ?></div>
<div class="alignright"><?php next_post_link('%link&nbsp;&raquo;') ?></div>
</div>

<?php } else { ?>

<div id="post-navigator"<?php if($infinate_scroll == 'Enable') { echo ' class="scroll-enable"'; } ?>>
<?php if($infinate_scroll == 'Enable'): ?>
<div class="wp-pagenavi">
<div class="alignright"><?php next_posts_link(__('Older Entries &raquo;', TEMPLATE_DOMAIN) ); ?></div>
<div class="alignleft"><?php previous_posts_link(__('&laquo; Newer Entries', TEMPLATE_DOMAIN) ); ?></div>
</div>
<?php else: ?>

<?php if( function_exists('paginate_links') ) : ?>
<?php
global $wp_query;
$big = 999999999; // need an unlikely integer
echo '<div class="wp-pagenavi">';
echo paginate_links( array(
    'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
    'format' => '?paged=%#%',
    'current' => max( 1, get_query_var('paged') ),
    'total' => $wp_query->max_num_pages,
    'prev_text'  => __('&laquo;'),
    'next_text'  => __('&raquo;'),
    'before_page_number' => ''
) );
echo '</div>';
?>

<?php else: ?>
<div class="wp-pagenavi">
<div class="alignright"><?php next_posts_link(__('Older Entries &raquo;', TEMPLATE_DOMAIN) ); ?></div>
<div class="alignleft"><?php previous_posts_link(__('&laquo; Newer Entries', TEMPLATE_DOMAIN) ); ?></div>
</div>
<?php endif; ?>
<?php endif; ?>
</div>

<?php } ?>