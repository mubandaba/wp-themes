<?php
/* options css */
$header_image = get_header_image();
$bg_image = get_background_image();
$bg_color = get_background_color();
?>

<?php
if( get_theme_option('body_font') == 'Choose a font' || get_theme_option('body_font') == '') { ?>
body, .post-meta { font-family:verdana,arial,sans-serif;}
<?php } else { ?>
body, .post-meta { font-family: <?php echo get_theme_option('body_font'); ?> !important; font-weight: <?php echo get_theme_option('body_font_weight'); ?> !important; }
<?php } ?>

<?php
if( get_theme_option('headline_font') == 'Choose a font' || get_theme_option('headline_font') == '') { ?>
h1,h2,h3,h4,h5,h6,#siteinfo h1, #siteinfo div,ul.tabbernav li a {font-family:arial,sans-serif;font-weight:bold;}
<?php } else { ?>
h1,h2,h3,h4,h5,h6,#siteinfo h1, #siteinfo div,ul.tabbernav li a {
font-family:  <?php echo get_theme_option('headline_font'); ?> !important; font-weight: <?php echo get_theme_option('headline_font_weight'); ?> !important;}
<?php } ?>

<?php
if( get_theme_option('navigation_font') == 'Choose a font' || get_theme_option('navigation_font') == '') { ?>
#main-navigation, .sf-menu li a { font-family:arial,sans-serif;font-weight:bold;}
<?php } else { ?>
#main-navigation, .sf-menu li a { font-family:  <?php echo get_theme_option('navigation_font'); ?> !important; font-weight: <?php echo get_theme_option('navigation_font_weight'); ?> !important;}
<?php } ?>

<?php
$main_color = get_theme_option('main_color');
if( $main_color ) { ?>
#header,.footer-top{background-color: <?php echo $main_color; ?>;}
h3#reply-title {background: <?php echo $main_color; ?> none;}
#main-navigation {border-top: 5px solid <?php echo $main_color; ?>;}
.sf-menu ul {background: <?php echo $main_color; ?> none;}
.sf-menu ul li a:hover {background: <?php echo dehex($main_color,-10); ?> none;}
.wp-pagenavi a:hover {color:<?php echo $main_color; ?>;border: 1px solid <?php echo $main_color; ?>;}
#right-sidebar h3.widget-title {border-top:1px solid <?php echo $main_color; ?>;border-left:1px solid <?php echo $main_color; ?>;border-right:1px solid <?php echo $main_color; ?>;background-color: <?php echo $main_color; ?>; }
.form-submit #submit{background: <?php echo dehex($main_color,-20); ?> none;border: 1px solid <?php echo $main_color; ?>;}
#right-sidebar a,#right-sidebar aside.widget a:hover,.content a,#post-related h2 a, #post-related p a, #post-related-inline h2 a {color: <?php echo $main_color; ?>;}
.ftop .widget-area aside ul li { border-bottom: 1px solid <?php echo dehex($main_color,-10); ?>; }
footer .fbottom li a{color:<?php echo $main_color; ?> !important;}
#container .content a:hover {color:<?php echo dehex($main_color,-20); ?> !important;}
#post-entry article.post-single .post-content p a,#post-entry article .post-meta a {color:<?php echo $main_color; ?>;}
#post-entry article.post-single .post-content p a:hover,#post-entry article .post-meta a:hover {border-bottom:1px dotted <?php echo $main_color; ?>;color:<?php echo dehex($main_color,-30); ?>;}
#siteinfo h1, #siteinfo div {text-shadow:0 1px 1px <?php echo dehex($main_color,-20); ?>;}
<?php } ?>


<?php
$sec_color = get_theme_option('sec_color');
if( $sec_color ) { ?>
#main-navigation,.footer-top {border-top: 5px solid <?php echo $sec_color; ?>;}
#right-sidebar h3.widget-title {border-bottom: 5px solid <?php echo $sec_color; ?>; }
.ftop h3.widget-title{color:<?php echo dehex($main_color,40); ?>;}
<?php } ?>