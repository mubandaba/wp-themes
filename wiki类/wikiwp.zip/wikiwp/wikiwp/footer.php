<div id="footer">
<a href="<?php bloginfo('url'); ?>/"><?php bloginfo('name'); ?></a><?php the_time('Y') ?>-2022.&nbsp;  powe<span class="red">red</span> by <a href="http://www.imenglei.cn/" target="_blank" title="图书百科">imenglei.cn</a> | <a class="rsslink" href="<?php bloginfo('rss2_url') ?>" title="RSS Feed">RSS</a> | <a href="http://www.imenglei.cn/sitemap.xml">Sitemap</a> | <script src="http://s24.cnzz.com/stat.php?id=4742320&web_id=4742320" language="JavaScript"></script> | <script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3Fcd24406ba6e1d7efa7f4476a3e12797a' type='text/javascript'%3E%3C/script%3E"));
</script>
</div>

<?php wp_footer() ?>

</body>
</html>