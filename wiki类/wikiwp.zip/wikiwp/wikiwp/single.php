<?php
get_header();
get_sidebar();
?>

<div id="container">

<?php while ( have_posts() ) : the_post() ?>

<h1 class="postitle"><?php the_title(); ?><hr /></h1>
<div class="content"><?php  the_content();  ?></div>
<div class="postinfo">作者: <span class="author"><?php  the_author(); ?></span> 更新日期:<span class="date"><?php  the_date(); ?></span> <span class="edit"><?php edit_post_link(__('编辑词条')); ?></span>
<br>
词条分类: <span class="cat"><?php the_category(', ') ; ?></span>
<br>
<span class="tags"><?php the_tags(); ?></span> 
</div>
<?php wp_link_pages(array('before' => '<p><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>

<div class="navigation">
<div class="alignleft"><?php next_post_link('下一篇: %link') ?></div>
<div class="alignright"><?php previous_post_link('上一篇: %link') ?></div>
</div>

<div class="comments">
<?php if (comments_open()) comments_template(); ?>
</div>

<?php endwhile ?>

<div class="lastlist">
<p>最新词条</p>
<ul>
<?php wp_get_archives('type=postbypost&limit=10'); ?>
</ul>
</div>

</div>

<?php get_footer(); ?>