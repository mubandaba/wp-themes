<?php
//文章截取文字函数
function wodewp_strimwidth($str ,$start ,$width ,$trimmarker ){
$output = trim(preg_replace('/^(?:[\x00-\x7F]|[\xC0-\xFF][\x80-\xBF]+){0,'.$start.'}((?:[\x00-\x7F]|[\xC0-\xFF][\x80-\xBF]+){0,'.$width.'}).*/s','\1',$str));
return $output.$trimmarker;
}
//the_date_x()同时显示多篇在同一日期发表的文章
function the_date_x($d='', $before='', $after='', $echo = true) {
        global $id, $post, $day, $previousday, $newday;
        $the_date = '';
        $the_date .= $before;
        if ( $d=='' )
                $the_date .= mysql2date(get_option('date_format'), $post->post_date);
        else
                $the_date .= mysql2date($d, $post->post_date);
        $the_date .= $after;
        $previousday = $day;

        $the_date = apply_filters('the_date', $the_date, $d, $before, $after);
        if ( $echo )
                echo $the_date;
        else
                return $the_date;
}
//自动提取文章内容前500字符作为摘要
function the_blog_excerpt($content, $size = 300, $echo = true) {
  $out = '';
  $_size = mb_strlen($content, 'utf-8');
  if ($_size <= $size) {
    $out = $content;
  } else if (strpos($content, '<') === false) {
    $out = mb_substr($content, 0, $size);
  } else if ($e = strpos($content, '<!-- more -->')) {
    $out = mb_substr($content, 0, $e);
  } else {
    $strlen_var = strlen($content);
    $html_tag = 0;
    $summary_string = '';
    $html_array = array('left' => array(), 'right' => array());
    for ($i = 0; $i < $strlen_var; ++$i) {
      if (!$size) {
        break;
      }
      $current_var = substr($content, $i, 1);
      if ($current_var == '<') {
        $html_tag = 1;
        $html_array_str = '';
      } else if ($html_tag == 1) {
        if ($current_var == '>') {
          $html_array_str = trim($html_array_str);
          if (substr($html_array_str, -1) != '/') {
            $f = substr($html_array_str, 0, 1);
            if ($f == '/') {
              $html_array['right'][] = str_replace('/', '', $html_array_str);
            } else if ($f != '?') {
              if (strpos($html_array_str, ' ') !== false) {
                $html_array['left'][] = strtolower(current(explode(' ', $html_array_str, 2)));
              } else {
                $html_array['left'][] = strtolower($html_array_str);
              }
            }
          }
          $html_array_str = '';
          $html_tag = 0;
        } else {
          $html_array_str .= $current_var;
        }
      } else {
		  --$size;
      }
      $ord_var_c = ord($content {$i});
      switch (true) {
      case(($ord_var_c & 0xE0) == 0xC0) : $summary_string .= substr($content, $i, 2);
        $i += 1;
        break;
      case (($ord_var_c & 0xF0) == 0xE0) : $summary_string .= substr($content, $i, 3);
        $i += 2;
        break;
      case (($ord_var_c & 0xF8) == 0xF0) : $summary_string .= substr($content, $i, 4);
        $i += 3;
        break;
      case (($ord_var_c & 0xFC) == 0xF8) : $summary_string .= substr($content, $i, 5);
        $i += 4;
        break;
      case (($ord_var_c & 0xFE) == 0xFC) : $summary_string .= substr($content, $i, 6);
        $i += 5;
        break;
      default:
        $summary_string .= $current_var;
      }
    }
    if ($html_array['left']) {
      $html_array['left'] = array_reverse($html_array['left']);
      foreach($html_array['left'] as $index => $tag) {
        $key = array_search($tag, $html_array['right']);
        if ($key !== false) {
          unset($html_array['right'][$key]);
        } else {
          if (strpos(substr($content, $i), '</'.$tag.'>') === false) {
            $summary_string .= '</'.$tag.'>';
          } else {
            while ($html_array_str != $tag) {
              $current_var = substr($content, $i, 1);
              $i++;
              if ($current_var == '<') {
                $html_tag = 1;
                $html_array_str = '';
              } else if ($html_tag == 1) {
                if ($current_var == '>') {
                  $html_array_str = '';
                  $html_tag = 0;
                } else {
                  $html_array_str .= $current_var;
                  $f = substr($html_array_str, 0, 1);
                  if ($f == '/') {
                    $html_array_str = str_replace('/', '', $html_array_str);
                  }
                }
              }
              $summary_string .= $current_var;
              if ($html_array_str == $tag) {
                $summary_string .= '>';
                $i = $i + 1;
                break;
              }
            }
          }
        }
      }
    }
    $out = $summary_string;
  }
  if ($echo) echo $out;
  return $out;
}
automatic_feed_links();

if ( function_exists('register_sidebar') )
	register_sidebar(array(
		'before_widget' => '<li id="%1$s" class="widget %2$s">',
		'after_widget' => '</li>',
		'before_title' => '',
		'after_title' => '',
	));
// 取消自动保存和修订版本
//　　remove_action('pre_post_update','wp_save_post_revision');
//　　add_action('wp_print_scripts','disable_autosave');
//　　function disable_autosave(){wp_deregister_script('autosave');}
?>