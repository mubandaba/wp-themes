<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes() ?>>

<head profile="http://gmpg.org/xfn/11">

<meta http-equiv="content-type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />

<title><?php echo trim(wp_title('',false)); ?><?php if(wp_title('', false)){echo '_'; } ?><?php bloginfo('name'); ?></title>
<meta name="Keywords" content="<?php echo trim(wp_title('',false)); ?><?php if(wp_title('', false)){echo ','; } ?><?php bloginfo('name'); ?>" />
<meta name="Description" content="<?php if (is_home()&!is_paged() ) {echo  bloginfo('description');} else if (is_single()) {echo '您现在浏览的词条《', trim(wp_title('',false)),'》的摘要是:',wodewp_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 100,"…");} else if (is_category()){echo '您现在浏览的分类是:', trim(wp_title('',false));}?>"/>

<link rel="shortcut icon" href="<?php bloginfo('template_url'); ?>/images/icon.png" type="image/x-icon" />
<link rel="stylesheet" type="text/css" media="screen,projection" href="<?php bloginfo('stylesheet_url'); ?>" />	
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<?php wp_head() ?>
</head>

<body>

<div id="logo">
<a href="<?php bloginfo('url'); ?>"><img src="<?php bloginfo('template_url'); ?>/images/logo.png"></a>
<!-- Change the logo with your own. Use 155x155px sized image, preferably .PNG -->
</div>

<div id="header">
<h1><a href="<?php bloginfo('url'); ?>/"><?php bloginfo('name'); ?></a></h1>
<h4><?php bloginfo('description'); ?></h4>
</div>