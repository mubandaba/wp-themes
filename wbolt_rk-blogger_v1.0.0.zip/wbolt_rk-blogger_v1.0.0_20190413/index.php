<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 * @package RK_blogger WordPress theme
 * @subpackage RK blogger
 * @since RK blogger 1.0
 */

get_header(); ?>

<div class="main">
	<?php if ( have_posts() ) : ?>

    <div class="articles-list" id="J_postList">
		<?php
		// Start the loop.
		$postIndex = 0;
		$adIndex = rand(3,8);
		$hasListAD = WBOptions::opt('ads')['list']['type'];

		while ( have_posts() ) : the_post();

			get_template_part( 'template-parts/content', get_post_format() );

			if($hasListAD && $postIndex == $adIndex){
				get_template_part( 'template-parts/content', 'list-ad' );
			}
			$postIndex++;

		endwhile;

		else :
			get_template_part( 'template-parts/content', 'none' );

		endif;
		?>
    </div>

    <div class="loading-bar"></div>
	<?php
	// Previous/next page navigation.
	wbolt_the_posts_pagination();
	?>
</div>
<?php get_sidebar(); ?>

<?php get_footer(); ?>