<?php
/**
 * The template part for displaying a ad code
 *
 * @package WordPress
 * @subpackage YK-Pro
 * @since Wbolt 1.0
 */
?>
<article class="post post-adbanner">
<?php if(WBOptions::opt('list_display_mode') < 2): ?>
    <div class="inner adb-b">
    <?php echo WBOptions::insertAdBlock('list_b',''); ?>
    </div>
<?php endif; ?>
    <div class="inner adb-a">
    <?php echo WBOptions::insertAdBlock('list',''); ?>
    </div>
</article>
