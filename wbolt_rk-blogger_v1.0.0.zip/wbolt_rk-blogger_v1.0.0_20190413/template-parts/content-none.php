<?php
/**
 * The template part for displaying a message that posts cannot be found
 *
 * @package WordPress
 * @subpackage RK blogger
 * @since Wbolt 1.0
 */
?>
<div class="content-empty">
	<div class="content-inner">
		<?php if ( is_home() && current_user_can( 'publish_posts' ) ) : ?>

            <p><?php printf( __( 'Oh~oh~...博主正在偷懒，未有相关文章。浏览下<a href="/">其他文章</a>其实也不错的...', 'wb' )); ?></p>

		<?php elseif ( is_search() ) : ?>

            <p><?php _e( 'Oh~oh~...暂时未有相关文章，或者你可以试下搜索其他关键字', 'wb' ); ?></p>

		<?php else : ?>

            <p><?php _e( 'Oh~oh~...暂时未有相关文章，或者你可以试下搜索其他关键字', 'wb' ); ?></p>
		<?php endif; ?>

        <form class="search-form" id="searchform-b" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">
            <button type="button" class="btn-search" id="searchsubmit-b"><?php echo wbolt_svg_icon('wbsico-search'); ?></button>
            <input type="text" class="form-control" name="s" id="s" placeholder="<?php esc_attr_e( 'Search', 'wbolt' ); ?>" />
        </form>
    </div>
</div>
