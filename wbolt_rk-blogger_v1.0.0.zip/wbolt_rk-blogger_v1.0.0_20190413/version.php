<?php


define('WB_THEMES_VER','1.0.0');
define('WB_THEMES_CODE','rk-blogger');