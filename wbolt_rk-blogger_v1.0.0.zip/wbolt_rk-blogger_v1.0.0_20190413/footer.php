<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after
 *
 * @package WordPress
 * @subpackage RK blogger
 * @since Wbolt 1.0
 */
?>
</div>

<footer class="footer">
	<?php
    $social_items = WBOptions::opt('social');
    if($social_items):
	    include(TEMPLATEPATH . '/settings/assets/_wb_social_icons.php');
    ?>
    <div class="social-icons">
        <?php foreach ($social_items as $k => $social_item) { ;?>
            <?php if($social_item['url'] || $social_item['img']): ?>
                <?php if($social_item['type'] == 1) { ;?>
                    <a class="social-item with-popover">
                        <?php echo wbolt_svg_icon('wbsi-'.$k); ?>
                        <div class="popover-img">
                            <img src="<?php echo $social_item['img']; ?>">
                        </div>
                    </a>
                <?php }else{ ?>
                    <a class="social-item" href="<?php echo $social_item['url']; ?>" target="_blank">
                        <?php echo wbolt_svg_icon('wbsi-'.$k); ?>
                    </a>
                <?php } ?>
        <?php endif ?>
        <?php } ?>
    </div>
	<?php endif; ?>

    <?php if (has_nav_menu( 'social' ) ) : ?>
        <nav class="nav-footer">
            <?php
            wp_nav_menu( array(
            'theme_location' => 'social',
            'menu_class'     => 'nav-ft',
            'menu_id'     => 'J_footerNav',
            'container'     => ''
            ) );
            ?>
        </nav>
    <?php endif; ?>

	<div class="copyright">
		<?php
		/**
			* Fires before the Wbolt footer text for footer customization.
			*
			* @since Wbolt 1.0
			*/
		do_action( 'wbolt_credits' );
		?>

        <?php if(WBOptions::opt('copyright_footer')): ?>
        <div class="ib">
            <?php echo WBOptions::opt('copyright_footer'); ?>
        </div>
        <?php else: ?>
            <span class="ib">Copyright &copy; <?php echo date('Y',time());?> <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></span>
            <span class="ib sppd-h">All Rights Reserved</span>
        <?php endif; ?>
        <span class="ib">Design by <a href="https://www.wbolt.com?ref=rkbloger" target="_blank">闪电博</a></span>
	</div>
</footer>


<?php wp_footer(); ?>

<a class="bktop" id="J_backTop" href="javascript:;" rel="nofollow" title="返回页顶"><svg xmlns="http://www.w3.org/2000/svg" width="23" height="12"><path fill="#999" fill-rule="evenodd" d="M21.58 12L11.5 2.33 1.42 12 0 10.63 10.79.28c.4-.37 1.03-.37 1.42 0L23 10.63 21.58 12z"/></svg></a>

<?php /*自定义底部代码*/ ?>
<?php if(WBOptions::opt('ft_code')) echo WBOptions::opt('ft_code'); ?>

<?php /*百度自动推送代码*/ ?>
<?php if(WBOptions::opt('seo')['bdauto']): ?>
<script>
    (function(){var bp = document.createElement('script');var curProtocol = window.location.protocol.split(':')[0];if (curProtocol === 'https') {bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';}else {bp.src = 'http://push.zhanzhang.baidu.com/push.js';}var s = document.getElementsByTagName("script")[0];s.parentNode.insertBefore(bp, s);})();
</script>
<?php endif; ?>

<?php if(WBOptions::opt('stats_code')): ?>
<div style="display:none;">
    <?php echo WBOptions::opt('stats_code'); ?>
</div>
<?php endif; ?>
</body>
</html>
