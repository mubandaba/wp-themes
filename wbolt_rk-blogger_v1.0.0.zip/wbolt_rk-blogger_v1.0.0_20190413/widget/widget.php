<?php
/**
*
*/

class Wb_Widget
{
    function __construct()
    {
        add_action('widgets_init',
            function() {
                //注册装载小工具的区域
	            register_sidebar( array(
		            'name'          => __( '边栏上部', 'wbolt' ),
		            'id'            => 'sidebar-def',
		            'description'   => __( '可将需要的小工具拖动至此范围，即可在则栏显示', 'wbolt' ),
		            'before_widget' => '<section id="%1$s" class="spmg-bottom widget %2$s">',
		            'after_widget'  => '</section>'
	            ) );
	            register_sidebar( array(
		            'name'          => __( '边栏低部', 'wbolt' ),
		            'id'            => 'sidebar-bottom',
		            'description'   => __( '可将需要的小工具拖动至此范围，即可在则栏显示', 'wbolt' ),
		            'before_widget' => '<section id="%1$s" class="spmg-bottom widget %2$s">',
		            'after_widget'  => '</section>'
	            ) );
	            register_sidebar( array(
		            'name'          => __( '文章详情底部', 'wbolt' ),
		            'id'            => 'sidebar-content-bottom',
		            'description'   => __( '可将需要的小工具拖动至此范围，即可文章详情页底部显示', 'wbolt' ),
		            'before_widget' => '<section id="%1$s" class="wbolt-plugin-area %2$s">',
		            'after_widget'  => '</section>'
	            ) );

                wp_register_sidebar_widget('wbolt-related-posts', '#相关推荐#', function () {
                    echo do_shortcode( '[manual_related_posts]' );
                },array('description'=>'列出相关推荐文章列表，建议在详情页内容底部展示'));

//	            unregister_widget( 'WP_Widget_Archives' );
//	            unregister_widget( 'WP_Widget_Calendar' );
//	            unregister_widget( 'WP_Widget_Categories' );
//	            unregister_widget( 'WP_Widget_Links' );
//	            unregister_widget( 'WP_Widget_Meta' );
//	            unregister_widget( 'WP_Widget_Pages' );
//	            unregister_widget( 'WP_Widget_Recent_Comments' );
//	            unregister_widget( 'WP_Widget_Recent_Posts' );
//	            unregister_widget( 'WP_Widget_RSS' );
//	            unregister_widget( 'WP_Widget_Search' );
//	            unregister_widget( 'WP_Widget_Tag_Cloud' );
//	            unregister_widget( 'WP_Widget_Text' );
//	            unregister_widget( 'WP_Widget_Custom_HTML' );
//	            unregister_widget( 'WP_Widget_Media_Image' );
//	            unregister_widget( 'WP_Widget_Media_Video' );
//	            unregister_widget( 'WP_Widget_Media_Audio' );
//	            unregister_widget( 'WP_Nav_Menu_Widget' );
            });
    }
}
new Wb_Widget();