<?php
/**
 * 下载弹窗
 *
 * @package WordPress
 * @subpackage RK blogger
 * @since Wbolt 1.0
 *
 */
//if( WBOptions::opt('dl')['need_login'])
$switch = 1;
if(WBOptions::opt('dl')['need_login']) {
	$switch = is_user_logged_in() ? 1 : 0;
}

if($switch){
	?>
    <!--下载弹层 S-->
    <div class="com-popover pst-c xk-dialog-df ppo-dl" id="J_ppoDownload">
    <div class="bd">
        <p class="dl-info">
			<?php echo wbolt_svg_icon('wbsico-confirm'); ?>
            <span>密码</span>
            <b class="dl-psw"></b>
            <span>已复制</span>
        </p>
        <a class="wb-btn btn-outlined btn-download btn-outlined-lg" href="" target="_blank" rel="nofollow">
			<?php echo wbolt_svg_icon('wbsico-download'); ?>
            <span>前往下载页面</span>
        </a>
    </div>
    <div class="info-for-sp">
        <p>低版本浏览器需手动复制密码再前往下载页面下载，谢谢</p>
    </div>

    <a class="wb-ppo-close"><?php echo wbolt_svg_icon('wbsico-close'); ?></a>
    </div>
<?php }?>