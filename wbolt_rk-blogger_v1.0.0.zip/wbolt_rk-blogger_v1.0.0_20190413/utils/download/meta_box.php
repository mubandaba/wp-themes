<?php



?>
<div class="wb-post-sitting-panel">
    <div class="wbsp-aside selector-bar">
        <label class="tab-item"><input class="wbs-radio" type="radio" name="wb_dl_type" <?php echo !$meta_value['wb_dl_type'] ? 'checked' : '';?> value="0"> 关闭</label>
        <label class="tab-item"><input class="wbs-radio" type="radio" name="wb_dl_type" <?php echo $meta_value['wb_dl_type'] == '1' ? 'checked' : '';?> value="1"> 本地附件上传</label>
        <label class="tab-item"><input class="wbs-radio" type="radio" name="wb_dl_type" <?php echo $meta_value['wb_dl_type'] == '2' ? 'checked' : '';?> value="2"> 百度网盘分享</label>
    </div>
    <div class="wbsp-main">
        <div class="wbsp-cont section-upload">
            <div class="wbs-upload-box"></div>
        </div>
        <div class="wbsp-cont section-upload">
            <div class="wbs-upload-box">
                <input class="wbs-input upload-input" type="text" placeholder="上传文件" name="wb_down_url_upload" id="wb_down_url_upload" value="<?php echo $meta_value['wb_down_url'];?>">
                <button type="button" class="wbs-btn wbs-upload-btn">
                    <svg class="wb-icon sico-upload"><use xlink:href="#sico-upload"></use></svg><span>上传</span>
                </button>
            </div>
        </div>
        <div class="wbsp-cont">
            <?php foreach ($fields as $key=>$field){

                echo '<div class="wb-post-sitting-item"><label for="'.$key.'">'.$field['name'].'</label> <input class="wbs-input" type="text" name="'.$key.'" id="'.$key.'" placeholder="'.$field['tip'].'" value="'.$meta_value[$key].'"></div>';

            }?>

        </div>
    </div>
</div>