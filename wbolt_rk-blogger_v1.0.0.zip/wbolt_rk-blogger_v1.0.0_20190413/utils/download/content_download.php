<?php



?>

<h3>文件下载</h3>
<div class="download-cont">
    <?php if($need_login && !$is_login){//if login ?>
    <a class="wb-btn btn-outlined btn-download" href="<?php echo wp_login_url(get_permalink());?>"><svg class="wb-icon wbsico-download"><use xlink:href="#wbsico-download"></use></svg> <span>去下载</span></a>

    <?php }else{//else if login ?>

        <?php
        if($meta_value['wb_dl_type']=='1'){ //if local file?>
        <a class="wb-btn btn-outlined btn-download" href="<?php echo $meta_value['wb_down_url'];?>" target="_blank"><svg class="wb-icon wbsico-download"><use xlink:href="#wbsico-download"></use></svg> <span>去下载</span></a>

        <?php }else{ //else baidu file?>
        <a class="wb-btn btn-outlined btn-download" data-ppo-name="#J_ppoDownload" data-dl-url="<?php echo $meta_value['wb_down_url'];?>" data-down="<?php echo $meta_value['wb_down_title'];?>" data-clipboard-text="<?php echo $meta_value['wb_down_pwd'];?>" href="javascript:;"><svg class="wb-icon wbsico-download"><use xlink:href="#wbsico-download"></use></svg> <span>去下载</span></a>
            <!--  pop box begin -->
        <div class="com-popover pst-c xk-dialog-df ppo-dl" id="J_ppoDownload">
            <div class="bd">
                <p class="dl-info">
                    <svg class="wb-icon wbsico-confirm"><use xlink:href="#wbsico-confirm"></use></svg>

                    <span>密码</span>
                    <b class="dl-psw"></b>
                    <span>已复制</span>
                </p>
                <a class="wb-btn btn-outlined btn-download btn-outlined-lg" href="" target="_blank" rel="nofollow">
                    <svg class="wb-icon wbsico-download"><use xlink:href="#wbsico-download"></use></svg>
                    <span>前往下载页面</span>
                </a>
            </div>
            <div class="info-for-sp">
                <p>低版本浏览器需手动复制密码再前往下载页面下载，谢谢</p>
            </div>

            <a class="wb-ppo-close"><svg class="wb-icon wbsico-close"><use xlink:href="#wbsico-close"></use></svg></a>
        </div>
            <!--  pop box end  -->

        <?php }//end if baidu file ?>

    <?php } //end if login ?>

</div>