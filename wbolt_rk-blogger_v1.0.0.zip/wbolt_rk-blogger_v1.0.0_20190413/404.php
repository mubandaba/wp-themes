<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package WordPress
 * @subpackage RK blogger
 * @since Wbolt 1.0
 */

get_header(); ?>

<div class="main">
    <div class="header-list">
        <div class="title-list">
            <h1>404 - 页面未找到</h1>
        </div>
    </div>
    <div class="content-empty">
        <div class="content-inner">
            <p>抱歉，您访问的页面不存在或者已经删除</p>
            <form class="search-form" id="searchform-b" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">
                <button type="button" class="btn-search" id="searchsubmit-b"><?php echo wbolt_svg_icon('wbsico-search'); ?></button>
                <input type="text" class="form-control" name="s" id="s" placeholder="<?php esc_attr_e( 'Search', 'wbolt' ); ?>" />
            </form>
        </div>
    </div>

</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>

