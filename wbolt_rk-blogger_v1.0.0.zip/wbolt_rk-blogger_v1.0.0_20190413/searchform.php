<?php
/**
 * Template for displaying search forms in Wbolt
 *
 * @package WordPress
 * @subpackage RK blogger
 * @since Wbolt 1.0
 */
?>
<form class="search-form" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">
    <button type="button" class="btn-search" id="searchsubmit"><?php echo wbolt_svg_icon('wbsico-search'); ?></button>
    <input type="text" class="form-control" name="s" id="s" placeholder="<?php esc_attr_e( 'Search', 'wbolt' ); ?>" />
</form>