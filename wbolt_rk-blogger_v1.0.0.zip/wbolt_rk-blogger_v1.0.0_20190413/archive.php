<?php
/**
 * The template for displaying archive pages
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * If you'd like to further customize these archive views, you may create a
 * new template file for each one. For example, tag.php (Tag archives),
 * category.php (Category archives), author.php (Author archives), etc.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage RK blogger
 * @since Wbolt 1.0
 */

get_header();

$have_posts = have_posts();
?>

<div class="main">
    <div class="header-list">
        <div class="title-list">
            <h1><?php echo single_cat_title( '', false ); ?></h1>
            <?php if ( category_description() ) : ?>
            <div class="description"><?php echo category_description(); ?></div>
           <?php endif; ?>
        </div>

        <?php
        $list_display_mode = WBOptions::opt('list_display_mode');
        if($list_display_mode == 0 && $have_posts): ?>
        <div class="ctrl-area" id="J_switchListModeBtns">
            <a class="ctrl-item" data-mode="1" title="卡片模式"><?php echo wbolt_svg_icon('wbsico-list-a'); ?></a>
            <a class="ctrl-item" data-mode="2" title="图文模式"><?php echo wbolt_svg_icon('wbsico-list-b'); ?></a>
        </div>
        <?php endif; ?>
    </div>

	<?php if ( $have_posts ) : ?>
	<?php echo WBOptions::insertAdBlock('list_title','adbanner-block under-list-title'); ?>

    <div class="articles-list <?php if($list_display_mode < 2) echo ' with-list-mode'; if($list_display_mode == 1) echo ' list-mode-b'; ?>" id="J_postList">
		<?php
		// Start the loop.
		$postIndex = 0;
		$adIndex = rand(3,8);
		$hasListAD = WBOptions::opt('ads')['list']['type'];

		while ( have_posts() ) : the_post();
			get_template_part( 'template-parts/content', get_post_format() );

			if($hasListAD && $postIndex == $adIndex){
				get_template_part( 'template-parts/content', 'list-ad' );
			}
			$postIndex++;

		endwhile;
		?>
    </div>
    <div class="loading-bar"></div>
    <?php
    wbolt_the_posts_pagination();
    ?>

	<?php else :
		get_template_part( 'template-parts/content-none', 'none' );

	endif;
	?>
</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>
