<?php
wp_enqueue_script('thickbox');
wp_enqueue_script('my-upload');
wp_enqueue_style('thickbox');
wp_enqueue_style( 'wp-color-picker' );
wp_enqueue_script( 'wp-color-picker');
wp_enqueue_script('eccharts-js', get_template_directory_uri() . '/settings/assets/echarts.min.js', array());
wp_enqueue_script('jquery-range-js', get_template_directory_uri() . '/settings/assets/jquery.range/jquery.range-min.js', array());
wp_enqueue_script('wbs-js', get_template_directory_uri() . '/settings/assets/wb_setting.js', array(),'20190409');

wp_enqueue_media();
?>
<script>
    var _admin_url = '<?php echo admin_url(); ?>';
</script>

<div style=" display:none;">
    <svg aria-hidden="true" style="position: absolute; width: 0; height: 0; overflow: hidden;" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
        <defs>
            <symbol id="sico-ad" viewBox="0 0 18 18">
                <title>sico-ad</title>
                <path d="M15.75 7.875h-2.813l-1.688 2.475-4.5-6.75-2.813 4.275h-1.688v-5.625h13.5v5.625zM15.75 15.75h-13.5v-5.625h2.813l1.688-2.475 4.5 6.75 2.813-4.275h1.688v5.625zM16.875 0h-15.75c-0.675 0-1.125 0.45-1.125 1.125v15.75c0 0.675 0.45 1.125 1.125 1.125h15.75c0.675 0 1.125-0.45 1.125-1.125v-15.75c0-0.675-0.45-1.125-1.125-1.125z"></path>
            </symbol>
            <symbol id="sico-base" viewBox="0 0 18 18">
                <title>sico-base</title>
                <path d="M15.75 6.75h-4.5v-2.25h4.5v2.25zM15.75 13.5h-2.588c-0.338 0.675-1.125 1.125-1.912 1.125-1.243 0-2.25-1.007-2.25-2.25v0c0-1.237 1.013-2.25 2.25-2.25 0.815 0.014 1.522 0.458 1.907 1.114l0.006 0.011h2.588v2.25zM6.75 7.875c-0.815-0.014-1.522-0.458-1.907-1.114l-0.006-0.011h-2.587v-2.25h2.587c0.338-0.675 1.125-1.125 1.913-1.125 1.243 0 2.25 1.007 2.25 2.25v0c0 1.243-1.007 2.25-2.25 2.25v0zM6.75 13.5h-4.5v-2.25h4.5v2.25zM15.75 0h-13.5c-1.243 0-2.25 1.007-2.25 2.25v0 13.5c0 1.238 1.012 2.25 2.25 2.25h13.5c1.243 0 2.25-1.007 2.25-2.25v0-13.5c0-1.243-1.007-2.25-2.25-2.25v0z"></path>
            </symbol>
            <symbol id="sico-code" viewBox="0 0 18 18">
                <title>sico-code</title>
                <path d="M14.287 12.713l-1.575-1.575 2.587-2.7-2.588-2.587 1.575-1.575 3.375 3.375c0.45 0.45 0.45 1.125 0 1.575l-3.375 3.375zM3.712 12.713l-3.375-3.375c-0.199-0.203-0.322-0.481-0.322-0.787s0.123-0.585 0.322-0.788l3.375-3.375 1.575 1.575-2.588 2.475 2.588 2.587-1.575 1.575zM6.75 16.313h-0.337c-0.44-0.159-0.749-0.574-0.749-1.060 0-0.145 0.027-0.283 0.077-0.41l-0.003 0.008 4.5-13.5c0.159-0.44 0.574-0.749 1.060-0.749 0.145 0 0.283 0.027 0.41 0.077l-0.008-0.003c0.563 0.225 0.9 0.787 0.675 1.462l-4.5 13.5c-0.225 0.45-0.675 0.787-1.125 0.787z"></path>
            </symbol>
            <symbol id="sico-seo" viewBox="0 0 18 18">
                <title>sico-seo</title>
                <path d="M7.987 13.5c-0.033 0.001-0.073 0.001-0.112 0.001-3.107 0-5.625-2.518-5.625-5.625 0-0 0-0.001 0-0.001v0c0-3.169 2.569-5.737 5.737-5.737s5.737 2.569 5.737 5.737v0c0 0 0 0.001 0 0.001 0 3.107-2.518 5.625-5.625 5.625-0.040 0-0.079-0-0.118-0.001l0.006 0zM14.287 12.6c0.983-1.3 1.575-2.943 1.575-4.725 0-4.349-3.526-7.875-7.875-7.875v0c-0 0-0.001 0-0.001 0-4.372 0-7.923 3.512-7.987 7.869l-0 0.006c0.016 4.4 3.586 7.96 7.987 7.96 1.778 0 3.42-0.581 4.747-1.563l-0.022 0.015 3.375 3.375c0.225 0.225 0.563 0.338 0.787 0.338s0.563-0.113 0.787-0.338c0.45-0.45 0.45-1.125 0-1.575l-3.375-3.375z"></path>
            </symbol>
            <symbol id="sico-upload" viewBox="0 0 16 13">
                <path d="M9 8v3H7V8H4l4-4 4 4H9zm4-2.9V5a5 5 0 0 0-5-5 4.9 4.9 0 0 0-4.9 4.3A4.4 4.4 0 0 0 0 8.5C0 11 2 13 4.5 13H12a4 4 0 0 0 1-7.9z" fill="#666" fill-rule="evenodd"/>
            </symbol>
            <symbol id="sico-download" viewBox="0 0 16 16">
                <path d="M9 9V0H7v9H4l4 4 4-4z"/><path d="M15 16H1a1 1 0 0 1-1-1.1l1-8c0-.5.5-.9 1-.9h3v2H2.9L2 14H14L13 8H11V6h3c.5 0 1 .4 1 .9l1 8a1 1 0 0 1-1 1.1"/>
            </symbol>
            <symbol id="sico-wb-logo" viewBox="0 0 18 18">
                <title>sico-wb-logo</title>
                <path fill="#fff" d="M7.264 10.8l-2.764-0.964c-0.101-0.036-0.172-0.131-0.172-0.243 0-0.053 0.016-0.103 0.044-0.144l-0.001 0.001 6.686-8.55c0.129-0.129 0-0.321-0.129-0.386-0.631-0.163-1.355-0.256-2.102-0.256-2.451 0-4.666 1.009-6.254 2.633l-0.002 0.002c-0.791 0.774-1.439 1.691-1.905 2.708l-0.023 0.057c-0.407 0.95-0.644 2.056-0.644 3.217 0 0.044 0 0.089 0.001 0.133l-0-0.007c0 1.221 0.257 2.314 0.643 3.407 0.872 1.906 2.324 3.42 4.128 4.348l0.051 0.024c0.129 0.064 0.257 0 0.321-0.129l2.25-5.593c0.064-0.129 0-0.257-0.129-0.321z"></path>
                <path fill="#fff" d="M16.714 5.914c-0.841-1.851-2.249-3.322-4.001-4.22l-0.049-0.023c-0.040-0.027-0.090-0.043-0.143-0.043-0.112 0-0.206 0.071-0.242 0.17l-0.001 0.002-2.507 5.914c0 0.129 0 0.257 0.129 0.321l2.571 1.286c0.129 0.064 0.129 0.257 0 0.386l-5.979 7.264c-0.129 0.129 0 0.321 0.129 0.386 0.618 0.15 1.327 0.236 2.056 0.236 2.418 0 4.615-0.947 6.24-2.49l-0.004 0.004c0.771-0.771 1.414-1.671 1.929-2.7 0.45-1.029 0.643-2.121 0.643-3.279s-0.193-2.314-0.643-3.279z"></path>
            </symbol>
            <symbol id="sico-version" viewBox="0 0 16 16">
                <path d="M8 14c-3.3 0-6-2.7-6-6s2.7-6 6-6 6 2.7 6 6-2.7 6-6 6M8 0C3.6 0 0 3.6 0 8s3.6 8 8 8 8-3.6 8-8-3.6-8-8-8"/>
                <path d="M10.97 6.95a1 1 0 0 1-1.4-.17C9.18 6.28 8.6 6 8 6a2 2 0 0 0 0 4c.61 0 1.18-.28 1.57-.78a1 1 0 1 1 1.58 1.23A4 4 0 1 1 8 4c1.23 0 2.38.56 3.15 1.55a1 1 0 0 1-.18 1.4"/>
            </symbol>
            <symbol id="sico-more" viewBox="0 0 16 16">
                <path d="M6 0H1C.4 0 0 .4 0 1v5c0 .6.4 1 1 1h5c.6 0 1-.4 1-1V1c0-.6-.4-1-1-1M15 0h-5c-.6 0-1 .4-1 1v5c0 .6.4 1 1 1h5c.6 0 1-.4 1-1V1c0-.6-.4-1-1-1M6 9H1c-.6 0-1 .4-1 1v5c0 .6.4 1 1 1h5c.6 0 1-.4 1-1v-5c0-.6-.4-1-1-1M15 9h-5c-.6 0-1 .4-1 1v5c0 .6.4 1 1 1h5c.6 0 1-.4 1-1v-5c0-.6-.4-1-1-1"/>
            </symbol>
            <symbol id="sico-views" viewBox="0 0 16 11">
                <path fill="#999" fill-rule="nonzero" d="M8 0a8.6 8.6 0 0 0-8 5.5A8.6 8.6 0 0 0 8 11a8.6 8.6 0 0 0 8-5.5A8.6 8.6 0 0 0 8 0zm0 9.17c-2 0-3.64-1.65-3.64-3.67A3.65 3.65 0 0 1 8 1.83c2 0 3.64 1.65 3.64 3.67A3.65 3.65 0 0 1 8 9.17zM8 3.3a2.2 2.2 0 0 0-2.18 2.2c0 1.21.98 2.2 2.18 2.2a2.2 2.2 0 0 0 2.18-2.2A2.2 2.2 0 0 0 8 3.3z"/>
            </symbol>
            <symbol id="sico-date" viewBox="0 0 16 16">
                <path d="M8 14c-3.3 0-6-2.7-6-6s2.7-6 6-6 6 2.7 6 6-2.7 6-6 6M8 0C3.6 0 0 3.6 0 8s3.6 8 8 8 8-3.6 8-8-3.6-8-8-8"/>
                <path d="M9 4H7v5h5V7H9z"/>
            </symbol>
        </defs>
    </svg>
</div>

<div id="optionsframework-wrap" class="wbs-wrap">
    <div class="wbs-header">
        <?php echo wbolt_svg_icon('sico-wb-logo'); ?>
        <span>WBOLT</span>
        <strong>主题设置</strong>
    </div>

    <div class="wbs-main">
        <div class="wbs-aside">
            <div class="wbs-tabs">
                <a class="tab-item" title="基本设置" data-href="#wbs-group-base">
	                <?php echo wbolt_svg_icon('sico-base'); ?>
                    <span>基本设置</span>
                </a>
                <a class="tab-item" title="广告管理" data-href="#wbs-group-ads">
	                <?php echo wbolt_svg_icon('sico-ad'); ?>
                    <span>广告管理</span>
                </a>
                <a class="tab-item" title="搜索引擎优化" data-href="#wbs-group-seo">
	                <?php echo wbolt_svg_icon('sico-seo'); ?>
                    <span>SEO设置</span>
                </a>
                <a class="tab-item" title="自定义代码" data-href="#wbs-group-code">
	                <?php echo wbolt_svg_icon('sico-code'); ?>
                    <span>自定义代码</span>
                </a>
                <a class="tab-item" title="下载设置" data-href="#wbs-group-download">
	                <?php echo wbolt_svg_icon('sico-download'); ?>
                    <span>下载设置</span>
                </a>
                <a class="tab-item" title="版本信息" data-href="#wbs-group-version">
	                <?php echo wbolt_svg_icon('sico-version'); ?>
                    <span>版本信息</span>
                </a>
                <a class="tab-item" title="更多资源" data-href="#wbs-group-more">
	                <?php echo wbolt_svg_icon('sico-more'); ?>
                    <span>更多资源</span>
                </a>
            </div>
        </div>

        <form class="wbs-content option-form" id="optionsframework" action="options.php" method="post">
		    <?php
		    settings_fields($opt_key);
		    function _opt($k,$echo=true){
			    $ret =  WBOptions::opt($k,'');
			    if(!$echo)return $ret;
			    echo $ret;
		    }

		    ?>

            <div id="wbs-group-base" class="tab-content">
			    <?php include get_template_directory() . '/settings/tpl/options.normal.tpl.php';?>
            </div>

            <div id="wbs-group-ads" class="tab-content optg-ads">
			    <?php include get_template_directory() . '/settings/tpl/options.ads.tpl.php';?>
            </div>

            <div id="wbs-group-seo" class="tab-content">
			    <?php include get_template_directory() . '/settings/tpl/options.seo.tpl.php';?>
            </div>

            <div id="wbs-group-code" class="tab-content">
                <?php include get_template_directory() . '/settings/tpl/options.code.tpl.php'; ?>
            </div>

            <div id="wbs-group-download" class="tab-content">
			    <?php include get_template_directory() . '/settings/tpl/options.download.tpl.php';?>
            </div>

            <div id="wbs-group-version" class="tab-content">
			    <?php include get_template_directory() . '/settings/tpl/options.version.tpl.php';?>
            </div>

            <div id="wbs-group-more" class="tab-content">
			    <?php include get_template_directory() . '/settings/tpl/options.more.tpl.php';?>
            </div>

            <div class="wbs-footer" id="optionsframework-submit">
                <div class="wbsf-inner">
                    <button class="wbs-btn-primary" type="submit" name="update">保存设置</button>
                </div>
            </div>
        </form>
    </div>
</div>