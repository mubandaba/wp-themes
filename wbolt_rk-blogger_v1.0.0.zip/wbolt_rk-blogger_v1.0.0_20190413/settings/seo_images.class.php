<?php
class RK_SEO_Images {

	
	public function __construct(){	
		$this->add_filters();
		
	}
	
	function add_filters() {
		
		add_filter( 'the_content', array( $this, 'handel_images' ), 500 );
		add_filter( 'post_thumbnail_html', array( $this, 'handel_images_featured' ), 500 );
	
	}
	
	
	function images_process( $matches ) {
		global $post;
		
		$alttext_rep = WBOptions::opt('seo.image.alt');
		$titletext_rep = WBOptions::opt('seo.image.title');
		$override_alt = WBOptions::opt('seo.image.o_alt');
		$override_title = WBOptions::opt('seo.image.o_title');
		$strip_extension_title = WBOptions::opt('seo.image.trip_title');
		
		$title = $post->post_title;
		
		# take care of unusual endings
		$matches[0] = preg_replace( '|([\'"])[/ ]*$|', '\1 /', $matches[0] );
		
		### Normalize spacing around attributes.
		$matches[0] = preg_replace( '/\s*=\s*/', '=', substr( $matches[0], 0, strlen( $matches[0] ) - 2 ) );
		### Get source.
		
		preg_match( '/src\s*=\s*([\'"])?((?(1).+?|[^\s>]+))(?(1)\1)/', $matches[0], $source );
		
		$saved = $source[2];
		
		### Swap with file's base name.
		preg_match( '%[^/]+(?=\.[a-z]{3}(\z|(?=\?)))%', $source[2], $source );
		### Separate URL by attributes.
		$pieces = preg_split( '/(\w+=)/', $matches[0], -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY );
		### Add missing pieces.
		
		$tags = "";
		if ( strrpos( $alttext_rep, "%tags" ) !== false || strrpos( $titletext_rep, "%tags" ) !== false ) {
			$posttags = get_the_tags();		
			
			if ( $posttags ) {
				$i = 0;
				foreach ( $posttags as $tag ) {
					if ( $i == 0 ) {
						$tags = $tag->name . $tags;
					} else {
						$tags = $tag->name . ' ' . $tags;
					}
					++$i;
				}
			}
		}
		
		$cats = "";
		if ( strrpos( $alttext_rep, "%category" ) !== false || strrpos( $titletext_rep, "%category" ) !== false ) {
			$categories = get_the_category();
			
			if ( $categories ) {
				$i = 0;
				foreach ( $categories as $cat ) {
					if ( $i == 0 ) {
						$cats = $cat->slug . $cats;
					} else {
						$cats = $cat->slug . ' ' . $cats;
					}
					++$i;
				}
			}
		}
		
		if ( $override_title || !in_array('alt=', $pieces)) {
			$titletext_rep = str_replace("%title", $post->post_title, $titletext_rep );
			$titletext_rep = str_replace("%name", $source[0], $titletext_rep );
			$titletext_rep = str_replace("%category", $cats, $titletext_rep );
			$titletext_rep = str_replace("%tags", $tags, $titletext_rep );
			$titletext_rep = str_replace("%desc", $post->post_excerpt, $titletext_rep);
			
			if ( $strip_extension_title ) {
				$titletext_rep = str_replace( '"', '', $titletext_rep );
				$titletext_rep = str_replace("'", "", $titletext_rep );			
				$titletext_rep = str_replace("_", " ", $titletext_rep );
				$titletext_rep = str_replace("-", " ", $titletext_rep );
			}
			
			//$titletext_rep = ucwords( strtolower( $titletext_rep ) );
			if ( ! in_array( 'title=', $pieces ) ) {
				array_push( $pieces, ' title="' . $titletext_rep . '"' );
			} else {
				$index			  = array_search( 'title=', $pieces );
				$pieces[$index + 1] = '"' . $titletext_rep . '" ';
			}
		}
		if ( $override_alt || !in_array('alt=', $pieces)) {
			$alttext_rep = str_replace("%title", $post->post_title, $alttext_rep );
			$alttext_rep = str_replace("%name", $source[0], $alttext_rep );
			$alttext_rep = str_replace("%category", $cats, $alttext_rep );
			$alttext_rep = str_replace("%tags", $tags, $alttext_rep );
			$alttext_rep = str_replace("%desc", $post->post_excerpt, $alttext_rep);
			$alttext_rep = str_replace("\"", "", $alttext_rep );
			$alttext_rep = str_replace("'", "", $alttext_rep );
			
			$alttext_rep = ( str_replace("-", " ", $alttext_rep ) );
			$alttext_rep = ( str_replace("_", " ", $alttext_rep ) );
			
			if ( ! in_array( 'alt=', $pieces ) ) {
				array_push( $pieces, ' alt="' . $alttext_rep . '"' );
			} else {
				$index			  = array_search( 'alt=', $pieces );
				$pieces[$index + 1] = '"' . $alttext_rep . '" ';
			}
		}
		
		return implode( '', $pieces ) . ' /';
	}   
	
	function handel_images( $content ) {	
		if(is_single()){		
			$replaced = preg_replace_callback( '/<img[^>]+/', array( $this, 'images_process' ), $content, 20 );
			return $replaced;
		}
		return $content;
	}
	
	function handel_images_featured( $html ) {
		//if(is_single()){
			$replaced = preg_replace_callback( '/<img[^>]+/', array( $this, 'images_process' ), $html );
			return $replaced;
		//}
		return $html;
	}	

}