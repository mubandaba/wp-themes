<?php /**
 * WBolt 推荐资源
 **/
?>
<script type="text/javascript" src="https://www.wbolt.com/wb-api/v1/news/newest"></script>