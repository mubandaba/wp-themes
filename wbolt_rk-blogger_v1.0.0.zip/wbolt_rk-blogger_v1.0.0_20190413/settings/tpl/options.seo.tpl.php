<?php /**
 * WBolt 主题广告设置
 **/

//$item_obj = isset($opt['seo']) && isset($opt['seo']) ? $opt['seo'] : array('','','');
//$item_name =  $opt_name . '[seo]';
 ?>
<div class="sc-header">
    <strong>SEO设置</strong>
    <span>搜索引擎优化</span>
</div>

<div class="sc-body">
    <table class="wbs-form-table">
        <tbody>

        <tr>
            <th class="row w8em">开启全站SEO</th>
            <td><input class="wb-switch" type="checkbox" data-target="#J_SEOseting" name="<?php echo $opt_name;?>[seo][active]" <?php echo isset($opt['seo']) && isset($opt['seo']['active']) && $opt['seo']['active']?' checked':'';?> value="1" id="seo_active"> <span class="description">若你使用了其他搜索引擎优化插件，请务必先停用插件后启用，以免引起冲突！！！</span></td>
        </tr>
        </tbody>
    </table>
</div>
<div class="default-hidden-box<?php echo isset($opt['seo']) && isset($opt['seo']['active']) && $opt['seo']['active']?' active':'';?>" id="J_SEOseting">

	<?php
	$item_obj = isset($opt['seo']) && isset($opt['seo']['index']) ? $opt['seo']['index'] : array('','','');
	$item_name =  $opt_name . '[seo][index]';
	?>
    <h3 class="sc-header">
        <strong>首页SEO设置</strong>
    </h3>
    <div class="sc-body">
        <table class="wbs-form-table">
            <tbody>
            <tr>
                <th class="row w8em">标题</th>
                <td>

                    <div class="input-with-count">
                        <input id="<?php echo $item_name . '_0'; ?>" class="wbs-input" data-max="80" name="<?php echo $item_name;?>[0]" type="text" value="<?php echo $item_obj[0];?>" placeholder="">
                        <span class="count">已输入<?php echo strlen($item_obj[0]);?></span>
                    </div>
                    <p class="description">一般不超过80个字符</p>
                </td>
            </tr>
            <tr>
                <th>关键词</th>
                <td>
                    <label class="input-with-count mt wb-tags-module">
                        <input id="<?php echo $item_name . '_1'; ?>" data-max="100" name="<?php echo $item_name;?>[1]" data-tags-value="<?php echo $item_obj[1];?>" type="hidden" value="<?php echo $item_obj[1];?>" placeholder="">
                        <span class="count">已输入<?php echo strlen($item_obj[1]);?></span>

                        <div class="wb-tags-ctrl">
                            <div class="tag-items">
				                <?php
				                if($item_obj[1]){
					                trim($item_obj[1]);
					                $tagArr = explode(',',$item_obj[1]);

					                foreach ( $tagArr as $item ) :
						                ?>
                                        <div class="tag-item">
                                            <span><?php echo $item; ?></span>
                                            <a class="del" data-del-val="<?php echo $item; ?>"></a>
                                        </div>
					                <?php endforeach; ?>
				                <?php } //endif; ?>
                            </div>
                            <input class="wb-tag-input" type="text" placeholder="以逗号或回车分隔">
                        </div>
                    </label>
                    <p class="description">一般不超过100个字符</p>
            </tr>
            <tr>
                <th>描述</th>
                <td>
                    <div class="input-with-count mt">
                        <textarea id="<?php echo $item_name . '_2'; ?>" class="wbs-input" data-max="200" rows="5" cols="42" name="<?php echo $item_name;?>[2]" placeholder=""><?php echo $item_obj[2];?></textarea>
                        <span class="count">已输入<?php echo strlen($item_obj[2]);?></span>
                    </div>
                    <p class="description">一般不超过200个字符</p>
                </td>
                </td>
            </tr>
            </tbody>
        </table>
    </div>

    <h3 class="sc-header">
        <strong>文章SEO设置</strong>
    </h3>
    <div class="sc-body">
        <p>主题将按如下规则分别自动匹配每篇post的设定：</p>
        <ul class="list-li">
            <li>标题: 文章标题 - 站点名称</li>
            <li>关键词: 文章编辑时使用的tag</li>
            <li>描述: 系统自动读取文章内容前200个字符</li>
        </ul>
    </div>

    <h3 class="sc-header">
        <strong>Page SEO设置</strong>
    </h3>
    <div class="sc-body">
        <p>主题将按如下规则分别自动匹配每篇Page的设定：</p>
        <ul class="list-li">
            <li>标题: 独立页面标题 - 站点名称</li>
            <li>关键词: 为“空”</li>
            <li>描述: 系统自动读取文章内容前200个字符</li>
        </ul>
    </div>

    <h3 class="sc-header">
        <strong>分类页SEO设置</strong>
    </h3>
    <div class="sc-body">

	    <?php
	    $c_list = get_categories(array('hide_empty'=>0));
	    $tableHTML = '';


	    if($c_list)foreach($c_list as $k => $o){
		    $f_name = $o->term_id;
		    $o_id = 'seo_'.$f_name;
		    $o_k = $opt_name.'[seo]['.$f_name.']';
		    $o_v = isset($opt['seo']) && isset($opt['seo'][$f_name])?$opt['seo'][$f_name]:array('','','');

		    $tagsHTML = '';

		    if($o_v[1]){
			    trim($o_v[1]);
			    $tagArr = explode(',',$o_v[1]);

			    foreach ( $tagArr as $item ) :
				    $tagsHTML .= '<div class="tag-item">
                                    <span>' .  $item . '</span>
                                    <a class="del" data-del-val="' . $item .'"></a>
                                </div>';
			    endforeach;
		    }

		    $tableHTML .='
                <table class="wbs-form-table cate-item mt" id="J_'. $o_id .'">
                    <tbody>
                        <tr>
                            <th class="row w8em">标题</th>
                            <td>
                                <div class="seo-setitem input-with-count">
                                    <input id="'. $o_id .'_title" class="wbs-input" data-max="80" name="' . $o_k .'[]" type="text" value="'. $o_v[0] .'" placeholder="">
                                    <span class="count">已输入' . strlen($o_v[0]) . '</span>
                                </div>
                                <p class="description">一般不超过80个字符</p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th>关键词</th>
                            <td>
                                <label class="input-with-count mt wb-tags-module">
                                    <input id="'. $o_id .'_keyWord" name="' . $o_k .'[]" type="hidden" data-max="100" data-tags-value="'. $o_v[1] .'" value="'. $o_v[1] .'" placeholder="">
                                    <span class="count">已输入' . strlen($o_v[1]) . '</span>
                                    
                                    <div class="wb-tags-ctrl">
                                        <div class="tag-items">'.  $tagsHTML .'</div>
                                            <input class="wb-tag-input" type="text" placeholder="以逗号或回车分隔">
                                    </div>
                                </label>
                                <p class="description">一般不超过100个字符</p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th>描述</th>
                            <td>
                                 <div class="seo-setitem input-with-count mt">
                                    <textarea id="'. $o_id .'_desc" class="wbs-input" data-max="200" rows="5" cols="42" name="' . $o_k .'[]" placeholder="">'. $o_v[2] .'</textarea>
                                    <span class="count">已输入' . strlen($o_v[2]) . '</span>
                                </div>
                                <p class="description">一般不超过200个字符</p>
                        </td>
                        </tr>
                    </tbody>
                </table>
                ';
		    ?>
	    <?php }
	    ?>


        <table class="wbs-form-table">
            <tbody>
            <tr>
                <th class="row w8em">请选择分类</th>
                <td>
	                <?php $dropdown_options = array(
		                'show_option_all' => get_taxonomy( 'category' )->labels->all_items,
		                'hide_empty' => 0,
		                'hierarchical' => 1,
		                'show_count' => 0,
		                'orderby' => 'name',
		                'class' => 'settings-cate-dropdown',
		                'selected' => isset($_GET['cat'])?$_GET['cat']:null
	                );

	                wp_dropdown_categories( $dropdown_options ); ?>

                </td>
            </tr>
            </tbody>
        </table>

	    <?php echo $tableHTML; ?>
    </div>
</div>

<h3 class="sc-header">
    <strong>百度推送设置</strong>
</h3>
<div class="sc-body">
    <script>
        function checkBaiduToken(obj,type) {
            if(type==1 && obj.value==obj.defaultValue){
                return;
            }
            var token = '';
            if(type==2){
                token = jQuery(obj).parent().prev('input').val();
            }else{
                token = obj.value;
            }
            jQuery('#check_baidu_resp').html('');
            jQuery.post(ajaxurl,{'action':'wb_baidu_push_url','do':'check_token','token':token},function(ret){
                //console.log(ret);
                if(ret.code){
                    jQuery('#check_baidu_resp').html(ret.desc);
                }else{
                    jQuery('#check_baidu_resp').html('验证成功');
                }


            },'json');
        }
    </script>
    <table class="wbs-form-table">
        <tbody>
        <tr>
            <th class="row w8em">主动推送</th>
            <td>
                <input id="wb_theme_cnf[seo][bdkey]" class="wbs-input" data-max="80" onblur="return checkBaiduToken(this,1);" name="<?php echo $opt_name;?>[seo][bdkey]" type="text" value="<?php echo isset($opt['seo']) && isset($opt['seo']['bdkey']) && $opt['seo']['bdkey'] ?  $opt['seo']['bdkey'] : '' ;?>" placeholder="">

                <p><a href="javascript:void(0);" onclick="return checkBaiduToken(this,2)">验证token</a> <span class="h1" id="check_baidu_resp"></span></p>
                <p class="description">请输入百度推送准入密钥，访问<a class="link">百度站长平台</a>获取准入密钥，<a class="link">查看教程</a>。
                </p>

                <div class="default-hidden-box<?php if($opt['seo']['bdkey'] != '') echo ' active'; ?>" id="J_displayBaiduData">
                    <p class="description mt">温馨提示：推送数据仅作为自动推送和SITEMAP提交链接补充，不代表推送数据一定被百度站长记录</p>
                    <div class="charts-box" id="J_bdtsCharts"></div>
                    <div class="hl">
		                <?php
		                $last_err = get_option('baidu_push_url_last_error',array());
		                if($last_err){
			                echo $last_err['desc'];
		                }
		                ?>
                    </div>
                </div>
            </td>
        </tr>
        <tr>
            <th class="row">自动推送</th>
            <td>
                <input class="wb-switch" type="checkbox" data-target="#J_bdAutoSetMsg" name="<?php echo $opt_name;?>[seo][bdauto]" <?php echo isset($opt['seo']) && isset($opt['seo']['bdauto']) && $opt['seo']['bdauto']?' checked':'';?> value="1" id="seo_bdauto">
                <?php if(isset($opt['seo']) && isset($opt['seo']['bdauto']) && $opt['seo']['bdauto']): ?><span class="description" id="J_bdAutoSetMsg">已启用百度链接自动推送，切莫重复添加推送工具代码。</span><?php else: ?>
                    <span class="description"> 自动推送开关开启后，主题会添加自动推送工具代码，提高百度搜索引擎对站点新增网页发现速度。</span>
                <?php endif; ?>

                <?php /* the code:
                         <script>
                        (function(){
                            var bp = document.createElement('script');
                            var curProtocol = window.location.protocol.split(':')[0];
                            if (curProtocol === 'https') {
                                bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
                            }
                            else {
                                bp.src = 'http://push.zhanzhang.baidu.com/push.js';
                            }
                            var s = document.getElementsByTagName("script")[0];
                            s.parentNode.insertBefore(bp, s);
                        })();
                        </script>
                    */ ?>
            </td>
        </tr>
        <tr>
            <th class="row">Sitemap推送</th>
            <td>


                <div id="sitemap-check">检测中......</div>
                <!--检测是否开启sitemap 若未有：-->
                <div id="sitemap-404" style="display: none;">
                    <p>未检测到有效站点Sitemap，请依据下方说明安装插件生成站点sitemap</p>
                    <p>(1)Sitemap生成-下载并启动Sitemap生成插件，建议安装 Google XML Sitemaps。<a class="link">查看教程</a><br>
                        (2)Sitemap提交-访问并登陆<a>百度站长平台</a>，找到链接提交-自动提交-sitemap，填入sitemap 地址，最后提交。<a>查看教程</a></p>
                </div>


                <!--若有：-->
                    <div id="sitemap-200" style="display: none;">
                        <p>
                            Sitemap地址：<a class="sitemap" href="<?php echo $site_map_exists;?>" target="_blank"><?php echo $site_map_exists;?></a>
                        </p>
                        <p>(1)Sitemap生成-下载并启动Sitemap生成插件，建议安装 Google XML Sitemaps。<a class="link">查看教程</a><br>
                            (2)Sitemap提交-访问并登陆<a>百度站长平台</a>，找到链接提交-自动提交-sitemap，填入sitemap 地址，最后提交。<a>查看教程</a></p>
                    </div>




                <script>
                    jQuery(function(){
                        jQuery.post(ajaxurl,{'action':'wb_baidu_push_url','do':'check_sitemap'},function(ret){
                            //console.log(ret);
                            var o = '#sitemap-' + ret['desc'];
                            jQuery(o).show();

                            jQuery('#sitemap-check').hide();
                            if(!ret.code){
                                var a = jQuery(o).find('a.sitemap');
                                a.attr('href',ret.data);
                                a.html(ret.data);
                            }


                        },'json');

                    })
                </script>

            </td>
        </tr>
        </tbody>
    </table>
</div>
