<?php /**
 * WBolt 版权信息
 **/
 ?>

<div class="sc-body sc-copyright">
    <table class="wbs-info-table">
        <tbody>
        <tr>
            <th class="w8em row">主题名称</th>
            <td>
                闪电博客基础皮肤
            </td>
        </tr>
        <tr>
            <th class="row">当前版本</th>
            <td>
                <strong>4.1.0</strong>
                <span class="ib ml-l">最新版本:4.1.0</span>
                <a href="#">在线更新主题</a>
            </td>
        </tr>
        <tr>
            <th class="row">自动更新</th>
            <td>
                <label>
                    <input class="wb-switch" type="checkbox" name="<?php echo $opt_name; ?>[auto_update]" <?php if(WBOptions::opt('auto_update')) echo ' checked="checked"'; ?> data-value="<?php _opt('auto_update'); ?>"> <span class="description">开启后系统会自动检查版本</span>
                </label>
            </td>
        </tr>
        </tbody>
    </table>
</div>