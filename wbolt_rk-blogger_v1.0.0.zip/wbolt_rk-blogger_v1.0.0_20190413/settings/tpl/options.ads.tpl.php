<?php /**
 * WBolt 主题广告设置
 * array('id'=>'', 'name' => '', 'type' => 0, 'code'=>'', 'img'=>'', 'url'=>'', 'code_desc' => '', 'img_desc' => '')
 **/
 ?>
<div class="sc-header">
    <strong>广告设置</strong>
    <span>提供有谷歌代码广告及图片广告两种形式供选择</span>
</div>

<div class="sc-body">
    <?php
    //初始化数据结构
    $adData = array(
        '0' => array(
            'id'=>'list',
            'name' => '列表页广告 - 卡片模式',
            'type' => 0,
            'code'=>'',
            'img'=>'',
            'url'=>'',
            'code_desc' => '',
            'img_desc' => '建议300px宽 340px高'
        ),
        '1' => array(
            'id'=>'list_b',
            'name' => '列表页广告 - 通栏模式',
            'type' => 0,
            'code'=>'',
            'img'=>'',
            'url'=>'',
            'code_desc' => '',
            'img_desc' => '建议940px宽 120px高'
        ),
        '2' => array(
            'id'=>'list_title',
            'name' => '列表页标题下广告',
            'type' => 0,
            'code'=>'',
            'img'=>'',
            'url'=>'',
            'code_desc' => '',
            'img_desc' => ''
        ),
        '3' => array(
            'id'=>'detail',
            'name' => '详情页广告',
            'type' => 0,
            'code'=>'',
            'img'=>'',
            'url'=>'',
            'code_desc' => '',
            'img_desc' => ''
        ),
        '4' => array(
            'id'=>'sidebar',
            'name' => '侧栏广告',
            'type' => 0,
            'code'=>'',
            'img'=>'',
            'url'=>'',
            'code_desc' => '',
            'img_desc' => ''
        ),
        '5' => array(
            'id'=>'sidebar_b',
            'name' => '侧栏广告-底部',
            'type' => 0,
            'code'=>'',
            'img'=>'',
            'url'=>'',
            'code_desc' => '',
            'img_desc' => ''
        ),
//        '6' => array(
//            'id'=>'dl_top',
//            'name' => '下载页 - 顶部',
//            'type' => 0,
//            'code'=>'',
//            'img'=>'',
//            'url'=>'',
//            'code_desc' => '',
//            'img_desc' => ''
//        ),
//        '7' => array(
//            'id'=>'dl_text',
//            'name' => '下载页 - 文字广告',
//            'type' => 0,
//            'code'=>'',
//            'img'=>'',
//            'url'=>'',
//            'code_desc' => '',
//            'img_desc' => ''
//        )
    );
    ?>

	<?php foreach ($adData as $k => $v){

	$item_obj = isset($opt['ads']) && isset($opt['ads'][$v['id']])?$opt['ads'][$v['id']]:array('','','');
	$item_name =  $opt_name . '[ads][' . $v['id'] . ']';

	?>
    <section class="sc-block j-ad-item">
        <div class="scb-hd"><?php echo $v['name']; ?></div>
        <div class="scb-main">
            <div class="selector-bar">
                <label><input class="wbs-radio" type="radio" name="<?php echo $item_name;?>[type]" value="0" <?php echo !$item_obj['type'] || $item_obj['type']==0 ?  'checked' : ''; ?>> 关闭</label>
                <label><input class="wbs-radio" type="radio" name="<?php echo $item_name;?>[type]" value="1" <?php echo $item_obj['type']==1?  'checked' : ''; ?>> 代码广告（谷歌广告）</label>
                <label><input class="wbs-radio" type="radio" name="<?php echo $item_name;?>[type]" value="2" <?php echo $item_obj['type']==2?  'checked' : ''; ?>> 图片广告</label>
            </div>

            <div class="default-hidden-box wbs-ad-item<?php echo $item_obj['type']==1 ? ' active' : ''; ?>">
                <textarea class="large-text code wbs-input" id="<?php echo $item_name;?>_code" name="<?php echo $item_name;?>[code]" rows="5" cols="42" placeholder="广告代码"><?php echo $item_obj['code'];?></textarea>
                <p class="description"><?php echo $v['code_desc']; ?></p>
            </div>

            <div class="default-hidden-box section-upload wbs-ad-item<?php echo $item_obj['type']==2 ? ' active' : ''; ?>">
                <div class="wbs-upload-box mb">
                    <input class="wbs-input upload-input" type="text" placeholder="广告图片: <?php echo $v['img_desc']; ?>" name="<?php echo $item_name; ?>[img]" id="<?php echo $item_name;?>_img" value="<?php echo $item_obj['img']; ?>">
                    <button type="button" class="wbs-btn wbs-upload-btn">
						<?php echo wbolt_svg_icon('sico-upload'); ?>
                        <span>选择图片</span>
                    </button>
                </div>
                <input class="wbs-input" type="text" name="<?php echo $item_name; ?>[url]" id="<?php echo $item_name;?>_url" value="<?php echo $item_obj['url']; ?>" placeholder="请输入广告链接 http(s)://xxx"/>
            </div>
        </div>
    </section>

    <?php
	} ?>
</div>

<input title="启用Google广告" type="hidden" name="<?php echo $opt_name;?>[ads][ggad]" value="<?php echo $opt['ads']['ggad']; ?>" id="ggad_active">
