<?php /**
 * WBolt 主题下载中转设置
 **/
 ?>

<div class="sc-header">
    <strong>下载设置</strong>
    <span></span>
</div>

<div class="sc-body">
    <table class="wbs-form-table">
        <tbody>
        <tr>
            <th class="row w8em">是否启用下载功能</th>
            <td>
                <input class="wb-switch" data-target="#J_needLoginForDl"  type="checkbox" name="<?php echo $opt_name;?>[dl][switch]"<?php echo isset($opt['dl']) && isset($opt['dl']['switch']) && $opt['dl']['switch']?' checked':'';?> value="1" id="dl_switch">
                <label class="description" for="dl_switch">启用下载功能后，发布文章支持填入下载链接 </label>
            </td>
        </tr>
        </tbody>
    </table>
    <div class="default-hidden-box<?php echo $opt['dl']['switch'] ? ' active':''; ?>" id="J_needLoginForDl">
        <table class="wbs-form-table">
            <tbody>
            <tr>
                <th class="row w8em">是否需要登录下载</th>
                <td>
                    <input class="wb-switch" type="checkbox" name="<?php echo $opt_name;?>[dl][need_login]"<?php echo isset($opt['dl']) && isset($opt['dl']['need_login']) && $opt['dl']['need_login']?' checked':'';?> value="1" id="dl_need_login">
                    <label class="description" for="sign_active">启用登录下载，需要访客注册登录下载，否则可以直接下载 </label>
                </td>
            </tr>
            </tbody>
        </table>
    </div>
</div>

