<?php

/**
 * Created by zhiqun.
 * User: zhiqun
 * Date: 2016/10/27
 * Time: 23:10
 * @subpackage RK blogger
 * @since WBolt 1.0
 */

class WBOptions
{
    function __construct()
    {
        //后台设置
        add_action('admin_init', array($this, 'settings_init'));


        //添加菜单
        add_action('admin_menu', array($this, 'options_page_menu'));


        //============SEO================
        //seo配置
        $seo_opt = $this->opt('seo');
        if (isset($seo_opt['active']) && $seo_opt['active']) {
            //去掉默认标题处理
            remove_action('wp_head', '_wp_render_title_tag', 1);
            //添加seo处理
            add_action('wp_head',array($this,'seoTitle') , 1);
        }

        add_action('admin_init',function(){
	        wp_enqueue_style('wbs-style', get_template_directory_uri() . '/settings/assets/wb_setting.css', array(),'20190409');
	        wp_enqueue_script('wbs-nmjs', get_template_directory_uri() . '/settings/assets/wb_admin.js', array(),'20190403', true);
        },1);
    }

    //主题常量配置
    static function cnf($key, $default = null)
    {
        $cnf = array(
            'name' => 'WB',
            'opt' => 'wb_theme_cnf',
            'opt_key' => 'options_xk_themes'
        );
        if (isset($cnf[$key])) return $cnf[$key];
        return $default;
    }

    //后台设置
    function settings_init()
    {
        register_setting($this->cnf('opt_key'), $this->cnf('opt'));
    }

	function options_page_menu()
	{
		add_menu_page(
			'主题设置',
			'主题设置',
			'edit_theme_options',
			'options-wbthemes',
			array($this,'optionsPage'),
			get_template_directory_uri() . '/settings/assets/wbolt_ico.svg'
		);
	}

    //配置页面get_template_directory() . '/settings/wbolt_ico.png'
    function optionsPage()
    {
	    global $wpdb;
        $opt = $this->opt('');//get_option($this->cnf('opt'));
        $opt_name = $this->cnf('opt');
        $opt_key = $this->cnf('opt_key') ;
        $name = $this->cnf('name');

	    $index_term_id = $opt['flID'];

	    $tm_1 = $wpdb->terms;
	    $tm_2 = $wpdb->term_taxonomy;
	    $sql = "SELECT b.name,b.slug,a.parent,a.term_id FROM $tm_2 a,$tm_1 b WHERE a.term_id=b.term_id AND a.taxonomy='category' order by a.parent";

	    $term_name = array();

	    $term_list = $wpdb->get_results($sql,ARRAY_A);
	    $cate_list = array();
	    $term_list2 = array();
	    foreach($term_list as $term){
		    if(!isset($cate_list[$term['parent']])){
			    $cate_list[$term['parent']] = array();
		    }
		    $cate_list[$term['parent']][] = $term;
		    $term_list2[$term['term_id']] = $term;
	    }
	    if($index_term_id){
		    $index_term_id = explode(',',$index_term_id);
		    foreach ($index_term_id as $term_id) {
			    $term_name[] = $term_list2[$term_id]['name'];
		    }
	    }
//        print_r($opt);

        include get_template_directory() . '/settings/options.php';
    }

    //配置值
    static function opt($name, $default = false)
    {
        //配置的name
        $option_name = self::cnf('opt');
        static $options = null;
        // Get option settings from database
        if (null == $options) $options = get_option($option_name);

        if(!$name)return $options;

        $ret = $options;
        $ak = explode('.', $name);
        foreach ($ak as $sk) {
            if (isset($ret[$sk])) {
                $ret = $ret[$sk];
            } else {
                return $default;
            }
        }
        return $ret;
    }


    //seo title, keywords, description
    function seoTitle()
    {
        $title = wp_get_document_title();
        $kw = $desc = '';
        $tpls = array('<title>%s</title>', '%s', '%s');
        $seo = $this->opt('seo');
        if (is_home()) {
            if (isset($seo['index'])) {
                $mata = $seo['index'];
                if (isset($mata[0]) && $mata[0]) {
                    $title = $this->formatTitle($mata[0]);
                }
                if (isset($mata[1]) && $mata[1]) {
                    $tpls[1] = '<meta name="keywords" content="%s" />';
                    $kw = $mata[1];
                }
                if (isset($mata[2]) && $mata[2]) {
                    $tpls[2] = '<meta name="description" content="%s" />';
                    $desc = $mata[2];
                }
            }
        } else if (is_category()) {
            $term = get_queried_object();
            $cid = $term->term_id;
            if (isset($seo[$cid])) {
                $mata = $seo[$cid];
                if (isset($mata[0]) && $mata[0]) {
                    $sep = apply_filters('document_title_separator', '-');
                    $title = implode($sep, array($mata[0], get_bloginfo('name', 'display')));
                    $title = $this->formatTitle($title);
                }
                if (isset($mata[1]) && $mata[1]) {
                    $tpls[1] = '<meta name="keywords" content="%s" />';
                    $kw = $mata[1];
                }
                if (isset($mata[2]) && $mata[2]) {
                    $tpls[2] = '<meta name="description" content="%s" />';
                    $desc = $mata[2];
                }
            }
        } else if (is_single()) {

            //kw
            $posttags = get_the_tags();

            if ($posttags) {
                $tags = array();
                foreach ($posttags as $tag) {
                    $tags[] = $tag->name;
                }
                $stags = implode(',', $tags);
                $kw = $stags;
                $tpls[1] = '<meta name="keywords" content="%s" />';
            }
            //desc
            $excerpt = $this->excerpt();

            if ($excerpt) {
                $desc = $excerpt;
                $tpls[2] = '<meta name="description" content="%s" />';
            }

        }
        echo sprintf(implode('', $tpls), $title, $kw, $desc);
    }

    //格式化标题
    function formatTitle($title)
    {
        $title = wptexturize($title);
        $title = convert_chars($title);
        $title = esc_html($title);
        $title = capital_P_dangit($title);
        return $title;
    }

    //文章摘要
    function excerpt()
    {
        $post = get_post();
        if (empty($post)) {
            return '';
        }
        $excerpt = $post->post_excerpt ? $post->post_excerpt : $this->trimContent($post->post_content);
        if (!$excerpt) return $excerpt;
        return apply_filters('get_the_excerpt', $excerpt);
    }

    //格式化文章内容
    function trimContent($text)
    {
        $text = strip_shortcodes($text);

        $text = str_replace(']]>', ']]&gt;', $text);

        $excerpt_length = apply_filters('excerpt_length', 120);

        $excerpt_more = apply_filters('excerpt_more', ' ' . '[&hellip;]');
        $text = wp_trim_words($text, $excerpt_length, $excerpt_more);

        return $text;
    }

    //插入广告位
	static function insertAdBlock($ad_name = '', $box_class = 'adbanner-block'){
    	if(!$ad_name) return;

		$ads = self::opt('ads')[$ad_name];

		if($ads['type'] == 0) return;

		$adHTML = '<div class="'. $box_class .'">';

		if($ads['type'] == 1){
			$adHTML .= $ads['code'];
		}elseif($ads['type'] == 2){
			$adHTML .= '<a href="' . $ads['url'] . '" target="_blank" rel="nofollow"><img class="adbn-img" src="' . $ads['img'] . '"></a>';
		}else{
			return;
		}
		$adHTML .= '</div>';

		return $adHTML;
    }

}

new WBOptions();