var gulp = require('gulp'),
    sass = require('gulp-sass'),
    sassmap = require('gulp-sourcemaps'),
    postcss = require('gulp-postcss'),
    px2rem = require('postcss-px2rem'),
    cleanCSS = require('gulp-clean-css'),
    autoprefixer = require('gulp-autoprefixer'),
    concat = require('gulp-concat'),
    notify = require('gulp-notify'),
    //rename = require('gulp-rename'),
    rev = require('gulp-rev'),
    clean = require('gulp-clean'),
    //revReplace = require('gulp-rev-replace'),
    uglify = require('gulp-uglify'),
    cache = require('gulp-cache'),
    watch = require('gulp-watch'),
    connect = require('gulp-connect'),
    cssver = require('gulp-make-css-url-version'),
    imagemin = require('gulp-imagemin'),
    pngquant = require('imagemin-pngquant'),
    uglifycss = require('gulp-uglifycss'),

    browserSync  = require('browser-sync').create(), // Reloads browser and injects CSS. Time-saving synchronised browser testing.
    reload       = browserSync.reload; // For manual browser reload.

//setting
var projectURL = 'http://www.ewp.com';
var paths={
    src:{
        root:'src',
        html:'src/html/**/*.html',
        js:['src/js/**/*.js'],
        scss:['src/sass/**/*.scss'],
        css:'src/css/',
        img:'src/images/**/*.*',
        php:'./**/*.php',
        setting_scss:['src/settings/sass/**/*.scss'],
        setting_css:'src/settings/css/',
        setting_js:'src/settings/js/**/*.js'
    },
    dist:{
        root:'/',
        html:'./html/',
        js:'./js/',
        css:'./css/',
        setting:'./settings/assets/',
        img:'./images/'
        //manifest:['./dist/css/rev-manifest.json','./dist/font/rev-manifest.json']
    }
};

//html
gulp.task('html', function () {
    var options = {
        removeComments: false,
        collapseWhitespace: false,
        collapseBooleanAttributes: false,
        removeEmptyAttributes: false,
        removeScriptTypeAttributes: false,
        removeStyleLinkTypeAttributes: false,
        minifyJS: false,
        minifyCSS: false
    };
    gulp.src(paths.src.html)
        .pipe(gulp.dest(paths.dist.html))
        .pipe(connect.reload());
        //.pipe(notify({ message: 'html编译完成' }));
});

//sass
gulp.task('sass', function() {
    // px to rem or px/2 - rem算法
    //var processors = [px2rem({remUnit: 50, divided: 2})];

    return gulp.src(paths.src.scss)
    //.pipe(sassmap.init())
        .pipe(sass())

        // px to rem or px/2
        //.pipe(postcss(processors))
        //.pipe(sassmap.write())
        //添加前缀
        .pipe(autoprefixer({
            browsers:('last 2 version', 'safari 5', 'ie 8', 'ie 9', 'opera 12.1', 'ios 6', 'android 4'),
            cascade: true,
            remove:true
        }))

        //给文件添加.min后缀
        //.pipe(concat('index.css'))
        //.pipe(rename({ suffix: '.min'}))


        .pipe(gulp.dest(paths.src.css))


        //url加版本号
        //.pipe(cssver({format:'md5'}))

        //压缩文件
        //.pipe(cleanCSS({compatibility: 'ie9+',  inline: ['local']}))

        .pipe(uglifycss({
            // "maxLineLen": 80,
            "uglyComments": true
        }))
        //输出压缩文件到指定目录
        .pipe(gulp.dest(paths.dist.css))

        .pipe(connect.reload());
});


//rem
gulp.task('rem', function() {
    // px to rem or px/2 - rem算法
    var processors = [px2rem({remUnit: 50, divided: 2})];

    return gulp.src(paths.src.scss_rem)
    //.pipe(sassmap.init())
    .pipe(sass())

    // px to rem or px/2
    .pipe(postcss(processors))
    //.pipe(sassmap.write())
    //添加前缀
    .pipe(autoprefixer({
        browsers:('last 2 version', 'safari 5', 'ie 8', 'ie 9', 'opera 12.1', 'ios 6', 'android 4'),
        cascade: true,
        remove:true
    }))

    //给文件添加.min后缀
    //.pipe(concat('index.css'))
    //.pipe(rename({ suffix: '.min'}))


    .pipe(gulp.dest(paths.src.css_rem))

    //url加版本号
    //.pipe(cssver({format:'md5'}))

    //压缩文件
    //.pipe(cleanCSS({compatibility: 'ie9+',  inline: ['local']}))

    //输出压缩文件到指定目录
    .pipe(gulp.dest(paths.dist.css_rem))

    .pipe(connect.reload());
});

// //minify and rev js
gulp.task('js-base',function(){
    console.log('js base is running');
    return gulp.src(['src/js/wbolt.js','src/js/base.js'])
        // .pipe(uglify())
        .pipe(concat('base.js'))
        // .pipe(uglify())
        .pipe(gulp.dest(paths.dist.js));
});

// //minify and rev js
gulp.task('js',function(){
    return gulp.src(paths.src.js)

        .pipe(uglify())
        .pipe(gulp.dest(paths.dist.js));
});

//img
gulp.task('img',function(){
    return gulp.src(paths.src.img)
        //.pipe(imagemin({
        //    progressive: true,
        //    svgoPlugins: [{removeViewBox: false}],//不要移除svg的viewbox属性
        //    use: [pngquant({quality: '40-80'})] //使用pngquant深度压缩png图片的imagemin插件
        //}))
        .pipe(gulp.dest(paths.dist.img));
});

//clean
gulp.task('clean',function(){
    return gulp.src(paths.dist.root)
        .pipe(clean())
        // .pipe(notify({message : 'clean task complete'}))
});

//setting
gulp.task('setting_js',function(){
    return gulp.src(paths.src.setting_js)
        .pipe(uglify())
        .pipe(gulp.dest(paths.dist.setting));
});
//sass
gulp.task('setting_sass', function() {
    return gulp.src(paths.src.setting_scss)
        .pipe(sass())
        .pipe(autoprefixer({
            browsers:('last 2 version', 'safari 5', 'ie 8', 'ie 9', 'opera 12.1', 'ios 6', 'android 4'),
            cascade: true,
            remove:true
        }))
        .pipe(gulp.dest(paths.src.setting_css))
        .pipe(uglifycss({
            // "maxLineLen": 80,
            "uglyComments": true
        }))
        //输出压缩文件到指定目录
        .pipe(gulp.dest(paths.dist.setting))
        .pipe(connect.reload());
});

// watch
gulp.task('watch', function () {
    gulp.watch(paths.src.scss, ['sass']);
    // gulp.watch(paths.src.scss_rem, ['rem']);
    gulp.watch(paths.src.css, ['html']);
    gulp.watch(paths.src.img, ['html']);
    // gulp.watch(paths.src.html, ['html']);
    gulp.watch(paths.src.js, ['js']);

    //setting
    gulp.watch(paths.src.setting_js, ['setting_js']);
    gulp.watch(paths.src.setting_scss, ['setting_sass']);
});

/**
 * Task: `browser-sync`.
 *
 * Live Reloads, CSS injections, Localhost tunneling.
 *
 * This task does the following:
 *    1. Sets the project URL
 *    2. Sets inject CSS
 *    3. You may define a custom port
 *    4. You may want to stop the browser from openning automatically
 */
gulp.task( 'browser-sync', function() {
    browserSync.init( {

        // For more options
        // @link http://www.browsersync.io/docs/options/

        // Project URL.
        proxy: {
            target:projectURL
        },

        // `true` Automatically open the browser with BrowserSync live server.
        // `false` Stop the browser from automatically opening.
        open: true,

        // Inject CSS changes.
        // Commnet it to reload browser for every CSS change.
        injectChanges: true,

        // Use a specific port (instead of the one auto-detected by Browsersync).
        // port: 7000,

    } );
});

gulp.task('connect', function() {
  connect.server({
    root: projectURL,
    port: 9000,
    livereload: true
  });
});

//var gulp = require('gulp');
//var fontmin = require('gulp-fontmin');
//
//gulp.task('default', function () {
//    return gulp.src('src/fonts/*.ttf')
//        .pipe(fontmin({
//            text: '天地玄黄 宇宙洪荒',
//        }))
//        .pipe(gulp.dest('dist/fonts'));
//});

//图标字体转换
//var Fontmin = require('fontmin');
//
//var fontmin = new Fontmin()
//    .use(Fontmin.css({
//        fontPath: './src/img/xyf-cd.ttf',         // location of font file
//        base64: true,           // inject base64 data:application/x-font-ttf; (gzip font with css).
//                                // default = false
//        glyph: true,            // generate class for each glyph. default = false
//        iconPrefix: 'my-icon',  // class prefix, only work when glyph is `true`. default to "icon"
//        fontFamily: 'myfont',   // custom fontFamily, default to filename or get from analysed ttf file
//        asFileName: false,      // rewrite fontFamily as filename force. default = false
//        local: true             // boolean to add local font. default = false
//    }))
//    .dest('./css/**/*.css');


// gulp.task('default', ['sass','rem', 'html' ,'js', 'img' , 'connect','watch']);
gulp.task('default', ['sass', 'js','watch']);

gulp.task('setting', ['setting_js', 'setting_sass','watch']);