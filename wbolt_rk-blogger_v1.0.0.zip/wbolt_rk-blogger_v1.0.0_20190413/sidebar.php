<?php
/**
 * The template for the sidebar containing the main widget area
 *
 * @package WordPress
 * @subpackage RK blogger
 * @since Wbolt 1.0
 */
?>

<div class="sidebar">
	<div class="sb-inner sticky-top">
		<?php echo WBOptions::insertAdBlock('sidebar','mb adbanner'); ?>

		<?php dynamic_sidebar( 'sidebar-def' ); ?>

        <section class="tabs mb" id="J_tabBoxSideBar">
            <ul class="tab-nav">
                <li class="current"><a><span>热门文章</span></a></li>
                <li><a><span>随机文章</span></a></li>
                <li><a><span>热门关键词</span></a></li>
            </ul>
            <div class="tab-conts">
                <div class="tab-cont current">
                    <ul class="post-list rec-ul-bull recul-row-1" id="tab-posts">
						<?php
						$strdate = date('Y-m-d',strtotime('-1 year',time()));
						$q_cat = '';
						if(is_category()){
							$q_cat = '&cat='.$wp_query->get('cat');
						}else if(is_single()){
							$term = wp_get_post_terms(get_the_ID(),'category');
							//print_r($term);
							if($term)
								$q_cat = '&cat='.$term[0]->term_id;
							if(get_the_ID()){
								$q_cat .= '&exclude[]='.get_the_ID();
							}
						}else if(is_search()){
							$q_cat = '';
						}
						$posts = get_posts("numberposts=10$q_cat&date_query[after]=$strdate&orderby=meta_value_num&meta_key=post_views_count&order=DESC");
						$idx = 0;
						foreach($posts as $post) : $idx++;?>
                            <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
						<?php endforeach;

						$number = 10-$idx;
						if($number>0){
							$posts = get_posts("numberposts={$number}$q_cat&date_query[before]=$strdate&orderby=rand&order=DESC");
							foreach($posts as $post) : ?>
                                <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
							<?php endforeach;
						}//end if
						?>
                    </ul>
                </div>
                <div class="tab-cont">
                    <ul class="post-list rec-ul-bull recul-row-1" id="tab-posts">
						<?php

						/*$q_cat = '';
						if(is_category()){
							$q_cat = '&cat='.$wp_query->get('cat');
						}else if(is_single()){
							$term = wp_get_post_terms(get_the_ID(),'category');
							//print_r($term);
							if($term)
								$q_cat = '&cat='.$term[0]->term__id;
							if(get_the_ID()){
								$q_cat .= '&exclude[]='.get_the_ID();
							}
						}*/
						$posts = get_posts("numberposts=10$q_cat&date_query[after]=$strdate&orderby=rand");

						$idx = 0;
						foreach($posts as $post) : $idx++;?>
                            <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
						<?php endforeach;
						$number = 10-$idx;
						if($number>0) {
							$posts = get_posts("numberposts=$number$q_cat&date_query[before]=$strdate&orderby=rand");
							foreach ($posts as $post) : ?>
                                <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
							<?php endforeach;
						}//end if
						?>
                    </ul>
                </div>
                <div class="tab-cont cont-tags" id="tab-tags">
                    <div class="tag-list">
						<?php wp_tag_cloud(array(
							'largest' => 1,
							'smallest' => 1,
							'unit' => 'em',
							'orderby' => 'count',
							'order' => 'DESC',
							'number' => 30
						)); ?>
                    </div>
                </div>
            </div>
        </section>

		<?php dynamic_sidebar( 'sidebar-bottom' ); ?>
		<?php echo WBOptions::insertAdBlock('sidebar_b','adbanner'); ?>
    </div>
</div>
