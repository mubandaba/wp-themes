<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage RK blogger
 * @since Wbolt 1.0
 */

if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
	wp_enqueue_script( 'comment-reply' );
}

get_header();

//统计views
setPostViews(get_the_ID());
?>
<div class="main main-detail">
	<?php
	// Start the loop.
	while ( have_posts() ) : the_post();

		// Include the single post content template.
		get_template_part( 'template-parts/content', 'single' );
		?>

        <div class="ctrl-area-cbm">
	        <?php
	        //打赏及分享
	            if( WBOptions::opt('donate')['switch'] ) echo do_shortcode( '[wbolt_donate]' );
	        ?>

            <div class="ctrl-item bdsharebuttonbox" data-tag="share_1">
                <a class="wb-btn btn-ctrl btn-outlined share bds_more" data-cmd="more">
                    <?php echo wbolt_svg_icon('wbsico-share'); ?>
                    <span>分享</span>
                </a>
            </div>


            <script>
                window._bd_share_config = {
                    share : [{
                        "bdSize" : 32
                    }],
                    "url" :'<?php echo get_template_directory_uri(); ?>/module/'
                };
                with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='<?php echo get_template_directory_uri(); ?>/module/static/api/js/share.js?cdnversion='+~(-new Date()/36e5)];
            </script>
        </div>

		<?php #tags S ?>
        <section class="panel-inner panel-tags">
            <h3 class="sc-title">标签</h3>
            <div class="tag-items">
				<?php the_tags('','',''); ?>
            </div>
        </section>
		<?php #tags E ?>

		<?php
		//相关推荐
		    echo do_shortcode( '[manual_related_posts]' );
		?>


		<?php dynamic_sidebar( 'sidebar-content-bottom' ); ?>

		<?php
		// If comments are open or we have at least one comment, load up the comment template.
		if ( comments_open() || get_comments_number() ) {
			comments_template();
		}

		// End of the loop.
	endwhile;
	?>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
