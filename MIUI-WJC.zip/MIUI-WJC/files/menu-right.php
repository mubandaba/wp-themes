<div id="qmenu">
	<a class="qmenua">快捷导航</a>
	<div class="qmenu-drop">
		<div class="feedurl">
			<h3>订阅地址：</h3>
			<input type="text" value="<?php bloginfo('rss2_url'); ?>" onmouseover="$(this).select()" />
			<input type="text" value="<?php bloginfo('atom_url'); ?>" onmouseover="$(this).select()" />
		</div>
	</div>
</div>