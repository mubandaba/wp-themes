<div class="copyright">
	<span>声明</span>：除非文中注明，本站文章均为原创，转载请以链接形式标明本文地址出处。<br />
	<?php bloginfo('name'); ?> | <a href="<?php the_permalink() ?>" rel="bookmark"><?php the_permalink() ?></a>
</div>