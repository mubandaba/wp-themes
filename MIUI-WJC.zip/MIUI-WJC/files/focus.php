<!--幻灯片-->
<div class="focus">
	<div class="col topCol" style="width: 594px">
		<a href="http://bbs.xiaomi.cn/thread-7889766-1-1.html" target="_blank">
			<img src="http://static.xiaomi.cn/xiaomicms/uploadfile/2013/0911/20130911022435807.jpg" style="width: 594px; height: 325px; opacity: 1" /> 
			<span>
				<img src="http://static.xiaomi.cn/xiaomicms/uploadfile/2013/0911/20130911022435807.jpg" style="width: 600px; height: 331px; " />
			</span>
		</a>
		<a href="http://bbs.xiaomi.cn/thread-8044783-1-1.html" target="_blank">
			<img src="http://static.xiaomi.cn/xiaomicms/uploadfile/2013/0911/20130911090716431.jpg" style="width: 594px; height: 325px; opacity: 1" /> 
			<span>
				<img src="http://static.xiaomi.cn/xiaomicms/uploadfile/2013/0911/20130911090716431.jpg" style="width: 600px; height: 331px" /> 
			</span>
		</a>
		<a href="http://bbs.xiaomi.cn/thread-7977935-1-1.html" target="_blank">
			<img src="http://static.xiaomi.cn/xiaomicms/uploadfile/2013/0910/20130910121059873.jpg" style="width: 594px; height: 325px; opacity: 1" /> 
			<span>
				<img src="http://static.xiaomi.cn/xiaomicms/uploadfile/2013/0910/20130910121059873.jpg" style="width: 600px; height: 331px" />
			</span>
		</a>
	</div>
	<div class="col">
		<!--社区首页幻灯中上中图-->
		<a href="http://bbs.xiaomi.cn/thread-7993256-1-1.html" target="_blank">
			<img src="http://static.xiaomi.cn/xiaomicms/uploadfile/2013/0916/20130916113009667.jpg" style="width: 173px; height: 195px; opacity: 1" /> 
			<span>
				<img src="http://static.xiaomi.cn/xiaomicms/uploadfile/2013/0916/20130916113009667.jpg" style="width: 179px; height: 201px; " />
			</span>
		</a>
		<!--社区首页幻灯中下小图-->
		<a href="http://bbs.xiaomi.cn/thread-8063276-1-1.html" target="_blank">
			<img src="http://static.xiaomi.cn/xiaomicms/uploadfile/2013/0916/20130916105944514.jpg" style="width: 173px; height: 120px; opacity: 1" /> 
			<span>
				<img src="http://static.xiaomi.cn/xiaomicms/uploadfile/2013/0916/20130916105944514.jpg" style="width: 179px; height: 126px; " /> 
			</span>
		</a>
	</div>
	<div class="col">
		<!--社区首页幻灯右上小图-->
		<a href="http://bbs.xiaomi.cn/thread-8080600-1-1.html" target="_blank">
			<img src="http://static.xiaomi.cn/xiaomicms/uploadfile/2013/0916/20130916103227912.jpg" style="width: 173px; height: 120px; opacity: 1" /> 
			<span>
				<img src="http://static.xiaomi.cn/xiaomicms/uploadfile/2013/0916/20130916103227912.jpg" style="width: 179px; height: 126px; " /> 
			</span>
		</a>
		<!--社区首页幻灯右下中图-->
		<a href="http://bbs.xiaomi.cn/thread-8077564-1-1.html" target="_blank">
			<img src="http://static.xiaomi.cn/xiaomicms/uploadfile/2013/0912/20130912105316571.jpg" style="width: 173px; height: 195px; opacity: 1" /> 
			<span>
				<img src="http://static.xiaomi.cn/xiaomicms/uploadfile/2013/0912/20130912105316571.jpg" style="width: 179px; height: 201px; " />
			</span>
		</a>
	</div>
</div>