<?php  
include_once('../../wp-config.php');
$options = get_option('mode-options');
$appid = $options['weiboid'];
$login = new sina();
$login->login($appid,get_bloginfo('url').'/oauth/weibo/bind-callback.php');
?>