<?php  
include_once('../../wp-config.php');
$options = get_option('mode-options');
$appid = $options['weiboid'];
$appkey = $options['weibokey'];
$callback = new sina();
$callback->callback($appid,$appkey,get_bloginfo('url').'/oauth/weibo/callback.php');
$callback->sina_bd();
?>