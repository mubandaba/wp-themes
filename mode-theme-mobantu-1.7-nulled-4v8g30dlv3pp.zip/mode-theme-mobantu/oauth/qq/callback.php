<?php  
include_once('../../wp-config.php');
$options = get_option('mode-options');
$appid = $options['qqid'];
$appkey = $options['qqkey'];
$callback = new qq();
$callback->callback($appid,$appkey,get_bloginfo('url').'/oauth/qq/callback.php');
$callback->get_openid();
$callback->qq_cb();
?>