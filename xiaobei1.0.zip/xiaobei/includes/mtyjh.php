<div class="yiyu" >
				<p><?php echo stripslashes(get_option('swt_yjhnr')); ?></p>
				</div>