﻿<div class="gg">
<p>  &nbsp; &nbsp; &nbsp; &nbsp;==<strong>博主QQ:915177271</strong>==<br/>
&nbsp;<a href="http://www.kanhulian.com/" title="网站"><img src="http://www.kanhulian.com/wp-content/themes/xiaobei/images/erweima.png" width="90" height="90"  align="middle"  alt="网站">&nbsp;&nbsp;&nbsp;&nbsp;</a><a href="http://www.kanhulian.com/" title="微信"><img src="http://www.kanhulian.com/wp-content/themes/xiaobei/images/weixin.png" width="90" height="90" align="middle" alt="微信"></a></p>
			<div class="clear"></div>
</div>
<div class="gk"><a href="http://www.kanhulian.com/141.html" title="主题下载" target="_blank"><img src="http://www.kanhulian.com/wp-content/uploads/2014/06/theme.png" alt="主题下载"></a></div>