
<?php get_header(); ?>

<div class="box">
<p style="padding:100px;font-size:2rem;">404，你懂的。</p>
</div>
</div></div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>