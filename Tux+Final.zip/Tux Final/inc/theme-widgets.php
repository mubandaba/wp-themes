<?php
//Tux widget
 include(TEMPLATEPATH . '/widget/posts-tab.php'); 
 include(TEMPLATEPATH . '/widget/widget-comment.php');
 include(TEMPLATEPATH . '/widget/socials.php');
 include(TEMPLATEPATH . '/widget/textbanner.php');
?>