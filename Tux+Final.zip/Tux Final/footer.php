</section>
<footer id="footer">
<?php echo stripslashes(get_option('tux_footer_copy')); ?> <?php echo stripslashes(get_option('tux_icp')); ?> <?php echo stripslashes(get_option('tux_tongji')); ?>
<span class="power-by"> Powered by <a href="http://wordpress.org/" rel="external nofollow" target="_blank">WordPress</a>,
Theme by <a href="http://www.phpabc.cn/simple-tux.html" title="Simple Tux" target="_blank">PHPABC</a></span>
</footer>
<?php wp_footer(); ?>
<a href="#0" class="cd-top">Go</a>
<script src="<?php bloginfo('template_directory'); ?>/js/top.js"></script>
</body>
</html>
