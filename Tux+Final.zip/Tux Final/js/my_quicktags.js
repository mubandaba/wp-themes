QTags.addButton( 'hr', 'hr', "\n<hr />\n", '' );
QTags.addButton( 'h2', 'h2', "<h2>", "</h2>\n" ); 
QTags.addButton( 'h3', 'h3', "<h3>", "</h3>\n" ); 
QTags.addButton( 'php', 'php', "<pre lang='php'>","</pre>");
QTags.addButton( 'javascript', 'javascript', "<pre lang='javascript'>","</pre>");
QTags.addButton( 'css', 'css', "<pre lang='css'>","</pre>");
QTags.addButton( 'html', 'html', "<pre lang='html'>","</pre>");
QTags.addButton( 'xml', 'xml', "<pre lang='xml'>","</pre>");
QTags.addButton( 'bash', 'bash', "<pre lang='bash'>","</pre>");