<?php

$options = array();

CSFramework_Shortcode_Manager::instance($options);
