  <div class="blog-sidebar am-offcanvas" id="blog-offcanvas">
    <div class="am-offcanvas-bar blog-offcanvas-bar">

      <div class="am-panel blog-sidebar-panel">
        <div class="am-panel-bd">
          <p><span class="am-icon-bookmark"></span> 公告</p>
          <p>
      【腾讯官方合作】使用QQ旋风极速下载本站资源！免费享受QQ旋风极速下载权限和超大旋风空间！<a href="http://www.1991217.com/qqxf-download/" target="_blank">点击了解详情</a></p>
        </div>
      </div>
      <div class="am-panel blog-sidebar-panel">
        <div class="am-panel-bd">
          <p><span class="am-icon-bookmark"></span> 伸手党联盟</p>
          <p>
      什么是伸手党？有问题自己不去搜索或者懒得学，却又觉得该问题不值得付费给别人解决，或者觉得费用太高。<small>—— 伸手党联盟</small></p>
        </div>
      </div>

    </div>
  </div>