<?php get_header(); ?>
<div class="am-cf blog-main">
  <div class="blog-content">
    <div class="am-cf am-padding">
      <div class="am-fl am-cf"><a href="http://www.1991217.com/bookmark/" target="_blank" rel="nofollow"><strong class="am-text-primary am-text-lg">酷站导航</strong></a> / <small>在首页你能了解到很多</small></div>
    </div>
    <div class="am-g">
       
      <div class="am-u-md-4">
        <div class="am-panel am-panel-default">
        <div class="am-panel-hd"><h3 class="am-panel-title">最新文章</h3></div>
        <ul class="am-list am-list-acolor am-text-truncate">
        <?php $recent = new WP_Query("showposts=5"); while($recent->have_posts()) : $recent->the_post();?>
<li><a href="<?php the_permalink() ?>" class="am-text-truncate">
<?php the_title(); ?>
</a></li>
<?php endwhile; ?>
        </ul>
        </div>

        <div class="am-panel am-panel-default">
        <div class="am-panel-hd"><h3 class="am-panel-title"><a href="http://www.1991217.com/category/website/site-procedures/">建站程序</a></h3></div>
        <div style="padding: 12.5px;"><a class="am-badge am-badge-secondary am-round">WHMCS</a> <a class="am-badge am-badge-secondary am-round">WordPress</a> <a class="am-badge am-badge-secondary am-radius">Discuz</a></div>
        <ul class="am-list am-list-acolor">
        <?php $recent = new WP_Query("cat=27&showposts=4"); while($recent->have_posts()) : $recent->the_post();?>
<li><a href="<?php the_permalink() ?>" class="am-text-truncate">
<?php the_title(); ?>
</a></li>
<?php endwhile; ?>
        </ul>
        </div>

      </div>

      <div class="am-u-md-4">
        <div class="am-panel am-panel-default">
        <div class="am-panel-hd"><h3 class="am-panel-title">推荐文章</h3></div>
        <ul class="am-list am-list-acolor am-text-truncate">
        <li><a href="http://www.1991217.com/qqxf-download/" class="am-text-truncate" style="color: #F00;">使用QQ旋风极速下载本站资源！免费享受极速下载权限和超大旋风空间！</a></li>
        <li><a href="http://www.1991217.com/make-money-netdisk/" class="am-text-truncate">
网站通过网盘赚钱月收入几千！2015年最好的网赚网盘名单！折腾并快乐着！！</a></li>
        
        <li><a href="http://www.1991217.com/%E6%9C%80%E6%96%B0%E6%8C%82%E6%9C%BA%E8%B5%9A%E9%92%B1%E7%BD%91%E8%B5%9A%E5%A4%A7%E5%85%A8/" class="am-text-truncate">
2016年最新挂机赚钱大全！没事放个程序解决每月话费。</a></li>
        <li><a href="http://www.1991217.com/qqxf-download/" class="am-text-truncate">
使用QQ旋风极速下载本站资源！免费享受极速下载权限和超大旋风空间！</a></li>
<li><a href="http://www.1991217.com/正确识别中国电信chinanet及纯cn2、半程cn2/" class="am-text-truncate" class="am-text-truncate" style="color: blue;">
CN2是什么?点此了解最近最潮的CN2线路!</a></li>
        </ul>
        </div>

        <div class="am-panel am-panel-default">
        <div class="am-panel-hd"><h3 class="am-panel-title"><a href="http://www.1991217.com/category/server/hostpanel/">主机面板</a></h3></div>
        <div class="am-panel-bd"><a class="am-badge am-badge-secondary am-radius">cPanel</a> <a class="am-badge am-badge-secondary am-radius">DirectAdmin</a> <a class="am-badge am-badge-secondary am-radius">AMH</a></div>
        <ul class="am-list am-list-acolor">
        <?php $recent = new WP_Query("cat=28&showposts=4"); while($recent->have_posts()) : $recent->the_post();?>
<li><a href="<?php the_permalink() ?>" class="am-text-truncate">
<?php the_title(); ?>
</a></li>
<?php endwhile; ?>
        </ul>
        </div>

      </div>

      <div class="am-u-md-4">
        <div class="am-panel am-panel-default">
        <div class="am-panel-hd"><h3 class="am-panel-title">别人正在看</h3></div>
        <ul class="am-list am-list-acolor am-text-truncate">
        <?php
$args = array( 'numberposts' => 5, 'orderby' => 'rand', 'post_status' => 'publish' );
$rand_posts = get_posts( $args );
foreach( $rand_posts as $post ) : ?>
<li><a href="<?php the_permalink() ?>" class="am-text-truncate">
<?php the_title(); ?>
</a></li>
<?php endforeach; ?>
        </ul>
        </div>

        <div class="am-panel am-panel-default">
        <div class="am-panel-hd"><h3 class="am-panel-title"><a href="http://www.1991217.com/category/pc-phone/">PC/手机软件</a></h3></div>
        <ul class="am-list am-list-acolor am-text-truncate">
<?php $recent = new WP_Query("cat=75&showposts=5"); while($recent->have_posts()) : $recent->the_post();?>
<li><a href="<?php the_permalink() ?>" class="am-text-truncate">
<?php the_title(); ?>
</a></li>
<?php endwhile; ?>
        </div>

      </div>

      <div class="am-u-md-12">
        <div class="am-panel am-panel-default">
        <div class="am-panel-hd"><h3 class="am-panel-title"><a href="http://www.1991217.com/category/website/template/">建站模版</a></h3></div>
        <div class="am-panel-bd"><a class="am-badge am-badge-secondary am-radius">PHPCMS模板</a> <a class="am-badge am-badge-secondary am-radius">Discuz模板</a> <a class="am-badge am-badge-secondary am-radius">WordPress模板</a></div>
        <hr style="margin-top: 0px;margin-bottom: 0px;">
    <ul class="am-avg-sm-2 am-avg-md-4 am-avg-lg-6 gallery-list">
    <?php $recent = new WP_Query("cat=102&showposts=6"); while($recent->have_posts()) : $recent->the_post();?>
      <li>
        <a href="<?php the_permalink() ?>">
          <img class="am-img-thumbnail am-img-bdrs" src="<?php echo catch_that_image() ?>" alt="<?php the_title(); ?>">
          <div class="gallery-title"><?php the_title(); ?></div>
        </a>
      </li>
     <?php endwhile; ?>
    </ul>

        </div>
        </div>


      <div class="am-u-md-12">
      <div class="am-panel am-panel-default">
        <div class="am-panel-hd"><h3 class="am-panel-title">友情链接</h3></div>
        <div class="am-panel-bd">
       <a href="http://shikey.com/" title="" target="_blank">天下无鱼</a>
        <a href="http://eruses.com/" title="" target="_blank">互联往事</a>
<a href="http://2005111.cc/" title="" target="_blank">2005问答社区</a>
        </div>
        </div>
        </div>
    </div>
  </div>
</div>
<?php get_footer(); ?>