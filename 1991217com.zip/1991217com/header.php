<!doctype html>
<html class="no-js">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php wp_title('-', true, 'right'); echo get_option('blogname'); if (is_home ()) echo "-", get_option('blogdescription'); if ($paged > 1) echo '-Page ', $paged; ?></title>
  <?php wp_head(); ?>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  <meta name="renderer" content="webkit">
  <meta http-equiv="Cache-Control" content="no-siteapp" />
  <link rel="icon" type="image/png" href="<?php bloginfo('template_url'); ?>/i/favicon.png">
  <link rel="apple-touch-icon-precomposed" href="<?php bloginfo('template_url'); ?>/i/app-icon72x72@2x.png">
  <meta name="apple-mobile-web-app-title" content="Amaze UI" />
  <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/amazeui.min.css"/>
  <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/style.css" media="all" />
  <script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "//hm.baidu.com/hm.js?55e54037ac77dfd80e74ccad6d5e53ed";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>
</head>
<body>
<!--[if lte IE 9]>
<p class="browsehappy">你正在使用<strong>过时</strong>的浏览器，Amaze UI 暂不支持。 请 <a href="http://browsehappy.com/" target="_blank">升级浏览器</a>
  以获得更好的体验！</p>
<![endif]-->

<header class="am-topbar blog-header am-topbar-inverse">
  <div class="am-topbar-brand">
    <a href="<?php bloginfo('url'); ?>"><strong>不折腾会死星人</strong></a> <small>点滴积累方有为。</small>
  </div>

  <button class="am-topbar-btn am-topbar-toggle am-btn am-btn-sm am-btn-success am-show-sm-only" data-am-collapse="{target: '#topbar-collapse'}"><span class="am-sr-only">导航切换</span> <span class="am-icon-bars"></span></button>

  <div class="am-collapse am-topbar-collapse" id="topbar-collapse">

    <ul class="am-nav am-nav-pills am-topbar-nav am-topbar-right blog-header-list ">
      <li class="am-dropdown " data-am-dropdown>
        <a class="am-dropdown-toggle" data-am-dropdown-toggle href="javascript:;">
          <span class="am-icon-users"></span> 服务器 <span class="am-icon-caret-down"></span>
        </a>
        <ul class="am-dropdown-content">
          <li><a href="http://www.1991217.com/category/server/hostpanel/"><span class="am-icon-user"></span> 主机面板 </a></li>
          <li><a href="http://www.1991217.com/category/server/idc-faq/"><span class="am-icon-power-off"></span> IDC问题集合 </a></li>
          <li class="am-divider"></li>
          <li><a href="http://www.1991217.com/category/server/linux/"><span class="am-icon-cog"></span> Linux服务器 </a></li>
          <li class="am-divider"></li>
          <li><a href="http://www.1991217.com/category/server/windows/"><span class="am-icon-power-off"></span> Windows服务器 </a></li>
        </ul>
      </li>
    <li class="am-dropdown " data-am-dropdown>
        <a class="am-dropdown-toggle" data-am-dropdown-toggle href="javascript:;">
          <span class="am-icon-users"></span> 网站建设 <span class="am-icon-caret-down"></span>
        </a>
        <ul class="am-dropdown-content">
          <li><a href="http://www.1991217.com/category/website/web-design/"><span class="am-icon-user"></span> 前端设计 </a></li>
          <li><a href="http://www.1991217.com/category/website/template/"><span class="am-icon-cog"></span> 建站模版 </a></li>
          <li class="am-divider"></li>
          <li><a href="http://www.1991217.com/category/website/site-procedures/"><span class="am-icon-power-off"></span> 建站程序 </a></li>
    <li><a href="http://www.1991217.com/category/website/faq/"><span class="am-icon-power-off"></span> 建站问题 </a></li>
    <li class="am-divider"></li>
          <li><a href="http://www.1991217.com/category/website/e-marketing/"><span class="am-icon-power-off"></span> 网络营销 </a></li>
        </ul>
      </li>
      <li><a href="http://www.1991217.com/gbook/"><span class="am-icon-comments"></span> 联系本站 </a></li>
      <li class="am-dropdown " data-am-dropdown>
        <a class="am-dropdown-toggle" data-am-dropdown-toggle href="javascript:;">
          <span class="am-icon-users"></span> 会员 <span class="am-icon-caret-down"></span>
        </a>
        <ul class="am-dropdown-content">
          <li><a href="#"><span class="am-icon-user"></span> 注册</a></li>
          <li><a href="#"><span class="am-icon-cog"></span> 设置</a></li>
          <li><a href="#"><span class="am-icon-power-off"></span> 退出</a></li>
        </ul>
      </li>
    </ul>
  </div>
</header>