<?php get_header(); ?>
<div class="am-cf blog-main">
  <!-- sidebar start -->
  <?php get_template_part( "sidebar" ) ?>
  <!-- sidebar end -->

  <!-- content start -->
  <div class="blog-content" id="blog-right">
    <div class="am-cf am-padding">
      <div class="am-fl am-cf">
      <?php bread_nav();?> </div>
    </div>
<hr>
<ul class="am-avg-sm-2 am-avg-md-4 am-avg-lg-6 am-margin gallery-list">
<?php if ( have_posts() ) : ?>
  <?php while ( have_posts() ) : the_post();?>
      <li>
        <a href="<?php the_permalink(); ?>">
          <img class="am-img-thumbnail am-img-bdrs" src="<?php echo catch_that_image() ?>" alt="<?php the_title(); ?>">
          <div class="gallery-title"><?php the_title(); ?></div>
          <div class="gallery-desc"><?php the_date_xml(); ?></div>
        </a>
      </li>
      <?php endwhile; ?>
    <?php endif; ?>
    </ul>
<hr>
<div class="am-u-sm-12 am-u-sm-centered">
   <?php par_pagenavij(9); ?>
  <?php par_pagenavi(9); ?>
</div>
   
  <!-- content end -->
</div>
</div>
<?php get_footer(); ?>