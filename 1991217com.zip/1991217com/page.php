<?php get_header(); ?>
<div class="am-cf blog-main">
  <!-- sidebar start -->
  <?php get_template_part( "sidebar" ) ?>
  <!-- sidebar end -->

  <!-- content start -->
  <div class="blog-content" id="blog-right">
    <div class="am-cf am-padding">
      <div class="am-fl am-cf">
      <?php bread_nav();?> 
</div>
    </div>
    <?php while (have_posts()) : the_post(); ?>
    <div class="am-g">
      <div class="am-u-sm-12 am-u-sm-centered">
        <h1><?php the_title(); ?></h1>
        <hr/>
      </div>

      <div class="am-u-sm-12 am-u-sm-centered">
      <?php the_content(); ?>
      </div>
    </div>
<div class="am-u-sm-12 am-u-sm-centered">
    <?php comments_template('', true); ?>
</div>
  </div>
  <!-- content end -->
</div>
<?php endwhile;?>
<?php get_footer(); ?>