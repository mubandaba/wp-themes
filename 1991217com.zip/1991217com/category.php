<?php get_header(); ?>
<div class="am-cf blog-main">
  <!-- sidebar start -->
  <?php get_template_part( "sidebar" ) ?>
  <!-- sidebar end -->

  <!-- content start -->
  <div class="blog-content" id="blog-right">
    <div class="am-cf am-padding">
      <div class="am-fl am-cf">
      <?php bread_nav();?> </div>
    </div>

    <div class="am-g">
      <div class="am-u-sm-12 am-u-sm-centered">
      <ul class="am-list am-list-static am-list-border ">
      <?php if ( have_posts() ) : ?>
      	<?php while ( have_posts() ) : the_post();?>
  <li><a href="<?php the_permalink(); ?>"><span class="am-fr"><?php the_date_xml(); ?> </span><?php the_title(); ?></a></li>

<?php endwhile; ?>
    <?php endif; ?>
    </ul>
   <?php par_pagenavij(9); ?>
 <?php par_pagenavi(9); ?>
      </div>

  
  </div>
  <!-- content end -->
</div>
</div>
<?php get_footer(); ?>