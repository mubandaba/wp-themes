<?php

$dname = '1991217com';
include (TEMPLATEPATH . '/functions/wp_bootstrap_navwalker.php');
/**
 * 移除菜单的多余CSS选择器
 * From http://www.wpdaxue.com/remove-wordpress-nav-classes.html
 */
add_filter('nav_menu_css_class', 'my_css_attributes_filter', 100, 1);
add_filter('nav_menu_item_id', 'my_css_attributes_filter', 100, 1);
add_filter('page_css_class', 'my_css_attributes_filter', 100, 1);
function my_css_attributes_filter($var) {
	return is_array($var) ? array() : '';
}


/**
* 修复WordPress找回密码提示“抱歉，该key似乎无效”问题
*/
function reset_password_message( $message, $key ) {
if ( strpos($_POST['user_login'], '@') ) {
$user_data = get_user_by('email', trim($_POST['user_login']));
} else {
$login = trim($_POST['user_login']);
$user_data = get_user_by('login', $login);
}
$user_login = $user_data->user_login;
$msg = __('有人要求重设如下帐号的密码：'). "\r\n\r\n";
$msg .= network_site_url() . "\r\n\r\n";
$msg .= sprintf(__('用户名：%s'), $user_login) . "\r\n\r\n";
$msg .= __('若这不是您本人要求的，请忽略本邮件，一切如常。') . "\r\n\r\n";
$msg .= __('要重置您的密码，请打开下面的链接：'). "\r\n\r\n";
$msg .= network_site_url("wp-login.php?action=rp&key=$key&login=" . rawurlencode($user_login), 'login') ;
return $msg;
}
add_filter('retrieve_password_message', reset_password_message, null, 2);


/*-----------------------------------------------------------------------------------*/
# 建立菜单
/*-----------------------------------------------------------------------------------*/
add_action( 'init', 'Bing_register_nav_menus' );
function Bing_register_nav_menus(){
	register_nav_menus( array(
		'header_menu' => __( '顶部菜单', 'Bing' ),
		'sidebar_menu' => __( '侧边栏菜单', 'Bing' )
	));
}

/*-----------------------------------------------------------------------------------*/
# 分页函数
/*-----------------------------------------------------------------------------------*/
function par_pagenavij($range = 9){   
if ( is_singular() ) return;  
global $wp_query, $paged;  
$max_page = $wp_query->max_num_pages;  
if ( $max_page == 1 ) return;  
if ( $paged == 0 ) $paged++;  
echo "<div class='am-cf'><p class='am-fl'>".第 . $paged .页 .（共 . $max_page .页）. "</p><div class='am-fr'><ul class='am-pagination'>";
}
function par_pagenavi($range = 9){
	global $paged, $wp_query;
	if ( !$max_page ) {$max_page = $wp_query->max_num_pages;}
	if($max_page > 1){if(!$paged){$paged = 1;}
	if($paged != 1){echo "<li><a href='" . get_pagenum_link(1) . "' title='跳转到首页'> 第一页 </a></li>";}
	echo "<li>";
	previous_posts_link(' 上一页 ');
	echo "</li>";
    if($max_page > $range){
		if($paged < $range){for($i = 1; $i <= ($range + 1); $i++){
			echo "<li";
			if($i==$paged)echo " class='am-active'";
			echo "><a href='" . get_pagenum_link($max_page) ."'";
			echo ">$i</a></li>";
		}
	}
    elseif($paged >= ($max_page - ceil(($range/2)))){
		for($i = $max_page - $range; $i <= $max_page; $i++){
			echo "<li";
			if($i==$paged)echo " class='am-active'";
			echo "><a href='" . get_pagenum_link($i) ."'";
			echo ">$i</a></li>";}}
	elseif($paged >= $range && $paged < ($max_page - ceil(($range/2)))){
		for($i = ($paged - ceil($range/2)); $i <= ($paged + ceil(($range/2))); $i++){
			echo "<li";
			if($i==$paged)echo " class='am-active'";
			echo "><a href='" . get_pagenum_link($i) ."'";
			echo ">$i</a></li>";}}}
    else{for($i = 1; $i <= $max_page; $i++){
    	echo "<li";
		if($i==$paged)echo " class='am-active'";
    	echo "><a href='" . get_pagenum_link($i) ."'";
    	echo ">$i</a></li>";}}

    	echo "<li>";
		next_posts_link(' 下一页 ');
		echo "</li>";
    if($paged != $max_page){echo "<li><a href='" . get_pagenum_link($max_page) . "' title='跳转到最后一页'> 最后一页 </a></li>";}
    echo '</ul></div></div>'; 
}
}
/*-----------------------------------------------------------------------------------*/
#面包屑导航
/*-----------------------------------------------------------------------------------*/
function bread_nav($sep = ' > '){
    echo '<a href="'. home_url() .'" title="首页">首页</a>';
    if ( is_category() ){    //如果是栏目页面
        global $cat;        
        echo $sep . get_category_parents($cat, true, $sep) . '文章列表';
    }elseif ( is_page() ){    //如果是自定义页面
        echo $sep . get_the_title();
    }elseif ( is_single() ){    //如果是文章页面
        $categories = get_the_category();
        $cat = $categories[0];
        echo $sep . get_category_parents($cat->term_id, true, $sep) . get_the_title(); 
    }

}
/*-----------------------------------------------------------------------------------*/
#某段时间内最热文章
/*-----------------------------------------------------------------------------------*/
function most_comm_posts($days=30, $nums=5) { //$days参数限制时间值，单位为‘天’，默认是7天；$nums是要显示文章数量
	global $wpdb;
	$today = date("Y-m-d H:i:s"); //获取今天日期时间
	$daysago = date( "Y-m-d H:i:s", strtotime($today) - ($days * 24 * 60 * 60) );  //Today - $days
	$result = $wpdb->get_results("SELECT comment_count, ID, post_title, post_date FROM $wpdb->posts WHERE post_date BETWEEN '$daysago' AND '$today' ORDER BY comment_count DESC LIMIT 0 , $nums");
	$output = '';
	if(empty($result)) {
		$output = '<li>None data.</li>';
	} else {
		foreach ($result as $topten) {
			$postid = $topten->ID;
			$title = $topten->post_title;
			$commentcount = $topten->comment_count;
			if ($commentcount != 0) {
				$output .= '<li><a href="'.get_permalink($postid).'" class="am-text-truncate">'.$title.'</a></li>';
			}
		}
	}
	echo $output;
}
/*-----------------------------------------------------------------------------------*/
#评论列表
/*-----------------------------------------------------------------------------------*/
function list_comment($comment, $args, $depth) {
		$GLOBALS['comment'] = $comment;
		extract($args, EXTR_SKIP);

		if ( 'div' == $args['style'] ) {
			$tag = 'div';
			$add_below = 'comment';
		} else {
			$tag = 'li';
			$add_below = 'div-comment';
		}
?>
		<<?php echo $tag ?> <?php comment_class(empty( $args['has_children'] ) ? '' : 'parent') ?> id="comment-<?php comment_ID() ?>">
		<?php if ( 'div' != $args['style'] ) : ?>
		<div id="div-comment-<?php comment_ID() ?>" class="comment-body">
		<?php endif; ?>
		<div class="comment-author vcard">
		<?php printf(__('<cite class="fn">%s</cite> <span class="says">says:</span>'), get_comment_author_link()) ?>
		</div>
<?php if ($comment->comment_approved == '0') : ?>
		<em class="comment-awaiting-moderation"><?php _e('Your comment is awaiting moderation.') ?></em>
		<br />
<?php endif; ?>

		<div class="comment-meta commentmetadata"><a href="<?php echo htmlspecialchars( get_comment_link( $comment->comment_ID ) ) ?>">
			<?php
				/* translators: 1: date, 2: time */
				printf( __('%1$s at %2$s'), get_comment_date(),  get_comment_time()) ?></a><?php edit_comment_link(__('(Edit)'),'  ','' );
			?>
		</div>


		<?php comment_text() ?>

		<?php if ( 'div' != $args['style'] ) : ?>
		</div>
		<?php endif; ?>
<?php
        }
//移除评论人名字的链接
function disable_comment_author_links( $author_link ){
	return strip_tags( $author_link );
}
add_filter( 'get_comment_author_link', 'disable_comment_author_links' );
remove_filter( 'comment_text', 'make_clickable',  9 );//移除评论内容里的链接
/*-----------------------------------------------------------------------------------*/
#简码
/*-----------------------------------------------------------------------------------*/
#禁止wordpress自动添加分段标签
remove_filter( 'the_content', 'wpautop' );
add_filter( 'the_content', 'wpautop' , 12);
#下载信息
add_shortcode('xiazai','box_download');
function box_download($atts, $content = null)
{
    global $_POST;
    extract( shortcode_atts( array(
        'title' => '',
        'wdyz' => '',
        'ctxzd' => '',
        'klyxzd' => '',
        'fmxzd' => '',
        'qjwmxzd' => '',
        'bdwplink' => '',
        'bdwpmm' => '',
        'yplink' => '',
        'ypmm' => '',
        'md5' => '',
        'sha1' => '',
), $atts ) );
    if ( $wdyz == '1' )
    {
		$wdyz = '<a class=" am-badge am-badge-secondary am-round">经验证无毒无后门</a>';
	} elseif ( $wdyz == '2' ) {
		$wdyz = '<a class=" am-badge am-badge-warning am-round">未经验证谨慎使用</a>';
	}
    if (empty($ctxzd)) {$ctxzdlk = null;}else{$ctxzdlk = '<a href="'.$ctxzd.'" target="_blank">城通下载点(推荐)</a> ';} 
    if (empty($klyxzd)) {$klyxzdlk = null;}else{$klyxzdlk = ' <a href="'.$klyxzd.'" target="_blank">可乐云下载点</a> ';}
    if (empty($fmxzd)) {$fmxzdlk = null;}else{$fmxzdlk = ' <a href="'.$fmxzd.'" target="_blank">飞猫下载点</a> ';}
    if (empty($qjwmxzd)) {$qjwmxzdlk = null;}else{$qjwmxzdlk = ' <a href="'.$qjwmxzd.'" target="_blank">千军万马下载点</a> ';}
 	$gsxz = $ctxzdlk.$klyxzdlk.$fmxzdlk.$qjwmxzdlk;
    if ( is_user_logged_in() && !is_feed() )
    {
        $vipxz = '<a data-am-modal="{target: \'#bdwp-alert\'}">百度网盘</a>  <a data-am-modal="{target: \'#yp-alert\'}">360云盘</a><div class="am-modal am-modal-alert" tabindex="-1" id="bdwp-alert">
  <div class="am-modal-dialog">
    <div class="am-modal-hd">百度网盘下载</div>
    <div class="am-modal-bd">
    <a href="'.$bdwplink.'" target="_blank">点击下载</a>
密码：'.$bdwpmm.'
    </div>
    <div class="am-modal-footer">
      <span class="am-modal-btn">关闭</span>
    </div>
  </div>
</div>
<div class="am-modal am-modal-alert" tabindex="-1" id="yp-alert">
  <div class="am-modal-dialog">
    <div class="am-modal-hd">360云盘下载</div>
    <div class="am-modal-bd">
    <a href="'.$yplink.'" target="_blank">点击下载</a>
提取码：'.$ypmm.'
    </div>
    <div class="am-modal-footer">
      <span class="am-modal-btn">关闭</span>
    </div>
  </div>
</div>';
    } else {
		$vipxz = '会员下载无广告，请先登陆。不是会员？点此成为会员！';
	}

  return '<div class="am-panel am-panel-default">
<div class="am-panel-hd"><strong style="padding-right: 5px;">'.$title.' 下载地址</strong>'.$wdyz.'</div>
<div class="am-panel-bd">'.$content.'</div>
<table class="am-table">
<thead><tr><td>高速下载</td><td>'.$gsxz.'</td></tr>
<tr class="am-active"><th>会员下载</th><th>'.$vipxz.'</th></tr></thead>
<tbody>
<tr><td>解压密码</td><td><code>www.1991217.com</code></td></tr>
<tr><td>MD5值</td><td>'.$md5.'</td></tr>
<tr><td>SHA1值</td><td>'.$sha1.'</td></tr>
</tbody></table>
<div class="am-panel-footer" style="background-color: #FFF;">下载前请仔细阅读<a href="http://www.1991217.com/bcinfo/" target="_blank">下载声明</a>。点此了解<a href="http://www.1991217.com/windwos-linux-macosx-android-ios-md5-sha1/" target="_blank">如何验证MD5、SHA1值</a>。</div>
</div>';
}

/*-----------------------------------------------------------------------------------*/
#调用文章第一张图片作为缩略图
/*-----------------------------------------------------------------------------------*/
function catch_that_image() {
      global $post, $posts;
      $first_img = '';
      ob_start();
      ob_end_clean();
      $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
      $first_img = $matches [1] [0];
      if(empty($first_img)){ //Defines a default image
        $first_img = "/images/default.jpg";
      }
      return $first_img;
    }



?>