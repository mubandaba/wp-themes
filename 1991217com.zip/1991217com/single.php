<?php get_header(); ?>
<div class="am-cf blog-main">
  <!-- sidebar start -->
  <?php get_template_part( "sidebar" ) ?>
  <!-- sidebar end -->

  <!-- content start -->
  <div class="blog-content">
    <div class="am-cf am-padding">
      <div class="am-fl am-cf">
      <?php bread_nav();?> 
</div>
    </div>   
    <?php while (have_posts()) : the_post(); ?>
    <div class="am-g">
      <div class="am-u-sm-12 am-u-sm-centered">
        <h1><?php the_title(); ?></h1>
        <p><span class="am-icon-calendar-o">  <?php the_date_xml(); ?></span> &nbsp;&nbsp; <span class="am-icon-columns">  <?php the_category('、'); ?></span> &nbsp;&nbsp; <span class="am-icon-comment-o">  <a href="<?php comments_link(); ?>" title="查看 <?php the_title(); ?> 的评论"><?php comments_number('0', '1', '%'); ?></a></span><?php edit_post_link(' &nbsp;&nbsp; <span class="am-icon-edit">  编辑</span>'); ?>
</p>
        <hr/>
      </div>

      <div class="am-u-sm-12 am-u-sm-centered">
<?php if ((get_the_modified_time('Y')*365+get_the_modified_time('z')) > (get_the_time('Y')*365+get_the_time('z'))) : ?><div class="am-alert am-alert-danger am-text-center"><i class="am-icon-refresh"></i> 本文于 <?php the_modified_time('Y-n-j H:i'); ?> 编辑更新</div><?php endif; ?>
      <?php the_content(); ?>
      </div>
    </div>
<div class="am-u-sm-12 am-u-sm-centered">
    <?php comments_template('', true); ?>
</div>
  </div>
  <!-- content end -->
</div>
<?php endwhile;?>
<?php get_footer(); ?>