<footer>
  <hr>
  <ul class="am-nav am-nav-pills am-nav-justify">
  <li><a href="#">关于本站</a></li>
  <li><a href="http://www.1991217.com/bcinfo/">下载申明</a></li>
  <li><a href="http://www.1991217.com/archives/">文章归档</a></li>
  <li><a href="http://www.1991217.com/tags/">标签云集</a></li>
  <li><a href="http://www.1991217.com/gbook/">在线留言</a></li>
</ul>
  <p class="am-text-center">© 2012-2015 1991217.COM · 基于 <a href="http://www.1991217.com/tag/wordpress/" target="_blank" rel="nofollow" title="WordPress建站程序"><i class="am-icon-wordpress"></i></a> &amp; <a href="" title="1991217com主题">1991217com</a> · 由 <a href="http://www.1991217.com" target="_blank">KOK</a> 设计和维护</p>
</footer>

<!--[if lt IE 9]>
<script src="http://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
<script src="http://cdn.staticfile.org/modernizr/2.8.3/modernizr.js"></script>
<script src="<?php bloginfo('template_url'); ?>/js/amazeui.ie8polyfill.min.js"></script>
<![endif]-->

<!--[if (gte IE 9)|!(IE)]><!-->
<script src="<?php bloginfo('template_url'); ?>/js/jquery.min.js"></script>
<!--<![endif]-->
<script src="<?php bloginfo('template_url'); ?>/js/amazeui.min.js"></script>
<script src="<?php bloginfo('template_url'); ?>/js/app.js"></script>
</body>
<script type="text/javascript">
var $$ = function(func){  
            if (document.addEventListener) {  
                window.addEventListener("load", func, false);  
            }  
            else if (document.attachEvent) {  
                window.attachEvent("onload", func);  
            }  
        }  
          
        $$(function(){  
           $(function(){  
function $(id){
return document.getElementById(id)
}
function getHeight() {
if ($("blog-offcanvas").offsetHeight>=$("blog-right").offsetHeight){
$("blog-right").style.height=$("blog-offcanvas").offsetHeight + "px";
}
else{
$("blog-offcanvas").style.height=$("blog-right").offsetHeight + "px";
}
}
window.onload = function() {
getHeight();
}
}) 
        }) 
</script>
</html>