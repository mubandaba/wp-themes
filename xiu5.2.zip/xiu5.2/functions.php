<?php 
// include xiu theme functions file
include 'functions.xiu.php';


// custom functions