<?php get_header(); ?>

<div class="bodybox">
  <div class="main">
    <div class="common">
	  <div class="error">
	    <p>404 Not Found</p>
		<span>抱歉，找不到相关页面！</span>
	  </div>
    </div>
  </div>
  <div class="clear"></div>
<?php get_footer(); ?>