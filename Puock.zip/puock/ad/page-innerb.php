<?php if(pk_is_checked('ad_page_c_b_c')): ?>
    <div class="puock-text p-block t-md ad-page-content-bottom">
        <?php echo pk_get_option('ad_page_c_b','') ?>
    </div>
<?php endif; ?>