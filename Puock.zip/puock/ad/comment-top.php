<?php if(pk_is_checked('ad_comment_t_c')): ?>
<div class="puock-text p-block t-md ad-comment-top">
    <?php echo pk_get_option('ad_comment_t','') ?>
</div>
<?php endif; ?>