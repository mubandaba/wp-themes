<div class="p-block">
    <div class="t-lg puock-text text-center">暂未找到你想要的内容</div>
    <div class="mt20">
        <div>
            <div class="w-100">
                <div class="container">
                    <form action="<?php echo home_url() ?>">
                        <div class="row">
                            <div class="col-12">
                                <input type="text" name="s" id="s" class="form-control" placeholder="或许你可以尝试搜索一下">
                            </div>
                            <div class="mt20 col-12 text-center">
                                <button class="btn-dark btn btn-sm"><i class="czs-search-l mr-1"></i>开始搜索</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>