jQuery(document).ready(function($) {
	//Init all the Bootstrap Material Design JS features
	$('body').bootstrapMaterialDesign();
});