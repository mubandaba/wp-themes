<?php do_action( 'mp_before_end_wrapper_content' ); ?>
</div>
<?php do_action( 'mp_before_end_wrapper' ); ?>
</div>
<?php do_action( 'mp_before_end_wrapper_container' ); ?>
</div>
<?php do_action( 'mp_after_wrapper' ); ?>
</div>
<?php do_action( 'mp_after_wrapper_main' ); ?>
<?php wp_footer(); ?>
</body>
</html>