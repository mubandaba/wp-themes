<?php $ads_right_sidebar = get_theme_mod('right_sidebar_ad_code'); if($ads_right_sidebar) { ?>
<aside class="widget ads-widget">
<div class="textwidget"><?php echo stripcslashes(do_shortcode($ads_right_sidebar)); ?></div>
</aside>
<?php } ?>
<aside class="widget">
<h3 class="widget-title"><span><?php _e('Search','iomer'); ?></span></h3>
<?php get_search_form(); ?>
</aside>
<aside class="widget">
<h3 class="widget-title"><?php _e('Categories', 'iomer'); ?></h3>
<ul><?php wp_list_categories('orderby=name&show_count=1&title_li='); ?></ul>
</aside>
<aside class="widget widget_recent_entries">
<h3 class="widget-title"><span><?php _e('Popular Posts','iomer'); ?></span></h3>
<?php frkw_get_popular_posts(5); ?>
</aside>