<?php get_header(); ?>

<main id="container">

<div id="latest-posts">
<h4><span><?php _e('Latest Posts', 'iomer'); ?></span></h4>
<div class="headline-latest-posts"><?php _e('Catch the latest news and update here', 'iomer'); ?></div>
<div class="latest-post">
<?php
$postcount = 1;
$oddpost = '';
query_posts( array( 'posts_per_page' => 7, ) );

if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

<article <?php post_class('home-post'); ?> id="post-<?php the_ID(); ?>">

<?php
$thepostlink =  '<a href="'. get_permalink() . '" title="' . the_title_attribute('echo=0') . '">';
echo frkw_get_featured_image("<div class='wow bounceInLeft post-thumb'>".$thepostlink, "</a></div>", 300, 300, "alignnone", 'thumbnail', frkw_get_image_alt_text(),the_title_attribute('echo=0'), false);
?>

<div class="post-wrapper">
<header class="post-title">
<h2 class="entry-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
</header>
<div class="post-content">
<?php echo frkw_get_custom_the_excerpt(30); ?>
</div>
</div>

</article>

<?php ($oddpost == "alt-post") ? $oddpost="" : $oddpost="alt-post"; $postcount++;
endwhile; wp_reset_query();
endif;
?>

<div class="blog-view-more">
<a title="<?php _e('View All Posts', 'iomer'); ?>" href="<?php echo get_permalink( get_page_by_path('blog') ) ?>"><?php _e('View All Posts', 'iomer'); ?></a>
</div>

</div>
<?php get_sidebar(); ?>
</div>

<?php get_template_part('templates/home-feat-cat-bottom'); ?>

</main>

<?php get_footer(); ?>