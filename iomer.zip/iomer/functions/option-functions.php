<?php
/*--------------------------------------------
Description: add body font style
---------------------------------------------*/
function frkw_add_body_font_style() {
$bodyfont = get_theme_mod('body_font');
$bodyfontweight = get_theme_mod('body_font_weight');
if( $bodyfont == 'Choose a font' || $bodyfont == '') { ?>
body {font-family: 'Montserrat Light', arial;}
<?php } else { ?>
body {font-family:<?php echo $bodyfont; ?>;font-weight:<?php echo $bodyfontweight; ?>;}
<?php
}
}
add_action('frkw_custom_css','frkw_add_body_font_style');


/*--------------------------------------------
Description: add headline font style
---------------------------------------------*/
function frkw_add_headline_font_style() {
$headlinefont = get_theme_mod('headline_font');
$headlinefontweight = get_theme_mod('headline_font_weight');
if( $headlinefont == 'Choose a font' || $headlinefont == '') { ?>
h1,h2,h3,h4,h5,h6,#siteinfo div,.activity-header { font-family: 'Montserrat', arial; font-weight: 700; }
<?php } else { ?>
h1,h2,h3,h4,h5,h6,#siteinfo div,.activity-header { font-family: <?php echo $headlinefont; ?>; font-weight: <?php echo $headlinefontweight; ?>; }
<?php
}
}
add_action('frkw_custom_css','frkw_add_headline_font_style');

/*--------------------------------------------
Description: add navigation font style
---------------------------------------------*/
function frkw_add_navigation_font_style() {
$navfont = get_theme_mod('navigation_font');
$navfontweight = get_theme_mod('navigation_font_weight');
if( $navfont == 'Choose a font' || $navfont == '') { ?>
.sf-menu{ font-family: 'Montserrat', arial; font-weight: 700; }
<?php } else { ?>
.sf-menu {font-family: <?php echo $navfont; ?>; font-weight:<?php echo $navfontweight; ?>; }
<?php
}
}
add_action('frkw_custom_css','frkw_add_navigation_font_style');



/*----------------------------------------------------
Description: add theme header text style
----------------------------------------------------*/
function frkw_add_header_textcolor() {
$header_textcolor = get_theme_mod('header_textcolor');
if( $header_textcolor == 'blank') { ?>
#custom #siteinfo h1,#custom #siteinfo div, #custom #siteinfo p {display:none;}
<?php } else {
if( $header_textcolor ) { ?>
#custom #siteinfo a {color: #<?php echo $header_textcolor; ?> !important;text-decoration: none;}
#custom #siteinfo p#site-description {color: #<?php echo $header_textcolor; ?> !important;text-decoration: none;}
<?php
}
}
}
add_action('frkw_custom_css','frkw_add_header_textcolor');


/*----------------------------------------------------
Description: add main color css
----------------------------------------------------*/
function frkw_add_main_color() {
$main_color = get_theme_mod('main_color');
if( $main_color ) { ?>

#custom .sidebar aside h3.widget-title {background-color: <?php echo $main_color; ?>;}

#latest-posts h2.entry-title a,.content-area article h2.entry-title a,.sidebar a {color:<?php echo $main_color; ?>;}

.blog-view-more a {color:<?php echo $main_color; ?>;border: 1px solid <?php echo $main_color; ?>;}
.blog-view-more a:hover {color:<?php echo dehex($main_color,20); ?>;border: 1px solid <?php echo dehex($main_color,20); ?>;}

.content a,aside.widget #calendar_wrap a, #custom aside.widget .textwidget a {color: <?php echo $main_color; ?>;}

.post-paging .page-navigation span.page-current {color:#fff;background-color:<?php echo $main_color; ?>;border:1px solid <?php echo $main_color; ?>;}



aside.widget a:hover,.summary-post h2.post-title a {color: <?php echo $main_color; ?>;}


footer.footer-top {background-color: <?php echo dehex($main_color,-30); ?>;border-top: 10px solid <?php echo $main_color; ?>;}
footer aside.widget ul.featured-cat-posts li {border-bottom: 1px solid <?php echo dehex($main_color,-20); ?>; }

footer.footer-bottom,footer aside.widget caption {background-color: <?php echo $main_color; ?>;}
footer aside.widget th {
    border-bottom: 1px solid <?php echo dehex($main_color,-20); ?>;
}

<?php }
}
add_action('frkw_custom_css','frkw_add_main_color');


/*----------------------------------------------------
Description: add theme custom css
----------------------------------------------------*/
function frkw_add_theme_custom_css() {
$customcss = get_theme_mod('custom_css');
if( $customcss ) { echo $customcss; }
}
add_action('frkw_custom_css','frkw_add_theme_custom_css');


/*----------------------------------------------------
Description: let's finalize all it wp_head
----------------------------------------------------*/
function frkw_init_theme_custom_style() {
print '<style id="theme-custom-css" type="text/css" media="all">' . "\n";
do_action( 'frkw_custom_css' );
print '</style>' . "\n";
}
add_action('wp_head','frkw_init_theme_custom_style',99);

?>