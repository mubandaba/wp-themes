</div>
<footer id="footer">
	<aside id="footer_box">
		<div id="sponsor">
			<a href="http://reader.mx/?utm_source=prower&utm_medium=web&utm_campaign=banner" target="_blank"><img src="http://media.reeoo.com/readermx.jpg" width="250" height="100" alt="ReaderMX" title="ReaderMX"></a>
			<a href="http://faq.wopus.org" target="_blank"><img src="http://media.reeoo.com/faq_side.png" width="250" height="100" alt="WordPress问答" title="WordPress问答"></a>
			<a href="http://reeoo.com" target="_blank"><img src="http://media.reeoo.com/reeoo.jpg" width="250" height="100" alt="精美网页设计欣赏" title="精美网页设计欣赏"></a>
		</div>
		<div id="linkcat"><?php wp_list_bookmarks('categorize=0&title_li=0&before='); ?></div>
	</aside>
	<p>&copy; 2013 <?php bloginfo('name'); ?>. Powered by <a href="http://wordpress.org/" target="_blank">WordPress</a>. Theme by <a href="http://www.prower.cn/work/2569" target="_blank">Prower</a>.</p>
</footer>
<?php wp_footer(); ?>
</body>
</html>