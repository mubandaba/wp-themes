<?php get_header(); ?>
	<div id="nopage">当前页面不存在！</div>
<?php get_footer(); ?>