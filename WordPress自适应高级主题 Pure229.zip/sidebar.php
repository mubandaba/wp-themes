<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('全局侧栏小工具') ) : ?>
<?php endif; ?>