<!doctype html>
<html class="no-js">
<head>
	<meta charset="utf-8">
	<meta property="wb:webmaster" content="aa7c88303e74b8e2" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="description" content="<?php echo hoyt_inc('seo_de'); ?>">
	<meta name="keywords" content="<?php echo hoyt_inc('seo_kw'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<title>
	<?php
		if ( is_home() ) {
			bloginfo('name'); echo " | "; bloginfo('description');
			}elseif ( is_category() ) {
				single_cat_title(); echo " | "; bloginfo('name');
			}elseif (is_single() || is_page() ) {
				single_post_title();echo " - ";echo " | ";bloginfo('name');
			}elseif (is_search() ) {
				echo "搜索结果"; echo " | "; bloginfo('name');
			}elseif (is_404() ) {
				echo '页面未找到!';
			}else{wp_title('',true);
		}
	?>
	</title>
	<!-- 360内核浏览器访问 -->
	<meta name="renderer" content="webkit">
	<!-- 拒绝百度手机转码 -->
	<meta http-equiv="Cache-Control" content="no-siteapp"/>
	<!-- 加载CSS样式 -->
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_url'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/css/font-awesome.min.css">
	<?php if(is_single() || is_page()){ ?>
		<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/images/boxer/jquery.fs.boxer.css">
	<?php } ?>
	<?php wp_head(); ?>
</head>
<body class="<?php if(wp_is_mobile()){echo 'mobile';}else{echo 'pc';} if(is_ie8_page()){echo ' ie8';} ?>">
<div id="ie8_hide">
<p><i class="fa fa-frown-o"></i> 请及时升级您的浏览器,该站点不支持IE8或以下内核的浏览器访问.感谢您的支持</p>
</div>

<div class="bodywrap">
<div class="wraper wth">

<div id="main" class="wth-l pad-tb">
<div class="pad-lr">
	<div class="head">
		<div class="logo"><h1><a href="<?php bloginfo('url'); ?>">Pure Ⅱ</a></h1></div>
		<div id="nav" class="nav ahover">
		<button id="nav_btn"><i class="fa fa-bars"></i>
			<div id="min_nav">
				<ul>
					<?php wp_nav_menu( array('container' => false, 'items_wrap' => '%3$s', 'theme_location' => 'Menus','depth' => 1) ); ?>
				</ul>
			</div>
		</button>
		<ul>
			<?php wp_nav_menu( array('container' => false, 'items_wrap' => '%3$s', 'theme_location' => 'Menus','depth' => 1) ); ?>
		</ul>
		</div>
	</div>
</div>