<div class="postvideo pad-tblr">
	<div class="enmed">
		<div class="enmed-inner">
		<?php
		$video_url = get_post_meta($post->ID,'video',true);
		echo $video_url;
		?>	
		</div>
	</div>
</div>
<?php include('article.php'); ?>