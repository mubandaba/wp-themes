<?php if(post_thumbnail_src()!= 'no_img'){ ?>
<div class="postimg pad-tblr">
	<img width="960" height="540" src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>">
</div>
<?php } ?>
<?php include('article.php'); ?>