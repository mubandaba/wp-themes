<div class="mode-article pad-tlr">
	<div id="main_article" class="pad-lr">
		<div class="post-sidebar">
			<div class="zan <?php if(isset($_COOKIE['bigfa_ding_'.$post->ID])) echo ' likes';?>">
				<a data-action="ding" data-id="<?php echo $post->ID; ?>" class="favorite" href="javascript:;" ><i class="fa fa-thumbs-o-up"></i><span><?php $like = get_post_meta($post->ID,'bigfa_ding',true);if($like >0){echo $like;}else{echo '0';} ?></span></a>
			</div>
			<div class="postinfo info_style"><!--POSTINFO--></div><div class="posttag ahover2"><!--POSTTAGS--></div>
		</div>
		<div class="post">
			<div class="quote"><i class="fa fa-quote-left"></i></div>
			<div class="title"><h1><?php the_title(); ?></h1></div>
			<div class="mininfo info_style"><!--MIN_POSTINFO--></div>
			<div class="minposttag info_style ahover2"><!--MIN_POSTTAGS--></div>
		</div>
		<div class="info_post">
				<div class="ahover2"><a href="<?php $cat = get_the_category($post_id); echo get_category_link(get_cat_id($cat[0]->cat_name)); ?>"><?php $cat = get_the_category($post_id); echo $cat[0]->cat_name;?></a></div>
				<div class="date">发布于<?php echo timeago( get_gmt_from_date(get_the_time('Y-m-d G:i:s')) ) ?></div>
				<div class="like"><?php if(function_exists('the_views')) { the_views(); } ?> 次浏览</div>
				<div class="commend"><?php echo get_comments_number(); ?> 条评论</div>
		</div>
		<div class="info_tags"><?php the_tags('', '' , ''); ?></div>
	</div>
</div>