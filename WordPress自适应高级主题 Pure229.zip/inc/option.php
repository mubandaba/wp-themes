<?php
/* 版本重置 */
$var = '0.01';
if(get_option('hoyt_inc_ver') != $var){
	update_option('hoyt_inc_ver',$var);
/* 重置内容[reset] */
    $seo_reset = '<::>';
    $foot_reset = 'WordPress Theme designed by <a href="http://www.hoyt99.com">Hoyt99</a><::>Proudly published with <a href="https://wordpress.org">WordPress</a>';
    $feed_reset = '新浪微博<::>腾讯微博<::>微信<::>腾讯QQ<::>人人网<::>Facebook<::>Twitter<::>Dribbble';
    $mb_reset = '0<::>0<::>0<::>0<::>0';
    $img_reset = '4';
	$ie_reset = '0';
    update_option('hoyt_inc_seo', urlencode($seo_reset));
    update_option('hoyt_inc_foot', urlencode($foot_reset));
    update_option('hoyt_inc_feed', urlencode($feed_reset));
    update_option('hoyt_inc_mb', urlencode($mb_reset));
    update_option('hoyt_inc_img', $img_reset);
	update_option('hoyt_inc_ie', $ie_reset);

	echo "<script>alert('提示：主题数据库表格格式发生不可逆变化,已经清理所有的旧内容!');</script>";
}
/* 处理请求[post] */
if(isset($_POST['option_save'])){   
    //seo
    $seo_post = stripslashes($_POST['kw']).'<::>'.stripslashes($_POST['de']);
    update_option('hoyt_inc_seo', urlencode($seo_post));
    //foot
    $foot_post = stripslashes($_POST['ft1']).'<::>'.stripslashes($_POST['ft2']);
    update_option('hoyt_inc_foot', urlencode($foot_post));
    //feed
    $feed_post = stripslashes($_POST['f1']).'<::>'.stripslashes($_POST['f2']).'<::>'.stripslashes($_POST['f3']).'<::>'.stripslashes($_POST['f4']).'<::>'.stripslashes($_POST['f5']).'<::>'.stripslashes($_POST['f6']).'<::>'.stripslashes($_POST['f7']);
    update_option('hoyt_inc_feed', urlencode($feed_post));
    //mb
    if($_POST['m1'] == 'show'){
    	$mb_post .= '0<::>';
    }else{
    	$mb_post .= '1<::>';
    }
    if($_POST['m2'] == 'show'){
    	$mb_post .= '0<::>';
    }else{
    	$mb_post .= '1<::>';
    }
    if($_POST['m3'] == 'show'){
    	$mb_post .= '0<::>';
    }else{
    	$mb_post .= '1<::>';
    }
    if($_POST['m4'] == 'show'){
    	$mb_post .= '0<::>';
    }else{
    	$mb_post .= '1<::>';
    }
    if($_POST['m5'] == 'show'){
    	$mb_post .= '0';
    }else{
    	$mb_post .= '1';
    }
    update_option('hoyt_inc_mb', urlencode($mb_post));
    //img
    $img_post = $_POST['img'];
    update_option('hoyt_inc_img', $img_post);
    //ie
    if($_POST['ie'] == 'show'){
    	$ie_post .= '0';
    }else{
    	$ie_post .= '1';
    }   
    update_option('hoyt_inc_ie', urlencode($ie_post));
}   
?>
<?php
function inc_option(){
    add_menu_page( 'Pure 2主题设置', '主题设置', 'edit_themes', 'inc_setting','inc_page','',64);
}   

/* 分隔数据[arr] */
function inc_page(){
	$seo_arr = explode('<::>',urldecode(get_option('hoyt_inc_seo')));
	$foot_arr = explode('<::>',urldecode(get_option('hoyt_inc_foot')));
	$feed_arr = explode('<::>',urldecode(get_option('hoyt_inc_feed')));
	$mb_arr = explode('<::>',urldecode(get_option('hoyt_inc_mb')));
	$img_arr = get_option('hoyt_inc_img');
	$ie_arr = get_option('hoyt_inc_ie');
?>
	<style type="text/css">
		input{
			display: block;
			margin: 10px 0;
			max-width:800px;
			width: 99%;
		}
		label span{
			color: #999;
		}
		label{
			display: block;
			padding-bottom: 10px;
		}
	</style>
	<h1>欢迎您使用Pure 2主题</h1><span>该主题属于收费主题,正版用户有任何问题欢迎<a target="_blank" href="http://weibo.com/hoythan"/> @快叫我韩大人 </a>获取帮助</span><hr>

	<form method="post" name="page_form" id="page_form">   
		<h2>》站点SEO优化</h2>
		<p>
		<label>网站关键词(KeyWords)：<span>关键词请使用英文逗号分隔，并应不超过100个字符长度.</span><input name="kw" size="40" value='<?php echo $seo_arr[0]; ?>'/></label>
		<label>网站描述(Description)： <span>用一句话描述你的站点，最多不要超过200字符.</span><input name="de" size="40" value='<?php echo $seo_arr[1]; ?>'/></label>
		<hr>
		</p>
		<h2>》社交信息</h2>
		<p>
		<label>新浪微博：<span>请输入完整的微博地址.</span><input name="f1" size="40" value='<?php echo $feed_arr[0]; ?>'/></label>
		<label>腾讯微博： <span>同上.</span><input name="f2" size="40" value='<?php echo $feed_arr[1]; ?>'/></label>
		<label>腾讯微信： <span>请输入完整的微信二维码图片地址.</span><input name="f3" size="40" value='<?php echo $feed_arr[2]; ?>'/></label>
		<label>腾讯QQ： <span>请键入QQ账号.</span><input name="f4" size="40" value='<?php echo $feed_arr[3]; ?>'/></label>
		<label>人人网： <span>请输入完整的人人网地址.</span><input name="f5" size="40" value='<?php echo $feed_arr[4]; ?>'/></label>
		<label>Facebook： <span>请输入完整的Facebook地址.</span><input name="f6" size="40" value='<?php echo $feed_arr[5]; ?>'/></label>
		<label>Twitter： <span>请输入完整的Twitter地址.</span><input name="f7" size="40" value='<?php echo $feed_arr[6]; ?>'/></label>
		<label>Dribbble： <span>请输入完整的Dribbble地址.</span><input name="f8" size="40" value='<?php echo $feed_arr[7]; ?>'/></label>
		<hr>
		</p>
		<h2>》页脚版权信息设置(支持使用小图标)</h2>
		<p>
		<label>第一行内容：<input name="ft1" size="40" value='<?php echo $foot_arr[0]; ?>'/></label>
		<label>第二行内容： <input name="ft2" size="40" value='<?php echo $foot_arr[1]; ?>'/></label>
		<hr>
		</p>
		<h2>》小屏时显示小工具(取消勾选则隐藏)</h2>
		<p>
			<label><input name="m1" type="checkbox" size="40" value="show" <?php if($mb_arr[0] == '0'){echo 'checked';} ?>/> 社交工具</label>
			<label><input name="m2" type="checkbox" size="40" value="show" <?php if($mb_arr[1] == '0'){echo 'checked';} ?>/> 最新评论</label>
			<label><input name="m3" type="checkbox" size="40" value="show" <?php if($mb_arr[2] == '0'){echo 'checked';} ?>/> 热门文章</label>
			<label><input name="m4" type="checkbox" size="40" value="show" <?php if($mb_arr[3] == '0'){echo 'checked';} ?>/> 友情链接</label>
			<label><input name="m5" type="checkbox" size="40" value="show" <?php if($mb_arr[4] == '0'){echo 'checked';} ?>/> 最新图片</label>
		<hr>
		</p>
		<h2>》最新图片小工具>图片显示数量</h2>
		<p>
			<label>图片数量： <span>请输入纯数字,并建议为偶数.</span><input name="img" size="40" value='<?php echo $img_arr; ?>'/></label>
		<hr>
		</p>
		<h2>》是否开启IE8浏览器升级提示(勾选则开启)</h2>
		<p>
			<label><input name="ie" type="checkbox" size="40" value="show" <?php if($ie_arr[0] == '0'){echo 'checked';} ?>/> IE8提示</label>
		<hr>
		</p>
		<p class="submit">   
        	<input class="sub" type="submit" name="option_save" value="保存设置" />   
    	</p>    
	</form>
<?php }
	add_action('admin_menu', 'inc_option'); 
?>