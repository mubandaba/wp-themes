//Window ready
$(window).ready(function(){
	min_info();
	$('#sidebar .searchform input#s').attr({
		placeholder: '键入搜索内容'
	});
	$('#sidebar .widget_recent_entries ul li').attr({
		class: 'ahover2'
	});
});
$(window).resize(function(){
	min_info();
});
//ATRICLE.PHP POSTINFO
function min_info(){
	var wth = $(window).width(),
		hei = $(window).height();
	if($('#article_warp li').length > 0){
		$('#article_warp li .mode-article').each(function(){
			if(wth > 1280){
				$(this).find('.mininfo').html('');
				$(this).find('.postinfo').html($(this).find('.info_post').html());
				$(this).find('.minposttag').html('');
				$(this).find('.posttag').html($(this).find('.info_tags').html());
				$(this).find('.post-sidebar').css('margin-left','-48px');
			}else{
				$(this).find('.postinfo').html('');
				$(this).find('.mininfo').html($(this).find('.info_post').html());
				$(this).find('.posttag').html('');
				$(this).find('.minposttag').html($(this).find('.info_tags').html());
				$(this).find('.post-sidebar').css('margin-left','0');
			}
		});
	}

	if(wth > 1280){
		if($('#sidebar').height() > $('#main').height()){
			if($('#sidebar').height() > hei){
				$('#main').css('min-height',$('#sidebar').height()+48+48);
			}
		}else{
			if($('#main').height() < hei){
				$('#main').css('min-height',hei);
			}
		}
	}else{
		$('#main').css('min-height','0');
	}
}
//Likes
$.fn.postLike = function() {
	if ($(this).parent('.zan').hasClass('likes')) {
		alert('您已经赞过啦,来试试评论下把?');
		return false;
	} else {
		$(this).parent('.zan').addClass('likes');
		$(this).children('span').html(parseInt($(this).children('span').html())+1+'+');
		var id = $(this).data("id"),
		action = $(this).data('action'),
		rateHolder = $(this).children('.count');
		var ajax_data = {
			action: "bigfa_like",
			um_id: id,
			um_action: action
		};
		$.post(javascript_ajax.url, ajax_data,
		function(data) {
			$(rateHolder).html(data);
		});
		return false;
	}
};
$(document).on("click", ".favorite",function() {
	$(this).postLike();
});
//评论框
$(document).on('click', '#comment', function() {
	if($('.cmd_box').length > 0){
		$('.cmd_box').css('height','auto');
	}else{
		return false;
	}
});
//表情
$(document).on("click", ".add-smily",
function() {
        var myField;
        tag = ' ' + jQuery(this).data("smilies") + ' ';
        if (document.getElementById('comment') && document.getElementById('comment').type == 'textarea') {
            myField = document.getElementById('comment');
        } else {
            return false;
        }
        if (document.selection) {
            myField.focus();
            sel = document.selection.createRange();
            sel.text = tag;
            myField.focus();
        }
        else if (myField.selectionStart || myField.selectionStart == '0') {
            var startPos = myField.selectionStart;
            var endPos = myField.selectionEnd;
            var cursorPos = endPos;
            myField.value = myField.value.substring(0, startPos)
                          + tag
                          + myField.value.substring(endPos, myField.value.length);
            cursorPos += tag.length;
            myField.focus();
            myField.selectionStart = cursorPos;
            myField.selectionEnd = cursorPos;
        }
        else {
            myField.value += tag;
            myField.focus();
        }
    return false;
});
//菜单
$(document).on('click', '#nav_btn', function() {
	if($('#min_nav').css('display') == 'none'){
		$('#min_nav').css('display','block');
	}else{
		$('#min_nav').css('display','none');
	}
});
//weixin
$(document).on('click', '#weixin', function() {
	$('#wbox').css('display','block');
	$('#wbox .box_link').css('display','none');
	$('#wbox .box_qt').css('display','none');
	$('#wbox .box_wx').css('display','block');
});
//link
$(document).on('click', '#box_link', function() {
	$('#wbox').css('display','block');
	$('#wbox .box_wx').css('display','none');
	$('#wbox .box_qt').css('display','none');
	$('#wbox .box_link').css('display','block');
});
//qt
$(document).on('click', '#box_qt', function() {
	$('#wbox').css('display','block');
	$('#wbox .box_wx').css('display','none');
	$('#wbox .box_link').css('display','none');
	$('#wbox .box_qt').css('display','block');
});
//WBOX
$(document).on('click', '#wbox .clear', function() {
	var wth = $(window).width();
	$('#wbox').animate({right:wth},200,function(){
		$('#wbox').css({
			display: 'none',
			right: '0'
		});
	});
});
//boxer
$(function(){
	$('.mobile .boxer').boxer({
		mobile: true
	});
	$('.pc .boxer').boxer({
		labels: {
			close: "关闭",
			count: "/",
			next: "下一个",
			previous: "上一个"
		}
	});
});
//滚动条滚动
var currTop = 0,
    sTop = 0;
	sTop = $(document).height() - $(window).height();
$(window).scroll(function(){
    currTop = $(window).scrollTop();
    if(currTop < $(window).height()*0.2){
    	$('#stop').css('right','-45px');
    }else{
		$('#stop').css('right','0px');
	}

    if(currTop < sTop * 0.2){
    	$('#stop a').html('<i class="fa fa-bicycle"></i>');
    }else if(currTop < sTop * 0.4){
    	$('#stop a').html('<i class="fa fa-car"></i>');
    }else if(currTop < sTop * 0.6){
    	$('#stop a').html('<i class="fa fa-train"></i>');
    }else if(currTop < sTop * 0.8){
    	$('#stop a').html('<i class="fa fa-fighter-jet"></i>');
    }else{
    	$('#stop a').html('<i class="fa fa-rocket"></i>');
	}
});
//返回顶部按钮经过
$('#stop').hover(function(){
	$('#stop a').html('<i class="fa fa-chevron-up"></i>');
},function(){
    if(currTop < sTop * 0.2){
    	$('#stop a').html('<i class="fa fa-bicycle"></i>');
    }else if(currTop < sTop * 0.4){
    	$('#stop a').html('<i class="fa fa-car"></i>');
    }else if(currTop < sTop * 0.6){
    	$('#stop a').html('<i class="fa fa-train"></i>');
    }else if(currTop < sTop * 0.8){
    	$('#stop a').html('<i class="fa fa-fighter-jet"></i>');
    }else{
    	$('#stop a').html('<i class="fa fa-rocket"></i>');
    }
});
//返回顶部按钮点击
$(document).on('click','#stop',function(){
	$('html, body').animate({scrollTop:0},500);
});