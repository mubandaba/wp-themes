<?php get_header(); ?>
<div id="single" class="pad-tblr">
	<div class="nopage">
		<p>找不到你要的东西.</p>
		<p>试试使用搜索功能!</p>
	</div>
	
</div>
</div>
<div id="sidebar" class="wth-r pad-tblr">
<?php get_sidebar(); ?>
</div>

</div>
</div>
<?php get_footer(); ?>