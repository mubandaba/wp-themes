<div class="copy pad-b2">
	<div class="list ahover">
		<div><?php echo hoyt_inc('foot_ft1'); ?></div>
		<div><?php echo hoyt_inc('foot_ft2'); ?></div>
	</div>
</div>