<div class="link pad-b2  <?php if( hoyt_inc('m4') != '0'){ echo'mb_hide';}?>">
	<h3 class="ahover2">友情链接<span><a id="box_link" title="查看更多友情链接"><i class="fa fa-expand"></i></a></span></h3>
	<div class="list ahover2">
		<?php wp_list_bookmarks('title_li=&categorize=0&before=<li>'); ?>
	</div>
	<div class="clear"></div>
</div>