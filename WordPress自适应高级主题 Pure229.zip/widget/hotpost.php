<div class="newpost pad-b2  <?php if( hoyt_inc('m3') != '0'){ echo'mb_hide';}?>">
	<h3>热门文章</h3>
	<div class="list">
		<ul>
			<?php
			$arr = hotpost();
			for ($i=0; $i < count($arr)-1 ; $i++) { 
			    $siteurl = get_site_url();
			    $a = $i+1;
			    echo'<li><div class="postinfo ahover2"><h4><a href="'.get_the_permalink($arr[$i]).'">'.get_post($arr[$i])->post_title.'</a></h4><p>'.get_post($arr[$i])->comment_count.' 条评论<i class="fa fa-angle-right"></i>'.get_post_meta($arr[$i],'bigfa_ding',true).'个赞<i class="fa fa-angle-right"></i>'.get_post_meta($arr[$i],'views',true).'次阅读</p></div></li>';
			}
			?>
		</ul>
	</div>
</div>