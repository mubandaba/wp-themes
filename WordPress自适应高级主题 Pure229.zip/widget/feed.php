<div class="feed pad-b2 <?php if( hoyt_inc('m1') != '0'){ echo'mb_hide';}?>">
    <h3>社交工具</h3>
    <div class="list ahoverop">
        <?php $i = hoyt_inc('f1');if($i){echo '<a href="'.$i.'" target="_blank" class="fa fa-weibo" title="新浪微博"></a>';}?>
        <?php $i = hoyt_inc('f2');if($i){echo '<a href="'.$i.'" target="_blank" class="fa fa-tencent-weibo" title="腾讯微博"></a>';}?>
        <button id="weixin" class="fa fa-weixin"></button>
        <?php $i = hoyt_inc('f4');if($i){echo '<a href="http://wpa.qq.com/msgrd?v=3&uin='.$i.'&site=qq&menu=yes" target="_blank" class="fa fa-qq" title="腾讯QQ"></a>';}?>
        <?php $i = hoyt_inc('f5');if($i){echo '<a href="'.$i.'" target="_blank" class="fa fa-renren" title="人人网"></a>';}?>
        <?php $i = hoyt_inc('f6');if($i){echo '<a href="'.$i.'" target="_blank" class="fa fa-facebook" title="Facebook"></a>';}?>
        <?php $i = hoyt_inc('f7');if($i){echo '<a href="'.$i.'" target="_blank" class="fa fa-twitter" title="Twitter"></a>';}?>
        <?php $i = hoyt_inc('f8');if($i){echo '<a href="'.$i.'" target="_blank" class="fa fa-dribbble" title="Dribbble"></a>';}?>
    </div>
</div>