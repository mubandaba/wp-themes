<div class="commend pad-b2 <?php if( hoyt_inc('m2') != '0'){ echo'mb_hide';}?>">
	<h3>最新评论</h3>
	<div class="list">
		<?php get_recent_comments(); ?>
	</div>
</div>