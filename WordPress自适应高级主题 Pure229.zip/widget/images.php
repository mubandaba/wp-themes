<div class="images pad-b2  <?php if( hoyt_inc('m5') != '0'){ echo'mb_hide';}?>">
	<h3>最新图片</h3>
	<div class="list ahover2">
		<ul>
		<?php
			$num = hoyt_inc('img');
			$arr = new_imgmeta($num);
			for($i=0;$i<count($arr)-1;$i++){
					if(end(explode('.',$arr[$i])) != 'gif'){
						echo '<li><img src="'.get_bloginfo("template_url").'/timthumb.php?src='.$arr[$i].'&h=135&w=192&q=100&zc=1&ct=1" alt="#"></li>';
					}else{
						echo '<li><img src="'.$arr[$i].'" alt="#"></li>';
					}
			}
		?>
		</ul>
	</div>
	<div class="clear"></div>
</div>