<?php get_header(); ?>


<ul id="article_warp">
	<?php global $query_string; query_posts( $query_string . '&ignore_sticky_posts=1' ); ?>
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	<li><?php get_template_part( 'modules/article', get_post_format() ); ?> </li>
	<?php endwhile; endif; wp_reset_query();?> 
</ul>
<?php portfolio_paging_nav(); ?>

</div>
<div id="sidebar" class="wth-r pad-tblr">
<?php get_sidebar(); ?>
</div>

</div>
</div>
<?php get_footer(); ?>