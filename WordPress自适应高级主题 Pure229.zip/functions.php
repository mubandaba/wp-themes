<?php
//设置
include_once('inc/option.php');
require get_template_directory() . '/ajax-comment/do.php';
//本地化JAVASCRIPT
$jsurl = get_bloginfo('template_url').'/js/main.js';
wp_enqueue_script('hoyt99_theme_js', $jsurl);
wp_localize_script('hoyt99_theme_js', 'javascript_ajax', array(
    'url' => admin_url('admin-ajax.php', (is_ssl() ? 'https' : 'http'))
));

//文章阅读次数统计
include_once('inc/postviews.php');
//注册菜单   
if( function_exists('register_nav_menus') ){   
    register_nav_menus(   
        array(   
            'Menus' => __( '主导航菜单' ),
        )
    );   
}
//添加特色图像功能
add_theme_support('post-thumbnails');
//时间显示方式‘xx以前’
function time_ago( $type = 'commennt', $day = 7 ) {
  $d = $type == 'post' ? 'get_post_time' : 'get_comment_time';
  if (time() - $d('U') > 60*60*24*$day) return;
  echo ' (', human_time_diff($d('U'), strtotime(current_time('mysql', 0))), '前)';
}

function timeago( $ptime ) {
    $ptime = strtotime($ptime);
    $etime = time() - $ptime;
    if($etime < 1) return '不久前';
    $interval = array (
        12 * 30 * 24 * 60 * 60  =>  '年前 <span>('.date('Y-m-d', $ptime).')</span>',
        30 * 24 * 60 * 60       =>  '个月前 <span>('.date('m-d', $ptime).')</span>',
        7 * 24 * 60 * 60        =>  '周前 <span>('.date('m-d', $ptime).')</span>',
        24 * 60 * 60            =>  '天前',
        60 * 60                 =>  '小时前',
        60                      =>  '分钟前',
        1                       =>  '秒前'
    );
    foreach ($interval as $secs => $str) {
        $d = $etime / $secs;
        if ($d >= 1) {
            $r = round($d);
            return $r . $str;
        }
    };
}
//文章截断
add_action('admin_head', 'admin_lettering');
function strimwidth($str ,$start , $width ,$trimmarker ){
    $output = preg_replace('/^(?:[\x00-\x7F]|[\xC0-\xFF][\x80-\xBF]+){0,'.$start.'}((?:[\x00-\x7F]|[\xC0-\xFF][\x80-\xBF]+){0,'.$width.'}).*/s','\1',$str);
    return $output.$trimmarker;
}
//输出缩略图地址
function post_thumbnail_src(){
    global $post;
    if( $values = get_post_custom_values("thumb") ) {   //输出自定义域图片地址
        $values = get_post_custom_values("thumb");
        $post_thumbnail_src = $values [0];
    } elseif( has_post_thumbnail() ){    //如果有特色缩略图，则输出缩略图地址
        $thumbnail_src = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
        $post_thumbnail_src = $thumbnail_src [0];
    } else {
        if(get_pure_setting('postimg')){
            $post_thumbnail_src = '';
            ob_start();
            ob_end_clean();
            $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
            $post_thumbnail_src = $matches [1] [0];   //获取该图片 src
            if(empty($post_thumbnail_src)){ //如果日志中没有图片，则返回无图提示
                return 'no_img';
            }   
        }else{
            return 'no_img';
        }
    };
    return $post_thumbnail_src;
}
//友情链接
add_filter( 'pre_option_link_manager_enabled', '__return_true' );
function get_the_link_items($id = null){
    $bookmarks = get_bookmarks('orderby=date&category=' .$id );
    $output = '';
    if ( !empty($bookmarks) ) {
        $output .= '<ul class="link-items fontSmooth">';
        foreach ($bookmarks as $bookmark) {
            if(strpos($bookmark->link_url,'weibo.com')){
                $url = 'http://weibo.com/favicon.ico';
            }else{
                $url = $bookmark->link_url.'/favicon.ico';
                $url_ico = 'onerror="javascript:this.src=&apos;'.get_bloginfo('template_url').'/images/noico.ico&apos;"';
            }

            $output .=  '<li class="link-item"><a class="link-item-inner" href="' . $bookmark->link_url . '" title="' . $bookmark->link_description . '" target="_blank" ><img src="'. $url.'" '.$url_ico.' style="float: left;" width="16px" height="16px"><span class="sitename">'. $bookmark->link_name .'</span></a></li>';
        }
        $output .= '</ul>';
    }
    return $output;
}
function get_link_items(){
    $linkcats = get_terms( 'link_category' );
    if ( !empty($linkcats) ) {
        foreach( $linkcats as $linkcat){            
            $result .=  '<h3 class="link-title">'.$linkcat->name.'</h3>';
            if( $linkcat->description ) $result .= '<div class="link-description">' . $linkcat->description . '</div>';
            $result .=  get_the_link_items($linkcat->term_id);
        }
    } else {
        $result = get_the_link_items();
    }
    return $result;
}

function shortcode_link(){
    return get_link_items();
}
add_shortcode('bigfalink', 'shortcode_link');
//点赞
add_action('wp_ajax_nopriv_bigfa_like', 'bigfa_like');
add_action('wp_ajax_bigfa_like', 'bigfa_like');
function bigfa_like(){
    global $wpdb,$post;
    $id = $_POST["um_id"];
    $action = $_POST["um_action"];
    if ( $action == 'ding'){
    $bigfa_raters = get_post_meta($id,'bigfa_ding',true);
    $expire = time() + 99999999;
    $domain = ($_SERVER['HTTP_HOST'] != 'localhost') ? $_SERVER['HTTP_HOST'] : false; // make cookies work with localhost
    setcookie('bigfa_ding_'.$id,$id,$expire,'/',$domain,false);
    if (!$bigfa_raters || !is_numeric($bigfa_raters)) {
        update_post_meta($id, 'bigfa_ding', 1);
    } 
    else {
            update_post_meta($id, 'bigfa_ding', ($bigfa_raters + 1));
        }
    echo get_post_meta($id,'bigfa_ding',true);
    }
    die;
}
//判断浏览器版本等于或低于IE8
function is_ie8() {
    if(strpos($_SERVER['HTTP_USER_AGENT'],"MSIE 8.0") || strpos($_SERVER['HTTP_USER_AGENT'],"MSIE 7.0") || strpos($_SERVER['HTTP_USER_AGENT'],"MSIE 6.0")){
        return '<script type="text/javascript" src="'.get_bloginfo('template_url').'/js/ie8.js"></script><script type="text/javascript" src="'.get_bloginfo('template_url').'/js/jquery.corner.js"></script>';
    }
}
function is_ie8_page() {
    if(strpos($_SERVER['HTTP_USER_AGENT'],"MSIE 8.0") || strpos($_SERVER['HTTP_USER_AGENT'],"MSIE 7.0") || strpos($_SERVER['HTTP_USER_AGENT'],"MSIE 6.0")){
        return true;
    }
    return false;
} 
//分页
if (!function_exists('portfolio_paging_nav')) {
    /**
     * Display navigation to next/previous set of posts when applicable.
     *
     *
     * @return void
     */
    function portfolio_paging_nav() {
        global $wp_query, $paged;
        
        //display number of current page
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
    
        // Don't print empty markup if there's only one page.
        if ( $wp_query->max_num_pages < 2 )
            return;
        ?>
        <nav id="paging_nav" class="navigation paging-navigation pad-tlr" role="navigation">
                <span class="pagination-item">当前 <?php echo $paged ?> 页，共 <?php echo $wp_query->max_num_pages ?> 页</span> 
                <div class="nav-links ahover2">
                    <?php if (get_previous_posts_link()) : ?>
                        <div class="nav-next"><i class="fa fa-long-arrow-left amz"></i><?php $nav = previous_posts_link('前一页'); echo str_replace('<a','<a target="_self" ',$nav); ?></div>
                    <?php endif; ?>
                    <?php if (get_next_posts_link()) : ?>
                        <div class="nav-previous"><?php $nav =  get_next_posts_link('后一页'); echo str_replace('<a','<a target="_self" ',$nav); ?><i class="fa fa-long-arrow-right amz"></i></div>
                    <?php endif; ?>           
                </div><!-- .nav-links -->
            </nav><!-- .navigation -->
        <?php
    }
}
//小工具
if(function_exists('register_sidebar'))
{
    register_sidebar(array(
    'name' => '全局侧栏小工具',
    'before_widget' => '<div id="%1$s" class="pad-b2 widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h3>',
    'after_title' => '</h3>',
    ));
}
if( function_exists( 'register_sidebar_widget' )){   
    register_sidebar_widget('[Pure] 热门文章','widget_hotpost');
    register_sidebar_widget('[Pure] 最新评论','widget_commend'); 
    register_sidebar_widget('[Pure] 友情链接','widget_links');
    register_sidebar_widget('[Pure] 社交工具','widget_feed'); 
    register_sidebar_widget('[Pure] 页脚版权','widget_copy');
    register_sidebar_widget('[Pure] 最新图片','widget_newimg');
}  
function widget_hotpost(){include(TEMPLATEPATH . '/widget/hotpost.php');}
function widget_commend(){include(TEMPLATEPATH . '/widget/commend.php');}
function widget_links(){include(TEMPLATEPATH . '/widget/links.php');}
function widget_feed(){include(TEMPLATEPATH . '/widget/feed.php');}
function widget_copy(){include(TEMPLATEPATH . '/widget/copy.php');}
function widget_newimg(){include(TEMPLATEPATH . '/widget/images.php');}
//获取最新评论
function get_recent_comments(){
 // 不显示pingback的type=comment,不显示自己的,加user_id=0.(此两个参数可有可无)
    $comments=get_comments(array('number'=>10,'status'=>'approve','type'=>'comment'));
    $output = '';
 foreach($comments as $comment) {
 //去除评论内容中的标签
    $comment_content = strip_tags($comment->comment_content);
 //先获取头像
    $output .= '<li><div class="bar_avatar">'.get_avatar($comment, 72) .'</div> ';
 //获取作者
    $output .= '<div class="bar_info"><div class="b_name">'.$comment->comment_author .'</div><div class="b_comment ahover2"><a href="';
 //评论内容和链接
    $output .= get_permalink( $comment->comment_post_ID ) .'" title="查看 '.get_post( $comment->comment_post_ID )->post_title .'">';
 $output .= $comment_content .'..</a></div></div></li>';
}
 //输出
echo $output;
}
/*
    获取热门文章的排行榜
    权重,文章评论 3，文章点赞 2，文章浏览次数1
*/
function hotpost(){
global $wpdb;
$sql = $wpdb->get_results("SELECT ID,comment_count
FROM $wpdb->posts
WHERE   `post_type` LIKE  'post' AND `post_status` LIKE 'publish'
LIMIT 0 , 5
");
foreach($sql as $post){
    $num = $post->comment_count*3 + get_post_meta($post->ID,'bigfa_ding',true)*2 + get_post_meta($post->ID,'views',true)*1;
    $info .= $num.'.'.$post->ID.',';
}
    $arr = explode(',',$info);
    rsort($arr);
    for ($i=0; $i < count($arr); $i++) {
        $id = explode('.',$arr[$i]);
        $arr[$i] = $id[1];
    }
    return $arr;
}
//友情链接
add_filter( 'pre_option_link_manager_enabled', '__return_true' );
//评论
function aurelius_comment($comment, $args, $depth)    
{   
   $GLOBALS['comment'] = $comment; ?>   
<li class="comment pad-tb2" id="li-comment-<?php comment_ID(); ?>">   
    <div class="comment-info pad-b2">
        <div class="comment-avatar"><?php if (function_exists('get_avatar') && get_option('show_avatars')) { echo get_avatar($comment, 80); } ?></div>
        <div class="comment-meta">
            <div class="edit"><?php edit_comment_link('修改'); ?></div>
            <div class="reply"><?php comment_reply_link(array_merge( $args, array('reply_text' => '回复','depth' => $depth, 'max_depth' => $args['max_depth']))) ?></div>
            <div class="name ashow"><?php echo get_comment_author_link();?><?php echo get_user_level($comment->comment_author_email,$comment->user_id);?></div>
            <div class="time"><?php echo timeago(get_comment_time('Y-m-d G:i:s'));?></div>
        </div>         
    </div>
    <div class="comment-content"> 
        <div class="comment_text">   
            <?php if ($comment->comment_approved == '0') : ?>   
                <em>你的评论正在审核，稍后会显示出来！</em><br />   
            <?php endif; ?>   
            <?php comment_text(); ?>   
        </div> 
    </div>  
</li>   
<?php }
//评论排序
function reverse_comments($comments) {
    global $post;
    if($post->post_type == 'dwqa-question' || $post->post_type == 'dwqa-answer' ){
        //如果是 dwqa-question 或 dwqa-answer 这两个文章类型的评论就颠倒排序
        return array_reverse($comments);
    }else{
        //否则正常排序
        return $comments;
    }
}
add_filter ('comments_array', 'reverse_comments');
//表情
add_filter('smilies_src','fa_smilies_src',1,10);
function fa_smilies_src ($img_src, $img, $siteurl){
    $img = rtrim($img, "gif");
    return get_bloginfo('template_directory').'/images/smilies/'.$img.'png';
}
function fa_get_wpsmiliestrans(){
    global $wpsmiliestrans;
    $wpsmilies = array_unique($wpsmiliestrans);
    foreach($wpsmilies as $alt => $src_path){
        $output .= '<a class="add-smily" data-smilies="'.$alt.'"><img class="wp-smiley" src="'.get_bloginfo('template_directory').'/images/smilies/'.rtrim($src_path, "gif").'png" /></a>';
    }
    return $output;
}

add_action('media_buttons_context', 'fa_smilies_custom_button');
function fa_smilies_custom_button($context) {
    $context .= '<style>.smilies-wrap{background:#fff;border: 1px solid #ccc;box-shadow: 2px 2px 3px rgba(0, 0, 0, 0.24);padding: 10px;position: absolute;top: 60px;width: 400px;display:none}.smilies-wrap img{height:24px;width:24px;cursor:pointer;margin-bottom:5px} .is-active.smilies-wrap{display:block}</style><a id="insert-media-button" style="position:relative" class="button insert-smilies add_smilies" title="添加表情" data-editor="content" href="javascript:;">
<span class="dashicons dashicons-admin-users"></span>
添加表情
</a><div class="smilies-wrap">'. fa_get_wpsmiliestrans() .'</div><script>jQuery(document).ready(function(){jQuery(document).on("click", ".insert-smilies",function() { if(jQuery(".smilies-wrap").hasClass("is-active")){jQuery(".smilies-wrap").removeClass("is-active");}else{jQuery(".smilies-wrap").addClass("is-active");}});jQuery(document).on("click", ".add-smily",function() { send_to_editor(" " + jQuery(this).data("smilies") + " ");jQuery(".smilies-wrap").removeClass("is-active");return false;});});</script>';
    return $context;
}
//评论等级
function get_user_level($comment_author_email,$user_id){
    global $wpdb;
    $author_count = count($wpdb->get_results(
    "SELECT comment_ID as author_count FROM $wpdb->comments WHERE comment_author_email = '$comment_author_email' "));
    //$adminEmail = get_option('admin_email');if($comment_author_email ==$adminEmail) return;
    return '<div class="user_level">'.get_star_ico($author_count).'</div>';
}
function get_star_ico($num){
    if($num <= 0)return false;
    $level = '';
    $sun = floor($num / 25);
    $moon = floor(($num - $sun*25) / 5);
    $star = $num - $moon * 5 - $sun * 25;

    for ($i=0; $i < $sun; $i++) { 
        $level .= '<i class="fa fa-star"></i>'; 
    }
    for ($i=0; $i < $moon; $i++) { 
        $level .='<i class="fa fa-star-half-o"></i>';
    }
    for ($i=0; $i < $star; $i++) { 
        $level .='<i class="fa fa-star-o"></i>';
    }
    return $level;
}
//回复的评论加@
function comment_add_at( $comment_text, $comment = '') {
    if( $comment->comment_parent > 0) {
        $comment_text = '<a rel="nofollow" class="comment_at" href="#comment-' . $comment->comment_parent . '">@'.get_comment_author( $comment->comment_parent ) . '：</a> ' . $comment_text;
    }
        return $comment_text;
    }
add_filter( 'comment_text' , 'comment_add_at', 10, 2);
//头像缓存
function duoshuo_avatar($avatar) {
    $avatar = str_replace(array("www.gravatar.com","0.gravatar.com","1.gravatar.com","2.gravatar.com"),"gravatar.duoshuo.com",$avatar);
    return $avatar;
}
add_filter( 'get_avatar', 'duoshuo_avatar', 10, 3 );
//文章样式
add_theme_support( 'post-formats', array('image','quote','video') );
//设置函数
function hoyt_inc($i){
    if($i == 'seo_kw' || $i == 'seo_de'){
        $seo_arr = explode('<::>',urldecode(get_option('hoyt_inc_seo')));
        if($i == 'seo_kw'){
            return $seo_arr[0];
        }else{
            return $seo_arr[1];
        }
    }
    if($i == 'foot_ft1' || $i == 'foot_ft2'){
        $foot_arr = explode('<::>',urldecode(get_option('hoyt_inc_foot')));
        if($i == 'foot_ft1'){
            return $foot_arr[0];
        }else{
            return $foot_arr[1];
        }
    }
    if(ord($i) == 102){
        $feed_arr = explode('<::>',urldecode(get_option('hoyt_inc_feed')));
        $num = explode('f',$i);
        $a = $num[1]-1;
        return $feed_arr[$a];
    }
    if(ord($i) == 109){
        $mb_arr = explode('<::>',urldecode(get_option('hoyt_inc_mb')));
        $num = explode('m',$i);
        $a = $num[1]-1;
        return $mb_arr[$a];
    }
    if($i == 'img'){
        return get_option('hoyt_inc_img');
    }
    if($i == 'e'){
        return get_option('hoyt_inc_ie');
    }
    return false;
}
//最新图片
function new_imgmeta($i){
global $wpdb;
$sql = $wpdb->get_results("SELECT meta_id,meta_value
FROM $wpdb->postmeta
WHERE   `meta_key` LIKE  '_wp_attached_file'
ORDER BY  $wpdb->postmeta .`meta_id` DESC 
LIMIT 0 , $i
");
$upload_dir = wp_upload_dir();
foreach($sql as $post){
    //$post->meta_id.'<:>'.
    $num .= $upload_dir['baseurl'].'/'.$post->meta_value.'<::>';
}
    $arr = explode('<::>',$num);
    return $arr;
}
//wp图片添加alt属性
add_filter('the_content','image_alt');
function image_alt($c) {
    global $post;$title = $post->post_title;$s = array('/src="(.+?.(jpg|bmp|png|jepg|gif))"/i'=> 'src="$1" alt="'.$title.'"');
    foreach($s as$p => $r){$c = preg_replace($p,$r,$c);}return$c;
};
//文章样式高亮
function highlight($atts, $content='') {
extract( shortcode_atts( array(
        'color' => 'red'
    ), $atts ) );

return '<span class="highlight hl-'.$color.'">'.$content.'</span>';
}
add_shortcode("highlight", "highlight");
//文章样式图片添加属性
add_filter('the_content', 'boxer');
function boxer($content){
    global $post;
    $pattern = "/<p><a(.*?)href=('|\")([^>]*).(bmp|gif|jpeg|jpg|png)('|\")(.*?)>(.*?)<\/a><\/p>/i";
    $replacement = '<a$1href=$2$3.$4$5 rel="gallery" class="boxer"$6>$7</a>';
    $content = preg_replace($pattern, $replacement, $content); 
    return $content;
}
/*
下面属于各种优化，可以按照自己的喜好删除或修改
有疑问请联系微博@快叫我韩大人
*/
//屏蔽登录工具条
add_filter('show_admin_bar', '__return_false');
//屏蔽自动保存和日志修订
define('WP_POST_REVISIONS', false);
remove_action ( 'pre_post_update', 'wp_save_post_revision' );
// 自动保存设置为10个小时
define('AUTOSAVE_INTERVAL', 36000 );
//当搜索结果只有一篇时直接重定向到日志
add_action('template_redirect', 'redirect_single_post');
function redirect_single_post() {
    if (is_search()) {
        global $wp_query;
        if ($wp_query->post_count == 1) {
            wp_redirect( get_permalink( $wp_query->posts['0']->ID ) );
        }
    }
}
//去除谷歌字体
if (!function_exists('remove_wp_open_sans')) :
    function remove_wp_open_sans() {
        wp_deregister_style( 'open-sans' );
        wp_register_style( 'open-sans', false );
    }
     add_action('admin_enqueue_scripts', 'remove_wp_open_sans');
     add_action('login_init', 'remove_wp_open_sans');
endif;
// 更改后台字体
function admin_lettering(){
    echo'<style type="text/css">
        * { font-family: "Microsoft YaHei" !important; }
        i, .ab-icon, .mce-close, i.mce-i-aligncenter, i.mce-i-alignjustify, i.mce-i-alignleft, i.mce-i-alignright, i.mce-i-blockquote, i.mce-i-bold, i.mce-i-bullist, i.mce-i-charmap, i.mce-i-forecolor, i.mce-i-fullscreen, i.mce-i-help, i.mce-i-hr, i.mce-i-indent, i.mce-i-italic, i.mce-i-link, i.mce-i-ltr, i.mce-i-numlist, i.mce-i-outdent, i.mce-i-pastetext, i.mce-i-pasteword, i.mce-i-redo, i.mce-i-removeformat, i.mce-i-spellchecker, i.mce-i-strikethrough, i.mce-i-underline, i.mce-i-undo, i.mce-i-unlink, i.mce-i-wp-media-library, i.mce-i-wp_adv, i.mce-i-wp_fullscreen, i.mce-i-wp_help, i.mce-i-wp_more, i.mce-i-wp_page, .qt-fullscreen, .star-rating .star { font-family: dashicons !important; }
        .mce-ico { font-family: tinymce, Arial !important; }
        .fa { font-family: FontAwesome !important; }
        .genericon { font-family: "Genericons" !important; }
        .appearance_page_scte-theme-editor #wpbody *, .ace_editor * { font-family: Monaco, Menlo, "Ubuntu Mono", Consolas, source-code-pro, monospace !important; }
        </style>';
}
//删除一些没有必要的代码
remove_action( 'wp_head', 'wp_generator');                  //删除 head 中的 WP 版本号
remove_action( 'wp_head', 'rsd_link' );                     //删除 head 中的 RSD LINK
remove_action( 'wp_head', 'wlwmanifest_link' );             //删除 head 中的 Windows Live Writer 的适配器？ 
remove_action( 'wp_head', 'feed_links_extra', 3 );          //删除 head 中的 Feed 相关的link
remove_action( 'wp_head', 'index_rel_link' );               //删除 head 中首页，上级，开始，相连的日志链接
remove_action( 'wp_head', 'parent_post_rel_link', 10, 0 ); 
remove_action( 'wp_head', 'start_post_rel_link', 10, 0 ); 
remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0 );
remove_action( 'wp_head', 'wp_shortlink_wp_head', 10, 0 );  //删除 head 中的 shortlink
remove_action( 'template_redirect','wp_shortlink_header', 11, 0 );  //删除短链接通知，不知道这个是干啥的。
?>