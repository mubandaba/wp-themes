<div id="footer">
	<div id="stop"><a href="javascript:;"><i class="fa fa-chevron-up"></i></a></div>
	<div id="wbox">
	<button class="clear fa fa-angle-left"></button>
	<div class="box_wx">
		<h1>扫一扫关注我的微信</h1>
		 <?php $i = hoyt_inc('f3');if($i){
		 	echo '<img src="'.$i.'">';
		 }else{
		 	echo '<h1>暂未设置微信信息</h1>';
		 }?>
	</div>
	<div class="box_link pad-tblr">
		<h1>我的友情链接</h1>
		<div class="pad-lr">
			<?php echo get_link_items(); ?>
		</div>
	</div>
	<div class="box_qt">
		<h1>扫一扫手机访问本页</h1>
		<?php echo '<img alt="本文二维码" src="http://qr.liantu.com/api.php?text='.get_the_permalink().'">'; ?>

	</div>
</div>
</div>
	<!-- JavaSrcipt-->
	<script src="<?php bloginfo('template_url'); ?>/js/jquery.min.js"></script>
	<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.fs.boxer.min.js"></script>
	<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/main.js"></script>
 
	<?php echo is_ie8(); wp_footer(); ?>

</body>
</html>