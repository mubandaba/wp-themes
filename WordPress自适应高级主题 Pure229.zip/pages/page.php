<?php
/* Template Name: 普通页面 */
get_header(); ?>
<?php
	$video_url = get_post_meta($post->ID,'video',true);
	if($video_url != ''){
?>
<div class="postvideo pad-lr">
	<div class="enmed">
		<div class="enmed-inner">
		<?php
		$video_url = get_post_meta($post->ID,'video',true);
		echo $video_url;
		?>	
		</div>
	</div>
</div>
<?php } ?>
<div id="single" class="pad-tblr">
	<?php while (have_posts()) : the_post(); ?>
		<div class="title">
			<h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
		</div>
    <div class="post_meta ahover pad-b2">
		<span class="time">发布于：<?php echo timeago( get_gmt_from_date(get_the_time('Y-m-d G:i:s')) ) ?></span>
		<span class="cmd"><?php if ( comments_open() ) echo '<i class="fa fa-comments-o"></i> <a href="'.get_comments_link().'">'.get_comments_number('0', '1', '%').' 条评论</a>'; ?></span>
		<span class="like">
			<i class="fa fa-thumbs-o-up"></i>
			<div class="zan <?php if(isset($_COOKIE['bigfa_ding_'.$post->ID])) echo ' likes';?>">
				<a data-action="ding" data-id="<?php the_ID(); ?>" class="favorite" href="javascript:;" ><span><?php $like = get_post_meta($post->ID,'bigfa_ding',true);if($like >0){echo $like.' 人点赞';}else{echo '0';} ?></span></a>
			</div>
		</span>
		<span class="mb" id="box_qt"><a href="javascript:;"><i class="fa fa-mobile"></i>手机访问</a></span>
		<span class="edit"><?php edit_post_link('[编辑页面]'); ?></span>
    </div>
    <div class="post">
		<?php the_content(); ?>
	</div>
	<?php endwhile; ?>
	<div class="comments">
	  <?php comments_template(); ?>
	</div>
</div>
</div>
<div id="sidebar" class="wth-r pad-tblr">
<?php get_sidebar(); ?>
</div>

</div>
</div>
<?php get_footer(); ?>