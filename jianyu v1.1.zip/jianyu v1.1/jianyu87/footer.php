<!-- 底部开始 -->
<div class="footer clear">
	<div class="content">
    	<div class="copyright">
        All Rights Reservied.<?php echo comicpress_copyright(); ?> <?php bloginfo('name'); ?> <a href="javascript:scroll(0,0)" >返回顶部</a>
        </div>
		<?php _e('<div class="powerby">Design By <a target="_blank" href="http://www.jianyu87.com/">健宇</a> | Power By <a href="http://www.jianyu87.com/">wordpress 健宇工作室.</a></div> ', 'jianyu');?> 
        <?php $options = get_option('jianyu_options'); ?> 
<?php if($options['wztj'] && $options['wztj_content']) : ?> 
<div class="powerby"><?php echo($options['wztj_content']); ?></div>
<?php endif; ?>   
	</div>
</div>
<!-- 底部结束 -->
<?php wp_footer(); ?>
</body>
</html>