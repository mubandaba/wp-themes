<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */
?><?php get_header(); ?>
<!-- 中间内容开始 -->
<div class="clear content">
	<div class="left main">
    	<?php if(is_home()){include(TEMPLATEPATH. '/banner.php'); }?>
    	<div class="left new_info">
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
            <div <?php post_class() ?> id="post-<?php the_ID(); ?>">
        	<div class="new_info_list">
            	<dl>
                <?php if(is_sticky()) : ?>
                <dt>[置顶]<a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></dt>
                <?php else : ?>
                <dt><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></dt>
				<?php endif; ?>
                <dd>
                <?php if(is_category() || is_archive() || is_home() ) {
						the_excerpt();
						} else {
							the_content('Read the rest of this entry &raquo;'); 
					}?>
                </dd>
                <dd class="tags"><span class="right"><?php the_time(__('Y/m/d', 'kubrick')) ?>&nbsp; 评论:<?php comments_popup_link(__('0'), __('1条'), __('%条')); ?></span><?php the_category(',') ?>&nbsp;&nbsp;Tag：<?php the_tags(__(' '), ' '); ?></dd>
                </dl>
            </div>
            </div>
            <?php endwhile; else: ?>
			<div class="new_info_list">糟糕！您要找的东西可能已搬到别处了，重新搜索一下吧，或者点击<a title="Home" class="active" href="<?php echo get_option('home'); ?>/">这里</a>回首页看看吧</div>
			<?php endif; ?> 

            <!-- //new_info_list -->
           <?php jianyu_pagination($query_string); ?>
            <!-- //pager -->
        </div>
        <!-- //left new_info -->
    </div>
    <!-- //left main -->
	<!--include sidebar-->
	<?php get_sidebar(); ?>
</div>
<!-- 中间内容结束 -->
<?php get_footer(); ?>