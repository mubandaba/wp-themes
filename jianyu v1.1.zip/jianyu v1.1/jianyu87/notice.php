<?php $options = get_option('jianyu_options'); ?> 
<?php if($options['notice'] && $options['notice_content']) : ?> 
<span id="mood" class="left"><b>最新公告:</b><?php echo($options['notice_content']); ?></span>
<?php endif; ?>