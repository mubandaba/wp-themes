    <div class="right sidebar">
    	<?php $options = get_option('jianyu_options'); ?> 
		<?php if($options['gyzz'] && $options['gyzz_content']) : ?> 
        <h2><span class="color">关于</span>站长</h2>
        <div class="s">
        <?php echo($options['gyzz_content']); ?>
        </div>
        <?php endif; ?>
        <div class="clear"></div>
        <h2><span class="color">日志</span>分类</h2>
        <div class="s">
        	<ul>
			<?php wp_list_cats ('sort_column=name&optioncount=1&hierarchical=0&sort_order=desc'); ?>
            </ul>
        </div>
        <div class="clear"></div>
        <h2><span class="color">最新</span>发布</h2>
        <div class="s">
        <?php query_posts('showposts=10'); ?>
        	<ul>
              <?php while (have_posts()) : the_post(); ?>
		<?php if(is_sticky()) : ?>
        <li>[置顶]<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
        <?php else : ?>
        <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
        <?php endif; ?>
        <?php endwhile;?>
            </ul>
        </div>
        <div class="clear"></div>
         <h2><span class="color">最热</span>文章</h2>
        <div class="s">
        	<ul>
             <?php $result = $wpdb->get_results("SELECT comment_count,ID,post_title FROM $wpdb->posts ORDER BY comment_count DESC LIMIT 0 , 10");
foreach ($result as $post) {
setup_postdata($post);
$postid = $post->ID;
$title = $post->post_title;
$commentcount = $post->comment_count;
if ($commentcount != 0) { ?>
<li><a href="<?php echo get_permalink($postid); ?>" title="<?php echo $title ?>">
<?php echo $title ?></a> (<?php echo $commentcount ?>)</li>
<?php } } ?> 
            </ul>
        </div>
        <div class="clear"></div>
         <h2><span class="color">随机</span>文章</h2>
        <div class="s">
        	<ul>
              <?php
	global $post;
	$postid = $post->ID;
	$args = array( 'orderby' => 'rand', 'post__not_in' => array($post->ID), 'showposts' => 10);
	$query_posts = new WP_Query();
	$query_posts->query($args);
?>
<?php while ($query_posts->have_posts()) : $query_posts->the_post(); ?>
<li><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></li>
<?php endwhile; ?>
            </ul>
        </div>
        <div class="clear"></div>
         <h2><span class="color">标签云</span></h2>
        <div class="s">
        <?php wp_tag_cloud('unit=px&smallest=12&largest=20'); ?>
        </div>
        <div class="clear"></div>
        <h2><span class="color">友情</span>链接</h2>
        <div class="s">
        	<ul>
             <li><a href="http://www.jianyu87.com">韶关SEO</a></li>
              <?php wp_list_bookmarks('title_li=&categorize=0'); ?>
            </ul>
        </div>
        <div class="clear"></div>
    </div>
    <!-- //right sidebar -->