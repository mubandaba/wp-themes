<?php get_header(); ?>
<!-- 中间内容开始 -->
<div class="clear content">
	<div class="left main">
    	<div class="left new_info">
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
            <div <?php post_class() ?> id="post-<?php the_ID(); ?>">
        	<div class="new_info_list">
            	<dl>
                <dt><?php the_title(''); ?></dt>
                <dd>
                <?php the_content(); ?>
                </dd>
                </dl>
            </div>
            </div>
            <?php comments_template(); ?>
            <?php endwhile; else: ?>
			<div class="new_info_list">糟糕！您要找的东西可能已搬到别处了，重新搜索一下吧，或者点击<a title="Home" class="active" href="<?php echo get_option('home'); ?>/">这里</a>回首页看看吧</div>
			<?php endif; ?> 
            <!-- //new_info_list -->
        </div>
        <!-- //left new_info -->
    </div>
    <!-- //left main -->
	<!--include sidebar-->
	<?php get_sidebar(); ?>
</div>
<!-- 中间内容结束 -->
<?php get_footer(); ?>