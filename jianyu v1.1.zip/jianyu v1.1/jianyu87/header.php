<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo( 'charset' ); ?>" />
<title><?php wp_title('&laquo;', true, 'right'); ?> <?php bloginfo('name'); ?></title>
<meta name="Keywords" content="<?=$keywords?>" />
<meta name="Description" content="<?=$description?>" />
<meta name="copyright" content="design by 健宇,www.jianyu87.com" />
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<link rel="shortcut icon" href="<?php bloginfo('template_directory'); ?>/images/favicon.ico" />
<?php wp_get_archives('type=monthly&format=link'); ?>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/jquery.min.js"></script>
<?php if ( is_singular() ){ ?>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/comments-ajax.js"></script>
<?php } ?>
<?php wp_head(); ?>
</head>
<body>
<!-- 头部开始 -->
<div class="top_header">
	<div class="content">
    	<ul>
        	<?php wp_list_pages('title_li=&depth=1'); ?>
			<li><a href="<?php bloginfo('rss_url'); ?>" id="feed" target="_blank" rel="nofollow">RSS订阅</a></li>
        </ul>
    </div>
</div>
<!-- //top_header -->
<div class="header">
	<div class="content">
    	<a class="logo left" href="http://www.jianyu87.com" title="健宇工作室"></a>
        <div class="search_box right">
        	<span>
            	<div id="blog_sub"><?php bloginfo('description'); ?></div>
            </span>
            <div class="search right">
			<?php include(TEMPLATEPATH. '/searchform.php'); ?>
            </div>
            <!-- //search right -->
        </div>
        <!-- //search_box right -->
    </div>
    <!-- //content -->
    <div class="clear content menu">
    	<?php include_once TEMPLATEPATH . '/notice.php'; ?>
       <ul>
         <li class="log_first"><a href="<?php echo get_option('home'); ?>/">首 页</a></li>
         <?php wp_list_categories('sort_column=name&orderby=id&title_li=&depth=1&number=6'); ?>
       </ul>
    </div>
    <!-- //clear content menu -->
</div>
<!-- //header -->
<!-- 头部结束 -->