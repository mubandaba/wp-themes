            	<div class="search_01 left">
                    <form class="searchform" action="<?php bloginfo('home'); ?>/" name="searchform" method="post">
                      <div class="left"><input type="text" class="search_input" onfocus="if(this.value=='请输入关键词') this.value='';" onblur="if(this.value=='') this.value='请输入关键词';" value="请输入关键词" size="23" id="s" name="s"><input type="hidden" value="<?php echo wp_specialchars($s, 1); ?>" name="field"></div>
                      <div class="right"><input type="image" name="submit" src="<?php bloginfo('template_url'); ?>/images/btn_srch.gif"></div>
                    </form>
                </div>
                 <?php $options = get_option('jianyu_options'); ?> 
				<?php if($options['rmss'] && $options['rmss_content']) : ?> 
                <div class="hot_tags left">热门搜索：           
                <?php echo($options['rmss_content']); ?>
                </div>
                 <?php endif; ?>