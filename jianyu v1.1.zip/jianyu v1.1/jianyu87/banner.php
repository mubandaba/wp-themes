<div id="home_banner">
<div class="demo">
<div class="num"><a class="cur">1</a><a>2</a><a>3</a></div>
<ul>
<li style="display:block;"><a href="http://www.jianyu87.com/services" target="_blank"><img src="<?php bloginfo('template_directory'); ?>/images/banner01.jpg" alt="做网站" title="做网站" /></a></li><li><a href="http://www.jianyu87.com/contact"  target="_blank"><img src="<?php bloginfo('template_directory'); ?>/images/banner02.jpg" alt="韶关SEO" title="韶关SEO"/></a></li><li><a href="http://www.jianyu87.com/services"  target="_blank"><img src="<?php bloginfo('template_directory'); ?>/images/banner03.jpg"  alt="SEO推广优化" title="SEO推广优化" /></a></li>
</ul>
</div>
<script type="text/javascript">
$(function(){
var sw = 0;
$(".demo .num a").mouseover(function(){
sw = $(".num a").index(this);
myShow(sw);
});
function myShow(i){
$(".demo .num a").eq(i).addClass("cur").siblings("a").removeClass("cur");
$(".demo ul li").eq(i).stop(true,true).fadeIn(600).siblings("li").fadeOut(600);
}
//滑入停止动画，滑出开始动画
$(".demo").hover(function(){
if(myTime){
clearInterval(myTime);
}
},function(){
myTime = setInterval(function(){
myShow(sw)
sw++;
if(sw==3){sw=0;}
} , 3500);
});
//自动开始
var myTime = setInterval(function(){
myShow(sw)
sw++;
if(sw==3){sw=0;}
} , 3500);
})
</script>
</div>
