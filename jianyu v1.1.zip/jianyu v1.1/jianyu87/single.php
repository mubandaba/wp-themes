<?php get_header(); ?>
<!-- 中间内容开始 -->
<div class="clear content">
	<div class="left main">
    	<div class="left new_info">
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
            <div <?php post_class() ?> id="post-<?php the_ID(); ?>">
        	<div class="new_info_list">
            	<dl>
                <dt><?php the_title(''); ?></dt>
                <dd>
                                <div class="meta"><span class="tag">分类：<?php the_category(',') ?> ｜ 作者：<?php the_author() ?> ｜ 发表于<?php the_time(__('Y/m/d', 'kubrick')) ?></span><span class="time"> <?php comments_popup_link(__('没有评论 '), __('1条评论'), __('%条评论')); ?>&nbsp;<?php if(function_exists('the_views')) { the_views(); } ?><?php edit_post_link(__('Edit This')); ?></span></div>
<div class="meta1">
<!-- JiaThis Button BEGIN -->
<div id="ckepop">
	<a href="http://www.jiathis.com/share/?uid=96361" class="jiathis jiathis_txt jtico jtico_jiathis" target="_blank">分享到：</a>
	<a class="jiathis_button_qzone"></a> 
    <a class="jiathis_button_xiaoyou"></a> 
    <a class="jiathis_button_tsina"></a> 
    <a class="jiathis_button_kaixin001"></a> 
    <a class="jiathis_button_renren"></a> 
    <a class="jiathis_button_douban"></a> 
    <a class="jiathis_button_tqq"></a> 
    <a class="jiathis_button_baidu"></a> 
    <a class="jiathis_button_email"></a> 
    <a class="jiathis_button_fav"></a> 
    <a class="jiathis_button_copy"></a>
</div>
<script type="text/javascript">var jiathis_config = {"data_track_clickback":true};</script>
<script type="text/javascript" src="http://v2.jiathis.com/code/jia.js?uid=96361" charset="utf-8"></script>
<!-- JiaThis Button END -->
</div>
                <div><?php the_content(); ?></div>
                <div class="thetag" style="margin-bottom:10px;">Tag：<?php the_tags(__(' '), ' '); ?> </div>
<div>
<p>文章作者：<a href="<?php echo get_option('home'); ?>/"><?php the_author() ?></a><br />原创地址：<a href="<?php the_permalink() ?>"><?php the_permalink() ?></a><br />版权所有 &copy; 转载时必须以链接形式注明作者和原始出处！</p>
</div>
                </dd>
                </dl>
            </div>
            </div>
            <?php comments_template(); ?>
            <?php endwhile; else: ?>
			<div class="new_info_list">糟糕！您要找的东西可能已搬到别处了，重新搜索一下吧，或者点击<a title="Home" class="active" href="<?php echo get_option('home'); ?>/">这里</a>回首页看看吧</div>
			<?php endif; ?> 
            <!-- //new_info_list -->
        </div>
        <!-- //left new_info -->
    </div>
    <!-- //left main -->
	<!--include sidebar-->
	<?php get_sidebar(); ?>
</div>
<!-- 中间内容结束 -->
<?php get_footer(); ?>