<?php
if ( function_exists('register_sidebar') )
	register_sidebar(array(
		'name' => 'RightSidebar',
		'before_widget' => '<li id=”%1$s”>',
		'after_widget' => '</li>',
		'before_title' => '<h2>',
		'after_title' => '</h2>',
	));
if ( function_exists('register_sidebar') )
	register_sidebar(array(
		'name' => 'FooterSidebar',
		'before_widget' => '<li id=”%1$s”>',
		'after_widget' => '</li>',
		'before_title' => '<h2>',
		'after_title' => '</h2>',
	));
function archives_list_SHe() {
	global $wpdb,$month;
	$lastpost = $wpdb->get_var("SELECT ID FROM $wpdb->posts WHERE post_date <'" . current_time('mysql') . "' AND post_status='publish' AND post_type='post' AND post_password='' ORDER BY post_date DESC LIMIT 1");
	$output = get_option('SHe_archives_'.$lastpost);
	if(empty($output)){
		$output = '';
		$wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE 'SHe_archives_%'");
		$q = "SELECT DISTINCT YEAR(post_date) AS year, MONTH(post_date) AS month, count(ID) as posts FROM $wpdb->posts p WHERE post_date <'" . current_time('mysql') . "' AND post_status='publish' AND post_type='post' AND post_password='' GROUP BY YEAR(post_date), MONTH(post_date) ORDER BY post_date DESC";
		$monthresults = $wpdb->get_results($q);
		if ($monthresults) {
			foreach ($monthresults as $monthresult) {
			$thismonth    = zeroise($monthresult->month, 2);
			$thisyear    = $monthresult->year;
			$q = "SELECT ID, post_date, post_title, comment_count FROM $wpdb->posts p WHERE post_date LIKE '$thisyear-$thismonth-%' AND post_date AND post_status='publish' AND post_type='post' AND post_password='' ORDER BY post_date DESC";
			$postresults = $wpdb->get_results($q);
			if ($postresults) {
				$text = sprintf('%s %d', $month[zeroise($monthresult->month,2)], $monthresult->year);
				$postcount = count($postresults);
				$output .= '<dl><dt><strong>' . $text . '</strong> &nbsp;(' . count($postresults) . '&nbsp;' . __('篇文章','freephp') . ')</dt>' . "\n";
			foreach ($postresults as $postresult) {
				if ($postresult->post_date != '0000-00-00 00:00:00') {
				$url = get_permalink($postresult->ID);
				$arc_title    = $postresult->post_title;
				if ($arc_title)
					$text = wptexturize(strip_tags($arc_title));
				else
					$text = $postresult->ID;
					$title_text = __('View this post','freephp') . ', &quot;' . wp_specialchars($text, 1) . '&quot;';
					$output .= '<dd>' . mysql2date('m-d', $postresult->post_date) . ':&nbsp;' . "<a href='$url' title='$title_text'>$text</a>";
					$output .= '&nbsp;(' . $postresult->comment_count . ')';
					$output .= '</dd>' . "\n";
				}
				}
			}
			$output .= '</dl>' . "\n";
			}
        update_option('SHe_archives_'.$lastpost,$output);
		}else{
			$output = '<div class="errorbox">'. __('Sorry, no posts matched your criteria.','freephp') .'</div>' . "\n";
		}
	}
	echo $output;
}
function jianyu_pagination($query_string){
global $posts_per_page, $paged;
$my_query = new WP_Query($query_string ."&posts_per_page=-1");
$total_posts = $my_query->post_count;
if(empty($paged))$paged = 1;
$prev = $paged - 1;
$next = $paged + 1;
$range = 4; // only edit this if you want to show more page-links
$showitems = ($range * 2)+1;

$pages = ceil($total_posts/$posts_per_page);
if(1 != $pages){
echo "<div class='pager'>";
echo ($paged > 2 && $paged+$range+1 > $pages && $showitems < $pages)? "<a href='".get_pagenum_link(1)."'>最前</a>":"";
echo ($paged > 1 && $showitems < $pages)? "<a href='".get_pagenum_link($prev)."'>上一页</a>":"";

for ($i=1; $i <= $pages; $i++){
if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems )){
echo ($paged == $i)? "<span class='now-page'>".$i."</span>":"<a href='".get_pagenum_link($i)."' class='inactive' >".$i."</a>";
}
}

echo ($paged < $pages && $showitems < $pages) ? "<a href='".get_pagenum_link($next)."'>下一页</a>" :"";
echo ($paged < $pages-1 && $paged+$range-1 < $pages && $showitems < $pages) ? "<a href='".get_pagenum_link($pages)."'>最后</a>":"";
echo "</div>\n";
}
}
//公告 function 
class jianyuOptions { 
/* -- 获取选项组 -- */
function getOptions() {
// 在数据库中获取选项组
$options = get_option('jianyu_options');
// 如果数据库中不存在该选项组, 设定这些选项的默认值, 并将它们插入数据库
if (!is_array($options)) {
$options['notice'] = false;
$options['notice_content'] = '';
$options['gyzz'] = false;
$options['gyzz_content'] = '';
$options['rmss'] = false;
$options['rmss_content'] = '';
$options['wztj'] = false;
$options['wztj_content'] = '';
// TODO: 在这里追加其他选项
update_option('jianyu_options', $options);
}
// 返回选项组
return $options;
} 
/* -- 初始化 -- */
function init() {
// 如果是 POST 提交数据, 对数据进行限制, 并更新到数据库
if(isset($_POST['jianyu_save'])) {
// 获取选项组, 因为有可能只修改部分选项, 所以先整个拿下来再进行更改
$options = jianyuOptions::getOptions(); 
// 数据限制
if ($_POST['notice']) {
$options['notice'] = (bool)true;
} else {
$options['notice'] = (bool)false;
}
$options['notice_content'] = stripslashes($_POST['notice_content']);
if ($_POST['gyzz']) {
$options['gyzz'] = (bool)true;
} else {
$options['gyzz'] = (bool)false;
}
$options['gyzz_content'] = stripslashes($_POST['gyzz_content']); 
if ($_POST['rmss']) {
$options['rmss'] = (bool)true;
} else {
$options['rmss'] = (bool)false;
}
$options['rmss_content'] = stripslashes($_POST['rmss_content']);
if ($_POST['wztj']) {
$options['wztj'] = (bool)true;
} else {
$options['wztj'] = (bool)false;
}
$options['wztj_content'] = stripslashes($_POST['wztj_content']);
// TODO: 在这追加其他选项的限制处理 
// 更新数据
update_option('jianyu_options', $options); 
// 否则, 重新获取选项组, 也就是对数据进行初始化
} else {
jianyuOptions::getOptions();
} 
// 在后台 Design 页面追加一个标签页, 叫 公告管理
add_theme_page("主题管理", "主题管理", 'edit_themes', basename(__FILE__), array('jianyuOptions', 'display'));
} 
/* -- 标签页 -- */
function display() {
$options = jianyuOptions::getOptions();
?> 
<form action="#" method="post" enctype="multipart/form-data" name="classic_form" id="classic_form">
<div>
<h2><?php _e('公告管理', 'jianyu'); ?></h2> 
<!-- 公告栏 -->
<table>
<tbody>
<tr valign="top">
<th scope="row">
<?php _e('公告', 'jianyu'); ?>
<br/>
<small style="font-weight:normal;"><?php _e('添加代码', 'jianyu') ?></small>
</th>
<td>
<!-- 是否显示公告栏 -->
<label>
<input name="notice" type="checkbox" value="checkbox" <?php if($options['notice']) echo "checked='checked'"; ?> />
<?php _e('展示公告.', 'jianyu'); ?>
</label>
<br/>
<!-- 公告栏内容 -->
<label>
<textarea name="notice_content" cols="50" rows="10" id="notice_content" style="width:450px;font-size:12px;"><?php echo($options['notice_content']); ?></textarea>
</label>
</td>
</tr>
</tbody>
</table> 
<!-- TODO: 在这里追加其他选项内容 --> 
</div> 
<div>
<h2><?php _e('关于站长管理', 'jianyu'); ?></h2> 
<!-- 公告栏 -->
<table>
<tbody>
<tr valign="top">
<th scope="row">
<?php _e('关于站长', 'jianyu'); ?>
<br/>
<small style="font-weight:normal;"><?php _e('添加代码', 'jianyu') ?></small>
</th>
<td>
<!-- 是否显示公告栏 -->
<label>
<input name="gyzz" type="checkbox" value="checkbox" <?php if($options['gyzz']) echo "checked='checked'"; ?> />
<?php _e('展示站长信息', 'jianyu'); ?>
</label>
<br/>
<!-- 公告栏内容 -->
<label>
<textarea name="gyzz_content" cols="50" rows="10" id="gyzz_content" style="width:450px;font-size:12px;"><?php echo($options['gyzz_content']); ?></textarea>
</label>
</td>
</tr>
</tbody>
</table> 
<!-- TODO: 在这里追加其他选项内容 --> 
<!-- 提交按钮 -->
</div> 
<div>
<h2><?php _e('热门关键词', 'jianyu'); ?></h2> 
<!-- 公告栏 -->
<table>
<tbody>
<tr valign="top">
<th scope="row">
<?php _e('热门关键词', 'jianyu'); ?>
<br/>
<small style="font-weight:normal;"><?php _e('添加代码', 'jianyu') ?></small>
</th>
<td>
<!-- 是否显示公告栏 -->
<label>
<input name="rmss" type="checkbox" value="checkbox" <?php if($options['rmss']) echo "checked='checked'"; ?> />
<?php _e('展示热门关键词.', 'jianyu'); ?>
</label>
<br/>
<!-- 公告栏内容 -->
<label>
<textarea name="rmss_content" cols="50" rows="10" id="rmss_content" style="width:450px;font-size:12px;"><?php echo($options['rmss_content']); ?></textarea>
</label>
</td>
</tr>
</tbody>
</table> 
<!-- TODO: 在这里追加其他选项内容 --> 
</div> 
<div>
<h2><?php _e('网站统计代码', 'jianyu'); ?></h2> 
<!-- 公告栏 -->
<table>
<tbody>
<tr valign="top">
<th scope="row">
<?php _e('网站统计代码', 'jianyu'); ?>
<br/>
<small style="font-weight:normal;"><?php _e('添加网站统计代码', 'jianyu') ?></small>
</th>
<td>
<!-- 是否显示公告栏 -->
<label>
<input name="wztj" type="checkbox" value="checkbox" <?php if($options['wztj']) echo "checked='checked'"; ?> />
<?php _e('展示站长信息', 'jianyu'); ?>
</label>
<br/>
<!-- 公告栏内容 -->
<label>
<textarea name="wztj_content" cols="50" rows="10" id="wztj_content" style="width:450px;font-size:12px;"><?php echo($options['wztj_content']); ?></textarea>
</label>
</td>
</tr>
</tbody>
</table> 
<!-- TODO: 在这里追加其他选项内容 --> 
<p>
<input type="submit" name="jianyu_save" value="<?php _e('更新 &raquo;', 'jianyu'); ?>" />
</p><!-- 提交按钮 -->
</div> 
</form> 
<?php
}
} 
/**
 * 登记初始化方法
 */
add_action('admin_menu', array('jianyuOptions', 'init'));

//comments link redirect
add_filter('get_comment_author_link', 'add_redirect_comment_link', 5);
add_filter('comment_text', 'add_redirect_comment_link', 99);
function add_redirect_comment_link($text = ''){
$text=str_replace('href="', 'href="'.get_option('home').'/?g=', $text);
$text=str_replace("href='", "href='".get_option('home')."/?g=", $text);
return $text;
}
add_action('init', 'redirect_comment_link');
function redirect_comment_link(){
$redirect = $_GET['g'];
if($redirect){
if(strpos($_SERVER['HTTP_REFERER'],get_option('home')) !== false){
header("Location: $redirect");
exit;
}
else {
header("Location: http://www.jianyu87.com/");
exit;
}
}
}
//版权年份自动化
function comicpress_copyright() {
    global $wpdb;
    $copyright_dates = $wpdb->get_results("
		SELECT
        YEAR(min(post_date_gmt)) AS firstdate,
        YEAR(max(post_date_gmt)) AS lastdate
        FROM
        $wpdb->posts
        WHERE
        post_status = 'publish'");
    $output = '';
    if($copyright_dates) {
        $copyright = "© " . $copyright_dates[0]->firstdate;
        if($copyright_dates[0]->firstdate != $copyright_dates[0]->lastdate) {
            $copyright .= '-' . $copyright_dates[0]->lastdate;
        }
        $output = $copyright;
    }
    return $output;
}
//comment_mail_notify(所有的回复都会发邮件通知)
function comment_mail_notify($comment_id) {
$comment = get_comment($comment_id);
$parent_id = $comment->comment_parent ? $comment->comment_parent : '';
$spam_confirmed = $comment->comment_approved;
if (($parent_id != '') && ($spam_confirmed != 'spam')) {
$wp_email = 'no-reply@' . preg_replace('#^www\.#', '', strtolower($_SERVER['SERVER_NAME']));
//此处是发件人的邮箱地址,默认是自动以你的域名为后缀,比如我的是"@yuelongr.cn",也可自行修改为其他的.
$to = trim(get_comment($parent_id)->comment_author_email);
$subject = '您在['.get_option("blogname").']的留言有了回复';
//此处是邮件的标题,如果是godaddy主机,标题太长邮件可能发送失败,比如"您在[乐龙博客]的留言有了回复"可正常发送
//以下为邮件内容,也可自行修改为其他的.
$message = '
<div style="background-color:#eef2fa; border:1px solid #d8e3e8; color:#111; padding:0 15px; -moz-border-radius:5px; -webkit-border-radius:5px; -khtml-border-radius:5px;">
<p>'.trim(get_comment($parent_id)->comment_author).', 您好!</p>
<p>这是您在《'.get_the_title($comment->comment_post_ID).'》中的留言:<br />'
.trim(get_comment($parent_id)->comment_content).'</p>
<p>以下是 '.trim($comment->comment_author).' 给您的回复:<br />'
.trim($comment->comment_content).'<br /></p>
<p>您可以<a href="' . htmlspecialchars(get_comment_link($parent_id)) . '">点击这里查看回复的完整内容.</a></p>
<p>欢迎再度光临 <a href="' . get_option('home') . '">' . get_option('blogname') . '</a></p>
<p>(注:此邮件由系统自动发出,请勿回复!)</p>
</div>';
$from = "From: \"" . get_option('blogname') . "\" <$wp_email>";
$headers = "$from\nContent-Type: text/html; charset=" . get_option('blog_charset') . "\n";
wp_mail( $to, $subject, $message, $headers );
}
}//Modify by Yuelongr.cn
add_action('comment_post', 'comment_mail_notify');
//缩略图功能
add_theme_support( 'post-thumbnails' ); 
?>