<?php
    // Show plugin info instead of directory listing
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<title>WP No Category Base</title>
	</head>
	<body>
		<ul>
			<li><strong>WP No Category Base</strong> plugin</li>
			<li><a href="http://wordpresssupplies.com/wordpress-plugins/no-category-base/">Plugin Homepage  »</a></li>
			<li><a href="http://wordpress.org/extend/plugins/wp-no-category-base/">Download Plugin »</a></li>
			<li><a href="http://wordpresssupplies.com/">Author Homepage »</a></li>
			<li><a href="http://wordpresssupplies.com/">Donate to this plugin »</a></li>
		</ul>
	</body>
</html>
