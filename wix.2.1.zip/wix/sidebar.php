<article class="col-md-4 no-padding-left">
	<div class="wix-sidebar">
	<?php dynamic_sidebar('sidebar-1'); ?>
    </div>
</article>