<?php
// Require theme functions
require get_stylesheet_directory() . '/func/functions.php';
require get_stylesheet_directory() . '/func/functions-theme.php';
require get_stylesheet_directory() . '/func/functions-xzh.php';
require get_stylesheet_directory() . '/func/functions-video.php';

// Customize your functions

// 代码结束
?>