<?php
// File Security Check.
if ( ! defined( 'ABSPATH' ) ) exit;
// WP App Store installer removed as of WooFramework V5.5.0.
?>