<?php
/**
 * Template part for displaying list of comics
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Toocheke
 */

?>
  <?php
                     $allowed_tags = array(
                        'a' => array(
                              'title' => array(),
                              'href' => array()
                        ),
                        'i' => array(
                           'class' => array()
                        )
                     );
                     $random_url = home_url() . '/?random&amp;nocache=1&amp;post_type=comic';
              
                     ?>
<div class="single-comic-navigation">         
  
                  <?php echo wp_kses(toocheke_get_comic_link('ASC', 'backward', $collection_id), $allowed_tags); ?>
                  <?php echo wp_kses(toocheke_adjacent_comic_link( get_the_ID(), $collection_id, 'prev'), $allowed_tags); ?>
                  <a style="<?php echo  esc_attr($collection_id == 0 ? "" : "display:none") ?>" href="<?php echo esc_url($random_url); ?>" title="Random Comic"><i class="fas fa-lg fa-random"></i></a>
                  <?php echo wp_kses(toocheke_adjacent_comic_link( get_the_ID(), $collection_id, 'next'), $allowed_tags); ?>
                  <?php echo wp_kses(toocheke_get_comic_link('DESC', 'forward', $collection_id), $allowed_tags); ?>
</div>