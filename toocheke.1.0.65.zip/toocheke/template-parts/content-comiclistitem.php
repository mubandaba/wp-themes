<?php
/**
 * Template part for displaying list of comics
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Toocheke
 */

?>
<li id="post-<?php esc_attr(the_ID()); ?>" <?php wp_kses_data(post_class()); ?>>
                              <a href="<?php echo esc_url($latest_collection_id > 0 ? add_query_arg ('col', $latest_collection_id, get_permalink ($post)) : get_permalink($post) ); ?>">
                                 <div class="comic-item">
                                    <div class="thmb">
										<?php
if ( has_post_thumbnail() ) {
	the_post_thumbnail();
} 
										?>

</div>
                                    <div class="comic-info">
                                    <?php 
                                       $comic_number = $show_comic_number ? "#" . wp_kses_data(get_post_meta( $post->ID, 'incr_number', true )) . ". " : "";


                                    ?>
                                   <div class="comic-title-wrapper">
                                    <p class="comic-title"><?php echo wp_kses_data($comic_number) . wp_kses_data(get_the_title( )); ?></p>
</div>

                                    <p class="comic-post-date"><?php echo wp_kses_data(toocheke_get_day_name(get_the_time('U'))); ?></p>
</div>
                                 </div>
                              </a>
                           </li>
