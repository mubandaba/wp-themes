<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Toocheke
 */

get_header();
$comics_paged = isset( $_GET['comics_paged'] ) ? (int) $_GET['comics_paged'] : 1;
?>

<div class="row">
               <!--START LEFT COL-->
               <div class="col-lg-8">
                  <div id="left-col">
                     <div id="left-content">
		<?php if ( have_posts() ) : ?>

			<header class="page-header">
				<?php
				the_archive_title( '<h1 class="page-title">', '</h1>' );

				?>
			</header><!-- .page-header -->
            <ul id="comic-list">
			<?php

			/* Start the Loop */
			while ( have_posts() ) : the_post();

				/*
				 * Include the Post-Type-specific template for the content.
				 * If you want to override this in a child theme, then include a file
				 * called content-___.php (where ___ is the Post Type name) and that will be used instead.
				 */
				set_query_var( 'latest_collection_id', 0);
        		set_query_var( 'show_comic_number', true );
				get_template_part( 'template-parts/content', 'comiclistitem' );

            endwhile;
            ?>  
            </ul>
     

			 <!-- Start Pagination -->
			 <?php
     the_posts_navigation(
		array(
			'prev_text' => __('Older comics', 'toocheke'),
			'next_text' => __('Newer comics', 'toocheke'),
			'screen_reader_text' => __('Posts navigation', 'toocheke')
		)
	);
 
 
 
    ?>



<?php


		else :

			get_template_part( 'template-parts/content', 'none' );

		endif;
		?>

		                         <!--END CONTENT-->
								 </div><!--./ left-content-->
                  </div><!--./ left-col-->
               </div><!--./ col-lg-8-->
               <!--END LEFT COL-->           
              
<?php
get_sidebar();
get_footer();
