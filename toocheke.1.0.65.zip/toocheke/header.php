<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Toocheke
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'toocheke' ); ?></a>

	<header id="masthead" class="site-header">

	<nav id="site-navigation" role="navigation" class="navbar navbar-expand-md  navbar-light bg-white fixed-top" aria-label="<?php esc_attr_e( 'Primary Menu', 'toocheke'); ?>">
            <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#bs4Navbar" aria-controls="bs4Navbar" aria-expanded="false" aria-label="Toggle navigation">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
			</button>
			<?php if ( function_exists( 'the_custom_logo' ) ) : ?>
			<?php
			the_custom_logo();
			endif;
				?>

			<?php
			wp_nav_menu(array(
'theme_location' => 'primary',
'container' => 'div',
'container_id' => 'bs4Navbar',
'container_class' => 'collapse navbar-collapse',
'menu_id' => 'main-menu',
'menu_class' => 'nav navbar-nav',
'depth' => '2',
'fallback_cb'     => 'WP_Bootstrap_Navwalker::fallback',
	'walker'          => new WP_Bootstrap_Navwalker(),
			));
			?>
         </nav>

	
	</header><!-- #masthead -->


	<main role="main" class="site-main" id="main">
		 <!-- START JUMBOTRON -->
		 <?php
		 $headerUrl = has_header_image() ? get_header_image() : get_theme_support( 'custom-header', 'default-image' );
		 ?>
         <div id="page-header" class="jumbotron" style="background-image: url(<?php echo esc_url($headerUrl); ?>)">
		 <?php
		 if (display_header_text()==true) :
			?>
           
               <div id="comic-info" class="col-md-12">
			   <?php
			   if ( is_front_page() && is_home() ) :
				?>
				<h1 class="site-title" ><?php esc_html(bloginfo( 'name' )); ?></h1>
				<?php
			else :
				?>
				<p class="site-title"><?php esc_html(bloginfo( 'name' )); ?></p>
				<?php
			endif;
			$toocheke_description = get_bloginfo( 'description', 'display' );
			if ( $toocheke_description || is_customize_preview() ) :
				?>
				<p class="site-description">
				<?php echo wp_kses_data($toocheke_description);  ?>
				</p>
			<?php endif; ?>
              
               </div>
		
			<?php endif; ?>
         </div>
         <!-- END JUMBOTRON -->
         <!-- START MAIN CONTENT -->
         <div id="content" class="site-content">
		
