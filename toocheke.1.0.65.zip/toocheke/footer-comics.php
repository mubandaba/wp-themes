<?php
/**
 * The template for displaying the footer for comics
 *
 * Contains the closing of the main and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Toocheke
 */

?>
</main>
      <!--START FOOTER-->
      <div id="comic-nav-bottom">
      <div class="row">
               <div id="scroll-container" class="col-5 comic-navigation">
               <a href="#" title="Scroll Top" class="ScrollTop">
               <i class="fas fa-lg fa-angle-double-up"></i>
               </a>
            <span class="comic-total-comments">
               <i class="far fa-lg fa-comment-dots" aria-hidden="true"></i><?php   comments_number('0', '1', '%'); ?>
</span>

               </div>
               <div class="col-7">
               
                  <span class="comic-navigation">
                     <?php
                     $allowed_tags = array(
                        'a' => array(
                              'title' => array(),
                              'href' => array()
                        ),
                        'i' => array(
                           'class' => array()
                        )
                     );
                     $random_url = home_url() . '/?random&amp;nocache=1&amp;post_type=comic';
                     ?>

                  <a style="<?php echo  esc_attr($collection_id == 0 ? "" : "display:none") ?>" href="<?php echo esc_url($random_url); ?>" title="Random Comic"><i class="fas fa-lg fa-random"></i></a>
                  <?php echo wp_kses(toocheke_get_comic_link('ASC', 'backward', $collection_id), $allowed_tags); ?>
                  <?php echo wp_kses(toocheke_adjacent_comic_link( get_the_ID(), $collection_id, 'prev'), $allowed_tags); ?>
                  <?php echo  $collection_id == 0 ? wp_kses_data(toocheke_get_comic_number()) : esc_html("");  ?>
                  <?php echo wp_kses(toocheke_adjacent_comic_link( get_the_ID(), $collection_id, 'next'), $allowed_tags); ?>
                  <?php echo wp_kses(toocheke_get_comic_link('DESC', 'forward', $collection_id), $allowed_tags); ?>
				  </span>
               </div>
            </div>
        
      </div>


      <!--END FOOTER-->


<?php wp_footer(); ?>

</body>
</html>