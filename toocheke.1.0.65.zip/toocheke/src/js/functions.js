
var url = document.location.href;
var clipboard = new ClipboardJS('#copy-link', {
    text: function() {
      return url;
    }
  });

clipboard.on('success', function(e) {
    jQuery("#copy-tooltip").tooltip('show');
    setTimeout(function(){
        jQuery("#copy-tooltip").tooltip('hide');
    }, 3000);
});



jQuery(document).ready(function() {
//handle dropdown menu accessiblity
jQuery(".dropdown-menu .menu-item:last-child").on("focusout",function() {
  jQuery(this).parent(".dropdown-menu").toggle();
});
jQuery(".has-submenu").on("focus",function() {
  //jQuery('.dropdown.open .dropdown-toggle').dropdown('toggle');
  jQuery(this).next(".dropdown-menu").toggle();

});
  var currentIndex = jQuery('.current-comic' ).data( 'index' );
  /* Carousels */
  jQuery('#collections-carousel').owlCarousel({
    startPosition: currentIndex-1,
    loop: false,
    margin: 3,
    nav: false,
    responsiveClass: true,
    responsive: {
      0: {
        items: 2,
        nav: false
      },
      600: {
        items: 3,
        nav: false
      },
      1000: {
        items: 4,
        nav: false,
        loop: false,
        margin: 3
      }
    }
    
  });
  jQuery('#comics-carousel').owlCarousel({
    startPosition: currentIndex-1,
    loop: false,
    margin: 3,
    responsiveClass: true,
    responsive: {
      0: {
        items: 5,
        nav: false
      },
      600: {
        items: 10,
        nav: false
      },
      1000: {
        items: 20,
        nav: false,
        loop: false,
        margin: 3
      }
    }
  });
  //Hide scroll top
  jQuery(window).scroll(function(){
    if(jQuery(document).scrollTop() < 600){
      jQuery('#home-scroll-container').fadeOut();
    }
    else{
      jQuery('#home-scroll-container').fadeIn();
    }
  });

})