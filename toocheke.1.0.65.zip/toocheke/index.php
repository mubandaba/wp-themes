<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Toocheke
 */

get_header();
$blog_paged = isset($_GET['blog_paged']) ? (int) $_GET['blog_paged'] : 1;
$comics_paged = isset($_GET['comics_paged']) ? (int) $_GET['comics_paged'] : 1;
set_query_var( 'comics_paged', $comics_paged );
set_query_var( 'blog_paged', $blog_paged );
//get number of posts in collections
$collections_args = array(
    'post_type'     => 'comic', //post type, I used 'product'
    'post_status'   => 'publish', // just tried to find all published post
    'nopaging' => true,
    'tax_query' => array(
      array(
        'taxonomy' => 'collections',  
        'field' => 'id',
        'terms' => 'collections'
      )
    )
  );
  $collections_query = new WP_Query( $collections_args);
  $collections_post_count = (int)$collections_query->post_count;
  
?>
				 <?php
if ($collections_post_count > 0 ):
?>
<!--DISPLAY MULTIPLE COMIC COLLECTION-->
<?php
    get_template_part( 'template-parts/content', 'multiplecollections' );
?>
<!--./DISPLAY MULTIPLE COMIC COLLECTION-->
<?php
else:
?>
<!--DISPLAY SINGLE COMIC COLLECTION-->
<?php
    get_template_part( 'template-parts/content', 'singlecollection' );
?>
<!--./DISPLAY SINGLE COMIC COLLECTION-->
<?php
endif;
?>
				 <!-- START BLOG POSTS-->
				 <?php
if (have_posts()):
?>
<hr/>
<p id="blog-section">&nbsp;</p>
<h2  class="left-title"><?php esc_html_e('Latest Posts', 'toocheke');?></h2>
<?php
if (is_home() && !is_front_page()):
?>
				 <h3 class="page-title screen-reader-text"><?php single_post_title();?></h3>
				<?php
endif;
$blog_args = array(
    'paged' => $blog_paged,
    //'posts_per_page' => 5,
);
$blog_query = new WP_Query($blog_args);
/* Start the Loop */
while ($blog_query->have_posts()): $blog_query->the_post();

    /*
     * Include the Post-Type-specific template for the content.
     * If you want to override this in a child theme, then include a file
     * called content-___.php (where ___ is the Post Type name) and that will be used instead.
     */
    get_template_part('template-parts/content', get_post_type());

endwhile;

?>
			 <!-- Start Pagination -->
			 <?php
// Set up paginated links.
$blog_links = paginate_links(array(
    'format' => '?blog_paged=%#%#blog-section',
    'current' => $blog_paged,
    'total' => $blog_query->max_num_pages,
    'prev_text' => wp_kses(__('<i class=\'fas fa-chevron-left\'></i>', 'toocheke'), array('i' => array('class' => array()))),
    'next_text' => wp_kses(__('<i class=\'fas fa-chevron-right\'></i>', 'toocheke'), array('i' => array('class' => array()))),
    'add_args' => array('comics_paged' => $comics_paged),
));

if ($blog_links):

?>

<nav id="blog-pagination" class="pagination" aria-label="Posts navigation">

            <?php echo wp_kses($blog_links, array(
    'a' => array(
        'href' => array(),
        'class' => array(),
    ),
    'i' => array(
        'class' => array(),
    ),
    'span' => array(
        'class' => array(),
    ),
)); ?>

    </nav><!--/ .navigation -->
    <?php
endif;
?>
 <!-- End Pagination -->
			<?php
wp_reset_postdata();

else:

    get_template_part('template-parts/content', 'none');

endif;
?>
				 <!-- END BLOG POSTS-->
                        <!--END CONTENT-->
                     </div><!--./ left-content-->
                  </div><!--./ left-col-->
               </div><!--./ col-lg-8-->
               <!--END LEFT COL-->

<?php
get_sidebar();
get_footer();
