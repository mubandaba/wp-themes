<?php

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function toocheke_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Right Sidebar', 'toocheke' ),
		'id'            => 'right-sidebar',
		'description'   => esc_html__( 'Add widgets here.', 'toocheke' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
}
add_action( 'widgets_init', 'toocheke_widgets_init' );

/*
* About Widget
*/
if ( ! function_exists( 'toocheke_load_about_widget' ) ) :
	function toocheke_load_about_widget() {
		register_widget( 'toocheke_about_widget' );
	}
	endif;
	add_action( 'widgets_init', 'toocheke_load_about_widget' );
	
	if ( ! class_exists( 'toocheke_about_widget' ) ) :
	class toocheke_about_widget extends WP_Widget
	{
	
		public function __construct()
		{
			$widget_details = array(
				'classname' => 'toocheke_about_widget',
				'description' => esc_html__('Creates an about section consisting of a title, image/avatar, and a description. Ideal for the right sidebar on the Toocheke WP theme.', 'toocheke' )
			);
	
			parent::__construct( 'toocheke_about_widget', 'Toocheke: About Us', $widget_details );
	
			add_action('admin_enqueue_scripts', array($this, 'toocheke_about_us_widget_assets'));
		}
	
	
	public function toocheke_about_us_widget_assets()
	{
		wp_enqueue_script('media-upload');
		wp_enqueue_script('thickbox');
		wp_enqueue_script( 'toocheke-bootstrap', get_template_directory_uri() . '/dist/js/toocheke-media-upload.js', array('jquery'), '20190508', true );
		wp_enqueue_style('thickbox');
	}
	
	
		public function widget( $args, $instance )
		{
			$allowed_tags = array(
				'section' => array(
						'id' => array(),
						'class' => array()
				),
				'h4' => array(
					'class' => array()
				)
			);
			echo wp_kses($args['before_widget'], $allowed_tags);
			if ( ! empty( $instance['title'] ) ) {
				$title = ! empty( $instance['title'] ) ? $instance['title'] : '';
				$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );
				echo wp_kses($args['before_title'], $allowed_tags) . wp_kses($title, $allowed_tags). wp_kses($args['after_title'], $allowed_tags);
			}
	
			?>
			<img src='<?php echo esc_attr($instance['image']) ?>' class='about-avatar' >
			
				<?php echo wp_kses_data(wpautop( esc_html( $instance['description'] ) )) ?>
		
	
		
	
			<?php
	
			echo wp_kses($args['after_widget'], $allowed_tags);
		}
	
		public function update( $new_instance, $old_instance ) {  
			$instance = array();
			$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
			$instance['description'] = ( ! empty( $new_instance['description'] ) ) ? sanitize_textarea_field( $new_instance['description'] ) : '';
			$instance['image'] = ( ! empty( $new_instance['image'] ) ) ? sanitize_text_field( $new_instance['image'] ) : '';
			return $instance;
		}
	
		public function form( $instance )
		{
	
			$title = '';
			if( !empty( $instance['title'] ) ) {
				$title = $instance['title'];
			}
	
			$description = '';
			if( !empty( $instance['description'] ) ) {
				$description = $instance['description'];
			}
	
	
			$image = '';
			if(isset($instance['image']))
			{
				$image = $instance['image'];
			}
			?>
			<p>
				<label for="<?php echo esc_attr($this->get_field_name( 'title' )); ?>"><?php esc_html_e( 'Title:' , 'toocheke' ); ?></label>
				<input class="widefat" id="<?php echo esc_attr($this->get_field_id( 'title' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'title' )); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
			</p>
	
			<p>
				<label for="<?php echo esc_attr($this->get_field_name( 'description' )); ?>"><?php esc_html_e( 'Description:' , 'toocheke' ); ?></label>
				<textarea class="widefat" id="<?php echo esc_attr($this->get_field_id( 'description' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'description' )); ?>" type="text" ><?php echo esc_attr( $description ); ?></textarea>
			</p>
	
	
			<p>
				<label for="<?php echo esc_attr($this->get_field_name( 'image' )); ?>"><?php esc_html_e( 'Image:' , 'toocheke' ); ?></label>
				<input name="<?php echo esc_attr($this->get_field_name( 'image' )); ?>" id="<?php echo esc_attr($this->get_field_id( 'image' )); ?>" class="widefat" type="text" size="36"  value="<?php echo esc_url( $image ); ?>" />
				<input class="upload_image_button" type="button" value="Upload Image" />
			</p>
		<?php
		}
	}
	endif;
	//About Us Widget ends here
	
	/*
	* Social Media Widget
	*/
	
	
	
	if ( ! function_exists( 'toocheke_load_social_media' ) ) :
	function toocheke_load_social_media() {
		register_widget( 'toocheke_social_media' );
	}
	endif;
	add_action( 'widgets_init', 'toocheke_load_social_media' );
	
	if ( ! class_exists( 'toocheke_social_media' ) ) :
	class toocheke_social_media extends WP_Widget
	{
	
		public function __construct()
		{
			$widget_details = array(
				'classname' => 'toocheke_social_media social-links',
				'description' => esc_html__('Add links to your social media profiles. Ideally for the right sidebar on the Toocheke WP theme. ', 'toocheke' )
			);
	
			parent::__construct( 'toocheke_social_media', 'Toocheke: Social', $widget_details );
	
	
		}
	
	
		public function widget( $args, $instance )
		{
			$allowed_tags = array(
				'section' => array(
						'id' => array(),
						'class' => array()
				),
				'h4' => array(
					'class' => array()
				)
			);
			echo wp_kses($args['before_widget'], $allowed_tags);
			if ( ! empty( $instance['title'] ) ) {
				$title = ! empty( $instance['title'] ) ? $instance['title'] : '';
				$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );
				echo wp_kses($args['before_title'], $allowed_tags) . wp_kses($title, $allowed_tags). wp_kses($args['after_title'], $allowed_tags);
			}
			?>
			<ul>
			<?php if ( ! empty( $instance['patreon_url'] ) ) { ?>
		<li class="line"><a target="_blank" href='<?php echo esc_attr($instance['patreon_url']) ?>' title="Patreon"><span class="fab fa-md fa-patreon"></span></a></li>
			<?php } if ( ! empty( $instance['webtoon_url'] ) ) { ?>
		<li class="line"><a target="_blank" href='<?php echo esc_attr($instance['webtoon_url']) ?>' title="Line Webtoon"><span class="fab fa-md">
		<svg role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><title/><path d="M15.023 15.26c.695 0 1.014-.404 1.014-1.051 0-.551-.308-1.01-.984-1.01-.58 0-.912.404-.912 1.016 0 .543.32 1.045.882 1.045zM10.135 15.447c.764 0 1.113-.443 1.113-1.154 0-.604-.338-1.109-1.082-1.109-.637 0-1.002.445-1.002 1.115 0 .597.352 1.148.971 1.148zM24 10.201l-3.15.029.83-9.686L1.958 3.605l1.686 6.248H0l3.734 11.488 8.713-1.283v3.396l10.113-4.641L24 10.201zm-9.104-3.594c0-.049.039-.092.088-.094l1.879-.125.446-.029c.524-.035 1.634.063 1.634 1.236 0 .83-.619 1.184-.619 1.184s.75.189.707 1.092c0 1.602-1.943 1.389-1.943 1.389l-.225-.006-1.908-.053a.089.089 0 0 1-.086-.09l.027-4.504zm-3.675.243c0-.047.039-.09.088-.092l3.064-.203a.08.08 0 0 1 .087.08v.943c0 .049-.039.09-.087.092l-1.9.08a.094.094 0 0 0-.088.09l-.005.394a.083.083 0 0 0 .086.084l1.646-.066a.082.082 0 0 1 .086.084l-.02 1.012a.089.089 0 0 1-.089.086h-1.63a.089.089 0 0 0-.088.088v.416c0 .047.039.088.088.088l1.87.033a.09.09 0 0 1 .087.09v.951a.084.084 0 0 1-.087.084l-3.063-.123a.09.09 0 0 1-.087-.09l.042-4.121zm-6.01.312l.975-.064a.101.101 0 0 1 .105.08l.458 2.205c.01.047.027.047.039 0l.576-2.281a.132.132 0 0 1 .108-.09l.921-.061a.108.108 0 0 1 .109.078l.564 2.342c.012.047.029.047.041 0l.6-2.424a.131.131 0 0 1 .108-.092l.996-.064c.048-.004.077.031.065.078l-1.09 4.104a.113.113 0 0 1-.109.082l-1.121-.031a.12.12 0 0 1-.109-.086l-.535-1.965c-.012-.047-.033-.047-.045 0l-.522 1.934a.12.12 0 0 1-.11.082l-1.109-.031a.123.123 0 0 1-.108-.088l-.873-3.618c-.011-.047.019-.088.066-.09zm-.288 9.623v-3.561a.089.089 0 0 0-.087-.088l-1.252-.029a.095.095 0 0 1-.091-.09l-.046-1.125a.082.082 0 0 1 .083-.086l4.047.096c.048 0 .087.041.085.088l-.022 1.088a.093.093 0 0 1-.089.088l-1.139.004a.09.09 0 0 0-.087.088v3.447c0 .049-.039.09-.087.092l-1.227.07a.08.08 0 0 1-.088-.082zm2.834-2.379c0-1.918 1.321-2.482 2.416-2.482s2.339.73 2.339 2.316c0 1.9-1.383 2.482-2.416 2.482-1.033.001-2.339-.724-2.339-2.316zm5.139-.115c0-1.746 1.166-2.238 2.162-2.238s2.129.664 2.129 2.107c0 1.729-1.259 2.26-2.198 2.26s-2.093-.68-2.093-2.129zm7.259 1.711a.175.175 0 0 1-.139-.064l-1.187-1.631c-.029-.039-.053-.031-.053.018v1.67c0 .047-.039.09-.086.092l-1.052.061a.082.082 0 0 1-.087-.082l.039-3.842c0-.047.039-.086.088-.084l.881.02a.2.2 0 0 1 .137.074l1.293 1.902c.027.041.051.033.051-.014l.032-1.846a.087.087 0 0 1 .089-.086l.963.029c.047 0 .085.041.083.09l-.138 3.555a.097.097 0 0 1-.091.092l-.823.046zM16.258 8.23l.724-.014s.47.018.47-.434c0-.357-.411-.33-.411-.33l-.782.008a.09.09 0 0 0-.088.088v.598a.083.083 0 0 0 .087.084zM16.229 10.191h.99c.024 0 .35-.051.35-.404 0-.293-.229-.402-.441-.398l-.898.029a.089.089 0 0 0-.087.09v.596a.086.086 0 0 0 .086.087z"/></svg>
		</span></a></li>
		<?php } if ( ! empty( $instance['instagram_url'] ) ) { ?>
		<li class="line"><a target="_blank" href='<?php echo esc_attr($instance['instagram_url']) ?>' title="Instagram"><span class="fab fa-md fa-instagram"></span></a></li>
		<?php } if ( ! empty( $instance['twitter_url'] ) ) { ?>
		<li class="line"><a target="_blank" href='<?php echo esc_attr($instance['twitter_url']) ?>' title="Twitter"><span class="fab fa-md fa-twitter"></span></a></li>
		<?php } if ( ! empty( $instance['facebook_url'] ) ) { ?>
		<li class="line"><a target="_blank" href='<?php echo esc_attr($instance['facebook_url']) ?>' title="Facebook"><span class="fab fa-md fa-facebook-f"></span></a></li>
		<?php } if ( ! empty( $instance['reddit_url'] ) ) { ?>
		<li class="line"><a target="_blank" href='<?php echo esc_attr($instance['reddit_url']) ?>' title="Reddit"><span class="fab fa-md fa-reddit-alien"></span></a></li>
		<?php } if ( ! empty( $instance['linkedin_url'] ) ) { ?>
		<li class="line"><a target="_blank" href='<?php echo esc_attr($instance['linkedin_url']) ?>' title="LinkedIn"><span class="fab fa-md fa-linkedin-in"></span></a></li>
		<?php } if ( ! empty( $instance['tumblr_url'] ) ) { ?>
		<li class="line"><a target="_blank" href='<?php echo esc_attr($instance['tumblr_url']) ?>' title="Tumblr"><span class="fab fa-md fa-tumblr"></span></a></li>
		<?php } if ( ! empty( $instance['kofi_url'] ) ) { ?>
		<li class="line"><a target="_blank" href='<?php echo esc_attr($instance['kofi_url']) ?>' title="Ko-fi"><span class="fab fa-md">
		<svg role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><title>Ko-fi icon</title><path d="M23.881 8.948c-.773-4.085-4.859-4.593-4.859-4.593H.723c-.604 0-.679.798-.679.798s-.082 7.324-.022 11.822c.164 2.424 2.586 2.672 2.586 2.672s8.267-.023 11.966-.049c2.438-.426 2.683-2.566 2.658-3.734 4.352.24 7.422-2.831 6.649-6.916zm-11.062 3.511c-1.246 1.453-4.011 3.976-4.011 3.976s-.121.119-.31.023c-.076-.057-.108-.09-.108-.09-.443-.441-3.368-3.049-4.034-3.954-.709-.965-1.041-2.7-.091-3.71.951-1.01 3.005-1.086 4.363.407 0 0 1.565-1.782 3.468-.963 1.904.82 1.832 3.011.723 4.311zm6.173.478c-.928.116-1.682.028-1.682.028V7.284h1.77s1.971.551 1.971 2.638c0 1.913-.985 2.667-2.059 3.015z"></path></svg>
		</span></a></li>
		<?php } if ( ! empty( $instance['vimeo_url'] ) ) { ?>
		<li class="line"><a target="_blank" href='<?php echo esc_attr($instance['vimeo_url']) ?>' title="Vimeo"><span class="fab fa-md fa-vimeo-v"></span></a></li>
		<?php } if ( ! empty( $instance['youtube_url'] ) ) { ?>
		<li class="line"><a target="_blank" href='<?php echo esc_attr($instance['youtube_url']) ?>' title="Youtube"><span class="fab fa-md fa-youtube"></span></a></li>
		<?php } if ( ! empty( $instance['twitch_url'] ) ) { ?>
		<li class="line"><a target="_blank" href='<?php echo esc_attr($instance['twitch_url']) ?>' title="Twitch"><span class="fab fa-md fa-twitch"></span></a></li>
		<?php } if ( ! empty( $instance['rss_url'] ) ) { ?>
		<li class="line"><a target="_blank" href='<?php echo esc_attr($instance['rss_url']) ?>' title="RSS"><span class="fas fa-md fa-rss"></span></a></li>
	<?php } ?>
	</ul>
	
	
	
	
	
		
	
			<?php
	
			echo wp_kses($args['after_widget'], $allowed_tags);
		}
	
		public function update( $new_instance, $old_instance ) {  
			$instance = array();
			$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
			$instance['patreon_url'] = ( ! empty( $new_instance['patreon_url'] ) ) ? esc_url_raw( $new_instance['patreon_url'] ) : '';
			$instance['webtoon_url'] = ( ! empty( $new_instance['webtoon_url'] ) ) ? esc_url_raw( $new_instance['webtoon_url'] ) : '';
			$instance['instagram_url'] = ( ! empty( $new_instance['instagram_url'] ) ) ? esc_url_raw( $new_instance['instagram_url'] ) : '';
			$instance['twitter_url'] = ( ! empty( $new_instance['twitter_url'] ) ) ? esc_url_raw( $new_instance['twitter_url'] ) : '';
			$instance['facebook_url'] = ( ! empty( $new_instance['facebook_url'] ) ) ? esc_url_raw( $new_instance['facebook_url'] ) : '';
			$instance['reddit_url'] = ( ! empty( $new_instance['reddit_url'] ) ) ? esc_url_raw( $new_instance['reddit_url'] ) : '';
			$instance['linkedin_url'] = ( ! empty( $new_instance['linkedin_url'] ) ) ? esc_url_raw( $new_instance['linkedin_url'] ) : '';
			$instance['tumblr_url'] = ( ! empty( $new_instance['tumblr_url'] ) ) ? esc_url_raw( $new_instance['tumblr_url'] ) : '';
			$instance['kofi_url'] = ( ! empty( $new_instance['kofi_url'] ) ) ? esc_url_raw( $new_instance['kofi_url'] ) : '';
			$instance['vimeo_url'] = ( ! empty( $new_instance['vimeo_url'] ) ) ? esc_url_raw( $new_instance['vimeo_url'] ) : '';
			$instance['youtube_url'] = ( ! empty( $new_instance['youtube_url'] ) ) ? esc_url_raw( $new_instance['youtube_url'] ) : '';
			$instance['twitch_url'] = ( ! empty( $new_instance['twitch_url'] ) ) ? esc_url_raw( $new_instance['twitch_url'] ) : '';
			$instance['rss_url'] = ( ! empty( $new_instance['rss_url'] ) ) ? esc_url_raw( $new_instance['rss_url'] ) : '';
			return $instance;
		}
	
		public function form( $instance )
		{
	
			$title = '';
			if( !empty( $instance['title'] ) ) {
				$title = $instance['title'];
			}
	
			$patreon_url = '';
			if( !empty( $instance['patreon_url'] ) ) {
				$patreon_url = $instance['patreon_url'];
			}
			
			
	
	
			 $webtoon_url = '';
			if( !empty( $instance['webtoon_url'] ) ) {
				$webtoon_url = $instance['webtoon_url'];
			}
			
			 $instagram_url = '';
			if( !empty( $instance['instagram_url'] ) ) {
				$instagram_url = $instance['instagram_url'];
			}
			 $twitter_url = '';
			if( !empty( $instance['twitter_url'] ) ) {
				$twitter_url = $instance['twitter_url'];
			}
			 $facebook_url = '';
			if( !empty( $instance['facebook_url'] ) ) {
				$facebook_url = $instance['facebook_url'];
			}
			
			$reddit_url = '';
			if( !empty( $instance['reddit_url'] ) ) {
				$reddit_url = $instance['reddit_url'];
			}
			
			$linkedin_url = '';
			if( !empty( $instance['linkedin_url'] ) ) {
				$linkedin_url = $instance['linkedin_url'];
			}
			
			$tumblr_url = '';
			if( !empty( $instance['tumblr_url'] ) ) {
				$tumblr_url = $instance['tumblr_url'];
			}
			
			$kofi_url = '';
			if( !empty( $instance['kofi_url'] ) ) {
				$kofi_url = $instance['kofi_url'];
			}

			$vimeo_url = '';
			if( !empty( $instance['vimeo_url'] ) ) {
				$vimeo_url = $instance['vimeo_url'];
			}

			$youtube_url = '';
			if( !empty( $instance['youtube_url'] ) ) {
				$youtube_url = $instance['youtube_url'];
			}
			$twitch_url = '';
			if( !empty( $instance['twitch_url'] ) ) {
				$twitch_url = $instance['twitch_url'];
			}
			
			$rss_url = '';
			if( !empty( $instance['rss_url'] ) ) {
				$rss_url = $instance['rss_url'];
			}
			?>
			<p>
				<label for="<?php echo esc_attr($this->get_field_name( 'title' )); ?>"><?php esc_html_e( 'Title:' , 'toocheke' ); ?></label>
				<input class="widefat" placeholder="Social Widget Title" id="<?php echo esc_attr($this->get_field_id( 'title' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'title' )); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
			</p>
	
			<p>
				<label for="<?php echo esc_attr($this->get_field_name( 'patreon_url' )); ?>"><?php esc_html_e( 'Patreon URL:'  , 'toocheke'); ?></label>
				<input class="widefat" placeholder="https://www.example.com" id="<?php echo esc_attr($this->get_field_id( 'patreon_url' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'patreon_url' )); ?>" type="text" value="<?php echo esc_attr( $patreon_url ); ?>" />
			</p>
	
			 <p>
				<label for="<?php echo esc_attr($this->get_field_name( 'webtoon_url' )); ?>"><?php esc_html_e( 'LINE Webtoon URL:'  , 'toocheke'); ?></label>
				<input class="widefat" placeholder="https://www.example.com" id="<?php echo esc_attr($this->get_field_id( 'webtoon_url' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'webtoon_url' )); ?>" type="text" value="<?php echo esc_attr( $webtoon_url ); ?>" />
			</p>
			 <p>
				<label for="<?php echo esc_attr($this->get_field_name( 'instagram_url' )); ?>"><?php esc_html_e( 'Intagram URL:'  , 'toocheke'); ?></label>
				<input class="widefat" placeholder="https://www.example.com" id="<?php echo esc_attr($this->get_field_id( 'instagram_url' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'instagram_url' )); ?>" type="text" value="<?php echo esc_attr( $instagram_url ); ?>" />
			</p>
			 <p>
				<label for="<?php echo esc_attr($this->get_field_name( 'twitter_url' )); ?>"><?php esc_html_e( 'Twitter URL:'  , 'toocheke'); ?></label>
				<input class="widefat" placeholder="https://www.example.com" id="<?php echo esc_attr($this->get_field_id( 'twitter_url' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'twitter_url' )); ?>" type="text" value="<?php echo esc_attr( $twitter_url ); ?>" />
			</p>
			 <p>
				<label for="<?php echo esc_attr($this->get_field_name( 'facebook_url' )); ?>"><?php esc_html_e( 'Facebook URL:'  , 'toocheke'); ?></label>
				<input class="widefat" placeholder="https://www.example.com" id="<?php echo esc_attr($this->get_field_id( 'facebook_url' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'facebook_url' )); ?>" type="text" value="<?php echo esc_attr( $facebook_url ); ?>" />
			</p>
			 <p>
				<label for="<?php echo esc_attr($this->get_field_name( 'reddit_url' )); ?>"><?php esc_html_e( 'Reddit URL:'  , 'toocheke'); ?></label>
				<input class="widefat" placeholder="https://www.example.com" id="<?php echo esc_attr($this->get_field_id( 'reddit_url' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'reddit_url' )); ?>" type="text" value="<?php echo esc_attr( $reddit_url ); ?>" />
			</p>
			 <p>
				<label for="<?php echo esc_attr($this->get_field_name( 'linkedin_url' )); ?>"><?php esc_html_e( 'LinkedIn URL:'  , 'toocheke'); ?></label>
				<input class="widefat" placeholder="https://www.example.com" id="<?php echo esc_attr($this->get_field_id( 'linkedin_url' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'linkedin_url' )); ?>" type="text" value="<?php echo esc_attr( $linkedin_url ); ?>" />
			</p>
			 <p>
				<label for="<?php echo esc_attr($this->get_field_name( 'tumblr_url' )); ?>"><?php esc_html_e( 'Tumblr URL:'  , 'toocheke'); ?></label>
				<input class="widefat" placeholder="https://www.example.com" id="<?php echo esc_attr($this->get_field_id( 'tumblr_url' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'tumblr_url' )); ?>" type="text" value="<?php echo esc_attr( $tumblr_url ); ?>" />
			</p>
			<p>
				<label for="<?php echo esc_attr($this->get_field_name( 'kofi_url' )); ?>"><?php esc_html_e( 'Ko-fi URL:' , 'toocheke'); ?></label>
				<input class="widefat" placeholder="https://www.example.com" id="<?php echo esc_attr($this->get_field_id( 'kofi_url' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'kofi_url' )); ?>" type="text" value="<?php echo esc_attr( $kofi_url ); ?>" />
			</p>
			<p>
				<label for="<?php echo esc_attr($this->get_field_name( 'vimeo_url' )); ?>"><?php esc_html_e( 'Vimeo URL:' , 'toocheke'); ?></label>
				<input class="widefat" placeholder="https://www.example.com" id="<?php echo esc_attr($this->get_field_id( 'vimeo_url' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'vimeo_url' )); ?>" type="text" value="<?php echo esc_attr( $vimeo_url ); ?>" />
			</p>
			 <p>
				<label for="<?php echo esc_attr($this->get_field_name( 'youtube_url' )); ?>"><?php esc_html_e( 'Youtube URL:' , 'toocheke'); ?></label>
				<input class="widefat" placeholder="https://www.example.com" id="<?php echo esc_attr($this->get_field_id( 'youtube_url' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'youtube_url' )); ?>" type="text" value="<?php echo esc_attr( $youtube_url ); ?>" />
			</p>
			<p>
				<label for="<?php echo esc_attr($this->get_field_name( 'twitch_url' )); ?>"><?php esc_html_e( 'Twitch URL:' , 'toocheke'); ?></label>
				<input class="widefat" placeholder="https://www.example.com" id="<?php echo esc_attr($this->get_field_id( 'twitch_url' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'twitch_url' )); ?>" type="text" value="<?php echo esc_attr( $twitch_url ); ?>" />
			</p>
			<p>
				<label for="<?php echo esc_attr($this->get_field_name( 'rss_url' )); ?>"><?php esc_html_e( 'Comics RSS URL(e.g. https://www.yourdomain.com/comic/feed):' , 'toocheke'); ?></label>
				<input class="widefat" placeholder="<?php echo esc_url(site_url()) . "/comic/feed" ?>" id="<?php echo esc_attr($this->get_field_id( 'rss_url' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'rss_url' )); ?>" type="text" value="<?php echo esc_attr( $rss_url ); ?>" />
			</p>
			
	
	
	
		<?php
		}
	}
	endif;
	//Social Media Widget ends here
