<?php
/**
 * Toocheke functions and definitions
 *
 * Set up the theme and provides some helper functions, which are used in the
 * theme as custom template tags. Others are attached to action and filter
 * hooks in WordPress to change core functionality.
 *
 * When using a child theme you can override certain functions (those wrapped
 * in a function_exists() call) by defining them first in your child theme's
 * functions.php file. The child theme's functions.php file is included before
 * the parent theme's file, so the child theme functions would be used.
 *
 * @link https://codex.wordpress.org/Theme_Development
 * @link https://codex.wordpress.org/Child_Themes
 *
 * Functions that are not pluggable (not wrapped in function_exists()) are
 * instead attached to a filter or action hook.
 *
 * For more information on hooks, actions, and filters,
 * {@link https://codex.wordpress.org/Plugin_API}
 *
 * @package WordPress
 * @subpackage toocheke
 */

 //Load theme functions
//require_once trailingslashit( get_template_directory() ) . 'inc/template-functions.php';
/**
 * Note: Do not add any custom code here. Please use a child theme so that your customizations aren't lost during updates.
 * http://codex.wordpress.org/Child_Themes
 */

if ( ! function_exists( 'toocheke_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function toocheke_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on Toocheke, use a find and replace
		 * to change 'toocheke' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'toocheke', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'primary' => esc_html__( 'Primary', 'toocheke' ),
		) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'toocheke_custom_background_args', array(
			'default-color' => 'f5f5f5',
			'default-image' => '',
		) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 45,
			'width'       => 45,
			'flex-width'  => true,
			'flex-height' => false,
		) );
	}
endif;
add_action( 'after_setup_theme', 'toocheke_setup' );



/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
if ( ! function_exists( 'toocheke_content_width' ) ) :
function toocheke_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'toocheke_content_width', 1140 );
}
endif;
add_action( 'after_setup_theme', 'toocheke_content_width', 0 );




/**
 * Enqueue scripts and styles.
 */
if ( ! function_exists( 'toocheke_scripts' ) ) :
function toocheke_scripts() {
	wp_enqueue_style( 'bs-css', get_template_directory_uri() . '/dist/css/bootstrap.min.css' );
	wp_enqueue_style( 'bs-smartmenus', get_template_directory_uri() . '/dist/css/jquery.smartmenus.bootstrap-4.css' );

	wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/fonts/font-awesome/css/all.min.css' );

	wp_enqueue_style( 'owl-carousel', get_template_directory_uri() . '/dist/css/owl.carousel.min.css' );
	wp_enqueue_style( 'owl-theme-default', get_template_directory_uri() . '/dist/css/owl.theme.default.min.css' );

	wp_register_style('google-font-hind', '//fonts.googleapis.com/css?family=Hind:regular,medium,bold,bolditalic,semibold', array(), null, 'all');
	wp_enqueue_style('google-font-hind');
	
	wp_enqueue_style( 'toocheke-style', get_stylesheet_uri() );

	wp_enqueue_script( 'popper', get_template_directory_uri() . '/src/js/popper.min.js', array(), '20190817', true );

	wp_enqueue_script( 'owl-carousel', get_template_directory_uri() . '/src/js/owl.carousel.min.js', array(), '20190817', true );

	wp_enqueue_script( 'tether', get_template_directory_uri() . '/src/js/tether.min.js', array(), '20190817', true );

	wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/src/js/bootstrap.min.js', array('jquery'), '20190817', true );

	wp_enqueue_script( 'skip-link-focus-fix', get_template_directory_uri() . '/src/js/skip-link-focus-fix.js', array(), '20190817', true );

	wp_enqueue_script( 'jquery-smartmenus', get_template_directory_uri() . '/src/js/jquery.smartmenus.min.js', array(), '20190817', true );

	wp_enqueue_script( 'jquery-smartmenus-bs4', get_template_directory_uri() . '/src/js/jquery.smartmenus.bootstrap-4.min.js', array(), '20190817', true );

	wp_enqueue_script( 'clipboard', get_template_directory_uri() . '/src/js/clipboard.min.js', array(), '20190817', true );

	wp_enqueue_script( 'toocheke-functions', get_template_directory_uri() . '/src/js/functions.js', array(), '20190817', true );
	

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
endif;
add_action( 'wp_enqueue_scripts', 'toocheke_scripts' );
/*
* Register required plugins
*/
// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
require_once get_template_directory() . '/inc/class-tgm-plugin-activation.php';

add_action( 'tgmpa_register', 'toocheke_register_required_plugins' );
/*
* Register the required plugins for this theme.
*/
if ( ! function_exists( 'toocheke_register_required_plugins' ) ) :
function toocheke_register_required_plugins() {
	/*
	 * Array of plugin arrays. Required keys are name and slug.
	 * If the source is NOT from the .org repo, then source is also required.
	 */
	$plugins = array(

		// Include the Toocheke plugin bundled with a theme.
		array(
			'name'               => 'Toocheke Companion', 
			'slug'               => 'toocheke-companion', 
			//'source'             => 'https://downloads.wordpress.org/plugin/toocheke-companion.zip', // The plugin source.
			'required'           => false, // If false, the plugin is only 'recommended' instead of required.
			'version'            => '', // E.g. 1.0.0. If set, the active plugin must be this version or higher. If the plugin version is higher than the plugin version installed, the user will be notified to update the plugin.
			'external_url'       => '', // If set, overrides default API URL and points to an external URL.
			'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
		),	


	);

	/*
	 * Array of configuration settings. Amend each line as needed.
	 *
	 */
	$config = array(
		'id'           => 'toocheke',                 // Unique ID for hashing notices for multiple instances of TGMPA.
		'default_path' => '',                      // Default absolute path to bundled plugins.
		'menu'         => 'toocheke-install-plugins', // Menu slug.
		'has_notices'  => true,                    // Show admin notices or not.
		'dismissable'  => true,                    // If false, a user cannot dismiss the nag message.
		'dismiss_msg'  => false,                      // If 'dismissable' is false, this message will be output at top of nag.
		'is_automatic' => false,                   // Automatically activate plugins after installation or not.
		'message'      => '',                      // Message to output right before the plugins table.

		
		
	
	);

	tgmpa( $plugins, $config );
}
endif;







//Comic Carousel Starts here
/**
 * Comic Carousel
 */
if ( ! function_exists( 'toocheke_load_comic_carousel' ) ) :
function toocheke_load_comic_carousel($collection_id) {
	set_query_var( 'collection_id', $collection_id );
	get_template_part( 'template-parts/content', 'comiccarousel' );

}
endif;
//Comic Carousel Ends here

/* ========================================================================================================================
	
	Comments
	
	======================================================================================================================== */


/**
 * Post Publish Date.
 */
function toocheke_get_day_name($timestamp) {

    $date = date('M d, Y', $timestamp);

    if($date == date('M d, Y')) {
      $date = 'Today';
    } 
    else if($date == date('M d, Y',strtotime("-1 days"))) {
      $date = 'Yesterday';
    }
    return $date;
}
/**
 * Home Layout
 */

// Update CSS within in Admin
function toocheke_render_home_layout_styles() {
	wp_register_style( 'toocheke-home-custom-style', false );
	wp_enqueue_style( 'toocheke-home-custom-style' );
	$home_layout = get_theme_mod( 'home_layout_setting' , 'default');
	switch ($home_layout) {
		case 'default':
		return;
		case 'alt-1':
		$hide_object_selector = '#comic-archive-list, .jumbotron, #chapter-wrapper, #collection-wrapper, #blog-section';
		$show_object_selector = '#latest-comic';
			break;
		case 'alt-2':
			$hide_object_selector = '.jumbotron, #main-content-row, .post, #content .col-lg-4';
			$show_object_selector = '#latest-comic';
				break;
		case 'alt-3':
		$hide_object_selector = '#comic-archive-list, .jumbotron, #chapter-wrapper, #collection-wrapper, #blog-section';
		$show_object_selector = '#collections-owl-carousel-wrapper';
			break;		
		default:
		$hide_object_selector = '#latest-comic';
		$show_object_selector = '#comic-archive-list, .jumbotron, #chapter-wrapper, #collection-wrapper, #blog-section';
	}

		$home_custom_css = "
		@media (min-width: 992px){
			#content{
				margin-top: 60px !important;
			}
	}
	@media (max-width: 991px){
		main {
			margin-top: 0px;
		}
		#content{
			margin-top: 35px !important;
		}
}
		
		{$hide_object_selector} {
			display: none !important;
				}
				{$show_object_selector} {
					display: block !important;
						}
				";
				wp_add_inline_style( 'toocheke-home-custom-style', $home_custom_css );
}
add_action( 'wp_enqueue_scripts', 'toocheke_render_home_layout_styles' );
/**
 * Comic Layout
 */

// Update CSS within in Admin

function toocheke_render_comic_layout_styles() {
wp_register_style( 'toocheke-custom-style', false );
wp_enqueue_style( 'toocheke-custom-style' );
	$image_width = '100';
		$layout = get_theme_mod( 'comic_layout_setting' , 'default'); 
		if ( 'default' === $layout ) {
			return;
		}
		switch ($layout) {
			case 'two':
			$image_width = '49';
				break;
			case 'three':
			$image_width = '33.333333333';
				break;
			case 'four':
			$image_width = '25';
			break;
			default:
			$image_width = '100';
		}

		$custom_css = "
		@media (min-width: 990px){
			#comic p {
				font-size: 0;
			}
		#comic p img {
			max-width: {$image_width}% !important;
			width: {$image_width}% !important;
			height: auto !important;
                }}";
				wp_add_inline_style( 'toocheke-custom-style', $custom_css );
}
add_action( 'wp_enqueue_scripts', 'toocheke_render_comic_layout_styles' );
/**
 * Get Comic Link
 */
if ( ! function_exists( 'toocheke_get_comic_link' ) ) :
function toocheke_get_comic_link($order, $font, $collection_id){
    //global $post;
    $current_permalink = esc_url(get_permalink());
    $placeholder = $GLOBALS['post'];
    $args = array(
		'post_type' => 'comic',
        'numberposts'     => 1,
        'offset'          => 0,
        'orderby'         => 'post_date',
        'order'           =>  $order,
		'post_status'     => 'publish' );
		if( $collection_id > 0 )
		$args['tax_query'] =  array(
		  array (
			  'taxonomy' => 'collections',
			  'field' => 'term_id',
			  'terms' => $collection_id
		  )
		  );
    $sorted_posts = get_posts( $args );
    $permalink = esc_url(get_permalink($sorted_posts[0]->ID) );
    if ($permalink == $current_permalink)
		return;
	$permalink = esc_url($collection_id > 0 ? add_query_arg ('col', $collection_id, get_permalink($sorted_posts[0]->ID)) : get_permalink($sorted_posts[0]->ID) );
    $title = esc_attr($sorted_posts[0]->post_title);
	$post = $placeholder;
	$font = esc_attr($font);
    $latest_link_html = '<a href="'.$permalink.'" title="'.$title.'" ><i class="fas fa-lg fa-step-'.$font.'"></i></a>';
    return $latest_link_html;
}
endif;
if ( ! function_exists( 'toocheke_adjacent_comic_link' ) ) :
function toocheke_adjacent_comic_link( $current_post_id, $collection_id, $direction ) {

	// Info
	$postIDs = array();

	$args = array(
		'post_type' => 'comic',
        'nopaging' => true,
        'offset'          => 0,
        'orderby'         => 'post_date',
        'order'           =>  'ASC',
		'post_status'     => 'publish' );

		if( $collection_id > 0 )
		$args['tax_query'] =  array(
		  array (
			  'taxonomy' => 'collections',
			  'field' => 'term_id',
			  'terms' => $collection_id
		  )
		  );

		  $comic_posts = get_posts( $args );
	
	
	// Get post IDs
	foreach ( $comic_posts as $thepost):
	$postIDs[] = $thepost->ID;
	endforeach;
	
	// Get prev and next post ID
	$currentIndex = array_search( $current_post_id, $postIDs );
	if($currentIndex > 0 ){
		$prevID = $postIDs[ $currentIndex - 1 ];
		$prev_title = esc_attr($comic_posts[$currentIndex - 1]->post_title);
	}
	if($currentIndex < count($comic_posts) - 1){
		$nextID = $postIDs[ $currentIndex + 1 ];
		$next_title = esc_attr($comic_posts[$currentIndex + 1]->post_title);
	}
	
	
	// Return information
	if( $direction == 'next' AND !empty($nextID)):
		$permalink = esc_url($collection_id > 0 ? add_query_arg ('col', $collection_id, get_permalink( $nextID )) : get_permalink( $nextID ) );
		$link_html = '<a href="'.$permalink.'" title="'.$next_title.'" ><i class="fas fa-lg fa-chevron-right" aria-hidden="true"></i></a>';
	
	
	elseif( $direction == 'prev' AND !empty($prevID) ):
		$permalink = esc_url($collection_id > 0 ? add_query_arg ('col', $collection_id, get_permalink( $prevID )) : get_permalink( $prevID ) );
		$link_html = '<a href="'.$permalink.'" title="'.$prev_title.'" ><i class="fas fa-lg fa-chevron-left" aria-hidden="true"></i></a>';
		
	else:
		return false;
	endif;
	return $link_html;
	}
endif;
/**
 * Get Comic Number
 */
function toocheke_get_comic_number(){
    global $post;
	$comic_number = "#" . get_post_meta( $post->ID, 'incr_number', true );
    return wp_kses_data($comic_number);
}

/**
 * Generate Comic Link
 */
function toocheke_get_random_comic() {

$random_args = array( 'post_type' => 'comic', 'posts_per_page' => 1, 'orderby' => 'rand' );
$random_comics_query = new WP_Query( $random_args );
while ( $random_comics_query->have_posts() ) : $random_comics_query->the_post();
$link = '<a href="'.esc_url(get_the_permalink()).'" title="'.esc_attr(get_the_title()).'" ><i class="fas fa-lg fa-random"></i></a>';
endwhile;
wp_reset_postdata(); 
return $link;
}
/**
 * Get Random Comic Link 
 */
function toocheke_random_comic_url( $title='Random Post' ) {
    // Get the URL of a random post and format it as a clickable link
    $posts = get_posts('post_type=comic&orderby=rand&numberposts=1');
    foreach($posts as $post) {
      $link = esc_url( get_permalink($post) );
    }
    // Return the link to wherever this function is called
    return $link;
  }
/**
 * Redirect to Random Comic
 */

function toocheke_redirect_random_comic() {
   
	$rand_args = array( 
		'posts_per_page' => 1, 
		'post_type' => 'comic', 
		'orderby' => 'rand', 
		'post_status' => 'publish'
		);	

  $random_comic = get_posts( $rand_args );
  if (is_array($random_comic)) {
	$random_comic = reset($random_comic);
	wp_redirect( esc_url(get_permalink( $random_comic->ID )) );
  }
  
  exit;
}


if ( isset( $_GET['random'] ) )
add_action( 'template_redirect', 'toocheke_redirect_random_comic' );
/**
 * Implement the Custom Header feature.
 */
// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
require get_template_directory() . '/inc/template-tags.php';
/**
 * Customizer additions.
 */
// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
require get_template_directory() . '/inc/customizer.php';

/**
 * Widgets File.
 */
// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
require get_template_directory() . '/inc/widgets.php';

/**
 * Boostrap Navwalker File.
 */
// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
require_once get_template_directory() . '/inc/wp-bootstrap-navwalker.php';



/**
 * Boostrap Comment Walker File.
 */
// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
require get_template_directory() . '/inc/bootstrap-comment-walker.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
	require get_template_directory() . '/inc/jetpack.php';
}

