=== Birch（白桦） ===
主题名称: Birch（白桦）
主题地址: http://www.jeffdesign.net/projects/wp-birch/
主题介绍: Birch（白桦）是由杰夫设计出品的一款免费的响应式瀑布流 WordPress 主题，多用途、极简、极速，适配PC端和移动端（手机、iPad、平板电脑等）。主题集成众多实用的功能，简洁实用，速度优化，主题所有文件仅40+K，可满足个人、工作室、公司企业内容展示，自媒体个站等需求。可搭配插件作为网站移动版。
主题作者: 杰夫设计
作者网站: http://www.jeffdesign.net/
最新版本: 1.1
使用授权: 作者保留版权所有，使用该主题需保留作者信息
主题帮助: http://www.jeffdesign.net/support/


== 安装主题 ==

1. 上传主题
2. 激活主题

主题所有功能设定可通过主题选项和主题自定义功能进行修改。


== 可选插件 ==

- Mobile Switcher

安装插件后可使本主题作为网站的移动版，安装并激活插件即可。


== 版权授权 ==

作者保留版权所有，使用该主题需保留作者信息。

除特别说明外，该主题基于 GNU General Public License v3 or later 协议发布，并以适当方式提示。

== 更新日志 ==

Version 1.1 (2017-10-10)
-------------------------
- 移除 archive.php
- 移除 search.php
- 移除 content.php 合并代码到 index.php
- 合并存档和搜索列表标题代码到 index.php
- 使用 the_posts_pagination() 替换原分页代码
- 增加空页面提示

Version 1.0 (2017-09-15)
-------------------------
