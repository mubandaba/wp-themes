<?php get_header(); ?>
<div class="content">
<div class="post single">
<div class="post-inner">
<div class="post-header">
<h2 class="post-title">出错啦！</h2>
</div>
<div class="post-content">
<p>没有找到你需要的内容，可能已经被移动或删除，请通过下方的搜索功能尝试搜索。</p>
<?php get_search_form(); ?>
</div>
</div>
</div>
<?php get_footer(); ?>