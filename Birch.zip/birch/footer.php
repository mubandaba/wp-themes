</div>
<div class="copyright">
<p>&copy; <?php echo date("Y") ?> <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo('name');echo a();?>
<?php wp_footer(); //Theme By JeffDesign.Net ?>
<!-- Theme By JeffDesign.Net -->
</body>
</html>
