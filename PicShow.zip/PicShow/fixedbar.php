		<div class="col-lg-2 visible-lg">
			<div id="fixedbar" class="panel panel-default">
				<!-- Default panel contents -->
				<div class="panel-heading">
					<i class="glyphicon glyphicon-map-marker"></i> 快捷导航
				</div>
				<!-- List group -->
				<ul class="list-group">
					<?php $result = mysql_query("select * from wp_term_taxonomy where taxonomy = 'category' AND count > 0 ORDER BY count DESC"); 
while ($row=mysql_fetch_array($result)) { ?>
					<a href="<?php echo get_category_link($row['term_id']); ?>" class="list-group-item">
						<?php echo get_cat_name($row['term_id']) ?>
					</a>
					<?php } ?>
				</ul>
			</div>
		</div>