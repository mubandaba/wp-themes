<?php get_header(); ?>
<div class="container">
	<ol class="breadcrumb">
		<li>
			当前位置：
			<a href="<?php bloginfo('url'); ?>">
				首页
			</a>
		</li>
		<li class="active">
			<?php single_cat_title(); ?>
		</li>
	</ol>
	<div class="row">
		<div class="col-md-12 col-lg-10">
			<div class="row hidden-xs hidden-sm">
				<div class="col-md-12">
					<div class="row" id="home-right-top-loop">
						<?php query_posts('showposts=4&orderby=rand'); ?>
						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						<div class="col-md-3">
							<a href="<?php the_permalink(); ?>" class="thumbnail">
								<div class="img-div">
									<img src="<?php echo img(); ?>" alt="<?php the_title(); ?>">
								</div>
								<div class="caption">
									<h4>
										<?php the_title(); ?>
									</h4>
									<p>
										<?php echo get_the_excerpt(); ?>
									</p>
								</div>
							</a>
						</div>
						<?php endwhile; endif;wp_reset_query(); ?>
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="row">
				<?php get_sidebar(); ?>
				<div class="col-md-9" id="arclist">
					<div class="panel panel-default">
						<!-- Default panel contents -->
						<div class="panel-heading">
							<h4 class="panel-title">
								<i class="glyphicon glyphicon-list"></i> <?php single_cat_title(); ?>
							</h4>
						</div>
						<ul class="list-group">
							<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
							<a href="<?php the_permalink(); ?>" class="list-group-item">
								<div class="row">
									<div class="col-sm-4">
										<img src="<?php echo img(); ?>" class="img-responsive" alt="<?php the_title(); ?>">
									</div>
									<div class="col-sm-8">
										<h4 class="list-group-item-heading">
											<?php the_title(); ?>
										</h4>
										<p class="list-group-item-text">
											<?php echo get_the_excerpt(); ?>
										</p>
									</div>
								</div>
							</a>
							<?php endwhile; endif; ?>
						</ul>
					</div>
					<ul id="pager" class="pagination">
						<?php par_pagenavi(9); ?>
					</ul>
				</div>
			</div>
		</div>
		<?php get_template_part('fixedbar'); ?>
	</div>
</div>
<?php get_footer(); ?>