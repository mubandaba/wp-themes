$(document).ready(function(){
	$("#fixedbar").pin();
	$("#home-right-top-loop .thumbnail").hover(function() {
		$('.img-div',this).animate({height:"400px"});
		$('.img-div',this).css('opacity','0.5');
	},function() {
		$('.img-div',this).animate({height:"100px"});
		$('.img-div',this).css('opacity','1');
	});
});

//内容页导航
$(function(){
	$.fn.scrollToTop2=function(){
		var scrollDiv2=$(this);
		$(window).scroll(function(){
			if($(window).scrollTop()<"900"){
				$(scrollDiv2).removeClass("navbar-fixed-top")
			}else{
				$(scrollDiv2).addClass("navbar-fixed-top")
			}
		});
	}
});
$(function() {
	$("#navbar-spy").scrollToTop2();
});

//平滑滚动到锚点
$(".pro-con-nav li a").click(function() {
        var gotop = $($(this).attr("href")).offset().top-80;
        $("html, body").animate({
            scrollTop: gotop + "px"
        }, {
            duration: 500,
            easing: "swing"
        });
        return false;
    });