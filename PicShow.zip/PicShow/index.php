<?php get_header(); ?>
<div class="container">
	<div class="row">
		<div class="col-md-12 col-lg-10">
			<div class="row hidden-xs hidden-sm">
				<div class="col-md-6">
					<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
						<!-- Indicators -->
						<ol class="carousel-indicators">
							<li data-target="#carousel-example-generic" data-slide-to="0" class="active">
							</li>
							<li data-target="#carousel-example-generic" data-slide-to="1">
							</li>
							<li data-target="#carousel-example-generic" data-slide-to="2">
							</li>
						</ol>
						<!-- Wrapper for slides -->
						<div class="carousel-inner">
							<?php query_posts('showposts=5&cat='.get_option('mao10_cat03').''); ?>
							<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
							<?php $num01++; ?>
							<div class="item <?php if($num01==1) echo 'active'; ?>">
								<img src="<?php echo img(); ?>" alt="<?php the_title(); ?>">
							</div>
							<?php endwhile; endif;wp_reset_query(); ?>
						</div>
						<!-- Controls -->
						<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
							<span class="glyphicon glyphicon-chevron-left">
							</span>
						</a>
						<a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
							<span class="glyphicon glyphicon-chevron-right">
							</span>
						</a>
					</div>
				</div>
				<div class="col-md-6">
					<div class="row" id="home-right-top-loop">
						<?php query_posts('showposts=4'); ?>
						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						<div class="col-md-6">
							<a href="<?php the_permalink(); ?>" class="thumbnail">
								<div class="img-div">
									<img src="<?php echo img(); ?>" alt="<?php the_title(); ?>">
								</div>
								<div class="caption">
									<h4>
										<?php the_title(); ?>
									</h4>
									<p>
										<?php echo get_the_excerpt(); ?>
									</p>
								</div>
							</a>
						</div>
						<?php endwhile; endif;wp_reset_query(); ?>
					</div>
					<div class="list-group" id="home-right-bottom-loop">
						<?php query_posts('showposts=5&cat='.get_option('mao10_cat03').''); ?>
						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						<?php $num03++; ?>
						<?php if($num03==1) { ?>
						<a href="<?php the_permalink(); ?>" class="list-group-item active">
							<h4 class="list-group-item-heading">
								<?php the_title(); ?>
							</h4>
							<p class="list-group-item-text">
								<?php echo get_the_excerpt(); ?>
							</p>
						</a>
						<?php } else { ?>
						<a href="<?php the_permalink(); ?>" class="list-group-item hrbl">
							<?php the_title(); ?>
						</a>
						<?php } ?>
						<?php endwhile; endif;wp_reset_query(); ?>
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
			<!-- Nav tabs -->
			<ul class="nav nav-pills nav-justified hidden-xs hidden-sm" id="home-tab-nav">
				<li class="active">
					<a href="#home-tab-1" data-toggle="tab">
						<?php echo get_cat_name(get_option('mao10_cat04')) ?>
					</a>
				</li>
				<li>
					<a href="#home-tab-2" data-toggle="tab">
						<?php echo get_cat_name(get_option('mao10_cat05')) ?>
					</a>
				</li>
				<li>
					<a href="#home-tab-3" data-toggle="tab">
						<?php echo get_cat_name(get_option('mao10_cat06')) ?>
					</a>
				</li>
				<li>
					<a href="#home-tab-4" data-toggle="tab">
						<?php echo get_cat_name(get_option('mao10_cat07')) ?>
					</a>
				</li>
				<li>
					<a href="#home-tab-5" data-toggle="tab">
						<?php echo get_cat_name(get_option('mao10_cat08')) ?>
					</a>
				</li>
			</ul>
			<!-- Tab panes -->
			<div class="tab-content hidden-xs hidden-sm" id="home-tab-content">
				<div class="tab-pane active" id="home-tab-1">
					<div class="row">
						<?php query_posts('showposts=4&cat='.get_option('mao10_cat04').''); ?>
						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						<div class="col-md-3">
							<a href="<?php the_permalink(); ?>" class="thumbnail">
								<img src="<?php echo img(); ?>" alt="<?php the_title(); ?>">
							</a>
						</div>
						<?php endwhile; endif;wp_reset_query(); ?>
					</div>
				</div>
				<div class="tab-pane" id="home-tab-2">
					<div class="row">
						<?php query_posts('showposts=4&cat='.get_option('mao10_cat05').''); ?>
						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						<div class="col-md-3">
							<a href="<?php the_permalink(); ?>" class="thumbnail">
								<img src="<?php echo img(); ?>" alt="<?php the_title(); ?>">
							</a>
						</div>
						<?php endwhile; endif;wp_reset_query(); ?>
					</div>
				</div>
				<div class="tab-pane" id="home-tab-3">
					<div class="row">
						<?php query_posts('showposts=4&cat='.get_option('mao10_cat06').''); ?>
						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						<div class="col-md-3">
							<a href="<?php the_permalink(); ?>" class="thumbnail">
								<img src="<?php echo img(); ?>" alt="<?php the_title(); ?>">
							</a>
						</div>
						<?php endwhile; endif;wp_reset_query(); ?>
					</div>
				</div>
				<div class="tab-pane" id="home-tab-4">
					<div class="row">
						<?php query_posts('showposts=4&cat='.get_option('mao10_cat07').''); ?>
						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						<div class="col-md-3">
							<a href="<?php the_permalink(); ?>" class="thumbnail">
								<img src="<?php echo img(); ?>" alt="<?php the_title(); ?>">
							</a>
						</div>
						<?php endwhile; endif;wp_reset_query(); ?>
					</div>
				</div>
				<div class="tab-pane" id="home-tab-5">
					<div class="row">
						<?php query_posts('showposts=4&cat='.get_option('mao10_cat08').''); ?>
						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						<div class="col-md-3">
							<a href="<?php the_permalink(); ?>" class="thumbnail">
								<img src="<?php echo img(); ?>" alt="<?php the_title(); ?>">
							</a>
						</div>
						<?php endwhile; endif;wp_reset_query(); ?>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4 hidden-xs hidden-sm">
					<div class="panel-group" id="accordion">
						<?php query_posts('showposts=3&cat='.get_option('mao10_cat09').''); ?>
						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						<?php $num09++; ?>
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo $num09; ?>" <?php if($num09>1) echo 'class="collapsed"'; ?>>
										<?php the_title(); ?>
									</a>
								</h4>
							</div>
							<div id="collapse<?php echo $num09; ?>" class="panel-collapse collapse <?php if($num09==1) echo 'in'; ?>">
								<div class="panel-body">
									<p><?php echo get_the_excerpt(); ?></p>
								</div>
							</div>
						</div>
						<?php endwhile; endif;wp_reset_query(); ?>
					</div>
				</div>
				<div class="col-md-8">
					<div class="row" id="home-bottom-right-loop">
						<?php query_posts('showposts=4&cat='.get_option('mao10_cat10').''); ?>
						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						<div class="col-md-6">
							<div class="panel panel-default">
								<div class="panel-body">
									<div class="row">
										<div class="col-sm-4">
											<a href="<?php the_permalink(); ?>">
												<img src="<?php echo img(); ?>" class="img-responsive" alt="<?php the_title(); ?>">
											</a>
										</div>
										<div class="col-sm-8">
											<h4>
												<a href="<?php the_permalink(); ?>">
													<?php the_title(); ?>
												</a>
											</h4>
											<p><?php echo get_the_excerpt(); ?></p>
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php endwhile; endif;wp_reset_query(); ?>
					</div>
				</div>
			</div>
			<div class="row hidden-xs hidden-sm" id="home-bottom">
				<?php query_posts('showposts=12&orderby=rand'); ?>
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				<div class="col-md-2">
					<a href="<?php echo img(); ?>" title="<?php the_title(); ?>" data-lightbox="roadtrip" class="thumbnail">
						<img src="<?php echo img(); ?>" alt="<?php the_title(); ?>">
					</a>
				</div>
				<?php endwhile; endif;wp_reset_query(); ?>
			</div>
		</div>
		<?php get_template_part('fixedbar'); ?>
	</div>
</div>
<?php get_footer(); ?>