				<div class="col-md-3 hidden-xs hidden-sm">
					<div class="panel panel-default">
						<!-- Default panel contents -->
						<div class="panel-heading">
							<i class="glyphicon glyphicon-bookmark"></i> 最新发布
						</div>
						<!-- List group -->
						<ul class="list-group">
							<?php query_posts('showposts=5'); ?>
							<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
							<a href="<?php the_permalink(); ?>" class="list-group-item">
								<?php the_title(); ?>
							</a>
							<?php endwhile; endif;wp_reset_query(); ?>
						</ul>
					</div>
					<div class="panel panel-default" id="side-img-list">
						<!-- Default panel contents -->
						<div class="panel-heading">
							<i class="glyphicon glyphicon-fire"></i> 最热门文章
						</div>
						<!-- List group -->
						<ul class="list-group">
							<?php if (have_posts()) : ?>
							<?php 
							// Create a new filtering function that will add our where clause to the query
							function filter_where( $where = '' ) {
								// posts in the last 30 days
								$where .= " AND post_date > '" . date('Y-m-d', strtotime('-360 days')) . "'";
								return $where;
							};
							$args=array(
								'orderby' => 'meta_value_num','meta_key'=> 'post_views_count','order' => 'DESC','showposts'=>'3','caller_get_posts' => 1
							);
							add_filter( 'posts_where', 'filter_where' );
							$my_query=new WP_Query(
								$args
							);
							remove_filter( 'posts_where', 'filter_where' );
							while ($my_query->have_posts()) : $my_query->the_post(); $do_not_duplicate = $post->ID;
							?>
							<a href="<?php the_permalink(); ?>" class="list-group-item">
								<img src="<?php echo img(); ?>" class="img-responsive" alt="Responsive image">
								<div class="clearfix"></div>
								<?php the_title(); ?>
							</a>
							<?php endwhile;endif;wp_reset_query(); ?>
						</ul>
					</div>
				</div>