<div id="footer" class="hidden-xs">
	<div class="container">
		<div class="row">
			<div class="col-sm-4 col-md-4 col-lg-3">
				<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footbar01') ) : endif; ?>
			</div>
			<div class="col-sm-4 col-md-4 col-lg-3">
				<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footbar02') ) : endif; ?>
			</div>
			<div class="col-lg-3 visible-lg">
				<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footbar03') ) : endif; ?>
			</div>
			<div class="col-sm-4 col-md-4 col-lg-3">
				<div id="foot-logo">
					<a href="<?php bloginfo('url'); ?>">
						<img src="<?php bloginfo('template_directory'); ?>/img/logo-foot.png">
					</a>
				</div>
			</div>
		</div>
	</div>
</div>
<div id="footer2">
	<div class="container">
		Copyright 2011-2013 www.mao01.com allright reserved. 网站设计 <a href="http://www.mao01.com/" title="wordpress主题定制">猫猫工作室</a>
	</div>
</div>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php bloginfo('template_directory'); ?>/js/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?php bloginfo('template_directory'); ?>/js/bootstrap.min.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/lightbox-2.6.min.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/jquery.pin.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/cat.js"></script>
</body>
</html>