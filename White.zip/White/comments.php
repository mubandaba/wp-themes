<?php
/*****************************************************************
_____   _   _____   _____   _   _   _____       ___  ___   _____
|  _  \ | | |_   _| |_   _| | | | | | ____|     /   |/   | | ____|
| |_| | | |   | |     | |   | |_| | | |__      / /|   /| | | |__
|  _  { | |   | |     | |   |  _  | |  __|    / / |__/ | | |  __|
| |_| | | |   | |     | |   | | | | | |___   / /       | | | |___
|_____/ |_|   |_|     |_|   |_| |_| |_____| /_/        |_| |_____|

HTTPS://WWW.BITTHEME.CN/
 ****************************************************************/
?>
<?php
	if (isset($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
		die ('Please do not load this page directly. Thanks!');
?>
                                <div class="pt-5 mt-5" id="comments">
                                    <h3 class="mb-5"><span class="iconfont icon-Comment"></span> 评论</h3>
                                    <ul class="comment-list">
<?php
if (!empty($post->post_password) && $_COOKIE['wp-postpass_' . COOKIEHASH] != $post->post_password) {
    ?>
    <li class="decmt-box">
        <p>请输入密码再查看评论内容！</p>
    </li>
    <?php
} else if (!comments_open()) {
    ?>
    <li class="decmt-box">
        <p>评论功能已经关闭！</p>
    </li>
    <?php
} else if (!have_comments()) {
    ?>
    <li class="decmt-box">
        <p>
            <a href="#message comment">还没有任何评论，你来说两句吧！</a>
        </p>
    </li>
    <?php
} else {
    wp_list_comments('type=comment&callback=aurelius_comment');
}
?>
                                   </ul>
                                    <div class="comment-form-wrap pt-5" id="respond">
                                        <h3 class="mb-5"><span class="iconfont icon-Pencil"></span> 发表评论</h3>
<?php 
if ( !comments_open() ) :
elseif ( get_option('comment_registration') && !is_user_logged_in() ) : 
?>
<p>你必须 <a href="<?php echo wp_login_url( get_permalink() ); ?>">登录</a> 才能发表评论.</p>
<?php else  : ?>
                                        <form id="commentform" name="commentform" action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post">
<?php if ( !is_user_logged_in() ) : ?>
                                            <div class="form-group">
                                                <label for="name">昵称（必填）</label>
                                                <input type="text" name="author" id="author" class="form-control" value="<?php echo $comment_author; ?>" size="23" tabindex="1" />
                                            </div>
                                            <div class="form-group">
                                                <label for="email">邮箱（必填）</label>
                                                <input type="email" name="email" id="email" class="form-control" value="<?php echo $comment_author_email; ?>" size="23" tabindex="2" />
                                            </div>
                                            <div class="form-group">
                                                <label for="website">网址（选填）</label>
                                                <input type="url" name="url" id="url" class="form-control" value="<?php echo $comment_author_url; ?>" size="23" tabindex="3" />
                                            </div>
<?php else : ?>
                                            <div class="clearfix"><a id="cancel-comment-reply-link"  href="javascript:;">取消回复</a></br>您已登录：<a href="<?php echo get_option('siteurl'); ?>/wp-admin/profile.php"><?php echo $user_identity; ?></a>
                                            </br>
                                            <a href="<?php echo wp_logout_url(get_permalink()); ?>" title="退出登录">退出登录<span class="iconfont icon-Enable"></span></a></div>
<?php endif; ?>
                                            <div class="form-group" id="comment-message">
                                                <label for="message">评论内容</label>
                                                <textarea name="comment" id="message comment" cols="30" rows="10" class="form-control"></textarea>
                                            </div>
                                            <div class="form-group">
                                                <input href="javascript:void(0);" id="comment-submit" onClick="Javascript:document.forms['commentform'].submit()" type="submit" value="提交评论" class="btn py-3 px-4">
                                            </div>
<?php comment_id_fields(); ?>
<?php do_action('commentform', $post->ID); ?>
                                        </form>
<?php endif; ?>
                                    </div>
                                </div>