<?php
/*****************************************************************
_____   _   _____   _____   _   _   _____       ___  ___   _____
|  _  \ | | |_   _| |_   _| | | | | | ____|     /   |/   | | ____|
| |_| | | |   | |     | |   | |_| | | |__      / /|   /| | | |__
|  _  { | |   | |     | |   |  _  | |  __|    / / |__/ | | |  __|
| |_| | | |   | |     | |   | | | | | |___   / /       | | | |___
|_____/ |_|   |_|     |_|   |_| |_| |_____| /_/        |_| |_____|

HTTPS://WWW.BITTHEME.CN/
 ****************************************************************/
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
    <head>
        <meta charset="<?php bloginfo('charset'); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title><?php if ( is_home() ) {
		bloginfo('name'); echo " - "; bloginfo('description');
	} elseif ( is_category() ) {
		single_cat_title(); echo " - "; bloginfo('name');
	} elseif (is_single() || is_page() ) {
		single_post_title();
	} elseif (is_search() ) {
		echo "搜索结果"; echo " - "; bloginfo('name');
	} elseif (is_404() ) {
		echo '很抱歉，您访问的页面不存在'; echo " - "; bloginfo('name');
	} else {
		wp_title('',true);
	} ?></title>
<?php require get_template_directory() . '/functions/theme-seo.php'; ?>
        <link rel="shortcut icon" type="images/x-icon" href="<?php echo bittheme( 'website_icon' ); ?>">
        <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/static/css/animate.css">
        <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/static/fonts/iconfont.css">
        <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/static/css/theme.css">
        <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
        <link rel="alternate" type="application/rss+xml" title="RSS 2.0 - 所有文章" href="<?php echo get_bloginfo('rss2_url'); ?>" />
        <link rel="alternate" type="application/rss+xml" title="RSS 2.0 - 所有评论" href="<?php bloginfo('comments_rss2_url'); ?>" />
        <?php wp_head(); ?>
    </head>
<?php flush(); ?>
    <body>
        <div class="KW_progressContainer">
            <div class="KW_progressBar"></div>
        </div>
        <div class="page">
            <nav id="aminos-main-nav">
                <a href="#" class="js-aminos-nav-toggle aminos-nav-toggle active"><i></i></a>
                <div class="js-fullheight aminos-table">
                    <div class="img" style="background-image: url(<?php echo bittheme( 'pop_up_menu_side_picture' ); ?>);"></div>
                    <div class="aminos-table-cell js-fullheight">
                        <div class="row no-gutters">
                            <div class="col-md-12 text-center">
<?php if (empty(bittheme('logo'))) { ?>
                                        <h1 class="mb-4"><a href="<?php echo get_option('home'); ?>" class="logo"><?php bloginfo('name'); ?></a></h1>
<?php } else { ?>
                                        <a href="<?php echo get_option('home'); ?>"><img src="<?php echo bittheme('logo'); ?>" alt="logo" style="height: 50px;"></a>
<?php } ?>
                                <ul>
<?php
$defaults = array(
	'theme_location'  => 'top-menu',
	'menu'            => '',
	'container'       => false,
	'container_class' => '',
	'container_id'    => '',
	'menu_class'      => 'menu',
	'menu_id'         => '',
	'echo'            => true,
	'fallback_cb'     => 'wp_page_menu',
	'before'          => '',
	'after'           => '',
	'link_before'     => '<span>',
	'link_after'      => '</span>',
	'items_wrap'      => '%3$s',
	'depth'           => 1,
	'walker'          => ''
);
wp_nav_menu( $defaults );
?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
            <div id="aminos-page">
                <header>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="aminos-navbar-brand">
                                    <a class="aminos-logo" href="<?php echo get_option('home'); ?>">
<?php if (empty(bittheme('logo'))) { ?>
                                        <?php bloginfo('name'); ?>
<?php } else { ?>
                                        <img src="<?php echo bittheme('logo'); ?>" alt="logo">
<?php } ?>
                                    </a>
                                </div> <a href="#" class="js-aminos-nav-toggle aminos-nav-toggle"><i></i></a>

                            </div>
                        </div>
                    </div>
                </header>