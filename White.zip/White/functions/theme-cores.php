<?php
function bit_add_menu_setup() {
    register_nav_menus([
        'top-menu' => __('顶部菜单'),
    ]);
}
add_action('after_setup_theme', 'bit_add_menu_setup');

function post_thumbnail_src() {
    $thumb = get_post_meta(get_the_ID(), 'my_post_options', true);
    global $post;
    if ($values = $thumb['thumbnail']) {
        $values = $thumb['thumbnail'];
        $post_thumbnail_src = $thumb['thumbnail'];
    } elseif (has_post_thumbnail()) {
        $thumbnail_src = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
        $post_thumbnail_src = $thumbnail_src [0];
    } else {
        $post_thumbnail_src = '';
        ob_start();
        ob_end_clean();
        $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
        $post_thumbnail_src = $matches [1] [0];
        if (empty($post_thumbnail_src)) {
            $post_thumbnail_src = get_bloginfo('template_url')."/static/images/default-picture.jpg";
        }
    }
    ;
    echo $post_thumbnail_src;
}

function par_pagenavi($range = 3) {
    global $paged, $wp_query;
    if (!$max_page) {
        $max_page = $wp_query->max_num_pages;
    }
    if ($max_page > 1) {
        if (!$paged) {
            $paged = 1;
        }
        if ($paged != 1) {
            echo "<a href='" . get_pagenum_link(1) . "'><span class='iconfont icon-Left'></span></a>";
        }
        if ($max_page > $range) {
            if ($paged < $range) {
                for ($i = 1; $i <= ($range + 1); $i++) {
                    echo "<a href='" . get_pagenum_link($i) ."'";
                    if ($i == $paged)echo " class='active'";echo ">$i</a>";
                }} elseif ($paged >= ($max_page - ceil(($range/2)))) {
                for ($i = $max_page - $range; $i <= $max_page; $i++) {
                    echo "<a href='" . get_pagenum_link($i) ."'";
                    if ($i == $paged)echo " class='active'";echo ">$i</a>";
                }} elseif ($paged >= $range && $paged < ($max_page - ceil(($range/2)))) {
                for ($i = ($paged - ceil($range/2)); $i <= ($paged + ceil(($range/2)));
                    $i++) {
                    echo "<a href='" . get_pagenum_link($i) ."'";if ($i == $paged)
                        echo " class='active'";echo ">$i</a>";
                }}} else {
            for ($i = 1; $i <= $max_page; $i++) {
                echo "<a href='" . get_pagenum_link($i) ."'";
                if ($i == $paged)echo " class='active'";echo ">$i</a>";
            }}
        next_posts_link('<span class="iconfont icon-Right"></span>');
    }
}

function copyrightDate() {
    global $wpdb;
    $copyright_dates = $wpdb->get_results("
		SELECT
			YEAR(min(post_date_gmt)) AS firstdate,
			YEAR(max(post_date_gmt)) AS lastdate
		FROM
			$wpdb->posts
		WHERE post_status = 'publish'
	");
    if ($copyright_dates) {
        $date = date('Y-m-d');
        $date = explode('-', $date);
        $copyright = "" . $copyright_dates[0]->firstdate;
        if ($copyright_dates[0]->firstdate != $date[0]) {
            $copyright .= '-' . $date[0];
        }
        echo $copyright;
    }
}

function aurelius_comment($comment, $args, $depth) {
    $GLOBALS['comment'] = $comment;
    ?>
                                        <li class="comment" id="comment-<?php comment_ID(); ?> comment-list">
                                            <div class="vcard bio">
<?php if (function_exists('get_avatar') && get_option('show_avatars')) {
    echo get_avatar($comment, 48);
}
?>
                                            </div>
                                            <div class="comment-body" id="comment-<?php comment_ID(); ?>">
                                                <?php printf(__('<h3>%s</h3>'), get_comment_author_link()); ?>
                                                <div class="meta"><?php echo get_comment_time('Y-m-d-H:i'); ?> <?php edit_comment_link('修改'); ?></div>
<?php if ($comment->comment_approved == '0') : ?>
                                                <p>你的评论正在审核，稍后会显示出来！</p>
<?php endif; ?>
                                                <p><?php comment_text(); ?></p>
                                                <p>
<?php 
    $comment_reply_class = 'reply';
    echo preg_replace( '/comment-reply-link/', 'comment-reply-link ' . $comment_reply_class, 
        get_comment_reply_link(array_merge( $args, array(
            'reply_text' => '回复', 
            'respond_id'    => 'respond',
            'reply_to_text' => __( '回复给 %s' ),
            'depth' => $depth, 
            'max_depth' => $args['max_depth']))), 1 );
?>
                                                </p>
                                            </div>
<?php } ?>