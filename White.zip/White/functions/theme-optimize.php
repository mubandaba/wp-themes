<?php
/*****************************************************************
_____   _   _____   _____   _   _   _____       ___  ___   _____
|  _  \ | | |_   _| |_   _| | | | | | ____|     /   |/   | | ____|
| |_| | | |   | |     | |   | |_| | | |__      / /|   /| | | |__
|  _  { | |   | |     | |   |  _  | |  __|    / / |__/ | | |  __|
| |_| | | |   | |     | |   | | | | | |___   / /       | | | |___
|_____/ |_|   |_|     |_|   |_| |_| |_____| /_/        |_| |_____|

HTTPS://WWW.BITTHEME.CN/
 ****************************************************************/
?>
<?php
if (bittheme('disable_emoji_emoticon_in') == true) {
    //WordPress禁用emoji表情
    remove_action ('wp_head','print_emoji_detection_script',7);
    remove_action ('wp_print_styles','print_emoji_styles');
    add_filter ('emoji_svg_url','__return_false');
}
if (bittheme('remove_top_toolbar') == true) {
    //WordPress移除顶部工具条
    add_filter('show_admin_bar', '__return_false');
}
if (bittheme('disable_rest_API') == true) {
    //WordPress禁用REST API
    remove_action('wp_head', 'rest_output_link_wp_head', 10);
    remove_action('wp_head', 'wp_oembed_add_discovery_links', 10);
}
if (bittheme('disable_gutenberg_editor') == true) {
    //WordPress禁用古腾堡编辑器
    add_filter ('use_block_editor_for_post','__return_false');
    remove_action('wp_enqueue_scripts', 'wp_common_block_scripts_and_styles');
}
if (bittheme('upload_file_rename_automatically') == true) {
    //WordPress上传文件自动重命名
    add_filter('wp_handle_upload_prefilter', 'custom_upload_filter');
    function custom_upload_filter($file) {
        $info = pathinfo($file['name']);
        $ext = '.' . $info['extension'];
        $md5 = md5($file['name']);
        $file['name'] = $md5.$ext;
        return $file;
    }
}
if (bittheme('block_article_revision_function') == true) {
    //WordPress屏蔽文章修订功能
    define('WP_POST_REVISIONS', false);
}
if (bittheme('the_article_page_realizes_the_label_automatically_adding_inner_chain') == true) {
    //WordPress文章页实现标签自动添加内链
    $match_num_from = 20;
    $match_num_to = 1;
    function tag_sort($a, $b) {
        if ($a->name == $b->name) return 0;
        return (strlen($a->name) > strlen($b->name)) ? -1 : 1;
    }
    function tag_link($content) {
        global $match_num_from,$match_num_to;
        $posttags = get_the_tags();
        if ($posttags) {
            usort($posttags, "tag_sort");
            foreach ($posttags as $tag) {
                $link = get_tag_link($tag->term_id);
                $keyword = $tag->name;
                $cleankeyword = stripslashes($keyword);
                $url = "<a href=\"$link\" title=\"".str_replace('%s',addcslashes($cleankeyword, '$'),__('查看含有【%s】标签的文章'))."\"";
                $url .= ' target="_blank"';
                $url .= ">".addcslashes($cleankeyword, '$')."</a>";
                $limit = rand($match_num_from,$match_num_to);
                $content = preg_replace('|(<a[^>]+>)(.*)('.$ex_word.')(.*)(</a[^>]*>)|U'.$case, '$1$2%&&&&&%$4$5', $content);
                $content = preg_replace('|(<img)(.*?)('.$ex_word.')(.*?)(>)|U'.$case, '$1$2%&&&&&%$4$5', $content);
                $cleankeyword = preg_quote($cleankeyword,'\'');
                $regEx = '\'(?!((<.*?)|(<a.*?)))('. $cleankeyword . ')(?!(([^<>]*?)>)|([^>]*?</a>))\'s' . $case;
                $content = preg_replace($regEx,$url,$content,$limit);
                $content = str_replace('%&&&&&%', stripslashes($ex_word), $content);
            }
        }
        return $content;
    }
    add_filter('the_content','tag_link',1);
}
if (bittheme('automatically_tag_articles') == true) {
    //WordPress自动给文章添加标签
    add_action('save_post', 'auto_add_tags');
    function auto_add_tags() {
        $tags = get_tags(array('hide_empty' => false));
        $post_id = get_the_ID();
        $post_content = get_post($post_id)->post_content;
        if ($tags) {
            foreach ($tags as $tag) {
                if (strpos($post_content, $tag->name) !== false)
                    wp_set_post_tags($post_id, $tag->name, true);
            }
        }
    }
}
if (bittheme('shield_useless_gadgets') == true) {
    //WordPress屏蔽无用小工具
    add_action('widgets_init', 'my_unregister_widgets');
    function my_unregister_widgets() {
        unregister_widget('WP_Widget_Archives');
        unregister_widget('WP_Widget_Calendar');
        unregister_widget('WP_Widget_Categories');
        unregister_widget('WP_Widget_Links');
        unregister_widget('WP_Widget_Meta');
        unregister_widget('WP_Widget_Pages');
        unregister_widget('WP_Widget_Recent_Comments');
        unregister_widget('WP_Widget_Recent_Posts');
        unregister_widget('WP_Widget_RSS');
        unregister_widget('WP_Widget_Search');
        unregister_widget('WP_Widget_Tag_Cloud');
        unregister_widget('WP_Widget_Text');
        unregister_widget('WP_Nav_Menu_Widget');
        unregister_widget('WP_Widget_Media_Image');
        unregister_widget('WP_Widget_Media_Gallery');
        unregister_widget('WP_Widget_Media_Video');
        unregister_widget('WP_Widget_Media_Audio');
    }
}
if (bittheme('database_cleanup_optimization_plug_in') == true) {
    //WordPress集成数据库清理优化插件
    require_once get_template_directory() . '/functions/wp-clean-up/wp-clean-up.php';
}
function ihuan_avatar($avatar) {
    $avatar = str_replace(array("gravatar.loli.net","sdn.geekzu.org","cdn.v2ex.com"),"gravatar.ihuan.me",$avatar);
    return $avatar;
}
add_filter('get_avatar', 'ihuan_avatar', 10, 3);