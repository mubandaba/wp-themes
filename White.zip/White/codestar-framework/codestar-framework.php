<?php if (! defined('ABSPATH')) {
    die;
}

if (! function_exists('bittheme')) {
    function bittheme($option = '', $default = null) {
        $options = get_option('my_framework');
        return (isset($options[$option])) ? $options[$option] : $default;
    }
}

require_once plugin_dir_path(__FILE__) .'classes/setup.class.php';
require_once plugin_dir_path(__FILE__) .'options/options.theme.php';
require_once plugin_dir_path(__FILE__) .'options/metabox.theme.php';
require_once plugin_dir_path(__FILE__) .'options/taxonomy-options.theme.php';