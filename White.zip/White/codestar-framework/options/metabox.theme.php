<?php
/*****************************************************************
_____   _   _____   _____   _   _   _____       ___  ___   _____
|  _  \ | | |_   _| |_   _| | | | | | ____|     /   |/   | | ____|
| |_| | | |   | |     | |   | |_| | | |__      / /|   /| | | |__
|  _  { | |   | |     | |   |  _  | |  __|    / / |__/ | | |  __|
| |_| | | |   | |     | |   | | | | | |___   / /       | | | |___
|_____/ |_|   |_|     |_|   |_| |_| |_____| /_/        |_| |_____|

HTTPS://WWW.BITTHEME.CN/
 ****************************************************************/
?>
<?php if (! defined('ABSPATH')) {
    die;
}
$prefix_page_opts = 'my_post_options';
CSF::createMetabox($prefix_page_opts, array(
    'title' => 'BitTheme主题拓展',
    'post_type' => 'post',
    'data_type' => 'serialize',
    'show_restore' => true,
));

CSF::createSection($prefix_page_opts, array(
    'title' => '基本设置',
    'fields' => array(
        array(
            'id' => 'thumbnail',
            'type' => 'upload',
            'title' => '缩略图',
        ),
    )
));

CSF::createSection($prefix_page_opts, array(
    'title' => '布局设置',
    'fields' => array(
        array(
            'id' => 'article_layout',
            'type' => 'button_set',
            'title' => '文章布局',
            'subtitle' => '如果不是相册文章请不要选择相册样式',
            'options' => array(
                '1' => '文章布局1',
                '2' => '文章布局2',
            ),
            'default' => '1'
        ),
    )
));