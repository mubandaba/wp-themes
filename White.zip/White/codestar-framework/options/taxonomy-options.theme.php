<?php
/*****************************************************************
_____   _   _____   _____   _   _   _____       ___  ___   _____
|  _  \ | | |_   _| |_   _| | | | | | ____|     /   |/   | | ____|
| |_| | | |   | |     | |   | |_| | | |__      / /|   /| | | |__
|  _  { | |   | |     | |   |  _  | |  __|    / / |__/ | | |  __|
| |_| | | |   | |     | |   | | | | | |___   / /       | | | |___
|_____/ |_|   |_|     |_|   |_| |_| |_____| /_/        |_| |_____|

HTTPS://WWW.BITTHEME.CN/
 ****************************************************************/
?>
<?php if (! defined('ABSPATH')) {
    die;
}
if (class_exists('CSF')) {
    $prefix = 'my_taxonomy_options';
    CSF::createTaxonomyOptions($prefix, array(
        'taxonomy' => 'category',
        'data_type' => 'unserialize ',
    ));

    CSF::createSection($prefix, array(
        'title' => 'BitTheme主题拓展',
        'fields' => array(
            array(
                'id' => 'classification_layout',
                'type' => 'button_set',
                'title' => '分类布局',
                'options' => array(
                    '1' => '博客布局',
                    '2' => '图片布局',
                    '3' => '文字布局',
                ),
                'default' => '1'
            ),
        )
    ));
}