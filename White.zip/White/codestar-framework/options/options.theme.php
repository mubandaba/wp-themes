<?php
/*****************************************************************
_____   _   _____   _____   _   _   _____       ___  ___   _____
|  _  \ | | |_   _| |_   _| | | | | | ____|     /   |/   | | ____|
| |_| | | |   | |     | |   | |_| | | |__      / /|   /| | | |__
|  _  { | |   | |     | |   |  _  | |  __|    / / |__/ | | |  __|
| |_| | | |   | |     | |   | | | | | |___   / /       | | | |___
|_____/ |_|   |_|     |_|   |_| |_| |_____| /_/        |_| |_____|

HTTPS://WWW.BITTHEME.CN/
 ****************************************************************/
?>
<?php if (! defined('ABSPATH')) {
    die;
}
if (class_exists('CSF')) {
    $prefix = 'my_framework';
    CSF::createOptions($prefix, array(
        'menu_title' => 'White主题设置',
        'menu_slug' => 'white-theme-settings',
    ));

    CSF::createSection($prefix, array(
        'title' => '基本设置',
        'icon' => 'fa fa-tachometer',
        'fields' => array(
            array(
                'id' => 'website_icon',
                'type' => 'upload',
                'title' => '网站图标',
                'default' => get_bloginfo('template_url').'/static/images/website-icon.png',
                'subtitle' => '浏览器标签上的小图标',
            ),
            array(
                'id' => 'logo',
                'type' => 'upload',
                'title' => 'Logo',
                'default' => get_bloginfo('template_url').'/static/images/logo.png',
                'subtitle' => '彰显网站主题特色的标志',
            ),
            array(
                'id' => 'pop_up_menu_side_picture',
                'type' => 'upload',
                'title' => '弹出菜单侧边图片',
                'default' => get_bloginfo('template_url').'/static/images/pop-up-menu-side-picture.jpg',
                'subtitle' => '建议放上一张大气的图片，可以瞬间提升逼格',
            ),
        ),
    ));

    CSF::createSection($prefix, array(
        'title' => '首页设置',
        'icon' => 'fa fa-home',
        'fields' => array(
            array(
                'id' => 'top_heading',
                'type' => 'text',
                'title' => '顶部标题',
                'subtitle' => '建议填写网站名称',
            ),
            array(
                'id' => 'top_secondary_title',
                'type' => 'text',
                'title' => '顶部二级标题',
                'subtitle' => '建议填写网站名称',
            ),
            array(
                'id' => 'home_page_layout',
                'type' => 'button_set',
                'title' => '首页布局',
                'options' => array(
                    '1' => '博客布局',
                    '2' => '图片布局',
                    '3' => '文字布局',
                ),
                'default' => '1'
            ),
        ),
    ));


    CSF::createSection($prefix, array(
        'title' => '底部设置',
        'icon' => 'fa fa-copyright',
        'fields' => array(
            array(
                'id' => 'copyright_bittheme_switcher',
                'type' => 'switcher',
                'title' => 'BitTheme版权开关',
                'default' => true,
                'subtitle' => '关闭后，前台将看不见BitTheme的版权',
            ),
            array(
                'id' => 'website_record_no',
                'type' => 'text',
                'title' => '网站备案号',
                'subtitle' => '这个对于备案过的网站很重要',
            ),
            array(
                'id' => 'bottom_js_code',
                'type' => 'code_editor',
                'title' => '底部js代码',
                'subtitle' => '需要填写script标签',
                'settings' => array(
                    'theme' => 'monokai',
                    'mode' => 'javascript',
                ),
            ),
        ),
    ));

    CSF::createSection($prefix, array(
        'title' => '功能设置',
        'icon' => 'fa fa-cogs',
        'fields' => array(
            array(
                'id' => 'database_cleanup_optimization_plug_in',
                'type' => 'switcher',
                'title' => '数据库清理优化插件',
                'default' => false,
                'subtitle' => '关闭后，后台将没有此功能',
            ),
        ),
    ));

    CSF::createSection($prefix, array(
        'title' => 'SEO设置',
        'icon' => 'fa fa-superpowers',
        'fields' => array(
            array(
                'id' => 'website_description',
                'type' => 'textarea',
                'title' => '网站描述',
            ),
            array(
                'id' => 'website_keywords',
                'type' => 'textarea',
                'title' => '网站关键词',
            ),
            array(
                'id' => 'the_article_page_realizes_the_label_automatically_adding_inner_chain',
                'type' => 'switcher',
                'title' => '文章页实现标签自动添加内链',
                'default' => false,
                'subtitle' => '有利于SEO优化',
            ),
            array(
                'id' => 'automatically_tag_articles',
                'type' => 'switcher',
                'title' => '自动给文章添加标签',
                'default' => false,
                'subtitle' => '有利于SEO优化',
            ),
        )
    ));

    CSF::createSection($prefix, array(
        'title' => '优化设置',
        'icon' => 'fa fa-rocket',
        'fields' => array(
            array(
                'id' => 'disable_emoji_emoticon_in',
                'type' => 'switcher',
                'title' => '禁用emoji表情',
                'default' => false,
                'subtitle' => '关闭后，网站上emoji表情可能不会显示',
            ),
            array(
                'id' => 'remove_top_toolbar',
                'type' => 'switcher',
                'title' => '移除顶部工具条',
                'default' => false,
                'subtitle' => '关闭后，网站上顶部的工具条将消失',
            ),
            array(
                'id' => 'disable_rest_API',
                'type' => 'switcher',
                'title' => '禁用REST API',
                'default' => false,
                'subtitle' => '不是将WordPress作为小程序的用户建议关闭',
            ),
            array(
                'id' => 'disable_gutenberg_editor',
                'type' => 'switcher',
                'title' => '禁用古腾堡编辑器',
                'default' => true,
                'subtitle' => '默认禁用，如果开启可能会导致主题部分功能失效',
            ),
            array(
                'id' => 'disable_rest_API',
                'type' => 'switcher',
                'title' => '禁用REST API',
                'default' => false,
                'subtitle' => '不是将WordPress作为小程序的用户建议关闭',
            ),
            array(
                'id' => 'upload_file_rename_automatically',
                'type' => 'switcher',
                'title' => '上传文件自动重命名',
                'default' => false,
                'subtitle' => '不是将WordPress作为小程序的用户建议关闭',
            ),
            array(
                'id' => 'block_article_revision_function',
                'type' => 'switcher',
                'title' => '屏蔽文章修订功能',
                'default' => false,
                'subtitle' => '文章多，修订次数的用户建议关闭此功能',
            ),
            array(
                'id' => 'shield_useless_gadgets',
                'type' => 'switcher',
                'title' => '屏蔽无用小工具',
                'default' => false,
                'subtitle' => '原生的小工具一般都并没有适配样式，所以建议屏蔽掉',
            ),
        ),
    ));

    CSF::createSection($prefix, array(
        'title' => '备份 / 恢复',
        'icon' => 'fa fa-shield',
        'fields' => array(
            array(
                'type' => 'backup',
            ),
        ),
    ));

}