<?php
/*****************************************************************
_____   _   _____   _____   _   _   _____       ___  ___   _____
|  _  \ | | |_   _| |_   _| | | | | | ____|     /   |/   | | ____|
| |_| | | |   | |     | |   | |_| | | |__      / /|   /| | | |__
|  _  { | |   | |     | |   |  _  | |  __|    / / |__/ | | |  __|
| |_| | | |   | |     | |   | | | | | |___   / /       | | | |___
|_____/ |_|   |_|     |_|   |_| |_| |_____| /_/        |_| |_____|

HTTPS://WWW.BITTHEME.CN/
 ****************************************************************/
?>
<?php get_header(); ?>
<?php
$term = get_category(get_query_var('cat'));
?>
<?php if(get_term_meta( $term->term_id, 'classification_layout', true ) == 2) { ?>
<?php require get_template_directory() . '/modular/home/picture-layout.php'; ?>
<?php } elseif (get_term_meta( $term->term_id, 'classification_layout', true ) == 3) { ?>
<?php require get_template_directory() . '/modular/home/text-layout.php'; ?>
<?php } else { ?>
<?php require get_template_directory() . '/modular/home/blog-layout.php'; ?>
<?php } ?>
<?php get_footer(); ?>