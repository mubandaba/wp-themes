<?php
/*****************************************************************
_____   _   _____   _____   _   _   _____       ___  ___   _____
|  _  \ | | |_   _| |_   _| | | | | | ____|     /   |/   | | ____|
| |_| | | |   | |     | |   | |_| | | |__      / /|   /| | | |__
|  _  { | |   | |     | |   |  _  | |  __|    / / |__/ | | |  __|
| |_| | | |   | |     | |   | | | | | |___   / /       | | | |___
|_____/ |_|   |_|     |_|   |_| |_| |_____| /_/        |_| |_____|

HTTPS://WWW.BITTHEME.CN/
 ****************************************************************/
?>
<?php get_header(); ?>
                <section class="ftco-section">
                    <div class="container mt-5 text-center">
                        <div class="row justify-content-center mb-5 pb-5">
                            <div class="col-md-7 text-center heading-section ftco-animate">
                                </br>
                                </br>
                                </br>
                                <span>Sorry, the page you visited does not exist</span>
                                <h2>很抱歉，您访问的页面不存在</h2>
                            </div>
                        </div>
                        <a href="<?php echo get_option('home'); ?>" class="btn">返回首页</a>
                    </div>
                </section>
<?php get_footer(); ?>