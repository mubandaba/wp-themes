<?php
/*****************************************************************
_____   _   _____   _____   _   _   _____       ___  ___   _____
|  _  \ | | |_   _| |_   _| | | | | | ____|     /   |/   | | ____|
| |_| | | |   | |     | |   | |_| | | |__      / /|   /| | | |__
|  _  { | |   | |     | |   |  _  | |  __|    / / |__/ | | |  __|
| |_| | | |   | |     | |   | | | | | |___   / /       | | | |___
|_____/ |_|   |_|     |_|   |_| |_| |_____| /_/        |_| |_____|

HTTPS://WWW.BITTHEME.CN/
 ****************************************************************/
?>
<?php get_header(); ?>
<?php if(bittheme( 'home_page_layout' ) == 2) { ?>
<?php require get_template_directory() . '/modular/home/picture-layout.php'; ?>
<?php } elseif (bittheme( 'home_page_layout' ) == 3) { ?>
<?php require get_template_directory() . '/modular/home/text-layout.php'; ?>
<?php } else { ?>
<?php require get_template_directory() . '/modular/home/blog-layout.php'; ?>
<?php } ?>
<?php get_footer(); ?>