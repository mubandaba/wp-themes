<?php
/*****************************************************************
_____   _   _____   _____   _   _   _____       ___  ___   _____
|  _  \ | | |_   _| |_   _| | | | | | ____|     /   |/   | | ____|
| |_| | | |   | |     | |   | |_| | | |__      / /|   /| | | |__
|  _  { | |   | |     | |   |  _  | |  __|    / / |__/ | | |  __|
| |_| | | |   | |     | |   | | | | | |___   / /       | | | |___
|_____/ |_|   |_|     |_|   |_| |_| |_____| /_/        |_| |_____|

HTTPS://WWW.BITTHEME.CN/
 ****************************************************************/
?>
<?php get_header(); ?>
<?php if (have_posts()) : the_post(); update_post_caches($posts); ?>
<?php if(get_post_meta(get_the_ID(), 'my_post_options', true)['article_layout'] == 2) { ?>
<?php require get_template_directory() . '/modular/single/article-layout-2.php'; ?>
<?php } else { ?>
<?php require get_template_directory() . '/modular/single/article-layout-1.php'; ?>
<?php } ?>
<?php else : ?>
<?php endif; ?>
<?php get_footer(); ?>