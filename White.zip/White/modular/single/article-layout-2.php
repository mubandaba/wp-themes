                <section class="ftco-section contact-section">
                    <div class="container mt-5">
                        <div class="row d-flex mb-5 contact-info">
                            <div class="col-md-12 mb-4">
                                <h2 class="h4"><?php the_title(); ?></h2>
                            </div>
                            <div class="col-md-2">
                                <p><span class="iconfont icon-Watch1"></span> <?php the_time('Y年n月j日'); ?></p>
                            </div>
                            <div class="col-md-2">
                                <p><span class="iconfont icon-Avatar"></span> <?php the_author(); ?></p>
                            </div>
                            <div class="col-md-2">
                                <p><span class="iconfont icon-Comment"></span> <?php comments_popup_link('0 条评论', '1 条评论', '% 条评论', '', '评论已关闭'); ?></p>
                            </div>
                            <div class="col-md-12 mb-4">
                                <?php the_content(); ?>
                            </div>
                        </div>
<?php comments_template(); ?>
                    </div>
                </section>