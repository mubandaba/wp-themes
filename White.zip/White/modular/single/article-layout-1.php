                <section class="ftco-section">
                    <div class="container mt-5">
                        <div class="row justify-content-center mb-5 pb-5">
                            <div class="col-md-7 text-center heading-section ftco-animate">
                                <span><span class="iconfont icon-Folder_"></span> <?php the_category(', '); ?></span>
                                <h2><?php the_title(); ?></h2>
                            </div>
                        </div>
                        <div class="row d-flex justify-content-center">
                            <div class="col-md-8">
                                <?php the_content(); ?>
<?php if ( has_tag() ) { ?>
                                <div class="tag-widget post-tag-container mb-5 mt-5">
                                    <div class="tagcloud">
                                        <span class="iconfont icon-Tag"></span>
                                        <?php echo get_the_tag_list('', '', ''); ?>
                                    </div>
                                </div>
<?php } ?>

                                <div class="about-author d-flex pt-5">
                                    <div class="bio align-self-md-center mr-4">
                                        <div class="img-fluid mb-4">
                                            <?php echo get_avatar( get_the_author_email(), '120' ); ?>
                                        </div>
                                    </div>
                                    <div class="desc align-self-md-center">
                                        <h3><?php the_author(); ?></h3>
                                        <p><?php the_author_description(); ?></p>
                                    </div>
                                </div>
<?php comments_template(); ?>
                            </div>
                        </div>
                    </div>
                </section>