                <section class="ftco-section">
                    <div class="container mt-5">
                        <div class="row justify-content-center mb-5 pb-5">
                            <div class="col-md-7 text-center heading-section ftco-animate">
                                <h2><?php echo bittheme('top_heading'); ?></h2>
                                <span><?php echo bittheme('top_secondary_title'); ?></span>
                            </div>
                        </div>
                        <div class="row">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                            <div class="col-md-4 ftco-animate">
                                <div class="blog-entry">
                                    <a href="<?php the_permalink(); ?>" class="block-20" style="background-image: url('<?php bloginfo('template_url');?>/functions/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&w=950&h=500&zc=1');"></a>
                                    <div class="text p-4 d-block">
                                        <div class="meta mb-3">
                                            <div><span class="iconfont icon-Watch1"></span> <?php the_time('Y年n月j日'); ?></div>
                                            <div><span class="iconfont icon-Avatar"></span> <?php the_author(); ?></div>
                                            <div><a class="meta-chat"><span class="iconfont icon-Comment"></span> <?php comments_popup_link('0 条评论', '1 条评论', '% 条评论', '', '评论已关闭'); ?></a></div>
                                        </div>
                                         <h3 class="heading"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>

                                    </div>
                                </div>
                            </div>
<?php endwhile; ?>
<?php else : ?>
                            <h1>暂时还没有文章...</h1>
<?php endif; ?>
                        </div>
                        <div class="row mt-5">
                            <div class="col text-center">
                                <div class="block-27">
                                    <ul>
<?php par_pagenavi(5); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>