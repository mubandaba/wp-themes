                <section class="ftco-section">
                    <div class="container mt-5">
                        <div class="row justify-content-center mb-5 pb-5">
                            <div class="col-md-7 text-center heading-section ftco-animate">
                                <h2><?php echo bittheme('top_heading'); ?></h2>
                                <span><?php echo bittheme('top_secondary_title'); ?></span>
                            </div>
                        </div>
                        <div class="row no-gutters">
<?php if (have_posts()) :$ashu_i=0;?> 
<?php while (have_posts()) : the_post();$ashu_i++;?>
<?php if($ashu_i%2==1) { ?>
                            <div class="block-3 d-md-flex ftco-animate" data-scrollax-parent="true">
                                <a href="<?php the_permalink(); ?>" class="image d-flex justify-content-center align-items-center" style="background-image: url('<?php bloginfo('template_url');?>/functions/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&w=500&h=500&zc=1'); " data-scrollax=" properties: { translateY: '-30%'}">
                                    <div class="icon d-flex text-center justify-content-center align-items-center">
                                        <span class="iconfont icon-Search"></span>
                                    </div>
                                </a>
                                <div class="text">
                                    <h4 class="subheading"><span class="iconfont icon-Folder_"></span> <?php the_category(', '); ?></h4>
                                    <h2 class="heading"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                    <p><?php echo mb_strimwidth(strip_tags($post->post_content),0,250,'...'); ?></p>
                                </div>
                            </div>
<?php } else { ?>
                            <div class="block-3 d-md-flex ftco-animate" data-scrollax-parent="true">
                                <a href="<?php the_permalink(); ?>" class="image order-2 d-flex justify-content-center align-items-center" style="background-image: url('<?php bloginfo('template_url');?>/functions/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&w=500&h=500&zc=1'); " data-scrollax=" properties: { translateY: '-30%'}">
                                    <div class="icon d-flex text-center justify-content-center align-items-center">
                                        <span class="iconfont icon-Search"></span>
                                    </div>
                                </a>
                                <div class="text order-1">
                                    <h4 class="subheading"><span class="iconfont icon-Folder_"></span> <?php the_category(', '); ?></h4>
                                    <h2 class="heading"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                    <p><?php echo mb_strimwidth(strip_tags($post->post_content),0,250,'...'); ?></p>
                                </div>
                            </div>
<?php } ?>
<?php endwhile; ?>
<?php else : ?>  
                            <h1>暂时还没有文章...</h1>
<?php endif; ?>
                        </div>
                        <div class="row mt-5">
                            <div class="col text-center">
                                <div class="block-27">
                                    <ul>
<?php par_pagenavi(5); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>