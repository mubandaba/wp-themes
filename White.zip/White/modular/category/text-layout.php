                <section class="ftco-section about-section">
                    <div class="container">
                        <div class="row d-flex justify-content-end mt-5">
                            <div class="col-md-10">
                                <div class="exp mt-5 ftco-animate">
                                    <h2 class="mb-4">最新文章</h2>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                                    <div class="exp-wrap py-4">
                                        <div class="desc">
                                            <h4><a href="<?php the_permalink(); ?>" style="color:#fff"><?php the_title(); ?></a></h4>
                                            <p class="location"><?php the_category(', '); ?> - <?php the_author(); ?></p>
                                        </div>
                                        <div class="year">
                                            <p style="text-align: right;"><?php the_time('Y-n-j'); ?></p>
                                        </div>
                                    </div>
<?php endwhile; ?>
<?php else : ?>
                                    <h1>暂时还没有文章...</h1>
<?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-5">
                            <div class="col text-center">
                                <div class="block-27">
                                    <ul>
<?php par_pagenavi(5); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>