<?php if (is_active_sidebar('single_sidebar' )): ?>
	<div class="sidebar-block">
		<?php dynamic_sidebar( 'single_sidebar' ); ?>
	</div>
<?php endif; ?>