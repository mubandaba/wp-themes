<?php if (is_active_sidebar('home_sidebar' )): ?>
	<div class="sidebar-block">
		<?php dynamic_sidebar( 'home_sidebar' ); ?>
	</div>
<?php endif; ?>