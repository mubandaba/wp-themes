<form role="search" method="get" id="searchform" class="right" action="<?php bloginfo('url');?>">
	<div class="right"><input type="text" name="s" id="s"></div>
</form>