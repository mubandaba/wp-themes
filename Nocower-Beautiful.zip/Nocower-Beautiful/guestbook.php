<?php
/*
Template Name: 留言板
*/
?>
<?php get_header(); ?>
<div id="roll"><div title="回到顶部" id="roll_top"></div><div title="查看评论" id="ct"></div><div title="转到底部" id="fall"></div></div>
<div id="content">
<h2 class="page_title" style=" margin: 0px;"></h2>
<li style=" margin: 15px 0 0 0; line-height: 95px; font-size: 71px; height: 110px; color: rgb(228, 63, 63); border-bottom: 2PX dashed #EEEEEE;
padding-bottom: 10px; list-style: none; text-align: center; font-family: cursive;"><font>You Are Beautiful！</font></li>
<div id="doubanfm" style="text-align: center;margin: 33px;margin-top: 40px;height: 170px;margin-bottom: 40px;box-shadow: 0px 0px 32px 0px rgb(213, 211, 211);border-radius: 20px;padding-top: 0px;background-color:#cfcfcf;"><img src="http://www.nocower.com/images/yinxiang.png" style=" margin-right: 80px; margin-bottom: 20px;">
<iframe style="box-shadow: 0 0px 29px rgb(124, 120, 120);margin-top: -7px;border-radius: 19px;" name="iframe_canvas" src="http://douban.fm/partner/baidu/doubanradio" scrolling="no" frameborder="0" width="420" height="185"></iframe><img style=" margin-left: 80px; margin-bottom: 20px; " src="http://www.nocower.com/images/yinxiang.png"></div>
  <div style=" padding: 20px; padding-top: 0px; border-top: 2PX dashed #EEEEEE;"><?php comments_template(); ?></div>
<?php get_footer(); ?>