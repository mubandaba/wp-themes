<?php get_header(); ?>
<div id="main">
	<div class="wrap">
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<div class="post">
				<h1 class="post-title"><?php the_title() ?></h1>
				<ul class="post-meta">
					<li>发表于：<?php the_time('Y-m-j'); ?></li>
					<li class="comment-count"><?php comments_popup_link('0 条评论', ' 1 条评论', '% 条评论'); ?></li>
				</ul>
				<div class="post-content">
					<?php the_content(); ?>
				</div>
			</div>
			<div class="related_acticles">
				<h2 class="related-title">相关文章</h2>
				<div class="acticles">
					<?php echo inlo_related_acticles( get_the_ID() ); ?>
					<div class="clear"></div>
				</div>
			</div>
		<?php endwhile; endif;?>	
		<?php comments_template(); ?>
	</div>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
