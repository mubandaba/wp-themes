<!DOCTYPE HTML>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<?php inlo_head(); ?>
<!--[if IE]>
<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo('template_directory'); ?>/style_ie.css" />
<![endif]-->
</head>
<body>
<div id="header">
<div class="inlo-header">
	<div class="site-name ">
        <a id="logo" href="<?php bloginfo('url'); ?>">
            <?php bloginfo('name'); ?>
        </a>
        <p class="description"><?php bloginfo('description'); ?></p>
    </div>
    <div class="header-nav">
		<?php wp_nav_menu( array( 'theme_location' => 'primary', 'container'=> false ,'menu_class' => 'nav-menu'));?>
		<ul class="mobile-nav nav-menu">
			<li><a href="<?php echo home_url(); ?>">首页</a></li>
			<li><a href="javascript:;" id="mobile_nav">菜单</a>
				<ul class="sub-menu" id="mobile_nav_list">
				<?php 
					$category = get_categories('hierarchical=false');
					if( !empty ( $category ) ){
						foreach($category as $cate){
							echo '<li><a href="'.get_category_link($cate).'">'.$cate->name.'</a></li>';
						}
					}
				?>
				</ul>
			</li>
		</ul>
    </div>
	<form class="search" method="get" action="<?php bloginfo('url'); ?>">
		<input type="text" name="s" class="text" placeholder="<?php _e('输入关键字搜索'); ?>" />
		<button type="submit" class="submit"><?php _e('搜索'); ?></button>
     </form>
</div>
</div>
<div id="container">