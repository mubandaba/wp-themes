<?php
/**
 * 
 * @Theme INLO
 * @Theme Author INLOJV
 * @Version 1.1
 * @Author URI http://www.inlojv.com
 */

// 添加RSS
add_theme_support( 'automatic-feed-links' );

// 定义菜单
	register_nav_menus(
		array(
			'primary' => __('顶部导航菜单')
		)
	);
	
// 用wp_head加载css以及js
// 加载自定义的CSS以及JS
add_action('init', 'inlo_scripts');
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'feed_links', 2);
remove_action('wp_head', 'rsd_link' ); 
function inlo_scripts() {  
        //wp_register_script( 'default', get_template_directory_uri() . '/jquery.js', array(), '' ); 
		wp_register_script( '360libs', 'http://libs.useso.com/js/jquery/1.8.3/jquery.min.js' );
        wp_register_style( 'default', get_template_directory_uri() . '/style.css' ); 
    if ( !is_admin() ) { /** Load Scripts and Style on Website Only */
        wp_enqueue_script( '360libs' );  
        wp_enqueue_style( 'default' );  
    }  
}  

// 编辑器按钮扩展
	if (current_user_can ( 'edit_posts' )) {
		add_action ( 'admin_print_footer_scripts', 'inlo_short_code_buttons', 100 );
		
	}	
	
// 注销不支持的小工具
add_action ( 'widgets_init', 'inlojv_remove_calendar_widget' );
	function inlojv_remove_calendar_widget() {
		unregister_widget ( 'WP_Widget_Calendar' );
		unregister_widget ( 'WP_Widget_Pages' );
		unregister_widget ( 'WP_Widget_Archives' );
		unregister_widget ( 'WP_Widget_Links' );
		unregister_widget ( 'WP_Widget_Meta' );
		unregister_widget ( 'WP_Widget_Search' );
		unregister_widget ( 'WP_Widget_Text' );
		unregister_widget ( 'WP_Widget_Categories' );
		unregister_widget ( 'WP_Widget_Recent_Posts' );
		unregister_widget ( 'WP_Widget_Recent_Comments' );
		unregister_widget ( 'WP_Widget_RSS' );
		unregister_widget ( 'WP_Widget_Tag_Cloud' );
		unregister_widget ( 'WP_Nav_Menu_Widget' );
	}
	
// INLO's 全站侧栏/跟随侧栏
function inlo_widgets() {
	register_sidebar(array(
			'name' => '全站侧栏',
			'description' => __('全站侧栏，所有页面均显示'),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget' => '</section>',
			'before_title' => '<h3 class="widget-title">',
			'after_title' => '</h3>'
		));
	register_sidebar(array(
        'name' => '滚动跟随侧栏',
		'description' => __('固定跟随滚动，可放置广告'),
        'id' => 'inlo_widget_follow'
		));
	}
	add_action( 'widgets_init', 'inlo_widgets' );    

// INLO主题设置
function inlo_options($field) {
	global $inlojv_options;
	if (isset ( $inlojv_options [$field] )) {
		$options = $inlojv_options [$field];
		if (is_array ( $options )) {
			return $options;
		}
		return stripcslashes ( $options );
	}
	return null;
}

// 判断文章类型
function inlo_get_post_format() {
	$format = get_post_format ();
	return $format == '' ? 'normal' : $format;
}

// 定义字符串长度
function inlo_substr($string, $length, $replace = '…') {
	if (strlen ( $string ) < $length) {
		return $string;
	} else {
		$char = ord ( $string [$length - 1] );
		if ($char >= 224 && $char <= 239) {
			$string = substr ( $string, 0, $length - 1 );
		} else {
			$char = ord ( $string [$length - 2] );
			if ($char >= 224 && $char <= 239) {
				$string = substr ( $string, 0, $length - 2 );
			} else {
				$string = substr ( $string, 0, $length );
			}
		}
	}
	
	$starts = $start_str = $ends = array ();
	preg_match_all ( '/<\w+[^>]*>?/', $string, $starts, PREG_OFFSET_CAPTURE );
	preg_match_all ( '/<\/\w+>/', $string, $ends, PREG_OFFSET_CAPTURE );
	$cut_pos = 0;
	$last_str = '';
	if (! empty ( $starts [0] )) {
		$starts = array_reverse ( $starts [0] );
		if (! empty ( $ends [0] )) {
			$ends = $ends [0];
		}
		foreach ( $starts as $sk => $s ) {
			$auto = false;
			if ($auto != false && $auto = strripos ( $s [0], '/>' )) {
				if ($cut_pos < $auto) {
					$cut_pos = $s [1];
					$last_str = $s [0];
					unset ( $starts [$sk] );
				}
			} else {
				preg_match ( '/<(\w+).*>?/', $s [0], $start_str );
				if (! empty ( $ends )) {
					foreach ( $ends as $ek => $e ) {
						$end_str = trim ( $e [0], '</>' );
						if ($end_str == $start_str [1] && $e [1] > $s [1]) {
							if ($cut_pos < $e [1]) {
								$cut_pos = $e [1];
								$last_str = $e [0];
							}
							unset ( $ends [$ek] );
							break;
						}
					}
				} else {
					$last_str = '';
					$cut_pos = $s [1];
				}
			}
		}
	}
	$res_str = substr ( $string, 0, $cut_pos ) . $last_str;
	$less_str = substr ( $string, strlen ( $res_str ) );
	$less_pos = strpos ( $less_str, '<' );
	if ($less_pos !== false) {
		$less_str = substr ( $less_str, 0, $less_pos );
	}
	$res_str .= $less_str . $replace;
	return $res_str;
}
	

// 首页/归档分页导航
function inlo_pagenavi( $p = 5 ) {
		if ( is_singular() ) return;
		global $wp_query, $paged;
		$max_page = $wp_query->max_num_pages;
		if ( $max_page == 1 ) return;
		echo '<div class="page-navigator">';

		if ( empty( $paged ) ) $paged = 1;
		if ( $paged > 1 ) p_link( $paged - 1, '&laquo; 上一页', '&laquo; 上一页' );
		if ( $paged > $p + 2 ) echo '<li><span>...</span></li>';
		for( $i = $paged - $p; $i <= $paged + $p; $i++ ) {
			if ( $i > 0 && $i <= $max_page ) $i == $paged ? print "<li class='current'><span>{$i}</span></li>" : p_link( $i );
		}
		if ( $paged < $max_page - $p - 1 ) echo '<li><span>...</span></li>';
		if ( $paged < $max_page ) p_link( $paged + 1,'下一页 &raquo;', '下一页 &raquo;' );

		echo '</div>';
}
function p_link( $i, $title = '', $linktype = '' ) {
		if ( $title == '' ) $title = "第 {$i} 页";
		if ( $linktype == '' ) { $linktext = $i; } else { $linktext = $linktype; }
		echo "<li><a href='", esc_html( get_pagenum_link( $i ) ), "' title='{$title}'>{$linktext}</a></li>";
}
	
// 加载头部SEO
function inlo_head() {
?>
<?php if ( is_home() ) : ?><title><?php bloginfo('name'); ?> | <?php bloginfo('description'); ?></title>
<?php elseif ( is_search() ) : ?><title><?php echo $_GET['s']; ?>的搜索结果 | <?php bloginfo('name'); ?></title>
<?php elseif ( is_single() ) : ?><title><?php echo trim(wp_title('', false)); ?> | <?php bloginfo('name'); ?></title>
<?php elseif ( is_page() ) : ?><title><?php echo trim(wp_title('', false)); ?> | <?php bloginfo('name'); ?></title>
<?php elseif ( is_category() ): ?><title><?php single_cat_title(); ?> | <?php bloginfo('name'); ?></title>
<?php elseif ( is_year() ) : ?><title><?php the_time('Y年'); ?>发布的内容 | <?php bloginfo('name'); ?></title>
<?php elseif ( is_month() ) : ?><title><?php the_time('Y年n月'); ?>发布的内容 | <?php bloginfo('name'); ?></title>
<?php elseif ( is_day() ) : ?><title><?php the_time('Y年n月j日'); ?>发布的内容 | <?php bloginfo('name'); ?></title>
<?php elseif ( is_tag() ) : ?><title><?php  single_tag_title("", true); ?> | <?php bloginfo('name'); ?></title>
<?php elseif ( is_author() ):?><title><?php wp_title(''); ?>发布的所有内容 | <?php bloginfo('name'); ?></title>
<?php endif;?>
<?php 
	$keywords = inlo_options('keyword');
	$keywords = $keywords ? $keywords : get_bloginfo('name');
	$description = inlo_options('description');
	$description = $description ? $description : get_bloginfo('description');
?>
<?php if(is_single()):?>
<?php 
	$keywords = strip_tags( get_the_tag_list( '',',','') );
	$post = get_post();
	if ($post->post_excerpt) {
		$post_desc = trim( strip_tags( $post->post_excerpt ) );
		$description = inlo_substr( $post_desc, 420, '' );
	} else {
		$description = $post->post_title;
	}
?>
<?php elseif (is_category() ): ?>
<?php 
	$keywords =  single_cat_title( '', false ) ;
	$cate_desc = category_description();
	$description = $cate_desc ? strip_tags( category_description() ) . ',' . $description : $description;
?>
<?php elseif (is_tag() ): ?>
<?php 
	$keywords = single_tag_title( '', false ) ;
?>
<?php elseif (is_page() ): ?>
<?php 
	$p_title = trim ( wp_title('', false) );
	$keywords = "{$p_title}";
?>
<?php endif; ?>
<meta name="keywords" content="<?php echo $keywords; ?>" />
<meta name="description" content="<?php echo trim($description); ?>" />
<link rel="shortcut icon" href="<?php bloginfo('url'); ?>/favicon.ico" type="image/x-icon" />
<?php wp_head();?>
<?php 
}

//相关文章
function inlo_related_acticles($post_id = 0) {
	$posts = $terms = array ();
	$args = array (
			'post_status' => 'publish',
			'post__not_in' => array ( $post_id ),
			'caller_get_posts' => 1,
			'orderby' => 'rand',
			'posts_per_page' => 6 
	);
	// 与标签相关的文章
	$post_terms = wp_get_post_terms ( $post_id, 'post_tag' );
	if (! empty ( $post_terms )) {
		foreach ( $post_terms as $term ) {
			$terms [] = $term->term_id;
		}
		$args ['tag__in'] = $terms;
		$posts = query_posts ( $args );
		wp_reset_query ();
	}
	// 如果没有与标签相关的文章，获取与分类相关的文章
	if ( empty($posts) ) {
		unset ( $args ['tag__in'] );
		$post_terms = wp_get_post_terms ( $post_id, 'category' );
		if (! empty ( $post_terms )) {
			foreach ( $post_terms as $term ) {
				$terms [] = $term->term_id;
			}
			$args ['category__in'] = $terms;
			$posts = query_posts ( $args );
			wp_reset_query ();
		}
	}
	// 如果相关文章不够4篇，获取随机文章
	$count = count ( $posts );
	if ( $count < 6 ) {
		$post_not_in = array();
		if( !empty($posts) ) {
			foreach ($posts as $post) {
				$post_not_in[] = $post->ID;
			}
		}
		unset ( $args ['category__in'] );
		$args ['posts_per_page'] = 6 -$count;
		$args ['post__not_in'] = $post_not_in;
		$rand_posts = query_posts( $args );
		$posts = array_merge($posts, $rand_posts);
		wp_reset_query ();
	}
	$count = count ( $posts );
	$str = '';
	foreach ( $posts as $k => $p ) {
		$max_width = ($count == 1 || $count == 5) && $k == $count - 1 ? ' max' : null;
		$str .= '
<div class="r-post ' . $max_width . '">
	<a title="' . $p->post_title . '" href="' . get_permalink ( $p->ID ) . '" rel="bookmark">
		<p> 	&raquo;　' . inlo_substr ( $p->post_title, 600 ) . '</p>		
		<div class="clr"></div>
	</a>
</div>';
	}
	return $str;
}

// 侧栏小工具
//分类目录小工具
class Inlo_Widget_Category extends WP_Widget {
	function Inlo_Widget_Category() {
		$widget_ops = array (
				'classname' => 'Inlo_Widget_Category',
				'description' => '显示文章分类目录'
		);
		$this->WP_Widget ( 'Inlo_Widget_Category', 'INLO-文章分类目录', $widget_ops );
	}
	function form($instance) {
		$instance = wp_parse_args ( ( array ) $instance, array (
				'title' => '分类目录',				
		) );
		$title = $instance ['title'];
		$column = absint($instance ['column']);
?>
<p>
	<label for="<?php echo $this->get_field_id('title'); ?>">
		标题：<input type="text" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $title; ?>" />
	</label>
</p>
<?php
	}
	function update($new_instance, $old_instance) {
		$new_instance ['column'] = absint($new_instance ['column']);
		return $new_instance;
	}
	function widget($args, $instance) {
		$category = get_categories('hierarchical=false');
		if( !empty ( $category ) ){
			$column =' jv-cats';
			echo '<section class="widget'.$column.'">
					<h3 class="widget-title">'. $instance['title'] .'</h3><div class="post-cats">';
			foreach($category as $cate){
				$title = empty($cate->category_description) ? $cate->name : $cate->category_description;
				echo '<a title="'.$title.'" href="'.get_category_link($cate).'" class="jv-border">'.$cate->name.' <span style="color:#428BCA">['.$cate->count.']</span></a>';
			}
			echo '</div><div class="clear"></div></section>';
		}
	}
}
add_action ( 'widgets_init', create_function ( '', 'return register_widget("Inlo_Widget_Category");') );

//自定义内容小工具
class Inlo_Widget_Custom extends WP_Widget {
	function Inlo_Widget_Custom() {
		$widget_ops = array (
				'classname' => 'Inlo_Widget_Custom',
				'description' => '自定义内容，广告类'
		);
		$this->WP_Widget ( 'Inlo_Widget_Custom', 'INLO-自定义内容', $widget_ops );
	}
	function form($instance) {
		$instance = wp_parse_args ( ( array ) $instance, array (
				'title' =>	'',
				'content' => ''
		) );
		$content = $instance ['content'];
		$title = $instance ['title'];
?>
<p>
	<label for="<?php echo $this->get_field_id('title'); ?>">
		标题：<input type="text" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $title; ?>" />
	</label>
</p>	
<p>
	<label for="<?php echo $this->get_field_id('content'); ?>">
		内容: <textarea class="widefat" rows="15" id="<?php echo $this->get_field_id('content'); ?>" name="<?php echo $this->get_field_name('content'); ?>"><?php echo $content; ?></textarea>
	</label>
</p>
<?php
	}
	function update($new_instance, $old_instance) {
		return $new_instance;
	}
	function widget($args, $instance) {
		echo '<section class="widget">
					<h3 class="widget-title">'. $instance['title'] .'</h3>
					<div class="jv-custom">'. $instance ['content'] .'</div>
			 </section>';
	}
}
add_action ( 'widgets_init', create_function ( '', 'return register_widget("Inlo_Widget_Custom");') );

//侧栏登录
class jv_loginwidget extends WP_Widget {
    function jv_loginwidget() {
        $widget_ops = array('description' => '用户登录小工具');
        $this->WP_Widget('jv_loginwidget', 'INLO-用户登录', $widget_ops);
    }
    function widget($args, $instance) {
        extract($args);
?>
<section class="widget">
<?php
    global $user_ID, $user_identity, $user_email, $user_login;
    get_currentuserinfo();
    if (!$user_ID) {
?>
<h3 class="widget-title">用户登录</h3>
<div class="jv-custom">
<form class="jv-login-custom" action="<?php echo get_option('siteurl'); ?>/wp-login.php" method="post">
<p><label><span class="inlojvicon inlojvicon-user"></span> 用户名：<input class="text" type="text" name="log" id="log" value="" size="14" placeholder="输入用户名..."/></label></p>
<p><label><span class="inlojvicon inlojvicon-log-in"></span> 密　码：<input class="text" type="password" name="pwd" id="pwd" value="" size="14" placeholder="输入密码..."/></label></p>
<p><input class="login_btn" type="submit" name="submit" value="登　录" /> </p>
<p><input type="hidden" name="redirect_to" value="<?php echo $_SERVER['REQUEST_URI']; ?>"/></p>
</form>
</div>
<?php } else { ?>
<h3 class="widget-title">后台管理</h3>
<div class="jv-custom">
<div class="jv_avatar">
<?php echo get_avatar( get_the_author_meta('ID'), '65' ); ?>
</div>
<div class="jv_li">
    <li><a href="<?php bloginfo('url') ?>/wp-admin/post-new.php" rel="nofollow"><span class="inlojvicon inlojvicon-edit"></span> 撰写文章</a></li>
    <li><a href="<?php bloginfo('url') ?>/wp-admin/edit-comments.php" rel="nofollow"><span class="inlojvicon inlojvicon-comment"></span> 管理评论</a></li>
    <li><a href="<?php bloginfo('url') ?>/wp-admin/" rel="nofollow"><span class="inlojvicon inlojvicon-cog"></span> 控制面板</a></li>
    <li><a href="<?php echo wp_logout_url( $current_url ); ?>" rel="nofollow"><span class="inlojvicon inlojvicon-log-out"></span> 注销登录</a></li>
</div>
</div>
<?php } ?>
</section>
<?php	
    }
    function form($instance) {
        global $wpdb;
?>
    <p>此工具无需设置</p>
<?php
    }
}
add_action('widgets_init', 'jv_loginwidget_init');
function jv_loginwidget_init() {
    register_widget('jv_loginwidget');
}

//侧栏最新评论
class Inlo_Widget_Rcomments extends WP_Widget {
    function Inlo_Widget_Rcomments() {
        $widget_ops = array('description' => '最新评论小工具');
        $this->WP_Widget('Inlo_Widget_Rcomments', 'INLO-最新评论', $widget_ops);
    }
    function widget($args, $instance) {
        extract($args);
		global $wpdb;
        $rcnum = strip_tags($instance['rcnum']);
		$rctitle = strip_tags($instance['rctitle']);
        echo '<section class="widget widget-rcomments">';
?>
	<h3 class="widget-title"><?php echo $rctitle; ?></h3>
	<div class="rcomments-content">
	<?php
	$limit_num = $rcnum; //这里定义显示的评论数量
	$my_email = "'" . get_bloginfo ('admin_email') . "'"; //这里是自动检测博主的邮件，实现博主的评论不显示
	$rc_comms = $wpdb->get_results("
	 SELECT ID, post_title, comment_ID, comment_author, comment_author_email, comment_content
	 FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts
	 ON ($wpdb->comments.comment_post_ID = $wpdb->posts.ID)
	 WHERE comment_approved = '1'
	 AND comment_type = ''
	 AND post_password = ''
	 AND comment_author_email != $my_email
	 ORDER BY comment_date_gmt
	 DESC LIMIT $limit_num
	 ");
	$rc_comments = '';
	foreach ($rc_comms as $rc_comm) {
	$rcavatar =get_avatar ( $rc_comm->comment_author_email, 16 );
	$rc_comments .= '<li>'.$rcavatar.'<span>'.$rc_comm->comment_author.': </span><a href="'. get_permalink($rc_comm->ID).'#comment-'.$rc_comm->comment_ID.'" title="查看《'.$rc_comm->post_title. '》上的评论" rel="nofollow">'.preg_replace("/\[private\].+?\[\/private\]/","@鹳狸猿",wp_trim_words(strip_tags($rc_comm->comment_content)))."</a></li>\n";
	}
	$rc_comments = convert_smilies($rc_comments);
	echo '<ul>';
	echo $rc_comments;
	echo '</ul>';   
	?>
	</div>
<?php	
        echo "</section>\n";
    }
	
    function update($new_instance, $old_instance) {
        if (!isset($new_instance['submit'])) {
            return false;
        }
        $instance = $old_instance;
        $instance['rcnum'] = strip_tags($new_instance['rcnum']);
		$instance['rctitle'] = strip_tags($new_instance['rctitle']);
        return $instance;
    }
    function form($instance) {
        global $wpdb;
        $instance = wp_parse_args((array) $instance, array('rcnum' => '10','rctitle' => '最新评论'));
        $rcnum = strip_tags($instance['rcnum']);
		$rctitle = strip_tags($instance['rctitle']);
?>
        
        <p><label for="<?php echo $this->get_field_id('rcnum'); ?>">显示数量：<input id="<?php echo $this->get_field_id('rcnum'); ?>" name="<?php echo $this->get_field_name('rcnum'); ?>" type="text" value="<?php echo $rcnum; ?>" /></label></p>
		 <p><label for="<?php echo $this->get_field_id('rctitle'); ?>">自定义标题：<input id="<?php echo $this->get_field_id('rctitle'); ?>" name="<?php echo $this->get_field_name('rctitle'); ?>" type="text" value="<?php echo $rctitle; ?>" /></label></p>
        <input type="hidden" id="<?php echo $this->get_field_id('submit'); ?>" name="<?php echo $this->get_field_name('submit'); ?>" value="1" />
<?php
    }
}
add_action('widgets_init', 'Inlo_Widget_Rcomments_init');
function Inlo_Widget_Rcomments_init() {
    register_widget('Inlo_Widget_Rcomments');
}

//聚合面板小工具
	class Inlo_randomwidget extends WP_Widget {
    function Inlo_randomwidget() {
        $widget_ops = array('description' => '显示最新、热评、随机文章小工具');
        $this->WP_Widget('Inlo_randomwidget', 'INLO-聚合面板', $widget_ops);
    }
    function widget($args, $instance) {
        extract($args);
		global $wpdb;
		$newtitle = strip_tags($instance['newtitle']);
		$hottitle = strip_tags($instance['hottitle']);
		$randtitle = strip_tags($instance['randtitle']);
		$num = strip_tags($instance['num']);
		$days = strip_tags($instance['days']);
		$sticky = get_option( 'sticky_posts' );
		echo '<section class="widget jv-tab" id="inlo_panel" style="overflow: hidden;">';
?>
<ul class="tab-title"><span class="selected"><?php echo $newtitle; ?></span><span><?php echo $hottitle; ?></span><span><?php echo $randtitle; ?></span></ul>
<div class="tab-content" style="margin-top:29px;">
        <ul><?php $posts = query_posts(array('orderby' =>'date','showposts'=>$num,'post__not_in' =>$sticky)); while(have_posts()) : the_post(); ?> 
            <li><a class="sb-border" href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php echo wp_trim_words(get_the_title()); ?></a></li><?php endwhile; wp_reset_query(); ?>
        </ul>
        <ul class="hide">
		<?php
			$hotsql = "SELECT ID , post_title , comment_count FROM $wpdb->posts WHERE post_type = 'post' AND TO_DAYS(now()) - TO_DAYS(post_date) < $days AND ($wpdb->posts.`post_status` = 'publish' OR $wpdb->posts.`post_status` = 'inherit') ORDER BY comment_count DESC LIMIT 0 , $num ";
			$hotposts = $wpdb->get_results($hotsql);
			$hotoutput = "";
			foreach ($hotposts as $post){
			$hotoutput .= "\n<li><a class=\"sb-border\" href= \"".get_permalink($post->ID)."\" rel=\"bookmark\" title=\"".$post->post_title." (".$post->comment_count."条评论)\" >". wp_trim_words($post->post_title)."</a></li>";
			}
			echo $hotoutput;
		 ?>
	</ul>
		<ul class="hide"><?php $posts = query_posts(array('orderby' =>'rand','showposts'=>$num,'post__not_in' =>$sticky)); while(have_posts()) : the_post(); ?> 
            <li><a  class="sb-border" href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php echo wp_trim_words(get_the_title()); ?></a></li><?php endwhile; wp_reset_query(); ?>
        </ul>
    </div>
<?php	
		echo "</section>\n";
    }
     function update($new_instance, $old_instance) {
         if (!isset($new_instance['submit'])) {
             return false;
         }
         $instance = $old_instance;
         $instance['newtitle'] = strip_tags($new_instance['newtitle']);
		 $instance['hottitle'] = strip_tags($new_instance['hottitle']);
		 $instance['randtitle'] = strip_tags($new_instance['randtitle']);
		 $instance['num'] = strip_tags($new_instance['num']);
		 $instance['days'] = strip_tags($new_instance['days']);
         return $instance;
     }
    function form($instance) {
        global $wpdb;
		$instance = wp_parse_args((array) $instance, array('newtitle' => '最新文章','hottitle' => '热评文章','randtitle' => '随机文章','num' => '5','days' => '14'));
        $newtitle = strip_tags($instance['newtitle']);
		$hottitle = strip_tags($instance['hottitle']);
		$randtitle = strip_tags($instance['randtitle']);
		$num = strip_tags($instance['num']);
		$days = strip_tags($instance['days']);
?>
 <p><label for="<?php echo $this->get_field_id('newtitle'); ?>">最新文章标题：<input class="widefat" id="<?php echo $this->get_field_id('newtitle'); ?>" name="<?php echo $this->get_field_name('newtitle'); ?>" type="text" value="<?php echo $newtitle; ?>" /></label></p>
 <p><label for="<?php echo $this->get_field_id('hottitle'); ?>">热评文章标题：<input class="widefat" id="<?php echo $this->get_field_id('hottitle'); ?>" name="<?php echo $this->get_field_name('hottitle'); ?>" type="text" value="<?php echo $hottitle; ?>" /></label></p>
 <p><label for="<?php echo $this->get_field_id('randtitle'); ?>">随机文章标题：<input class="widefat" id="<?php echo $this->get_field_id('randtitle'); ?>" name="<?php echo $this->get_field_name('randtitle'); ?>" type="text" value="<?php echo $randtitle; ?>" /></label></p>
 <p><label for="<?php echo $this->get_field_id('num'); ?>">显示数量：<input class="widefat" id="<?php echo $this->get_field_id('num'); ?>" name="<?php echo $this->get_field_name('num'); ?>" type="text" value="<?php echo $num; ?>" /></label></p>
 <p><label for="<?php echo $this->get_field_id('days'); ?>">热评文章控制天数：<input class="widefat" id="<?php echo $this->get_field_id('days'); ?>" name="<?php echo $this->get_field_name('days'); ?>" type="text" value="<?php echo $days; ?>" /></label></p>
         <input type="hidden" id="<?php echo $this->get_field_id('submit'); ?>" name="<?php echo $this->get_field_name('submit'); ?>" value="1" />
<?php
    }
}
add_action('widgets_init', 'Inlo_randomwidget_init');
function Inlo_randomwidget_init() {
    register_widget('Inlo_randomwidget');
}

//标签云小工具
class Inlo_Widget_Tags extends WP_Widget {
	function Inlo_Widget_Tags() {
		$widget_ops = array (
				'classname' => 'Inlo_Widget_Tags',
				'description' => '显示标签云'
		);
		$this->WP_Widget ( 'Inlo_Widget_Tags', 'INLO-标签云', $widget_ops );
	}
	function form($instance) {
		$instance = wp_parse_args ( ( array ) $instance, array (
				'title' => '热门标签',
				'count' => 32
		) );
		$title = $instance ['title'];
		$count = $instance ['count'];
?>
<p>
	<label for="<?php echo $this->get_field_id('title'); ?>">
		标题：<input type="text" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $title; ?>" />
	</label>
</p>
<p>
	<label for="<?php echo $this->get_field_id('count'); ?>">
		显示数量: <input type="text" size="3" maxlength="2" id="<?php echo $this->get_field_id('count'); ?>" name="<?php echo $this->get_field_name('count'); ?>" value="<?php echo absint($count); ?>" />
	</label>
</p>
<?php 
	}
	function update($new_instance, $old_instance) {
		$new_instance ['count'] = absint( $new_instance ['count'] );
		return $new_instance;
	}
	function widget($args, $instance) { 
?>
<section class="widget">
	<h3 class="widget-title"><?php echo $instance ['title']; ?></h3>
	<div class="jv-tags-wrap jv-border" id="jv-tags">
		<?php wp_tag_cloud('smallest=13&largest=13&number=20&unit=px&orderby=count&order=DESC'); ?>
	</div>
</section>
<?php 
	}
}
add_action ( 'widgets_init', create_function ( '', 'return register_widget("Inlo_Widget_Tags");') );

//网站统计小工具
class widget_tongji extends WP_Widget {
	function widget_tongji() {
		$option = array('classname' => 'jv-tongji', 'description' => '网站统计' );
		$this->WP_Widget(false, 'INLO-网站统计', $option);
	}
	function widget($args, $instance) {
		extract($args, EXTR_SKIP);
		echo $before_widget;
		$title = empty($instance['title']) ? '最新评论' : apply_filters('widget_title', $instance['title']);
		$time = empty($instance['time']) ? '建站日期' : apply_filters('widget_count', $instance['time']);

		echo $before_title . $title . $after_title;
		echo '<ul class="tongji" style=" border-top: none;">';?>
			<li style="color: #6E7173;line-height: 20px;display: block;border-bottom: 1px solid #E3E3E3;padding: 5px 10px 5px 10px;">文章总数：<?php $count_posts = wp_count_posts();echo $published_posts = $count_posts->publish;?>篇</li>
            <li style="color: #6E7173;line-height: 20px;display: block;border-bottom: 1px solid #E3E3E3;padding: 5px 10px 5px 10px;">评论总数：<?php $count_comments = get_comment_count();echo $count_comments['approved'];?>条</li>
            <li style="color: #6E7173;line-height: 20px;display: block;border-bottom: 1px solid #E3E3E3;padding: 5px 10px 5px 10px;">页面总数：<?php $count_pages = wp_count_posts('page'); echo $page_posts = $count_pages->publish; ?> 个</li>
            <li style="color: #6E7173;line-height: 20px;display: block;border-bottom: 1px solid #E3E3E3;padding: 5px 10px 5px 10px;">分类总数：<?php echo $count_categories = wp_count_terms('category'); ?>个</li>
            <li style="color: #6E7173;line-height: 20px;display: block;border-bottom: 1px solid #E3E3E3;padding: 5px 10px 5px 10px;">标签总数：<?php echo $count_tags = wp_count_terms('post_tag'); ?>个</li>
            <li style="color: #6E7173;line-height: 20px;display: block;border-bottom: 1px solid #E3E3E3;padding: 5px 10px 5px 10px;">运行天数：<?php echo floor((time()-strtotime($time))/86400); ?> 天</li>
		<?php 
		echo '</ul>';
		echo $after_widget;
	}
	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['time'] = strip_tags($new_instance['time']);
		return $instance;
	}
	function form($instance) {
		$instance = wp_parse_args( (array) $instance, array( 'title' => '', 'count' => '' ) );
		$title = strip_tags($instance['title']);
		$time = strip_tags($instance['time']);

		echo '<p><label>标题：<input id="'.$this->get_field_id('title').'" name="'.$this->get_field_name('title').'" type="text" value="'.attribute_escape($title).'" size="24" /></label></p>';
		echo '<p><label>建站日期：<input id="'.$this->get_field_id('time').'" name="'.$this->get_field_name('time').'" type="text" value="'.attribute_escape($time).'" size="24" /></label></p>';
	}
}
add_action('widgets_init', create_function('', 'return register_widget("widget_tongji");'));


// 评论列表模块
function inlo_comment($comment, $args, $depth) {
  $avatar = get_avatar ( $comment->comment_author_email, 36 );
  echo '<li '; comment_class(); echo ' id="comment-'.get_comment_ID().'">';

  //头像
  echo '<div class="cl-avatar">';
    echo    $avatar;
  echo '</div>';
  //内容
  echo '<div class="cl-main" id="div-comment-'.get_comment_ID().'">';
    echo '<div class="cl-content" >';
    echo convert_smilies(get_comment_text());
    if ($comment->comment_approved == '0'){
      echo '<span class="cl-approved">（您的评论需要审核后才能显示！）</span><br />';
    }
    echo '</div>';
    //信息
    echo '<div data-no-instant><div class="cl-meta">';
            if ($comment->comment_type == '') {
    $author_link = empty ( $comment->comment_author_url ) ? null : ' href="' . $comment->comment_author_url . '"';    
    $author = $comment->comment_author;    
        echo <<<EOF
        <span class="cl-author"><a title="{$author}" rel="external nofollow" target="_blank" class="cl-author-url"{$author_link}>{$author}</a></span>        
EOF;
    }
        echo get_comment_time ( 'Y-n-j H:i' ); 
        if ($comment->comment_approved !== '0'){ 
            echo comment_reply_link( array_merge( $args, array('add_below' => 'div-comment', 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); 
        echo edit_comment_link(__('(编辑)'),' - ','');
      } 
    echo '</div></div>';
  echo '</div>';
}
// 任何添加于主题functions文件夹内的php文件都被调用到这里，与include的功能相同//////////

define('functions', TEMPLATEPATH.'/functions');
IncludeAll( functions );
function IncludeAll($dir){
    $dir = realpath($dir);
    if($dir){
        $files = scandir($dir);
        sort($files);
        foreach($files as $file){
            if($file == '.' || $file == '..'){
                continue;
            }elseif(preg_match('/.php$/i', $file)){
                include_once $dir.'/'.$file;
            }
        }
    }
} 