<?php get_header(); ?>
<div id="main">
<?php include ('posts.php'); ?>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>