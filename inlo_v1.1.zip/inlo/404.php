<?php get_header(); ?>
<div class="error-page">
	<h1 class="post-title">404 - <?php _e('页面没找到'); ?></h1>
	<p><?php _e('您想查看的页面已被转移或删除了'); ?></p>
	<p>您可以 <a href="<?php bloginfo('url'); ?>" style="color:#428bca">返回首页</a> 或者 点击右上角进行搜索</p>
</div>
<style>#nav-menu{visibility: hidden;}</style>
<?php get_footer(); ?>