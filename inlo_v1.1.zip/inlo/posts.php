<div class="post-warp">
<?php if ( have_posts() ) { ?>
<?php while ( have_posts() ) { the_post(); global $post; ?>
	<?php $post_format = inlo_get_post_format(); ?>
	<div class="post-box">
	    	<div class="post-header">			
    			<h3 class="post-title tra"><a href="<?php the_permalink(); ?>" class="ease"><?php the_title(); ?></a></h3>
    			<div class="post-date" title="发布时间"><?php the_time('Y-n-j'); ?></div>
	    	</div>
	    	<?php if ( post_password_required( $post->ID ) ) { ?>
	    	<div class="post-content">
	    		<?php echo get_the_password_form( $post->ID ); ?>
	    	</div>
	    	<?php } else { ?>
	    	<div class="post-content">		
	    		<div class="post-info">				
	    			<!--?php echo inlo_get_index_cates( $post->ID );?-->
	    		</div>
	    	<?php
	    		$desc = has_excerpt();
	    		if ( ! $desc ) {
	    			// 去掉表情 和 回复可见内容
	    			$post_content = preg_replace( '/(\s\:.*\:\s)|(<\!--inlo_hide_start-->([\s\S]*)<\!--inlo_hide_end-->)/i', '', get_the_content() );
	    			echo inlo_substr( strip_tags( $post_content ), 550, '<a href="'.get_permalink().'" class="read-more" style="margin-left:10px;color:#aaa">...</a>' ) ;
	    		} else {
	    			the_excerpt();
	    		}
	    	?>
	    	</div>
	    	<div class="clear"></div>	
	    	<?php } ?>
	</div>
<?php  } ?>
<?php } ?>
</div>
<?php echo inlo_pagenavi(); ?>