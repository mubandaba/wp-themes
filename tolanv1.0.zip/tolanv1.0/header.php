<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" class=" js csstransitions">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php bloginfo( 'charset' ); ?>">

<?php include('includes/seo.php'); ?>

<link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet" type="text/css" />
<link href="<?php bloginfo('template_url'); ?>/css/master.css" rel="stylesheet" type="text/css" />

<noscript><link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/css/noJS.css"/></noscript>
<link rel="shortcut icon" href="<?php bloginfo('template_url'); ?>/images/favicon.ico" />
<link href="<?php bloginfo('template_url'); ?>/images/LOVEUI_114_icon.png" sizes="114x114" rel="apple-touch-icon-precomposed">

<!--[if IE]> <script src="<?php bloginfo('template_url'); ?>/js/html5.js"></script> <![endif]-->
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/modernizr.custom.97074.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.hoverdir.js"></script>
<script type="text/javascript">
	$(function() {
	$(' #da-thumbs > li ').each( function() { $(this).hoverdir(); } );
});
</script>


<script type="text/javascript">
  function toueme(){
    document.getElementById("poptip").style.display="none";
    addCookie('loveui','tip',12);
  }
  function addCookie(objName,objValue,objHours) {
  var str = objName + "=" + escape(objValue);
  if(objHours > 0){
    var date = new Date();
    var ms = objHours*3600*1000;
    date.setTime(date.getTime() + ms);
    str += "; expires=" + date.toGMTString();
  }
  document.cookie = str;
}
function getCookie(objName) {
  var arrStr = document.cookie.split("; ");
  for(var i = 0;i < arrStr.length;i ++){
    var temp = arrStr[i].split("=");
    if(temp[0] == objName) return unescape(temp[1]);
  } 
}

function show_gg()
{
  t = getCookie('loveui');
  if (t != 'tip')
  {
    document.getElementById("poptip").style.display="block";
  }
}



</script>


	<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
<!-- 请置于所有广告位代码之前 -->

<?php wp_head();?>


<?php if ( is_single()  ) { ?>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/comments.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/ATheme.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/comments-ajax.js"></script>
<?php } ?>

</head>


<body>

<!--Login in-->

<div id="header" class="group">
	<div id="header-inner" class="group">
    	<div id="logo"><h1><a href="/" onfocus="this.blur()" title=""></a></h1></div>

        		     <?php
 
$defaults = array(
	'theme_location'  => '',
	'menu'            => '',
	'container'       => 'div',
	'container_class' => '',
	'container_id'    => '',
	'menu_class'      => 'nav ',
	'menu_id'         => 'nav',
	'echo'            => true,
	'fallback_cb'     => 'wp_page_menu',
	'before'          => '',
	'after'           => '',
	'link_before'     => '',
	'link_after'      => '',
	'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>',
	'depth'           => 0,
	'walker'          => ''
);
 
wp_nav_menu( $defaults );
 
?>


       
    </div>
</div>