<div id="bottom" class="group">
	<div class="foot group">
    	<div class="FtLeft">
        	<p><a href="/about">认识LOVEUI</a>　-　<a href="/help">帮助中心</a>　-　<a href="/feedback">意见反馈</a><br><br>
            HI,这里是Loveui.Cn！<br>
            社区性UI设计师作品展示网站。<br>
            联盟QQ群：101926005　业务QQ：790505790<br>
            Copyright © 2012-2013 Loveui.Cn All rights reserved. 京ICP备09067768号 <?php if ( is_home()  ) { ?><a href="http://www.newsky365.com">by 天天分享</a><?php } ?> </p>
			
            <div class="email"><a href="/">Email</a></div>
            <div class="rss"><a href="/">RSS</a></div>
			<div><?php if( dopt('d_track_b') ) echo ''.dopt('d_track').''; ?></div>
        </div>
        <div class="FtRight">
			<p>共有作品</p>
        	<span><?php $count_posts = wp_count_posts(); echo $published_posts = $count_posts->publish;?></span>
        </div>
    </div>
</div>
<?php wp_footer();?>