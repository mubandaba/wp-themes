<?php get_header(); ?>

<div id="wrap" class="group">

	
	    <div id="info" class="group">
        <p><span style="color:#333;"><?php echo get_option('d_new'); ?></span></p>
           </div>
	
	
	   <?php include('includes/headser.php'); ?>
	
	<div id="cate" data-type="meta" data-name="likes"></div>


    <div id="content" class="group">
        <div id="main" class="group">
			                 <div id="sidebar" class="group"> <?php get_sidebar(); ?>  
                     </div>   
								
					<div id="works" class="group">


                <ol id="da-thumbs" class="loveuis group da-thumbs">


<?php if ( isset($_GET['order']) )   
{   
    switch ($_GET['order'])   
    {   
        case 'rand' : $orderby = 'rand'; break;   
        case 'commented' : $orderby = 'comment_count'; break;   
        case 'alpha' : $orderby = 'title'; break;   
        default : $orderby = 'title';   
    }    
    global $wp_query;   
    $args= array('orderby' => $orderby, 'order' => 'DESC');    
    $arms = array_merge($args, $wp_query->query);   
    query_posts($arms);   
}   
//下面这句只是为标明我们添加的位置，请注意在添加时要去掉   
//或者直接用这所有代码去替换我们找到的那句代码   
if (have_posts()) : while (have_posts()) : the_post(); ?>


<!--判断是否模板-->





					                    <li class="group">
						
						<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="loveui-img">
												<img src="<?php bloginfo('template_url'); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=150&w=200&zc=1" alt="<?php the_title(); ?>" />												<div class="sus" style="display: block; left: -100%; top: 0px; transition: all 300ms ease; -webkit-transition: all 300ms ease;"><span class="stitle"><?php the_title(); ?></span><span class="sauthor"><abbr class="timeago" title="<?php echo time_since($post->post_date);?>"><?php echo time_since($post->post_date);?></abbr></span></div>

						</a>
						
						<span class="tools group">
							<span style="border-left:0;" class="toolview"><a><?php post_views(' ', ''); ?></a></span>
							<span class="toolcomments"><?php comments_popup_link ('0','1','%'); ?></span>
							

<span class="toollikes" id="wizylike-post-7738">
<?php if(function_exists('wizylike')) wizylike('button');  ?></span>						</span>


                    </li>

            <?php endwhile;endif; ?>


					                 
					                </ol>
                <div class="Page"><?php previous_posts_link(__('«Newer')) ?><?php next_posts_link(__('Older»')) ?></div>
            </div>
        </div>
         <?php include('includes/flist.php'); ?> </div>
         <div class="IndexLinkListWrap">
		<div class="moketitle" style="font-size: 16px;"><strong>友情链接</strong></div>
		<?php wp_nav_menu( array( 'theme_location' => 'footer-menu' ) ); ?>
	</div>

</div>






<?php get_footer(); ?>


</body></html>