jQuery(document).ready(function(){
    $(".comment-body").live("mouseenter mouseleave",
    function(event) {
        if (event.type == "mouseenter") {
            $(this).find(".reply").stop(false, true).fadeIn();
        } else {
            $(this).find(".reply").stop(false, true).fadeOut();
        };
    });
    $(function() {
        var o = 0;
        var timeInterval = 5000;
        var $cont = $(".tab-content ul");
        var $title = $(".tab-title span");
        $cont.hide();
        $($cont[0]).show();
        function auto() {
            o < $cont.length - 1 ? o++:o = 0;
            $cont.eq(o).fadeIn(800).siblings().hide();
            $title.eq(o).addClass("selected").siblings().removeClass("selected");
        }
        set = window.setInterval(auto, timeInterval);
    });
	

$(function($){
$body=(window.opera)?(document.compatMode=="CSS1Compat"?$('html'):$('body')):$('html,body');//修复Opera滑动异常地，加过就不需要重复加了。
$('#shang').mouseover(function(){//鼠标移到id=shang元素上触发事件
        up();
    }).mouseout(function(){//鼠标移出事件
        clearTimeout(fq);
    }).click(function(){//点击事件
        $body.animate({scrollTop:0},400);//400毫秒滑动到顶部
});
$('#xia').mouseover(function(){
        dn();
    }).mouseout(function(){
        clearTimeout(fq);
    }).click(function(){
        $body.animate({scrollTop:$(document).height()},400);//直接取得页面高度，不再是手动指定页尾ID
});
$('#comt').click(function(){
    $body.animate({scrollTop:$('#respond').offset().top},800);//滑动到id=comments元素，遇到不规范的主题需调整
});
}); 



// 文字滚动
(function($){
$.fn.extend({
Scroll:function(opt,callback){
if(!opt) var opt={};
var _this=this.eq(0).find("ul:first");
var        lineH=_this.find("li:first").height(),
line=opt.line?parseInt(opt.line,10):parseInt(this.height()/lineH,10),
speed=opt.speed?parseInt(opt.speed,10):7000, //卷动速度，数值越大，速度越慢（毫秒）
timer=opt.timer?parseInt(opt.timer,10):7000; //滚动的时间间隔（毫秒）
if(line==0) line=1;
var upHeight=0-line*lineH;
scrollUp=function(){
_this.animate({
marginTop:upHeight
},speed,function(){
for(i=1;i<=line;i++){
_this.find("li:first").appendTo(_this);
}
_this.css({marginTop:0});
});
}
_this.hover(function(){
clearInterval(timerID);
},function(){
timerID=setInterval("scrollUp()",timer);
}).mouseout();
}
})
})(jQuery);
$(document).ready(function(){
$("#bulletin").Scroll({line:1,speed:1000,timer:5000});//修改此数字调整滚动时间
});
});
function up(){
   $wd = $(window);
   $wd.scrollTop($wd.scrollTop() - 1);
   fq = setTimeout("up()", 50);
}
function dn(){
   $wd = $(window);
   $wd.scrollTop($wd.scrollTop() + 1);
   fq = setTimeout("dn()", 50);
}
