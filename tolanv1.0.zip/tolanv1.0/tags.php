<?php
/*
Template Name: Tags(标签云集)
*/
?>
<?php get_header(); ?>
<div id="wrap" class="group">
	<section class="TagBox">
	<div class="tBsearch">
    	<form method="get" id="searchform" action="/">
		<input name="s" id="s" type="text" class="tBsinput" onkeydown="if (event.keyCode==13) {}" onblur="if(this.value=='')value='搜索分类、作品';" onfocus="if(this.value=='搜索分类、作品')value='';" value="搜索分类、作品" />
		<input id="go" name="" type="submit" value="" class="tBsbutton" />
        </form>

    </div>
    <div class="tBtags">
    	<p>
		 <?php if (have_posts()) : ?>
            <?php while (have_posts()) : the_post(); ?>
			

            <?php
$tags = get_tags ();
if($tags) {
foreach ( $tags as $tag )
	echo '<a title="标签 '.$tag->name.' 下共有'.$tag->count.'篇文章" class="tag-link tag-link-'.$tag->term_id.'" href="' . get_tag_link($tag) . '">' . $tag->name .'</a>';
} ?>


			     <?php endwhile; ?>
        <?php endif; ?>
     </p>
    </div>
</section>
</div>
<?php get_footer(); ?>

</body></html>