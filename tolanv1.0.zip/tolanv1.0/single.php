<?php get_header(); ?>
<div id="wrap" class="group">
	<style>.tool-tips{float:left;line-height:32px;color:#666;}.toolview, .toolcomments, .toollikes{width:auto;padding-right:6px;font-weight:bold;color:#2DB2EA;}.tools a{color:#2DB2EA;}</style>
<section class="Post">
    <?php while ( have_posts() ) : the_post(); ?>
	<div class="Lview">
		    	<div class="Rlsuser">
			<?php echo get_avatar( get_the_author_email(), '50' ); ?>
			<h1><?php the_title(); ?></h1>
			<span>in <?php the_category(', ') ?> /by <a href="<?php bloginfo('url') ?>/author/<?php the_author() ?>"><?php the_author() ?></a> / <?php the_time('m-d'); ?></span>
 
			<div style="clear:both"></div>
		</div>
    	<div class="Lvipic">
        	<div class="Lvpleft">
				<div id="viewer-img">

                <img src="<?php bloginfo('template_url'); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=800&w=776&zc=1" alt="<?php the_title(); ?>" />  

            		
				</div>
				
				
				<div class="download" style="display:none;">
								</div>
            </div>
            <div class="Lvpright">
            	<div class="lvptool">
                	<div class="tools group" style="background:#fff;border:0;">
                        <span class="toolview" style="border-left:0;"><a title="查看"><?php post_views(' ', ' 次'); ?></a></span><div class="tool-tips">围观</div>
                        <span class="toolcomments"><?php comments_popup_link ('0','1','%'); ?></span><div class="tool-tips">口水</div>
						<span class="toollikes" id="wizylike-post-7312">
<?php if(function_exists('wizylike')) wizylike('button'); ?></span><div class="tool-tips">喜欢</div>

                       

   <?php if (function_exists('wpfp_link')) { wpfp_link(); } ?>

                       
					</div>




                </div>
				<div class="share-post">
					<div class="lvpfenx">
					
						
					<ul>
						<?php if(function_exists('wb_praise')) : ?><?php wb_praise(); ?><?php endif; ?>
							
						</ul>

				
					</div>
				</div>
                <div class="lvptags">
					<p>Tags</p>
                	 <?php the_tags('', '', ''); ?>               </div>
				


            </div>
           
            

        </div>
		<br/>
 
               <div class="Lvipic"> <?php if( dopt('d_adsite_01_b') ) echo '<div class="banner banner-site">'.dopt('d_adsite_01').'</div>'; ?></div><br/>


		<div class="Lvipic">




<div class="con">


 <?php the_content(); ?>

<br/>


</div></div><br/>

<div class="Lvipic"> <?php if( dopt('d_adsite_02_b') ) echo '<div class="banner banner-site">'.dopt('d_adsite_02').'</div>'; ?></div><br/>

		        <div class="comBox">
        	<h3>COMMENTS</h3>
			<a name="comments" id="comments"></a>
			<?php comments_template(); ?>

        </div>
    </div>
	<?php endwhile; ?>
	        <div id="sidebar" class="group" style="float:right;"><?php get_sidebar(); ?>    </div>   

</section>
<script type="text/javascript">
$(document).ready(function() {
	$('#viewer-img img').click(function() {
		$(this).toggleClass('zoomed');
		$('.Lview').toggleClass('zoomed');
		$('.Lvpleft').toggleClass('zoomed');
		$('.Lvpright').toggleClass('zoomed');
		$('.Exctxt').toggleClass('zoomed');
		$('#sidebar').toggleClass('zoomed');
		return false;
	});
});
</script>
</div>

<?php get_footer(); ?>

</body></html>