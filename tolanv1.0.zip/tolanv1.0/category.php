<?php get_header(); ?>
<div id="wrap" class="group">
	
	
	    <div id="info" class="group">
       <p><span style="color:#333;"><?php echo get_option('d_new'); ?></span></p>

    </div>
	
	  <?php include('includes/headser.php'); ?>
	
	<div id="cate" data-type="meta" data-name="likes"></div>
    <div id="content" class="group">
        <div id="main" class="group">
			                 <div id="sidebar" class="group"> <?php get_sidebar(); ?>     </div>   
								
								
								
								
								
								
								
							<div id="works" class="group">
                <ol id="da-thumbs" class="loveuis group da-thumbs">
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>		
					                    <li class="group">
						
						<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="loveui-img">
										<img src="<?php bloginfo('template_url'); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=150&w=200&zc=1" alt="<?php the_title(); ?>" />												<div class="sus" style="display: block; left: -100%; top: 0px; transition: all 300ms ease; -webkit-transition: all 300ms ease;"><span class="stitle"><?php the_title(); ?></span><span class="sauthor"><abbr class="timeago" title="<?php echo time_since($post->post_date);?>"><?php echo time_since($post->post_date);?></abbr></span></div>
						</a>
						
						<span class="tools group">
							<span style="border-left:0;" class="toolview"><a href=""><?php post_views(' ', ''); ?></a></span>
							<span class="toolcomments"><a href="<?php the_permalink(); ?>#comments" title="<?php the_title(); ?>"></a></span>
							<span class="toollikes" id="wizylike-post-7738">
<?php if(function_exists('wizylike')) wizylike('button');  ?></span>						</span>
                    </li>
<?php endwhile; ?>
	<?php else : ?>
	<p>这里好像什么文章都没有!~</p>
	<div class="b2"></div>
	<?php endif; ?>
					                 
					                </ol>
                <div class="Page"><?php next_posts_link(__('MORE')) ?></div>
            </div>
        </div>
        <?php include('includes/flist.php'); ?>   </div>
</div>
<?php get_footer(); ?>
</body></html>