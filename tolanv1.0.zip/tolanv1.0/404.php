<?php
  
// 发出404状态码
header("HTTP/1.1 404 Not Found");
header("Status: 404 Not Found");
  
// 网站信息
$blog  = get_bloginfo('name');
$site  = get_bloginfo('url') . '/';
$email = get_bloginfo('admin_email');
  
// 当前主题信息
if (!empty($_COOKIE["nkthemeswitch" . COOKIEHASH])) {
    $theme = clean($_COOKIE["nkthemeswitch" . COOKIEHASH]);
} else {
    $theme_data = wp_get_theme();
    $theme = clean($theme_data->Name);
}
  
// 访问404页面的访客
if (isset($_SERVER['HTTP_REFERER'])) {
    $referer = clean($_SERVER['HTTP_REFERER']);
} else {
    $referer = "undefined";
}
// 请求的URL
if (isset($_SERVER['REQUEST_URI']) && isset($_SERVER["HTTP_HOST"])) {
    $request = clean('http://' . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
} else {
    $request = "undefined";
}
// 查询字符串
if (isset($_SERVER['QUERY_STRING'])) {
    $string = clean($_SERVER['QUERY_STRING']);
} else {
    $string = "undefined";
}
// IP地址
if (isset($_SERVER['REMOTE_ADDR'])) {
    $address = clean($_SERVER['REMOTE_ADDR']);
} else {
    $address = "undefined";
}
//用户代理
if (isset($_SERVER['HTTP_USER_AGENT'])) {
    $agent = clean($_SERVER['HTTP_USER_AGENT']);
} else {
    $agent = "undefined";
}
//身份
if (isset($_SERVER['REMOTE_IDENT'])) {
    $remote = clean($_SERVER['REMOTE_IDENT']);
} else {
    $remote = "undefined";
}
//日志时间
$time = clean(date("F jS Y, h:ia", time()));
  
function clean($string) {
    $string = rtrim($string);
    $string = ltrim($string);
    $string = htmlentities($string, ENT_QUOTES);
    $string = str_replace("\n", "<br>", $string);
  
    if (get_magic_quotes_gpc()) {
        $string = stripslashes($string);
    }
    return $string;
}
  

  
?>

<?php get_header(); ?>
<div id="wrap" class="group">
	
	
	    <div id="info" class="group">
        <p><span style="color:#333;"><?php echo get_option('cool_announce'); ?></span>分享出来，我们为您提供发布和展示。</p>

    </div>
	
	  <?php include('includes/headser.php'); ?>
	
	<div id="cate" data-type="meta" data-name="likes"></div>
    <div id="content" class="group">
        <div id="main" class="group">
			                 <div id="sidebar" class="group"> <?php get_sidebar(); ?>     </div>   
								
								
								
								
								
								
								
							<div id="works" class="group">
                 <div style="text-align:center;padding:60px 0;font-size:16px;">
		<h2 style="font-size:60px;margin-bottom:32px;">404 . Not Just An Error</h2>
		抱歉，沒有找到您需要的内容！！
	</div>
	<div>给您推荐以下内容：</div><br/>

                <ol id="da-thumbs" class="loveuis group da-thumbs">
				<?php $recent = new WP_Query("cat=1&showposts=10"); while($recent->have_posts()) : $recent->the_post();?>	
					                    <li class="group">
						
						<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="loveui-img">
										<img src="<?php bloginfo('template_url'); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=150&w=200&zc=1" alt="<?php the_title(); ?>" />												<div class="sus" style="display: block; left: -100%; top: 0px; transition: all 300ms ease; -webkit-transition: all 300ms ease;"><span class="stitle"><?php the_title(); ?></span><span class="sauthor"><abbr class="timeago" title="<?php echo time_since($post->post_date);?>"><?php echo time_since($post->post_date);?></abbr></span></div>
						</a>
						
						<span class="tools group">
							<span style="border-left:0;" class="toolview"><a href=""><?php post_views(' ', ''); ?></a></span>
							<span class="toolcomments"><a href="<?php the_permalink(); ?>#comments" title="<?php the_title(); ?>"></a></span>
							<span class="toollikes" id="wizylike-post-7738">
<?php if(function_exists('wizylike')) wizylike('button');  ?></span>						</span>
                    </li>
<?php endwhile; ?>
					                 
					                </ol>
                <div class="Page"><?php next_posts_link(__('MORE')) ?></div>
            </div>
        </div>
        <?php include('includes/flist.php'); ?>   </div>
</div>
<?php get_footer(); ?>
</body></html>