	<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package WordPress
 * @subpackage Twenty_Eleven
 * @since Twenty Eleven 1.0
 */

get_header(); ?>

 <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div id="wrap" class="group">
	
	
		
	    <style>
#wrap{padding-top:0px;}
#works{float:left;}
#sidebar{float:right;}
</style>
	
    <div id="content" class="group">
        <div id="main" class="group">



	      <div id="sidebar" class="group"><?php get_sidebar(); ?>  
								
            </div>      



        	
        <div id="works" class="group">

                <ol id="da-thumbs" >
											<div style="margin:18px 0 0 22px;color:#666;border:1px solid #eee;background:#fff;padding:15px;"><?php the_content(__('Read More'));?></div>
					                </ol>
                            </div>

            

        </div>
        <?php include('includes/flist.php'); ?>   </div>
</div>
 <?php endwhile; endif;?>   
<?php get_footer(); ?>

</body></html>