	<?php
/**
 * The template for displaying Author Archive pages.
 *
 */

get_header(); ?>


<div id="wrap" class="group">
	
	
		
	    <style>
#wrap{padding-top:0px;}
#works{float:left;}
#sidebar{float:right;}
</style>
	
    <div id="content" class="group">
        <div id="main" class="group">



	      <div id="sidebar" class="group">
								<?php get_sidebar(); ?> 
            </div>      



        	
        <div id="works" class="group">



        <ol id="da-thumbs" class="loveuis group">
           <?php if (have_posts()) : ?>	
           <?php while ( have_posts() ) : the_post(); ?>
					              
					                    <li class="group">
						
						<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="loveui-img">
												<img src="<?php bloginfo('template_url'); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=150&w=200&zc=1" alt="<?php the_title(); ?>" />												<div class="sus" style="display: block; left: -100%; top: 0px; transition: all 300ms ease; -webkit-transition: all 300ms ease;"><span class="stitle"><?php the_title(); ?></span><span class="sauthor"><abbr class="timeago" title="<?php echo time_since($post->post_date);?>"><?php echo time_since($post->post_date);?></abbr></span></div>

						</a>
						
						<span class="tools group">
							<span style="border-left:0;" class="toolview"><a><?php post_views(' ', ''); ?></a></span>
							<span class="toolcomments"><?php comments_popup_link ('0','1','%'); ?></span>
							

<span class="toollikes" id="wizylike-post-7738">
<?php if(function_exists('wizylike')) wizylike('button');  ?></span>						</span>


                    </li>
					      <?php endwhile; ?>
					        <?php endif; ?>
					                </ol>

                <div class="Page"><?php previous_posts_link(__('«Newer')) ?><?php next_posts_link(__('Older»')) ?></div>


        </div>

            

        </div>
        <?php include('includes/flist.php'); ?>   </div>
</div>

<?php get_footer(); ?>

</body></html>