 <div id="toBox">
        <div id="intool" class="group">
            <div class="search">
            <form method="get" id="searchform" action="/">
            <input type="text" value="搜索分类、作品" onfocus="if(this.value=='搜索分类、作品')value='';" onblur="if(this.value=='')value='搜索分类、作品';" onkeydown="if (event.keyCode==13) {}" class="sinput" id="s" name="s">
            <input id="go" name="" type="submit" value="" class="sbutton" />
            </form>

            </div>
			            <div class="poeve">

                <li><a title="随机评论" <?php if ( isset($_GET['order']) && ($_GET['order']=='rand') ) echo 'class="current"'; ?> href="/?order=rand">随机评论</a></li>

                <li><a  title="最受欢迎" <?php if ( isset($_GET['order']) && ($_GET['order']=='commented') ) echo 'class="current"'; ?> href="/?order=commented">最受欢迎</a></li>

                <li><a title="最新推荐" <?php if ( isset($_GET['order']) && ($_GET['order']=='alpha') ) echo 'class="current"'; ?> href="/?order=alpha">最新推荐</a></li>

		

		       

                        <li><a class="pactive" href="/" title="最新作品">最新作品</a></li>
                        


				<div id="poptip"><span class="poptip-arrow poptip-arrow-bottom"><em>◆</em><i>◆</i></span>最新作品在这里哦~　　<a href="javascript:void(0);" onclick="toueme();" title="关闭提示">知道了</a></div>
				<script>show_gg();</script>
            </div>

        </div>
    </div>