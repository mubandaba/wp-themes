






<div class="s-box">
                    <div class="group">
                        <div class="postBtn"><a title="<?php echo $instance['title']; ?>" href="<?php echo $instance['titles']; ?>"><div class="pb"></div><?php echo $instance['title']; ?></a></div>
                        
                       <p>

						<?php wp_tag_cloud('smallest=12&largest=18&unit=px&number='.$bqs.'&orderby=count&order=DESC');?>
                            

                        <div class="navBtn"><a title="<?php echo $instance['title']; ?>" href="<?php echo $instance['title2s']; ?>"><div class="nb"></div><?php echo $instance['title2']; ?></a></div>
                        <div class="helpBtn"><a title="<?php echo $instance['title3']; ?>" target="_blank" href="<?php echo $instance['title3s']; ?>"><div class="hb"></div><?php echo $instance['title3']; ?></a></div>
                    </div>
                    <div class="s-line"></div>
                  
                </div>