


<div class="s-box">
  <ul class="excli group" >
                        <h2><?php echo $instance['title']; ?></h2>
<?php query_posts('orderby=rand&caller_get_posts=1&showposts='.$suijs.''); ?>
<?php while (have_posts()) : the_post(); ?>
                        <li><a href="<?php the_permalink() ?>" title='<?php the_title() ?>'><img src="<?php bloginfo('template_url'); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=90&w=120&zc=1"></a></li>
                        <?php endwhile;?>
                    </ul>
   
   <div class="both:clear;"></div>
             
    </div>

