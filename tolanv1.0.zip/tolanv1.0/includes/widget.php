<?php

//边栏小工具

if ( function_exists('register_sidebar') ) {
	register_sidebar(array(
		'name' => '首页边栏',
		'before_widget' => '<div class="t %2$s">',
		'after_widget' => '</div></div>',
		'before_title' => '<div class="hc"><span>',
		'after_title' => '</span></div><div class="h_widget cl">',
		));
}

if ( function_exists('register_sidebar') ) {
	register_sidebar(array(
		'name' => '文章页面边栏',
		'before_widget' => '<div class="t %2$s">',
		'after_widget' => '</div></div>',
		'before_title' => '<div class="hc"><span>',
		'after_title' => '</span></div><div class="h_widget cl">',
		));
}

if ( function_exists('register_sidebar') ) {
	register_sidebar(array(
		'name' => '其他页面边栏',
		'before_widget' => '<div class="t %2$s">',
		'after_widget' => '</div></div>',
		'before_title' => '<div class="hc"><span>',
		'after_title' => '</span></div><div class="h_widget cl">',
		));
}

// 读者排行
class widget_readers extends WP_Widget{
	function widget_readers(){
		$widget_options = array('classname'=>'set_contact','description'=>'H-读者排行');
		$this->WP_Widget(false,'H-读者排行',$widget_options);
	}
	 function form($instance) {
?>
<p>
			<label>
				标题名称：
				<input id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $instance['title']; ?>" class="widefat" />
			</label>
		</p>
		<p>
			<label>
				不想显示(名称)：
				<input id="<?php echo $this->get_field_id('name'); ?>" name="<?php echo $this->get_field_name('name'); ?>" type="text" value="<?php echo $instance['name']; ?>" class="widefat" />
			</label>
			<label>
				显示的时间(最近多少天)：
				<input id="<?php echo $this->get_field_id('times'); ?>" name="<?php echo $this->get_field_name('times'); ?>" type="text" value="<?php echo $instance['times']; ?>" class="widefat" />
			</label>
			<label>
				显示个数：
				<input id="<?php echo $this->get_field_id('ges'); ?>" name="<?php echo $this->get_field_name('ges'); ?>" type="text" value="<?php echo $instance['ges']; ?>" class="widefat" />
			</label>
			
		</p>
<?php
	}
	function widget($args,$instance){
		 extract($args);
                             $title = strip_tags($instance['title']);
							 $name = strip_tags($instance['name']);
							 $times = strip_tags($instance['times']);
		                     $ges = strip_tags($instance['ges']);
							
		include("widget/side_reader.php");
	}}
	add_action('widgets_init',create_function('', 'return register_widget("widget_readers");'));



//标签云
			class widget_tags extends WP_Widget{
				function widget_tags(){
					$widget_options = array('classname'=>'set_contact','description'=>'H-标签云');
					$this->WP_Widget(false,'H-标签云',$widget_options);
				}
                  function form($instance) {
?>
<p>
			<label>
				标题1名称：
				<input id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $instance['title']; ?>" class="widefat" />
			</label>
			<label>
				标题1链接：
				<input id="<?php echo $this->get_field_id('titles'); ?>" name="<?php echo $this->get_field_name('titles'); ?>" type="text" value="<?php echo $instance['titles']; ?>" class="widefat" />
			</label>
			<label>
				标题2名称：
				<input id="<?php echo $this->get_field_id('title2'); ?>" name="<?php echo $this->get_field_name('title2'); ?>" type="text" value="<?php echo $instance['title2']; ?>" class="widefat" />
			</label>
			<label>
				标题2链接：
				<input id="<?php echo $this->get_field_id('title2s'); ?>" name="<?php echo $this->get_field_name('title2s'); ?>" type="text" value="<?php echo $instance['title2s']; ?>" class="widefat" />
			</label>
			<label>
				标题3名称：
				<input id="<?php echo $this->get_field_id('title3'); ?>" name="<?php echo $this->get_field_name('title3'); ?>" type="text" value="<?php echo $instance['title3']; ?>" class="widefat" />
			</label>
			<label>
				标题3链接：
				<input id="<?php echo $this->get_field_id('title3s'); ?>" name="<?php echo $this->get_field_name('title3s'); ?>" type="text" value="<?php echo $instance['title3s']; ?>" class="widefat" />
			</label>
		</p>
		<p>
			<label>
				文章标签数：
				<input id="<?php echo $this->get_field_id('bqs'); ?>" name="<?php echo $this->get_field_name('bqs'); ?>" type="text" value="<?php echo $instance['bqs']; ?>" class="widefat" />
			</label>
		</p>
<?php
	}


				function widget($args,$instance){
					 extract($args);
                             $title = strip_tags($instance['title']);
							 $titles = strip_tags($instance['titles']);
							 $title2 = strip_tags($instance['title2']);
							 $title2s = strip_tags($instance['title2s']);
							 $title3 = strip_tags($instance['title3']);
							 $title3s = strip_tags($instance['title3s']);
		                     $bqs = strip_tags($instance['bqs']);
					include("widget/side_tags.php");
				}}
				add_action('widgets_init',create_function('', 'return register_widget("widget_tags");'));





// ad推荐
						class widget_ad extends WP_Widget{
							function widget_ad(){
								$widget_options = array('classname'=>'set_contact','description'=>'H-AD推荐');
								$this->WP_Widget(false,'H-AD推荐',$widget_options);
							}
							   function form($instance) {
?>
<p>
			<label>
				广告名称：
				<input id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $instance['title']; ?>" class="widefat" />
			</label>
		</p>
		<p>
			<label>
				广告代码：
				<textarea id="<?php echo $this->get_field_id('code'); ?>" name="<?php echo $this->get_field_name('code'); ?>" class="widefat" rows="12" style="font-family:Courier New;"><?php echo $instance['code']; ?></textarea>
			</label>
		</p>
<?php
	}

							function widget($args,$instance){
                                 extract($args);
                             $title = strip_tags($instance['title']);
		                     $code = strip_tags($instance['code']);
								include("widget/side_ad.php");

							}}
							add_action('widgets_init',create_function('', 'return register_widget("widget_ad");'));
// 随机推荐
						class widget_rand extends WP_Widget{
							function widget_rand(){
								$widget_options = array('classname'=>'set_contact','description'=>'H-随机推荐');
								$this->WP_Widget(false,'H-随机推荐',$widget_options);
							}
							  function form($instance) {
?>
<p>
			<label>
				标题名称：
				<input id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $instance['title']; ?>" class="widefat" />
			</label>
		</p>
		<p>
			<label>
				随机推荐数：
				<input id="<?php echo $this->get_field_id('suijs'); ?>" name="<?php echo $this->get_field_name('suijs'); ?>" type="text" value="<?php echo $instance['suijs']; ?>" class="widefat" />
			</label>
		</p>
<?php
	}
							function widget($args,$instance){
								 extract($args);
                             $title = strip_tags($instance['title']);
		                     $suijs = strip_tags($instance['suijs']);
								include("widget/side_rand.php");
							}}
							add_action('widgets_init',create_function('', 'return register_widget("widget_rand");'));


               



//注销多余的小工具
							add_action( 'widgets_init', 'my_unregister_widgets' );   
							function my_unregister_widgets() {           
								unregister_widget( 'WP_Widget_Recent_Comments' );   
                                unregister_widget( 'WP_Widget_Recent_Posts' );
	                            unregister_widget( 'WP_Widget_RSS' );   
								unregister_widget( 'WP_Widget_Search' );   
								unregister_widget( 'WP_Widget_Tag_Cloud' );    
								unregister_widget( 'WP_Nav_Menu_Widget' );   
							    unregister_widget('WP_Widget_Text');
								unregister_widget('WP_Widget_Pages');
								unregister_widget('WP_Widget_Archives');
								unregister_widget('WP_Widget_Meta');
								unregister_widget('WP_Widget_Categories');
								unregister_widget('WP_Widget_Calendar');
							}  

							?>