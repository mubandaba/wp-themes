<?php

/*
 *前台登录
 */

/*Template Name: Login*/
 
ini_set('display_errors', false);
 
if (is_user_logged_in()){
//重定向浏览器
wp_safe_redirect( get_option('home') );
//确保重定向后，后续代码不会被执行
exit;
}
 
$redirect_to = sanitize_user( $_REQUEST['redirect_to'] );
if( !empty($_POST['csyor_login']) ) {
$error = '';
$sanitized_user_login = sanitize_user( $_POST['user_login'] );
$rememberme = $_POST['rememberme']?true:false;
$user_pass = $_POST['user_pass'] ;
$comment_aaa      	  = ( isset($_POST['aaa']) ) ? trim($_POST['aaa']) : '0';
$comment_bbb          = ( isset($_POST['bbb']) ) ? trim($_POST['bbb']) : '0';
$comment_subab        = ( isset($_POST['subab']) ) ? trim($_POST['subab']) : '0';
 
global $wp_hasher;  
if ( $sanitized_user_login == '' ) {
$error .= '<strong>错误</strong>：请输入您的登陆账号。';
}elseif ( !username_exists( $sanitized_user_login ) ) {
$error .= '<strong>错误</strong>：该用户名不存在，赶紧注册一个吧。';
}elseif($user_pass == ''){
$error .= '<strong>错误</strong>：请输入您的登录密码。';
}elseif(((int)$comment_subab)!=(((int)$comment_aaa)+((int)$comment_bbb))){
$error .= '<strong>错误</strong>：请输入正确的验证数字。';	
}elseif ( empty($wp_hasher) ) {  
require_once( './wp-includes/class-phpass.php');  
$wp_hasher = new PasswordHash(8, TRUE);  
$pass = get_user_pass($sanitized_user_login);
$data = $wp_hasher->CheckPassword($user_pass,$pass);  
	if($data){
		$user = get_userdatabylogin($sanitized_user_login);
		$user_id = $user->ID;
		// 自动登录
		wp_set_current_user($user_id, $user_login);
		wp_set_auth_cookie($user_id,$rememberme);
		do_action('wp_login', $user_login);
		
		wp_safe_redirect( $redirect_to );  
	}else{
		$error .= '<strong>错误</strong>：登陆账号和密码不匹配。';	
	}  
} 
 
}
 
get_header(); ?>

<?php get_header('top'); ?>

<div id="main" class="container" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">

<div class="row">

		<article id="content" class="col-lg-12 col-md-8 single" data-post-id="<?php the_ID(); ?>" role="article" itemscope itemtype="http://schema.org/Article">

			<div class="panel panel-default">
				<div class="entry-breadcrumb clearfix" role="toolbar"><span class="glyphicon glyphicon-home" style="margin-right:8px"></span><?php momo_breadcrumb_html(get_the_ID(),'&nbsp› &nbsp'); ?></div>
				<div class="panel-body" style="padding-bottom:100px;">

					<div class="col-lg-8 col-md-6 col-sm-12" style="margin:0 auto;float:none;"  itemprop="articleBody" data-no-instant>
						<div class="col-lg-6">
							<div style="width:90%">
								<div class="ludou-login" style="text-align:center;font-size:28px;font-weight:bold;margin: 50px auto 10px;">登录</div>

									<?php if(!empty($error)) {
									echo '<p class="ludou-error">'.$error.'</p>';
									}

									if (!is_user_logged_in()) { ?>

									

									<form id="loginform" class="ludou-login" action="<?php echo $_SERVER["REQUEST_URI"]; ?>" method="post">


									<p><input type="text" name="user_login" id="log" class="input" value="<?php if(!empty($sanitized_user_login)) echo $sanitized_user_login; ?>" placeholder="<?php _e('用户名 &hellip;','momo');?>" />
									</p>


									<p><input id="pwd" class="input" type="password" value="" name="user_pass" placeholder="<?php _e('密码 &hellip;','momo');?>"/>
									</p>

									<p>
									<?php $aaa=rand(0,9); $bbb=rand(1,9); ?>
									<input type="text" class="input" name="subab" id="subab" size="30" tabindex="3" placeholder="验　证：请输入计算结果：<?php echo $aaa; ?>+<?php echo $bbb; ?>=? "/>
									</p>

									<input name="aaa" value="<?php echo $aaa; ?>" type="hidden" />
									<input name="bbb" value="<?php echo $bbb; ?>" type="hidden" />

									<p class="forgetmenot" style="margin-top:25px;margin-bottom:33px;">

									<label for="rememberme">

									<input name="rememberme" type="checkbox" id="rememberme" value="1" <?php checked( $rememberme ); ?> />

									记住我

									</label>

									<span style="float:right;"><a href="<?php echo home_url('/wp-login.php?action=lostpassword/'); ?>">忘记密码？</a></span>

									</p>

									<p class="login-submit">

									<input type="hidden" name="redirect_to" value="<?php echo $_SERVER['REQUEST_URI']; ?>"/>
									<input type="hidden" name="csyor_login" value="ok" />

									<input name="submit" id="wp-submit" class="button-primary" value="登录" type="submit" style="margin-top:0px!important;">

									</p>


								
	

									<div style="margin:15px auto;text-align:center;">还没有账号？<a href="<?php echo home_url('/register/'); ?>">注册</div>

									</form>

									<?php } else {

									echo '<p class="ludou-error">您已登录！（<a href="'.wp_logout_url( $url_this).'" title="登出">登出？</a>）</p>';
									} ?>
							</div>
						</div>
						
						
						<div class="col-lg-6 col-md-6 col-sm-12" >
							<div class="loginpage" style="">
							<div style="margin:15px auto;font-size:13px;width:200px;">无需注册，使用新浪微博账号登录</div>			
							<?php $qq_open = intval(get_option('dmeng_open_qq',0));
							if ($qq_open){ ?>
							<a href="<?php echo  dmeng_get_open_login_url('qq', 'login', dmeng_get_current_page_url()); ?>"><div class="loginqq">QQ账号登录</div></a>
							<?php 
							}
							$weibo_open = intval(get_option('dmeng_open_weibo',0));
							if ($weibo_open){
							?>
							<a href="<?php echo  dmeng_get_open_login_url('weibo', 'login', dmeng_get_current_page_url()); ?>"><div class="loginweibo">新浪微博账号登录</div></a>
							<?php } ?>
							</div>
						</div>
						
						
					</div>

					

					

				</div>

	

			</div>

			

		 </article><!-- #content -->		

		

		

	

	</div>




 </div><!-- #main -->

<?php get_footer('colophon'); ?>

<?php get_footer(); ?>