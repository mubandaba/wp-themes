<?php
/*
 * 亲，如果您喜欢本主题，请上http://www.wpmomo.com发表留言，或者加我QQ45134691探讨问题
 */
get_header(); ?>
<?php get_header('top'); ?>
<div id="main" class="container" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">

	<div class="row">
			<?php
				while ( have_posts() ) : the_post();
			?>
			<article id="content" class="col-lg-12" data-post-id="<?php the_ID(); ?>" role="article" itemscope itemtype="http://schema.org/Article">
				<div>
					<div class="entry-breadcrumb clearfix" role="toolbar"><span class="glyphicon glyphicon-home" style="margin-right:8px"></span><?php momo_breadcrumb_html(get_the_ID(),'&nbsp› &nbsp'); ?>
					</div>

					<div class="entry-header page-header">
						<h1 class="entry-title" itemprop="name"><?php echo apply_filters( 'dmeng_the_title', esc_html(get_the_title()) );?><?php if( is_preview() || current_user_can('edit_post', get_the_ID()) ) echo ' <small><a href="'.get_edit_post_link().'" data-no-instant>'.__('Edit This').'</a></small>'; ?></h1>
						<?php momo_post_meta();?>
					</div>

					<?php global $post;
						if ($post->post_excerpt) {
						echo '<div class="excerpt">';
							$excerpt= $post->post_excerpt;
 							echo $excerpt;
						echo '</div>';
					}
					?>

					<div class="entry-content"  itemprop="articleBody" data-no-instant>
						<?php the_content();?>
						<?php momo_post_page_nav(); ?>
					</div>

					<div style="border-top:1px solid #ddd;padding:20px 0;margin:20px 0 50px 0;">
					<?php momo_post_footer();?>
					</div>

					<div class="clearfix"></div>
				</div>

				<div class="<?php echo apply_filters('dmeng_comment_panel_class','panel panel-default');?>" id="comments" data-no-instant><?php comments_template( '', true ); ?>
				</div>

				<?php
				$prev_post = get_previous_post(true);
				if (!empty( $prev_post )) {
				?>

				<span id="nav_prev"><a href="<?php echo get_permalink( $prev_post->ID ); ?>" title="上一篇：<?php echo $prev_post->post_title; ?>">‹</a></span>

				<?php }
				$next_post = get_next_post(true);
				if ( is_a( $next_post , 'WP_Post' ) ) {
				?>
				<span id="nav_next"><a href="<?php echo get_permalink( $next_post->ID ); ?>" title="下一篇：<?php echo get_the_title( $next_post->ID ); ?>">›</a></span>
				<?php } ?>

		 	</article><!-- #content -->

		 	<?php
			endwhile; // end of the loop.
			momo_paginate();
			?>

	</div>
 </div><!-- #main -->
<?php get_footer('colophon'); ?>
<?php get_footer(); ?>
