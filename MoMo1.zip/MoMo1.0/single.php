<?php
/*
 *文章页面
 */
get_header(); ?>
<?php get_header('top'); ?>
<div id="main" class="container" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">
	<div class="row">
		<?php 
		
		while ( have_posts() ) : the_post();
			get_template_part('content');
			
		endwhile;
		//momo_paginate();
		?>
		<?php get_sidebar();?>
	</div>
</div><!-- #main -->
<?php get_footer('colophon'); ?>
<?php get_footer(); ?>