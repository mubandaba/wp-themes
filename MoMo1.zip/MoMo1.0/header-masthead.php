<?php

/*
 * 亲，如果您喜欢本主题，请上http://www.wpmomo.com与发表留言
 */

$header_content = '';

$custom_header = momo_custom_header(); //顶部左侧内容

if( $custom_header ){
	
	$profile_li = '<div class="l_x" id="weibo"><a href=""></a></div>
	<div class="l_x" id="qq"><a href=""></a></div>
	<div class="l_x" id="weixin"><a href=""></a></div>';

	$current_user = wp_get_current_user();

	$email_tips = '';

	//如果登录，使用用户头像，如果未登录，使用avatar.png作为头像
	if( $current_user->exists() ){
		$author_url = get_edit_profile_url($current_user->ID);
		$avatar_url = momo_get_avatar( $current_user->ID , '32' , momo_get_avatar_type($current_user->ID), true );
		if( ! is_email($current_user->user_email) ){
			$email_tips =  'data-toggle="tooltip" data-placement="left" title="'.__('请添加正确的邮箱以保证账户安全','momo').'"';
			$author_url .= '#pass';
		}
		if( $current_user->user_email != $current_user->dmeng_verify_email ){
			$email_tips =  'data-toggle="tooltip" data-placement="left" title="'.__('请验证一个邮箱用以接收通知','momo').'"';
			$author_url .= '#pass';
		}
		//$profile_li .= '<div class="l_x"><a href="'.get_edit_profile_url($current_user->ID).'">'.$avatar_url.'</a></div>';
		$avatar_html = $avatar_url ? sprintf('<div class="l_x"><a href="%s" class="avatar"%s>%s</a></div>', $author_url, $email_tips, $avatar_url) : '';
	}else{
		//$profile_li .= '<div class="l_x"><a data-toggle="modal" data-target="#myModal" style="cursor:pointer"><img class="avatar" src="'.get_template_directory_uri().'/images/avatar.png'.'"></a></div>';
		$avatar_html = '<div class="l_x"><a data-toggle="modal" data-target="#myModal" style="cursor:pointer"><img class="avatar" src="'.get_template_directory_uri().'/images/avatar.png'.'"></a></div>';
	}

	$header_content = '<section id="top"><div class="container header-content"><div class="row">';
	$header_content .= '<div class="col-lg-4 col-md-4 col-sm-4 col-xs-6">'.$custom_header.'</div>';
	$header_content .= '<div class="col-lg-4 col-md-4 col-sm-4">'.get_search_form($true).'</div>';
	$header_content .= '<div class="col-lg-4 col-md-4 col-sm-4 col-xs-6">'. $profile_li.$avatar_html.'</div>';
	$header_content .= '</div></div></section>';
}

?>


<?php
	$name = 'login'; //登录page别名
	global $wpdb;
	$page_id = $wpdb->get_var("SELECT ID FROM $wpdb->posts WHERE post_name = '$name'");
	$loginpermalink = get_permalink($page_id);

	$name1 = 'register'; //注册page别名
	global $wpdb;
	$page_id = $wpdb->get_var("SELECT ID FROM $wpdb->posts WHERE post_name = '$name1'");
	$registerpermalink = get_permalink($page_id);
?>
<!-- 模态框（Modal） -->
<div class="modal fade " id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-sm" style="width:300px;">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title" id="myModalLabel">登录</h4>
			</div>
			<div class="modal-body">
				<form name="loginform" id="loginform" action="<?php echo "http://test.com/wp-login.php"; ?>" method="post">
				<p class="login-username">
				<input name="log" id="user_login" class="input" value="" size="20" type="text" placeholder="用户名">
				</p>

				<p class="login-password">
				<input name="pwd" id="user_pass" class="input" value="" size="20" type="password" placeholder="密码">
				</p>
				<p class="login-remember">
				<label><input name="rememberme" id="rememberme" value="forever" type="checkbox"> 记住我的登录信息</label>
				</p>
				<?php
				if (get_option('users_can_register')) {  //判断用户可以注册
				?>
				<p class="register"><a href="<?php echo $registerpermalink; ?>">注册</a></p>
				<?php } ?>
				<p class="login-submit">
				<input name="wp-submit" id="wp-submit" class="button-primary" value="登录" type="submit">
				</p>
				</form>
			</div>
			
			<div class="modal-footer login">
				<?php
				$qq_open = intval(get_option('dmeng_open_qq',0));
				if ($qq_open) {
				?>
				<a href="<?php echo  dmeng_get_open_login_url('qq', 'login', dmeng_get_current_page_url()); ?>"><div class="loginqq">QQ账号登录</div></a>
				<?php } 
				$weibo_open = intval(get_option('dmeng_open_weibo',0));
				if ($weibo_open) {
				?>
				<a href="<?php echo  dmeng_get_open_login_url('weibo', 'login', dmeng_get_current_page_url()); ?>"><div class="loginweibo">新浪微博账号登录</div></a>
				<?php 
				}
				?>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<header id="masthead" itemscope itemtype="http://schema.org/WPHeader">

	<?php echo $header_content;?>

	<nav class="topnav" role="banner">
		<div class="container">
		<div class="row">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar"><span class="sr-only"><?php _e('切换菜单','momo');?></span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
				<?php
				$brand_class[] = 'navbar-brand';
				
				if(!$custom_header){
					$brand_class[] = 'show';
				}
				$blogname = get_option('blogname');
				$blogname =  ( is_home() || is_front_page() ) ? '<h1>'.$blogname.'</h1>' : $blogname;
				printf('<a class="%1$s" href="%2$s" rel="home" itemprop="headline">%3$s</a>', join(' ', $brand_class), esc_url(home_url('/')), $blogname);
				?>
			</div>
			<div id="navbar" class="collapse navbar-collapse" role="navigation" style="padding-left:15px;padding-right:15px;" itemscope itemtype="http://schema.org/SiteNavigationElement">
				
				<?php
				// 主菜单
				if ( has_nav_menu( 'header_menu' ) ) {
					wp_nav_menu( array(
						'menu'              => 'header_menu',
						'theme_location'    => 'header_menu',
						'depth'             => 0,
						'container'         => '',
						'container_class'   => '',
						'menu_class'        => 'nav navbar-nav navbar-main',
						'items_wrap' 		=> '<ul class="%2$s">%3$s</ul>',
						'walker'            => new WPMoMo_Bootstrap_Menu()
					)	);
				}else{
					echo '<div class="setmenu"><a href="'.home_url('/').'wp-admin/nav-menus.php">请前往后台"外观"->"菜单"，设置"头部菜单"</a></div>';
				}

				// 右侧菜单
				if ( has_nav_menu( 'header_right_menu' ) ) {
					wp_nav_menu( array(
						'menu'              => 'header_right_menu',
						'theme_location'    => 'header_right_menu',
						'depth'             => 0,
						'container'         => '',
						'container_class'   => '',
						'menu_class'        => 'nav navbar-nav navbar-right',
						'items_wrap' 		=> '<ul class="%2$s">%3$s</ul>',
						'walker'            => new WPMoMo_Bootstrap_Menu()
					)	);

				}

			?>

			<form class="navbar-form input-group input-group-sm" role="search" method="get" id="searchform1" action="<?php echo home_url( '/' ); ?>">
				
				<input type="text" class="form-control" placeholder="<?php _e('搜索 &hellip;','momo');?>" name="s" id="s" required>
				
				<span class="input-group-btn">
					<button type="submit" class="btn btn-default" id="searchsubmit">
						<span class="glyphicon glyphicon-search"></span>
					</button>
				</span>

			</form>

		</div>
		</div><!-- #navbar -->
	</div>
	</nav>
</header><!-- #masthead -->