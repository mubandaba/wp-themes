<?php
/* * 亲，如果您喜欢本主题，请上http://www.wpmomo.com发表留言，或者加我QQ45134691探讨问题 */
 ?>
<form class="input-group input-group-sm" role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
	<input type="text" class="form-control" placeholder="<?php _e('搜索 &hellip;','momo');?>" name="s" id="s" required>
	<span class="input-group-btn">
		<button type="submit" class="btn btn-default" id="searchsubmit">
			<span class="glyphicon glyphicon-search"></span>
		</button>
	</span>
</form>