<?php
/*
* 亲，如果您喜欢本主题或者有任何意见，请上http://www.wpmomo.com发表留言
*/
get_header(); ?>

<?php get_header('top'); ?>
	
<div id="main" class="container">

	<div class="row">

	<div id="content" class="col-lg-8 col-md-8 col-sm-12 col-xs-12 archive" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">

	<?php

	$paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;

	$home_setting = json_decode(get_option('home_setting','{"page1":"[]","page2":"[]","page3":"[]","category1":"[]","category2":"[]","post":"1","post_title":"","ignore_sticky_posts":"1","post_exclude":"[]"}'));

	$home_ignore_sticky_posts = intval($home_setting->ignore_sticky_posts);

	$home_category1 = $home_setting->category1;
	$home_category2 = $home_setting->category2;

	//~ 只在第一页显示幻灯片和分类列表等。`
	if( $paged<2 ){
		//~ 首页幻灯片
		$slide_home = intval(get_option('dmeng_slide_home',0));
		if( $slide_home ) echo dmeng_slide_to_html($slide_home);
	
		$homepage = (int)get_option('homepage',0);
		if ($homepage==1){
	?>

		<div class="row homepage3" >
			
			<?php
			$home_page1 = $home_setting->page1;
			$home_page2 = $home_setting->page2;
			$home_page3 = $home_setting->page3;
			$page_data = get_page( $home_page1 );  
			
			$home_page_des = json_decode(get_option('home_page_des','{"home_page1_des":"","home_page2_des":"","home_page3_des":""}'));
			
		   	$home_page1_des = $home_page_des->home_page1_des;
			$home_page2_des = $home_page_des->home_page2_des;
			$home_page3_des = $home_page_des->home_page3_des;
			
			$home_page1_des = htmlspecialchars_decode($home_page1_des);
			$home_page2_des = htmlspecialchars_decode($home_page2_des);
			$home_page3_des = htmlspecialchars_decode($home_page3_des);
			?>

		    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 homepage">
				<div class="homeimg">
					<img style="height:50px;" src="<?php echo get_option('page1_icon'); ?>">
				</div>
				<div style="padding:20px;"  class="">
					<div style="font-size:18px;color:#000;font-family:microsoft yahei" ><a href="<?php echo get_page_link ($home_page1) ; ?> " style="color: #000;font-size: 17px;" ><?php echo $page_data->post_title ?></a></div>
					<div style="font-size: 14px;color: #999;line-height: 20px;margin-top: 5px;"><?php echo $home_page1_des; ?></div>
				</div>
			</div>

			<?php $page_data = get_page( $home_page2 ); ?>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 homepage">
				<div class="homeimg">
					<img style="height:50px;" src="<?php echo get_option('page2_icon'); ?>">
				</div>
				<div style="padding:20px;"  class="">
					<div style="font-size:18px;color:#000;font-family:microsoft yahei" ><a href="<?php echo get_page_link ($home_page2) ; ?> " style="color: #000;font-size: 17px;" ><?php echo $page_data->post_title ?></a></div>
					<div style="font-size: 14px;color: #999;line-height: 20px;margin-top: 5px;"><?php echo $home_page2_des; ?></div>
				</div>
			</div>

			<?php $page_data = get_page( $home_page3 ); ?>
		    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 homepage">
				<div class="homeimg">
					<img style="height:50px;" src="<?php echo get_option('page3_icon'); ?>">
				</div>
				<div style="padding:20px;" class="">
					<div style="font-size:18px;color:#000;font-family:microsoft yahei" ><a href="<?php echo get_page_link ($home_page3) ; ?> " style="color: #000;font-size: 17px;" ><?php echo $page_data->post_title ?></a></div>
					<div style="font-size: 14px;color: #999;line-height: 20px;margin-top: 5px;"><?php echo $home_page3_des ?> </div>
				</div>
			</div>

		</div>

		<?php
		}  //$homepage==1

		$category1 = (int)get_option('category1',0);
		if ($category1==1){
    		$catname = get_category($home_category1)->name ;
    		$catcount = get_category($home_category1)->count ;
    		$itemcount = (int)$catcount / 4;

    		$maxindex = get_option('home_num1');
    		if($maxindex>$itemcount){
    			$displaycount=$itemcount;
    		}else{
    			$displaycount = $maxindex;
    		}
		?>


		<div class="titname"><?php echo $catname; ?></div>
		<div id="carousel-category1" class="carousel carousel-category slide" data-ride="carousel">
			<div class="carousel-inner">

				<div class="item active">
					<div class="index">1&nbsp/&nbsp<?php echo $displaycount; ?></div>	
					<ul class="list">
                    <?php
                    $args = array(
                        'showposts' => 4,
                        'cat'   => $home_category1
                    );
                    $the_query = new WP_Query( $args ); // 查询
                    if ( $the_query->have_posts() ) :
                        while ( $the_query->have_posts() ) :
                            $the_query->the_post();
                    
					
        					$thumbnail = momo_get_the_thumbnail();
        					$thummore =  get_bloginfo('template_url')."/timthumb.php?src=$thumbnail[0]&h=130&w=170";
        					if($thumbnail[0]){
        						$thumbnail_html =  '<img src="'.$thummore.'" alt="'.get_the_title().'">';
        					}else{
        						$thumbnail_html =  '<img src="'.get_template_directory_uri().'/images/indexfeature.png"'.' alt="'.get_the_title().'">';
        					}
					?>	
        					<li class="list-item">
        						<div class="cat1pic"><?php echo $thumbnail_html; ?></div>
        						<div class="cat1title"><a href="<?php echo get_permalink(); ?>"><?php the_title() ?></a></div>
        					</li>
					    <?php endwhile; ?><!-- end of the loop -->
                        <?php wp_reset_postdata(); ?>
					<?php endif; ?>
					</ul>	
				</div>
				<?php
				for ($x=0; $x<$displaycount-1; $x++) {
				$offset = $x*4+4;
				?>
				
				<div class="item">
					<div class="index"><?php echo $x+2; ?>&nbsp/&nbsp<?php echo $displaycount; ?></div>
					<ul class="list">
                    <?php
                    $args = array(
                        'showposts' => 4,
                        'cat'   => $home_category1,
                        'offset' => $offset
                    );
                    $the_query = new WP_Query( $args ); // 查询
                    if ( $the_query->have_posts() ) :
                        while ( $the_query->have_posts() ) :
                            $the_query->the_post();
					
        					$thumbnail = momo_get_the_thumbnail();
        					$thummore =  get_bloginfo('template_url')."/timthumb.php?src=$thumbnail[0]&h=130&w=170";
        					if($thumbnail[0]){
        						$thumbnail_html =  '<img src="'.$thummore.'" alt="'.get_the_title().'">';
        					}else{
        						$thumbnail_html =  '<img src="'.get_template_directory_uri().'/images/indexfeature.png"'.' alt="'.get_the_title().'">';
        					}
        					?>	
        					<li class="list-item">
        						
        						<div class="cat1pic"><?php echo $thumbnail_html; ?></div>
        						<div class="cat1title"><a href="<?php echo get_permalink(); ?>"><?php the_title() ?></a></div>
        					</li>
					   <?php endwhile; ?>
                       <?php wp_reset_postdata(); ?>		
					<?php endif;?>
					</ul>	
				</div>
            </div>
		

			<a class="left carousel-control" href="#carousel-category1" role="button" data-slide="prev">
			<span class="glyphicon glyphicon-chevron-left"></span>
			</a>
			
			<a class="right carousel-control" href="#carousel-category1" role="button" data-slide="next">
			<span class="glyphicon glyphicon-chevron-right"></span>
			</a>
			
		</div>

                		<?php
                		} //$category1==1
        }   
		?>

		<?php
		$catpage = (int)get_option('catpage',0);
		if ($catpage==1){
		$cat_page = get_option('cat_page');
		$page_data = get_page( $cat_page );  

		$cat_page_des = get_option('cat_page_des');
		$cat_page_des = stripslashes(htmlspecialchars_decode($cat_page_des));
		
		?>
		<div class="row note">
			<div style="font-size:18px;color:#000;font-family:microsoft yahei" ><a href="<?php echo get_page_link ($home_page1) ; ?> " style="color: #000;font-size: 17px;" ><?php echo $page_data->post_title ?></a></div>

		<div style="font-size: 14px;color: #999;line-height: 20px;margin-top: 5px;"><?php echo $cat_page_des; ?></div>

		<div class="detail"><a href="<?php echo get_page_link ($home_page1) ; ?> ">查看详情</a></div>

		</div>
		<?php
		}
		?>

		<?php

		$category2 = (int)get_option('category2',0);
		if ($category2==1){
		$catname = get_category($home_category2)->name ;
		$catcount = get_category($home_category2)->count ;
		$itemcount = (int)$catcount / 4;

		$maxindex = get_option('home_num2');
		if($maxindex>$itemcount){
			$displaycount=$itemcount;
		}else{
			$displaycount = $maxindex;
		}
		?>

		<div class="titname"><?php echo $catname; ?></div>
		<div id="carousel-category2" class="carousel carousel-category slide" data-ride="carousel">
			<div class="carousel-inner">

				<div class="item active">
					<div class="index">1&nbsp/&nbsp<?php echo $displaycount; ?></div>	
					<ul class="list">
					<?php
                    $args = array(
                        'showposts' => 4,
                        'cat'   => $home_category2
                    );
                    $the_query = new WP_Query( $args ); // 查询
                    if ( $the_query->have_posts() ) :
                        while ( $the_query->have_posts() ) :
                            $the_query->the_post();
                    
					
        					$thumbnail = momo_get_the_thumbnail();
        					$thummore =  get_bloginfo('template_url')."/timthumb.php?src=$thumbnail[0]&h=130&w=170";
        					if($thumbnail[0]){
        						$thumbnail_html =  '<img src="'.$thummore.'" alt="'.get_the_title().'">';
        					}else{
        						$thumbnail_html =  '<img src="'.get_template_directory_uri().'/images/indexfeature.png"'.' alt="'.get_the_title().'">';
        					}
					?>	
					
						<li class="list-item">
							<div class="cat1pic"><?php echo $thumbnail_html; ?></div>
							<div class="cat1title"><a href="<?php echo get_permalink(); ?>"><?php the_title() ?></a></div>
						</li>
						<?php endwhile; ?><!-- end of the loop -->
                        <?php wp_reset_postdata(); ?>
					<?php endif; ?>
					</ul>	
				</div>
				<?php

				for ($x=0; $x<$displaycount-1; $x++) {
				$offset = $x*4+4;
				?>
				
				<div class="item">
					<div class="index"><?php echo $x+2; ?>&nbsp/&nbsp<?php echo $displaycount; ?></div>
					<ul class="list">

					<?php
                    $args = array(
                        'showposts' => 4,
                        'cat'   => $home_category2,
                        'offset' => $offset
                    );
                    $the_query = new WP_Query( $args ); // 查询
                    if ( $the_query->have_posts() ) :
                        while ( $the_query->have_posts() ) :
                            $the_query->the_post();
                    
					
        					$thumbnail = momo_get_the_thumbnail();
        					$thummore =  get_bloginfo('template_url')."/timthumb.php?src=$thumbnail[0]&h=130&w=170";
        					if($thumbnail[0]){
        						$thumbnail_html =  '<img src="'.$thummore.'" alt="'.get_the_title().'">';
        					}else{
        						$thumbnail_html =  '<img src="'.get_template_directory_uri().'/images/indexfeature.png"'.' alt="'.get_the_title().'">';
        					}
					?>

					<li class="list-item">
						<div class="cat1pic"><?php echo $thumbnail_html; ?></div>
						<div class="cat1title"><a href="<?php echo get_permalink(); ?>"><?php the_title() ?></a></div>
					</li>
					<?php endwhile; ?><!-- end of the loop -->
                        <?php wp_reset_postdata(); ?>
					<?php endif; ?>
					</ul>	
				</div>

				<?php
				} 
				?>
			</div>

			<a class="left carousel-control" href="#carousel-category2" role="button" data-slide="prev">
			<span class="glyphicon glyphicon-chevron-left"></span>
			</a>
			
			<a class="right carousel-control" href="#carousel-category2" role="button" data-slide="next">
			<span class="glyphicon glyphicon-chevron-right"></span>
			</a>
			
		</div>


		<?php
		}
		}



//~ 文章列表


$home_post = intval($home_setting->post);


if($home_post){



	$home_post_exclude = (array)$home_setting->post_exclude;


	$query_args = array();
	$query_args['ignore_sticky_posts'] = $home_ignore_sticky_posts;
	$query_args['paged'] = $paged;
	if($home_post_exclude) $query_args['category__not_in'] = $home_post_exclude;
	if($home_post===1) $query_args['orderby'] = 'date';
	if($home_post===2) $query_args['orderby'] = 'modified';
	if($home_post===3) $query_args['orderby'] = 'comment_count';


	//~ 如果置顶文章单独显示在上面了，这下面的列表就排除置顶文章吧～
	if($home_ignore_sticky_posts===2) $query_args['post__not_in'] = get_option( 'sticky_posts' );
	$home_post_title = '';
	if( $paged>=2 ) $home_post_title .= sprintf( ' <small>' . __( '第 %s 页', 'momo' ) . '</small>', $paged );
	?>

	<div class="index-tit">
    	<div class="tit"><?php echo $home_setting->post_title ?></div>
	</div>

	<?php

	echo '<div class="article-list" role="main">';
	if($home_post_title) echo '<h3 class="page-header panel-archive-title">'.$home_post_title.'</h3>';

		$the_query = new WP_Query( $query_args );
		if ( $the_query->have_posts() ) :
			while ( $the_query->have_posts() ) : $the_query->the_post(); 
				get_template_part('content','archive');
			endwhile; // end of the loop.
			wp_reset_postdata(); 
		endif;
		
		
	global $wp_query;
	$url = home_url('/');
	$paged = get_query_var('paged');
	$prepage = $paged + 1;
	$nextpage = $paged - 1;
	$preurl = add_query_arg( 'paged', $prepage , $url );
	$nexturl = add_query_arg( 'paged', $nextpage , $url );
	
	
	if ($prepage <= $wp_query->max_num_pages){ ?>
	
	<div id="next" style="text-align:center"><a href="<?php echo $preurl ?>" title="<?php echo sprintf('第 %s 页',$prepage) ?>" data-no-instant>加载更多</a></div>

	
	<?php
	
	}elseif ($prepage > $wp_query->max_num_pages){  ?>
	
	
	<div id="next" style="text-align:center"><a href="<?php echo $preurl ?>" title="<?php echo sprintf('第 %s 页',$prepage) ?>">没有更多</a></div>
	
	
	<?php }  ?>
	
		
	<script>

		
            var infinite_scroll = {
		behavior:'twitter',
		loading: {
                img: "<?php echo get_stylesheet_directory_uri(); ?>/images/ajax-loader.gif",
		msgText: "<?php _e('加载更多...', 'momo'); ?>",
                finishedMsg: "<?php _e('没有更多..', 'momo'); ?>"
                },
                nextSelector:'#next a',
                navSelector:"#next a",
                itemSelector:"#content article",
                contentSelector:"#content .article-list"
            };	
            jQuery(infinite_scroll.contentSelector ).infinitescroll( infinite_scroll, function(){
				jQuery('#next a').css("display","inline");
                jQuery('#next').insertAfter('#content article:last');
            });


</script>		
	


<?php
	echo '</div>';
	
}
?>

	 </div><!-- #content -->


	<?php get_sidebar();?>


	</div>


	<?php if ($prepage <= $wp_query->max_num_pages){ ?>
	<span id="nav_prev"><a href="<?php echo $preurl ?>" title="<?php echo sprintf('第 %s 页',$prepage) ?>">‹</a></span>
	<?php } ?>

	<?php if ($nextpage > 0){  ?>		
	<span id="nav_next"><a href="<?php echo $nexturl ?>" title="<?php echo sprintf('第 %s 页',$nextpage); ?>">›</a></span>	 
	<?php } ?>


 </div><!-- #main -->


<?php get_footer('colophon'); ?>


<?php get_footer(); ?>