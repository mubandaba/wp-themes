<?php
/*
* 内容页面
*/
?>

<article id="content" class="col-lg-8 col-md-8 single" data-post-id="<?php the_ID(); ?>" role="article">

	<!--面包屑导航-->
	<div class="entry-breadcrumb" role="toolbar">	
		<span class="glyphicon glyphicon-home" style="margin-right:8px"></span>
		<?php momo_breadcrumb_html(get_the_ID(),'&nbsp› &nbsp'); ?>
	</div>

	<!--文章头部-->
	<div class="entry-header page-header">
		<!--文章标题-->
		<h1 class="entry-title" itemprop="name">
		<?php 
		echo  esc_html(get_the_title()) ;?><?php if( is_preview() || current_user_can('edit_post', get_the_ID()) ) echo ' <small><a href="'.get_edit_post_link().'">'.__('Edit This').'</a></small>'; 
		?>
		</h1>

		<!--文章注记-->
		<?php momo_post_meta();?>
	</div>

	

	<!--如果设置摘要，则显示摘要-->

	<?php 

	global $post; 

	if ($post->post_excerpt) {

		echo '<div class="excerpt">';

		$excerpt= $post->post_excerpt;

		echo $excerpt;

		echo '</div>';

	}



	?>



	<!--文章内容及分页导航-->

	<div class="entry-content"  itemprop="articleBody">

		<?php the_content();?>

		<?php momo_post_page_nav(); ?>

	</div>



	<!--文章底部点赞及分享按钮-->

	<div class="article-footer" style="border-top:1px solid #ddd;padding:20px 0;margin:20px 0 50px 0;">

		<?php momo_post_footer();?>

	</div>

	

	<!--猜您喜欢标题-->

	<div class="index-tit">

		<div class="tit" style="font-size:14px;padding-bottom:3px">猜您喜欢</div>

	</div>



	<ul id="tags_related">

	<?php

	global $post;

	$cats = wp_get_post_categories($post->ID);

	if ($cats) {

		$args = array(
  			'category__in' => array( $cats[0] ),
  			'post__not_in' => array( $post->ID ),
  			'showposts' => 5,
  			'caller_get_posts' => 1
			);

		$the_query = new WP_Query( $args ); // 查询

		if ( $the_query->have_posts() )  {
			while ( $the_query->have_posts() ){
			$the_query->the_post(); update_post_caches($posts); 
			$size = array(120 ,120);
			$image_url = momo_get_the_thumbnail($size);
			$thummore =  get_bloginfo('template_url')."/timthumb.php?src=$image_url[0]&h=120&w=120";
	?>

			<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
				<li>
				<?php if($image_url) { ?>
				<img src="<?php echo $thummore; ?>" width="120" height="120" alt="<?php echo get_the_title() ?>">
				<?php }else{ ?>
				<img src="<?php echo get_template_directory_uri(); ?>/images/nofeature.png" width="120" height="120" alt="<?php echo get_the_title() ?>">
				<?php } ?>
				<div style="color:#000;font-size:12px;line-height:18px;"><?php the_title(); ?></div>
				</li>
			</a>

			<?php
    		}
			wp_reset_postdata();
		}else {
			echo '<div style="margin-bottom:40px">暂无相关文章</div>';
		}

	}else {
		echo '<div style="margin-bottom:40px">暂无相关文章</div>';
	}

			?>
	</ul>

	<!--加载评论-->
	<div class="panel panel-default" id="comments">
		<?php comments_template(); ?>
	</div>

	<?php
	$prev_post = get_previous_post(true);
	if (!empty( $prev_post )) {  ?>		
	<span id="nav_prev"><a href="<?php echo get_permalink( $prev_post->ID ); ?>" title="上一篇：<?php echo $prev_post->post_title; ?>">‹</a></span>
	<?php } 
	$next_post = get_next_post(true);
	if ( is_a( $next_post , 'WP_Post' ) ) { ?>
	<span id="nav_next"><a href="<?php echo get_permalink( $next_post->ID ); ?>" title="下一篇：<?php echo get_the_title( $next_post->ID ); ?>">›</a></span>
	<?php } ?>
 </article><!-- #content -->