<?php

/*
版本检查
*/

//启动主题时清理检查任务
function dmeng_clear_version_check(){
	global $pagenow;   
	if ( 'themes.php' == $pagenow && isset( $_GET['activated'] ) ){
		wp_clear_scheduled_hook( 'dmeng_check_version_daily_event' );
	}
}
add_action( 'load-themes.php', 'dmeng_clear_version_check' ); 

//每天00:00检查主题版本
function dmeng_check_version_setup_schedule() {
	if ( ! wp_next_scheduled( 'dmeng_check_version_daily_event' ) ) {
		//~ 1193875200 是 2007/11/01 00:00 的时间戳
		wp_schedule_event( time(), 'daily', 'dmeng_check_version_daily_event');
	}
}
add_action( 'wp', 'dmeng_check_version_setup_schedule' );

//检查主题版本回调函数
function dmeng_check_version_do_this_daily() {
	//更新这个代码版本号为1.0
	update_option('dmeng_version', '1.0' );
	$response = wp_remote_get('http://www.wpmomo.com/version.json');
	if(wp_remote_retrieve_response_code($response) =='200'){
		$dmengVersion = wp_get_theme()->get( 'version' );
		$version = json_decode(wp_remote_retrieve_body($response) ,true);
		if( !empty( $version["version"] ) ){
			update_option('dmeng_theme_upgrade', $version["version"]);
			return true;
		}
	}
	return false;
}
add_action( 'dmeng_check_version_daily_event', 'dmeng_check_version_do_this_daily' );

//~ 新版本提示
function dmeng_update_alert_callback(){
	$version = get_option('dmeng_version');
	$dmeng_upgrade = get_option('dmeng_theme_upgrade');
	if( version_compare($dmeng_upgrade, $version, '>') ){
		echo '<div class="updated fade"><p>'.sprintf(__('MoMo主题有了更新的版本，请<a href="%s">到版本升级了解详情</a>！','momo'), admin_url('admin.php?page=dmeng_options_tool&tab=version') ).'</p></div>';
	}
}
add_action( 'admin_notices', 'dmeng_update_alert_callback' );

//~ momo提示
function momo_note(){
	$response = wp_remote_get('http://www.wpmomo.com/version.json');
	$response_body = json_decode(wp_remote_retrieve_body($response) ,true);
	$note_display = $response_body["note_display"];
	if($note_display){
		echo '<div class="updated"><p>'.sprintf(__('%1s<a href="%2s">%3s</a>','momo'),  $response_body["note"], $response_body["url"],$response_body["url_body"]).'</p></div>';
	}
}
add_action( 'admin_notices', 'momo_note' );