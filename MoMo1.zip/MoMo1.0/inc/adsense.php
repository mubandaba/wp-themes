<?php
/* * 亲，如果您喜欢本主题，请上http://www.wpmomo.com发表留言，或者加我QQ45134691探讨问题哦 */

/*
 * 广告  
 * 
 */

function dmeng_adsense($type='single',$local='top'){

	$content = $adsense = '';
	
	if($type=='single') $adsense = json_decode(get_option('dmeng_adsense_single','{"top":"","comment":"","bottom":""}'));
	if($type=='archive') $adsense = json_decode(get_option('dmeng_adsense_archive','{"top":"","bottom":""}'));
	if($type=='author') $adsense = json_decode(get_option('dmeng_adsense_author','{"top":"","bottom":""}'));

	if($adsense) $content = stripslashes(htmlspecialchars_decode($adsense->$local));
	
	if($content) return '<div class="panel panel-default"><div class="panel-body adsense">'.trim($content).'</div></div>';

}
