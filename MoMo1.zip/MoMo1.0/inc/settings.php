<?php

/*
 * 亲，如果您喜欢本主题，请上http://www.wpmomo.com发表留言，或者加我QQ45134691探讨问题哦
 */

/*
 * 主题设置页面
 */

add_action( 'admin_menu', 'wpmomo_admin_menu_page' );

function wpmomo_admin_menu_page(){
	$title = __('MoMo设置','momo');
	$slug = 'wpmomo_settings';
	add_menu_page( $title, 'MoMo', 'manage_options', $slug, 'wpmomo_options_page', get_template_directory_uri()."/images/adminicon.png"); 
	add_submenu_page( $slug, 'MoMo设置','MoMo设置', 'manage_options',  $slug, 'wpmomo_options_page' ); 
	$wpmomo_submenus = array(
		'slide' =>__('幻灯片','momo'),
		'tool' =>__('高级','momo'),
		'log' =>__('数据记录','momo')
	);

	foreach( $wpmomo_submenus as $skey=>$stitle ){
		add_submenu_page( $slug, $stitle, $stitle, 'manage_options', 'dmeng_options_'.$skey , 'dmeng_options_'.$skey.'_page' ); 
	}

	add_submenu_page( $slug, '主题介绍','主题介绍', 'manage_options',   'wpmomo_theme_introduce', 'wpmomo_theme_introduce' ); 
	add_submenu_page( $slug, '主题使用','主题使用', 'manage_options',   'wpmomo_theme_usage', 'wpmomo_theme_usage' ); 

}

function dmeng_admin_tabs($tab='general'){

	$dmeng_tabs = array(
		'general' => __('常规设置', 'momo'),
		'home' => __('首页', 'momo'),
		'writing' =>__('撰写','momo'),
		'reading' =>__('阅读','momo'),
		'discussion' =>__('评论','momo'),
		'open' =>__('开放平台','momo'),
		'smtp' =>__('SMTP发信','momo'),
	);

	$tab_output = '<h2 class="nav-tab-wrapper">';

	foreach( $dmeng_tabs as $tab_key=>$tab_name ){

		$tab_output .= sprintf('<a href="%s" class="nav-tab%s">%s</a>', add_query_arg('tab', $tab_key), $tab_key==$tab ? ' nav-tab-active' : '', $tab_name);

	}

	$tab_output .= '</h2>';

	echo $tab_output;

}

$dmeng_tabs_array = array(
	'general',
	'home',
	'writing',
	'reading',
	'discussion',
	'open',
	'smtp'
);

//~ 载入设置页面
require_once( get_template_directory() . '/inc/settings-slide.php' );
require_once( get_template_directory() . '/inc/settings-tool.php' );
require_once( get_template_directory() . '/inc/settings-log.php' );


foreach( $dmeng_tabs_array as $dmeng_tab_slug ){
	require_once( get_template_directory() . '/inc/settings-'.$dmeng_tab_slug.'.php' );
}

function wpmomo_theme_introduce(){
    $url = "http://www.wpmomo.com/momo-1-0/";  
    echo "<script language='javascript' 
    type='text/javascript'>";  
    echo "window.location.href='$url'";  
    echo "</script>";  

}

function wpmomo_theme_usage(){
    $url = "http://www.wpmomo.com/theme-usage/";  
    echo "<script language='javascript' 
    type='text/javascript'>";  
    echo "window.location.href='$url'";  
    echo "</script>";  
}



function wpmomo_options_page(){

	global $dmeng_tabs_array;

	$tab = 'general';

	if( isset($_GET['tab']) ){

		$tab = in_array($_GET['tab'], $dmeng_tabs_array) ? $_GET['tab'] : 'general';

	}

	$tab = 'dmeng_options_'.$tab.'_page';

	$tab();

}



class DmengOptionsOutput {

	

	public function table($items){



		if( empty($items[0]['type']) ) return;

		

		echo '<table class="form-table"><tbody>';

		

		foreach( $items as $item){

			

			$item = wp_parse_args( $item, array(

								'type' => '',

								'th' => '',

								'before' => '',

								'after' => '',

								'key' => '',

								'value' => '',
								
								'style' => ''

							));

			

			echo '<tr>';

			$this->tableTH($item['key'], $item['th']);

			$this->tableTD($item['type'], $item['key'], $item['value'], $item['before'], $item['after'], $item['style']);

			echo '</tr>';

		}

		

		echo '</tbody></table>';

	}

	

	public function tableTH($key, $title){

		echo sprintf('<th scope="row"><label for="%s">%s</label></th>', $key, $title);

	}

	

	public function tableTD($type, $key, $value, $before, $after, $style){

		

		echo '<td>'.$before;



		if( $type=='input' ){

			echo sprintf('<input name="%1$s" type="text" id="%1$s" value="%2$s" class="regular-text ltr" style="%3$s">', $key, $value, $style);

		}



		if( $type=='input-password' ){

			echo sprintf('<input name="%1$s" type="password" id="%1$s" value="%2$s" class="regular-text ltr">', $key, $value);

		}



		if( $type=='textarea' ){

			echo sprintf('<textarea name="%1$s" rows="5" cols="50" id="%1$s" class="large-text code">%2$s</textarea>', $key, $value);

		}

		

		if( $type=='select' ){

			echo sprintf('<select name="%1$s" id="%1$s">', $key);

			foreach( $value['option'] as $option_key=>$option_value ){

				echo sprintf('<option value="%1$s"%2$s>%3$s</option>', $option_key, (in_array($option_key, $value['default']) ? ' selected="selected"' : ''), $option_value);

			}

			echo '</select>';

		}

		

		if( $type=='checkbox' ){

			foreach( $value['option'] as $option_key=>$option_value ){

				echo sprintf('<label><input name="%1$s[]" type="checkbox" value="%2$s"%3$s> %4$s </label>', $key, $option_key, (in_array($option_key, $value['default']) ? ' checked' : ''), $option_value);

			}

		}

		

		if( $type=='editor' ){

			wp_editor( $value, $key, array( 'media_buttons' => false, 'textarea_rows' => 5 ) );

		}



		echo $after.'</td>';

	}



}

