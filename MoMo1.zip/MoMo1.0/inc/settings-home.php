<?php
/*
 * 首页设置页面
 */

function dmeng_options_home_page(){

	if( isset($_POST['action']) && sanitize_text_field($_POST['action'])=='update' && wp_verify_nonce( trim($_POST['_wpnonce']), 'check-nonce' ) ) :

  	//首页关键词及描述
	update_option( 'momo_home_seo', json_encode(array(
		'keywords' => sanitize_text_field($_POST['home_keywords']),
		'description' => sanitize_text_field($_POST['home_description'])
	)));

	//三个页面的id
	$home_page1 = empty($_POST['home_page1']) ? "" : $_POST['home_page1'];
	$home_page2 = empty($_POST['home_page2']) ? "" : $_POST['home_page2'];
	$home_page3 = empty($_POST['home_page3']) ? "" : $_POST['home_page3'];
	//三个页面的描述
	update_option( 'home_page_des', json_encode(array(
		'home_page1_des' => htmlspecialchars($_POST['home_page1_des']),
		'home_page2_des' => htmlspecialchars($_POST['home_page2_des']),
		'home_page3_des' => htmlspecialchars($_POST['home_page3_des']),
	)));

	update_option( 'qq',$_POST['qq'] );
	update_option( 'weibo',$_POST['weibo'] );

	//两个分类的id
	$home_category1 = empty($_POST['home_category1']) ? "" : $_POST['home_category1'];
	$home_category2 = empty($_POST['home_category2']) ? "" : $_POST['home_category2'];
	//首页两个分类显示的页数
	update_option( 'home_num1', $_POST['home_num1']);
	update_option( 'home_num2', $_POST['home_num2']);

	//分类间页面的id	
	$cat_page = empty($_POST['cat_page']) ? "" : $_POST['cat_page'];
	update_option('cat_page',$cat_page);
	//分类间页面的描述
	update_option('cat_page_des',htmlspecialchars($_POST['cat_page_des']));

	//上面这些是否显示
	update_option( 'homepage', intval($_POST['homepage']) );
	update_option( 'catpage', intval($_POST['catpage']) ); 
	update_option( 'category1', intval($_POST['category1']) );
	update_option( 'category2', intval($_POST['category2']) );
	
	/****Favicon处理数据********/  
    if ( isset( $_POST['save_wpmomo_options'] ) ) { //save_wpmomo_options是先前输出的隐藏域   
        $new_option = $old_option = get_option('page1_icon'); //获取老数据,新数据的值暂时和老数据一样   
        $new_option = $_POST['page1_icon']; //获取提交的数据，新数据重新赋值   
        if ( $old_option != $new_option ) { //如果新老数据不一样，就说明更改了   
            update_option( 'page1_icon', $new_option ); //更新上数据   
        }   
		
		$new_option = $old_option = get_option('page2_icon'); //获取老数据,新数据的值暂时和老数据一样   
        $new_option = $_POST['page2_icon']; //获取提交的数据，新数据重新赋值   
        if ( $old_option != $new_option ) { //如果新老数据不一样，就说明更改了   
            update_option( 'page2_icon', $new_option ); //更新上数据   
        }   
		
		$new_option = $old_option = get_option('page3_icon'); //获取老数据,新数据的值暂时和老数据一样   
        $new_option = $_POST['page3_icon']; //获取提交的数据，新数据重新赋值   
        if ( $old_option != $new_option ) { //如果新老数据不一样，就说明更改了   
            update_option( 'page3_icon', $new_option ); //更新上数据   
        }

        $new_option = $old_option = get_option('weixin_upload'); //获取老数据,新数据的值暂时和老数据一样   
        $new_option = $_POST['weixin_upload']; //获取提交的数据，新数据重新赋值   
        if ( $old_option != $new_option ) { //如果新老数据不一样，就说明更改了   
            update_option( 'weixin_upload', $new_option ); //更新上数据   
        }
    }

    //排除分类
	$momo_home_post_exclude = empty($_POST['home_post_exclude']) ? array() : $_POST['home_post_exclude'];

	update_option( 'home_setting', json_encode(array(
		'page1' => $home_page1,
		'page2' => $home_page2,
		'page3' => $home_page3,
		'category1' => $home_category1,
		'category2' => $home_category2,
		'post' => intval($_POST['home_post']), //文章排列方式
		'post_title' => $_POST['home_post_title'],  //文章列表的标题
		'ignore_sticky_posts' => intval($_POST['home_ignore_sticky_posts']),  //是否可以置顶文章
		'post_exclude' => $momo_home_post_exclude
	)));

	dmeng_settings_error('updated');

	endif;
  
	$homepage = (int)get_option('homepage',0);
	$catpage = (int)get_option('catpage',0);
	$category1 = (int)get_option('category1',0);
	$category2 = (int)get_option('category2',0);

	$home_seo = json_decode(get_option('momo_home_seo','{"keywords":"","description":""}'));

	$home_num1 = get_option('home_num1');
	$home_num2 = get_option('home_num2');
	
	$home_page_des = json_decode(get_option('home_page_des','{"home_page1_des":"","home_page2_des":"","home_page3_des":""}'));

	
	$home_page1_des = $home_page_des->home_page1_des;
	$home_page2_des = $home_page_des->home_page2_des;
	$home_page3_des = $home_page_des->home_page3_des;
	
	$home_page1_des = stripslashes(htmlspecialchars_decode($home_page1_des));
	$home_page2_des = stripslashes(htmlspecialchars_decode($home_page2_des));
	$home_page3_des = stripslashes(htmlspecialchars_decode($home_page3_des));

	$cat_page_des = get_option('cat_page_des');
	$cat_page_des = stripslashes(htmlspecialchars_decode($cat_page_des));

	$home_setting = json_decode(get_option('home_setting','{"page1":"[]","page2":"[]","page3":"[]","category1":"[]","category2":"[]","post":"1","post_title":"","ignore_sticky_posts":"1","post_exclude":"[]"}'));
	$home_page1 = (array)$home_setting->page1;
	$home_page2 = (array)$home_setting->page2;
	$home_page3 = (array)$home_setting->page3;

	$cat_page = (array)get_option('cat_page');
	
	$home_category1 = (array)$home_setting->category1;
	$home_category2 = (array)$home_setting->category2;

	$home_post = intval($home_setting->post);

	$home_post_title = $home_setting->post_title;

	$home_ignore_sticky_posts = intval($home_setting->ignore_sticky_posts);

	$home_post_exclude = (array)$home_setting->post_exclude;

	//获取所有页面并赋予$page_array数组
	$pages = get_pages();
	foreach ( $pages as $page ) {
		$page_array[$page->ID] = $page->post_title;
	}

	//获取所有页面并赋予$categories_array数组
	$categories = get_categories();
	foreach ( $categories as $category ) {
		$categories_array[$category->term_id] = $category->name;
	}

?>

<div class="wrap1">

	<h2>MoMo 1.0</h2>
	<form method="post">
		<input type="hidden" name="action" value="update">
		<input type="hidden" id="_wpnonce" name="_wpnonce" value="<?php echo wp_create_nonce( 'check-nonce' );?>">

		<?php
		dmeng_admin_tabs('home');
		$option = new DmengOptionsOutput();
		$option->table( array(

			array(
				'type' => 'input',
				'th' => __('首页关键词','momo'),
				'before' => '<p>'.__('网站首页的网页关键词','momo').'</p>',
				'key' => 'home_keywords',
				'value' => $home_seo->keywords
			),

			array(
				'type' => 'textarea',
				'th' => __('首页描述','momo'),
				'before' => '<p>'.__('网站首页的网页描述，推荐200字以内','momo').'</p>',
				'key' => 'home_description',
				'value' => $home_seo->description
			)
			));

			/******处理数据*****/  
			echo '<div style="margin:20px 0">';
			
			echo '<div style="vertical-align: top;display:inline-block;padding: 20px 10px 20px 0px;width: 200px;line-height: 1.3;font-size:14px;font-weight: 600;">
			<label>设置微信二维码图片</label></div>';   
		 
			echo '<div style="padding:10px;display:inline-block">
			<p style="margin-bottom:3px;font-size:14px">鼠标悬停微信图标后将显示您设置的图片</p>
			<input type="text" size="60" value="'.get_option('weixin_upload').'" name="weixin_upload" class="wpmomo_url_input" id="weixin_upload_input"/>
			<a id="weixin_upload" class="wpmomo_upload_button button" href="#">选择或上传</a></div>';   
			   
			echo '<p><input type="hidden" value="1" name="save_wpmomo_options"/></p>';   
			
			echo '</div>';	

			$option->table( array(

			array(
				'type' => 'input',
				'th' => __('设置您的qq号','momo'),
				'before' => '<p>'.__('鼠标点击后将发起与您的qq对话','momo').'</p>',
				'key' => 'qq',
				'value' => get_option('qq')			
			),

			array(
				'type' => 'input',
				'th' => __('设置您的微博地址','momo'),
				'before' => '<p>'.__('鼠标点击后将跳转至您设置的地址(请填写完整的http地址)','momo').'</p>',
				'key' => 'weibo',
				'value' => get_option('weibo')			
			),

			
			array(
				'type' => 'select',
				'th' => __('幻灯片下方三个页面的设置','momo'),
				'before' => '<p>'.__('请选择是否显示','momo').'</p>',
				'key' => 'homepage',
				'value' => array(
					'default' => array($homepage),
					'option' => array(
						1 => __( '显示', 'momo' ),
						0 => __( '不显示', 'momo' )
					)
				)
			),

			array(
				'type' => 'select',
				'before' => '<p style="font-weight:bold">'.__('第一个页面','momo').'</p>',
				'key' => 'home_page1',
				'value' => array(
					'default' => $home_page1,
					'option' => $page_array
				)
			),
				
			array(
				'type' => 'input',
				'before' => '<p>'.__('描述（支持 html标签）','momo').'</p>',
				'key' => 'home_page1_des',
				'value' => $home_page1_des			
			)
			
			) );
			
			
			/******处理数据*****/  
			echo '<div>';
			
			echo '<div style="vertical-align: top;display:inline-block;padding: 20px 10px 20px 0px;width: 200px;line-height: 1.3;font-size:14px;font-weight: 600;"></div>';   
		 
			echo '<div style="padding:10px;display:inline-block">
			<p style="margin-bottom:3px;font-size:14px">设置图标</p>
			<input type="text" size="60" value="'.get_option('page1_icon').'" name="page1_icon" class="wpmomo_url_input" id="wpmomo_upload_input"/>
			<a id="page1_icon" class="wpmomo_upload_button button" href="#">选择或上传</a></div>';   
			   
			echo '<p><input type="hidden" value="1" name="save_wpmomo_options"/></p>';   
			
			echo '</div>';	

			$option->table( array(
			
			array(
				'type' => 'select',
				'before' => '<p style="font-weight:bold">'.__('第二个页面','momo').'</p>',
				'key' => 'home_page2',
				'value' => array(
					'default' => $home_page2,
					'option' => $page_array
				)
			),
			
			array(
				'type' => 'input',
				'before' => '<p>'.__('描述（支持 html标签）','momo').'</p>',
				'key' => 'home_page2_des',
				'value' => $home_page2_des
			)
			
			) );
			
			
			/******处理数据*****/  
			echo '<div>';
			
			echo '<div style="vertical-align: top;display:inline-block;padding: 20px 10px 20px 0px;width: 200px;line-height: 1.3;font-size:14px;font-weight: 600;"></div>';   
		 
			echo '<div style="padding:10px;display:inline-block">
			<p style="margin-bottom:3px;font-size:14px">设置图标</p>
			<input type="text" size="60" value="'.get_option('page2_icon').'" name="page2_icon" class="wpmomo_url_input" id="wpmomo_upload_input"/>
			<a id="page2_icon" class="wpmomo_upload_button button" href="#">选择或上传</a></div>';   
			   
			echo '<p><input type="hidden" value="1" name="save_wpmomo_options"/></p>';   
			
			echo '</div>';	
			
			$option->table( array(

			array(
				'type' => 'select',
				'before' => '<p style="font-weight:bold">'.__('第三个页面','momo').'</p>',
				'key' => 'home_page3',
				'value' => array(
					'default' => $home_page3,
					'option' => $page_array
				)
			),
			
			array(
				'type' => 'input',
				'before' => '<p>'.__('描述（支持 html标签）','momo').'</p>',
				'key' => 'home_page3_des',
				'value' => $home_page3_des
			)
			
			) );
			
			
			/******处理数据*****/  
			echo '<div>';
			
			echo '<div style="vertical-align: top;display:inline-block;padding: 20px 10px 20px 0px;width: 200px;line-height: 1.3;font-size:14px;font-weight: 600;"></div>';   
		 
			echo '<div style="padding:10px;display:inline-block">
			<p style="margin-bottom:3px;font-size:14px">设置图标</p>
			<input type="text" size="60" value="'.get_option('page3_icon').'" name="page3_icon" class="wpmomo_url_input" id="wpmomo_upload_input"/>
			<a id="page3_icon" class="wpmomo_upload_button button" href="#">选择或上传</a></div>';   
			   
			echo '<p><input type="hidden" value="1" name="save_wpmomo_options"/></p>';   
			
			echo '</div>';
			
			
			$option->table( array(
			
			array(
				'type' => 'select',
				'th' => __('首页第一个分类','momo'),
				'before' => '<p>'.__('请选择是否显示','momo').'</p>',
				'key' => 'category1',
				'value' => array(
					'default' => array($category1),
					'option' => array(
						1 => __( '显示', 'momo' ),
						0 => __( '不显示', 'momo' )
					)
				)
			),
						
			array(
				'type' => 'select',
				'before' => '<p>'.__('请选择一个文章分类','momo').'</p>',
				'key' => 'home_category1',
				'value' => array(
					'default' => $home_category1,
					'option' => $categories_array
				)
			),

			array(
				'type' => 'input',
				'before' => '<p>'.__('请指定共显示几页(填写一个整数)','momo').'</p>',
				'key' => 'home_num1',
				'value' => $home_num1
			),

			array(
				'type' => 'select',
				'th' => __('第一个分类下面的页面','momo'),
				'before' => '<p>'.__('请选择是否显示','momo').'</p>',
				'key' => 'catpage',
				'value' => array(
					'default' => array($catpage),
					'option' => array(
						1 => __( '显示', 'momo' ),
						0 => __( '不显示', 'momo' )
					)
				)
			),

			array(
				'type' => 'select',
				'before' => '<p style="font-weight:bold">'.__('请选择页面','momo').'</p>',
				'key' => 'cat_page',
				'value' => array(
					'default' => $cat_page,
					'option' => $page_array
				)
			),

			array(
				'type' => 'input',
				'before' => '<p>'.__('描述（支持 html标签）','momo').'</p>',
				'key' => 'cat_page_des',
				'value' => $cat_page_des			
			),


			array(
				'type' => 'select',
				'th' => __('首页第二个分类','momo'),
				'before' => '<p>'.__('请选择是否显示','momo').'</p>',
				'key' => 'category2',
				'value' => array(
					'default' => array($category2),
					'option' => array(
						1 => __( '显示', 'momo' ),
						0 => __( '不显示', 'momo' )
					)
				)
			),
						
			array(
				'type' => 'select',
				'before' => '<p>'.__('请选择一个文章分类','momo').'</p>',
				'key' => 'home_category2',
				'value' => array(
					'default' => $home_category2,
					'option' => $categories_array
				)
			),

			array(
				'type' => 'input',
				'before' => '<p>'.__('请指定共显示几页(填写一个整数)','momo').'</p>',
				'key' => 'home_num2',
				'value' => $home_num2
			),

			array(
				'type' => 'select',
				'th' => __('文章列表','momo'),
				'before' => '<p>'.__('首页文章列表','momo').'</p>',
				'key' => 'home_post',
				'value' => array(
					'default' => array($home_post),
					'option' => array(
						1 => __( '最新发表的', 'momo' ),
						2 => __( '最后更新的', 'momo' ),
						3 => __( '评论最多的', 'momo' ),
						0 => __( '不显示', 'momo' )
					)
				)
			),

			array(
				'type' => 'input',
				'th' => __('文章列表标题','momo'),
				'before' => '<p>'.__('如：最新文章。留空不显示','momo').'</p>',
				'key' => 'home_post_title',
				'value' => $home_post_title
			),

			array(
				'type' => 'select',
				'th' => __('排除文章','momo'),
				'before' => '<p>'.__('置顶显示置顶文章','momo').'</p>',
				'key' => 'home_ignore_sticky_posts',
				'value' => array(
					'default' => array($home_ignore_sticky_posts),
					'option' => array(
						0 => __( '可以置顶', 'momo' ),

						1 => __( '不置顶', 'momo' ),
					)
				)
			),

			array(
				'type' => 'checkbox',
				'th' => __('文章列表排除分类','momo'),
				'before' => '<p>'.__('选择排除的分类，留空则不排除任何分类','momo').'</p>',
				'key' => 'home_post_exclude',
				'value' => array(
					'default' => $home_post_exclude,
					'option' => $categories_array
				)
			)

		) );

			/******以下是添加的js****/  
    wp_enqueue_media(); //在设置页面需要加载媒体中心   
    ?>   
    <script>   
    jQuery(document).ready(function(){   
    var wpmomo_upload_frame;   
    var value_id;   
    jQuery('.wpmomo_upload_button').live('click',function(event){   
        value_id =jQuery( this ).attr('id');       
        event.preventDefault();   
        if( wpmomo_upload_frame ){   
            wpmomo_upload_frame.open();   
            return;   
        }   
        wpmomo_upload_frame = wp.media({   
            title: '插入图像',   
            button: {   
                text: '选择',   
            },   
            multiple: false   
        });   
        wpmomo_upload_frame.on('select',function(){   
            attachment = wpmomo_upload_frame.state().get('selection').first().toJSON();   
            jQuery('input[name='+value_id+']').val(attachment.url);   
        });   
           
        wpmomo_upload_frame.open();   
    });   
    });   
    </script>  

		<p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="<?php _e( '保存更改', 'momo' );?>"></p>
	</form>

</div>

<?php
}
?>



