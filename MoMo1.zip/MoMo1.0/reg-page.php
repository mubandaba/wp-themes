    <?php
    //下面这一句是必须的，表示当前模板的名称
    /*Template Name: Register*/
      
    //如果用户已经登陆那么跳转到首页
    if (is_user_logged_in()){
      //重定向浏览器
      wp_safe_redirect( get_option('home') );
      //确保重定向后，后续代码不会被执行
      exit;
    }
      
    //获取注册页面提交时候的表单数据
    $redirect_to = sanitize_user( $_REQUEST['redirect_to'] );
    if( !empty($_POST['csyor_reg']) ) {
      $error = '';
      $sanitized_user_login = sanitize_user( $_POST['user_login'] );
      $user_website = sanitize_user( $_POST['website'] );
      $user_description = sanitize_user( $_POST['description'] );
      $user_nickname = sanitize_user( $_POST['nickname'] );
      $user_email = apply_filters( 'user_registration_email', $_POST['user_email'] );
      $comment_aaa          = ( isset($_POST['aaa']) ) ? trim($_POST['aaa']) : '0';
      $comment_bbb          = ( isset($_POST['bbb']) ) ? trim($_POST['bbb']) : '0';
      $comment_subab        = ( isset($_POST['subab']) ) ? trim($_POST['subab']) : '0';
      
      // 验证邮箱
      if ( $user_email == '' ) {
        $error .= '<strong>错误</strong>：请填写电子邮件地址。';
      } elseif ( ! is_email( $user_email ) ) {
        $error .= '<strong>错误</strong>：电子邮件地址不正确。';
        $user_email = '';
      } elseif ( email_exists( $user_email ) ) {
        $error .= '<strong>错误</strong>：该电子邮件地址已经被注册，请换一个。';
      }
      
      // 验证用户名
      elseif ( $sanitized_user_login == '' ) {
        $error .= '<strong>错误</strong>：请输入登陆账号。';
      } elseif ( !preg_match("/^[a-zA-Z0-9_]{6,16}$/",$sanitized_user_login) ) {
        $error .= '<strong>错误</strong>：登陆账号只能包含字母、数字、下划线，长度6到16位。';
        $sanitized_user_login = '';
      } elseif ( username_exists( $sanitized_user_login ) ) {
        $error .= '<strong>错误</strong>：该用户名已被注册，请再选择一个。';
      }
      
      //验证密码
      elseif(strlen($_POST['user_pass']) < 6){
        $error .= '<strong>错误</strong>：密码长度至少6位。';
      }elseif($_POST['user_pass'] != $_POST['user_pass2']){
        $error .= '<strong>错误</strong>：两次输入的密码必须一致。>';
      }elseif(((int)$comment_subab)!=(((int)$comment_aaa)+((int)$comment_bbb))){
        $error .= '<strong>错误</strong>：请输入正确的验证数字。'; 
      }
      
      if($error == '') {
        //验证全部通过进入注册信息添加
        $display_name = empty($user_nickname)?$sanitized_user_login:$user_nickname;
        $user_pass = $_POST['user_pass'];
        $user_id = wp_insert_user( array ( 
          'user_login' => $sanitized_user_login, 
          'user_pass' => $user_pass , 
          'nickname' => $user_nickname,
          'display_name' => $display_name, 
          'user_email' => $user_email, 
          'user_url' => $user_website,
          'description' => $user_description) ) ;
        
        //意外情况判断，添加失败
        if ( ! $user_id ) {
          $error .= sprintf( '<p><strong>错误</strong>：无法完成您的注册请求... 请联系<a href=\"mailto:%s\">管理员</a>！</p>', get_option( 'admin_email' ) );
        }else if (!is_user_logged_in()) {
          //注册成功发送邮件通知用户
          $to = $user_email;
          $subject = '您在 [' . get_option("blogname") . '] 的注册已经成功';
          $message = '<div style="background-color:#eef2fa; border:1px solid #d8e3e8; color:#111; padding:0 15px; -moz-border-radius:5px; -webkit-border-radius:5px; -khtml-border-radius:5px; border-radius:5px;">
            <p>' . $user_nickname . ', 您好!</p>
            <p>感谢您在 [' . get_option("blogname") . '] 注册用户~</p>
            <p>你的注册信息如下:<br />
            账号：'. $sanitized_user_login . '<br />
            邮箱：'. $user_email . '<br />
            密码：'. $_POST['user_pass'] . '<br />
            </p>
            <p>欢迎光临 <a href="' . get_option('home') . '">' . get_option('blogname') . '</a>。</p>
      <p>(此郵件由系統自動發出, 請勿回覆.)</p>
      </div>';
          $from = "From: \"" . get_option('blogname') . "\" <$wp_email>";
          $headers = "$from\nContent-Type: text/html; charset=" . get_option('blog_charset') . "\n";
          wp_mail( $to, $subject, $message, $headers );
          
          $user = get_userdatabylogin($sanitized_user_login);
          $user_id = $user->ID;
          
          // 自动登录
          wp_set_current_user($user_id, $user_login);
          wp_set_auth_cookie($user_id);
          do_action('wp_login', $user_login);
          
          wp_safe_redirect( $redirect_to );
        }
      }
    } 
    ?>
      
<!--下面部分是页面显示部分-->
<?php get_header(); ?>
    
<?php get_header('top'); ?>

<div id="main" class="container" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">

  <div class="row">

    <article id="content" class="container" data-post-id="<?php the_ID(); ?>" role="article" itemscope itemtype="http://schema.org/Article">

				<div class="entry-breadcrumb clearfix" role="toolbar"><span class="glyphicon glyphicon-home" style="margin-right:8px"></span><?php momo_breadcrumb_html(get_the_ID(),'&nbsp› &nbsp'); ?></div>

				<div class="panel-body" style="padding-bottom:100px;">

						<div class="col-lg-10 col-md-10 col-sm-12" style="margin:0 auto;float:none;"  itemprop="articleBody">


						<div class="col-lg-6 col-md-6 col-sm-12">


      <?php if(!empty($error)) {
        //输出错误提示信息
        echo '<p class="ludou-error">'.$error.'</p>';
      }
      if (!is_user_logged_in()) { ?>
      <form name="registerform" method="post" action="#" class="ludou-reg">

      <p>
      <input type="text" name="user_login" tabindex="1" id="user_login" class="input" value="<?php if(!empty($sanitized_user_login)) echo $sanitized_user_login; ?>" placeholder="<?php _e('用户名 &hellip;','momo');?>"/>
      </p>

      <p>
      <input id="user_pwd1" class="input" tabindex="3" type="password" tabindex="21"  value="" name="user_pass" placeholder="<?php _e('密码(请输入大于6位字符的密码) &hellip;','momo');?>"/>
      </p>

      <p>
      <input id="user_pwd2" class="input" tabindex="4" type="password" tabindex="21"  value="" name="user_pass2"  placeholder="<?php _e('重复密码 &hellip;','momo');?>"/>
      </p>

      <p>
      <input type="text" name="user_email" tabindex="2" id="user_email" class="input" value="<?php if(!empty($user_email)) echo $user_email; ?>" placeholder="<?php _e('电子邮箱 &hellip;','momo');?>"/>
      </p>
      
      <p>
      <input class="input" id="nickname" class="input" type="text" tabindex="5" size="25"  name="nickname" placeholder="<?php _e('昵称 &hellip;','momo');?>" />
      </p>

      <p>
      <input class="input" id="website" class="input" type="text" tabindex="6" size="25"  name="website"  placeholder="<?php _e('站点 &hellip;','momo');?>" />
      </p>
      
      <p>
      <textarea class="input" id="description" name="description" rows="3" cols="120" style="height:130px;" placeholder="<?php _e('个人说明 &hellip;','momo');?>"></textarea>
      </p>
      
      <p>
      <?php $aaa=rand(0,9); $bbb=rand(1,9); ?>
      <input class="input" type="text" name="subab" id="subab" size="25" tabindex="8" placeholder="验证：请输入计算结果: <?php echo $aaa; ?>+<?php echo $bbb; ?>=?" />
      </p>

      <input name="aaa" value="<?php echo $aaa; ?>" type="hidden" />
      <input name="bbb" value="<?php echo $bbb; ?>" type="hidden" />
      
      <p class="login-submit" align="center">
      <input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" tabindex="7" value="用户注册" />
      <input type="hidden" name="csyor_reg" value="ok" />
      <input type="hidden" name="redirect_to" value="<?php echo $redirect_to; ?>"/>
      </p>

      </form>
      <?php 
             } else {
         echo '<p class="ludou-error">您已注册成功，并已登录！</p>';
       }
      ?>
         
     
 
</div>
						 


            <div class="col-lg-6 col-md-6 col-sm-12" >
              <div class="login">
              <div style="margin:15px auto;font-size:13px;width:200px;">无需注册，使用新浪微博账号登录</div>
              <?php
                $qq_open = intval(get_option('dmeng_open_qq',0));
                if ($qq_open) {
                ?>
                <a href="<?php echo  dmeng_get_open_login_url('qq', 'login', dmeng_get_current_page_url()); ?>"><div class="loginqq">QQ账号登录</div></a>
                <?php } 
                $weibo_open = intval(get_option('dmeng_open_weibo',0));
                if ($weibo_open) {
                ?>
                <a href="<?php echo  dmeng_get_open_login_url('weibo', 'login', dmeng_get_current_page_url()); ?>"><div class="loginweibo">新浪微博账号登录</div></a>
                <?php 
                }
                ?>
              </div>


                
             
  					</div>


					   </div>

				    </div>



		 </article><!-- #content -->		

	</div>

 </div><!-- #main -->

<?php get_footer('colophon'); ?>

<?php get_footer(); ?>