</div><div class="clear"></div>
<?php wp_footer(); ?>
</body>

<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/jQuery.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/jQuery.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/ice.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/fancyboxmin.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/comments-ajax.js"></script>
</html>