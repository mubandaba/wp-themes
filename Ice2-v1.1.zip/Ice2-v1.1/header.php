<!DOCTYPE html>
<html>
<head>
	<title><?php
			if ( is_tag() ) { echo wp_title('Tag:'); if($paged > 1) printf(' - 第%s页',$paged); echo ' | '; bloginfo( 'name' ); }
			elseif ( is_archive() ) { echo wp_title(''); if($paged > 1) printf(' - 第%s页',$paged); echo ' | '; bloginfo( 'name' ); }
			elseif ( is_search() ) { echo '&quot;'.wp_specialchars($s).'&quot;的搜索结果 | '; bloginfo( 'name' ); }
			elseif ( is_home() ) {bloginfo( 'name' ); $paged = get_query_var('paged'); if($paged > 1) printf(' - 第%s页',$paged); }
			elseif ( is_404() ) {echo '页面不存在！ | '; bloginfo( 'name' ); }
			else { echo wp_title( ' | ', false, right ); bloginfo( 'name' ); }
	?></title>

	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />	
	<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1" />
	<meta name="keywords" content="<?php echo get_option('mytheme_keywords'); ?>" />
	<meta name="description" content="<?php echo get_option('mytheme_description'); ?>" />
	<?php if( is_single() || is_page() ) {
    if( function_exists('get_query_var') ) {
        $cpage = intval(get_query_var('cpage'));
        $commentPage = intval(get_query_var('comment-page'));
    }
    if( !empty($cpage) || !empty($commentPage) ) {
        echo '<meta name="robots" content="noindex, nofollow" />';
        echo "\n";
    }
	}
	?>
	<?php echo get_option('mytheme_headinfo'); ?>

	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
	<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
	<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/PIE.js"></script>
	<!--[if lt IE 9]>
	<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/html5.js"></script>
	<![endif]-->
	<!--[if IE 6]>
	<script src="http://letskillie6.googlecode.com/svn/trunk/2/zh_CN.js"></script>
	<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/DD_belatedPNG.js"></script>
	<script type="text/javascript">
		DD_belatedPNG.fix("*");
	</script>
	<![endif]-->
	
	<?php wp_get_archives('type=monthly&format=link'); ?>
	<?php wp_head(); ?>
</head>
<body>
<div class="container">
<div class="topmenucon w680 left"><?php ice_menu('topmenu', 0); ?></div>