<?php
	
add_action('admin_menu', 'light_admin_menu');
function light_admin_menu() {
	add_theme_page(__( '主题设置', 'light' ), __( '主题设置', 'light' ), 'edit_themes', basename(__FILE__), 'light_settings_page');
	add_action( 'admin_init', 'light_settings' );
}

function light_settings() {
	register_setting( 'light-settings-group', 'light_options' );
}

function light_settings_page() {
if ( isset($_REQUEST['updated']) ) echo '<div id="message" class="updated fade"><p><strong> settings saved.</strong></p></div>';
if( 'reset' == isset($_REQUEST['reset']) ) {
	delete_option('light_options');
	echo '<div id="message" class="updated fade"><p><strong> settings reset.</strong></p></div>';
}
?>
<style type="text/css">
.clearfix{clear:both}
.light_nodisplay{display:none}
.wrap{margin:0 0 50px 10px}
.light_option_wrap{margin:0; width:850px; font-size:13px; font-family: "Century Gothic", "Lucida Grande", Helvetica, Arial, 微软雅黑; border-left:1px solid #DFDFDF; border-bottom:1px solid #DFDFDF; border-right:1px solid #DFDFDF; background:#fff; 
border-bottom-left-radius:5px 5px;border-bottom-right-radius:5px 5px;border-top-right-radius:5px 5px;overflow:hidden}
.light_option_section{width:850px; height:50px; background:#eee}
.light_option_section h2{margin:0 0 0 30px; font-size:15px; font-family:"Century Gothic", "Lucida Grande", Helvetica, Arial, 微软雅黑; color:#777; font-style:normal}
.light_option{width:850px; display:block; border-top:1px solid #DFDFDF}
.light_option .cbbox_checked{}
.light_option_l{float:left; width:150px}
.light_option_l label{margin:20px 0 20px 20px; width:150px; display:block; font-size:13px}
.light_option_m{float:left; width:450px; margin:20px 0 20px 0}
.light_option_m input{font-size:13px; font-family: "Century Gothic", "Lucida Grande", Helvetica, Arial, 微软雅黑; color:#777}
.light_option_m .radio_options{margin:0 20px 0 5px; position:relative}
.light_option_m input[type="text"], .light_option_m select{width:430px; font-size:13px; font-family: "Century Gothic", "Lucida Grande", Helvetica, Arial, 微软雅黑; padding:4px; color:#333; line-height:1em; background:#f3f3f3}
.light_option_m input:focus, .light_option_m textarea:focus{background:#fff}
.light_option_m textarea{width:430px; height:60px; font-size:12px; padding:4px; color:#333; line-height:1.5em; background:#f3f3f3}
.light_option_r{float:left; width:220px}
.light_option_r small{margin:20px 0 20px 20px; width:200px; display:block; font-size:12px; color:#777}
#light_nav_list{margin:30px 0 0 0;}
#light_nav_list ul.light_tabs_js{width:850px; list-style:none}
#light_nav_list ul.light_tabs_js li{float:left; margin:0 15px 0 0px; padding:5px 13px; border-left:1px solid #DFDFDF; border-top:1px solid #DFDFDF; border-right:1px solid #DFDFDF; cursor:pointer;border-top-left-radius:5px 5px;border-top-right-radius:5px 5px;}
#light_nav_list ul.light_tabs_js li.selected{background:#EEE; border-left:1px solid #DFDFDF; border-top:1px solid #DFDFDF; border-right:1px solid #DFDFDF;border-top-left-radius:5px 5px;border-top-right-radius:5px 5px;}
#light_nav_list .light_inside{margin:0}
#light_nav_list .light_inside ul{padding:0; list-style:none}
.light_helppage{padding:20px 25px 20px 25px; width:800px; display:block; border-top:1px solid #eee}
.light_helppage p{font-size:13px}
.light_submit_form{float:left; margin:20px 0 0 0; display:block}
.light_reset_form{float:left; margin:20px 0 0 20px; display:block}
#light_admin_ie_warning_disable{float:right; color:#777; cursor:pointer}
#light_admin_ie_warning_disable:hover{color:#333}
.none{display:none}
fieldset{width:80%; margin:15px 0 10px 74px; padding:10px 0 20px 20px; border:1px solid #EEE}
fieldset legend{ cursor:pointer;  font-size:13px;  color:#FFF; background:#2683AE; border-color:#EEE; -moz-box-shadow:0 0 5px #EEE; -webkit-box-shadow:0 0 5px #EEE; box-shadow:0 0 5px #EEE; padding:2px 15px 4px 15px; -webkit-border-radius:30px; -moz-border-radius:30px; border-radius:30px; -webkit-box-shadow:1px 1px 1px rgba(0,0,0,.29),inset 1px 1px 1px rgba(255,255,255,.44); -moz-box-shadow:1px 1px 1px rgba(0,0,0,.29),inset 1px 1px 1px rgba(255,255,255,.44); box-shadow:1px 1px 1px rgba(0,0,0,.29),inset 1px 1px 1px rgba(255,255,255,.44)}
</style>
<script type="text/javascript">
jQuery(document).ready(function($){
	jQuery.cookie=function(b,j,m){if(typeof j!="undefined"){m=m||{};if(j===null){j="";m.expires=-1}var e="";if(m.expires&&(typeof m.expires=="number"||m.expires.toUTCString)){var f;if(typeof m.expires=="number"){f=new Date();f.setTime(f.getTime()+(m.expires*24*60*60*1000))}else{f=m.expires}e="; expires="+f.toUTCString()}var l=m.path?"; path="+(m.path):"";var g=m.domain?"; domain="+(m.domain):"";var a=m.secure?"; secure":"";document.cookie=[b,"=",encodeURIComponent(j),e,l,g,a].join("")}else{var d=null;if(document.cookie&&document.cookie!=""){var k=document.cookie.split(";");for(var h=0;h<k.length;h++){var c=jQuery.trim(k[h]);if(c.substring(0,b.length+1)==(b+"=")){d=decodeURIComponent(c.substring(b.length+1));break}}}return d}};
	jQuery("input.light_cbbox:checked").each(function() {jQuery(this).parents().children(".cbbox_checked").show();}); jQuery("input.light_cbbox").click(function () {if (jQuery(this).is(":checked")){jQuery(this).parents().children(".cbbox_checked").show();} else {jQuery(this).parents().children(".cbbox_checked").hide();}});
	jQuery("input.light_cbradio_op:checked").each(function() {jQuery(this).parents().children(".cbradio_checked").show();}); jQuery("input.light_cbradio_op").click(function () {if (jQuery(this).is(":checked")){jQuery(this).parents().children(".cbradio_checked").show();} else {jQuery(this).parents().children(".cbradio_checked").hide();}});jQuery("input.light_cbradio_cl").click(function () {if (jQuery(this).is(":checked")){jQuery(this).parents().children(".cbradio_checked").hide();} else {jQuery(this).parents().children(".cbradio_checked").show();}});
	jQuery('.light_inside ul li:last-child').css('border-bottom','0px');jQuery('.light_tabs_js').each(function(){jQuery(this).children('li:first').addClass('selected');});jQuery('.light_inside > *').hide();jQuery('.light_inside > *:first-child').show();jQuery('.light_tabs_js li').click(function(evt){var clicked_tab_ref = jQuery(this).attr('title');jQuery(this).parent().children('li').removeClass('selected');jQuery(this).addClass('selected');jQuery(this).parent().parent().children('.light_inside').children('*').hide();jQuery('.light_inside ' + clicked_tab_ref).show();evt.preventDefault();});
	function light_upgradeie(){if(jQuery.browser.msie && parseInt(jQuery.browser.version) <= 8){ return true;}return false;};var light_upiew = jQuery.cookie('light_upgradeiewarning');if(light_upgradeie() && light_upiew != 'seen' ){jQuery(function(){jQuery("#light_admin_ie_warning").fadeIn(500);jQuery('#light_admin_ie_warning_disable').click(function(){jQuery.cookie('light_upgradeiewarning', 'seen');jQuery("#light_admin_ie_warning").fadeOut(500);return false;});});};
	$(".toggle").click(function(){$(this).next().slideToggle('slow')});
});
</script>

<div class="wrap">
	<div id="icon-options-general" class="icon32"><br></div><h2>主题设置</h2><br>	
	<div id="light_admin_ie_warning" class="light_nodisplay updated fade"><p><strong> <?php _e('建议: 为了获得更好的体验，请不要使用IE浏览器.','light') ?><span id="light_admin_ie_warning_disable">Close [X]</span></strong></p></div>
		<form method="post" action="options.php">
		<?php settings_fields( 'light-settings-group' ); ?>
		<?php $options = get_option('light_options'); ?>
		<div id="light_nav_list">
			<ul class="light_tabs_js">
				<li class="tabs_general" title="#lu-tab-general"><?php _e('网站设置','light') ?></li>
				<li class="tabs_appearance" title="#lu-tab-header"><?php _e('外观设置','light') ?></li>
				<li class="tabs_functions" title="#lu-tab-functions"><?php _e('功能设置','light') ?></li>
				<li class="tabs_frame" title="#lu-tab-frame"><?php _e('幻灯片','light') ?></li>
				<li class="tabs_fave" title="#lu-tab-post"><?php _e('我的收藏','light') ?></li>
				<li class="tabs_slide" title="#lu-tab-slide"><?php _e('个性链接','light') ?></li>
				<li class="tabs_sns" title="#lu-tab-sns"><?php _e('SNS设置','light') ?></li>
				<li class="tabs_readme" title="#lu-tab-readme"><?php _e('主题说明','light') ?></li>
			</ul>
			<div class="light_inside">
				<ul id="lu-tab-general" class="list lu-tab-list">
					<div class="light_option_wrap">
						<div class="light_option_section">
							<h2><?php _e('网站设置','light') ?></h2>
						</div>

						<div class="light_option">
							<div class="light_option_l"><label for="light_options[description_content]"><?php _e('网站描述','light') ?></label></div>
							<div class="light_option_m">
								<textarea type="textarea" name="light_options[description_content]"><?php echo $options['description_content']; ?></textarea>
							</div>
							<div class="light_option_r"><small><?php _e('用简洁凝练的话对你的网站进行描述','light') ?></small></div>
							<div class="clearfix"></div>
						</div><!-- .light_option -->

						<div class="light_option">
							<div class="light_option_l"><label for="light_options[keyword_content]"><?php _e('网站关键词','light') ?></label></div>
							<div class="light_option_m">
								<textarea type="textarea" name="light_options[keyword_content]"><?php echo $options['keyword_content']; ?></textarea>
							</div>
							<div class="light_option_r"><small><?php _e('多个关键词请用英文逗号隔开','light') ?></small></div>
							<div class="clearfix"></div>
						</div><!-- .light_option -->

						<div class="light_option">
							<div class="light_option_l"><label for="light_options[statistics]"><?php _e('网站统计','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[statistics]" class="light_cbradio_cl" value="" <?php checked('', $options['statistics']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[statistics]" class="light_cbradio_op" value="1" <?php checked('1', $options['statistics']); ?>/> <?php _e('使用','light') ?></span>
							</div>
							<div class="light_option_r"><small><?php _e('网站统计代码设置','light') ?></small></div>
							<div class="clearfix"></div>
							<div class="cbradio_checked light_nodisplay">
								<div class="light_option_l"><label for="light_options[statisticscode]"><?php _e('统计代码','light') ?></label></div>
								<div class="light_option_m"><textarea  type="textarea" name="light_options[statisticscode]"><?php echo $options['statisticscode']; ?></textarea></div>
								<div class="light_option_r"><small><?php _e('输入统计代码。<br />统计代码不会在页面中显示，但统计功能是正常的','light') ?></small></div>
								<div class="clearfix"></div>
							</div>
						</div><!-- .light_option -->
						
					</div><!-- .light_option_wrap -->
				</ul><!-- #lu-tab-general -->

				<ul id="lu-tab-header" class="list lu-tab-list">
					<div class="light_option_wrap">
						<div class="light_option_section">
							<h2><?php _e('这里进行一些基本的外观设置，其中logo的大小为180*60','light') ?></h2>
						</div>

						<div class="light_option">
							<div class="light_option_l"><label for="light_options[favicon_ck]"><?php _e('Favicon图标','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[favicon_ck]" class="light_cbradio_cl" value="" <?php checked('', $options['favicon_ck']); ?>/> <?php _e('使用默认','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[favicon_ck]" class="light_cbradio_op" value="1" <?php checked('1', $options['favicon_ck']); ?>/> <?php _e('自定义','light') ?></span>
							</div>
							<div class="light_option_r"><small><?php _e('这里是设置Favicon图标','light') ?></small></div>
							<div class="clearfix"></div>
							<div class="cbradio_checked light_nodisplay">
								<div class="light_option_l"><label for="light_options[custom_favicon]"><?php _e('自定义Favicon图标','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[custom_favicon]" value="<?php echo $options['custom_favicon']; ?>"/></div>
								<div class="light_option_r"><small><?php _e('输入你的Favicon图标链接','light') ?></small></div>
								<div class="clearfix"></div>
							</div>
						</div><!-- .light_option -->
						
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[custom_logo]"><?php _e('网站LOGO','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[custom_logo]" class="light_cbradio_cl" value="" <?php checked('', $options['custom_logo']); ?>/> <?php _e('使用默认','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[custom_logo]" class="light_cbradio_op" value="1" <?php checked('1', $options['custom_logo']); ?>/> <?php _e('自定义','light') ?></span>
							</div>
							<div class="light_option_r"><small><?php _e('这里是设置LOGO','light') ?></small></div>
							<div class="clearfix"></div>
							<div class="cbradio_checked light_nodisplay">
								<div class="light_option_l"><label for="light_options[logo_url]"><?php _e('自定义LOGO','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[logo_url]" value="<?php echo $options['logo_url']; ?>"/></div>
								<div class="light_option_r"><small><?php _e('输入你的LOGO图片的链接','light') ?></small></div>
								<div class="clearfix"></div>
							</div>
						</div><!-- .light_option -->

					</div><!-- .light_option_wrap -->
				</ul><!-- #lu-tab-header -->
				
				<ul id="lu-tab-functions" class="list lu-tab-list">
					<div class="light_option_wrap">
						<div class="light_option_section">
							<h2><?php _e('功能设置','light') ?></h2>
						</div>
						
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[thumbnail]"><?php _e('是否为每篇文章<br/>自动匹配一张缩略图','muzzz') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[thumbnail]" class="light_cbradio_cl" value="" <?php checked('', $options['thumbnail']); ?>/> <?php _e('否','muzzz') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[thumbnail]" class="light_cbradio_op" value="1" <?php checked('1', $options['thumbnail']); ?>/> <?php _e('是','muzzz') ?></span>
							</div>
							<div class="light_option_r"><small><?php _e('该功能为每篇普通样式的文章自动匹配一张缩略图。缩略图显示原理：如果你为文章设置缩略图则显示你设置的缩略图；若没有，则获取文章第一张图片作为缩略图；否则则显示主题内置的缩略图','muzzz') ?></small></div>
							<div class="clearfix"></div>
						</div><!-- .light_option -->
						
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[editor]"><?php _e('增强编辑器','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[editor]" class="light_cbradio_cl" value="" <?php checked('', $options['editor']); ?>/> <?php _e('否','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[editor]" class="light_cbradio_op" value="1" <?php checked('1', $options['editor']); ?>/> <?php _e('是','light') ?></span>
							</div>
							<div class="light_option_r"><small><?php _e('是否增强WordPress的默认编辑器','light') ?></small></div>
							<div class="clearfix"></div>
						</div><!-- .light_option -->
						
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[lazyload]"><?php _e('图片延时加载','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[lazyload]" class="light_cbradio_cl" value="" <?php checked('', $options['lazyload']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[lazyload]" class="light_cbradio_op" value="1" <?php checked('1', $options['lazyload']); ?>/> <?php _e('使用','light') ?></span>
							</div>
							<div class="light_option_r"><small><?php _e('图片延时加载是指在浏览器可视区域外的图片不会被载入，当页面滚动到它们所在的位置时才可见。该功能可加快页面载入速度，降低服务器负担','light') ?></small></div>
							<div class="clearfix"></div>
						</div><!-- .light_option -->
						
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[jQuery]"><?php _e('jQuery库选择','light') ?></label></div>
							<div class="light_option_m">
								调用新浪在线jQuery库
								<span class="radio_options"><input type="radio" name="light_options[sinajq]" class="light_cbradio_cl" value="" <?php checked('', $options['sinajq']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[sinajq]" class="light_cbradio_op" value="1" <?php checked('1', $options['sinajq']); ?>/> <?php _e('使用','light') ?></span>
								<div class="clearfix"></div><p/>
								调用谷歌在线jQuery库
								<span class="radio_options">&nbsp;&nbsp;&nbsp;<input type="radio" name="light_options[googlejq]" class="light_cbradio_cl" value="" <?php checked('', $options['googlejq']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[googlejq]" class="light_cbradio_op" value="1" <?php checked('1', $options['googlejq']); ?>/> <?php _e('使用','light') ?></span>
								<div class="clearfix"></div><p/>
								调用主题自带jQuery库
								<span class="radio_options">&nbsp;&nbsp;&nbsp;<input type="radio" name="light_options[selfjq]" class="light_cbradio_cl" value="" <?php checked('', $options['selfjq']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[selfjq]" class="light_cbradio_op" value="1" <?php checked('1', $options['selfjq']); ?>/> <?php _e('使用','light') ?></span>
							</div>
							<div class="light_option_r"><small><?php _e('jQuery库必须且只能选一个，不要多选。因为众所周知的原因，谷歌的服务不稳定；为了稳妥和减轻主机负担，建议调用新浪的在线jQuery库','light') ?></small></div>
							<div class="clearfix"></div>
							
						</div><!-- .light_option -->
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[offwpjq]"><?php _e('强制关闭WP自带JQ库','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[offwpjq]" class="light_cbradio_cl" value="" <?php checked('', $options['offwpjq']); ?>/> <?php _e('否','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[offwpjq]" class="light_cbradio_op" value="1" <?php checked('1', $options['offwpjq']); ?>/> <?php _e('是','light') ?></span>
							</div>
							<div class="light_option_r"><small><?php _e('如果您发现有一些插件使用后会导致JS特效不正常，可开启此选项。','light') ?></small></div>
							<div class="clearfix"></div>
						</div><!-- .light_option -->						
					</div><!-- .light_option_wrap -->
				</ul><!-- #lu-tab-header -->
				
				<ul id="lu-tab-frame" class="list lu-tab-list">
					<div class="light_option_wrap">
						<div class="light_option_section"><h2><?php _e('幻灯片所用图片的大小为：405*145，请严格按照只尺寸来选择图片','light') ?></h2></div>
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[slide1]"><?php _e('第一张幻灯','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[slide1]" class="light_cbradio_cl" value="" <?php checked('', $options['slide1']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[slide1]" class="light_cbradio_op" value="1" <?php checked('1', $options['slide1']); ?>/> <?php _e('使用','light') ?></span>
							</div>
							<div class="clearfix"></div>
							<div class="cbradio_checked light_nodisplay">
								<div class="light_option_l"><label for="light_options[slideimg1]"><?php _e('图片地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[slideimg1]" value="<?php echo $options['slideimg1']; ?>"/></div>								
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[slidelink1]"><?php _e('链接地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[slidelink1]" value="<?php echo $options['slidelink1']; ?>"/></div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[slidestext1]"><?php _e('是否填写文本文本','light') ?></label></div>
								<div class="light_option_m">
									<span class="radio_options"><input type="radio" name="light_options[slidestext1]" class="light_cbradio_cl" value="" <?php checked('', $options['slidestext1']); ?>/> <?php _e('否','light') ?></span>
									<span class="radio_options"><input type="radio" name="light_options[slidestext1]" class="light_cbradio_op" value="1" <?php checked('1', $options['slidestext1']); ?>/> <?php _e('是','light') ?></span>
								</div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[slidetitle1]"><?php _e('文本标题','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[slidetitle1]" value="<?php echo $options['slidetitle1']; ?>"/></div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[slideintro1]"><?php _e('文本内容','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[slideintro1]" value="<?php echo $options['slideintro1']; ?>"/></div>
								<div class="clearfix"></div>
							</div>
						</div><!-- .light_option -->
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[slide2]"><?php _e('第二张幻灯','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[slide2]" class="light_cbradio_cl" value="" <?php checked('', $options['slide2']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[slide2]" class="light_cbradio_op" value="1" <?php checked('1', $options['slide2']); ?>/> <?php _e('使用','light') ?></span>
							</div>
							<div class="clearfix"></div>
							<div class="cbradio_checked light_nodisplay">
								<div class="light_option_l"><label for="light_options[slideimg2]"><?php _e('图片地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[slideimg2]" value="<?php echo $options['slideimg2']; ?>"/></div>								
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[slidelink2]"><?php _e('链接地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[slidelink2]" value="<?php echo $options['slidelink2']; ?>"/></div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[slidestext2]"><?php _e('是否填写文本文本','light') ?></label></div>
								<div class="light_option_m">
									<span class="radio_options"><input type="radio" name="light_options[slidestext2]" class="light_cbradio_cl" value="" <?php checked('', $options['slidestext2']); ?>/> <?php _e('否','light') ?></span>
									<span class="radio_options"><input type="radio" name="light_options[slidestext2]" class="light_cbradio_op" value="1" <?php checked('1', $options['slidestext2']); ?>/> <?php _e('是','light') ?></span>
								</div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[slidetitle2]"><?php _e('文本标题','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[slidetitle2]" value="<?php echo $options['slidetitle2']; ?>"/></div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[slideintro2]"><?php _e('文本内容','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[slideintro2]" value="<?php echo $options['slideintro2']; ?>"/></div>
								<div class="clearfix"></div>
							</div>
						</div><!-- .light_option -->
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[slide3]"><?php _e('第三张幻灯','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[slide3]" class="light_cbradio_cl" value="" <?php checked('', $options['slide3']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[slide3]" class="light_cbradio_op" value="1" <?php checked('1', $options['slide3']); ?>/> <?php _e('使用','light') ?></span>
							</div>
							<div class="clearfix"></div>
							<div class="cbradio_checked light_nodisplay">
								<div class="light_option_l"><label for="light_options[slideimg3]"><?php _e('图片地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[slideimg3]" value="<?php echo $options['slideimg3']; ?>"/></div>								
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[slidelink3]"><?php _e('链接地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[slidelink3]" value="<?php echo $options['slidelink3']; ?>"/></div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[slidestext3]"><?php _e('是否填写文本文本','light') ?></label></div>
								<div class="light_option_m">
									<span class="radio_options"><input type="radio" name="light_options[slidestext3]" class="light_cbradio_cl" value="" <?php checked('', $options['slidestext3']); ?>/> <?php _e('否','light') ?></span>
									<span class="radio_options"><input type="radio" name="light_options[slidestext3]" class="light_cbradio_op" value="1" <?php checked('1', $options['slidestext3']); ?>/> <?php _e('是','light') ?></span>
								</div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[slidetitle3]"><?php _e('文本标题','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[slidetitle3]" value="<?php echo $options['slidetitle3']; ?>"/></div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[slideintro3]"><?php _e('文本内容','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[slideintro3]" value="<?php echo $options['slideintro3']; ?>"/></div>
								<div class="clearfix"></div>
							</div>
						</div><!-- .light_option -->
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[slide4]"><?php _e('第四张幻灯','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[slide4]" class="light_cbradio_cl" value="" <?php checked('', $options['slide4']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[slide4]" class="light_cbradio_op" value="1" <?php checked('1', $options['slide4']); ?>/> <?php _e('使用','light') ?></span>
							</div>
							<div class="clearfix"></div>
							<div class="cbradio_checked light_nodisplay">
								<div class="light_option_l"><label for="light_options[slideimg4]"><?php _e('图片地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[slideimg4]" value="<?php echo $options['slideimg4']; ?>"/></div>								
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[slidelink4]"><?php _e('链接地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[slidelink4]" value="<?php echo $options['slidelink4']; ?>"/></div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[slidestext4]"><?php _e('是否填写文本文本','light') ?></label></div>
								<div class="light_option_m">
									<span class="radio_options"><input type="radio" name="light_options[slidestext4]" class="light_cbradio_cl" value="" <?php checked('', $options['slidestext4']); ?>/> <?php _e('否','light') ?></span>
									<span class="radio_options"><input type="radio" name="light_options[slidestext4]" class="light_cbradio_op" value="1" <?php checked('1', $options['slidestext4']); ?>/> <?php _e('是','light') ?></span>
								</div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[slidetitle4]"><?php _e('文本标题','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[slidetitle4]" value="<?php echo $options['slidetitle4']; ?>"/></div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[slideintro4]"><?php _e('文本内容','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[slideintro4]" value="<?php echo $options['slideintro4']; ?>"/></div>
								<div class="clearfix"></div>
							</div>
						</div><!-- .light_option -->
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[slide5]"><?php _e('第五张幻灯','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[slide5]" class="light_cbradio_cl" value="" <?php checked('', $options['slide5']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[slide5]" class="light_cbradio_op" value="1" <?php checked('1', $options['slide5']); ?>/> <?php _e('使用','light') ?></span>
							</div>
							<div class="clearfix"></div>
							<div class="cbradio_checked light_nodisplay">
								<div class="light_option_l"><label for="light_options[slideimg5]"><?php _e('图片地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[slideimg5]" value="<?php echo $options['slideimg5']; ?>"/></div>								
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[slidelink5]"><?php _e('链接地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[slidelink5]" value="<?php echo $options['slidelink5']; ?>"/></div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[slidestext5]"><?php _e('是否填写文本文本','light') ?></label></div>
								<div class="light_option_m">
									<span class="radio_options"><input type="radio" name="light_options[slidestext5]" class="light_cbradio_cl" value="" <?php checked('', $options['slidestext5']); ?>/> <?php _e('否','light') ?></span>
									<span class="radio_options"><input type="radio" name="light_options[slidestext5]" class="light_cbradio_op" value="1" <?php checked('1', $options['slidestext5']); ?>/> <?php _e('是','light') ?></span>
								</div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[slidetitle5]"><?php _e('文本标题','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[slidetitle5]" value="<?php echo $options['slidetitle5']; ?>"/></div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[slideintro5]"><?php _e('文本内容','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[slideintro5]" value="<?php echo $options['slideintro5']; ?>"/></div>
								<div class="clearfix"></div>
							</div>
						</div><!-- .light_option -->
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[slide6]"><?php _e('第六张幻灯','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[slide6]" class="light_cbradio_cl" value="" <?php checked('', $options['slide6']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[slide6]" class="light_cbradio_op" value="1" <?php checked('1', $options['slide6']); ?>/> <?php _e('使用','light') ?></span>
							</div>
							<div class="clearfix"></div>
							<div class="cbradio_checked light_nodisplay">
								<div class="light_option_l"><label for="light_options[slideimg6]"><?php _e('图片地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[slideimg6]" value="<?php echo $options['slideimg6']; ?>"/></div>								
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[slidelink6]"><?php _e('链接地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[slidelink6]" value="<?php echo $options['slidelink6']; ?>"/></div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[slidestext6]"><?php _e('是否填写文本文本','light') ?></label></div>
								<div class="light_option_m">
									<span class="radio_options"><input type="radio" name="light_options[slidestext6]" class="light_cbradio_cl" value="" <?php checked('', $options['slidestext6']); ?>/> <?php _e('否','light') ?></span>
									<span class="radio_options"><input type="radio" name="light_options[slidestext6]" class="light_cbradio_op" value="1" <?php checked('1', $options['slidestext6']); ?>/> <?php _e('是','light') ?></span>
								</div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[slidetitle6]"><?php _e('文本标题','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[slidetitle6]" value="<?php echo $options['slidetitle6']; ?>"/></div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[slideintro6]"><?php _e('文本内容','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[slideintro6]" value="<?php echo $options['slideintro6']; ?>"/></div>
								<div class="clearfix"></div>
							</div>
						</div><!-- .light_option -->
					</div><!-- .light_option_wrap -->
				</ul><!-- #lu-tab-frame -->

				<ul id="lu-tab-post" class="list lu-tab-list">
					<div class="light_option_wrap">
						<div class="light_option_section"><h2><?php _e('这里可以放一些你喜欢的网站、博客或者你推荐的书籍、听过的音乐等等。图片大小为：65*90','light') ?></h2></div>
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[favewebs1]"><?php _e('是否使用','light') ?></label></div>
								<div class="light_option_m">
									<span class="radio_options"><input type="radio" name="light_options[favewebs1]" class="light_cbradio_cl" value="" <?php checked('', $options['favewebs1']); ?>/> <?php _e('不使用','light') ?></span>
									<span class="radio_options"><input type="radio" name="light_options[favewebs1]" class="light_cbradio_op" value="1" <?php checked('1', $options['favewebs1']); ?>/> <?php _e('使用','light') ?></span>
								</div>
								<div class="clearfix"></div>
								<fieldset>
									<legend class="toggle">我的收藏NO.1</legend>
									<div class="show"><p/>
										<div class="light_option_l"><label for="light_options[FaveWebsimg1]"><?php _e('图片地址','light') ?></label></div>
										<div class="light_option_m"><input type="text" name="light_options[FaveWebsimg1]" value="<?php echo $options['FaveWebsimg1']; ?>"/></div><br/>
										<div class="light_option_l"><label for="light_options[FaveWebslink1]"><?php _e('链接地址','light') ?></label></div>
										<div class="light_option_m"><input type="text" name="light_options[FaveWebslink1]" value="<?php echo $options['FaveWebslink1']; ?>"/></div><br/>
									</div>
								</fieldset>
						</div><!-- .light_option -->
						<div class="light_option">
						<div class="light_option_l"><label for="light_options[favewebs2]"><?php _e('是否使用','light') ?></label></div>
								<div class="light_option_m">
									<span class="radio_options"><input type="radio" name="light_options[favewebs2]" class="light_cbradio_cl" value="" <?php checked('', $options['favewebs2']); ?>/> <?php _e('不使用','light') ?></span>
									<span class="radio_options"><input type="radio" name="light_options[favewebs2]" class="light_cbradio_op" value="1" <?php checked('1', $options['favewebs2']); ?>/> <?php _e('使用','light') ?></span>
								</div>
								<div class="clearfix"></div>
							<fieldset>
								<legend class="toggle">我的收藏NO.2</legend>
								<div class="none"><p/>
									<div class="light_option_l"><label for="light_options[FaveWebsimg2]"><?php _e('图片地址','light') ?></label></div>
									<div class="light_option_m"><input type="text" name="light_options[FaveWebsimg2]" value="<?php echo $options['FaveWebsimg2']; ?>"/></div><br/>									
									<div class="light_option_l"><label for="light_options[FaveWebslink2]"><?php _e('链接地址','light') ?></label></div>
									<div class="light_option_m"><input type="text" name="light_options[FaveWebslink2]" value="<?php echo $options['FaveWebslink2']; ?>"/></div><br/>
								</div>
							</fieldset>
						</div><!-- .light_option -->
						<div class="light_option">
						<div class="light_option_l"><label for="light_options[favewebs3]"><?php _e('是否使用','light') ?></label></div>
								<div class="light_option_m">
									<span class="radio_options"><input type="radio" name="light_options[favewebs3]" class="light_cbradio_cl" value="" <?php checked('', $options['favewebs3']); ?>/> <?php _e('不使用','light') ?></span>
									<span class="radio_options"><input type="radio" name="light_options[favewebs3]" class="light_cbradio_op" value="1" <?php checked('1', $options['favewebs3']); ?>/> <?php _e('使用','light') ?></span>
								</div>
								<div class="clearfix"></div>
							<fieldset>
								<legend class="toggle">我的收藏NO.3</legend>
								<div class="none"><p/>
									<div class="light_option_l"><label for="light_options[FaveWebsimg3]"><?php _e('图片地址','light') ?></label></div>
									<div class="light_option_m"><input type="text" name="light_options[FaveWebsimg3]" value="<?php echo $options['FaveWebsimg3']; ?>"/></div><br/>									
									<div class="light_option_l"><label for="light_options[FaveWebslink3]"><?php _e('链接地址','light') ?></label></div>
									<div class="light_option_m"><input type="text" name="light_options[FaveWebslink3]" value="<?php echo $options['FaveWebslink3']; ?>"/></div><br/>
								</div>
							</fieldset>
						</div><!-- .light_option -->
						<div class="light_option">
						<div class="light_option_l"><label for="light_options[favewebs4]"><?php _e('是否使用','light') ?></label></div>
								<div class="light_option_m">
									<span class="radio_options"><input type="radio" name="light_options[favewebs4]" class="light_cbradio_cl" value="" <?php checked('', $options['favewebs4']); ?>/> <?php _e('不使用','light') ?></span>
									<span class="radio_options"><input type="radio" name="light_options[favewebs4]" class="light_cbradio_op" value="1" <?php checked('1', $options['favewebs4']); ?>/> <?php _e('使用','light') ?></span>
								</div>
								<div class="clearfix"></div>
							<fieldset>
								<legend class="toggle">我的收藏NO.4</legend>
								<div class="none"><p/>
									<div class="light_option_l"><label for="light_options[FaveWebsimg4]"><?php _e('图片地址','light') ?></label></div>
									<div class="light_option_m"><input type="text" name="light_options[FaveWebsimg4]" value="<?php echo $options['FaveWebsimg4']; ?>"/></div><br/>									
									<div class="light_option_l"><label for="light_options[FaveWebslink4]"><?php _e('链接地址','light') ?></label></div>
									<div class="light_option_m"><input type="text" name="light_options[FaveWebslink4]" value="<?php echo $options['FaveWebslink4']; ?>"/></div><br/>
								</div>
							</fieldset>
						</div><!-- .light_option -->
						<div class="light_option">
						<div class="light_option_l"><label for="light_options[favewebs5]"><?php _e('是否使用','light') ?></label></div>
								<div class="light_option_m">
									<span class="radio_options"><input type="radio" name="light_options[favewebs5]" class="light_cbradio_cl" value="" <?php checked('', $options['favewebs5']); ?>/> <?php _e('不使用','light') ?></span>
									<span class="radio_options"><input type="radio" name="light_options[favewebs5]" class="light_cbradio_op" value="1" <?php checked('1', $options['favewebs5']); ?>/> <?php _e('使用','light') ?></span>
								</div>
								<div class="clearfix"></div>
							<fieldset>
								<legend class="toggle">我的收藏NO.5</legend>
								<div class="none"><p/>
									<div class="light_option_l"><label for="light_options[FaveWebsimg5]"><?php _e('图片地址','light') ?></label></div>
									<div class="light_option_m"><input type="text" name="light_options[FaveWebsimg5]" value="<?php echo $options['FaveWebsimg5']; ?>"/></div><br/>									
									<div class="light_option_l"><label for="light_options[FaveWebslink5]"><?php _e('链接地址','light') ?></label></div>
									<div class="light_option_m"><input type="text" name="light_options[FaveWebslink5]" value="<?php echo $options['FaveWebslink5']; ?>"/></div><br/>
								</div>
							</fieldset>
						</div><!-- .light_option -->
						<div class="light_option">
						<div class="light_option_l"><label for="light_options[favewebs6]"><?php _e('是否使用','light') ?></label></div>
								<div class="light_option_m">
									<span class="radio_options"><input type="radio" name="light_options[favewebs6]" class="light_cbradio_cl" value="" <?php checked('', $options['favewebs6']); ?>/> <?php _e('不使用','light') ?></span>
									<span class="radio_options"><input type="radio" name="light_options[favewebs6]" class="light_cbradio_op" value="1" <?php checked('1', $options['favewebs6']); ?>/> <?php _e('使用','light') ?></span>
								</div>
								<div class="clearfix"></div>
							<fieldset>
								<legend class="toggle">我的收藏NO.6</legend>
								<div class="none"><p/>
									<div class="light_option_l"><label for="light_options[FaveWebsimg6]"><?php _e('图片地址','light') ?></label></div>
									<div class="light_option_m"><input type="text" name="light_options[FaveWebsimg6]" value="<?php echo $options['FaveWebsimg6']; ?>"/></div><br/>									
									<div class="light_option_l"><label for="light_options[FaveWebslink6]"><?php _e('链接地址','light') ?></label></div>
									<div class="light_option_m"><input type="text" name="light_options[FaveWebslink6]" value="<?php echo $options['FaveWebslink6']; ?>"/></div><br/>
								</div>
							</fieldset>
						</div><!-- .light_option -->
					</div><!-- .light_option_wrap -->
				</ul><!-- #lu-tab-post -->

				<ul id="lu-tab-slide" class="list lu-tab-list">
					<div class="light_option_wrap">
						<div class="light_option_section"><h2><?php _e('为了整体美观，个性链接的描述请控制在一行','light') ?></h2></div>
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[favelink1]"><?php _e('第一个链接','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[favelink1]" class="light_cbradio_cl" value="" <?php checked('', $options['favelink1']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[favelink1]" class="light_cbradio_op" value="1" <?php checked('1', $options['favelink1']); ?>/> <?php _e('使用','light') ?></span>
							</div>
							<div class="clearfix"></div>
							<div class="cbradio_checked light_nodisplay">
								<div class="light_option_l"><label for="light_options[favename1]"><?php _e('链接名称','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[favename1]" value="<?php echo $options['favename1']; ?>"/></div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[favelinks1]"><?php _e('链接地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[favelinks1]" value="<?php echo $options['favelinks1']; ?>"/></div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[favecontent1]"><?php _e('链接描述','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[favecontent1]" value="<?php echo $options['favecontent1']; ?>"/></div>
								<div class="clearfix"></div>
							</div>
						</div><!-- .light_option -->
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[favelink2]"><?php _e('第二个链接','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[favelink2]" class="light_cbradio_cl" value="" <?php checked('', $options['favelink2']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[favelink2]" class="light_cbradio_op" value="1" <?php checked('1', $options['favelink2']); ?>/> <?php _e('使用','light') ?></span>
							</div>
							<div class="clearfix"></div>
							<div class="cbradio_checked light_nodisplay">
								<div class="light_option_l"><label for="light_options[favename2]"><?php _e('链接名称','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[favename2]" value="<?php echo $options['favename2']; ?>"/></div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[favelinks2]"><?php _e('链接地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[favelinks2]" value="<?php echo $options['favelinks2']; ?>"/></div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[favecontent2]"><?php _e('链接描述','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[favecontent2]" value="<?php echo $options['favecontent2']; ?>"/></div>
								<div class="clearfix"></div>
							</div>
						</div><!-- .light_option -->
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[favelink3]"><?php _e('第三个链接','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[favelink3]" class="light_cbradio_cl" value="" <?php checked('', $options['favelink3']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[favelink3]" class="light_cbradio_op" value="1" <?php checked('1', $options['favelink3']); ?>/> <?php _e('使用','light') ?></span>
							</div>
							<div class="clearfix"></div>
							<div class="cbradio_checked light_nodisplay">
								<div class="light_option_l"><label for="light_options[favename3]"><?php _e('链接名称','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[favename3]" value="<?php echo $options['favename3']; ?>"/></div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[favelinks3]"><?php _e('链接地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[favelinks3]" value="<?php echo $options['favelinks3']; ?>"/></div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[favecontent3]"><?php _e('链接描述','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[favecontent3]" value="<?php echo $options['favecontent3']; ?>"/></div>
								<div class="clearfix"></div>
							</div>
						</div><!-- .light_option -->
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[favelink4]"><?php _e('第四个链接','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[favelink4]" class="light_cbradio_cl" value="" <?php checked('', $options['favelink4']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[favelink4]" class="light_cbradio_op" value="1" <?php checked('1', $options['favelink4']); ?>/> <?php _e('使用','light') ?></span>
							</div>
							<div class="clearfix"></div>
							<div class="cbradio_checked light_nodisplay">
								<div class="light_option_l"><label for="light_options[favename4]"><?php _e('链接名称','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[favename4]" value="<?php echo $options['favename4']; ?>"/></div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[favelinks4]"><?php _e('链接地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[favelinks4]" value="<?php echo $options['favelinks4']; ?>"/></div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[favecontent4]"><?php _e('链接描述','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[favecontent4]" value="<?php echo $options['favecontent4']; ?>"/></div>
								<div class="clearfix"></div>
							</div>
						</div><!-- .light_option -->
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[favelink5]"><?php _e('第五个链接','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[favelink5]" class="light_cbradio_cl" value="" <?php checked('', $options['favelink5']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[favelink5]" class="light_cbradio_op" value="1" <?php checked('1', $options['favelink5']); ?>/> <?php _e('使用','light') ?></span>
							</div>
							<div class="clearfix"></div>
							<div class="cbradio_checked light_nodisplay">
								<div class="light_option_l"><label for="light_options[favename5]"><?php _e('链接名称','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[favename5]" value="<?php echo $options['favename5']; ?>"/></div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[favelinks5]"><?php _e('链接地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[favelinks5]" value="<?php echo $options['favelinks5']; ?>"/></div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[favecontent5]"><?php _e('链接描述','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[favecontent5]" value="<?php echo $options['favecontent5']; ?>"/></div>
								<div class="clearfix"></div>
							</div>
						</div><!-- .light_option -->
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[favelink6]"><?php _e('第六个链接','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[favelink6]" class="light_cbradio_cl" value="" <?php checked('', $options['favelink6']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[favelink6]" class="light_cbradio_op" value="1" <?php checked('1', $options['favelink6']); ?>/> <?php _e('使用','light') ?></span>
							</div>
							<div class="clearfix"></div>
							<div class="cbradio_checked light_nodisplay">
								<div class="light_option_l"><label for="light_options[favename6]"><?php _e('链接名称','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[favename6]" value="<?php echo $options['favename6']; ?>"/></div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[favelinks6]"><?php _e('链接地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[favelinks6]" value="<?php echo $options['favelinks6']; ?>"/></div>
								<div class="clearfix"></div>
								<div class="light_option_l"><label for="light_options[favecontent6]"><?php _e('链接描述','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[favecontent6]" value="<?php echo $options['favecontent6']; ?>"/></div>
								<div class="clearfix"></div>
							</div>
						</div><!-- .light_option -->
					</div><!-- .light_option_wrap -->
				</ul><!-- #lu-tab-slide -->
				
				
				<ul id="lu-tab-sns" class="list lu-tab-list">
					<div class="light_option_wrap">
						<div class="light_option_section"><h2><?php _e('SNS社交网站，最多能同时显示6个，请务必控制好数量','light') ?></h2></div>
						
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[rss]"><?php _e('RSS','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[rss]" class="light_cbradio_cl" value="" <?php checked('', $options['rss']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[rss]" class="light_cbradio_op" value="1" <?php checked('1', $options['rss']); ?>/> 使用</span>
							</div>
							<div class="clearfix"></div>
							<div class="light_option_l"><label for="light_options[feedrss]"><?php _e('默认or自定义','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[feedrss]" class="light_cbradio_cl" value="" <?php checked('', $options['feedrss']); ?>/> <?php _e('默认','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[feedrss]" class="light_cbradio_op" value="1" <?php checked('1', $options['feedrss']); ?>/> <?php _e('自定义','light') ?></span>
							</div>
							<div class="light_option_r"><small><?php _e('选择WordPress默认的Rss订阅地址还是自定义？','light') ?></small></div>
							<div class="clearfix"></div>
							<div class="cbradio_checked light_nodisplay">
								<div class="light_option_l"><label for="light_options[rssurl]"><?php _e('自定义RSS','light') ?></label></div>
								<div class="light_option_m"><textarea  type="textarea" name="light_options[rssurl]"><?php echo $options['rssurl']; ?></textarea></div>
								<div class="light_option_r"><small><?php _e('输入自定义RSS地址','light') ?></small></div>
								<div class="clearfix"></div>
							</div>
						</div><!-- .light_option -->
						
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[twitter]"><?php _e('<b>Twitter</b>','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[twitter]" class="light_cbradio_cl" value="" <?php checked('', $options['twitter']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[twitter]" class="light_cbradio_op" value="1" <?php checked('1', $options['twitter']); ?>/> <?php _e('使用','light') ?></span>
							</div>
							<div class="clearfix"></div>
							<div class="cbradio_checked light_nodisplay">
								<div class="light_option_l"><label for="light_options[twitterlink]"><?php _e('链接地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[twitterlink]" value="<?php echo $options['twitterlink']; ?>"/></div>
								<div class="clearfix"></div>
							</div>
						</div><!-- .light_option -->
						
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[deviantart]"><?php _e('<b>deviantart</b>','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[deviantart]" class="light_cbradio_cl" value="" <?php checked('', $options['deviantart']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[deviantart]" class="light_cbradio_op" value="1" <?php checked('1', $options['deviantart']); ?>/> <?php _e('使用','light') ?></span>
							</div>
							<div class="clearfix"></div>
							<div class="cbradio_checked light_nodisplay">
								<div class="light_option_l"><label for="light_options[deviantartlink]"><?php _e('链接地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[deviantartlink]" value="<?php echo $options['deviantartlink']; ?>"/></div>
								<div class="clearfix"></div>
							</div>
						</div><!-- .light_option -->
						
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[dribbble]"><?php _e('<b>Dribbble</b>','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[dribbble]" class="light_cbradio_cl" value="" <?php checked('', $options['dribbble']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[dribbble]" class="light_cbradio_op" value="1" <?php checked('1', $options['dribbble']); ?>/> <?php _e('使用','light') ?></span>
							</div>
							<div class="clearfix"></div>
							<div class="cbradio_checked light_nodisplay">
								<div class="light_option_l"><label for="light_options[dribbblelink]"><?php _e('链接地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[dribbblelink]" value="<?php echo $options['dribbblelink']; ?>"/></div>
								<div class="clearfix"></div>
							</div>
						</div><!-- .light_option -->
						
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[weibo]"><?php _e('<b>新浪微博</b>','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[weibo]" class="light_cbradio_cl" value="" <?php checked('', $options['weibo']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[weibo]" class="light_cbradio_op" value="1" <?php checked('1', $options['weibo']); ?>/> <?php _e('使用','light') ?></span>
							</div>
							<div class="clearfix"></div>
							<div class="cbradio_checked light_nodisplay">
								<div class="light_option_l"><label for="light_options[weibolink]"><?php _e('链接地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[weibolink]" value="<?php echo $options['weibolink']; ?>"/></div>
								<div class="clearfix"></div>
							</div>
						</div><!-- .light_option -->
						
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[qqweibo]"><?php _e('<b>腾讯微博</b>','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[qqweibo]" class="light_cbradio_cl" value="" <?php checked('', $options['qqweibo']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[qqweibo]" class="light_cbradio_op" value="1" <?php checked('1', $options['qqweibo']); ?>/> <?php _e('使用','light') ?></span>
							</div>
							<div class="clearfix"></div>
							<div class="cbradio_checked light_nodisplay">
								<div class="light_option_l"><label for="light_options[qqweibolink]"><?php _e('链接地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[qqweibolink]" value="<?php echo $options['qqweibolink']; ?>"/></div>
								<div class="clearfix"></div>
							</div>
						</div><!-- .light_option -->
						
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[kaixin]"><?php _e('<b>开心网主页</b>','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[kaixin]" class="light_cbradio_cl" value="" <?php checked('', $options['kaixin']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[kaixin]" class="light_cbradio_op" value="1" <?php checked('1', $options['kaixin']); ?>/> <?php _e('使用','light') ?></span>
							</div>
							<div class="clearfix"></div>
							<div class="cbradio_checked light_nodisplay">
								<div class="light_option_l"><label for="light_options[kaixinlink]"><?php _e('链接地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[kaixinlink]" value="<?php echo $options['kaixinlink']; ?>"/></div>
								<div class="clearfix"></div>
							</div>
						</div><!-- .light_option -->
						
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[renren]"><?php _e('<b>人人网主页</b>','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[renren]" class="light_cbradio_cl" value="" <?php checked('', $options['renren']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[renren]" class="light_cbradio_op" value="1" <?php checked('1', $options['renren']); ?>/> <?php _e('使用','light') ?></span>
							</div>
							<div class="clearfix"></div>
							<div class="cbradio_checked light_nodisplay">
								<div class="light_option_l"><label for="light_options[renrenlink]"><?php _e('链接地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[renrenlink]" value="<?php echo $options['renrenlink']; ?>"/></div>
								<div class="clearfix"></div>
							</div>
						</div><!-- .light_option -->
						
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[douban]"><?php _e('<b>豆瓣主页</b>','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[douban]" class="light_cbradio_cl" value="" <?php checked('', $options['douban']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[douban]" class="light_cbradio_op" value="1" <?php checked('1', $options['douban']); ?>/> <?php _e('使用','light') ?></span>
							</div>
							<div class="clearfix"></div>
							<div class="cbradio_checked light_nodisplay">
								<div class="light_option_l"><label for="light_options[doubanlink]"><?php _e('链接地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[doubanlink]" value="<?php echo $options['doubanlink']; ?>"/></div>
								<div class="clearfix"></div>
							</div>
						</div><!-- .light_option -->
						
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[sohu]"><?php _e('<b>搜狐微博</b>','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[sohu]" class="light_cbradio_cl" value="" <?php checked('', $options['sohu']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[sohu]" class="light_cbradio_op" value="1" <?php checked('1', $options['sohu']); ?>/> <?php _e('使用','light') ?></span>
							</div>
							<div class="clearfix"></div>
							<div class="cbradio_checked light_nodisplay">
								<div class="light_option_l"><label for="light_options[sohulink]"><?php _e('链接地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[sohulink]" value="<?php echo $options['sohulink']; ?>"/></div>
								<div class="clearfix"></div>
							</div>
						</div><!-- .light_option -->
						
						<div class="light_option">
							<div class="light_option_l"><label for="light_options[wangyi]"><?php _e('<b>网易微博</b>','light') ?></label></div>
							<div class="light_option_m">
								<span class="radio_options"><input type="radio" name="light_options[wangyi]" class="light_cbradio_cl" value="" <?php checked('', $options['wangyi']); ?>/> <?php _e('不使用','light') ?></span>
								<span class="radio_options"><input type="radio" name="light_options[wangyi]" class="light_cbradio_op" value="1" <?php checked('1', $options['wangyi']); ?>/> <?php _e('使用','light') ?></span>
							</div>
							<div class="clearfix"></div>
							<div class="cbradio_checked light_nodisplay">
								<div class="light_option_l"><label for="light_options[wangyilink]"><?php _e('链接地址','light') ?></label></div>
								<div class="light_option_m"><input type="text" name="light_options[wangyilink]" value="<?php echo $options['wangyilink']; ?>"/></div>
								<div class="clearfix"></div>
							</div>
						</div><!-- .light_option -->
						
					</div><!-- .light_option_wrap -->
				</ul><!-- #lu-tab-slide -->

				<ul id="lu-tab-readme" class="list lu-tab-list">
					<div class="light_option_wrap">
						<div class="light_option_section">
							<h2><?php _e('主题说明','light') ?></h2>
						</div>
						<div class="light_helppage">
							<p>当前主题：<?php $theme_data = get_theme_data(ABSPATH . 'wp-content/themes/light/style.css');echo $theme_data['Title']; ?></p>
							<p>主题版本：<?php $theme_data = get_theme_data(ABSPATH . 'wp-content/themes/light/style.css');echo $theme_data['Version']; ?></p>
							<p>主题作者：<a href="http://oneiro.me/" target="_blank" title="苏米诺" rel="external">Sumiro</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://mufeng.me" target="_blank" title="牧风" rel="external">牧风</a></p>
							<p>致谢： <a href="http://acora.cc/" target="_blank" title="acora" rel="external">Acora</a></p><br/>
							<p style="line-height:24px">此为收费主题，版权归作者，禁止任何未经授权的使用、仿制、转卖、盗卖；仅允许一个站点使用，禁止一次购买多个站点或域名使用。主题使用中有疑问可在群里发言或者联系QQ：1298768641或352355433。
							</p>
						</div>
					</div><!-- .light_option_wrap -->
				</ul><!-- #lu-tab-readme -->

			</div><!-- .light_inside -->
		</div><!-- #light_nav_list -->
		<div class="light_submit_form">
			<input type="submit" class="button-primary light_submit_form_btn" name="save" value="<?php _e('Save Changes') ?>"/>
		</div>
	</form>
	<form method="post">
		<div class="light_reset_form">
			<input type="submit" name="reset" value="<?php _e('Reset') ?>" class="button-secondary light_reset_form_btn"/> 重置将清空全部的主题设置，请谨慎操作！
			<input type="hidden" name="reset" value="reset" />
		</div>
	</form>
<div class="clearfix"></div>
</div><!-- .wrap -->
<?php } ?>