<?php $options = get_option('light_options'); ?>
		<section sum="logo">
			<?php if($options['custom_logo'] ) : ?>
				<a id="custom_logo" href="<?php bloginfo('url');?>" title="<?php bloginfo('description'); ?>"><img src="<?php echo($options['logo_url']); ?>" alt="<?php bloginfo('name'); ?>" /></a>
			<?php else : ?>	
				<a class="logo" href="<?php bloginfo('url');?>"><img src="<?php bloginfo('template_url');?>/images/logo.png" alt="<?php bloginfo('name'); ?>" /></a>
			<?php endif; ?>					
			<div class="clear"></div><div class="sidline"></div>
			
			<div class="sns">
				<?php if($options['rss'] ) : ?><?php if($options['feedrss'] ) : ?>
					<a class="rss" href="<?php echo($options['rssurl']); ?>" target="_blank" title="订阅本站"></a>
				<?php else : ?>	
					<a class="rss" href="<?php bloginfo( 'rss2_url' ); ?>" target="_blank" title="订阅本站"></a>
				<?php endif; ?><?php endif; ?>
				<?php if($options['weibo']): ?>
					<a href="<?php echo($options['weibolink']); ?>" target="_blank" rel="nofollow" title="新浪微博" class="sns_sina"></a>
				<?php endif; ?>
				<?php if($options['deviantart']): ?>
					<a href="<?php echo($options['deviantartlink']); ?>" target="_blank" rel="nofollow" title="My Deviantart" class="sns_da"></a>
				<?php endif; ?>
				<?php if($options['twitter']): ?>
					<a href="<?php echo($options['twitterlink']); ?>" target="_blank" rel="nofollow" title="Follow me" class="sns_twitter"></a>
				<?php endif; ?>
				<?php if($options['dribbble']): ?>
					<a href="<?php echo($options['dribbblelink']); ?>" target="_blank" rel="nofollow" title="My Dribbble" class="sns_dribbble"></a>
				<?php endif; ?>
				<?php if($options['qqweibo']): ?>
					<a href="<?php echo($options['qqweibolink']); ?>" target="_blank" rel="nofollow" title="腾讯微博" class="sns_qqweibo"></a>
				<?php endif; ?>
				<?php if($options['kaixin']): ?>
					<a href="<?php echo($options['kaixinlink']); ?>" target="_blank" rel="nofollow" title="我的开心网" class="sns_kaixin"></a>
				<?php endif; ?>
				<?php if($options['renren']): ?>
					<a href="<?php echo($options['renrenlink']); ?>" target="_blank" rel="nofollow" title="我的人人网" class="sns_renren"></a>
				<?php endif; ?>
				<?php if($options['douban']): ?>
					<a href="<?php echo($options['doubanlink']); ?>" target="_blank" rel="nofollow" title="我的豆瓣" class="sns_douban"></a>
				<?php endif; ?>
				<?php if($options['sohu']): ?>
					<a href="<?php echo($options['sohulink']); ?>" target="_blank" rel="nofollow" title="搜狐微博" class="sns_sohu"></a>
				<?php endif; ?>
				<?php if($options['wangyi']): ?>
					<a href="<?php echo($options['wangyilink']); ?>" target="_blank" rel="nofollow" title="网易微博" class="sns_wangyi"></a>
				<?php endif; ?>
			</div>
			
		</section>