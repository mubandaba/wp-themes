<?php
	function muzzzcomment($comment, $args, $depth) {
	$GLOBALS['comment'] = $comment;global $commentcount;
	if(!$commentcount) {
		$page = get_query_var('cpage')-1;
		$cpp=get_option('comments_per_page');
		$commentcount = $cpp * $page;
	}
?>
<li id="comment-<?php comment_ID() ?>" <?php comment_class('commenttips',$comment_id,$comment_post_ID); ?> >
	<div class="commentdiv">
	
		<div class="gravatar">
			<div class="author left"><?php echo get_avatar( get_comment_author_email(), '38'); ?></div>
		</div>
		
		<div class="commenttext">
		
			<div class="comment-meta">
				<span class="commenttime">
					<span class="commentid"><?php comment_author_link();?></span>
					<span class="fabiaoyu">回应于<?php echo time_ago(); ?></span>
					<span class="reply"><?php comment_reply_link(array_merge( $args, array('reply_text' => '回复TA','depth' => $depth, 'max_depth' => $args['max_depth']))) ?></span>
				</span>
				<?php if ($comment->comment_approved == '0') : ?>
					<span class="moderation right"><?php _e('Your comment is awaiting moderation.') ?></span>
				<?php endif; ?>
			</div>
			
			<div class="clear"></div>
			
			<div class="comment_text">
				<div class="info-neirong">
				<?php comment_text() ?><?php edit_comment_link('【编辑】'); ?>
				</div>
			</div>
			
		</div>
		
	</div>
<?php } 
	function devepings($comment, $args, $depth) { $GLOBALS['comment'] = $comment; ?>
	<li id="comment-<?php comment_ID(); ?>"><div class="pingdiv"><?php comment_author_link(); ?></div>
	<?php }
?>