<?php $options = get_option('light_options'); ?>		
		<section sum="randomposts">
			<h3 class="doubanh3">我的收藏</h3>
			<div class="douban">
			<?php if($options['favewebs1']) : ?>
				<a href="<?php echo($options['FaveWebslink1']); ?>" target="_blank"><img src="<?php echo($options['FaveWebsimg1']); ?>" width="65" height="90" ></a>
			<?php endif; ?>
			<?php if($options['favewebs2']) : ?>
				<a href="<?php echo($options['FaveWebslink2']); ?>" target="_blank"><img src="<?php echo($options['FaveWebsimg2']); ?>" width="65" height="90" ></a>
			<?php endif; ?>
			<?php if($options['favewebs3']) : ?>
				<a href="<?php echo($options['FaveWebslink3']); ?>" target="_blank"><img src="<?php echo($options['FaveWebsimg3']); ?>" width="65" height="90" ></a>
			<?php endif; ?>
			<?php if($options['favewebs4']) : ?>
				<a href="<?php echo($options['FaveWebslink4']); ?>" target="_blank"><img src="<?php echo($options['FaveWebsimg4']); ?>" width="65" height="90" ></a>
			<?php endif; ?>
			<?php if($options['favewebs5']) : ?>
				<a href="<?php echo($options['FaveWebslink5']); ?>" target="_blank"><img src="<?php echo($options['FaveWebsimg5']); ?>" width="65" height="90" ></a>
			<?php endif; ?>
			<?php if($options['favewebs6']) : ?>
				<a href="<?php echo($options['FaveWebslink6']); ?>" target="_blank"><img src="<?php echo($options['FaveWebsimg6']); ?>" width="65" height="90" ></a>
			<?php endif; ?>
			</div>
		</section>