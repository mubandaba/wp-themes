<?php

	class light_widget extends WP_Widget {
    function light_widget() {
        $widget_ops = array('description' => '网站LOGO');
        $this->WP_Widget('light_widget', 'L-LOGO', $widget_ops);
    }
    function widget($args, $instance) {
        extract($args);
?>
		<?php include_once('loss.php');?>
<?php	
    }
    function form($instance) {
        global $wpdb;
?>
    <p>请在<a href="themes.php?page=setting.php" target="_blank">主题设置</a>中进行详细设置</p>
<?php
    }
}
add_action('widgets_init', 'light_widget_init');
function light_widget_init() {
    register_widget('light_widget');
}

//////////////////////////////////////////////////////////

	class light_widget1 extends WP_Widget {
    function light_widget1() {
        $widget_ops = array('description' => '主题自带的三合一工具，包含：标签、页面和分类');
        $this->WP_Widget('light_widget1', 'L-三合一', $widget_ops);
    }
    function widget($args, $instance) {
        extract($args);
		$limit = strip_tags($instance['limit']);
?>
		<section sum="thrinone">
			<div class="tabs"><span class="selected">标签</span><span>分类</span><span>页面</span></div>
			<div class="tabcontent">
				<ul class="tagcloud">
					<?php
						wp_tag_cloud( array(
						'unit' => 'px',
						'smallest' => 12,
						'largest' => 12,
						'number' => $limit,
						'format' => 'flat',
						'orderby' => 'count',
						'order' => 'DESC'
						)
						);
					?>
				</ul>
				<ul class="hide">
					<?php wp_list_categories('show_count=1&title_li='); ?>
				</ul>
				<ul class="hide">
					<?php wp_list_pages('title_li=' ); ?>
				</ul>
			</div>
		</section>
<?php	
    }
	function update($new_instance, $old_instance) {
        if (!isset($new_instance['submit'])) {
            return false;
        }
        $instance = $old_instance;
        $instance['limit'] = strip_tags($new_instance['limit']);
        return $instance;
    }
    function form($instance) {
        global $wpdb;
        $instance = wp_parse_args((array) $instance, array('limit' => ''));
        $limit = strip_tags($instance['limit']);
?>
	<p>分类和页面没有选项，输入标签数量即可</p>
    <p><label for="<?php echo $this->get_field_id('limit'); ?>">标签数量：<input id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="text" value="<?php echo $limit; ?>" /></label></p>
    <input type="hidden" id="<?php echo $this->get_field_id('submit'); ?>" name="<?php echo $this->get_field_name('submit'); ?>" value="1" />
<?php
    }
}
add_action('widgets_init', 'light_widget1_init');
function light_widget1_init() {
    register_widget('light_widget1');
}

//////////////////////////////////////////////////////////

	class light_widget2 extends WP_Widget {
    function light_widget2() {
        $widget_ops = array('description' => '主题自带的菜单');
        $this->WP_Widget('light_widget2', 'L-菜单', $widget_ops);
    }
    function widget($args, $instance) {
        extract($args);
?>
		<section sum="menu">
			<?php wp_nav_menu( array( 'theme_location' => 'sid-menu','walker'=> new Category_Class_Walker_Nav_Menu())); ?>
		</section>
<?php	
    }
    function form($instance) {
        global $wpdb;
?>
    <p>请到<a href="nav-menus.php" target="_blank">菜单</a>中进行设置</p>
<?php
    }
}
add_action('widgets_init', 'light_widget2_init');
function light_widget2_init() {
    register_widget('light_widget2');
}

//////////////////////////////////////////////////////////

class light_widget3 extends WP_Widget {
    function light_widget3() {
        $widget_ops = array('description' => '主题自带的随机文章小工具');
        $this->WP_Widget('light_widget3', 'L-随机文章', $widget_ops);
    }
    function widget($args, $instance) {
        extract($args);
        $limit = strip_tags($instance['limit']);
?>
	<section sum="randomposts">
		<h3 class="randompostsh3">随机文章</h3>

		<ul class="sidgeneralli">
			<?php $posts = query_posts($query_string . "orderby=rand&showposts=$limit()" ); ?>
				<?php while(have_posts()) : the_post(); ?>
                <li><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a></li>
			<?php endwhile; ?>
		</ul>
	</section>
<?php	
    }
	
    function update($new_instance, $old_instance) {
        if (!isset($new_instance['submit'])) {
            return false;
        }
        $instance = $old_instance;
        $instance['limit'] = strip_tags($new_instance['limit']);
        return $instance;
    }
    function form($instance) {
        global $wpdb;
        $instance = wp_parse_args((array) $instance, array('limit' => ''));
        $limit = strip_tags($instance['limit']);
?>
        
        <p><label for="<?php echo $this->get_field_id('limit'); ?>">文章数量：<input id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="text" value="<?php echo $limit; ?>" /></label></p>
        <input type="hidden" id="<?php echo $this->get_field_id('submit'); ?>" name="<?php echo $this->get_field_name('submit'); ?>" value="1" />
<?php
    }
}
add_action('widgets_init', 'light_widget3_init');
function light_widget3_init() {
    register_widget('light_widget3');
}

//////////////////////////////////////////////////////////

class light_widget4 extends WP_Widget {
    function light_widget4() {
        $widget_ops = array('description' => '主题自带的热门文章小工具');
        $this->WP_Widget('light_widget4', 'L-热门文章', $widget_ops);
    }
    function widget($args, $instance) {
        extract($args);
        $limit = strip_tags($instance['limit']);
		$poptime = strip_tags($instance['poptime']);
?>
		<section sum="hotposts">
			<h3 class="popularposts">热门文章</h3>
			<ul class="sidgeneralli">
				<?php if(function_exists('most_comm_posts')) most_comm_posts( $poptime , $limit ); ?>
			</ul>
		</section>
<?php	
    }
	
    function update($new_instance, $old_instance) {
        if (!isset($new_instance['submit'])) {
            return false;
        }
        $instance = $old_instance;
        $instance['limit'] = strip_tags($new_instance['limit']);
		$instance['poptime'] = strip_tags($new_instance['poptime']);
        return $instance;
    }
    function form($instance) {
        global $wpdb;
        $instance = wp_parse_args((array) $instance, array('limit' => ''));
        $limit = strip_tags($instance['limit']);
		$poptime = strip_tags($instance['poptime']);
?>
        
    <p><label for="<?php echo $this->get_field_id('limit'); ?>">文章数量：<input id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="text" value="<?php echo $limit; ?>" /></label></p>
	<p><label for="<?php echo $this->get_field_id('poptime'); ?>" >热评文章时间范围:<br>（例如希望Popular栏目显示90天内评论最多的文章，则输入“90”）<input id="<?php echo $this->get_field_id('poptime'); ?>" name="<?php echo $this->get_field_name('poptime'); ?>" type="text" value="<?php echo $poptime; ?>" /></label></p>
    <input type="hidden" id="<?php echo $this->get_field_id('submit'); ?>" name="<?php echo $this->get_field_name('submit'); ?>" value="1" />
<?php
    }
}
add_action('widgets_init', 'light_widget4_init');
function light_widget4_init() {
    register_widget('light_widget4');
}

/////////////////////////////////////////////////////////

	class light_widget5 extends WP_Widget {
    function light_widget5() {
        $widget_ops = array('description' => '主题自带的最近文章小工具');
        $this->WP_Widget('light_widget5', 'L-最近文章', $widget_ops);
    }
    function widget($args, $instance) {
        extract($args);
        $limit = strip_tags($instance['limit']);
?>
		<section sum="recentpost">
			<h3 class="recentposts">最近文章</h3>
			<ul class="sidgeneralli">
				<?php $posts = query_posts($query_string . "orderby=date&showposts=$limit()" ); ?>  
					<?php while(have_posts()) : the_post(); ?> 
					<li><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a></li> 
			<?php endwhile; ?> 
			</ul>
		</section>
<?php
    }
	
    function update($new_instance, $old_instance) {
        if (!isset($new_instance['submit'])) {
            return false;
        }
        $instance = $old_instance;
        $instance['limit'] = strip_tags($new_instance['limit']);
        return $instance;
    }
    function form($instance) {
        global $wpdb;
        $instance = wp_parse_args((array) $instance, array('limit' => ''));
        $limit = strip_tags($instance['limit']);
?>  
    <p><label for="<?php echo $this->get_field_id('limit'); ?>">文章数量：<input id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="text" value="<?php echo $limit; ?>" /></label></p>
    <input type="hidden" id="<?php echo $this->get_field_id('submit'); ?>" name="<?php echo $this->get_field_name('submit'); ?>" value="1" />
<?php
    }
}
add_action('widgets_init', 'light_widget5_init');
function light_widget5_init() {
    register_widget('light_widget5');
}

//////////////////////////////////////////////////////////

	class light_widget6 extends WP_Widget {
    function light_widget6() {
        $widget_ops = array('description' => '主题自带的友情链接小工具');
        $this->WP_Widget('light_widget6', 'L-友情链接', $widget_ops);
    }
    function widget($args, $instance) {
        extract($args);
?>
		<section class="friendlink">
			<h3 class="sidebarlinks">友情链接</h3>
			<ul class="friendlinks"><?php wp_list_bookmarks('title_li=&categorize=0'); ?></ul>
		</section>
<?php
    }
    function form($instance) {
        global $wpdb;
?>
    <p>请在<a href="link-manager.php" target="_blank">后台链接</a>中进行添加网站链接</p>
<?php
    }
}
add_action('widgets_init', 'light_widget6_init');
function light_widget6_init() {
    register_widget('light_widget6');
}

//////////////////////////////////////////////////////////

class light_widget7 extends WP_Widget {
     function light_widget7() {
         $widget_ops = array('description' => '主题自带的最近评论小工具');
         $this->WP_Widget('light_widget7', 'L-最近评论', $widget_ops);
     }
     function widget($args, $instance) {
         extract($args);
         $limit = strip_tags($instance['limit']);
?> 
		<section sum="recentcomments">
			<h3 class="recentcomh3">最近评论</h3>
			<ul class="recentcomments">
				<?php
					global $wpdb;
					$limit_num = $limit;
					$my_email = "'" . get_bloginfo ('admin_email') . "'";
					$rc_comms = $wpdb->get_results("SELECT ID, post_title, comment_ID, comment_author,comment_author_email,comment_date,comment_content FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID  = $wpdb->posts.ID) WHERE comment_approved = '1' AND comment_type = '' AND post_password = '' AND comment_author_email != $my_email ORDER BY comment_date_gmt DESC LIMIT $limit_num ");
					$rc_comments = '';
					foreach ($rc_comms as $rc_comm) { $rc_comments .= "<li><span class='recentcommentsavatar'>" . get_avatar($rc_comm,$size='30') ."</span><a href='". get_permalink($rc_comm->ID) . "#comment-" . $rc_comm->comment_ID. "' title='在 " . $rc_comm->post_title .  " 发表的评论'>".strip_tags($rc_comm->comment_content)."</a><br><span class='recentcomments_author'>".$rc_comm->comment_author."</span><span class='recentcomments_date'>" .$rc_comm->comment_date."</span></li>\n";}
					echo $rc_comments;
				?>
			</ul>
		</section>
<?php
     }
     function update($new_instance, $old_instance) {
         if (!isset($new_instance['submit'])) {
             return false;
         }
         $instance = $old_instance;
         $instance['limit'] = strip_tags($new_instance['limit']);
         return $instance;
     }
     function form($instance) {
         global $wpdb;
         $instance = wp_parse_args((array) $instance, array('limit' => ''));
         $limit = strip_tags($instance['limit']);
 ?>
         <p><label for="<?php echo $this->get_field_id('limit'); ?>">显示数量：<input id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="text" value="<?php echo $limit; ?>" /></label></p>
         <input type="hidden" id="<?php echo $this->get_field_id('submit'); ?>" name="<?php echo $this->get_field_name('submit'); ?>" value="1" />

 <?php
     }
 }
 add_action('widgets_init', 'light_widget7_init');
 function light_widget7_init() {
     register_widget('light_widget7');
 }
 
//////////////////////////////////////////////////////////
	class light_widget8 extends WP_Widget {
    function light_widget8() {
        $widget_ops = array('description' => '主题自带的我的收藏秀工具');
        $this->WP_Widget('light_widget8', 'L-我的收藏', $widget_ops);
    }
    function widget($args, $instance) {
        extract($args);
?>
		<?php include_once('fave.php');?>
<?php	
    }
    function form($instance) {
        global $wpdb;
?>
    <p>请在<a href="themes.php?page=setting.php" target="_blank">主题设置</a>中进行详细设置</p>
<?php
    }
}
add_action('widgets_init', 'light_widget8_init');
function light_widget8_init() {
    register_widget('light_widget8');
}

//////////////////////////////////////////////////////////

	class light_widget9 extends WP_Widget {
    function light_widget9() {
        $widget_ops = array('description' => 'light主题的个性链接工具');
        $this->WP_Widget('light_widget9', 'L-个性链接', $widget_ops);
    }
    function widget($args, $instance) {
        extract($args);
?>
		<?php include_once('links.php');?>
<?php	
    }
    function form($instance) {
        global $wpdb;
?>
    <p>请在<a href="themes.php?page=setting.php" target="_blank">主题设置</a>中进行详细设置</p>
<?php
    }
}
add_action('widgets_init', 'light_widget9_init');
function light_widget9_init() {
    register_widget('light_widget9');
}

//////////////////////////////////////////////////////////

class light_widget10 extends WP_Widget {
	function light_widget10() {
		$widget_ops = array('description' => '主题自带的读者墙小工具，可自定义月份和读者显示数量');
		$this->WP_Widget('light_widget10', 'L-读者墙', $widget_ops);
	}
	function widget($args, $instance) {
		extract($args);
		$limit = strip_tags($instance['limit']);
		$month = strip_tags($instance['month']);
?>
	<section sum="guestavatar">
		<h3 class="sidavatarsh3">读者墙</h3>
		<div class="sidavatars">
			<?php
				global $post,$wpdb;
				$identity="comment_author";
				$passwordpost = " AND post_password=''";
				$userexclude = " AND user_id='0'";
				$approved = " AND comment_approved='1'";
				$counts = $wpdb->get_results("SELECT COUNT(" . $identity . ") AS cnt, comment_author, comment_author_url,comment_author_email FROM (SELECT * FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts  ON ($wpdb->posts.ID=$wpdb->comments.comment_post_ID) WHERE comment_date > date_sub( NOW(), INTERVAL ". $month ." MONTH )" . $userexclude . $passwordpost . $approved . ") AS tempcmt GROUP BY " . $identity . " ORDER BY cnt DESC LIMIT " . $limit);
				if ( $counts ) : foreach ($counts as $count) :
				echo '<a class="avatars" href="'. $count->comment_author_url .
					'" target="_blank" title="' . $count->comment_author . ' - '. $count->cnt . '条评论">' .get_avatar($count->comment_author_email,30).' </a>';
				endforeach; endif;
			?>
		</div>
	</section>
<?php
	}
	function update($new_instance, $old_instance) {
		if (!isset($new_instance['submit'])) {
			return false;
		}
		$instance = $old_instance;
		$instance['limit'] = strip_tags($new_instance['limit']);
		$instance['month'] = strip_tags($new_instance['month']);
		return $instance;
	}
	function form($instance) {
		global $wpdb;
		$instance = wp_parse_args((array) $instance, array('limit' => '', 'month' => '1'));
		$limit = strip_tags($instance['limit']);
		$month = strip_tags($instance['month']);
?>
	<p>
		<label for="<?php echo $this->get_field_id('limit'); ?>">头像显示数量：<input id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="text" value="<?php echo $limit; ?>" /></label>
	</p>
	<p>
		<label for="<?php echo $this->get_field_id('month'); ?>">统计月份数量：<br>（最近一个月数值为"1"，最近两个月数值为“2"，以此类推）<input class="widefat" id="<?php echo $this->get_field_id('month'); ?>" name="<?php echo $this->get_field_name('month'); ?>" type="text" value="<?php echo $month; ?>" /></label>
	</p>
	<input type="hidden" id="<?php echo $this->get_field_id('submit'); ?>" name="<?php echo $this->get_field_name('submit'); ?>" value="1" />
<?php
	}
}
add_action('widgets_init', 'light_widget10_init');
function light_widget10_init() {
	register_widget('light_widget10');
}

//////////////////////////////////////////////////////////

class light_widget11 extends WP_Widget {
    function light_widget11() {
        $widget_ops = array('description' => '主题自带的边栏网站统计小工具');
        $this->WP_Widget('light_widget11', 'L-网站统计', $widget_ops);
    }
    function widget($args, $instance) {
        extract($args);
		echo $before_widget;
?>
	<section sum="webcount">
	<h3 class="webcount">网站统计</h3>
		<ul class="sidgeneralli clearfix">
			<li>文章总数：<?php $count_posts = wp_count_posts();echo $published_posts = $count_posts->publish;?>篇</li>
			<li>评论总数：<?php $count_comments = get_comment_count();echo $count_comments['approved'];?>条</li>
			<li>页面总数：<?php $count_pages = wp_count_posts('page'); echo $page_posts = $count_pages->publish; ?> 个</li>
			<li>分类总数：<?php echo $count_categories = wp_count_terms('category'); ?>个</li>
			<li>标签总数：<?php echo $count_tags = wp_count_terms('post_tag'); ?>个</li>
		</ul> 
	</section>
<?php	
	  echo $after_widget;
   }
    function form($instance) {
        global $wpdb;
?>
    <p>该工具没有选项!</p>
<?php
    }
}
add_action('widgets_init', 'light_widget11_init');
function light_widget11_init() {
    register_widget('light_widget11');
}

//////////////////////////////////////////////////////////

class light_widget12 extends WP_Widget {
    function light_widget12() {
        $widget_ops = array('description' => '主题自带的边栏用户管理小工具');
        $this->WP_Widget('light_widget12', 'L-用户管理', $widget_ops);
    }
    function widget($args, $instance) {
        extract($args);
		echo $before_widget;
?>
	<h3 class="usercontrol">用户管理</h3>
		<ul class="tworow">
			<li><a href="<?php bloginfo('url') ?>/wp-admin/" target="_blanlk">登录网站</a></li>
			<li><a href="<?php bloginfo('url') ?>/wp-register.php/" target="_blanlk">用户注册</a></li>
			<li><a href="<?php bloginfo('url') ?>/wp-admin/post-new.php" target="_blanlk">撰写文章</a></li>
			<li><a href="<?php bloginfo('url') ?>/wp-admin/edit-comments.php" target="_blanlk">评论管理</a></li>
		</ul> 
<?php	
	  echo $after_widget;
   }
    function form($instance) {
        global $wpdb;
?>
    <p>该工具没有选项!</p>
<?php
    }
}
add_action('widgets_init', 'light_widget12_init');
function light_widget12_init() {
    register_widget('light_widget12');
}

class Category_Class_Walker_Nav_Menu extends Walker_Nav_Menu {
	/**
	 * @see Walker::start_el()
	 * @since 3.0.0
	 *
	 * @param string $output Passed by reference. Used to append additional content.
	 * @param object $item Menu item data object.
	 * @param int $depth Depth of menu item. Used for padding.
	 * @param int $current_page Menu item ID.
	 * @param object $args
	 */
	function start_el(&$output, $item, $depth, $args) {
		global $wp_query;           

		$indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';

		$class_names = $value = '';

		$classes = empty( $item->classes ) ? array() : (array) $item->classes;
		$classes[] = 'menu-item-' . $item->ID;

		$class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args ) );
		$class_names = ' class="' . esc_attr( $class_names ) . '"';

		$id = apply_filters( 'nav_menu_item_id', 'menu-item-'. $item->ID, $item, $args );
		$id = strlen( $id ) ? ' id="' . esc_attr( $id ) . '"' : '';

		$output .= $indent . '<li' . $id . $value . $class_names .'>';

		$attributes  = ! empty( $item->attr_title ) ? ' title="'  . esc_attr( $item->attr_title ) .'"' : '';
		$attributes .= ! empty( $item->target )     ? ' target="' . esc_attr( $item->target     ) .'"' : '';
		$attributes .= ! empty( $item->xfn )        ? ' rel="'    . esc_attr( $item->xfn        ) .'"' : '';
		$attributes .= ! empty( $item->url )        ? ' href="'   . esc_attr( $item->url        ) .'"' : '';
		$attributes .= ' class="clx"';

		$item_output = $args->before;
		$item_output .= '<a'. $attributes .'><span class="menu-left"></span><span class="menu-text">';
		$item_output .= $args->link_before . apply_filters( 'the_title', $item->title, $item->ID ) . $args->link_after;
		$item_output .= '</span><span class="menu-right"></span></a>';
		$item_output .= $args->after;

		$output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
	}
}


?>