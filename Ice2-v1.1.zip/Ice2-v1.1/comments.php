<?php

// Do not delete these lines
  if (!empty($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
    die ('Please do not load this page directly. Thanks!');

  if ( post_password_required() ) { ?>
    <p class="nocomments">这是一篇受密码保护的文章，你需要输入密码来查看评论。</p>
  <?php
    return;
  }
?>

<!-- You can start editing here. -->

  <?php if ( have_comments() ) : ?>
        
        <?php if ( ! empty($comments_by_type['comment']) ) : ?>
    
    <h3 id="comments" class="league"><?php comments_number(__('没有爪印儿', 'framework'), __('一个爪印儿', 'framework'), __('% 个爪印儿', 'framework')); ?></h3>

    <ol class="commentlist">
        <?php wp_list_comments('type=comment&avatar_size=52'); ?>
        </ol>

        <?php endif; ?>

        <?php if ( ! empty($comments_by_type['pings']) ) : ?>
    
    <h3 id="pings" class="league"><?php _e('Trackbacks for this post', 'framework') ?></h3>
    
    <ol class="pinglist">
        <?php wp_list_comments('type=pings&callback=tz_list_pings'); ?>
    </ol>

        <?php endif; ?>

    <div id="loading-comments"><span class="nimei"><img src="<?php bloginfo('template_directory'); ?>/images/commloading.gif" width="24" height="24"></span>Loading ....</div>

    <div class="navigation" id="comments-navi">
      <?php paginate_comments_links('prev_text=<&next_text=>'); ?>
    </div>
    <div class="clear"></div>

    <?php else : // this is displayed if there are no comments so far ?>
  
    
        <?php if ('open' == $post->comment_status) : ?>
         <!-- If comments are open, but there are no comments. -->

        <?php else : // if comments are closed output text on posts only ?>
    <?php if (is_single()) { ?>
    <p class="nocomments">Sorry...评论已关闭。</p>

        <?php } endif; ?>
<?php endif; ?>


  <?php if ( comments_open() ) : ?>

  <div id="respond">

    <h3 class="league"><?php comment_form_title( __('留下你的脚印', 'framework'), __('给 %s 回复', 'framework') ); ?></h3>
  
    <div class="cancel-comment-reply">
      <?php cancel_comment_reply_link(); ?>
    </div>
  
    <?php if ( get_option('comment_registration') && !is_user_logged_in() ) : ?>
    <p><?php printf(__('你必须 %1$s登陆%2$s 才能留下评论。', 'framework'), '<a href="'.get_option('siteurl').'/wp-login.php?redirect_to='.urlencode(get_permalink()).'">', '</a>') ?></p>
    <?php else : ?>
  
    <form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform">
  
      <?php if ( is_user_logged_in() ) : ?>
    
      <p><?php printf(__('您已经登陆为 %1$s. %2$s退出登录 &raquo;%3$s', 'framework'), '<a href="'.get_option('siteurl').'/wp-admin/profile.php">'.$user_identity.'</a>', '<a href="'.(function_exists('wp_logout_url') ? wp_logout_url(get_permalink()) : get_option('siteurl').'/wp-login.php?action=logout" title="').'" title="'.__('Log out of this account', 'framwork').'">', '</a>') ?></p>
    
      <?php else : ?>

      <p><input type="text" name="author" id="author" value="<?php echo esc_attr($comment_author); ?>" size="22" tabindex="1" />
      <label for="author"><small>昵称 <?php if ($req) { ?><span class="required">*</span><?php } ?></small></label></p>
    
      <p><input type="text" name="email" id="email" value="<?php echo esc_attr($comment_author_email); ?>" size="22" tabindex="2" />
      <label for="email"><small>邮箱 <?php if ($req) { ?><span class="required">*</span><?php } ?> (不会被公开，用于显示 <a href="http://www.gravatar.com" target="_blank">Gravatar</a> 头像)</small></label></p>
    
      <p><input type="text" name="url" id="url" value="<?php echo esc_attr($comment_author_url); ?>" size="22" tabindex="3" />
      <label for="url"><small>网站</small></label></p>
    
      <?php endif; ?>
    
      <p><textarea name="comment" id="comment" cols="58" rows="10" tabindex="4"></textarea></p>
      
      <p class="allowed-tags"><small>你可以使用以下的HTML标签 <code><?php echo allowed_tags(); ?></code></small></p>
    
      <p><input name="submit" type="submit" id="submit" tabindex="5" value="提交评论" />
      <?php comment_id_fields(); ?><?php wp_smilies(); ?>
      </p>
      <?php do_action('comment_form', $post->ID); ?>
  
    </form>

  <?php endif; // If registration required and not logged in ?>
  </div>

  <?php endif; // if you delete this the sky will fall on your head ?>
