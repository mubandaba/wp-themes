<?php
include_once('functions/shortcode.php');
//add_filter('show_admin_bar','__return_false');
add_filter( 'pre_option_link_manager_enabled', '__return_true' );  
remove_filter('the_content', 'wptexturize');
register_nav_menus(array('topmenu' => __('站点导航'),));
function ice_menu($menuname, $depths) { wp_nav_menu(array('container_class' => $menuname, 'theme_location' => $menuname, 'depth' => $depths)); }
if (function_exists('register_sidebar')) register_sidebar(array('name' => 'Ice 侧边栏', 'before_widget' => '<li class="widget-item">', 'after_widget' => '</li><div class="clear"></div>', 'before_title' => '<div class="widgettitle">', 'after_title' => '</div>'));
add_action('wp_footer', 'envf');
function envf() { echo('<div class="footer"><span class="footinfo left"><a href="'.get_bloginfo('url').'">'.get_bloginfo('name').'</a></span><span class="copyright right">Powered by <a href="http://cn.wordpress.org" target="_blank">Wordpress</a> &amp; <a href="http://s-kias.likecer.com" target="_blank">Ice 2 Theme</a>.</span></div>'); };
add_action('wp_footer', 'envf');

function cut_str($string, $sublen, $start = 0, $code = 'UTF-8'){if($code == 'UTF-8'){$pa = "/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|\xe0[\xa0-\xbf][\x80-\xbf]|[\xe1-\xef][\x80-\xbf][\x80-\xbf]|\xf0[\x90-\xbf][\x80-\xbf][\x80-\xbf]|[\xf1-\xf7][\x80-\xbf][\x80-\xbf][\x80-\xbf]/";preg_match_all($pa, $string, $t_string);if(count($t_string[0]) - $start > $sublen) return join('', array_slice($t_string[0], $start, $sublen))."...";return join('', array_slice($t_string[0], $start, $sublen));}else{$start = $start*2;$sublen = $sublen*2;$strlen = strlen($string);$tmpstr = '';for($i=0; $i<$strlen; $i++){ if($i>=$start && $i<($start+$sublen)){if(ord(substr($string, $i, 1))>129) $tmpstr.= substr($string, $i, 2);else $tmpstr.= substr($string, $i, 1);}if(ord(substr($string, $i, 1))>129) $i++;}if(strlen($tmpstr)<$strlen ) $tmpstr.= "...";return $tmpstr;}}

function par_pagenavi($range = 9){
	global $paged, $wp_query;
	if ( !$max_page ) {$max_page = $wp_query->max_num_pages;}
	if($max_page > 1){if(!$paged){$paged = 1;}
	if($paged != 1){echo "<a href='" . get_pagenum_link(1) . "' class='extend' title='跳转到首页'>返回首页</a>";}
	previous_posts_link('上一页');
	if($max_page > $range){
		if($paged < $range){for($i = 1; $i <= ($range + 1); $i++){echo "<a href='" . get_pagenum_link($i) ."'";
		if($i==$paged)echo " class='current'";echo ">$i</a>";}}
	elseif($paged >= ($max_page - ceil(($range/2)))){
		for($i = $max_page - $range; $i <= $max_page; $i++){echo "<a href='" . get_pagenum_link($i) ."'";
		if($i==$paged)echo " class='current'";echo ">$i</a>";}}
	elseif($paged >= $range && $paged < ($max_page - ceil(($range/2)))){
		for($i = ($paged - ceil($range/2)); $i <= ($paged + ceil(($range/2))); $i++){echo "<a href='" . get_pagenum_link($i) ."'";if($i==$paged) echo " class='current'";echo ">$i</a>";}}}
	else{for($i = 1; $i <= $max_page; $i++){echo "<a href='" . get_pagenum_link($i) ."'";
	if($i==$paged)echo " class='current'";echo ">$i</a>";}}
	next_posts_link('下一页');
	if($paged != $max_page){echo "<a href='" . get_pagenum_link($max_page) . "' class='extend' title='跳转到最后一页'>最后一页</a>";}}
}

function time_ago( $type = 'commennt', $day = 30 ) {$d = $type == 'post' ? 'get_post_time' : 'get_comment_time';$timediff = time() - $d('U');if ($timediff <= 60*60*24*$day){echo  human_time_diff($d('U'), strtotime(current_time('mysql', 0))), '前';}if ($timediff > 60*60*24*$day){echo  date('Y/m/d',get_comment_date('U')), ' ', get_comment_time('H:i');};}

function encode_code_in_comment($source) {$encoded = preg_replace_callback('/<code>(.*?)<\/code>/ims',create_function('$matches', '$matches[1] = preg_replace(array("/^[\r|\n]+/i", "/[\r|\n]+$/i"), "", $matches[1]); return "<code>" . htmlentities($matches[1]) . "</"."code>";'), $source);if ($encoded) return $encoded; else return $source;}
add_filter('pre_comment_content', 'encode_code_in_comment');

function comment_mail_notify($comment_id) {$comment = get_comment($comment_id);$parent_id = $comment->comment_parent ? $comment->comment_parent : '';$spam_confirmed = $comment->comment_approved;if (($parent_id != '') && ($spam_confirmed != 'spam')) {$wp_email = 'no-reply@' . preg_replace('#^www\.#', '', strtolower($_SERVER['SERVER_NAME']));$to = trim(get_comment($parent_id)->comment_author_email);$subject = '你在 [' . get_option("blogname") . '] 的留言有了新回复';$message = '<div style="background-color:#eef2fa; border:1px solid #d8e3e8; color:#111; padding:0 15px; -moz-border-radius:5px; -webkit-border-radius:5px; -khtml-border-radius:5px; border-radius:5px;"><p><strong>' . trim(get_comment($parent_id)->comment_author) . ', 你好!</strong></p><p><strong>您曾在《' . get_the_title($comment->comment_post_ID) . '》的留言为:</strong><br />'. trim(get_comment($parent_id)->comment_content) . '</p><p><strong>' . trim($comment->comment_author) . ' 给你的回复是:</strong><br />'. trim($comment->comment_content) . '<br /></p><p>你可以点击此链接 <a href="' . htmlspecialchars(get_comment_link($parent_id)) . '">查看完整内容</a></p><br /><p>欢迎再次来访<a href="' . get_option('home') . '">' . get_option('blogname') . '</a></p><p>(此邮件为系统自动发送，请勿直接回复.)</p></div>';$from = "From: \"" . get_option('blogname') . "\" <$wp_email>";$headers = "$from\nContent-Type: text/html; charset=" . get_option('blog_charset') . "\n";wp_mail( $to, $subject, $message, $headers );}}
add_action('comment_post', 'comment_mail_notify');

function wp_smilies() {global $wpsmiliestrans;if ( !get_option('use_smilies') or (empty($wpsmiliestrans))) return;$smilies = array_unique($wpsmiliestrans);$link='';foreach ($smilies as $key => $smile) {$file = get_bloginfo('template_directory').'/images/smilies/'.$smile;$value = " ".$key." ";$img = "<img src=\"{$file}\" alt=\"{$smile}\" />";$imglink = htmlspecialchars($img);$link .= "<span><a href=\"#comment\" onclick=\"document.getElementById('comment').focus();document.getElementById('comment').value += '{$value}';return false;\">{$img}</a></span>";} echo '<div class="editor_tools clearfix"><span><a href="javascript:SIMPALED.Editor.empty();" title="清空内容" class="et_empty">清空内容</a></span><span><a href="javascript:SIMPALED.Editor.strong()" title="粗体" class="et_strong">粗体</a></span><span><a href="javascript:SIMPALED.Editor.em()" title="斜体" class="et_em">斜体</a></span><span><a href="javascript:SIMPALED.Editor.underline()" title="下划线" class="et_underline">下划线</a></span><span><a href="javascript:SIMPALED.Editor.del()" title="删除线" class="et_del">删除线</a></span><span><a href="javascript:SIMPALED.Editor.ahref()" title="链接" class="et_ahref">链接</a></span><span><a href="javascript:SIMPALED.Editor.fontColor();" title="字体颜色" class="et_color">字体颜色</a></span><span><a href="javascript:SIMPALED.Editor.smilies()" title="表情" class="et_smilies">表情</a></span><div id="smilies-container"><div class="wp_smilies">'.$link.'</div></div></div>';}
if (is_user_logged_in()) {add_filter('comment_form_logged_in_after', 'wp_smilies');} else { add_filter( 'comment_form_after_fields', 'wp_smilies');}
add_filter('smilies_src','ice_smilies_src',1,10);
function ice_smilies_src ($img_src, $img, $siteurl){return get_bloginfo('template_directory').'/images/smilies/'.$img;}


	add_action('admin_footer', 'media_upload_for_upyun');function media_upload_for_upyun(){ ?>
	<div id="ddm-lay"></div>
	<div id="ddm-box">
		<div id="ddm-content" class="cfx">
			<ul id="ddm-cate">
				<li><a href="#" class="current">静态面板短代码</a></li>
				<li><a href="#">新版静态面板短代码</a></li>
				<li><a href="#">按钮短代码</a></li>
				<li><a href="#">音乐</a></li>
				<li><a href="#">视频播放短代码</a></li>
			</ul>
			<ul id="ddm-ddm">
				<li class="cfx current">
					<p>旧版</p>
					<a href="1">下载面板</a><a href="2">警告面板</a><a href="3">介绍面板</a><a href="4">文本面板</a><a href="5">教程面板</a><a href="6">项目面板</a><a href="7">错误面板</a><a href="8">提问面板</a><a href="9">链接面板</a><a href="10">代码面板</a></li>
				<li class="cfx">
					<p>新版</p>
					<a href="11">下载面板</a><a href="12">警告面板</a><a href="13">介绍面板</a><a href="14">文本面板</a><a href="15">教程面板</a><a href="16">项目面板</a><a href="17">错误面板</a><a href="18">提问面板</a><a href="19">链接面板</a><a href="20">代码面板</a></li>
				<li class="cfx"><a href="21">下载按钮</a><a href="22">爱心图标</a><a href="23">文本图标</a><a href="24">盒子图标</a><a href="25">搜索图标</a><a href="26">文档图标</a><a href="27">链接图标</a><a href="28">箭头图标</a><a href="29">音乐图标</a></li>
				<li class="cfx"><a href="30">音乐</a><a href="31">音乐(可自动播放)</a></li>
				<li class="cfx"><a href="33">优酷</a><a href="34">土豆</a><a href="35">酷6</a><a href="36">音悦台</a></li>
			</ul>
			<a id="ddm-close" href="#">X</a></div>
	</div>
	<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/ie7.css" type="text/css" media="all">
	<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.ddm.js"></script>
	<?php }
	add_action('media_buttons_context',  'add_my_custom_button');
	function add_my_custom_button($context) {$img = '<img src="' . get_bloginfo('template_url') . '/images/ddm.png" width="15" height="15" />';
	$context .='<a href="#" id="ddm-button" title="短代码" class="thickbox">' . $img . '</a>';
	return $context;}

?>