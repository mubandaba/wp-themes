<form role="search" method="get" id="searchform" action="http://192.168.18.1/wordpress/">
	<div><input type="text" value="Search..." name="s" id="s" onfocus="if (value =='Search...'){value ='';$('#uns').fadeIn()}" onblur="if (value ==''){value='Search...'}">
	<p id="uns" style="display:none;" onclick="document.getElementById('s').value='Search...';$('#uns').fadeOut()">&nbsp;</p></div>
</form><div class="clear"></div>