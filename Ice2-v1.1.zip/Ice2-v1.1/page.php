﻿<?php get_header(); ?>

	<div class="content left w680">
		<div class="postlist">
			<?php if(have_posts()){while(have_posts()){the_post();?>
			<div id="post-<?php the_ID();?>" class="post">
				<div class="postcon nr">
					<h2 class="title"><a href="<?php the_permalink();?>" rel="bookmark" title="<?php the_title(); ?>">
					<?php the_title();?></a></h2>
					<span class="entry">
						<?php the_content(); ?>
					</span>
				</div>

<div class="clear"></div>
<?php include_once('sharebar.php'); ?>
				<div class="clear"></div>
			</div>
			<div class="clear"></div>
			<?php }?>
			<?php }else{?>
			<div>
				<div class="title">
					<h2>额..神啊！发生神马事了....</h2>
				</div>
				<div class="entry">
					<p>神曰：你要找的东西不在地球上</p>
				</div>
			</div>
			<?php }?>
		</div>

		<?php comments_template('', true); ?>
	</div>

	<div class="sidebarcon right"><?php get_sidebar(); ?></div>

<?php get_footer(); ?>