<div id="sidebar">
	<ul class="rightbar">
		<li class="widget-item">
			<?php get_search_form(); ?>
		</li>
		<?php if ( !function_exists('dynamic_sidebar')
			|| !dynamic_sidebar() ) : ?>
		<?php endif; ?>
	</ul>
</div>