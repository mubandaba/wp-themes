<?php get_header(); ?>

	<div class="content left w680">
		<div class="postlist">
			<?php if(have_posts()){while(have_posts()){the_post();?>
			<div id="post-<?php the_ID();?>" class="post">
				<div class="postlefts left">
					<ul class="postmeta">
					<li class="postdate"><?php the_time('Y.m.j'); ?></li>
					<li class="postcomm"><?php comments_popup_link('没有爪印','1 个爪印','% 个爪印');?></li>
					<li class="postcat"><?php the_category(', ');?></li>
					<li class="postaut"><?php the_author();?></li>
					<?php edit_post_link('<li class="postedit">Edit</li>');?>
					</ul>
				</div>
				<div class="postcon lb left">
					<h2 class="title"><a href="<?php the_permalink();?>" rel="bookmark" title="<?php the_title(); ?>">
					<?php the_title();?></a></h2>
					<span class="entry">
						<?php echo cut_str(strip_tags(apply_filters('the_content',$post->post_content)),160); ?>
					</span>
				</div>
				<div class="clear"></div>
				<span class="readmore right"><a href="<?php the_permalink();?>" rel="bookmark" title="<?php the_title(); ?>">阅读更多</a></span>
				<div class="clear"></div>
			</div>
			<div class="clear"></div>
			<?php }?>
		<div id="postnavigation">   
			<div class="page_navi"> <?php par_pagenavi(9); ?> </div>  
			<div class="clear"></div>  
		</div>
			<?php }else{?>
			<div>
				<div class="title">
					<h2>额..神啊！发生神马事了....</h2>
				</div>
				<div class="entry">
					<p>神曰：你要找的东西不在地球上</p>
				</div>
			</div>
			<?php }?>
		</div>
	</div>

	<div class="sidebarcon right"><?php get_sidebar(); ?></div>

<?php get_footer(); ?>