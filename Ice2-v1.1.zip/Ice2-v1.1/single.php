<?php get_header(); ?>

	<div class="content left w680">
		<div class="postlist">
			<?php if(have_posts()){while(have_posts()){the_post();?>
			<div id="post-<?php the_ID();?>" class="post">
				<div class="postcon nr">
					<h2 class="title"><a href="<?php the_permalink();?>" rel="bookmark" title="<?php the_title(); ?>">
					<?php the_title();?></a></h2>
					<span class="entry">
						<?php the_content(); ?>
					</span>
				</div>


<div class="relatebar">	
<span class="relatetitle">暧昧文章：</span>
<ul class="cf">	
	<?php $post_num = 3; $exclude_id = $post->ID;$posttags = get_the_tags(); $i = 0;if ( $posttags ) { $tags = ''; foreach ( $posttags as $tag ) $tags .= $tag->name . ',';$args = array('post_status' => 'publish','tag_slug__in' => explode(',', $tags), 'post__not_in' => explode(',', $exclude_id), 'caller_get_posts' => 1, 'orderby' => 'comment_date', 'posts_per_page' => $post_num);query_posts($args); while( have_posts() ) { the_post(); ?><li class="left"><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a><span class="relatetime">Posted on <?php the_time('Y.m.j'); ?></span></li>
	<?php $exclude_id .= ',' . $post->ID; $i ++;} wp_reset_query();}if ( $i < $post_num ) { $cats = ''; foreach ( get_the_category() as $cat ) $cats .= $cat->cat_ID . ',';$args = array('category__in' => explode(',', $cats), 'post__not_in' => explode(',', $exclude_id),'caller_get_posts' => 1,'orderby' => 'comment_date','posts_per_page' => $post_num - $i);query_posts($args);while( have_posts() ) { the_post(); ?> <li class="left"><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a><span class="relatetime">Posted on <?php the_time('Y.m.j'); ?></span></li>
	<?php $i ++;} wp_reset_query();}if ( $i  == 0 )  echo '<li>还没有相关文章</li>';?>
</ul>	
</div><div class="clear"></div>
<?php include_once('sharebar.php'); ?>
				<div class="clear"></div>
			</div>
			<div class="clear"></div>
			<?php }?>
			<?php }else{?>
			<div>
				<div class="title">
					<h2>额..神啊！发生神马事了....</h2>
				</div>
				<div class="entry">
					<p>神曰：你要找的东西不在地球上</p>
				</div>
			</div>
			<?php }?>
		</div>

		<?php comments_template('', true); ?>
	</div>

	<div class="sidebarcon right"><?php get_sidebar(); ?></div>

<?php get_footer(); ?>