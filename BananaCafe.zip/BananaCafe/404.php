<?php get_header(); ?>

<!--Container-->
<div id="container">


<div class="error">
<a onfocus="this.blur()" href="http://cdc.tencent.com" class="back_index"><b>回到首页</b></a>
<a onfocus="this.blur()" href="javascript:history.go(-1);" class="back_page"><b>返回上页</b></a>
</div>

</div>
<!--Container End-->

<?php get_footer(); ?>