<?php get_header(); ?>
<?php if ( have_posts() ) : ?>
    <div class="pageheader">
        <div class="layoutSingleColumn-header v-displayCenter">
            <h1 class="hero-title">

                <?php echo get_search_query();?>

            </h1>

            <div class="note">

                <?php echo get_search_query().'的搜索结果'; ?>

            </div>


        </div>  </div>
    <div class="layoutSingleColumn v-displayCenter">
        <div class="blockGroup--posts blockGroup--cardWithFullBleedImage-container">
            <?php while ( have_posts() ) : the_post(); ?>
                <?php get_template_part( 'content', 'archive' ); ?>
            <?php endwhile; ?>
        </div>
        <div class="posts--load--more v-alignCenter"><?php next_posts_link( '更多文章' ); ?></div>

    </div>
<?php endif; ?>
<?php get_footer(); ?>