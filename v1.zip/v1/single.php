<?php get_header(); ?>
	<div class="layoutMultiColumn-container v-displayCenter">
<div class="layoutMultiColumn--primary layoutMultiColumn">
<div class="bucket-content bucket-content--posts">
	<?php while ( have_posts() ) : the_post(); ?>			
        <div class="bucket-item" itemtype="http://schema.org/Article" itemscope="itemscope">
            <div class="postItemTop">
                <h1 class="postItem-title" itemprop="headline"><?php the_title();?></h1>
				<div class="postItem-meta"><span itemprop="datePublished"><?php echo get_the_date('M d, Y');?></span> <?php _e( 'in', 'aladdin' ); ?>
                <span itemprop="articleSection"><?php echo get_the_category_list(",");?></span> with <span><?php if ( function_exists('custom_the_views') ) custom_the_views($post->ID); ?></span></div>
            </div>
			
            <div class="article-content" itemprop="articleBody">
                <?php 
				the_content();?>
				</div>
		</div>
		<?php comments_template( '', true ); ?>
		<?php endwhile; ?></div>
    </div>
<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>