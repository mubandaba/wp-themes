<?php
/**
 * Theme functions file
 * @package bigfa
 */

require( dirname(__FILE__) . '/modules/base.php' );
?>
