<div class="layoutMultiColumn--secondary layoutMultiColumn">
    <?php if( is_home() ){
        dynamic_sidebar( 'sidebar-1' );
    }else{

        dynamic_sidebar( 'sidebar-2' );
    }?>

</div>