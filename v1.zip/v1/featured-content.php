<div class="blockDivider">
<div class="blockDivider-name">
<h2 class="blockDivider-title">热门文章</h2><div class="v-miniFont v-floatRight blockDivider-button">
<a href="#">更多文章...</a>
</div>
</div>
<ul class="blockGroup-list"><?php
                    $args = array( 'posts_per_page' => 6,'meta_key' => 'views',
            'orderby' => 'meta_value_num');
                    $myposts = get_posts( $args );$i = 0;
                    foreach ( $myposts as $post ) : setup_postdata( $post ); $i++?>
                   <li class="block--cardWithImage v-clearfix">
<a class="block-image v-floatLeft" href="<?php the_permalink();?>">
<?php post_thumbnail(120,60)?>
</a>
<div class="block-snippet">
<h3 class="block-snippet--title v-overflowHidden">
<a href="<?php the_permalink();?>" title="<?php the_title();?>"><?php the_title();?></a>
</h3>
<p class="block-snippet--meta"><?php if ( function_exists('custom_the_views') ) custom_the_views($post->ID); ?></p>
</div>
</li>
                            <?php endforeach;
                            wp_reset_postdata();?>
		</ul>

</div>