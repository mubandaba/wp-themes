<?php get_header(); ?>


<?php if ( have_posts() ) : ?>
    <div class="pageheader">
        <div class="layoutSingleColumn-header v-displayCenter">
            <h1 class="hero-title">

                <?php echo single_cat_title( '', false );?>

            </h1>
            <?php if ( category_description() ) : // Show an optional category description ?>
                <div class="note">

                    <?php echo category_description(); ?>

                </div>
            <?php endif; ?>

        </div>  </div>
    <div class="layoutSingleColumn v-displayCenter">
        <div class="blockGroup--posts blockGroup--cardWithFullBleedImage-container">


            <?php /* Start the Loop */ ?>
            <?php while ( have_posts() ) : the_post(); ?>
                <?php get_template_part( 'content', 'archive' ); ?>
            <?php endwhile; ?>





        </div>
        <div class="posts--load--more v-alignCenter"><?php next_posts_link( '更多文章' ); ?></div>
    </div>
<?php endif; // end have_posts() check ?>
<?php get_footer(); ?>