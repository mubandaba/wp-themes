<?php get_header(); ?>

	<div class="layoutMultiColumn-container v-displayCenter">
	<div class="pageside">
<?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_class' => 'pagemenu','container'=>'ul' ) ); ?>
</div>
		<div class="page--content" role="main">

			<?php while ( have_posts() ) : the_post(); ?>
			<header class="article-header"><h1 class="article-title"><?php the_title();?></h1></header>
			<div class="article-content">
				<?php the_content();?></div>
			<?php endwhile; // end of the loop. ?>

		</div><!-- #content -->
	</div><!-- #primary -->


<?php get_footer(); ?>