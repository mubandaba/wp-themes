<article class="block--inset" itemtype="http://schema.org/Article" itemscope="itemscope">
    <div class="block-content block-with-image v-clearfix">
        <a class="block---image v-floatLeft" href="<?php the_permalink();?>">
            <?php post_thumbnail(240,160)?>
        </a>
        <div class="block---text">
            <h2 class="block---title" itemprop="headline">
                <a href="<?php the_permalink();?>"><?php the_title();?></a>
            </h2>
            <div class="article-right-text" itemprop="description"><?php echo mb_strimwidth(strip_tags($post->post_content), 0, 200,"...");?></div>
        </div>
    </div>
    <div class="postMetaInline-footerLockup">
        <span class="postMetaInline" itemprop="datePublished"><?php echo get_the_date('M d, Y');?></span><span class="postMetaInline postMetaViews"><?php if ( function_exists('custom_the_views') ) custom_the_views($post->ID); ?></span>
    </div>
</article>