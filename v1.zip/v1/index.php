<?php get_header(); ?>

    <div class="layoutMultiColumn-container v-displayCenter">
        <div class="layoutMultiColumn--primary layoutMultiColumn">
            <?php
            if ( is_front_page() ) {
                // Include the featured content template.
                get_template_part( 'featured-content' );
            }
            ?>
            <div class="blockGroup--posts">
                <?php if ( have_posts() ) : ?>

                    <?php /* Start the Loop */ ?>
                    <?php while ( have_posts() ) : the_post(); ?>
                        <?php get_template_part( 'content', get_post_format() ); ?>
                    <?php endwhile; ?>



                <?php endif; // end have_posts() check ?>

            </div>
            <div class="posts--load--more v-alignCenter"><?php next_posts_link( '更多文章' ); ?></div>
        </div>
        <?php get_sidebar(); ?></div>
<?php get_footer(); ?>