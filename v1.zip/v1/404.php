<?php


get_header(); ?>

	<div class="layoutMultiColumn-container">
	<div class="error--page">
	<i class="iconfont icon-404cuowu"></i>
<h2>沒有找到你要的内容！</h2>
<p>
<a class="btn btn-primary" href="#">返回首页</a>
</p>
	</div>
</div>
<?php get_footer(); ?>