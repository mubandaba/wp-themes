<?php
function vytto_widgets_init() {
    register_sidebar( array(
        'name' => 'Main Sidebar',
        'id' => 'sidebar-1',
        'description' => '首页边栏',
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );
	register_sidebar( array(
        'name' => 'Single Sidebar',
        'id' => 'sidebar-2',
        'description' => '内页边栏',
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );

}
add_action( 'widgets_init', 'vytto_widgets_init' );

add_action('widgets_init', create_function('', 'return register_widget("tg_posts");'));
class tg_posts extends WP_Widget {
    function tg_posts() {
        global $prename;
        $this->WP_Widget('tg_posts', $prename.'多功能文章 ', array( 'description' => '图文展示（最新文章+热门文章+热评文章）' ));
    }
    function widget($args, $instance) {
        extract($args, EXTR_SKIP);
        echo $before_widget;
        $title        = apply_filters('widget_name', $instance['title']);
        $limit        = $instance['limit'];
        $cat          = $instance['cat'];
        $module      = $instance['module'];
        $orderby      = $instance['orderby'];

        if($module=='medium') $className = 'widget--posts--medium v-clearfix';
        if($module=='small') $className = 'widget--posts--width-image v-clearfix';
        if($module=='text') $className = 'widget--posts--widthout-image v-clearfix';
        echo $before_title.$title.$after_title;
        echo '<ul class="'.$className.'">';
        echo tg_posts_list( $orderby,$commentcount,$limit,$module,$cat );
        echo '</ul>';
        echo $after_widget;
    }
    function update($new_instance, $old_instance) {
        $instance                 = $old_instance;
        $instance['title']        = strip_tags($new_instance['title']);
        $instance['limit']        = strip_tags($new_instance['limit']);
        $instance['cat']          = strip_tags($new_instance['cat']);
        $instance['module']      = strip_tags($new_instance['module']);
        $instance['orderby']      = strip_tags($new_instance['orderby']);
        return $instance;
    }
    function form($instance) {
        $instance = wp_parse_args( (array) $instance, array(
                'title'        => '最新文章',
                'limit'        => '5',
                'cat'          => '',
                'module'      => '',
                'orderby'      => 'date'
            )
        );
        $title        = strip_tags($instance['title']);
        $limit        = strip_tags($instance['limit']);
        $cat          = strip_tags($instance['cat']);
        $module      = strip_tags($instance['module']);
        $orderby      = strip_tags($instance['orderby']);
        ?>

        <p>
            <label>
                标题：
                <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $instance['title']; ?>" />
            </label>
        </p>

        <p>
            <label>
                排序：
                <select class="widefat" id="<?php echo $this->get_field_id('orderby'); ?>" name="<?php echo $this->get_field_name('orderby'); ?>" style="width:100%;">
                    <option value="comment_count" <?php selected('comment_count', $instance['orderby']); ?>>按评论数</option>
                    <option value="date" <?php selected('date', $instance['orderby']); ?>>按发布时间</option>
                    <option value="meta_value_num" <?php selected('meta_value_num', $instance['orderby']); ?>>按浏览量</option>
                </select>
            </label>
        </p>
        <p>
            <label>
                显示方式：
                <select class="widefat" id="<?php echo $this->get_field_id('module'); ?>" name="<?php echo $this->get_field_name('module'); ?>" style="width:100%;">
                    <option value="medium" <?php selected('medium', $instance['module']); ?>>大缩略图模式</option>
                    <option value="small" <?php selected('small', $instance['module']); ?>>小缩略图模式</option>
                    <option value="text" <?php selected('text', $instance['module']); ?>>无缩略图模式</option>
                </select>
            </label>
        </p>
        <p>
            <label>
                分类限制：
                <a style="font-weight:bold;color:#f60;text-decoration:none;" href="javascript:;" title="格式：1,2 &nbsp;表限制ID为1,2分类的文章&#13;格式：-1,-2 &nbsp;表排除分类ID为1,2的文章&#13;也可直接写1或者-1；注意逗号须是英文的">？</a>
                <input class="widefat" id="<?php echo $this->get_field_id('cat'); ?>" name="<?php echo $this->get_field_name('cat'); ?>" type="text" value="<?php echo attribute_escape($cat); ?>" size="24" />
            </label>
        </p>
        <p>
            <label>
                显示数目：
                <input class="widefat" id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="number" value="<?php echo attribute_escape($limit); ?>" size="24" />
            </label>
        </p>
    <?php
    }
}

function tg_posts_list($orderby,$commentcount,$limit,$module,$cat) {
    $args = array(
        'order'            => DESC,
        'cat'              => $cat,
        'orderby'          => $orderby,
        'showposts'        => $limit,
        'meta_key' => 'views',
        'caller_get_posts' => 1
    );
    query_posts($args);
    $i=0;while (have_posts()) : the_post(); $i++;
        if($module=='medium') :?>
            <li><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><b><?php echo $i;?></b><?php post_thumbnail(270,140,true,'medium-thumbnail')?><h4 class="medium-title"><?php the_title(); ?></h4></a><p class="medium-meta"><?php echo the_modified_date('M d, Y');?> - <?php if ( function_exists('custom_the_views') ) custom_the_views($post->ID); ?></p></li>
        <?php
        elseif($module=='small'):?>
            <li class="v-clearfix">
                <a href="<?php the_permalink() ?>">
                    <?php post_thumbnail(120,60,true,'v-floatLeft')?>
                    <?php the_title(); ?></a>
            </li>

        <?php else :?>
            <li><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?><small><?php echo the_modified_date('M d, Y');?> - <?php if ( function_exists('custom_the_views') ) custom_the_views($post->ID); ?></small></a></li>

        <?php endif;
    endwhile; wp_reset_query();
}

function post_thumbnail( $width = 255,$height = 130,$echo = true,$class = null ){
    global $post;

    if ($class) $class = 'class="'.$class.'" ';

    if( has_post_thumbnail() ){

        $timthumb_src = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
        $post_timthumb = '<img width="'.$width.'" height="'.$height.'" '.$class.'src="'.get_bloginfo("template_url").'/timthumb.php?src='.$timthumb_src[0].'&amp;h='.$height.'&amp;w='.$width.'&amp;zc=1" alt="'.get_the_title().'"/>';
        $output = $post_timthumb;

    } else {

        $content = $post->post_content;
        $defaltthubmnail = get_template_directory_uri().'/images/1.jpeg';
        preg_match_all('/<img.*?(?: |\\t|\\r|\\n)?src=[\'"]?(.+?)[\'"]?(?:(?: |\\t|\\r|\\n)+.*?)?>/sim', $content, $strResult, PREG_PATTERN_ORDER);
        $n = count($strResult[1]);
        if($n > 0){

            $output = '<img width="'.$width.'" height="'.$height.'" '.$class.'src="'.get_bloginfo("template_url").'/timthumb.php?w='.$width.'&amp;h='.$height.'&amp;src='.$strResult[1][0].'" alt="'.get_the_title().'"/>';

        } else {

            $output = '<img width="'.$width.'" height="'.$height.'" '.$class.'src="'.get_bloginfo("template_url").'/timthumb.php?w='.$width.'&amp;h='.$height.'&amp;src='.$defaltthubmnail.'" alt="'.get_the_title().'"/>';

        }

    }
    if($echo == true){

        echo $output;

    } else {

        return $output;

    }
}


function vytto_setup() {

    register_nav_menu( 'primary', __( 'Primary Menu', 'vytto' ) );

    add_theme_support( 'post-thumbnails' );
    set_post_thumbnail_size( 624, 9999 ); // Unlimited height, soft crop
}
add_action( 'after_setup_theme', 'vytto_setup' );




function vytto_scripts_styles() {
    global $wp_styles;

    wp_enqueue_style( 'vytto-style', get_stylesheet_uri() );

}
add_action( 'wp_enqueue_scripts', 'vytto_scripts_styles' );


function vytto_wp_title( $title, $sep ) {
    global $paged, $page;

    if ( is_feed() )
        return $title;

    // Add the site name.
    $title .= get_bloginfo( 'name', 'display' );

    // Add the site description for the home/front page.
    $site_description = get_bloginfo( 'description', 'display' );
    if ( $site_description && ( is_home() || is_front_page() ) )
        $title = "$title $sep $site_description";

    // Add a page number if necessary.
    if ( $paged >= 2 || $page >= 2 )
        $title = "$title $sep " . sprintf( __( 'Page %s', 'vytto' ), max( $paged, $page ) );

    return $title;
}
add_filter( 'wp_title', 'vytto_wp_title', 10, 2 );

function get_the_views($post_id) {
    $count_key = 'views';
    $views = get_post_custom($post_id);
    $views = intval($views['views'][0]);
    $post_views = intval(post_custom('views'));
    if ($views == '') {
        return '';
    } else {

        return $views;

    }
}
function set_post_views() {
    global $post;
    $post_id = intval($post->ID);
    $count_key = 'views';
    $views = get_post_custom($post_id);
    $views = intval($views['views'][0]);
    if (is_single() || is_page()) {
        if(!update_post_meta($post_id, 'views', ($views + 1))) {
            add_post_meta($post_id, 'views', 1, true);
        }
    }
}
add_action('get_header', 'set_post_views');
function custom_the_views($post_id, $echo=true, $unit=' reads') {
    $count_key = 'views';
    $views = get_post_custom($post_id);
    $views = intval($views['views'][0]);
    $post_views = intval(post_custom('views'));
    if ($views == '') {
        return '';
    } else {
        if ($echo) {
            echo $views . $unit;
        } else {
            return $views . $unit;
        }
    }
}
function vytto_comment($comment, $args, $depth) {
    $GLOBALS['comment'] = $comment;
    global $commentcount,$insertAD;
    if(!$commentcount) {
        $page = ( !empty($in_comment_loop) ) ? get_query_var('cpage')-1 : get_page_of_comment( $comment->comment_ID, $args )-1;
        $cpp=get_option('comments_per_page');
        $commentcount = $cpp * $page;
    }
    switch ( $comment->comment_type ) :
        case 'pingback' :
        case 'trackback' :
            ?>
            <li <?php comment_class(); ?> id="comment-<?php comment_ID(); ?>">
            <p><?php _e( 'Pingback:', 'vytto' ); ?> <?php comment_author_link(); ?> </p>
            <?php
            break;
        default :
            global $post;
            ?>
                <li <?php comment_class(); ?> <?php if( $depth > 2){ echo ' style="margin-left:-50px;"';} ?> id="li-comment-<?php comment_ID() ?>" itemtype="http://schema.org/Comment" itemscope="" itemprop="comment">
                <div class="comment-block">
                    <div class="comment-info v-clearfix">
                        <?php echo get_avatar( $comment, $size = '56');?>
                        <div class="comment-meta">
                            <div class="fn" itemprop="author">
                                <?php echo get_comment_author_link();?>
                            </div>
                            <div itemprop="datePublished"><?php echo get_comment_date(); ?></div>
                        </div>
                    </div>
                    <div class="comment-content" itemprop="description">
                        <?php comment_text(); ?>
                    </div>
                    <div class="reply"><?php comment_reply_link(array_merge( $args, array('reply_text' => 'Give a reply','depth' => $depth, 'max_depth' => $args['max_depth']))) ?></div>

                    <?php
                    if(!$parent_id = $comment->comment_parent){
                        ++$commentcount;
                        echo "<span floor = '". $commentcount ."'class='floor'></span>";
                        ++$insertAD;
                    }
                    ?>

                </div>
            <?php
            break;
    endswitch;
}


function comment_mail_notify($comment_id) {
    $comment = get_comment($comment_id);
    $parent_id = $comment->comment_parent ? $comment->comment_parent : '';
    $spam_confirmed = $comment->comment_approved;
    if (($parent_id != '') && ($spam_confirmed != 'spam')) {
        $wp_email = 'no-reply@' . preg_replace('#^www\.#', '', strtolower($_SERVER['SERVER_NAME'])); //e-mail 發出點, no-reply 可改為可用的 e-mail.
        $to = trim(get_comment($parent_id)->comment_author_email);
        $subject = '你在 [' . get_option("blogname") . '] 的留言有了新回复';
        $message = '

	<div align="center" style="PADDING-BOTTOM: 66px; BACKGROUND-COLOR: #ededed; PADDING-LEFT: 0px; WIDTH: 100%; PADDING-RIGHT: 0px; COLOR: #777; PADDING-TOP: 66px">
	<div style="TEXT-ALIGN: left; BACKGROUND-COLOR: #fff; WIDTH: 700px">
<div style="BACKGROUND-COLOR: #444; MARGIN: 0px 60px 30px; WIDTH: 580px; HEIGHT: 4px"></div>
<h2 style="LINE-HEIGHT: 50px; MARGIN: 0px 60px 30px; WIDTH: 580px; COLOR: #24b0cf; FONT-SIZE: 28px; FONT-WEIGHT: bold">
<p class="MsoNormal" align="center" style="TEXT-ALIGN: center">
<b>
<span style="FONT-FAMILY: 微软雅黑; FONT-SIZE: 15pt">
<font size="5">
<font color="black">'.$subject.'
</font>
</font>
</span>
</b>
</p>
</h2>
<div style="BACKGROUND-COLOR: #444; MARGIN: 0px 60px 40px; WIDTH: 580px; HEIGHT: 1px"></div>
<div style="MARGIN: 0px 60px 30px; WIDTH: 580px;">
<p><strong>' . trim(get_comment($parent_id)->comment_author) . ', 你好!</strong></p>
<p class="message"><strong>您曾在《' . get_the_title($comment->comment_post_ID) . '》的留言为:</strong><br />'
            . trim(get_comment($parent_id)->comment_content) . '</p>
	<p><strong>' . trim($comment->comment_author) . ' 给你的回复是:</strong><br />'
            . trim($comment->comment_content) . '<br /></p>
	<p>你可以点击此链接 <a href="' . htmlspecialchars(get_comment_link($parent_id)) . '">查看完整内容</a> | 欢迎再次来访<a href="' . home_url() . '">' . get_option('blogname') . '</a></p></div><div style="BORDER-BOTTOM: #a5a5a5 2px dashed; MARGIN: 40px auto 30px; WIDTH: 700px"></div><table style="PADDING-BOTTOM: 30px; MARGIN: 0px 60px 30px; PADDING-LEFT: 0px; WIDTH: 580px; PADDING-RIGHT: 0px; PADDING-TOP: 0px">
<tbody>
<tr>
<td style="WIDTH: 500px">
<p style="LINE-HEIGHT: 20px; MARGIN: 0px; COLOR: #999; FONT-SIZE: 12px">©' . get_option('blogname') . ' 2014</p>
<p style="LINE-HEIGHT: 20px; MARGIN: 0px; COLOR: #999; FONT-SIZE: 12px">' . get_bloginfo( 'description' ) .'</p>
<br>
</td>
</tr>
</tbody>
</table></div>
</div>';

        $from = "From: \"" . get_option('blogname') . "\" <$wp_email>";
        $headers = "$from\nContent-Type: text/html; charset=" . get_option('blog_charset') . "\n";
        wp_mail( $to, $subject, $message, $headers );
    }
}
add_action('comment_post', 'comment_mail_notify');


function vytto($e){
    $option =get_option('vytto_config');
    if( !empty( $option[$e] ))
        return $option[$e];

    return false ;

}
function hu_popuplinks($text) {
    $text = preg_replace('/<a (.+?)>/i', "<a $1 target='_blank'>", $text);
    return $text;
}
add_filter('get_comment_author_link', 'hu_popuplinks', 6);

function vytto_description() {
    global $s, $post , $wp_query;
    $description = '';
    $blog_name = get_bloginfo('name');
    if ( is_singular() ) {
        $ID = $post->ID;
        $title = $post->post_title;
        $author = $post->post_author;
        $user_info = get_userdata($author);
        $post_author = $user_info->display_name;
        if (!get_post_meta($ID, "meta-description", true)) {$description = $title.' - 作者: '.$post_author.',首发于'.$blog_name;}
        else {$description = get_post_meta($ID, "meta-description", true);}
    } elseif ( is_home () )    { $description = vytto('description');
    } elseif ( is_tag() )      { $description = single_tag_title('', false) . " - ". trim(strip_tags(tag_description()));
    } elseif ( is_category() ) { $description = single_cat_title('', false) . " - ". trim(strip_tags(category_description()));
    } elseif ( is_archive() )  { $description = $blog_name . "'" . trim( wp_title('', false) ) . "'";
    } elseif ( is_search() )   { $description = $blog_name . ": '" . esc_html( $s, 1 ) . "' 的搜索結果";
    }  else { $description = $blog_name . "'" . trim( wp_title('', false) ) . "'";
    }
    $description = mb_substr( $description, 0, 220, 'utf-8' );
    echo "<meta name=\"description\" content=\"$description\">\n";
}
add_action('wp_head','vytto_description',1);

function vytto_footer() {
    ?>
    <div class="bentoFooter v-alignCenter">
        <?php $theme_data = wp_get_theme(get_option('template'));
        $theme_version = $theme_data->Version;  ?>
        <p>Theme V1 By <a href="http://tinyglim.com" target="_blank" title="Tinyglim">Tinyglim</a> . Version <?php echo $theme_version;?></p>
    </div>
    </body>
    </html>
<?php }
add_action('wp_footer','vytto_footer',1);
?>