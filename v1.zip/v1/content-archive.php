<div class="block--cardWithFullBleedImage">
			<?php echo post_thumbnail(358,227,false,'block-image');?>
			<h2 class="card-image-title u-overflowHidden"><a href="<?php the_permalink();?>" title="<?php the_title();?>"><?php the_title();?></a></h2>
			<div class="footer-meta v-miniFont"><?php echo the_modified_date('M d, Y');?> - <?php if ( function_exists('custom_the_views') ) custom_the_views($post->ID); ?></div>
				</div>