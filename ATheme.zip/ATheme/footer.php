<div id="footer">
    <div id="footer_inner">
        <div class="copyright">
            <?php ATheme_menu(bottom_bar); ?>
            本站采用<a href="http://creativecommons.org/licenses/by-nc-sa/3.0/cn/deed.en rel="nofollow" target="_blank"> CC BY-NC-SA 3.0 </a>协议进行授权 <?php echo ATheme_comicpress_copyright(); ?> <?php bloginfo('name'); ?>. Powered by <a href="http://wordpress.org/" rel="nofollow" target="_blank">WordPress</a>. Theme by <a href="http://andyshare.com/" target="_blank">Andy</a> and <a href="http://www.hqqblog.com/" target="_blank">HuaQiQi</a>.
            <?php if (get_option('swt_statistics') == 'Display') { ?><?php echo stripslashes(get_option('swt_statisticscode')); ?>
            <?php { echo ''; } ?><?php } else { } ?>
        </div>
    </div>
</div>

<?php if (get_option('swt_wpshare') == 'Display') { ?>
<script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/wpshare.js"></script>
<?php { echo ''; } ?><?php } else { } ?>
<?php ATheme_show_notify(); ?>
<script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F6606ff760ac2733ab4d32bebd54cf89f' type='text/javascript'%3E%3C/script%3E"));
$(window).load(function() {     
$("#circle").fadeOut(500);
$("#circle1").fadeOut(700);
});</script>

</body>
</html>