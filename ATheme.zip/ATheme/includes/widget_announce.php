<?php
/* 使用WP评论作为公告栏 by zwwooooo | zww.me */
////参数设定
$page_ID=406; //用来作为公告栏的页面或者文章id
$num=3; //显示公告的条数
?>

<h3>博主的吐糟录</h3>
<ul>
	<?php
	$announcement = '';
	$comments = get_comments("number=$num&post_id=$page_ID");
	if ( !empty($comments) ) {
		foreach ($comments as $comment) {

			$announcement .= '<li>'. convert_smilies($comment->comment_content) . ' <span style="color:#999;font-size: xx-small">(' . get_comment_date('m-d H:i',$comment->comment_ID) . ')</span></li>';
		}
	}
	if ( empty($announcement) ) $announcement = '<li>欢迎光临本博！</li>';
	echo $announcement;
	?>
</ul>
<?php if ($user_ID) echo '<p style="text-align:right;">[<a href="' . get_page_link($page_ID) . '#respond" rel="nofollow" class="anno">发表公告</a>]</p>'; ?>