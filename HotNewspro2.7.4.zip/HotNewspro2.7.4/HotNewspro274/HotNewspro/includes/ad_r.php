<div class="ad_r">
	<?php echo stripslashes(get_option('swt_ad_rc')); ?>
</div>