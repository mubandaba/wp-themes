<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/mousewheel.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/fancybox-video.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	$("a[rel=example_group]").fancybox({
		'padding'			: 5,
		'autoScale'			: false,
		'transitionIn'		: 'none',
		'transitionOut'		: 'none'
	});

	$("#various1").fancybox({
		'padding'			: 5,
		'autoScale'			: false,
		'transitionIn'		: 'none',
		'transitionOut'		: 'none'
	});

	$("#various2").fancybox({
		'padding'			: 5,
		'autoScale'			: false,
		'transitionIn'		: 'none',
		'transitionOut'		: 'none'
	});
});
</script>