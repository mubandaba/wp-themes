<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
	<input type="text" name="s" id="s" class="swap_value" />
	<input type="image" src="<?php bloginfo('template_directory'); ?>/images/go.gif" id="go" alt="Search" title="搜索" />
</form>