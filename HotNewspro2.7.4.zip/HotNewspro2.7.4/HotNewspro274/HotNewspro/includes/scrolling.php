<?php if (get_option('swt_rolling') == 'true') { ?>
<?php include('show.php'); ?>
<?php } ?>
<?php if (get_option('swt_rolling_v') == 'true') { ?>
<?php include('show_v.php'); ?>
<?php } ?>