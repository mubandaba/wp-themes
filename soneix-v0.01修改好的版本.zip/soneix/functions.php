<?php
	$techengage_theme_path = get_template_directory() . '/inc/';

	require( $techengage_theme_path . '/custom-navwalker.php' );
	require( $techengage_theme_path . '/font/font.php');

	require( $techengage_theme_path .'/enqueue.php');

	require( $techengage_theme_path . '/customize/customize_copyright_and_icons.php');
	require( $techengage_theme_path . '/customize/footer_settings.php');
	require( $techengage_theme_path . '/customize/header_settings.php');
	require( $techengage_theme_path . '/customize/customize_control/class-customize-alpha-color-control.php');
	require( $techengage_theme_path . '/customize/colors_copyright_and_icons.php');
	require( $techengage_theme_path . '/customize/colors_footer_settings.php');
	require( $techengage_theme_path . '/customize/colors_header_settings.php');
	require( $techengage_theme_path . '/customize/pagination_settings.php');

if ( ! function_exists( 'techengage_setup' ) ) :

function techengage_setup() {

	load_theme_textdomain( 'techengage', get_template_directory() . '/languages' );


	add_theme_support( 'automatic-feed-links' );

	add_theme_support( 'title-tag' );

	add_theme_support( 'post-thumbnails' );

	register_nav_menus( array(
		'primary' => __('Primary menu','techengage' )
	) );

	add_theme_support( 'html5', array(
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	add_theme_support( 'custom-logo');

	function techengage_the_custom_logo() {
		the_custom_logo();
	}

	add_filter('get_custom_logo','techengage_logo_class');


	function techengage_logo_class($html)
	{
	$html = str_replace('custom-logo-link', 'navbar-brand', $html);
	return $html;
	}

	add_theme_support( 'custom-background', apply_filters( 'techengage_custom_background_args', array(
		'default-color' => 'eeeeee',
		'default-image' => '',
	) ) );

}
endif;
add_action( 'after_setup_theme', 'techengage_setup' );
function techengage_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'techengage_content_width', 640 );
}
add_action( 'after_setup_theme', 'techengage_content_width', 0 );

//开启友情链接
add_filter('pre_option_link_manager_enabled','__return_true');

//文章浏览次数统计
function record_visitors()
{
    if (is_singular())
    {
      global $post;
      $post_ID = $post->ID;
      if($post_ID)
      {
          $post_views = (int)get_post_meta($post_ID, 'views', true);
          if(!update_post_meta($post_ID, 'views', ($post_views+1)))
          {
            add_post_meta($post_ID, 'views', 1, true);
          }
      }
    }
}
add_action('wp_head', 'record_visitors');

function post_views($before = '(点击 ', $after = ' 次浏览)', $echo = 1)
{
  global $post;
  $post_ID = $post->ID;
  $views = (int)get_post_meta($post_ID, 'views', true);
  if ($echo) echo $before, number_format($views), $after;
  else return $views;
}



function techengage_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'techengage' ),
		'id'            => 'sidebar-1',
		'description'   => '',
		'before_widget' => '<div id="%1$s" class="techengage-widget %2$s bounceInRight animated">',
		'after_widget'  => '</div>',
		'before_title'  => '<h6>',
		'after_title'   => '</h6>',
	) );

	register_sidebar( array(
		'name'          => esc_html__( 'Footer Widget Area', 'techengage' ),
		'id'            => 'footer_widget_area',
		'description'   => '',
		'before_widget' => '<div id="%1$s" class="col-md-6 col-sm-6 rotateInDownLeft animated techengage-widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h6>',
		'after_title'   => '</h6>',
	) );
}
add_action( 'widgets_init', 'techengage_widgets_init' );


function techengage_enqueue_customizer_controls_styles() {
  wp_register_style( 'techengage-customizer-controls', get_template_directory_uri() . '/css/customizer-controls.css', NULL, NULL, 'all' );
  wp_enqueue_style( 'techengage-customizer-controls' );
  }
add_action( 'customize_controls_print_styles', 'techengage_enqueue_customizer_controls_styles' );



require get_template_directory() . '/inc/template-tags.php';

function techengage_read_more() {

	global $post;

	$readbtnurl = '<br><a class="btn btn-tislider-two" href="' . esc_url(get_permalink()) . '">'.esc_html__('Read More','techengage').'</a>';

    return $readbtnurl;
}
add_filter( 'the_content_more_link', 'techengage_read_more' );


   	function techengage_excerpt_more($more) {
   	if ( is_admin() ){
		return $more;
	}
   	global $post;
   	return ' <br><a class="read-more-button" href="'. esc_url(get_permalink($post->ID)) . '">' . esc_html__('Read More &raquo;','techengage') . '</a>';
   	}
   	add_filter('excerpt_more', 'techengage_excerpt_more');


add_action('wp_ajax_techengage_load_more_fun', 'techengage_load_more_fun');
add_action('wp_ajax_nopriv_techengage_load_more_fun', 'techengage_load_more_fun');

function techengage_load_more_fun() {

	if( !empty($_POST['post_query_vars'])) {
		$args = json_decode( stripslashes( sanitize_text_field(wp_unslash($_POST['post_query_vars'])) ), true );
	}

	if( !empty($_POST['page'])) {
		$paged = sanitize_text_field( wp_unslash($_POST['page']));
		$next_page = $paged + 1 ;
	}
	else {
		die();
	}

	$args['paged'] = $next_page;
	$args['post_status'] = 'publish';

	query_posts( $args );

	// The Loop
	if ( have_posts() ) {

		while ( have_posts() ) {
				the_post();
				get_template_part('content','');
		}

	}

	wp_reset_query();

	die();

}



//禁止wordpress加载google字体
function coolwp_remove_open_sans_from_wp_core() {
wp_deregister_style( 'open-sans' );
wp_register_style( 'open-sans', false );
wp_enqueue_style('open-sans','');}
add_action( 'init', 'coolwp_remove_open_sans_from_wp_core' );

//添加编辑器快捷按钮
add_action('admin_print_scripts', 'my_quicktags');
function my_quicktags() {
    wp_enqueue_script(
        'my_quicktags',
        get_stylesheet_directory_uri().'/js/my_quicktags.js',
        array('quicktags')
    );
    };


//移除wp-head 多余代码
    remove_action( 'wp_head', 'feed_links', 2 ); //移除feed
    remove_action( 'wp_head', 'feed_links_extra', 3 ); //移除feed
    remove_action( 'wp_head', 'rsd_link' ); //移除离线编辑器开放接口
    remove_action( 'wp_head', 'wlwmanifest_link' );  //移除离线编辑器开放接口
    remove_action( 'wp_head', 'index_rel_link' );//去除本页唯一链接信息
    remove_action('wp_head', 'parent_post_rel_link', 10, 0 );//清除前后文信息
    remove_action('wp_head', 'start_post_rel_link', 10, 0 );//清除前后文信息
    remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0 );
    remove_action('publish_future_post','check_and_publish_future_post',10, 1 );
    remove_action( 'wp_head', 'noindex', 1 );
    remove_action( 'wp_head', 'wp_generator' ); //移除WordPress版本
    remove_action( 'wp_head', 'rel_canonical' );
    remove_action( 'wp_head', 'wp_shortlink_wp_head', 10, 0 );
    remove_action( 'template_redirect', 'wp_shortlink_header', 11, 0 );
    add_action('widgets_init', 'my_remove_recent_comments_style');
//wp-json链接、embeds功能
    add_filter('rest_enabled', '_return_false');
    add_filter('rest_jsonp_enabled', '_return_false');
    remove_action( 'wp_head', 'rest_output_link_wp_head', 10 );
    remove_action( 'wp_head', 'wp_oembed_add_discovery_links', 10 );
    function my_remove_recent_comments_style() {
    global $wp_widget_factory;
    remove_action('wp_head', array($wp_widget_factory->widgets['WP_Widget_Recent_Comments'] ,'recent_comments_style'));
    }

    /**禁止加载WP自带的jquery.js
    if ( !is_admin() ) {
    function my_init_method() {
    wp_deregister_script( 'jquery' ); // 取消原有的 jquery 定义
    }
    add_action('init', 'my_init_method');
    }
    wp_deregister_script( 'l10n' );
**/


//禁用embeds
        function disable_emojis() {
        remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
remove_action( 'admin_print_styles', 'print_emoji_styles' );
remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
add_filter( 'tiny_mce_plugins', 'disable_emojis_tinymce' );
}
add_action( 'init', 'disable_emojis' );




function disable_emojis_tinymce( $plugins ) {
if ( is_array( $plugins ) ) {
return array_diff( $plugins, array( 'wpemoji' ) );
} else {
return array();
}
}

function disable_embeds_init() {
global $wp;
$wp->public_query_vars = array_diff( $wp->public_query_vars, array( 'embed', ) );
remove_action( 'rest_api_init', 'wp_oembed_register_route' );
add_filter( 'embed_oembed_discover', '__return_false' );
remove_filter( 'oembed_dataparse', 'wp_filter_oembed_result', 10 );
remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
remove_action( 'wp_head', 'wp_oembed_add_host_js' );
add_filter( 'tiny_mce_plugins', 'disable_embeds_tiny_mce_plugin' );
add_filter( 'rewrite_rules_array', 'disable_embeds_rewrites' ); }
add_action( 'init', 'disable_embeds_init', 9999 );
function disable_embeds_tiny_mce_plugin( $plugins ) { return array_diff( $plugins, array( 'wpembed' ) ); }
function disable_embeds_rewrites( $rules ) { foreach ( $rules as $rule => $rewrite ) { if ( false !== strpos( $rewrite, 'embed=true' ) ) { unset( $rules[ $rule ] ); } }
return $rules; }
function disable_embeds_remove_rewrite_rules() { add_filter( 'rewrite_rules_array', 'disable_embeds_rewrites' ); flush_rewrite_rules(); }
register_activation_hook( __FILE__, 'disable_embeds_remove_rewrite_rules' );
function disable_embeds_flush_rewrite_rules() { remove_filter( 'rewrite_rules_array', 'disable_embeds_rewrites' ); flush_rewrite_rules(); }
register_deactivation_hook( __FILE__, 'disable_embeds_flush_rewrite_rules' );


function soneix_custom_excerpt_length( $length ) {
    return 200;
}
add_filter( 'excerpt_length', 'soneix_custom_excerpt_length', 999 );
