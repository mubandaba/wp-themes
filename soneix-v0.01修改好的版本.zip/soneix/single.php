<?php get_header(); ?>
<div class="clearfix"></div>
 <main id="content">
  <div class="container">
    <div class="row">
      <div class="<?php if( !is_active_sidebar('sidebar-1')) { echo "col-lg-12 col-md-12"; } else { echo "col-lg-9 col-md-9"; } ?>">
        <div class="single-content-container">
          <div class="row">
  		      <?php if(have_posts())
  		        {
  		      while(have_posts()) { the_post(); ?>
            <div class="col-lg-12">
              <div class="techengage-blog-post-box">
                   <article class="small">

                  <h1><a><?php the_title(); ?></a></h1>

                  <div class="techengage-blog-category post-meta-data">
                    <i class="fa fa-user meta-fa-icon-user"></i>
                    <a class="meta-user-des" href="<?php echo esc_url(get_author_posts_url( get_the_author_meta( 'ID' ) ));?>">
                      <?php the_author(); ?>
                    </a>
                    <?php $cat_list = get_the_category_list();
                      if(!empty($cat_list)) {
                    ?>
                    <i class="fa fa-folder meta-fa-icons"></i>
                    <a href="#">
                      <?php if(!empty($cat_list)) { ?>
                      <?php the_category(', '); ?>
                    </a>
                    <?php }} ?>
<i class="fa fa-calendar meta-fa-icons"></i><span class="meta-data-date"><?php echo get_the_date( 'Y-m-d' ); ?></span>
                    <i class="fa fa-eye" aria-hidden="true"></i><span class="meta-data-date"><?php post_views(' ', ' 次浏览'); ?></span>
                    <span class="meta-data-date"><?php edit_post_link(' 编辑', '  <i class="fa fa-pencil-square-o" aria-hidden="true"></i> ', ''); ?></span>
                  </div>
<div class="artext"><?php the_content(); ?></div>

<?php wp_link_pages( array( 'before' => '<div class="link single-page-break">' . __( 'Pages:', 'techengage' ), 'after' => '</div>' ) ); ?>
<div class=" col-lg-12 col-md-12 artend  bg-warning text-warning">
<ul>
<li>QQ群:<a target="_blank" href="//shang.qq.com/wpa/qunwpa?idkey=17e42310316937e3aab0d4e67f088ee61f6ec0a4abb38ab20b76feabc8a2c99b">253510359</a></li>
<li>建议:VPS商家层出不穷,根据需要购买,切莫剁剁剁!</li>
<li>评测:很多VPS虽已评测,但网络环境改变稳定性,速度也会随之改变.评测只能作为一般性参考.不负任何法律,道义责任.</li>
<li>申明:所有vps,域名,服务器优惠信息均来自网络公开内容,由于水平有限不免有谬误.请以官方为准.</li>
<ul>
</div>

                </article>
              </div>
            </div>
  		      <?php } ?>
            <div class="col-lg-12">
              <div class="media techengage-info-author-block"> <a href="<?php echo esc_url(get_author_posts_url( get_the_author_meta( 'ID' ) ));?>" class="techengage-author-pic"> <?php echo get_avatar( get_the_author_meta( 'ID') , 150); ?> </a>
                <div class="media-body">
      <!--相关文章开始-->
<div class="related artext">
<h3>相关文章:</h3>
<ul>
<?php
global $post, $wpdb;
$post_tags = wp_get_post_tags($post->ID);
if ($post_tags) {
    $tag_list = '';
    foreach ($post_tags as $tag) {
        // 获取标签列表
        $tag_list .= $tag->term_id.',';
    }
    $tag_list = substr($tag_list, 0, strlen($tag_list)-1);

    $related_posts = $wpdb->get_results("
        SELECT DISTINCT ID, post_title
        FROM {$wpdb->prefix}posts, {$wpdb->prefix}term_relationships, {$wpdb->prefix}term_taxonomy
        WHERE {$wpdb->prefix}term_taxonomy.term_taxonomy_id = {$wpdb->prefix}term_relationships.term_taxonomy_id
        AND ID = object_id
        AND taxonomy = 'post_tag'
        AND post_status = 'publish'
        AND post_type = 'post'
        AND term_id IN (" . $tag_list . ")
        AND ID != '" . $post->ID . "'
        ORDER BY RAND()
        LIMIT 5");
        // 以上代码中的 5 为限制只获取8篇相关文章
        // 通过修改数字 5，可修改你想要的文章数量

    if ( $related_posts ) {
        foreach ($related_posts as $related_post) {
?>
    <li><a href="<?php echo get_permalink($related_post->ID); ?>" rel="bookmark" title="<?php echo $related_post->post_title; ?>"><?php echo $related_post->post_title; ?></a></li>
<?php   }
    }
    else {
      echo '<li>暂无相关文章</li>';
    }
}
else {
  echo '<li>暂无相关文章</li>';
}
?>
</ul>
</div>
<!--相关文章结束-->
                  <div class="row">
                    <div class="col-lg-6">
                      <ul class="list-inline info-author-social">

                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
  		      <?php } ?>
           <?php comments_template('',true); ?>
          </div>
      </div>
      </div>
      <div class="col-lg-3 col-md-3">
      <?php get_sidebar(); ?>
      </div>
    </div>
    <!--/ Row end -->
  </div>
</main>
<?php get_footer(); ?>