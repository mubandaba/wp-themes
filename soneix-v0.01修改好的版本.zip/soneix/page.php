<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @package TechEngage
 */
get_header(); ?>
<main id="content">
    <div class="container">
      	<div class="row">
			<div class="<?php if( !is_active_sidebar('sidebar-1')) { echo "col-lg-12 col-md-12"; } else { echo "col-lg-9 col-md-9"; } ?>">
        		<div class="single-content-container">
					<div class="row">
						<div class="col-lg-12">
							<div class="page-content">
								<?php if( have_posts()) :  the_post(); ?>
								<h1><?php the_title(); ?></h1>
<div class="artext"><?php the_content(); ?></div>
<?php wp_link_pages( array( 'before' => '<div class="link single-page-break">' . __( 'Pages:', 'techengage' ), 'after' => '</div>' ) ); ?>
<div class=" col-lg-12 col-md-12 artend  bg-warning text-warning">
<ul>
<li>QQ群:<a target="_blank" href="//shang.qq.com/wpa/qunwpa?idkey=17e42310316937e3aab0d4e67f088ee61f6ec0a4abb38ab20b76feabc8a2c99b">253510359</a></li>
<li>建议:VPS商家层出不穷,根据需要购买,切莫剁剁剁!</li>
<li>评测:很多VPS虽已评测,但网络环境改变稳定性,速度也会随之改变.评测只能作为一般性参考.不负任何法律,道义责任.</li>
<li>申明:所有vps,域名,服务器优惠信息均来自网络公开内容,由于水平有限不免有谬误.请以官方为准.</li>
<ul>
</div>
								<?php wp_link_pages( array( 'before' => '<div class="link page-break-links">' . __( 'Pages:', 'techengage' ), 'after' => '</div>' ) ); ?>
								<?php endif; ?>
							</div>
							<?php comments_template( '', true ); // show comments ?>
						</div>
					</div>
				</div>
			</div>
			<!--Sidebar Area-->
			<aside class="col-md-3 col-lg-3">
				<?php get_sidebar(); ?>
			</aside>
			<!--Sidebar Area-->
		</div>
	</div>
</main>
<?php
get_footer();