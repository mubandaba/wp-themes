<footer>
  <div class="overlay">
  <!--Start techengage-footer-widget-area-->
  <?php if ( is_active_sidebar( 'footer_widget_area' ) ) { ?>
  <div class="techengage-footer-widget-area">
    <div class="container">
      <div class="row">
        <?php  dynamic_sidebar( 'footer_widget_area' ); ?>
      </div>
    </div>
  </div>
  <?php } ?>
  <!--End techengage-footer-widget-area-->
  <div class="techengage-footer-copyright">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-sm-12 copy-right-line">
  		    <p>&copy; <?php echo esc_html(date_i18n( 'Y' )).' ';bloginfo('name'); ?>
      		</p>
		    </div>
      </div>
    </div>
  </div>
  </div>
</footer>
</div>
<!--Scroll To Top-->
<a href="#" class="ti_scroll bounceInRight  animated"><i class="fa fa-angle-double-up"></i></a>
<!--/Scroll To Top-->
<?php wp_footer(); ?>
</body>
</html>