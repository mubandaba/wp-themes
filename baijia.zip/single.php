<?php get_header(); ?>
<section class="container-single">
	<div class="content-wrap">
    <div class="singleh">
	<div class="content">
		<?php while (have_posts()) : the_post(); ?>
	<h1 class="article-title"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h1><div class="article-infos">
    <div class="top-share">
<div class="bdsharebuttonbox" data-tag="share_1" style="float:right">
<a class="bds_more" data-cmd="more" style="display:none">分享到：</a>
<a href="#" class="bds_weixin bjweixin1" data-cmd="weixin"></a>
<a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a>
<a href="#" class="bds_renren" data-cmd="renren" title="分享到人人网"></a>
<a href="#" class="bds_douban" data-cmd="douban" title="分享到豆瓣网"></a>
<a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a>
<a class="bds_count" data-cmd="count" style="display:none"></a>
</div>
<div class="bdbsharecode bjcode1">
<i class="public-modal-btn-cancel-red closeweixin1"></i>
<em class="sharecode_o"></em>
</div>
</div>
<div class="article-info">
<a class="name" target="_blank" mon="name=bjarticle&pos=name"><?php the_author();?></a>
<span class="time"> <?php echo get_the_time('m月d日 G:H'); ?></span>
				<?php _moloader('mo_get_post_from', false); ?>
				<?php if( mo_get_post_from() ){ ?><span class="item"><?php echo mo_get_post_from(); ?></span><?php } ?>
				<?php $p_meta = _hui('post_plugin'); ?>
				<span class="item"><?php edit_post_link('[编辑]'); ?></span>
</div>
<div class="article-info">
<span class="type">  <?php if( $p_meta['tags'] ){ ?><?php the_tags('标签：',' ,  ',''); ?> <?php } ?></span>
</div>
</div>
      <?php if( _hui('post_p_indent_cc') ){?>  <div class="zhaoyao"><i class="i iquote"></i><?php the_excerpt()?></div><?php } ?>
        
		<article class="article-content">
			<?php _the_ads($name='ads_post_01', $class='asb-post asb-post-01') ?>
			<?php the_content(); ?>
		</article>
 
		<?php wp_link_pages('link_before=<span>&link_after=</span>&before=<div class="article-paging">&after=</div>&next_or_number=number'); ?>
		<?php endwhile; ?>
		
        
        <nav class="article-nav">
			<span class="article-nav-prev"><?php previous_post_link('上一篇 %link'); ?></span>
			<span class="article-nav-next"><?php next_post_link('%link 下一篇'); ?></span>
		</nav>
	
		<?php _the_ads($name='ads_post_02', $class='asb-post asb-post-02') ?>

        <?php include('related.php');?>
       
		<?php _the_ads($name='ads_post_03', $class='asb-post asb-post-03') ?>
		<?php comments_template('', true); ?>
	</div>
    </div>
	</div>
    <div class="mt10">
	
    		

 
	<?php get_sidebar() ?>
    </div>
</section>

<?php get_footer(); 

