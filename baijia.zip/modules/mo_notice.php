<?php 
/**
 * For site notice and user welcome
 */
if( is_home() && (_hui('site_notice_s')||_hui('user_on_notice_s')) ) { 
	$s_notice = _hui('site_notice_s');
	$s_user = _hui('user_page_s') && _hui('user_on_notice_s');

	_moloader('mo_get_user_page', false);
?>
<style>
.warps {
	width:330px;
	height:180px;
	margin-bottom:15px;
	padding:10px;
}
.contents {
	width:300px;
	height:160px;
	margin:0px auto;
	padding:30px 30px;
	background:rgba(38, 38, 38, 0.6)!important;
	filter:Alpha(opacity=60);
	background:#000;
}

.contents p {
	font-weight:bold;
	position:relative;
	color:#fff;
	font-size:18px;
	line-height:30px;
	text-align:center;
	margin-top:20px;
}
.contents{ text-align:center}
.siatime{ font-size:12px; color:#CCC}
</style>
</head><body>
<?php query_posts($query_string . 'tag='. stripslashes(_hui('site_widthc')).'&showposts=' . $limit=1)?>        
<?php while (have_posts()) : the_post(); ?>
<div class="warps" style="background:url(<?php echo post_thumbnail_src(); ?>) no-repeat left top; background-size:100%">
  <div class="contents"><a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title();?>">
    <p>
      <?php echo mb_strimwidth(get_the_title(), 0, 45, '…'); ?>
    </p>
    <span class="siatime"><?php echo get_the_time('m月d日 G:H'); ?></span>
    </a></div>
</div>
<?php endwhile;wp_reset_query();?>


			<?php if( $s_user ){ ?>
<div class="widget widget-tops" style="background-color:#262627; background-image:url(<?php echo _hui('user_src_bj'); ?>);background-size:100% ">
  <ul class="widget-navcontent" >
 
				<li class="item item-02<?php echo ($s_user && !$s_notice) ? ' active' : '' ?>">
<?php 
					if( is_user_logged_in() ){
						global $current_user; 
					?>
      <dl>
        <dt><?php echo _get_the_avatar($user_id=$current_user->ID, $user_email=$current_user->user_email, true); ?></dt>
        <dd><?php echo $current_user->display_name ?><span class="text-muted"><?php echo $current_user->user_email ?></span></dd>
      </dl>
      <ul>
        <li><a href="<?php echo mo_get_user_page() . '#posts/all' ?>">我的文章</a></li>
        <li><a href="<?php echo mo_get_user_page() . '#comments' ?>">我的评论</a></li>
        <li><a href="<?php echo mo_get_user_page() . '#info' ?>">修改资料</a></li>
        <li><a href="<?php echo mo_get_user_page() . '#password' ?>">修改密码</a></li>
      </ul>
      <?php }else{ ?>
      <h4 style=" color:#fff">需要登录才能进入会员中心</h4>
      <p> <a href="javascript:;" class="btn btn-primary signin-loader">立即登录</a> <a href="javascript:;" class="btn btn-default signup-loader">现在注册</a> </p>
					<?php } ?>
				</li>
			<?php } ?>
		</ul>
	</div>
<?php 
} 