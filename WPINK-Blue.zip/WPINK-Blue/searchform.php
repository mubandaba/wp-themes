<div class="search">
<form method="get" id="searchform" class="searchform" action="<?php bloginfo('url'); ?>/">
   <input class="searchInput" type="text" value="<?php the_search_query(); ?>" name="s" id="s"/>
   <input class="searchBtn" type="submit" id="searchsubmit" value="搜 索"/>
</form>
</div>