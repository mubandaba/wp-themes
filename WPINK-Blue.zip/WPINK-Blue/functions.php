<?php
if ( function_exists('register_sidebars') )
{
	register_sidebar(array(
		'name' => 'Topbar',
		'before_title' => '<h3>',
		'after_title' => '</h3>'
	));
	register_sidebar(array(
		'name' => 'Leftbar',
		'before_title' => '<h3>',
		'after_title' => '</h3>'
	));
	register_sidebar(array(
		'name' => 'Rightbar',
		'before_title' => '<h3>',
		'after_title' => '</h3>'
	));
}
//Thumbnail
if ( function_exists( 'add_theme_support' ) )
	add_theme_support( 'post-thumbnails' );

//First Post Image
function catch_that_image() {
  global $post, $posts;
  $first_img = '';
  ob_start();
  ob_end_clean();
  $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
  $first_img = $matches [1] [0];

  if(empty($first_img)){ //Defines a default image
  	$site_url = bloginfo('template_url');
    $first_img = "$site_url/images/no-thumb.jpg";
  }
  return $first_img;
}

// Custom Comment
function custom_comment($comment, $args, $depth) {
   $GLOBALS['comment'] = $comment; ?>
   <li <?php comment_class(); ?> id="li-comment-<?php comment_ID() ?>">
     <div id="comment-<?php comment_ID(); ?>">
         <div class="comment-author vcard">
				<?php echo get_avatar( $comment, $size = '28', $default = '<path_to_url>' ); ?>
                <div class="author_info">
					<?php printf(__('<cite class="fn">%s</cite>'), get_comment_author_link()) ?> <?php edit_comment_link(__('(Edit)'),'  ','') ?><br />
                    <em><?php printf(__('%1$s at %2$s'), get_comment_date('Y/m/d '),  get_comment_time(' H:i:s')) ?></em>
                </div>
                <div class="reply">
			   		<?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
              	</div>
          </div>
		  <?php if ($comment->comment_approved == '0') : ?>
             <em><?php _e('Your comment is awaiting moderation.') ?></em>
             <br />
          <?php endif; ?>

      		<?php comment_text() ?>
     </div>
<?php } ?>
<?php
$themename = "WPINK";

function wpyou_add_option() {

	global $themename;

	//create new top-level menu under Presentation
	add_theme_page($themename." 主题设置", "".$themename." 主题设置", 'administrator', basename(__FILE__), 'wpyou_form');

	//call register settings function
	add_action( 'admin_init', 'register_mysettings' );
}

function register_mysettings() {

	//register our settings
	register_setting( 'wpyou-settings', 'wpyou_feed_url');
	register_setting( 'wpyou-settings', 'wpyou_feedsky_username');
	register_setting( 'wpyou-settings', 'wpyou_bachground');
	register_setting( 'wpyou-settings', 'wpyou_site_analytics');
	register_setting( 'wpyou-settings', 'wpyou_ad_468x60');
	register_setting( 'wpyou-settings', 'wpyou_ad_sidebar');
	register_setting( 'wpyou-settings', 'wpyou_ad_posttop');
	register_setting( 'wpyou-settings', 'wpyou_ad_postbottom');
	register_setting( 'wpyou-settings', 'wpyou_ad_sponsor_336X280');
	register_setting( 'wpyou-settings', 'wpyou_bookmark');
}

function wpyou_form() {

	global $themename;

?>
<!-- Options Form begin -->
<div class="wrap">
	<div id="icon-options-general" class="icon32"><br/></div>
	<h2><?php echo $themename; ?>主题设置</h2>
    
	<form method="post" action="options.php">
		<?php settings_fields('wpyou-settings'); ?>
		<table class="form-table">
			<tr valign="top">
            	<td><h3>基本设置</h3></td>
        	</tr>
            <tr valign="top">
                <th scope="row"><label>Feed 订阅地址<span class="description"></span></label></th>
                <td>
                    <input class="regular-text" style="width:35em;" type="text" value="<?php echo get_option('wpyou_feed_url'); ?>" name="wpyou_feed_url"/>
                    <span class="description">留空则输出默认Feed地址</span>
                </td>
        	</tr>
			<tr valign="top">
                <th scope="row"><label>FeedSky 用户名<span class="description"></span></label></th>
                <td>
                    <input class="regular-text" type="text" value="<?php echo get_option('wpyou_feedsky_username'); ?>" name="wpyou_feedsky_username"/>
                    <span class="description">如果不是FeedSky用户, 可以<a href="http://www.feedsky.com/" target="_blank"><strong>点击这里申请</strong></a> FeedSky用户名和统计功能</span>
                </td>
        	</tr>
            <tr valign="top">
                <th scope="row"><label>背景图片设置<span class="description"></span></label></th>
                <td>
                    <input class="regular-text" style="width:35em;" type="text" value="<?php echo get_option('wpyou_bachground'); ?>" name="wpyou_bachground"/>
                    <span class="description">填写背景图片的完整路径</span>
                </td>
        	</tr>
            <tr valign="top">
                <th scope="row"><label>统计代码<span class="description">(网站流量统计)</span></label></th>
                <td>
                    <textarea style="width:35em; height:10em;" name="wpyou_site_analytics"><?php echo get_option('wpyou_site_analytics'); ?></textarea>
                    <br />
                    <span class="description">添加Google Analytics或者其他服务商提供的网站流量统计代码 (显示在网站底部)</span>
                </td>
        	</tr>
            <tr valign="top">
                <th scope="row"><label>分享收藏书签<span class="description"></span></label></th>
                <td>
                    <textarea style="width:35em; height:10em;" name="wpyou_bookmark"><?php echo get_option('wpyou_bookmark'); ?></textarea>
                    <br />
                    <span class="description">添加社会化网络书签功能(比如: <a href="http://digg.com/" target="_blank">Digg</a>、<a href="http://delicious.com/" target="_blank">Del.icio.us</a>、<a href="http://xianguo.com/" target="_blank">鲜果推荐</a>等)</span>
                </td>
                
        	</tr>
            <tr valign="top">
            	<td><h3>广告设置</h3></td>
        	</tr>
			<tr valign="top">
                <th scope="row"><label>顶部广告<span class="description">(468X60)</span></label></th>
                <td>
                    <textarea style="width:35em; height:10em;" name="wpyou_ad_468x60"><?php echo get_option('wpyou_ad_468x60'); ?></textarea>
                    <br />
                    <span class="description">广告尺寸不大于 468X60 px</span>
                </td>
        	</tr>
            <tr valign="top">
                <th scope="row"><label>侧边栏广告<span class="description">(侧边栏顶部)</span></label></th>
                <td>
                    <textarea style="width:35em; height:10em;" name="wpyou_ad_sidebar"><?php echo get_option('wpyou_ad_sidebar'); ?></textarea>
                    <br />
                    <span class="description">广告宽度不大于 310 px (显示在侧边栏顶部, 支持多个广告代码)</span>
                </td>
        	</tr>
            <tr valign="top">
                <th scope="row"><label>正文广告1<span class="description">(正文前)</span></label></th>
                <td>
                    <textarea style="width:35em; height:10em;" name="wpyou_ad_posttop"><?php echo get_option('wpyou_ad_posttop'); ?></textarea>
                    <br />
                    <span class="description">广告宽度不大于 600 px (显示在正文开始前, 支持多个广告代码)</span>
                </td>
        	</tr>
            <tr valign="top">
                <th scope="row"><label>正文广告2<span class="description">(正文后)</span></label></th>
                <td>
                    <textarea style="width:35em; height:10em;" name="wpyou_ad_postbottom"><?php echo get_option('wpyou_ad_postbottom'); ?></textarea>
                    <br />
                    <span class="description">广告宽度不大于 600 px (显示在正文结束后, 支持多个广告代码)</span>
                </td>
        	</tr>
            <tr valign="top">
                <th scope="row"><label>赞助商广告<span class="description">(336X280)</span></label></th>
                <td>
                    <textarea style="width:35em; height:10em;" name="wpyou_ad_sponsor_336X280"><?php echo get_option('wpyou_ad_sponsor_336X280'); ?></textarea>
                    <br />
                    <span class="description">广告尺寸不大于 336X280 px (显示在正文页面的"随机文章/赞助商广告", 不设置，则显示随机文章)</span>
                </td>
        	</tr>
		</table>

		<p class="submit">
		<input type="submit" name="save" id="button-primary" class="button-primary" value="<?php _e('Save Changes') ?>" />
		</p>
        
	</form>
</div>
<!-- Options Form begin -->

<?php } 
	// create custom plugin settings menu
	add_action('admin_menu', 'wpyou_add_option');
?>