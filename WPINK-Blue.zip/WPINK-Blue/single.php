<?php get_header(); ?>
<!-- Article begin -->
<div class="article">
	<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
			<div class="post single">
                    <h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
                    <div class="pmeta">
						时间: <?php the_time('Y-m-d'); ?> / 分类: <?php the_category(', ') ?> / 浏览次数: <?php if(function_exists('the_views')) { the_views(); } ?> / <a href="#comments" class="anchorLink"><?php comments_number('0','1','%'); ?>个评论</a> <a href="#respond" class="anchorLink">发表评论</a> <?php edit_post_link('编辑本文', '', ''); ?>
                    </div>
                    <div class="clear"></div>
                    <div class="pcontent">
                    	<!-- Google Adsense begin -->
                        <div class="ad_single">
                            <?php if (get_option('wpyou_ad_posttop')) { ?>
								<?php echo get_option('wpyou_ad_posttop'); ?>
                            <?php } else { ?>
                                <script type="text/javascript"><!--
								google_ad_client = "pub-2034762497287079";
								/* 336x280, 创建于 07-12-16 */
								google_ad_slot = "0500222370";
								google_ad_width = 336;
								google_ad_height = 280;
								//-->
								</script>
								<script type="text/javascript"
								src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
								</script>
								<?php } ?>
                        </div>
                        <!-- Google Adsense end -->
                        <div class="clear"></div>
                        <?php the_content(); ?>
                        <div class="clear"></div>
                        <!-- Google Adsense begin -->
                        <div class="ad_single">
                            <?php if (get_option('wpyou_ad_postbottom')) { ?>
								<?php echo get_option('wpyou_ad_postbottom'); ?>
                            <?php } else { ?>
                                <script type="text/javascript"><!--
								google_ad_client = "pub-2034762497287079";
								/* 336x280, 创建于 07-12-16 */
								google_ad_slot = "0500222370";
								google_ad_width = 336;
								google_ad_height = 280;
								//-->
								</script>
								<script type="text/javascript"
								src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
								</script>
							<?php } ?>
                        </div>
                        <!-- Google Adsense end -->
                    </div>
                <!-- Navigation begin -->
                <div class="page_navi pro_next">
                   <div class="pageleft"><?php previous_post_link('<strong>上一篇: </strong> %link') ?></div>
                   <div class="pageright"><?php next_post_link('<strong>下一篇: </strong> %link') ?></div>
                </div>
                <!-- Navigation end -->
           		<!-- Post Function begin -->
               <div class="postmeta">
                    <?php the_tags('<strong>标签:</strong> ', ', ', ''); ?> <br />
                    <strong>本文链接:</strong> <a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a><br />
                    <strong>版权所有:</strong> <a href="<?php echo get_settings('home'); ?>"><?php bloginfo('name'); ?></a>, 转载请注明本文出处。
               </div>
               <!-- Post Function end -->
               <div class="clear"></div>
               <!-- Social Bookmark begin -->
               <div class="snsmedia">
               		<div class="bookmark">
                    		<?php if (get_option('wpyou_bookmark')) { ?>
								<?php echo get_option('wpyou_bookmark'); ?>
							<?php } ?>
                                <!-- 订阅更新 -->
                                <a href="<?php if (get_option('wpyou_feed_url')) { ?><?php echo get_option('wpyou_feed_url'); ?><?php } ?>" title="订阅更新" target="_blank"><img src="<?php bloginfo('template_directory');?>/images/rss.gif" alt="订阅" title="订阅" /></a>
                    </div>
               </div>
               <!-- Social Bookmark end -->
               <!-- Related Content begin -->
               <div class="related">
                    <div class="related_post">
                        <?php if( function_exists('wp_related_posts')) { wp_related_posts(); } ?>
                    </div>  
                    <div class="related_txt">
                    	<?php if (get_option('wpyou_ad_sponsor_336X280')) { ?>
                        	<h3><?php _e('赞助商广告'); ?></h3>
							<?php echo get_option('wpyou_ad_sponsor_336X280'); ?>
                        <?php } else { ?>
                            <h3><?php _e('随机文章'); ?></h3>
                            <?php wp_reset_query(); ?>
                             <?php query_posts("showposts=10&caller_get_posts=1&order=DESC&orderby=rand"); ?>
                             	<ul>
                                	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                                    	<li><a href="<?php the_permalink() ?>" title="<?php the_title() ?>"><?php the_title() ?></a></li>
                                    <?php endwhile ?>
                                    <?php endif ?>
                                </ul>
						<?php } ?>
                        <?php wp_reset_query(); ?>
                    </div> 
                </div>
            	<!-- Related Content end -->
                <!-- Post Comment begin -->
                <div class="post_comment">
                	<?php comments_template(); ?>
                </div>
                <!-- Post Comment end -->
           </div>
		<?php endwhile; ?>
	<?php else : ?>
            <div class="post single">
            	<h2>抱歉,没有找到合适的文章.</h2>
            	<p>请您<a href="<?php echo get_settings('home'); ?>">返回首页</a>或在搜索中查找您所需的信息.带来不便,敬请谅解!</p>
            </div>
    <?php endif; ?>
</div>
<!-- Article end -->
<!-- Sidebar begin -->
	<?php include (TEMPLATEPATH . '/sidebar.php'); ?>
<!-- Sidebar end -->
<?php get_footer(); ?>