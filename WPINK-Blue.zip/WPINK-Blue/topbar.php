<div class="topbar">
	<div class="sidead">
    	<?php if (get_option('wpyou_ad_sidebar')) { ?>
        	<?php echo get_option('wpyou_ad_sidebar'); ?>
        <?php } else { ?>
        	<a target="_blank" href="http://www.wpyou.com/" title="WordPress主题定制设计服务"><img src="<?php bloginfo('template_url'); ?>/images/wpyou.gif" width="310" height="124"/></a>
        <?php } ?>
	</div>
    <div class="clear"></div>
		<ul>
        	<li>
                <h3><?php _e('最新文章'); ?></h3>
                    <?php query_posts("showposts=10&caller_get_posts=1&orderby=date&order=DESC"); ?>
                        <ul>
                        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                             <li><a href="<?php the_permalink() ?>" title="<?php the_title() ?>"><?php the_title() ?></a></li>
                        <?php endwhile; endif; ?>
                        </ul>
           	</li>
        	<li>
            <h3><?php _e('最热文章'); ?></h3>
            <?php
			  function filter_where($where = '') {
				//posts in the last 30 days
				$where .= " AND post_date > '" . date('Y-m-d', strtotime('-30 days')) . "'";
				return $where;
			  }
			add_filter('posts_where', 'filter_where');
			query_posts("showposts=10&v_sortby=views&caller_get_posts=1&orderby=date&order=desc") ?>
                    <ul>
                        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                            <li><a href="<?php the_permalink() ?>" title="<?php the_title() ?>"><?php the_title() ?></a></li>
                        <?php endwhile; endif; ?><?php wp_reset_query(); ?>
                    </ul>
            </li>
            
			<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(1) ) : else : ?>
            
        	<?php endif; ?>
        </ul>
</div>
<div class="clear"></div>