<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" />
<!-- leave this for stats -->
<title><?php if ( is_home() ) { ?><? bloginfo('name'); ?> - <?php bloginfo('description'); ?><?php } ?>
<?php if ( is_search() ) { ?>搜索到“<?php echo $s; ?>” - <? bloginfo('name'); ?><?php } ?>
<?php if ( is_404() ) { ?>404页面 - <? bloginfo('name'); ?><?php } ?>
<?php if ( is_author() ) { ?>文章列表 - <? bloginfo('name'); ?><?php } ?>
<?php if ( is_single() ) { ?><?php wp_title(''); ?> - <? bloginfo('name'); ?><?php } ?>
<?php if ( is_page() ) { ?><?php wp_title(''); ?> - <? bloginfo('name'); ?><?php } ?>
<?php if ( is_category() ) { ?><?php single_cat_title(); ?> - <? bloginfo('name'); ?><?php } ?>
<?php if ( is_month() ) { ?><?php the_time('F, Y'); ?> - <? bloginfo('name'); ?><?php } ?>
<?php if ( is_day() ) { ?><?php the_time('F j, Y'); ?> - <? bloginfo('name'); ?><?php } ?>
</title>
<link rel="shortcut icon" href="/favicon.ico" />
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<script type="text/javascript" src="<?php bloginfo('template_directory');?>/js/jquery.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory');?>/js/jquery.lazyload.js"></script>
<!--[if lte IE 6]>
<script type="text/javascript" src="<?php bloginfo('template_directory');?>/js/DD_belatedPNG.js"></script>
<script>
  DD_belatedPNG.fix('#png,.png');
</script>
<![endif]-->
<script type="text/javascript" charset="utf-8">
	// Navigation Menu
	$(function() {
		$("#dropmenu ul").css({display: "none"}); // Opera Fix
		$("#dropmenu li").hover(function(){
			$(this).find('ul:first').css({visibility: "visible",display: "none"}).slideDown("normal");
		},function(){
			$(this).find('ul:first').css({visibility: "hidden"});
		});
	});
	
	$(function() {
		$("#dropmenu a").addClass("png");
	});
	// Mouse Hover
	<?php if(is_home() || is_archive() || is_search()): ?>
	$(function() { 
		$(".post").mouseover(function(){
				$(this).css({ border:"1px solid #D8D8D8", background:"#F5FDFF"});
				$("h2 a:first",this).css({ display:"block", color:"#004364"});
			}).mouseout(function(){
				$(this).css({ border:"1px solid #E6E6E6", background:"#F5F6F7"});
				$("h2 a:first",this).css({ color:"#24282B"});
				});
		
		});
	<?php endif ?>
	// Delay Image
	$(function() {          
    	$(".post img").lazyload({
        	placeholder : "<?php bloginfo('template_url'); ?>/images/grey.gif",
            effect : "fadeIn"
          });
    	});
	
	//Slide to any anchor
	$(document).ready(function() {
	$("a.anchorLink").anchorAnimate()
	});
	
	jQuery.fn.anchorAnimate = function(settings) {
	
		settings = jQuery.extend({
			speed : 1100
		}, settings);	
		
		return this.each(function(){
			var caller = this
			$(caller).click(function (event) {	
				event.preventDefault()
				var locationHref = window.location.href
				var elementClick = $(caller).attr("href")
				
				var destination = $(elementClick).offset().top;
				$("html:not(:animated),body:not(:animated)").animate({ scrollTop: destination}, settings.speed, function() {
					window.location.hash = elementClick
				});
				return false;
			})
		})
	}
</script>
<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
<?php wp_head(); ?>
</head>
<body <?php if (get_option('wpyou_bachground')) { ?>
				style="background-image:url(<?php echo get_option('wpyou_bachground'); ?>);"
		<?php } else { ?>
				style="background-image:url(<?php bloginfo('template_url') ?>/images/bg.jpg);"
		<?php } ?>>
<!-- Header begin -->
<div id="header">
	<!-- SNS begin -->
	<div class="sns">
        <div class="rss">
			<?php if (get_option('wpyou_feed_url')) { ?>
				<a href="<?php echo get_option('wpyou_feed_url'); ?>" title="订阅本站" target="_blank" class="rssfeed">订阅本站</a>
			<?php } else { ?>
				<a href="<?php bloginfo('rss2_url'); ?>" title="订阅本站" target="_blank" class="rssfeed">订阅本站</a>
			<?php } ?>
			
            <?php if (get_option('wpyou_feedsky_username')) { ?>
				<img id="feedimage" src="http://www.feedsky.com/feed/<?php echo get_option('wpyou_feedsky_username'); ?>/sc/gif" alt="订阅统计"/>
			<?php } else { ?>
				<img id="feedimage" src="http://www.feedsky.com/feed/bbon/sc/gif" alt="订阅统计"/>
			<?php } ?>
        </div>
    </div>
    <!-- SNS end -->
    <!-- Header-inner begin -->
	<div class="head png">
    	<!-- Description PageMenu begin -->
        <div class="description_pagelist">
			<div class="description"><?php bloginfo('description'); ?></div>
            <ul class="pagelist">
                <?php wp_list_pages('title_li=&depth=1&sort_column=post_date&sort_order=DESC')?>
            </ul>
        </div>
        <!-- Description PageMenu end -->
        <!-- Logo Banner begin -->
        <div class="logo_banner">
			<h1 class="logo"><a href="<?php echo get_option('home'); ?>/" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a></h1>
        	<!-- Banner begin -->
            <div class="banner">
            	<?php if (get_option('wpyou_ad_468x60')) { ?>
                    <?php echo get_option('wpyou_ad_468x60'); ?>
                <?php } else { ?>
                    <script type="text/javascript"><!--
					google_ad_client = "pub-2034762497287079";
					/* 顶部Banner 468x60, 创建于 09-10-26 */
					google_ad_slot = "0063439127";
					google_ad_width = 468;
					google_ad_height = 60;
					//-->
					</script>
					<script type="text/javascript"
					src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
					</script>
                <?php } ?>
            </div>
            <!-- Banner end -->
        </div>
        <!-- Logo Banner end -->
        <!-- Main Navigation begin -->
        <ul id="dropmenu" class="navigation">
        	<li <?php if ( is_home()){ echo ' class="cat-item current-cat" '; } ?>><a href="<?php echo get_option('home'); ?>/" class="png"><span class="png">首页</span></a></li>
			<?php echo preg_replace('@\<li([^>]*)>\<a([^>]*)>(.*?)\<\/a>@i', '<li$1><a$2><span class="png">$3</span></a>', wp_list_categories('echo=0&orderby=id&title_li=&depth=2&hide_empty=0')); ?>
        </ul>
        <!-- Main Navigation end -->
    </div>
    <!-- Header-inner end -->
</div>
<!-- Header end -->
<!-- Breadcrumb begin -->
 	<?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
 	<div class="breadcrumb">
    	<div class="crumb">
		  <?php /* If this is a category archive */ if (is_home()) { ?>
                当前位置: <a href="<?php echo get_settings('home'); ?>"><?php bloginfo('name'); ?></a> > 首页
          <?php /* If this is a tag archive */ } elseif(is_category()) { ?>
                当前位置: <a href="<?php echo get_settings('home'); ?>"><?php bloginfo('name'); ?></a> > <?php the_category(' / ') ?>
          <?php /* If this is a search result */ } elseif (is_search()) { ?>
                当前位置: <a href="<?php echo get_settings('home'); ?>"><?php bloginfo('name'); ?></a> > <?php echo $s; ?>
          <?php /* If this is a tag archive */ } elseif(is_tag()) { ?>
                当前位置: <a href="<?php echo get_settings('home'); ?>"><?php bloginfo('name'); ?></a> > <?php single_tag_title(); ?>
          <?php /* If this is a daily archive */ } elseif (is_day()) { ?>
                当前位置: <a href="<?php echo get_settings('home'); ?>"><?php bloginfo('name'); ?></a> ><?php the_time('Y, F jS'); ?> 时间内的文章
          <?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
                当前位置: <a href="<?php echo get_settings('home'); ?>"><?php bloginfo('name'); ?></a> ><?php the_time('Y, F'); ?> 时间内的文章
          <?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
                当前位置: <a href="<?php echo get_settings('home'); ?>"><?php bloginfo('name'); ?></a> ><?php the_time('Y'); ?> 时间内的文章
          <?php /* If this is an author archive */ } elseif (is_author()) { ?>
                当前位置: <a href="<?php echo get_settings('home'); ?>"><?php bloginfo('name'); ?></a> > 作者文章
          <?php /* If this is a single page */ } elseif (is_single()) { ?>
                当前位置: <a href="<?php echo get_settings('home'); ?>"><?php bloginfo('name'); ?></a> > <?php the_category(', ') ?> > 文章正文
          <?php /* If this is a page */ } elseif (is_page()) { ?>
                当前位置: <a href="<?php echo get_settings('home'); ?>"><?php bloginfo('name'); ?></a> > <?php the_title(); ?>
          <?php /* If this is a 404 error page */ } elseif (is_404()) { ?>
                当前位置: <a href="<?php echo get_settings('home'); ?>"><?php bloginfo('name'); ?></a> > 404 错误
          <?php /* If this is a paged archive */ } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
                当前位置: <a href="<?php echo get_settings('home'); ?>"><?php bloginfo('name'); ?></a> > 存档
          <?php } ?>
		</div>
        <!-- Search Begin-->
            <?php include (TEMPLATEPATH . '/searchform.php'); ?>
      	<!-- Search end-->
    </div>
    <!-- Breadcrumb end -->
<!-- Content begin -->
<div id="content">