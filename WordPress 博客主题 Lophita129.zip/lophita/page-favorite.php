<?php
/*
Template Name: 收藏模板
*/
get_header(); 
?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<article class="post">
	<div class="entry-content favorite-page clearfix">
		<?php if($_COOKIE['lo_author']) {?>
		<div class="my-info">
			<?php echo get_avatar( $_COOKIE['lo_email'], $size = '90'); 
			echo '<p>'.$_COOKIE["lo_email"].'</p>';
			if($_COOKIE['lo_url']) echo '<p><a href="'.$_COOKIE["lo_url"].'">'.$_COOKIE["lo_url"].'</a></p>';
			?>
		</div>
		<?php } ?>
		<div class="my-favorite">
			<h3>我的收藏</h3>
		<?php
			$flag = 0;
			foreach($_COOKIE as $k => $id) {
				if(!(strpos($k, 'lo_love_')===false)) {
					$flag++;
					$post = get_post($id);
					echo '<p class="line1"><a href="'.$post->guid.'">'.$post->post_title.'</a></p>';
					echo '<p class="line2">'.__('Last Modified on ', 'Lophita').$post->post_modified.__(' with ', 'Lophita').
					$post->comment_count.' ';
					if($post->comment_count>1)
						echo __('Comments', 'Lophita').'</p>';
					else
						echo __('Comment', 'Lophita').'</p>';
				}
			}
			if($flag==0) {
				echo '<p>暂无收藏</p>';
			}
			?>
		</div>
		<div class="my-comment">
			<h3>我的评论</h3>
			<?php
			$flag = 0;
			foreach($_COOKIE as $k => $id) {
				if(!(strpos($k, 'lo_comment_')===false)) {
					$comment = get_comment($id);
					$post = get_post($comment->comment_post_ID);
					echo '<p class="line1">'.$comment->comment_content.'</p>';
					echo '<p class="line2">'.__('Comment in Post ', 'Lophita').'<a href="'.$post->guid.'">'. $post->post_title.'</a>'.__(' on ', 'Lophita').$comment->comment_date.'</p>';
				}
			}
			if($flag==0) {
				echo '';
			}
			?>
		</div>
	</div>
</article>

<?php endwhile; endif;?>

<?php get_footer(); ?>