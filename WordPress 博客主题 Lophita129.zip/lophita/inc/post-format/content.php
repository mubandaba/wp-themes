<?php
	$postnew ='';
	$diff=(time()-strtotime($post->post_date))/3600;
	if(is_sticky()){
		$postnew = 'sticky ';
	}elseif($diff<24){
		$postnew = 'new ';
	}elseif(get_post_meta($post->ID, 'views', true) > 1000){
		$postnew = 'hot ';
	}
?>

<article class="post fadeInUp <?php echo $postnew;?>" itemscope itemtype="http://schema.org/Article">
    <header class="entry-header">
		<h2 class="entry-name" itemprop="name headline">
			<a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a>
		</h2>
		<div class="post-love">
			<a href="javascript:;" data-id="<?php the_ID(); ?>" class="favorite post-love-link tooltip tip-right <?php if(isset($_COOKIE['lo_love_'.$post->ID])){ echo 'done" data-tooltip="取消收藏"';} else { echo '" data-tooltip="收藏"';}?> ><i class="iconfont icon-shoucang"></i></a></div>
    </header>

    <div class="entry-content clearfix" itemprop="description">
        <?php
		$pc=$post->post_content;
		$st=strip_tags(apply_filters('the_content',$pc));
		if(has_excerpt())
			the_excerpt();
		elseif(preg_match('/<!--more.*?-->/',$pc) || mb_strwidth($st)<500)
			the_content('');
		elseif(function_exists('mb_strimwidth'))
			echo'<p>'.mb_strimwidth($st,0,500,' ...').'</p>';
		else the_content('');
		?>
    </div>

    <footer class="entry-footer">
		<?php the_category(','); ?> · <time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>" itemprop="datePublished" pubdate><?php the_time('d,m,Y');?></time> · <?php lo_post_views(' views');?> · <?php comments_popup_link(__("no reply", 'Lophita'), __("1 reply", 'Lophita'), __('% replies', 'Lophita')); ?>
	</footer>
</article>