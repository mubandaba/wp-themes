<article class="post <?php if(is_single())?>" itemscope itemtype="http://schema.org/Article">
    <header class="entry-header">
		<h2 class="entry-name" itemprop="name headline">
			<a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a>
		</h2>
		<div class="post-love">
			<a href="javascript:;" data-id="<?php the_ID(); ?>" class="favorite post-love-link tooltip tip-right <?php if(isset($_COOKIE['lo_love_'.$post->ID])){ echo 'done" data-tooltip="取消收藏"';} else { echo '" data-tooltip="收藏"';}?> ><i class="iconfont icon-shoucang"></i></a></div>
    </header>
	<div class="post-meta">
		<span><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>" itemprop="datePublished" pubdate><?php the_time('d,m,Y');?></time></span> ·
		<span><?php the_category(','); ?></span> ·
		<span><?php lo_post_views(' views');?></span> ·
		<?php
			lo_rating($post->ID);
			if (is_user_logged_in() || current_user_can('edit_post')) {
				echo '· <span><a  href="'.get_bloginfo("home").'/wp-admin/post.php?post='.get_the_ID().'&amp;action=edit">编辑</a></span>';
			} ?>
	</div>
    <div class="entry-content clearfix" itemprop="description">
        <?php the_content(); ?>
		<?php  {  
wp_link_pages('before=<strong>&after=</strong>&next_or_number=next&previouspagelink=«&nextpagelink=&nbsp');  
wp_link_pages('before=<span class="wp-pagenavi">&after=</span>&next_or_number=number');  
//echo "&nbsp;";  
wp_link_pages('before=<strong>&after=</strong>&next_or_number=next&previouspagelink=&nbsp&nextpagelink=»');  
} ?>  
    </div>
	<footer class="entry-footer">
		<div class="post-tags" itemprop="keywords"><?php echo lo_get_tags( get_the_ID(), 'post_tag' );?></div>
	</footer>
</article>

<div class="post-author">
	<div class="post-author-avatar"><?php echo get_avatar( get_the_author_email(), $size = '90' , '' );?></div>
	<h6 class="post-author-name"><?php the_author(); ?></h6>
	<p class="post-author-bio"><?php the_author_description(); ?></p>
	<?php if( dopt('d_sns_open') ) {
			echo '<p class="post-author-social">';
			if( dopt('d_rss_b') ) echo '<a class="rss" href="'.dopt('d_rss').'"><i class="iconfont icon-dingyue"></i></a>';
			if( dopt('d_mail_b') ) echo '<a class="mail" href="'.dopt('d_mail').'"><i class="iconfont icon-mail"></i></a>';
			if( dopt('d_rss_sina_b') ) echo '<a class="weibo" href="'.dopt('d_rss_sina').'"><i class="iconfont icon-xinlangweibo"></i></a>';
			if( dopt('d_rss_twitter_b') ) echo '<a class="twitter" href="'.dopt('d_rss_twitter').'"><i class="iconfont icon-twitter"></i></a>';
			if( dopt('d_rss_google_b') ) echo '<a class="google" href="'.dopt('d_rss_google').'"><i class="iconfont icon-0394googleplus2"></i></a>';
			if( dopt('d_rss_facebook_b') ) echo '<a class="facebook" href="'.dopt('d_rss_facebook').'"><i class="iconfont icon-facebook"></i></a>';
			if( dopt('d_rss_github_b') ) echo '<a class="github" href="'.dopt('d_rss_github').'"><i class="iconfont icon-github"></i></a>';
			if( dopt('d_rss_tencent_b') ) echo '<a class="tweibo" href="'.dopt('d_rss_tencent').'"><i class="iconfont icon-tengxunweibo"></i></a>';
			if( dopt('d_rss_linkedin_b') ) echo '<a class="linkedin" href="'.dopt('d_rss_linkedin').'"><i class="iconfont icon-0457linkedin"></i></a>';
			echo '<a class="weixin" href="javascript:;"><i class="iconfont icon-pengyouquan"></i></a>';
			echo '<img class="qrcode" src="http://qr.liantu.com/api.php?w=200text=';
			global $wp; echo home_url(add_query_arg(array(),$wp->request));
			
			echo '"/></p>';
		}
		?>
</div>

<?php comments_template('', true); ?>