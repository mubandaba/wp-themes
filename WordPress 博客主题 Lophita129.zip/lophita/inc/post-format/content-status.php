<article class="status">
	<div class="author-avatar"><?php echo get_avatar( get_the_author_email(), $size = '80' , '' );?></div>
	<div class="quote">
        <a rel="bookmark" href="<?php the_permalink(); ?>"><?php the_content(); ?></a>
    </div>
</article>