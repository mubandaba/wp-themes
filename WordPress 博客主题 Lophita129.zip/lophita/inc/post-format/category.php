<article class="post lo-archive" itemscope itemtype="http://schema.org/Article">
    <header class="entry-header">
		<h2 class="entry-name" itemprop="name headline">
			<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
		</h2>
    </header>

    <div class="entry-content clearfix" itemprop="description">
        <?php
		$pc=$post->post_content;
		$str = apply_filters('the_content',$pc);
		$str = preg_replace( "@<script(.*?)</script>@is", "", $str ); 
		$str = preg_replace( "@<iframe(.*?)</iframe>@is", "", $str ); 
		$str = preg_replace( "@<style(.*?)</style>@is", "", $str );	
		$st=strip_tags($str);
		if( function_exists('mb_strimwidth') )
			echo'<p>'.mb_strimwidth($st,0,300,' ...').'</p>';
		?>
    </div>
</article>