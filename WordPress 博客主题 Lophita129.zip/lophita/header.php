<!DOCTYPE html>
<html lang="zh-CN" itemscope="itemscope" itemtype="http://schema.org/WebPage">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="initial-scale=1.0,user-scalable=no,minimal-ui" />
	<meta http-equiv="Cache-Control" content="no-transform" />
	<meta http-equiv="Cache-Control" content="no-siteapp" />
    <title>
	<?php
	if(is_front_page() || is_home()) { 
		bloginfo('name');
		echo ' | '.get_bloginfo( 'description', 'display' );
	} else if(is_single() || is_page()) {
		wp_title('|', true, 'right'); bloginfo('name');
	} else if(is_category()) {
		single_cat_title('', true);
		echo ' | ';
		bloginfo('name');
	} else if(is_search()) {
		printf(__('Search Result: %1$', 'Lophita' ), wp_specialchars($s, 1));
		echo ' | ';
		bloginfo('name');
	} else if(is_tag()) {
		single_tag_title('', true);
		echo ' | ';
		bloginfo('name');
	} else if(is_date()) {
		_e('Archives by Date', 'Lophita');
	} else {
		bloginfo('name');
		echo ' | '.get_bloginfo( 'description', 'display' );
	}
	?></title>
	<?php if( dopt('d_headcode_b') != '' ) echo dopt('d_headcode');?>
	<?php wp_head(); ?>
</head>
<body <?php body_class();?>>
	<div id="wrap">
		<div id="header">
			<div class="bannar">
				<span class="color-block color1"></span>
				<span class="color-block color2"></span>
				<span class="color-block color3"></span>
				<span class="color-block color4"></span>
			</div>
			<div class="header-wrap clearfix">
				<h1 class="site-title left"><a href="<?php bloginfo('url'); ?>"><?php bloginfo('name')?></a></h1>
				<div id="mobile-menu"><i class="iconfont icon-diantileimu"></i></div>
				<?php 
					if(function_exists('wp_nav_menu')) {
						wp_nav_menu(array( 'theme_location' => 'header-menu','container' => 'ul', 'menu_class' => 'nav right')); 
					}
				?>
			</div>
			<div class="loading-bar"></div>
		</div>
		<div id="container" class="clearfix">
			<div id="content">
