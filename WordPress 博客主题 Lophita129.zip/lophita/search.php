<?php get_header(); ?>

<?php if( have_posts() ){  ?>

<div class="archive-meta">
	<h3 class="title-meta"><?php echo $s; ?></h3>
	<div class="desc-meta"><p><?php _e('Search Result', 'Lophita' );?></p></div>
</div>

<?php 
	while ( have_posts() ){
			the_post(); 
			get_template_part( 'inc/post-format/category', get_post_format() );
		}
	} else {
?>
<div class="archive-meta">
	<h3 class="title-meta"><?php echo $s; ?></h3>
	<div class="desc-meta"><p><?php _e('Apologies, but no results were found.', 'Lophita')?></p></div>
</div>
<?php } ?>
<?php lo_pagenavi();?>
<?php get_footer(); ?>