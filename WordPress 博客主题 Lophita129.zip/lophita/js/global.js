~function(b,a){var c=function(e,d){a.setup({url:d.swf,debugMode:false});this.index=0;this.url=d.url;this.nonce=d.nonce;this.IE6=!-[1,]&&!window.XMLHttpRequest;this.single=d.single;this.lyric=null;this.offset={};this.mark=null;this.lyricH=300;this.line=27;this.isMobile="createTouch" in document&&!("onmousemove" in document)||/(iPhone|iPad|iPod)/i.test(navigator.userAgent);this.getDOM(b(e)).getAttr().init()};c.prototype={init:function(){var d=this.attr,e=this.DOM;e.time.text("00:00");e.title.text("Loading...");e.author.text("Loading...");if(d.lyric&&this.isMobile){e.lyricsbtn.hide()}if(!d.xiami){this.localAction()}else{(d.source=="xiami")?this.xiamiAction():this.neteaseAction()}},neteaseAction:function(){var d=this.attr.type,f=this.attr.xiami,e=this;b.ajax({url:this.url,type:"get",headers:{nonce:this.nonce},data:{action:"wpplayer",type:d,id:f}}).done(function(g){if(g.status&&g.data.trackList){e.data=g.data.trackList;e.createList().createSound().addEvent()}})},xiamiAction:function(){var e=this.getXiamiType(this.attr.type),f=this.attr.xiami,g=this,d="http://www.xiami.com/song/playlist/id/"+f+"/type/"+e+"/cat/json?callback=?";b.getJSON(d,function(j){if(j.status&&j.data.trackList){for(var h=0,k=j.data.trackList.length;h<k;h++){j.data.trackList[h].location=g.getXiamiLocation(j.data.trackList[h].location)}g.data=j.data.trackList;g.createList().createSound().addEvent()}else{g.getSinaApi()}}).fail(function(){g.getSinaApi()})},getSinaApi:function(){var d=typeof this.attr.type=="undefined"?"song":this.attr.type,e=this.attr.xiami,f=this;b.getJSON("http://wpplayer.sinaapp.com/?callback=?",{act:d,id:e},function(g){if(g.code>0&&g.data.length){f.data=g.data;f.createList().createSound().addEvent()}})},localAction:function(){if(typeof this.attr.address==="undefined"){return false}var d={title:this.attr.title,artist:this.attr.author,location:this.attr.address,pic:this.attr.thumb};this.data=[d];this.createList().createSound().addEvent()},createList:function(){var f=0,e="",g=this.DOM,j=this.data,d=j.length;for(;f<d;f++){var h=f%2?"odd":"";e+=c.template.replace("{i}",f).replace("{class}",h).replace("{author}",j[f].artist).replace("{serial}",f+1).replace("{title}",j[f].title)}b(e).appendTo(g.list.children("ul")).first().addClass("current");return this},createSound:function(h){var i=this,d=(typeof h==="undefined")?0:h,g=this.data[d],e=this.DOM,f=(this.attr.autoplay=="1"&&!this.isMobile)?true:false;e.title.text(g.title);e.author.text(g.artist);e.thumb.find("img").attr("src",g.pic);a.onready(function(){if(typeof i.sound==="object"){i.sound.destruct()}i.timeReady=i.isMobile?true:false;i.sound=a.createSound({url:g.location,onload:function(){i.timeReady=true},onplay:function(){i.setPlay()},onresume:function(){i.setPlay()},onpause:function(){i.setStop()},onfinish:function(){i.nextSound()},whileplaying:function(){var m,o,k,n,j=(this.position/this.duration)*100,l=j>100?"100%":j.toFixed(5)+"%";if(i.timeReady){n="-";m=Math.floor((this.duration-this.position)/1000);o=i.formatNumber(Math.floor(m/60));k=i.formatNumber(Math.floor(m%60))}else{n="";o="00";k="00"}e.playbar.width(l);e.time.text(n+o+":"+k);if(i.attr.lyric&&i.lyric&&!i.isMobile){i.setLyric(this.position)}},whileloading:function(){var j=this.bytesTotal?(this.bytesLoaded/this.bytesTotal)*100:100;e.seekbar.width(j+"%")}});i.soundEvent();if(i.attr.lyric&&!i.isMobile){i.getLyric()}if(typeof h!=="undefined"||f){i.sound.play()}});return this},createLyric:function(w){this.emptyLyric();var k=0,e=[],o=w.split("\n"),n=o.length,u=this.DOM,f=/\[(\d+:\d+.?\d+)\]/g,d=/[^\[(\d+):(\d+.?\d+)\]\s*].+/g,m="";for(;k<n;k++){var l=b.trim(o[k]).match(f);if(b.isArray(l)){var p=b.trim(o[k]).match(d);for(var h=0;h<l.length;h++){var s=l[h].replace("[","").replace("]","").split(":"),g=(s[0]*60)+Math.floor(s[1]);e.push({time:g,lyric:b.isArray(p)?p[0]:"&nbsp;"})}}}if(!e.length){this.noLyric();return false}k=0;n=e.length;for(;k<n;k++){for(var h=k;h<n;h++){if(e[k].time>e[h].time){var r=e[k];e[k]=e[h];e[h]=r}}}this.lyric={};for(k=0;k<n;k++){m+="<li>"+e[k].lyric+"</li>";this.lyric[e[k].time]=k}u["lyricList"]=b(m).appendTo(u.lyrics.children("ul"));var o=u.lyrics.children("ul").height(),v=Math.floor(this.lyricH/2),q=o-v;this.offset={min:Math.floor(v/this.line),max:Math.floor(q/this.line)}},getLyric:function(){this.noLyric(this.attr.xiami?"\u6b63\u5728\u52a0\u8f7d\u6b4c\u8bcd...":"\u6682\u65e0\u6b4c\u8bcd");if(!this.attr.xiami){return false}var f=this,d=this.url+"?action=wpplayerGetLrc&type="+this.attr.source+"&id="+this.data[this.index].song_id,e=this.attr.source=="xiami"?this.data[this.index].lyric_url:"";b.ajax({url:d,type:"post",headers:{nonce:this.nonce},data:{lyric:e}}).done(function(g){(g.status&&g.lyric)?f.createLyric(g.lyric):f.noLyric()}).fail(function(){f.noLyric()})},setLyric:function(i){var f=this.DOM,h=this.offset,g=Math.floor(i/1000),e=this.lyric&&this.lyric[g],d=0;if(typeof e!=="undefined"&&f.lyricList&&this.mark!=e){if(e>=h.min){d=e-h.min}if(e>=h.max){d=h.max-h.min}f.lyricList.removeClass("current").eq(e).addClass("current");
f.lyrics.children("ul").css("margin-top",-d*this.line);this.mark=e}},emptyLyric:function(){var d=this.DOM;this.lyric=null;d.lyrics.children("ul").css("margin-top",0).html("")},noLyric:function(f){var d=this.DOM,e=typeof f==="undefined"?"\u6682\u65e0\u6b4c\u8bcd":f;this.lyric=null;d.lyrics.children("ul").html("<li>"+e+"</li>")},addEvent:function(){var h=this.DOM,i=this,f=this.isMobile?"touchend":"click",e,d;h.listbtn.on(f,function(){var j=b(this).hasClass("wp-player-open");h.lyrics.children("ul").stop(true,true).hide();b(this)[j?"removeClass":"addClass"]("wp-player-open");h.list.show()[j?"removeClass":"addClass"]("wp-player-list-hide")});if(this.attr.lyric){h.lyricsbtn.on(f,function(){h.listbtn.addClass("wp-player-open");h.list.hide();h.lyrics.children("ul").stop(true,true).fadeIn()})}var g=function(m){var j=typeof m==="undefined"?b(this):b(m).parents("li"),l=parseInt(j.attr("data-index"),10),k=j.hasClass("current")&&i.sound.playState>0;(l<0||l>i.data.length-1)?i.index=0:i.index=l;if(k&&!i.sound.paused){i.sound.pause()}else{if(k&&i.sound.paused){i.sound.resume()}else{i.reset().setList().createSound(i.index)}}};if(!this.isMobile){h.list.on("click","li",function(){g.call(this)})}else{h.list[0].addEventListener("touchstart",function(k){var l=k.target.nodeName;if(l==="A"||l==="SPAN"){var j=k.touches[0];e=j.clientX;d=j.clientY}},false);h.list[0].addEventListener("touchend",function(l){var n=l.target.nodeName;if(n==="A"||n==="SPAN"){var k=l.changedTouches[0],j=k.clientX,m=k.clientY;if(Math.abs(e-j)<6&&Math.abs(d-m)<6){g(l.target);e=null;d=null}}},false)}return this},soundEvent:function(){var e=this.DOM,f=this,d=this.isMobile?"touchend":"click";if(!this.isMobile){e.seekbar.off().on(d,function(g){f.seekbar(g)})}e.play.off().on(d,function(){f.play()});e.stop.off().on(d,function(){f.stop()});if(this.data.length>2){e.previous.off().on(d,function(){f.prevSound()});e.next.off().on(d,function(){f.nextSound()})}return this},seekbar:function(g){var f=this.DOM,e=g.offsetX?g.offsetX:(g.clientX-f.progress.offset().left).toFixed(0);var d=(e/f.progress.width())*this.sound.duration;if(d<0){d=0}if(d>this.sound.duration){d=this.sound.duration}this.sound.setPosition(d);f.lyricList&&f.lyricList.removeClass("current")},play:function(){this.sound[this.sound.playState<1?"play":"resume"]()},stop:function(){this.sound.pause()},prevSound:function(){var d=0;if(--this.index<d){this.index=this.data.length-1}this.reset().setList().createSound(this.index)},nextSound:function(){var d=this.data.length-1;if(++this.index>d){this.index=0}this.reset().setList().createSound(this.index)},setPlay:function(){var d=this.DOM;d.playing.stop(true,true)[(this.IE6||this.isMobile)?"show":"fadeIn"]();d.play.hide();d.stop.show();return this},setStop:function(){var d=this.DOM;d.playing.stop(true,true)[(this.IE6||this.isMobile)?"hide":"fadeOut"]();d.play.show();d.stop.hide();return this},reset:function(){var d=this.DOM;this.setStop();d.seekbar.width(0);d.playbar.width(0);return this},setList:function(){var d=this.DOM;d.list.find("li").removeClass("current").eq(this.index).addClass("current");return this},getDOM:function(d){var h=d[0].getElementsByTagName("*"),g={};g["wrap"]=d;for(var f=0;f<h.length;f++){if(h[f].className.indexOf("wp-player")>-1){var e=h[f].className.replace("wp-player","").replace(/-/g,"");g[e]=b(h[f])}}this.DOM=g;return this},formatNumber:function(d){return d.toString().length<2?"0"+d:d},getAttr:function(){var f=this.DOM,e=f.wrap.attr("data-lyric"),d=typeof e==="undefined"?false:(e=="open"?true:false);this.attr={source:f.wrap.attr("data-source"),type:f.wrap.attr("data-type"),xiami:f.wrap.attr("data-xiami"),title:f.wrap.attr("data-title"),author:f.wrap.attr("data-author"),address:f.wrap.attr("data-address"),thumb:f.wrap.attr("data-thumb"),autoplay:f.wrap.attr("data-autoplay"),lyric:d};return this},getXiamiType:function(e){var d;switch(e){case"song":d=0;break;case"album":d=1;break;case"artist":d=2;break;case"collect":d=3;break;default:d=0}return d},getXiamiLocation:function(o){try{var g=parseInt(o.charAt(0)),f=o.substring(1),d=Math.floor(f.length/g),u=f.length%g,t=[],s=0,r="",q="";for(;s<u;++s){t[s]=f.substr((d+1)*s,(d+1))}for(;s<g;++s){t[s]=f.substr(d*(s-u)+(d+1)*u,d)}for(var l=0,m=t[0].length;l<m;++l){for(var k=0,h=t.length;k<h;++k){r+=t[k].charAt(l)}}r=decodeURIComponent(r);for(var l=0,p=r.length;l<p;++l){q+=r.charAt(l)==="^"?"0":r.charAt(l)}return q}catch(n){return false}}};c.template='<li data-index="{i}" class="{class}"><a href="javascript:void(0);"><span class="wp-player-list-author">{author}</span><span class="wp-player-list-order">{serial}</span><span class="wp-player-list-title">{title}</span></a></li>';b.fn.WPPlayer=function(d){return this.each(function(){new c(this,d)})};return b}(jQuery,soundManager);jQuery('[data-wp-player="wp-player"]').WPPlayer(wp_player_params);

var ajaxcontent="content";var ajaxsearch_class="searchform";var ajaxignore_string=new String("#, /wp-, .pdf, .zip, .rar, /share");var ajaxignore=ajaxignore_string.split(", ");var ajaxtrack_analytics=false;var ajaxscroll_top=true;var ajaxloading_code='<div class="spinner"><div class="rect1"></div><div class="rect2"></div><div class="rect3"></div><div class="rect4"></div><div class="rect5"></div></div>';var ajaxloading_error_code='<div class="box"><p style="padding:20px;">出错啦，请刷新当前页面。</p></div>';var ajaxreloadDocumentReady=false;var ajaxisLoad=false;var ajaxstarted=false;var ajaxsearchPath=null;var ajaxua=jQuery.browser;jQuery(document).ready(function(){ajaxloadPageInit("")});window.onpopstate=function(b){if(ajaxstarted===true&&ajaxcheck_ignore(document.location.toString())==true){ajaxloadPage(document.location.toString(),1)}};function ajaxloadPageInit(b){jQuery(b+"a").click(function(f){if(this.href.indexOf(ajax.home)>=0&&this.href.indexOf(ajax.home)<20&&ajaxcheck_ignore(this.href)==true){f.preventDefault();this.blur();var a=this.title||this.name||"";var e=this.rel||false;ajaxloadPage(this.href)}});jQuery("."+ajaxsearch_class).each(function(a){if(jQuery(this).attr("action")){ajaxsearchPath=jQuery(this).attr("action");jQuery(this).submit(function(){submitSearch(jQuery(this).serialize());return false})}})}function ajaxloadPage(g,h,f){if(!ajaxisLoad){if(ajaxscroll_top==true){jQuery("html,body").animate({scrollTop:0},1500)}ajaxisLoad=true;ajaxstarted=true;nohttp=g.replace("http://","").replace("https://","");firstsla=nohttp.indexOf("/");pathpos=g.indexOf(nohttp);path=g.substring(pathpos+firstsla);if(h!=1){if(typeof window.history.pushState=="function"){var e={foo:1000+Math.random()*1001};history.pushState(e,"ajax page loaded...",path)}}if(!jQuery("#"+ajaxcontent)){}jQuery("#"+ajaxcontent).append(ajaxloading_code);showLoadingBar();jQuery("#"+ajaxcontent).fadeTo("slow",0.6,function(){jQuery("#"+ajaxcontent).fadeIn("slow",function(){jQuery.ajax({type:"GET",url:g,data:f,cache:false,dataType:"html",success:function(b){ajaxisLoad=false;datax=b.split("<title>");titlesx=b.split("</title>");if(datax.length==2||titlesx.length==2){b=b.split("<title>")[1];titles=b.split("</title>")[0];jQuery(document).attr("title",(jQuery("<div/>").html(titles).text()))}if(ajaxtrack_analytics==true){if(typeof _gaq!="undefined"){if(typeof f=="undefined"){f=""}else{f="?"+f}_gaq.push(["_trackPageview",path+f])}}b=b.split('id="'+ajaxcontent+'"')[1];b=b.substring(b.indexOf(">")+1);var a=1;var c="";while(a>0){temp=b.split("</div>")[0];i=0;pos=temp.indexOf("<div");while(pos!=-1){i++;pos=temp.indexOf("<div",pos+1)}a=a+i-1;c=c+b.split("</div>")[0]+"</div>";b=b.substring(b.indexOf("</div>")+6)}document.getElementById(ajaxcontent).innerHTML=c;jQuery("#"+ajaxcontent).css("position","absolute");jQuery("#"+ajaxcontent).css("left","20000px");jQuery("#"+ajaxcontent).show();ajaxloadPageInit("#"+ajaxcontent+" ");if(ajaxreloadDocumentReady==true){jQuery(document).trigger("ready")}ajaxreload_code();jQuery("#"+ajaxcontent).hide();jQuery("#"+ajaxcontent).css("position","");jQuery("#"+ajaxcontent).css("left","");jQuery("#"+ajaxcontent).fadeTo("slow",1,function(){});hideLoadingBar();},error:function(c,a,b){ajaxisLoad=false;document.title="Error loading requested page!";document.getElementById(ajaxcontent).innerHTML=ajaxloading_error_code}})})})}}function submitSearch(b){if(!ajaxisLoad){ajaxloadPage(ajaxsearchPath,0,b)}}function ajaxcheck_ignore(d){for(var c in ajaxignore){if(d.indexOf(ajaxignore[c])>=0){return false}}return true}function ajaxreload_code(){initSlim();var a=$("input.rating");a.rating();a.on("rating.change",function(d,e,c){var f=e;var g=jQuery(this).data("post_id");var b={action:"lo_rate",um_id:g,um_score:f};jQuery.ajax({url:ajax.ajax_url,type:"POST",data:b,dataType:"json",success:function(j){if(j.status==200){var h=new Object();h=j.data;a.rating("update",h.average);a.rating("refresh",{disabled:true});jQuery(".rate-info").html(h.average+"分 / "+h.raters+"票")}else{a.rating("update",f)}}})})};
(function(j){var i=j(window),h,p,c=-1,d,w,z,g,H,x,o,l=!window.XMLHttpRequest,s=[],F=document.documentElement,q={},m=new Image(),n=new Image(),D,E,t,b,k,C;j(function(){j("body").append(j([D=j('<div id="lbOverlay" />').click(r)[0],E=j('<div id="lbCenter" />')[0]]).css("display","none"));t=j('<div id="lbImage" />').appendTo(E).append(b=j('<div style="position: relative;" />').append([k=j('<a id="lbPrevLink" href="#" />').click(e)[0],C=j('<a id="lbNextLink" href="#" />').click(v)[0]])[0])[0];});j.slimbox=function(K,J,I){h=j.extend({loop:false,overlayOpacity:0.95,overlayFadeDuration:400,resizeDuration:400,resizeEasing:"swing",initialWidth:250,initialHeight:250,imageFadeDuration:400,closeKeys:[27,88,67],previousKeys:[37,80],nextKeys:[39,78]},I);if(typeof K=="string"){K=[[K,J]];J=0;}H=i.scrollTop()+(i.height()/2);x=h.initialWidth;o=h.initialHeight;j(E).css({top:Math.max(0,H-(o/2)),width:x,height:o,marginLeft:-x/2}).show();g=l||(D.currentStyle&&(D.currentStyle.position!="fixed"));if(g){D.style.position="absolute";}j(D).css("opacity",h.overlayOpacity).fadeIn(h.overlayFadeDuration);G();u(1);p=K;h.loop=h.loop&&(p.length>1);return A(J);};j.fn.slimbox=function(I,L,K){L=L||function(M){return[M.href,M.title];};K=K||function(){return true;};var J=this;return J.unbind("click").click(function(){var O=this,Q=0,P,M=0,N;P=j.grep(J,function(S,R){return K.call(O,S,R);});for(N=P.length;M<N;++M){if(P[M]==O){Q=M;}P[M]=L(P[M],M);}return j.slimbox(P,Q,I);});};function G(){var J=i.scrollLeft(),I=i.width();j([E]).css("left",J+(I/2));if(g){j(D).css({left:J,top:i.scrollTop(),width:I,height:i.height()});}}function u(I){if(I){j("object").add(l?"select":"embed").each(function(K,L){s[K]=[L,L.style.visibility];L.style.visibility="hidden";});}else{j.each(s,function(K,L){L[0].style.visibility=L[1];});s=[];}var J=I?"bind":"unbind";i[J]("scroll resize",G);j(document)[J]("keydown",B);}function B(K){var J=K.which,I=j.inArray;return(I(J,h.closeKeys)>=0)?r():(I(J,h.nextKeys)>=0)?v():(I(J,h.previousKeys)>=0)?e():null;}function e(){return A(w);}function v(){return A(z);}function A(I){if(I>=0){c=I;d=p[c][0];w=(c||(h.loop?p.length:0))-1;z=((c+1)%p.length)||(h.loop?0:-1);y();E.className="lbLoading";q=new Image();q.onload=f;q.src=d;}return false;}function f(){E.className="";j(t).css({backgroundImage:"url("+d+")",visibility:"hidden",display:"","background-size":"100%"});var L=q.width,I=q.height,J=i.width(),K=i.height();if(L>=J||I>=K){if(J>=K){j(b).width(K*0.8*L/I);j([b,k,C]).height(K*0.8);}else{j(b).width(J*0.8);j([b,k,C]).height(J*0.8*I/L);}}else{j(b).width(q.width);j([b,k,C]).height(q.height);}if(w>=0){m.src=p[w][0];}if(z>=0){n.src=p[z][0];}x=t.offsetWidth;o=t.offsetHeight;var M=Math.max(0,H-(o/2));if(E.offsetHeight!=o){j(E).animate({height:o,top:M},h.resizeDuration,h.resizeEasing);}if(E.offsetWidth!=x){j(E).animate({width:x,marginLeft:-x/2},h.resizeDuration,h.resizeEasing);}j(E).queue(function(){j(t).css({display:"none",visibility:"",opacity:""}).fadeIn(h.imageFadeDuration,a);});}function a(){if(w>=0){j(k).show();}if(z>=0){j(C).show();}}function y(){q.onload=null;q.src=m.src=n.src=d;j([E,t]).stop(true);j([k,C,t]).hide();}function r(){if(c>=0){y();c=w=z=-1;j(E).hide();j(D).stop().fadeOut(h.overlayFadeDuration,u);}return false;}})(jQuery);jQuery(document).ready(initSlim());function initSlim(){jQuery(".slimbox").slimbox();}

(function($){var DEFAULT_MIN=0;var DEFAULT_MAX=5;var DEFAULT_STEP=0.5;var isTouchCapable="ontouchstart" in window||(window.DocumentTouch&&document instanceof window.DocumentTouch);var isEmpty=function(value,trim){return typeof value==="undefined"||value===null||value===undefined||value==[]||value===""||trim&&$.trim(value)===""};var validateAttr=function($input,vattr,options){var chk=isEmpty($input.data(vattr))?$input.attr(vattr):$input.data(vattr);if(chk){return chk}return options[vattr]};var getDecimalPlaces=function(num){var match=(""+num).match(/(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/);if(!match){return 0}return Math.max(0,(match[1]?match[1].length:0)-(match[2]?+match[2]:0))};var applyPrecision=function(val,precision){return parseFloat(val.toFixed(precision))};var Rating=function(element,options){this.$element=$(element);this.init(options)};Rating.prototype={constructor:Rating,_parseAttr:function(vattr,options){var self=this,$input=self.$element;if($input.attr("type")==="range"||$input.attr("type")==="number"){var val=validateAttr($input,vattr,options);var chk=DEFAULT_STEP;if(vattr==="min"){chk=DEFAULT_MIN}else{if(vattr==="max"){chk=DEFAULT_MAX}else{if(vattr==="step"){chk=DEFAULT_STEP}}}var finall=isEmpty(val)?chk:val;return parseFloat(finall)}return parseFloat(options[vattr])},listen:function(){var self=this;self.initTouch();self.$rating.on("click",function(e){if(self.inactive){return}var w=e.pageX-self.$rating.offset().left;self.setStars(w);self.$element.trigger("change");self.$element.trigger("rating.change",[self.$element.val(),self.$caption.html()]);self.starClicked=true});self.$rating.on("mousemove",function(e){if(!self.hoverEnabled||self.inactive){return}self.starClicked=false;var pos=e.pageX-self.$rating.offset().left,out=self.calculate(pos);self.toggleHover(out);self.$element.trigger("rating.hover",[out.val,out.caption,"stars"])});self.$rating.on("mouseleave",function(e){if(!self.hoverEnabled||self.inactive||self.starClicked){return}var out=self.cache;self.toggleHover(out);self.$element.trigger("rating.hoverleave",["stars"])});self.$clear.on("mousemove",function(e){if(!self.hoverEnabled||self.inactive||!self.hoverOnClear){return}self.clearClicked=false;var caption='<span class="'+self.clearCaptionClass+'">'+self.clearCaption+"</span>",val=self.clearValue,width=self.getWidthFromValue(val),out;out={caption:caption,width:width,val:val};self.toggleHover(out);self.$element.trigger("rating.hover",[val,caption,"clear"])});self.$clear.on("mouseleave",function(e){if(!self.hoverEnabled||self.inactive||self.clearClicked||!self.hoverOnClear){return}var out=self.cache;self.toggleHover(out);self.$element.trigger("rating.hoverleave",["clear"])});self.$clear.on("click",function(e){if(!self.inactive){self.clear();self.clearClicked=true}});$(self.$element[0].form).on("reset",function(e){if(!self.inactive){self.reset()}})},destroy:function(){var self=this,$el=self.$element;if(!isEmpty(self.$container)){self.$container.before($el).remove()}$.removeData($el.get(0));$el.off("rating").removeClass("hide")},create:function(){var options=arguments.length>0?arguments[0]:{},$el=self.$element;self.destroy();$el.rating(options)},setTouch:function(e,update){var self=this;if(!isTouchCapable||self.inactive){return}var ev=e.originalEvent,touches=ev.touches.length>0?ev.touches:ev.changedTouches,pos=touches[0].pageX-self.$rating.offset().left;if(update===true){self.setStars(pos);self.$element.trigger("change");self.$element.trigger("rating.change",[self.$element.val(),self.$caption.html()]);self.starClicked=true}else{var out=self.calculate(pos),caption=out.val<=self.clearValue?self.fetchCaption(self.clearValue):out.caption,w=self.getWidthFromValue(self.clearValue),width=out.val<=self.clearValue?(self.rtl?(100-w)+"%":w+"%"):out.width;self.$caption.html(caption);self.$stars.css("width",width)}},initTouch:function(){var self=this;self.$rating.on("touchstart",function(e){self.setTouch(e,false)});self.$rating.on("touchmove",function(e){self.setTouch(e,false)});self.$rating.on("touchend",function(e){self.setTouch(e,true)})},initSlider:function(options){var self=this;if(isEmpty(self.$element.val())){self.$element.val(0)}self.initialValue=self.$element.val();self.min=(typeof options.min!=="undefined")?options.min:self._parseAttr("min",options);self.max=(typeof options.max!=="undefined")?options.max:self._parseAttr("max",options);self.step=(typeof options.step!=="undefined")?options.step:self._parseAttr("step",options);if(isNaN(self.min)||isEmpty(self.min)){self.min=DEFAULT_MIN}if(isNaN(self.max)||isEmpty(self.max)){self.max=DEFAULT_MAX}if(isNaN(self.step)||isEmpty(self.step)||self.step==0){self.step=DEFAULT_STEP}self.diff=self.max-self.min},init:function(options){var self=this;self.options=options;self.hoverEnabled=options.hoverEnabled;self.hoverChangeCaption=options.hoverChangeCaption;self.hoverChangeStars=options.hoverChangeStars;self.hoverOnClear=options.hoverOnClear;self.starClicked=false;self.clearClicked=false;self.initSlider(options);self.checkDisabled();
$element=self.$element;self.containerClass=options.containerClass;self.glyphicon=options.glyphicon;var defaultStar="\u2605";self.symbol=isEmpty(options.symbol)?defaultStar:options.symbol;self.rtl=options.rtl||self.$element.attr("dir");if(self.rtl){self.$element.attr("dir","rtl")}self.showClear=options.showClear;self.showCaption=options.showCaption;self.size=options.size;self.stars=options.stars;self.defaultCaption=options.defaultCaption;self.starCaptions=options.starCaptions;self.starCaptionClasses=options.starCaptionClasses;self.clearButton=options.clearButton;self.clearButtonTitle=options.clearButtonTitle;self.clearButtonBaseClass=!isEmpty(options.clearButtonBaseClass)?options.clearButtonBaseClass:"clear-rating";self.clearButtonActiveClass=!isEmpty(options.clearButtonActiveClass)?options.clearButtonActiveClass:"clear-rating-active";self.clearCaption=options.clearCaption;self.clearCaptionClass=options.clearCaptionClass;self.clearValue=isEmpty(options.clearValue)?self.min:options.clearValue;self.$element.removeClass("form-control").addClass("form-control");self.$clearElement=isEmpty(options.clearElement)?null:$(options.clearElement);self.$captionElement=isEmpty(options.captionElement)?null:$(options.captionElement);if(typeof self.$rating=="undefined"&&typeof self.$container=="undefined"){self.$rating=$(document.createElement("div")).html('<div class="rating-stars"></div>');self.$container=$(document.createElement("div"));self.$container.before(self.$rating);self.$container.append(self.$rating);self.$element.before(self.$container).appendTo(self.$rating)}self.$stars=self.$rating.find(".rating-stars");self.generateRating();self.$clear=!isEmpty(self.$clearElement)?self.$clearElement:self.$container.find("."+self.clearButtonBaseClass);self.$caption=!isEmpty(self.$captionElement)?self.$captionElement:self.$container.find(".caption");self.setStars();self.$element.removeClass("hide").addClass("hide");self.listen();if(self.showClear){self.$clear.attr({"class":self.getClearClass()})}var starVal=self.$element.val(),starWidth=self.getWidthFromValue(starVal);self.cache={caption:self.$caption.html(),width:(self.rtl?(100-starWidth):starWidth)+"%",val:starVal};self.$element.removeClass("rating-loading")},checkDisabled:function(){var self=this;self.disabled=validateAttr(self.$element,"disabled",self.options);self.readonly=validateAttr(self.$element,"readonly",self.options);self.inactive=(self.disabled||self.readonly)},getClearClass:function(){return this.clearButtonBaseClass+" "+((this.inactive)?"":this.clearButtonActiveClass)},generateRating:function(){var self=this,clear=self.renderClear(),caption=self.renderCaption(),css=(self.rtl)?"rating-container-rtl":"rating-container",stars=self.getStars();css+=" rating-uni";self.$rating.attr("class",css);self.$rating.attr("data-content",stars);self.$stars.attr("data-content",stars);var css=self.rtl?"star-rating-rtl":"star-rating";self.$container.attr("class",css+" rating-"+self.size);if(self.inactive){self.$container.removeClass("rating-active").addClass("rating-disabled")}else{self.$container.removeClass("rating-disabled").addClass("rating-active")}if(typeof self.$caption=="undefined"&&typeof self.$clear=="undefined"){if(self.rtl){self.$container.prepend(caption).append(clear)}else{self.$container.prepend(clear).append(caption)}}if(!isEmpty(self.containerClass)){self.$container.removeClass(self.containerClass).addClass(self.containerClass)}},getStars:function(){var self=this,numStars=self.stars,stars="";for(var i=1;i<=numStars;i++){stars+=self.symbol}return stars},renderClear:function(){return""},renderCaption:function(){return""},fetchCaption:function(rating){var self=this;var val=parseFloat(rating),css,cap;if(typeof(self.starCaptionClasses)=="function"){css=isEmpty(self.starCaptionClasses(val))?self.clearCaptionClass:self.starCaptionClasses(val)}else{css=isEmpty(self.starCaptionClasses[val])?self.clearCaptionClass:self.starCaptionClasses[val]}if(typeof(self.starCaptions)=="function"){var cap=isEmpty(self.starCaptions(val))?self.defaultCaption.replace(/\{rating\}/g,val):self.starCaptions(val)}else{var cap=isEmpty(self.starCaptions[val])?self.defaultCaption.replace(/\{rating\}/g,val):self.starCaptions[val]}var caption=(val==self.clearValue)?self.clearCaption:cap;return'<span class="'+css+'">'+caption+"</span>"},getWidthFromValue:function(val){var self=this,min=self.min,max=self.max,step=self.step;if(val<=min||min==max){return 0}if(val>=max){return 100}return(val-min)*100/(max-min)},getValueFromPosition:function(pos){var self=this,precision=getDecimalPlaces(self.step),val,factor,maxWidth=self.$rating.width();factor=(self.diff*pos)/(maxWidth*self.step);factor=self.rtl?Math.floor(factor):Math.ceil(factor);val=applyPrecision(parseFloat(self.min+factor*self.step),precision);val=Math.max(Math.min(val,self.max),self.min);return self.rtl?(self.max-val):val},toggleHover:function(out){var self=this;if(self.hoverChangeCaption){var caption=out.val<=self.clearValue?self.fetchCaption(self.clearValue):out.caption;
self.$caption.html(caption)}if(self.hoverChangeStars){var w=self.getWidthFromValue(self.clearValue),width=out.val<=self.clearValue?(self.rtl?(100-w)+"%":w+"%"):out.width;self.$stars.css("width",width)}},calculate:function(pos){var self=this,defaultVal=isEmpty(self.$element.val())?0:self.$element.val(),val=arguments.length?self.getValueFromPosition(pos):defaultVal,caption=self.fetchCaption(val),width=self.getWidthFromValue(val);if(self.rtl){width=100-width}width+="%";return{caption:caption,width:width,val:val}},setStars:function(pos){var self=this,out=arguments.length?self.calculate(pos):self.calculate();self.$element.val(out.val);self.$stars.css("width",out.width);self.$caption.html(out.caption);self.cache=out},clear:function(){var self=this;var title='<span class="'+self.clearCaptionClass+'">'+self.clearCaption+"</span>";self.$stars.removeClass("rated");if(!self.inactive){self.$caption.html(title)}self.$element.val(self.clearValue);self.setStars();self.$element.trigger("rating.clear")},reset:function(){var self=this;self.$element.val(self.initialValue);self.setStars();self.$element.trigger("rating.reset")},update:function(val){var self=this;if(!arguments.length){return}self.$element.val(val);self.setStars()},refresh:function(options){var self=this;if(!arguments.length){return}self.$rating.off("rating");self.$clear.off();self.init($.extend(self.options,options));self.showClear?self.$clear.show():self.$clear.hide();self.showCaption?self.$caption.show():self.$caption.hide();self.$element.trigger("rating.refresh")}};$.fn.rating=function(option){var args=Array.apply(null,arguments);args.shift();return this.each(function(){var $this=$(this),data=$this.data("rating"),options=typeof option==="object"&&option;if(!data){$this.data("rating",(data=new Rating(this,$.extend({},$.fn.rating.defaults,options,$(this).data()))))}if(typeof option==="string"){data[option].apply(data,args)}})};$.fn.rating.defaults={stars:5,glyphicon:false,symbol:null,disabled:false,readonly:false,rtl:false,size:"md",showClear:true,showCaption:true,defaultCaption:"{rating} Stars",starCaptions:{0.5:"Half Star",1:"One Star",1.5:"One & Half Star",2:"Two Stars",2.5:"Two & Half Stars",3:"Three Stars",3.5:"Three & Half Stars",4:"Four Stars",4.5:"Four & Half Stars",5:"Five Stars"},starCaptionClasses:{0.5:"label label-danger",1:"label label-danger",1.5:"label label-warning",2:"label label-warning",2.5:"label label-info",3:"label label-info",3.5:"label label-primary",4:"label label-primary",4.5:"label label-success",5:"label label-success"},clearButton:'<i class="glyphicon glyphicon-minus-sign"></i>',clearButtonTitle:"Clear",clearButtonBaseClass:"clear-rating",clearButtonActiveClass:"clear-rating-active",clearCaption:"Not Rated",clearCaptionClass:"label label-default",clearValue:null,captionElement:null,clearElement:null,containerClass:null,hoverEnabled:true,hoverChangeCaption:true,hoverChangeStars:true,hoverOnClear:true};$("input.rating").addClass("rating-loading");$(document).ready(function(){var $input=$("input.rating"),count=Object.keys($input).length;if(count>0){$input.rating();$("input.rating").on("rating.change",function(event,value,caption){var score=value;var id=jQuery(this).data("post_id");var ajax_data={action:"lo_rate",um_id:id,um_score:score};jQuery.ajax({url:ajax.ajax_url,type:"POST",data:ajax_data,dataType:"json",success:function(data){if(data.status==200){var item=new Object();item=data.data;$input.rating("update",item.average);$input.rating("refresh",{disabled:true});jQuery(".rate-info").html(item.average+"分 / "+item.raters+"票")}else{$input.rating("update",score)}}})})}})}(jQuery));


jQuery.fn.postLike = function() {
	if (jQuery(this).hasClass('done')) {
		jQuery(this).removeClass('done');
		jQuery(this).attr('data-tooltip','收藏');
		var id = jQuery(this).data("id");
		var ajax_data = {
			action: "lo_post_not_love",
			um_id: id
		};
		jQuery.post(ajax.ajax_url, ajax_data,
		function(data) {
		});
		return false;
	} else {
		jQuery(this).addClass('done');
		jQuery(this).attr('data-tooltip','取消收藏');
		var id = jQuery(this).data("id");
		var ajax_data = {
			action: "lo_post_love",
			um_id: id
		};
		jQuery.post(ajax.ajax_url, ajax_data,
		function(data) {
		});
		return false;
	}
};
jQuery(document).on("click", ".favorite",function(){jQuery(this).postLike()});

$.fn.typing = function(n){
	var options = {
		speed : 100,
		range : 0,
		repeat : true,
		flashback : true,
		flicker : false
	}
	$.extend(options,n);
	var _this = $(this);
	var str = $(this).text().split(''); 
	var index = 0;
	var direction = 1; 
	$(str).each(function(i,k){
		str[i] = (str[i-1] ? str[i-1] : '') + str[i];
	});
	_this.css('border-right','1px solid #000');
	setTimeout(init,options.speed);
	function init(){
		_this.text(str[index]);
		if(index >= (str.length-1) && options.repeat){
			if(options.flashback){
				direction = -1;
			}else{
				index = 0;
			}
			if(options.flicker){
				_this.delay(200).fadeOut(1).delay(400).fadeIn(1).delay(200).fadeOut(1).delay(400).fadeIn(1);
			}
			setTimeout(init,2000);
		}else if( index >= (str.length-1) && !options.repeat ){
			if(options.flicker){
			_this.delay(200).fadeOut(1).delay(400).fadeIn(1).delay(200).fadeOut(1).delay(400).fadeIn(1);
			}
			_this.css('border-right','');
		}else if(index < 0 ){
			index = 0;
			direction = 1;
			setTimeout(init,Math.random()*options.range + options.speed);
		}else{
			setTimeout(init,Math.random()*options.range + options.speed);
		}
		index += direction;
	}
};
 
$('#header .desc span').typing({
	range : 200,
	repeat : true
});

jQuery(document).ready(function($) {
	var $commentform = $('#commentform'),
	txt1 = '<div id="loading"><img src="' + ajax.gif + '">正在提交, 请稍候...</div>',
	txt2 = '<div id="error">#</div>',
	txt3 = '">提交成功',
	edt1 = ', 刷新页面之前可以<a rel="nofollow" href="#edit" onclick=\'return addComment.moveForm("',
	edt2 = ')\'>再编辑</a>',
	cancel_edit = '取消编辑',
	edit,
	num = 1,
	$comments = $('#comments-title span'),
	$cancel = $('#cancel-comment-reply-link'),
	cancel_text = $cancel.text(),
	$submit = $('#commentform #submit');
	$submit.attr('disabled', false),
	$body = (window.opera) ? (document.compatMode == "CSS1Compat" ? $('html') : $('body')) : $('html,body'),
	comm_array = [];
	comm_array.push('');
	$('#comment').after(txt1 + txt2);
	$('#loading').hide();
	$('#error').hide();
	$(document).on("submit", "#commentform",
	function() {
		if (edit) $('#comment').after('<input type="text" name="edit_id" id="edit_id" value="' + edit + '" style="display:none;" />');
		editcode();
		$submit.attr('disabled', true).fadeTo('slow', 0.5);
		$('#loading').slideDown();
		showLoadingBar();
		$.ajax({
			url: ajax.ajax_url,
			data: $(this).serialize() + "&action=ajax_comment",
			type: $(this).attr('method'),
			error: function(request) {
				$('#loading').hide();
				hideLoadingBar();
				$("#error").slideDown().html(request.responseText);
				setTimeout(function() {
					$submit.attr('disabled', false).fadeTo('slow', 1);
					$('#error').slideUp();
				},
				3000);
			},
			success: function(data) {
				if ($(".reply-to-read").length > 0) {
					var ajax_data = {
						action: "ajax_post_content",
						id: $("#comment_post_ID").attr("value"),
					};
					$.post(ajax.ajax_url, ajax_data,
					function(data) {
						$(".entry-content").html(data);
					});
				}
				
				$('#loading').hide();
				hideLoadingBar();
				comm_array.push($('#comment').val());
				$('textarea').each(function() {
					this.value = ''
				});
				var t = addComment,
				cancel = t.I('cancel-comment-reply-link'),
				temp = t.I('wp-temp-form-div'),
				respond = t.I(t.respondId),
				post = t.I('comment_post_ID').value,
				parent = t.I('comment_parent').value;
				if (!edit && $comments.length) {
					n = parseInt($comments.text().match(/\d+/));
					$comments.text($comments.text().replace(n, n + 1));
				}
				new_htm = '" id="new_comm_' + num + '"></';
				new_htm = (parent == '0') ? ('\n<ol style="clear:both;" class="commentlist' + new_htm + 'ol>') : ('\n<ul class="children' + new_htm + 'ul>');
				ok_htm = '\n<div class="ajax-notice" id="success_' + num + txt3;
				div_ = (document.body.innerHTML.indexOf('div-comment-') == -1) ? '': ((document.body.innerHTML.indexOf('li-comment-') == -1) ? 'div-': '');
				ok_htm = ok_htm.concat(edt1, div_, 'comment-', parent, '", "', parent, '", "respond", "', post, '", ', num, edt2);
				ok_htm += '</span><span></span>\n';
				ok_htm += '</div>\n';
				$('#respond').before(new_htm);
				$('#new_comm_' + num).append(data);
				$('#new_comm_' + num + ' li').append(ok_htm);
				$body.animate({
					scrollTop: $('#new_comm_' + num).offset().top - 200
				},
				900);
				countdown();
				num++;
				edit = '';
				$('*').remove('#edit_id');
				cancel.style.display = 'none';
				cancel.onclick = null;
				t.I('comment_parent').value = '0';
				if (temp && respond) {
					temp.parentNode.insertBefore(respond, temp);
					temp.parentNode.removeChild(temp)
				}
			}
		});
		return false;
	});
	addComment = {
		moveForm: function(commId, parentId, respondId, postId, num) {
			var t = this,
			div,
			comm = t.I(commId),
			respond = t.I(respondId),
			cancel = t.I('cancel-comment-reply-link'),
			parent = t.I('comment_parent'),
			post = t.I('comment_post_ID');
			if (edit) exit_prev_edit();
			num ? (t.I('comment').value = comm_array[num], edit = t.I('new_comm_' + num).innerHTML.match(/(comment-)(\d+)/)[2], $new_sucs = $('#success_' + num), $new_sucs.hide(), $new_comm = $('#new_comm_' + num), $new_comm.hide(), $cancel.text(cancel_edit)) : $cancel.text(cancel_text);
			t.respondId = respondId;
			postId = postId || false;
			if (!t.I('wp-temp-form-div')) {
				div = document.createElement('div');
				div.id = 'wp-temp-form-div';
				div.style.display = 'none';
				respond.parentNode.insertBefore(div, respond)
			} ! comm ? (temp = t.I('wp-temp-form-div'), t.I('comment_parent').value = '0', temp.parentNode.insertBefore(respond, temp), temp.parentNode.removeChild(temp)) : comm.parentNode.insertBefore(respond, comm.nextSibling);
			$body.animate({
				scrollTop: $('#respond').offset().top - 180
			},
			400);
			if (post && postId) post.value = postId;
			parent.value = parentId;
			cancel.style.display = '';
			cancel.onclick = function() {
				if (edit) exit_prev_edit();
				var t = addComment,
				temp = t.I('wp-temp-form-div'),
				respond = t.I(t.respondId);
				t.I('comment_parent').value = '0';
				if (temp && respond) {
					temp.parentNode.insertBefore(respond, temp);
					temp.parentNode.removeChild(temp);
				}
				this.style.display = 'none';
				this.onclick = null;
				return false;
			};
			try {
				t.I('comment').focus();
			}
			 catch(e) {}
			return false;
		},
		I: function(e) {
			return document.getElementById(e);
		}
	};
	function exit_prev_edit() {
		$new_comm.show();
		$new_sucs.show();
		$('textarea').each(function() {
			this.value = ''
		});
		edit = '';
	}
	var wait = 15,
	submit_val = $submit.val();
	function countdown() {
		if (wait > 0) {
			$submit.val(wait);
			wait--;
			setTimeout(countdown, 1000);
		} else {
			$submit.val(submit_val).attr('disabled', false).fadeTo('slow', 1);
			wait = 15;
		}
	}
	function editcode() {
		var a = "",
		b = $("#comment").val(),
		start = b.indexOf("<code>"),
		end = b.indexOf("</code>");
		if (start > -1 && end > -1 && start < end) {
			a = "";
			while (end != -1) {
				a += b.substring(0, start + 6) + b.substring(start + 6, end).replace(/<(?=[^>]*?>)/gi, "&lt;").replace(/>/gi, "&gt;");
				b = b.substring(end + 7, b.length);
				start = b.indexOf("<code>") == -1 ? -6: b.indexOf("<code>");
				end = b.indexOf("</code>");
				if (end == -1) {
					a += "</code>" + b;
					$("#comment").val(a)
				} else if (start == -6) {
					myFielde += "&lt;/code&gt;"
				} else {
					a += "</code>"
				}
			}
		}
		var b = a ? a: $("#comment").val(),
		a = "",
		start = b.indexOf("<pre>"),
		end = b.indexOf("</pre>");
		if (start > -1 && end > -1 && start < end) {
			a = a
		} else return;
		while (end != -1) {
			a += b.substring(0, start + 5) + b.substring(start + 5, end).replace(/<(?=[^>]*?>)/gi, "&lt;").replace(/>/gi, "&gt;");
			b = b.substring(end + 6, b.length);
			start = b.indexOf("<pre>") == -1 ? -5: b.indexOf("<pre>");
			end = b.indexOf("</pre>");
			if (end == -1) {
				a += "</pre>" + b;
				$("#comment").val(a)
			} else if (start == -5) {
				myFielde += "&lt;/pre&gt;"
			} else {
				a += "</pre>"
			}
		}
	}
	function grin(a) {
		var b;
		a = " " + a + " ";
		if (document.getElementById("comment") && document.getElementById("comment").type == "textarea") {
			b = document.getElementById("comment")
		} else {
			return false
		}
		if (document.selection) {
			b.focus();
			sel = document.selection.createRange();
			sel.text = a;
			b.focus()
		} else if (b.selectionStart || b.selectionStart == "0") {
			var c = b.selectionStart;
			var d = b.selectionEnd;
			var e = d;
			b.value = b.value.substring(0, c) + a + b.value.substring(d, b.value.length);
			e += a.length;
			b.focus();
			b.selectionStart = e;
			b.selectionEnd = e
		} else {
			b.value += a;
			b.focus()
		}
	}
});

function get_post_content() {
    if ($(".reply-to-read").length > 0) {
        var ajax_data = {
            action: "ajax_post_content",
            id: $("#comment_post_ID").attr("value"),
        };
        $.post(ajax.ajax_url, ajax_data,
        function(data) {
            $(".entry-content").html(data);
        });
    }
}

jQuery(window).scroll(function() {
	jQuery(this).scrollTop() > 800 ? jQuery("#gotop").css({
		bottom: "80px"
	}) : jQuery("#gotop").css({
		bottom: "-80px"
	})
});
jQuery("#gotop").click(function() {
	return jQuery("body,html").animate({
		scrollTop: 0
	},
	800),
	!1
});

$(document).on("click", ".commentnav a",
    function() {
		showLoadingBar();
        var baseUrl = $(this).attr("href"),
        commentsHolder = $(".commentshow"),
        id = $(this).parent().data("postid"),
        page = 1,
        concelLink = $("#cancel-comment-reply-link");
        /comment-page-/i.test(baseUrl) ? page = baseUrl.split(/comment-page-/i)[1].split(/(\/|#|&).*jQuery/)[0] : /cpage=/i.test(baseUrl) && (page = baseUrl.split(/cpage=/)[1].split(/(\/|#|&).*jQuery/)[0]);
        concelLink.click();
        var ajax_data = {
            action: "ajax_comment_page_nav",
            um_post: id,
            um_page: page
        };
		commentsHolder.html('<div>loading..</div>');
		jQuery("body, html").animate({
                scrollTop: commentsHolder.offset().top - 150
            },
            1e3);
        //add loading
        jQuery.post(ajax.ajax_url, ajax_data,
        function(data) {
            commentsHolder.html(data);
            //remove loading
            $("body, html").animate({
                scrollTop: commentsHolder.offset().top - 50
            },
            1e3);
			hideLoadingBar();
        });
        return false;
    });
	

jQuery(document).ready(function($) {
	jQuery('.archives ul.archives-monthlisting').hide();
	jQuery('.archives ul.archives-monthlisting:first').show();
	jQuery('.archives .m-title').click(function() {
		jQuery(this).next().slideToggle('fast');
		return false;
	});
	
	jQuery('.show-form').click(function() {
		jQuery('#comment-info').toggle(300);
	});
	jQuery('.tabs1').click(function() {
		jQuery(this).addClass('current');
		jQuery('.tabs2').removeClass('current');
		jQuery('#tab2').hide(300);
		jQuery('#tab1').show(300);
	});
	jQuery('.tabs2').click(function() {
		jQuery(this).addClass('current');
		jQuery('.tabs1').removeClass('current');
		jQuery('#tab1').hide(300);
		jQuery('#tab2').show(300);
	});
	jQuery('#mobile-menu').click(function(){
		if(jQuery('#container').hasClass('side-transform')){
			jQuery('#container').removeClass('side-transform');}
		else{jQuery('#container').addClass('side-transform');}
		jQuery('#header ul.nav').toggle(300);
	});
});

jQuery(document).on("click", ".add-smily",
function() {
        var myField;
        tag = ' ' + jQuery(this).data("smilies") + ' ';
        if (document.getElementById('comment') && document.getElementById('comment').type == 'textarea') {
            myField = document.getElementById('comment');
        } else {
            return false;
        }
        if (document.selection) {
            myField.focus();
            sel = document.selection.createRange();
            sel.text = tag;
            myField.focus();
        }
        else if (myField.selectionStart || myField.selectionStart == '0') {
            var startPos = myField.selectionStart;
            var endPos = myField.selectionEnd;
            var cursorPos = endPos;
            myField.value = myField.value.substring(0, startPos)
                          + tag
                          + myField.value.substring(endPos, myField.value.length);
            cursorPos += tag.length;
            myField.focus();
            myField.selectionStart = cursorPos;
            myField.selectionEnd = cursorPos;
        }
        else {
            myField.value += tag;
            myField.focus();
        }
    return false;
});

$(document).on("click", ".save-setting",
	function() {
		showLoadingBar();
		edit = $(this).data("edit"), value = $(this).prev().val();
		var ajax_data = {
			action: "lo_user_setting",
			edit: edit,
			value: value
		};
		jQuery.ajax({
			url: ajax.ajax_url,
			type: "POST",
			data: ajax_data,
			dataType: "json",
			success: function(data) {
				if (data.status == 200) {
					showNotice('修改成功');
				} else {
					showNotice('失败，请重试');
				}
				hideLoadingBar();
			}
		});
	});
	
function showNotice(message) {
	clearNotice();
	$('body').append('<div class="notice"><p>' + message + '</p></div>');
	setTimeout("clearNotice()", 2000);
}
function clearNotice() {
	if ($(".notice").length > 0) {
		$(".notice").remove();
	}
}
function showLoadingBar() {
	$('.loading-bar').show();
}
function hideLoadingBar() {
	$('.loading-bar').hide();
}
var _last = 0;
jQuery(window).scroll(function() {
	var _top = jQuery(this).scrollTop();
	if ( _top < _last || _top < 200) {
		jQuery('#header').removeClass('slideUp');
		jQuery('#header').addClass('slideDown');
	} else {
		jQuery('#header').removeClass('slideDown');
		jQuery('#header').addClass('slideUp');
	}
	_last = jQuery(this).scrollTop();
});

