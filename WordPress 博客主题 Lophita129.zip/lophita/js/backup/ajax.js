var ajaxcontent="content";var ajaxsearch_class="searchform";var ajaxignore_string=new String("#, /wp-, .pdf, .zip, .rar, /share");var ajaxignore=ajaxignore_string.split(", ");var ajaxtrack_analytics=false;var ajaxscroll_top=true;var ajaxloading_code='<div class="spinner"><div class="rect1"></div><div class="rect2"></div><div class="rect3"></div><div class="rect4"></div><div class="rect5"></div></div>';var ajaxloading_error_code='<div class="box"><p style="padding:20px;">出错啦，请刷新当前页面。</p></div>';var ajaxreloadDocumentReady=false;var ajaxisLoad=false;var ajaxstarted=false;var ajaxsearchPath=null;var ajaxua=jQuery.browser;jQuery(document).ready(function(){ajaxloadPageInit("")});window.onpopstate=function(a){if(ajaxstarted===true&&ajaxcheck_ignore(document.location.toString())==true){ajaxloadPage(document.location.toString(),1)}};function ajaxloadPageInit(a){jQuery(a+"a").click(function(c){if(this.href.indexOf(ajax.home)>=0&&this.href.indexOf(ajax.home)<20&&ajaxcheck_ignore(this.href)==true){c.preventDefault();this.blur();var b=this.title||this.name||"";var d=this.rel||false;ajaxloadPage(this.href)}});jQuery("."+ajaxsearch_class).each(function(b){if(jQuery(this).attr("action")){ajaxsearchPath=jQuery(this).attr("action");jQuery(this).submit(function(){submitSearch(jQuery(this).serialize());return false})}})}function ajaxloadPage(d,c,a){if(!ajaxisLoad){if(ajaxscroll_top==true){jQuery("html,body").animate({scrollTop:0},1500)}ajaxisLoad=true;ajaxstarted=true;nohttp=d.replace("http://","").replace("https://","");firstsla=nohttp.indexOf("/");pathpos=d.indexOf(nohttp);path=d.substring(pathpos+firstsla);if(c!=1){if(typeof window.history.pushState=="function"){var b={foo:1000+Math.random()*1001};history.pushState(b,"ajax page loaded...",path)}}if(!jQuery("#"+ajaxcontent)){}jQuery("#"+ajaxcontent).append(ajaxloading_code);jQuery("#"+ajaxcontent).fadeTo("slow",0.4,function(){jQuery("#"+ajaxcontent).fadeIn("slow",function(){jQuery.ajax({type:"GET",url:d,data:a,cache:false,dataType:"html",success:function(f){ajaxisLoad=false;datax=f.split("<title>");titlesx=f.split("</title>");if(datax.length==2||titlesx.length==2){f=f.split("<title>")[1];titles=f.split("</title>")[0];jQuery(document).attr("title",(jQuery("<div/>").html(titles).text()))}if(ajaxtrack_analytics==true){if(typeof _gaq!="undefined"){if(typeof a=="undefined"){a=""}else{a="?"+a}_gaq.push(["_trackPageview",path+a])}}f=f.split('id="'+ajaxcontent+'"')[1];f=f.substring(f.indexOf(">")+1);var g=1;var e="";while(g>0){temp=f.split("</div>")[0];i=0;pos=temp.indexOf("<div");while(pos!=-1){i++;pos=temp.indexOf("<div",pos+1)}g=g+i-1;e=e+f.split("</div>")[0]+"</div>";f=f.substring(f.indexOf("</div>")+6)}document.getElementById(ajaxcontent).innerHTML=e;jQuery("#"+ajaxcontent).css("position","absolute");jQuery("#"+ajaxcontent).css("left","20000px");jQuery("#"+ajaxcontent).show();ajaxloadPageInit("#"+ajaxcontent+" ");if(ajaxreloadDocumentReady==true){jQuery(document).trigger("ready")}ajaxreload_code();jQuery("#"+ajaxcontent).hide();jQuery("#"+ajaxcontent).css("position","");jQuery("#"+ajaxcontent).css("left","");jQuery("#"+ajaxcontent).fadeTo("slow",1,function(){})},error:function(e,g,f){ajaxisLoad=false;document.title="Error loading requested page!";document.getElementById(ajaxcontent).innerHTML=ajaxloading_error_code}})})})}}function submitSearch(a){if(!ajaxisLoad){ajaxloadPage(ajaxsearchPath,0,a)}}function ajaxcheck_ignore(a){for(var b in ajaxignore){if(a.indexOf(ajaxignore[b])>=0){return false}}return true}
function ajaxreload_code(){
	var $input = $('input.rating');
	$input.rating();
	$input.on('rating.change', function(event, value, caption) {
				var score = value;
				var id = jQuery(this).data("post_id");
				var ajax_data = {
					action: "lo_rate",
					um_id: id,
					um_score: score
				};
				jQuery.ajax({
						url: ajax.ajax_url,
						type: "POST",
						data: ajax_data,
						dataType: "json",
						success: function(data) {
							if (data.status == 200) {
								var item = new Object();
								item = data.data;
									$input.rating('update', item.average);
									$input.rating('refresh', {disabled: true});
									jQuery('.rate-info').html(item.average +'分 / '+ item.raters + '票');
							} else {
								$input.rating('update', score);
							}
						}
					});
			});
}