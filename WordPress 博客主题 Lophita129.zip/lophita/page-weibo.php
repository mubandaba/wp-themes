<?php 
/*
Template Name: 微博模板
*/
get_header(); 
?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<article class="post">
	<div class="entry-content page-weibo clearfix" itemprop="description">
		<?php 
		ini_set("display_errors","Off");
		$user = array();
		$user = array();
		$arr = array();
		$count = isset($_GET['count']) && $_GET['count'] ? intval($_GET['count']) : 20;
		$count = $count ? $count : 20;

		function wptl_topic_link($tweet_msg){
			preg_match_all ( '/#(.*)#/', $tweet_msg, $matches, PREG_SET_ORDER);
			foreach( $matches as $match )
			{
				$url = "http://weibo.com/k/" . rawurlencode($match[1]);
				$tweet_msg = str_replace( '#'.$match[1].'#', "<a href='".$url."' target='_blank'>#".$match[1]."#</a>" , $tweet_msg) ;
			}
			return $tweet_msg;
		}

		function wptl_url_link($tweet_msg){
			preg_match_all ( '|http://t\.cn/\w+|', $tweet_msg, $matches, PREG_SET_ORDER);
			foreach( $matches as $match )
			{
				$url = $match[0];
				$tweet_msg = str_replace( $match[0], "<a href='".$url."' target='_blank'>".$match[0]."</a>" , $tweet_msg) ;
			}
			return $tweet_msg;
		}

		function wptl_at_link($tweet_msg){
			preg_match_all ( '/@(.*?)[:\s]/', $tweet_msg, $matches, PREG_SET_ORDER);
			foreach( $matches as $match )
			{
				$url = $match[1];
				$tweet_msg = str_replace( $match[0], "<a href='http://weibo.com/n/".$url."' target='_blank'>@".$match[1]."</a> " , $tweet_msg) ;
			}
			return $tweet_msg;
		}
		function wptl_at($content){
			$content = wptl_topic_link($content);
			$content = wptl_url_link($content);
			$content = wptl_at_link($content);
			return $content;
		}

		//$getjson = 'https://api.weibo.com/2/statuses/user_timeline.json?access_token=2.00jST9FCZfzD6D005d03967dnGPmgB';
		$getjson = 'https://api.weibo.com/2/statuses/user_timeline.json?access_token='.dopt('d_weibo_token');
		$ch = curl_init(); 
		$timeout = 5; 
		curl_setopt($ch, CURLOPT_URL, $getjson); 
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout); 
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		$content = curl_exec($ch); 
		curl_close($ch); 
		$weibo = json_decode($content, true);
		$arr = $weibo['statuses'];

		$abc = $arr[1];
		$abb = $abc['user'];
		echo '<div class="weibo-user"><img class="wb-avatar" src="'.$abb['avatar_hd'].'">';
		echo '<div class="wb-info"><div class="wb-name"><a class="wb-follow" target="_blank" href="http://weibo.com/'.$abb['domain'].'">'.$abb['name'].'</a></div><div class="wb-des">'.$abb['description'].'</div></div></div>';
		for($i=0;$i<$count;$i++){
			$arr1 = $arr["$i"];
			if($arr1) {
				$content = wptl_at($arr1['text']);
				$time=strtotime($arr1['created_at']) + 8*60*60;
				$wbty=date('y-m-d',$time);
				$wbtt=date('H:i',$time);
				$source=$arr1['source'];
				echo '<div class="timeline_feed"><section class="tl-a-feed"><article class="share-feed"><div class="wb-cont">'.$content.'</div>';
				$rltp=$arr1['pic_urls'];
				$temp = count($rltp);
				if($temp != 0) {
				echo '<div class="wbp-container">';
				for($j=0;$j<$temp;$j++){
					$thum=$rltp["$j"];
						if($thum){
							echo '<a class="slimbox" href="'.str_replace("thumbnail","large",$thum['thumbnail_pic']).'"><img class="wb-pic" src="'.str_replace("thumbnail","square",$thum['thumbnail_pic']).'"></a>';
								}
							}
				echo '</div>';            
						}
				$rlt=$arr1['retweeted_status'];
				if(count($rlt) != 0){
				$rcontent = wptl_at($rlt['text']);
				$ruser=$rlt['user'];
				$rname=$ruser['name'];
				echo '<div class="rlt"><div class="rname">'.$rname.'</div><div class="wb-cont">'.$rcontent.'</div>';
				$rltp=$rlt['pic_urls'];
				$tempc = count($rltp);
				if($tempc != 0){
				echo '<div class="wbp-container">';
				for($j=0;$j<$tempc;$j++){
					$thum=$rltp["$j"];
						if($thum){
							echo '<a class="slimbox" href="'.str_replace("thumbnail","large",$thum['thumbnail_pic']).'"><img class="wb-pic" src="'.str_replace("thumbnail","square",$thum['thumbnail_pic']).'"></a>';
								}
							}
				echo '</div>';            
						}
				echo '</div>';        
				}
				echo '</article></section><div class="legend"><span class="year">'.$wbty.'</span><span class="time">'.$wbtt.'</span></div></div>';
			}
		}
		?>  
    </div>
</article>

<?php endwhile; endif;?>
<?php get_footer(); ?>