<?php

include_once('inc/themeset.php');

include (TEMPLATEPATH . '/custom-functions.php');
include (TEMPLATEPATH . '/functions/edit.php');
include (TEMPLATEPATH . '/functions/theme.php');
include (TEMPLATEPATH . '/functions/clear.php');
include (TEMPLATEPATH . '/functions/comments.php');
include (TEMPLATEPATH . '/functions/tags.php');
include (TEMPLATEPATH . '/functions/lophita.php');
include (TEMPLATEPATH . '/functions/widgets.php');
include (TEMPLATEPATH . '/functions/wp_bootstrap_gallery.php');

add_action('after_setup_theme', 'my_theme_setup');
function my_theme_setup(){
    load_theme_textdomain('Lophita', get_template_directory() . '/languages');
}
register_nav_menus(array('header-menu' => '顶部导航', 'footer-menu' => '底部导航'));

add_theme_support( 'post-formats', array( 'status'));

function dopt($e){
    return stripslashes(get_option($e));
}

function do_post($url, $data) {
    $ch = curl_init ();
    curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, TRUE );
    curl_setopt ( $ch, CURLOPT_POST, TRUE );
    curl_setopt ( $ch, CURLOPT_POSTFIELDS, $data );
    curl_setopt ( $ch, CURLOPT_URL, $url );
    curl_setopt ( $ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    $ret = curl_exec ( $ch );
    curl_close ( $ch );
    return $ret;
}
function get_url_contents($url) {
    if (ini_get ( "allow_url_fopen" ) == "1")
        return file_get_contents ( $url );
    $ch = curl_init ();
    curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, TRUE );
    curl_setopt ( $ch, CURLOPT_URL, $url );
    $result = curl_exec ( $ch );
    curl_close ( $ch );
    return $result;
}
?>