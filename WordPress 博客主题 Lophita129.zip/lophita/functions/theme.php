<?php
add_action( 'wp_enqueue_scripts', 'my_enqueue_scripts_frontpage' );
function my_enqueue_scripts_frontpage() {
	wp_enqueue_style( 'default', get_template_directory_uri() . '/style.css', array(), '1.0.0' );
	//wp_enqueue_style( 'custom', get_template_directory_uri() . '/custom-style.css', array(), '1.0.0' );
	wp_enqueue_script( 'jquerylib', get_template_directory_uri() . '/js/jquery-1.10.2.min.js' , array(), '1.10.2', false);  
	wp_enqueue_script( 'wp-player-jplayer', get_template_directory_uri().'/inc/wp-player/js/soundmanager2.js', array(), '1.0.0', true );
	wp_enqueue_script( 'base', get_template_directory_uri() . '/js/global.js', array(), '1.0.0', true);

	wp_localize_script( 'wp-player-jplayer', 'wp_player_params', 
		array(
			'swf' => get_template_directory_uri().'/inc/wp-player/js/',
			'url' => admin_url().'admin-ajax.php',
			'nonce' => wp_create_nonce('wp-player'),
			'single' => ( is_single() || is_page() ) ? 'true' : 'false'
	));

	wp_localize_script('base', 'ajax', array(
		'ajax_url' => admin_url('admin-ajax.php'),
		'home' => home_url(),
		'gif' => includes_url('/images/spinner.gif')
	));
}

add_filter('nav_menu_css_class', 'my_css_attributes_filter', 100, 1);
add_filter('nav_menu_item_id', 'my_css_attributes_filter', 100, 1);
add_filter('page_css_class', 'my_css_attributes_filter', 100, 1);
function my_css_attributes_filter($var) {
	return is_array($var) ? array_intersect($var, array('current-menu-item','current-post-ancestor','current-menu-ancestor','current-menu-parent')) : '';
}

add_filter('pre_get_posts','search_filter');
function search_filter($query) {
	if ($query->is_search) {
		$query->set('post_type', 'post');
	}
	return $query;
}


?>