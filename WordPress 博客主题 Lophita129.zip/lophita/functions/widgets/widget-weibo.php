<?php
add_action('widgets_init', 'lo_weibo_widget');
function lo_weibo_widget() {
    register_widget('lo_weibo');
}
class lo_weibo extends WP_Widget {
    function lo_weibo() {
		$widget_ops = array( 'classname' => 'lo_weibo','description' => '最近原创微博' );
		$control_ops = array( 'width' => 250, 'height' => 350, 'id_base' => 'weibo-widget' );
		$this->WP_Widget( 'weibo-widget','微博', $widget_ops, $control_ops );
    }
    function widget($args, $instance) {
        extract($args);
        $limit = strip_tags($instance['limit']) ? strip_tags($instance['limit']) : 5;
        echo $before_widget;
        weibo_widget($limit);
        echo $after_widget;
    }
    function update($new_instance, $old_instance) {
        if (!isset($new_instance['submit'])) {
            return false;
        }
        $instance = $old_instance;
        $instance['limit'] = strip_tags($new_instance['limit']);

        return $instance;
    }
    function form($instance) {
        global $wpdb;
        $instance = wp_parse_args((array) $instance, array('limit' => ''));
        $limit = strip_tags($instance['limit']);
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('limit'); ?>">显示数量：<input class="widefat" id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="text" value="<?php echo $limit; ?>" /></label>
        </p>
        <input type="hidden" id="<?php echo $this->get_field_id('submit'); ?>" name="<?php echo $this->get_field_name('submit'); ?>" value="1" />
    <?php
    }
}

function weibo_widget($limit=5){
	$get_user_info = "https://api.weibo.com/2/statuses/user_timeline.json?feature=1&count=".$limit."&access_token=".dopt('d_weibo_token');
	$data = get_url_contents ( $get_user_info );
	$ms  = json_decode($data , true);
    if( is_array( $ms['statuses'] ) ):
        echo '<div id="weibo-list">';
        foreach( $ms['statuses'] as $item ):
            $text = $item['text'];
			$time=strtotime($item['created_at']) + 8*60*60;
			$t=date('m-d H:i',$time);
            
            echo '<div class="weibo-item"><i class="iconfont icon-xinlangweibo"></i>';
			echo '<span>'.$text.'</span><span class="time">'.$t.'</span>';
            echo '</div>';
        endforeach;

    endif;

}

?>