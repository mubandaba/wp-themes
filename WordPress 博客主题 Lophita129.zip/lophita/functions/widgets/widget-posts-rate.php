<?php
add_action('widgets_init', 'lo_rate_posts_widget');
function lo_rate_posts_widget() {
    register_widget('lo_rate_posts');
}
class lo_rate_posts extends WP_Widget {
    function lo_rate_posts() {
        $widget_ops = array('description' => '列出评分最高的几篇文章');
        $this->WP_Widget('most_rated', '评分高的文章', $widget_ops);
    }
    function widget($args, $instance) {
        extract($args);
        $title = apply_filters('widget_title',esc_attr($instance['title']));
        $limit = strip_tags($instance['limit']) ? strip_tags($instance['limit']) : 5;
        echo $before_widget.$before_title.$title.$after_title;
        ?>
        <ul class="lo_rate-posts">
            <?php query_posts( array('showposts' => $limit,
                'meta_key' => '_rating_average',
                'orderby' => 'meta_value_num',
                'ignore_sticky_posts' => 1));?>
            <?php while (have_posts()) : the_post(); 
					$info = lo_get_rating_info($post_id);
					$rate = $info['average'];
					$rate = number_format($rate,1);
					$raters = $info['raters'];
			
			?>
                <li class="lo_rate-post">
					<a href="<?php the_permalink() ?>" class="rate-number" data-num="<?php echo $rate;?>"></a>
					<div class="rate-title"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
                        <?php the_title(); ?>
                         </a>
						 <p><?php _e('Based on ','Lophita');echo $raters; _e(' Readers', 'Lophita');?></p></div></li>
            <?php endwhile;wp_reset_query(); ?>
        </ul>

        <?php
        echo $after_widget;
    }
    function update($new_instance, $old_instance) {
        if (!isset($new_instance['submit'])) {
            return false;
        }
        $instance = $old_instance;
        $instance['title'] = strip_tags($new_instance['title']);
        $instance['limit'] = strip_tags($new_instance['limit']);

        return $instance;
    }
    function form($instance) {
        global $wpdb;
        $instance = wp_parse_args((array) $instance, array('title'=> '', 'limit' => ''));
        $title = esc_attr($instance['title']);
        $limit = strip_tags($instance['limit']);
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>">标题：<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></label>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('limit'); ?>">显示数量：<input class="widefat" id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="text" value="<?php echo $limit; ?>" /></label>
        </p>
        <input type="hidden" id="<?php echo $this->get_field_id('submit'); ?>" name="<?php echo $this->get_field_name('submit'); ?>" value="1" />
    <?php
    }
}

?>