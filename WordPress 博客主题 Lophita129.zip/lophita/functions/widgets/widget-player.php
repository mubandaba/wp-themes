<?php
add_action('widgets_init', 'lo_player_widget');
function lo_player_widget() {
    register_widget('lo_player');
}
class lo_player extends WP_Widget {
    function lo_player() {
        $widget_ops = array('description' => '边栏播放器');
        $this->WP_Widget('lo_player', '边栏播放器', $widget_ops);
    }
    function widget($args, $instance) {
        extract($args);
        $type = esc_attr($instance['type']);
        $xiami = esc_attr($instance['xiami']);
        $autoplay = esc_attr($instance['autoplay']);
        echo $before_widget;
        get_lo_player( $type, $xiami, $autoplay );
        echo $after_widget;
    }
    function update($new_instance, $old_instance) {
        if (!isset($new_instance['submit'])) {
            return false;
        }
        $instance = $old_instance;
        $instance['type'] = strip_tags($new_instance['type']);
        $instance['xiami'] = strip_tags($new_instance['xiami']);
        $instance['autoplay'] = strip_tags($new_instance['autoplay']);

        return $instance;
    }
    function form($instance) {
        global $wpdb;
        $instance = wp_parse_args((array) $instance, array('type' => 'song'));
        $type = strip_tags($instance['type']);
        $xiami = strip_tags($instance['xiami']);
        $autoplay = strip_tags($instance['autoplay']);
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('type'); ?>">虾米音乐类型：
				<select class="widefat mp3_xiami_type" id="<?php echo $this->get_field_id('type'); ?>" name="<?php echo $this->get_field_name('type'); ?>">
					<option value="song" <?php if($type=='song') echo 'selected="selected"';?>>单音乐页面</option>
					<option value="album" <?php if($type=='album') echo 'selected="selected"';?>>专辑页面</option>
					<option value="artist" <?php if($type=='artist') echo 'selected="selected"';?>>艺人页面</option>
					<option value="collect" <?php if($type=='collect') echo 'selected="selected"';?>>精选集页面</option>
				</select>
			</label>
        </p>
		<p>
            <label for="<?php echo $this->get_field_id('xiami'); ?>">歌曲/专辑/艺人/精选集 ID：
				<input class="widefat mp3_xiami" id="<?php echo $this->get_field_id('xiami'); ?>" name="<?php echo $this->get_field_name('xiami'); ?> " value="<?php echo $xiami; ?>">
			</label>
        </p>
		<p>
            <label for="<?php echo $this->get_field_id( 'autoplay' ); ?>">自动播放 : </label>
			<input id="<?php echo $this->get_field_id( 'autoplay' ); ?>" name="<?php echo $this->get_field_name( 'autoplay' ); ?>" value="true" <?php if( $instance['autoplay'] ) echo 'checked="checked"'; ?> type="checkbox" />
        </p>
        <input type="hidden" id="<?php echo $this->get_field_id('submit'); ?>" name="<?php echo $this->get_field_name('submit'); ?>" value="1" />
    <?php
    }
}

 function get_lo_player( $type, $xiami, $autoplay ){
	if($autoplay){
		$autoplay = 1;
	} else {
		$autoplay = 0;
	}

	$thumb = get_template_directory_uri().'/images/default.png';

	echo '<!--wp-player start--><div class="wp-player" data-wp-player="wp-player" data-source="xiami" data-autoplay="'.$autoplay.'" data-type="'.$type.'" data-xiami="'.$xiami.'" ><div class="wp-player-box"><div class="wp-player-thumb"><img src="'.$thumb.'" width="90" height="90" alt="" /><div class="wp-player-playing"><span></span></div></div><div class="wp-player-panel"><div class="wp-player-title"></div><div class="wp-player-author"></div><div class="wp-player-progress"><div class="wp-player-seek-bar"><div class="wp-player-play-bar"><span class="wp-player-play-current"></span></div></div></div><div class="wp-player-controls-holder"><div class="wp-player-time"></div><div class="wp-player-controls"><a href="javascript:;" class="wp-player-previous" title="上一首"></a><a href="javascript:;" class="wp-player-play" title="播放"></a><a href="javascript:;" class="wp-player-stop" title="暂停"></a><a href="javascript:;" class="wp-player-next" title="下一首"></a></div><div class="wp-player-webjyh"><a href="http://webjyh.com/wp-player/" target="_blank">©</a></div><div class="wp-player-list-btn" title="歌单"></div></div></div></div><div class="wp-player-main"><div class="wp-player-list"><ul></ul></div><div class="wp-player-lyrics"><ul></ul></div></div></div><!--wp-player end-->';
}

?>