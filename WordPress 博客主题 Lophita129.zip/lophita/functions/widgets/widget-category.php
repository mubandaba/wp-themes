<?php
add_action( 'widgets_init', 'lo_category_posts_widget' );
function lo_category_posts_widget() {
	register_widget( 'lo_category_posts' );
}
class lo_category_posts extends WP_Widget {

	function lo_category_posts() {
		$widget_ops = array( 'classname' => 'category-posts','description' => '显示某个特定分类下的文章' );
		$this->WP_Widget( 'category-posts-widget','分类文章列表', $widget_ops, $control_ops );
	}
	
	function widget( $args, $instance ) {
		extract( $args );

		$title = apply_filters('widget_title', $instance['title'] );
		$no_of_posts = $instance['no_of_posts'];
		$cats_id = $instance['cats_id'];
		$thumb = $instance['thumb'];

		echo $before_widget;
			echo $before_title;
			echo $title ; ?>
		<?php echo $after_title; 
		
			if($thumb) echo '<ul class="category-posts-thumb">';
			else echo '<ul class="category-posts-nothumb">';
		?>
					<?php lo_last_posts_cat($no_of_posts , $thumb , $cats_id)?>	
				</ul>
		<div class="clear"></div>
	<?php 
		echo $after_widget;
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['no_of_posts'] = strip_tags( $new_instance['no_of_posts'] );
		
		$instance['cats_id'] = implode(',' , $new_instance['cats_id']  );

		$instance['thumb'] = strip_tags( $new_instance['thumb'] );
		return $instance;
	}

	function form( $instance ) {
		$defaults = array( 'title' => '分类文章', 'no_of_posts' => '5' , 'cats_id' => '1' , 'thumb' => 'true' );
		$instance = wp_parse_args( (array) $instance, $defaults );
		
		$categories_obj = get_categories();
		$categories = array();

		foreach ($categories_obj as $pn_cat) {
			$categories[$pn_cat->cat_ID] = $pn_cat->cat_name;
		}
		?>

		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>">标题 : </label>
			<input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" class="widefat" type="text" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'no_of_posts' ); ?>">显示数目 : </label>
			<input id="<?php echo $this->get_field_id( 'no_of_posts' ); ?>" name="<?php echo $this->get_field_name( 'no_of_posts' ); ?>" value="<?php echo $instance['no_of_posts']; ?>" type="text" size="3" />
		</p>
		<p>
			<?php $cats_id = explode ( ',' , $instance['cats_id'] ) ; ?>
			<label for="<?php echo $this->get_field_id( 'cats_id' ); ?>">分类 : </label>
			<select multiple="multiple" id="<?php echo $this->get_field_id( 'cats_id' ); ?>[]" name="<?php echo $this->get_field_name( 'cats_id' ); ?>[]">
				<?php foreach ($categories as $key => $option) { ?>
				<option value="<?php echo $key ?>" <?php if ( in_array( $key , $cats_id ) ) { echo ' selected="selected"' ; } ?>><?php echo $option; ?></option>
				<?php } ?>
			</select>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'thumb' ); ?>">显示缩略图 : </label>
			<input id="<?php echo $this->get_field_id( 'thumb' ); ?>" name="<?php echo $this->get_field_name( 'thumb' ); ?>" value="true" <?php if( $instance['thumb'] ) echo 'checked="checked"'; ?> type="checkbox" />
		</p>

	<?php
	}
}

function lo_last_posts_cat($numberOfPosts = 5 , $thumb = true , $cats = 1){
	global $post;
	$orig_post = $post;

	$lastPosts = get_posts('category='.$cats.'&no_found_rows=1&suppress_filters=0&numberposts='.$numberOfPosts);
	foreach($lastPosts as $post): setup_postdata($post);
?>
<li>
	<?php if ( function_exists("has_post_thumbnail") && $thumb ) : ?>
		<div class="post-thumbnail">
			<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark"><?php lo_thumb(); ?></a>
		</div>
	<?php endif; ?>
	<div class="category-post"><h3><a href="<?php the_permalink(); ?>"><?php the_title();?></a></h3>
	<?php if(!$thumb) {comments_popup_link(__("No Reply", 'Lophita'), __("1 Reply", 'Lophita'), __('% Replies', 'Lophita'));} ?> <span class="date"><?php lo_get_time() ?></span></div>
</li>
<?php endforeach;
	$post = $orig_post;
}

function lo_get_time(){
	global $post ;
	$to = current_time('timestamp'); //time();
	$from = get_the_time('U') ;
	
	$diff = (int) abs($to - $from);
	if ($diff <= 3600) {
		$mins = round($diff / 60);
		if ($mins <= 1) {
			$mins = 1;
		}
		$since = sprintf(_n('%s min', '%s mins', $mins), $mins) .' '. __( 'ago' , 'Lophita' );
	}
	else if (($diff <= 86400) && ($diff > 3600)) {
		$hours = round($diff / 3600);
		if ($hours <= 1) {
			$hours = 1;
		}
		$since = sprintf(_n('%s hour', '%s hours', $hours), $hours) .' '. __( 'ago' , 'Lophita' );
	}
	elseif ($diff >= 86400) {
		$days = round($diff / 86400);
		if ($days <= 1) {
			$days = 1;
			$since = sprintf(_n('%s day', '%s days', $days), $days) .' '. __( 'ago' , 'Lophita' );
		}
		elseif( $days > 29){
			$since = get_the_time(get_option('date_format'));
		}
		else{
			$since = sprintf(_n('%s day', '%s days', $days), $days) .' '. __( 'ago' , 'Lophita' );
		}
	}
	echo '<span>'.$since.'</span>';
}
?>