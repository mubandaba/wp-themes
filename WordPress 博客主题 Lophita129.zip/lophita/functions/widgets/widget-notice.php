<?php
add_action( 'widgets_init', 'lo_notice_widget' );
function lo_notice_widget() {
	register_widget( 'lo_notice' );
}
class lo_notice extends WP_Widget {

	function lo_notice() {
		$widget_ops = array( 'classname' => 'notice-widget'  );
		$control_ops = array( 'width' => 250, 'height' => 350, 'id_base' => 'notice-widget' );
		$this->WP_Widget( 'notice-widget','公告', $widget_ops, $control_ops );
	}
	
	function widget( $args, $instance ) {
		extract( $args );

		$notice = apply_filters('widget_title', $instance['notice'] );
		echo $before_widget;
		echo '<i class="iconfont icon-mail1"></i><span>'.$notice.'</span>';
		echo $after_widget;
			
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['notice'] = strip_tags( $new_instance['notice'] );
		return $instance;
	}

	function form( $instance ) {
		$defaults = array( 'notice' => '公告' );
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>

		<p>
			<label for="<?php echo $this->get_field_id( 'notice' ); ?>">公告 : </label>
			<textarea id="<?php echo $this->get_field_id( 'notice' ); ?>" name="<?php echo $this->get_field_name( 'notice' ); ?>"  class="widefat" ><?php  if( !empty($instance['notice']) ) echo $instance['notice']; ?></textarea>
		</p>
	<?php
	}
}
?>