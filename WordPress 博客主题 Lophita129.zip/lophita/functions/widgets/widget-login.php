<?php
add_action( 'widgets_init', 'lo_login_widget_box' );
function lo_login_widget_box() {
	register_widget( 'lo_login_widget' );
}
class lo_login_widget extends WP_Widget {

	function lo_login_widget() {
		$widget_ops = array( 'classname' => 'login-widget'  );
		$control_ops = array( 'width' => 250, 'height' => 350, 'id_base' => 'login-widget' );
		$this->WP_Widget( 'login-widget','后台登陆', $widget_ops, $control_ops );
	}
	
	function widget( $args, $instance ) {
		extract( $args );

		$title = apply_filters('widget_title', $instance['title'] );
		
		echo $before_widget;
		echo $before_title;
		echo $title ; 
		echo $after_title;
		lo_login_form();
		echo $after_widget;
			
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags( $new_instance['title'] );
		return $instance;
	}

	function form( $instance ) {
		$defaults = array( 'title' =>__('Login' , 'lo')  );
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>

		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>">标题 : </label>
			<input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php  if( !empty($instance['title']) ) echo $instance['title']; ?>" class="widefat" type="text" />
		</p>



	<?php
	}
}

function lo_login_form( $login_only  = 0 ) {
	global $user_ID, $user_identity, $user_level;
	
	if ( $user_ID ) : ?>
		<?php if( empty( $login_only ) ): ?>
		<div id="user-login">
			<span class="author-avatar"><?php echo get_avatar( $user_ID, $size = '85'); ?></span>
			<ul>
				<li><a href="<?php echo home_url() ?>/wp-admin/"><?php _e( 'Dashboard' , 'Lophita' ) ?> </a></li>
				<li><a href="<?php echo home_url() ?>/wp-admin/profile.php"><?php _e( 'Your Profile' , 'Lophita' ) ?> </a></li>
				<li><a href="<?php echo wp_logout_url(); ?>"><?php _e( 'Logout' , 'Lophita' ) ?> </a></li>
			</ul>
		</div>
		<?php endif; ?>
	<?php else: ?>
		<div id="login-form" class="clearfix">
			<form name="loginform" id="loginform" action="<?php echo home_url() ?>/wp-login.php" method="post">
				<p id="log-username">
					<label>用户名:</label>
					<input type="text" name="log" id="log" /></p>
				<p id="log-pass">
					<label>密　码:</label>
					<input type="password" name="pwd" id="pwd" /></p>
					<input type="submit" name="submit" value="<?php _e( 'Log in' , 'Lophita' ) ?>" class="login-button" />
				<input type="hidden" name="redirect_to" value="<?php echo $_SERVER['REQUEST_URI']; ?>"/>
			</form>
		</div>
	<?php endif;
}
?>