<?php

add_action( 'widgets_init', 'lo_author_widget' );
function lo_author_widget() {
	register_widget( 'lo_author' );
}

class lo_author extends WP_Widget {
	function lo_author() {
		$widget_ops = array( 'classname' => 'lo_author', 'description' => '显示作者的信息机个人简介' );
		$this->WP_Widget( 'lo_author', '作者信息', $widget_ops, $control_ops );
	}

	function widget( $args, $instance ) {
		extract( $args );
		echo $before_widget;
		?>
		<img src="<?php bloginfo('template_directory'); ?>/images/bg_small.jpg">
		<div class="author-body">
			<div class="author-avatar">
			<?php echo get_avatar( get_bloginfo ('admin_email'), $size = '80' , '' );?>
			</div>
			<div class="author-info">
				<h3><?php the_author_meta('nickname');?> </h3>
				<p><?php the_author_meta('user_description');?> </p>
			</div>
		</div>
		<?php if( dopt('d_sns_open') ) {
			echo '<p class="author-social">';
			if( dopt('d_rss_b') ) echo '<a class="rss" href="'.dopt('d_rss').'"><i class="iconfont icon-dingyue"></i></a>';
			if( dopt('d_mail_b') ) echo '<a class="mail" href="'.dopt('d_mail').'"><i class="iconfont icon-mail"></i></a>';
			if( dopt('d_rss_sina_b') ) echo '<a class="weibo" href="'.dopt('d_rss_sina').'"><i class="iconfont icon-xinlangweibo"></i></a>';
			if( dopt('d_rss_twitter_b') ) echo '<a class="twitter" href="'.dopt('d_rss_twitter').'"><i class="iconfont icon-twitter"></i></a>';
			if( dopt('d_rss_google_b') ) echo '<a class="google" href="'.dopt('d_rss_google').'"><i class="iconfont icon-0394googleplus2"></i></a>';
			if( dopt('d_rss_facebook_b') ) echo '<a class="facebook" href="'.dopt('d_rss_facebook').'"><i class="iconfont icon-facebook"></i></a>';
			if( dopt('d_rss_github_b') ) echo '<a class="github" href="'.dopt('d_rss_github').'"><i class="iconfont icon-github"></i></a>';
			if( dopt('d_rss_tencent_b') ) echo '<a class="tweibo" href="'.dopt('d_rss_tencent').'"><i class="iconfont icon-tengxunweibo"></i></a>';
			if( dopt('d_rss_linkedin_b') ) echo '<a class="linkedin" href="'.dopt('d_rss_linkedin').'"><i class="iconfont icon-0457linkedin"></i></a>';
			echo '</p>';
		}
		?>
<?php
		echo $after_widget;
	}
	function form($instance) {
?>
		<p>
			<label>
			无选项
			</label>
		</p>

<?php
	}
}

?>