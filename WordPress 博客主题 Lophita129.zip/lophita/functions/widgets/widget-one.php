<?php
add_action( 'widgets_init', 'lo_one_widget' );
function lo_one_widget() {
	register_widget( 'lo_one' );
}
class lo_one extends WP_Widget {
	function lo_one() {
		$widget_ops = array( 'classname' => 'lo_one','description' => 'One每日一言' );
		$control_ops = array( 'width' => 250, 'height' => 350, 'id_base' => 'one-widget' );
		$this->WP_Widget( 'one-widget','One', $widget_ops, $control_ops );
	}
	function widget( $args, $instance ) {
		extract( $args );
		echo $before_widget.the_one().$after_widget;
	}
}

function the_one(){
	$json = get_one_json();
	$content = $json['hpEntity'];
	$image = $content['strOriginalImgUrl'];
	$author = $content['strAuthor'];
	$words = $content['strContent'];
	$output .= '<img src="'.$image.'">';
	$output .= '<div class="one_content">'.$words.'</div>';
	return $output;
}

function get_one_json(){
	if (get_transient('onecache')) {
		$content = get_transient('onecache');
	}else{
		delete_transient('onecache');
		$data = date("Y-m-d",time());
		$getjson = 'http://211.152.49.184:7001/OneForWeb/one/getHpinfo?strDate=' . $data;
		$content = file_get_contents($getjson);
		set_transient('onecache', $content, 60*60*24);
	}
	return json_decode($content,true);
}
?>