<?php
## widget_tabs
add_action( 'widgets_init', 'lo_widget_tabs_box' );
function lo_widget_tabs_box(){
	register_widget( 'lo_widget_tabs' );
}
class lo_widget_tabs extends WP_Widget {
	function lo_widget_tabs() {
		$widget_ops = array( 'description' => '最热-最近文章-Tab切换'  );
		$this->WP_Widget( 'widget_tabs','最热-最近文章 ', $widget_ops );
	}
	function widget( $args, $instance ) {
		
		if( empty($instance['posts_number']) || $instance['posts_number'] == ' ' || !is_numeric($instance['posts_number']))	$posts_number = 5;
		else $posts_number = $instance['posts_number'];
	?>
	<div class="widget" id="tabbed-widget">
		<div class="widget-container">
			<div class="widget-top">
				<ul class="tabs posts-tabs">
					<li class="tabs1 current"><?php _e( 'Popular' , 'Lophita' ) ?></li>
					<li class="tabs2"><?php _e( 'Recent' , 'Lophita' ) ?></li>
				</ul>
			</div>
			<div id="tab1" class="tabs-wrap">
				<ul>
					<?php lo_popular_posts( $posts_number ) ?>	
				</ul>
			</div>
			<div id="tab2" class="tabs-wrap">
				<ul>
					<?php lo_last_posts( $posts_number )?>	
				</ul>
			</div>
		</div>
	</div>
<?php
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['posts_number'] = strip_tags( $new_instance['posts_number'] );
		return $instance;
	}

	function form( $instance ) {
		$defaults = array( 'posts_number' => 5 );
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>

		<p>
			<label for="<?php echo $this->get_field_id( 'posts_number' ); ?>">显示数目 : </label>
			<input id="<?php echo $this->get_field_id( 'posts_number' ); ?>" name="<?php echo $this->get_field_name( 'posts_number' ); ?>" value="<?php if( !empty($instance['posts_number']) ) echo $instance['posts_number']; ?>" size="3" type="text" />
		</p>


	<?php
	}
}



?>
