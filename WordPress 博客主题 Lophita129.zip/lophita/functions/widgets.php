<?php
add_action('widgets_init', 'lo_unregister_default_wp_widgets', 1);
function lo_unregister_default_wp_widgets() {
	unregister_widget('WP_Widget_Pages');
	unregister_widget('WP_Widget_Calendar');
	unregister_widget('WP_Widget_Archives');
	unregister_widget('WP_Widget_Links');
	unregister_widget('WP_Widget_Meta');
	unregister_widget('WP_Widget_Search');
	unregister_widget('WP_Widget_Text');
	unregister_widget('WP_Widget_Categories');
	unregister_widget('WP_Widget_Recent_Posts');
	unregister_widget('WP_Widget_Recent_Comments');
	unregister_widget('WP_Widget_RSS');
	unregister_widget('WP_Widget_Tag_Cloud');
	unregister_widget('WP_Nav_Menu_Widget');
}

add_action('widgets_init','lo_sidebar');
function lo_sidebar(){
    register_sidebar(array(
        'id'=>'sidebar',
        'name'=>'边栏',
		'before_title' => '<h3 class="widget-title"><span>',
        'after_title' => '</h3></span>',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
    ));
}

include (TEMPLATEPATH . '/functions/widgets/widget-author.php');
include (TEMPLATEPATH . '/functions/widgets/widget-posts-raters.php');
include (TEMPLATEPATH . '/functions/widgets/widget-posts-rate.php');
include (TEMPLATEPATH . '/functions/widgets/widget-category.php');
include (TEMPLATEPATH . '/functions/widgets/widget-login.php');
include (TEMPLATEPATH . '/functions/widgets/widget-comments-avatar.php');
include (TEMPLATEPATH . '/functions/widgets/widget-readers.php');
include (TEMPLATEPATH . '/functions/widgets/widget-tags.php');
include (TEMPLATEPATH . '/functions/widgets/widget-search.php');
include (TEMPLATEPATH . '/functions/widgets/widget-tabbed.php');
include (TEMPLATEPATH . '/functions/widgets/widget-posts.php');
include (TEMPLATEPATH . '/functions/widgets/widget-one.php');
include (TEMPLATEPATH . '/functions/widgets/widget-weibo.php');
include (TEMPLATEPATH . '/functions/widgets/widget-notice.php');
include (TEMPLATEPATH . '/functions/widgets/widget-player.php');


?>