<?php
remove_action('wp_head','wp_generator');
remove_action('wp_head','rsd_link');
remove_action('wp_head','wlwmanifest_link');
remove_action('wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0 );
remove_action('wp_head', 'wp_shortlink_wp_head', 10, 0 );

add_filter('show_admin_bar','hide_admin_bar'); 
function hide_admin_bar($flag) {
	return false;
}

remove_filter ('comment_text', 'wpautop');
add_filter( 'pre_option_link_manager_enabled', '__return_true' );

remove_filter( 'the_content', 'wpautop' );
add_filter( 'the_content', 'wpautop' , 12);

function no_self_ping( &$links ) {
	$home = get_option( 'home' );
	foreach ( $links as $l => $link )
		if ( 0 === strpos( $link, $home ) )
	unset($links[$l]);
}
if(dopt('d_nopingback_b')){
	add_action( 'pre_ping', 'no_self_ping' );
}

?>