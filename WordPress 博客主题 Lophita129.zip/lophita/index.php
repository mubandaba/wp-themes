<?php get_header(); ?>

<div class="article-sort">
	<div class="sort-wrap">
		<?php if ( !isset($_GET['order'])) { ?><span class="sort-btn"><a href="<?php echo get_option('home'); ?>/?order=hot" rel="nofollow" title="热度排序"><i class="iconfont icon-hotranking"></i></a></span><?php } ?>
		<?php if ( isset($_GET['order']) && ($_GET['order']=='hot') ) { ?><span class="sort-btn"><a href="<?php echo get_option('home'); ?>" rel="nofollow" title="时间排序"><i class="iconfont icon-time"></i></a></span><?php } ?>
	</div>
</div>

<?php

	if ( isset($_GET['order']) && $_GET['order']=='hot') {
		$orderby = 'comment_count';
		global $wp_query;
		$args= array('orderby' => $orderby, 'order' => 'DESC');

		$arms = array_merge($args, $wp_query->query);
		query_posts($arms);
	}
	if( have_posts() ){
		while ( have_posts() ){
			the_post(); 
			get_template_part( 'inc/post-format/content', get_post_format() );
		}
	}
?>
<?php lo_pagenavi();?>
<?php get_footer(); ?>