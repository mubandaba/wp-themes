<?php 
/*
Template Name: 留言板模板
*/
get_header(); 
function readers_wall( $outer='1',$timer='100',$limit='27' ){
	global $wpdb;
	$counts = $wpdb->get_results("select count(comment_author) as cnt, comment_author, comment_author_url, comment_author_email from (select * from $wpdb->comments left outer join $wpdb->posts on ($wpdb->posts.id=$wpdb->comments.comment_post_id) where comment_date > date_sub( now(), interval $timer month ) and user_id='0' and comment_author != '".$outer."' and post_password='' and comment_approved='1' and comment_type='') as tempcmt group by comment_author order by cnt desc limit $limit");
	foreach ($counts as $count) {
		$c_url = $count->comment_author_url;
		if (!$c_url) $c_url = 'javascript:;';
		$type .= '<a target="_blank" href="'. $c_url . '" title="['.$count->comment_author.']近期评论'. $count->cnt . '次">'.get_avatar( $count->comment_author_email, $size = '64' ).'</a>';
	}
	echo $type;
};
?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<article class="post">
    <header class="entry-header">
		<h2 class="entry-name">
			<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
		</h2>
    </header>
    <div class="entry-content readers-wall" itemprop="description">
        <?php readers_wall(); ?>
		
    </div>
</article>

<?php comments_template('', true); ?>
	
<?php endwhile; endif;?>
<?php get_footer(); ?>