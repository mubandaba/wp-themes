<?php
/*
Template Name: 标签模板
*/
get_header(); 
?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<article class="post">
	<header class="entry-header">
		<h2 class="entry-name">
			<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
		</h2>
	</header>
	<div class="tags-page" itemprop="description">
		<?php specs_show_tags(); ?>
	</div>
</article>

<?php endwhile; endif;?>

<?php get_footer(); ?>