		</div>
		<?php get_sidebar();?>
	</div>
	
	<footer id="footer">
		<div class="footer-wrap clearfix">
			<p><?php echo dopt('d_notice_bottom');?></p>
			<div class="footer-menu">
				<?php 
					if(function_exists('wp_nav_menu')) {
						wp_nav_menu(array( 'theme_location' => 'footer-menu','container' => 'ul')); 
					}
				?>
			</div>
		</div>
	</footer>
	</div>
	<a id="gotop" href="javascript:;"><i class="iconfont icon-huidaodingbu"></i></a>
<?php 
if( dopt('d_track_b') != '' ) echo '<div class="static-hide">'.dopt('d_track').'</div>';
if( dopt('d_footcode_b') != '' ) echo dopt('d_footcode');
wp_footer();
?>
</body>
</html>