<div id="sidebar">
<?php 
		if(is_dynamic_sidebar()) 
			dynamic_sidebar('sidebar');
	?>
</div>