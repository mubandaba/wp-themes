<?php get_header(); ?>

<div class="archive-meta">
	<h3 class="title-meta"><?php single_tag_title(); ?></h3>
</div>

<?php 

	if( have_posts() ){ 
		while ( have_posts() ){
			the_post(); 
			get_template_part( 'inc/post-format/category', get_post_format() );
		}
	}

?>
<?php lo_pagenavi();?>
<?php get_footer(); ?>