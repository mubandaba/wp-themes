<?php
/**
 * The template for the sidebar containing the main widget area
 *
 * @package WordPress
 * @subpackage Inpandora
 * @since Wbolt 1.0
 */
?>

<div class="sidebar">
	<div class="sb-inner">
		<?php dynamic_sidebar( 'sidebar-def' ); ?>

        <div class="widget widget-tags">
            <h3 class="widgettitle">标签</h3>
            <div class="hot-tags">
				<?php the_tags('','',''); ?>
            </div>
        </div>

        <?php
        $old_post = $GLOBALS['post'];
        global $wp_query;
        ?>
        <section class="widget widget-hot" id="J_hotPostList">
            <h3 class="widgettitle">热门软件</h3>
            <ul class="post-list">
				<?php

				$arg = array(
					'numberposts'=>5,
					'date_query'=>array('after'=>date('Y-m-d',strtotime('-2 year'))),
					//'meta_key'=>'s_os',
					//'meta_compare'=>"EXISTS",
					//'meta_value'=>'(1)',
					'category__not_in'=>2,
					'orderby'=>'meta_value_num',
					'meta_key'=>'post_views_count',
					'order'=>'DESC'
				);
				//$q_cat = '';
				if(is_category()){
					//$q_cat = '&cat='.$wp_query->get('cat');
					$arg['cat'] = $wp_query->get('cat');
				}
				$posts = get_posts($arg);

				foreach($posts as $post) :
					$GLOBALS['post'] = $post;
					?>
                    <li>
                        <a class="media-pic" href="<?php the_permalink(); ?>">
							<?php wbolt_post_thumbnail(); ?>
                        </a>
                        <div class="media-body">
                            <a class="title" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            <p class="post-meta">
								<?php echo wbolt_svg_icon('wbsico-download'); ?><em class="meta-download"><?php echo getPostMataVal('post_downs'); ?></em>
                            </p>
                        </div>
                    </li>
				<?php endforeach; ?>

            </ul>
        </section>
		<?php

		$GLOBALS['post'] = $old_post;
        ?>

		<?php
		$links_items = wb_opt('links');
		if(!empty($links_items)):
		?>
        <section class="widget widget-links">
            <h3 class="widgettitle">友情链接</h3>
            <div class="links-items">
				<?php foreach ($links_items as $item) :
					$img_url = isset($item['img']) && $item['img'] ?$item['img'] : get_template_directory_uri(). '/images/link_def.png';
					?>
                    <a href="<?php echo $item['url']; ?>"
						<?php
						if(isset($item['target']) && $item['target']){ echo 'target="_blank"';}
						if(isset($item['nofollow']) && $item['nofollow']){ echo 'rel="nofollow"';} ?>>
                        <img src="<?php echo $img_url; ?>" alt="">
                        <span><?php echo $item['name']; ?></span>
                    </a>
				<?php endforeach; ?>
            </div>
        </section>
		<?php endif; ?>

        <?php dynamic_sidebar( 'sidebar-bottom' ); ?>
		<?php echo wb_insert_ad_block('sidebar'); ?>
    </div>
</div>
