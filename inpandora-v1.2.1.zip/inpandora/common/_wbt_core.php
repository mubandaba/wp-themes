<?php
/**
 */
//获取设置数据
function wb_opt($name,$default=0){
	return class_exists('WBOptions') ? WBOptions::opt($name,$default) : '';
}
//获取广告代码
function wb_insert_ad_block($ad_name='', $box_class='adbanner-block'){
	return class_exists('WBOptions') ? WBOptions::insertAdBlock($ad_name, $box_class) : '';
}

//分页
function wbolt_the_posts_pagination( $args = array() ) {
	echo wbolt_get_the_posts_pagination( $args );
}

function wbolt_get_the_posts_pagination( $args = array() ) {
	$navigation = '';

	// Don't print empty markup if there's only one page.
	if ( $GLOBALS['wp_query']->max_num_pages > 1 ) {
		$args = wp_parse_args( $args, array(
			'mid_size'           => 5,
			'prev_text'          => _x( 'Prev', 'previous post','wbolt' ),
			'next_text'          => _x( 'Next', 'next post','wbolt' ),
			'screen_reader_text' => __( 'Posts navigation' ,'wbolt'),
		) );

		// Make sure we get a string back. Plain is the next best thing.
		if ( isset( $args['type'] ) && 'array' == $args['type'] ) {
			$args['type'] = 'plain';
		}

		// Set up paginated links.
		$links = paginate_links( $args );

		if ( $links ) {
			$navigation = wbolt_navigation_markup( $links, 'pagination', $args['screen_reader_text'] );
		}
	}

	return $navigation;
}

function wbolt_navigation_markup( $links, $class = 'posts-navigation', $screen_reader_text = '' ) {
	if ( empty( $screen_reader_text ) ) {
		$screen_reader_text = __( 'Posts navigation', 'wbolt' );
	}

	$template = '
    <a class="btn btn-load-more" id="J_loadMoreBtn">'. __('More','wbolt') . '</a>
    <div class="wb-navigation %1$s" role="navigation">
        %3$s
    </div>';

	//Add this line
	$template = apply_filters('navigation_markup_template', $template);

	return sprintf( $template, sanitize_html_class( $class ), esc_html( $screen_reader_text ), $links );
}

//处理评论区头象烂图问题
function get_ssl_avatar($avatar)
{
	$https = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 1 : 0;

	if( $https ) return;

	$avatar = preg_replace('/.*\/avatar\/(.*)\?s=([\d]+)&.*/', '<img src="https://secure.gravatar.com/avatar/$1?s=$2" class="avatar avatar-$2" height="$2" width="$2">', $avatar);
	return $avatar;
}
//add_filter('get_avatar', 'get_ssl_avatar');

function wb_def_avatar ($avatar_defaults) {
	$wb_avatar = get_template_directory_uri() . '/images/def_avatar.png';
	$avatar_defaults[$wb_avatar] = 'Wbolt';
	return $avatar_defaults;
}
add_filter( 'avatar_defaults', 'wb_def_avatar' );


//自定义菜单
class Wbolt_Walker_Nav_Menu extends Walker_Nav_Menu
{
	function start_lvl( &$output, $depth = 0, $args = array() ) {
		$indent = str_repeat("\t", $depth);
		$output .= "\n$indent<div class=\"sub-menu lv-$depth\">\n<ul>";
	}

	function end_lvl( &$output, $depth = 0, $args = array() ) {
		$indent = str_repeat("\t", $depth);
		$output .= "$indent</ul>\n</div>";
	}
}

//自定义菜单
class Wbolt_Walker_Nav_Menu_m extends Walker_Nav_Menu
{
	function start_lvl( &$output, $depth = 0, $args = array() ) {
		$indent = str_repeat("\t", $depth);
		$output .= "\n$indent".($depth == 0 ? '<i class="nav-arrow"></i>':'')."<div class=\"sub-menu-m lv-$depth\"><ul>";
	}

	function end_lvl( &$output, $depth = 0, $args = array() ) {
		$indent = str_repeat("\t", $depth);
		$output .= "$indent</ul>\n</div>";
	}
}

//移除菜单的多余CSS选择器
add_filter('nav_menu_css_class', 'my_css_attributes_filter', 100, 1);
add_filter('nav_menu_item_id', 'my_css_attributes_filter', 100, 1);
add_filter('page_css_class', 'my_css_attributes_filter', 100, 1);
function my_css_attributes_filter($var) {
	return is_array($var) ? array_intersect($var, array('menu-item-has-children')) : '';
}

//面包屑
function wb_breadcrumbs( $current_page = false)
{
	$delimiter = '<i>&gt;</i>';
	$name = __('Home','wbolt');
	$currentBefore = '<strong>';
	$currentAfter = '</strong>';

	if (!is_home() && !is_front_page() || is_paged()) {

		echo '<div class="bread-crumbs"><div class="inner pw">';

		global $post;
		$home = home_url() ;
		echo '<a href="' . $home . '" rel="home">' . $name . '</a> ' . $delimiter . ' ';

		if ($current_page) {
			echo $currentBefore;
			echo $current_page;
			echo $currentAfter;

		}elseif (is_category()) {
			global $wp_query;
			$cat_obj = $wp_query->get_queried_object();
			$thisCat = $cat_obj->term_id;
			$thisCat = get_category($thisCat);
			$parentCat = get_category($thisCat->parent);

			if ($thisCat->parent != 0) echo(get_category_parents($parentCat, TRUE, ' ' . $delimiter . ' '));
			echo $currentBefore;
			single_cat_title();
			echo $currentAfter;

		} elseif (is_day()) {
			echo '' . get_the_time('Y') . ' ' . $delimiter . ' ';
			echo '' . get_the_time('F') . ' ' . $delimiter . ' ';
			echo $currentBefore . get_the_time('d') . $currentAfter;

		} elseif (is_month()) {
			echo '' . get_the_time('Y') . ' ' . $delimiter . ' ';
			echo $currentBefore . get_the_time('F') . $currentAfter;

		} elseif (is_year()) {
			echo $currentBefore . get_the_time('Y') . $currentAfter;

		} elseif (is_single()) {
			$cat = get_the_category();

			if(isset($cat[0]) && $cat[0] -> category_parent){
				$cet_ret = get_category_parents($cat[0] -> category_parent, TRUE, ' ' . $delimiter . ' ');
				if(!is_wp_error($cet_ret))echo $cet_ret;
			}

			foreach ($cat as $key => $cats){
				if($key > 0) echo ' | ';
				echo '<a href='.get_category_link($cats -> term_id) . '>' . $cats -> name . '</a>';
			}

			if($cat) echo ' ' . $delimiter . ' ';

			echo $currentBefore;
			the_title();
			echo $currentAfter;

		} elseif (is_page() && !$post->post_parent) {
			echo $currentBefore;
			the_title();
			echo $currentAfter;

		} elseif (is_page() && $post->post_parent) {
			$parent_id = $post->post_parent;
			$breadcrumbs = array();
			while ($parent_id) {
				$page = get_post($parent_id);
				$breadcrumbs[] = '' . get_the_title($page->ID) . '';
				$parent_id = $page->post_parent;
			}
			$breadcrumbs = array_reverse($breadcrumbs);
			foreach ($breadcrumbs as $crumb) echo $crumb . ' ' . $delimiter . ' ';
			echo $currentBefore;
			the_title();
			echo $currentAfter;

		} elseif (is_search()) {
			echo $currentBefore . __('Search Results','wbolt'). ' &#39;' . get_search_query() . '&#39;' . $currentAfter;

		} elseif (is_tag()) {
			echo $currentBefore;
			single_tag_title();
			echo $currentAfter;

		} elseif (is_author()) {
			global $author;
			$userdata = get_userdata($author);
			echo $currentBefore. __('Post','wbolt') . $userdata->display_name . $currentAfter;

		} elseif (is_404()) {
			echo $currentBefore . '404' . $currentAfter;
		}

		if (get_query_var('paged')) {
			echo $currentBefore.'(';
			echo __('Page','wbolt') . ' ' . get_query_var('paged');
			echo ')'.$currentAfter;
		}

		echo '</div></div>';

	}
}

//详情通用变量
function getPostMataVal($key,$default=0){
	$postId = get_the_ID();
	if(!$postId)return $default;
	$val = get_post_meta($postId,$key,true);
	return $val?$val:$default;
}

//浏览数
function getPostViews($postID){
	$count_key = 'post_views_count';
	$count = get_post_meta($postID, $count_key, true);
	if($count==''){
		delete_post_meta($postID, $count_key);
		add_post_meta($postID, $count_key, '0');
		return '0';
	}
	return $count;
}

function setPostViews($postID) {
	$count_key = 'post_views_count';
	$count = get_post_meta($postID, $count_key, true);
	if($count==''){
		$count = 0;
		delete_post_meta($postID, $count_key);
		add_post_meta($postID, $count_key, '0');
	}else{
		$count++;
		update_post_meta($postID, $count_key, $count);
	}
}


//获取一级分类菜单ID
function get_category_root_id($cat)
{
	$this_category = get_category($cat);
	while($this_category->category_parent)
	{
		$this_category = get_category($this_category->category_parent);
	}
	return $this_category->term_id;
}
function get_article_category_ID()
{
	$category = get_the_category();
	return $category[0]->cat_ID;
}


//缩略图
/**
 * Display an optional post thumbnail.
 */
function wbolt_post_thumbnail() {
	if ( post_password_required() || is_attachment()) {
		return;
	}

	if(has_post_thumbnail() && get_the_post_thumbnail()!==''){
		the_post_thumbnail( 'post-thumbnail', array( 'alt' => get_the_title() ) );
		return;
	}

	//无设定默认图尝试获取文章第一张图
	if( $img = wbolt_catch_first_image()){
		if($img['src']){

			echo '<img src="'.$img['src'].'" alt="">';
			return;
		}
	}

	//主题设置默认占位图
	if( wb_opt('def_img_url') ){
		echo  '<img src="'. wb_opt('def_img_url') .'" alt="">';
		return;
	}

	//都没有，读取主题默认图
	echo '<img src="'. get_template_directory_uri() .'/images/wbolt_def_cover.png" alt="">';
}

//抽取文章第一张图
function wbolt_catch_first_image() {
	global $post;
	$first_img = array();

	if(preg_match_all('#<img[^>]+>#is',$post->post_content,$match)){

		$match_frist = $match[0][0];


		if($match_frist) :
			preg_match('#src=[\'"]([^\'"]+)[\'"]#',$match_frist,$src);
			preg_match('#width=[\'"]([^\'"]+)[\'"]#',$match_frist,$width);
			preg_match('#height=[\'"]([^\'"]+)[\'"]#',$match_frist,$height);

			$first_img['src'] = $src ? $src[1] : '';
			$first_img['width'] = $width ? $width[1] : '';
			$first_img['height'] = $height ? $height[1] : '';

		endif;
	}else{
		$first_img = 0;
	}
	return $first_img;
}

function wbolt_content_image_sizes_attr($sizes, $size)
{
	$width = $size[0];

	880 <= $width && $sizes = '(max-width: 768px) calc(100vw - 40px), (max-width: 1200px) 550px, (max-width: 1400px) 730px, 880px';

	return $sizes;
}

add_filter('wp_calculate_image_sizes', 'wbolt_content_image_sizes_attr', 10, 2);

/**
 * Add custom image sizes attribute to enhance responsive image functionality
 * for post thumbnails
 */
function wbolt_post_thumbnail_sizes_attr($attr, $attachment, $size)
{
	if(is_admin()) return $attr;

	$attr['data-src'] = $attr['src'];

	$attr['src'] = wb_opt('def_img_url') ? wb_opt('def_img_url') : get_template_directory_uri() . '/images/wbolt_def_cover.png';

	$attr['data-srcset'] = isset($attr['srcset']) ? $attr['srcset'] : '';
	$attr['srcset'] = '';

	if ('post-thumbnail' === $size) {
		$attr['sizes'] = '(max-width: 1200) 300px, (max-width: 1400) 250px, 300px';
	}

	return $attr;
}

add_filter('wp_get_attachment_image_attributes', 'wbolt_post_thumbnail_sizes_attr', 10, 3);


/***
 * 列表文章概要字数重置
 */
function wb_excerpt_length($length){
	return $length;
}
add_filter('excerpt_length', 'wb_excerpt_length');

function wb_excerpt_more(){
	return  '...';
}
add_filter('excerpt_more','wb_excerpt_more');

function postTime(){
	$time = get_post_time( 'G', true, null );
	//$time = $post->post_date;
	$diff = time()-$time;
	if($diff<DAY_IN_SECONDS){
		echo  human_time_diff($time). ' '. _x('Before','post time','wbolt');
	}else{
		echo the_time('Y.n.j');
	}

}

/**
 * 插入svg icon
 * e.g. wbolt_svg_icon('icon-time');
 */
function wbolt_svg_icon($name,$size_class=''){
	return '<svg class="wb-icon '.$name. ' '.$size_class.'"><use xlink:href="#'.$name.'"></use></svg>';
}