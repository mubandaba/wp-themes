<?php
/**
 * Template Name: newest_page
 *
 * @package WordPress
 * @subpackage Inpandora
 * @since Wbolt 1.0
 */

get_header(); ?>

<div class="main">
    <div class="title-floor">
        <h3>最新更新</h3>
    </div>

    <?php

    $paged = isset($wp->query_vars['paged']) ? $wp->query_vars['paged']:'';
	$arg = array( 'post_type'=>'post', 'orderby'=>'post_date', 'paged'=> $paged);//'category__not_in'=>explode(',',$homeFlID),
	query_posts($arg);

	?>

	<?php if ( have_posts() ) : ?>

    <div class="articles-list<?php if(wp_is_mobile()) echo ' with-list-mode list-mode-b'; ?>" id="J_postList">
		<?php
		// Start the loop.
		$_paged = $wp->query_vars['paged'];

		$list_idx = 0;
		$adIndex = rand(3,8);
		$hasListAD = wb_opt('ads.list.type');

		while ( have_posts() ) : the_post();

			get_template_part( 'template-parts/content',get_post_format());

			if($hasListAD && $list_idx == $adIndex){
				get_template_part( 'template-parts/content', 'list-ad' );
			}
			$list_idx++;

			// End the loop.
		endwhile;

		// If no content, include the "No posts found" template.
		else :
			get_template_part( 'template-parts/content-none', 'none' );

		endif;
		?>
    </div>
    <div class="loading-bar"></div>
	<?php
	// Previous/next page navigation.
	wbolt_the_posts_pagination();
	?>
</div>

<?php get_footer(); ?>
