<?php /**
 * WBolt 版本信息
 **/
?>
<div class="sc-body sc-version">
    <table class="wbs-info-table">
        <tbody>
        <tr>
            <th class="w8em row">主题名称</th>
            <td>
				<?php echo $pd_name; ?>
            </td>
        </tr>
        <tr>
            <th class="row">当前版本</th>
            <td>
                <strong><?php echo WB_THEMES_VER; ?></strong>

				<?php if(wb_opt('auto_update')){

					echo '<script type="text/javascript" src="https://www.wbolt.com/wb-api/v1/themes/checkver?code='.WB_THEMES_CODE.'&ver='.WB_THEMES_VER.'"></script>';

				}?>
            </td>
        </tr>
        <tr>
            <th class="row">自动检查</th>
            <td>
                <label>
                    <input class="wb-switch" type="checkbox" value="1" name="<?php echo $opt_name; ?>[auto_update]" <?php if(wb_opt('auto_update')) echo ' checked="checked"'; ?> data-value="<?php _opt('auto_update'); ?>"> <span class="description">开启后系统将自动检测最新版本</span>
                </label>
            </td>
        </tr>
        </tbody>
    </table>
</div>