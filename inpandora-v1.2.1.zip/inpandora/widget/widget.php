<?php
/**
*
*/

class Wb_Widget
{
    function __construct()
    {
        add_action('widgets_init',array(__CLASS__,'widgets_init'));
    }

    public static function widgets_init(){
        //注册装载小工具的区域
        register_sidebar( array(
            'name'          => __( '边栏上部', 'wbolt' ),
            'id'            => 'sidebar-def',
            'description'   => __( '可将需要的小工具拖动至此范围，即可在则栏显示', 'wbolt' ),
            'before_widget' => '<section id="%1$s" class="spmg-bottom widget %2$s">',
            'after_widget'  => '</section>'
        ) );
        register_sidebar( array(
            'name'          => __( '边栏低部', 'wbolt' ),
            'id'            => 'sidebar-bottom',
            'description'   => __( '可将需要的小工具拖动至此范围，即可在则栏显示', 'wbolt' ),
            'before_widget' => '<section id="%1$s" class="spmg-bottom widget %2$s">',
            'after_widget'  => '</section>'
        ) );
        register_sidebar( array(
            'name'          => __( '文章详情底部', 'wbolt' ),
            'id'            => 'sidebar-content-bottom',
            'description'   => __( '可将需要的小工具拖动至此范围，即可文章详情页底部显示', 'wbolt' ),
            'before_widget' => '<section id="%1$s" class="wbolt-plugin-area %2$s">',
            'after_widget'  => '</section>'
        ) );

        wp_register_sidebar_widget('wbolt-related-posts', '#相关推荐#', array(__CLASS__,'wb_related_posts'),array('description'=>'列出相关推荐文章列表，建议在详情页内容底部展示'));
    }
}
new Wb_Widget();