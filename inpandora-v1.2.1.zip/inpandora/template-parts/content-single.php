<?php
/**
 * The template part for displaying single posts
 *
 * @package WordPress
 * @subpackage Inpandora
 * @since Wbolt 1.0
 */
?>

<article class="article-detail">
	<?php //详情页广告位 S ?>
	<?php echo wb_insert_ad_block('detail_under_title'); ?>

	<?php
	the_content();
	?>

	<?php echo wb_insert_ad_block('detail_content_btm'); ?>
</article>