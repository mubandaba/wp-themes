<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after
 *
 * @package WordPress
 * @subpackage Inpandora
 * @since Wbolt 1.0
 */
?>
</div>

<footer class="footer">
    <?php if (has_nav_menu( 'social' ) ) : ?>
        <nav class="nav-footer">
            <?php
            wp_nav_menu( array(
            'theme_location' => 'social',
            'menu_class'     => 'nav-ft',
            'menu_id'     => 'J_footerNav',
            'container'     => ''
            ) );
            ?>
        </nav>
    <?php endif; ?>

	<div class="copyright">
		<?php
		/**
			* Fires before the Wbolt footer text for footer customization.
			*
			* @since Wbolt 1.0
			*/
		do_action( 'wbolt_credits' );
		?>

        <?php if(wb_opt('copyright_footer')): ?>
        <div class="ib">
            <?php echo wb_opt('copyright_footer'); ?>
        </div>
        <?php else: ?>
            <span class="ib">Copyright &copy; <?php echo date('Y',time());?> <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></span>
            <span class="ib sppd-h">All Rights Reserved</span>
        <?php endif; ?>
        <span class="ib pwb" data-theme-code="<?php echo WB_THEMES_CODE; ?>">Design by <a href="https://www.wbolt.com?ref=<?php echo WB_THEMES_CODE; ?>" target="_blank">闪电博</a></span>
	</div>
</footer>


<?php wp_footer(); ?>

<a class="bktop" id="J_backTop" href="javascript:;" rel="nofollow" title="返回页顶"><svg xmlns="http://www.w3.org/2000/svg" width="23" height="12"><path fill-rule="evenodd" d="M21.58 12L11.5 2.33 1.42 12 0 10.63 10.79.28c.4-.37 1.03-.37 1.42 0L23 10.63 21.58 12z"/></svg></a>

<?php echo do_shortcode('[wb_custom_footer_code]') ?>

</body>
</html>
