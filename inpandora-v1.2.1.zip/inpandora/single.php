<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Inpandora
 * @since Wbolt 1.0
 */
$GLOBALS['container-custom'] = 'container-single';

if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
	wp_enqueue_script( 'comment-reply' );
}

the_post();

get_header();

//统计views
setPostViews(get_the_ID());

?>
<div class="main main-detail">
	<?php if (function_exists('wb_breadcrumbs')) wb_breadcrumbs(); ?>

    <header class="article-header">
		<?php the_title( '<h1 class="title-detail">', '</h1>' ); ?>

        <div class="post-metas">
            <span class="meta-item meta-author">
                <?php echo wbolt_svg_icon('wbsico-author'); ?>
                <em><?php the_author(); ?></em>
            </span>
            <span class="meta-item meta-date">
                <?php echo wbolt_svg_icon('wbsico-time'); ?>
                <em><?php the_time('M d, Y') ?></em>
            </span>
            <span class="meta-item meta-date">
                <?php echo wbolt_svg_icon('wbsico-download'); ?>
                <em><?php echo getPostMataVal('post_downs'); ?></em>
            </span>
        </div>
    </header>

    <div class="content pw-dt">
		<?php
			get_template_part( 'template-parts/content', 'single' );
		?>

		<?php get_sidebar(); ?>
    </div>

	<?php dynamic_sidebar( 'sidebar-content-bottom' ); ?>

	<?php
	if ( comments_open() || get_comments_number() ) {
		comments_template();
	}
	?>
</div>

<?php get_footer(); ?>
