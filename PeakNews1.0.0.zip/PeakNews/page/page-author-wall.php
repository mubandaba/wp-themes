<?php
/*
Template Name: 作者墙
*/
?>
<?php get_header(); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8">
            <main class="main-content-area">
                <article class="post post-single">
                    <header class="post-header">
                        <h1 class="post-title"><?php the_title(); ?></h1>
                    </header>
                    <div class="post-content"></div>
                </article>
                <div class="row">
                    <?php
                    $blogusers = get_users(['role__in' => ['administrator', 'editor', 'author']]);
                    foreach ($blogusers as $user) { ?>
                        <div class="col-lg-6 col-md-12 author-archive-card-wrap">
                            <a href="/author/apurba/" class="author-archive-card">
                                <div class="item-card-inner text-center">
                                    <div class="avatar-wrap loading-bg">
                                        <?php
                                        $user_gravatar_url = 'http://www.gravatar.com/avatar/' . md5($user->user_email) . '?s=100';
                                        ?>
                                        <img data-src="<?php echo $user_gravatar_url; ?>" alt="name" class="avatar lazy">
                                    </div>
                                    <div class="author-info">
                                        <div class="author-name h3"><?php echo esc_html($user->display_name); ?></div>
                                        <?php if (esc_html($user->roles[0]) == "administrator") { ?>
                                            <div class="post-count">站长</div>
                                        <?php } else { ?>
                                            <div class="post-count">用户</div>
                                        <?php } ?>
                                        <div class="bio"><?php echo esc_html($user->description); ?></div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php } ?>
                </div>
            </main>
        </div>
        <?php get_sidebar(); ?>
    </div>
</div>
<?php get_footer(); ?>