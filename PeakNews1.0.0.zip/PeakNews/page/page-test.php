<?php
/*
Template Name: test
*/
?>
<?php get_header(); ?>

<?php get_footer(); ?>