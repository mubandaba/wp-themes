<?php
function bit_add_menu_setup()
{
    register_nav_menus([
        'head-menu' => __('头部菜单'),
        'phone-menu' => __('手机菜单'),
        'bottom-menu' => __('底部菜单'),
    ]);
}
add_action('after_setup_theme', 'bit_add_menu_setup');

add_action('wp_ajax_data_fetch', 'data_fetch');
add_action('wp_ajax_nopriv_data_fetch', 'data_fetch');
function data_fetch()
{
    $the_query = new WP_Query(array('posts_per_page' => -1, 's' => esc_attr($_POST['keyword']), 'post_type' => 'post'));
    if ($the_query->have_posts()) :
        while ($the_query->have_posts()) : $the_query->the_post();
?>
            <div class="search-results-item">
                <a href="<?php the_permalink();
                            ?>">
                    <div class="content">
                        <h3 class="title h5"><?php the_title();
                                                ?></h3>
                        <div class="meta">
                            <span><?php echo get_the_category()[0]->cat_name;
                                    ?></span>
                            -
                            <time><?php the_time('Y-n-j');
                                    ?></time>
                        </div>
                    </div>
                </a>
            </div>
<?php endwhile;
    endif;
    die();
    wp_reset_postdata();
}

register_sidebar(array(
    'name' => __('侧边栏', 'Bing'),
    'id' => 'sidebar',
    'before_widget' => '<div class="widget">',
    'after_widget' => '</div>',
    'before_title' => '<h3 class="widget-title text-upper">',
    'after_title' => '</h3>'
));
