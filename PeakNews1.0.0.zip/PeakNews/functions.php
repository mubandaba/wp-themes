<?php
require get_template_directory() . '/function/bittheme.php';