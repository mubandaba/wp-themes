<?php get_header(); ?>
<?php if (have_posts()) : the_post();
    update_post_caches($posts); ?>
    <?php setPostViews(get_the_ID()); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <main class="main-content-area">
                    <article class="post post-single">
                        <header class="post-header">
                            <?php if (has_tag()) { ?>
                                <div class="tag-wrap">
                                    <?php
                                    $posttags = get_the_tags();
                                    if ($posttags) {
                                        foreach ($posttags as $tag) {
                                            $tag_color = get_term_meta($tag->term_taxonomy_id, 'classification-color', true);
                                            if (empty(get_term_meta($tag->term_taxonomy_id, 'classification-color', true))) {
                                                $tag_color = '#1a202b';
                                            } else {
                                                $tag_color = get_term_meta($tag->term_taxonomy_id, 'classification-color', true);
                                            };
                                    ?>
                                            <a href="<?php echo get_tag_link($tag); ?>" class="tag tag-pill" style="--t-color: <?php echo $tag_color; ?>;"><?php echo $tag->name; ?></a>
                                    <?php }
                                    } ?>
                                </div>
                            <?php } ?>
                            <h1 class="post-title"><?php the_title(); ?></h1>
                            <div class="post-meta">
                                <span class="author">作者：<?php the_author(); ?></span>
                                <time class="pub-date" datetime="<?php the_time('Y-n-j'); ?>"><?php the_time('Y年n月j日'); ?></time>
                                <span class="read-time"><?php comments_popup_link('0 条评论', '1 条评论', '% 条评论', '', '评论已关闭'); ?></span>
                                -
                                <span class="post-views"><?php echo getPostViews(get_the_ID()); ?> 人阅读</span>
                            </div>
                        </header>
                        <div class="post-img-wrap loading-bg">
                            <img class="post-img lazy" data-src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>">
                        </div>
                        <div class="post-content">
                            <?php the_content(); ?>
                        </div>
                    </article>
                </main>
                <div class="share-wrap">
                    <div class="share-title h5 text-center">分享本文</div>
                    <div class="share-links flex">
                        <a class="qr-code-sharing" data-fancybox data-animation-duration="300" data-src="#qr-code-sharing" href="javascript:;" title="二维码分享">
                            <svg t="1599368185635" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="9321" width="48" height="48">
                                <path d="M853.333333 533.333333a32 32 0 0 1 64 0v266.666667c0 64.8-52.533333 117.333333-117.333333 117.333333H224c-64.8 0-117.333333-52.533333-117.333333-117.333333V256c0-64.8 52.533333-117.333333 117.333333-117.333333h277.333333a32 32 0 0 1 0 64H224a53.333333 53.333333 0 0 0-53.333333 53.333333v544a53.333333 53.333333 0 0 0 53.333333 53.333333h576a53.333333 53.333333 0 0 0 53.333333-53.333333V533.333333z m-42.058666-277.333333l-89.792-95.402667a32 32 0 0 1 46.613333-43.861333l140.544 149.333333C927.861333 286.485333 913.376 320 885.333333 320H724.704C643.029333 320 576 391.210667 576 480v192a32 32 0 1 1-64 0V480c0-123.296 94.784-224 212.704-224h86.570667z" p-id="9322"></path>
                            </svg>
                        </a>
                        <div style="display: none;" id="qr-code-sharing" class="animated-modal text-center p-5">
                            <h3>微信分享</h3>
                            <p class="mb-0"><img src="https://wenhairu.com/static/api/qr/?size=300&text=<?php the_permalink(); ?>" style="width: 100%"></p>
                        </div>
                    </div>
                </div>
                <?php if (wpzt('bottom-of-content-page')['switch'] == true) { ?>
                    <div class="ad-spot ad-wrap-content-area text-center">
                        <div class="ad-spot-title"><?php echo wpzt('bottom-of-content-page')['headline']; ?></div>
                        <div class="ad-container">
                            <?php echo wpzt('bottom-of-content-page')['custom-area']; ?>
                        </div>
                    </div>
                <?php } ?>
                <div class="about-author-wrap">
                    <div class="author-card">
                        <div class="avatar-wrap loading-bg">
                            <a href="<?php echo get_author_posts_url(get_the_author_meta('ID'), get_the_author_meta('user_nicename')); ?>" title="<?php echo the_author_meta('nickname'); ?>">
                                <?php
                                $user_gravatar_url = 'http://www.gravatar.com/avatar/' . md5($user->user_email) . '?s=100';
                                ?>
                                <img data-src="<?php echo $user_gravatar_url; ?>" alt="name" class="avatar lazy">
                            </a>
                        </div>
                        <div class="author-info">
                            <h3 class="name h5"><?php the_author_posts_link(); ?></a></h3>
                            <div class="bio"><?php the_author_description(); ?></div>
                            <div class="permalink"><a href="<?php echo get_author_posts_url(get_the_author_meta('ID'), get_the_author_meta('user_nicename')); ?>">查看更多TA的文章 <svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1.5 13.5h17.79l-5.445 6.54a1.502 1.502 0 102.31 1.92l7.5-9a1.78 1.78 0 00.135-.226c0-.075.075-.12.105-.195A1.5 1.5 0 0024 12a1.499 1.499 0 00-.105-.54c0-.075-.075-.12-.105-.195a1.766 1.766 0 00-.135-.225l-7.5-9A1.499 1.499 0 0015 1.5a1.5 1.5 0 00-1.155 2.46l5.445 6.54H1.5a1.5 1.5 0 100 3z" /></svg></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="related-post-wrap">
                    <div class="row">
                        <div class="col-12">
                            <h3 class="section-title">相关文章</h3>
                        </div>
                        <?php
                        if (is_single()) :
                            global $post;
                            $categories = get_the_category();
                            foreach ($categories as $category) :
                        ?>
                                <?php
                                $posts = get_posts('numberposts=3&category=' . $category->term_id . '&exclude=' . get_the_ID());
                                foreach ($posts as $post) :
                                ?>
                                    <div class="col-lg-4 col-md-6 col-sm-6">
                                        <article class="post post-style-one">
                                            <a href="<?php the_permalink(); ?>" aria-label="<?php the_title(); ?>">
                                                <div class="post-img-wrap loading-bg">
                                                    <img class="post-img lazy" data-src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>">
                                                </div>
                                            </a>
                                            <div class="post-content">
                                                <div class="tag-wrap">
                                                    <div class="tag tag-small" style="background-color: <?php $term = get_category_by_slug(get_the_category()[0]->slug);
                                                                                                        echo get_term_meta($term->term_id, 'classification-color', true); ?>;width: fit-content;padding: 4px;"><?php the_category(','); ?></div>
                                                </div>
                                                <h2 class="post-title h4"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                                <div class="post-meta">
                                                    <time class="pub-date" datetime="<?php the_time('Y-n-j'); ?>"><?php the_time('Y年n月j日'); ?></time>
                                                    <span class="read-time"><?php comments_popup_link('0 条评论', '1 条评论', '% 条评论', '', '评论已关闭'); ?></span>
                                                </div>
                                            </div>
                                        </article>
                                    </div>
                                <?php endforeach; ?>
                        <?php
                            endforeach;
                        endif; ?>
                    </div>
                </div>
                <div class="prev-next-wrap">
                    <div class="row">
                        <?php
                        $next_post = get_next_post();
                        if ($values = get_post_meta($next_post->ID, 'thumbnail', true)) {
                            $values = get_post_custom_values("thumbnail");
                            $post_thumbnail_src = $values[0];
                        } elseif (has_post_thumbnail()) {
                            $thumbnail_src = wp_get_attachment_image_src(get_post_thumbnail_id($next_post->ID), 'full');
                            $post_thumbnail_src = $thumbnail_src[0];
                        } else {
                            $post_thumbnail_src = '';
                            ob_start();
                            ob_end_clean();
                            $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $next_post->post_content, $matches);
                            $post_thumbnail_src = $matches[1][0];
                            if (empty($post_thumbnail_src)) {
                                $post_thumbnail_src = get_bloginfo('template_url') . "/static/images/no-image.png";
                            }
                        };
                        if (!empty($next_post)) : ?>
                            <div class="col-md-6">
                                <div class="post post-compact next-post has-img">
                                    <div class="post-img-wrap loading-bg">
                                        <img class="post-img lazy" data-src="<?php echo $post_thumbnail_src; ?>" alt="<?php the_title(); ?>">
                                    </div>
                                    <a href="<?php echo get_permalink($next_post->ID); ?>" aria-label="<?php the_title(); ?>" class="overlay-link"></a>
                                    <div class="post-content">
                                        <div class="label">
                                            <svg width="24" height="25" viewBox="0 0 24 25" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M22.5 11H4.71l5.445-6.54a1.5 1.5 0 10-2.31-1.92l-7.5 9c-.05.072-.096.147-.135.226 0 .075-.075.12-.105.195A1.5 1.5 0 000 12.5a1.5 1.5 0 00.105.54c0 .075.075.12.105.195.04.078.084.154.135.225l7.5 9A1.498 1.498 0 009 23a1.5 1.5 0 001.155-2.46L4.71 14H22.5a1.5 1.5 0 100-3z" />
                                            </svg>上一篇</div>
                                        <h2 class="post-title h4"><?php echo $next_post->post_title; ?></h2>
                                        <div class="post-meta">
                                            <time class="pub-date" datetime="<?php the_time('Y-n-j'); ?>"><?php the_time('Y年n月j日'); ?></time>
                                            <span class="read-time"><?php comments_popup_link('0 条评论', '1 条评论', '% 条评论', '', '评论已关闭'); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php
                        $prev_post = get_previous_post();
                        if ($values = get_post_meta($prev_post->ID, 'thumbnail', true)) {
                            $values = get_post_custom_values("thumbnail");
                            $post_thumbnail_src = $values[0];
                        } elseif (has_post_thumbnail()) {
                            $thumbnail_src = wp_get_attachment_image_src(get_post_thumbnail_id($prev_post->ID), 'full');
                            $post_thumbnail_src = $thumbnail_src[0];
                        } else {
                            $post_thumbnail_src = '';
                            ob_start();
                            ob_end_clean();
                            $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $prev_post->post_content, $matches);
                            $post_thumbnail_src = $matches[1][0];
                            if (empty($post_thumbnail_src)) {
                                $post_thumbnail_src = get_bloginfo('template_url') . "/static/images/no-image.png";
                            }
                        };
                        if (!empty($prev_post)) : ?>
                            <div class="col-md-6">
                                <div class="post post-compact previous-post has-img">
                                    <div class="post-img-wrap loading-bg">
                                        <img class="post-img lazy" data-src="<?php echo $post_thumbnail_src; ?>" alt="<?php the_title(); ?>">
                                    </div>
                                    <a href="<?php echo get_permalink($prev_post->ID); ?>" aria-label="<?php the_title(); ?>" class="overlay-link"></a>
                                    <div class="post-content">
                                        <div class="label">下一篇
                                            <svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M1.5 13.5h17.79l-5.445 6.54a1.502 1.502 0 102.31 1.92l7.5-9a1.78 1.78 0 00.135-.226c0-.075.075-.12.105-.195A1.5 1.5 0 0024 12a1.499 1.499 0 00-.105-.54c0-.075-.075-.12-.105-.195a1.766 1.766 0 00-.135-.225l-7.5-9A1.499 1.499 0 0015 1.5a1.5 1.5 0 00-1.155 2.46l5.445 6.54H1.5a1.5 1.5 0 100 3z" />
                                            </svg>
                                        </div>
                                        <h2 class="post-title h4"><?php echo $prev_post->post_title; ?></h2>
                                        <div class="post-meta">
                                            <time class="pub-date" datetime="<?php the_time('Y-n-j'); ?>"><?php the_time('Y年n月j日'); ?></time>
                                            <span class="read-time"><?php comments_popup_link('0 条评论', '1 条评论', '% 条评论', '', '评论已关闭'); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <!--<div class="comment-wrap">-->
                <!--    <h3>评论区</h3>-->
                <!--</div>-->
            </div>
            <?php get_sidebar(); ?>
        </div>
    </div>
<?php endif; ?>
<?php get_footer(); ?>