<?php
if (!class_exists('EDD_Theme_Updater_Admin')) {
    include(dirname(__FILE__) . '/theme-updater-admin.php');
}
$updater = new EDD_Theme_Updater_Admin(
    $config = array(
        'remote_api_url' => 'https://www.wpbit.cn',
        'item_name' => 'PeakNews',
        'theme_slug' => 'peaknews',
        'version' => wp_get_theme()->get('Version'),
        'author' => wp_get_theme()->get('Author'),
        'item_id' => '850',
    ),
    $strings = array(
        'theme-license' => __('主题授权', 'edd-theme-updater'),
        'enter-key' => __('输入主题授权码。', 'edd-theme-updater'),
        'license-key' => __('授权码', 'edd-theme-updater'),
        'license-action' => __('授权操作', 'edd-theme-updater'),
        'deactivate-license' => __('停用授权', 'edd-theme-updater'),
        'activate-license' => __('激活授权', 'edd-theme-updater'),
        'status-unknown' => __('授权状态未知。', 'edd-theme-updater'),
        'renew' => __('续费？', 'edd-theme-updater'),
        'unlimited' => __('无限的', 'edd-theme-updater'),
        'license-key-is-active' => __('授权码处于激活状态。', 'edd-theme-updater'),
        'expires%s' => __('到期 %s.', 'edd-theme-updater'),
        'expires-never' => __('终身授权。', 'edd-theme-updater'),
        '%1$s/%2$-sites' => __('你有 %1$s / %2$s 网站已激活。', 'edd-theme-updater'),
        'license-key-expired-%s' => __('授权码已过期 %s.', 'edd-theme-updater'),
        'license-key-expired' => __('授权码已过期。', 'edd-theme-updater'),
        'license-keys-do-not-match' => __('授权码不匹配。', 'edd-theme-updater'),
        'license-is-inactive' => __('授权处于未激活状态。', 'edd-theme-updater'),
        'license-key-is-disabled' => __('授权码已禁用。', 'edd-theme-updater'),
        'site-is-inactive' => __('站点处于非活动状态。', 'edd-theme-updater'),
        'license-status-unknown' => __('授权状态未知。', 'edd-theme-updater'),
        'update-notice' => __("更新此主题将丢失您所做的任何自定义设置“取消”停止，“确定”更新。", 'edd-theme-updater'),
        'update-available' => __('<strong>%1$s %2$s</strong> 这个新版本已经正式发布。 <a href="%3$s" class="thickbox" title="%4s">查看更新内容</a> 或者 <a href="%5$s"%6$s>立即更新</a>.', 'edd-theme-updater'),
    )
);