<?php
if (class_exists('CSF')) {
    $prefix = 'taxonomy_options';
    CSF::createTaxonomyOptions($prefix, array(
        'taxonomy' => 'category',
        'data_type' => 'unserialize',
    ));

    CSF::createSection($prefix, array(
        'fields' => array(
            array(
                'id' => 'classification-color',
                'type' => 'color',
                'title' => '分类颜色',
                'default' => '#1a202b'
            ),
        )
    ));
}
