<?php
if (class_exists('CSF')) {

    CSF::createWidget('wpzt_article_list', array(
        'title' => 'WPZT - 文章列表',
        'classname' => 'csf-widget-classname',
        'fields' => array(
            array(
                'id' => 'headline',
                'type' => 'text',
                'title' => '大标题',
            ),
            array(
                'id' => 'article-sorting',
                'type' => 'select',
                'title' => '文章排序',
                'placeholder' => '选择一个文章排序',
                'options' => array(
                    'author' => '发表作者',
                    'date' => '日期',
                    'title' => '标题',
                ),
                'default' => 'date',
            ),
            array(
                'id' => 'number-of-articles',
                'type' => 'slider',
                'title' => '文章数量',
                'min' => 1,
                'max' => 8,
                'step' => 1,
                'unit' => '篇',
                'default' => 4,
            ),
        )
    ));

    if (!function_exists('wpzt_article_list')) {
        function wpzt_article_list($args, $instance)
        {
            echo $args['before_widget'];
            echo '
                                <h3 class="widget-title text-upper">' . $instance['headline'] . '</h3>
                                <div class="widget-content">
            ';
            query_posts(array(
                'showposts' => $instance['number-of-articles'],
                'orderby' => $instance['article-sorting'],
            ));
            if (have_posts()) : while (have_posts()) : the_post();
                    echo '
                                    <article class="post post-style-two flex">
                                        <a href="' . get_the_permalink() . '" aria-label="Autumn is a second spring when every leaf is a flower">
                                            <div class="post-img-wrap loading-bg">
                                                <img class="post-img lazy" data-src="
            ';
                    echo post_thumbnail_src();
                    echo '
            " alt="<?php the_title(); ?>">
                                            </div>
                                        </a>
                                        <div class="post-content">
                                            <div class="tag-wrap">
                                                <div class="tag tag-small" style="background-color:
            ';
                    $term = get_category_by_slug(get_the_category()[0]->slug);
                    echo get_term_meta($term->term_id, 'classification-color', true);
                    echo '
            ;width: fit-content;padding: 4px;">
            ';
                    foreach ((get_the_category()) as $category) {
                        echo '
                                                    <a href="' . $cat_links = get_category_link($category->term_id) . '" rel="category tag">' . $category->name . '</a>
                ';
                    };
                    echo '
                                                </div>
                                            </div>
                                             <h2 class="post-title h5"><a href="' . get_the_permalink() . '">' . get_the_title() . '</a></h2>
                                            <div class="post-meta">
                                                <time class="pub-date" datetime="' . get_the_time('Y-n-j') . '">' . get_the_time('Y年n月j日') . '</time>
                                                <span class="read-time">' . get_comments_number(get_the_ID()) . '人评论</span>
                                            </div>
                                        </div>
                                    </article>
                                    ';
                endwhile;
            else : endif;
            wp_reset_query();
            echo '
                                </div>
            ';
            echo $args['after_widget'];
        }
    }
}
