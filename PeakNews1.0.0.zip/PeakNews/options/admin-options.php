<?php
if (class_exists('CSF')) {
    $prefix = 'admin_options';

    CSF::createOptions($prefix, array(
        'menu_title' => '主题设置',
        'menu_slug' => 'theme-settings',
    ));

    CSF::createSection($prefix, array(
        'title' => '常规设置',
        'fields' => array(
            array(
                'id' => 'logo',
                'type' => 'media',
                'title' => 'logo',
            ),
        )
    ));

    CSF::createSection($prefix, array(
        'title' => '首页设置',
        'fields' => array(
            array(
                'id' => 'add-module',
                'type' => 'group',
                'title' => '添加模块',
                'fields' => array(
                    array(
                        'id' => 'headline',
                        'type' => 'text',
                        'title' => '大标题',
                    ),
                    array(
                        'id' => 'select-module',
                        'type' => 'image_select',
                        'title' => '选择模块',
                        'options' => array(
                            '1' => get_bloginfo('template_url') . "/static/images/option/1.png",
                            '2' => get_bloginfo('template_url') . "/static/images/option/2.png",
                            '3' => get_bloginfo('template_url') . "/static/images/option/3.png",
                            '4' => get_bloginfo('template_url') . "/static/images/option/4.png",
                            '5' => get_bloginfo('template_url') . "/static/images/option/5.png",
                            '6' => get_bloginfo('template_url') . "/static/images/option/6.png",
                            '7' => get_bloginfo('template_url') . "/static/images/option/7.png",
                        ),
                    ),
                    array(
                        'id' => 'choose-category',
                        'type' => 'select',
                        'title' => '选择分类',
                        'placeholder' => '选择一个分类目录',
                        'options' => 'categories',
                        'multiple' => true,
                        'chosen' => true,
                        'dependency' => array('select-module', 'any', '2,3,5,6,7'),
                    ),
                    array(
                        'id' => 'select-article',
                        'type' => 'select',
                        'title' => '选择文章',
                        'subtitle' => '必须选择6篇文章',
                        'placeholder' => '选择一些文章',
                        'options' => 'posts',
                        'chosen' => true,
                        'multiple' => true,
                        'dependency' => array('select-module', 'any', '1'),
                    ),
                    array(
                        'id' => 'custom-area',
                        'type' => 'wp_editor',
                        'title' => '自定义区域',
                        'dependency' => array('select-module', 'any', '4'),
                    ),
                ),
            ),
        )
    ));

    CSF::createSection($prefix, array(
        'title' => '顶部设置',
        'fields' => array(
            array(
                'id' => 'top-text-message',
                'type' => 'text',
                'title' => '顶部文本信息',
            ),
            array(
                'id' => 'top-social-information',
                'type' => 'fieldset',
                'title' => '顶部社交信息',
                'fields' => array(
                    array(
                        'id' => 'social-display-switch',
                        'type' => 'switcher',
                        'title' => '社交显示开关',
                        'default' => false,
                    ),
                    array(
                        'id' => 'wechat-qr-code',
                        'type' => 'media',
                        'title' => '微信二维码',
                        'dependency' => array('social-display-switch', '==', 'true'),
                    ),
                    array(
                        'id' => 'qq-number',
                        'type' => 'text',
                        'title' => 'QQ号码',
                        'dependency' => array('social-display-switch', '==', 'true'),
                    ),
                    array(
                        'id' => 'sina-weibo-address',
                        'type' => 'text',
                        'title' => '新浪微博地址',
                        'dependency' => array('social-display-switch', '==', 'true'),
                    ),
                    array(
                        'id' => 'custom-area',
                        'type' => 'wp_editor',
                        'title' => '自定义区域',
                        'dependency' => array('switch', '==', 'true'),
                    ),
                ),
            ),
        )
    ));

    CSF::createSection($prefix, array(
        'title' => '底部设置',
        'fields' => array(
            array(
                'id' => 'about-this-site',
                'type' => 'fieldset',
                'title' => '关于本站',
                'fields' => array(
                    array(
                        'id' => 'switch',
                        'type' => 'switcher',
                        'title' => '开关',
                        'default' => false,
                    ),
                    array(
                        'id' => 'headline',
                        'type' => 'text',
                        'title' => '大标题',
                        'dependency' => array('switch', '==', 'true'),
                    ),
                    array(
                        'id' => 'social-display-switch',
                        'type' => 'switcher',
                        'title' => '社交显示开关',
                        'default' => false,
                        'dependency' => array('switch', '==', 'true'),
                    ),
                    array(
                        'id' => 'wechat-qr-code',
                        'type' => 'media',
                        'title' => '微信二维码',
                        'dependency' => array('social-display-switch', '==', 'true'),
                    ),
                    array(
                        'id' => 'qq-number',
                        'type' => 'text',
                        'title' => 'QQ号码',
                        'dependency' => array('social-display-switch', '==', 'true'),
                    ),
                    array(
                        'id' => 'sina-weibo-address',
                        'type' => 'text',
                        'title' => '新浪微博地址',
                        'dependency' => array('social-display-switch', '==', 'true'),
                    ),
                    array(
                        'id' => 'custom-area',
                        'type' => 'wp_editor',
                        'title' => '自定义区域',
                        'dependency' => array('switch', '==', 'true'),
                    ),
                ),
            ),
            array(
                'id' => 'bottom-menu',
                'type' => 'fieldset',
                'title' => '底部菜单',
                'fields' => array(
                    array(
                        'id' => 'switch',
                        'type' => 'switcher',
                        'title' => '开关',
                        'default' => false,
                    ),
                    array(
                        'id' => 'headline',
                        'type' => 'text',
                        'title' => '大标题',
                        'dependency' => array('switch', '==', 'true'),
                    ),
                ),
            ),
            array(
                'id' => 'bottom-copyright',
                'type' => 'fieldset',
                'title' => '底部版权',
                'fields' => array(
                    array(
                        'id' => 'switch',
                        'type' => 'switcher',
                        'title' => '开关',
                        'default' => false,
                    ),
                    array(
                        'id' => 'custom-area',
                        'type' => 'wp_editor',
                        'title' => '自定义区域',
                        'dependency' => array('switch', '==', 'true'),
                    ),
                ),
            ),
        )
    ));

    CSF::createSection($prefix, array(
        'title' => '广告设置',
        'fields' => array(
            array(
                'id' => 'head-advertising',
                'type' => 'fieldset',
                'title' => '头部广告',
                'fields' => array(
                    array(
                        'id' => 'switch',
                        'type' => 'switcher',
                        'title' => '开关',
                        'default' => false,
                    ),
                    array(
                        'id' => 'custom-area',
                        'type' => 'wp_editor',
                        'title' => '自定义区域',
                        'dependency' => array('switch', '==', 'true'),
                    ),
                ),
            ),
            array(
                'id' => 'sidebar-head',
                'type' => 'fieldset',
                'title' => '侧边栏头部',
                'fields' => array(
                    array(
                        'id' => 'switch',
                        'type' => 'switcher',
                        'title' => '开关',
                        'default' => false,
                    ),
                    array(
                        'id' => 'headline',
                        'type' => 'text',
                        'title' => '大标题',
                        'dependency' => array('switch', '==', 'true'),
                    ),
                    array(
                        'id' => 'custom-area',
                        'type' => 'wp_editor',
                        'title' => '自定义区域',
                        'dependency' => array('switch', '==', 'true'),
                    ),
                ),
            ),
            array(
                'id' => 'bottom-of-sidebar',
                'type' => 'fieldset',
                'title' => '侧边栏底部',
                'fields' => array(
                    array(
                        'id' => 'switch',
                        'type' => 'switcher',
                        'title' => '开关',
                        'default' => false,
                    ),
                    array(
                        'id' => 'headline',
                        'type' => 'text',
                        'title' => '大标题',
                        'dependency' => array('switch', '==', 'true'),
                    ),
                    array(
                        'id' => 'custom-area',
                        'type' => 'wp_editor',
                        'title' => '自定义区域',
                        'dependency' => array('switch', '==', 'true'),
                    ),
                ),
            ),
            array(
                'id' => 'bottom-of-content-page',
                'type' => 'fieldset',
                'title' => '内容页底部',
                'fields' => array(
                    array(
                        'id' => 'switch',
                        'type' => 'switcher',
                        'title' => '开关',
                        'default' => false,
                    ),
                    array(
                        'id' => 'headline',
                        'type' => 'text',
                        'title' => '大标题',
                        'dependency' => array('switch', '==', 'true'),
                    ),
                    array(
                        'id' => 'custom-area',
                        'type' => 'wp_editor',
                        'title' => '自定义区域',
                        'dependency' => array('switch', '==', 'true'),
                    ),
                ),
            ),
        )
    ));
}

if (!function_exists('wpzt')) {
    function wpzt($option = '', $default = null)
    {
        $options = get_option('admin_options');
        return (isset($options[$option])) ? $options[$option] : $default;
    }
}
