<?php
if (class_exists('CSF')) {
    $prefix = 'taxonomy_post_tag_options';
    CSF::createTaxonomyOptions($prefix, array(
        'taxonomy' => 'post_tag',
        'data_type' => 'unserialize',
    ));

    CSF::createSection($prefix, array(
        'fields' => array(
            array(
                'id' => 'classification-color',
                'type' => 'color',
                'title' => '标签颜色',
                'default' => '#1a202b'
            ),
        )
    ));
}
