                    <div class="col-md-4">
                        <aside class="site-sidebar">
                            <?php if (wpzt('sidebar-head')['switch'] == true) { ?>
                                <div class="ad-spot text-center">
                                    <div class="ad-spot-title"><?php echo wpzt('sidebar-head')['headline']; ?></div>
                                    <div class="ad-container">
                                        <?php echo wpzt('sidebar-head')['custom-area']; ?>
                                    </div>
                                </div>
                            <?php } ?>
                            <?php dynamic_sidebar('sidebar'); ?>
                            <div class="widget">
                                <h3 class="widget-title text-upper">Tags</h3>
                                <div class="widget-content">
                                    <?php
                                    $tagslist = get_tags(array(
                                        'number' => 20,
                                        'orderby' => 'count',
                                        'order' => 'DESC',
                                    ));
                                    foreach ($tagslist as $tag) {
                                        $tag_color = get_term_meta($tag->term_taxonomy_id, 'classification-color', true);
                                        if (empty(get_term_meta($tag->term_taxonomy_id, 'classification-color', true))) {
                                            $tag_color = '#1a202b';
                                        } else {
                                            $tag_color = get_term_meta($tag->term_taxonomy_id, 'classification-color', true);
                                        };
                                        echo '
                                    <a href="' . get_tag_link($tag) . '" class="tag tag-pill" style="margin-bottom: 4px;--t-color: ' . $tag_color . ';">' . $tag->name . ' × ' . $tag->count . '</a>
	    ';
                                    }
                                    ?>
                                </div>
                            </div>
                            <?php if (wpzt('bottom-of-sidebar')['switch'] == true) { ?>
                                <div class="ad-spot text-center">
                                    <div class="ad-spot-title"><?php echo wpzt('bottom-of-sidebar')['headline']; ?></div>
                                    <div class="ad-container">
                                        <?php echo wpzt('bottom-of-sidebar')['custom-area']; ?>
                                    </div>
                                </div>
                            <?php } ?>
                        </aside>
                    </div>