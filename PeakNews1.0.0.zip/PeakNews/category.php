<?php get_header(); ?>
<div class="main-content-area">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="cover-wrap cover-tag">
                    <div class="archive-cover has-image">
                        <img class="lazy feature-image" data-src="<?php echo post_thumbnail_src(); ?>" alt="<?php echo single_cat_title(); ?>" />
                        <div class="cover-content-wrapper text-center tc-health">
                            <h1 class="tag-name h2"><?php echo single_cat_title(); ?></h1>
                            <div class="tag-description"><?php echo category_description(); ?></div>
                        </div>
                    </div>
                </div>
                <div class="row post-list">
                    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                            <div class="col-md-6 col-sm-6 post-list-item">
                                <article class="post">
                                    <a href="<?php the_permalink(); ?>" aria-label="<?php the_title(); ?>">
                                        <div class="post-img-wrap loading-bg">
                                            <img class="post-img lazy" data-src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>">
                                        </div>
                                    </a>
                                    <div class="post-content">
                                        <div class="tag-wrap">
                                            <div class="tag tag-pill" style="background-color: <?php $term = get_category_by_slug(get_the_category()[0]->slug);
                                                                                                echo get_term_meta($term->term_id, 'classification-color', true); ?>;"><?php the_category(','); ?></div>
                                        </div>
                                        <h2 class="post-title h3"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                        <div class="post-meta">
                                            <time class="pub-date" datetime="<?php the_time('Y-n-j'); ?>"><?php the_time('Y年n月j日'); ?></time>
                                            <span class="read-time"><?php comments_popup_link('0 条评论', '1 条评论', '% 条评论', '', '评论已关闭'); ?></span>
                                            -
                                            <span class="post-views"><?php echo getPostViews(get_the_ID()); ?> 人阅读</span>
                                        </div>
                                    </div>
                                </article>
                            </div>
                        <?php endwhile; ?>
                    <?php else : ?>
                    <?php endif; ?>
                </div>
                <div class="row justify-center"> <span class="post-loading-indicator" id="js-post-loding-indicator"></span>
                </div>
            </div>
            <?php get_sidebar(); ?>
        </div>
    </div>
</div>
<?php get_footer(); ?>