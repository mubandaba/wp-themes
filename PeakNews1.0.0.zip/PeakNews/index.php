<?php get_header(); ?>
<main class="main-content-area">
    <div class="container">
        <div class="row">
            <?php if (!empty(wpzt('add-module'))) {
                foreach (wpzt('add-module') as $key => $value) { ?>
                    <?php if ($value['select-module'] == 1) { ?>
                        <div class="col-12">
                            <div class="row block featured-posts-wrap clearfix">
                                <?php
                                query_posts(array(
                                    'post__in' => $value['select-article'],
                                    'showposts' => '6',
                                ));
                                if (have_posts()) : while (have_posts()) : the_post();
                                        $i++; ?>
                                        <?php if ($i == 1) { ?>
                                            <div class="col-xl-8 col-lg-8 f-left">
                                                <article class="post post-large post-compact has-img">
                                                    <div class="post-img-wrap loading-bg">
                                                        <img class="post-img lazy" data-src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>">
                                                    </div>
                                                    <a href="<?php the_permalink(); ?>" aria-label="<?php the_title(); ?>" class="overlay-link"></a>
                                                    <div class="post-content">
                                                        <div class="tag-wrap">
                                                            <div class="tag tag-pill" style="background-color: <?php $term = get_category_by_slug(get_the_category()[0]->slug);
                                                                                                                echo get_term_meta($term->term_id, 'classification-color', true); ?>;"><?php the_category(','); ?></div>
                                                        </div>
                                                        <h2 class="post-title h4"><?php the_title(); ?></h2>
                                                        <div class="post-meta">
                                                            <time class="pub-date" datetime="<?php the_time('Y-n-j'); ?>"><?php the_time('Y年n月j日'); ?></time>
                                                            <span class="read-time"><?php comments_popup_link('0 条评论', '1 条评论', '% 条评论', '', '评论已关闭'); ?></span>
                                                            -
                                                            <span class="post-views"><?php echo getPostViews(get_the_ID()); ?> 人阅读</span>
                                                        </div>
                                                    </div>
                                                </article>
                                            </div>
                                        <?php } else { ?>
                                            <div class="col-lg-4 col-sm-6 f-left">
                                                <article class="post post-compact has-img">
                                                    <div class="post-img-wrap loading-bg">
                                                        <img class="post-img lazy" data-src="<?php echo post_thumbnail_src(); ?>" alt="">
                                                    </div>
                                                    <a href="<?php the_permalink(); ?>" aria-label="<?php the_title(); ?>" class="overlay-link"></a>
                                                    <div class="post-content">
                                                        <div class="tag-wrap">
                                                            <div class="tag tag-pill" style="background-color: <?php $term = get_category_by_slug(get_the_category()[0]->slug);
                                                                                                                echo get_term_meta($term->term_id, 'classification-color', true); ?>;"><?php the_category(','); ?></div>
                                                        </div>
                                                        <h2 class="post-title h4"><?php the_title(); ?></h2>
                                                        <div class="post-meta">
                                                            <time class="pub-date" datetime="<?php the_time('Y-n-j'); ?>"><?php the_time('Y年n月j日'); ?></time>
                                                            <span class="read-time"><?php comments_popup_link('0 条评论', '1 条评论', '% 条评论', '', '评论已关闭'); ?></span>
                                                        </div>
                                                    </div>
                                                </article>
                                            </div>
                                        <?php } ?>
                                    <?php endwhile;
                                else : ?>
                                <?php endif;
                                wp_reset_query(); ?>
                            </div>
                        </div>
                    <?php } elseif ($value['select-module'] == 2) { ?>
                        <div class="col-12">
                            <div class="row block latest-postc-wrap clearfix">
                                <div class="col-12">
                                    <div class="section-header flex">
                                        <?php
                                        $str = implode(",", $value['choose-category']);
                                        $read_more = strpos($str, ',');
                                        $cat_ID = get_cat_ID(get_cat_name($str));
                                        $cat = get_category($cat_ID);
                                        ?>
                                        <h3 class="section-title text-upper" style="--t-color: <?php $term = get_category_by_slug($cat->slug);
                                                                                                echo get_term_meta($term->term_id, 'classification-color', true); ?>;"><?php echo $value['headline'] ?></h3>
                                        <?php if ($read_more !== false) {
                                        } else { ?>
                                            <a href="<?php echo get_category_link($str); ?>" class="text-upper section-header-link">阅读更多<svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M1.5 13.5h17.79l-5.445 6.54a1.502 1.502 0 102.31 1.92l7.5-9a1.78 1.78 0 00.135-.226c0-.075.075-.12.105-.195A1.5 1.5 0 0024 12a1.499 1.499 0 00-.105-.54c0-.075-.075-.12-.105-.195a1.766 1.766 0 00-.135-.225l-7.5-9A1.499 1.499 0 0015 1.5a1.5 1.5 0 00-1.155 2.46l5.445 6.54H1.5a1.5 1.5 0 100 3z" /></svg></a>
                                        <?php } ?>
                                    </div>
                                </div>
                                <?php
                                query_posts(array(
                                    'cat' => $value['choose-category'],
                                    'showposts' => '6',
                                ));
                                if (have_posts()) : while (have_posts()) : the_post();
                                        $i2++; ?>
                                        <?php if ($i2 == 1) { ?>
                                            <div class="col-xl-7 col-lg-6 f-left">
                                                <article class="post post-style-one post-large">
                                                    <a href="<?php the_permalink(); ?>" aria-label="<?php the_title(); ?>">
                                                        <div class="post-img-wrap loading-bg">
                                                            <img class="post-img lazy" data-src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>">
                                                        </div>
                                                    </a>
                                                    <div class="post-content">
                                                        <div class="tag-wrap">
                                                            <div class="tag tag-pill" style="background-color: <?php $term = get_category_by_slug(get_the_category()[0]->slug);
                                                                                                                echo get_term_meta($term->term_id, 'classification-color', true); ?>;"><?php the_category(','); ?></div>
                                                        </div>
                                                        <h2 class="post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                                        <div class="post-excerpt"><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 160, "..."); ?></div>
                                                        </br>
                                                        <div class="post-meta">
                                                            <time class="pub-date" datetime="<?php the_time('Y-n-j'); ?>"><?php the_time('Y年n月j日'); ?></time>
                                                            <span class="read-time"><?php comments_popup_link('0 条评论', '1 条评论', '% 条评论', '', '评论已关闭'); ?></span>
                                                            -
                                                            <span class="post-views"><?php echo getPostViews(get_the_ID()); ?> 人阅读</span>
                                                        </div>
                                                    </div>
                                                </article>
                                            </div>
                                        <?php } else { ?>
                                            <div class="col-xl-5 col-lg-6 f-left">
                                                <article class="post post-style-two flex">
                                                    <a href="<?php the_permalink(); ?>" aria-label="<?php the_title(); ?>">
                                                        <div class="post-img-wrap loading-bg">
                                                            <img class="post-img lazy" data-src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>">
                                                        </div>
                                                    </a>
                                                    <div class="post-content">
                                                        <div class="tag-wrap">
                                                            <div class="tag tag-small" style="background-color: <?php $term = get_category_by_slug(get_the_category()[0]->slug);
                                                                                                                echo get_term_meta($term->term_id, 'classification-color', true); ?>;width: fit-content;padding: 4px;"><?php the_category(','); ?></div>
                                                        </div>
                                                        <h2 class="post-title h4"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                                        <div class="post-meta">
                                                            <time class="pub-date" datetime="<?php the_time('Y-n-j'); ?>"><?php the_time('Y年n月j日'); ?></time>
                                                            <span class="read-time"><?php comments_popup_link('0 条评论', '1 条评论', '% 条评论', '', '评论已关闭'); ?></span>
                                                        </div>
                                                    </div>
                                                </article>
                                            </div>
                                        <?php } ?>
                                    <?php endwhile;
                                else : ?>
                                <?php endif;
                                wp_reset_query(); ?>
                            </div>
                        </div>
                    <?php } elseif ($value['select-module'] == 3) { ?>
                        <div class="col-12">
                            <div class="row block section-style-one clearfix">
                                <div class="col-12">
                                    <div class="section-header flex">
                                        <?php
                                        $str = implode(",", $value['choose-category']);
                                        $read_more = strpos($str, ',');
                                        $cat_ID = get_cat_ID(get_cat_name($str));
                                        $cat = get_category($cat_ID);
                                        ?>
                                        <h3 class="section-title text-upper" style="--t-color: <?php $term = get_category_by_slug($cat->slug);
                                                                                                echo get_term_meta($term->term_id, 'classification-color', true); ?>;"><?php echo $value['headline'] ?></h3>
                                        <?php if ($read_more !== false) {
                                        } else { ?>
                                            <a href="<?php echo get_category_link($str); ?>" class="text-upper section-header-link">阅读更多<svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M1.5 13.5h17.79l-5.445 6.54a1.502 1.502 0 102.31 1.92l7.5-9a1.78 1.78 0 00.135-.226c0-.075.075-.12.105-.195A1.5 1.5 0 0024 12a1.499 1.499 0 00-.105-.54c0-.075-.075-.12-.105-.195a1.766 1.766 0 00-.135-.225l-7.5-9A1.499 1.499 0 0015 1.5a1.5 1.5 0 00-1.155 2.46l5.445 6.54H1.5a1.5 1.5 0 100 3z" /></svg></a>
                                        <?php } ?>
                                    </div>
                                </div>
                                <?php
                                query_posts(array(
                                    'cat' => $value['choose-category'],
                                    'showposts' => '4',
                                ));
                                if (have_posts()) : while (have_posts()) : the_post();
                                        $i3++; ?>
                                        <?php if ($i3 == 1) { ?>
                                            <div class="col-xl-4 col-lg-5 f-left">
                                                <article class="post post-compact post-large has-img">
                                                    <div class="post-img-wrap loading-bg">
                                                        <img class="post-img lazy" data-src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>">
                                                    </div>
                                                    <a href="<?php the_permalink(); ?>" aria-label="<?php the_title(); ?>" class="overlay-link"></a>
                                                    <div class="post-content">
                                                        <div class="tag-wrap">
                                                            <div class="tag tag-pill" style="background-color: <?php $term = get_category_by_slug(get_the_category()[0]->slug);
                                                                                                                echo get_term_meta($term->term_id, 'classification-color', true); ?>;"><?php the_category(','); ?></div>
                                                        </div>
                                                        <h2 class="post-title h4"><?php the_title(); ?></h2>
                                                        <div class="post-meta">
                                                            <time class="pub-date" datetime="<?php the_time('Y-n-j'); ?>"><?php the_time('Y年n月j日'); ?></time>
                                                            <span class="read-time"><?php comments_popup_link('0 条评论', '1 条评论', '% 条评论', '', '评论已关闭'); ?></span>
                                                        </div>
                                                    </div>
                                                </article>
                                            </div>
                                        <?php } else { ?>
                                            <div class="col-xl-8 col-lg-7 f-left">
                                                <article class="post post-style-two post-large flex">
                                                    <a href="<?php the_permalink(); ?>" aria-label="<?php the_title(); ?>">
                                                        <div class="post-img-wrap loading-bg">
                                                            <img class="post-img lazy" data-src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>">
                                                        </div>
                                                    </a>
                                                    <div class="post-content">
                                                        <div class="tag-wrap">
                                                            <div class="tag tag-small" style="background-color: <?php $term = get_category_by_slug(get_the_category()[0]->slug);
                                                                                                                echo get_term_meta($term->term_id, 'classification-color', true); ?>;width: fit-content;padding: 4px;"><?php the_category(','); ?></div>
                                                        </div>
                                                        <h2 class="post-title h3"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                                        <div class="post-meta">
                                                            <time class="pub-date" datetime="<?php the_time('Y-n-j'); ?>"><?php the_time('Y年n月j日'); ?></time>
                                                            <span class="read-time"><?php comments_popup_link('0 条评论', '1 条评论', '% 条评论', '', '评论已关闭'); ?></span>
                                                            -
                                                            <span class="post-views"><?php echo getPostViews(get_the_ID()); ?> 人阅读</span>
                                                        </div>
                                                        <div class="post-excerpt"><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 160, "..."); ?></div>
                                                    </div>
                                                </article>
                                            </div>
                                        <?php } ?>
                                    <?php endwhile;
                                else : ?>
                                <?php endif;
                                wp_reset_query(); ?>
                            </div>
                        </div>
                    <?php } elseif ($value['select-module'] == 4) { ?>
                        <div class="col-12">
                            <div class="ad-spot ad-wrap-content-area text-center">
                                <div class="ad-spot-title"><?php echo $value['headline'] ?></div>
                                <div class="ad-container">
                                    <?php echo $value['custom-area']; ?>
                                </div>
                            </div>
                        </div>
                    <?php } elseif ($value['select-module'] == 5) { ?>
                        <div class="col-12">
                            <div class="row section-style-two clearfix">
                                <div class="col-12">
                                    <div class="section-header flex">
                                        <?php
                                        $str = implode(",", $value['choose-category']);
                                        $read_more = strpos($str, ',');
                                        $cat_ID = get_cat_ID(get_cat_name($str));
                                        $cat = get_category($cat_ID);
                                        ?>
                                        <h3 class="section-title text-upper" style="--t-color: <?php $term = get_category_by_slug($cat->slug);
                                                                                                echo get_term_meta($term->term_id, 'classification-color', true); ?>;"><?php echo $value['headline']; ?></h3>
                                        <?php if ($read_more !== false) {
                                        } else { ?>
                                            <a href="<?php echo get_category_link($str); ?>" class="text-upper section-header-link">阅读更多<svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M1.5 13.5h17.79l-5.445 6.54a1.502 1.502 0 102.31 1.92l7.5-9a1.78 1.78 0 00.135-.226c0-.075.075-.12.105-.195A1.5 1.5 0 0024 12a1.499 1.499 0 00-.105-.54c0-.075-.075-.12-.105-.195a1.766 1.766 0 00-.135-.225l-7.5-9A1.499 1.499 0 0015 1.5a1.5 1.5 0 00-1.155 2.46l5.445 6.54H1.5a1.5 1.5 0 100 3z" /></svg></a>
                                        <?php } ?>
                                    </div>
                                </div>
                                <?php
                                query_posts(array(
                                    'cat' => $value['choose-category'],
                                    'showposts' => '6',
                                ));
                                if (have_posts()) : while (have_posts()) : the_post();
                                        $i5++; ?>
                                        <?php if ($i5 == 1) { ?>
                                            <div class="col-md-6">
                                                <article class="post post-style-one post-large">
                                                    <a href="<?php the_permalink(); ?>" aria-label="<?php the_title(); ?>">
                                                        <div class="post-img-wrap loading-bg">
                                                            <img class="post-img lazy" data-src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>">
                                                        </div>
                                                    </a>
                                                    <div class="post-content">
                                                        <div class="tag-wrap">
                                                            <div class="tag tag-pill" style="background-color: <?php $term = get_category_by_slug(get_the_category()[0]->slug);
                                                                                                                echo get_term_meta($term->term_id, 'classification-color', true); ?>;"><?php the_category(','); ?></div>
                                                        </div>
                                                        <h2 class="post-title h3"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                                        <div class="post-meta">
                                                            <time class="pub-date" datetime="<?php the_time('Y-n-j'); ?>"><?php the_time('Y年n月j日'); ?></time>
                                                            <span class="read-time"><?php comments_popup_link('0 条评论', '1 条评论', '% 条评论', '', '评论已关闭'); ?></span>
                                                            -
                                                            <span class="post-views"><?php echo getPostViews(get_the_ID()); ?> 人阅读</span>
                                                        </div>
                                                    </div>
                                                </article>
                                            </div>
                                        <?php } elseif ($i5 == 2) { ?>
                                            <div class="col-md-6">
                                                <article class="post post-style-one post-large">
                                                    <a href="<?php the_permalink(); ?>" aria-label="<?php the_title(); ?>">
                                                        <div class="post-img-wrap loading-bg">
                                                            <img class="post-img lazy" data-src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>">
                                                        </div>
                                                    </a>
                                                    <div class="post-content">
                                                        <div class="tag-wrap">
                                                            <div class="tag tag-pill" style="background-color: <?php $term = get_category_by_slug(get_the_category()[0]->slug);
                                                                                                                echo get_term_meta($term->term_id, 'classification-color', true); ?>;"><?php the_category(','); ?></div>
                                                        </div>
                                                        <h2 class="post-title h3"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                                        <div class="post-meta">
                                                            <time class="pub-date" datetime="<?php the_time('Y-n-j'); ?>"><?php the_time('Y年n月j日'); ?></time>
                                                            <span class="read-time"><?php comments_popup_link('0 条评论', '1 条评论', '% 条评论', '', '评论已关闭'); ?></span>
                                                            -
                                                            <span class="post-views"><?php echo getPostViews(get_the_ID()); ?> 人阅读</span>
                                                        </div>
                                                    </div>
                                                </article>
                                            </div>
                                        <?php } else { ?>
                                            <div class="col-lg-3 col-md-4 col-sm-6">
                                                <article class="post post-style-one">
                                                    <a href="<?php the_permalink(); ?>" aria-label="<?php the_title(); ?>">
                                                        <div class="post-img-wrap loading-bg">
                                                            <img class="post-img lazy" data-src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>">
                                                        </div>
                                                    </a>
                                                    <div class="post-content">
                                                        <div class="tag-wrap">
                                                            <div class="tag tag-small" style="background-color: <?php $term = get_category_by_slug(get_the_category()[0]->slug);
                                                                                                                echo get_term_meta($term->term_id, 'classification-color', true); ?>;width: fit-content;padding: 4px;"><?php the_category(','); ?></div>
                                                        </div>
                                                        <h2 class="post-title h3"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                                        <div class="post-meta">
                                                            <time class="pub-date" datetime="<?php the_time('Y-n-j'); ?>"><?php the_time('Y年n月j日'); ?></time>
                                                            <span class="read-time"><?php comments_popup_link('0 条评论', '1 条评论', '% 条评论', '', '评论已关闭'); ?></span>
                                                        </div>
                                                    </div>
                                                </article>
                                            </div>
                                        <?php } ?>
                                    <?php endwhile;
                                else : ?>
                                <?php endif;
                                wp_reset_query(); ?>
                            </div>
                        </div>
                    <?php } elseif ($value['select-module'] == 6) { ?>
                        <div class="col-md-6">
                            <div class="row section-style-two clearfix">
                                <div class="col-12">
                                    <div class="section-header flex">
                                        <?php
                                        $str = implode(",", $value['choose-category']);
                                        $read_more = strpos($str, ',');
                                        $cat_ID = get_cat_ID(get_cat_name($str));
                                        $cat = get_category($cat_ID);
                                        ?>
                                        <h3 class="section-title text-upper" style="--t-color: <?php $term = get_category_by_slug($cat->slug);
                                                                                                echo get_term_meta($term->term_id, 'classification-color', true); ?>;"><?php echo $value['headline'] ?></h3>
                                        <?php if ($read_more !== false) {
                                        } else { ?>
                                            <a href="<?php echo get_category_link($str); ?>" class="text-upper section-header-link">阅读更多<svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M1.5 13.5h17.79l-5.445 6.54a1.502 1.502 0 102.31 1.92l7.5-9a1.78 1.78 0 00.135-.226c0-.075.075-.12.105-.195A1.5 1.5 0 0024 12a1.499 1.499 0 00-.105-.54c0-.075-.075-.12-.105-.195a1.766 1.766 0 00-.135-.225l-7.5-9A1.499 1.499 0 0015 1.5a1.5 1.5 0 00-1.155 2.46l5.445 6.54H1.5a1.5 1.5 0 100 3z" /></svg></a>
                                        <?php } ?>
                                    </div>
                                </div>
                                <?php
                                query_posts(array(
                                    'cat' => $value['choose-category'],
                                    'showposts' => '4',
                                ));
                                if (have_posts()) : while (have_posts()) : the_post();
                                        $i6++; ?>
                                        <?php if ($i6 == 1) { ?>
                                            <div class="col-12">
                                                <article class="post post-style-one post-large">
                                                    <a href="<?php the_permalink(); ?>" aria-label="<?php the_title(); ?>">
                                                        <div class="post-img-wrap loading-bg">
                                                            <img class="post-img lazy" data-src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>">
                                                        </div>
                                                    </a>
                                                    <div class="post-content">
                                                        <div class="tag-wrap">
                                                            <div class="tag tag-pill" style="background-color: <?php $term = get_category_by_slug(get_the_category()[0]->slug);
                                                                                                                echo get_term_meta($term->term_id, 'classification-color', true); ?>;"><?php the_category(','); ?></div>
                                                        </div>
                                                        <h2 class="post-title h3"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                                        <div class="post-meta">
                                                            <time class="pub-date" datetime="<?php the_time('Y-n-j'); ?>"><?php the_time('Y年n月j日'); ?></time>
                                                            <span class="read-time"><?php comments_popup_link('0 条评论', '1 条评论', '% 条评论', '', '评论已关闭'); ?></span>
                                                            -
                                                            <span class="post-views"><?php echo getPostViews(get_the_ID()); ?> 人阅读</span>
                                                        </div>
                                                    </div>
                                                </article>
                                            </div>
                                        <?php } else { ?>
                                            <div class="col-12">
                                                <article class="post post-style-two flex">
                                                    <a href="<?php the_permalink(); ?>" aria-label="<?php the_title(); ?>">
                                                        <div class="post-img-wrap loading-bg">
                                                            <img class="post-img lazy" data-src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>">
                                                        </div>
                                                    </a>
                                                    <div class="post-content">
                                                        <div class="tag-wrap">
                                                            <div class="tag tag-small" style="background-color: <?php $term = get_category_by_slug(get_the_category()[0]->slug);
                                                                                                                echo get_term_meta($term->term_id, 'classification-color', true); ?>;width: fit-content;padding: 4px;"><?php the_category(','); ?></div>
                                                        </div>
                                                        <h2 class="post-title h4"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                                        <div class="post-meta">
                                                            <time class="pub-date" datetime="<?php the_time('Y-n-j'); ?>"><?php the_time('Y年n月j日'); ?></time>
                                                            <span class="read-time"><?php comments_popup_link('0 条评论', '1 条评论', '% 条评论', '', '评论已关闭'); ?></span>
                                                        </div>
                                                    </div>
                                                </article>
                                            </div>
                                        <?php } ?>
                                    <?php endwhile;
                                else : ?>
                                <?php endif;
                                wp_reset_query();
                                $i6 = 0; ?>
                            </div>
                        </div>
                    <?php } elseif ($value['select-module'] == 7) { ?>
                        <div class="col-12">
                            <div class="row clearfix">
                                <div class="col-12">
                                    <div class="section-header flex">
                                        <h3 class="section-title text-upper"><?php echo $value['headline']; ?></h3>
                                    </div>
                                </div>
                                <?php
                                $cats = get_categories();
                                foreach ($cats as $cat) {
                                    query_posts(array(
                                        'cat' => $cat->cat_ID,
                                        'showposts' => '1',
                                    ));
                                ?>
                                    <?php while (have_posts()) {
                                        the_post(); ?>
                                        <div class="col-lg-4 col-md-4 col-sm-6">
                                            <a href="<?php echo get_category_link($cat); ?>" aria-label="<?php echo $cat->cat_name; ?>">
                                                <div class="tag-item-wrap has-img">
                                                    <div class="tag-img-wrap">
                                                        <img class="lazy" data-src="<?php echo post_thumbnail_src(); ?>" alt="<?php echo $cat->cat_name; ?>">
                                                    </div>
                                                    <div class="tag-name text-upper text-center">
                                                        <span><?php echo $cat->cat_name; ?></span>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    <?php } ?>
                                <?php }
                                wp_reset_query(); ?>
                            </div>
                        </div>
                    <?php } ?>
            <?php }
            } ?>
        </div>
    </div>
</main>
<?php get_footer(); ?>