      <div class="ul_con">

      <ul>

        <li class="h">关于我们</li>

        <li><a rel="nofollow" href="http://v7v3.com/about/">关于我们</a></li>

        <li><a href="http://v7v3.com/sitemap.xml">SiteMap</a></li>

      </ul>

      <ul>

        <li class="h">联系我们</li>

        <li><a rel="nofollow" href="http://v7v3.com/contact/">联系方式</a></li>

        <li><a rel="nofollow" href="http://v7v3.com/group/">交流QQ群</a></li>

        <li><a rel="nofollow" href="http://list.qq.com/cgi-bin/qf_invite?id=3077e5391b4997f56a6854122b0c351be607d83c3ebf649b">RSS订阅</a></li>

        <li><a rel="nofollow" href="http://v7v3.com/bot/">蜘蛛抓取监控</a></li>

      </ul>

      <ul>

        <li class="h">其他帮助</li>

        <li><a rel="nofollow" href="http://v7v3.com/tougao/">用户投稿</a></li>

      </ul>

    </div>