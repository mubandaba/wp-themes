<div class="quick_nav">
<h2><span class="h2_txt">关注维7维3</span></h2>
<ul>
<li><a rel="nofollow" href="http://list.qq.com/cgi-bin/qf_invite?id=3077e5391b4997f56a6854122b0c351be607d83c3ebf649b" title="订阅本站"><img  src="<?php bloginfo('template_url'); ?>/images/jq.png"/ alt="订阅本站"></a></li>
<li><a rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=1176882511&site=v7v3&menu=yes" title="联系站长"><img  src="<?php bloginfo('template_url'); ?>/images/3.gif"/ alt="联系站长"></a></li>
<li><a rel="nofollow" href="http://t.qq.com/naizui_ycx" title="关注微博"><img  src="<?php bloginfo('template_url'); ?>/images/1.gif" alt="关注微博"/></a></li>
</ul>
</div>