<?php ob_start(); ?>
<?php
header('HTTP/1.1 404 Not Found');
header("status: 404 Not Found");
?>
<h1>404!!</h1>