<?php
/*--------------------------------------------
Description: add body font style
---------------------------------------------*/
function frkw_add_body_font_style() {
$bodyfont = get_theme_mod('body_font');
$bodyfontweight = get_theme_mod('body_font_weight');
if( $bodyfont == 'Choose a font' || $bodyfont == '') { ?>
body,.sf-menu .menu-description {font-family: 'Franklin Gothic Book', arial;}
<?php } else { ?>
body {font-family:<?php echo $bodyfont; ?>;font-weight:<?php echo $bodyfontweight; ?>;}
<?php
}
}
add_action('frkw_custom_css','frkw_add_body_font_style');


/*--------------------------------------------
Description: add headline font style
---------------------------------------------*/
function frkw_add_headline_font_style() {
$headlinefont = get_theme_mod('headline_font');
$headlinefontweight = get_theme_mod('headline_font_weight');
if( $headlinefont == 'Choose a font' || $headlinefont == '') { ?>
h1,h2,h3,h4,h5,h6,#siteinfo div,.activity-header {font-family: 'Franklin Gothic Demi Cond', arial;}
<?php } else { ?>
h1,h2,h3,h4,h5,h6,#siteinfo div,.activity-header { font-family: <?php echo $headlinefont; ?>; font-weight: <?php echo $headlinefontweight; ?>; }
<?php
}
}
add_action('frkw_custom_css','frkw_add_headline_font_style');

/*--------------------------------------------
Description: add navigation font style
---------------------------------------------*/
function frkw_add_navigation_font_style() {
$navfont = get_theme_mod('navigation_font');
$navfontweight = get_theme_mod('navigation_font_weight');
if( $navfont == 'Choose a font' || $navfont == '') { ?>
.sf-menu {font-family: 'Franklin Gothic Heavy', arial;}
<?php } else { ?>
.sf-menu {font-family: <?php echo $navfont; ?>; font-weight:<?php echo $navfontweight; ?>; }
<?php
}
}
add_action('frkw_custom_css','frkw_add_navigation_font_style');



/*----------------------------------------------------
Description: add theme header text style
----------------------------------------------------*/
function frkw_add_header_textcolor() {
$header_textcolor = get_theme_mod('header_textcolor');
if( $header_textcolor == 'blank') { ?>
#custom #siteinfo h1,#custom #siteinfo div, #custom #siteinfo p {display:none;}
<?php } else {
if( $header_textcolor ) { ?>
#custom #siteinfo a {color: #<?php echo $header_textcolor; ?> !important;text-decoration: none;}
#custom #siteinfo p#site-description {color: #<?php echo $header_textcolor; ?> !important;text-decoration: none;}
<?php
}
}
}
add_action('frkw_custom_css','frkw_add_header_textcolor');


/*----------------------------------------------------
Description: add main color css
----------------------------------------------------*/
function frkw_add_main_color() {
$main_color = get_theme_mod('main_color');
if( $main_color ) { ?>

#top-navigation {
background: <?php echo $main_color; ?>;
background: -moz-linear-gradient(top,  <?php echo $main_color; ?> 0%, <?php echo dehex($main_color,-20); ?> 100%);
background: -webkit-linear-gradient(top,  <?php echo $main_color; ?> 0%,<?php echo dehex($main_color,-20); ?> 100%);
background: linear-gradient(to bottom,  <?php echo $main_color; ?> 0%,<?php echo dehex($main_color,-20); ?> 100%);
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='<?php echo $main_color; ?>', endColorstr='<?php echo dehex($main_color,-20); ?>',GradientType=0 );
}
.sf-menu ul li,.sf-menu ul ul li  {background:<?php echo dehex($main_color,-20); ?> none;}
.sf-menu li.current-menu-item a,.sf-menu li.current-page-item a {background-color: <?php echo dehex($main_color,-25); ?>;}
.sf-menu li li:hover {background: <?php echo $main_color; ?> none;color:#fff;}


#mp-ticker a,.content a,aside.widget #calendar_wrap a, #custom aside.widget .textwidget a {color: <?php echo $main_color; ?>;}

.post-paging .page-navigation span.page-current {color:#fff;background-color:<?php echo $main_color; ?>;border:1px solid <?php echo $main_color; ?>;}

footer.footer-top {background-color: <?php echo $main_color; ?>;}

.content #entries h2.entry-title a {color:<?php echo $main_color; ?>;}
.content h2.entry-title a:hover {color:<?php echo dehex($main_color,-25); ?> !important;}

footer.footer-top .footer-box.fbox-center {
    border-right: 1px solid <?php echo dehex($main_color,-10); ?>;
    border-left: 1px solid <?php echo dehex($main_color,-10); ?>;
}
footer aside.widget caption {
    background-color: <?php echo dehex($main_color,-10); ?>;
}
footer aside.widget th {
    border-bottom: 1px solid <?php echo dehex($main_color,-10); ?>;
}
footer aside.widget ul.featured-cat-posts li {
    border-bottom: 1px solid <?php echo dehex($main_color,-10); ?>;
}
<?php }
}
add_action('frkw_custom_css','frkw_add_main_color');


function frkw_if_ticker_on_css() {
if( get_theme_mod('ticker_post') != '') { ?>
#mp-ticker {overflow:hidden;width: 100%;margin: 0 0 0.5em;float:left;font-size:1.5em;letter-spacing:1px;}
#mp-ticker div {font-weight:bold;display: inline-block;word-wrap: break-word;}
#mp-ticker em {font-size:14px;color:#888;font-style:normal;}
<?php }
}
add_action('frkw_custom_css','frkw_if_ticker_on_css');



/*----------------------------------------------------
Description: add theme custom css
----------------------------------------------------*/
function frkw_add_theme_custom_css() {
$customcss = get_theme_mod('custom_css');
if( $customcss ) { echo $customcss; }
}
add_action('frkw_custom_css','frkw_add_theme_custom_css');


/*----------------------------------------------------
Description: let's finalize all it wp_head
----------------------------------------------------*/
function frkw_init_theme_custom_style() {
print '<style id="theme-custom-css" type="text/css" media="all">' . "\n";
do_action( 'frkw_custom_css' );
print '</style>' . "\n";
}
add_action('wp_head','frkw_init_theme_custom_style',99);

?>