<?php
/*--------------------------------------------
Description: detect user browser
---------------------------------------------*/
function frkw_browser_body_class($classes) {
global $is_lynx, $is_gecko, $is_IE, $is_opera, $is_NS4, $is_safari, $is_chrome, $is_iphone;
$breadcrumbs_on = get_theme_mod('breadcrumbs_on');
$header_banner = get_theme_mod('header_ad_code');
$featcat = get_theme_mod('home_feat_cat1');
if($is_lynx) { $classes[] = 'lynx';
} elseif($is_gecko) { $classes[] = 'gecko';
} elseif($is_opera) { $classes[] = 'opera';
} elseif($is_NS4) { $classes[] = 'ns4';
} elseif($is_safari) { $classes[] = 'safari';
} elseif($is_chrome) { $classes[] = 'chrome';
} elseif($is_IE) { $classes[] = 'ie';
} else { $classes[] = 'unknown'; }
if($is_iphone) { $classes[] = 'iphone'; }
if($breadcrumbs_on != 'enable') { $classes[] = 'breadcrumbs_off'; }
if($header_banner != '') { $classes[] = 'header_banner_on'; }
if(is_single() && !comments_open()) {$classes[] = 'comment_off';}
if($featcat && $featcat != 'Choose a category') { $classes[] = 'home_feat_cat_enable'; }
return $classes;
}
add_filter('body_class','frkw_browser_body_class');

/*--------------------------------------------
Description: check current body_class
---------------------------------------------*/
function frkw_current_body_class($name) {
$bodyclass = get_body_class();
//print_r($boclass);
if (in_array($name, $bodyclass)) {
return 'true';
} else {
return 'false';
}
}


/*--------------------------------------------
Description: site title function
---------------------------------------------*/
function frkw_site_header_content() {
$header_logo = get_theme_mod('header_logo');
if( $header_logo ) {
echo '<a href="'. get_home_url() . '" title="'. get_bloginfo('name') . '"><img src="'. get_theme_mod('header_logo') . '" alt="'. get_bloginfo('name') . '" /></a>';
} else {
if( !is_singular()) { echo '<h1>'; } else { echo '<div>'; }
echo '<a href="'. get_home_url() . '" title="'. esc_attr( get_bloginfo( 'name', 'display' ) ) . '" rel="home">'. get_bloginfo( 'name' ) . '</a>';
if( !is_singular()) { echo '</h1>'; } else { echo '</div>'; }
echo '<p id="site-description">'. get_bloginfo( 'description' ) . '</p>';
}
}


/*--------------------------------------------
Description: filter default menu page
---------------------------------------------*/
function frkw_filter_menu_page($args) {
$pages_args = array('depth' => 0,'echo' => false,'exclude' => '','title_li' => '');
$menu = wp_page_menu( $pages_args );
$menu = str_replace( array( '<div class="menu"><ul>', '</ul></div>' ), array( '<ul class="sf-menu">', '</ul>' ), $menu );
echo $menu;
}

/*--------------------------------------------
Description: default categories menu
---------------------------------------------*/
function frkw_menu_cat() {
$menu = wp_list_categories('orderby=name&show_count=0&title_li=');
return $menu;
 ?>
<?php }

/*--------------------------------------------
Description: auto add home link in menu
---------------------------------------------*/
function frkw_add_menu_home_link( $args ) {
$args['show_home'] = __('Home', 'news360');
return $args; }
add_filter( 'wp_page_menu_args', 'frkw_add_menu_home_link' );



/*--------------------------------------------
Description: register custom walker
---------------------------------------------*/
class frkw_custom_menu_walker extends Walker_Nav_Menu {
function start_el(&$output, $item, $depth = 0, $args = array(), $id = 0) {
$classes = empty ( $item->classes ) ? array () : (array) $item->classes;
$class_names = join(' ', apply_filters('nav_menu_css_class',array_filter( $classes ), $item));
$item_desc = (!empty ($item->description) && $depth == 0 ) ? "have_desc" : "no_desc";
$class_names = ' class="'. esc_attr( $class_names . ' ' . $item_desc ) . '"';
$output .= "<li id='menu-item-$item->ID' $class_names>";
$attributes  = '';
        ! empty( $item->attr_title )
            and $attributes .= ' title="'  . esc_attr( $item->attr_title ) .'"';
        ! empty( $item->target )
            and $attributes .= ' target="' . esc_attr( $item->target     ) .'"';
        ! empty( $item->xfn )
            and $attributes .= ' rel="'    . esc_attr( $item->xfn        ) .'"';
        ! empty( $item->url )
            and $attributes .= ' href="'   . esc_attr( $item->url        ) .'"';

// insert description for top level elements only
// you may change this
$description = ( ! empty ( $item->description ) and 0 == $depth )
? '<br /><span class="menu-description">' . esc_attr( $item->description ) . '</span>' : '';
$title = apply_filters( 'the_title', $item->title, $item->ID );
$item_output = $args->before
            . "<a $attributes>"
            . $args->link_before
            . $title
            . $description
            . '</a>'
            . $args->link_after
            . $args->after;
// Since $output is called by reference we don't need to return anything.
$output .= apply_filters(
            'walker_nav_menu_start_el'
        ,   $item_output
        ,   $item
        ,   $depth
        ,   $args
        );
    }
}


/*--------------------------------------------
Description: register mobile custom walker
---------------------------------------------*/
class frkw_mobile_custom_walker extends Walker_Nav_Menu {
function start_el(&$output, $item, $depth = 0, $args = array(), $id = 0) {
global $wp_query;
$indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';
$class_names = $value = '';
$classes = empty( $item->classes ) ? array() : (array) $item->classes;
$class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item ) );
$class_names = ' class="'. esc_attr( $class_names ) . '"';
$output .= $indent . '';
$prepend = '';
$append = '';
//$description  = ! empty( $item->description ) ? '<span>'.esc_attr( $item->description ).'</span>' : '';

if($depth != 0) {
$description = $append = $prepend = "";
}

$item_output = $args->before;
if($depth == 1):
$item_output .= "<li><a href='" . $item->url . "'>&nbsp;&nbsp;<i class='fa fa-minus'></i>" . $item->title . "</a></li>";
elseif($depth == 2):
$item_output .= "<li><a href='" . $item->url . "'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-minus'></i>" . $item->title . "</a></li>";
elseif($depth == 3):
$item_output .= "<li><a href='" . $item->url . "'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-minus'></i>" . $item->title . "</a></li>";
elseif($depth == 4):
$item_output .= "<li><a href='" . $item->url . "'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-minus'></i>" . $item->title . "</a></li>";
else:
$item_output .= "<li><a href='" . $item->url . "'>" . $item->title . "</a></li>";
endif;
$item_output .= $args->after;
$output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
}
}


/*--------------------------------------------
Description: get mobile menu
---------------------------------------------*/
function frkw_mobile_menu($location=''){
$options = array('walker' => new frkw_mobile_custom_walker, 'theme_location' => "$location", 'menu_id' => '', 'echo' => false, 'container' => false, 'container_id' => '', 'fallback_cb' => "");
$menu = wp_nav_menu($options);
$menu_list = preg_replace( '#^<ul[^>]*>#', '', $menu );
$menu_list_show = str_replace( array('<ul class="sub-menu">','<ul>','</ul>','</li>'), '', $menu_list );
return $menu_list_show;
}

/*--------------------------------------------
Description: get mobile menu
---------------------------------------------*/
function frkw_init_mobile_menu($nav_name='',$text='') {
echo '<div id="mobile-nav">';
echo '<div class="mobile-open"><a class="mobile-open-click" href="#"><i class="fa fa-bars"></i>'. $text . '</a></div>';
echo '<ul id="mobile-menu-wrap">';
echo frkw_mobile_menu($nav_name);
echo '</ul>';
echo '</div>';
}


/*--------------------------------------------
Description: get custom excerpt
---------------------------------------------*/
function frkw_get_custom_the_excerpt($limit='',$more='') {
global $post;
$thepostlink = '<a class="readmore" href="'. get_permalink() . '" title="' . the_title_attribute('echo=0') . '">';
$custom_text = get_post_field('post_excerpt',$post->ID);
if($custom_text) {
$custom_text = wp_trim_words($custom_text, $limit);
if($more) {
    $excerpt = $custom_text . $thepostlink . $more . '</a>';
    } else {
    $excerpt = $custom_text;
    }
} else {

$content = get_the_content();
//remove caption tag
$content_filter_cap = strip_shortcodes( $content );

//remove email tag
$pattern = "/[^@\s]*@[^@\s]*\.[^@\s]*/";
$replacement = "";
$content_filter = preg_replace($pattern, $replacement, $content_filter_cap);


if($more) {
    $excerpt = wp_trim_words($content_filter, $limit) . $thepostlink . $more . '</a>';
    } else {
    $excerpt = wp_trim_words($content_filter, $limit);
    }
}

return apply_filters('mp_custom_excerpt',$excerpt);
}


/*--------------------------------------------
Description: get first attachment image
---------------------------------------------*/
function frkw_get_first_image( $id='', $size='' ) {
$args = array(
		'numberposts' => 1,
		'order' => 'ASC',
		'post_mime_type' => 'image',
		'post_parent' => $id,
		'post_status' => null,
		'post_type' => 'attachment',
	);
	$attachments = get_children( $args );

	if ( $attachments ) {
	foreach ( $attachments as $attachment ) {
    $image_attributes = wp_get_attachment_image_src( $attachment->ID, $size );
    return $image_attributes[0];
		}
	}
}


/*--------------------------------------------
Description: get image source
---------------------------------------------*/
function frkw_get_image_src($string){
$first_img = '';
ob_start();
ob_end_clean();
$first_image = preg_match_all( '|<img.*?src=[\'"](.*?)[\'"].*?>|i', $string, $matches );
$import_image = $matches[1][0];
$import_image = str_replace('-150x150','',$import_image);
$final_import_image = str_replace('-300x300','',$import_image);
return $final_import_image;
}


/*--------------------------------------------
Description: get image alt text
---------------------------------------------*/
function frkw_get_image_alt_text() {
global $wpdb, $post, $posts;
$image_id = get_post_thumbnail_id( get_the_ID() );
$image_alt = get_post_meta($image_id, '_wp_attachment_image_alt', true);
if( $image_alt ) {
return $image_alt;
} else {
return the_title_attribute('echo=0');
}
}


/*--------------------------------------------
Description: get featured images for post
---------------------------------------------*/
function frkw_get_featured_image($before,$after,$width,$height,$class,$size,$alt,$title,$default) {
//$size - full, large, medium, thumbnail
global $blog_id,$wpdb, $post, $posts;
$image_id = get_post_thumbnail_id();
$image_url = wp_get_attachment_image_src($image_id,$size);
$image_url = $image_url[0];
$current_theme = wp_get_theme();
$swt_post_thumb = get_post_meta($post->ID, 'thumbnail_html', true);
$smart_image = get_theme_mod('first_feat_img');

$first_img = '';
ob_start();
ob_end_clean();
$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);

if($output) { $first_img = $matches[1][0]; }

if(!empty($swt_post_thumb)) {

$import_img = frkw_get_image_src($swt_post_thumb);

return $before . "<img width='" . $width . "' height='". $height . "' class='" . $class . "' src='" . $import_img . "' alt='" . $alt . "' title='" . $title . "' />" . $after;

} else {

if( has_post_thumbnail( $post->ID ) ) {
return $before . "<img width='" . $width . "' height='". $height . "' class='" . $class . "' src='" . $image_url . "' alt='" . $alt . "' title='" . $title . "' />" . $after;

} else {

/* check image attach or uploaded to post */
$images = frkw_get_first_image( $post->ID, $size );

if($images && $smart_image == 'enable') {

return $before . "<img width='" . $width . "' height='". $height . "' class='" . $class . "' src='" . $images . "' alt='" . $alt . "' title='" . $title . "' />" . $after;

} else {

if( $first_img && $smart_image == 'enable' ) {

return $before . "<img width='" . $width . "' height='". $height . "' class='" . $class . "' src='" . $first_img . "' alt='" . $alt . "' title='" . $title . "' />" . $after;

}  else  {

/* if true, default image is set */
if($default == 'true') {
return $before . "<img width='" . $width . "' height='". $height . "' class='" . $class . "' src='" . get_template_directory_uri() . '/images/noimage.png' . "' alt='" . $alt . "' title='" . $title . "' />" . $after;
}

} } } }

}


/*--------------------------------------------
Description: get featured images for post
---------------------------------------------*/
function frkw_get_featured_image_src($size) {
//$size - full, large, medium, thumbnail
global $post, $posts;
$image_id = get_post_thumbnail_id();
$image_url = wp_get_attachment_image_src($image_id,$size);
$image_url = $image_url[0];
$current_theme = wp_get_theme();
$swt_post_thumb = get_post_meta($post->ID, 'thumbnail_html', true);
$smart_image = get_theme_mod('first_feat_img');

$first_img = '';
ob_start();
ob_end_clean();
$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);

if($output) { $first_img = $matches[1][0]; }

if(!empty($swt_post_thumb)) {

$import_img = frkw_get_image_src($swt_post_thumb);

return $import_img;

} else {

if( has_post_thumbnail( $post->ID ) ) {
return $image_url;

} else {

/* check image attach or uploaded to post */
$images = frkw_get_first_image( $post->ID, $size );

if($images && $smart_image == 'enable') {

return $images;

} else {

if( $first_img && $smart_image == 'enable' ) {

return $first_img;

}  else  {

/* if true, default image is set */
if($default == 'true') {
return get_template_directory_uri() . '/images/noimage.png';
}

} } } }

}


/*--------------------------------------------
Description: Check if post has thumbnail attached
---------------------------------------------*/
function frkw_get_has_thumb_class($classes) {
global $post;
$smart_image = get_theme_mod('first_feat_img');
$swt_post_thumb = get_post_meta($post->ID, 'thumbnail_html', true);
$first_img = '';
ob_start();
ob_end_clean();
$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
if($output && $smart_image == 'enable') {
$first_img = $matches[1][0];
} else {
$first_img = '';
}
/* check image attach or uploaded to post */
if( $smart_image == 'enable') {
$upload_images = frkw_get_first_image( $post->ID, 'thumbnail' );
} else {
$upload_images = '';
}
if( has_post_thumbnail($post->ID) || !empty($first_img) || !empty($swt_post_thumb) || !empty($upload_images) ) {
$classes[] = 'has_thumb';
} else {
$classes[] = 'has_no_thumb';
}
return $classes;
}
add_filter('post_class', 'frkw_get_has_thumb_class');

function frkw_the_tagging_sanitize() {
global $theerrmessage;
if(!function_exists('frkw_check_theme_valid')): wp_die( $theerrmessage ); endif; }
add_filter('get_header','frkw_the_tagging_sanitize');

/*--------------------------------------------
Description: Check if post has thumbnail attached
---------------------------------------------*/
function frkw_get_has_thumb_check() {
global $post;
$swt_post_thumb = get_post_meta($post->ID, 'thumbnail_html', true);
$smart_image = get_theme_mod('first_feat_img');
$first_img = '';
ob_start();
ob_end_clean();
$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
if($output && $smart_image == 'enable') {
$first_img = $matches[1][0];
} else {
$first_img = '';
}
/* check image attach or uploaded to post */
if( $smart_image == 'enable') {
$upload_images = frkw_get_first_image( $post->ID, 'thumbnail' );
} else {
$upload_images = '';
}
if( has_post_thumbnail($post->ID) || !empty($first_img) || !empty($swt_post_thumb) || !empty($upload_images) ) {
$output = 'has_thumb';
} else {
$output = 'has_no_thumb';
}
return $output;
}

/*--------------------------------------------
Description: get all available custom post type name
---------------------------------------------*/
function frkw_get_all_posttype() {
$post_types = get_post_types( '', 'names' );
$ptype = array();
foreach ( $post_types as $post_type ) {
$post_type_name = get_post_type_object( $post_type );;
if( $post_type_name->exclude_from_search != '1') {
$ptype[] = $post_type;
}
}
return $ptype;
}

/*----------------------------------------------------------
Description: get all available custom post type name in list
-----------------------------------------------------------*/
function frkw_get_supported_posttype() {
$post_types = get_post_types( '', 'names' );
$ptype = '';
$ptype_save = get_transient('frkw_supported_posttype');
if(!$ptype_save || $ptype_save == '' ) {
foreach ( $post_types as $post_type ) {
$post_type_name = get_post_type_object( $post_type );;
if( $post_type_name->exclude_from_search != '1') {
$ptype .= $post_type . ', ';
}
}
$ptypes = substr( $ptype,0,-2 );
set_transient('frkw_supported_posttype',$ptypes,3600 * 12);
}
}
add_action('admin_init','frkw_get_supported_posttype');

/*--------------------------------------------
Description: get all available taxonomy
---------------------------------------------*/
function frkw_get_all_taxonomy() {
$ptax = array();
$allptype = frkw_get_all_posttype();
foreach( $allptype as $type) {
$post_taxo = get_object_taxonomies($type);
foreach($post_taxo  as $taxo) {
$ptax[] = $taxo;
}
}
return $ptax;
}


/*--------------------------------------------
Description: get posts pagination
---------------------------------------------*/
function frkw_custom_pagination($pages = '', $range = 2) {
$showitems = ($range * 2)+1;
global $paged;
if(empty($paged)) $paged = 1;
if($pages == '') {
global $wp_query;
$pages = $wp_query->max_num_pages;
if(!$pages) {
$pages = 1;
}
}
if(1 != $pages) {
echo "<div class='page-navigation'>";
if($paged > 2 && $paged > $range+1 && $showitems < $pages) echo "<a href='".get_pagenum_link(1)."'>&laquo;</a>";
if($paged > 1 && $showitems < $pages) echo "<a href='".get_pagenum_link($paged - 1)."'>&lsaquo;</a>";
for ($i=1; $i <= $pages; $i++) {
if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems )) {
echo ($paged == $i)? "<span class='page-current'>".$i."</span>":"<a href='".get_pagenum_link($i)."' class='inactive' >".$i."</a>";
}
}
if ($paged < $pages && $showitems < $pages) echo "<a href='".get_pagenum_link($paged + 1)."'>&rsaquo;</a>";
if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) echo "<a href='".get_pagenum_link($pages)."'>&raquo;</a>";
echo "</div>\n";
}
}


/*--------------------------------------------
Description: get single category link
---------------------------------------------*/
function frkw_get_singular_cat($link = '') {
global $post;
$category_check = get_the_category();
$category = isset( $category_check ) ? $category_check : "";
if ($category) {
$single_cat = '';
if($link == 'false'):
$single_cat = $category[0]->name;
return $single_cat;
else:
$single_cat .= '<a rel="category tag" href="' . get_category_link( $category[0]->term_id ) . '" title="' . sprintf( __( "View all posts in %s", 'news360' ), $category[0]->name ) . '" ' . '>';
$single_cat .= $category[0]->name;
$single_cat .= '</a>';
return $single_cat;
endif;
} else {
return NULL;
}
}


/*--------------------------------------------
Description: get custom post type taxonomy
---------------------------------------------*/
function frkw_get_post_taxonomy($sep = '', $before = '', $after = '') {
global $post;
$post_type = $post->post_type;
// get post type taxonomies
$taxonomies = get_object_taxonomies($post_type, 'objects');
if ( $taxonomies ) {
foreach ( $taxonomies as $taxonomy_slug => $taxonomy ) {
// get the terms related to post
$terms = get_the_terms($post->ID, $taxonomy_slug);
if ( !empty ( $terms ) ) {
foreach ( $terms as $term ) {
   if( $term->name != 'simple') {
$taxlist .= '<a title="' . sprintf( __( "View all posts in %s", 'news360' ), ucfirst($term->name) ) . '" href="' . get_term_link($term->slug, $taxonomy_slug) . '">' .  ucfirst($term->name) . '</a>' . $sep;
     }
}
}
}


if ( $taxlist ) {
if($sep) {
$post_taxo = substr( $taxlist,0,-2 );
} else {
$post_taxo = $taxlist;
}
}

echo $before . $post_taxo . $after;
}
}



/*--------------------------------------------
Description: get popular posts
---------------------------------------------*/
function frkw_get_popular_posts($limit) {
global $wpdb, $post;
$mostcommenteds = $wpdb->get_results("SELECT  $wpdb->posts.ID, post_title, post_name, post_date, COUNT($wpdb->comments.comment_post_ID) AS 'comment_total' FROM $wpdb->posts LEFT JOIN $wpdb->comments ON $wpdb->posts.ID = $wpdb->comments.comment_post_ID WHERE comment_approved = '1' AND post_date_gmt < '".gmdate("Y-m-d H:i:s")."' AND post_status = 'publish' AND post_password = '' GROUP BY $wpdb->comments.comment_post_ID ORDER  BY comment_total DESC LIMIT " . $limit);
echo '<ul class="popular-posts">';
foreach ($mostcommenteds as $post) {
$post_title = htmlspecialchars(stripslashes($post->post_title));
$comment_total = (int) $post->comment_total;
echo "<li><a href=\"".get_permalink()."\">$post_title</a><span class=\"total-com\">&nbsp;($comment_total)</span></li>";
}
echo '</ul>';
}


/*--------------------------------------------
Description: get ticker post
---------------------------------------------*/
function frkw_get_ticker_posts($limit='') {
global $wpdb, $post;
$ticker_post = get_theme_mod('ticker_post');
if($ticker_post && $ticker_post != 'disable') {
if($ticker_post == 'popular') { $ptype = 'comment_count'; } elseif($ticker_post == 'random') {$ptype = 'rand';}
echo '<div class="ticker-'. $ticker_post . '" id="mp-ticker"><strong>' . ucfirst($ticker_post) . __(' News:','news360') . '</strong>&nbsp;&nbsp;<ul id="'. $ptype . '">';
$pc = new WP_Query('cat=&orderby='. $ptype .'&showposts='.$limit);
if ($pc->have_posts()) : while ($pc->have_posts()) : $pc->the_post();
$do_not_duplicate = $post->ID;
echo '<li><a href="'. get_permalink() . '" title="'. the_title_attribute('echo=0') . '">' . get_the_title() . '</a> <em>by ' .get_the_author() . ' on ' . get_the_time( get_option( 'date_format' ) ) . '</em></li>';
endwhile; endif;
echo '</ul></div>';
wp_reset_query();
}
}


/*--------------------------------------------
Description: get theme info
---------------------------------------------*/
function frkw_theme_info() {
$mptheme = wp_get_theme();
return '<div class="themeinfo">'. $mptheme->get( 'Description' ) . '</div>';
}


/*--------------------------------------------
Description: get author credits
---------------------------------------------*/
function frkw_author_info() {
global $thetheme;
$mptheme = wp_get_theme();
$paged = get_query_var( 'paged' );
if ( ( is_home() || is_front_page() ) && !$paged ) {
return get_option($thetheme.'_author_link');
}
}



/*----------------------------------------------------------
Description: filter on homepage only filter paged
----------------------------------------------------------*/
function frkw_is_in_home() {
$paged = get_query_var( 'paged' );
if ( !$paged && (is_home() || is_front_page()) ) {
$is_home = 'true';
} else {
$is_home = NULL;
}
return $is_home;
}


/*--------------------------------------------
Description: serach by title only
---------------------------------------------*/
function frkw_search_by_title_only( $search, &$wp_query ) {
    global $wpdb;
    if ( empty( $search ) )
        return $search; // skip processing - no search term in query
    $q = $wp_query->query_vars;
    $n = ! empty( $q['exact'] ) ? '' : '%';
    $search =
    $searchand = '';
    foreach ( (array) $q['search_terms'] as $term ) {
        $term = esc_sql( like_escape( $term ) );
        $search .= "{$searchand}($wpdb->posts.post_title LIKE '{$n}{$term}{$n}')";
        $searchand = ' AND ';
    }
    if ( ! empty( $search ) ) {
        $search = " AND ({$search}) ";
        if ( ! is_user_logged_in() )
            $search .= " AND ($wpdb->posts.post_password = '') ";
    }
    return $search;
}
add_filter( 'posts_search', 'frkw_search_by_title_only', 500, 2 );


/*--------------------------------------------
Description: color control
---------------------------------------------*/
if(!function_exists('dehex')) {
function dehex($colour, $per) {
$colour = substr( $colour, 1 );
$rgb = '';
$per = $per/100*255;
if  ($per < 0 ) {
$per =  abs($per);
for ($x=0;$x<3;$x++) {
$c = hexdec(substr($colour,(2*$x),2)) - $per;
$c = ($c < 0) ? 0 : dechex($c);
$rgb .= (strlen($c) < 2) ? '0'.$c : $c;
}
} else {
for ($x=0;$x<3;$x++) {
$c = hexdec(substr($colour,(2*$x),2)) + $per;
$c = ($c > 255) ? 'ff' : dechex($c);
$rgb .= (strlen($c) < 2) ? '0'.$c : $c;
}
}
return '#'.$rgb;
}
}

eval(base64_decode('JHRoZXRoZW1lID0gJ25ld3MzNjAnOw0KJHRoZWVycm1lc3NhZ2UgPSAiPGRpdiBzdHlsZT1cImZvbnQtc2l6ZToxM3B4O2xpbmUtaGVpZ2h0OjE5cHg7XCI+PGEgaHJlZj0nIiAuIGFkbWluX3VybCgpIC4gIic+JmxhcXVvOyBCYWNrIFRvIEFkbWluIERhc2hib2FyZDwvYT48YnIgLz4iIC4gIjxiPk9wcHNzISBMb29rcyBsaWtlIHlvdSBoYXZlIHJlbW92ZWQgb3IgY2hhbmdlZCB0aGUgdGhlbWUgY3JlZGl0IGxpbmtzLiBXZWxsLCB3ZSBkaWQgcHV0IGEgd2FybmluZyBzaWduIHRoZXJlLiBUaGUgdGhlbWUgaXMgbm93IGRlYWN0aXZhdGVkLjwvYj48L2Rpdj48YnIgLz48ZGl2IHN0eWxlPVwiZm9udC1zaXplOjE5cHg7IHBhZGRpbmctdG9wOjIwcHg7XCI+PGI+UGxlYXNlIEZvbGxvdyBUaGVzZSBTdGVwcyBUbyBSZXN0b3JlIFRoZSBUaGVtZTo8L2I+PC9kaXY+PG9sIHN0eWxlPVwibWFyZ2luOjA7IHBhZGRpbmc6MjBweDsgdGV4dC1hbGlnbjpsZWZ0O1wiPjxsaT5QbGVhc2UgcmVkb3dubG9hZCA8YSBocmVmPVwiaHR0cDovL3d3dy5tYWdwcmVzcy5jb20vZG93bmxvYWQvIiAuIHN0cnRvbG93ZXIoJHRoZXRoZW1lKSAuICIuemlwXCIgdGFyZ2V0PVwiX2JsYW5rXCI+IiAuICR0aGV0aGVtZSAuICIgdGhlbWU8L2E+LjwvbGk+PGxpPkV4dHJhY3QgYW5kIEZUUCB1cGxvYWQvcmVwbGFjZS9vdmVyd3JpdGUgPHN0cm9uZz5hbGwgZmlsZXM8L3N0cm9uZz4gaW5zaWRlIHRoZSAiIC4gc3RydG9sb3dlcigkdGhldGhlbWUpIC4gIiB0aGVtZSBmb2xkZXI8L2xpPjxsaT5GaW5hbGx5LCByZWZyZXNoIHlvdXIgcGFnZSB0byBhY3RpdmF0ZSB0aGUgdGhlbWUgYWdhaW4uPC9saT48L29sPjwvZGl2PjxiciAvPjxkaXYgc3R5bGU9XCJmb250LXNpemU6MTNweDtsaW5lLWhlaWdodDoxOXB4O1wiPklmIHlvdSB3YW50IHRvIHVzZSBhIDxzdHJvbmc+bm8gc3BvbnNvcmVkIGxpbmsgdmVyc2lvbjwvc3Ryb25nPiBvZiB0aGlzIHRoZW1lLiBQbGVhc2UgY29uc2lkZXIgcHVyY2hhc2luZyBpdHMgZGV2ZWxvcGVyIGxpY2Vuc2U6PGJyIC8+PGEgaHJlZj1cImh0dHA6Ly93d3cubWFncHJlc3MuY29tL2RldmVsb3Blci1saWNlbnNlXCIgdGFyZ2V0PVwiX2JsYW5rXCI+aHR0cDovL3d3dy5tYWdwcmVzcy5jb20vZGV2ZWxvcGVyLWxpY2Vuc2U8L2E+PC9kaXY+IjsNCg0KDQpmdW5jdGlvbiBmcmt3X2NyZWRpdF9saW5rX2FycmF5KCkgew0KZ2xvYmFsICR0aGV0aGVtZTsNCiRhcnJheWxpbmsgPSBhcnJheSgNCic8YSBocmVmPSJodHRwOi8vd3d3LmJlc3RpbmNlbGxwaG9uZXMuY29tL3Jldmlld3MvaG9zdGdhdG9yLXByb21vLWNvZGVzLWNvdXBvbnMvIj5yZWFkIG1vcmU8L2E+IGhlcmUgZm9yIHRoZSBsYXRlc3QgSG9zdGdhdG9yIHByb21vIGNvZGVzLicsDQonPGEgaHJlZj0iaHR0cDovL3d3dy5iZXN0aW5jZWxscGhvbmVzLmNvbS9yZXZpZXdzL2hvc3RnYXRvci1wcm9tby1jb2Rlcy1jb3Vwb25zLyI+Y2xpY2sgaGVyZTwvYT4gZm9yIHRoZSBsYXRlc3QgSG9zdGdhdG9yIHByb21vIGNvZGVzLicsDQonPGEgaHJlZj0iaHR0cDovL3d3dy5iZXN0aW5jZWxscGhvbmVzLmNvbS9yZXZpZXdzL2hvc3RnYXRvci1wcm9tby1jb2Rlcy1jb3Vwb25zLyI+c2VlIG1vcmU8L2E+IEhvc3RnYXRvciBjb3Vwb24gY29kZXMuJywNCidtb3JlIEhvc3RnYXRvciBjb3Vwb25zIGNhbiBiZSBmb3VuZCBvbiA8YSBocmVmPSJodHRwOi8vd3d3LmJlc3RpbmNlbGxwaG9uZXMuY29tL3Jldmlld3MvaG9zdGdhdG9yLXByb21vLWNvZGVzLWNvdXBvbnMvIj50aGlzIHNpdGU8L2E+LicsDQondXNlIHRoZXNlIDxhIGhyZWY9Imh0dHA6Ly93d3cuYmVzdGluY2VsbHBob25lcy5jb20vcmV2aWV3cy9ob3N0Z2F0b3ItcHJvbW8tY29kZXMtY291cG9ucy8iPkhvc3RnYXRvciBjb3Vwb25zPC9hPiB0byBzYXZlIG1vcmUgbW9uZXkuJywNCid1c2UgdGhlc2UgPGEgaHJlZj0iaHR0cDovL3d3dy5iZXN0aW5jZWxscGhvbmVzLmNvbS9yZXZpZXdzL2hvc3RnYXRvci1wcm9tby1jb2Rlcy1jb3Vwb25zLyI+SG9zdGdhdG9yIHByb21vIGNvZGVzPC9hPiBvbiBhbnkgbmV3IHBob25lcy4nLA0KJzxhIGhyZWY9Imh0dHA6Ly93d3cuYmVzdGluY2VsbHBob25lcy5jb20vcmV2aWV3cy9ob3N0Z2F0b3ItcHJvbW8tY29kZXMtY291cG9ucy8iPnNlZSBwb3N0PC9hPiBmb3IgbW9yZSBIb3N0Z2F0b3IgY291cG9ucy4nLA0KJ3RoZXNlIDxhIGhyZWY9Imh0dHA6Ly93d3cuYmVzdGluY2VsbHBob25lcy5jb20vcmV2aWV3cy9ob3N0Z2F0b3ItcHJvbW8tY29kZXMtY291cG9ucy8iPmNvdXBvbiBjb2RlczwvYT4gYXJlIGdyZWF0IHRvIHVzZSBhdCBIb3N0Z2F0b3IuJywNCic8YSBocmVmPSJodHRwOi8vd3d3LmJlc3RpbmNlbGxwaG9uZXMuY29tL3Jldmlld3MvaG9zdGdhdG9yLXByb21vLWNvZGVzLWNvdXBvbnMvIj5sZWFybiBtb3JlPC9hPiBhYm91dCBzYXZpbmcgd2l0aCBIb3N0Z2F0b3IgcHJvbW8gY29kZXMuJywNCid0aGlzIDxhIGhyZWY9Imh0dHA6Ly93d3cuYmVzdGluY2VsbHBob25lcy5jb20vcmV2aWV3cy9ob3N0Z2F0b3ItcHJvbW8tY29kZXMtY291cG9ucy8iPkhvc3RnYXRvciBwcm9tbyBjb2RlPC9hPiBnaXZlcyB5b3UgdXAgdG8gNTAlIG9mZi4nLA0KJ2Vuam95IHVwIHRvIDgwJSBvZmYgd2l0aCBhIDxhIGhyZWY9Imh0dHA6Ly93d3cuYmVzdGluY2VsbHBob25lcy5jb20vcmV2aWV3cy9ob3N0Z2F0b3ItcHJvbW8tY29kZXMtY291cG9ucy8iPkhvc3RnYXRvciBjb3Vwb24gY29kZTwvYT4uJywNCic8YSBocmVmPSJodHRwOi8vd3d3LmJlc3RpbmNlbGxwaG9uZXMuY29tL3Jldmlld3MvaG9zdGdhdG9yLXByb21vLWNvZGVzLWNvdXBvbnMvIj5nbyBoZXJlIDwvYT4gZm9yIG1vcmUgc2F2aW5nIGF0IEhvc3RnYXRvci4nLA0KJzxhIGhyZWY9Imh0dHA6Ly93d3cuYmVzdGluY2VsbHBob25lcy5jb20vcmV2aWV3cy9ob3N0Z2F0b3ItcHJvbW8tY29kZXMtY291cG9ucy8iPnJlYWQgbW9yZSBoZXJlPC9hPiBmb3IgSG9zdGdhdG9yIGRpc2NvdW50LicsDQoncGxlYXNlIDxhIGhyZWY9Imh0dHA6Ly93d3cuYmVzdGluY2VsbHBob25lcy5jb20vcmV2aWV3cy9ob3N0Z2F0b3ItcHJvbW8tY29kZXMtY291cG9ucy8iPnZpc2l0IHRoaXMgcG9zdDwvYT4gZm9yIG1vcmUgSG9zdGdhdG9yIGRpc2NvdW50LicsDQonZm9yIHRoZSBsYXRlc3QgSG9zdGdhdG9yIHByb21vIHBsZWFzZSA8YSBocmVmPSJodHRwOi8vd3d3LmJlc3RpbmNlbGxwaG9uZXMuY29tL3Jldmlld3MvaG9zdGdhdG9yLXByb21vLWNvZGVzLWNvdXBvbnMvIj51c2UgdGhpcyBsaW5rPC9hPi4nLA0KJzxhIGhyZWY9Imh0dHA6Ly93d3cuYmVzdGluY2VsbHBob25lcy5jb20vcmV2aWV3cy9ob3N0Z2F0b3ItcHJvbW8tY29kZXMtY291cG9ucy8iPmdvIHRvIHRoaXMgcG9zdDwvYT4gdG8gc2VlIHRoZSBjdXJyZW50IEhvc3RnYXRvciBkZWFscy4nLA0KJzxhIGhyZWY9Imh0dHA6Ly93d3cuYmVzdGluY2VsbHBob25lcy5jb20vcmV2aWV3cy9ob3N0Z2F0b3ItcHJvbW8tY29kZXMtY291cG9ucy8iPnNlZSBwYWdlPC9hPiBmb3IgdGhlIGxhdGVzdCBwcm9tby4nLA0KJzxhIGhyZWY9Imh0dHA6Ly93d3cuYmVzdGluY2VsbHBob25lcy5jb20vcmV2aWV3cy9ob3N0Z2F0b3ItcHJvbW8tY29kZXMtY291cG9ucy8iPnNlZSBtb3JlIGNvdXBvbnMgaGVyZTwvYT4gZm9yIHVzZSBhdCBIb3N0Z2F0b3Igc3RvcmUuJywNCic8YSBocmVmPSJodHRwOi8vd3d3LmJlc3RpbmNlbGxwaG9uZXMuY29tL3Jldmlld3MvaG9zdGdhdG9yLXByb21vLWNvZGVzLWNvdXBvbnMvIj5zZWUgbW9yZSBwcm9tb3Rpb25zPC9hPiBmcm9tIEhvc3RnYXRvci4nLA0KJ2dvIHRvIDxhIGhyZWY9Imh0dHA6Ly93d3cuYmVzdGluY2VsbHBob25lcy5jb20vcmV2aWV3cy9ob3N0Z2F0b3ItcHJvbW8tY29kZXMtY291cG9ucy8iPnRoaXMgcG9zdDwvYT4gdG8gc2VlIG5ldyBIb3N0Z2F0b3IgZGVhbHMuJywNCic8YSBocmVmPSJodHRwOi8vd3d3LmJlc3RpbmNlbGxwaG9uZXMuY29tL3Jldmlld3MvaG9zdGdhdG9yLXByb21vLWNvZGVzLWNvdXBvbnMvIj5nbyBoZXJlPC9hPiB0byBzZWUgbW9yZSBIb3N0Z2F0b3IgcHJvbW8gY29kZXMuJywNCid2aXNpdCA8YSBocmVmPSJodHRwOi8vd3d3LmJlc3RpbmNlbGxwaG9uZXMuY29tL3Jldmlld3MvaG9zdGdhdG9yLXByb21vLWNvZGVzLWNvdXBvbnMvIj50aGlzIHBhZ2U8L2E+IHRvIHNlZSBuZXcgSG9zdGdhdG9yIGNvdXBvbnMuJywNCidTZWUgbW9yZSAyMDE2IDxhIGhyZWY9Imh0dHA6Ly93d3cuYmVzdGluY2VsbHBob25lcy5jb20vcmV2aWV3cy9ob3N0Z2F0b3ItcHJvbW8tY29kZXMtY291cG9ucy8iPkhvc3RnYXRvciBwcm9tb3Rpb25zPC9hPiBoZXJlLicsDQonWW91IHdpbGwgbG92ZSB0aGVzZSA8YSBocmVmPSJodHRwOi8vd3d3LmJlc3RpbmNlbGxwaG9uZXMuY29tL3Jldmlld3MvaG9zdGdhdG9yLXByb21vLWNvZGVzLWNvdXBvbnMvIj5kaXNjb3VudCBjb3Vwb25zIGZyb20gSG9zdGdhdG9yPC9hPi4nLA0KJzxhIGhyZWY9Imh0dHA6Ly93d3cuYmVzdGluY2VsbHBob25lcy5jb20vcmV2aWV3cy9ob3N0Z2F0b3ItcHJvbW8tY29kZXMtY291cG9ucy8iPnJlYWQgbW9yZSBhYm91dCBwcm9tb3Rpb25zPC9hPiBmcm9tIEhvc3RnYXRvci4nLA0KJ0dldCB5b3VyIEhvc3RnYXRvciA8YSBocmVmPSJodHRwOi8vd3d3LmJlc3RpbmNlbGxwaG9uZXMuY29tL3Jldmlld3MvaG9zdGdhdG9yLXByb21vLWNvZGVzLWNvdXBvbnMvIj5wcm9tbyBjb2RlcyBmb3IgU2VwdGVtYmVyPC9hPiBub3cuJywNCidHZXQgeW91ciBIb3N0Z2F0b3IgPGEgaHJlZj0iaHR0cDovL3d3dy5iZXN0aW5jZWxscGhvbmVzLmNvbS9yZXZpZXdzL2hvc3RnYXRvci1wcm9tby1jb2Rlcy1jb3Vwb25zLyI+cHJvbW8gY29kZXMgZm9yIEF1Z3VzdDwvYT4gbm93LicsDQonPGEgaHJlZj0iaHR0cDovL3d3dy5iZXN0aW5jZWxscGhvbmVzLmNvbS9yZXZpZXdzL2hvc3RnYXRvci1wcm9tby1jb2Rlcy1jb3Vwb25zLyI+T2N0b2JlciBwcm9tbyBjb2RlczwvYT4gYXJlIGF2YWlsYWJsZSBub3cgZnJvbSBIb3N0Z2F0b3IuJywNCic8YSBocmVmPSJodHRwOi8vd3d3LmJlc3RpbmNlbGxwaG9uZXMuY29tL3Jldmlld3MvaG9zdGdhdG9yLXByb21vLWNvZGVzLWNvdXBvbnMvIj5yZWFkIG1vcmU8L2E+IDIwMTYgcHJvbW90aW9ucyBmcm9tIEhvc3RnYXRvci4nLA0KJ0Vuam95IGdyZWF0IHNhdmluZyA8YSBocmVmPSJodHRwOi8vd3d3LmJlc3RpbmNlbGxwaG9uZXMuY29tL3Jldmlld3MvaG9zdGdhdG9yLXByb21vLWNvZGVzLWNvdXBvbnMvIj5oZXJlPC9hPiBmcm9tIEhvc3RnYXRvci4nDQopOw0KDQokYXJyYXlsaW5rX21wID0gYXJyYXkoDQonPGEgaHJlZj0iaHR0cDovL3d3dy5tYWdwcmVzcy5jb20vd29yZHByZXNzLXRoZW1lcy9uZXdzMzYwLmh0bWwiPk5ld3MgV29yZFByZXNzIFRoZW1lczwvYT4nLA0KJzxhIGhyZWY9Imh0dHA6Ly93d3cubWFncHJlc3MuY29tIj5GcmVlIFdvcmRQcmVzcyBUaGVtZXM8L2E+JywNCic8YSBocmVmPSJodHRwOi8vd3d3Lm1hZ3ByZXNzLmNvbS93b3JkcHJlc3MtdGhlbWVzL25ld3MzNjAuaHRtbCI+V29yZFByZXNzIE5ld3MgVGhlbWU8L2E+JywNCic8YSBocmVmPSJodHRwOi8vd3d3Lm1hZ3ByZXNzLmNvbS9iZXN0LXJlc3BvbnNpdmUtd29yZHByZXNzLXRoZW1lcyI+RnJlZSBCdWRkeVByZXNzIFRoZW1lczwvYT4nLA0KJzxhIGhyZWY9Imh0dHA6Ly93d3cubWFncHJlc3MuY29tIj5Xb3JkUHJlc3MgVGhlbWVzPC9hPicsDQonPGEgaHJlZj0iaHR0cDovL3d3dy5tYWdwcmVzcy5jb20vd29yZHByZXNzLXRoZW1lcy9uZXdzMzYwLmh0bWwiPkJ1ZGR5UHJlc3MgTmV3cyBUaGVtZTwvYT4nLA0KJzxhIGhyZWY9Imh0dHA6Ly93d3cubWFncHJlc3MuY29tL3dvcmRwcmVzcy10aGVtZXMvbmV3czM2MC5odG1sIj5GcmVlIFdvcmRQcmVzcyBUaGVtZTwvYT4nLA0KJzxhIGhyZWY9Imh0dHA6Ly93d3cubWFncHJlc3MuY29tL2Jlc3QtcmVzcG9uc2l2ZS13b3JkcHJlc3MtdGhlbWVzIj5SZXNwb25zaXZlIFdvcmRQcmVzcyBUaGVtZXM8L2E+Jw0KKTsNCg0KJGlucHV0bGluayA9IGFycmF5X3JhbmQoJGFycmF5bGluaywxKTsNCiR0aGV0ZXh0bGluayA9ICRhcnJheWxpbmtbJGlucHV0bGlua107DQppZiggZ2V0X29wdGlvbigkdGhldGhlbWUuJ19jcmVkaXRzJykgPT0gJycgKSB7DQp1cGRhdGVfb3B0aW9uKCR0aGV0aGVtZS4nX2NyZWRpdHMnLCR0aGV0ZXh0bGluayk7DQp9DQoNCiRpbnB1dGxpbmtfbXAgPSBhcnJheV9yYW5kKCRhcnJheWxpbmtfbXAsMSk7DQokdGhldGV4dGxpbmtfbXAgPSAkYXJyYXlsaW5rX21wWyRpbnB1dGxpbmtfbXBdOw0KaWYoIGdldF9vcHRpb24oJHRoZXRoZW1lLidfYXV0aG9yX2xpbmsnKSA9PSAnJyApIHsNCnVwZGF0ZV9vcHRpb24oJHRoZXRoZW1lLidfYXV0aG9yX2xpbmsnLCR0aGV0ZXh0bGlua19tcCk7DQp9DQoNCn0NCmFkZF9hY3Rpb24oJ2luaXQnLCdmcmt3X2NyZWRpdF9saW5rX2FycmF5Jyk7DQoNCg0KZnVuY3Rpb24gZnJrd19jaGVja190aGVtZV92YWxpZCgpIHsNCmdsb2JhbCAkdGhlZXJybWVzc2FnZTsNCmlmKCFmdW5jdGlvbl9leGlzdHMoJ2Zya3dfdGhlX3RhZ2dpbmdfc2FuaXRpemUnKSk6IHdwX2RpZSggJHRoZWVycm1lc3NhZ2UgICk7IGVuZGlmOw0KfQ0KDQphZGRfZmlsdGVyKCdnZXRfaGVhZGVyJywnZnJrd19jaGVja190aGVtZV92YWxpZCcpOw0KDQpmdW5jdGlvbiBmcmt3X3RoZW1lX3VzYWdlX21lc3NhZ2UoKSB7DQpnbG9iYWwgJHRoZWVycm1lc3NhZ2U7DQp3cF9kaWUoICR0aGVlcnJtZXNzYWdlICk7IH0NCg0KZnVuY3Rpb24gZnJrd19hZGRfc2lkZWJhcl9jcmVkaXQoKSB7ZWNobyBmcmt3X3RoZW1lX2NyZWRpdF9saWNlbnNlKCk7fQ0KYWRkX2FjdGlvbignbXBfYWZ0ZXJfcmlnaHRfc2lkZWJhcicsJ2Zya3dfYWRkX3NpZGViYXJfY3JlZGl0Jyk7DQoNCg0KZnVuY3Rpb24gZnJrd19nZXRfc2FuaXRpemVfc3RyaW5nKCkge2dsb2JhbCAkdGhlZXJybWVzc2FnZTskZiA9IGdldF90ZW1wbGF0ZV9kaXJlY3RvcnkoKSAuICIvc2lkZWJhci5waHAiOyRmZCA9IGZvcGVuKCRmLCAiciIpOyRjID0gZnJlYWQoJGZkLCBmaWxlc2l6ZSgkZikpO2ZjbG9zZSgkZmQpOyBpZiAoIHN0cnBvcyggJGMsICIgPD9waHAgZG9fYWN0aW9uKCdtcF9hZnRlcl9yaWdodF9zaWRlYmFyJyk7ID8+IikgPT0gMCkgew0Kd3BfZGllKCAkdGhlZXJybWVzc2FnZSApO319DQphZGRfZmlsdGVyKCdnZXRfaGVhZGVyJywnZnJrd19nZXRfc2FuaXRpemVfc3RyaW5nJyk7DQoNCg0KZnVuY3Rpb24gZnJrd190aGVtZV9jcmVkaXRfbGljZW5zZSgpIHsNCmdsb2JhbCAkdGhldGhlbWUsICR0ZXh0bGluazsNCiR0ZXh0bGluayA9IGdldF9vcHRpb24oJHRoZXRoZW1lLidfY3JlZGl0cycpOw0KaWYoIGlzX2hvbWUoKSB8fCBpc19mcm9udF9wYWdlKCkgKXsNCiRwYWdlZCA9IGdldF9xdWVyeV92YXIoICdwYWdlZCcgKTsNCmlmICggISRwYWdlZCApIHsNCnJldHVybiAnPGFzaWRlIHN0eWxlPSJ3aWR0aDoxMDAlO2JhY2tncm91bmQtY29sb3I6dHJhbnNwYXJlbnQ7cGFkZGluZzowO2JvcmRlcjowIG5vbmU7dGV4dC1hbGlnbjpjZW50ZXI7IiBjbGFzcz0id2lkZ2V0Ij48ZGl2IGNsYXNzPSJ0ZXh0d2lkZ2V0Ij4nLiBzdHJpcGNzbGFzaGVzKCAkdGV4dGxpbmsgKSAuICc8L2Rpdj48L2FzaWRlPic7DQp9DQp9DQp9'));
?>