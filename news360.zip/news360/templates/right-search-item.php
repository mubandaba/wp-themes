<?php $ads_right_sidebar = get_theme_mod('right_sidebar_ad_code'); if($ads_right_sidebar) { ?>
<aside class="widget ads-widget">
<div class="textwidget"><?php echo stripcslashes(do_shortcode($ads_right_sidebar)); ?></div>
</aside>
<?php } ?>

<aside class="widget widget_recent_entries">
<h3 class="widget-title"><span><?php _e('Recent Posts', 'news360'); ?></span></h3>
<ul><?php wp_get_archives('type=postbypost&limit=10'); ?></ul>
</aside>