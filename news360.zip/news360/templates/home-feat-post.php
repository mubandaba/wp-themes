<?php
$home_feat = get_theme_mod('home_feat_post');
if($home_feat) {
if( frkw_is_in_home() ) { ?>
<div class="feat-post-box">
<?php
$post_count = 1;
$oddpost = '';
$allposttype = frkw_get_all_posttype();

query_posts( array( 'post_type'=> $allposttype, 'post__in' => explode(',', $home_feat), 'posts_per_page' => 6, 'ignore_sticky_posts' => 1, 'orderby' => 'post__in' ) );

if (have_posts()) : while ( have_posts() ) : the_post();
$thepostlink =  '<a href="'. get_permalink() . '" title="' . the_title_attribute('echo=0') . '">';
?>

<article <?php post_class('feat-post ' . $oddpost ); ?> id="post-<?php the_ID(); ?>">

<?php echo frkw_get_featured_image("<div class='feat-post-thumb'>".$thepostlink, "</a></div>", 600, 400, "alignleft", 'large', frkw_get_image_alt_text(),the_title_attribute('echo=0'), false); ?>

<div class="feat-post-wrapper">
<?php if( has_category() ) { ?>
<span class="entry-category home-entry-category"><?php echo frkw_get_singular_cat(); ?></span>
<?php } else { ?>
<?php echo frkw_get_post_taxonomy(', ','<span class="entry-category home-entry-category">', '</span>'); ?>
<?php } ?>
<h2 class="post-title entry-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
</div>

</article>

<?php ($oddpost == "alt-post") ? $oddpost="" : $oddpost="alt-post"; $post_count++; endwhile; wp_reset_query(); endif; ?>
</div>

<?php } } ?>