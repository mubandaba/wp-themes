<?php $ads_right_sidebar = get_theme_mod('right_sidebar_ad_code'); if($ads_right_sidebar) { ?>
<aside class="widget ads-widget">
<div class="textwidget"><?php echo stripcslashes(do_shortcode($ads_right_sidebar)); ?></div>
</aside>
<?php } ?>
<aside class="widget" id="social-box-widget">
<h3 class="widget-title"><?php _e('Stay Up Date', 'news360'); ?></h3>
<?php echo frkw_add_social_box(); ?>
</aside>
<aside class="widget">
<h3 class="widget-title"><span><?php _e('Search','news360'); ?></span></h3>
<?php get_search_form(); ?>
</aside>
<aside class="widget">
<h3 class="widget-title"><?php _e('Categories', 'news360'); ?></h3>
<ul><?php wp_list_categories('orderby=name&show_count=1&title_li='); ?></ul>
</aside>
<aside class="widget widget_recent_entries">
<h3 class="widget-title"><span><?php _e('Popular Posts','news360'); ?></span></h3>
<?php frkw_get_popular_posts(5); ?>
</aside>