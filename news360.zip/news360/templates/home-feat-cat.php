<?php
global $post;
$featcat1 = get_theme_mod('home_feat_cat1');
$featcat2 = get_theme_mod('home_feat_cat2');
$featcat3 = get_theme_mod('home_feat_cat3');
$featcat4 = get_theme_mod('home_feat_cat4');
$featcat5 = get_theme_mod('home_feat_cat5');

$featcat1_name = get_cat_name($featcat1);
$featcat2_name = get_cat_name($featcat2);
$featcat3_name = get_cat_name($featcat3);
$featcat4_name = get_cat_name($featcat4);
$featcat5_name = get_cat_name($featcat5);
?>


<?php
echo '<h4 class="latest-post-header">' . __('Latest News','news360'). '</h4>';
$postcount = 1;
query_posts( 'posts_per_page=3' );
if ( have_posts() ) : while ( have_posts() ) : the_post();
get_template_part( 'content', get_post_format() );
($oddpost == "alt-post") ? $oddpost="" : $oddpost="alt-post"; $postcount++;
endwhile; wp_reset_query(); endif;


/* home feat one */
if($featcat1 && $featcat1 != 'Choose a category') { ?>
<div class="feat-cat-box">
<?php
echo '<h4 class="feat-cat-header"><a href="'. get_category_link( $featcat1 ) . '">'. stripcslashes($featcat1_name) . '</a></h4>';
$post_cat_count = 1;
$custom_query1 = 'cat='. $featcat1 . '&showposts=5';
$my_query1 = new WP_Query($custom_query1);
while ($my_query1->have_posts()) : $my_query1->the_post(); $do_not_duplicate = $post->ID;
$thepostlink =  '<a href="'. get_permalink() . '" title="' . the_title_attribute('echo=0') . '">';
?>

<?php
if( $post_cat_count == 2 ) { echo '<!-- home feat 1 wrap --><div class="post-cat-right-wrap">'; } ?>
<article <?php post_class('feat-cat-post'); ?> id="post-<?php the_ID(); ?>">
<?php if( $post_cat_count < 2 ) {
echo frkw_get_featured_image("<div class='feat-post-thumb'>".$thepostlink, "</a></div>", 600, 400, "alignleft", 'large', frkw_get_image_alt_text(),the_title_attribute('echo=0'), false);
} else {
echo frkw_get_featured_image("<div class='feat-post-thumb'>".$thepostlink, "</a></div>", 300, 200, "alignleft", 'thumbnail', frkw_get_image_alt_text(),the_title_attribute('echo=0'), false);
}
?>
<div class="feat-post-wrapper">
<h2 class="post-title entry-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
<div class="post-content">
<?php get_template_part('templates/post-meta','home'); ?>
<?php if( $post_cat_count < 2 ) { ?>
<?php echo frkw_get_custom_the_excerpt(40); ?>
<?php } else { ?>
<?php echo frkw_get_custom_the_excerpt(10); ?>
<?php } ?>
</div>
</div>
</article>
<?php if( $post_cat_count == 5 ) { echo '</div><!-- end home feat 1 -->'; } ?>
<?php $post_cat_count++; endwhile; wp_reset_query(); ?>
</div>
<?php } ?>






<?php
/* home feat two */
if($featcat2 && $featcat2 != 'Choose a category') { ?>
<div class="feat-cat-box">
<?php
echo '<h4 class="feat-cat-header"><a href="'. get_category_link( $featcat2 ) . '">'. stripcslashes($featcat2_name) . '</a></h4>';
$post_cat_count = 1;
$custom_query2 = 'cat='. $featcat2 . '&showposts=5';
$my_query2 = new WP_Query($custom_query2);
while ($my_query2->have_posts()) : $my_query2->the_post(); $do_not_duplicate = $post->ID;
$thepostlink =  '<a href="'. get_permalink() . '" title="' . the_title_attribute('echo=0') . '">';
?>

<?php
if( $post_cat_count == 2 ) { echo '<!-- home feat 1 wrap --><div class="post-cat-right-wrap">'; } ?>
<article <?php post_class('feat-cat-post'); ?> id="post-<?php the_ID(); ?>">
<?php if( $post_cat_count < 2 ) {
echo frkw_get_featured_image("<div class='feat-post-thumb'>".$thepostlink, "</a></div>", 600, 400, "alignleft", 'large', frkw_get_image_alt_text(),the_title_attribute('echo=0'), false);
} else {
echo frkw_get_featured_image("<div class='feat-post-thumb'>".$thepostlink, "</a></div>", 300, 200, "alignleft", 'thumbnail', frkw_get_image_alt_text(),the_title_attribute('echo=0'), false);
}
?>
<div class="feat-post-wrapper">
<h2 class="post-title entry-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
<div class="post-content">
<?php get_template_part('templates/post-meta','home'); ?>
<?php if( $post_cat_count < 2 ) { ?>
<?php echo frkw_get_custom_the_excerpt(40); ?>
<?php } else { ?>
<?php echo frkw_get_custom_the_excerpt(10); ?>
<?php } ?>
</div>
</div>
</article>
<?php if( $post_cat_count == 5 ) { echo '</div><!-- end home feat 1 -->'; } ?>
<?php $post_cat_count++; endwhile; wp_reset_query(); ?>
</div>
<?php } ?>



<?php
/* home feat three */
if($featcat3 && $featcat3 != 'Choose a category') { ?>
<div class="feat-cat-box">
<?php
echo '<h4 class="feat-cat-header"><a href="'. get_category_link( $featcat3 ) . '">'. stripcslashes($featcat3_name) . '</a></h4>';
$post_cat_count = 1;
$custom_query3 = 'cat='. $featcat3 . '&showposts=5';
$my_query3 = new WP_Query($custom_query3);
while ($my_query3->have_posts()) : $my_query3->the_post(); $do_not_duplicate = $post->ID;
$thepostlink =  '<a href="'. get_permalink() . '" title="' . the_title_attribute('echo=0') . '">';
?>

<?php
if( $post_cat_count == 2 ) { echo '<!-- home feat 1 wrap --><div class="post-cat-right-wrap">'; } ?>
<article <?php post_class('feat-cat-post'); ?> id="post-<?php the_ID(); ?>">
<?php if( $post_cat_count < 2 ) {
echo frkw_get_featured_image("<div class='feat-post-thumb'>".$thepostlink, "</a></div>", 600, 400, "alignleft", 'large', frkw_get_image_alt_text(),the_title_attribute('echo=0'), false);
} else {
echo frkw_get_featured_image("<div class='feat-post-thumb'>".$thepostlink, "</a></div>", 300, 200, "alignleft", 'thumbnail', frkw_get_image_alt_text(),the_title_attribute('echo=0'), false);
}
?>
<div class="feat-post-wrapper">
<h2 class="post-title entry-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
<div class="post-content">
<?php get_template_part('templates/post-meta','home'); ?>
<?php if( $post_cat_count < 2 ) { ?>
<?php echo frkw_get_custom_the_excerpt(40); ?>
<?php } else { ?>
<?php echo frkw_get_custom_the_excerpt(10); ?>
<?php } ?>
</div>
</div>
</article>
<?php if( $post_cat_count == 5 ) { echo '</div><!-- end home feat 1 -->'; } ?>
<?php $post_cat_count++; endwhile; wp_reset_query(); ?>
</div>
<?php } ?>




<?php
/* home feat four */
if($featcat4 && $featcat4 != 'Choose a category') { ?>
<div class="feat-cat-box">
<?php
echo '<h4 class="feat-cat-header"><a href="'. get_category_link( $featcat4 ) . '">'. stripcslashes($featcat4_name) . '</a></h4>';
$post_cat_count = 1;
$custom_query4 = 'cat='. $featcat4 . '&showposts=5';
$my_query4 = new WP_Query($custom_query4);
while ($my_query4->have_posts()) : $my_query4->the_post(); $do_not_duplicate = $post->ID;
$thepostlink =  '<a href="'. get_permalink() . '" title="' . the_title_attribute('echo=0') . '">';
?>

<?php
if( $post_cat_count == 2 ) { echo '<!-- home feat 1 wrap --><div class="post-cat-right-wrap">'; } ?>
<article <?php post_class('feat-cat-post'); ?> id="post-<?php the_ID(); ?>">
<?php if( $post_cat_count < 2 ) {
echo frkw_get_featured_image("<div class='feat-post-thumb'>".$thepostlink, "</a></div>", 600, 400, "alignleft", 'large', frkw_get_image_alt_text(),the_title_attribute('echo=0'), false);
} else {
echo frkw_get_featured_image("<div class='feat-post-thumb'>".$thepostlink, "</a></div>", 300, 200, "alignleft", 'thumbnail', frkw_get_image_alt_text(),the_title_attribute('echo=0'), false);
}
?>
<div class="feat-post-wrapper">
<h2 class="post-title entry-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
<div class="post-content">
<?php get_template_part('templates/post-meta','home'); ?>
<?php if( $post_cat_count < 2 ) { ?>
<?php echo frkw_get_custom_the_excerpt(40); ?>
<?php } else { ?>
<?php echo frkw_get_custom_the_excerpt(10); ?>
<?php } ?>
</div>
</div>
</article>
<?php if( $post_cat_count == 5 ) { echo '</div><!-- end home feat 1 -->'; } ?>
<?php $post_cat_count++; endwhile; wp_reset_query(); ?>
</div>
<?php } ?>




<?php
/* home feat five */
if($featcat5 && $featcat5 != 'Choose a category') { ?>
<div class="feat-cat-box">
<?php
echo '<h4 class="feat-cat-header"><a href="'. get_category_link( $featcat5 ) . '">'. stripcslashes($featcat5_name) . '</a></h4>';
$post_cat_count = 1;
$custom_query5 = 'cat='. $featcat5 . '&showposts=5';
$my_query5 = new WP_Query($custom_query5);
while ($my_query5->have_posts()) : $my_query5->the_post(); $do_not_duplicate = $post->ID;
$thepostlink =  '<a href="'. get_permalink() . '" title="' . the_title_attribute('echo=0') . '">';
?>

<?php
if( $post_cat_count == 2 ) { echo '<!-- home feat 1 wrap --><div class="post-cat-right-wrap">'; } ?>
<article <?php post_class('feat-cat-post'); ?> id="post-<?php the_ID(); ?>">
<?php if( $post_cat_count < 2 ) {
echo frkw_get_featured_image("<div class='feat-post-thumb'>".$thepostlink, "</a></div>", 600, 400, "alignleft", 'large', frkw_get_image_alt_text(),the_title_attribute('echo=0'), false);
} else {
echo frkw_get_featured_image("<div class='feat-post-thumb'>".$thepostlink, "</a></div>", 300, 200, "alignleft", 'thumbnail', frkw_get_image_alt_text(),the_title_attribute('echo=0'), false);
}
?>
<div class="feat-post-wrapper">
<h2 class="post-title entry-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
<div class="post-content">
<?php get_template_part('templates/post-meta','home'); ?>
<?php if( $post_cat_count < 2 ) { ?>
<?php echo frkw_get_custom_the_excerpt(40); ?>
<?php } else { ?>
<?php echo frkw_get_custom_the_excerpt(10); ?>
<?php } ?>
</div>
</div>
</article>
<?php if( $post_cat_count == 5 ) { echo '</div><!-- end home feat 1 -->'; } ?>
<?php $post_cat_count++; endwhile; wp_reset_query(); ?>
</div>
<?php } ?>




