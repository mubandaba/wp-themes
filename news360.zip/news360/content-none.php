<?php do_action('mp_before_post_article'); ?>

<article <?php post_class(); ?> id="post-<?php the_ID(); ?>"<?php do_action('mp_article_start'); ?>>

<?php do_action('mp_before_post_wrapper'); ?>


<header class="post-title">
<h1 class="entry-title"><?php _e('Nothing Found', 'news360'); ?></h1>
</header>
<div class="post-content">
<div class="entry-content"<?php do_action('mp_article_post_content'); ?>>

<h3><?php _e('The page you requested cannot be found!', 'news360'); ?></h3>
<p><?php _e('Perhaps you are here because:', 'news360'); ?></p>
<ul>
<li><?php _e('The page has moved', 'news360'); ?></li>
<li><?php _e('The page url has been change', 'news360'); ?></li>
<li><?php _e('The page no longer exist', 'news360'); ?></li>
</ul>

<h3><?php _e('Try search with other terms.', 'news360'); ?></h3>
<p><?php get_search_form(); ?></p>

</div>
</div>


<?php do_action('mp_after_post_wrapper'); ?>
</article>

<?php do_action('mp_after_post_article'); ?>