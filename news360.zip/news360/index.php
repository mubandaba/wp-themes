<?php get_header(); ?>
<?php do_action( 'mp_before_container' ); ?>
<main id="container">
<?php do_action( 'mp_inside_container' ); ?>
<div class="content">
<?php do_action( 'mp_before_content_inner' ); ?>
<div class="content-inner">

<?php get_template_part('templates/home-feat-post'); ?>

<?php do_action( 'mp_before_content_area' ); ?>
<div id="entries" class="content-area">
<?php do_action( 'mp_before_content_area_inner' ); ?>
<div class="content-area-inner">
<?php do_action( 'mp_inside_content_area_inner' ); ?>
<?php
$featcat1 = get_theme_mod('home_feat_cat1');
if($featcat1 && $featcat1 != 'Choose a category') {
get_template_part('templates/home-feat-cat');
} else {
$postcount = 1;
if ( have_posts() ) : while ( have_posts() ) : the_post();
get_template_part( 'content', get_post_format() );
($oddpost == "alt-post") ? $oddpost="" : $oddpost="alt-post"; $postcount++;
endwhile;
else :
get_template_part( 'content', 'none' );
endif;
}
?>
</div>
<?php do_action( 'mp_after_content_area_inner' ); ?>
</div>
<?php do_action( 'mp_after_content_area' ); ?>
<?php comments_template(); ?>
</div>
<?php do_action( 'mp_after_content_inner' ); ?> 
</div>
<?php do_action( 'mp_after_content' ); ?>

</main>

<?php do_action( 'mp_after_container' ); ?>