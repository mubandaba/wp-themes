jQuery( function($) {

$(document).ready(function(){
jQuery("ul.sf-menu").supersubs({
            minWidth:    18,
            maxWidth:    18,
            extraWidth:  1
        }).superfish();

});

 jQuery("#mobile-nav ul").hide('fast');
 jQuery(".mobile-open-click").click(function(){
 jQuery("#mobile-nav ul").toggle('fast');
 }
 );

 jQuery('#mp-ticker').ticker({
    random:        false, // Whether to display ticker items in a random order
    itemSpeed:     3000,  // The pause on each ticker item before being replaced
    cursorSpeed:   25,    // Speed at which the characters are typed
    pauseOnHover:  false,  // Whether to pause when the mouse hovers over the ticker
    finishOnHover: true,  // Whether or not to complete the ticker item instantly when moused over
    cursorOne:     '_',   // The symbol for the first part of the cursor
    cursorTwo:     '-',   // The symbol for the second part of the cursor
    fade:          true,  // Whether to fade between ticker items or not
    fadeInSpeed:   600,   // Speed of the fade-in animation
    fadeOutSpeed:  300    // Speed of the fade-out animation
 });

});


/*! jQuery Ticker Plugin v1.2.1 | https://github.com/BenjaminRH/jquery-ticker | Copyright 2014 Benjamin Harris | Released under the MIT license */
(function(l){function D(c){for(var a=c.length-1;0<a;a--){var w=Math.floor(Math.random()*(a+1)),b=c[a];c[a]=c[w];c[w]=b}return c}function x(c,a){a=a||[];return c.replace(/\x3c!--.*?--\x3e/img,"").replace(/<\/?([a-z][a-z0-9]*)\b[^>]*>/img,function(c,b){return-1!==a.indexOf(b.toLowerCase())?c:""})}l.fn.ticker=function(c){var a=l.extend({},l.fn.ticker.defaults,c);return this.each(function(){function c(){u=!0;y?(y=!1,b()):z=setTimeout(function(){a.pauseOnHover&&e.hasClass("hover")?(clearTimeout(h),c()):b()},a.itemSpeed)}function b(){u?(u=!1,A()):d>k[f].length?B():a.finishOnHover&&a.pauseOnHover&&e.hasClass("hover")&&d<=k[f].length?(p.html(v()),d+=1,b()):h=setTimeout(function(){a.pauseOnHover&&e.hasClass("hover")?(clearTimeout(h),b()):(A(),B())},a.cursorSpeed)}function B(){d>k[f].length&&(f+=1,d=0,f==k.length&&(f=0),clearTimeout(h),clearTimeout(z),c())}function A(){0===d&&a.fade?(clearTimeout(h),p.fadeOut(a.fadeOutSpeed,function(){p.html(v());p.fadeIn(a.fadeInSpeed,function(){d+=1;b()})})):(p.html(v()),d+=1,clearTimeout(h),b())}function v(){var c,b,q,m;switch(d%2){case 1:c=a.cursorOne;break;case 0:c=a.cursorTwo}d>=k[f].length&&(c="");var n="",e=[];for(b=0;b<d;b++){m=null;for(q=0;q<r[f].length;q++)if(r[f][q]&&r[f][q].start===b){m=r[f][q];break}m&&(n+=m.tag,m.selfClosing||("/"===m.tag.charAt(1)?e.pop():e.push(m.name)));n+=k[f][b]}for(b=0;b<e.length;b++)n+="</"+e[b]+">";return n+c}var e=l(this),p,E=e.find("li"),k=[],r={},z,h,f=0,d=0,y=!0,u=!0,F="a b strong span i em u".split(" ");if(a.finishOnHover||a.pauseOnHover)e.removeClass("hover"),e.hover(function(){l(this).toggleClass("hover")});var t,C;E.each(function(a,c){var b=t=x(l(this).html(),F),d;d=[];for(var e=/<\/?([a-z][a-z0-9]*)\b[^>]*>/im,f=/\/\s{0,}>$/m,h=[],g;null!==(g=e.exec(b));)if(0===d.length||-1!==d.indexOf(g[1]))g={tag:g[0],name:g[1],selfClosing:f.test(g[0]),start:g.index,end:g.index+g[0].length-1},h.push(g),b=b.slice(0,g.start)+b.slice(g.end+1),e.lastIndex=0;C=h;t=x(t);k.push(t);r[k.length-1]=C});a.random&&D(k);e.find("ul").after("<div></div>").remove();p=e.find("div");c()})};l.fn.ticker.defaults={random:!1,itemSpeed:3E3,cursorSpeed:50,pauseOnHover:!0,finishOnHover:!0,cursorOne:"_",cursorTwo:"-",fade:!0,fadeInSpeed:600,fadeOutSpeed:300}})(jQuery);