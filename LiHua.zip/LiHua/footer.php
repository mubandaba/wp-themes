		<div id="footer">
			<div class="footerzi">
				<p>
					<?php bloginfo('name'); ?> 版权所有 ©2013 All Rights Reserved.
				</p>
			</div>
			<div class="footerzi1">
				<p>
					主题设计 <a href="http://www.mao01.com/" title="wordpress主题定制">猫猫工作室</a> .Powered By WordPress.
				</p>
			</div>
		</div>
	</div>
	<div class="c">
	</div>
</div>			
</body>
<?php wp_footer(); ?>
</html>