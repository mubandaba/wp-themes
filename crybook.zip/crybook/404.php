<?php get_header(); ?>
<!--#content:start-->
    	<div id="content">
        	<div class="entry" id="post-error">
            	<h2>404 - File not found</h2>
                <p>Sorry but we can't find the right page you&rsquo;re looking for</p>
            </div>
        </div>
<!--#content:end-->
<?php get_sidebar(); ?>
<?php get_footer(); ?>