    </div>
    	<div id="footer">
        	<p>
				&copy; <?php echo date('Y'); ?> <a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a>. Theme designed by <a href="http://themetation.com">Themetation</a> &amp; developed by <a href="http://crynobone.com">Crynobone</a>. Happily powered by <a href="http://wordpress.org/">WordPress</a>.             	
            </p>
			<?php wp_footer(); ?>
        </div>


</body>
</html>