<div id="sidebar">

<div class="widget" id="one">
	<?php dynamic_sidebar( 'one' ); ?>
</div>

<div class="widget" id="two">
	<?php dynamic_sidebar( 'two' ); ?>
</div>

</div>