<?php get_header(); ?>
<div id="header_info">
    <nav class="header-nav reveal">
        <a style="text-decoration:none;" href="<?php echo site_url() ?>" class="header-logo" title="TonyHe">404 :)</a>
        <p class="lead" style="margin-top: 0px;display:block">抱歉，你请求的内容消失嘞</p>
        <a href="<?php echo site_url() ?>" style="padding: 4px 18px 6px 19px;border: 2px solid rgb(0, 123, 255);border-radius: 4px;font-weight: 600;line-height: 80px;text-decoration:none">返回首页</a>
    </nav>
</div>