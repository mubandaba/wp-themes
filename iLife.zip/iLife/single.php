<?php get_header(); ?>
		<div id="single-content">
			<div id="post-home">
				<?php if(have_posts()) : while (have_posts()) : the_post(); ?>
				<div id="post-header">
					<?php if (function_exists('get_avatar')) { echo get_avatar( get_the_author_email(), '48' ); }?>
					<div id="post-title">
                    	<div id="post-title-left">
                            <h1><?php the_title_attribute(); ?></h1>
                            <p>by <?php the_author() ?>&#160;&#124;&#160;<?php the_time('M d, Y'); ?>&#160;&#124;&#160;in <?php the_category(', '); ?>&#160;&#124;&#160;<?php if(function_exists('the_views')) {$views = the_views(0);preg_match('/\d+/', $views, $match);echo '<span>'._e( 'Views',iphoto).' '.$match[0].'</span>';} ?>&#160;&#124;&#160;<?php _e( 'Comments',iphoto).' ';?><?php comments_popup_link('0', '1', '%'); ?></p>
                        </div>
                        <div class="post-info2"> <?php if(function_exists('wizylike')) wizylike('button');  ?></div>	 
					</div>
					<div class="clear"></div>
				</div>
				<div class="post-content">
					<?php the_content(''); ?>
                    <div class="single_tag_share">
                        <span class="bb_tag"> <?php the_tags('', ',', ' '); ?></span>
                        <span class="delimiter">&nbsp;</span>
                        <div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare">
                            <span class="bds_more">分享到：</span>
                            <a class="bds_qzone">QQ空间</a>
                            <a class="bds_tsina">新浪微博</a>
                            <a class="bds_tqq">腾讯微博</a>
                            <a class="bds_renren">人人网</a>
                            <a class="bds_kaixin001">开心网</a>
                            <a class="shareCount"></a>
                        </div>
                    </div>
				</div>
				<?php endwhile; endif; ?>
				<div id="comments">
					<?php comments_template('', true); ?>
				</div>
			</div>
		</div>   
<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=311413" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
	document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + new Date().getHours();
</script> 
 <script type="text/javascript">
(
    function(d)
    {
	var e = d.createElement('script'),
	    a = d.getElementsByTagName('head')[0] || d.body;
	   
	if(a) {
	    e.setAttribute('type','text/javascript');
	    e.setAttribute('charset','UTF-8');
	    e.setAttribute('src','http://apitu.jipin.kaixin001.com/remote/assistant?t='+(+new Date));
	    a.appendChild(e);
	}
    }
)(document); 
</script>
<script type="text/javascript" defer="defer" charset="utf-8">
    (function(d,t) {
      var appendScript = function() {
        var a   = d.createElement('script');
        a.id    = 'huaban_share_script';
        a.async = true;
        a.setAttribute('charset','utf-8');
        a.src   = 'http://huaban.com/js/pinmarklet.js?' + Math.floor(+new Date/1E7);
        var s   = d.getElementsByTagName(t)[0];
        s.parentNode.insertBefore(a, s);
      }
      if (window.attachEvent) {
        window.attachEvent('onload', function(){setTimeout(appendScript, 1000);});
      } else {
        appendScript();
      }
    })(document, 'script');
</script>  
<?php get_sidebar(); ?>
<?php get_footer(); ?>