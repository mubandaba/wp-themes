<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
<?php include('includes/seo.php'); ?>
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/style.css" type="text/css" media="screen" />
<link rel="shortcut icon" href="<?php bloginfo('url');?>/favicon.ico" type="image/x-icon" />
<?php if(get_option('iphoto_lib')!="") : ?>
<script type="text/javascript" src="http://lib.sinaapp.com/js/jquery/1.4.4/jquery.min.js"></script>
<?php else : ?>	
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/includes/jquery.min.js"></script>
<?php endif; ?>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/includes/all.js"></script>
<?php if (is_home() || is_archive()) { ?>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/includes/jquery.waterfall.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/includes/index.js"></script>
<?php } elseif (is_singular()){ ?>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/includes/comments-ajax.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/includes/phzoom.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/includes/single.js"></script>
<script type="text/javascript">/* <![CDATA[ */var base="<?php bloginfo('url'); ?>"; var themeurl="<?php echo get_bloginfo('template_directory') . '/';?>";css_string = '#main{-moz-border-radius:0 0 10px 10px;-webkit-border-radius:0 0 10px 10px;border-radius:0 0 10px 10px;}';css_string += 'a:link, a:visited ';css_string += '{-webkit-transition: all 0.3s ease-in-out;}';css_string += '::-moz-selection,::selection';css_string += '{background-color: #a0a356; color: #fff;}';css_string += '.paging a.active,.readmore a, .readmore a:hover, .comment, .avatar,#author, #email, #url,#submit_mail,#ajaxnav a,.postimg,#box_content,blockquote,pre,code,.nbox a,.nbox,#saytooltip,#submit_comment,#submit,#rc_submit, input[type="text"],textarea,#smelislist';css_string += '{-moz-border-radius: 5px; -khtml-border-radius: 5px; -webkit-border-radius: 5px;border-radius: 5px;}';css_string += 'pre';css_string += '{-moz-box-shadow: rgba(50,50,50,1) 1px 4px 7px; -webkit-box-shadow: rgba(50,50,50,1) 1px 4px 7px; -khtml-box-shadow: rgba(50,50,50,1) 1px 4px 7px; box-shadow: rgba(50,50,50,1) 1px 4px 7px;}';css_string += '.mostactive img,#smelislist';css_string += '{-moz-box-shadow: rgba(0,0,0,.8) 1px 7px 12px; -webkit-box-shadow: rgba(0,0,0,.8) 1px 7px 12px; -khtml-box-shadow: rgba(0,0,0,.8) 1px 7px 12px; box-shadow: rgba(0,0,0,.8) 1px 7px 12px;}';css_string += '#submit_comment,#submit,#submit_mail,#rc_submit';css_string += '{-moz-box-shadow:0 1px 1px #aaa;-webkit-box-shadow:0 1px 1px #aaa;}';css_string += 'input:focus,textarea:focus,#email:focus, #url:focus, #author:focus';css_string += '{-moz-box-shadow: 0 0 8px #52A8EC; -webkit-box-shadow: 0 0 8px #52A8EC;}';document.write('<style type="text\/css">' + css_string + '<\/style>');/* ]]> */</script>
<?php }?>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
	<div id="header">
		<div id="header-box">
            <div class="dl-btns">
                <a class="dl-btn logo" href="<?php bloginfo('url'); ?>"><span class=icon-box><I class="im im-logo"></I></span><span class=btn-txt><?php bloginfo('name'); ?></span></a>
            </div> 
			<div id="nav">
					<ul>
                        <li><?php wp_nav_menu( array( 'menu' => 'mymenu', 'depth' => 1) ); ?></li>
             	</ul>
			 </div>
			<div id="search">		
            	 <form id="searchform" method="get" action="<?php bloginfo('home'); ?>">
                            <input type="text" onblur="if (this.value == '') {this.value = 'Search……';}" onfocus="if (this.value == 'Search……') {this.value = '';}" class="s" name="s" value="Search……" />
                            <button type="submit"><?php _e("Search"); ?></button>
                        </form>
                    </div>
            </div>
            	<div id="header_right"><div id="fm_show"><a href="http://ishine.me/fm" title="Digital FM" target="_blank"><img src="<?php bloginfo('template_url'); ?>/images/fm_show2.gif" /></a></div>
                <?php if (!(current_user_can('level_0'))){ ?>
				<div id="login"><a href="#" title="<?php _e('Log in','iphoto'); ?>"><?php _e('Log in','iphoto'); ?></a></div>
				<div id="login-form">
					<form action="<?php echo get_option('home'); ?>/wp-login.php" method="post">
						<div id="actions">
							<p><?php _e('Username','iphoto'); ?></p>
							<input id="log" type="text" name="log" value="<?php echo wp_specialchars(stripslashes($user_login), 1) ?>" size="20" />
							<p><?php _e('Password','iphoto'); ?><a href="<?php echo get_option('home'); ?>/wp-login.php?action=lostpassword"><?php _e('Forgot password ?','iphoto'); ?></a></p>
							<input type="password" name="pwd" id="pwd" size="20"  />
							<div class="clear"></div>
							<input type="submit" name="submit" value="<?php _e('Log in','iphoto'); ?>" class="button" />
							<input type="hidden" name="redirect_to" value="<?php bloginfo('url'); ?>/post" />
                            <?php do_action('comment_form', $post->ID); ?>
						</div>
					</form>
				</div></div>
			<?php } else { ?>
				<div id="logined">
					<a href="#" id="info" title="info"><?php global $current_user;get_currentuserinfo();echo get_avatar( $current_user->user_email, 36);echo '<span>';echo $current_user->user_login;echo '</span>';?></a>
					<div id="info-content" class="hidden">
						<a id="info-post" href="<?php bloginfo('url'); ?>/post" title="<?php _e('Post','iphoto'); ?>"><?php _e('Post','iphoto'); ?></a><a id="info-quit" href="<?php echo wp_logout_url( get_bloginfo('url') ); ?>" title="<?php _e('Logout','iphoto'); ?>"><?php _e('Logout','iphoto'); ?></a>
					</div>
				</div>
			<?php }?>
			<div class="clear"></div>
		</div>
	</div>
	<div id="wrapper">