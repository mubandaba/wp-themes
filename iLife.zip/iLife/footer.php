<div class="clear"></div>
</div>
<div id="footer">
	<p><?php if(stripslashes(get_option('iphoto_copyright'))!=''){echo stripslashes(get_option('iphoto_copyright'));}else{echo 'Copyright &copy; '.date("Y").' '.'<a href="'.home_url( '/' ).'" title="'.esc_attr( get_bloginfo( 'name') ).'">'.esc_attr( get_bloginfo( 'name') ).'</a> All Rights Reserved';}?></p><p>WordPress 驱动, Theme By <a href="http://ishine.me" target="_blank" title="Digital Life">Shine</a></p>
 <!--特别提醒：使用或修改主题请保留页脚作者链接，谢谢合作 --><script src="http://s13.cnzz.com/stat.php?id=2487312&web_id=2487312" language="JavaScript"></script>
</div>
<!--[if IE 6]><script src="<?php bloginfo('template_url');?>/includes/jQuery.autoIMG.min.js"></script><![endif]-->
<?php wp_footer(); ?>
<script type="text/javascript">
(function() {
var $backToTopTxt = "", $backToTopEle = $('<div class="backToTop"></div>').appendTo($("body"))
.text($backToTopTxt).attr("title", $backToTopTxt).click(function() {
$("html, body").animate({ scrollTop: 0 }, 120);
}), $backToTopFun = function() {
var st = $(document).scrollTop(), winh = $(window).height();
(st > 0)? $backToTopEle.show(): $backToTopEle.hide();
//IE6下的定位
if (!window.XMLHttpRequest) {
$backToTopEle.css("top", st + winh - 166);
}
};
$(window).bind("scroll", $backToTopFun);
$(function() { $backToTopFun(); });
})();
</script> 
</body>
</html>