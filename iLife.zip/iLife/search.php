<?php get_header(); ?>
<div id="search_main">
    <div id="post-title-page" style="padding:10px;">
    	<h1><?php
/* Search Count */
$allsearch = &new WP_Query("s=$s&showposts=-1");
$key = wp_specialchars($s, 1);
$count = $allsearch->post_count;
printf('找到 %1$s 条关于“%2$s”的结果：', $count, $key, timer_stop(0,3));
?> </h1>
    </div>
<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>
	<div id="post-<?php the_ID(); ?>" class="post">
        <div class="postmeta">
    		<span class="sear_tit"><a title="<?php the_title_attribute(); ?>" href="<?php the_permalink() ?>"><?php the_title_attribute(); ?></a></span>
			<span class="alignleft sear_fenlei">分类：<?php the_category(',') ?></span><span class="alignright">-<?php the_time(' m月 d日,Y'); ?></span>
		</div>
		<div class="clear"></div>
	</div>
<?php endwhile; ?>
<div id="pagenavi"><?php pagenavi(); ?></div>
<?php else: ?>
		<div class="post"><div class="postentry"><p>没有找到文章</p></div></div>
		<?php endif; ?>
</div>
<?php get_footer(); ?> 