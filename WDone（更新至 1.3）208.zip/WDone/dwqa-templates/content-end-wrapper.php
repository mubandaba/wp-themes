</div>
</article>
</div>
</div>
<?php get_sidebar('dwqa'); ?>
</div>
</div>
</div>