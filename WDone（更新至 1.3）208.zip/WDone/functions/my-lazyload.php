<?php
add_action('wp_enqueue_scripts', 'lazyload_scripts');
add_filter('the_content', 'lazyload_content',999);
add_filter('wp_get_attachment_link', 'lazyload_content',999);
add_filter('get_avatar', 'lazyload_content',999);
function lazyload_scripts() {
	wp_enqueue_script(  'lazyload', get_template_directory_uri() . '/js/lazyload.min.js',array('jquery'),theme_ver, 1,true);
	wp_enqueue_script( 'comments-ajax-lazyload', get_template_directory_uri() . '/js/comments-ajax-lazyload.js', array('lazyload','comments-ajax'), theme_ver, 1,true);
}
function lazyload_content($content) {
	if( is_page(array( 'register', 'profile' )) || is_feed() || is_preview() || ( function_exists( 'is_mobile' ) && is_mobile() ) || is_admin() )
	{
		return $content;
	}else{
		$loadimg_url = get_template_directory_uri() .'/images/grey.gif';
		$content=preg_replace('/<img(.+)src=[\'"]([^\'"]+)[\'"](.*)>/i',"<img \$1 data-original=\"\$2\" src=\"$loadimg_url\"\$3>\n<noscript>\$0</noscript>",$content);
	}
	return $content;
}