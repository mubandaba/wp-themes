<?php
/*-----------------------------------------------------------------------------------*/
# Check PHP version
/*-----------------------------------------------------------------------------------*/
add_action('init', 'php_version_check_massage');
function php_version_check_massage(){
    $phpVer = PHP_VERSION;
    if ( version_compare($phpVer, '5.3', '<') || version_compare($phpVer, '5.5', '>')){
    wp_die(sprintf(__('<p style="color:#c00;font-size:16px;">Current theme can only be used in PHP 5.3.x and PHP 5.4.x series of PHP environments, your current PHP version is %s, does not meet the requirements!</p><p>Note: To remove this message, please delete the theme via FTP.</p>','cmp'), $phpVer ) );
    }
}
/*-----------------------------------------------------------------------------------*/
# Check WordPress version
/*-----------------------------------------------------------------------------------*/
add_action('admin_notices', 'wp_version_check_massage');
function wp_version_check_massage(){
    global $wp_version;
    $ver = 4.2;
    if (version_compare($wp_version, $ver) < 0) {
        echo '<div id="message" class="error"><p>'.__("WordPress version you are currently using is less than 4.2, in order to ensure the normal use of the theme, please update to version 4.2 or above.","cmp").'</p></div>';
    }
}

/*-----------------------------------------------------------------------------------*/
# Check  WP-PostViews
/*-----------------------------------------------------------------------------------*/
add_action('admin_notices', 'plugin_check_massage');
function plugin_check_massage(){
    $plugin_messages = array();
    include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
    // Download WP-PostViews plugin
    if(!is_plugin_active( 'wp-postviews/wp-postviews.php' )){
        $plugin_messages[] = __('This theme requires you to install the <strong> WP-PostViews </strong> plugin, <a href="http://wordpress.org/plugins/wp-postviews/" target="_blank">download it from here</a>.','cmp');
    }
    if(count($plugin_messages) > 0){
        echo '<div id="message" class="error">';
        foreach($plugin_messages as $message)
        {
            echo '<p>'.$message.'</p>';
        }
        echo '</div>';
    }
}
/*-----------------------------------------------------------------------------------*/
# Setup Theme
/*-----------------------------------------------------------------------------------*/
add_action( 'after_setup_theme', 'cmp_setup' );
function cmp_setup() {
    global $default_data;
    add_theme_support( 'automatic-feed-links' );
    load_theme_textdomain( 'cmp', get_template_directory() . '/languages' );
    register_nav_menus( array(
        'main-menu' => __( 'Main Menu', 'cmp' ),
        'foot-menu' => __( 'Footer Menu', 'cmp' ),
        'user-menu' => __( 'User Menu', 'cmp' ),
        'top-menu' => __( 'Top Menu', 'cmp' )
        ) );
}
/*-----------------------------------------------------------------------------------*/
# Get Theme Options
/*-----------------------------------------------------------------------------------*/
function cmp_get_option( $name ) {
    $get_options = get_option( 'cmp_options' );
    if( !empty( $get_options[$name] ))
        return $get_options[$name];
    return false ;
}
/*-----------------------------------------------------------------------------------*/
# Get templates
/*-----------------------------------------------------------------------------------*/
function cmp_include($template){
    include ( get_template_directory() . '/includes/'.$template.'.php' );
}
/*-----------------------------------------------------------------------------------*/
 # Remove nav classes
 # From http://www.wpdaxue.com/remove-wordpress-nav-classes.html
/*-----------------------------------------------------------------------------------*/
add_filter('nav_menu_css_class', 'my_css_attributes_filter', 100, 1);
add_filter('nav_menu_item_id', 'my_css_attributes_filter', 100, 1);
add_filter('page_css_class', 'my_css_attributes_filter', 100, 1);
function my_css_attributes_filter($var) {
    return is_array($var) ? array_intersect($var, array('current-menu-item','current-post-ancestor','current-menu-ancestor','current-menu-parent','display-none')) : '';
}
/*-----------------------------------------------------------------------------------*/
# Comments containing the full English and prevent Japanese
/*-----------------------------------------------------------------------------------*/
function wpdaxue_comment_post( $incoming_comment ) {
$pattern = '/[一-龥]/u';  // Must contain Chinese
$text = '/['.trim(cmp_get_option( 'sensitive_character' )).']/u';
if(cmp_get_option( 'comment_chinese' ) && !preg_match($pattern, $incoming_comment['comment_content'])) {
    wp_die( __("Your comment must contain Chinese.","cmp" ));
}
if(cmp_get_option( 'comment_sensitive' ) && preg_match($text, $incoming_comment['comment_content'])) {
    wp_die( __("Comments are not allowed sensitive character.","cmp" ) );
}
return( $incoming_comment );
}
add_filter('preprocess_comment', 'wpdaxue_comment_post');
/*-----------------------------------------------------------------------------------*/
# If the menu doesn't exist
/*-----------------------------------------------------------------------------------*/
function cmp_nav_fallback(){
    echo '<li class="the_tips">'.__( 'Please Visit "Appearance > Menus" to build menus' , 'cmp' ).'</li>';
}
/*-----------------------------------------------------------------------------------*/
# Post Thumbinals
/*-----------------------------------------------------------------------------------*/
if ( function_exists( 'add_theme_support' ) ){
    add_theme_support( 'post-thumbnails' );
}

/**
 * Get the Attachment ID from an Image URL
 * https://philipnewcomer.net/2012/11/get-the-attachment-id-from-an-image-url-in-wordpress/
 * Since 1.3
 */
function cmp_get_image_id( $attachment_url = '' ) {
    global $wpdb;
    $attachment_id = false;
    // If there is no url, return.
    if ( '' == $attachment_url )
        return;
    // Get the upload directory paths
    $upload_dir_paths = wp_upload_dir();
    // Make sure the upload path base directory exists in the attachment URL, to verify that we're working with a media library image
    if ( false !== strpos( $attachment_url, $upload_dir_paths['baseurl'] ) ) {
        // If this is the URL of an auto-generated thumbnail, get the URL of the original image
        $attachment_url = preg_replace( '/-\d+x\d+(?=\.(jpg|jpeg|png|gif)$)/i', '', $attachment_url );
        // Remove the upload path base directory from the attachment URL
        $attachment_url = str_replace( $upload_dir_paths['baseurl'] . '/', '', $attachment_url );
        // Finally, run a custom database query to get the attachment ID from the modified attachment URL
        $attachment_id = $wpdb->get_var( $wpdb->prepare( "SELECT wposts.ID FROM $wpdb->posts wposts, $wpdb->postmeta wpostmeta WHERE wposts.ID = wpostmeta.post_id AND wpostmeta.meta_key = '_wp_attached_file' AND wpostmeta.meta_value = '%s' AND wposts.post_type = 'attachment'", $attachment_url ) );
    }
    return $attachment_id;
}
/**
 * Get the first image ID of a post
 * Since 1.3
 */
function cmp_get_first_image_id($postID){
    $attachment_id = '';
    $args = array(
        'numberposts' => 1,
        'order' => 'ASC',
        'post_mime_type' => 'image',
        'post_parent' => $postID,
        'post_status' => null,
        'post_type' => 'attachment',
    );
    $attachments = get_children( $args );
    if ( $attachments ) {
        foreach ( $attachments as $attachment ) {
            $attachment_id = $attachment->ID;
        }
    }
    return $attachment_id;
}
/**
 * Get a random thumbnail for a post
 * Since 1.3
 */
function cmp_get_random_thumb($width,$height){
    $random_thumb = '';
    $random = mt_rand(1, 5);
    $random_thumb = get_template_directory_uri().'/images/pic/'.$random.'-'.$width.'x'.$height.'.jpg';
    return $random_thumb;
}
/**
 * 001. Use OTF Regenerate Thumbnails to get thumb url
 * https://github.com/gambitph/WP-OTF-Regenerate-Thumbnails
 * Since 1.3
 */
require_once(TEMPLATEPATH . '/functions/otf_regen_thumbs.php');
function cmp_otf_thumb_src($width,$height){
    global $post;
    $post_thumbnail_src = '';
    if( $values = get_post_custom_values("thumb") ) {
        $values = get_post_custom_values("thumb");
        $image_id = cmp_get_image_id($values[0]);
        $thumbnail_src = wp_get_attachment_image_src($image_id,array($width,$height));
        $post_thumbnail_src = $thumbnail_src[0];
    } elseif( has_post_thumbnail() ){
        $thumbnail_src = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),array($width,$height));
        $post_thumbnail_src = $thumbnail_src[0];
    } else {
        $attachment_id = cmp_get_first_image_id($post->ID);
        if ( $attachment_id ) {
            $thumbnail_src = wp_get_attachment_image_src( $attachment_id, array($width,$height));
            $post_thumbnail_src = $thumbnail_src[0];
        }else{
            $post_thumbnail_src = cmp_get_random_thumb($width,$height);
        }
    }
    return $post_thumbnail_src;
}

/**
 * 002. Use Aqua Resizer to get thumb url
 * https://github.com/syamilmj/Aqua-Resizer
 * Since 1.3
 */
require_once(TEMPLATEPATH . '/functions/aq_resizer.php');
function cmp_aq_thumb_src($width,$height){
    global $post;
    $post_thumbnail_src = '';
    if( $values = get_post_custom_values("thumb") ) {
        $values = get_post_custom_values("thumb");
        $post_thumbnail_src = aq_resize( $values[0], $width, $height, true , true , true );
    } elseif( has_post_thumbnail() ){
        $thumbnail_src = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
        $post_thumbnail_src = aq_resize( $thumbnail_src[0], $width, $height, true , true , true );
    } else {
        $attachment_id = cmp_get_first_image_id($post->ID);
        if ( $attachment_id ) {
            $thumbnail_src = wp_get_attachment_image_src( $attachment_id, 'full');
            $post_thumbnail_src = aq_resize( $thumbnail_src[0], $width, $height, true , true , true );
        }else{
            $post_thumbnail_src = cmp_get_random_thumb($width,$height);
        }
    }
    return $post_thumbnail_src;
}

/**
 * 003. Use Qiniu to get thumb url
 * https://github.com/syamilmj/Aqua-Resizer
 * Since 1.3
 */
function cmp_qiniu_cut($img,$width,$height){
    $q = cmp_get_option('thumb_q')?cmp_get_option('thumb_q'):'90';
    $result = $img.'?imageView2/1/w/'.$width.'/h/'.$height.'/q/'.$q;
    return $result;
}
function cmp_qiniu_thumb_src($width,$height){
    global $post;
    $post_thumbnail_src = '';
    if( $values = get_post_custom_values("thumb") ) {
        $values = get_post_custom_values("thumb");
        $post_thumbnail_src = cmp_qiniu_cut($values[0],$width,$height);
    } elseif( has_post_thumbnail() ){
        $thumbnail_src = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
        $post_thumbnail_src = cmp_qiniu_cut($thumbnail_src[0],$width,$height);
    } else {
        $attachment_id = cmp_get_first_image_id($post->ID);
        if ( $attachment_id ) {
            $thumbnail_src = wp_get_attachment_image_src( $attachment_id, 'full');
            $post_thumbnail_src = cmp_qiniu_cut($thumbnail_src[0],$width,$height);
        }else{
            $post_thumbnail_src = cmp_get_random_thumb($width,$height);
        }
    }
    return $post_thumbnail_src;
}
/**
 * 004. Use Timthumb to get thumb url
 *
 * Since 1.3
 */
function cmp_tim_cut($img,$width,$height){
    $q = cmp_get_option('thumb_q')?cmp_get_option('thumb_q'):'90';
    $zc = cmp_get_option('thumb_zc')?cmp_get_option('thumb_zc'):'1';
    $result = get_template_directory_uri().'/timthumb.php?src='.$img.'&w='.$width.'&h='.$height.'&zc='.$zc.'&q='.$q.'&ct=1';
    return $result;
}
function cmp_tim_thumb_src($width,$height){
    global $post;
    $post_thumbnail_src = '';
    if( $values = get_post_custom_values("thumb") ) {
        $values = get_post_custom_values("thumb");
        $post_thumbnail_src = cmp_tim_cut($values[0],$width,$height);
    } elseif( has_post_thumbnail() ){
        $thumbnail_src = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
        $post_thumbnail_src = cmp_tim_cut($thumbnail_src[0],$width,$height);
    } else {
        ob_start();
        ob_end_clean();
        $output = preg_match('/<img.+src=[\'"]([^\'"]+)[\'"].*>/Ui', $post->post_content, $matches);
        if(isset($matches[1])) $first_img_src = $matches[1];
        if(!empty($first_img_src)){
            $post_thumbnail_src = cmp_tim_cut($first_img_src,$width,$height);
        }else{
            $post_thumbnail_src = cmp_get_random_thumb($width,$height);
        }
    }
    return $post_thumbnail_src;
}
/**
 * Choose the final way to cut thumbnail
 * Since 1.3
 */
function post_thumbnail_src($width,$height){
    $post_thumbnail_src = '';
    if (cmp_get_option('thumb_cut') == 'tim'){
        $post_thumbnail_src = cmp_tim_thumb_src($width,$height);
    }elseif (cmp_get_option('thumb_cut') == 'otf'){
        $post_thumbnail_src = cmp_otf_thumb_src($width,$height);
    }elseif (cmp_get_option('thumb_cut') == 'qiniu'){
        $post_thumbnail_src = cmp_qiniu_thumb_src($width,$height);
    }else{
        $post_thumbnail_src = cmp_aq_thumb_src($width,$height);
        //$post_thumbnail_src = cmp_otf_thumb_src($width,$height);
    }
    return $post_thumbnail_src;
}
/**
 * echo thumbnail html code
 * Since 1.3
 */
function cmp_post_thumbnail($width,$height){
    if(cmp_get_option( 'lazyload' )): ?>
        <img class="lazy" src="<?php echo get_template_directory_uri(); ?>/images/grey.gif" data-original="<?php echo post_thumbnail_src($width,$height); ?>" alt="<?php the_title_attribute(); ?>" width="<?php echo $width ?>" height="<?php echo $height ?>" />
        <noscript><img src="<?php echo post_thumbnail_src($width,$height); ?>" alt="<?php the_title_attribute(); ?>" width="<?php echo $width ?>" height="<?php echo $height ?>" /></noscript>
    <?php else: ?>
        <img src="<?php echo post_thumbnail_src($width,$height); ?>" alt="<?php the_title_attribute(); ?>" width="<?php echo $width ?>" height="<?php echo $height ?>" />
    <?php endif;
}
/**
 * Echo Slider Img Src
 * Since 1.3
 */
function cmp_slider_img_src($image_id , $width='' , $height=''){
    $img_src = '';
    if (cmp_get_option('thumb_cut') == 'otf'){
        $img = wp_get_attachment_image_src($image_id, array($width,$height) );
        $img_src = $img[0];
    }else{
        $img =  wp_get_attachment_image_src( $image_id , 'full' );
        if (cmp_get_option('thumb_cut') == 'tim'){
            $img_src = cmp_tim_cut($img[0],$width,$height);
        }elseif (cmp_get_option('thumb_cut') == 'qiniu'){
            $img_src = cmp_qiniu_cut($img[0],$width,$height);
        }elseif (cmp_get_option('thumb_cut') == 'aq'){
            $img_src = aq_resize( $img[0], $width, $height, true , true , true );
        }
    }
    return $img_src;
}
/*-----------------------------------------------------------------------------------*/
# remove wptexturize
/*-----------------------------------------------------------------------------------*/
remove_filter('the_content', 'wptexturize');
remove_filter('the_excerpt', 'wptexturize');
remove_filter('comment_text', 'wptexturize');
/*-----------------------------------------------------------------------------------*/
# image_default_link_type as file
/*-----------------------------------------------------------------------------------*/
update_option('image_default_link_type' , 'file');
/*-----------------------------------------------------------------------------------*/
# clean head
/*-----------------------------------------------------------------------------------*/
function cmp_remove_version() {
    return '';
}
add_filter('the_generator', 'cmp_remove_version');
remove_action('wp_head', 'index_rel_link');
remove_action('wp_head', 'feed_links_extra', 3);
remove_action('wp_head', 'start_post_rel_link', 10, 0);
remove_action('wp_head', 'parent_post_rel_link', 10, 0);
remove_action('wp_head', 'adjacent_posts_rel_link', 10, 0);
remove_action('wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0 );
remove_action('wp_head', 'wp_shortlink_wp_head', 10, 0 );
remove_action('wp_head', 'rel_canonical' );
/*-----------------------------------------------------------------------------------*/
# add_contact_fields on profile
/*-----------------------------------------------------------------------------------*/
add_filter( 'user_contactmethods', 'cm_add_contact_fields' );
function cm_add_contact_fields( $contactmethods ) {
    $contactmethods['qq'] = __('QQ','cmp');
    $contactmethods['qm_mailme'] = __('QQ Mail Me','cmp');
    $contactmethods['qq_weibo'] = __('QQ Weibo','cmp');
    $contactmethods['sina_weibo'] = __('Sina Weibo','cmp');
    $contactmethods['twitter'] = __('Twitter','cmp');
    $contactmethods['google_plus'] = __('Google+','cmp');
    unset( $contactmethods['yim'] );
    unset( $contactmethods['aim'] );
    unset( $contactmethods['jabber'] );
    return $contactmethods;
}
/*-----------------------------------------------------------------------------------*/
# Author Box --used in single post、archive and sidebar
/*-----------------------------------------------------------------------------------*/
function cmp_author_box($avatar = true , $social = true ){
    if( $avatar ) : ?>
    <div class="author-avatar">
        <?php echo get_avatar( get_the_author_meta( 'user_email' ), apply_filters( 'MFW_author_bio_avatar_size', 64 ) ); ?>
    </div>
<?php endif; ?>
<div class="author-description">
    <p><?php if(get_the_author_meta( 'description' )){
        echo get_the_author_meta( 'description' );
    }else{
        $current_user = wp_get_current_user();
        $author_id = get_the_author_meta( 'ID' );
        if(class_exists("WP_User_Frontend") && $current_user->ID == $author_id){
            $profile_url = get_home_url().'/user/profile';
            $description = sprintf(__('Please visit <a href="%s">Your Profile</a> to fill in Biographical Info.','cmp'),$profile_url);
        }elseif($current_user->ID == $author_id){
            $profile_url = get_home_url().'/wp-admin/profile.php';
            $description = sprintf(__('Please visit <a href="%s">Your Profile</a> to fill in Biographical Info.','cmp'),$profile_url);
        }else{
            $description = __('The user is lazy, not fill in his Biographical Info.','cmp');
        }
        echo $description;
    }
    ?>
</p>
<?php  if( $social ) :  ?>
    <ul class="author-social follows nb">
        <?php  if( !is_author() ) :
        $userlinks = get_author_posts_url( get_the_author_meta( 'ID' ) );
        ?>
        <li class="archive">
            <a target="_blank" href="<?php echo $userlinks; ?>" title="<?php echo sprintf( __( "Read more articles of %s", 'cmp' ), get_the_author_meta( 'display_name' )); ?>"><?php echo sprintf( __( "Read more articles of %s", 'cmp' ), get_the_author_meta( 'display_name' )); ?></a>
        </li>
    <?php endif; ?>
    <?php if ( get_the_author_meta( 'url' ) ) : ?>
        <li class="website">
            <a target="_blank" rel="nofollow" href="<?php the_author_meta( 'url' ); ?>" title="<?php echo sprintf( __( "Visit %s's site", 'cmp' ), get_the_author_meta( 'display_name' )); ?>"><?php echo sprintf( __( "Visit %s's site", 'cmp' ), get_the_author_meta( 'display_name' )); ?></a>
        </li>
    <?php endif ?>
    <?php if ( get_the_author_meta( 'qq' ) ) : ?>
        <li class="qq">
            <a target="_blank" rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&amp;site=qq&amp;menu=yes&amp;uin=<?php the_author_meta( 'qq' ); ?>" title="<?php echo sprintf( __( "Contact %s by QQ", 'cmp' ), get_the_author_meta( 'display_name' )); ?>"><?php echo sprintf( __( "Contact %s by QQ", 'cmp' ), get_the_author_meta( 'display_name' )); ?></a>
        </li>
    <?php endif ?>
    <?php if(class_exists("cartpaujPM")){ ?>
    <li class="email">
        <a target="_blank" rel="nofollow" href="<?php echo get_home_url(); ?>/user/pm?pmaction=newmessage&to=<?php echo get_the_author_meta( 'ID' ); ?>" title="<?php echo sprintf( __( "Contact %s by Private Messages", 'cmp' ), get_the_author_meta( 'display_name' )); ?>"><?php echo sprintf( __( "Contact %s by Private Messages", 'cmp' ), get_the_author_meta( 'display_name' )); ?></a>
    </li>
    <?php } elseif(get_the_author_meta( 'qm_mailme' )) { ?>
    <li class="email">
        <a target="_blank" rel="nofollow" href="<?php the_author_meta( 'qm_mailme' ); ?>" title="<?php echo sprintf( __( "Contact %s by Email", 'cmp' ), get_the_author_meta( 'display_name' )); ?>"><?php echo sprintf( __( "Contact %s by Email", 'cmp' ), get_the_author_meta( 'display_name' )); ?></a>
    </li>
    <?php } ?>
    <?php if ( get_the_author_meta( 'sina_weibo' ) ) : ?>
        <li class="sina_weibo">
            <a target="_blank" rel="nofollow" href="<?php the_author_meta( 'sina_weibo' ); ?>" title="<?php echo sprintf( __( "Follow %s on Sina Weibo", 'cmp' ), get_the_author_meta( 'display_name' )); ?>"><?php echo sprintf( __( "Follow %s on Sina Weibo", 'cmp' ), get_the_author_meta( 'display_name' )); ?></a>
        </li>
    <?php endif ?>
    <?php if ( get_the_author_meta( 'qq_weibo' ) ) : ?>
        <li class="qq_weibo">
            <a target="_blank" rel="nofollow" href="<?php the_author_meta( 'qq_weibo' ); ?>" title="<?php echo sprintf( __( "Follow %s on QQ Weibo", 'cmp' ), get_the_author_meta( 'display_name' )); ?>"><?php echo sprintf( __( "Follow %s on QQ Weibo", 'cmp' ), get_the_author_meta( 'display_name' )); ?></a>
        </li>
    <?php endif ?>
    <?php if ( get_the_author_meta( 'twitter' ) ) : ?>
        <li class="twitter">
            <a target="_blank" rel="nofollow" href="<?php the_author_meta( 'twitter' ); ?>" title="<?php echo sprintf( __( "Follow %s on Twitter", 'cmp' ), get_the_author_meta( 'display_name' )); ?>"><?php echo sprintf( __( "Follow %s on Twitter", 'cmp' ), get_the_author_meta( 'display_name' )); ?></a>
        </li>
    <?php endif ?>
    <?php if ( get_the_author_meta( 'google_plus' ) ) : ?>
        <li class="google_plus">
            <a target="_blank" href="<?php the_author_meta( 'google_plus' ); ?>" rel="author" title="<?php echo sprintf( __( "Follow %s on Google+", 'cmp' ), get_the_author_meta( 'display_name' )); ?>"><?php echo sprintf( __( "Follow %s on Google+", 'cmp' ), get_the_author_meta( 'display_name' )); ?></a>
        </li>
    <?php endif ?>
</ul>
</div>
<?php endif; ?>
<div class="clear"></div>
<?php
}
/*-----------------------------------------------------------------------------------*/
# Archives list by zwwooooo | http://zww.me
/*-----------------------------------------------------------------------------------*/
function archives_list() {
    if( !$output = get_option('archives_list') ){
        $output = '<div id="archives"><p>[<a id="al_expand_collapse" rel="nofollow" href="#">'.__('Expand / Collapse All </a>] <em>(Note: Click on the month you can expand it)</em>','cmp').'</p>';
        $the_query = new WP_Query( 'posts_per_page=-1&ignore_sticky_posts=1' );
        $year=0; $mon=0; $i=0; $j=0;
        while ( $the_query->have_posts() ) : $the_query->the_post();
        $year_tmp = get_the_time('Y');
        $mon_tmp = get_the_time('m');
        $y=$year; $m=$mon;
        if ($mon != $mon_tmp && $mon > 0) $output .= '</ul></li>';
        if ($year != $year_tmp && $year > 0) $output .= '</ul>';
        if ($year != $year_tmp) {
            $year = $year_tmp;
            $output .= '<h3 class="al_year">'. $year .__(' Year','cmp').'</h3><ul class="al_mon_list">';
        }
        if ($mon != $mon_tmp) {
            $mon = $mon_tmp;
            $output .= '<li><span class="al_mon">'. $mon .__(' Month','cmp').'</span><ul class="al_post_list">';
        }
        $output .= '<li>'. get_the_time('d') .__(' Day: ','cmp').'<a href="'. get_permalink() .'">  '. get_the_title() .'</a> <em>('. get_comments_number('0', '1', '%') .')</em></li>';
        endwhile;
        wp_reset_postdata();
        $output .= '</ul></li></ul></div>';
        update_option('archives_list', $output);
    }
    echo $output;
}
function clear_al_cache() {
    update_option('archives_list', '');
}
add_action('save_post', 'clear_al_cache');
/*-----------------------------------------------------------------------------------*/
# comment_mail_notify
/*-----------------------------------------------------------------------------------*/
function comment_mail_notify($comment_id) {
    $admin_notify = '1'; // admin whether to receive reply notifications ('1 '= to; '0' = not)
    $admin_email = get_bloginfo ('admin_email'); // $admin_email can be changed to your designated e-mail.
    $comment = get_comment($comment_id);
    $comment_author_email = trim($comment->comment_author_email);
    $parent_id = $comment->comment_parent ? $comment->comment_parent : '';
    global $wpdb;
    if ($wpdb->query("Describe {$wpdb->comments} comment_mail_notify") == '')
        $wpdb->query("ALTER TABLE {$wpdb->comments} ADD COLUMN comment_mail_notify TINYINT NOT NULL DEFAULT 0;");
    if (($comment_author_email != $admin_email && isset($_POST['comment_mail_notify'])) || ($comment_author_email == $admin_email && $admin_notify == '1'))
        $wpdb->query("UPDATE {$wpdb->comments} SET comment_mail_notify='1' WHERE comment_ID='$comment_id'");
    $notify = $parent_id ? get_comment($parent_id)->comment_mail_notify : '0';
    $spam_confirmed = $comment->comment_approved;
    if ($parent_id != '' && $spam_confirmed != 'spam' && $notify == '1') {
    $wp_email = 'no-reply@' . preg_replace('#^www\.#', '', strtolower($_SERVER['SERVER_NAME'])); // e-mail to issue point, no-reply can be changed to the available e-mail.
    $to = trim(get_comment($parent_id)->comment_author_email);
    $subject = sprintf( __( 'Hi! Someone just reply to your comments on %s', 'cmp' ), get_option("blogname") );
    $message = '
    <div style="color:#333;font:100 14px/24px microsoft yahei;">
        <p>' . sprintf( __( 'Hi! %s', 'cmp' ), trim(get_comment($parent_id)->comment_author) ) . '</p>
        <p>' . sprintf( __( 'Your comments on %s :', 'cmp' ), get_the_title($comment->comment_post_ID) ) . '<br /> &nbsp;&nbsp;&nbsp;&nbsp; '. trim(get_comment($parent_id)->comment_content) . '</p>
        <p>' . trim($comment->comment_author) . __(' Reply to you:','cmp').'<br /> &nbsp;&nbsp;&nbsp;&nbsp; '
            . trim($comment->comment_content) . '<br /></p>
            <p>' . sprintf( __( 'Click <a href="%s">HERE</a> for more details.', 'cmp' ), htmlspecialchars(get_comment_link($parent_id)) ) . '</p>
            <p>'.__('Welcome back to','cmp').'<a href="' . home_url() . '">' . get_option('blogname') . '</a></p>
            <p style="color:#999">('.__('This message is sent automatically by the system, do not reply to.','cmp').')</p>
        </div>';
        $from = "From: \"" . get_option('blogname') . "\" <$wp_email>";
        $headers = "$from\nContent-Type: text/html; charset=" . get_option('blog_charset') . "\n";
        wp_mail( $to, $subject, $message, $headers );
    }
}
//Automatic check
function cmp_add_checkbox() {
    global $post;
    if($post->post_type == 'post' || $post->post_type == 'page' ){
        echo '<p><label for="comment_mail_notify"><input type="checkbox" name="comment_mail_notify" id="comment_mail_notify" value="comment_mail_notify" checked="checked"/>'.__('E-mail me when someone replies to me.','cmp').'</label></p>';
    }
}
if (cmp_get_option('comment_mail_notify')) {
    add_action('comment_post','comment_mail_notify');
    add_action('comment_form','cmp_add_checkbox');
}
/*-----------------------------------------------------------------------------------*/
# News In Picture
/*-----------------------------------------------------------------------------------*/
function wp_last_news_pic($order , $numberOfPosts = 12 , $cats = 1 , $p_title = true){
    global $post;
    $orig_post = $post;
    if( $order == 'random'){
        $lastPosts = get_posts( $args = array('numberposts' => $numberOfPosts, 'orderby' => 'rand', 'category' => $cats ,'no_found_rows' => 1));
    }else{
        $lastPosts = get_posts( $args = array('numberposts' => $numberOfPosts, 'category' => $cats ,'no_found_rows' => 1));
    }
    $i=1;
    foreach($lastPosts as $post): setup_postdata($post); ?>
    <div class="post-inner<?php if($i % 2 ==0) echo ' even'; ?>">
        <p><a class="post-thumbnail" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark" <?php echo cmp_target_blank();?>>
            <?php cmp_post_thumbnail(204,120) ?>
        </a></p>
        <?php if($p_title):?>
        <p class="pic-t"><a class="post-thumbnail" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark" <?php echo cmp_target_blank();?>>
            <?php the_title(); ?>
        </a></p>
    <?php endif;?>
    </div>
    <?php $i++; endforeach;
    $post = $orig_post;
}
/*-----------------------------------------------------------------------------------*/
# Get Most Racent posts
/*-----------------------------------------------------------------------------------*/
function wp_last_posts($numberOfPosts = 5 , $thumb = true){
    global $post;
    $orig_post = $post;
    $lastPosts = get_posts( $args = array('numberposts' => $numberOfPosts,'no_found_rows' => 1));
    foreach($lastPosts as $post): setup_postdata($post);
    ?>
    <li>
        <div class="widget-thumb group">
            <?php if ( $thumb ) : ?>
                <a class="post-thumbnail" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark" <?php echo cmp_target_blank();?>>
                    <?php cmp_post_thumbnail(150,90); ?>
                </a>
            <?php endif; ?>
            <div class="post-info">
                <a class="post-title" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>><?php the_title();?></a>
                <!-- <span class="date"><?php cmp_get_time() ?></span> -->
            </div>
        </div>
    </li>
<?php endforeach;
$post = $orig_post;
}
/*-----------------------------------------------------------------------------------*/
# Get Most Racent posts from Category
/*-----------------------------------------------------------------------------------*/
function wp_last_posts_cat($numberOfPosts = 5 , $thumb = true , $cats = 1){
    global $post;
    $orig_post = $post;
    $lastPosts = get_posts( $args = array('numberposts' => $numberOfPosts, 'category' => $cats ,'no_found_rows' => 1));
    foreach($lastPosts as $post): setup_postdata($post);
    ?>
    <li>
        <div class="widget-thumb group">
            <?php if ( $thumb ) : ?>
                <a class="post-thumbnail" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark" <?php echo cmp_target_blank();?>>
                    <?php cmp_post_thumbnail(150,90); ?>
                </a>
            <?php endif; ?>
            <div class="post-info">
                <a class="post-title" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>><?php the_title();?></a>
                <!-- <span class="date"><?php cmp_get_time() ?></span> -->
            </div>
        </div>
    </li>
<?php endforeach;
$post = $orig_post;
}
/*-----------------------------------------------------------------------------------*/
# Get Random posts
/*-----------------------------------------------------------------------------------*/
function wp_random_posts($numberOfPosts = 5 , $thumb = true){
    global $post;
    $orig_post = $post;
    $lastPosts = get_posts( $args = array('numberposts' => $numberOfPosts, 'orderby' => 'rand' ,'no_found_rows' => 1));
    foreach($lastPosts as $post): setup_postdata($post);
    ?>
    <li>
        <div class="widget-thumb group">
            <?php if ( $thumb ) : ?>
                <a class="post-thumbnail" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark" <?php echo cmp_target_blank();?>>
                    <?php cmp_post_thumbnail(150,90); ?>
                </a>
            <?php endif; ?>
            <div class="post-info">
                <a class="post-title" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>><?php the_title();?></a>
                <!-- <span class="date"><?php cmp_get_time() ?></span> -->
            </div>
        </div>
    </li>
<?php endforeach;
$post = $orig_post;
}
/*-----------------------------------------------------------------------------------*/
# Get Popular posts
/*-----------------------------------------------------------------------------------*/
function wp_popular_posts($pop_posts = 5 , $thumb = true , $days = 30){
    global $wpdb , $post;
    $orig_post = $post;
    $today = date("Y-m-d H:i:s");
    $daysago = date( "Y-m-d H:i:s", strtotime($today) - ($days * 24 * 60 * 60) );
    $popularposts = "SELECT ID,post_title,post_date,post_author,post_content,post_type FROM $wpdb->posts WHERE post_status = 'publish' AND post_type = 'post' AND post_date BETWEEN '$daysago' AND '$today' ORDER BY comment_count DESC LIMIT 0,".$pop_posts;
    $posts = $wpdb->get_results($popularposts);
    if($posts){
        global $post;
        foreach($posts as $post){
            setup_postdata($post);?>
            <li>
                <div class="widget-thumb group">
                    <?php if ( $thumb ) : ?>
                        <a class="post-thumbnail" href="<?php echo get_permalink( $post->ID ) ?>" title="<?php the_title_attribute(); ?>" rel="bookmark" <?php echo cmp_target_blank();?>>
                            <?php cmp_post_thumbnail(150,90); ?>
                        </a>
                    <?php endif; ?>
                    <div class="post-info">
                        <a class="post-title" href="<?php echo get_permalink( $post->ID ) ?>" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>><?php the_title();?></a>
                    </div>
                </div>
            </li>
            <?php
        }
    }
    $post = $orig_post;
}
/*-----------------------------------------------------------------------------------*/
# Custom comment style
# add 1.2
/*-----------------------------------------------------------------------------------*/
function cm_comment($comment, $args, $depth) {
    $GLOBALS['comment'] = $comment;
    $comorder =  get_option('comment_order');
    if($comorder == 'asc'){
        global $commentcount;
        if(!$commentcount) {
            $page = get_query_var('cpage')-1;
            $cpp=get_option('comments_per_page');
            $commentcount = $cpp * $page;
        }
    }else{
        global $commentcount,$wpdb, $post;
        if(!$commentcount) {
            $comments = $wpdb->get_results("SELECT * FROM $wpdb->comments WHERE comment_post_ID = $post->ID AND comment_type = '' AND comment_approved = '1' AND !comment_parent");
            $cnt = count($comments);
            $page = get_query_var('cpage');
            $cpp=get_option('comments_per_page');
            if (ceil($cnt / $cpp) == 1 || ($page > 1 && $page  == ceil($cnt / $cpp))) {
                $commentcount = $cnt + 1;
            } else {$commentcount = $cpp * $page + 1;}
        }
    }
    ?>
    <li <?php comment_class(); ?> id="comment-<?php comment_ID() ?>">
        <div id="div-comment-<?php comment_ID() ?>" class="comment-body">
            <?php $add_below = 'div-comment'; ?>
            <div class="comment-author vcard">
                <?php echo get_avatar( $comment, 64 , '',$comment->comment_author); ?>
                <cite class="fn"><?php comment_author_link() ?></cite><span class="says"><?php _e('Says:','cmp') ?></span>
            </div>
            <div class="comment-meta commentmetadata"><?php comment_date('Y-m-d') ?> <?php comment_time() ?> <?php edit_comment_link(__('(Edit)','cmp'),'',''); ?></div>
            <div class="floor">
                    <?php
                    if($comorder == 'asc'){
                        if(!$parent_id = $comment->comment_parent){printf('%1$s#', ++$commentcount);}
                    }else{
                        if(!$parent_id = $comment->comment_parent){printf('%1$s#', --$commentcount);}
                    }
                    ?>
            </div>
            <?php if ( $comment->comment_approved == '0' ) : ?>
                <span><?php _e('Your comment is awaiting moderation ...','cmp') ?></span>
                <br />
            <?php endif; ?>
            <?php comment_text() ?>
            <div class="reply">
            <?php comment_reply_link(array_merge( $args, array('reply_text' => __('Reply','cmp'), 'add_below' =>$add_below, 'depth' => $depth, 'max_depth' => $args['max_depth']))); ?></div>
        </div>
    <?php
}
function cm_end_comment() {
    echo '</li>';
}
/*-----------------------------------------------------------------------------------*/
# Get avatar from http://cn.gravatar.com
# Since 1.3
/*-----------------------------------------------------------------------------------*/
if(!function_exists('get_ssl_avatar') && !function_exists('get_cn_avatar')){
    function cmp_get_cn_avatar($avatar) {
        $avatar = preg_replace('/.*\/avatar\/(.*)\?s=([\d]+)&.*/','<img src="http://cn.gravatar.com/avatar/$1?s=$2" class="avatar avatar-$2" height="$2" width="$2">',$avatar);
        return $avatar;
    }
    add_filter('get_avatar', 'cmp_get_cn_avatar',99,1);
}
function cmp_get_cn_avatar_url($avatar) {
    $avatar = preg_replace('/.*\/avatar\/(.*)\?s=([\d]+)&.*/','http://cn.gravatar.com/avatar/$1?s=$2"',$avatar);
    return $avatar;
}
add_filter('get_avatar_url', 'cmp_get_cn_avatar_url',99,1);

/*-----------------------------------------------------------------------------------*/
# Add Page Break button in WordPress Visual Editor
# 1.3
/*-----------------------------------------------------------------------------------*/
add_filter( 'mce_buttons', 'cmp_add_page_break_button', 1, 2 );
function cmp_add_page_break_button( $buttons, $id ){
    if ( 'content' != $id )
        return $buttons;
    array_splice( $buttons, 13, 0, 'wp_page' );
    return $buttons;
}

/**
* Disable the emoji's
 */
function disable_emojis() {
    remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
    remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
    remove_action( 'wp_print_styles', 'print_emoji_styles' );
    remove_action( 'admin_print_styles', 'print_emoji_styles' );
    remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
    remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
    remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
    add_filter( 'tiny_mce_plugins', 'disable_emojis_tinymce' );
}
add_action( 'init', 'disable_emojis' );
/**
 * Filter function used to remove the tinymce emoji plugin.
 *
 * @param    array  $plugins
 * @return   array             Difference betwen the two arrays
 */
function disable_emojis_tinymce( $plugins ) {
    return array_diff( $plugins, array( 'wpemoji' ) );
}
/**
 * 4.2表情
 */
function my_init_smilies(){
    global $wpsmiliestrans;
    $wpsmiliestrans = array(
        ':mrgreen:' => 'icon_mrgreen.gif',
        ':neutral:' => 'icon_neutral.gif',
        ':twisted:' => 'icon_twisted.gif',
        ':arrow:' => 'icon_arrow.gif',
        ':shock:' => 'icon_eek.gif',
        ':smile:' => 'icon_smile.gif',
        ':???:' => 'icon_confused.gif',
        ':cool:' => 'icon_cool.gif',
        ':evil:' => 'icon_evil.gif',
        ':grin:' => 'icon_biggrin.gif',
        ':idea:' => 'icon_idea.gif',
        ':oops:' => 'icon_redface.gif',
        ':razz:' => 'icon_razz.gif',
        ':roll:' => 'icon_rolleyes.gif',
        ':wink:' => 'icon_wink.gif',
        ':cry:' => 'icon_cry.gif',
        ':eek:' => 'icon_surprised.gif',
        ':lol:' => 'icon_lol.gif',
        ':mad:' => 'icon_mad.gif',
        ':sad:' => 'icon_sad.gif',
        '8-)' => 'icon_cool.gif',
        '8-O' => 'icon_eek.gif',
        ':-(' => 'icon_sad.gif',
        ':-)' => 'icon_smile.gif',
        ':-?' => 'icon_confused.gif',
        ':-D' => 'icon_biggrin.gif',
        ':-P' => 'icon_razz.gif',
        ':-o' => 'icon_surprised.gif',
        ':-x' => 'icon_mad.gif',
        ':-|' => 'icon_neutral.gif',
        ';-)' => 'icon_wink.gif',
        '8O' => 'icon_eek.gif',
        ':(' => 'icon_sad.gif',
        ':)' => 'icon_smile.gif',
        ':?' => 'icon_confused.gif',
        ':D' => 'icon_biggrin.gif',
        ':P' => 'icon_razz.gif',
        ':o' => 'icon_surprised.gif',
        ':x' => 'icon_mad.gif',
        ':|' => 'icon_neutral.gif',
        ';)' => 'icon_wink.gif',
        ':!:' => 'icon_exclaim.gif',
        ':?:' => 'icon_question.gif',
    );
}
add_action( 'init', 'my_init_smilies', 5 );
/**
 * Fixed 4.2+ activity widget avatar
 * Since 1.3
 */
if( !function_exists('fixed_activity_widget_avatar_style')){
    function fixed_activity_widget_avatar_style(){
        echo '<style type="text/css">
        #activity-widget #the-comment-list .avatar {
        position: absolute;
        top: 13px;
        width: 50px;
        height: 50px;
        }
    </style>';
    }
    add_action('admin_head', 'fixed_activity_widget_avatar_style' );
}

/**
 * Test if the current browser runs on a mobile device (smart phone, tablet, etc.)
 * Since 1.3
 */
function cmp_is_mobile() {
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    $mobile_browser = Array(
        "mqqbrowser","opera mobi","juc","iuc","fennec","ios","applewebKit/420","applewebkit/525","applewebkit/532","ipad","iphone","ipaq","ipod","iemobile", "windows ce","240x320","480x640","acer","android","anywhereyougo.com","asus","audio","blackberry","blazer","coolpad" ,"dopod", "etouch", "hitachi","htc","huawei", "jbrowser", "lenovo","lg","lg-","lge-","lge", "mobi","moto","nokia","phone","samsung","sony","symbian","tablet","tianyu","wap","xda","xde","zte"
        );
    $is_mobile = false;
    foreach ($mobile_browser as $device) {
        if (stristr($user_agent, $device)) {
            $is_mobile = true;
            break;
        }
    }
    return $is_mobile;
}
/**
 * cmp_target_blank
 * Since 1.3
 */
function cmp_target_blank(){
    if(cmp_get_option( 'target_blank' )){
        return 'target="_blank"';
    }
}
/*-----------------------------------------------------------------------------------*/
# Exclude pages From Search
/*-----------------------------------------------------------------------------------*/
function cmp_Search_Filter($query) {
    if( $query->is_search ){
        if ( cmp_get_option( 'search_exclude_pages' ) && !is_admin() )
            $query->set('post_type', 'post');
        if ( cmp_get_option( 'search_cats' ))
            $query->set( 'cat', cmp_get_option( 'search_cats' ) && !is_admin() );
    }
    return $query;
}
add_filter('pre_get_posts','cmp_Search_Filter');
/*-----------------------------------------------------------------------------------*/
# Excerpt Length
/*-----------------------------------------------------------------------------------*/
function cmp_excerpt_global_length( $length ) {
    if( cmp_get_option( 'exc_length' ) )
        return cmp_get_option( 'exc_length' );
    else return 90;
}
function cmp_excerpt_home_length( $length ) {
    if( cmp_get_option( 'home_exc_length' ) )
        return cmp_get_option( 'home_exc_length' );
    else return 60;
}
function cmp_excerpt(){
    add_filter( 'excerpt_length', 'cmp_excerpt_global_length', 999 );
    if(cmp_get_option( 'exc_length_repair' )){
        $words = cmp_get_option( 'exc_length' ) ? cmp_get_option( 'exc_length' ) : 90;
        echo wp_trim_words( get_the_excerpt() , $words , ' ...' );
    }else{
        echo get_the_excerpt();
    }
}
function cmp_excerpt_home(){
    add_filter( 'excerpt_length', 'cmp_excerpt_home_length', 999 );
    if(cmp_get_option( 'exc_length_repair' )){
        $words = cmp_get_option( 'home_exc_length' ) ? cmp_get_option( 'home_exc_length' ) : 60;
        echo wp_trim_words( get_the_excerpt() , $words , ' ...' );
    }else{
        echo get_the_excerpt();
    }
}
/*-----------------------------------------------------------------------------------*/
# Read More Functions
/*-----------------------------------------------------------------------------------*/
function cmp_remove_excerpt( $more ) {
    return ' ...';
}
add_filter('excerpt_more', 'cmp_remove_excerpt');
/*-----------------------------------------------------------------------------------*/
# Get the post time
# Updated in 1.3
/*-----------------------------------------------------------------------------------*/
function cmp_get_time(){
    global $post ;
    if( cmp_get_option( 'time_format' ) == 'none' ){
        return false;
    }elseif( cmp_get_option( 'time_format' ) == 'modern' ){
        $to = current_time('timestamp',1);
        $from = get_the_time('U') ;
        $since = human_time_diff( $from, $to ). __( 'ago' , 'cmp' );
    }else{
        $since = get_the_time(get_option('date_format'));
    }
    echo $since ;
}

/**
 * Remove-wordpress-comments-url
 * http://www.wpdaxue.com/remove-wordpress-comments-url.html
 * Added in 1.3
 */
function cmp_remove_comments_url($fields){
    if(isset($fields['url']))
    unset($fields['url']);
    return $fields;
}
function cmp_remove_comment_author_link( $author_link ){
    return strip_tags( $author_link );
}
if(cmp_get_option( 'remove_comments_url' )){
    add_filter('comment_form_default_fields', 'cmp_remove_comments_url');
    add_filter( 'get_comment_author_link', 'cmp_remove_comment_author_link' );
}