<?php get_header(); ?>
<section class="content">
  <?php cmp_breadcrumbs();?>
  <div class="pad group">
    <div id="post">
      <?php while ( have_posts() ): the_post(); ?>
        <article <?php post_class(); ?> itemscope itemtype="http://schema.org/Article">
          <div class="post-inner group">
            <header class="entry-header">
            <?php if (function_exists('wpfp_link')) { wpfp_link(); } ?>
              <h1 class="post-title" itemprop="headline"><?php the_title(); ?></h1>
              <?php get_template_part( 'includes/post-meta' ); ?>
              <div class="clear"></div>
            </header>
            <div class="entry" itemprop="articleBody">
              <div class="entry-inner">
                <?php get_template_part('includes/ad-post-above');?>
                <?php the_content(); ?>
                <?php wp_link_pages( array( 'before' => '<div class="post-pages">' . __( 'Pages:', 'cmp' ), 'after' => '</div>','link_before' =>'<span>', 'link_after'=>'</span>' ) ); ?>
                <?php if( cmp_get_option('share_post')) get_template_part('includes/single-post-share' ); ?>
              </div>
              <div class="clear"></div>
            </div><!--/.entry-->
          </div><!--/.post-inner-->
        </article><!--/.post-->
      <?php endwhile; ?>
      <div class="clear"></div>
      <?php get_template_part('includes/ad-post-below');?>
      <?php the_tags('<p class="post-tags"><span>'.__('Tags:','cmp').'</span> ','','</p>'); ?>
      <?php if( ( cmp_get_option( 'post_authorbio' ) && empty( $get_meta["cmp_hide_author"][0] ) ) || ( isset( $get_meta["cmp_hide_related"][0] ) && $get_meta["cmp_hide_author"][0] == 'no' ) ): ?>
        <div id="author-box">
          <h3><span><?php _e( 'Last edited: ', 'cmp' ); echo get_the_modified_time('Y/n/j')?></span><?php _e( 'Post By', 'cmp' ) ?> <?php the_author() ?></h3>
          <div class="author-info">
            <?php cmp_author_box() ?>
          </div>
        </div>
      <?php endif; ?>
      <?php if( cmp_get_option( 'post_nav' ) ): ?>
        <div class="post-navigation">
          <div class="post-previous"><?php echo get_previous_post_link( '%link', '<span>'. __( 'Previous:', 'cmp' ).'</span> %title' ); ?></div>
          <div class="post-next"><?php echo get_next_post_link( '%link', '<span>'. __( 'Next:', 'cmp' ).'</span> %title' ); ?></div>
        </div>
      <?php endif; ?>
    </div>
    <?php get_template_part('includes/post-related' ); ?>
    <?php comments_template('/comments.php',true); ?>
  </div><!--/.pad-->
</section><!--/.content-->
<?php get_sidebar(); ?>
<?php get_footer(); ?>