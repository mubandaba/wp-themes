<?php get_header(); ?>
<section class="content">
  <div class="page-title">
    <h1 itemprop="headline">
      <?php echo __('Tag: ','cmp') . single_tag_title( '', false ) ; ?>
      <?php if( cmp_get_option( 'tag_rss' ) ):?>
        <?php $tag_id = get_query_var('tag_id'); ?>
        <a class="rss-cat-icon tooltip" title="<?php _e( 'Subscribe to this tag', 'cmp' ); ?>"  href="<?php echo  get_term_feed_link($tag_id , 'post_tag', "rss2") ?>"><i class="fa fa-rss"></i></a>
      <?php endif; ?>
    </h1>
  </div>
  <?php cmp_breadcrumbs();?>
  <div class="clear"></div>
  <div class="notebox">
    <?php echo sprintf( __( 'The following articles associated with the tag: %s', 'cmp' ), single_tag_title('', false)); ?>
  </div>
  <div class="pad group">
    <?php
    query_posts($query_string . "&posts_per_page=".cmp_get_option('default_number'));
    get_template_part( 'loop', 'tag' );
    ?>
  </div>
</section>
<?php get_sidebar(); ?>
<?php get_footer(); ?>