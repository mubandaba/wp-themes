<?php get_header(); ?>
<section class="content">
  <?php if ( have_posts() ) : ?>
    <div class="page-title">
      <h1 itemprop="headline">
        <?php printf( __( 'Search: %s', 'cmp' ),  get_search_query() ); ?>
      </h1>
    </div><!--/.page-title-->
    <?php cmp_breadcrumbs();?>
    <div class="clear"></div>
    <div class="notebox">
      <?php printf( __( 'Posts 0f search results for: %s', 'cmp' ), get_search_query()); ?>
    </div>
  <?php else : ?>
    <div class="page-title">
      <h1 itemprop="headline">
        <?php echo __( 'Nothing Found', 'cmp' ); ?>
      </h1>
    </div><!--/.page-title-->
    <?php cmp_breadcrumbs();?>
    <div class="clear"></div>
    <div class="notebox">
      <?php _e( 'Sorry, but nothing matched your search criteria. Please try again with some different keywords.', 'cmp' ); ?>
    </div>
  <?php endif; ?>
  <div class="pad group">
    <?php query_posts($query_string . "&posts_per_page=".cmp_get_option('default_number'));?>
    <?php if ( have_posts() ) :?>
      <?php get_template_part( 'loop', 'search' );?>
    <?php else : ?>
      <article id="post-0" class="post not-found">
        <div class="entry">
          <?php get_search_form(); ?>
        </div>
      </article>
    <?php endif; ?>
  </div>
</section>
<?php get_sidebar(); ?>
<?php get_footer(); ?>