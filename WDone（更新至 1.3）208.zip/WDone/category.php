<?php get_header(); ?>
<?php $category_id = get_query_var('cat') ; ?>
<section class="content">
  <div class="page-title">
    <h1 itemprop="headline">
      <?php echo '<i class="fa fa-folder-open"></i>'.__('Category: ','cmp') . single_cat_title( '', false ) ; ?>
      <?php if( cmp_get_option( 'category_rss' ) ): ?>
        <a class="rss-cat-icon" title="<?php _e( 'Subscribe to this category', 'cmp' ); ?>" href="<?php echo get_category_feed_link($category_id) ?>"><i class="fa fa-rss"></i></a>
      <?php endif; ?>
    </h1>
  </div><!--/.page-title-->
  <?php cmp_breadcrumbs();?>
  <div class="clear"></div>
  <?php
  if(cmp_get_option( 'category_desc' ) ){
    $category_description = category_description();
    if(!empty( $category_description ) && !is_paged() )
      echo '<div class="notebox">' . $category_description . '</div>';
  }
  ?>
  <div class="pad group">
    <?php
    if ( is_category(explode(',', cmp_get_option('big_thumb') )) ){
      query_posts($query_string . "&posts_per_page=".cmp_get_option('big_thumb_number'));
    } elseif ( is_category(explode(',', cmp_get_option('medium_thumb_1') )) ){
      query_posts($query_string . "&posts_per_page=".cmp_get_option('medium_thumb_1_number'));
    } elseif ( is_category(explode(',', cmp_get_option('medium_thumb_2') )) ){
      query_posts($query_string . "&posts_per_page=".cmp_get_option('medium_thumb_2_number'));
    } elseif ( is_category(explode(',', cmp_get_option('litle_thumb') )) ){
      query_posts($query_string . "&posts_per_page=".cmp_get_option('litle_thumb_number'));
    } elseif ( is_category(explode(',', cmp_get_option('samll_thumb') )) ){
      query_posts($query_string . "&posts_per_page=".cmp_get_option('samll_thumb_number'));
    } else {
      query_posts($query_string . "&posts_per_page=".cmp_get_option('default_number'));
    }
    get_template_part( 'loop', 'category' );  ?>
  </div>
</section>
<?php get_sidebar(); ?>
<?php get_footer(); ?>