<?php
//如果使用了WPUF，并且当前用户ID和作者ID一致，跳转到用户中心
$author = get_user_by( 'slug', get_query_var( 'author_name' ) );
$current_user = wp_get_current_user();
if( function_exists('wpuf_autoload') && $current_user->ID == $author->ID){
  wp_redirect( home_url().'/user/posts' ); exit;
}
get_header('2'); ?>
<?php cmp_breadcrumbs();?>
<section class="pad user-center group">
  <div class="user-inner">
    <div id="user-left">
      <div class="user-avatar">
        <?php echo get_avatar( $author->user_email, 100 ).'<p>'.$author->nickname.'</p>'; ?>
        <?php if(class_exists("cartpaujPM")){
          echo '<p class="user-pm"><a href="'.get_home_url().'/user/pm?pmaction=newmessage&to='.$author->ID.'" ><i class="icon-pencil"></i> '.__('Send a message','cmp').'</a></p>';
        }
        ?>
      </div>
      <ul id="user-menu">
        <li class="current-menu-item"><a href="<?php echo get_author_posts_url( $author->ID ); ?>"><i class="icon-book"></i><?php _e('His/Her Posts','cmp') ?></a></li>
      </ul>
    </div>
    <div id="user-right" class="entry">
      <div class="user-header">
        <h1 class="user-title" itemprop="headline">
          <?php echo sprintf(__("%s's Posts","cmp"), $author->nickname); ?>
          <?php if( cmp_get_option( 'author_rss' ) ): ?>
            <a class="rss-cat-icon" title="<?php _e( 'Subscribe to this author', 'cmp' ); ?>"  href="<?php echo get_author_feed_link( $author->ID ); ?>"><i class="icon-rss"></i></a>
          <?php endif; ?>
        </h1>
      </div>
      <?php
      if(count_user_posts( $author->ID ) != '0'){
        printf(__('<div class="post-count"> %s has published %s posts :</div>','cmp'), $author->nickname , count_user_posts( $author->ID ) ) ;
      }else{
        printf(__('<div class="post-count"> %s has not yet published any post, you can read the following wonderful posts : </div>','cmp'), $author->nickname ) ;
      }
      ?>
      <ul>
        <?php
        query_posts($query_string . "&posts_per_page=10");
        if(have_posts()) :
          while ( have_posts() ) : the_post(); ?>
            <li class="archive-simple">
              <h2><i class="fa fa-angle-double-right"></i><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><?php the_title(); ?></a>
              </h2>
              <p class="post-meta">
                <span><i class="fa fa-clock-o"></i><?php if (function_exists('cmp_get_time')) cmp_get_time();?></span>
                <?php if(function_exists('the_views')) : ?>
                  <span><i class="fa fa-eye"></i><?php the_views(); ?></span>
                <?php endif; ?>
              </p>
            </li>
          <?php endwhile;
          else:
            $rand_posts = get_posts('numberposts=10&orderby=rand');  foreach( $rand_posts as $post ) :
          ?>
          <li class="archive-simple">
            <h2><i class="fa fa-angle-double-right"></i><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><?php the_title(); ?></a>
            </h2>
            <p class="post-meta">
              <span><i class="fa fa-clock-o"></i><?php if (function_exists('cmp_get_time')) cmp_get_time();?></span>
              <?php if(function_exists('the_views')) : ?>
                <span><i class="fa fa-eye"></i><?php the_views(); ?></span>
              <?php endif; ?>
            </p>
          </li>
        <?php endforeach; endif; ?>
      </ul>
      <div class="clear"></div>
      <?php if ($wp_query->max_num_pages > 1) cmp_pagenavi(); ?>
    </div>
    <div class="clear"></div>
  </div>
</section>
<?php get_footer(); ?>