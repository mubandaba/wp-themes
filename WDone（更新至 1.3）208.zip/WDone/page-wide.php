<?php
/*
Template Name: 无边栏无评论页面
*/
get_header('2');?>
<section class="content">
  <?php cmp_breadcrumbs();?>
  <div class="pad group">
    <div id="post">
      <?php while ( have_posts() ) : the_post(); ?>
        <article <?php post_class(); ?> itemscope itemtype="http://schema.org/Article">
          <div class="post-inner group">
            <header class="entry-header">
              <h1 class="post-title" itemprop="headline"><?php the_title(); ?></h1>
              <?php get_template_part( 'includes/post-meta' ); ?>
              <div class="clear"></div>
            </header>
            <div class="entry" itemprop="articleBody">
              <div class="entry-inner">
                <?php the_content(); ?>
                <?php wp_link_pages(array('before'=>'<div class="post-pages">'.__('Pages:','cmp'),'after'=>'</div>')); ?>
              </div>
              <div class="clear"></div>
            </div><!--/.entry-->
          </div><!--/.post-inner-->
        </article><!--/.post-->
      <?php endwhile; ?>
      <div class="clear"></div>
    </div>
  </div><!--/.pad-->
</section><!--/.content-->
<?php get_footer(); ?>