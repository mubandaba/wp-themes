<?php
/*
Template Name: User List
*/
get_header('2'); ?>
<?php
function authors_with_posts( $query ) {
  global $wpdb;
  if ( isset( $query->query_vars['query_id'] ) && 'authors_with_posts' == $query->query_vars['query_id'] ) {
    $query->query_from = $query->query_from . ' LEFT OUTER JOIN (
      SELECT post_author, COUNT(*) as post_count
      FROM '.$wpdb->prefix.'posts
      WHERE post_type = "post" AND (post_status = "publish" OR post_status = "private")
      GROUP BY post_author
      ) p ON ('.$wpdb->prefix.'users.ID = p.post_author)';
    $query->query_where = $query->query_where . ' AND post_count  > 0 ';
  }
}
add_action('pre_user_query','authors_with_posts');

$no=40;
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
if($paged==1){
  $offset=0;
}
else {
 $offset= ($paged-1)*$no;
}

$args = array(
  'number' => $no,
  'offset' => $offset,
  // 'query_id' => 'authors_with_posts',
  'orderby' => 'registered',
  'order' => 'DESC'
  );
$user_query = new WP_User_Query( $args );
$authors = $user_query->get_results();
?>
<section class="content">
  <?php cmp_breadcrumbs();?>
  <div class="pad group">
    <div id="post">
      <?php while ( have_posts() ) : the_post(); ?>
        <article <?php post_class(); ?> itemscope itemtype="http://schema.org/Article">
          <div class="post-inner group">
            <header class="entry-header">
              <h1 class="post-title" itemprop="headline"><?php the_title(); ?></h1>
              <span>（按注册时间先后倒序排列）</span>
              <div class="clear"></div>
            </header>
            <div class="entry" itemprop="articleBody">
              <div class="entry-inner">
                <?php if(!empty($authors)): ?>
                  <div class="user-list">
                    <?php foreach($authors as $author) : ?>
                      <div class="user-info">
                      <p><a class="user-avatar" href="<?php echo get_author_posts_url($author->ID); ?>"><?php echo get_avatar($author->ID, 80); ?></a><br/><a class="user-name" href="<?php echo get_author_posts_url($author->ID); ?>">
                      <?php echo $author->display_name; ?></a></p>
                      </div>

                    <?php endforeach; ?>
                  </div>
                  <div class="clear"></div>
                  <?php
                  $total_user = $user_query->total_users;
                  $total_pages=ceil($total_user/$no);
                  $page_links = paginate_links( array(
                    'base' => get_pagenum_link(1) . '%_%',
                    'format' => '?paged=%#%',
                    'prev_text' => __( '&laquo;', 'cmp' ),
                    'next_text' => __( '&raquo;', 'cmp' ),
                    'total' => $total_pages,
                    'current' => $paged
                    ) );
                  if ( $page_links ) {
                    echo '<div class="page-nav"><span class="pages">'.$paged.'/'.$total_pages.'</span>' . $page_links . '</div>';
                  }
                  ?>
                <?php endif; ?>
              </div>
              <div class="clear"></div>
            </div><!--/.entry-->
          </div><!--/.post-inner-->
        </article><!--/.post-->
      <?php endwhile; ?>
      <div class="clear"></div>
    </div>
  </div><!--/.pad-->
</section><!--/.content-->
<?php //get_sidebar(); ?>
<?php get_footer(); ?>