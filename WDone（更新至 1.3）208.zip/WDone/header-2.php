<!DOCTYPE html>
<html class="no-js" <?php language_attributes();?>>
<head>
  <?php get_template_part( "includes/seo" ) ?>
  <meta charset="<?php bloginfo( 'charset' ); ?>" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="Cache-Control" content="no-transform" />
  <meta http-equiv="Cache-Control" content="no-siteapp" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <meta name="renderer" content="webkit">
  <link rel="profile" href="http://gmpg.org/xfn/11" />
  <?php wp_head(); ?>
</head>
<body id="top" <?php body_class('col-2cl'); ?>>
  <div id="wrapper">
    <header id="header">
      <nav class="nav-container group" id="nav-topbar">
        <div class="nav-toggle"><i class="fa fa-bars"></i></div>
        <div class="nav-text"></div>
        <div class="nav-wrap container">
          <ul id="menu-header" class="nav container-inner group">
            <?php if(function_exists('wp_nav_menu')) wp_nav_menu(array('container' => false, 'items_wrap' => '%3$s','theme_location' => 'top-menu', 'fallback_cb' => '','walker' => new wp_bootstrap_navwalker() )) ; ?>
          </ul>
        </div>
      </nav><!--/#nav-topbar-->
      <div class="container group">
        <div class="container-inner">
          <?php get_template_part('includes/popup-menu' ); ?>
          <div class="group pad">
            <?php
            if ( cmp_get_option('blog_logo')){
              $logo_class = 'class="site-image"';
            }else {
              $logo_class = '';
            }
            ?>
            <?php if(is_home() || is_front_page()): ?>
              <h1 class="site-title">
                <a <?php echo $logo_class;?> href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php bloginfo( 'name' ) ?></a>
              </h1>
            <?php else : ?>
              <div class="site-title">
                <a <?php echo $logo_class;?> href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php bloginfo( 'name' ) ?></a>
              </div>
            <?php endif; ?>
            <?php if( get_bloginfo( 'description' ) && cmp_get_option('head_description')): ?>
              <p class="site-description"><?php bloginfo( 'description' ); ?></p>
            <?php endif; ?>
            <?php get_template_part('includes/ad-top-right' );?>
          </div>
          <nav class="nav-container group <?php if(cmp_get_option('nav_fixed')) echo 'nav-header'; ?>" id="nav-header">
            <div class="nav-toggle"><i class="fa fa-bars"></i></div>
            <div class="nav-text"></div>
            <div class="nav-wrap container">
              <ul id="menu-header" class="nav container-inner group">
                <?php if(function_exists('wp_nav_menu')) wp_nav_menu(array('container' => false, 'items_wrap' => '%3$s','theme_location' => 'main-menu', 'fallback_cb' => '','walker' => new wp_bootstrap_navwalker() )) ; ?>
              </ul>
            </div>
            <div class="container">
              <div class="container-inner">
                <?php
                if(cmp_get_option( 'baidu_search' )){
                  $action = 'http://'.cmp_get_option( 'search_domain' ).'/cse/search';
                  $search_id = '<input type="hidden" name="s" value="'.cmp_get_option( 'search_id' ).'">';
                  $name = 'q';
                }else{
                  $action = home_url();
                  $search_id = '';
                  $name = 's';
                }
                ?>
                <div class="toggle-search"><i class="fa fa-search"></i></div>
                <div class="search-expand">
                  <div class="search-expand-inner">
                    <form method="get" class="searchform themeform" action="<?php echo $action ?>" <?php if(cmp_get_option( 'search_target' )) echo 'target="_blank"'; ?>>
                        <div>
                            <?php echo $search_id ?>
                            <input type="text" class="search" name="<?php echo $name ?>" onblur="if(this.value=='')this.value='<?php _e('Input and press Enter','cmp'); ?>';" onfocus="if(this.value=='<?php _e('Input and press Enter','cmp'); ?>')this.value='';" value="<?php _e('Input and press Enter','cmp'); ?>" x-webkit-speech />
                            <button type="submit" id="submit-bt" title="<?php _e('Search' , 'cmp'); ?>"><i class="fa fa-search"></i></button>
                        </div>
                    </form>
                  </div>
                </div>
              </div><!--/.container-inner-->
            </div><!--/.container-->
          </nav><!--/#nav-header-->
        </div><!--/.container-inner-->
      </div><!--/.container-->
    </header><!--/#header-->
    <div class="container">
      <div class="container-inner">
        <?php if(cmp_get_option( 'announcement' )): ?>
          <div class="site-notice"><?php echo htmlspecialchars_decode(cmp_get_option( 'announcement' ));?></div>
        <?php endif; ?>
        <?php get_template_part('includes/ad-top' );?>
        <?php if( is_home() && !is_paged() && cmp_get_option('slider') && cmp_get_option('slider_position') == 'top' ) get_template_part('includes/slider' );?>
        <div class="main">
          <div class="main-inner user-page group">