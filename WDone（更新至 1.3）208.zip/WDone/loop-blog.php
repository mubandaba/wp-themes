<?php if ( ! have_posts() ) : ?>
  <div class="post-list group">
    <article>
      <h2 class="post-title"><?php _e( 'Not Found', 'cmp' ); ?></h2>
      <div class="entry excerpt">
        <p><?php _e( 'Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post.', 'cmp' ); ?></p>
        <?php get_search_form(); ?>
      </div>
    </article>
  </div>
<?php else : ?>
  <div class="post-list group">
    <?php
    $i = 1;
    while ( have_posts() ) : the_post();
    if ( cmp_get_option('list_style') == 'big_thumb') { ?>
    <article id="post-<?php the_ID(); ?>" <?php post_class('big-thumb group');?> >
      <div class="post-inner post-hover">
        <?php if (cmp_get_option('archive_author')):?>
          <div class="post-meta-left has-author">
            <p class="post-author"><a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) )?>" title="<?php sprintf( esc_attr__( 'View all posts by %s', 'cmp' ), get_the_author() ) ?>" <?php echo cmp_target_blank();?>><?php echo get_avatar( get_the_author_meta('user_email'), 64 )?></a></p>
            <p><i class="fa fa-user"></i><?php echo get_the_author(); ?></p>
          <?php else: ?>
          <div class="post-meta-left">
          <?php endif; ?>
          <?php if (cmp_get_option('archive_date') && function_exists('cmp_get_time')) :?>
            <p><i class="fa fa-clock-o"></i><?php cmp_get_time();?></p>
          <?php endif; ?>
          <?php if( cmp_get_option('archive_views') && function_exists('the_views')): ?>
            <p><i class="fa fa-eye"></i><?php the_views();  ?></p>
          <?php endif; ?>
          <?php if (cmp_get_option('archive_comments')) :?>
            <p><i class="fa fa-comments-o"></i><?php comments_popup_link('0','1','%' ); ?></p>
          <?php endif; ?>
          <?php if (cmp_get_option('archive_tags') && has_tag()) :?>
            <div class="post-tag"><?php the_tags('<p><i class="fa fa-tag"></i>', '</p><p><i class="fa fa-tag"></i>', '</p>'); ?></div>
          <?php endif; ?>
        </div>
        <div class="post-info">
          <?php if (function_exists('cmp_post_thumbnail')): ?>
            <div class="post-thumbnail">
              <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>>
                <?php cmp_post_thumbnail(838,300); ?>
              </a>
              <?php if(function_exists('getPostLikeLink')): ?>
                <span class="post-like"><?php echo getPostLikeLink( $post->ID );?></span>
              <?php endif; ?>
            </div><!--/.post-thumbnail-->
          <?php endif; ?>
          <h2 class="post-title">
          <?php if(is_sticky()) echo '<i class="fa fa-thumb-tack" title="'.__('Sticky Post','cmp').'"></i>'; ?>
            <a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>><?php the_title(); ?></a>
          </h2><!--/.post-title-->
          <div class="entry excerpt">
            <?php if (function_exists('cmp_excerpt')) cmp_excerpt(); ?>
          </div><!--/.entry-->
        </div>
      </div><!--/.post-inner-->
    </article><!--/.post-->
    <?php } elseif ( cmp_get_option('list_style') == 'medium_thumb_1' ) { ?>
    <article id="post-<?php the_ID(); ?>" <?php if($i % 2 == 0) post_class('medium-thumb group vertical even');else post_class('medium-thumb group vertical');?> >
      <div class="post-inner post-hover">
        <?php if (function_exists('cmp_post_thumbnail')): ?>
          <div class="post-thumbnail">
            <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>>
              <?php cmp_post_thumbnail(408,240); ?>
            </a>
            <?php if(function_exists('getPostLikeLink')): ?>
              <span class="post-like"><?php echo getPostLikeLink( $post->ID );?></span>
            <?php endif; ?>
          </div><!--/.post-thumbnail-->
        <?php endif; ?>
        <div class="post-info">
          <h2 class="post-title">
          <?php if(is_sticky()) echo '<i class="fa fa-thumb-tack" title="'.__('Sticky Post','cmp').'"></i>'; ?>
            <a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>><?php the_title(); ?></a>
          </h2><!--/.post-title-->
          <div class="entry excerpt">
            <?php if (function_exists('cmp_excerpt')) cmp_excerpt(); ?>
          </div><!--/.entry-->
          <?php if (function_exists('loop_blog_meta')) loop_blog_meta(); ?>
        </div>
      </div><!--/.post-inner-->
    </article><!--/.post-->
    <?php } elseif ( cmp_get_option('list_style') == 'medium_thumb_2' ) { ?>
    <article id="post-<?php the_ID(); ?>" <?php post_class('medium-thumb group horizontal');?> >
      <div class="post-inner post-hover">
        <?php if (function_exists('cmp_post_thumbnail')): ?>
          <div class="post-thumbnail">
            <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>>
              <?php cmp_post_thumbnail(408,240); ?>
            </a>
            <?php if(function_exists('getPostLikeLink')): ?>
              <span class="post-like"><?php echo getPostLikeLink( $post->ID );?></span>
            <?php endif; ?>
          </div><!--/.post-thumbnail-->
        <?php endif; ?>
        <div class="post-info">
          <h2 class="post-title">
          <?php if(is_sticky()) echo '<i class="fa fa-thumb-tack" title="'.__('Sticky Post','cmp').'"></i>'; ?>
            <a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>><?php the_title(); ?></a>
          </h2><!--/.post-title-->
          <div class="entry excerpt">
            <?php if (function_exists('cmp_excerpt')) cmp_excerpt(); ?>
          </div><!--/.entry-->
          <?php if (function_exists('loop_blog_meta')) loop_blog_meta(); ?>
        </div>
        <div class="clear"></div>
      </div><!--/.post-inner-->
    </article><!--/.post-->
    <?php } elseif ( cmp_get_option('list_style') == 'litle_thumb' ) { ?>
    <article id="post-<?php the_ID(); ?>" <?php if(cmp_get_option('litle_thumb_right')) post_class('litle-thumb thumb-right group'); else post_class('litle-thumb group');?> >
      <div class="post-inner post-hover">
      <h2 class="post-title">
          <?php if(is_sticky()) echo '<i class="fa fa-thumb-tack" title="'.__('Sticky Post','cmp').'"></i>'; ?>
            <a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>><?php the_title(); ?></a>
        </h2><!--/.post-title-->
        <?php if (function_exists('cmp_post_thumbnail')): ?>
          <div class="post-thumbnail">
            <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>>
              <?php cmp_post_thumbnail(204,120); ?>
            </a>
            <?php if(function_exists('getPostLikeLink')): ?>
              <span class="post-like"><?php echo getPostLikeLink( $post->ID );?></span>
            <?php endif; ?>
          </div><!--/.post-thumbnail-->
        <?php endif; ?>
        <div class="post-info">
          <div class="entry excerpt">
            <?php if (function_exists('cmp_excerpt')) cmp_excerpt(); ?>
          </div><!--/.entry-->
          <?php if (function_exists('loop_blog_meta')) loop_blog_meta(); ?>
        </div>
        <div class="clear"></div>
      </div><!--/.post-inner-->
    </article><!--/.post-->
    <?php } elseif ( cmp_get_option('list_style') == 'samll_thumb' ) { ?>
    <article id="post-<?php the_ID(); ?>" <?php if($i % 2 == 0) post_class('small-thumb group even');else post_class('small-thumb group');?> >
      <div class="post-inner post-hover">
        <div class="post-thumbnail">
          <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>>
            <?php cmp_post_thumbnail(150,90); ?>
          </a>
        </div><!--/.post-thumbnail-->
        <h3 class="post-title">
          <?php if(is_sticky()) echo '<i class="fa fa-thumb-tack" title="'.__('Sticky Post','cmp').'"></i>'; ?>
          <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><?php the_title(); ?></a>
        </h3>
        <div class="post-meta">
          <span><i class="fa fa-clock-o"></i><?php if (function_exists('cmp_get_time')) cmp_get_time();?></span>
          <span><i class="fa fa-eye"></i><?php if(function_exists('the_views')) { the_views(); } ?></span>
          <span><i class="fa fa-comments-o"></i><?php comments_popup_link('0','1','%' ); ?></span>
        </div>
        <div class="clear"></div>
      </div>
    </article>
    <?php } ?>
    <?php $i++; endwhile; ?>
    <div class="clear"></div>
    <?php if ($wp_query->max_num_pages > 1) cmp_pagenavi(); ?>
  </div>
<?php endif; ?>
<?php
function loop_blog_meta(){
  if (cmp_get_option('archive_meta')) :?>
  <div class="post-meta">
    <?php if (cmp_get_option('archive_author')):?>
      <span><i class="fa fa-user"></i><a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) )?>" title="<?php sprintf( esc_attr__( 'View all posts by %s', 'cmp' ), get_the_author() ) ?>"><?php echo get_the_author() ?></a></span>
    <?php endif; ?>
    <?php
    if (cmp_get_option('archive_category') ){
      $categories = get_the_category();
        if ( ! empty( $categories ) ) {
            echo '<span><i class="fa fa-folder-open"></i><a href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a></span>';
        } 
    }
    ?>
    <?php if (cmp_get_option('archive_date') && function_exists('cmp_get_time')) :?>
      <span><i class="fa fa-clock-o"></i><?php cmp_get_time();?></span>
    <?php endif; ?>
    <?php if( cmp_get_option('archive_views') && function_exists('the_views')): ?>
      <span><i class="fa fa-eye"></i><?php the_views();  ?></span>
    <?php endif; ?>
    <?php if (cmp_get_option('archive_comments')) :?>
      <span><i class="fa fa-comments-o"></i><?php comments_popup_link('0','1','%' ); ?></span>
    <?php endif; ?>
    <?php if (cmp_get_option('archive_tags') && has_tag()) :?>
      <span><i class="fa fa-tags"></i><?php the_tags('',''); ?></span>
    <?php endif; ?>
  </div>
<?php endif;
}
?>