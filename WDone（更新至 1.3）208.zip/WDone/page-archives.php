<?php
/*
Template Name: archives
*/
?>
<?php get_header(); ?>
<section class="content">
  <?php cmp_breadcrumbs();?>
  <div class="pad group">
    <div id="post">
      <?php while ( have_posts() ) : the_post(); ?>
        <article <?php post_class(); ?> itemscope itemtype="http://schema.org/Article">
          <div class="post-inner group">
            <header class="entry-header">
              <h1 class="post-title" itemprop="headline"><?php the_title(); ?></h1>
              <div class="clear"></div>
            </header>
            <div class="entry" itemprop="articleBody">
              <div class="entry-inner">
                <?php the_content(); ?>
                <?php archives_list(); ?>
                <script src="<?php echo get_template_directory_uri(); ?>/js/archives.js"></script>
              </div>
              <div class="clear"></div>
            </div><!--/.entry-->
          </div><!--/.post-inner-->
        </article><!--/.post-->
      <?php endwhile;?>
      <div class="clear"></div>
    </div>
  </div><!--/.pad-->
</section><!--/.content-->
<?php get_sidebar(); ?>
<?php get_footer(); ?>