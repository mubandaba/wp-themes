<?php
function get_home_scroll( $cat_data ){
  global $post;
  $Cat_ID = $cat_data['id'];
  $Posts = $cat_data['number'];
  $images = $cat_data['items'];
  $cat_title = $cat_data['title'] ? $cat_data['title'] : get_the_category_by_ID($Cat_ID);
  $cat_title_url = $cat_data['title_url'] ? $cat_data['title_url'] :get_category_link( $Cat_ID );
  if($images == '2') {
    $slider_class = 'slider-two';
    $width = 408;
    $height = 240;
  }elseif($images == '3'){
    $slider_class = 'slider-three';
    $width = 408;
    $height = 240;
  }else{
    $slider_class = 'slider-one';
    $width = 840;
    $height = 300;
  }
$post_ids = '';
if($cat_data['post_ids'] || $cat_data['post_ids'] !='')$post_ids = explode(',', $cat_data['post_ids'] );
if($post_ids){
  $args = array( 'post__in' => $post_ids ,'posts_per_page'=> $Posts , 'orderby'=>'post__in','ignore_sticky_posts' => 1 ,'no_found_rows' => 1);
  $cat_query = new WP_Query( $args );
}elseif($Cat_ID){
  $cat_query = new WP_Query('cat='.$Cat_ID.'&posts_per_page='.$Posts.'&no_found_rows=true');
}
$who = $cat_data['who'];
if( $who == 'logged' && !is_user_logged_in()):
  // return none;
elseif( $who == 'anonymous' && is_user_logged_in()):
  // return none;
else:
  ?>
  <div class="post-box scroll-posts">
    <h2 class="box-title"><span><a href="<?php echo $cat_title_url; ?>" <?php echo cmp_target_blank();?>><?php echo $cat_title ; ?></a></span></h2>
    <?php if($cat_query->have_posts()): ?>
      <div id="<?php echo 'scroll-'.$Cat_ID; ?>" class="slider <?php echo $slider_class; ?>">
        <?php $i= 1; while ( $cat_query->have_posts() ) : $cat_query->the_post()?>
        <article class="item post-hover<?php echo ' item-'.$i; if( $images =='2' && $i % 2 == 0)  echo ' ml20'; ?>">
          <div class="post-thumbnail">
            <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>>
              <img class="lazyOwl" src="<?php echo post_thumbnail_src($width,$height); ?>" alt="<?php the_title_attribute(); ?>" title="<?php the_title_attribute(); ?>" width="<?php echo stripslashes($width); ?>" height="<?php echo stripslashes($height); ?>"/>
            </a>
            <h2 class="post-title">
              <a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>><?php the_title(); ?></a>
            </h2><!--/.post-title-->
            <?php if(function_exists('getPostLikeLink')): ?>
              <span class="post-like"><?php echo getPostLikeLink( $post->ID );?></span>
            <?php endif; ?>
          </div>
          <div class="entry excerpt">
            <?php cmp_excerpt_home() ?>
          </div><!--/.entry-->
          <div class="post-meta">
            <?php if(function_exists('cmp_get_time')): ?>
              <span><i class="fa fa-clock-o"></i><?php cmp_get_time();?></span>
            <?php endif; ?>
            <?php if(function_exists('the_views')): ?>
              <span><i class="fa fa-eye"></i><?php the_views(); ?></span>
            <?php endif; ?>
            <span><i class="fa fa-comments-o"></i><?php comments_popup_link('0','1','%' ); ?></span>
          </div><!--/.post-meta-->
        </article>
        <?php $i++; endwhile; ?>
      </div>
    <?php endif; wp_reset_query();?>
  </div>
  <?php if( $images == '2' ){ ?>
  <script>
    jQuery(document).ready(function($) {
      $("#<?php echo 'scroll-'.$Cat_ID; ?>").owlCarousel({
        autoPlay: 5000,
        items : 2,
        scrollPerPage : true,
        itemsDesktop : [1199,2],
        itemsDesktopSmall : [979,2],
        itemsTablet:[768,1],
        itemsMobile:[479,1],
        stopOnHover:true,
        navigation:true,
        lazyLoad:true,
        navigationText:["",""]
      });
    });
  </script>
<?php } elseif( $images == '3' ) { ?>
  <script>
    jQuery(document).ready(function($) {
      $("#<?php echo 'scroll-'.$Cat_ID; ?>").owlCarousel({
        autoPlay: 5000,
        items : 3,
        scrollPerPage : true,
        itemsDesktop : [1199,3],
        itemsDesktopSmall : [979,2],
        itemsTablet:[768,1],
        itemsMobile:[479,1],
        stopOnHover:true,
        navigation:true,
        lazyLoad:true,
        navigationText:["",""]
      });
    });
  </script>
  <?php }else{ ?>
  <script>
    jQuery(document).ready(function($) {
      $("#<?php echo 'scroll-'.$Cat_ID; ?>").owlCarousel({
        autoPlay: 5000,
        singleItem:true,
        navigation : true,
        stopOnHover:true,
        navigationText:["",""],
        lazyLoad:true
      });
    });
  </script>
  <?php }
  endif;//$who
} ?>