<?php
function get_home_cats( $cat_data ){ ?>
<?php
global $post;
$Cat_ID = $cat_data['id'];
$Posts = $cat_data['number'];
$order = $cat_data['order'];
$post_ids = '';
if($cat_data['post_ids'] || $cat_data['post_ids'] !='')$post_ids = explode(',', $cat_data['post_ids'] );
if($post_ids){
  $args = array( 'post__in' => $post_ids ,'posts_per_page'=> $Posts , 'orderby'=>'post__in','ignore_sticky_posts' => 1 ,'no_found_rows' => 1);
  $cat_query = new WP_Query( $args );
}elseif($Cat_ID){
  if( $order == 'rand') {
    $rand ="&orderby=rand";
    $cat_query = new WP_Query('cat='.$Cat_ID.'&posts_per_page='.$Posts.$rand.'&no_found_rows=true');
  } else {
    $cat_query = new WP_Query('cat='.$Cat_ID.'&posts_per_page='.$Posts.'&no_found_rows=true');
  }
}
$cat_title = $cat_data['title'] ? $cat_data['title'] : get_the_category_by_ID($Cat_ID);
$cat_title_url = $cat_data['title_url'] ? $cat_data['title_url'] :get_category_link( $Cat_ID );
$count = 0;
$home_layout = $cat_data['style'];
$who = $cat_data['who'];
if( $who == 'logged' && !is_user_logged_in()):
  // return none;
elseif( $who == 'anonymous' && is_user_logged_in()):
  // return none;
else:
?>
<?php if( $home_layout == '1ch' ):   ?>
  <div class="post-box half-width">
    <h2 class="box-title"><span><a href="<?php echo $cat_title_url; ?>" <?php echo cmp_target_blank();?>><?php echo $cat_title ; ?></a></span></h2>
    <div class="box-inner">
      <?php if($cat_query->have_posts()): while ( $cat_query->have_posts() ) : $cat_query->the_post(); $count ++ ;?>
        <?php if($count == 1) : ?>
          <article id="post-<?php the_ID(); ?>" <?php post_class('medium-thumb group');?> >
            <div class="post-inner post-hover">
              <?php if (function_exists('cmp_post_thumbnail')): ?>
                <div class="post-thumbnail">
                  <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>>
                    <?php cmp_post_thumbnail(408,240); ?>
                  </a>
                  <?php if(function_exists('getPostLikeLink')): ?>
                    <span class="post-like"><?php echo getPostLikeLink( $post->ID );?></span>
                  <?php endif; ?>
                </div><!--/.post-thumbnail-->
              <?php endif; ?>
              <div class="post-info">
                <h3 class="post-title">
                  <a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>><?php the_title(); ?></a>
                </h3><!--/.post-title-->
                <div class="entry excerpt">
                  <?php cmp_excerpt_home() ?>
                </div><!--/.entry-->
                <div class="post-meta">
                  <?php if(function_exists('cmp_get_time')): ?>
                    <span><i class="fa fa-clock-o"></i><?php cmp_get_time();?></span>
                  <?php endif; ?>
                  <?php if(function_exists('the_views')): ?>
                    <span><i class="fa fa-eye"></i><?php the_views(); ?></span>
                  <?php endif; ?>
                  <span><i class="fa fa-comments-o"></i><?php comments_popup_link('0','1','%' ); ?></span>
                </div>
              </div>
            </div><!--/.post-inner-->
          </article><!--/.post-->
          <div class="other-posts">
          <?php else: ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class('other-thumb group');?> >
              <div class="post-inner post-hover">
                <div class="post-thumbnail">
                  <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>>
                    <?php cmp_post_thumbnail(150,90); ?>
                  </a>
                </div><!--/.post-thumbnail-->
                <h3 class="post-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><?php the_title(); ?></a></h3>
                <div class="post-meta">
                  <?php if(function_exists('cmp_get_time')): ?>
                    <span><i class="fa fa-clock-o"></i><?php cmp_get_time();?></span>
                  <?php endif; ?>
                  <?php if(function_exists('the_views')): ?>
                    <span><i class="fa fa-eye"></i><?php the_views(); ?></span>
                  <?php endif; ?>
                  <span><i class="fa fa-comments-o"></i><?php comments_popup_link('0','1','%' ); ?></span>
                </div>
                <div class="clear"></div>
              </div>
            </article>
          <?php endif; ?>
        <?php endwhile; endif; wp_reset_query(); ?>
      </div>
      <div class="clear"></div>
    </div>
  </div>
<?php elseif( $home_layout == '1cf' ):   ?>
  <div class="post-box full-width">
    <h2 class="box-title"><span><a href="<?php echo $cat_title_url; ?>" <?php echo cmp_target_blank();?>><?php echo $cat_title ; ?></a></span></h2>
    <div class="box-inner">
      <?php if($cat_query->have_posts()): while ( $cat_query->have_posts() ) : $cat_query->the_post(); $count ++ ;?>
        <?php if($count == 1) : ?>
          <article id="post-<?php the_ID(); ?>" <?php post_class('medium-thumb group');?> >
            <div class="post-inner post-hover">
              <?php if (function_exists('cmp_post_thumbnail')): ?>
                <div class="post-thumbnail">
                  <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>>
                    <?php cmp_post_thumbnail(408,240); ?>
                  </a>
                  <?php if(function_exists('getPostLikeLink')): ?>
                    <span class="post-like"><?php echo getPostLikeLink( $post->ID );?></span>
                  <?php endif; ?>
                </div><!--/.post-thumbnail-->
              <?php endif; ?>
              <div class="post-info">
                <h3 class="post-title">
                  <a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>><?php the_title(); ?></a>
                </h3><!--/.post-title-->
                <div class="entry excerpt">
                  <?php cmp_excerpt_home() ?>
                </div><!--/.entry-->
                <div class="post-meta">
                  <?php if(function_exists('cmp_get_time')): ?>
                    <span><i class="fa fa-clock-o"></i><?php cmp_get_time();?></span>
                  <?php endif; ?>
                  <?php if(function_exists('the_views')): ?>
                    <span><i class="fa fa-eye"></i><?php the_views(); ?></span>
                  <?php endif; ?>
                  <span><i class="fa fa-comments-o"></i><?php comments_popup_link('0','1','%' ); ?></span>
                </div>
              </div>
            </div><!--/.post-inner-->
          </article><!--/.post-->
        <?php else: ?>
          <article id="post-<?php the_ID(); ?>" <?php if($count % 2 !== 0) post_class('other-thumb group even');else post_class('other-thumb group');?> >
            <div class="post-inner post-hover">
              <div class="post-thumbnail">
                <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>>
                  <?php cmp_post_thumbnail(150,90); ?>
                </a>
              </div><!--/.post-thumbnail-->
              <h3 class="post-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><?php the_title(); ?></a></h3>
              <div class="post-meta">
                <?php if(function_exists('cmp_get_time')): ?>
                  <span><i class="fa fa-clock-o"></i><?php cmp_get_time();?></span>
                <?php endif; ?>
                <?php if(function_exists('the_views')): ?>
                  <span><i class="fa fa-eye"></i><?php the_views(); ?></span>
                <?php endif; ?>
                <span><i class="fa fa-comments-o"></i><?php comments_popup_link('0','1','%' ); ?></span>
              </div>
              <div class="clear"></div>
            </div>
          </article>
        <?php endif; ?>
      <?php endwhile; endif; wp_reset_query(); ?>
      <div class="clear"></div>
    </div>
  </div>
<?php elseif( $home_layout == 'pic1' ):   ?>
  <div class="post-box pic-posts">
    <h2 class="box-title"><span><a href="<?php echo $cat_title_url; ?>" <?php echo cmp_target_blank();?>><?php echo $cat_title ; ?></a></span></h2>
    <div class="box-inner">
      <?php if($cat_query->have_posts()): while ( $cat_query->have_posts() ) : $cat_query->the_post(); $count ++ ;?>
        <?php if($count == 1) : ?>
          <article id="post-<?php the_ID(); ?>" <?php post_class('medium-thumb group');?> >
            <div class="post-inner post-hover">
              <?php if (function_exists('cmp_post_thumbnail')): ?>
                <div class="post-thumbnail">
                  <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>>
                    <?php cmp_post_thumbnail(408,240); ?>
                  </a>
                  <h3 class="post-title">
                    <a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>><?php the_title(); ?></a>
                  </h3><!--/.post-title-->
                  <?php if(function_exists('getPostLikeLink')): ?>
                    <span class="post-like"><?php echo getPostLikeLink( $post->ID );?></span>
                  <?php endif; ?>
                </div><!--/.post-thumbnail-->
              <?php endif; ?>
            </div><!--/.post-inner-->
          </article><!--/.post-->
        <?php else: ?>
          <article id="post-<?php the_ID(); ?>" <?php if($count % 2 !==0) post_class('other-pic group even mr-fix-'.$count); else post_class('other-pic group');?> >
            <div class="post-inner post-hover">
              <div class="post-thumbnail">
                <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>>
                  <?php cmp_post_thumbnail(204,120); ?>
                </a>
              </div><!--/.post-thumbnail-->
              <h3 class="post-title">
                    <a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>><?php the_title(); ?></a>
              </h3><!--/.post-title-->
            </div>
          </article>
        <?php endif; ?>
      <?php endwhile;?>
    <?php endif; wp_reset_query();?>
    <div class="clear"></div>
  </div>
</div>
<?php elseif( $home_layout == 'pic2' ): ?>
  <div class="post-box pic-posts">
    <h2 class="box-title"><span><a href="<?php echo $cat_title_url; ?>" <?php echo cmp_target_blank();?>><?php echo $cat_title ; ?></a></span></h2>
    <div class="box-inner">
      <?php if($cat_query->have_posts()): while ( $cat_query->have_posts() ) : $cat_query->the_post(); $count ++ ;?>
        <article id="post-<?php the_ID(); ?>" <?php post_class('other-pic pic-'.$count.' group');?> >
          <div class="post-inner post-hover">
            <div class="post-thumbnail">
              <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>>
                <?php cmp_post_thumbnail(204,120); ?>
              </a>
            </div><!--/.post-thumbnail-->
          </div>
        </article>
      <?php endwhile;?>
    <?php endif; wp_reset_query();?>
    <div class="clear"></div>
  </div>
</div>
<?php else: ?>
  <div class="post-box full-width">
    <h2 class="box-title"><span><a href="<?php echo $cat_title_url; ?>" <?php echo cmp_target_blank();?>><?php echo $cat_title ; ?></a></span></h2>
    <div class="box-inner">
      <?php if($cat_query->have_posts()): while ( $cat_query->have_posts() ) : $cat_query->the_post(); $count ++ ;?>
        <article id="post-<?php the_ID(); ?>" <?php if($count % 2 == 0) post_class('other-thumb group even');else post_class('other-thumb group');?> >
          <div class="post-inner post-hover">
            <div class="post-thumbnail">
              <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>>
                <?php cmp_post_thumbnail(150,90); ?>
              </a>
            </div><!--/.post-thumbnail-->
            <h3 class="post-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><?php the_title(); ?></a></h3>
            <div class="post-meta">
              <?php if(function_exists('cmp_get_time')): ?>
                <span><i class="fa fa-clock-o"></i><?php cmp_get_time();?></span>
              <?php endif; ?>
              <?php if(function_exists('the_views')): ?>
                <span><i class="fa fa-eye"></i><?php the_views(); ?></span>
              <?php endif; ?>
              <span><i class="fa fa-comments-o"></i><?php comments_popup_link('0','1','%' ); ?></span>
            </div>
            <div class="clear"></div>
          </div>
        </article>
      <?php endwhile; endif; wp_reset_query(); ?>
      <div class="clear"></div>
    </div>
  </div>
<?php endif; ?>
<?php endif;//$who ?>
<?php } ?>