<?php
function get_home_recent( $cat_data ){
  $exclude = @$cat_data['exclude'];
  $Posts = $cat_data['number'];
  $most_commented = $cat_data['show_most_commented'];
  $most_viewed = $cat_data['show_most_viewed'];
  $random = $cat_data['show_random'];
  $who = $cat_data['who'];
  if( $who == 'logged' && !is_user_logged_in()):
    // return none;
  elseif( $who == 'anonymous' && is_user_logged_in()):
    // return none;
  else:
  ?>
  <?php if( $most_commented || $most_viewed || $random ): ?>
    <div id="home-news-tabs">
      <ul class="resp-tabs-list">
        <li><?php _e('Recent Posts','cmp'); ?></li>
        <?php if( $most_commented ): ?>
          <li><?php _e('Most Commented ','cmp'); ?></li>
        <?php endif; ?>
        <?php if( function_exists('the_views')&& $most_viewed): ?>
          <li><?php _e('Most Viewed ','cmp'); ?></li>
        <?php endif; ?>
        <?php if( $random ): ?>
          <li><?php _e('Random ','cmp'); ?></li>
        <?php endif; ?>
      </ul>
      <div class="resp-tabs-container">
        <div class="post-list group">
          <?php
          $latest_query = new WP_Query(array ( 'ignore_sticky_posts' => true, 'posts_per_page' => $Posts , 'post_type' => 'post' , 'no_found_rows' => 1, 'category__not_in' => $exclude)); ?>
          <?php $i=1; while ( $latest_query->have_posts() ) : $latest_query->the_post()?>
          <article id="post-<?php the_ID(); ?>" <?php if($i % 2 == 0) post_class('small-thumb group even');else post_class('small-thumb group');?> >
            <div class="post-inner post-hover">
              <div class="post-thumbnail">
                <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>>
                  <?php cmp_post_thumbnail(150,90); ?>
                </a>
              </div><!--/.post-thumbnail-->
              <h3 class="post-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><?php the_title(); ?></a></h3>
              <div class="post-meta">
                <?php if(function_exists('cmp_get_time')): ?>
                  <span><i class="fa fa-clock-o"></i><?php cmp_get_time();?></span>
                <?php endif; ?>
                <?php if(function_exists('the_views')): ?>
                  <span><i class="fa fa-eye"></i><?php the_views(); ?></span>
                <?php endif; ?>
                <span><i class="fa fa-comments-o"></i><?php comments_popup_link('0','1','%' ); ?></span>
              </div>
              <div class="clear"></div>
            </div>
          </article>
          <?php $i++; endwhile;wp_reset_query(); ?>
          <div class="clear"></div>
        </div>
        <?php if( $most_commented ): ?>
          <div class="post-list group">
            <?php
            $popular = new WP_Query( array('post_type' => 'post','showposts'=> $Posts,'category__not_in' => $exclude,'ignore_sticky_posts'=> true,'orderby'=> 'comment_count','order'=> 'dsc', 'no_found_rows' => 1, 'date_query' => array(array('day' => '30') ) ) );
            ?>
            <?php $i=1; while ( $popular->have_posts() ): $popular->the_post(); ?>
            <article id="post-<?php the_ID(); ?>" <?php if($i % 2 == 0) post_class('small-thumb group even');else post_class('small-thumb group');?> >
              <div class="post-inner post-hover">
                <div class="post-thumbnail">
                  <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>>
                    <?php cmp_post_thumbnail(150,90); ?>
                  </a>
                </div><!--/.post-thumbnail-->
                <h3 class="post-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><?php the_title(); ?></a></h3>
                <div class="post-meta">
                  <?php if(function_exists('cmp_get_time')): ?>
                    <span><i class="fa fa-clock-o"></i><?php cmp_get_time();?></span>
                  <?php endif; ?>
                  <?php if(function_exists('the_views')): ?>
                    <span><i class="fa fa-eye"></i><?php the_views(); ?></span>
                  <?php endif; ?>
                  <span><i class="fa fa-comments-o"></i><?php comments_popup_link('0','1','%' ); ?></span>
                </div>
                <div class="clear"></div>
              </div>
            </article>
            <?php $i++; endwhile; wp_reset_query(); ?>
            <div class="clear"></div>
          </div>
        <?php endif; ?>
        <?php if( function_exists('the_views')&& $most_viewed): ?>
          <div class="post-list group">
            <?php
            $mostViews = new WP_Query( array('post_type'=> 'post','showposts'=> $Posts,'category__not_in' => $exclude, 'ignore_sticky_posts'=> true,'meta_key' => 'views','orderby'=> 'meta_value_num','order'=> 'dsc','no_found_rows' => 1,'date_query' => array(array('day' => '30') ) ) );
            ?>
            <?php $i=1; while ( $mostViews->have_posts() ): $mostViews->the_post(); ?>
            <article id="post-<?php the_ID(); ?>" <?php if($i % 2 == 0) post_class('small-thumb group even');else post_class('small-thumb group');?> >
              <div class="post-inner post-hover">
                <div class="post-thumbnail">
                  <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>>
                    <?php cmp_post_thumbnail(150,90); ?>
                  </a>
                </div><!--/.post-thumbnail-->
                <h3 class="post-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><?php the_title(); ?></a></h3>
                <div class="post-meta">
                  <?php if(function_exists('cmp_get_time')): ?>
                    <span><i class="fa fa-clock-o"></i><?php cmp_get_time();?></span>
                  <?php endif; ?>
                  <?php if(function_exists('the_views')): ?>
                    <span><i class="fa fa-eye"></i><?php the_views(); ?></span>
                  <?php endif; ?>
                  <span><i class="fa fa-comments-o"></i><?php comments_popup_link('0','1','%' ); ?></span>
                </div>
                <div class="clear"></div>
              </div>
            </article>
            <?php $i++; endwhile; wp_reset_query(); ?>
            <div class="clear"></div>
          </div>
        <?php endif; ?>
        <?php if( $random ): ?>
          <div class="post-list group">
            <?php
            $rand_query = new WP_Query(array ( 'ignore_sticky_posts' => true, 'posts_per_page' => $Posts , 'post_type' => 'post' ,'orderby' => 'rand','no_found_rows' => 1,'category__not_in' => $exclude)); ?>
            <?php $i=1; while ( $rand_query->have_posts() ) : $rand_query->the_post()?>
            <article id="post-<?php the_ID(); ?>" <?php if($i % 2 == 0) post_class('small-thumb group even');else post_class('small-thumb group');?> >
              <div class="post-inner post-hover">
                <div class="post-thumbnail">
                  <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>>
                    <?php cmp_post_thumbnail(150,90); ?>
                  </a>
                </div><!--/.post-thumbnail-->
                <h3 class="post-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><?php the_title(); ?></a></h3>
                <div class="post-meta">
                  <?php if(function_exists('cmp_get_time')): ?>
                    <span><i class="fa fa-clock-o"></i><?php cmp_get_time();?></span>
                  <?php endif; ?>
                  <?php if(function_exists('the_views')): ?>
                    <span><i class="fa fa-eye"></i><?php the_views(); ?></span>
                  <?php endif; ?>
                  <span><i class="fa fa-comments-o"></i><?php comments_popup_link('0','1','%' ); ?></span>
                </div>
                <div class="clear"></div>
              </div>
            </article>
            <?php $i++; endwhile; wp_reset_query(); ?>
            <div class="clear"></div>
          </div>
        <?php endif; ?>
      </div>
      <script>
        jQuery(document).ready(function ($) {
          $('#home-news-tabs').easyResponsiveTabs();
        });
      </script>
    <?php else: ?>
      <h2 class="box-title"><span><?php _e('Recent Posts','cmp'); ?></span></h2>
      <div class="post-list group">
      <?php
      $latest_query = new WP_Query(array ( 'ignore_sticky_posts' => true, 'posts_per_page' => $Posts , 'post_type' => 'post' , 'no_found_rows' => 1, 'category__not_in' => $exclude)); ?>
      <?php $i=1; while ( $latest_query->have_posts() ) : $latest_query->the_post()?>
      <article id="post-<?php the_ID(); ?>" <?php if($i % 2 == 0) post_class('small-thumb group even');else post_class('small-thumb group');?> >
        <div class="post-inner post-hover">
          <div class="post-thumbnail">
            <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>>
              <?php cmp_post_thumbnail(150,90); ?>
            </a>
          </div><!--/.post-thumbnail-->
          <h3 class="post-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><?php the_title(); ?></a></h3>
          <div class="post-meta">
            <?php if(function_exists('cmp_get_time')): ?>
              <span><i class="fa fa-clock-o"></i><?php cmp_get_time();?></span>
            <?php endif; ?>
            <?php if(function_exists('the_views')): ?>
              <span><i class="fa fa-eye"></i><?php the_views(); ?></span>
            <?php endif; ?>
            <span><i class="fa fa-comments-o"></i><?php comments_popup_link('0','1','%' ); ?></span>
          </div>
          <div class="clear"></div>
        </div>
      </article>
      <?php $i++; endwhile;wp_reset_query(); ?>
      <div class="clear"></div>
      </div>
    <?php endif; ?>
    <?php
    endif;//$who
  }
  ?>