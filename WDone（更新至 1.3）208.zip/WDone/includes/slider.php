<?php
global $post;
$orig_post = $post;
$number = cmp_get_option( 'slider_number' );
$slider_query = cmp_get_option( 'slider_query' );
if( $slider_query == 'custom' ){
	$custom_slider_args = array( 'post_type' => 'cmp_slider', 'p' => cmp_get_option( 'slider_custom') ,'no_found_rows' => 1);
  $custom_slider = new WP_Query( $custom_slider_args );
}else{
  if( $slider_query  == 'tag'){
    $tags = explode (' , ' , cmp_get_option('slider_tag'));
    foreach ($tags as $tag){
      $theTagId = get_term_by( 'name', $tag, 'post_tag' );
      if($fea_tags) $sep = ' , ';
      $fea_tags .=  $sep . $theTagId->slug;
    }
		$args= array('posts_per_page'=> $number , 'tag' => $fea_tags,'no_found_rows' => 1);
  }
  elseif( $slider_query  == 'category'){
		$args= array('posts_per_page'=> $number , 'category__in' => cmp_get_option('slider_cat'),'no_found_rows' => 1);
  }
  elseif( $slider_query  == 'post'){
    $posts = explode (',' , cmp_get_option('slider_posts'));
		$args= array('posts_per_page'=> $number , 'post_type' => 'post', 'post__in' => $posts,'ignore_sticky_posts' => 1 ,'no_found_rows' => 1);
  }
  elseif( $slider_query  == 'page'){
    $pages = explode (',' , cmp_get_option('slider_pages'));
		$args= array('posts_per_page'=> $number , 'post_type' => 'page', 'post__in' => $pages ,'no_found_rows' => 1 );
  }
  elseif( $slider_query  == 'sticky'){
		$args= array('posts_per_page'=> $number ,'post__in'  => get_option( 'sticky_posts' ),'ignore_sticky_posts' => 1 ,'no_found_rows' => 1);
	}elseif( $slider_query  == 'latest'){
		$args= array('posts_per_page'=> $number ,'ignore_sticky_posts' => 1,'no_found_rows' => 1 );
  }
  $featured_query = new wp_query( $args );
}
$stopOnHover = cmp_get_option( 'slider_autoHover' ) ? cmp_get_option( 'slider_autoHover' ):true;
$auto = cmp_get_option( 'slider_auto' );
$autoPlay = cmp_get_option( 'auto_play' ) ? cmp_get_option( 'auto_play' ):5000;
$images = cmp_get_option('images_number');

if($images =='2') {
  $slider_class = 'slider-two';
  if(cmp_get_option('slider_position') == 'top'){
    $width = 838;
    $height = 300;
  }else{
    $width = 408;
    $height = 240;
  }
}elseif($images =='3') {
  $slider_class = 'slider-three';
  $width = 408;
  $height = 240;
} else {
  $slider_class = 'slider-one';
  $width = 838;
  $height = 300;
}
if(cmp_get_option('slider_position') == 'top') $slider_id = 'top-carousel';
if(cmp_get_option('slider_position') == 'left') $slider_id = 'left-carousel';
?>
<?php if( $slider_query != 'custom' ): ?>
  <?php if( $featured_query->have_posts() ) : ?>
    <div class="box-inner">
      <div id="<?php echo $slider_id; ?>" class="slider <?php echo $slider_class; ?>">
        <?php $i= 1; while ( $featured_query->have_posts() ) : $featured_query->the_post();?>
        <article class="item post-hover<?php  echo ' item-'.$i; if($images =='2' && $i % 2 == 0)  echo ' ml20'; ?>">
          <div class="post-thumbnail">
            <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>>
              <img class="lazyOwl" data-src="<?php echo post_thumbnail_src($width,$height); ?>" alt="<?php the_title_attribute(); ?>" width="<?php echo stripslashes($width); ?>" height="<?php echo stripslashes($height); ?>"/>
            </a>
            <h2 class="post-title">
              <a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>><?php the_title();?></a>
            </h2><!--/.post-title-->
            <?php if(function_exists('getPostLikeLink')): ?>
              <span class="post-like"><?php echo getPostLikeLink( $post->ID );?></span>
            <?php endif; ?>
          </div>
          <div class="entry excerpt">
            <?php if (function_exists('cmp_excerpt')) cmp_excerpt(); ?>
          </div><!--/.entry-->
          <div class="post-meta">
            <?php if(function_exists('cmp_get_time')): ?>
              <span><i class="fa fa-clock-o"></i><?php cmp_get_time();?></span>
            <?php endif; ?>
            <?php if(function_exists('the_views')): ?>
              <span><i class="fa fa-eye"></i><?php the_views(); ?></span>
            <?php endif; ?>
            <span><i class="fa fa-comments-o"></i><?php comments_popup_link('0','1','%' ); ?></span>
          </div><!--/.post-meta-->
        </article>
        <?php $i++; endwhile;?>
      </div>
    </div>
  <?php endif; wp_reset_query();?>
<?php else: ?>
  <div class="box-inner">
    <div id="<?php echo $slider_id; ?>" class="slider <?php echo $slider_class; ?>">
      <?php $i= 1;
      while ( $custom_slider->have_posts() ) : $custom_slider->the_post();
      $custom = get_post_custom($post->ID);
      $slider = unserialize( $custom["custom_slider"][0] );
      $number = count($slider);
      if( $slider ){
        foreach( $slider as $slide ): ?>
        <article class="item post-hover<?php  echo ' item-'.$i; if($images =='2' && $i % 2 == 0)  echo ' ml20'; ?>">
          <div class="post-thumbnail">
            <?php if( !empty( $slide['link'] ) ):?><a href="<?php  echo stripslashes( $slide['link'] )  ?>" <?php if($slide['target'] == 'on') echo 'target="_blank"' ?>><?php endif; ?>
            <img class="lazyOwl" data-src="<?php echo cmp_slider_img_src( $slide['id'] , $width , $height ) ?>" alt="thumb<?php echo $i; ?>" width="<?php echo stripslashes($width); ?>" height="<?php echo stripslashes($height);?>" />
            <?php if( !empty( $slide['link'] ) ):?>
            </a>
          <?php endif; ?>
          <?php if( !empty( $slide['title'] ) ):?>
            <h2 class="post-title">
              <a href="<?php  echo stripslashes( $slide['link'] )  ?>" rel="bookmark" title="<?php echo stripslashes( $slide['title'] );?>" <?php if($slide['target'] == 'on') echo 'target="_blank"' ?>><?php echo stripslashes( $slide['title'] );?></a>
            </h2><!--/.post-title-->
          <?php endif; ?>
        </div>
        <?php if( !empty( $slide['caption'] ) ):?>
          <div class="entry excerpt">
            <?php echo stripslashes( $slide['caption'] );?>
          </div><!--/.entry-->
        <?php endif; ?>
      </article>
      <?php $i++; endforeach;
    }
    endwhile; wp_reset_query();?>
  </div>
</div>
<?php endif; ?>
<?php if( $images == '1' ){ ?>
<script>
  jQuery(document).ready(function($) {
    $("#<?php echo $slider_id; ?>").owlCarousel({
      <?php if( $auto ) echo 'autoPlay: '. $autoPlay .','; ?>
      singleItem:true,
      navigation : true,
      stopOnHover:<?php echo $stopOnHover; ?>,
      navigationText:["",""],
      lazyLoad:true
    });
  });
</script>
<?php } elseif( $images == '2' ) { ?>
<script>
  jQuery(document).ready(function($) {
    $("#<?php echo $slider_id; ?>").owlCarousel({
      <?php if($auto = true) echo 'autoPlay: '. $autoPlay .','; ?>
      items : 2,
      scrollPerPage : true,
      itemsDesktop : [1199,2],
      itemsDesktopSmall : [979,2],
      itemsTablet:[768,1],
      itemsMobile:[479,1],
      stopOnHover:<?php echo $stopOnHover; ?>,
      navigation:true,
      lazyLoad:true,
      navigationText:["",""]
    });
  });
</script>
<?php } elseif( $images == '3' ) { ?>
<script>
  jQuery(document).ready(function($) {
    $("#<?php echo $slider_id; ?>").owlCarousel({
      <?php if($auto = true) echo 'autoPlay: '. $autoPlay .','; ?>
      items : 3,
      scrollPerPage : true,
      itemsDesktop : [1199,3],
      itemsDesktopSmall : [979,2],
      itemsTablet:[768,1],
      itemsMobile:[479,1],
      stopOnHover:<?php echo $stopOnHover; ?>,
      navigation:true,
      lazyLoad:true,
      navigationText:["",""]
    });
  });
</script>
<?php } ?>