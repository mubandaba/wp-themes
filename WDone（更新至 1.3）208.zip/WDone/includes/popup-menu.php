<div class="popup-menu">
  <?php if ( cmp_get_option('popup_follows')): ?>
    <div class="menu-follow">
      <a class="btn btn-arrow btn-popupmenu" href="javascript:;"><?php _e('Follows','cmp') ?><i class="arrow"></i></a>
      <div class="popup-layer">
        <div class="popup">
          <div class="popup-inner">
          <?php if(cmp_get_option('sina_weibo')||cmp_get_option('qq_weibo')||cmp_get_option('twitter')||cmp_get_option('google_plus')): ?>
            <h4><?php _e('Follows Us','cmp') ?></h4>
            <?php endif ?>
            <?php if(cmp_get_option('sina_weibo')): ?>
              <a class="sina_weibo" href="<?php echo stripslashes(cmp_get_option('sina_weibo')); ?>" target="_blank" rel="external nofollow" title="<?php _e('Sina Weibo','cmp') ?>"><i class="fa fa-weibo"></i><?php _e('Sina Weibo','cmp') ?></a>
            <?php endif ?>
            <?php if(cmp_get_option('qq_weibo')): ?>
              <a class="qq_weibo" href="<?php echo stripslashes(cmp_get_option('qq_weibo')); ?>" target="_blank" rel="external nofollow" title="<?php _e('QQ Weibo','cmp') ?>"><i class="fa fa-tencent-weibo"></i><?php _e('QQ Weibo','cmp') ?></a>
            <?php endif ?>
            <?php if(cmp_get_option('twitter')): ?>
              <a class="twitter" href="<?php echo stripslashes(cmp_get_option('twitter')); ?>" target="_blank" rel="external nofollow" title="<?php _e('Twitter','cmp') ?>"><i class="fa fa-twitter"></i><?php _e('Twitter ','cmp') ?></a>
            <?php endif ?>
            <?php if(cmp_get_option('google_plus')): ?>
              <a class="google_plus" href="<?php echo stripslashes(cmp_get_option('google_plus')); ?>" target="_blank" rel="external nofollow"  title="<?php _e('Google+','cmp') ?>"><i class="fa fa-google-plus"></i><?php _e('Google+ ','cmp') ?></a>
            <?php endif ?>
            <div class="clear"></div>
            <?php if(cmp_get_option('qq')||cmp_get_option('send_email')||cmp_get_option('qq_group')): ?>
            <h4><?php _e('Contact Us','cmp') ?></h4>
            <?php endif ?>
            <?php if(cmp_get_option('qq')): ?>
              <a class="qq" href="http://wpa.qq.com/msgrd?v=3&amp;site=qq&amp;menu=yes&amp;uin=<?php echo stripslashes(cmp_get_option('qq')); ?>" target="_blank" rel="external nofollow" title="<?php _e('Contact me by QQ','cmp') ?>"><i class="fa fa-qq"></i><?php _e('QQ','cmp') ?></a>
            <?php endif ?>
            <?php if(cmp_get_option('send_email')): ?>
             <a class="email" href="<?php echo stripslashes(cmp_get_option('send_email')); ?>" target="_blank" rel="external nofollow" title="<?php _e('Send email','cmp') ?>"><i class="fa fa-envelope"></i><?php _e('Send email','cmp') ?></a>
           <?php endif ?>
           <div class="clear"></div>
           <?php if(cmp_get_option('qq_group')): ?>
            <?php if(cmp_get_option('qqqun_url')){ ?>
            <p><a class="qq_group" href="<?php echo stripslashes(cmp_get_option('qqqun_url')); ?>" target="_blank" rel="external nofollow" title="<?php _e('QQ Group','cmp') ?>"><i class="fa fa-users"></i><?php _e( 'QQ Group' , 'cmp' );echo stripslashes(cmp_get_option('qq_group')); ?></a></p>
            <?php }else { ?>
            <p><i class="fa fa-users"></i><?php _e( 'QQ Group' , 'cmp' );echo stripslashes(cmp_get_option('qq_group')); ?></p>
            <?php }
            endif; ?>
            <?php if(cmp_get_option('rss_url')): ?>
              <h4><a class="rss" href="<?php echo stripslashes(cmp_get_option('rss_url')); ?>" target="_blank" rel="external nofollow" title="<?php _e('Subscribe','cmp') ?>"><?php _e('Subscribe','cmp') ?> <i class="fa fa-rss"></i></a></h4>
            <p><input class="ipt" type="text" readonly value="<?php echo stripslashes(cmp_get_option('rss_url')); ?>"></p>
            <p><?php _e('Subscribe To:','cmp'); ?>
             <a rel="external nofollow" target="_blank" href="http://reader.youdao.com/b.do?keyfrom=bookmarklet&url=<?php echo rawurlencode(cmp_get_option('rss_url')); ?>"><?php _e('Youdao','cmp') ?></a>
             <a rel="external nofollow" target="_blank" href="http://feedly.com/index.html#subscription%2Ffeed%2F<?php echo stripslashes(cmp_get_option('rss_url')); ?>"><?php _e('Feedly','cmp') ?></a>
           </p>
            <?php endif ?>
           <?php if(cmp_get_option('qq_email_list')): ?>
           <form action="http://list.qq.com/cgi-bin/qf_compose_send" target="_blank" method="post">
            <input type="hidden" name="t" value="qf_booked_feedback">
            <input type="hidden" name="id" value="<?php echo stripslashes(cmp_get_option('qq_email_list')); ?>">
            <input id="to" placeholder="<?php _e('Enter your E-mail','cmp') ?>" name="to" type="text" class="themeform ipt">
            <input class="btn btn-primary submit" type="submit" value="<?php _ex('Subscribe','Subscribe to Email','cmp') ?>">
          </form>
        <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
<?php endif; ?>
<?php if ( cmp_get_option('popup_login')): ?>
  <div class="menu-profile">
    <?php
    global $current_user;
    $u_id    = $current_user->ID;
    $user_info = get_userdata($u_id);
    $u_name    = get_user_meta($u_id,'nickname',true);
    $url_this = 'http://'.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"];
    if(cmp_get_option('password_url')){
      $password_url = htmlspecialchars_decode(cmp_get_option('password_url')) ;
    }else{
      $password_url = home_url().'/wp-login.php?action=lostpassword';
    }
    if(cmp_get_option('register_url')){
      $register_url = htmlspecialchars_decode(cmp_get_option('register_url')) ;
    }else{
      $register_url = home_url().'/wp-login.php?action=register';
    }
    if( !is_user_logged_in() ) { ?>
    <a class="btn btn-arrow btn-popupmenu" href="javascript:;"><?php _e('Log in','cmp') ?><i class="arrow"></i></a>
    <div class="popup-layer">
      <div class="popup">
        <div class="popup-inner">
          <form class="popup-signin" name="loginform" action="<?php echo wp_login_url($url_this); ?>" method="post">
            <input class="ipt" placeholder="<?php _e('Username','cmp') ?>" type="text" name="log" value="" size="20">
            <input class="ipt" placeholder="<?php _e('Password','cmp') ?>" type="password" name="pwd" value="" size="20">
            <input name="rememberme" id="rememberme" type="checkbox" checked="checked" value="forever" /> <?php _e('Remember Me','cmp') ?>
            <input class="btn btn-primary submit" type="submit" name="submit" value="<?php _e('Login','cmp'); ?>">
          </form>
          <p>
            <?php if(get_option('users_can_register') == '1' ) :?>
              <a rel="nofollow" href="<?php echo $register_url; ?>"><i class="fa fa-sign-in"></i><?php _e('Register','cmp') ?></a>|
            <?php endif; ?>
            <a rel="nofollow" href="<?php echo $password_url; ?>"><i class="fa fa-unlock-alt"></i><?php _e('Lost your password?','cmp') ?></a>
          </p>
        </div>
      </div>
    </div>
    <?php } else{ ?>
    <a class="btn btn-arrow btn-image btn-popupmenu" href="javascript:;">
      <img class="avatar" src="<?php echo get_avatar_url($current_user->user_email,array('size'=>'23')); ?>" alt="<?php echo $u_name ?>" width="23" height="23" /><?php echo $u_name ?><i class="arrow"></i>
    </a>
    <div class="popup-layer">
      <div class="popup">
        <div class="popup-inner">
          <ul class="popup-user-menu">
            <?php
            if(has_nav_menu('user-menu')){
              wp_nav_menu(array('container' => false, 'items_wrap' => '%3$s', 'theme_location' => 'user-menu', 'fallback_cb' => '','walker' => new wp_bootstrap_navwalker()));
            }else{
              ?>
              <li><a href="<?php echo get_home_url(); ?>/wp-admin/index.php" rel="nofollow"><i class="fa fa-tachometer"></i><?php _e('Dashboard','cmp') ?></a></li>
              <li><a href="<?php echo get_home_url(); ?>/wp-admin/post-new.php" rel="nofollow"><i class="fa fa-pencil-square-o"></i><?php _e('New Post','cmp') ?></a></li>
              <li><a href="<?php echo get_home_url(); ?>/wp-admin/post-new.php?post_type=page" rel="nofollow"><i class="fa fa-file-text"></i><?php _e('New Page','cmp') ?></a></li>
              <li><a href="<?php echo get_home_url(); ?>/wp-admin/edit-comments.php" rel="nofollow"><i class="fa fa-comments-o"></i><?php _e('Edit Comments','cmp') ?></a></li>
              <li><a href="<?php echo get_home_url(); ?>/wp-admin/profile.php" rel="nofollow"><i class="fa fa-cog"></i><?php _e('Edit Profile','cmp') ?></a></li>
              <?php } ?>
              <li class="log-out"><a href="<?php echo wp_logout_url($url_this); ?>" rel="nofollow"><i class="fa fa-sign-out"></i><?php _e('Log out','cmp') ?></a></li>
            </ul>
            <div class="clear"></div>
          </div>
        </div>
      </div>
      <?php } ?>
    </div>
  <?php endif; ?>
</div>