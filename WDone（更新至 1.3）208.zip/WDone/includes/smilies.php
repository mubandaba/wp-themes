<div id="smilies">
  <?php if(cmp_get_option( 'lazyload' )): ?>
    <a href="javascript:grin(':arrow:')"><img class="lazy" src="<?php echo get_template_directory_uri(); ?>/images/grey.gif" data-original="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_arrow.gif" alt="arrow" /></a>
    <a href="javascript:grin(':grin:')"><img class="lazy" src="<?php echo get_template_directory_uri(); ?>/images/grey.gif" data-original="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_biggrin.gif" alt="grin" /></a>
    <a href="javascript:grin(':!:')"><img class="lazy" src="<?php echo get_template_directory_uri(); ?>/images/grey.gif" data-original="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_exclaim.gif" alt="!" /></a>
    <a href="javascript:grin(':?:')"><img class="lazy" src="<?php echo get_template_directory_uri(); ?>/images/grey.gif" data-original="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_question.gif" alt="?" /></a>
    <a href="javascript:grin(':cool:')"><img class="lazy" src="<?php echo get_template_directory_uri(); ?>/images/grey.gif" data-original="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_cool.gif" alt="cool" /></a>
    <a href="javascript:grin(':roll:')"><img class="lazy" src="<?php echo get_template_directory_uri(); ?>/images/grey.gif" data-original="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_rolleyes.gif" alt="roll" /></a>
    <a href="javascript:grin(':eek:')"><img class="lazy" src="<?php echo get_template_directory_uri(); ?>/images/grey.gif" data-original="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_eek.gif" alt="eek" /></a>
    <a href="javascript:grin(':evil:')"><img class="lazy" src="<?php echo get_template_directory_uri(); ?>/images/grey.gif" data-original="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_evil.gif" alt="evil" /></a>
    <a href="javascript:grin(':razz:')"><img class="lazy" src="<?php echo get_template_directory_uri(); ?>/images/grey.gif" data-original="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_razz.gif" alt="razz" /></a>
    <a href="javascript:grin(':mrgreen:')"><img class="lazy" src="<?php echo get_template_directory_uri(); ?>/images/grey.gif" data-original="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_mrgreen.gif" alt="mrgreen" /></a>
    <a href="javascript:grin(':smile:')"><img class="lazy" src="<?php echo get_template_directory_uri(); ?>/images/grey.gif" data-original="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_smile.gif" alt="smile" /></a>
    <a href="javascript:grin(':oops:')"><img class="lazy" src="<?php echo get_template_directory_uri(); ?>/images/grey.gif" data-original="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_redface.gif" alt="oops" /></a>
    <a href="javascript:grin(':lol:')"><img class="lazy" src="<?php echo get_template_directory_uri(); ?>/images/grey.gif" data-original="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_lol.gif" alt="lol" /></a>
    <a href="javascript:grin(':mad:')"><img class="lazy" src="<?php echo get_template_directory_uri(); ?>/images/grey.gif" data-original="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_mad.gif" alt="mad" /></a>
    <a href="javascript:grin(':twisted:')"><img class="lazy" src="<?php echo get_template_directory_uri(); ?>/images/grey.gif" data-original="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_twisted.gif" alt="twisted" /></a>
    <a href="javascript:grin(':wink:')"><img class="lazy" src="<?php echo get_template_directory_uri(); ?>/images/grey.gif" data-original="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_wink.gif" alt="wink" /></a>
    <a href="javascript:grin(':idea:')"><img class="lazy" src="<?php echo get_template_directory_uri(); ?>/images/grey.gif" data-original="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_idea.gif" alt="idea" /></a>
    <a href="javascript:grin(':cry:')"><img class="lazy" src="<?php echo get_template_directory_uri(); ?>/images/grey.gif" data-original="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_cry.gif" alt="cry" /></a>
    <a href="javascript:grin(':shock:')"><img class="lazy" src="<?php echo get_template_directory_uri(); ?>/images/grey.gif" data-original="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_surprised.gif" alt="shock" /></a>
    <a href="javascript:grin(':neutral:')"><img class="lazy" src="<?php echo get_template_directory_uri(); ?>/images/grey.gif" data-original="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_neutral.gif" alt="neutral" /></a>
    <a href="javascript:grin(':sad:')"><img class="lazy" src="<?php echo get_template_directory_uri(); ?>/images/grey.gif" data-original="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_sad.gif" alt="sad" /></a>
    <a href="javascript:grin(':???:')"><img class="lazy" src="<?php echo get_template_directory_uri(); ?>/images/grey.gif" data-original="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_confused.gif" alt="???" /></a>
  <?php else : ?>
    <a href="javascript:grin(':arrow:')"><img src="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_arrow.gif" alt="arrow" /></a>
    <a href="javascript:grin(':grin:')"><img src="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_biggrin.gif" alt="grin" /></a>
    <a href="javascript:grin(':!:')"><img src="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_exclaim.gif" alt="!" /></a>
    <a href="javascript:grin(':?:')"><img src="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_question.gif" alt="?" /></a>
    <a href="javascript:grin(':cool:')"><img src="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_cool.gif" alt="cool" /></a>
    <a href="javascript:grin(':roll:')"><img src="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_rolleyes.gif" alt="roll" /></a>
    <a href="javascript:grin(':eek:')"><img src="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_eek.gif" alt="eek" /></a>
    <a href="javascript:grin(':evil:')"><img src="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_evil.gif" alt="evil" /></a>
    <a href="javascript:grin(':razz:')"><img src="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_razz.gif" alt="razz" /></a>
    <a href="javascript:grin(':mrgreen:')"><img src="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_mrgreen.gif" alt="mrgreen" /></a>
    <a href="javascript:grin(':smile:')"><img src="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_smile.gif" alt="smile" /></a>
    <a href="javascript:grin(':oops:')"><img src="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_redface.gif" alt="oops" /></a>
    <a href="javascript:grin(':lol:')"><img src="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_lol.gif" alt="lol" /></a>
    <a href="javascript:grin(':mad:')"><img src="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_mad.gif" alt="mad" /></a>
    <a href="javascript:grin(':twisted:')"><img src="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_twisted.gif" alt="twisted" /></a>
    <a href="javascript:grin(':wink:')"><img src="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_wink.gif" alt="wink" /></a>
    <a href="javascript:grin(':idea:')"><img src="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_idea.gif" alt="idea" /></a>
    <a href="javascript:grin(':cry:')"><img src="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_cry.gif" alt="cry" /></a>
    <a href="javascript:grin(':shock:')"><img src="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_surprised.gif" alt="shock" /></a>
    <a href="javascript:grin(':neutral:')"><img src="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_neutral.gif" alt="neutral" /></a>
    <a href="javascript:grin(':sad:')"><img src="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_sad.gif" alt="sad" /></a>
    <a href="javascript:grin(':???:')"><img src="<?php echo get_template_directory_uri(); ?>/images/smilies/icon_confused.gif" alt="???" /></a>
  <?php endif; ?>
</div>