<div class="clear"></div>
<div class="bdsharebuttonbox post-share" data-tag="share_2">
<a href="#" class="bds_qzone" data-cmd="qzone" title="<?php _e('Share to Qzone','cmp'); ?>"></a>
<a href="#" class="bds_tsina" data-cmd="tsina" title="<?php _e('Share to Sina Weibo','cmp'); ?>"></a>
<a href="#" class="bds_tqq" data-cmd="tqq" title="<?php _e('Share to QQ Weibo','cmp'); ?>"></a>
<a href="#" class="bds_renren" data-cmd="renren" title="<?php _e('Share to Renren','cmp'); ?>"></a>
<a href="#" class="bds_weixin" data-cmd="weixin" title="<?php _e('Share to Weixin','cmp'); ?>"></a>
<a href="#" class="bds_more" data-cmd="more"></a>
<a class="bds_count" data-cmd="count"></a>
</div>