<?php
global $get_meta , $post;
if( ( cmp_get_option('related') && empty( $get_meta["cmp_hide_related"][0] ) ) || ( isset( $get_meta["cmp_hide_related"][0] ) && $get_meta["cmp_hide_related"][0] == 'no' ) ):
  $related_no = cmp_get_option('related_number') ? cmp_get_option('related_number') : 4;
global $post;
$orig_post = $post;
$query_type = cmp_get_option('related_query') ;
if( $query_type == 'author' ){
	$args=array('post__not_in' => array($post->ID),'ignore_sticky_posts' => 1,'posts_per_page'=> $related_no , 'author'=> get_the_author_meta( 'ID' ),'no_found_rows' => 1);
}elseif( $query_type == 'tag' ){
  $tags = wp_get_post_tags($post->ID);
  $tags_ids = array();
  foreach($tags as $individual_tag) $tags_ids[] = $individual_tag->term_id;
	$args=array('post__not_in' => array($post->ID),'ignore_sticky_posts' => 1,'posts_per_page'=> $related_no , 'tag__in'=> $tags_ids ,'no_found_rows' => 1);
}
else{
  $categories = get_the_category($post->ID);
  $category_ids = array();
  foreach($categories as $individual_category) $category_ids[] = $individual_category->term_id;
	$args=array('post__not_in' => array($post->ID),'posts_per_page'=> $related_no , 'category__in'=> $category_ids ,'no_found_rows' => 1);
}
$related_query = new wp_query( $args );
if( !$related_query->have_posts() ){ ?>
<div id="related-posts">
  <h3 class="box-title"><span><?php _e( 'Random Articles' , 'cmp' ); ?></span></h3>
  <div class="post-list group">
    <?php
    $args = array('post__not_in' => array($post->ID),'ignore_sticky_posts' => 1,'posts_per_page'=> $related_no ,'orderby' => 'rand','no_found_rows' => 1);
    query_posts($args);$i=1;
    while( have_posts() ) : the_post(); ?>
    <article id="post-<?php the_ID(); ?>" <?php if($i % 2 == 0) post_class('small-thumb group even');else post_class('small-thumb group');?> >
      <div class="post-inner post-hover">
        <div class="post-thumbnail">
          <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>>
            <?php cmp_post_thumbnail(150,90); ?>
          </a>
        </div><!--/.post-thumbnail-->
        <h3 class="post-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><?php the_title(); ?></a></h3>
        <div class="post-meta">
          <?php if(function_exists('cmp_get_time')): ?>
            <span><i class="fa fa-clock-o"></i><?php cmp_get_time();?></span>
          <?php endif; ?>
          <?php if(function_exists('the_views')): ?>
            <span><i class="fa fa-eye"></i><?php the_views(); ?></span>
          <?php endif; ?>
          <span><i class="fa fa-comments-o"></i><?php comments_popup_link('0','1','%' ); ?></span>
        </div>
        <div class="clear"></div>
      </div>
    </article>
    <?php $i++; endwhile; wp_reset_query();
  }elseif( $related_query->have_posts() ) { $i=1;?>
  <div id="related-posts">
    <h3 class="box-title"><span><?php _e( 'Related Articles' , 'cmp' ); ?></span></h3>
    <div class="post-list group">
      <?php while ( $related_query->have_posts() ) : $related_query->the_post()?>
        <article id="post-<?php the_ID(); ?>" <?php if($i % 2 == 0) post_class('small-thumb group even');else post_class('small-thumb group');?> >
          <div class="post-inner post-hover">
            <div class="post-thumbnail">
              <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" <?php echo cmp_target_blank();?>>
                <?php cmp_post_thumbnail(150,90); ?>
              </a>
            </div><!--/.post-thumbnail-->
            <h3 class="post-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><?php the_title(); ?></a></h3>
            <div class="post-meta">
              <?php if(function_exists('cmp_get_time')): ?>
                <span><i class="fa fa-clock-o"></i><?php cmp_get_time();?></span>
              <?php endif; ?>
              <?php if(function_exists('the_views')): ?>
                <span><i class="fa fa-eye"></i><?php the_views(); ?></span>
              <?php endif; ?>
              <span><i class="fa fa-comments-o"></i><?php comments_popup_link('0','1','%' ); ?></span>
            </div>
            <div class="clear"></div>
          </div>
        </article>
        <?php $i++; endwhile;?>
        <?php }
        $post = $orig_post;
        wp_reset_query();?>
        <div class="clear"></div>
      </div>
    </div>
  <?php endif; ?>