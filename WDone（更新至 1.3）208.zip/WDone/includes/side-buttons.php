<div class="side-buttons" id="side-buttons">
    <?php if( cmp_get_option('button_guestbook')): ?>
        <div class="side-buttons-box relative sb-comment ">
            <a href="<?php echo cmp_get_option('guestbook_url'); ?>" rel="nofollow" <?php if(cmp_get_option('guestbook_tab')) echo 'target="_blank"'; ?>><i class="sb-icon fa fa-comments-o" title="<?php _e('mess- age','cmp'); ?>"></i></a>
        </div>
    <?php endif; ?>
    <?php if( cmp_get_option('button_bookmark')): ?>
        <div class="side-buttons-box relative sb-bookmark">
            <a href="javascript:;" id="bookmark"><i class="sb-icon fa fa-star-o" title="<?php _e('book mark','cmp'); ?>"></i></a>
        </div>
    <?php endif; ?>
    <?php if( cmp_get_option('button_share')): ?>
        <div class="side-buttons-box relative sb-share">
            <a href="#"><i class="sb-icon fa fa-share-square-o" title="<?php _e('share this','cmp'); ?>"></i></a>
            <div class="side-buttons-triangle">
                <em class="border-sj">&#9670;</em>
                <span class="con-sj">&#9670;</span>
            </div>
            <div class="sb-layer bdsharebuttonbox" data-tag="share_1">
                <a href="#" class="bds_mshare" data-cmd="mshare" title="<?php _e('one key share','cmp'); ?>"><?php _e('one key share','cmp'); ?></a>
                <a href="#" class="bds_tsina" data-cmd="tsina" title="<?php _e('share to sina weibo','cmp'); ?>"><?php _e('sina weibo','cmp'); ?></a>
                <a href="#" class="bds_tqq" data-cmd="tqq" title="<?php _e('share to tencent weibo','cmp'); ?>"><?php _e('tencent weibo','cmp'); ?></a>
                <a href="#" class="bds_renren" data-cmd="renren" title="<?php _e('share to renren','cmp'); ?>"><?php _e('renren','cmp'); ?></a>
                <a href="#" class="bds_weixin" data-cmd="weixin" title="<?php _e('share to weixin','cmp'); ?>"><?php _e('weixin','cmp'); ?></a>
                <a href="#" class="bds_qzone" data-cmd="qzone" title="<?php _e('share to qzone','cmp'); ?>"><?php _e('qzone','cmp'); ?></a>
                <a href="#" class="bds_douban" data-cmd="douban" title="<?php _e('share to douban','cmp'); ?>"><?php _e('douban','cmp'); ?></a>
                <a href="#" class="bds_twi" data-cmd="twi" title="<?php _e('share to twitter','cmp'); ?>"><?php _e('twitters','cmp'); ?></a>
                <a href="#" class="bds_fbook" data-cmd="fbook" title="<?php _e('share to facebook','cmp'); ?>"><?php _e('facebook','cmp'); ?></a>
            </div>
        </div>
    <?php endif; ?>
    <?php if( cmp_get_option('button_qr')): ?>
        <div class="side-buttons-box relative sb-qr">
            <a href="#"><i class="sb-icon fa fa-qrcode" title="<?php _e('qr code','cmp'); ?>"></i></a>
            <div class="side-buttons-triangle">
                <em class="border-sj">&#9670;</em>
                <span class="con-sj">&#9670;</span>
            </div>
            <div class="sb-layer">
                <p class="qr-img"><img alt="<?php echo htmlspecialchars_decode(cmp_get_option('qr_tips')); ?>" src="<?php echo cmp_get_option('qr_img');?>" width="200"></p>
                <p class="qr-text"><?php echo htmlspecialchars_decode(cmp_get_option('qr_tips')); ?></p>
            </div>
        </div>
    <?php endif; ?>
    <?php if( cmp_get_option('button_top')): ?>
        <div class="side-buttons-box relative sb-top">
            <a href="#"><i class="sb-icon fa fa-chevron-up" title="<?php _e('return top','cmp'); ?>"></i></a>
        </div>
        <?php if( !cmp_get_option('share_post')): ?>
            <script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"0","bdSize":"16"},"share":{"tag" : "share_1","bdSize":"16"}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script>
        <?php endif; ?>
    <?php endif; ?>
</div>