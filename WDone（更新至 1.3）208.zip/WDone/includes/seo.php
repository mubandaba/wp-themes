<?php
if( is_single() || is_page() ) {
    if( function_exists('get_query_var') ) {
        $cpage = intval(get_query_var('cpage'));
        $commentPage = intval(get_query_var('comment-page'));
    }
    if( !empty($cpage) || !empty($commentPage) ) {
        echo '<meta name="robots" content="noindex, nofollow" />';
        echo "\n";
    }
}
//title
$title = '';
global $page, $paged;
$separator = cmp_get_option('separator')?cmp_get_option('separator'):' | ';
$site_description = get_bloginfo( 'description', 'display' );
if ( is_home() || is_front_page() ) {
    if(cmp_get_option('homepage_title')){
        $title = cmp_get_option('homepage_title');
    }else{
        $title = get_bloginfo('name');
        if ($site_description) $title = $title.$separator.$site_description;
    }
    if ( $paged >= 2 || $page >= 2 ){
        $title = $title. ' - ' . sprintf( __( 'Page %s', 'cmp' ), max( $paged, $page ) );
    }
} else{
    if(is_single() || is_page()) {
        if(get_post_meta($post->ID, "_cmp_seo_title", true)){
            $title = strip_tags(trim(get_post_meta($post->ID, "_cmp_seo_title", true)));
        }else{
            $title = trim(wp_title('',0));
        }
    }elseif (is_category()) {
        if(get_option('cm_tax_title' . get_query_var('cat'))){
            $title = strip_tags(trim(get_option('cm_tax_title' . get_query_var('cat'))));
        }else{
            $title = trim(wp_title('',0));
        }
    }elseif (is_tax()) {
        $current_term = get_term_by('slug', get_query_var('term'), get_query_var('taxonomy'));
        if(get_option('cm_tax_title' . $current_term->term_id)){
            $title = strip_tags(trim(get_option('cm_tax_title' .$current_term->term_id)));
        }else{
            $title = trim(wp_title('',0));
        }
    }else{
        $title = trim(wp_title('',0));
    }
    if ( $paged >= 2 || $page >= 2 ){
        $title = $title.' - ' . sprintf( __( 'Page %s', 'cmp' ), max( $paged, $page ) );
    }
    if(cmp_get_option('title_suffix')){
        $title = $title. $separator.get_bloginfo('name');
    }
}
//description & keywords
$description ='';
$keywords ='';
if (is_home() || is_front_page())
{
    $description = strip_tags(trim(cmp_get_option('homepage_description')));
    $keywords = cmp_get_option('homepage_keywords');
}
elseif (is_category() )
{
    if(get_option('cm_tax_keywords' . get_query_var('cat'))){
        $keywords = strip_tags(trim(get_option('cm_tax_keywords' . get_query_var('cat'))));
    }else{
        $keywords = single_cat_title('', false);
    }
    $description = strip_tags(trim(wp_trim_words(category_description(),130,"") ));
}
elseif (is_tax())
{
    $current_term = get_term_by('slug', get_query_var('term'), get_query_var('taxonomy'));
    if(get_option('cm_tax_keywords' . $current_term->term_id)){
        $keywords = strip_tags(trim(get_option('cm_tax_keywords' . $current_term->term_id)));
    }else{
        $keywords = single_cat_title('', false);
    }
    $description = strip_tags(trim(wp_trim_words(category_description(),130,"") ));
}
elseif (is_tag())
{
    $description = strip_tags(trim(sprintf( __( 'The following articles associated with the tag: %s', 'cmp' ), single_tag_title('', false)) ));
    $keywords = single_tag_title('', false);
}
elseif (is_single())
{
    if(get_post_meta($post->ID, "_cmp_seo_description", true)) {
        $description = strip_tags(trim(get_post_meta($post->ID, "_cmp_seo_description", true)));
    } elseif ($post->post_excerpt) {
        $description = strip_tags(trim($post->post_excerpt));
    } else {
        $description = strip_tags(trim(wp_trim_words($post->post_content, 130,"") ));
    };
    if(get_post_meta($post->ID, "_cmp_seo_keywords", true)) {
        $keywords = strip_tags(trim(get_post_meta($post->ID, "_cmp_seo_keywords", true)));
    } else{
        $tags = wp_get_post_tags($post->ID);
        if(function_exists('dwqa_plugin_init') && 'dwqa-question' == get_post_type()){
            $tags = wp_get_object_terms( $post->ID,  'dwqa-question_tag' );
        }
        if(!empty($tags) && !is_wp_error( $tags ) ){
            foreach ($tags as $tag ) {
                $keyword = $keyword . $tag->name . ",";
                $keywords =  trim($keyword,',');
            }
        }
    }
}
elseif (is_page())
{
    if(get_post_meta($post->ID, "_cmp_seo_description", true)) {
        $description = strip_tags(trim(get_post_meta($post->ID, "_cmp_seo_description", true)));
    } else {
        $description = strip_tags(trim(wp_trim_words($post->post_content, 130,"") ));
    };
    if(get_post_meta($post->ID, "_cmp_seo_keywords", true)) {
        $keywords = strip_tags(trim(get_post_meta($post->ID, "_cmp_seo_keywords", true)));
    } else{
        $keywords = single_post_title('', false);
    }
}
elseif( is_search() )
{
    $keywords = strip_tags(get_search_query());
    $description = sprintf( __( 'Posts of search results for: %s', 'cmp' ), get_search_query() );
}
elseif( is_author() )
{
    $userdata = get_user_by( 'slug', get_query_var( 'author_name' ) );
    $keywords = strip_tags($userdata->display_name);
    $description = sprintf( __( 'Posts of author: %s', 'cmp' ),  $userdata->display_name ).'('.strip_tags(trim($userdata->description)).')';
}
//description paged
$desc_page = '';
if ( $paged >= 2 || $page >= 2 ){
    $dPage = sprintf( __( 'Page %s:', 'cmp' ), max( $paged, $page ) );
    $desc_page = $dPage;
}
$description = $desc_page.$description;
?>
<title><?php echo $title; ?></title>
<meta name="keywords" content="<?php echo $keywords; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
