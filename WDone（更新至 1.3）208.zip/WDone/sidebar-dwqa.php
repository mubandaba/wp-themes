<aside class="sidebar side-right <?php if(cmp_get_option( 'hide_sidebar' )) echo 'hide-sidebar'; ?>" role="complementary" itemscope itemtype="http://schema.org/WPSideBar">
  <a class="sidebar-toggle" title="<?php _e('Expand the sidebar','cmp'); ?>"><i class="fa icon-sidebar-toggle"></i></a>
  <div class="sidebar-content">
    <?php
    wp_reset_query();
    if (function_exists('dynamic_sidebar') && dynamic_sidebar('dwqa-widget-area')){

    } else {
        echo '<div class="the_tips">'.__('Please go to "<a target="_blank" href="/wp-admin/widgets.php"> Appearance > Widgets </a>" to set "DWQA Widget Area".','cmp').'</div>';
    }
    ?>
  </div>
</aside>