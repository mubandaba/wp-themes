<?php get_header(); ?>
<section class="content">
  <div class="page-title">
    <h1 itemprop="headline">
      <?php echo __('Archive: ','cmp') .trim(wp_title('',0)); ?>
    </h1>
  </div><!--/.page-title-->
  <?php cmp_breadcrumbs();?>
  <div class="clear"></div>
  <?php
  if(cmp_get_option( 'category_desc' ) ){
    $category_description = category_description();
    if(!empty( $category_description ) && !is_paged() )
      echo '<div class="notebox">' . $category_description . '</div>';
  }
  ?>
  <div class="pad group">
    <?php
    query_posts($query_string . "&posts_per_page=".cmp_get_option('default_number'));
    get_template_part( 'loop', 'category' );  ?>
  </div>
</section>
<?php get_sidebar(); ?>
<?php get_footer(); ?>