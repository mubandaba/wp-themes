<?php get_header(); ?>
<section class="content">
  <div class="pad group <?php if( cmp_get_option('on_home') == 'boxes' ) echo 'home-cms'; ?>">
    <?php
    if( is_home() && !is_paged() && cmp_get_option('slider') && cmp_get_option('slider_position') == 'left' ) get_template_part('includes/slider' );
    if( cmp_get_option('on_home') != 'boxes' ){
      $do_not_duplicate = explode(',',cmp_get_option( 'exclude_posts' ));
      $posts_per_page = (cmp_get_option( 'blog_posts_number' )) ? cmp_get_option( 'blog_posts_number' ) : 10;
      if(cmp_get_option( 'ignore_sticky' )) {
        $args = array('ignore_sticky_posts' => 1,'post__not_in' =>$do_not_duplicate,'cat' => cmp_get_option( 'exclude_categories' ),'paged' => $paged,'posts_per_page' => $posts_per_page ); query_posts($args);
      } else {
        $args = array('post__not_in' =>$do_not_duplicate,'cat' => cmp_get_option( 'exclude_categories' ),'paged' => $paged,'posts_per_page' => $posts_per_page ); query_posts($args);
      }
      get_template_part( 'loop', 'blog' );
    }else{
      $cats = get_option( 'cmp_home_cats' ) ;
      if($cats)
        foreach ($cats as $cat) cmp_get_home_cats($cat);
      else _e( 'You can use Homepage builder to build your homepage' , 'cmp' );
    }
    ?>
  </div><!--/.pad-->
</section><!--/.content-->
<?php get_sidebar(); ?>
<?php get_footer(); ?>