jQuery(document).ready(function($) {
/*  popup-layer
/* ------------------------------------ */
$(document).click(function() {
  $('.popup-layer,.popup-arrow').hide();
  $('.btn-popupmenu').removeClass('btn-active');
})
$('.btn-popupmenu,.popup-layer,.popup-arrow').click(function(event) {
  event.stopPropagation();
})
$('.btn-popupmenu').each(function() {
  $(this).click(function() {
     $(this).toggleClass('btn-active');
     $(this).next().toggle();
     $(this).next().next().toggle();
     $(this).parent().siblings().find('.popup-layer,.popup-arrow').hide();
 })
})
/*  Toggle header search
/* ------------------------------------ */
$(document).click(function (event) {
    $('.search-expand').hide();
    $('.toggle-search').removeClass('active');
});
$('.toggle-search ,.search-expand').click(function(event) {
    event.stopPropagation();
});
$('.toggle-search').click(function(){
    $('.toggle-search').toggleClass('active');
    $('.search-expand').fadeToggle(250);
    setTimeout(function(){
        $('.search-expand input').focus();
    }, 300);
});
/*  fiexd menu
/* ------------------------------------ */
if($(".nav-header").length>0){
    var navTop = $('.nav-header').offset().top;
    $(window).scroll(function(){
        if ($(window).scrollTop() > navTop && $(window).width() > 719) {
            $('.nav-header').addClass('fixed');
        } else {
            $('.nav-header').removeClass('fixed');
        }
    });
}
/*  Comments / pingbacks tabs
/* ------------------------------------ */
$(".comment-tabs li").click(function() {
    $(".comment-tabs li").removeClass('active');
    $(this).addClass("active");
    $(".comment-tab").hide();
    var selected_tab = $(this).find("a").attr("href");
    $(selected_tab).fadeIn();
    return false;
});
/*  Table odd row class
/* ------------------------------------ */
$('table tr:odd').addClass('alt');
/*  Sidebar collapse
/* ------------------------------------ */
$('body').addClass('side-right-collapse');
$('.side-right .sidebar-toggle').click(function(){
  $('body').toggleClass('side-right-collapse').toggleClass('side-right-expand');
});
/*  Dropdown menu animation
/* ------------------------------------ */
$('.nav ul.sub-menu').hide();
$('.nav li').hover(
  function() {
     $(this).children('ul.sub-menu').slideDown('fast');
 },
 function() {
     $(this).children('ul.sub-menu').hide();
 }
 );
/*  Mobile menu smooth toggle height
/* ------------------------------------ */
$('.nav-toggle').on('click', function() {
  slide($('.nav-wrap .nav', $(this).parent()));
});
function slide(content) {
  var wrapper = content.parent();
  var contentHeight = content.outerHeight(true);
  var wrapperHeight = wrapper.height();
  wrapper.toggleClass('expand');
  if (wrapper.hasClass('expand')) {
      setTimeout(function() {
         wrapper.addClass('transition').css('height', contentHeight);
     }, 10);
  }
  else {
      setTimeout(function() {
         wrapper.css('height', wrapperHeight);
         setTimeout(function() {
             wrapper.addClass('transition').css('height', 0);
         }, 10);
     }, 10);
  }
  wrapper.one('transitionEnd webkitTransitionEnd transitionend oTransitionEnd msTransitionEnd', function() {
      if(wrapper.hasClass('open')) {
         wrapper.removeClass('transition').css('height', 'auto');
     }
 });
}
});