jQuery(document).ready(function($) {
	$(document).ajaxStop(function(){
		$("img.lazy, .entry img, img.avatar").show().lazyload({
			effect: "fadeIn",
			failure_limit : 50,
			threshold : 200
		});
	});
});