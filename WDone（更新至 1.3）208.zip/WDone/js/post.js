jQuery(document).ready(function($) {
	if ($.browser.msie && ($.browser.version == 6.0) && !$.support.style) {
		var ie_6 = '';
	} else if ($('.sidebar .widget').length > 0 && $(window).width() > 960) {
		var rightWidth = 330;
		var rightRollbox = $('.sidebar .widget'),
		rightRolllen = rightRollbox.length;
		if (0 < right_1 <= rightRolllen && 0 < right_2 <= rightRolllen) {
			$(window).scroll(function() {
				var roll = document.documentElement.scrollTop + document.body.scrollTop;
				if (roll > rightRollbox.eq(rightRolllen - 1).offset().top + rightRollbox.eq(rightRolllen - 1).height()) {
					if ($('.rightRoller').length == 0) {
						rightRollbox.parent().append('<div class="rightRoller"></div>');
						rightRollbox.eq(right_1 - 1).clone().appendTo('.rightRoller');
						if (right_1 !== right_2)
						 rightRollbox.eq(right_2 - 1).clone().appendTo('.rightRoller')
						 $('.rightRoller').css({
							position: 'fixed',
							top: 60,
							zIndex: 0
						});
						$('.rightRoller').width(rightWidth);
					} else {
						$('.rightRoller').fadeIn(300);
					}
				} else {
					$('.rightRoller').hide();
				}
			})
		};
	}
});