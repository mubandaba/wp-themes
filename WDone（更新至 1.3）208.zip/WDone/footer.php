          </div><!--/.main-inner-->
        </div><!--/.main-->
        <?php get_template_part('includes/ad-bottom' );?>
      </div><!--/.container-inner-->
    </div><!--/.container-->
    <footer id="footer">
      <nav class="nav-container group" id="nav-footer">
        <div class="nav-toggle"><i class="fa fa-bars"></i></div>
        <div class="nav-text"><!-- put your mobile menu text here --></div>
        <div class="nav-wrap">
          <ul id="menu-footer" class="nav container group">
            <?php if(function_exists('wp_nav_menu')) wp_nav_menu(array('container' => false, 'items_wrap' => '%3$s','theme_location' => 'foot-menu', 'fallback_cb' => '','walker' => new wp_bootstrap_navwalker() )) ; ?>
          </ul>
        </div>
      </nav><!--/#nav-footer-->
      <section class="container" id="footer-bottom">
        <div class="container-inner">
          <div class="pad group">
            <div id="copyright">
              <?php echo htmlspecialchars_decode(cmp_get_option('footer_code')); ?>
            </div><!--/#copyright-->
          </div><!--/.pad-->
        </div><!--/.container-inner-->
      </section><!--/.container-->
    </footer><!--/#footer-->
  </div><!--/#wrapper-->
  <?php wp_footer(); ?>
  <?php if(cmp_get_option('side_buttons')) get_template_part('includes/side-buttons' ); ?>
</body>
</html>