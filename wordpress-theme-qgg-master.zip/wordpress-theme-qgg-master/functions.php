<?php
// Require theme functions
require get_template_directory() . '/functions/index.php';

// Customize your functions
