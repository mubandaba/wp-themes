<?php
/**
 * @name 文章评分提交
 * @description 创建并更新 scores 文章 Meta 信息
 * 功能待完善
 */
?>

<?php
// 加载 wp-load.php 文件
require dirname(__FILE__).'/../../../../wp-load.php';
