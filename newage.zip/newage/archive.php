<?php get_header(); ?>

<div id="content">

<section id="post-entry">

<?php $postcounter = 0; if ( have_posts() ) : ?>
<?php while ( have_posts() ) : $postcounter = $postcounter + 1; the_post(); ?>

<article id="post-<?php the_ID(); ?>" <?php post_class('post-home'); ?>>
<?php get_template_part( 'lib/templates/post-image' ); ?>
<header class="entry-title"><h2><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2></header>
<?php get_template_part( 'lib/templates/post-meta' ); ?>
<div class="post-content"><?php echo custom_excerpt(50); ?></div>
</article><!-- POST <?php the_ID(); ?> END -->

<?php
$get_ads_code_one = get_theme_option('ads_loop_one');
$get_ads_code_two = get_theme_option('ads_loop_two');
if( 2 == $postcounter ){ ?>
<?php if($get_ads_code_one) { echo '<div class="adsense-post">'. stripcslashes(do_shortcode($get_ads_code_one)) . '</div>'; } ?>
<?php } elseif( 4 == $postcounter ){ ?>
<?php if($get_ads_code_two) { echo '<div class="adsense-post">'. stripcslashes(do_shortcode($get_ads_code_two)) . '</div>'; } ?>
<?php } ?>

<?php endwhile; ?>
<?php else : ?>

<?php get_template_part( 'lib/templates/404' ); ?>

<?php endif; ?>

<?php get_template_part( 'lib/templates/paginate' ); ?>

<div class="clearfix"></div>
</section><!-- POST ENTRY END -->
</div><!-- CONTENT END -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>