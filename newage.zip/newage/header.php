<!DOCTYPE html>
<!--[if IE 7]><html class="ie ie7" <?php language_attributes(); ?>><![endif]-->
<!--[if IE 8]><html class="ie ie8" <?php language_attributes(); ?>><![endif]-->
<!--[if !(IE 7) | !(IE 8)  ]><!--><html <?php language_attributes(); ?>><!--<![endif]-->
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<?php global $is_IE; if($is_IE): ?><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><?php endif; ?>
<?php if( wp_is_mobile()) { ?><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta name="HandheldFriendly" content="true"><?php } ?>
<title><?php wp_title( '|', true, 'right' ); ?></title>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<link href="<?php echo get_template_directory_uri(); ?>/style.css" rel="stylesheet" type="text/css">
<?php if( get_theme_option('fav_icon') ) { ?><link rel="icon" href="<?php echo get_theme_option('fav_icon'); ?>" type="images/x-icon" /><?php } ?>
<?php wp_head(); ?>
<?php $header_code = get_theme_option('header_code'); echo stripcslashes($header_code); ?>
<!--[if gte IE 9]><style type="text/css">
#main-navigation, .featured-category h3, .widget .widgettitle, #main-footer, ol.commentlist li div.reply a, .form-submit #submit { filter: none; }</style><![endif]-->
</head>

<body id="custom" <?php body_class(); ?>>

<header id="main-header" class="inner" role="banner">
<div id="topheader">
<?php if( get_theme_option('header_logo') ) { ?>
<div id="site-logo"><a href="<?php echo home_url( '/' ); ?>" title="<?php bloginfo('name'); ?>"><img src="<?php echo get_theme_option('header_logo'); ?>" alt="<?php bloginfo('name'); ?>" /></a></div>
<?php } else { ?>
<<?php if( !is_singular()) { echo 'h1'; } else { echo 'div'; } ?> id="site-title"><a href="<?php echo home_url( '/' ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></<?php if( !is_singular()) { echo 'h1'; } else { echo 'div'; } ?>>
<div id="site-description"><?php bloginfo( 'description' ); ?></div>
<?php } ?>
</div><!-- TOPHEADER END -->
<div id="topbanner">
<?php $header_banner = get_theme_option('header_banner'); if($header_banner == '') { ?>
<a target="_blank" rel="nofollow" title="datafeedr" href="http://www.datafeedr.com/affiliates/jrox.php?id=2610_1_tlid_8_wpthemes"><img src="<?php echo get_template_directory_uri(); ?>/images/datafeedr728x90.jpg" alt="build online affiliate store with datafeedr"></a>
<?php } else { ?><?php echo get_theme_option('header_banner'); ?><?php } ?>
</div><!-- TOPBANNER END -->
<div class="clearfix"></div>
</header><!-- MAIN HEADER END -->

<nav id="main-navigation" class="effect gradient" role="navigation">
<?php wp_nav_menu( array( 'theme_location' => 'primary', 'container_class' => 'inner', 'menu_class' => 'sf-menu', 'menu_id' => 'topmenu', 'fallback_cb' => 'revert_wp_menu_page', 'walker' => new Custom_Description_Walker ) ); ?>
<div id="mobile-nav" role="navigation">
<?php get_mobile_navigation( $type='top', $nav_name="primary" ); ?>
</div>
<div class="clearfix"></div>
</nav><!-- MAIN NAVIGATION END -->

<?php if ( get_header_image() ) : ?>
<div id="custom-header" class="inner"><img src="<?php header_image(); ?>" width="<?php echo get_custom_header()->width; ?>" height="<?php echo get_custom_header()->height; ?>" border="0" alt="<?php bloginfo('name'); ?>" /></div><!-- CUSTOM HEADER END -->
<?php endif; ?>

<div id="main-content">
<?php if( !is_home() && !is_404() ) { get_template_part( 'lib/templates/breadcrumbs' ); } ?> 