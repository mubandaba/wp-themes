<?php get_header(); ?>

<div id="content" role="main">

<?php if ( ( is_home() && (is_front_page()) && ($paged < 1)) && get_theme_option('slider_on') == 'Enable') { ?>
<?php get_template_part( 'lib/templates/slider' ); ?> 
<?php } ?>

<section id="post-entry">
<?php $postcounter = 0; if ( have_posts() ) : ?>
<?php while ( have_posts() ) : $postcounter = $postcounter + 1; the_post(); ?>
<article id="post-<?php the_ID(); ?>" <?php post_class('post-home'); ?>>
<?php get_template_part( 'lib/templates/post-image' ); ?>
<header class="entry-title"><h2><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2></header>
<?php get_template_part( 'lib/templates/post-meta' ); ?>
<div class="post-content"><?php if ( is_sticky() && is_home() && ! is_paged() ) : ?><?php the_content(); ?><?php else : ?><?php echo custom_excerpt(50); ?><?php endif; ?></div>
</article><!-- POST <?php the_ID(); ?> END -->

<?php
$get_ads_code_one = get_theme_option('ads_loop_one');
$get_ads_code_two = get_theme_option('ads_loop_two');
if( 2 == $postcounter ){ ?>
<?php if($get_ads_code_one) { echo '<div class="adsense-post">'. stripcslashes(do_shortcode($get_ads_code_one)) . '</div>'; } ?>
<?php } elseif( 4 == $postcounter ){ ?>
<?php if($get_ads_code_two) { echo '<div class="adsense-post">'. stripcslashes(do_shortcode($get_ads_code_two)) . '</div>'; } ?>
<?php } ?>


<?php endwhile; ?>

<?php get_template_part( 'lib/templates/paginate' ); ?>

<?php else : ?>

<?php get_template_part( 'lib/templates/404' ); ?>

<?php endif; ?>

<div class="clearfix"></div>
</section><!-- POST ENTRY END -->

<?php if ( is_home() && is_front_page() && get_theme_option('feat_home_on') == 'Enable') { ?>
<?php get_template_part( 'lib/templates/featured-home' ); ?>
<?php } ?>

</div><!-- CONTENT END -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>