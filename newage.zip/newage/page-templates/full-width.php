<?php
/*
Template Name: Full Width
*/
?>

<?php get_header(); ?>

<div id="full-content">

<section id="post-entry">

<?php $postcounter = 0; if ( have_posts() ) : ?>
<?php while ( have_posts() ) : $postcounter = $postcounter + 1; the_post(); ?>

<article <?php post_class('post-meta'); ?> id="post-<?php the_ID(); ?>">
<header class="entry-header"><h1 class="entry-title"><?php the_title(); ?></h1></header>
<div class="post-content">
<?php the_content( __( 'Continue reading <span class="meta-nav">&rarr;</span>', TEMPLATE_DOMAIN ) ); ?>
<?php wp_link_pages( array( 'before' => '<div class="page-links">' . __( 'Pages:', TEMPLATE_DOMAIN ), 'after' => '</div>' ) ); ?>
</div>
</article><!-- POST <?php the_ID(); ?> END -->

<?php comments_template( '', true ); ?>

<?php endwhile; ?>
<?php else : ?>

<?php get_template_part( 'lib/templates/404' ); ?>

<?php endif; ?>

<?php get_template_part( 'lib/templates/paginate' ); ?>

<div class="clearfix"></div>
</section><!-- POST ENTRY END -->
</div><!-- CONTENT END -->

<?php get_footer(); ?>