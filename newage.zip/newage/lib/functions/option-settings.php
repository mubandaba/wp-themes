<?php
$global_options = array (
/*header setting*/
array(
	"header-title" => __("Header Setting", TEMPLATE_DOMAIN),
	"name" => __("Site Logo", TEMPLATE_DOMAIN),
	"section" => "header",
	"description" => __("Enter your logo url here.", TEMPLATE_DOMAIN),
	"id" => "header_logo",
    "filename" => "header_logo",
	"type" => "text",
	"default" => ""),

array(
	"name" => __("Favourite Icon", TEMPLATE_DOMAIN),
	"description" => __("Enter your fav icon url here.", TEMPLATE_DOMAIN),
    "section" => "header",
    "id" => "fav_icon",
    "filename" => "fav_icon",
	"type" => "text",
	"default" => ""),
	


/* typography setting */
array(
"header-title" => __("Typography Settings", TEMPLATE_DOMAIN),
"name" => __("Body Font", TEMPLATE_DOMAIN),
	"description" => __("Choose a font for the body text.", TEMPLATE_DOMAIN),
    "section" => "typography",
    "id" => "body_font",
	"type" => "select-fonts",
	"default" => ""),

array(
"name" => __("Body Font Weight", TEMPLATE_DOMAIN),
	"description" => "",
    "section" => "typography",
    "id" => "body_font_weight",
	"type" => "select-fonts-weight",
	"default" => ""),

array(
"name" => __("Headline and Title Font", TEMPLATE_DOMAIN),
	"description" => __("Choose a font for the headline text.", TEMPLATE_DOMAIN),
    "section" => "typography",
    "id" => "headline_font",
	"type" => "select-fonts",
	"default" => ""),

array(
"name" => __("Headline Font Weight", TEMPLATE_DOMAIN),
	"description" => "",
    "section" => "typography",
    "id" => "headline_font_weight",
	"type" => "select-fonts-weight",
	"default" => ""),


array(
"name" => __("Navigation Font", TEMPLATE_DOMAIN),
	"description" => __("Choose a font for the navigation text.", TEMPLATE_DOMAIN),
    "section" => "typography",
    "id" => "navigation_font",
	"type" => "select-fonts",
	"default" => ""),
    
array(
"name" => __("Navigation Font Weight", TEMPLATE_DOMAIN),
	"description" => "",
    "section" => "typography",
    "id" => "navigation_font_weight",
	"type" => "select-fonts-weight",
	"default" => ""),


/* design setting */
array(
"header-title" => __("Design Settings", TEMPLATE_DOMAIN),
"name" => __("Main Color", TEMPLATE_DOMAIN),
	"description" => __("Choose main color for your site.", TEMPLATE_DOMAIN),
    "section" => "design",
    "id" => "main_color",
	"type" => "colorpicker",
	"default" => ""),
array(
"name" => __("Sidebar Color", TEMPLATE_DOMAIN),
	"description" => __("Choose background color for your sidebar header.", TEMPLATE_DOMAIN),
    "section" => "design",
    "id" => "sidebar_color",
	"type" => "colorpicker",
	"default" => ""),

/* Slider setting */
array(
	"header-title" => __("Featured Posts Settings", TEMPLATE_DOMAIN),
	"name" => __("Enable Featured posts", TEMPLATE_DOMAIN),
	"description" => __("Choose if you want to enable or disable featured posts.", TEMPLATE_DOMAIN),
    "section" => "slider",
	"id" => "slider_on",
	"type" => "radio-enable-disable",
	"default" => "Disable"),

array(
	"name" => __("Categories ID", TEMPLATE_DOMAIN),
	"description" => __("Add a list of category ids if you want to use category as featured. <em>*leave blank to use bottom post ids featured</em><br /><small>example: 3,4,68</small>", TEMPLATE_DOMAIN),
    "section" => "slider",
	"id" => "feat_cat",
	"type" => "text",
	"default" => ""),

array(
	"name" => __("Limit to how many posts", TEMPLATE_DOMAIN),
	"description" => __("How many posts in categories you listed you want to show?", TEMPLATE_DOMAIN),
    "section" => "slider",
	"id" => "feat_cat_count",
	"type" => "select-count",
	"default" => ""),


array(
	"name" => __("Posts ID", TEMPLATE_DOMAIN),
	"description" => __("Add a list of post ids if you want to use posts as featured. <em>*leave blank to use above category ids featured</em><br /><small>example: 136,928,925,80,77,55,49</small>", TEMPLATE_DOMAIN),
     "section" => "slider",
	"id" => "feat_post",
	"type" => "text",
	"default" => ""),
	

/* Featured Setting */

array(
	"header-title" => __("Featured Settings", TEMPLATE_DOMAIN),
	"name" => __("Enable Featured Home", TEMPLATE_DOMAIN),
	"description" => __("Choose if you want to enable or disable featured category home.", TEMPLATE_DOMAIN),
    "section" => "featured",
	"id" => "feat_home_on",
	"type" => "radio-enable-disable",
	"default" => "Disable"),

array(
	"name" => __("Featured Home Category 1", TEMPLATE_DOMAIN),
	"description" => __("Choose which category to featured.", TEMPLATE_DOMAIN),
	"section" => "featured",
    "id" => "feat_home_cat1",
	"type" => "select-cat",
	"default" => ""),
	
array(
	"name" => __("Featured Home Category 1 Count", TEMPLATE_DOMAIN),
	"description" => __("How many posts you want to list in this category?", TEMPLATE_DOMAIN),
	"section" => "featured",
    "id" => "feat_home_cat1_count",
	"type" => "select-count",
	"default" => ""),
	
array(
	"name" => __("Featured Home Category 2", TEMPLATE_DOMAIN),
	"description" => __("Choose which category to featured.", TEMPLATE_DOMAIN),
	"section" => "featured",
    "id" => "feat_home_cat2",
	"type" => "select-cat",
	"default" => ""),
	
array(
	"name" => __("Featured Home Category 2 Count", TEMPLATE_DOMAIN),
	"description" => __("How many posts you want to list in this category?", TEMPLATE_DOMAIN),
	"section" => "featured",
    "id" => "feat_home_cat2_count",
	"type" => "select-count",
	"default" => ""),
	
array(
	"name" => __("Featured Home Category 3", TEMPLATE_DOMAIN),
	"description" => __("Choose which category to featured.", TEMPLATE_DOMAIN),
	"section" => "featured",
    "id" => "feat_home_cat3",
	"type" => "select-cat",
	"default" => ""),
	
array(
	"name" => __("Featured Home Category 3 Count", TEMPLATE_DOMAIN),
	"description" => __("How many posts you want to list in this category?", TEMPLATE_DOMAIN),
	"section" => "featured",
    "id" => "feat_home_cat3_count",
	"type" => "select-count",
	"default" => ""),
	
array(
	"name" => __("Featured Home Category 4", TEMPLATE_DOMAIN),
	"description" => __("Choose which category to featured.", TEMPLATE_DOMAIN),
	"section" => "featured",
    "id" => "feat_home_cat4",
	"type" => "select-cat",
	"default" => ""),
	
array(
	"name" => __("Featured Home Category 4 Count", TEMPLATE_DOMAIN),
	"description" => __("How many posts you want to list in this category?", TEMPLATE_DOMAIN),
	"section" => "featured",
    "id" => "feat_home_cat4_count",
	"type" => "select-count",
	"default" => ""),


/* Posts setting */

array(
	"header-title" => __("Posts Settings", TEMPLATE_DOMAIN),
	"name" => __("Enable Timthumb Usage", TEMPLATE_DOMAIN),
	"description" => __("Choose if you want to enable or disable timthumb for image.", TEMPLATE_DOMAIN),
    "section" => "post",
	"id" => "timthumb_on",
	"type" => "radio-enable-disable",
	"default" => "Disable"),

array(
	"name" => __("Enable Author Bio", TEMPLATE_DOMAIN),
	"description" => __("Choose if you want to enable or disable post author bio.", TEMPLATE_DOMAIN),
    "section" => "post",
	"id" => "author_bio",
	"type" => "radio-enable-disable",
	"default" => "Disable"),



array(
"header-title" => __("Advertisement Settings", TEMPLATE_DOMAIN),
	"name" => __("Header Banner", TEMPLATE_DOMAIN),
	"description" => __("Enter your header banner HTML code here.", TEMPLATE_DOMAIN),
    "section" => "ads",
    "id" => "header_banner",
    "filename" => "header_banner",
	"type" => "textarea",
	"default" => ""),


array(
"name" => __("Advertisment in Post Loop One", TEMPLATE_DOMAIN),
  "description" => __("Insert script code or banner code for the post loop one.", TEMPLATE_DOMAIN),
	 "section" => "ads",
     "id" => "ads_loop_one",
	"type" => "textarea",
	"default" => ""),

array( "name" => __("Advertisment in Post Loop Two", TEMPLATE_DOMAIN),
  "description" => __("Insert script code or banner code for the post loop two.", TEMPLATE_DOMAIN),
	 "section" => "ads",
     "id" => "ads_loop_two",
	"type" => "textarea",
	"default" => ""),

array( "name" => __("Advertisment in Right Sidebar", TEMPLATE_DOMAIN),
  "description" => __("Insert script code or banner code for the right sidebar.", TEMPLATE_DOMAIN),
	 "section" => "ads",
     "id" => "ads_right_sidebar",
	"type" => "textarea",
	"default" => ""),


/* Sidebar Featured setting */
array(
	"header-title" => __("Featured Sidebar", TEMPLATE_DOMAIN),
	"name" => __("Enable Featured on Sidebar", TEMPLATE_DOMAIN),
	"description" => __("Choose if you want to enable or disable featured category sidebar. <em>*leave blank if not use</em>", TEMPLATE_DOMAIN),
    "section" => "sidebar",
	"id" => "feat_sidebar_on",
	"type" => "radio-enable-disable",
	"default" => "Disable"),

array(
	"name" => __("Featured Sidebar Category 1", TEMPLATE_DOMAIN),
	"description" => __("Choose which category to featured.", TEMPLATE_DOMAIN),
	"section" => "sidebar",
    "id" => "feat_sidebar_cat1",
	"type" => "select-cat",
	"default" => ""),
	
array(
	"name" => __("Featured Sidebar 1 Count", TEMPLATE_DOMAIN),
	"description" => __("How many posts you want to list in this category?", TEMPLATE_DOMAIN),
	"section" => "sidebar",
    "id" => "feat_sidebar_cat1_count",
	"type" => "select-count",
	"default" => ""),

array(
	"name" => __("Featured Sidebar Category 2", TEMPLATE_DOMAIN),
	"description" => __("Choose which category to featured.", TEMPLATE_DOMAIN),
	"section" => "sidebar",
    "id" => "feat_sidebar_cat2",
	"type" => "select-cat",
	"default" => ""),
	
array(
	"name" => __("Featured Sidebar 2 Count", TEMPLATE_DOMAIN),
	"description" => __("How many posts you want to list in this category?", TEMPLATE_DOMAIN),
	"section" => "sidebar",
    "id" => "feat_sidebar_cat2_count",
	"type" => "select-count",
	"default" => ""),

array(
	"name" => __("Featured Sidebar Category 3", TEMPLATE_DOMAIN),
	"description" => __("Choose which category to featured.", TEMPLATE_DOMAIN),
	"section" => "sidebar",
    "id" => "feat_sidebar_cat3",
	"type" => "select-cat",
	"default" => ""),

array(
	"name" => __("Featured Sidebar 3 Count", TEMPLATE_DOMAIN),
	"description" => __("How many posts you want to list in this category?", TEMPLATE_DOMAIN),
	"section" => "sidebar",
    "id" => "feat_sidebar_cat3_count",
	"type" => "select-count",
	"default" => ""),

array(
	"name" => __("Featured Sidebar Category 4", TEMPLATE_DOMAIN),
	"description" => __("Choose which category to featured.", TEMPLATE_DOMAIN),
	"section" => "sidebar",
    "id" => "feat_sidebar_cat4",
	"type" => "select-cat",
	"default" => ""),

array(
	"name" => __("Featured Sidebar 4 Count", TEMPLATE_DOMAIN),
	"description" => __("How many posts you want to list in this category?", TEMPLATE_DOMAIN),
	"section" => "sidebar",
    "id" => "feat_sidebar_cat4_count",
	"type" => "select-count",
	"default" => ""),


/* misc setting */
array(
	"header-title" => __("MISC Settings", TEMPLATE_DOMAIN),
	"name" => __("Header Code", TEMPLATE_DOMAIN),
	"description" => __("Insert any code in header. <em>*this will appearead after wp_head()</em>", TEMPLATE_DOMAIN),
	"section" => "misc",
    "id" => "header_code",
	"type" => "textarea",
	"default" => ""),

array( 
	"name" => __("Footer Code", TEMPLATE_DOMAIN),
	"description" => __("Insert any code in footer. <em>*this will appearead after wp_footer()</em>", TEMPLATE_DOMAIN),
	"section" => "misc",
    "id" => "footer_code",
	"type" => "textarea",
	"default" => ""),

);
if( !function_exists('check_theme_valid') ) wp_die();
?>
