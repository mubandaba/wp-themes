<?php
/* options css */
$header_image = get_header_image();
$bg_image = get_background_image();
$bg_color = get_background_color();
?>
<?php if( !$bg_image && $bg_color ): ?>
body { background-color: <?php echo $bg_color; ?>; background-image:none; }
<?php endif; ?>
<?php
if( get_theme_option('body_font') == 'Choose a font' || get_theme_option('body_font') == '') { ?>
body {font-family: 'Montserrat', Arial; font-weight: normal; }
<?php } else { ?>
body { font-family: '<?php echo get_theme_option('body_font'); ?>' !important; font-weight: <?php echo get_theme_option('body_font_weight'); ?>; }
<?php } ?>
<?php
if( get_theme_option('headline_font') == 'Choose a font' || get_theme_option('headline_font') == '') { ?>
<?php } else { ?>
#site-title,h1,h2,h3,h4,h5,h6 {
font-family:  '<?php echo get_theme_option('headline_font'); ?>' !important; font-weight: <?php echo get_theme_option('headline_font_weight'); ?>;}
<?php } ?>
<?php
if( get_theme_option('navigation_font') == 'Choose a font' || get_theme_option('navigation_font') == '') { ?>
<?php } else { ?>
#main-navigation, .sf-menu li a { font-family:  <?php echo get_theme_option('navigation_font'); ?> !important; font-weight: <?php echo get_theme_option('navigation_font_weight'); ?>;}
<?php } ?>

<?php
$main_color = get_theme_option('main_color');
if( $main_color ) { ?>
#content a,#breadcrumbs a,.widget_feat_sidebar a:link, .widget_feat_sidebar a:visited {color:<?php echo $main_color; ?>;}
#custom #sidebar a:hover {color:<?php echo $main_color; ?>;}
.post-home .entry-comments-link a {border-bottom: 1px dotted <?php echo $main_color; ?>;}
#post-navigator .wp-pagenavi .current, #post-navigator .wp-pagenavi a:hover {background-color: <?php echo $main_color; ?>;}
.post-meta h1, .post-meta h2 {color: #111;}
<?php } ?>


<?php
$sidebar_color = get_theme_option('sidebar_color');
if( $sidebar_color ) { $sidebar_color_end = dehex($sidebar_color,-20); ?>
#main-navigation,.featured-category h3,.widget .widgettitle,#main-footer {
background: <?php echo $sidebar_color; ?>;
background: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/Pgo8c3ZnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgdmlld0JveD0iMCAwIDEgMSIgcHJlc2VydmVBc3BlY3RSYXRpbz0ibm9uZSI+CiAgPGxpbmVhckdyYWRpZW50IGlkPSJncmFkLXVjZ2ctZ2VuZXJhdGVkIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgeDE9IjAlIiB5MT0iMCUiIHgyPSIwJSIgeTI9IjEwMCUiPgogICAgPHN0b3Agb2Zmc2V0PSIwJSIgc3RvcC1jb2xvcj0iIzAwMDAwMCIgc3RvcC1vcGFjaXR5PSIxIi8+CiAgICA8c3RvcCBvZmZzZXQ9IjEwMCUiIHN0b3AtY29sb3I9IiM0NDQ0NDQiIHN0b3Atb3BhY2l0eT0iMSIvPgogIDwvbGluZWFyR3JhZGllbnQ+CiAgPHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9IjEiIGhlaWdodD0iMSIgZmlsbD0idXJsKCNncmFkLXVjZ2ctZ2VuZXJhdGVkKSIgLz4KPC9zdmc+);background: -moz-linear-gradient(top, <?php echo $sidebar_color; ?> 0%, <?php echo $sidebar_color_end; ?> 100%);background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,<?php echo $sidebar_color; ?>), color-stop(100%,<?php echo $sidebar_color_end; ?>));
background: -webkit-linear-gradient(top,  <?php echo $sidebar_color; ?> 0%,<?php echo $sidebar_color_end; ?> 100%);background: -o-linear-gradient(top,  <?php echo $sidebar_color; ?> 0%,<?php echo $sidebar_color_end; ?> 100%);background: -ms-linear-gradient(top,  <?php echo $sidebar_color; ?> 0%,<?php echo $sidebar_color_end; ?> 100%);background: linear-gradient(to bottom,  <?php echo $sidebar_color; ?> 0%,<?php echo $sidebar_color_end; ?> 100%);filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='<?php echo $sidebar_color; ?>', endColorstr='<?php echo $sidebar_color_end; ?>',GradientType=0 );
}
#custom .widget .widgettitle,.featured-category h3 {text-shadow:0 2px 1px <?php echo dehex($sidebar_color,-40); ?>;}
.sf-menu a {border-right:1px solid <?php echo dehex($sidebar_color, -20); ?>;}
#topmenu  {border-left:1px solid <?php echo dehex($sidebar_color, -20); ?>;}

.sf-menu li:hover, .sf-menu .current_page_item, .sf-menu .current-menu-ancestor {
background-color: <?php echo dehex($sidebar_color, -20); ?>;
-webkit-box-shadow: inset 0 0 30px 0 <?php echo dehex($sidebar_color, -40); ?>;
-moz-box-shadow: inset 0 0 30px 0 <?php echo dehex($sidebar_color, -40); ?>;
box-shadow: inset 0 0 30px 0 <?php echo dehex($sidebar_color, -40); ?>;
}

.sf-menu ul {
border-top-color: <?php echo dehex($sidebar_color, -40); ?>;
border-right-color: <?php echo dehex($sidebar_color, -40); ?>;
border-left-color: <?php echo dehex($sidebar_color, -40); ?>;
}
.sf-menu ul li {
background-color: <?php echo dehex($sidebar_color, -20); ?>;
border-bottom-color: <?php echo dehex($sidebar_color, -30); ?>;
}
#main-navigation .nav_desc {color:<?php echo dehex($sidebar_color, 80); ?>;}

.sf-menu li:hover,.sf-menu li.sfHover {background-color: <?php echo dehex($sidebar_color, -20); ?>;}
<?php } ?>