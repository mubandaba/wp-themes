<?php
global $post;
$featon = get_theme_option('feat_home_on');

$featcat1 = get_theme_option('feat_home_cat1');
$featcat2 = get_theme_option('feat_home_cat2');
$featcat3 = get_theme_option('feat_home_cat3');
$featcat4 = get_theme_option('feat_home_cat4');

$featcat1_count = get_theme_option('feat_home_cat1_count');
$featcat2_count = get_theme_option('feat_home_cat2_count');
$featcat3_count = get_theme_option('feat_home_cat3_count');
$featcat4_count = get_theme_option('feat_home_cat4_count');

$category_id1 = $featcat1;
$category_id2 = $featcat2;
$category_id3 = $featcat3;
$category_id4 = $featcat4;

$icon_name = "";
$icon_time = "";
$icon_comment = '<i class="icon-comment-alt"></i>';

if($featon=="Enable"):

/* FEATURED HOME CATEGORY 1 */
if($featcat1 && $featcat1 != 'Choose a category'):
$my_query1 = new WP_Query('cat='. $category_id1 . '&' . 'offset=' . '&' . 'showposts='. $featcat1_count); $postcounter = 0; ?>
<div class="featured-category">
<h3>Latest On <?php echo stripcslashes(get_cat_name($featcat1)); ?></h3>
<?php while ($my_query1->have_posts()) : $postcounter = $postcounter + 1; $my_query1->the_post(); $do_not_duplicate = $post->ID; ?>
<?php if(( 1 == $postcounter) || (2 == $postcounter) ){ ?>
<article id="featpost-<?php echo $post->ID; ?>" class="featured-post-one <?php if(0==$postcounter%2){?>columnfix<?php }?>"> 
<?php get_template_part( 'lib/templates/featured-home-image' ); ?>
<h2><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
<?php get_template_part( 'lib/templates/post-meta' ); ?>
<p><?php echo custom_excerpt(20); ?></p>
</article><!-- FEATPOST-<?php the_ID(); ?> END -->
<?php } else { ?>
<article id="featpost-<?php echo $post->ID; ?>" class="featured-post-two"> 
<h2><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
<?php get_template_part( 'lib/templates/post-meta' ); ?>
</article><!-- FEATPOST-<?php the_ID(); ?> END -->
<?php } ?>
<?php endwhile; wp_reset_postdata(); ?>
<div class="clearfix"></div>
</div><!-- FEATURED CATEGORY END -->
<?php endif;

/* FEATURED HOME CATEGORY 2 */
if($featcat2 && $featcat2 != 'Choose a category'):
$my_query2 = new WP_Query('cat='. $category_id2 . '&' . 'offset=' . '&' . 'showposts='. $featcat2_count); $postcounter = 0; ?>
<div class="featured-category">
<h3>Latest On <?php echo stripcslashes(get_cat_name($featcat2)); ?></h3>
<?php while ($my_query2->have_posts()) : $postcounter = $postcounter + 1; $my_query2->the_post(); $do_not_duplicate = $post->ID; ?>
<?php if(( 1 == $postcounter) || (2 == $postcounter) ){ ?>
<article id="featpost-<?php echo $post->ID; ?>" class="featured-post-one <?php if(0==$postcounter%2){?>columnfix<?php }?>"> 
<?php get_template_part( 'lib/templates/featured-home-image' ); ?>
<h2><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
<?php get_template_part( 'lib/templates/post-meta' ); ?>
<p><?php echo custom_excerpt(20); ?></p>
</article><!-- FEATPOST-<?php the_ID(); ?> END -->
<?php } else { ?>
<article id="featpost-<?php echo $post->ID; ?>" class="featured-post-two"> 
<h2><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
<?php get_template_part( 'lib/templates/post-meta' ); ?>
</article><!-- FEATPOST-<?php the_ID(); ?> END -->
<?php } ?>
<?php endwhile; wp_reset_postdata(); ?>
<div class="clearfix"></div>
</div><!-- FEATURED CATEGORY END -->
<?php endif;


/* FEATURED HOME CATEGORY 3 */
if($featcat3 && $featcat3 != 'Choose a category'):
$my_query3 = new WP_Query('cat='. $category_id3 . '&' . 'offset=' . '&' . 'showposts='. $featcat3_count); $postcounter = 0; ?>
<div class="featured-category">
<h3>Latest On <?php echo stripcslashes(get_cat_name($featcat3)); ?></h3>
<?php while ($my_query3->have_posts()) : $postcounter = $postcounter + 1; $my_query3->the_post(); $do_not_duplicate = $post->ID; ?>
<?php if(( 1 == $postcounter) || (2 == $postcounter) ){ ?>
<article id="featpost-<?php echo $post->ID; ?>" class="featured-post-one <?php if(0==$postcounter%2){?>columnfix<?php }?>"> 
<?php get_template_part( 'lib/templates/featured-home-image' ); ?>
<h2><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
<?php get_template_part( 'lib/templates/post-meta' ); ?>
<p><?php echo custom_excerpt(20); ?></p>
</article><!-- FEATPOST-<?php the_ID(); ?> END -->
<?php } else { ?>
<article id="featpost-<?php echo $post->ID; ?>" class="featured-post-two"> 
<h2><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
<?php get_template_part( 'lib/templates/post-meta' ); ?>
</article><!-- FEATPOST-<?php the_ID(); ?> END -->
<?php } ?>
<?php endwhile; wp_reset_postdata(); ?>
<div class="clearfix"></div>
</div><!-- FEATURED CATEGORY END -->
<?php endif;


/* FEATURED HOME CATEGORY 4 */
if($featcat4 && $featcat4 != 'Choose a category'):
$my_query4 = new WP_Query('cat='. $category_id4 . '&' . 'offset=' . '&' . 'showposts='. $featcat4_count); $postcounter = 0; ?>
<div class="featured-category">
<h3>Latest On <?php echo stripcslashes(get_cat_name($featcat4)); ?></h3>
<?php while ($my_query4->have_posts()) : $postcounter = $postcounter + 1; $my_query4->the_post(); $do_not_duplicate = $post->ID; ?>
<?php if(( 1 == $postcounter) || (2 == $postcounter) ){ ?>
<article id="featpost-<?php echo $post->ID; ?>" class="featured-post-one <?php if(0==$postcounter%2){?>columnfix<?php }?>"> 
<?php get_template_part( 'lib/templates/featured-home-image' ); ?>
<h2><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
<?php get_template_part( 'lib/templates/post-meta' ); ?>
<p><?php echo custom_excerpt(20); ?></p>
</article><!-- FEATPOST-<?php the_ID(); ?> END -->
<?php } else { ?>
<article id="featpost-<?php echo $post->ID; ?>" class="featured-post-two"> 
<h2><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
<?php get_template_part( 'lib/templates/post-meta' ); ?>
</article><!-- FEATPOST-<?php the_ID(); ?> END -->
<?php } ?>
<?php endwhile; wp_reset_postdata(); ?>
<div class="clearfix"></div>
</div><!-- FEATURED CATEGORY END -->
<?php endif;

endif;?>