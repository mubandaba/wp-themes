<?php if ( '' != get_the_post_thumbnail() ) {?>
<div class="post-image">
<?php $timthumb_on = get_theme_option('timthumb_on'); if( $timthumb_on == 'Enable' ): ?>
<?php $src = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large' ); $thumbnailSrc = $src[0]; ?>
<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><img src="<?php bloginfo('template_directory'); ?>/lib/scripts/timthumb/image.php?src=<?php echo $thumbnailSrc; ?>&h=200&w=400&a=tl" alt="<?php the_title_attribute(); ?>" class="aligncenter"></a>
<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><img src="<?php bloginfo('template_directory'); ?>/lib/scripts/timthumb/image.php?src=<?php echo $thumbnailSrc; ?>&h=300&w=600&a=tl" alt="<?php the_title_attribute(); ?>" class="mobile"></a>
<?php else : ?>
<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_post_thumbnail('featured-category', array('class' => 'aligncenter')); ?></a>
<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_post_thumbnail('large', array('class' => 'mobile')); ?></a>
<?php endif; ?>
</div><!-- POST IMAGE <?php the_ID(); ?> END -->
<?php }?>