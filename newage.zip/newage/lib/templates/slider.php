<?php
$featured_on = get_theme_option('slider_on');
$featured_category = get_theme_option('feat_cat');
$featured_number = get_theme_option('feat_cat_count');
$featured_post = get_theme_option('feat_post');
?>

<?php if($featured_on == 'Enable'): ?>
<?php if(!$featured_category && !$featured_post): ?>
<?php else: ?>
<?php if($featured_category): ?>

<div id="featuredbox">
<div id="featured">
<div id="Gallerybox">
<script type="text/javascript">
function startGallery() {
var myGallery = new gallery($('myGallery'), {
timed: true,
showArrows: true,
showCarousel: true,
embedLinks: true
});
document.gallery = myGallery;
}
window.onDomReady(startGallery);
</script>	
<div id="myGallery">
<?php
$query = new WP_Query( "cat=$featured_category&posts_per_page=$featured_number&orderby=date" );
while ( $query->have_posts() ) : $query->the_post(); ?>
<div class="imageElement post-<?php the_ID(); ?>">
<?php the_post_thumbnail('full', array('class' => 'full')); ?>
<?php the_post_thumbnail(array(100,75), array('class' => 'thumbnail')); ?>
<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php echo the_title(); ?></a></h3>
<p><?php echo custom_excerpt(30); ?></p>
<a href="<?php the_permalink(); ?>" title="open image" class="open"></a>
</div><!-- FEATURED POST-<?php the_ID(); ?> END -->
<?php endwhile; wp_reset_query(); ?>
</div><!-- MYGALLERY END -->
</div><!-- GALLERBOX END -->
</div><!-- FEATURED END -->
</div><!-- GALLERY SLIDER END -->

<?php elseif($featured_post && !$featured_category): ?>

<div id="featuredbox">
<div id="featured">
<div id="Gallerybox">
<script type="text/javascript">
function startGallery() {
var myGallery = new gallery($('myGallery'), {
timed: true,
showArrows: true,
showCarousel: true,
embedLinks: true
});
document.gallery = myGallery;
}
window.onDomReady(startGallery);
</script>
<div id="myGallery">
<?php
query_posts( array( 'post__in' => explode(',', $featured_post), 'post_type'=> array('post','page','portfolio'), 'posts_per_page' => 100, 'orderby' => 'post__in', 'order' => '' ) );
while ( have_posts() ) : the_post(); ?>
<div class="imageElement post-<?php the_ID(); ?>">
<?php the_post_thumbnail('full', array('class' => 'full')); ?>
<?php the_post_thumbnail(array(100,75), array('class' => 'thumbnail')); ?>
<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php echo the_title(); ?></a></h3>
<p><?php echo custom_excerpt(30); ?></p>
<a href="<?php the_permalink(); ?>" title="open image" class="open"></a>
</div><!-- FEATURED POST-<?php the_ID(); ?> END -->
<?php endwhile; wp_reset_query(); ?>
</div><!-- MYGALLERY END -->
</div><!-- GALLERBOX END -->
</div><!-- FEATURED END -->
</div><!-- GALLERY SLIDER END -->

<?php endif; ?>
<?php endif; ?>
<?php endif; ?>