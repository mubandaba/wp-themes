<article class="post-meta post-error" id="post-0">
<header class="entry-header"><h2 class="entry-title"><?php _e( 'Nothing Found', TEMPLATE_DOMAIN ); ?></h2></header>
<p><?php _e( 'It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', TEMPLATE_DOMAIN ); ?></p>
<div style="width:350px;"><?php get_search_form(); ?></div>
</article><!-- POST ERROR END -->