<?php if ( '' != get_the_post_thumbnail() ) {?>
<div class="post-image">
<?php $timthumb_on = get_theme_option('timthumb_on'); if( $timthumb_on == 'Enable' ): ?>
<?php $src = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large' ); $thumbnailSrc = $src[0]; ?>
<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><img src="<?php bloginfo('template_directory'); ?>/lib/scripts/timthumb/image.php?src=<?php echo $thumbnailSrc; ?>&h=150&w=150&a=tl" alt="<?php the_title_attribute(); ?>" class="alignleft"></a>
<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><img src="<?php bloginfo('template_directory'); ?>/lib/scripts/timthumb/image.php?src=<?php echo $thumbnailSrc; ?>&h=250&w=600&a=tl" alt="<?php the_title_attribute(); ?>" class="mobile"></a>
<?php else : ?>
<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_post_thumbnail('thumbnail', array('class' => 'alignleft')); ?></a>
<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_post_thumbnail('large', array('class' => 'mobile')); ?></a>
<?php endif; ?>
</div><!-- POST IMAGE <?php the_ID(); ?> END -->
<?php }?>
