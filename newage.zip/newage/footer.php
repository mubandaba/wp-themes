<div class="clearfix"></div>
</div><!-- MAINCONTENT END -->

<footer id="main-footer" role="contentinfo" itemscope="itemscope" itemtype="http://schema.org/WPFooter">
<div class="inner">

<?php if ( is_active_sidebar( 'footer-widget-1' ) ) : ?>
<div id="footer-widget-box">
<?php dynamic_sidebar( 'footer-widget-1' ); ?>
<?php dynamic_sidebar( 'footer-widget-2' ); ?>
<?php dynamic_sidebar( 'footer-widget-3' ); ?>
<?php dynamic_sidebar( 'footer-widget-4' ); ?>
<div class="clearfix"></div>
</div>
<?php else: ?>
<?php endif; ?> 

<div id="footer-left">
<?php if ( function_exists( 'wp_nav_menu' ) ) { // Added in 3.0 ?>
	<?php wp_nav_menu( array(
	'theme_location' => 'footer',
	'container' => false,
	'depth' => 1,
	'fallback_cb' => 'none'
	)); ?>
<?php } ?>
</div><!-- FOOTER LEFT END -->
<div id="footer-right">
<?php _e('Copyright &copy;', TEMPLATE_DOMAIN); ?> <?php echo gmdate(__('Y', TEMPLATE_DOMAIN)); ?>. <?php bloginfo('name'); ?>
</div><!-- FOOTER RIGHT END -->

<div class="clearfix"></div>
</div></footer><!-- MAIN FOOTER END -->

<script>	
(function($){ //create closure so we can safely use $ as alias for jQuery
$(document).ready(function(){
// initialise plugin
var example = $('#topmenu').superfish({
//add options here if required
});
});
})(jQuery);
</script>

<?php wp_footer(); ?>
<?php $footer_code = get_theme_option('footer_code'); echo stripcslashes($footer_code); ?>

<div class="clearfix"></div>
</body>
</html>