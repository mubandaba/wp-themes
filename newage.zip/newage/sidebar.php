<div id="sidebar" class="widget-area" role="complementary" itemscope="itemscope" itemtype="http://schema.org/WPSideBar">
<?php if ( is_active_sidebar( 'sidebar' ) ) : ?>
<?php dynamic_sidebar( 'sidebar' ); ?>
<?php else: ?>
<?php $get_right_ads_code = get_theme_option('ads_right_sidebar'); if($get_right_ads_code != '') { ?>
<aside class="widget ctr-ad">
<div class="textwidget adswidget"><?php echo stripcslashes($get_right_ads_code); ?></div>
</aside>
<?php } ?>
<?php the_widget( 'WP_Widget_Search' ); ?>
<?php the_widget( 'WP_Widget_Categories' ); ?>
<?php the_widget( 'WP_Widget_Pages' ); ?> 
<?php the_widget( 'WP_Widget_Archives' ); ?>
<?php the_widget( 'WP_Widget_Meta' ); ?> 
<?php endif; ?> 

<?php /* WARNING! THEME WILL BE DEACTIVATED IF REMOVE OR EDIT ANYTHING WITHIN */?>
      <?php echo ccc_theme_license(); ?>
<?php /* WARNING! THEME WILL BE DEACTIVATED IF REMOVE OR EDIT ANYTHING WITHIN */?>

<div class="clearfix"></div>
</div><!-- SIDEBAR END -->
