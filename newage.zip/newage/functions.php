<?php
////////////////////////////////////////////////////////////////////////////////
// Global Define
////////////////////////////////////////////////////////////////////////////////
// do not change this, its for translation and options string
define('TEMPLATE_DOMAIN', 'newage'); 
define('TEMPLATE_OPTIONS', TEMPLATE_DOMAIN . '_theme_options');
define('SUPER_STYLE', 'yes');

////////////////////////////////////////////////////////////////////////////////
// Set up the content width value based on the theme's design and stylesheet.
////////////////////////////////////////////////////////////////////////////////

if ( ! isset( $content_width ) )
	$content_width = 1200;

////////////////////////////////////////////////////////////////////////////////
// Global Setup
////////////////////////////////////////////////////////////////////////////////
function mptheme_setup() { 
//Add Language Support
load_theme_textdomain( TEMPLATE_DOMAIN, get_template_directory() . '/languages' );
add_editor_style();
add_theme_support( 'automatic-feed-links' );
add_theme_support( 'html5', array('search-form', 'comment-form', 'comment-list') );
add_theme_support( 'menus' );
register_nav_menus( array(
'primary' => __( 'Primary Menu', TEMPLATE_DOMAIN ),
'footer' => __( 'Footer Menu', TEMPLATE_DOMAIN ),
));
//Default Fallback Menu
function revert_wp_menu_page($args) {
$pages_args = array(
		'depth'      => 0,
		'echo'       => false,
		'exclude'    => '',
		'title_li'   => ''
	);
$menu = wp_page_menu( $pages_args );
$menu = str_replace( array( '<div class="menu"><ul>', '</ul></div>' ), array( '<div class="inner"><ul id="topmenu" class="sf-menu">', '</ul></div>' ), $menu );
echo $menu;
}
// Custom background
add_theme_support( 'custom-background', array(
		'default-color' => 'eee',
		'default-image' => get_template_directory_uri() . '/images/bg.png',
));
// Custom background
add_theme_support( 'custom-header', array(
// The default header text color.
		'default-text-color' => '',
        'default-image' => '',
        'header-text'  => false,
		// The height and width of our custom header.
		'width' => 1200,
		'height' => 300,
		// Support flexible heights.
		'flex-height' => true,
		// Random image rotation by default.
	   'random-default'	=> false,
		// Callback for styling the header.
		'wp-head-callback' => '',
		// Callback for styling the header preview in the admin.
		'admin-head-callback' => '',
		// Callback used to display the header preview in the admin.
		'admin-preview-callback' => '',
));
// Standard post thumbnails
add_theme_support( 'post-thumbnails' );
set_post_thumbnail_size( 300, 300, true ); //(cropped)
// Custom size post thumbnails
add_theme_support( 'add_image_size' );
add_image_size( 'slider', 800, 400, true ); // Slider images (cropped)
add_image_size( 'featured-category', 400, 200, true ); // Featured home category (cropped)
add_image_size( 'featured-sidebar', 400, 200, true ); // Featured sidebar category (cropped)
}
add_action( 'after_setup_theme', 'mptheme_setup' );

///////////////////////////////////////////////////////////////////////////////
// Load Theme Styles and Javascripts
///////////////////////////////////////////////////////////////////////////////
/*---------------------------load styles--------------------------------------*/
function mptheme_load_styles() {
	global $theme_version,$is_IE;
	wp_enqueue_style( 'superfish', get_template_directory_uri(). '/lib/scripts/superfish-menu/superfish.css', array(), $theme_version );
	wp_enqueue_style( 'normalize', get_template_directory_uri(). '/lib/scripts/normalize.css', array(), $theme_version );
	if ( ( is_home() && is_front_page() && ($paged < 1) ) && get_theme_option('slider_on') == 'Enable'  ) { 
	wp_enqueue_style( 'jd-gallery', get_template_directory_uri(). '/lib/scripts/jd-gallery/jd.gallery.css', array(), $theme_version );
	}
	wp_enqueue_style( 'fontawesome', get_template_directory_uri() . '/lib/scripts/fontawesome/css/font-awesome.css', array(), $theme_version );
	if($is_IE):
	wp_enqueue_style( 'fontawesome-ie7', get_template_directory_uri() . '/lib/scripts/fontawesome/css/font-awesome-ie7.css', array(), $theme_version );
	endif;
}
add_action( 'wp_enqueue_scripts', 'mptheme_load_styles' );

/*---------------------------load js scripts--------------------------------------*/

function mptheme_load_scripts() {
	global $theme_version,$is_IE;
	wp_enqueue_script("jquery");
	wp_enqueue_script("hoverIntent");
	wp_enqueue_script( 'modernizr', get_template_directory_uri(). '/lib/scripts/modernizr.js', array(), '2.6.2', $theme_version );
	wp_enqueue_script( 'superfish', get_template_directory_uri(). '/lib/scripts/superfish-menu/superfish.js', array(), '1.7.4', $theme_version );
	if($is_IE): 
	wp_enqueue_script('html5shim', get_template_directory_uri(). '/lib/scripts/html5.js', array(), '3.7.0', $theme_version );
	endif;
	if ( ( is_home() && is_front_page() && ($paged < 1) ) && get_theme_option('slider_on') == 'Enable'  ) { 
	wp_enqueue_script('mootools', get_template_directory_uri(). '/lib/scripts/jd-gallery/mootools.js', $theme_version, '1.11' );
	wp_enqueue_script('jd-gallery2', get_template_directory_uri(). '/lib/scripts/jd-gallery/jd.gallery.js', $theme_version, '2.0' );
	wp_enqueue_script('jd-gallery-set', get_template_directory_uri(). '/lib/scripts/jd-gallery/jd.gallery.set.js', $theme_version, '2.0' );
	wp_enqueue_script('jd-gallery-transitions', get_template_directory_uri(). '/lib/scripts/jd-gallery/jd.gallery.transitions.js', $theme_version, '2.0' );
	}
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) )
	wp_enqueue_script( 'comment-reply' );
}
add_action( 'wp_enqueue_scripts', 'mptheme_load_scripts' );

///////////////////////////////////////////////////////////////////////////////
// Load Theme Cusrom Style
///////////////////////////////////////////////////////////////////////////////

function theme_custom_style_init() {
global $theme_version,$is_IE;
if($is_IE): ?>
<!--<style type="text/css">
</style>-->
<?php endif; ?>
<?php print "<style type='text/css' media='all'>"; ?>
@font-face {
  font-family: 'FontAwesome';
  src: url('<?php echo get_template_directory_uri(); ?>/lib/scripts/fontawesome/fonts/fontawesome-webfont.eot?v=4.0.3');
  src: url('<?php echo get_template_directory_uri(); ?>/lib/scripts/fontawesome/fonts/fontawesome-webfont.eot?#iefix&v=4.0.3') format('embedded-opentype'), url('<?php echo get_template_directory_uri(); ?>/lib/scripts/fontawesome/fonts/fontawesome-webfont.woff?v=4.0.3') format('woff'), url('<?php echo get_template_directory_uri(); ?>/lib/scripts/fontawesome/fonts/fontawesome-webfont.ttf?v=4.0.3') format('truetype'), url('<?php echo get_template_directory_uri(); ?>/lib/scripts/fontawesome/fonts/fontawesome-webfont.svg?v=4.0.3#fontawesomeregular') format('svg');
  font-weight: normal;
  font-style: normal;
}
<?php get_template_part ( '/lib/options/options-css' ); ?>
<?php if( get_theme_option('custom_css') ): ?><?php echo get_theme_option('custom_css'); ?><?php endif; ?>
<?php print "</style>"; ?>
<?php }
add_action('wp_head','theme_custom_style_init');

///////////////////////////////////////////////////////////////////////////////
// Load Theme Default Fonts
///////////////////////////////////////////////////////////////////////////////
/*---------------------------load google webfont style--------------------------------------*/
function mp_theme_load_gwf_styles() {
if( get_theme_option('body_font') == 'Choose a font' || get_theme_option('body_font') == '') {
wp_register_style('default_body_gwf', 'http://fonts.googleapis.com/css?family=Montserrat%3A100%2C200%2C300%2C400%2C600%2C700%2C900%2C100italic%2C200italic%2C300italic%2C400italic%2C600italic%2C700italic%2C900italic&subset=latin%2Ccyrillic-ext%2Clatin-ext%2Ccyrillic%2Cgreek%2Cgreek-ext%2Cvietnamese');
wp_enqueue_style( 'default_body_gwf');
}
}
add_action('wp_enqueue_scripts', 'mp_theme_load_gwf_styles');

////////////////////////////////////////////////////////////////////////////////
// Add Theme Custom Functions
////////////////////////////////////////////////////////////////////////////////
include( get_template_directory() . '/lib/functions/theme-functions.php' );
include( get_template_directory() . '/lib/functions/option-functions.php' );
include( get_template_directory() . '/lib/functions/widget-functions.php' );

?>