Copyright 2005-2014, Ronald KSY and MagPress.com, use only as authorized
***********************************
Please read this license carefully before using MAGPRESS free wordpress theme
By using this theme, you are bound to the terms of this license.
***********************************

***********************************
Personal & Commercial License
***********************************
You are not allowed to Remove Author or Contributor link in theme unless you have purchase a developer version of the theme.
You have the rights to use this theme for personal and commercial project(s) purposes.
You can modify/customize the files to fit your needs.
You cannot claim credit or ownership for any of the files found on this theme.
You cannot resell, redistribute, license, or sub-license this theme.

***************************************************
How to purchase a developer license for this theme?
***************************************************
Thank You For Using WordPress Theme By MagPress.com
If you're interested in purchasing a developer's license (clean footer or sidebar) for this theme.
please go to this developer license purchase page at the Theme URI or developer page at http://www.magpress.com/developer-license

