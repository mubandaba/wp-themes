<div class="wintips">
	<div class="wintips-thumb"></div><h2><?php echo _hui("wintip_title") ?></h2>
	<p><?php echo _hui("wintip_asb") ?></p>
	<p><a href="<?php echo _hui("wintip_url") ?>" <?php if (_hui("wintip_blank")){echo 'target="_blank"';} ?> class="btn btn-primary btn-wintips">
	<?php echo _hui("wintip_button") ?></a></p> <span etap="wintips_close" class="wintips-close"><i class="fa fa-times-circle-o"></i></span>
</div>