wedocs-plugin

将wedocs-plugin文件夹剪贴到plugins插件文件夹下,启用插件wedocs-plugin和主题wedocs