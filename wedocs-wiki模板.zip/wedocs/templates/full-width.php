<?php
/**
 * Template Name: Full Width
 */

get_template_part( 'templates/page', 'header' );
get_template_part( 'templates/content', 'page' );
