<?php
/**
 * Template Name: No Page Header
 */

get_template_part( 'templates/content', 'page' );
