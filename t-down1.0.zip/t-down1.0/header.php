<!DOCTYPE html>

    <html lang="en" id="index">
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <?php include('seo.php'); ?>
    <link href="http://www.newsky365.com/favicon.ico" rel="shortcut icon" type="image/x-icon">
    <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
    <script>
        var _hmt = _hmt || [];
    </script>
  </head>
  
  <body>

<!--index header-->  
  
  <div id="topBar">
        <div id="topNav">
            <a class="logo" href="/"></a>
            <div class="searchBar">
<form action="/" method="GET" id="searchform" target="_blank">
<div class="header-search-box">
<input type="text" class="header-search-input" value="" id="hd-input" name="s" style="color: rgb(0, 0, 0); ">
<input type="submit" name="" class="header-search-btn" value="搜索">
<div style="clear:both"></div>
</div>
</form>
</div>
            <div class="fBg"></div>
            <div class="sBg"></div>
            <div class="tBg"></div>
            <div id="request_url"></div>
            <div class="sub_nav">
                <a href="http://www.newsky365.com/" target="_blank">&gt;&gt;返回天天分享</a>
            </div>
        </div>
    </div>

<style type="text/css">
   .banner img,.softSet dd img,.specialSets img, .rank td img{display:none;}
</style>
