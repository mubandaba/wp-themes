<?php get_header();?>
<div class="app-content">
    <div class="app-content--inner bg-white">
<!--Post-->
<div class="h5 my-3 mb-lg-4">
    <div class="d-flex flex-fill algin-items-center">
        <div class="flex-fill"><?php the_archive_title();?></div>
    </div>
</div>
<div class="divider my-4"></div>
    <div class="row mb-3">
        <?php if (have_posts()):while (have_posts()):the_post();$author_id = get_post_field( 'post_author', $post_id );?>
        <div class="col-xxl-5 col-lg-3 col-lg-post-4 col-lg-post-3 col-md-4 col-sm-6">
            <a href="<?php the_permalink();?>" class="card card-box-hover-rise mb-5" target="_blank">
                <div class="card-badges">
                    <span class="badge badge-danger"><?php the_archive_title();?></span>
                </div>
                <img src="<?php vik_thumb('post_thumb');?>" class="card-img-top" alt="<?php the_title()?>">
                <div class="card-body card-body-avatar">
                    <div class="avatar-icon-wrapper">
                        <div class="avatar-icon">
                            <img src="<?php vik_author_img($author_id);?>" alt="">
                        </div>
                    </div>
                    <h5 class="card-title text-black text-truncate text-nowrap"style="font-size: 0.875rem">
                        <?php the_title()?>
                    </h5>
                    <p class="card-text text-black text-truncate text-nowrap" style="max-width: 100%;font-size: 0.75rem">
                        <?php echo wp_trim_words(get_the_excerpt(),'100','...');?>
                    </p>
                    <div class="card-date mt-2">
                        <i class="fa fa-clock text-muted mr-1"></i>
                        <small class="text-muted">
                            <?php the_time('Y-m-d');?>
                        </small>
                    </div>
                </div>
            </a>
        </div>
        <?php endwhile;endif;?>
    </div>
        <?php
        if ( function_exists('vik_pagination') )
            vik_pagination();
        ?>
    </div>
    <?php include 'template_parts/footer.php'?>
</div>
<!--Post END-->
<?php get_footer();?>