$((function () {
    $('[data-toggle="tooltip"]').tooltip(), $(".tooltip-custom").each((function () {
        $(this).tooltip({html: !0, title: $("#" + $(this).data("tip")).html()})
    }))
})), $(document).on("inserted.bs.tooltip", (function (t) {
    var o = $(t.target).data("bs.tooltip");
    $(o.tip).addClass($(t.target).data("tooltip-class"))
})), $((function () {
    $('[data-toggle="popover"]').popover(), $(".popover-custom").each((function () {
        $(this).popover({
            html: !0, content: function () {
                return $("#" + $(this).data("tip")).html()
            }
        })
    }))
})), $(document).on("inserted.bs.popover", (function (t) {
    var o = $(t.target).data("bs.popover");
    $(o.tip).addClass($(t.target).data("popover-class"))
})), $("body").on("click", (function (t) {
    $('[data-rel="popover-close-outside"]').each((function () {
        $(this).is(t.target) || 0 !== $(this).has(t.target).length || 0 !== $(".popover").has(t.target).length || $(this).popover("hide")
    }))
})), $('a[href="#"]').click((function (t) {
    t.preventDefault()
}));