$((function () {
    $("#sidebar-nav").metisMenu()
}));