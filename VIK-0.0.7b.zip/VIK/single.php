<?php get_header(); if (have_posts()):while (have_posts()):the_post();?>

    <div class="app-content bg-white">
        <div class="app-content--inner">
            <div class="row">
                <div class="col-xl-8">
                    <div class="page-title pb-4">
                        <div>
                            <h5 class="mt-1 mb-2 font-weight-bold"><?php the_title()?></h5>
                            <div class="text-black-50 mb-0 mt-5 text-left" style="overflow: hidden;"><?php the_content();?></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4">
                    <div class="app-content--sidebar app-content--sidebar__lg pos-r" id="sidebar-inner-2">
                        <div class="app-content--sidebar__content">
                            <div class="card card-transparent mb-5">
                                <a href="https://www.joytheme.com/download/vik" target="_blank" class="card-img-wrapper rounded">
                                    <div class="card-badges card-badges-bottom">
                                        <span class="badge badge-neutral-dark text-dark">广告</span>
                                    </div>
                                    <img src="https://demo.joytheme.com/vik/wp-content/uploads/2019/12/vik_adpost.png" class="card-img-top rounded" alt="JOYtheme">
                                </a>
                            </div>
                            <div class="divider my-4"></div>
                            <div class="font-weight-bold font-size-lg d-flex align-items-center mb-3">
                                <h5>分类目录</h5>
                            </div>
                            <?php $cats = get_categories();foreach ($cats as $cat):$cat_link = get_category_link($cat->term_id)?>
                            <div class="py-2">
                                <div class="d-flex justify-content-between">
                                    <span class="d-block">
                                        <a href="<?php echo $cat_link?>"><?php echo $cat->name?></a>
                                    </span>
                                    <span class="badge badge-dark">
                                        <?php echo $cat->count?>
                                    </span>
                                </div>
                            </div>
                            <?php endforeach;?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include 'template_parts/footer.php'?>
    </div>

<?php endwhile;endif;get_footer();?>
