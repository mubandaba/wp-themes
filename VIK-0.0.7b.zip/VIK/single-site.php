<?php get_header();
$vik_customize = get_option('vik_customize');
$load_type = $vik_customize['load_type'];
if (have_posts()):while (have_posts()):the_post();?>
    <div class="app-content">
        <div class="app-content--inner bg-white">
            <!--Book-->
            <div class="py-5">
                <div class="container">
                    <?php
                        $web_id = get_the_ID();
                        $web_desc = get_post_meta($web_id,'web_desc',true);
                        $web_link = get_post_meta($web_id,'web_link',true);
                        $web_logo_url = get_post_meta($web_id,'web_logo',true)['url'];
                        $web_logo_id = get_post_meta($web_id,'web_logo',true)['id'];
                    ?>
                    <div class="row mb-5">
                        <div class="col-lg-4">

                            <div class="card card-transparent mb-5 mb-sm-0">
                                <img <?php xyz_src($web_logo_id);?> class="card-img-top rounded w-100 shadow-sm">
                            </div>
                        </div>
                        <div class="col-lg-8 d-flex align-items-center mt-5">
                            <div class="tool-body p-xl-4">
                                <div class="tool-name h4"><?php the_title_attribute()?> <span class="badge badge-neutral-success text-success"><small>官网</small></span></div>
                                <div class="mt-2 mt-md-3">
                                    <div class="tool-info text-sm text-muted">
                                        <ul class="list-unstyled text-dark">
                                            <li class="my-2">网站介绍：<?php echo $web_desc?></li>
                                            <?php if ($load_type=='modal_link'):?>
                                                <li class="my-2">网站链接：<span id="site_link"><?php echo $web_link;?></span></li>
                                                <button type="button" id="modal_button" class="btn btn-secondary mt-3" data-toggle="modal" data-target="#modal_jump"><?php the_title_attribute()?> <i class="fa fa-angle-right" aria-hidden="true"></i></button>
                                                <div class="modal fade" id="modal_jump" tabindex="-1" role="dialog" aria-labelledby="modal_jump" aria-hidden="true">
                                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-body p-0">
                                                                <div class="card bg-secondary shadow-none border-0">
                                                                    <div class="card-body px-lg-5 py-lg-5 text-center">
                                                                        <div class="avatar-icon-wrapper avatar-initials avatar-icon-xl">
                                                                            <div id="time" class="avatar-icon rounded text-white bg-dark">
                                                                                10
                                                                            </div>
                                                                        </div>
                                                                        <p class="text-center py-5">
                                                                            您将离开本站并访问 <?php the_title_attribute()?>
                                                                        </p>

                                                                        <div class="text-center">
                                                                            <button type="button" id="cancel_button" class="btn btn-dark" data-dismiss="modal">取消</button>
                                                                            <button type="button" class="btn btn-primary">
                                                                                <a href="<?php echo $web_link?>" class="text-white">立即前往</a>
                                                                            </button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else:?>
                                                <li class="my-2">网站链接：
                                                    <a id="site_link" href="<?php get_page_url('go', 'page'); ?>?url=<?php echo $web_link?>&siteID=<?php echo $web_id?>" target="_blank">
                                                        <?php echo parse_url($web_link)['host'];?>
                                                        <i class="fa fa-external-link" aria-hidden="true"></i>
                                                    </a>
                                                </li>
                                            <?php endif;?>
                                        </ul>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <!--推荐-->
                    <div class="h5 mb-3 mb-lg-4">
                        <div class="d-flex flex-fill algin-items-center">
                            <div class="flex-fill">相关推荐</div>
                        </div>
                    </div>
                    <div class="divider my-4"></div>
                    <div class="row">
                        <?php
                            $posts = get_posts("numberposts=6&post_type=site"); if($posts) : foreach( $posts as $post ) : setup_postdata( $post );
                            $web_id = get_the_ID();
                            $web_desc = get_post_meta($web_id,'web_desc',true);
                            $web_logo_url = get_post_meta($web_id,'web_logo',true)['url'];
                            $web_logo_id = get_post_meta($web_id,'web_logo',true)['id'];
                        ?>
                            <div class="col-xl-4 col-xlg-3 col-lg-4 col-sm-12 col-xmd-2 mb-4">
                                <div class="card card-box-hover-shadow site-card">
                                    <a class="row no-gutters" href="<?php the_permalink();?>">
                                        <div class="col-3">
                                            <img <?php xyz_src($web_logo_id);?> class="card-img" alt="..." style="width: 80px">
                                        </div>
                                        <div class="col-7">
                                            <div class="card-body pb-0">
                                                <h5 class="text-black" style="font-size: 0.875rem"><?php the_title()?></h5>
                                                <p class="card-text text-dark-50 d-inline-block text-truncate" style="max-width: 100%;font-size: 0.75rem">
                                                    <small><?php echo $web_desc?></small>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="d-flex align-items-center card-hover-indicator">
                                            <i class="fa fa-chevron-circle-right"></i>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach;endif;?>
                    </div>
                    <!--推荐 END-->
                </div>
            </div>
        </div>
        <?php include 'template_parts/footer.php'?>
    </div>
<?php endwhile;endif;get_footer();?>