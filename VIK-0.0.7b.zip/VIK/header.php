<!doctype html>
<html lang="zh-hans">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no">
    <link rel="shortcut icon" href="<?php echo xyz_img( 'web_favicon' )?>">
    <?php wp_head();?>
</head>
<body id="app-top">
<?php if ( !is_page_template('page-go.php') ) {
    $vik_customize = get_option('vik_customize');
    if ($vik_customize['blog_logo']){$blog_logo = $vik_customize['blog_logo']['id'];}
    if ($vik_customize['wechat']){$wechat_id = $vik_customize['wechat']['id'];}
    $qq = $vik_customize['qq'];
    $weibo = $vik_customize['weibo'];
?>
<div class="app-wrapper">
    <div class="app-sidebar app-sidebar--light">
        <div class="app-sidebar--header">
            <div class="nav-logo w-100 text-center">
                <a href="<?php bloginfo('url');?>" class="d-block" data-toggle="tooltip" title="">
                    <?php $url = get_template_directory_uri()?>
                    <img <?php xyz_src($blog_logo,'',  $url.'/static/images/vik_logo.png')?> alt="">
                </a>
            </div>

        </div>
        <div class="app-sidebar--content scrollbar-container">
            <div class="sidebar-navigation">
                <ul id="sidebar-nav">
                    <?php xyz_menu_with_walker('main_menu', new  Sidenav_Menu_Walker())?>

                </ul>
            </div>
        </div>
        <div class="app-sidebar--footer d-block pt-3">
            <div class="text-center mb-2">
                <?php if ($qq){
                    $qq_link='';
                    $qq_link.='<a href="tencent://message/?uin='.$qq.'&Site=&Menu=yes" target="_blank" class="m-2 btn btn-secondary p-0 d-inline-block text-center d-40 rounded" >';
                    $qq_link.='<i class="fa fa-qq"></i>';
                    $qq_link.='</a>';
                    echo $qq_link;
                }if ($weibo){
                    $weibo_link='';
                    $weibo_link.='<a href="'.$weibo.'" target="_blank" class="m-2 btn btn-secondary p-0 d-inline-block text-center d-40 rounded" >';
                    $weibo_link.='<i class="fa fa-weibo"></i>';
                    $weibo_link.='</a>';
                    echo $weibo_link;
                }if ($wechat_id){?>
                <a href="#" class="m-2 btn btn-secondary p-0 d-inline-block text-center d-40 rounded popover-custom" data-trigger="click" data-placement="top" rel="popover-close-outside" data-tip="tip-popover-3" data-popover-class="popover-secondary popover-custom-wrapper popover-custom-lg">
                    <i class="fa fa-wechat"></i>
                </a>
                <div id="tip-popover-3" class="d-none">
                    <div class="card bg-secondary shadow-none border-0 d-140">
                        <img <?php xyz_src($wechat_id)?> class="card-img-top rounded" alt="">
                    </div>
                </div>
                <?php }?>
            </div>
        </div>
    </div>
    <div class="sidebar-mobile-overlay"></div>
    <div class="app-main">
        <div class="app-header">
            <div class="d-flex">
                <button class="navbar-toggler wax-menu wax-menu--elastic toggle-sidebar" type="button">
                    <span class="wax-menu-box">
                        <span class="wax-menu-inner"></span>
                    </span>
                </button>
                <button class="navbar-toggler wax-menu wax-menu--elastic toggle-sidebar-mobile" type="button">
                    <span class="wax-menu-box">
                        <span class="wax-menu-inner"></span>
                    </span>
                </button>
            </div>

            <div class="nav-logo w-100 d-sm-none text-center mr-5">
                <a href="<?php bloginfo('url');?>" class="d-block">
                    <img <?php xyz_src($blog_logo,'',  $url.'/static/images/vik_logo.png')?> alt="">
                </a>
            </div>
        </div>
<?php }?>