<?php
function create_wx() {
    $labels = array(
        'name'               => '二维码导航',
        'singular_name'      => '二维码导航',
        'add_new'            => '新增导航',
        'add_new_item'       => '新增导航',
        'edit_item'          => '编辑导航',
        'new_item'           => '新导航',
        'all_items'          => '所有导航',
        'view_item'          => '查看导航',
        'search_items'       => '搜索导航',
        'not_found'          => '没有找到有关导航',
        'not_found_in_trash' => '回收站里面没有相关导航',
        'parent_item_colon'  => '',
        'menu_name'          => '二维码导航'
    );
    $args = array(
        'labels'        => $labels,
        'description'   => '我们网站的二维码导航信息',
        'public'        => true,
        'menu_position' => 5,
        'supports'      => array('title'),
        'menu_icon'     => 'dashicons-thumbs-up',
        'has_archive'   => true
    );
    register_post_type( 'wx', $args );
}
add_action( 'init', 'create_wx' );
function create_wx_tax() {
    $labels = array(
        'name'              =>'导航分类',
        'singular_name'     =>'导航分类',
        'search_items'      =>'搜索分类' ,
        'all_items'         =>'所有分类' ,
        'parent_item'       =>'该分类的上级分类' ,
        'parent_item_colon' =>'该分类的上级分类：' ,
        'edit_item'         =>'编辑分类' ,
        'update_item'       =>'更新分类' ,
        'add_new_item'      =>'添加新分类' ,
        'new_item_name'     =>'新分类' ,
        'menu_name'         =>'分类' ,
    );
    $args = array(
        'labels' => $labels,
        'hierarchical' => true,
    );
    register_taxonomy( 'wx_tax', 'wx', $args );
}
add_action( 'init', 'create_wx_tax', 0 );