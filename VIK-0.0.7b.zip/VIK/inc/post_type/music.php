<?php
function create_music() {
    $labels = array(
        'name'               => '音乐',
        'singular_name'      => '音乐',
        'add_new'            => '新增音乐',
        'add_new_item'       => '新增音乐',
        'edit_item'          => '编辑音乐',
        'new_item'           => '新音乐',
        'all_items'          => '所有音乐',
        'view_item'          => '查看音乐',
        'search_items'       => '搜索音乐',
        'not_found'          => '没有找到有关音乐',
        'not_found_in_trash' => '回收站里面没有相关音乐',
        'parent_item_colon'  => '',
        'menu_name'          => '音乐'
    );
    $args = array(
        'labels'        => $labels,
        'description'   => '我们网站的音乐信息',
        'public'        => true,
        'menu_position' => 5,
        'supports'      => array( 'title','editor'),
        'menu_icon'     => 'dashicons-format-audio',
        'has_archive'   => true
    );
    register_post_type( 'music', $args );
}
add_action( 'init', 'create_music' );
function create_music_tax() {
    $labels = array(
        'name'              =>'音乐分类',
        'singular_name'     =>'音乐分类',
        'search_items'      =>'搜索音乐分类' ,
        'all_items'         =>'所有音乐分类' ,
        'parent_item'       =>'该音乐分类的上级分类' ,
        'parent_item_colon' =>'该音乐分类的上级分类：' ,
        'edit_item'         =>'编辑音乐分类' ,
        'update_item'       =>'更新音乐分类' ,
        'add_new_item'      =>'添加新的音乐分类' ,
        'new_item_name'     =>'新音乐分类' ,
        'menu_name'         =>'音乐分类' ,
    );
    $args = array(
        'labels' => $labels,
        'hierarchical' => true,
    );
    register_taxonomy( 'music_tax', 'music', $args );
}
add_action( 'init', 'create_music_tax', 0 );