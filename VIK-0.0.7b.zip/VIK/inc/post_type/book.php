<?php
function create_book() {
    $labels = array(
        'name'               => '书籍',
        'singular_name'      => '书籍',
        'add_new'            => '新增书籍',
        'add_new_item'       => '新增书籍',
        'edit_item'          => '编辑书籍',
        'new_item'           => '新书籍',
        'all_items'          => '所有书籍',
        'view_item'          => '查看书籍',
        'search_items'       => '搜索书籍',
        'not_found'          => '没有找到有关书籍',
        'not_found_in_trash' => '回收站里面没有相关书籍',
        'parent_item_colon'  => '',
        'menu_name'          => '书籍'
    );
    $args = array(
        'labels'        => $labels,
        'description'   => '我们网站的书籍信息',
        'public'        => true,
        'menu_position' => 5,
        'supports'      => array( 'title','editor'),
        'menu_icon'     => 'dashicons-book-alt',
        'has_archive'   => true
    );
    register_post_type( 'book', $args );
}
add_action( 'init', 'create_book' );
function create_book_tax() {
    $labels = array(
        'name'              =>'书籍分类',
        'singular_name'     =>'书籍分类',
        'search_items'      =>'搜索书籍分类' ,
        'all_items'         =>'所有书籍分类' ,
        'parent_item'       =>'该书籍分类的上级分类' ,
        'parent_item_colon' =>'该书籍分类的上级分类：' ,
        'edit_item'         =>'编辑书籍分类' ,
        'update_item'       =>'更新书籍分类' ,
        'add_new_item'      =>'添加新的书籍分类' ,
        'new_item_name'     =>'新书籍分类' ,
        'menu_name'         =>'书籍分类' ,
    );
    $args = array(
        'labels' => $labels,
        'hierarchical' => true,
    );
    register_taxonomy( 'book_tax', 'book', $args );
}
add_action( 'init', 'create_book_tax', 0 );