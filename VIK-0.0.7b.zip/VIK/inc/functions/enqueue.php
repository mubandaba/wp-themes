<?php
function joytheme_enqueue_sources() {
    wp_deregister_script('jquery');
    wp_enqueue_style ( 'vik'      ,get_template_directory_uri()."/static/css/vik.css"        ,array(), false, 'all');
    wp_enqueue_style ( 'fa'        ,get_template_directory_uri()."/static/css/fa.css"          ,array(), false, 'all');
    wp_enqueue_script( 'jquery'    ,get_template_directory_uri()."/static/js/jquery.js"        ,array(), false, false);
    wp_enqueue_script( 'popper'    ,get_template_directory_uri()."/static/js/popper.min.js"    ,array(), false, true);
    wp_enqueue_script( 'bootstrap' ,get_template_directory_uri()."/static/js/bootstrap.min.js" ,array(), false, true);
    wp_enqueue_script( 'bootstrap1',get_template_directory_uri()."/static/js/bootstrap.min1.js",array(), false, true);
    wp_enqueue_script( 'me'        ,get_template_directory_uri()."/static/js/me.js"            ,array(), false, true);
    wp_enqueue_script( 'me1'       ,get_template_directory_uri()."/static/js/me1.js"           ,array(), false, true);
    wp_enqueue_script( 'perfect'   ,get_template_directory_uri()."/static/js/perfect.js"       ,array(), false, true);
    wp_enqueue_script( 'perfect1'  ,get_template_directory_uri()."/static/js/perfect1.js"      ,array(), false, true);
    wp_enqueue_script( 'icons'     ,get_template_directory_uri()."/static/js/icons.js"         ,array(), false, true);
    wp_enqueue_script( 'icons1'    ,get_template_directory_uri()."/static/js/icons1.js"        ,array(), false, true);
    wp_enqueue_script( 'vik'      ,get_template_directory_uri()."/static/js/vik.js"          ,array(), false, true);
}
add_action('wp_enqueue_scripts' , 'joytheme_enqueue_sources' , 2);
