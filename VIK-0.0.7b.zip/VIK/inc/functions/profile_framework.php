<?php
if( class_exists( 'CSF' ) ) {

    $prefix = 'vik_profile_options';

    CSF::createProfileOptions( $prefix, array(
        'data_type' => 'unserialize',
    ) );

    CSF::createSection( $prefix, array(
        'fields' => array(

            array(
                'id'    => 'user_img',
                'type'  => 'media',
                'title' => '用户头像',
                'url'   => false,
            ),

        )
    ) );

}