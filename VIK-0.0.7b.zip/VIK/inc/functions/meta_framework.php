<?php
if( class_exists( 'CSF' ) ) {
    $site_options = 'xyz_site_meta';
    $wx_options   = 'xyz_wx_meta';
    CSF::createMetabox($site_options, array(
        'title'     => '站点信息',
        'post_type' => 'site',
        'data_type' => 'unserialize',
        'theme'     => 'light',
    ));
    CSF::createSection($site_options, array(
        'title'     => '站点信息',
        'fields'    => array(
            array(
                'id'      => 'web_logo',
                'type'    => 'media',
                'title'   => 'LOGO',
                'library' => 'image',
                'url'     => false,
            ),
            array(
                'id'      => 'web_link',
                'type'    => 'text',
                'title'   => '链接',
                'desc'    => '需要带上http://或者https://',
            ),
            array(
                'id'      => 'web_desc',
                'type'    => 'textarea',
                'title'   => '简介',
            ),
        )
    ) );
    CSF::createMetabox($wx_options, array(
        'title'     => '导航设置',
        'post_type' => 'wx',
        'data_type' => 'unserialize',
        'theme'     => 'light',
    ));
    CSF::createSection($wx_options, array(
        'fields'   => array(
            array(
                'id'      => 'wx_logo',
                'type'    => 'media',
                'title'   => 'LOGO',
                'library' => 'image',
                'url'     => false,
            ),
            array(
                'id'      => 'wx_code',
                'type'    => 'media',
                'title'   => '二维码',
                'library' => 'image',
                'url'     => false,
            ),
            array(
                'id'       => 'wx_desc',
                'type'     => 'textarea',
                'title'    => '简介',
            ),
        )
    ) );
}