<?php
// 防止该文件直接被访问
if (!defined('ABSPATH')) {
    exit;
}
if ( ! function_exists( 'xyz' ) ) {
    function xyz( $option = '', $default = null ) {
        $options = get_option( 'xyz' );
        return ( isset( $options[$option] ) ) ? $options[$option] : $default;
    }
}
# 去掉“分类：”
# ------------------------------------------------------------------------------
add_filter('get_the_archive_title', function ($title) {
    if (is_category()) {
        $title = single_cat_title('', false);
    } elseif (is_tag()) {
        $title = single_tag_title('', false);
    } elseif (is_author()) {
        $title = '<span class="vcard">' . get_the_author() . '</span>';
    }
    return $title;
});
CSF::createOptions('xyz_index_seo', array(
    'framework_title'=> '首页SEO设置',
    'menu_title'     => '首页SEO设置',
    'menu_slug'      => 'xyz_index_seo',
    'menu_type'      => 'submenu',
    'menu_parent'    => 'themes.php',
    'theme'          => 'light',
));
CSF::createSection('xyz_index_seo', array(
'title'  => '首页SEO设置',
'id	'    => 'seo',
'icon'   => 'fa fa-file-text',
'fields' => array(

    array(
        'id'    => 'index_title',
        'type'  => 'text',
        'title' => '标题',
    ),
    array(
        'id'    => 'index_keywords',
        'type'  => 'text',
        'title' => '关键词',
    ),
    array(
        'id'    => 'index_description',
        'type'  => 'textarea',
        'title' => '描述',
    ),

    )
));
// 文章SEO选项
CSF::createMetabox('xyz_post_meta', array(
    'title'     => '文章选项',
    'post_type' => 'post',
    'data_type' => 'unserialize',
    'theme'     => 'light',
));
CSF::createSection('xyz_post_meta', array(
    'title'  => 'SEO设置',
    'fields' => array(

        array(
            'id'       => 'xyz_post_meta_title',
            'type'     => 'text',
            'title'    => '标题',
            'subtitle' => '留空时，以文章标题作为SEO标题',
        ),
        array(
            'id'       => 'xyz_post_meta_keywords',
            'type'     => 'text',
            'title'    => '关键词',
            'subtitle' => '留空时，以文章标题作为SEO关键词',
        ),
        array(
            'id'       => 'xyz_post_meta_description',
            'type'     => 'textarea',
            'title'    => '描述',
            'subtitle' => '如果需要尽量填写，不填则截取文章内容作为描述',
        ),

    )
));
// 页面SEO选项
CSF::createMetabox('xyz_page_meta', array(
    'title'     => '页面SEO设置',
    'post_type' => 'page',
    'data_type' => 'unserialize',
    'theme'     => 'light',
));
CSF::createSection('xyz_page_meta', array(
    'fields' => array(
        array(
            'id'    => 'xyz_page_meta_title',
            'type'  => 'text',
            'title' => '标题',
        ),
        array(
            'id'    => 'xyz_page_meta_keywords',
            'type'  => 'text',
            'title' => '关键词',
        ),
        array(
            'id'    => 'xyz_page_meta_description',
            'type'  => 'textarea',
            'title' => '描述',
        ),

    )
));
// 导航SEO选项
CSF::createSection('xyz_site_meta', array(
    'title' => 'SEO设置',
    'fields' => array(
        array(
            'id'       => 'xyz_site_meta_title',
            'type'     => 'text',
            'title'    => '标题',
            'subtitle' => '留空时，以导航标题作为SEO标题',
        ),
        array(
            'id'       => 'xyz_site_meta_keywords',
            'type'     => 'text',
            'title'    => '关键词',
            'subtitle' => '留空时，以导航标题作为SEO关键词',
        ),
        array(
            'id'       => 'xyz_site_meta_description',
            'type'     => 'textarea',
            'title'    => '描述',
            'subtitle' => '如果需要尽量填写，不填则为空',
        ),

    )
));

// 分类页SEO选项
CSF::createTaxonomyOptions('xyz_post_cat_meta', array(
    'taxonomy'  => 'category',
    'data_type' => 'unserialize',
));
CSF::createSection('xyz_post_cat_meta', array(
    'fields' => array(
        array(
            'id'    => 'xyz_post_cat_meta_title',
            'type'  => 'text',
            'title' => '标题',
        ),
        array(
            'id'    => 'xyz_post_cat_meta_keywords',
            'type'  => 'text',
            'title' => '关键词',
        ),
        array(
            'id'    => 'xyz_post_cat_meta_description',
            'type'  => 'textarea',
            'title' => '描述',
        ),

    )
));
// 站点归档页SEO选项
CSF::createOptions( 'xyz_site_archive_meta', array(
    'framework_title'=> 'SEO设置',
    'menu_title'     => 'SEO设置',
    'menu_slug'      => 'site_seo',
    'menu_type'      => 'submenu',
    'menu_parent'    => 'edit.php?post_type=site',
    'theme'          => 'light',
) );
CSF::createSection('xyz_site_archive_meta', array(
    'fields' => array(
        array(
            'id'    => 'xyz_site_archive_meta_title',
            'type'  => 'text',
            'title' => '标题',
        ),
        array(
            'id'    => 'xyz_site_archive_meta_keywords',
            'type'  => 'text',
            'title' => '关键词',
        ),
        array(
            'id'    => 'xyz_site_archive_meta_description',
            'type'  => 'textarea',
            'title' => '描述',
        ),

    )
));
// 站点分类页SEO选项
CSF::createTaxonomyOptions('xyz_site_cat_meta', array(
    'taxonomy'  => 'site_tax',
    'data_type' => 'unserialize',
));
CSF::createSection('xyz_site_cat_meta', array(
    'fields' => array(
        array(
            'id'    => 'xyz_site_cat_meta_title',
            'type'  => 'text',
            'title' => '标题',
        ),
        array(
            'id'    => 'xyz_site_cat_meta_keywords',
            'type'  => 'text',
            'title' => '关键词',
        ),
        array(
            'id'    => 'xyz_site_cat_meta_description',
            'type'  => 'textarea',
            'title' => '描述',
        ),

    )
));

// 二维码归档页SEO选项
CSF::createOptions( 'xyz_wx_archive_meta', array(
    'framework_title'=> 'SEO设置',
    'menu_title'     => 'SEO设置',
    'menu_slug'      => 'wx_seo',
    'menu_type'      => 'submenu',
    'menu_parent'    => 'edit.php?post_type=wx',
    'theme'          => 'light',
) );
CSF::createSection('xyz_wx_archive_meta', array(
    'fields' => array(
        array(
            'id'    => 'xyz_wx_archive_meta_title',
            'type'  => 'text',
            'title' => '标题',
        ),
        array(
            'id'    => 'xyz_wx_archive_meta_keywords',
            'type'  => 'text',
            'title' => '关键词',
        ),
        array(
            'id'    => 'xyz_wx_archive_meta_description',
            'type'  => 'textarea',
            'title' => '描述',
        ),

    )
));
// 二维码分类页SEO选项
CSF::createTaxonomyOptions('xyz_wx_cat_meta', array(
    'taxonomy'  => 'wx_tax',
    'data_type' => 'unserialize',
));
CSF::createSection('xyz_wx_cat_meta', array(
    'fields' => array(
        array(
            'id'    => 'xyz_wx_cat_meta_title',
            'type'  => 'text',
            'title' => '标题',
        ),
        array(
            'id'    => 'xyz_wx_cat_meta_keywords',
            'type'  => 'text',
            'title' => '关键词',
        ),
        array(
            'id'    => 'xyz_wx_cat_meta_description',
            'type'  => 'textarea',
            'title' => '描述',
        ),

    )
));
function vik_seo_title($sep = '&raquo;', $display = true, $seplocation = ''){
    $xyz_index_seo = get_option('xyz_index_seo');
    $index_title       = $xyz_index_seo['index_title'];
    $index_keywords    = $xyz_index_seo['index_keywords'];
    $index_description = $xyz_index_seo['index_description'];
    if (!$index_title) {
        $index_title = get_bloginfo('name') . '-' . get_bloginfo('description');
    }
    if (!$index_keywords) {
        $index_keywords = get_bloginfo('name') . ',' . get_bloginfo('description');
    }
    if (!$index_description) {
        $index_description = get_bloginfo('description');
    }
    // 首页
    if ((is_home() || is_front_page())) {
        $title       = $index_title;
        $keywords    = $index_keywords;
        $description = $index_description;
    }
    // 文章页
    if (is_single()) {
        
        if (get_post_type() == 'post') {
            $meta_prefix = 'xyz_post_meta';
        }
        if (get_post_type() == 'site') {
            $meta_prefix = 'xyz_site_meta';
        }
        $single_object = get_queried_object();
        $title         = get_post_meta($single_object->ID,$meta_prefix.'_title',true);
        $keywords      = get_post_meta($single_object->ID,$meta_prefix.'_keywords',true);
        $description   = get_post_meta($single_object->ID,$meta_prefix.'_description',true);
        if (!$title) {
            $title = single_post_title('', false) . '-' . get_bloginfo('name');
        }
        if (!$keywords) {
            $keywords = single_post_title('', false) . ',' . $index_keywords;
        }
        if (!$description) {
            $description = wp_trim_words($single_object->post_content, 90);
        }
    }
    //页面
    if (is_page()) {
        $single_object = get_queried_object();
        $title         = get_post_meta($single_object->ID,'xyz_page_meta_title',true);
        $keywords      = get_post_meta($single_object->ID,'xyz_page_meta_keywords',true);
        $description   = get_post_meta($single_object->ID,'xyz_page_meta_description',true);
        if (!$title) {
            $title = get_the_title() . '-' . get_bloginfo('name');
        }
        if (!$keywords) {
            $keywords = get_the_title() . ',' . $index_keywords;
        }
        if (!$description) {
            $description = wp_trim_words($single_object->post_content, 90);
        }

    }
    //归档页
    if (is_archive()) {
        $archive_object = get_queried_object();
        if (is_tax()||is_category()) {
            if (get_post_type() == 'post') {
                $title       = get_term_meta($archive_object->term_id, 'xyz_post_cat_meta_title', true);
                $keywords    = get_term_meta($archive_object->term_id, 'xyz_post_cat_meta_keywords', true);
                $description = get_term_meta($archive_object->term_id, 'xyz_post_cat_meta_description', true);
            } elseif (get_post_type() == 'site') {
                $title       = get_term_meta($archive_object->term_id, 'xyz_site_cat_meta_title', true);
                $keywords    = get_term_meta($archive_object->term_id, 'xyz_site_cat_meta_keywords', true);
                $description = get_term_meta($archive_object->term_id, 'xyz_site_cat_meta_description', true);
            }
        } else {
            if (get_post_type() == 'site') {
                $xyz_site_archive_meta = get_option('xyz_site_archive_meta');
                $title       = $xyz_site_archive_meta['xyz_site_archive_meta_title'];
                $keywords    = $xyz_site_archive_meta['xyz_site_archive_meta_keywords'];
                $description = $xyz_site_archive_meta['xyz_site_archive_meta_description'];
            }
        }
        if (!$title) {
            $title = get_the_archive_title() . '-' . get_bloginfo('name');
        }
        if (!$keywords) {
            $keywords = get_the_archive_title() . ',' . $index_keywords;
        }
        if (!$description) {
            $description = wp_trim_words(get_the_archive_description(), 90);
        }
    }

    // '月份'归档
    if (is_archive() && !empty($m)) {

        global $wp_locale;
        $my_year = substr($m, 0, 4);
        $my_month = $wp_locale->get_month(substr($m, 4, 2));
        $my_day = intval(substr($m, 6, 2));
        $title = $my_year . ($my_month ? $t_sep . $my_month : '') . ($my_day ? $t_sep . $my_day : '');
        $keywords = $index_keywords;
        $description = $index_description;
    }

    // '年份'归档
    if (is_archive() && !empty($year)) {
        $title = $year;
        if (!empty($monthnum)) {
            $title .= $t_sep . $wp_locale->get_month($monthnum);
        }
        if (!empty($day)) {
            $title .= $t_sep . zeroise($day, 2);
        }

        $keywords = $index_keywords;
        $description = $index_description;
    }

    // 搜索页面
    if (is_search()) {
        /* translators: 1: separator, 2: search phrase */
        $search = get_query_var('s');
        $title = sprintf(__('搜索：'), strip_tags($search));
        $keywords = $index_keywords;
        $description = $index_description;
    }

    // 404页面
    if (is_404()) {
        $title = '404错误！页面未找到';
        $keywords = $index_keywords;
        $description = $index_description;
    }

    echo "<title>$title</title>\r\n";
    echo "<meta name=\"keywords\" content=\"$keywords\"/>\r\n";
    echo "<meta name=\"description\" content=\"$description\"/>\r\n";
}
add_action('wp_head', 'vik_seo_title', 1);

