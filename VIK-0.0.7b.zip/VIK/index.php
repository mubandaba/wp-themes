<?php get_header();?>
<div class="app-content">
    <div class="app-content--inner bg-white">
        <?php
            $vik_customize = get_option('vik_customize');
            $index_content_groups = $vik_customize['index_content_group'];
            if ($index_content_groups){
                foreach ($index_content_groups as $guide){
                    $guide_radio = $guide['guide_radio'];
                    $web_num = $guide['index_data_num'];
                    if ($guide_radio=='wx'){
                        include 'template_parts/weixin.php';
                    }elseif($guide_radio=='post') {
                        include 'template_parts/post.php';
                    }elseif($guide_radio=='ad') {
                        include 'template_parts/ad.php';
                    }else{
                        include 'template_parts/site.php';
                    }
                }
            }
            $friend_link_groups = $vik_customize['friend_link_group'];
            if ($friend_link_groups){
                include 'template_parts/friend_link.php';
            }
        ?>
    </div>
<?php include 'template_parts/footer.php'?>
</div>
<?php get_footer();?>