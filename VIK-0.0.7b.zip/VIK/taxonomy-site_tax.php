<?php get_header();?>
    <div class="app-content">
        <div class="app-content--inner bg-white">
            <!--Site-->
            <div class="h5 mb-3 mb-lg-4">
                <div class="d-flex flex-fill algin-items-center">
                    <div class="flex-fill"><?php the_archive_title();?></div>
                    <a class="text-muted" href="<?php echo get_post_type_archive_link('site');?>">more+</a>
                </div>
            </div>
            <div class="divider my-4"></div>
            <div class="row mb-3">
                <?php
                if (have_posts() ) : while (have_posts() ) :the_post();
                    $web_id = get_the_ID();
                    $web_desc = get_post_meta($web_id,'web_desc',true);
                    $web_logo_id = get_post_meta($web_id,'web_logo',true)['id'];
                    ?>
                    <div class="col-xl-3 col-xlg-3 col-lg-4 col-sm-12 col-xmd-2 mb-4">
                        <div class="card card-box-hover-shadow site-card">
                            <a class="row no-gutters" href="<?php the_permalink();?>">
                                <div class="col-3">
                                    <img <?php xyz_src($web_logo_id);?> class="card-img" alt="..." style="width: 80px">
                                </div>
                                <div class="col-7">
                                    <div class="card-body pb-0">
                                        <h5 class="text-black" style="font-size: 0.875rem"><?php the_title()?></h5>
                                        <p class="card-text text-dark-50 d-inline-block text-truncate" style="max-width: 100%;font-size: 0.75rem">
                                            <small><?php echo $web_desc?></small>
                                        </p>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center card-hover-indicator">
                                    <i class="fa fa-chevron-circle-right"></i>
                                </div>
                            </a>
                        </div>
                    </div>
                <?php endwhile;endif;wp_reset_postdata();?>
            </div>
            <!--Site END-->
            <?php
            if ( function_exists('vik_pagination') )
                vik_pagination();
            ?>
        </div>
        <?php include 'template_parts/footer.php'?>
    </div>

<?php get_footer();?>