
<div class="col-12 d-none d-md-block p-0">
    <div class="card card-transparent mb-5">
        <?php $ad_img_id = $guide['ad_img']['id'];?>
        <a href="<?php echo $guide['ad_link'];?>" target="_blank" class="card-img-wrapper rounded">
            <?php if ($guide['badge_switcher']=='1'):?>
            <div class="card-badges card-badges-bottom">
                <span class="badge badge-neutral-dark text-dark">广告</span>
            </div>
            <?php endif;?>
            <img <?php xyz_src($ad_img_id);?> class="card-img-top rounded" alt="<?php echo $guide['ad_title'];?>">
        </a>
    </div>
</div>