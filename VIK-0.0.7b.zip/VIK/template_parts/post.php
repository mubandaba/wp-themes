<!--Post-->
<div class="h5 mb-3 mb-lg-4">
    <div class="d-flex flex-fill algin-items-center">
        <div class="flex-fill"><?php echo $guide['guide_title']?></div>
        <?php
            $post_cat = $guide['post_cat'];
            $post_cat = intval($post_cat);
            $cat_link = get_category_link($post_cat);
            $post_cat_name = get_the_category_by_ID($post_cat);
        ?>
        <a class="text-muted" href="<?php echo $cat_link?>">more+</a>
    </div>
</div>
<div class="divider my-4"></div>
<div class="row mb-3">
    <?php
        $args = array(
            'posts_per_page'=>$web_num,
            'cat' => $post_cat,
        );
        $site_query = new WP_Query( $args );
        if ( $site_query->have_posts() ) : while ( $site_query->have_posts() ) : $site_query->the_post();
        $web_id = get_the_ID();
        $author_id = get_post_field( 'post_author', $post_id );
    ?>
    <div class="col-xxl-5 col-lg-3 col-lg-post-4 col-lg-post-3 col-md-4 col-sm-6">
        <a href="<?php the_permalink();?>" class="card card-box-hover-rise mb-5" target="_blank">
            <div class="card-badges">
                <span class="badge badge-danger"><?php echo $post_cat_name?></span>
            </div>
            <img src="<?php vik_thumb('post_thumb');?>" class="card-img-top" alt="<?php the_title()?>">
            <div class="card-body card-body-avatar">
                <div class="avatar-icon-wrapper">
                    <div class="avatar-icon">
                        <img src="<?php vik_author_img($author_id);?>" alt="">
                    </div>
                </div>
                <h5 class="card-title text-black text-truncate text-nowrap"style="font-size: 0.875rem">
                    <?php the_title()?>
                </h5>
                <p class="card-text text-black text-truncate text-nowrap" style="max-width: 100%;font-size: 0.75rem">
                    <?php echo wp_trim_words(get_the_excerpt(),'100','...');?>
                </p>
                <div class="card-date mt-2">
                    <i class="fa fa-clock text-muted mr-1"></i>
                    <small class="text-muted">
                        <?php the_time('Y-m-d');?>
                    </small>
                </div>
            </div>
        </a>
    </div>
    <?php endwhile;endif;wp_reset_postdata();?>
</div>
<!--Post END-->