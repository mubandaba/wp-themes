<!--底部版权信息 免费主题，希望能尊重主题作者的劳动成果保留底部信息，感激不尽！！！-->
<div class="app-footer font-size-sm text-black-50">
    <div>
        Copyright <a href="<?php bloginfo('url');?>"><?php bloginfo('name');?></a> © <?php the_time('Y');?> Design by <a href="https://www.joytheme.com" title="JOYtheme" target="_blank">JOYtheme</a> - <?php echo get_template()?>
    </div>
</div>