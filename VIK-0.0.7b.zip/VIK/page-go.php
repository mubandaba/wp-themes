<?php
get_header();
$load_link = $_GET['url'];
$site_id = $_GET['siteID'];
$web_link = get_post_meta($site_id,'web_link',true);
if ($web_link==$load_link):?>
<script>
    window.onload = function() {
        function relocation() {
            window.location.href = "<?php echo $web_link?>";
        }
        setTimeout(relocation, <?php echo 3*1000 ?>)
    }
</script>
<?php endif;?>
<div class="app-wrapper" style="background-color: #313942">
    <div class="app-main">
        <div class="app-content p-0">
            <div class="app-content--inner p-0">
                <div class="flex-grow-1 w-100 d-flex align-items-center">
                    <div class="bg-composed-wrapper--content">
                        <div class="hero-wrapper bg-composed-wrapper min-vh-100">
                            <div class="flex-grow-1 w-100 d-flex align-items-center">
                                <div class="col-lg-6 px-4 mx-auto text-center text-black">
                                    <div class="row text-center">
                                        <div class="col-12">
                                            <img src="<?php bloginfo('template_url');?>/static/images/loader.gif" class="img-fluid rounded mb-5" style="width: 420px;height: 310px;">
                                        </div>

                                    </div>
                                    <div class="text-center text-white">
                                        正在前往<?php echo get_the_title($site_id)?>
                                    </div>
                                    <a href="<?php bloginfo('url');?>" class="btn px-5 btn-secondary mt-4 mb-3 btn-lg">
                                        <span class="btn-wrapper--label">
                                            返回首页
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php get_footer();?>



