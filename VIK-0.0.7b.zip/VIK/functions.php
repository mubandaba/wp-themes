<?php
include ('inc/functions/xyz-install.php');
if($xyz_status) {
# 支持自定义功能
# ------------------------------------------------------------------------------
add_theme_support( 'customize-selective-refresh-widgets' );
add_action( 'admin_notices', 'vik_init_check' );
function vik_init_check(){
    if (!is_plugin_active('menu-icons/menu-icons.php')){
        $html = '<div class="notice notice-warning">
                    <p>
                        <b>警告：</b> 当前主题<code>菜单图标</code>需要依赖插件 <code>Menu Icons by ThemeIsle</code> 请先安装并启用此插件
                        <a href="'.get_bloginfo('url').'/wp-admin/plugin-install.php?tab=plugin-information&amp;plugin=menu icons&amp;TB_iframe=true&amp;width=640&amp;height=500" class="thickbox">
                            立即安装？
                        </a>
                        如果您连接不到WP官方服务器，可以到 <a href="https://jq.qq.com/?_wv=1027&k=5rDuK9gp">【WordPress技术援助中心】</a>群号：923323423 群文件中下载
                    </p>
                    <button type="button" class="notice-dismiss"><span class="screen-reader-text">忽略此通知。</span></button>
                </div>';
        echo $html;
    }
}
function active_vik_notice() {
    $notice = '';
    $notice .= '<div id="setting-error-tgmpa" class="notice notice-info settings-error is-dismissible">';
    $notice .= '<p><strong><span style="display: block; margin: 0.5em 0.5em 0 0; clear: both;">通知：</b> VIK主题已激活，鉴于之前很多用户使用时都遇到了问题，请您先去';
    $notice .= '<a href="'.get_bloginfo('url').'/vik/wp-admin/index.php">仪表盘</a>仔细阅读使用说明，谢谢！';
    $notice .= '</span></strong></p>';
    $notice .= '<button type="button" class="notice-dismiss"><span class="screen-reader-text">忽略此通知。</span></button>';
    $notice .= '</div>';
    echo $notice;
}
add_action( 'after_switch_theme', 'active_vik_notice');


# 引用功能
# ------------------------------------------------------------------------------
    require_once(dirname(__FILE__) . '/inc/functions/enqueue.php');
    require_once(dirname(__FILE__) . '/inc/functions/menu.php');
    require_once(dirname(__FILE__) . '/inc/functions/meta_framework.php');
    require_once(dirname(__FILE__) . '/inc/functions/customize_framework.php');
    require_once(dirname(__FILE__) . '/inc/functions/profile_framework.php');
    require_once(dirname(__FILE__) . '/inc/functions/sidemenu_walker.php');
    require_once(dirname(__FILE__) . '/inc/functions/pagination.php');
    require_once(dirname(__FILE__) . '/inc/functions/seo.php');
    require_once(dirname(__FILE__) . '/inc/functions/site_colums.php');
    require_once(dirname(__FILE__) . '/inc/functions/wx_colums.php');
    require_once(dirname(__FILE__) . '/inc/functions/post_columns.php');
    require_once(dirname(__FILE__) . '/inc/post_type/site.php');
    require_once(dirname(__FILE__) . '/inc/post_type/wx.php');

# 支持特色图像并添加自定义裁剪尺寸
# ------------------------------------------------------------------------------
    add_theme_support('post-thumbnails');
    add_image_size('post_thumb', '270', '170', true);
    add_image_size('site_thumb', '80', '80', true);
    add_image_size('site_single', '200', '200', true);
# 自定义名称
# ------------------------------------------------------------------------------
    function xyz_archive_title($title)
    {
        if (is_category()) {
            $title = single_cat_title('', false);
        } elseif (is_tag()) {
            $title = single_tag_title('', false);
        } elseif (is_author()) {
            $title = '<span class="vcard">' . get_the_author() . '</span>';
        } elseif (is_post_type_archive()) {
            $title = post_type_archive_title('', false);
        } elseif (is_tax()) {
            $title = single_term_title('', false);
        }
        return $title;
    }

    add_filter('get_the_archive_title', 'xyz_archive_title');
    # 定义函数
# ----------------------------------------------------------------------------------------------------------------------
    if ( ! function_exists( '_vik' ) ) {
        function _vik( $option = '', $default = null ) {
            $options = get_option('vik_customize');
            return ( isset( $options[$option] ) ) ? $options[$option] : $default;
        }
    }
    if (!function_exists('_umtu_img')) {
        function _umtu_img($option = '', $default = '')
        {
            $options = get_option('umtu_framework');
            $_umtu_img_id = $options[$option]['id'];
            $_umtu_img_url = wp_get_attachment_image_url($_umtu_img_id,'full');
            return ( isset( $options[$option] ) ) ? $_umtu_img_url : $default;
        }
    }
    if (!function_exists('download_img')) {
        function download_img($post,$option, $default = '', $size='')
        {
            $option = get_post_meta($post,$option,true);
            $download_img_id = $option['id'];
            $download_img_url = wp_get_attachment_image_url($download_img_id,$size);
            return ( isset( $options[$option] ) ) ? $download_img_url : $default;
        }
    }

    if (!function_exists('_umtu_user_img')) {
        function _umtu_user_img($option, $author_id ,$default=''){
            $user_banner_id = get_user_meta($author_id,$option,true)['id'];
            $user_banner_url = wp_get_attachment_image_url($user_banner_id,'full');
            return ($user_banner_url) ? $user_banner_url : $default;
        }
    }
    if (!function_exists('vik_excerpt')) {
        function vik_excerpt($text,$num, $suffix=''){
            $vik_excerpt = wp_trim_words($text,$num,$suffix);
            return $vik_excerpt;
        }
    }
    # 获取作者头像
# ----------------------------------------------------------------------------------------------------------------------
    function vik_author_img($author_id){
        $user_img = get_user_meta($author_id,'user_img',true);
        if ($user_img['id']){
            $user_img_url = $user_img['url'];
        }
        echo $user_img_url;
    }
# 设置默认缩略图
# ----------------------------------------------------------------------------------------------------------------------
    function vik_thumb($size){
        $default_thumb = _vik('vik_thumb');
        if ($default_thumb){
            $default_thumb_id = $default_thumb['id'];
        }
        if (has_post_thumbnail()){
            $thumb_url = get_the_post_thumbnail_url('',$size);
        }elseif ($default_thumb_id){
            $thumb_url = wp_get_attachment_image_url( $default_thumb_id, $size );
        }else{
            $random = mt_rand(1, 2);
            $thumb_url = get_bloginfo('template_url').'/static/images/'.$random.'.png';
        }
        echo $thumb_url;
    }
# 输出图片
# ------------------------------------------------------------------------------
    function xyz_src($img_id = '', $size = '',$default='')
    {
        if ($img_id) {
            $img_src = wp_get_attachment_image_src($img_id, $size);
            echo 'src="' . $img_src[0] . '"';
        } elseif($default) {
            echo 'src="' . $default . '"';
        }else {
            echo 'src="' . get_template_directory_uri() . '/static/images/noimg.png"';
        }
    }
    //xyz_theme_upgrader();

    if (!function_exists('xyz_img')) {
        function xyz_img($option = '', $default = '')
        {
            $options = get_option('vik_customize'); // Attention: Set your unique id of the framework
            return ( isset( $options[$option] ) ) ? $options[$option]['url'] : $default;
        }
    }

    function joy_add_page($title, $slug, $page_template = '')
    {
        $allPages = get_pages();
        $exists = false;
        foreach ($allPages as $page) {
            if (strtolower($page->post_name) == strtolower($slug)) {
                $exists = true;
            }
        }
        if ($exists == false) {
            $new_page_id = wp_insert_post(
                array(
                    'post_title' => $title,
                    'post_type' => 'page',
                    'post_name' => $slug,
                    'comment_status' => 'closed',
                    'ping_status' => 'closed',
                    'post_content' => '',
                    'post_status' => 'publish',
                    'post_author' => 1,
                    'menu_order' => 0
                )
            );
            if ($new_page_id && $page_template != '') {
                update_post_meta($new_page_id, '_wp_page_template', $page_template);
            }
        }
    }

    function joy_add_pages()
    {
        global $pagenow;
        if ('themes.php' == $pagenow && isset($_GET['activated'])) {
            joy_add_page('跳转页面--VIK主题创建的页面不要删除也不要做任何更改', 'go', 'page-go.php');
        }
    }
    add_action('load-themes.php', 'joy_add_pages');

# 获取
# ------------------------------------------------------------------------------
    function get_page_url($slug, $type="page"){
        global $wpdb;
        if ($type == "page") {
            $url_id = $wpdb->get_var("SELECT ID FROM $wpdb->posts WHERE post_name = '".$slug."'");
            echo get_permalink($url_id);
        }else{
            $url_id = $wpdb->get_var("SELECT term_id FROM $wpdb->terms WHERE slug = '".$slug."'");
            echo get_category_link($url_id);
        }
    }

# 获取
# ------------------------------------------------------------------------------
    function custom_dashboard_help() {
        echo '鉴于之前很多用户在使用VIK主题过程中出现了相关的问题，特意添加了此模块：
                <ul>
                <li>
                    <p>更新说明：</p>
                </li>
                <li>
                    <p>1、0.0.6版本新增的文章模块，现在您可以在首页设置显示文章了</p>
                    <p>2、快速编辑特色图像功能</p>
                    <p style="color: red">3、祝大家圣诞快乐！</p>
                </li>
                <li>
                    <p>一、VIK主题的所有设置选项都在"外观-自定义"设置中实现</p>
                </li>
                <li>
                    <p>二、VIK站点导航详情页的跳转方式有两种，一种是<code>弹窗跳转</code>，另外一种是<code>页面跳转</code></p>
                </li>
                <li>
                    <p>三、这里着重说一下页面跳转，启用这种跳转方式之前，请先到<strong style="color: red">"后台-页面-所有页面"</strong>中检查一下，您的页面中是否有一个别名为"<strong style="color: red">"go"</strong>"的页面，</p>
                </li>
                    <p><strong style="color: red">注意：页面标题无所谓，别名一定要是"go"，VIK主题在启用时会自动创建该页面，但是有些小伙伴的网站可能使用了某些插件，导致页面创建不成功，需要自己手动添加</strong></p>
                <li>
                    <p>
                    四、VIK主题的菜单图标是由"Menu Icons"插件实现的，需要您自行安装，
                    如果您连接不到WP官方服务器，可以到 <a href="https://jq.qq.com/?_wv=1027&k=5rDuK9gp">【WordPress技术援助中心】</a>群号：923323423 群文件中下载
                    如果不设置菜单图标在菜单折叠时会出现菜单文字强行换行的情况，影响网站美观
                    </p>
                </li>
            </ul>
        ';
    }
    function example_add_dashboard_widgets() {
        wp_add_dashboard_widget('custom_help_widget', 'VIK主题使用说明', 'custom_dashboard_help');
    }
    add_action('wp_dashboard_setup', 'example_add_dashboard_widgets' );


    //删除仪表盘模块
    function example_remove_dashboard_widgets() {
        // Globalize the metaboxes array, this holds all the widgets for wp-admin
        global $wp_meta_boxes;
        // 以下这一行代码将删除 "快速发布" 模块
        unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_quick_press']);
        // 以下这一行代码将删除 "引入链接" 模块
        unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_incoming_links']);
        // 以下这一行代码将删除 "插件" 模块
        unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_plugins']);
        // 以下这一行代码将删除 "近期评论" 模块
        unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_recent_comments']);
        // 以下这一行代码将删除 "近期草稿" 模块
        unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_recent_drafts']);
        // 以下这一行代码将删除 "WordPress 开发日志" 模块
        unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_primary']);
        // 以下这一行代码将删除 "其它 WordPress 新闻" 模块
        unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_secondary']);
        // 以下这一行代码将删除 "概况" 模块
        unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_right_now']);
    }
    add_action('wp_dashboard_setup', 'example_remove_dashboard_widgets' );
// 以下这一行代码将删除 "welcome" 模块
    remove_action('welcome_panel', 'wp_welcome_panel');
}