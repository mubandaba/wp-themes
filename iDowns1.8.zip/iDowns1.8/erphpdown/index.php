<?php 
    //by yunsheji.cc
	echo '1';