<!-- 按钮 -->
	<section class="download-area ptb-130" style=" background: rgba(0, 0, 0, 0) url(<?php echo _DGA('footer_iconbg'); ?>) repeat scroll center center / cover; ">
			<div class="container">
				<div class="row">
					<div class="col-sm-12">
						<div class="section-heading text-center pb-45">
							<h2><?php echo _DGA('home_btntite'); ?></h2>
							<p><?php echo _DGA('home_btndesc'); ?></p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="download-option-btn text-center">
							<ul>
								<li>
									<a href="<?php echo _DGA('home_btnlink1'); ?>"><?php echo _DGA('home_btntext1'); ?>
									<a class="active" href="<?php echo _DGA('home_btnlink2'); ?>"><?php echo _DGA('home_btntext2'); ?></a>
									<a href="<?php echo _DGA('home_btnlink3'); ?>"><?php echo _DGA('home_btntext3'); ?></a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
	</section>