<?php get_header();?>
<div class="main">
	<div class="container">
		<div class="f404"><img src="<?php echo get_stylesheet_directory_uri(); ?>/static/img/404.png"><h2>404 . Not Found</h2><h3>沒有找到你要的内容！</h3><p><a class="btn btn-primary" href="<?php bloginfo('url') ?>">返回首页</a></p></div>
	</div>
</div>
<?php get_footer();?>