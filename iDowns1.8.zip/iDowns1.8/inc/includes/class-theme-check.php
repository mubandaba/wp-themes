<?php
/**
 * @package   ylit.cc
 * @author    idowns theme
 * @link      https://ylit.cc
 * @copyright 2018.10.11
 */


function theme_check_active(){
	return true;
}
function options_page_sidebar() { 
?>
	
	<aside class="options-sidebar">
		<h1>主题状态</h1>
		<ul>
			<li>会员专属开源版本</li>
			
			<li>图标参考网址和代码（去掉*号）：<a target="_bank" href="http://demo.amitjakhu.com/dripicons/">http://demo.amitjakhu.com/dripicons/</a> <br> 
			<li>VIP专属开源版，去掉所有授权机制信息，完美奔放，不限制环境，不限制域名，不限制任何，会员有权随便二开，随便卖，感谢支持！</li>
			
		</ul>
		<p style="text-align: center; "><img src="https://ylit.cc/wp-content/themes/iDowns/static/img/logo.png">

	</aside>

<?php 
} 
?>