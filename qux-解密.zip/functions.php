<?php
// themeid  请勿更改或删除，否者主题无法运行
$themeid = '2415781385155042';
// Require theme functions
require get_stylesheet_directory() . '/func/functions.php';
require get_stylesheet_directory() . '/func/functions-theme.php';
require get_stylesheet_directory() . '/func/functions-video.php';

// Customize your functions


// 代码结束
?> 