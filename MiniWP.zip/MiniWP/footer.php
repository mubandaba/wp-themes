	<div id="footer">
        <p>&copy; CopyRight: <a href="<?php echo get_option('home') ?>/" title="<?php bloginfo('name') ?>" rel="home"><?php bloginfo('name') ?></a> | <b><a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/2.5/cn/">Creative Commons Licence</a></b> | All Right Reresve.
        <br />
        <span><a class="ipower" href="http://www.happinesz.cn/archives/474/" title="Get MiniWP Theme For Your Wordpress Blog">Mini<span class="ipower">WP</span></a> themed by <a href="http://www.happinesz.cn/" title="Designer" rel="designer">sofish</a>, &amp; proudly driving by <a href="http://www.wordpress.org.cn/" title="Wordpress" rel="generator">wordpress</a>.</span>
        </p>   
    </div><!--#footer-->

<?php wp_footer(); ?>

</div><!--#wrapper-->

</body>
</html>
