<?php get_header() ?>

	<div id="container">
		<div id="content">

<?php if (have_posts()) : ?>

		<h2 class="page-title">Search Results for: <?php the_search_query() ?></h2>

<?php while ( have_posts() ) : the_post(); ?>
            
				<div id="post-<?php the_ID() ?>" class="post">
				<h2 class="entry-title"><a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title_attribute(); ?>" rel="bookmark"><?php the_title() ?></a></h2>
				<ul class="entry-info">
                	<li><?php the_time('Y-m-d'); ?></li>
					<li><?php the_category(' '); ?></li>
				</ul>
				<div class="entry-content">
                	<?php the_excerpt('Read the rest &raquo;'); ?>
				</div>
                
			</div><!-- .post -->

<?php endwhile; ?>

			<div id="navigation">
				<div class="nav-previous"><?php next_posts_link('&laquo; Older Entries') ?></div>
				<div class="nav-next"><?php previous_posts_link('Newer Entries &raquo;') ?></div>
			</div>

<?php else : ?>

			<div id="post-0" class="noresults post">
				<h2 class="entry-title">Nothing Found</h2>
				<div class="entry-content">
					<p>Sorry, but nothing matched your search criteria. I guest you may like the latest 5 posts:</p>
                    <ol>
                    <?php $my_query = new WP_Query('showposts=5');
  while ($my_query->have_posts()) : $my_query->the_post();
  $do_not_duplicate = $post->ID; ?>
                    	<li><h3><a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title_attribute(); ?>" rel="bookmark"><?php the_title() ?></a></h3></li>
                    <?php endwhile; ?>
                    </ol>
                    <p>If not, Please try again with some different keywords:</p>
				
				<form id="noresults-searchform" method="get" action="<?php bloginfo('home') ?>">
					<div>
						<input id="noresults-s" class="text-input" name="s" type="text" value="<?php the_search_query() ?>" size="40" />
						<input id="noresults-searchsubmit" class="submit-button" name="searchsubmit" type="submit" value="Find" />
					</div>
				</form>
                
                </div>
			</div><!-- .post -->

<?php endif; ?>

		</div><!-- #content -->
	</div><!-- #container -->

<?php get_sidebar() ?>
<?php get_footer() ?>