<?php get_header() ?>

	<div id="container">
		<div id="content">
        
<?php the_post() ?>

			<div id="post-<?php the_ID(); ?>" class="post">
				<h2 class="entry-title"><?php the_title(); ?></h2>
                <ul class="entry-info">
                <li><?php the_time('Y-m-d'); ?></li>
                <li><a href="<?php trackback_url(); ?>/" title="Trackback URL for your post" rel="trackback">Trackback URL</a></li>
                <li><?php the_category(' '); ?></li>
                
                <?php edit_post_link('<li>Edit</li>'); ?>
                </ul>
				<div class="entry-content">
					<?php the_content(); ?>
				</div>
                
				<div class="entry-meta">
                <?php the_tags('Tagged: ',' | ',''); ?>
				</div>
                
			</div><!-- .post -->

<?php comments_template(); ?>

		</div><!-- #content -->
	</div><!-- #container -->

<?php get_sidebar() ?>
<?php get_footer() ?>