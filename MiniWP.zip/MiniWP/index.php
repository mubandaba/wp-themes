<?php get_header(); ?>

	<div id="container">
    	<div id="content">
        
        <?php if (have_posts()) : ?>
        	
            <?php while (have_posts()) : the_post(); ?>
        	<div id="post-<?php the_ID(); ?>" class="post">
            	
                <h2 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark" title="Permanent Links to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
                
                <ul class="entry-info">
                	<li><?php the_time('Y-m-d'); ?></li>
					<li><?php the_author_posts_link(); ?></li>
					<li><?php comments_popup_link('No Comment','One Comment','% Comments'); ?></li>
					<?php edit_post_link('<li>Edit</li>'); ?>
				</ul>
                
                <div class="entry-content"><?php the_content('Continue Reading &raquo;'); ?></div>
                
            </div><!--.post-->
        	<?php endwhile; ?>
            
            <div class="navigation">
            	<div class="alignleft"><?php next_posts_link('&laquo; Older Entries'); ?></div>
                <div class="alignright"><?php previous_posts_link('Newer Entries &raquo;'); ?></div>
            </div>
            
		<?php else : ?>
            
            	<h2 class="entry-title">Not Found</h2>
            	<p>Sorry, but what you are looking for isn't here...</p>
            	<?php include (TEMPLATEPATH . "/searchform.php"); ?>
            
        <?php endif; ?>    
        </div><!--#content-->
    </div><!--#container-->
    
<?php get_sidebar(); ?>
<?php get_footer(); ?>
