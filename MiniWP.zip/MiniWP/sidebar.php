<div id="sidebar" class="sidebar">

		<h4>Search</h4>
		<form id="searchform" method="get" action="<?php bloginfo('home') ?>">
                    <div>
                    <input id="s" name="s" class="text-input" type="text" value="<?php the_search_query() ?>" size="10" tabindex="1" accesskey="S" />
                    <input id="searchsubmit" class="submit-button" name="searchsubmit" type="submit" value="<?php _e('Find', 'sandbox') ?>" tabindex="2" />
                    </div>
        </form>

		<ul>
<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar(1) ) : // begin sidebar widgets ?>

    		<li id="pages">
				<h4>Pages</h4>
				<ul>
<?php wp_list_pages('title_li=&sort_column=post_title' ) ?>
				</ul>
			</li>

			<li id="categories">
				<h4>Categories</h4>
				<ul>
<?php wp_list_categories('title_li=&show_count=0&hierarchical=1') ?> 

				</ul>
			</li>
            
            <li id="archives">
				<h4>Archives</h4>
				<ul>
<?php wp_get_archives('type=monthly') ?>

				</ul>
			</li>

			<li id="rss-links">
				<h4>RSS Feeds</h4>
				<ul>
					<li><a href="<?php bloginfo('rss2_url') ?>" title="<?php echo wp_specialchars(bloginfo('name'), 1) ?> Posts RSS feed" rel="alternate" type="application/rss+xml">All posts</a></li>
					<li><a href="<?php bloginfo('comments_rss2_url') ?>" title="<?php echo wp_specialchars(bloginfo('name'), 1) ?> Comments RSS feed" rel="alternate" type="application/rss+xml">All comments</a></li>
				</ul>
			</li>

			<li id="meta">
				<h4>博主工具</h4>
				<ul>
					<?php wp_register() ?>
					<li><?php wp_loginout() ?></li>
					<?php wp_meta() ?>
				</ul>
			</li>
		
<?php endif; // end sidebar widgets  ?>
		</ul>
		
</div> <!-- #sidebar .sidebar -->