<?php get_header() ?>
	
	<div id="container">
		<div id="content">
	<h2 class="page-title">Tag Archives: <?php single_tag_title(); ?></h2>

<?php while (have_posts()) : the_post(); ?>

			<div id="post-<?php the_ID() ?>" class="post">
				<h2 class="entry-title"><a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title_attribute(); ?>" rel="bookmark"><?php the_title() ?></a></h2>
				<ul class="entry-info">
                	<li><?php the_time('Y-m-d'); ?></li>
					<li><?php the_author_posts_link(); ?></li>
				</ul>
				<div class="entry-content">
                	<?php the_excerpt('Read the rest &raquo;'); ?>
				</div>
                
			</div><!-- .post -->

<?php endwhile; ?>

			<div class="navigation">
            	<div class="alignleft"><?php next_posts_link('&laquo; Older Entries'); ?></div>
                <div class="alignright"><?php previous_posts_link('Newer Entries &raquo;'); ?></div>
            </div>

		</div><!-- #content -->
	</div><!-- #container -->

<?php get_sidebar() ?>
<?php get_footer() ?>