<?php get_header() ?>

	<div id="container">
		<div id="content">
        
       <?php the_post() ?>

			<div id="post-0" class="post">
				<h2 class="entry-title"><?php the_title(); ?></h2>
				<div class="entry-content">
                	<p>Apologies, but we were unable to find what you were looking for. I guest you may like the latest 5 posts:</p>
                    <ol>
                    <?php $my_query = new WP_Query('showposts=5');
  while ($my_query->have_posts()) : $my_query->the_post();
  $do_not_duplicate = $post->ID; ?>
                    	<li><h3><a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title_attribute(); ?>" rel="bookmark"><?php the_title() ?></a></h3></li>
                    <?php endwhile; ?>
                    </ol>
                    <p>If not, Perhaps searching will help:</p>
				
				<form id="noresults-searchform" method="get" action="<?php bloginfo('home') ?>">
					<div>
						<input id="noresults-s" class="text-input" name="s" type="text" value="<?php the_search_query() ?>" size="40" />
						<input id="noresults-searchsubmit" class="submit-button" name="searchsubmit" type="submit" value="Find" />
					</div>
				</form>
                
				</div>
			</div><!-- .post -->

		</div><!-- #content -->
	</div><!-- #container -->

<?php get_sidebar() ?>
<?php get_footer() ?>