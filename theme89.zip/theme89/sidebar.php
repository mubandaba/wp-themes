<div class="sidebar">
	<div id="sidebar_top">
        <div class="rss">
			<a href="<?php bloginfo('rss_url'); ?>"><img src="<?php bloginfo('template_url'); ?>/images/rss.png" alt="RSS Feeds" align="absmiddle" />&nbsp;&nbsp;Subscribe via RSS&nbsp;</a>
		</div>
		<div class="email">
			<a href="#">- Subscribe via Email</a>
		</div>
		<div id="clear"></div>
	</div>
	<div id="menu">
		<ul>
            <li class="page_item <? if(is_home()) echo 'current_page_item'; ?>">
                <a href="<? bloginfo('url'); ?>" title="Home">Home</a>
            </li>
            <?php
            	wp_list_pages( array ('title_li'=>'', 'depth'=>1));
            ?>
        </ul>
		<div id="clear"></div>
	</div>
    <ul>
    	<div class="sidebarads">
			<div class="ads" style="padding-right:11px">
				<a href="#"><img src="<?php bloginfo('template_url'); ?>/images/bg_ads.gif" alt="Advertising" /></a>
			</div>
			<div class="ads">
				<a href="#"><img src="<?php bloginfo('template_url'); ?>/images/bg_ads1.gif" alt="Advertising" /></a>
			</div>
			<div id="clear"></div>
		</div>
    	<?php
        if (function_exists('dynamic_sidebar') && dynamic_sidebar()):
            else :
        ?>
        <li>
            <h2>
                <?php
                _e('Categories');
                ?>
            </h2>
            <ul>
                <?php
                wp_list_cats('sort_column=name&hierarchical=0');
                ?>
            </ul>
        </li>
		<li>
        	<h2>tags</h2>
            <ul>
                <?php
                	/*wp_cumulus_insert();*/
                ?>
            </ul>
        </li>
		<li>
            <h2>
                <?php
                _e('Archives');
                ?>
            </h2>
            <ul>
                <?php
                wp_get_archives('type=monthly');
                ?>
            </ul>
        </li>
        <?php
        endif;
        ?>
    </ul>
</div>
