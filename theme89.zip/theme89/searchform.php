<form method="get" id="searchform" action="<?php bloginfo('home'); ?>/">
	<div>
		<input class="search" type="text" value="Search Blog" onfocus="if (this.value == 'Search Blog') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Search Blog';}" name="s" id="s" />
		<input class="search_btn" type="submit" id="searchsubmit" value="" />
	</div>
</form>