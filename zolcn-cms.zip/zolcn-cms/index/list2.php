<div class="in_same">
 <div class="in_clumn_2">
 <strong>分类一</strong>
 </div>    <div class="late_con">                    
            <ul>
                                              <?php
/**
* 修改cat=1为你想要的分类ID如分类2就是$rand_posts = get_posts('numberposts=12&orderby=new&cat=2');
*/
$rand_posts = get_posts('numberposts=12&orderby=new&cat=1');
foreach( $rand_posts as $post ) :
?>
<li><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></li>
<?php endforeach; ?>
                            </ul>
            </div>
        </div>               