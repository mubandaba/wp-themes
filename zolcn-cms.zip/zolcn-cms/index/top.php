<div id="featured">

                                                                    <div class="image" id="image_xixi-01"><a href="<?php echo get_option('mytheme_hdurl1'); ?>"><img width="665" height="300" src="<?php echo get_option('mytheme_hd1'); ?>" class="attachment-slider-big wp-post-image"/></a><div class="word"><?php echo get_option('mytheme_hdbt1'); ?></div></div>

                                                                      <div class="image" id="image_xixi-02"><a href="<?php echo get_option('mytheme_hdurl2'); ?>"><img width="665" height="300" src="<?php echo get_option('mytheme_hd2'); ?>" class="attachment-slider-big wp-post-image"/></a><div class="word"><?php echo get_option('mytheme_hdbt2'); ?></div></div>

                                                                      <div class="image" id="image_xixi-03"><a href="<?php echo get_option('mytheme_hdurl3'); ?>"><img width="665" height="300" src="<?php echo get_option('mytheme_hd3'); ?>" class="attachment-slider-big wp-post-image"/></a><div class="word"><?php echo get_option('mytheme_hdbt3'); ?></div></div>

                                                    

                </div> 
				  <div>

            <div id="thumbs">

              <ul>

              

                                                                <li class="slideshowItem"><a id="thumb_xixi-01" href="#image_xixi-01"><img width="665" height="300" src="<?php echo get_option('mytheme_hd1'); ?>" class="attachment-slider-small wp-post-image"/></a></li>

                                                                     <li class="slideshowItem"><a id="thumb_xixi-02" href="#image_xixi-01"><img width="665" height="300" src="<?php echo get_option('mytheme_hd2'); ?>" class="attachment-slider-small wp-post-image"/></a></li>

                                                                     <li class="slideshowItem"><a id="thumb_xixi-03" href="#image_xixi-01"><img width="665" height="300" src="<?php echo get_option('mytheme_hd3'); ?>" class="attachment-slider-small wp-post-image"/></a></li>

                                                     

               

              </ul>

            </div>

        </div>

      </div>

     </div>