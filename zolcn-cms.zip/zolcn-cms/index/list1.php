     <div class="in_box_1">

          <div class="hot_news">

            <div class="in_clumn_2"><strong>随机资讯</strong></div>

            <div class="late_con">

              <ul>
    <?php
$rand_posts = get_posts('numberposts=9&orderby=rand');
foreach( $rand_posts as $post ) :
?>
<li><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></li>
<?php endforeach; ?>

                               </ul>

            </div>

          </div>

          <div class="late">

            <div class="in_clumn_2"><strong>最新资讯</strong></div>

            <div class="late_con">

              <ul>

              <?php
$rand_posts = get_posts('numberposts=9&orderby=new');
foreach( $rand_posts as $post ) :
?>
<li><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></li>
<?php endforeach; ?>
            </div>

          </div>

        </div>