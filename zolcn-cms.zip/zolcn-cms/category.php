<?php include TEMPLATEPATH. '/header_fy.php'; ?>
<div class="container">
    <img src="<?php bloginfo('template_url'); ?>/img/wra_archive_2.gif" class="fl">
    <div class="archive_content">
      <div class="archive_content_L">
        <div class="nowPosition"><a href="<?php bloginfo('home'); ?>"><?php bloginfo('name'); ?></a> &raquo; <span class="current"><?php echo(get_category_parents($cat, TRUE, ' ')); ?></span></div>                
		<?php if (have_posts()) : ?>
	<?php while (have_posts()) : the_post(); ?>
        <div class="archive_list_1">
          <ul>
<li>
              <h2><a href="<?php the_permalink() ?>" title="<?php the_title() ?>"><?php the_title() ?></a></h2>
			   <p class="archive_tools"><img src="<?php bloginfo('template_url'); ?>/images/archive_tools_3.gif"><?php the_time('Y - m - d') ?></p>
              <p class="archive_list_word">
                              <a href="<?php the_permalink() ?>"><img width="72" height="62" src="http://www.qiyouc.com/wp-content/uploads/2012/06/三亚_副本-72x62.jpg" class="attachment-post wp-post-image" alt="三亚_副本" title="三亚_副本" /></a>
                              <span><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 400,"……"); ?></span>
              </p>
              <em><a href="<?php the_permalink() ?>" target="_blank">阅读全部</a></em>
 </li>







          </ul>
        </div><?php endwhile; ?>
        <div class="paging_1">
           <?php wp_pagenavi(); ?></div>
      </div><?php endif ?>
<?php include TEMPLATEPATH. '/sidebar_ny.php'; ?>
    </div>
	
   
  <?php get_footer(); ?>