<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/style.css" type="text/css" media="screen" />
<script type="text/javascript" src="http://lib.sinaapp.com/js/jquery/1.4.4/jquery.min.js"></script>
<script src="<?php bloginfo('template_url'); ?>/slide.js" type="text/javascript"></script>
<script type='text/javascript' src='http://lib.sinaapp.com/js/jquery/1.7.2/jquery.min.js'></script>
<script type='text/javascript' src='http://static.duoshuo.com/embed.js'></script>
<title><?php if (is_single() || is_page() || is_archive()) { ?><?php wp_title('—',true,'right'); ?><?php } bloginfo('name'); ?><?php if ( $paged < 2 ) {} else { echo (' - 页面 '); echo ($paged);}?></title>
<?php
if (is_category()) {
    $description = category_description();
    $keywords = single_cat_title('', false);
} elseif (is_tag()){
    $description = tag_description();
    $keywords = single_tag_title('', false);
}
$description = trim(strip_tags($description));
$keywords = trim(strip_tags($keywords));
?>
<?php if(is_category()&&!is_paged()) { ?>
<meta content="<?php echo $description; ?>" name="Description"/>
<meta content="<?php echo $keywords; ?>" name="Keywords"/>
<?php } ?>
</head>



<body class="home blog">

<!--屏蔽-->

<div id="block"></div>


  <!--Header-->

  <div id="header">

   <div class="wrapper">

    <h1 id="logo"><a href="<?php bloginfo('home'); ?>"></a></h1>

        <div id="topbanner"> <?php if (get_option('mytheme_ad1')!="") {?>
 
<?php echo stripslashes(get_option('mytheme_ad1')); ?>
<?php }?></div>

        <!--top right-->

    <div id="topright">

      <div id="mini-nav">

        <p>

                <span class="login"><a href="http://www.zolcn.net/">首页</a></span>

        <span class="signup"><a href="<?php bloginfo('home'); ?>/wp-login.php">登录</a></span>

        <span class="rss"><a href="<?php bloginfo('home'); ?>/feed">RSS</a></span>

                </p>

      </div>

 

<div id="hd-sr">

<form action="http://www.baidu.com/baidu">

<input type=text name=word>

<input type="submit" value="站内搜索">

<input name=tn type=hidden value="bds">

<input name=cl type=hidden value="3">

<input name=ct type=hidden value="2097152">

<input name=si type=hidden value="<?php bloginfo('home'); ?>">

</form>

</div>

    </div> 

    <!--end top right-->

    <div class="clear"></div>

    

   <!--Navigation-->

   <div id="nav_container">

    <div id="nav" class="menu-%e9%aa%91%e6%b8%b8%e5%85%ac%e7%a4%be-container">
	<ul id="menu-%e9%aa%91%e6%b8%b8%e5%85%ac%e7%a4%be" class="menu">
<?php wp_nav_menu( array( 'container_class' => 'menu-header', 'theme_location' => 'primary' ) ); ?>

</ul></div>    
<div id="nav2" class="menu-%e5%8f%b3%e5%af%bc%e8%88%aa-container"><ul id="menu-%e5%8f%b3%e5%af%bc%e8%88%aa" class="menu">
<li id="menu-item" class="magazine menu-item menu-item-type-post_type menu-item-object-page menu-item"><a href="http://www.zolcn.net/wordpress/zhuti/">主题下载</a></li>
<li id="menu-item" class="events menu-item menu-item-type-taxonomy menu-item-object-events menu-item"><a href="http://www.zolcn.net/wordpress/chajian/">插件下载</a></li>
<li id="menu-item-745" class="submit menu-item menu-item-type-post_type menu-item-object-page menu-item"><a href="http://www.zolcn.net/wordpress/">教程</a></li>
</ul></div>    </div> 

  

   </div>

  </div>