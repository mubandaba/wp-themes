<?php
add_action('admin_menu', 'mytheme_page');
 
function mytheme_page (){
 
	if ( count($_POST) > 0 && isset($_POST['mytheme_settings']) ){
 
		$options = array ('keywords','description','analytics','hd1','hd2','hd3','ad1','ad2','ad3','hdurl1','hdurl2','hdurl3','hdbt1','hdbt2','hdbt3','weibo','douban','renren');
 
		foreach ( $options as $opt ){
 
			delete_option ( 'mytheme_'.$opt, $_POST[$opt] );
 
			add_option ( 'mytheme_'.$opt, $_POST[$opt] );	
 
		}
 
	}
 
	add_theme_page(__('zolcn-cms主题设置'), __('zolcn-cms主题设置'), 'edit_themes', basename(__FILE__), 'mytheme_settings');
 
}
 
function mytheme_settings(){?>
 

 
<div class="wrap">
 
<h2>zolcn-cms主题选项</h2>
 
<form method="post" action="">
 
	<fieldset>
 
 
		<table class="form-table">
 <legend><strong>首页关键词</strong></legend>
			<tr><td>
 
				<textarea name="keywords" id="keywords" rows="1" cols="70"><?php echo get_option('mytheme_keywords'); ?></textarea><br />
 
				<p>网站首页关键词（Meta Keywords），多个关键词请用中间用半角逗号隔开。如：zolcn,zol站长网</p>
 
			</td></tr>
 
			<tr><td>
 <legend><strong>首页描述</strong></legend>
				<textarea name="description" id="description" rows="3" cols="70"><?php echo get_option('mytheme_description'); ?></textarea>
 
				<p>网站描述（Meta Description），针对搜索引擎设置的网页描述。如：zol站长网，致力于为广大站长提供最详细的建站知识库，海量的建站资源，最新的seo理念。</p>
 
			</td></tr>
 
		</table>
 
	</fieldset>
 
 
 
	<fieldset>
 
	<legend><strong>统计代码添加</strong></legend>
 
		<table class="form-table">
 
			<tr><td>
 
				<textarea name="analytics" id="analytics" rows="5" cols="70"><?php echo stripslashes(get_option('mytheme_analytics')); ?></textarea>
 
			</td></tr>
 
		</table>
 
	</fieldset>
	 <hr/>
<fieldset>
<legend><strong>首页列表幻灯片设置</strong></legend>
 
		<table class="form-table">
 
			<tr><td>
 
				<strong>图片1网址：</strong><textarea name="hd1" id="hd1" rows="1" cols="50"><?php echo stripslashes(get_option('mytheme_hd1')); ?></textarea>
				<strong>图片1超链接：</strong><textarea name="hdurl1" id="hdurl1" rows="1" cols="50"><?php echo stripslashes(get_option('mytheme_hdurl1')); ?></textarea>
				<strong>图片1标题：</strong><textarea name="hdbt1" id="hdbt1" rows="1" cols="50"><?php echo stripslashes(get_option('mytheme_hdbt1')); ?></textarea>
 
			</td></tr>
			<tr><td>
 <strong>图片2网址：</strong><textarea name="hd2" id="hd2" rows="1" cols="50"><?php echo stripslashes(get_option('mytheme_hd2')); ?></textarea>
 <strong>图片2超链接：</strong><textarea name="hdurl2" id="hdurl2" rows="1" cols="50"><?php echo stripslashes(get_option('mytheme_hdurl2')); ?></textarea>
 <strong>图片2标题：</strong><textarea name="hdbt2" id="hdbt2" rows="1" cols="50"><?php echo stripslashes(get_option('mytheme_hdbt2')); ?></textarea>
 </td></tr>
 <tr><td>
				<strong>图片3网址：</strong><textarea name="hd3" id="hd3" rows="1" cols="50"><?php echo stripslashes(get_option('mytheme_hd3')); ?></textarea>
				<strong>图片3超链接：</strong><textarea name="hdurl3" id="hdurl3" rows="1" cols="50"><?php echo stripslashes(get_option('mytheme_hdurl3')); ?></textarea>
				<strong>图片3标题：</strong><textarea name="hdbt3" id="hdbt3" rows="1" cols="50"><?php echo stripslashes(get_option('mytheme_hdbt3')); ?></textarea>
				 </td></tr>
		</table>
 
	</fieldset>
	<hr/>
<fieldset>
<legend><strong>主题预留广告位</strong></legend>
 
		<table class="form-table">
 
			<tr><td>
 
				<strong>顶部496*74广告位：</strong><textarea name="ad1" id="ad1" rows="5" cols="50"><?php echo stripslashes(get_option('mytheme_ad1')); ?></textarea>
				<strong>边栏250*250广告位：</strong><textarea name="ad2" id="ad2" rows="5" cols="50"><?php echo stripslashes(get_option('mytheme_ad2')); ?></textarea>
				<strong>边栏250*300广告位：</strong><textarea name="ad3" id="ad3" rows="5" cols="50"><?php echo stripslashes(get_option('mytheme_ad3')); ?></textarea>
 
			</td></tr>
			<tr><td>
	</table>
 
	</fieldset>
	<hr/>
		<fieldset>

	<legend><strong>微博</strong></legend>
 
		<table class="form-table">
 
			<tr><td>
 
				<strong>新浪微博网址：</strong><textarea name="weibo" id="weibo" rows="1" cols="50"><?php echo stripslashes(get_option('mytheme_weibo')); ?></textarea>
 
			</td></tr>
 
 


	
 
			<tr><td>
 
				<strong>豆瓣主页网址：</strong><textarea name="douban" id="douban" rows="1" cols="50"><?php echo stripslashes(get_option('mytheme_douban')); ?></textarea>
			
 
			</td></tr>
 
<tr><td>

 
				<strong>人人小站网址：</strong><textarea name="renren" id="renren" rows="1" cols="50"><?php echo stripslashes(get_option('mytheme_renren')); ?></textarea>
 
			</td></tr>
 
		</table>
 
	</fieldset>
	
	<hr/>
	<p class="submit">
 
		<input type="submit" name="Submit" class="button-primary" value="保存设置" />
 
		<input type="hidden" name="mytheme_settings" value="save" style="display:none;" />
 
	</p>
 
 
 
</form>
 
</div>
 
<?php }
?>