<!--Footer-->
  <div id="footer">
    <div class="wrapper">
    <div id="footer-widget">
       <div class="widget"><h4>关于我们</h4><div class="menu-%e5%85%b3%e4%ba%8e%e6%88%91%e4%bb%ac-container"><ul id="menu-%e5%85%b3%e4%ba%8e%e6%88%91%e4%bb%ac" class="menu">
	   <li><a href="#">关于我们</a></li>
<li><a href="#">联系我们</a></li>
</ul></div></div><div class="widget"><h4>菜单</h4><div><?php wp_nav_menu( array( 'container_class' => 'menu-header', 'theme_location' => 'primary' ) ); ?>
</ul></div></div><div class="widget"><h4>加入我们</h4><div><ul><li><a href="http://www.zolcn.net/qun.html">官方QQ群</a></li>
<li><a href="#">投稿</a></li>
</ul></div></div><div class="widget"><h4>友情链接</h4><div><ul>
<li><a href="http://wordpress.org">wordpress</a></li>
<li><a href="http://www.zolcn.net/">站长网</a></li>
<li><a href="http://www.zolcn.net/wordpress/zhuti/">wordpress模板主题</a></li>
<li><a href="http://www.zolcn.net/wordpress/chajian/">wordpress插件</a></li>
</ul></div></div>      
    </div>
    <div id="copyright"><!-- 尊重作者请勿修改版权 -->
      <p>
      Theme by <a href="http://www.zolcn.net/">站长网</a>  2011 www.zolcn.net All Rights Reserved </p>
    </div>
    </div>
  </div>

<SCRIPT type=text/javascript>
var target = ["xixi-01","xixi-02","xixi-03","xixi-04","xixi-05","xixi-06","xixi-07"];

function DY_scroll(wraper,prev,next,img,speed,or)
	{	
		var wraper = $(wraper);
		var prev = $(prev);
		var next = $(next);
		var img = $(img).find('ul');
		var w = img.find('li').outerWidth(true);
		var s = speed;
		next.click(function()
							{
								img.animate({'margin-left':-w},function()
																		{
																			img.find('li').eq(0).appendTo(img);
																			img.css({'margin-left':0});
																			});
								});
		prev.click(function()
							{
								img.find('li:last').prependTo(img);
								img.css({'margin-left':-w});
								img.animate({'margin-left':0});
								});
		if (or == true)
		{
			ad = setInterval(function() { next.click();},s*1000);
			wraper.hover(function(){clearInterval(ad);},function(){ad = setInterval(function() { next.click();},s*1000);});
		}
	}
	DY_scroll('.img-scroll','.prev','.next','.img-list',3,false);// 首页图片轮播，true为自动播放，不加此参数或false就默认不自动。
</script>
<?php if (get_option('mytheme_analytics')!="") {?>
 
<?php echo stripslashes(get_option('mytheme_analytics')); ?>
<?php }?>
</body>
</html>