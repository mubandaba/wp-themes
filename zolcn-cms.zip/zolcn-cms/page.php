<?php include TEMPLATEPATH. '/header_ny.php'; ?>
<div class="container">

    <img src="<?php bloginfo('template_url'); ?>/img/wra_archive_2.gif" class="fl">

    <div class="archive_content">
	<?php if (have_posts()) : ?>
	<?php while (have_posts()) : the_post(); ?>
      <div class="archive_content_L">

        <div class="nowPosition"><a href="<?php bloginfo('home'); ?>"><?php bloginfo('name'); ?></a> &raquo; <?php the_category(', ') ?> &raquo; <span class="current"><?php the_title(); ?></span></div>        <div class="single_box">

               <div class="single_1">

          <h2><?php the_title(); ?></h2>

          <p> <span>发表于<?php the_time('Y - m - d') ?></span><span>分类：<?php the_category(', ') ?></span></p>

        </div>

        <div class="single_2"><?php the_content(); ?>
</div>

            <div class="single_3">

      

<div id="ckepop">

	<span class="jiathis_txt">分享到：</span>

	<a class="jiathis_button_icons_1"></a>

	<a class="jiathis_button_icons_2"></a>

	<a class="jiathis_button_icons_3"></a>

	<a class="jiathis_button_icons_4"></a>

	<a href="http://www.jiathis.com/share" class="jiathis jiathis_txt jtico jtico_jiathis" target="_blank"></a>

	<a class="jiathis_counter_style"></a>

</div>

<script type="text/javascript" src="http://v2.jiathis.com/code/jia.js" charset="utf-8"></script>

<?php $key="title"; echo get_post_meta($post->ID, $key, true); ?>

      </div>

		<div id="ds-ssr">

		<?php endwhile; ?>
      <?php comments_template(); ?>

		            
    </div>      </div><?php endif ?>

      </div>
	  <?php include TEMPLATEPATH. '/sidebar_ny.php'; ?>
    </div>
	
   
  <?php get_footer(); ?>
