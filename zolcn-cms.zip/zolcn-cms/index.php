<?php get_header();?>


  <div class="container">

    <img src="<?php bloginfo('template_url'); ?>/images/wra_archive_2.gif" class="fl">

    <div class="archive_content">

      <div class="archive_content_in_L">

              <div id="topstory">

            <div id="highlight" class="in_ad_2">

                <?php include TEMPLATEPATH. '/index/top.php'; ?>

          

         <?php include TEMPLATEPATH. '/index/new.php'; ?>


      
<?php include TEMPLATEPATH. '/index/list1.php'; ?>
               

   

                  <div class="in_ad_3"> <a href="http://www.zolcn.net" target="_blank"><img src="<?php bloginfo('template_url'); ?>/img/222222.jpg" alt="" border="0" style="width:667px;height:93px" /></a></a></div>


<?php include TEMPLATEPATH. '/index/list2.php'; ?>

<?php include TEMPLATEPATH. '/index/list3.php'; ?>
<?php include TEMPLATEPATH. '/index/list4.php'; ?>
<?php include TEMPLATEPATH. '/index/list5.php'; ?>

<?php get_sidebar(); ?>
  
<?php get_footer(); ?>