<?php if ( get_post_meta($post->ID, '_mcf_short-text', true) ) : ?>
<?php $title = get_post_meta($post->ID, '_mcf_short-text', true); ?>
<title><?php $key="_mcf_short-text"; echo get_post_meta($post->ID, $key, true); ?></title>
<?php else: ?>
<title><?php if (is_single() || is_page() || is_archive()) { ?><?php wp_title('—',true,'right'); ?><?php } bloginfo('name'); ?><?php if(is_singular() ) {
if(strpos( $post->post_content, '<!--nextpage-->' )) {
setup_postdata($post);
global $numpages;
echo ' - 第' . $page.'页'; } //此处文字可以修改成你喜欢的格式
} ?></title>
<?php endif; ?>
<?php if ( get_post_meta($post->ID, '_mcf_checkbox', true) ) : ?>
<?php $meta = get_post_meta($post->ID, '_mcf_checkbox', true); ?>
<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
<?php else: ?>
<meta name="模板作者" "http://www.zolcn.net"/>
<?php endif; ?>