<?php
//Gzip压缩
function dtheme_gzip() {
if ( strstr($_SERVER['REQUEST_URI'], '/js/tinymce') )
return false;
if ( ( ini_get('zlib.output_compression') == 'On' || ini_get('zlib.output_compression_level') > 0 ) || ini_get('output_handler') == 'ob_gzhandler' )
return false;
if (extension_loaded('zlib') && !ob_start('ob_gzhandler'))
ob_start();
}
add_action('init','dtheme_gzip');


function disable_our_feeds() {
wp_die( __('<strong>Error:</strong> No RSS Feed Available, Please visit our homepage.') );
}
/**
* 菜单
*/ 
if(function_exists('register_nav_menus')){
register_nav_menus( array(
'primary' => __( 'Primary Navigation', 'twentyten' ),
'second' => __( 'second Navigation', 'twentyten' ),
) );
}
/**标签云**/
function colorCloud($text) { 
$text = preg_replace_callback('|<a (.+?)>|i', 'colorCloudCallback', $text);
return $text;
} 
function colorCloudCallback($matches) { 
$text = $matches[1];
$color = dechex(rand(0,16777215));
$pattern = '/style=(\'|\")(.*)(\'|\")/i';
$text = preg_replace($pattern, "style=\"color:#{$color};$2;\"", $text);
return "<a $text>";
}
?>
<?php require_once(TEMPLATEPATH . '/admin/admin.php');?>
<?php require_once(TEMPLATEPATH . '/admin/seo.php');?>
<?php require_once(TEMPLATEPATH . '/admin/til.php');?>