<?php get_header();?>


		<div class="mainleft">
			<ul id="post_container" class="masonry clearfix">
				<?php include('includes/list_post.php'); ?>
			</ul>
			<div class="clear"></div>
			<?php if (get_option('loocol_scrolladd') == 'Display') { ?>
			<div class="navigation container" id="ajax-load-posts"><?php next_posts_link(__('LOAD MORE'));?></div>
			<?php }else{?>
			<div class="navigation container"><?php pagination(5);?></div>
			<?php }?>
		</div>
			<?php get_sidebar();?>
	</div>

<div class="clear"></div>

<?php get_footer(); ?>