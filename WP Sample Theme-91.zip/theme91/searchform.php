<form method="get" id="searchform" action="<?php bloginfo('home'); ?>/">
<div>
<span>Search Blog...</span><input class="search" type="text" value="Search..." onfocus="if (this.value == 'Search...') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Search...';}" name="s" id="s" size="30" /><input class="submit" type="submit" id="searchsubmit" value="" />
</div>
</form>