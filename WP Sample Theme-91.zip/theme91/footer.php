<div id="footer">		
	<div class="designby">
		Designed by <a href="http://www.free-css-templates.com/">Free WordPress Themes</a>, Thanks to <a href="http://www.rentdubai.com">Dubai Rentals</a>
	</div>
	<?php wp_footer(); ?>
</div>