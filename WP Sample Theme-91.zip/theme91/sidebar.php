<div id="sidebar" class="sidebar">
<ul>
<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar() ) : else : ?>
		<li class="odd" id="sidecat">
			<h2><?php _e('Categories'); ?></h2>
			<ul>
				<?php wp_list_cats('sort_column=name&hierarchical=0&depth=0'); ?>
			</ul>
		</li>
		<li class="even">
			<h2><?php _e('recent posts'); ?></h2>
			<ul>
			<?php
					global $post;
					$recent = get_posts('numberposts=5&orderby=date');
					foreach($recent as $post) : setup_postdata($post);
				?>				
			<li>
				<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
			</li>	
			<?php endforeach; ?>
			</ul>
		</li>
		<li class="odd">
			<h2><?php _e('tags'); ?></h2>
			<ul>
				<li><?php if(function_exists('wp_cumulus_insert')){ wp_cumulus_insert(); } ?></li>
			</ul>
		</li>
		<?php wp_list_bookmarks(array('title_li' => __('Blogroll'), 'category_before' => '<li id="blogroll" class="even">')); ?> 
<?php endif;?>
</ul>
<div id="clear"></div>
</div>