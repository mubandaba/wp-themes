<?php  
/* 
Template Name:guestbook
*/  
?> 


<?php get_header(); ?>


<!--分类头部介绍开始-->
<div class="bs-header" id="content">
  <div class="container">
        <h1>欢迎留言</h1>
        <p>有什么疑问或者建议可以在这里留言,我会第一时间作出解答,谢谢。</p>
        
  </div>
</div>
<!--分类头部介绍结束-->


<div class="article">
  <div class="nav-bar"></div>
  
  
  <div class="article-main">
    <!--ads begin-->
      <div class="ads-guestbook"><?php echo stripslashes(get_option('cnsecer_guestbook-ads-header')); ?></div>
    <!--ads end-->
    <?php poptip();?>
    <div class="o1">
<div id="comments"><?php comments_template(); ?></div>
    </div>
  
    <div style="font: 0px/0px sans-serif;clear: both;display: block"> </div>
  </div>

</div>
    

    
<?php get_footer(); ?>
    
    
    