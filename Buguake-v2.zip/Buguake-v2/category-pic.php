<!--这是分类目录-->

<?php get_header(); ?>




<!--分类头部介绍开始-->
<div class="bs-header hidden-sm  hidden-xs" id="content">
	<div class="container">
        <h1>WP主题</h1>
        <p>这里主要为我原创的主题和一些收集的主题,遇到问题请到留言板留言</p>
        
	</div>
</div>
<!--分类头部介绍结束-->
<div class="category">
	<div class="nav-bar hidden-sm  hidden-xs"></div>
	<div class="cate-main">
		<!--left begin-->
		<div class="cate-main-left">
			<!--j1 begin-->
			<div class="j1"><a href="<?php bloginfo('url'); ?>" target="_top">首页</a> > 
				<?php if (get_option('mytheme_Product2')!=""): ?>                                  <!--判断语句-->
				<?php echo get_option('mytheme_Product2'); ?>                                 <!--输出语句-->
				<?php else : ?>                                                                 <!--否定语句-->
				产品中心
				<?php endif; ?> > <?php wp_title(''); ?>
			</div>
			<!--j1 end-->

			<!--pic begin-->
			<div class="cate-pic">
				<?php $posts = query_posts($query_string . '&orderby=date&showposts=9'); ?>
				<?php if( $posts ) : ?>                                       
				<ul>
					<?php foreach( $posts as $post ) : setup_postdata( $post ); ?>     
					<div class="n2">
						<div class="n3"><a href="<?php the_permalink() ?>" target="_blank">
							<img class="featurette-image img-responsive img-thumbnail" src="<?php post_thumbnail_src(); ?>"  style="width: 175px; height: 130px;">
						</a></div>
						<h2 class="n4">
							<a href="<?php the_permalink() ?>" target="_blank">
							<?php echo mb_strimwidth(get_the_title(), 0, 25,"...") ?>
							</a>
						</h2>
					</div>
					<?php endforeach; ?>                                         	
					<?php endif; ?> 
					<div class="navigation"><?php pagination($query_string);  ?></div>
				</div>
				<!--pic end-->
			</div>
			<!--left end-->
			
		<!--sidebar begin-->
		<?php get_sidebar("pic"); ?>
		<!--sidebar end-->
				
				<div style="font: 0px/0px sans-serif;clear: both;display: block"> </div>
			</div>
			
		</div>
		
		
		
		<?php get_footer(); ?>
		