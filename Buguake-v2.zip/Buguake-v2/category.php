<?php
	/*  功能:
	*	判断是否为分类目录别名，如果不是，则使用category-all.php 分类目录模板
	*   如果是，则使用对应的分类目录模板
	*/
if ( is_category('wordpress') ) {
include(TEMPLATEPATH . '/category-pic.php');
}




// elseif 结束
else {
include(TEMPLATEPATH . '/category-default.php');
}
?>


