<!--文章页面-->

<?php get_header(); ?>



<!--分类头部介绍开始-->
<div class="bs-header hidden-sm hidden-xs" id="content">
	<div class="container">
        <h1>NICE</h1>
        <p>遇到问题可以在文章底部留言,如果本文帮到了你,麻烦点击下底部的广告,谢谢^_^</p>
        
	</div>
</div>
<!--分类头部介绍结束-->


<div class="article">
	<div class="nav-bar hidden-sm  hidden-xs"></div>
	
	
	<div class="article-main">
		<div class="o1">
			<h2 class="title"><?php the_title(); ?></h2>
			<div class="info">
				
				<div class="a">更新时间：<?php the_time('20y年m月d日 H:i')?></div>
				<div class="b">作者：<?php rand_user(); ?></div>
				<?php edit_post_link('编辑'); ?>
				<div class="c">评论:<?php comments_popup_link ('跪求评论','1条评论','%条评论'); ?> </div>
				<div class="d">分享：
					<div class="share">
						<!-- JiaThis Button BEGIN -->
						<div class="jiathis_style">
							<a class="jiathis_button_qzone"></a>
							<a class="jiathis_button_tsina"></a>
							<a class="jiathis_button_tqq"></a>
							<a class="jiathis_button_weixin"></a>
							<a class="jiathis_button_renren"></a>
							<a href="http://www.jiathis.com/share" class="jiathis jiathis_txt jtico jtico_jiathis" target="_blank"></a>
							<a class="jiathis_counter_style"></a>
						</div>
						<script type="text/javascript" src="http://v3.jiathis.com/code/jia.js" charset="utf-8"></script>
						<!-- JiaThis Button END -->
					</div>      
				</div>
				
			</div>
		<!--ads begin-->
			<div class="ads-single"><?php echo stripslashes(get_option('cnsecer_single-ads-header')); ?></div>
		<!--ads end-->
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<p>
				<?php the_content(); ?>
				<?php wp_link_pages(array('before' => 'Pages: ', 'next_or_number' => 'number')); ?>
			</p>
			<?php endwhile; endif; ?>
			
			<div class="o5"></div>
		</div>
		<!--ads begin-->
			<div class="ads-single"><?php echo stripslashes(get_option('cnsecer_single-ads-buttom')); ?></div>
		<!--ads end-->
		<div class="post_link ">
			<div class="prev"><?php previous_post_link('<span class="glyphicon glyphicon-chevron-left"></span> %link') ?></div>
			<div class="next"><?php next_post_link('%link <span class="glyphicon glyphicon-chevron-right"></span> ') ?></div>
		</div>	
		<div id="comments"><?php comments_template(); ?></div>
		<div style="font: 0px/0px sans-serif;clear: both;display: block"> </div>
	</div>
	
	
</div>




<?php get_footer(); ?>
