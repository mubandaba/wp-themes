<div class="cate-main-right">
     <div class="k1">  <p>热门文章</p>  </div>   
        <div class="k3">
            <?php cnsecer_get_most_viewed();  ?> 
        </div>
     <div class="k1">  <p>精彩推荐</p>  </div> 
        <div class="cate250">
         <?php echo stripslashes(get_option('cnsecer_cate-ads-sidebar')); ?>
        </div>
</div>
