<?php  
/* 
Template Name:test
*/  
?> 
<?php get_header(); ?>
<div class="container"  style ="height:300px;">
<?php

echo "11111111";

 bootstrap_nav(); ?>



</div   >
<?php get_footer(); ?>