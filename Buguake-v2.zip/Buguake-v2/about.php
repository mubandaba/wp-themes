<?php  
/* 
Template Name:about
*/  
?> 


<?php get_header(); ?>




<!--分类头部介绍开始-->
<div class="bs-header" id="content">
	<div class="container">
        <h1>关于我</h1>
        <p>我是一个大三的学生,计算机专业,业余爱好PHP。</p>
        
	</div>
</div>
<!--分类头部介绍结束-->


<div class="article">
	<div class="nav-bar" style="text-align:center">
			
	</div>
	
	
	<div class="article-main">
		<div class="o1">
    <div class="content">
	<br/>
	<br/>
	<br/>



      <p><span style="color:#008000;"><strong>关于本主题<strong></span></p>
      <br>
      <p>
        现用主题采用HTML5+CSS3+BootStrap 3。0构建，BootStrap为Twritter开源的前端框架。主题通过W3C的HTML5认证，响应式布局。<br>
        主题优点：本主题会自动判断访问设备屏幕尺寸，并自动显示出不同的布局。<br>
        主题缺点：不支持IE8以下浏览器，不支持三级导航。
      </p>
      <br>
      <br>
      <p><span style="color:#008000;"><strong>关于博主</strong></span></p>
      <br>
      <p>PHP业余爱好者，计算机专业，现在在郑州上大学。熟悉WP模板制作，欢迎志同道合的朋友加我QQ</p>
      <br>
      <p><span style="color:#008000;"><strong>关于本站</strong></span></p>
      <br>
      <p>
      1、里面的大部分文章都是自己遇到过的问题，方便以后查找。不过我比较懒，里面90%的文章都是我拷贝过来的.<br>
      2、本站为非营利性站点，希望里面的内容能为你提供帮助!<br>
      </p>
    
      <br>
      <p><span style="color:#008000;"><strong>投稿</strong></span></p>
      <br>
      <p>投稿请在本站注册会员，然后在后台发表文章，经过审核后即可在前台显示。或者发邮件至root@cnsecer.com</p>
      <br>
      <br>
      <p><span style="color:#008000;"><strong>联系方式</strong></span></p>
      <br>
      <p>
        <p>Q Q:156420012</p>
        <p>E-mail：root@cnsecer.om</p>
        <br>
        <br>
      <div class="progress progress-striped active">
        <div class="progress-bar"  role="progressbar" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100" style="width: 45%">
          <span >主题开发进度:45% Complete</span>
        </div>
      </div>
        <br>
     <!--ads begin-->
      <div class="ads-about"><?php echo stripslashes(get_option('cnsecer_about-ads-buttom')); ?></div>
    <!--ads end-->
        <br>

        
      </div>

		</div>
		<div style="font: 0px/0px sans-serif;clear: both;display: block"> </div>
	</div>

</div>
		

		
<?php get_footer(); ?>
		
		
		