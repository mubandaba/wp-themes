<?php
  /*
    Template Name:sbie

  */
  
?>

<!DOCTYPE html>
<html>
  <head>
    <title>呵呵呵呵呵呵呵</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">

	<!-- Optional theme -->
	<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap-theme.min.css">

	<!-- Latest compiled and minified JavaScript -->
	<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>

  </head>
  <body>

<div class="container">
	
	<div class="alert alert-danger">
        <strong>Warning!</strong> 
        你的浏览器太过垃圾,已被本站禁止访问,如果你想继续访问本站,推荐下载：
        <a href='http://www.google.cn/intl/zh-CN/chrome/browser/' target="_blank">Chrome</a>或者<a href='http://firefox.com.cn/download/' target="_blank">Firefox</a>

      </div>
</div>
  </body>
</html>