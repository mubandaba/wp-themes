<?php get_header(); ?>
<div class="container content">
		<div class="row">
			<div class="col-md-9">
				<!-- Blog-Box -->
				<section>
					<h3 class="section-title blue" style="margin-left:0;">搜索结果:<?php esc_attr($_GET['s']); ?></h3>
					<div class="line" style="margin-left:0;"></div>
					<?php if (have_posts()) : while (have_posts()) : the_post(); ?>					
					<div class="search-box">
						<div class="search-item">
							<h3><a href="<?php the_permalink() ?>" target="_blank" rel="bookmark" title="<?php the_title_attribute(); ?>" class="dark-blue" ></a></h3>
							<p class="post-item-text"><?php 
									if (has_excerpt()) the_excerpt(); 
									else echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 140,"...");
								?></p>
							<div class="search-info">
								<span class="tm green"><?php the_time('Y-m-d'); ?></span>
								<span class="count green">阅读（<?php if(function_exists('the_views')) { echo the_views(); } ?>）</span>
								<a href="<?php the_permalink() ?>" target="_blank" rel="bookmark" title="<?php the_title_attribute(); ?>" class="green">详细阅读</a>
							</div>
						</div>
					</div>
					<?php endwhile; endif;?>
				</section>
				<ul class="pagination">
				  <ul class="pagination">
				  <?php par_pagenavi(5); ?>
				</ul>
				</ul>
				<!-- //Blog-Box -->
			</div>
			<?php get_sidebar(); ?>
			<?php get_footer(); ?>