<?php
register_widget('New_Articles');
class New_Articles extends WP_Widget {
	public function __construct() {
		parent::__construct(
	 		'newarticle', // 基本 ID
			'Bulletin-最新文章', // 名称
			array( 'description' => '主题自带的最新文章小工具', ) // Args
		);
	}
	function widget($args, $instance) {
		extract($args, EXTR_SKIP);
		$title = empty($instance['title']) ? '最新文章' : apply_filters('widget_title', $instance['title']);
		$name = empty($instance['name']) ? 'New Articles' : apply_filters('widget_name', $instance['name']);
		$count = empty($instance['count']) ? '5' : apply_filters('widget_count', $instance['count']);
		echo $before_widget.$before_title.$title;
		echo '<span class="sub-title orange">'.$name.'</span>'.$after_title;
		echo '<div class="widget-item">';
		new_post($count);
		echo '</ul></div>'.$after_widget;
	}
	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['name'] = strip_tags($new_instance['name']);
		$instance['count'] = strip_tags($new_instance['count']);
		return $instance;
	}
	function form($instance) {
		$instance = wp_parse_args( (array) $instance, array( 'title' => '', 'name' => '', 'count' => '' ) );
		$title = strip_tags($instance['title']);
		$name = strip_tags($instance['name']);
		$count = strip_tags($instance['count']);

		echo '<p><label>标题：<input id="'.$this->get_field_id('title').'" name="'.$this->get_field_name('title').'" type="text" value="'.esc_attr($title).'" size="24" /></label></p>';
		echo '<p><label>英文：<input id="'.$this->get_field_id('name').'" name="'.$this->get_field_name('name').'" type="text" value="'.esc_attr($name).'" size="24" /></label></p>';
		echo '<p><label>数目：<input id="'.$this->get_field_id('count').'" name="'.$this->get_field_name('count').'" type="text" value="'.esc_attr($count).'" size="24" /></label></p>';
	}
}

function new_post( $limit ){
    global $post;
    $args = array(
        'post__not_in' => array($post->ID),
        'showposts' => $limit,
        'ignore_sticky_posts' => 1
    );
    $query = new WP_Query( $args );
    if ($query->have_posts()) :
		while ($query->have_posts()) : $query->the_post();
			$category = get_the_category();
			echo '<div class="widget-post"><a href="';
			the_permalink();
			echo '" target="_blank" rel="bookmark" title="';
			the_title_attribute();
			echo '" >';
			if(has_post_thumbnail()){the_post_thumbnail('thumbnail'); } else {echo wp_the_thumbnail();}
			echo '<span>';
			the_title();
			echo '</span></a>';
			if( $category[0] ){
				echo '<span class="btn-cat"><a href="'.get_category_link($category[0]->term_id ).'" title="'.$category[0]->cat_name.'"">'.$category[0]->cat_name.'</a></span>';
			};
			echo '</div>';
		endwhile;
    else:
        echo '赶快写下你的第一篇文章吧！';
    endif;
    wp_reset_postdata();
}
?>
