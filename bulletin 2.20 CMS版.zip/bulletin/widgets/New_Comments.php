<?php
register_widget('New_Comments');
class New_Comments extends WP_Widget {
	public function __construct() {
		parent::__construct(
	 		'newcomments', // 基本 ID
			'Bulletin-最新评论', // 名称
			array( 'description' => '主题自带最新评论小工具', ) // Args
		);
	}
	function widget($args, $instance) {
		extract($args, EXTR_SKIP);
		$title = empty($instance['title']) ? '最新评论' : apply_filters('widget_title', $instance['title']);
		$name = empty($instance['name']) ? 'New Comments' : apply_filters('widget_name', $instance['name']);
		$num = empty($instance['num']) ? '5' : apply_filters('widget_num', $instance['num']);
		echo $before_widget.$before_title.$title;
		echo '<span class="sub-title orange">'.$name.'</span>'.$after_title.'<div class="widget-item"><ul class="comments_list">';
		$args = array(
			'number'	=>	$num,
			'order'		=>	'DESC',
			'status'	=>	'approve'
		);
		$comments = get_comments($args);
		$output = '';
		foreach ($comments as $value) {
			$title = get_post($value->comment_post_ID)->post_title;
			$output .= "<li><div class='comments_author clearfix'>".get_avatar( $value, 32 )."<span>". strip_tags($value->comment_author)."</span></div><div class='comments_info'>".$value->comment_content."</div><div class='comments_article'><i class='fa fa-quote-left red'></i>发表在：<a href=\"".get_permalink($value->comment_post_ID)."\" class='jtooltip' title='点击查看-".$title."'>".$title."</a></div></li>";
		}
		echo $output.'</ul>';
		echo '</div>'.$after_widget;
	}
	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['name'] = strip_tags($new_instance['name']);
		$instance['num'] = strip_tags($new_instance['num']);
		return $instance;
	}
	function form($instance) {
		$instance = wp_parse_args( (array) $instance, array( 'title' => '', 'name' => '') );
		$title = strip_tags($instance['title']);
		$name = strip_tags($instance['name']);
		$num = strip_tags($instance['num']);
		echo '<p><label>标题：<input id="'.$this->get_field_id('title').'" name="'.$this->get_field_name('title').'" type="text" value="'.esc_attr($title).'" size="24" /></label></p>';
		echo '<p><label>英文：<input id="'.$this->get_field_id('name').'" name="'.$this->get_field_name('name').'" type="text" value="'.esc_attr($name).'" size="24" /></label></p>';
		echo '<p><label>评论数目：<input id="'.$this->get_field_id('num').'" name="'.$this->get_field_name('num').'" type="text" value="'.esc_attr($num).'" size="22" /></label></p>';
	}
}
?>
