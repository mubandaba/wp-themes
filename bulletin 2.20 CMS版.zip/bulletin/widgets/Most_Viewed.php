<?php
register_widget('Most_Viewed');
class Most_Viewed extends WP_Widget {
	public function __construct() {
		parent::__construct(
	 		'mostviewed', // 基本 ID
			'Bulletin-文章排行', // 名称
			array( 'description' => '主题自带的文章排行小工具', ) // Args
		);
	}
	function widget($args, $instance) {
		extract($args, EXTR_SKIP);
		$title = empty($instance['title']) ? '文章排行' : apply_filters('widget_title', $instance['title']);
		$name = empty($instance['name']) ? 'Top Articles' : apply_filters('widget_name', $instance['name']);
		echo $before_widget.$before_title.$title;
		echo '<span class="sub-title orange">'.$name.'</span>'.$after_title;
		echo '<div class="widget-item"><ul class="widget-rank">';
		if(function_exists('get_most_viewed')):
		get_most_viewed('post',5);
		endif;
		echo '</ul></div>'.$after_widget;
	}
	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['name'] = strip_tags($new_instance['name']);
		return $instance;
	}
	function form($instance) {
		$instance = wp_parse_args( (array) $instance, array( 'title' => '', 'name' => '') );
		$title = strip_tags($instance['title']);
		$link = strip_tags($instance['link']);

		echo '<p><label>标题：<input id="'.$this->get_field_id('title').'" name="'.$this->get_field_name('title').'" type="text" value="'.esc_attr($title).'" size="24" /></label></p>';
		echo '<p><label>英文：<input id="'.$this->get_field_id('name').'" name="'.$this->get_field_name('name').'" type="text" value="'.esc_attr($name).'" size="24" /></label></p>';
	}
}
?>
