<?php
register_widget('widget_author');
class widget_author extends WP_Widget {
	public function __construct() {
		parent::__construct(
	 		'author', // 基本 ID
			'bulletin-本文作者', // 名称
			array( 'description' => '主题自带的本文作者小工具', ) // Args
		);
	}
	function widget($args, $instance) {
		extract($args, EXTR_SKIP);
		$dec = get_the_author_meta('description');
		if(!$dec) $dec = "这家伙很懒，什么也没留下。";
		echo $before_widget.'<div class="widget-item"><div class="about-author"><div class="widget-author">';
		echo get_avatar( get_the_author_meta('user_email'), '80');
		echo '</div><div class="author-des"><h3 class="text-center">';
		the_author();
		echo '</h3>';
		echo '<p>'.$dec.'</p>';
		echo '</div></div></div>'.$after_widget;
	}
}
