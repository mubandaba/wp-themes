<?php
register_widget('B_About');
class B_About extends WP_Widget {
	public function __construct() {
		parent::__construct(
	 		'about', // 基本 ID
			'bulletin-关于我们', // 名称
			array( 'description' => '主题自带的关于我们小工具', ) // Args
		);
	}
	function widget($args, $instance) {
		extract($args, EXTR_SKIP);
		$title = empty($instance['title']) ? '关注我' : apply_filters('widget_title', $instance['title']);
		$name = empty($instance['name']) ? 'Follow Me' : apply_filters('widget_name', $instance['name']);
		$weibo = empty($instance['weibo']) ? 'wwj448' : apply_filters('widget_weibo', $instance['weibo']);
		$qq = empty($instance['qq']) ? '2892391690' : apply_filters('widget_qq', $instance['qq']);
		global $wp_option;
		echo $before_widget.$before_title.$title;
		echo '<span class="sub-title orange">'.$name.'</span>'.$after_title;
		echo '<div class="widget-item"><ul class="followme center">';
		echo '<li class="orange-bg jtooltip" title="点击关注我的新浪微博" ><a href="http://weibo.com/'.$weibo.'" class="follow-icon"><i class="fa fa-weibo"></i></a></li>';
		echo '<li class="blue-bg jtooltip" title="点击与我QQ交谈"><a href="http://wpa.qq.com/msgrd?v=3&uin='.$qq.'&site=qq&menu=yes" class="follow-icon"><i class="fa fa-qq"></i></a></li>';
		echo '<li class="green-bg" id="wechat" qrcode=" <img src=\''.$wp_option['base']['wechat'].'\' />"><a href="#" class="follow-icon"><i class="fa fa-weixin"></i></a></li>';
		echo '<li class="red-bg jtooltip" title="订阅我们"><a href="'.get_bloginfo('rss2_url').'" class="follow-icon"><i class="fa fa-rss"></i></a></li></ul></div>';
		echo $after_widget;
	}
	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['name'] = strip_tags($new_instance['name']);
		$instance['weibo'] = strip_tags($new_instance['weibo']);
		$instance['qq'] = strip_tags($new_instance['qq']);
		return $instance;
	}
	function form($instance) {
		$instance = wp_parse_args( (array) $instance, array( 'title' => '', 'name' => '', 'weibo' => '', 'qq' => '') );
		$title = strip_tags($instance['title']);
		$name = strip_tags($instance['name']);
		$weibo = strip_tags($instance['weibo']);
		$qq = strip_tags($instance['qq']);

		echo '<p><label>标题：<input id="'.$this->get_field_id('title').'" name="'.$this->get_field_name('title').'" type="text" value="'.esc_attr($title).'" size="24" /></label></p>';
		echo '<p><label>英文：<input id="'.$this->get_field_id('name').'" name="'.$this->get_field_name('name').'" type="text" value="'.esc_attr($name).'" size="24" /></label></p>';
		echo '<p><label>微博：<input id="'.$this->get_field_id('weibo').'" name="'.$this->get_field_name('weibo').'" type="text" value="'.esc_attr($weibo).'" size="24" /></label></p>';
		echo '<p><label>QQ：<input id="'.$this->get_field_id('qq').'" name="'.$this->get_field_name('qq').'" type="text" value="'.esc_attr($qq).'" size="24" /></label></p>';
	}
}
