<?php
register_widget('B_Links');
class B_Links extends WP_Widget {
	public function __construct() {
		parent::__construct(
	 		'friend_links', // 基本 ID
			'Bulletin-友情链接', // 名称
			array( 'description' => '主题自带的友情链接管理工具', ) // Args
		);
	}
	function widget($args, $instance) {
		extract($args, EXTR_SKIP);
		$title = empty($instance['title']) ? '友情链接' : apply_filters('widget_title', $instance['title']);
		$name = empty($instance['name']) ? 'Friend Links' : apply_filters('widget_name', $instance['name']);
		$link = empty($instance['link']) ? 'links' : apply_filters('widget_link', $instance['link']);
		if(is_home()):
			echo $before_widget.$before_title.$title;
			echo '<span class="sub-title orange">'.$name.'</span>'.$after_title;
			echo '<div class="widget-item"><ul class="widget-links">';
			wp_list_bookmarks('title_li=&categorize=&show_images=');
			echo '<li>[<a href="'.get_bloginfo("url").'/'.$link.'">申请友情链接</a>]</li>';
			echo '</ul></div>'.$after_widget;
		endif;
	}
	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['name'] = strip_tags($new_instance['name']);
		$instance['link'] = strip_tags($new_instance['link']);
		return $instance;
	}
	function form($instance) {
		$instance = wp_parse_args( (array) $instance, array( 'title' => '', 'name' => '', 'link' => '' ) );
		$title = strip_tags($instance['title']);
		$link = strip_tags($instance['link']);

		echo '<p><label>标题：<input id="'.$this->get_field_id('title').'" name="'.$this->get_field_name('title').'" type="text" value="'.esc_attr($title).'" size="24" /></label></p>';
		echo '<p><label>英文：<input id="'.$this->get_field_id('name').'" name="'.$this->get_field_name('name').'" type="text" value="'.esc_attr($name).'" size="24" /></label></p>';
		echo '<p><label>链接：<input id="'.$this->get_field_id('link').'" name="'.$this->get_field_name('link').'" type="text" value="'.esc_attr($link).'" size="24" placeholder="links" /></label></p>';
	}
}
?>
