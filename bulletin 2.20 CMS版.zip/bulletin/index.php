<?php
  global $wp_option;
  if($wp_option['base']['cms'] == "open")
    include 'cms/CmsIndex.php';
  else
    include 'blog/blog.php';
  echo $value;
 ?>
