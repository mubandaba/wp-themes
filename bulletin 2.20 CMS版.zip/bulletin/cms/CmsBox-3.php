<?php
register_widget('CmsBox_three');
class CmsBox_three extends WP_Widget {
	public function __construct() {
		parent::__construct(
	 		'cmsbox_three', // 基本 ID
			'CMS-样式3', // 名称
			array( 'description' => '首页CMS样式3', ) // 描述
		);
	}
	function widget($args, $instance) {
		extract($args, EXTR_SKIP);
		$num = empty($instance['num']) ? '3' : $instance['num'];
		$icon = empty($instance['icon']) ? 'fa-list-ul' : $instance['icon'];
		$cat = empty($instance['category']) ? '1' : $instance['category'];
		$output = '<div class="cmsbox clearfix">';
		$output .= get_cms_cat($cat, $icon);
		$output .= get_cms3_posts($num, $cat);
		$output .= '</div>';
		echo $output;
	}
	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['num'] = strip_tags($new_instance['num']);
		$instance['icon'] = strip_tags($new_instance['icon']);
		$instance['category'] = strip_tags($new_instance['category']);
		return $instance;
	}
	function form($instance) {
		$instance = wp_parse_args( (array) $instance, array( 'num' => '', 'icon' => '', 'category' => '' ) );
		$num = strip_tags($instance['num']);
		$icon = strip_tags($instance['icon']);
		$category = strip_tags($instance['category']);
		echo '<p><lable>分类名称：'.get_cat_list($this->get_field_id('category'),$this->get_field_name('category'),esc_attr($category)).'</p>';
		echo '<p><label>显示数目：<input id="'.$this->get_field_id('num').'" name="'.$this->get_field_name('num').'" type="text" value="'.esc_attr($num).'" size="24" /></label></p>';
		echo '<p><label>分类图标：<input id="'.$this->get_field_id('icon').'" name="'.$this->get_field_name('icon').'" type="text" value="'.esc_attr($icon).'" size="24" /></label></p>';
	}
}

function get_cms3_posts( $limit, $cat ){
		$args = array(
				'showposts' => $limit,
				'cat'	=> $cat,
		);
		$query = new WP_Query( $args );
		if ($query->have_posts()) :
			$output = '<ul class="cmsul">';
			while ($query->have_posts()) :
				$query->the_post();
				$output .= '<li class="col-md-4 cmslist-2">';
				$output .= '<a href="'.get_the_permalink().'" class="jtooltip" title="'.get_the_title().'" target="_blank">';
				$output .= '<h4>'.get_the_title().'</h4><div class="cmsmask-2">';
				if(has_post_thumbnail())
					$output .= get_the_post_thumbnail(null, 'thumbnail');
				else
					$output .= wp_the_thumbnail();
				global $post;
				$output .= '<div class="cmslist-2-desc">'.mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 80,"...").'</div></div><div class="cmslist-2-info"><span><i class="fa fa-eye"></i>';
				if(function_exists('the_views'))
					$output .= the_views(false);
				$output .= '</span><span><i class="fa fa-clock-o"></i>'.get_the_time('Y-m-d').'</span></div></a></li>';
			endwhile;
		else:
				$output = '赶快写下你的第一篇文章吧！';
		endif;
		wp_reset_postdata();
		$output .= '</ul>';
		return $output;
}
