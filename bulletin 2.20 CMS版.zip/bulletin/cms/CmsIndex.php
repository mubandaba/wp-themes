<?php get_header(); ?>
<div class="maintop">
	<div class="container">
		<div class="row">
			<!-- Slider -->
			<div class="col-md-6 slider">
				<?php
					$args = array(
						'post_type'=>'slider',
						'posts_per_page' => 6,
					);
					query_posts($args);
					if(have_posts()):
						$i = 0;
				?>
					<div id="slide-box" class="carousel slide" data-ride="carousel">
					<!-- Wrapper for slides -->
					<div class="carousel-inner" role="listbox">
						<?php
							while(have_posts()): the_post();
							$slider_pic = get_post_meta($post->ID,'slider_pic',true);
							$slider_link = get_post_meta($post->ID,'slider_link',true);
						?>
						<div class="item <?php if ($i == 0)	echo "active"; ?>">
							<a target="_blank" href="<?php echo $slider_link; ?>"><img src="<?php echo $slider_pic ?>" alt="<?php the_title(); ?>" ></a>
						</div>
						<?php $i++;	endwhile; ?>
						<ol class="carousel-indicators">
							<?php
								for($len=0; $len<$i; $len++){
							?>
										<li data-target="#slide-box" data-slide-to="<?php echo $len; ?>" <?php if($len==0) echo 'class="active"'; ?>></li>
							<?php } ?>
						</ol>

						<!-- Controls -->
						<a class="left carousel-control" href="#slide-box" role="button" data-slide="prev">
							<i class="fa fa-chevron-circle-left glyphicon-chevron-left"></i>
							<span class="sr-only">Previous</span>
						</a>
						<a class="right carousel-control" href="#slide-box" role="button" data-slide="next">
							<i class="fa fa-chevron-circle-right glyphicon-chevron-right"></i>
							<span class="sr-only">Next</span>
						</a>
					</div>
				</div>
				<?php endif; wp_reset_query(); ?>
			</div>
			<!-- //Slider -->
			<div class="col-md-3">
				<div class="hometop">
					<h3 class="hometitle navy-bg">最新文章</h3>
					<?php
						query_posts('posts_per_page=5');
						if(have_posts()):
					?>
					<ul>
						<?php while (have_posts()) : the_post();  ?>
						<li><a href="<?php the_permalink(); ?>" target="_blank" class="jtooltip" rel="bookmark" title="<?php the_title_attribute(); ?>" ><span class="hometime"><?php the_time('m-d'); ?></span><?php the_title(); ?></a></li>
						<?php endwhile; ?>
					</ul>
				<?php endif; wp_reset_query(); ?>
				</div>
			</div>
			<div class="col-md-3">
				<div class="hometop">
					<div class="homeimg">
						<?php echo $wp_option['base']['home_img']; ?>
					</div>
					<div class="homenote red-bg">
						<?php echo $wp_option['base']['home_note']; ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="container" id="main">
		<div class="row">
			<div class="col-md-9">
				<?php
					if(is_home()):
					if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('首页CMS') ) :

					endif; endif;
				?>
			</div>
			<?php get_sidebar(); ?>
			<?php get_footer(); ?>
