<?php

add_action( 'category_add_form_fields', 'wp_new_term_color_field' );
add_action( 'post_tag_add_form_fields', 'wp_new_term_color_field' );

function wp_new_term_color_field() {
    wp_nonce_field( basename( __FILE__ ), 'wp_term_color_nonce' ); ?>

    <div class="form-field wp-term-color-wrap">
        <label for="wp-term-color">颜色</label>
        <input type="text" name="wp_term_color" id="wp-term-color" data-default-color="#ffffff" />
    </div>
<?php }

add_action( 'category_edit_form_fields', 'wp_edit_term_color_field' );

function wp_edit_term_color_field( $term ) {
    $default = '#ffffff';
    $color   = get_term_meta( $term->term_id, 'color', true );

    if ( ! $color )
        $color = $default; ?>

    <tr class="form-field wp-term-color-wrap">
        <th scope="row"><label for="wp-term-color">颜色</label></th>
        <td>
            <?php echo wp_nonce_field( basename( __FILE__ ), 'wp_term_color_nonce' ); ?>
            <input type="text" name="wp_term_color" id="wp-term-color" value="<?php echo esc_attr( $color ); ?>" data-default-color="<?php echo esc_attr( $default ); ?>" />
        </td>
    </tr>
<?php }

add_action( 'create_category', 'wp_save_term_color' );
add_action( 'edit_category',   'wp_save_term_color' );

function wp_save_term_color( $term_id ) {
    if ( ! isset( $_POST['wp_term_color_nonce'] ) || ! wp_verify_nonce( $_POST['wp_term_color_nonce'], basename( __FILE__ ) ) )
        return;

    $color = isset( $_POST['wp_term_color'] ) ? $_POST['wp_term_color'] : '';

    if ( '' === $color ) {
        delete_term_meta( $term_id, 'color' );
    } else {
        update_term_meta( $term_id, 'color', $color );
    }
}

add_filter( 'manage_edit-category_columns', 'wp_edit_term_columns' );

function wp_edit_term_columns( $columns ) {
    $columns['color'] = '颜色';
    return $columns;
}

add_filter( 'manage_category_custom_column', 'wp_manage_term_custom_column', 10, 3 );

function wp_manage_term_custom_column( $out, $column, $term_id ) {
    if ( 'color' === $column ) {
        $color = get_term_meta( $term_id, 'color', true );

        if ( ! $color )
            $color = '#ffffff';

        $out = sprintf( '<span class="color-block" style="background:%s">&nbsp</span>', esc_attr( $color ) );
    }
    return $out;
}

add_action( 'admin_enqueue_scripts', 'wp_admin_enqueue_scripts' );

function wp_admin_enqueue_scripts( $hook_suffix ) {
    if ( 'edit-tags.php' === $hook_suffix || 'category' === get_current_screen()->taxonomy ){
      wp_enqueue_style( 'wp-color-picker' );
      wp_enqueue_script( 'wp-color-picker' );

      add_action( 'admin_head',   'wp_term_color_print_styles' );
      add_action( 'admin_footer', 'wp_term_color_print_scripts' );
    }
    
}

function wp_term_color_print_styles() { ?>
    <style>
        .column-color { width: 50px; }
        .column-color .color-block { display: inline-block; width: 28px; height: 28px; border-radius: 50%; }
    </style>
<?php }

function wp_term_color_print_scripts() { ?>
    <script>
        jQuery( function( $ ) {
            $( '#wp-term-color' ).wpColorPicker();
        } );
    </script>
<?php }
