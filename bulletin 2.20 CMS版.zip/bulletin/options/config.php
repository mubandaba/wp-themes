<?php
/**
*
*post meta test
*
**/
/*****Meta Box********/
$wp_meta = array();
$meta_conf = array('title' => '文章SEO设置', 'id'=>'seobox', 'page'=>array('page','post'), 'context'=>'normal', 'priority'=>'low', 'callback'=>'');

$wp_meta[] = array(
  'name' => '标签',
  'id'   => 'keywords',
  'desc' => '文章meta标签，不影响自带标签',
  'std'  => '',
  'size' => 70,
  'type' => 'text'
);

$wp_meta[] = array(
  'name' => '文章描述',
  'id'   => 'desc',
  'desc' => '文章meta描述设置',
  'std'  => '',
  'size' => array(70,5),
  'type' => 'textarea'
);

$new_box = new wp_postmeta_feild($wp_meta, $meta_conf);

/**
*
*Site Options
*
**/
/*********Options************/
$page_info = array(
    'full_name' => '主题设置',
    'optionname'=>'base',
    'child'=>false,
    'filename' => 'basepage'
);

$base_option = array();

$base_option[] = array(
    'name' => '基本设置',
    'type' => 'open',
    'desc' => '主题基本设置',
    'id'   => 'base'
);

$base_option[] = array(
    'name' => '关于我们',
    'id'   => 'about',
    'desc' => '显示在网站左下角',
    'std'  => '',
    'size' => array(50,3),
    'type' => 'textarea'
);

$base_option[] = array(
    'name' => '统计代码',
    'id'   => 'statistic',
    'desc' => '第三方统计代码，前台默认隐藏统计代码图标，不影响统计功能',
    'std'  => '',
    'size' => array(50,3),
    'type' => 'textarea'
);

$base_option[] = array(
    'name' => '网站底部',
    'id'   => 'icp',
    'desc' => '自定义网站底部内容',
    'std'  => 'Copyright © 2016 律动星光 版权所有 设计：<a href="http://www.ldstars.com" rel="no-follow">律动星光</a>',
    'size' => array(50,3),
    'type' => 'textarea'
);

$base_option[] = array(
    'name' => '微信关注',
    'id'   => 'wechat',
    'desc' => '微信公众号二维码，显示在网站右下角和小工具里面',
    'std'  => '',
    'size' => 50,
    'button_text' => '上传',
    'type' => 'upload'
);

$base_option[] = array(
    'type' => 'close'
);

$base_option[] = array(
    'name' => '功能设置',
    'type' => 'open',
    'id'   => 'functions'
);

$base_option[] = array(
  'name'    => '首页风格',
  'id'      => 'cms',
  'desc'    => '是否开启CMS模式',
  'std'     => 'close',
  'buttons' => array(
    'open'      => '开启',
    'close'    => '关闭'
  ),
  'type'    => 'radio'
);

$base_option[] = array(
  'name'    => '弹幕开关',
  'id'      => 'danmu',
  'desc'    => '开启或关闭评论弹幕',
  'std'     => 'open',
  'buttons' => array(
    'open'      => '开启',
    'close'    => '关闭'
  ),
  'type'    => 'radio'
);

$base_option[] = array(
  'name'    => 'jQuery开关',
  'id'      => 'jq',
  'desc'    => '是否加载主题自带jQuery',
  'std'     => 'open',
  'buttons' => array(
    'open'     => '开启',
    'close'    => '关闭'
  ),
  'type'    => 'radio'
);

$base_option[] = array(
    'type' => 'close'
);

$base_option[] = array(
    'name' => '广而告之',
    'type' => 'open',
    'id'   => 'ads'
);

$base_option[] = array(
    'name' => '首页顶部广告',
    'id'   => 'home_img',
    'desc' => '支持html代码，一般为图片广告',
    'std'  => '',
    'size' => array(50,6),
    'type' => 'textarea'
);

$base_option[] = array(
    'name' => '首页顶部公告',
    'id'   => 'home_note',
    'desc' => '支持html代码，一般为文字公告',
    'std'  => '',
    'size' => array(50,6),
    'type' => 'textarea'
);

$base_option[] = array(
    'name' => '文章广告',
    'id'   => 'single_b',
    'desc' => '支持html代码，显示在文章页面底部',
    'std'  => '',
    'size' => array(50,6),
    'type' => 'textarea'
);

$base_option[] = array(
    'type' => 'close'
);

$base_option[] = array(
    'name' => 'SEO设置',
    'type' => 'open',
    'id'   => 'seo'
);

$base_option[] = array(
    'name' => '关键字',
    'id'   => 'keywords',
    'desc' => '输入主题的首页关键字，多个用英文","隔开',
    'std'  => '',
    'size' => 95,
    'type' => 'text'
);
$base_option[] = array(
    'name' => '描述',
    'id'   => 'desc',
    'desc' => '输入主题的首页描述',
    'std'  => '',
    'size' => array(50,3),
    'type' => 'textarea'
);

$base_option[] = array(
    'type' => 'close'
);

$base_option[] = array(
    'name' => '自定义',
    'type' => 'open',
    'id'   => 'custome'
);

$base_option[] = array(
    'name' => '自定义代码',
    'id'   => 'code',
    'desc' => '在网站底部自定义添加JS代码',
    'std'  => '',
    'size' => array(50,6),
    'type' => 'textarea'
);

$base_option[] = array(
    'name' => '手机端代码',
    'id'   => 'm_code',
    'desc' => '当手机访问时，在网站底部自定义添加JS代码',
    'std'  => '',
    'size' => array(50,6),
    'type' => 'textarea'
);

$base_option[] = array(
    'type' => 'close'
);

$option_page = new wp_options_feild($base_option, $page_info);

/****import-export*****/
$import_info = array(
    'full_name' => '导入/导出',
    'child'=>false,
    'parent_slug'=>'generalpage',
    'filename' => 'import_page'
);
$import_page = new wp_option_import_class($import_info);
?>
