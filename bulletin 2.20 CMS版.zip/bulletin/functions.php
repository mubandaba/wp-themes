<?php
//网站配置
require('options/wp_framework_core.php'); //必须 加载核心类
require('options/wp_options_feild.php'); //可选 设置页面
require('options/wp_termmeta_feild.php'); //可选 分类字段
require('options/wp_postmeta_feild.php'); //可选 文字字段
require('options/import_export.php'); //可选 设置选项导入导出
require('options/wp_slider.php'); //可选 设置幻灯片
require('options/config.php'); //配置文件-按需配置
require('config/flip.php');
require('config/optimize.php');
require('config/shortcode.php');
require('config/wp_bootstrap_navwalker.php');
require('widgets/B_About.php');
require('widgets/B_Author.php');
require('widgets/B_Links.php');
require('widgets/New_Articles.php');
require('widgets/Most_Viewed.php');
require('widgets/New_Comments.php');
require('comments-ajax/comments-ajax.php');
require('options/wp_term_meta.php');
require 'cms/CmsBox-1.php';
require 'cms/CmsBox-2.php';
require 'cms/CmsBox-3.php';
require 'cms/CmsBox-4.php';

//自定义菜单
register_nav_menus(
  array(
	 'header-menu' => __( '顶部菜单' ),
	 'footer-menu' => __( '底部菜单' ),
  )
);

//自定义小工具
if( function_exists('register_sidebar') ) {
        register_sidebar(array(
            'id' => 'side-1',
            'name'			=> '首页小工具',
            'before_widget' => '<div class="widget-box">',
            'after_widget' => '</div>',
            'before_title' => '<div class="widget-title"><h3>',
            'after_title' => '</h3></div>'
        ));
        register_sidebar(array(
				'id' => 'side-2',
		        'name'			=> '文章小工具',
                'before_widget' => '<div class="widget-box">',
                'after_widget' => '</div>',
                'before_title' => '<div class="widget-title"><h3>',
                'after_title' => '</h3></div>'
        ));
		register_sidebar(array(
				'id' => 'side-3',
		        'name'			=> '首页CMS',
                'before_widget' => '',
                'after_widget' => '',
                'before_title' => '',
                'after_title' => ''
        ));
		register_sidebar(array(
				'id' => 'side-4',
		        'name'			=> '页面小工具',
                'before_widget' => '<div class="widget-box">',
                'after_widget' => '</div>',
                'before_title' => '<div class="widget-title"><h3>',
                'after_title' => '</h3></div>'
        ));
}


//自定义背景
add_theme_support( 'post-thumbnails' );
add_theme_support('custom-background');

//后台预览
add_editor_style('/css/editor-style.css');


//文章缩略图
function wp_the_thumbnail(){
    global $post;
    //判断缩略图
    $content = $post->post_content;
    preg_match_all('/<img.*?(?: |\\t|\\r|\\n)?src=[\'"]?(.+?)[\'"]?(?:(?: |\\t|\\r|\\n)+.*?)?>/sim', $content, $strResult, PREG_PATTERN_ORDER);
    $n = count($strResult[1]);
    if($n > 0){ // 提取首图
        return '<img itemprop="image" class="media-object" src="'.$strResult[1][0].'" />';
    }else { // 随机图片
        return '<img itemprop="image" class="media-object" src="'.get_bloginfo('template_url').'/img/random/thumb-'.rand(1,4).'.jpg" />';
    }
}


//禁止代码标点转换
remove_filter('the_content', 'wptexturize');

//编辑器增强
 function enable_more_buttons($buttons) {
     $buttons[] = 'hr';
     $buttons[] = 'del';
     $buttons[] = 'sub';
     $buttons[] = 'sup';
     $buttons[] = 'fontselect';
     $buttons[] = 'fontsizeselect';
     $buttons[] = 'cleanup';
     $buttons[] = 'styleselect';
     $buttons[] = 'wp_page';
     $buttons[] = 'anchor';
     $buttons[] = 'backcolor';
     return $buttons;
     }
add_filter("mce_buttons_3", "enable_more_buttons");

//增加字号
function customize_text_sizes($initArray){
   $initArray['fontsize_formats'] = "12px 13px 14px 15px 16px 17px 18px 19px 20px 21px 22px 23px 24px 25px 26px 27px 28px 29px 30px 32px 34px 36px 38px 42px 44px 46px 48px";
   return $initArray;
}
add_filter('tiny_mce_before_init', 'customize_text_sizes');

//编辑器字体
function custum_fontfamily($initArray){
   $initArray['font_formats'] = "微软雅黑='微软雅黑';宋体='宋体';黑体='黑体';仿宋='仿宋';楷体='楷体';隶书='隶书';幼圆='幼圆';ClearSans='clear_sansregular',Helvetica,Arial,sans-serif;ClearSans Medium='clear_sans_mediumregula',Helvetica,Arial,sans-serif;ClearSans Light='clear_sans_lightregular',Helvetica,Arial,sans-serif;ClearSans Thin='clear_sans_thinregular',Helvetica,Arial,sans-serif";
   return $initArray;
}
add_filter('tiny_mce_before_init', 'custum_fontfamily');

//友情链接
add_filter('pre_option_link_manager_enabled','__return_true');


//支持中文用户名注册
function kb_sanitize_user ($username, $raw_username, $strict) {
  $username = wp_strip_all_tags( $raw_username );
  $username = remove_accents( $username );
  $username = preg_replace( '|%([a-fA-F0-9][a-fA-F0-9])|', '', $username );
  $username = preg_replace( '/&.+?;/', '', $username );
  if ($strict) {
    $username = preg_replace ('|[^a-z\p{Han}0-9 _.\-@]|iu', '', $username);
  }
  $username = trim( $username );
  $username = preg_replace( '|\s+|', ' ', $username );
  return $username;
}
add_filter ('sanitize_user', 'kb_sanitize_user', 10, 3);

//关闭谷歌字体
add_filter( 'gettext_with_context', 'rabit_disable_open_sans', 888, 4 );
function rabit_disable_open_sans( $translations, $text, $context, $domain ) {
  if ( 'Open Sans font: on or off' == $context && 'on' == $text ) {
    $translations = 'off';
  }
  return $translations;
}

//替换后台网址
add_filter( 'login_headerurl', 'custom_loginlogo_url' );
function custom_loginlogo_url($url) {
    return get_bloginfo('url');
}

//修改后台样式
add_action('login_head', 'custom_login_logo');
function custom_login_logo() {
    echo '<link rel="stylesheet" type="text/css" href="' . get_bloginfo('stylesheet_directory') . '/css/customlogin.css" />';
}

//自动改图片文件名称
function new_filename($filename) {
	$info = pathinfo($filename);
	$ext = empty($info['extension']) ? '' : '.' . $info['extension'];
	$name = basename($filename, $ext);
	return substr(md5($name), 0, 20) . $ext;
}
add_filter('sanitize_file_name', 'new_filename', 10);


//去除emoji
function reset_emojis() {
	remove_action('wp_head', 'print_emoji_detection_script', 7);
	remove_action('admin_print_scripts', 'print_emoji_detection_script');
	remove_action('wp_print_styles', 'print_emoji_styles');
	remove_action('admin_print_styles', 'print_emoji_styles');

}
add_action('init', 'reset_emojis');

//弹幕JSON输出
function get_danmu($post_id){
	$args = array('post_id' => $post_id, 'order' => 'DESC', 'status' => 'approve');
	$comments = get_comments($args);
	$barrages = array();
	$len = strlen(get_permalink($post_id));
	$post_url = substr(get_permalink($post_id),0,$len-1);
	foreach($comments as $comment){
		$avatar = get_avatar_url($comment->comment_author_email, 50);
		$len =
		$url = $post_url . "#comment-" . $comment->comment_ID;
		array_push($barrages, array('info' => $comment->comment_content, 'img' => $avatar, 'href' => $url));
	}
	echo json_encode($barrages);
}

//加载主题JS文件
function myScripts() {
	wp_register_script( 'default', get_template_directory_uri() . '/js/jquery-2.1.1.min.js');
	wp_register_script( 'bootstrap', get_template_directory_uri() . '/js/bootstrap.min.js', false, '', true);
	wp_register_script( 'jbox', get_template_directory_uri() . '/js/jBox.min.js', false, '', true);
	wp_register_script( 'main', get_template_directory_uri() . '/js/function.js', false, '', true);
	wp_register_script( 'barrager', get_template_directory_uri() . '/js/jquery.barrager.min.js', false, '', true);
	global $wp_option;
	if($wp_option['base']['jq'] != 'close')
		wp_enqueue_script( 'default' );
	wp_enqueue_script( 'bootstrap' );
	wp_enqueue_script( 'jbox' );
	wp_enqueue_script( 'main' );
	if(is_single()||is_page())
		wp_enqueue_script( 'barrager' );
}
add_action( 'wp_enqueue_scripts', 'myScripts' );

//加载主题CSS文件
function myCss(){
	wp_register_style( 'bootstrap', get_template_directory_uri() . '/css/bootstrap.min.css' );
  wp_register_style( 'fontawesome', get_template_directory_uri() . '/fonts/FontAwesome/font-awesome.css' );
	wp_register_style( 'jbox', get_template_directory_uri() . '/css/jBox.css' );
	wp_register_style( 'animate', get_template_directory_uri() . '/css/animate.css' );
	wp_register_style( 'default', get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'bootstrap' );
  wp_enqueue_style( 'fontawesome' );
	wp_enqueue_style( 'jbox' );
	wp_enqueue_style( 'animate' );
	wp_enqueue_style( 'default' );
}
add_action( 'wp_enqueue_scripts', 'myCss' );

//对图片增加lightbox属性
function pirobox_gall_replace ($content){
	global $post;
	if(!wp_is_mobile()){
		$pattern = "/<a(.*?)><img(.*?)alt=\"(.*?)\"(.*?)>(.*?)<\/a>/i";
		$replacement = '<a$1 data-jbox-image="'.$post->ID.'" title="'.get_the_title($post->ID).'"><img$2alt=\"$3\"$4>$5</a>';
		$content = preg_replace($pattern, $replacement, $content);
	}
	return $content;
}
add_filter('the_content', 'pirobox_gall_replace');

// 评论添加@
function wp_comment_add_at( $comment_text, $comment = '') {
  if( $comment->comment_parent > 0) {
    $comment_text = '<a href="#comment-' . $comment->comment_parent . '" style="color: #FF6600;">@'.get_comment_author( $comment->comment_parent ) . '</a> ' . $comment_text;
  }

  return $comment_text;
}
add_filter( 'comment_text' , 'wp_comment_add_at', 20, 2);

//  获取分类列表
function get_cat_list($id, $name, $value){
  $output = '<select name="'.$name.'" id="'.$id.'">';
  //$value = $value | '1';
  if(!$value)
    $value = 1;
  $output .= '<option value="'.$value.'">'.get_cat_name($value).'</option>';
  $categories=  get_categories();
  $option = '';
  foreach ($categories as $category) {
    if($category->term_id == $value)
      continue;
    $option .= '<option value="'.$category->term_id.'">';
    $option .= $category->cat_name;
    $option .= '</option>';
  }
  $output .= $option.'</select>';
  return $output;
}

//  首页CMS标题
function get_cms_cat($cat, $icon){
	$output = '<div class="cmstitle"><h3><i class="fa '.$icon.'"></i>'.get_cat_name($cat).'</h3>';
	$output .= '<a href="'.get_category_link($cat).'" class="pull-right">全部<i class="fa fa-chevron-right"></i></a></div>';
	return $output;
}

//全部结束
?>
