<?php
define('AC_VERSION','1.0.0');

if ( version_compare( $GLOBALS['wp_version'], '4.4-alpha', '<' ) ) {
	wp_die('请升级到4.4以上版本');
}

if(!function_exists('wp_ajax_comment_scripts')) :

    function wp_ajax_comment_scripts(){
		if(is_single() || is_page()){
			wp_enqueue_script( 'ajax-comment', get_template_directory_uri() . '/comments-ajax/comments-ajax.js', array( 'jquery' ), AC_VERSION , true );
		
			wp_localize_script( 'ajax-comment', 'ajaxcomment', array(
				'ajax_url'   => admin_url('admin-ajax.php'),
				'order' => get_option('comment_order'),
				'formpostion' => 'bottom', //默认为bottom，如果你的表单在顶部则设置为top。
			) );
		}
    }

endif;

if(!function_exists('wp_ajax_comment_err')) :

    function wp_ajax_comment_err($a) {
        header('HTTP/1.0 500 Internal Server Error');
        header('Content-Type: text/plain;charset=UTF-8');
        echo $a;
        exit;
    }

endif;

if(!function_exists('wp_ajax_comment_callback')) :

    function wp_ajax_comment_callback(){
        $comment = wp_handle_comment_submission( wp_unslash( $_POST ) );
        if ( is_wp_error( $comment ) ) {
            $data = $comment->get_error_data();
            if ( ! empty( $data ) ) {
            	wp_ajax_comment_err($comment->get_error_message());
            } else {
                exit;
            }
        }
        $user = wp_get_current_user();
        do_action('set_comment_cookies', $comment, $user);
        $GLOBALS['comment'] = $comment; //根据你的评论结构自行修改，如使用默认主题则无需修改
        ?>
        <li <?php comment_class(); ?> id="comment-<?php comment_ID() ?>">
			<div id="div-comment-<?php comment_ID() ?>" class="comment-body">
				  <?php $add_below = 'div-comment'; ?>
				  <div class="gravatar">
					<div class="comment-author vcard">
						<?php echo get_avatar($comment_author_email, 50); ?>
					</div>
				  </div>
				<div class="floor"><?php
				if(!$parent_id = $comment->comment_parent){//正序排列
				switch ($commentcount){
				 case 0 :echo "沙发";++$commentcount;break;
				 case 1 :echo "板凳";++$commentcount;break;
				 case 2 :echo "地板";++$commentcount;break;
				 default:printf('%1$s楼', ++$commentcount);
			   }
			 }
		 ?></div>
				<div class="commenttext">
					 <span class="commentid"><span class="comment_author"><?php commentauthor(); ?></span><?php get_author_class($comment->comment_author_email,$comment->comment_author_url)?></span><span class="datetime"><?php mop_time_diff( $time_type = 'comment' ); ?></span><?php if ( $comment->comment_approved == '0' ){?><?php }else{ ?><span class="reply">&nbsp;<?php comment_reply_link(array_merge( $args, array('reply_text' => '回复', 'add_below' =>$add_below, 'depth' => $depth, 'max_depth' => $args['max_depth']))); ?></span><?php } ?><span class="edit_comment"><?php edit_comment_link('[编辑]','&nbsp;&nbsp;',''); ?></span>
							<div class="comment_text">
							<?php if ( $comment->comment_approved == '0' ){?>
							<span style="color:#f00;">您的评论正在等待审核中...</span>		
							<?php comment_text() ?>
							<?php }else{ ?>
							<?php comment_text() ?>
							<?php } ?>
							</div>
				</div>
			</div>
		</li>
        <?php die();
    }

endif;

add_action( 'wp_enqueue_scripts', 'wp_ajax_comment_scripts' );
add_action('wp_ajax_nopriv_ajax_comment', 'wp_ajax_comment_callback');
add_action('wp_ajax_ajax_comment', 'wp_ajax_comment_callback');

//评论链接新窗口
	function commentauthor($comment_ID = 0) {
		$url    = get_comment_author_url( $comment_ID );
		$author = get_comment_author( $comment_ID );
		if ( empty( $url ) || 'http://' == $url )
			echo $author;
		else
			echo "<a href='$url' rel='external nofollow' target='_blank' class='url'>$author</a>";
	}
	
	//获取访客VIP样式
	function get_author_class($comment_author_email,$comment_author_url){
		global $wpdb;
		$adminEmail = get_bloginfo ('admin_email');
		$author_count = count($wpdb->get_results(
		"SELECT comment_ID as author_count FROM $wpdb->comments WHERE comment_author_email = '$comment_author_email' "));
		$linkurls = $wpdb->get_results(
		"SELECT link_url FROM $wpdb->links WHERE link_url = '$comment_author_url'");
		if(get_the_author()==get_comment_author() || get_the_author_meta("login")==get_comment_author()){
		echo '<a class="vp" title="本文作者">作者</a>';
		}elseif($comment_author_email==$adminEmail){
		echo '<a class="vp" title="本站博主">博主</a>';
		}
		else{
		$comment = get_comment($comment_id);
		if($author_count>=1 && $author_count<5 && $comment_author_email!=$adminEmail)
		echo '<a data-hint="潜水" class="hint hint--top"><i class="fa fa-star yellow"></i></a>';
		else if($author_count>=5 && $author_count<15 && $comment_author_email!=$adminEmail)
		echo '<a data-hint="冒泡" class="hint hint--top"><i class="fa fa-star yellow"></i><i class="fa fa-star yellow"></i></a>';
		else if($author_count>=15 && $author_count<30 && $comment_author_email!=$adminEmail)
		echo '<a data-hint="吐槽" class="hint hint--top"><i class="fa fa-star yellow"></i><i class="fa fa-star yellow"></i><i class="fa fa-star yellow"></i></a>';
		else if($author_count>=30 && $author_count<50 && $comment_author_email!=$adminEmail)
		echo '<a data-hint="活跃" class="hint hint--top"><i class="fa fa-moon-o yellow"></i></a>';
		else if($author_count>=50 &&$author_count<80 && $comment_author_email!=$adminEmail)
		echo '<a data-hint="评论员" class="hint hint--top"><i class="fa fa-moon-o yellow"></i><i class="fa fa-moon-o yellow"></i></a>';
		else if($author_count>=80 && $author_coun<200 && $comment_author_email!=$adminEmail)
		echo '<a data-hint="专业点评" class="hint hint--top"><i class="fa fa-moon-o yellow"></i><i class="fa fa-moon-o yellow"></i><i class="fa fa-moon-o yellow"></i></a>';
		else if($author_count>=200 && $comment_author_email!=$adminEmail)
		echo '<a data-hint="专家" class="hint hint--top"><i class="fa fa-sun-o yellow"></i></a>';
		}

		foreach ($linkurls as $linkurl) {
			if ($linkurl->link_url == $comment_author_url )
			echo '<a class="vip" target="_blank" href="/links" title="我是隔壁的"></a>';
		}
	}
	
	//日志与评论的相对时间显示
	function mop_time_diff( $time_type ) {
		switch( $time_type ){
			case 'comment':    //如果是评论的时间
				$time_diff = current_time('timestamp') - get_comment_time('U');
				 if( $time_diff <= 60 )
					echo ('刚刚');
				elseif( $time_diff > 60 && $time_diff <= 86400 )    //24 小时之内
					echo human_time_diff(get_comment_time('U'), current_time('timestamp')).'前';    //显示格式 OOXX 之前
				else
					printf(__('%1$s at %2$s'), get_comment_date(),  get_comment_time()); 
				break;
			case 'post';    //如果是日志的时间
				$time_diff = current_time('timestamp') - get_the_time('U');
				 if( $time_diff <= 60 )
					echo ('刚刚');
				elseif( $time_diff > 60 && $time_diff <= 86400 ) 
					echo human_time_diff(get_the_time('U'), current_time('timestamp')).'前';
				else
					the_time('Y-m-d H:i');
				break;
		}
	}