<?php get_header(); ?>
<?php while ( have_posts() ) : the_post(); ?>
<div class="container" id="main">
		<div class="row">
			<div class="col-md-9">
					<!--- Article-Head -->
					<div class="article-head">
						<ol class="breadcrumb">
						  <li><a href="<?php bloginfo('url'); ?>" rel="nofollow">首页</a></li>
						  <li><?php $categories = get_the_category(); echo(get_category_parents($categories[0]->term_id, TRUE, ''));  ?></li>
						  <li class="active">正文</li>
						</ol>
						<!-- Blog-Box -->
						<h1 class="article-title text-center"><?php the_title(); ?></h1>
						<div class="article-info">
							<div class="col-md-4 col-xs-7">
								<span class="article-author navy"><b><?php the_author(); ?></b></span>
								<span class="article-time">发表于：&nbsp;<?php the_time('Y-m-d'); ?></span>
							</div>
							<div class="col-md-4 col-md-offset-4 col-xs-5">
								<span class="article-view">阅读:<span class="article-count red"><?php if(function_exists('the_views')) { echo the_views(); } ?></span></span>
								<?php if('open' == $post->comment_status): ?><span class="article-view">评论:<span class="article-count"><?php comments_popup_link('0', '1 ', '%'); ?></span></span><?php endif; ?>
							</div>
						</div>
					</div>
					<!--- //Article-Head -->
					<section class="article">
					<!--- Article-content -->
					<div class="article-content">
						<?php
							the_content();
							global $wp_option;
							if($wp_option):
								echo '<div class="single_b">'.$wp_option['base']['single_b'].'</div>';
							endif;
						 ?>

					</div>
					<!--- //Article-content -->
					<div class="award">
						<p><a href="javascript:void(0)" id="award" title="打赏，支持一下">赏</a></p>
					</div>
					<div class="award_box">
						<div class="award_payimg">
							<img src="<?php echo get_template_directory_uri();?>/img/alipayimg.jpg" alt="扫码支持" title="扫一扫" />
						</div>
						<div class="pay_explain">扫码打赏，你说多少就多少</div>
						<div class="award_payselect">
							<div class="pay_item checked" data-id="alipay">
								<span class="radiobox"></span>
								<span class="pay_logo"><img src="<?php echo get_template_directory_uri();?>/img/alipay.jpg" alt="支付宝" /></span>
							</div>
							<div class="pay_item" data-id="weipay">
								<span class="radiobox"></span>
								<span class="pay_logo"><img src="<?php echo get_template_directory_uri();?>/img/wechat.jpg" alt="微信" /></span>
							</div>
						</div>
						<div class="award_info">
							<p>打开<span id="award_pay_txt">支付宝</span>扫一扫，即可进行扫码打赏哦</p>
						</div>
					</div>

					<div class="article-foot">
						<div class="article-foot-l pull-left">
							<h3>标签：</h3>
							<div class="article-tags">
								<?php the_tags('','',''); ?>
							</div>
							<h3>分享到：</h3>
							<div class="bdsharebuttonbox">
								<a class="bds_qzone" onclick="javascript:bShare.share(event,'qzone',0);return false;" title="分享到QQ空间"></a>
								<a class="bds_tsina" onclick="javascript:bShare.share(event,'sinaminiblog',0);return false;" title="分享到新浪微博"></a>
								<a class="bds_weixin" onclick="javascript:bShare.share(event,'weixin',0);return false;" title="分享到微信"></a><a class="bds_tqq" onclick="javascript:bShare.share(event,'qqmb',0);return false;" title="分享到腾讯微博"></a>
								<a class="bds_sqq" onclick="javascript:bShare.share(event,'qqim',0);return false;" title="分享到QQ好友"></a><a class="bds_douban" onclick="javascript:bShare.share(event,'douban',0);return false;" title="分享到豆瓣"></a>
								<a class="bds_copy" onclick="javascript:bShare.share(event,'clipboard',0);return false;" title="分享到复制网址"></a>
								<a class="bds_mail" onclick="javascript:bShare.share(event,'email',0);return false;" title="分享到邮件"></a>
							</div>							<script type="text/javascript" charset="utf-8" src="http://static.bshare.cn/b/buttonLite.js#uuid=&style=-1"></script>
						</div>
						<?php if (!wp_is_mobile()): ?>						<div class="article-qcode pull-right text-center">
							<img src="http://qr.liantu.com/api.php?&w=200&text=<?php echo get_the_permalink(); ?>" alt="扫一扫在手机阅读" />
							<p>扫一扫 在手机阅读、分享本文</p>
						</div>
						<?php endif; ?>
					</div>
					<div class="article-pn">
						<span class="preview col-md-6">上一篇：<?php  if (get_previous_post()) {previous_post_link('%link'); } else { echo "已经是最后的文章了"; }; ?></span>
						<span class="next <?php if(wp_is_mobile()){echo 'col-md-6';}else{echo 'pull-right';} ?>">下一篇：<?php  if (get_next_post()) {next_post_link('%link'); } else { echo "已经是最新的文章了"; }; ?></span>
					</div>
					<div class="related">
						<h3>相关文章</h3>
						<ul class="row related-box">
							<?php include('config/related.php'); ?>
						</ul>
					</div>
					<?php if ( comments_open() ) : ?>
					<div class="comments">
						<?php comments_template(); ?>
					</div>
					<?php endif; ?>
				</section>
				<!-- //Blog-Box -->
			</div>
			<?php endwhile; ?>
			<?php get_sidebar(); ?>
			<?php get_footer('single'); ?>
