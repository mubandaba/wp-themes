<?php get_header(); ?>
<div class="container" id="main">
		<div class="row">
			<div class="col-md-9">
				<?php
					$args = array(
					  'post_type'=>'slider',
					  'posts_per_page' => 6,
					);
					query_posts($args);
					if(have_posts()):
						$i = 0;
				?>
				<!-- Slider -->
				<div class="slider">
						<div id="slide-box" class="carousel slide" data-ride="carousel">
					  <!-- Wrapper for slides -->
					  <div class="carousel-inner" role="listbox">
							<?php
								while(have_posts()): the_post();
								$slider_pic = get_post_meta($post->ID,'slider_pic',true);
								$slider_link = get_post_meta($post->ID,'slider_link',true);
							?>
					    <div class="item <?php if ($i == 0)	echo "active"; ?>">
					      <a target="_blank" href="<?php echo $slider_link; ?>"><img src="<?php echo $slider_pic ?>" alt="<?php the_title(); ?>" ></a>
					    </div>
					    <?php $i++;	endwhile; ?>
							<ol class="carousel-indicators">
								<?php
									for($len=0; $len<$i; $len++){
								?>
											<li data-target="#slide-box" data-slide-to="<?php echo $len; ?>" <?php if($len==0) echo 'class="active"'; ?>></li>
								<?php } ?>
						  </ol>

					  <!-- Controls -->
					  <a class="left carousel-control" href="#slide-box" role="button" data-slide="prev">
					    <i class="fa fa-chevron-circle-left glyphicon-chevron-left"></i>
					    <span class="sr-only">Previous</span>
					  </a>
					  <a class="right carousel-control" href="#slide-box" role="button" data-slide="next">
					    <i class="fa fa-chevron-circle-right glyphicon-chevron-right"></i>
					    <span class="sr-only">Next</span>
					  </a>
					</div>
				</div>
				</div>
				<?php endif; wp_reset_query(); ?>
				<!-- //Slider -->
				<!-- Blog-Box -->
				<?php
					if(have_posts()):
				?>
				<section>
					<?php while (have_posts()) : the_post();  ?>
					<div class="post-box fadeInUp animated">
						<div class="col-sm-3 post-img">
							<?php if(has_post_thumbnail()){the_post_thumbnail('thumbnail'); } else {echo wp_the_thumbnail();} ?>
						</div>
						<div class="col-sm-9 post-item">
							<h3><a href="<?php the_permalink(); ?>" target="_blank" rel="bookmark" title="<?php the_title_attribute(); ?>" ><?php the_title(); ?></a></h3>
							<p class="post-item-text">
								<?php
									if (has_excerpt()) the_excerpt();
									else echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 140,"...");
								?></p>
							<div class="post-item-info">
								<span class="post-item-author"><i class="fa fa-mortar-board"></i><?php the_author(); ?></span>
								<?php
									$category = get_the_category();
									if( $category[0] ){
										echo '<span class="post-label"><a href="'.get_category_link($category[0]->term_id ).'" title="'.$category[0]->cat_name.'"><i class="fa fa-list-ul"></i>'.$category[0]->cat_name.'</a></span>';
									};
								?>
								<span class="tm"><i class="fa fa-clock-o"></i><?php the_time('Y-m-d'); ?></span>
								<span class="count"><i class="fa fa-eye"></i><?php if(function_exists('the_views')) { echo the_views(); } ?></span>
							</div>
						</div>
					</div>
					<?php endwhile; ?>
				</section>
				<ul class="pagination">
				  <?php par_pagenavi(3); ?>
				</ul>
				<?php endif; ?>
				<!-- //Blog-Box -->
			</div>
			<?php get_sidebar(); ?>
			<?php get_footer(); ?>
