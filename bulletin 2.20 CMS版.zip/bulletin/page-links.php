<?php
/*
Template Name:友情链接
*/
?>
<?php get_header(); ?>
<style type="text/css">
.link_page{padding:15px 0 15px 30px;list-style:none;}
.link_page h2{background-color: #555;color: #fff;line-height: 1.75;padding: 8px 30px 8px 16px;border-left:5px solid #ff9d34;border-radius: 4px;font-size: 16px;}
.link_page li h2{float:left;width:990px;margin:10px 0;}
.link_page li{display:inline-block;}
.link_page li a{float:left;width:170px;margin:0 10px 10px 0;padding:10px;border:1px solid #DEDEDE;border-radius: 4px;box-shadow: #eee 0 0 2px;font-size: 16px;line-height: 24px;}
.link_page li a:hover{background: #dedede;color:#1ABC9C}
.link_page li img{float:left;width:25px;height:25px;margin:0 14px 0 2px;}
.link_page ul{overflow:hidden;}
</style>
<?php while ( have_posts() ) : the_post(); ?>
<div class="container">
		<div class="row">
			<div class="col-md-12">
				<!-- Blog-Box -->
				<section class="article">
					<!--- Article-Head -->
					<div class="article-head">
						<h1 class="article-title text-center"><?php the_title(); ?></h1>
						<div class="article-info">
							<span class="article-author navy"><?php the_author(); ?></span>
							<span class="article-time"><?php the_time('Y-m-d'); ?></span>
							<span class="article-view pull-right">阅读:<span class="article-count red"><?php if(function_exists('the_views')) { echo the_views(); } ?></span></span>
							<?php if('open' == $post->comment_status): ?><span class="article-view pull-right">评论:<span class="article-count"><?php comments_popup_link('0', '1 ', '%'); ?></span></span><?php endif; ?>
						</div>
					</div>
					<!--- //Article-Head -->
					
					<!--- Article-content -->
					<div class="article-content">
						<div class="link_page">
            				<h2>友情链接排名不分先后，随机排序。</h2>
                                    <br>
            				<ul>
            				<?php
            				$bookmarks = get_bookmarks('title_li=&orderby=rand'); //全部链接随机输出
            				//如要输出链接分类ID为5的链接 title_li=&categorize=0&category=5&orderby=rand
            				if ( !empty($bookmarks) ) {
            					foreach ($bookmarks as $bookmark) {
            					echo '<li><a href="' .$bookmark->link_url . '" title="' . $bookmark->link_description . '" target="_blank" ><img src="http://api.byi.pw/favicon/?url=' . $bookmark->link_url . '" />' . $bookmark->link_name . '</a></li>';
            						}
            					}
            				?>
            				</ul>
            					
            		    </div>
            		    <?php the_content(); ?>
					</div>
					<!--- //Article-content -->
					
					<div class="award">
						<p><a href="javascript:void(0)" id="award" title="打赏，支持一下">打赏</a></p>
					</div>
					
					<div class="award_box">
						<div class="award_payimg">
							<img src="<?php echo get_template_directory_uri();?>/img/alipayimg.jpg" alt="扫码支持" title="扫一扫" />
						</div>
						<div class="pay_explain">扫码打赏，你说多少就多少</div>
						<div class="award_payselect">
							<div class="pay_item checked" data-id="alipay">
								<span class="radiobox"></span>
								<span class="pay_logo"><img src="<?php echo get_template_directory_uri();?>/img/alipay.jpg" alt="支付宝" /></span>
							</div>
							<div class="pay_item" data-id="weipay">
								<span class="radiobox"></span>
								<span class="pay_logo"><img src="<?php echo get_template_directory_uri();?>/img/wechat.jpg" alt="微信" /></span>
							</div>
						</div>
						<div class="award_info">
							<p>打开<span id="award_pay_txt">支付宝</span>扫一扫，即可进行扫码打赏哦</p>
						</div>
					</div>
					
					<?php if ( comments_open() ) : ?>
					<div class="comments">
						<h3>精彩评论</h3>
						<?php comments_template(); ?>
					</div>
					<?php endif; ?>
				</section>
				<!-- //Blog-Box -->
			</div>
			<?php endwhile; ?>
			</div>
			</div>
			<?php get_footer('single'); ?>
			