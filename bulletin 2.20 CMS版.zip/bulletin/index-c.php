<?php get_header(); ?>
<div class="maintop">
	<div class="container">
		<div class="row">
			<!-- Slider -->
			<div class="col-md-6 slider">
				<?php
					$args = array(
						'post_type'=>'slider',
						'posts_per_page' => 6,
					);
					query_posts($args);
					if(have_posts()):
						$i = 0;
				?>
					<div id="slide-box" class="carousel slide" data-ride="carousel">
					<!-- Wrapper for slides -->
					<div class="carousel-inner" role="listbox">
						<?php
							while(have_posts()): the_post();
							$slider_pic = get_post_meta($post->ID,'slider_pic',true);
							$slider_link = get_post_meta($post->ID,'slider_link',true);
						?>
						<div class="item <?php if ($i == 0)	echo "active"; ?>">
							<a target="_blank" href="<?php echo $slider_link; ?>"><img src="<?php echo $slider_pic ?>" alt="<?php the_title(); ?>" ></a>
						</div>
						<?php $i++;	endwhile; ?>
						<ol class="carousel-indicators">
							<?php
								for($len=0; $len<$i; $len++){
							?>
										<li data-target="#slide-box" data-slide-to="<?php echo $len; ?>" <?php if($len==0) echo 'class="active"'; ?>></li>
							<?php } ?>
						</ol>

						<!-- Controls -->
						<a class="left carousel-control" href="#slide-box" role="button" data-slide="prev">
							<i class="fa fa-chevron-circle-left glyphicon-chevron-left"></i>
							<span class="sr-only">Previous</span>
						</a>
						<a class="right carousel-control" href="#slide-box" role="button" data-slide="next">
							<i class="fa fa-chevron-circle-right glyphicon-chevron-right"></i>
							<span class="sr-only">Next</span>
						</a>
					</div>
				</div>
				<script type="text/javascript" src="<?php echo get_template_directory_uri()?>/js/bootstrap-touch-slider.js"></script>
				<script type="text/javascript">
					$('#slide-box').bsTouchSlider();
				</script>
				<?php endif; wp_reset_query(); ?>
			</div>
			<!-- //Slider -->
			<div class="col-md-3">
				<div class="hometop">
					<h3 class="hometitle navy-bg">最新文章</h3>
					<?php
						$args = array(
							'posts_per_page' => 6,
						);
						query_posts($args);
						if(have_posts()):
					?>
					<ul>
						<?php while (have_posts()) : the_post();  ?>
						<li><a href="<?php the_permalink(); ?>" target="_blank" rel="bookmark" title="<?php the_title_attribute(); ?>" ><span class="hometime"><?php the_time('m-d'); ?></span><?php the_title(); ?></a></li>
						<?php endwhile; ?>
					</ul>
				<?php endif; wp_reset_query(); ?>
				</div>
			</div>
			<div class="col-md-3">
				<div class="hometop">
					<img src="<?php echo get_template_directory_uri().'/img/alipayimg.jpg'; ?>" alt="" />
					<img src="<?php echo get_template_directory_uri().'/img/alipayimg.jpg'; ?>" alt="" />
					<div class="homenote red-bg">
						欢迎扫二维码，加入QQ群
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="container" id="main">
		<div class="row">
			<div class="col-md-9">
				<div class="cmsbox clearfix">
					<div class="cmstitle">
						<h3><i class="fa fa-list-ul"></i>苹果体验店</h3>
						<a href="#" class="pull-right">全部<i class="fa fa-chevron-right"></i></a>
					</div>
					<ul class="cmsul">
						<li class="col-md-3 cmslist"><a href="#">
							<div class="cmsdiv">
								<img src="http://www.ldstars.com/wp-content/themes/bulletin/img/random/thumb-4.jpg" alt="" />
								<div class="cmsmask">
									<h3>Bulletin主题文件结构及详细入门教程</h3>
									<p>
										<span><i class="fa fa-eye"></i>333</span>
										<span><i class="fa fa-clock-o"></i>2017-01-09</span>
									</p>
								</div>
							</div>
						</a></li>
						<li class="col-md-3 cmslist"><a href="#">
							<div class="cmsdiv">
								<img src="http://www.ldstars.com/wp-content/themes/bulletin/img/random/thumb-4.jpg" alt="" />
								<div class="cmsmask">
									<h3>微信小程序标题</h3>
									<p>
										<span><i class="fa fa-eye"></i>333</span>
										<span><i class="fa fa-clock-o"></i>2017-01-09</span>
									</p>
								</div>
							</div>
						</a></li>
						<li class="col-md-3 cmslist"><a href="#">
							<div class="cmsdiv">
								<img src="http://www.ldstars.com/wp-content/themes/bulletin/img/random/thumb-4.jpg" alt="" />
								<div class="cmsmask">
									<h3>微信小程序标题</h3>
									<p>
										<span><i class="fa fa-eye"></i>333</span>
										<span><i class="fa fa-clock-o"></i>2017-01-09</span>
									</p>
								</div>
							</div>
						</a></li>
						<li class="col-md-3 cmslist"><a href="#">
							<div class="cmsdiv">
								<img src="http://www.ldstars.com/wp-content/themes/bulletin/img/random/thumb-4.jpg" alt="" />
								<div class="cmsmask">
									<h3>微信小程序标题</h3>
									<p>
										<span><i class="fa fa-eye"></i>333</span>
										<span><i class="fa fa-clock-o"></i>2017-01-09</span>
									</p>
								</div>
							</div>
						</a></li>
					</ul>
				</div>

				<div class="cmsbox clearfix">
					<div class="cmstitle">
						<h3><i class="fa fa-list-ul"></i>苹果体验店</h3>
						<a href="#" class="pull-right">全部<i class="fa fa-chevron-right"></i></a>
					</div>
					<ul class="cmsul">
						<li class="col-md-3"><a href="#">
							<div class="cmslist-1">
								<img src="http://www.ldstars.com/wp-content/themes/bulletin/img/random/thumb-4.jpg" alt="" />
								<div class="cmsmask-1">
									<h3>Bulletin主题文件结构及详细入门教程</h3>
									<p>
										<span><i class="fa fa-eye"></i>333</span>
										<span><i class="fa fa-clock-o"></i>2017-01-09</span>
									</p>
								</div>
							</div>
						</a></li>
						<li class="col-md-3"><a href="#">
							<div class="cmslist-1">
								<img src="http://www.ldstars.com/wp-content/themes/bulletin/img/random/thumb-4.jpg" alt="" />
								<div class="cmsmask-1">
									<h3>Bulletin主题文件结构及详细入门教程</h3>
									<p>
										<span><i class="fa fa-eye"></i>333</span>
										<span><i class="fa fa-clock-o"></i>2017-01-09</span>
									</p>
								</div>
							</div>
						</a></li>
						<li class="col-md-3"><a href="#">
							<div class="cmslist-1">
								<img src="http://www.ldstars.com/wp-content/themes/bulletin/img/random/thumb-4.jpg" alt="" />
								<div class="cmsmask-1">
									<h3>Bulletin主题文件结构及详细入门教程</h3>
									<p>
										<span><i class="fa fa-eye"></i>333</span>
										<span><i class="fa fa-clock-o"></i>2017-01-09</span>
									</p>
								</div>
							</div>
						</a></li>
						<li class="col-md-3"><a href="#">
							<div class="cmslist-1">
								<img src="http://www.ldstars.com/wp-content/themes/bulletin/img/random/thumb-4.jpg" alt="" />
								<div class="cmsmask-1">
									<h3>Bulletin主题文件结构及详细入门教程</h3>
									<p>
										<span><i class="fa fa-eye"></i>333</span>
										<span><i class="fa fa-clock-o"></i>2017-01-09</span>
									</p>
								</div>
							</div>
						</a></li>
					</ul>
				</div>

				<div class="cmsbox clearfix">
					<div class="cmstitle">
						<h3><i class="fa fa-list-ul"></i>苹果体验店</h3>
						<a href="#" class="pull-right">全部<i class="fa fa-chevron-right"></i></a>
					</div>
					<ul class="cmsul">
						<li class="col-md-4 cmslist-2"><a href="#">
							<h4>Bulletin主题文件结构及详细入门教程</h4>
							<div class="cmsmask-2">
								<img src="http://www.ldstars.com/wp-content/themes/bulletin/img/random/thumb-4.jpg" alt="" />
								<div class="cmslist-2-desc">
									Bulletin主题欢迎使用，小小物联实验室出品，必属精品。
								</div>
							</div>
							<div class="cmslist-2-info">
								<span><i class="fa fa-eye"></i>333</span>
								<span><i class="fa fa-clock-o"></i>2017-01-09</span>
							</div>
						</a></li>
						<li class="col-md-4 cmslist-2"><a href="#">
							<h4>Bulletin主题文件结构及详细入门教程sdjlfjaslj</h4>
							<div class="cmsmask-2">
								<img src="http://www.ldstars.com/wp-content/themes/bulletin/img/random/thumb-4.jpg" alt="" />
								<div class="cmslist-2-desc">
									Bulletin主题欢迎使用，小小物联实验室出品，必属精品。
								</div>
							</div>
							<div class="cmslist-2-info">
								<span><i class="fa fa-eye"></i>333</span>
								<span><i class="fa fa-clock-o"></i>2017-01-09</span>
							</div>
						</a></li>
						<li class="col-md-4 cmslist-2"><a href="#">
							<h4>Bulletin主题文件结构及详细入门教程</h4>
							<div class="cmsmask-2">
								<img src="http://www.ldstars.com/wp-content/themes/bulletin/img/random/thumb-4.jpg" alt="" />
								<div class="cmslist-2-desc">
									Bulletin主题欢迎使用，小小物联实验室出品，必属精品。
								</div>
							</div>
							<div class="cmslist-2-info">
								<span><i class="fa fa-eye"></i>333</span>
								<span><i class="fa fa-clock-o"></i>2017-01-09</span>
							</div>
						</a></li>
						<li class="col-md-4 cmslist-2"><a href="#">
							<h4>Bulletin主题文件结构及详细入门教程</h4>
							<div class="cmsmask-2">
								<img src="http://www.ldstars.com/wp-content/themes/bulletin/img/random/thumb-4.jpg" alt="" />
								<div class="cmslist-2-desc">
									Bulletin主题欢迎使用，小小物联实验室出品，必属精品。
								</div>
							</div>
							<div class="cmslist-2-info">
								<span><i class="fa fa-eye"></i>333</span>
								<span><i class="fa fa-clock-o"></i>2017-01-09</span>
							</div>
						</a></li>
					</ul>
				</div>

				<div class="cmsbox-3 clearfix col-md-6">
					<div class="cmsbox">
						<div class="cmstitle">
							<h3><i class="fa fa-list-ul"></i>苹果体验店</h3>
							<a href="#" class="pull-right">全部<i class="fa fa-chevron-right"></i></a>
						</div>
						<ul class="cmsul">
							<li class="cmslist-3"><a href="#">
								<span class="cmslist-3-time">2017-02-05</span>
								<h4>Bulletin主题文件结构及详细入门教程</h4>
								<span class="cmslist-3-more pull-right">查看<i class="fa fa-chevron-right"></i></span>
							</a></li>
							<li class="cmslist-3"><a href="#">
								<span class="cmslist-3-time">2017-02-05</span>
								<h4>Bulletin主题文件结构及详细入门教程</h4>
								<span class="cmslist-3-more pull-right">查看<i class="fa fa-chevron-right"></i></span>
							</a></li>
							<li class="cmslist-3"><a href="#">
								<span class="cmslist-3-time">2017-02-05</span>
								<h4>Bulletin主题文件结构及详细入门教程</h4>
								<span class="cmslist-3-more pull-right">查看<i class="fa fa-chevron-right"></i></span>
							</a></li>
							<li class="cmslist-3"><a href="#">
								<span class="cmslist-3-time">2017-02-05</span>
								<h4>Bulletin主题文件结构及详细入门教程</h4>
								<span class="cmslist-3-more pull-right">查看<i class="fa fa-chevron-right"></i></span>
							</a></li>
							<li class="cmslist-3"><a href="#">
								<span class="cmslist-3-time">2017-02-05</span>
								<h4>Bulletin主题文件结构及详细入门教程</h4>
								<span class="cmslist-3-more pull-right">查看<i class="fa fa-chevron-right"></i></span>
							</a></li>
						</ul>
					</div>
				</div>

				<div class="cmsbox-3 clearfix col-md-6">
					<div class="cmsbox">
						<div class="cmstitle">
							<h3><i class="fa fa-list-ul"></i>苹果体验店</h3>
							<a href="#" class="pull-right">全部<i class="fa fa-chevron-right"></i></a>
						</div>
						<ul class="cmsul">
							<li class="cmslist-3"><a href="#">
								<span class="cmslist-3-time">2017-02-05</span>
								<h4>Bulletin主题文件结构及详细入门教程</h4>
								<span class="cmslist-3-more pull-right">查看<i class="fa fa-chevron-right"></i></span>
							</a></li>
							<li class="cmslist-3"><a href="#">
								<span class="cmslist-3-time">2017-02-05</span>
								<h4>Bulletin主题文件结构及详细入门教程</h4>
								<span class="cmslist-3-more pull-right">查看<i class="fa fa-chevron-right"></i></span>
							</a></li>
							<li class="cmslist-3"><a href="#">
								<span class="cmslist-3-time">2017-02-05</span>
								<h4>Bulletin主题文件结构及详细入门教程</h4>
								<span class="cmslist-3-more pull-right">查看<i class="fa fa-chevron-right"></i></span>
							</a></li>
							<li class="cmslist-3"><a href="#">
								<span class="cmslist-3-time">2017-02-05</span>
								<h4>Bulletin主题文件结构及详细入门教程</h4>
								<span class="cmslist-3-more pull-right">查看<i class="fa fa-chevron-right"></i></span>
							</a></li>
							<li class="cmslist-3"><a href="#">
								<span class="cmslist-3-time">2017-02-05</span>
								<h4>Bulletin主题文件结构及详细入门教程</h4>
								<span class="cmslist-3-more pull-right">查看<i class="fa fa-chevron-right"></i></span>
							</a></li>
						</ul>
					</div>
				</div>

			</div>
			<?php get_sidebar(); ?>
			<?php get_footer(); ?>
