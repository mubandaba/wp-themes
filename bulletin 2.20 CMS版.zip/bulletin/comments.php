<?php
	if (!empty($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
				die ( __('Please do not load this page directly. Thanks!') );

	if ( post_password_required() ) { ?>
			<p class="nocomments">必须输入密码，才能查看评论！</p>
	<?php
			return;
	}


	// 自定义评论样式
	function wp_comment($comment, $args, $depth) {
		$GLOBALS['comment'] = $comment;
		global $commentcount, $page;
?>
	<li <?php comment_class(); ?> id="comment-<?php comment_ID() ?>">
	   <div id="div-comment-<?php comment_ID() ?>" class="comment-body">
		  <?php $add_below = 'div-comment'; ?>
		  <div class="gravatar">
			<div class="comment-author vcard">
				<?php echo get_avatar($comment, 50); ?>
			</div>
		  </div>
		<div class="floor"><?php
		if(!$parent_id = $comment->comment_parent){//正序排列
			printf('%1$s楼', ++$commentcount);
		 }
	 ?></div>
		 <div class="commenttext">
			 <span class="commentid"><span class="comment_author"><?php commentauthor(); ?></span><?php get_author_class($comment->comment_author_email,$comment->comment_author_url)?></span>
					<div class="comment_text">
					<?php if ( $comment->comment_approved == '0' ){?>
					<span style="color:#f00;">您的评论正在等待审核中...</span>
					<?php comment_text(); ?>
					<?php }else{ ?>
					<?php comment_text(); ?>
					<?php } ?>
					</div>
					<div class="comment-info">
						<span class="datetime"><i class="fa fa-clock-o"></i><?php comment_date('Y-m-d h:i:s'); ?></span>
						<?php if ( $comment->comment_approved != '0' ){ ?><span class="reply"><i class="fa fa-reply"></i><?php comment_reply_link(array_merge( $args, array('reply_text' => '回复', 'add_below' =>$add_below, 'depth' => $depth, 'max_depth' => $args['max_depth']))); ?></span><?php } ?><span class="edit_comment"><?php edit_comment_link('[编辑]','&nbsp;&nbsp;',''); ?></span>
					</div>
		</div>
	  </div>
<?php
	}

function wp_end_comment() {
		echo '</li>';
}

if ($comments) : ?>
	<h3>精彩评论</h3>
	<div id="comments"><span style="font-weight:bold;font-size:14px;margin-right:30px;">全部回复</span><span style="color: #f60;font-size:18px;font-weight: bold;"><?php comments_number('0', '1', '%' );?></span>人评论<span style="color: #f60;font-size:18px;margin-left:30px;font-weight: bold;"><?php if(function_exists('the_views')) { echo the_views(); } ?></span>人参与</div>
	<!-- 评论列表-->
	<div id="comment-lists">
		<ol class="commentlist">
		<?php wp_list_comments('style=ul&format=html5&avatar_size=40&max_depth=100&callback=wp_comment&end-callback=wp_end_comment'); ?>
		</ol>
		<div class="navigation">
			<div id="comments-navi"><?php paginate_comments_links('prev_text=上一页&next_text=下一页');?></div>
		</div>
    </div>
	<!-- //评论列表-->
 <?php else :
	if('open' == $post->comment_status): ?>
        <h3>还没有评论，快来抢沙发！</h3>
	<?php else : // comments are closed ?>
		<p class="nocomments"><a href="<?php bloginfo('wpurl'); ?>/message">抱歉，评论已关闭，请移步留言板！</a></p>
	<?php endif;
		endif;
	if ('open' == $post->comment_status) : ?>
	<div id="respond">
    <p>
	<?php if ( '' != $comment_author ): ?>
		<div class="author-back"><?php printf(__('<span>%s</span>'), $comment_author); ?>
		<a href="javascript:toggleCommentAuthorInfo();" id="toggle-comment-author-info">[ 编辑信息 ]</a> <?php cancel_comment_reply_link('[ 取消回复 ]'); ?></div>
	</p>
	<script type="text/javascript">
		jQuery(document).ready(function(){
			jQuery('#comment-author-info').hide();
		});
	</script>
	 <?php endif; ?>
	<?php
		$args = array(
			'fields' => apply_filters( 'comment_form_default_fields',array(
				'author' =>
					'<div id="comment-author-info"><p class="comment-form-author col-md-4">' .
					'<input name="author" type="text" placeholder="昵称：*" value="' . esc_attr( $commenter['comment_author'] ) .
					'" size="30" /></p>',
				'email' =>
					'<p class="comment-form-email col-md-4">' .
					'<input name="email" type="text" placeholder="邮箱：*" value="' . esc_attr(  $commenter['comment_author_email'] ) .
					'" size="30" /></p>',
				'url' =>
					'<p class="comment-form-url col-md-4">' .
					'<input name="url" type="text" placeholder="网址" value="' . esc_attr( $commenter['comment_author_url'] ) .
					'" size="30" /></p></div>'
			)),
			'comment_field' =>
				'<p class="col-md-12 comments-form"><textarea id="comment" name="comment" tabindex="4" cols="40" rows="3" aria-required="true"></textarea></p>',
			'logged_in_as' => '<p class="logged-in-as">' .
				get_avatar($comment_author_email, 40).
				sprintf(
				__( '登录用户：<a href="%1$s">%2$s</a>&nbsp;<a href="%3$s" title="Log out of this account">【退出？】</a>' ),
				  admin_url( 'profile.php' ),
				  $user_identity,
				  wp_logout_url( apply_filters( 'the_permalink', get_permalink( ) ) )
				) . '</p>',
			'id_form'           => 'commentform',
			'id_submit'         => 'submit',
			'title_reply'       => '',
			'title_reply_to'    => __( 'Leave a Reply to %s' ),
			'cancel_reply_link' => '【取消回复】',
			'label_submit'      => __( 'Post Comment' ),
			'comment_notes_after' => '<label for="comment_mail_notify" style="display:none"><input type="checkbox" name="comment_mail_notify" id="comment_mail_notify" value="comment_mail_notify" checked="checked"/>有人回复时邮件通知我</label>',
		);
		comment_form($args);
	?>
	<div id="loading-img"><img src="<?php bloginfo('template_directory');?>/img/loading_com.gif" alt="loading" /></div>
	<div id="error-comments"></div>
	<script type="text/javascript">	//快捷回复 Ctrl+Enter
	//<![CDATA[
		jQuery(document).keypress(function(e){
			if(e.ctrlKey && e.which == 13 || e.which == 10) {
				jQuery(".submit").click();
				document.body.focus();
			} else if (e.shiftKey && e.which==13 || e.which == 10) {
				jQuery(".submit").click();
			}
		})
	// ]]>
	//<![CDATA[
	var changeMsg = "[ 编辑信息 ]";
	var closeMsg = "[ 隐藏信息 ]";
	function toggleCommentAuthorInfo() {
		jQuery('#comment-author-info').slideToggle('slow', function(){
			if ( jQuery('#comment-author-info').css('display') == 'none' ) {
				jQuery('#toggle-comment-author-info').text(changeMsg);
				} else {
				jQuery('#toggle-comment-author-info').text(closeMsg);
			}
		});
	}
	//]]>
	</script>
  </div>
  <?php endif; ?>
