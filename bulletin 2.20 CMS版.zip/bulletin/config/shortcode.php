<?php
///////////////////////////短代码///////////////////////////
//文件下载
function down($atts,$content=null){
	extract(shortcode_atts(array("href"=>'',"password"=>""),$atts));
	return '<div class="down_table"><table><thead><tr><td>资源名称：</td><td style="color: #FF3366;">'.$content.'</td></thead><tbody><tr><td>下载地址：</td><td><a href="'.$href.'" target="_blank"><i class="fa fa-cloud-download fa-lg"></i>高速下载</a></td></tr><tr><td>相关密码：</td><td style="color: #FF3366;">'.$password.'</td></tr></tbody></table></div>';
	}
add_shortcode('down','down');

//链接跳转
function urlLink($atts, $content = null) {
	extract(shortcode_atts(array("href"=>'http://'), $atts));
	return '<span class="url"><a href="'.$href.'" target="_blank" class="transition">'.$content.'<i class="fa fa-external-link"></i></a></span>';
}
add_shortcode('url', 'urlLink');

//收缩栏
function post_toggle($atts, $content=null){
	extract(shortcode_atts(array("title"=>''),$atts));
	$output = '<div class="collapse-item"><div class="collapse-title"><i class="fa fa-question-circle"></i>'.$title.'<i class="fa fa-chevron-circle-up pull-right"></i></div>';
	$output .= '<div class="collapse-on">'.$content.'</div></div>';
	return $output;
}
add_shortcode('toggle','post_toggle');
/////////////////////////////////////////////////////////////

function appthemes_add_quicktags(){
    if (wp_script_is('quicktags')){
?>
<script type="text/javascript">
QTags.addButton( 'down', '下载按钮', '[down href="" password="无密码"]资源名称[/down]');
QTags.addButton( 'url', '链接', '[url href="http://"]链接文字[/url]');
QTags.addButton( 'toggle', '收缩栏', '[toggle title="标题"]这里输入内容[/toggle]');
//这儿共有四对引号，分别是按钮的ID、显示名、点一下输入内容、再点一下关闭内容（此为空则一次输入全部内容），表示换行。
</script>
<?php
	} }
add_action( 'admin_print_footer_scripts', 'appthemes_add_quicktags' );
?>
