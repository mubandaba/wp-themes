<title><?php if ( is_home() ) {   
        bloginfo('name'); echo " - "; bloginfo('description'); 
    } elseif ( is_category() ) {   
        single_cat_title(); echo " - "; bloginfo('name');   
    } elseif (is_single() || is_page() ) {   
        single_post_title(); echo " - "; bloginfo('name');   
    } elseif (is_search() ) {   
        echo esc_attr($_GET["s"]) ."的搜索结果";echo " - "; bloginfo('name');   
    } elseif (is_404() ) {   
        echo '糟糕...我把网站弄丢了';   
    } elseif (is_author() ) {   
       wp_title('');echo " 在 ".get_bloginfo('name')." 的个人主页";   
    }elseif(function_exists('is_tag')){
		if ( is_tag() ){
			single_tag_title("", true);echo " - "; bloginfo('name');
		}
	}else {   
       wp_title('',true);   
    } ?></title>	
<?php
    global $wp_option;	
    if (is_home()) {   
    $description =  $wp_option["base"]["desc"];   
    $keywords = $wp_option["base"]["keywords"];   
   }   
   elseif (is_single() || is_page()) {   
    $description1 = get_post_meta($post->ID, "postDesc", true);  
    $description2 = mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 150, "…");    
    $description = $description1 ? $description1 : $description2;    
    $keywords = get_post_meta($post->ID, "postTag", true);   
    if($keywords == '') {
        $tags = wp_get_post_tags($post->ID);       
        foreach ($tags as $tag ) {           
            $keywords = $keywords . $tag->name . ", ";       
        } 
        $keywords = rtrim($keywords, ', ');   
    }   
}   
  elseif (is_category()) {   
    $description = category_description();   
    $keywords = single_cat_title('', false);   
}   
  elseif (is_tag()){   
    $description = tag_description();   
    $keywords = single_tag_title('', false);   
}   
   elseif (is_404()){
       $description = "404页面,网页找不到了";
       $keywords = "404";
}
  $description = trim(strip_tags($description));   
  $keywords = trim(strip_tags($keywords));   
?> 
<meta name="keywords" content="<?php echo $keywords; ?>" />  
<meta name="description" content="<?php echo $description; ?>" />   
