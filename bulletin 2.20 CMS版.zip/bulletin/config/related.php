<?php
	global $post;
	$post_tags = wp_get_post_tags($post->ID);
	$tag_list = array();
	if ($post_tags) {
	  foreach ($post_tags as $tag) {
		$tag_list[] .= $tag->term_id;
	}
	$args = array(
	'tag__in' => $tag_list,
	'category__not_in' => array(NULL),
	'post__not_in' => array($post->ID),
	'showposts' => 3,
	'ignore_sticky_posts' => 1
	);
	$query = new WP_Query( $args );
	if ($query->have_posts()) :
		while ($query->have_posts()) : $query->the_post();
	?>
	  <li class="col-sm-6">
		<a href="<?php the_permalink() ?>" target="_blank" rel="bookmark" title="<?php the_title_attribute(); ?>" ><i class="fa fa-hand-o-right"></i><?php the_title(); ?></a>
	   </li>
	<?php
		endwhile;
	else:
		echo '<div class="col-sm-12">暂无相关推荐文章</div>';
	endif;
	}else{
		echo '<div class="col-sm-12">暂无相关推荐文章</div>';
	}
	wp_reset_postdata();
?>
