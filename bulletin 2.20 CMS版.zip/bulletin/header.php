<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="icon" href="<?php echo home_url(); ?>/favicon.ico" mce_href="<?php echo home_url(); ?>/favicon.ico" type="image/x-icon" />
    <?php include("config/seo.php"); ?>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="//cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
	<!-- Fixed navbar -->
  <div class="navfilter">

  </div>
	<nav class="navbar navbar-default">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#b-navbar-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="<?php echo home_url(); ?>"><img src="<?php echo get_template_directory_uri();?>/img/logo.png" alt="Logo"></a>
			</div>
			<div class="collapse navbar-collapse" id="b-navbar-collapse">
				<?php wp_nav_menu( array( 'theme_location' => 'header-menu','menu_id' => '','container' => '','menu_class'=> 'nav navbar-nav', 'walker'=> new wp_bootstrap_navwalker())); ?>
			</div>
		</div>
	</nav>
	<div class="banner">
		<form class="search-form center" action="<?php echo home_url(); ?>">
			<div class="form-group">
				<input type="text" name="s" id="bdcsMain" class="form-control" placeholder="关键字...">
				<button type="submit" class="btn btn-default"><i class="fa fa-search navy"></i></button>
			</div>
		</form>
	</div>
