<!-- Widget-Box -->
<div class="col-md-3 widget">
	<?php
		if (is_home() || is_category()):
		if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('首页小工具') ) :

		endif;endif;

		if(is_single()):
		if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('文章小工具') ) :

		endif; endif;

		if(is_page()):
		if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('页面小工具') ) :

		endif; endif;
	?>
</div>
<!-- //Widget-Box -->
</div>
</div>
