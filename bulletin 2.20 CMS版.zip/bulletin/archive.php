<?php get_header(); ?>

  <!-- CAT-HEAER -->
  <div class="cat-header">
    <div class="overlay">
      <h2>快拨网络电话，开启网络新时代</h2>
      <p class="text-center"><a href="<?php bloginfo('url'); ?>">首页</a> / <?php single_cat_title(); ?></p>
    </div>
  </div>
  <!-- END CAT-HEAER -->

  <!-- CAT-MAIN -->
  <div class="cat-main">
    <div class="container">
      <div class="row">
        <div class="col-md-9">
          <!-- Blog-Box -->
  				<section>
  					<?php while ( have_posts() ) : the_post(); ?>
  						<div class="post-box fadeInUp animated">
  							<div class="col-sm-3 post-img">
  								<?php if(has_post_thumbnail()){the_post_thumbnail('thumbnail'); } else {echo wp_the_thumbnail();} ?>
  							</div>
  							<div class="col-sm-9 post-item">
  								<h3><a href="<?php the_permalink(); ?>" target="_blank" rel="bookmark" title="<?php the_title_attribute(); ?>" ><?php the_title(); ?></a></h3>
  								<p class="post-item-text">
  									<?php
  										if (has_excerpt()) the_excerpt();
  										else echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 140,"...");
  									?></p>
  								<div class="post-item-info">
  									<span class="post-item-author"><i class="fa fa-mortar-board"></i><?php the_author(); ?></span>
  									<?php
  										$category = get_the_category();
  										if( $category[0] ){
  											echo '<span class="post-label"><a href="'.get_category_link($category[0]->term_id ).'" title="'.$category[0]->cat_name.'"><i class="fa fa-list-ul"></i>'.$category[0]->cat_name.'</a></span>';
  										};
  									?>
  									<span class="tm"><i class="fa fa-clock-o"></i><?php the_time('Y-m-d'); ?></span>
  									<span class="count"><i class="fa fa-eye"></i><?php if(function_exists('the_views')) { echo the_views(); } ?></span>
  								</div>
  							</div>
  						</div>
  					<?php endwhile; ?>
  				</section>
  				<ul class="pagination">
  				  <?php par_pagenavi(5); ?>
  				</ul>
  				<!-- //Blog-Box -->
      </div>

        <div class="col-md-3 widgets">
          <div class="side-menu">
            <?php wp_nav_menu( array( 'theme_location' => 'side','menu_id' => '','container' => '','menu_class'=> '', 'walker'=> new wp_bootstrap_navwalker())); ?>
          </div>
          <div class="side-box red-bg">
              <a href="/contact"><i class="fa fa-phone-square fa-lg"></i>联系我们</a>
          </div>
          <div class="side-box blue-bg">
              <a href="/download"><i class="fa fa-cloud-download fa-lg"></i>下载应用</a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- END CAT-MAIN -->

<?php get_footer(); ?>
