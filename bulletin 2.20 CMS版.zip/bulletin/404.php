<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>404网页找不到了 - <?php bloginfo('name'); ?></title>
	<style>
	html,body
	{
		width:100%;
		height:100%;
		margin:0;
		padding:0;
	}
	.text
	{
		line-height:28px;
		font-family: microsoft yahei,microsoft jhenghei,verdana,tahoma;
		font-size:14px;
		color:#ff746e;
		float:right;
		padding-top:10px;
		margin-right:150px;
	}
	.text a,.text a:link
	{
		color:#ff746e;
		text-decoration:underline;
		font-weight:bold;
	}
	.text a:hover
	{
		text-decoration:none;
	}
	img {
		border: none;
		margin: 0;
		padding:0;
		display: block;
	}
	</style>

	</head>
	<body>
		<div style="width:100%; height:100%;">
			<div style="width:560px; height:240px; padding-top:180px; line-height:240px;  margin:0 auto;">
				<img src="<?php echo get_template_directory_uri();?>/img/nu.gif" style="display:block; float:left; margin:20px 0px; 10px 50px">
				<div style="padding-top:20px;">
					<img src="<?php echo get_template_directory_uri();?>/img/err_404.gif">
					<div class="text">莫有办法，找不到这个页面<br>回到 <a href="<?php bloginfo("home"); ?>">律动星光</a>首页</div>
				</div>
			</div>
		</div>
	</body>
</html>