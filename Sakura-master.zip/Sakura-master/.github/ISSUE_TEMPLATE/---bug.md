---
name: 报告 bug
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

<!-- 
如果这是您第一次在GitHub上发 issue，请阅读【提问的智慧】：https://github.com/ryanhanwu/How-To-Ask-Questions-The-Smart-Way/blob/master/README-zh_CN.md 
-->

**描述问题**

**bug 重现步骤**

**截图（如有）**

**系统信息**
 - （前端）操作系统: [e.g. Windows 10, Android 9.0]
 - 浏览器: [e.g. chrome, safari]
 - PHP 版本
 - WordPress 版本
 - Sakura 主题版本

**补充信息**
