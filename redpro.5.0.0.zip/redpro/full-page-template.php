<?php 
/*
 * Template Name: Full Page
*/
get_header(); ?>
<div class="page-title">
  <div class="container">
    <div class="row">
      <div class="col-md-6  col-sm-6 ">
       <p class="redpro-post-title"><?php esc_html_e('Blog ','redpro'); echo " : "; ?>
          <span class="redpro-post-subtitle">
          <?php redpro_title(); ?>
          </span></p>
      </div>
      <div class="col-md-6  col-sm-6 ">
        <ol class="breadcrumb  pull-right">
          <?php redpro_breadcrumbs(); ?>
        </ol>
      </div>
    </div>
  </div>
</div>
<!--end / page-title-->
<div class="main-container">
  <div class="container"> 
    <!-- Example row of columns -->
    <div class="row">
      <div class="col-md-12 main full-page">
        <?php while ( have_posts() ) : the_post(); ?>
        <article class="post">          
          <figure class="feature-thumbnail-large">
           <?php if(has_post_thumbnail()) { ?>
            <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('large');?></a>
            <?php } ?> </figure>          
          <div class="post-content">
            <?php the_content(); ?>
          </div>
          <!--end / post-content--> 
        </article>
        <?php endwhile; ?>
        <!--end / article-->
        <?php comments_template( '', true ); ?>
      </div>
      <!--end / main-->
    </div>
  </div>
  <!-- /container --> 
</div>
<?php get_footer(); ?>