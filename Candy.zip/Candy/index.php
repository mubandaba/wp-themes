<?php get_header(); ?>
	<div class="container">
		<div class="row">
			<div class="col-md-9">
				<div id="carousel-example-generic" class="carousel slide hidden-xs">
					<!-- Indicators -->
					<ol class="carousel-indicators">
						<li data-target="#carousel-example-generic" data-slide-to="0" class="active">
						</li>
						<li data-target="#carousel-example-generic" data-slide-to="1">
						</li>
						<li data-target="#carousel-example-generic" data-slide-to="2">
						</li>
					</ol>
					<!-- Wrapper for slides -->
					<div class="carousel-inner">
					<?php if(get_option('mao10_gg4')) { ?>
						<div class="item active">
								<a href="<?php echo get_option('mao10_gg5'); ?>"><img id="syhdkd" src="<?php echo get_option('mao10_gg4'); ?>"/></a>
						</div>
						<?php } ?>
						<?php if(get_option('mao10_gg6')) { ?>
						<div class="item">
							<a href="<?php echo get_option('mao10_gg7'); ?>"><img id="syhdkd" src="<?php echo get_option('mao10_gg6'); ?>"/></a>
						</div>
						<?php } ?>
						<?php if(get_option('mao10_gg8')) { ?>
						<div class="item">
						<a href="<?php echo get_option('mao10_gg9'); ?>"><img id="syhdkd" src="<?php echo get_option('mao10_gg8'); ?>"/></a>
						</div>
						<?php } ?>
						<?php if(get_option('mao10_gg11')) { ?>
						<div class="item">
						<a href="<?php echo get_option('mao10_gg12'); ?>"><img id="syhdkd" src="<?php echo get_option('mao10_gg11'); ?>"/></a>
						</div>
						<?php } ?>
						<?php if(get_option('mao10_gg13')) { ?>
						<div class="item">
						<a href="<?php echo get_option('mao10_gg14'); ?>"><img id="syhdkd" src="<?php echo get_option('mao10_gg13'); ?>"/></a>
						</div>
						<?php } ?>
					</div>
					<!-- Controls -->
					<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
						<span class="icon-prev">
						</span>
					</a>
					<a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
						<span class="icon-next">
						</span>
					</a>
				</div>
				<div class="panel panel-default" style="margin-top: 20px;">
					<div class="panel-heading" id="headbjs">
					<i class="glyphicon glyphicon-tag"></i>
					<span style="color:#fff; margin-left:10px;">
					<a href="<?php echo get_category_link(''. get_option('mao10_gg1') .'') ?>"><?php echo get_cat_name(''. get_option('mao10_gg1') .'') ?></a>
					</span>
					<a class="pull-right" href="<?php echo get_category_link(''.get_option('mao10_gg1').''); ?>"> 更多
					</a>
					</div>
					<div class="panel-body">
						<div class="row">
						
						<?php query_posts('cat='.get_option('mao10_gg1').'&showposts=2'); ?>
						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
							<div class="col-md-6 cpxj1">
									<div class="xstc" style="display:none;">
									<div class="zitifff">
									 	<?php the_excerpt(); ?>
									 </div>
									</div>
								<a class="img-div" style="display:block; overflow:hidden;" href="<?php the_permalink(); ?>"> <img src="<?php echo mmimg(); ?>"/></a>
								<a style="color:#999; height:45px; overflow:hidden; display:block; margin: 10px 0px;" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
								<p>评论: <span class="juhuangse"><?php comments_number('0', '1', '%' );?></span>
								 <span class="pull-right"><span class="juhuangse"><?php the_time('Y.m.d'); ?></span></span>
								</p>
							</div>
						<?php endwhile; endif; ?>
						</div>
					</div>
				</div>
				<div class="panel panel-default" style="margin-top: 20px;">
					<div class="panel-heading" id="headbjs">
					<i class="glyphicon glyphicon-tag"></i>
					<span style="color:#fff; margin-left:10px;">
					<a href="<?php echo get_category_link(''. get_option('mao10_gg2') .'') ?>"><?php echo get_cat_name(''. get_option('mao10_gg2') .'') ?></a>
					
					</span>
					<a class="pull-right" href="<?php echo get_category_link(''.get_option('mao10_gg2').''); ?>"> 更多
					</a>
					</div>
					<div class="panel-body">
						<div class="row">
						<?php query_posts('cat='.get_option('mao10_gg2').'&showposts=3'); ?>
						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
							<div class="col-md-4 cpxj1">
									<div class="xstc" style="display:none;">
									<div class="zitifff">
									 	<?php the_excerpt(); ?>
									 </div>
									</div>
								<a class="img-div" style="display:block; overflow:hidden;" href="<?php the_permalink(); ?>"> <img src="<?php echo mmimg(); ?>"/></a>
								<a style="color:#999; height:40px; overflow:hidden; display:block; margin: 8px 0px;" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
								<p>评论: <span class="juhuangse"><?php comments_number('0', '1', '%' );?></span>
								 <span class="pull-right"><span class="juhuangse"><?php the_time('Y.m.d'); ?></span></span>
								</p>
							</div>
						<?php endwhile; endif; ?>
						</div>
					</div>
				</div>
				<div class="panel panel-default" style="margin-top: 20px;">
					<div class="panel-heading" id="headbjs">
					<i class="glyphicon glyphicon-tag"></i><span style="color:#fff; margin-left:10px;">
					<a href="<?php echo get_category_link(''. get_option('mao10_gg3') .'') ?>"><?php echo get_cat_name(''. get_option('mao10_gg3') .'') ?></a>
					</span>
					<a class="pull-right" href="<?php echo get_category_link(''.get_option('mao10_gg3').''); ?>"> 更多
					</a>
					</div>
					<div class="panel-body">
						<div class="row">
						<?php query_posts('cat='.get_option('mao10_gg3').'&showposts=4'); ?>
						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
							<div class="col-md-3 cpxj1">
									<div class="xstc" style="display:none;">
									<div class="zitifff">
									 	<?php the_excerpt(); ?>
									 </div>
									</div>
								<a class="img-div" style="display:block; overflow:hidden;" href="<?php the_permalink(); ?>"> <img src="<?php echo mmimg(); ?>"/></a>
								<a style="color:#999; height:25px; overflow:hidden; display:block; margin: 7px 0px;" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
								<p>评论: <span class="juhuangse"><?php comments_number('0', '1', '%' );?></span>
								 <span class="pull-right"><span class="juhuangse"><?php the_time('Y.m.d'); ?></span></span>
								</p>
							</div>
						<?php endwhile; endif; ?>
						</div>
					</div>
				</div>
				
			</div>
			<div class="col-md-3">
				<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('side') ) : ?><?php endif; ?>
		</div>
	</div>
	</div>
	
	<?php get_footer(); ?>