<div class="foot hidden-xs" style="background:#999; margin-top:20px; padding: 30px 0px;">
		<div align="center">
		
       
     
       <div class="col-md-12" style="margin: 10px 0px;">
        
         <p></p>
            <p class="jiaobuyanse ziti12"> Copyright&nbsp;©&nbsp;2010-2013&nbsp;Maomao&nbsp;版权所有 </p>
         
         <p class="jiaobuyanse ziti12">© 2014 猫猫建站. Powered by WordPress.</p>
      </div>
   
			
		</div>
	</div>
</body>
<script src="<?php bloginfo('template_directory'); ?>/js/jquery.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/bootstrap.js"></script>
 
<?php wp_footer(); ?>

</html>