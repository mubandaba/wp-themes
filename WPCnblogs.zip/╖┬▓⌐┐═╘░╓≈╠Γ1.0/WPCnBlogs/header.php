<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head profile="http://gmpg.org/xfn/11">
	<?php include('includes/seo.php'); ?>
	<?php wp_head(); ?>
	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
	<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" />
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_url'); ?>" />
	<script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/jquery.min.js" ></script>
	<script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/custom.js" ></script>
	<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/comments-ajax.js"></script>
</head>

<body>
<div id="wrapper">
	<div id="hd_info">
		<div id="top-link">
			<script language="javascript">
				function AddFavorite(sURL,sTitle){
					try{
						window.external.addFavorite(sURL,sTitle)
					}catch(e){
							try{
								window.sidebar.addPanel(sTitle,sURL,"")
							}catch(e){
									alert("加入收藏失败，请使用Ctrl+D进行添加")
							}}}
				function SetHome(obj,vrl){
					try{
						obj.style.behavior='url(#default#homepage)';
						obj.setHomePage(vrl)
					}catch(e){
							if(window.netscape){
								try{
									netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect")
								}catch(e){
										alert("此操作被浏览器拒绝！\n请在浏览器地址栏输入“about:config”并回车\n然后将 [signed.applets.codebase_principal_support]的值设置为'true',双击即可。")
								}
							}
					}
				}
			</script>
			<a title="设为主页" style="behavior: url(#default#homepage);" onclick="SetHome(this,window.location);" href="#">设为首页</a> | 
			<a title="收藏本站" onclick="AddFavorite(window.location.href,document.title);" href="#">收藏本站</a> | 
			<a title="关于本站" target="_blank" href="/about/">关于本站</a>
		</div>
    </div>
    <div id="header">  
		<p class="h_r_3"></p><p class="h_r_2"></p><p class="h_r_1"></p>
		<div id="header_block">
			<div id="logo">
				<h1><a href="index.php" title="<?php bloginfo('name'); ?>">
				<img src="<?php bloginfo('template_directory'); ?>/images/logo.gif" alt="<?php bloginfo('description'); ?>"></a>
				</h1>
			</div> 
			<div class="clear"></div>
		</div> 
        <p class="h_r_1"></p><p class="h_r_2"></p><p class="h_r_3"></p>        
    </div><!-- #header -->

	<div id="nav_wrapper">
        <div id="nav_block">
			<ul>
				<li class="<?php if (((is_home()) && !(is_paged())) or (is_archive()) or (is_single()) or (is_paged()) or (is_search())) { ?>current_page_item<?php } else { ?><?php } ?>"><a href="<?php echo get_settings('home'); ?>">Home</a></li>
				<?php wp_list_pages('sort_column=menu_order&depth=1&title_li='); ?>
            </ul>
        </div>
        <div class="clear"></div>            
    </div><!-- #nav -->