</div><!-- #content -->

<div id="footer">
	Copyright <?php echo comicpress_copyright(); ?> <?php bloginfo('name'); ?>&nbsp;&nbsp;保留所有权利.
	</span>&nbsp;Theme by <a href="http://v7v3.com/" title="http://www.zxlive.net" target="_blank">飘无痕</a>&nbsp;&nbsp;
	Demon <a href="http://www.syet.net" title="http://www.syet.net" target="_blank">三叶草博客</a>&nbsp;&nbsp;
	基于 <a href="http://wordpress.org/" target="_blank">WordPress</a>技术创建&nbsp;&nbsp;	
	<?php if (get_option('swt_analytics')!="") {?>
		<?php echo stripslashes(get_option('swt_analytics')); ?>
	<?php }?>
</div>
<div class="clear"></div>

<?php wp_footer(); ?>

</body>
</html>