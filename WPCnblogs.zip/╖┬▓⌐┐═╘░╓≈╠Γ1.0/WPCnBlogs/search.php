<?php get_header(); ?>

<?php get_sidebar(); ?>
	
<div id="content">
	<div id="map">
		<div class="browse">现在位置＞ <a title="返回首页" href="<?php echo get_settings('Home'); ?>/">首页</a> ＞搜索结果</div>
		<div id="feed"><a href="<?php bloginfo('rss2_url'); ?>" title="RSS">RSS</a></div>
		<b class="lt"></b>
		<b class="rt"></b>
		<b class="lb"></b>
		<b class="rb"></b>
	</div>
	<div class="navigation"><?php pagination($query_string); ?></div>
    <div class="clear"></div>
 	<!-- end: navigation_t -->
 	<!-- archive_box -->
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	<div class="post_item">
		<div class="indexdate">
			<div class="postdate">
				<span class="postday"><?php the_time('d') ?></span>
				<span class="postyear"><?php the_time('m') ?>/<?php the_time('y') ?></span>
			</div>
			<div class="clear"></div>
		</div>
		<div class="post_item_body">
			<h3><a href="<?php the_permalink() ?>" class="titlelnk" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
			<p class="post_item_summary">
				<?php if (has_excerpt()){ the_excerpt() ;
					}else{
						echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 480,"...");
					}?>
			</p>
			<div class="post_item_foot">
				<span>发表于&nbsp;<?php echo date("Y-m-d H:i",get_the_time('U')); ?></span>
				<span class="category"><?php the_category(', ') ?></span>
				<span class="article_comment"><?php comments_popup_link('暂无评论', '评论(1)', '评论(%)'); ?></span>
				<?php if(function_exists('the_views')){ print ' <span class="article_view grayline">阅读(<span>';the_views(); print '</span>)</span>';   } ?>
			</div>
			<div class="clear"></div>
		</div>
	</div>
 	<!-- end: box_archive --> 
	<?php endwhile;  else: ?>
	<div class="entry_box">
		<h3 class="center">抱歉!无法搜索到与之相匹配的信息。</h3>
		<b class="lt"></b>
		<b class="rt"></b>
	</div>
	<div class="entry_box_b">
		<b class="lb"></b>
		<b class="rb"></b>
	</div>
	<?php endif; ?>
	<!-- end: archive_box --> 
 	<!-- navigation_b -->
    <div class="navigation_b"><?php pagination($query_string); ?></div>
 	<!-- end: navigation_b -->
	<div class="clear"></div>	


</div><!-- #content -->

<?php get_footer(); ?>