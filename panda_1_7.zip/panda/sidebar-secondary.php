<?php if ( !theme_dynamic_sidebar( 'secondary' ) ) : ?>
<?php $style = theme_get_option('theme_sidebars_style_secondary'); ?>



<?php endif; ?>