<?php
global $theme_options;

if (WP_VERSION < 3.0) {
	$theme_options = array (
		array(	
		'name'	=>	__('Footer', THEME_NS),
		'type'	=>	'heading'
		),
		array(	
		'id'	=>	'theme_footer_content',
		'name'	=>	__('Footer content', THEME_NS),
		'desc'	=>	sprintf(__('<strong>XHTML:</strong> You can use these tags: <code>%s</code>', THEME_NS), 'a, abbr, acronym, em, b, i, strike, strong, span') . '<br />'
	   			. sprintf(__('<strong>ShortTags:</strong><code>%s</code>', THEME_NS), '[year], [top], [rss], [login-link], [blog-title], [xhtml], [css]'),
		'type'	=>	'textarea'
		)
	);
	return;
}

$theme_menu_source_options = array(
	'Pages'	=>	__('Pages', THEME_NS),
	'Categories'	=>	__('Categories', THEME_NS)
);

$theme_sidebars_style_options = array(
	'block'	=>	__('Block style', THEME_NS),
	'post'	=>	__('Post style', THEME_NS),
	'simple'	=>	__('Simple text', THEME_NS)
);

global $theme_options;
$theme_options = array (
	array(	
	'name'	=>	__('头部', THEME_NS),
	'type'	=>	'heading'
	),
	array(	
	'id'	=>	'theme_header_show_headline',
	'name'	=>	__('显示标题', THEME_NS),
	'desc'	=>	__('Yes', THEME_NS),
	'type'	=>	'checkbox'
	),
	array(	
	'id'	=>	'theme_header_show_slogan',
	'name'	=>	__('显示次标题', THEME_NS),
	'desc'	=>	__('Yes', THEME_NS),
	'type'	=>	'checkbox'
	),
	array(	
	'name'	=>	__('导航菜单', THEME_NS),
	'type'	=>	'heading'
	),
	array(	
	'id'	=>	'theme_menu_showHome',
	'name'	=>	__('显示主页', THEME_NS),
	'desc'	=>	__('Yes', THEME_NS),
	'type'	=>	'checkbox'
	),
	array(	
	'id'	=>	'theme_menu_homeCaption',
	'name'	=>	__('首项标题', THEME_NS),
	'type'	=>	'text'
	),
	array(	
	'id'	=>	'theme_menu_highlight_active_categories',
	'name'	=>	__('突出活动分类', THEME_NS),
	'desc'	=>	__('Yes', THEME_NS),
	'type'	=>	'checkbox'
	),
	
	array(	
	'id'	=>	'theme_menu_trim_title',
	'name'	=>	__('修改长菜单项目', THEME_NS),
	'desc'	=>	__('Yes', THEME_NS),
	'type'	=>	'checkbox'
	),	
	array(	
	'id'	=>	'theme_menu_trim_len',
	'name'	=>	__('每个项目限制 [N] 个字符', THEME_NS),
	'desc'	=>	__('(characters).', THEME_NS),
	'type'	=>	'numeric'
	),
	
	array(	
	'id'	=>	'theme_submenu_trim_len',
	'name'	=>	__('每个子项限制 [N] 个字符', THEME_NS),
	'desc'	=>	__('(characters).', THEME_NS),
	'type'	=>	'numeric'
	),
	
	array(	
	'name'	=>	__('贴出', THEME_NS),
	'type'	=>	'heading'
	),

	array(	
	'id'	=>	'theme_home_top_posts_navigation',
	'name'	=>	__('在前面的文章页面的顶部显示导航链接', THEME_NS),
	'desc'	=>	__('Yes', THEME_NS),
	'type'	=>	'checkbox'
	),	

	array(	
	'id'	=>	'theme_top_posts_navigation',
	'name'	=>	__('在文章页面的顶部显示导航链接', THEME_NS),
	'desc'	=>	__('Yes', THEME_NS),
	'type'	=>	'checkbox'
	),

	array(	
	'id'	=>	'theme_bottom_posts_navigation',
	'name'	=>	__('在文章页面的底部显示导航链接', THEME_NS),
	'desc'	=>	__('Yes', THEME_NS),
	'type'	=>	'checkbox'
	),

	array(	
	'id'	=>	'theme_top_single_navigation',
	'name'	=>	__('在单篇文章视图显示顶部导航链接', THEME_NS),
	'desc'	=>	__('Yes', THEME_NS),
	'type'	=>	'checkbox'
	),
	array(	
	'id'	=>	'theme_bottom_single_navigation',
	'name'	=>	__('在单篇文章视图显示底部导航链接', THEME_NS),
	'desc'	=>	__('Yes', THEME_NS),
	'type'	=>	'checkbox'
	),
	array(	
	'id'	=>	'theme_single_navigation_trim_title',
	'name'	=>	__('修改长导航链接在单页面', THEME_NS),
	'desc'	=>	__('Yes', THEME_NS),
	'type'	=>	'checkbox'
	),	
	array(	
	'id'	=>	'theme_single_navigation_trim_len',
	'name'	=>	__('限制每一个链接[N]个字符', THEME_NS),
	'desc'	=>	__('(characters).', THEME_NS),
	'type'	=>	'numeric'
	),
	
	array(	
	'name'	=>	__('特色图片', THEME_NS),
	'type'	=>	'heading'
	),
	array(	
	'id'	=>	'theme_metadata_use_featured_image_as_thumbnail',
	'name'	=>	__('特色图片以缩略图', THEME_NS),
	'desc'	=>	__('Yes', THEME_NS),
	'type'	=>	'checkbox'
	),
	array(	
	'id'	=>	'theme_metadata_thumbnail_auto',
	'name'	=>	__('使用自动缩略图', THEME_NS),
	'desc'	=>	__('Generate post thumbnails automatically (use the first image from the post gallery)', THEME_NS),
	'type'	=>	'checkbox'
	),
	array(	
	'id'	=>	'theme_metadata_thumbnail_width',
	'name'	=>	__('缩略图长度', THEME_NS),
	'desc'	=>	__('(px)', THEME_NS),
	'type'	=>	'numeric'
	),
	array(	
	'id'	=>	'theme_metadata_thumbnail_height',
	'name'	=>	__('缩略图高度', THEME_NS),
	'desc'	=>	__('(px)', THEME_NS),
	'type'	=>	'numeric'
	),
	array(	
	'name'	=>	__('Excerpt', THEME_NS),
	'type'	=>	'heading'
	),
	array(	
	'id'	=>	'theme_metadata_excerpt_auto',
	'name'	=>	__('使用自动摘录', THEME_NS),
	'desc'	=>	__('Generate post excerpts automatically (When neither more-tag nor post excerpt is used)', THEME_NS),
	'type'	=>	'checkbox'
	),
	array(	
	'id'	=>	'theme_metadata_excerpt_words',
	'name'	=>	__('摘自长度', THEME_NS),
	'desc'	=>	__('(words)', THEME_NS),
	'type'	=>	'numeric'
	),
	array(	
	'id'	=>	'theme_metadata_excerpt_min_remainder',
	'name'	=>	__('摘自平衡', THEME_NS),
	'desc'	=>	__('(words)', THEME_NS),
	'type'	=>	'numeric'
	),
	array(	
	'id'	=>	'theme_metadata_excerpt_use_tag_filter',
	'name'	=>	__('应用摘录标签过滤器', THEME_NS),
	'desc'	=>	__('Yes', THEME_NS),
	'type'	=>	'checkbox'
	),
	array(	
	'id'	=>	'theme_metadata_excerpt_allowed_tags',
	'name'	=>	__('允许摘录标签', THEME_NS),
	'desc'	=>	__('Used when "Apply excerpt tag filter" is enabled', THEME_NS),
	'type'	=>	'widetext'
	),
	array(	
	'name'	=>	__('页面', THEME_NS),
	'type'	=>	'heading'
	),
	array(	
	'id'	=>	'theme_show_random_posts_on_404_page',
	'name'	=>	__('显示404页面', THEME_NS),
	'desc'	=>	__('Yes', THEME_NS),
	'type'	=>	'checkbox'
	),
	array(	
	'id'	=>	'theme_show_random_posts_title_on_404_page',
	'name'	=>	__('随机文章标题', THEME_NS),
	'type'	=>	'text',
	'desc'	=>	__('Used when "Show random posts on 404 page" is enabled', THEME_NS)
	),
	array(	
	'id'	=>	'theme_show_tags_on_404_page',
	'name'	=>	__('404页面的显示卷标', THEME_NS),
	'desc'	=>	__('Yes', THEME_NS),
	'type'	=>	'checkbox'
	),
	array(	
	'id'	=>	'theme_show_tags_title_on_404_page',
	'name'	=>	__('标签标题', THEME_NS),
	'type'	=>	'text',
	'desc'	=>	__('Used when "Show tags on 404 page" is enabled', THEME_NS)
	),
	array(	
	'name'	=>	__('评论', THEME_NS),
	'type'	=>	'heading',
	),
	array(	
	'id'	=>	'theme_comment_use_smilies',
	'name'	=>	__('在评论中使用图释', THEME_NS),
	'desc'	=>	__('Yes', THEME_NS),
	'type'	=>	'checkbox'
	),
	array(	
	'name'	=>	__('侧边栏', THEME_NS),
	'type'	=>	'heading',
	'desc' => __('Default widgets style', THEME_NS)
	),
	array(	
	'id'	=>	'theme_sidebars_style_default',
	'name'	=>	__('初级侧边栏', THEME_NS),
	'type'	=>	'select',
	'options'	=>	$theme_sidebars_style_options
	),
	array(	
	'id'	=>	'theme_sidebars_style_secondary',
	'name'	=>	__('第二侧边栏', THEME_NS),
	'type'	=>	'select',
	'options'	=>	$theme_sidebars_style_options
	),
	array(	
	'id'	=>	'theme_sidebars_style_top',
	'name'	=>	__('顶部侧边栏', THEME_NS),
	'type'	=>	'select',
	'options'	=>	$theme_sidebars_style_options
	),
	array(	
	'id'	=>	'theme_sidebars_style_bottom',
	'name'	=>	__('底部侧边栏', THEME_NS),
	'type'	=>	'select',
	'options'	=>	$theme_sidebars_style_options
	),
	array(	
	'id'	=>	'theme_sidebars_style_footer',
	'name'	=>	__('页脚侧边栏', THEME_NS),
	'type'	=>	'select',
	'options'	=>	$theme_sidebars_style_options
	),
	array(	
	'name'	=>	__('底部', THEME_NS),
	'type'	=>	'heading'
	),
	array(	
	'id'	=>	'theme_footer_content',
	'name'	=>	__('页脚内容', THEME_NS),
	'desc'	=>	sprintf(__('<strong>XHTML:</strong> You can use these tags: <code>%s</code>', THEME_NS), 'a, abbr, acronym, em, b, i, strike, strong, span') . '<br />'
	   		. sprintf(__('<strong>ShortTags:</strong><code>%s</code>', THEME_NS), '[year], [top], [rss], [login-link], [blog-title], [xhtml], [css]'),
	'type'	=>	'textarea'
	),
	array(	
	'name'	=>	__('广告', THEME_NS),
	'type'	=>	'heading',
	'desc' => sprintf(__('Use the %s short code to insert these ads into posts, text widgets or footer', THEME_NS),'<code>[ad]</code>') . '<br/>'
		. '<span>' . __('Example:', THEME_NS) .'</span><code>[ad code=4 align=center]</code>'
	),
	array(	
	'id'	=>	'theme_ad_code_1',
	'name'	=>	sprintf(__('Ad code #%s:', THEME_NS),1),
	'type'	=>	'textarea'
	),
	array(	
	'id'	=>	'theme_ad_code_2',
	'name'	=>	sprintf(__('Ad code #%s:', THEME_NS),2),
	'type'	=>	'textarea'
	),
	array(	
	'id'	=>	'theme_ad_code_3',
	'name'	=>	sprintf(__('Ad code #%s:', THEME_NS),3),
	'type'	=>	'textarea'
	),
	array(	
	'id'	=>	'theme_ad_code_4',
	'name'	=>	sprintf(__('Ad code #%s:', THEME_NS),4),
	'type'	=>	'textarea'
	),
	array(	
	'id'	=>	'theme_ad_code_5',
	'name'	=>	sprintf(__('Ad code #%s:', THEME_NS),5),
	'type'	=>	'textarea'
	)
);

global $theme_page_meta_options;
$theme_page_meta_options = array (
	array(	
	'id'	=>	'theme_show_in_menu',
	'name'	=>	__('在菜单中显示', THEME_NS),
	'desc'	=>	__('Yes', THEME_NS),
	'type'	=>	'checkbox'
	),
	array(	
	'id'	=>	'theme_show_as_separator',
	'name'	=>	__('作为分隔符在菜单中显示', THEME_NS),
	'desc'	=>	__('Yes', THEME_NS),
	'type'	=>	'checkbox'
	),
	array(	
	'id'	=>	'theme_title_in_menu',
	'name'	=>	__('菜单标题', THEME_NS),
	'type'	=>	'text'
	),
	array(	
	'id'	=>	'theme_show_page_title',
	'name'	=>	__('显示页面上的标题', THEME_NS),
	'desc'	=>	__('Yes', THEME_NS),
	'type'	=>	'checkbox'
	)
);

global $theme_post_meta_options;
$theme_post_meta_options = array(
	array(	
	'id'	=>	'theme_show_post_title',
	'name'	=>	__('显示标题在单页上', THEME_NS),
	'desc'	=>	__('Yes', THEME_NS),
	'type'	=>	'checkbox'
	)
);
