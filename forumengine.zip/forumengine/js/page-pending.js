(function($){

	$(document).ready(function(){
		//new ForumEngine.Views.PostPendingControl();
		new ForumEngine.Views.ListThread({el : '#main_list_post'});
	});

})(jQuery);