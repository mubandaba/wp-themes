/*-----------------------------------------------------------------------------------*/
/* Fashionbuzz WordPress Theme */
/*-----------------------------------------------------------------------------------*/

Theme Name      :   Fashionbuzz
Theme URI       :    https://www.flythemes.net/wordpress-themes/fashionbuzz-wordpress-theme/
Version         :   1.2.4
Tested up to    :   WP 4.7.2
Author          :   Flythemes
Author URI      :   https://www.flythemes.net/

license         :   GNU General Public License v3.0
License URI     :   http://www.gnu.org/licenses/gpl.html

/*-----------------------------------------------------------------------------------*/
/* About Author - Contact Details */
/*-----------------------------------------------------------------------------------*/

email       :   support@flythemes.net

/*-----------------------------------------------------------------------------------*/
/* Theme Resources */
/*-----------------------------------------------------------------------------------*/

Theme is Built using the following resource bundles.

1 - All js that have been used are within folder /js of theme.
- jquery.nivo.slider.js is licensed under MIT.
- html5.js is dual licensed under MIT and GPL2

2 - Open Sans font - https://www.google.com/fonts/specimen/Open+Sans
	License: Distributed under the terms of the Apache License, version 2.0 http://www.apache.org/licenses/LICENSE-2.0.html

3 - Images used from Pixabay. License: Distributed under the terms of the GPLv2 Image urls : used within the themes. 
		https://pixabay.com/en/girl-camera-old-retro-holds-549154/

Fashionbuzz Pro version
==========================================================
Fashionbuzz pro version is compatible with GPL licensed.


For any help you can mail us at support[at]flythemes.net