<?php get_header(); ?>
		<!-- main start -->
		<div class="main">
			<div class="banner box">
			</div>
			<!--幻灯片-->
			<div class="focus box">
				<div class="col">
					<a href="<?php echo get_option('mao10_indexlink1'); ?>" target="_blank">
						<img height="330" src="<?php echo get_option('mao10_indexflash1'); ?>" style="opacity: 1;" width="600" />
						<span>
							<img height="336" src="<?php echo get_option('mao10_indexflash1'); ?>" width="611" />
						</span>
					</a>
				</div>
				<div class="col">
					<a href="<?php echo get_option('mao10_indexlink2'); ?>"	target="_blank">
						<img height="200" src="<?php echo get_option('mao10_indexflash2'); ?>" style="opacity: 1;" width="160" />
						<span>
							<img height="206" src="<?php echo get_option('mao10_indexflash2'); ?>" width="166" />
						</span>
					</a>
					<a href="<?php echo get_option('mao10_indexlink3'); ?>" target="_blank">
						<img height="120" src="<?php echo get_option('mao10_indexflash3'); ?>" style="opacity: 1;" width="160" />
						<span>
							<img height="126" src="<?php echo get_option('mao10_indexflash3'); ?>" width="166" />
						</span>
					</a>
				</div>
				<div class="col">
					<a href="<?php echo get_option('mao10_indexlink4'); ?>" target="_blank">
						<img height="120" src="<?php echo get_option('mao10_indexflash4'); ?>" style="opacity: 1;" width="160" />
						<span>
							<img height="126" src="<?php echo get_option('mao10_indexflash4'); ?>" width="166" />
						</span>
					</a>
					<a href="<?php echo get_option('mao10_indexlink5'); ?>" target="_blank">
						<img height="200" src="<?php echo get_option('mao10_indexflash5'); ?>" style="opacity: 1;" width="160" />
						<span>
							<img height="206" src="<?php echo get_option('mao10_indexflash5'); ?>" width="166" />
						</span>
					</a>
				</div>
			</div>
			<div class="content">
				<!--左侧新闻-->
				<div class="left box">
					<?php query_posts('meta_key=tuijian_value&showposts=1');  ?>
					<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
					<?php $fmimg = get_post_meta($post->ID, "tuijian_value", true); ?>
					<dl class="topLine">
						<dt>
							<h2>
								<a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a>
							</h2>
							<a href="<?php the_permalink(); ?>" target="_blank">
								<img src="<?php echo $fmimg; ?>" alt="<?php the_title(); ?>" title="<?php the_title(); ?>" width="296" height="175" />
							</a>
						</dt>
						<dd>
							<span>
								<em class="view">
									<?php echo getPostViews(get_the_ID());?>
								</em>
								<script type="text/javascript">
									document.write('<a href="http://v.t.sina.com.cn/share/share.php?url=' + encodeURIComponent('<?php the_permalink(); ?>') + '&appkey=1874498659&title=' + encodeURIComponent('<?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 100, "…"); ?> ——来自@<?php bloginfo('name'); ?>') + '" title="分享到新浪微博" target="_blank">分享</a>');
								</script>
							</span>
							<?php the_category(', '); ?>
							| <?php the_time('Y年m月d日'); ?>
							<?php the_excerpt(); ?>
						</dd>
					</dl>
					<?php endwhile; endif; wp_reset_query(); ?>
					<ul class="subTopLine">
						<?php query_posts('meta_key=tuijian_value&showposts=4&offset=1');  ?>
						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						<?php $fmimg = get_post_meta($post->ID, "tuijian_value", true); ?>
						<li>
							<a href="http://bbs.xiaomi.cn/thread-7702997-1-1.html" target="_blank">
								<img src="<?php echo $fmimg; ?>" width="142" height="83" alt="<?php the_title(); ?>" title="<?php the_title(); ?>" />
							</a>
							<h3>
								<a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a>
							</h3>
							<span>
								<?php the_category(', '); ?>
								<?php the_time('Y-m-d'); ?>
							</span>
						</li>
						<?php endwhile; endif; wp_reset_query(); ?>
					</ul>
					<ul class="news">
						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						<?php 
							$fmimg = get_post_meta($post->ID, "fmimg_value", true);
							$cti = catch_that_image();
							if($fmimg) {
								$showimg = $fmimg;
							} else {
								$showimg = $cti;
							};
						?>
						<li>
							<h2>
								<a href="<?php the_permalink(); ?>" target="_blank">
									<?php the_title(); ?>
								</a>
							</h2>
							<span>
								<em class="view">
									<?php echo getPostViews(get_the_ID());?>
								</em>
								<a href="<?php the_permalink(); ?>#comment" class="comment" target="_blank">
									<?php comments_number('0', '1', '%' );?>
								</a>
								<script type="text/javascript">
									document.write('<a href="http://v.t.sina.com.cn/share/share.php?url=' + encodeURIComponent('<?php the_permalink(); ?>') + '&appkey=1874498659&title=' + encodeURIComponent('<?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 100, "…"); ?> ——来自@<?php bloginfo('name'); ?>') + '" title="分享到新浪微博" target="_blank">分享</a>');
								</script>
							</span>
							<?php the_category(', '); ?>
							| <?php the_time('Y年m月d日'); ?> |
							<?php the_tags('<div class="tag">','','</div>'); ?>
							<a href="<?php the_permalink(); ?>" target="_blank">
								<img src="<?php echo $showimg; ?>" width="605" height="220" alt="<?php the_title(); ?>" title="<?php the_title(); ?>" />
							</a>
							<?php the_excerpt(); ?>
						</li>
						<?php endwhile; endif; ?>
					</ul>
					<div id="pager"><?php par_pagenavi(9); ?></div>
				</div>
				<div class="right">
					<?php get_search_form(); ?>
					<?php get_sidebar(); ?>
				</div>
				<!--[if lte IE 7]>
					<div style="clear: both">
					</div>
				<![endif]-->
			</div>
			<!--热门地区-->
			<div class="location box">
				<h4>
					<strong>
						热门同城会
					</strong>
				</h4>
				<div>
					<a href="#" target="_blank">西安</a>
					<a href="#" target="_blank">西安</a>
					<a href="#" target="_blank">西安</a>
					<a href="#" target="_blank">西安</a>
					<a href="#" target="_blank">西安</a>
					<a href="#" target="_blank">西安</a>
					<a href="#" target="_blank">西安</a>
					<a href="#" target="_blank">西安</a>
					<a href="#" target="_blank">西安</a>
					<a href="#" target="_blank">西安</a>
					<a href="#" target="_blank">西安</a>
					<a href="#" target="_blank">西安</a>
					<a href="#" target="_blank">西安</a>
					<a href="#" target="_blank">西安</a>
					<a href="#" target="_blank">西安</a>
					<a href="#" target="_blank">西安</a>
					<a href="#" target="_blank">西安</a>
					<a href="#" target="_blank">西安</a>
					<a href="#" target="_blank">西安</a>
					<a href="#" target="_blank">西安</a>
					<a href="#" target="_blank">西安</a>
					<a href="#" target="_blank">西安</a>
					<a href="#" target="_blank">西安</a>
					<a href="#" target="_blank">西安</a>
					<a href="#" target="_blank">西安</a>
					<a href="#" target="_blank">西安</a>
					<a href="#" target="_blank">西安</a>
				</div>
			</div>
			<!--友情链接-->
			<div class="links box">
				<h4>
					<strong>
						友情链接
					</strong>
				</h4>
				<div class="topLink">
					<a href="#" title="小米网" target="_blank">
						<img src="http://static.xiaomi.cn/xiaomicms/uploadfile/2012/0809/20120809020546414.png"
						/>
					</a>
					<a href="#" title="小米社区" target="_blank">
						<img src="http://static.xiaomi.cn/xiaomicms/uploadfile/2012/0808/20120808121132470.png"
						/>
					</a>
					<a href="#" title="MIUI" target="_blank">
						<img src="http://static.xiaomi.cn/xiaomicms/uploadfile/2012/0809/20120809020758246.png"
						/>
					</a>
					<a href="#" title="米聊" target="_blank">
						<img src="http://static.xiaomi.cn/xiaomicms/uploadfile/2012/0809/20120809020822196.png"
						/>
					</a>
					<a href="#" title="多看精品书城" target="_blank">
						<img src="http://static.xiaomi.cn/xiaomicms/uploadfile/2013/0604/20130604050619988.jpg"
						/>
					</a>
				</div>
				<div class="link">
					<a href="#" title="人民网通信频道" target="_blank">
						人民网通信频道
					</a>
					<a href="#" title="中关村手机" target="_blank">
						中关村手机
					</a>
					<a href="#" title="人民网通信频道" target="_blank">
						人民网通信频道
					</a>
					<a href="#" title="中关村手机" target="_blank">
						中关村手机
					</a>
					<a href="#" title="人民网通信频道" target="_blank">
						人民网通信频道
					</a>
					<a href="#" title="中关村手机" target="_blank">
						中关村手机
					</a>
					<a href="#" title="人民网通信频道" target="_blank">
						人民网通信频道
					</a>
					<a href="#" title="中关村手机" target="_blank">
						中关村手机
					</a>
					<a href="#" title="人民网通信频道" target="_blank">
						人民网通信频道
					</a>
					<a href="#" title="中关村手机" target="_blank">
						中关村手机
					</a>
					<a href="#" title="人民网通信频道" target="_blank">
						人民网通信频道
					</a>
					<a href="#" title="中关村手机" target="_blank">
						中关村手机
					</a>
					<a href="#" title="人民网通信频道" target="_blank">
						人民网通信频道
					</a>
					<a href="#" title="中关村手机" target="_blank">
						中关村手机
					</a>
				</div>
			</div>
		</div>
		<!-- main end -->
		<?php get_footer(); ?>