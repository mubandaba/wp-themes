<?php get_header(); ?>
		<!-- main start -->
		<div class="main">
			<div class="content">
				<!--左侧新闻-->
				<div class="left box">
					<ul class="news">
						<li style="background:none">
							<h2 style="color:#333">
								错误404
							</h2>
							<p>这里是火星，请迅速返回地球！</p>
						</li>
					</ul>
				</div>
				<div class="right">
					<?php get_search_form(); ?>
					<?php get_sidebar(); ?>
				</div>
				<!--[if lte IE 7]>
					<div style="clear: both">
					</div>
				<![endif]-->
			</div>
		</div>
		<!-- main end -->
		<?php get_footer(); ?>