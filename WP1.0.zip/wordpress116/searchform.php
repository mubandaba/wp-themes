<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
	<div class="box search" id="indexSearch">
		<input id="searchinput" type="text" name="s" id="indexTxtSearch" value="" />
		<input type="submit" id="searchbtn" value="" />
	</div>
</form>
