<?php get_header(); ?>
		<!-- main start -->
		<div class="main">
			<div class="content">
				<!--左侧新闻-->
				<div class="left box">
					<ul class="news">
						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						<?php setPostViews(get_the_ID()); ?>
						<?php 
							$fmimg = get_post_meta($post->ID, "fmimg_value", true);
							$cti = catch_that_image();
							if($fmimg) {
								$showimg = $fmimg;
							} else {
								$showimg = $cti;
							};
						?>
						<li style="background:none">
							<h2 style="color:#333">
								<?php the_title(); ?>
							</h2>
							<span>
								<em class="view">
									<?php echo getPostViews(get_the_ID());?>
								</em>
								<a href="<?php the_permalink(); ?>#comment" class="comment" target="_blank">
									<?php comments_number('0', '1', '%' );?>
								</a>
								<script type="text/javascript">
									document.write('<a href="http://v.t.sina.com.cn/share/share.php?url=' + encodeURIComponent('<?php the_permalink(); ?>') + '&appkey=1874498659&title=' + encodeURIComponent('<?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 100, "…"); ?> ——来自@<?php bloginfo('name'); ?>') + '" title="分享到新浪微博" target="_blank">分享</a>');
								</script>
							</span>
							<?php the_category(', '); ?>
							| <?php the_time('Y年m月d日'); ?> |
							<?php the_tags('<div class="tag">','','</div>'); ?>
							<?php the_content(); ?>
						</li>
						<?php endwhile; endif; ?>
					</ul>
					<div id="comment">
						<?php comments_template(); ?>
					</div>
				</div>
				<div class="right">
					<?php get_search_form(); ?>
					<?php get_sidebar(); ?>
				</div>
				<!--[if lte IE 7]>
					<div style="clear: both">
					</div>
				<![endif]-->
			</div>
		</div>
		<!-- main end -->
		<?php get_footer(); ?>