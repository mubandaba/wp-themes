		<div class="footer">
			<div class="footerInner">
				<a class="logo" href="<?php bloginfo('url'); ?>">
					<em>
						小米社区
					</em>
				</a>
				<a href="#" target="_blank">
					关于小米
				</a>
				<a href="#" target="_blank">
					小米招聘
				</a>
				<a href="#" target="_blank">
					联系我们
				</a>
				<span>
					旗下网站：
				</span>
				<a class="link link_xiaomi" href="#" target="_blank">
					小米网
				</a>
				<a class="link link_miui" href="#" target="_blank">
					MIUI
				</a>
				<a class="link link_miliao" href="#" target="_blank">
					米聊
				</a>
			</div>
		</div>
	</body>
	<?php wp_footer(); ?>
</html>

