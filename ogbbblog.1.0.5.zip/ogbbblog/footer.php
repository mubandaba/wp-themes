				
			</div>
			<?php get_sidebar(); ?>
		</div>
		<div id="footer">
			<div id="cizgi"></div>
		
		</div>
	</div>
	<?php wp_footer(); ?>
</body>
</html>