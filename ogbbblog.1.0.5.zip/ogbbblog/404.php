
<?php get_header(); ?>
				<?php esc_html_e('Oops! That page can&rsquo;t be found.', 'ogbbblog' ); ?>
<?php get_footer(); ?>