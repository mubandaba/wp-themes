=== Ogbb Blog ===
Contributors: Osman �AKIRSOY
Tags: two-columns, right-sidebar, custom-background, custom-menu, custom-logo, blog
Requires at least: 4.7.5
Tested up to: 4.7.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==
Bu tema sade ve g�steri�ten uzak olarak tasarlanm��t�r. Sizde sade bir blog temas� istiyorsan�z bu tema tam size g�re olabilir.

== Copyright ==
* Google Fonts, http://google.com/fonts, Copyright 2010, Google, open source licenses, see: https://developers.google.com/fonts/faq#Any_Page_OK.
* Image used in screenshot.png: licensed under Creative Commons Zero(http://creativecommons.org/publicdomain/zero/1.0/)

== Versiyon 1.0.5 ==
* Css ve Html alan�nda g�rsel geli�tirmeler yap�ld�.
* Screenshot (Ekran G�r�nt�s�) yenilendi.

== Resources ==
WordPress Theme, Copyright 2017 Osman �AKIRSOY
is distributed under the terms of the GNU GPL