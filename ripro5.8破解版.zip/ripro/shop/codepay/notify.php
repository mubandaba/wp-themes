<?php
//码支付
header('Content-type:text/html; Charset=utf-8');
date_default_timezone_set('Asia/Shanghai');
ob_start();
require_once dirname(__FILE__) . "../../../../../../wp-load.php";
ob_end_clean();

// 获取后台支付配置
$codepayConfig = _cao('codepay');//这是通信密钥
$mzf_appid  = $codepayConfig['mzf_appid']; //appid
$mzf_secret = $codepayConfig['mzf_secret']; //secret


ksort($_POST); //排序post参数
reset($_POST); //内部指针指向数组中的第一个元素
$sign = '';//初始化
foreach ($_POST AS $key => $val) { //遍历POST参数
    if ($val == '' || $key == 'sign') continue; //跳过这些不签名
    if ($sign) $sign .= '&'; //第一个字符串签名不加& 其他加&连接起来参数
    $sign .= "$key=$val"; //拼接为url参数形式
}
if (!$_POST['pay_no'] || md5($sign . $mzf_secret) != $_POST['sign']) { //不合法的数据
    exit('fail');  //返回失败 继续补单
} else { //合法数据 
    //商户本地订单号
    $out_trade_no = $_POST['pay_id'];
    //交易号
    $trade_no = $_POST['pay_no'];
    //发送支付成功回调用
    $ShopOrder = new ShopOrder();
    $order     = $ShopOrder->get($out_trade_no);
    // 是否有效订单 && 订单类型为充值
    if ($order && $order->order_type == 'charge') {
    	// 实例化用户信息
        $CaoUser = new CaoUser($order->user_id);
        // 计算充值数量
        $charge_rate  = (int) _cao('site_change_rate'); //充值比例
        $old_money    = $CaoUser->get_balance(); //用户原来余额
        $charge_money = sprintf('%0.2f', $order->order_price * $charge_rate); // 实际充值数量
        //更新用户余额信息
        if ($CaoUser->update_balance($charge_money)) {
            // 写入记录
            $Caolog    = new Caolog();
            $new_money = $old_money + $charge_money; //充值后金额
            $note      = '支付宝-在线充值 [￥' . $order->order_price . '] +' . $charge_money;
            $Caolog->addlog($order->user_id, $old_money, $charge_money, $new_money, 'charge', $note);
            //更新订单状态
            $ShopOrder->update($out_trade_no, $trade_no);
            //发放佣金 查找推荐人
            add_to_user_bonus($order->user_id,$charge_money);
            //发送邮件
            $obj_user = get_user_by('ID', $order->user_id);
            _sendMail($obj_user->user_email, '支付成功', $note);
        }
    }
    if($order && $order->order_type == 'other'){
        //更新订单状态
        $ShopOrder->update($out_trade_no, $trade_no);
        //更新文章购买记录
        $PostPay = new PostPay($uid, $post_id);
        $PostPay->update($out_trade_no);
    }
    exit("success");
}