<?php 
	$options = get_option( 'um_options' );
	$um_reward_set = $options['um_reward_set'];
	$um_zan_set = $options['um_zan_set'];
	get_header(); 
?>

<div class="single">
	<?php include(TEMPLATEPATH . '/template-parts/ad.php'); ?>	
	<div class="uk-container uk-container-center ">
		<div class="crumb">
			<?php if(function_exists('cmp_breadcrumbs')) cmp_breadcrumbs();?>
		</div>
		<div class="uk-grid">
			<div class="uk-width-small-1-1 uk-width-large-7-10">
				<div class="uk-block-default b-r-4 ">
					<?php while ( have_posts() ) : the_post(); ?>
					<header class="single-head b-b uk-nbfc">
						<div class="single-title">
							<h1><?php the_title(); ?><span style="display:none">_<?php bloginfo('name'); ?></span></h1>
							<div class="single-data">
								<span><i class="iconfont icon-rili"></i><?php echo time_since($post->post_date);?></span>
								<span class="uk-hidden-small"><i class="iconfont icon-message"></i><?php echo $post->comment_count; ?></span>
								<span><i class="iconfont icon-eye"></i><?php post_views('', ''); ?></span>
								<span><?php edit_post_link('<i class="iconfont icon-bianji"></i>编辑'); ?></span>	
							</div>
						</div>
					</header>
					<?php 
					if ( in_category(array(68,172,173,176,182,244)) ){
						echo '<div class="single-content single-tx">';
					}
					elseif ( in_category(array(27)) ){
						echo '<div class="single-content single-article">';
					}else{
						echo '<div class="single-content">';
					}
					?>	
						<?php the_content(); ?>

						<div class="zan uk-margin-large-top">
							<?php if( $um_zan_set==0 ){}else {?>
							<a href="javascript:;" data-action="topTop" data-id="<?php the_ID(); ?>" class="b-r-4 dotGood <?php echo isset($_COOKIE['dotGood_' . $post->ID]) ? 'done' : ''; ?>">
								<i class="iconfont icon-like-fill"></i>(<span class="count"><?php echo ($dot_good=get_post_meta($post->ID, 'dotGood', true)) ? $dot_good : '0'; ?></span>)
							</a>
							<?php }?>
							<?php if( $um_reward_set==0 ){}else {?>
							<a href="#reward" data-uk-modal=""  class="reward b-r-4">
								<i class="iconfont icon-icon-test20"></i><span class="count">打赏</span>
							</a>
							<?php }?>

						</div>
						
					</div>
					<div class="single-bottom uk-text-left">
						<div class="single-tags uk-text-left uk-margin-large-top">
							<i class="iconfont icon-tag"></i><?php the_tags('', ',') ?>
						</div>
						<div class="uk-alert uk-alert-warning single-warning uk-text-left b-r-4 uk-margin-large-top" data-uk-alert="">
							<a href="" class="uk-alert-close uk-close"></a>
							<p class="uk-margin-remove">标题：<?php the_title(); ?></p>
							<p class="uk-margin-remove">分类：<?php the_category(' ') ?></p>	
							<p class="uk-margin-remove">链接：<?php the_permalink(); ?></p>	
							<p class="uk-margin-remove">版权：<?php echo $options['um_article_cop']; ?></p>	
						</div>
					</div>	
					<?php endwhile; ?>
				
				</div>
				<?php include(TEMPLATEPATH . '/template-parts/turn-page.php');?>

				<div class="uk-margin-bottom">
					<?php comments_template( '', true ); ?>
				</div>
				<div class="uk-hidden-small">
					<div class="part-title">
						<h3>猜你喜欢</h3>
					</div>
					<div class="pic-list uk-grid uk-grid-medium" data-uk-grid >
						<?php
						query_posts('cat=-19&posts_per_page=9&ignore_sticky_posts=1&orderby=rand');
						while(have_posts()):the_post();
						?>
						<div class="uk-width-1-1 uk-width-small-1-2 uk-width-medium-1-2 uk-width-large-1-3">
							<?php include(TEMPLATEPATH . '/template-parts/loop/pic.php');?>
						</div>
						<?php endwhile;wp_reset_query();?>

					</div>
				</div>

			</div>
			<div class="uk-width-small-1-1 uk-width-large-3-10">
				<?php include(TEMPLATEPATH . '/template-parts/side/single-side.php'); ?>
			</div>
		</div>	
	</div>

<?php get_footer(); ?>