<?php 
	get_header();
	$options = get_option( 'um_options' ); 
	$um_author_bg = $options['um_author_bg'];
?>
			<div class="author">
				<div class="author-top uk-block-default uk-position-relative b-t">
					<div class="author-top-bg uk-position-absolute">
						<img src="<?php if ( get_the_author_meta( 'bg' ) ){echo get_the_author_meta( 'bg' );}else {echo $um_author_bg; }?>" alt="<?php the_author_login(); ?>" >
					</div>
					<div class="uk-h1 uk-position-relative uk-text-contrast uk-text-center uk-margin-large-top">#<?php the_author_nickname(); ?></div>
				</div>
				<div class="author-main uk-container uk-container-center uk-position-relative">
					<div class="uk-grid">
						<div class="uk-width-1-1 uk-width-small-1-1 uk-width-medium-7-10 uk-width-large-7-10">
							<div class="box-title uk-block-default b-b">
								<i class="iconfont icon-aixin"></i> Ta的动态
							</div>
							<div class="ajax-ul">
								<?php if(have_posts()) : while (have_posts()) : the_post(); ?>
								
								<div class="uk-block-default ajax-li b-b">
									<div class="box-main">
										<div class="item-info">
											<h3><a href="<?php the_permalink(); ?>" target="_blank"><?php echo wp_trim_words( get_the_title(), 10 ); ?></a></h3>
											<div class="data uk-text-small uk-margin-top">
												<span class="uk-margin-right"><i class="iconfont icon-rili"></i><?php echo time_since($post->post_date);?></span>
												<span class="uk-margin-right"><i class="iconfont icon-xiaoxi"></i><?php echo $post->comment_count; ?></span>
												<span class="uk-margin-right"><i class="iconfont icon-eye"></i><?php post_views('', ''); ?></span>
											</div>
										</div>
									</div>
								</div>
								<?php endwhile; else: ?>
								<div class="uk-width-1-1 uk-container-cente">
									<div class="uk-alert uk-alert-warning uk-text-warning uk-text-muted uk-margin-large-top uk-margin-large-bottom">
										<a href="" class="uk-alert-close uk-close"></a>
										<p>很懒，很个性，就不发动态！</p>
									</div>
								</div>
								<?php endif; ?>

							</div>
							<div class="uk-margin-top">
								<div id="pagination" class="ajax-btn uk-display-block">
									<?php next_posts_link(__('点击查看更多')); ?>
								</div>
							</div>
						</div>
						<div class="uk-width-3-10 uk-hidden-small">
							<?php include(TEMPLATEPATH . '/template-parts/loop/author.php');?>
									
						</div>
					</div>
				</div>
			</div>

<?php get_footer(); ?>