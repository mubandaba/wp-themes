<?php 
	get_header(); 
	$options = get_option( 'um_options' ); 
	$um_homelink_set = $options['um_homelink_set'];
	$home_parts = $options['home_parts'];
	include(TEMPLATEPATH . '/template-parts/home/search.php');
?>
<div class="uk-container uk-container-center">
	<?php 
		include(TEMPLATEPATH . '/template-parts/home/catbox.php');
		include(TEMPLATEPATH . '/template-parts/home/topic.php');
		include(TEMPLATEPATH . '/template-parts/home/tx.php');
		include(TEMPLATEPATH . '/template-parts/home/mt.php');
		include(TEMPLATEPATH . '/template-parts/home/music.php');
		include(TEMPLATEPATH . '/template-parts/home/article.php');
		include(TEMPLATEPATH . '/template-parts/home/like.php');
	?>
	<?php
	if ( is_home() ) { 
		if (!$um_homelink_set){ 
		}else {?>
	<div class="part link">
		<div class="part-title">
			<h3>友情链接</h3>
			<em class="uk-float-right uk-text-muted">友情链接Qq：1098816988</em>
		</div>
		<ul class="uk-panel uk-block-default b-r-4 uk-margin-remove">
			<?php wp_list_bookmarks('title_li=&categorize=0'); ?>
		</ul>
	</div>	
	<?php } } ?>
</div>
<?php get_footer(); ?>