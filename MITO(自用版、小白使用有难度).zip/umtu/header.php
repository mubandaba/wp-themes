<!DOCTYPE html>
<html <?php language_attributes(); ?> >
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<?php wp_head();?>
		<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" />
		<link rel="stylesheet" href="<?php bloginfo('template_url');?>/static/css/uikit.css" />
<?php if ( is_single() ) { ?>
		<link rel="stylesheet" href="<?php bloginfo('template_url');?>/static/css/components/slidenav.min.css" />
<?php } ?>		<link rel="stylesheet" href="<?php bloginfo('template_url');?>/static/css/components/tooltip.min.css" />
		<link rel="stylesheet" href="<?php bloginfo('template_url');?>/static/css/components/notify.min.css" />
		<link rel="stylesheet" href="<?php bloginfo('template_url');?>/static/plugin/swiper/css/swiper.min.css" />
		<link rel="stylesheet" href="https://at.alicdn.com/t/font_1434095_48g60w4jcrx.css" />
		<link rel="shortcut icon" href="<?php $options = get_option( 'um_options' ); echo $options['um_head_favicon']; ?>"/>	

		<?php 
			$um_homeside_set = $options['um_homeside_set'];
			$um_home_wide_set = $options['um_home_wide_set'];
			if( $um_home_wide_set==0 ){}else {
		?>
		<style>.uk-container {width: 1440px!important;max-width: none!important;}</style>
		<?php }?><?php echo $options['um_head_code']; ?>
		
		<script>
			(function(){
				var bp = document.createElement('script');
				var curProtocol = window.location.protocol.split(':')[0];
				if (curProtocol === 'https') {
					bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
				}
				else {
					bp.src = 'http://push.zhanzhang.baidu.com/push.js';
				}
				var s = document.getElementsByTagName("script")[0];
				s.parentNode.insertBefore(bp, s);
			})();
		</script>
		<!-- 百度推送 -->

	</head>
	<body>
		<div id="umtu" class="uk-position-relative uk-nbfc">
			<header class="uk-block-default">
				<div class="navbar uk-container uk-container-center uk-grid uk-grid-collapse">
					<div class="uk-width-1-3 uk-width-small-1-2 uk-width-medium-5-10 uk-width-large-1-10">
						<h1><a href="<?php bloginfo('url'); ?>" target="_blank"><img src="<?php echo $options['um_head_logo']; ?>" alt="<?php bloginfo('name'); ?>"></a></h1>
					</div>
					<div class="uk-width-7-10 uk-visible-large">
						<?php 
						wp_nav_menu( array(
							'theme_location' => 'head-nav',//用于在调用导航菜单时指定注册过的某一个导航菜单名，如果没有指定，则显示第一个
							'container'  => 'nav',  //容器标签
							'container_class' => 'nav',//ul父节点class值
							'menu_id'   => '',  //ul节点id值
							'echo'  => true,//是否输出菜单，默认为真
						) );
						?>
					</div>
					<div class="head-menu uk-text-right uk-width-2-3 uk-width-small-1-2 uk-width-medium-5-10 uk-width-large-2-10">
						<?php if ( is_user_logged_in() ) { ?>
						<div class="uk-button-dropdown" data-uk-dropdown="">
							<a href="/author/<?php global $current_user;echo $current_user->user_login;?>" class="s-avatar rotate uk-display-inline-block"><?php global $current_user;get_currentuserinfo();echo get_avatar( $current_user->user_email, 32); ?></a>
							<div class="uk-dropdown shadow">
								<ul class="uk-nav uk-nav-dropdown uk-text-center">
									<?php if( current_user_can( 'read' ) && !current_user_can( 'edit_posts' ) ) {?>
									<li class="b-b"><a class="fabu" >发布文章</a></li>
									<?php }else {?>
									<li class="b-b"><a href="/wp-admin/post-new.php" target="_blank" rel="nofollow">发布文章</a></li>
									<?php }?>
									<li class="b-b"><a href="/author/<?php global $current_user;echo $current_user->user_login;?>" target="_blank" rel="nofollow">个人主页</a></li>
									<li class="b-b"><a href="/wp-admin/profile.php" target="_blank" rel="nofollow">个人资料</a></li>
									<li class="b-b"><a href="<?php echo home_url(user_trailingslashit('/wp-admin'));?>" target="_blank" rel="nofollow">进入后台</a></li>
									
									<li><a href="<?php echo wp_logout_url(home_url()); ?>" title="退出">退出登录</a></li>
								</ul>
							</div>
						</div>
						<?php }else{?>
						<a href="/wp-login.php"  class="s-avatar rotate uk-display-inline-block" target="_blank" rel="nofollow"><img style="opacity: .3;" src="<?php bloginfo('template_url');?>/static/images/default-avatar.png"></a>

						<?php }?>

						<a href="#search" data-uk-modal class="uk-margin-left"><i class="iconfont icon-sousuo uk-border-circle"></i></a>
						<?php if (!$um_homeside_set){}else {?>
							<a href="#head-locker" data-uk-offcanvas class="uk-margin-left"><i class="iconfont icon-align-right uk-border-circle"></i></a>
						<?php }?>	
					</div>
				</div>
				<div id="head-locker" class="uk-offcanvas">
					<div class="head-locker-bg uk-offcanvas-bar uk-offcanvas-bar-flip">
						<div class="side-main">
							<div class="uk-flex-center uk-text-center uk-margin-top uk-margin-bottom">
								<a href="<?php bloginfo('url'); ?>" target="_blank" class="uk-display-inline-block uk-margin-bottom"><img src="<?php echo $options['um_head_logo'];?>" alt="<?php bloginfo('name'); ?>"></a>
								<h3 class="uk-margin-remove">收录优美图片</h3>
								<span class="uk-text-muted">www.umtu.cn</span>
							</div>
							<?php 
							wp_nav_menu( array(
								'theme_location' => 'head-nav',//用于在调用导航菜单时指定注册过的某一个导航菜单名，如果没有指定，则显示第一个
								'container'  => 'nav',  //容器标签
								'container_class' => 'side-nav b-t',//ul父节点class值
								'menu_id'   => '',  //ul节点id值
								'echo'  => true,//是否输出菜单，默认为真
							) );
							?>
						</div>
					</div>
				</div>
				<!-- 首页侧边栏导航 -->
			</header>
			<main>