<?php 
/* Template Name: 标签页 */ 
?>
<?php get_header(); ?>
				<div class="tag">
					<div class=" uk-block-default b-t">
						<div class="uk-container uk-container-center">
							<div class="page-top part-title">
								<h3>#<?php single_tag_title(); ?></h3>
								<p class="uk-text-muted">标签为 #<?php single_tag_title(); ?> 内容如下：</p>
							</div>
						</div>
					</div>
					<div class="uk-container uk-container-center uk-margin-large-top">
						<div class="pic-list uk-grid uk-grid-medium" data-uk-grid >
							<?php while (have_posts()) : the_post(); ?>

							<div class="uk-width-1-1 uk-width-small-1-1 uk-width-medium-1-2 uk-width-large-1-4 uk-margin-bottom">
								<?php include(TEMPLATEPATH . '/template-parts/loop/pic.php');?>

							</div>
							<?php endwhile; ?>

						</div>
						<div class="fenye">
							<?php fenye(); ?>
						</div>	
					</div>
					
				</div>

<?php get_footer(); ?>
