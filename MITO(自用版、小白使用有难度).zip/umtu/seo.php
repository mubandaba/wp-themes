<?php 
/* 
 * Template Name:SEO
 */ 
	$options = get_option( 'um_options' );
	global $wp_query;
	$cat_keywords = get_query_var('cat');
	$um_home_title = $options['um_home_title'];
	$um_home_keywords = $options['um_home_keywords'];
	$um_home_description = $options['um_home_description'];
	$um_cat_text = $options['um_cat_text']['id']
?>
<title><?php 
	if ( is_home() ) { 
		bloginfo('name');_e(' - ');$paged = get_query_var('paged'); if ( $paged > 1 ) printf('第%s页 - ',$paged); bloginfo('description');
	}elseif ( is_category() ) { 
		_e(trim(wp_title('',0)));_e(' - ');$paged = get_query_var('paged'); if ( $paged > 1 ) printf('第%s页 - ',$paged); bloginfo('name');
	}elseif ( get_post_type() == 'topic'  ) { 
		_e(trim(wp_title('',0)));_e(' - ');$paged = get_query_var('paged'); if ( $paged > 1 ) printf('第%s页 - ',$paged); bloginfo('name');
	}elseif ( is_single() ){
		_e(trim(wp_title('',0)));_e(' - ');$category = get_the_category();echo $category[0]->cat_name;_e(' - ');bloginfo('name');
	}elseif ( is_search() ) {
	_e('搜索「');$allsearch = WP_Query("s=$s&showposts=-1"); $key = wp_specialchars($s, 1); $count = $allsearch->post_count; _e(''); _e($key.'」'); _e('的结果 - ');$paged = get_query_var('paged'); if ( $paged > 1 ) printf('第%s页 - ',$paged); bloginfo('name'); wp_reset_query();
}elseif ( is_404() ) {
		_e('404 Not Found(页面未找到) - '); bloginfo('name');
	}elseif ( is_author() ) {
		_e('「');_e(trim(wp_title('',0)));_e('」的个人主页 - ');bloginfo('name');
	}elseif(is_page()){
		_e(trim(wp_title('',0)));_e(' - ');$paged = get_query_var('paged'); if ( $paged > 1 ) printf('第%s页 - ',$paged); bloginfo('name');
	}elseif ( is_month() ) {
		the_time('Y年n月');_e('的文章归档');_e(' - ');$paged = get_query_var('paged'); if ( $paged > 1 ) printf('第%s页 - ',$paged); bloginfo('name');
	}elseif ( is_day() ) {
		the_time('Y年n月j日');_e('的文章归档');_e(' - ');$paged = get_query_var('paged'); if ( $paged > 1 ) printf('第%s页 - ',$paged); bloginfo('name');
	}elseif (function_exists('is_tag')){
		if ( is_tag() ) {
			_e('标签为「');single_tag_title("", true);_e('」的相关内容');_e(' - ');$paged = get_query_var('paged'); if ( $paged > 1 ) printf('第%s页 - ',$paged); bloginfo('name');_e(' - ');
		}
	}
	?>
</title>
<?php
	$keywords = $um_home_keywords;
	$description = $um_home_description;
	if (is_home()){
		$keywords = $um_home_keywords;
		$description = $um_home_description;
	} elseif ( is_category() ) { 
		$description = category_description();
		$keywords = get_option('cat-keywords-'.$cat_keywords);
	} elseif (is_single()){
		$single_cat = get_the_category(); 
		$single_cat_id = $single_cat[0]->cat_ID;
		if(wp_get_post_tags($post->ID)){
			$tags = wp_get_post_tags($post->ID);
			foreach ($tags as $tag ) {
				$keywords = $tag->name.",".$keywords;
			}
		}else{
			$keywords = $um_home_keywords;
		}
		if ($post->post_excerpt) {
			$description = $post->post_excerpt;
		}elseif ($single_cat_id != $um_cat_text ){
			$description = get_the_title($post->ID); 
		}else {
			global $more; 
			$more = 1; //1=全文 0=摘要 
			$my_content = strip_tags(get_the_excerpt(), $post->post_content); //获得文章 
			$my_content = str_replace(array('rn', 'r', 'n', ' ', 't', 'o', 'x0B',''),'',$my_content); //去掉空格
			$my_content = mb_strimwidth( $my_content, 0, 180, '...');
			$description = $my_content;
		}
	} elseif(function_exists('is_tag')){
		if( is_tag() ) {
			$keywords = trim(wp_title('',0)).",".$keywords;
			$description = trim(wp_title('',0)) . "相关的内容" ;
		}
	}if ( is_search() ) {
		$keywords = $um_home_keywords;
		$description = "搜索" .$key. "的结果 - " .$keywords; 
	}?>
		<meta name="keywords" content="<?=$keywords?>" />
		<meta name="description" content="<?=$description?>" />
