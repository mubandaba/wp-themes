<?php 
/* Template Name:默认 */ 
get_header(); 
$options = get_option( 'um_options' );
?>
<div class="category">
	<?php include(TEMPLATEPATH . '/template-parts/ad.php'); ?>
	<div class="category-list b-t uk-block-default">
		<ul class="uk-container uk-container-center uk-overflow-container">
			<li><a href="<?php get_category_cat() ?>" class="vary-bg uk-text-contrast">全部</a></li>	

			<?php wp_list_categories( 
				$args = array(
					'show_option_all'    => '',
					'orderby'            => 'name',
					'use_desc_for_title' => 1,
					'child_of'           => get_category_root_id($cat),
					'optioncount'=>1,
					'hierarchical'       => 1,
					'title_li'           => '',
					'show_option_none'   => __('<span style="padding:0 20px;">抱歉，暂无分类。</span>'),
					'depth'              => 1,
					'taxonomy'           => 'category',
					'walker'             => null
				)); 
			?>

		</ul>
	</div>
	<div class="uk-container uk-container-center">
		<?php if(function_exists('cmp_breadcrumbs')) cmp_breadcrumbs();?>

		<div class="article-main uk-grid">

			<div class="uk-width-1-1 uk-width-medium-7-10 uk-width-large-7-10">
				<div class="uk-grid uk-grid-medium" data-uk-grid >
					<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
					<div class="uk-width-1-1 uk-width-small-1-2 uk-width-medium-1-2 uk-width-large-1-3 uk-margin-bottom">
						<?php include(TEMPLATEPATH . '/template-parts/loop/pic.php'); ?>
					</div>
					<?php endwhile; else: ?>
					
					<div class="uk-width-1-1">
						<div class="uk-alert uk-alert-warning uk-text-center">抱歉，暂时没有任何收录！</div>
					</div>
					<?php endif; ?>

				</div>
			</div>
			<div class="uk-width-3-10 uk-hidden-small">
				<?php include(TEMPLATEPATH . '/template-parts/side/cat-side.php');?>
				
			</div>
		</div>
		<div class="fenye uk-margin-large-top">
			<?php fenye(); ?>
		</div>
	</div>
</div>

<?php get_footer(); ?>

