<div class="sidebar">

	<?php 	
		include(TEMPLATEPATH . '/template-parts/side/logo.php');
		include(TEMPLATEPATH . '/template-parts/side/nav.php');
		include(TEMPLATEPATH . '/template-parts/side/user.php');
		include(TEMPLATEPATH . '/template-parts/side/hot.php');
	?>
	
</div>