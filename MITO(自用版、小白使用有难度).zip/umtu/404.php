<!DOCTYPE html>
<html>

	<head>
		<meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>404</title>
		<meta name="Keywords" content="传奇sf发布网,传奇私服,1756新服网" />
		<meta name="Description" content="1756新服网是面向传奇私服游戏玩家的综合门户，是个有趣有态度的传奇sf发布网，找私服不能错过1756fw.com。" />
		<link rel="stylesheet" href="https://at.alicdn.com/t/font_1434095_u0gcuy95zjh.css" />

		<style>
			.bg {
				background-color: #000000;
				-webkit-background-size: cover;
				-moz-background-size: cover;
				-o-background-size: cover;
				background-size: cover;
				-webkit-text-size-adjust: none;
				background-attachment: fixed;
				background-image: url(https://img.umtu.cn/wp-content/uploads/2019/11/2019110713593182.jpg?imageView2/1/w/3840/h/2160/interlace/1/q/100#);
				background-repeat: no-repeat;
				background-position: center center;
			}
			
			.wrap {
				position: relative;
				z-index: 20;
				margin-top: 100px;
			}
			
			.w1200 {
				width: 1200px;
				margin: 0 auto;
			}
			
			.head {
				margin: 30px 0;
				text-align: center;
			}
			
			.content {
				color: #333;
				background: #fff;
				padding: 5em 7em
			}
			
			.content h2 {
				font-size: 48px;
				margin: 0;
			}
			
			.content p {
				max-width: 80%;
				font-size: 16px;
				letter-spacing: 1px;
				line-height: 26px;
				color: #888;
				margin-bottom: 50px;
				font-family: arial, 'Microsoft JhengHei';
			}
			
			.search {}
			
			.search-form {
				background: #eee;
				max-width: 260px;
				padding: 15px 20px;
				position: relative;
			}
			
			.search-input {
				border: none;
				background: none;
				outline: none;
				color: #333;
			}
			
			.search-button {
				border: 0;
				background: none;
				color: #333;
				font-weight: bold;
				cursor: pointer;
				position: absolute;
				right: 10px;
			}
			
			.nav {
				margin-top: 30px;
				color: #333;
				font-size: 15px;
				font-weight: bold;
				font-family: arial, 'Microsoft JhengHei';
			}
			
			.nav a {
				color: #333;
				text-decoration: none;
				margin-right: 20px;
				font-weight: normal;
			}
			
			.foot-nav {
				color: #fff;
				font-size: 13px;
				text-align: center;
			}
			
			.foot-nav a {
				color: #fff;
				text-decoration: none;
			}
		</style>
	</head>

	<body class="bg">
		<div class="wrap">
			<div class="w1200">
				<header class="head">
					<a href="http://www.umtu.cn"><img src="https://img.umtu.cn/wp-content/uploads/2019/10/2019102103335792.png" /></a>
				</header>
				<!-- header -->
				<main>
					<div class="content">
						<h2>404ERROR.</h2>
						<p>对不起，你现在访问的页面估计可能也许应该是不存在</br>
							也不知道你是怎么跑到这个页面来的。</br>
							你可以在下面搜索框内搜索你喜欢的内容，也可以点击导航直达页面！</p>
						<div class="seach">
							<form method="get" class="search-form" action="https://www.umtu.cn">
								<input type="search" placeholder="输入关键词进行搜索…" autocomplete="off" value="" name="s" required="required" class="search-input">
								<button type="submit" class="search-button"><i class="iconfont icon-sousuo"></i></button>
							</form>
						</div>
						<div class="nav">
							快捷导航：
							<a href="https://www.umtu.cn" target="_blank">网站首页</a>
							<a href="https://www.umtu.cn/bizhi" target="_blank">高清壁纸</a>
							<a href="https://www.umtu.cn/youmei/tx" target="_blank">个性头像</a>
						</div>
					</div>
				</main>
				<!-- main -->
				<footer>
					<div class="foot-nav">

						<p>
							<a href="https://www.umtu.cn" target="_blank">优美图（umtu.cn）</a> - Copyright © 2018-2019</p>
					</div>
				</footer>
				<!-- footer -->
			</div>
		</div>
		<!-- wrap -->
	</body>

</html>