	//返回顶部/返回底部
	var jq_um=jQuery.noConflict();
	jq_um(window).scroll(function(){
		var scroll_top = jq_um(window).scrollTop();
		if(scroll_top>=200){
			jq_um(".go-top").fadeIn();
		}else{
			jq_um(".go-top").fadeOut();
		}
	})
	jq_um('#go-top').click(function() {
		jq_um('html,body').animate({
			scrollTop: '0px'
		}, 500);
	});
	jq_um('#go-bottom').click(function() {
		jq_um('html,body').animate({
			scrollTop: jq_um('.footer').offset().top
		}, 500);
	});


	//发布文章提示
	jq_um('.fabu').click(function(){
		UIkit.notify({
			message : '抱歉！您暂无权限发布文章。<a class="uk-text-success uk-margin-left" href="https://umtu.cn/join" target="_blank">立即申请 →</a>',
			status  : 'danger',
			timeout : 1000,
			pos     : 'top-center'
		});
	})


	//快捷投稿
	var arr = new Array();
	arr[0] = "每日签到，收录优美图片，分享美好生活！";
	arr[1] = "每日签到，幸福的人从不晚睡，";
	arr[2] = "每日签到，美好的生活，从每日签到开始！";
	arr[3] = "每日签到，人情纵似长情月，算一年年。又能得、几回圆。";
	arr[4] = "每日签到，人生如逆旅，我亦是行人！";
	arr[5] = "每日签到，若人间有情，那是开始，也是尽头。";
	arr[6] = "每日签到，雨打梨花深闭门。忘了青春，误了青春。";
	arr[7] = "每日签到，人生不过是午后到黄昏的距离，茶凉言尽，月上柳梢。";
	arr[8] = "每日签到，人间烟火，山河远阔；无一是你，无一不是你。";
	arr[9] = "每日签到，如果有来生，希望每次的相逢，都能化为永恒。";

	var arrs = arr[Math.floor((Math.random() * arr.length))];
	var tags = '每日签到'
	var myDate = new Date();
	var year = myDate.getFullYear();
	var month = myDate.getMonth() + 1;
	var date = myDate.getDate();
	var now = year + '-'  + month + '-' + date

	jq_um('#qiandao').click(function(){
		jq_um('#tougao_content').val(now + '' + arrs);
		jq_um('#tougao_title').val(now + '' + arrs);
		jq_um('#tougao_tags').val(tags);
	})


	//点赞
	jq_um.prototype.postLike = function () {
		if (jq_um(this).hasClass('done')) {
			UIkit.notify({
				message : '您已经点过赞了！！！',
				status  : 'danger',
				timeout : 3000,
				pos     : 'top-center'
			});
			return false;
		} else {
			jq_um(this).addClass('done');
			var id = jq_um(this).data("id"),
				action = jq_um(this).data('action'),
				rateHolder = jq_um(this).children('.count');
			var ajax_data = {
				action: "dotGood",
				um_id: id,
				um_action: action
			};
			jq_um.post("/wp-admin/admin-ajax.php", ajax_data,
				function (data) {
					jq_um(rateHolder).html(data);
				});
			return false;
		}
	};
	jq_um(".dotGood").click(function () {
		jq_um(this).postLike();
	});



	//点击加载更多
	jQuery(document).ready(function($) {
		//点击下一页的链接(即那个a标签)
		$('#pagination a').click(function() {
			$this = $(this);
			$this.addClass('loading').text("正在努力加载..."); //给a标签加载一个loading的class属性，可以用来添加一些加载效果
			var href = $this.attr("href"); //获取下一页的链接地址
			if (href != undefined) { //如果地址存在
				$.ajax({ //发起ajax请求
					url: href, //请求的地址就是下一页的链接
					type: "get", //请求类型是get
					error: function(request) {
						//如果发生错误怎么处理
					},
					success: function(data) { //请求成功
						setTimeout(function(){
							$this.removeClass('loading').text("点击查看更多"); //移除loading属性
							var $res = $(data).find(".ajax-li"); //从数据中挑出文章数据，请根据实际情况更改
							$('.ajax-ul').append($res.fadeIn(500)); //将数据加载加进posts-loop的标签中。
							var newhref = $(data).find("#pagination a").attr("href"); //找出新的下一页链接
							if (newhref != undefined) {
								$("#pagination a").attr("href", newhref);
							} else {
								$("#pagination").remove(); //如果没有下一页了，隐藏
							}
						},500);
					}
				});
			}
			return false;
		});
	});


	//首页分类轮播
	var swiper = new Swiper('.category-container', {
		slidesPerView: 1,
		spaceBetween: 10,
		autoplay: {
			delay: 3000, //1秒切换一次
		},
		// init: false,
		pagination: {
			el: '.category-pagination',
			clickable: true,
		},
		breakpoints: {
			640: {
				slidesPerView: 1,
				spaceBetween: 20,
			},
			768: {
				slidesPerView: 2,
				spaceBetween: 25,
			},
			1024: {
				slidesPerView: 4,
				spaceBetween: 25,
			},
		}
	});

	//首页分类轮播
	var swiper = new Swiper('.topci-container', {
		slidesPerView: 1,
		spaceBetween: 10,
		autoplay: {
			delay: 3000, //1秒切换一次
		},
		// init: false,
		breakpoints: {
			640: {
				slidesPerView: 1,
				spaceBetween: 20,
			},
			768: {
				slidesPerView: 2,
				spaceBetween: 25,
			},
			1024: {
				slidesPerView: 3,
				spaceBetween: 25,
			},
		}
	});
