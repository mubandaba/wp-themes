<?php 
// 分类添加字段
function ems_add_category_field(){
	echo '<div class="form-field">
			<label for="cat-keywords">关键词</label>
			<input name="cat-keywords" id="cat-keywords" type="text" value="" size="40">
			<p>输入关键词</p>
		  </div>';	
}
add_action('category_add_form_fields','ems_add_category_field',10,2);
 
// 分类编辑字段
function ems_edit_category_field($tag){
	echo '<tr class="form-field">
			<th scope="row"><label for="cat-keywords">关键词</label></th>
			<td>
				<input name="cat-keywords" id="cat-keywords" type="text" value="';
				echo get_option('cat-keywords-'.$tag->term_id).'" size="40"/><br>
				<p class="description">'.$tag->name.' 关键词</p>
			</td>
		</tr>';
}
add_action('category_edit_form_fields','ems_edit_category_field',10,2);
 
// 保存数据
function ems_taxonomy_metadate($term_id){
	if(isset($_POST['cat-keywords'])){
		//判断权限--可改
		if(!current_user_can('manage_categories')){
			return $term_id;
		}
		// 电话
		$cat_key = 'cat-keywords-'.$term_id; // key 选项名为 cat-keywords-1 类型
		$cat_value = $_POST['cat-keywords'];	// value
		

		// 更新选项值
		update_option( $cat_key, $cat_value ); 
	}
}
 
// 虽然要两个钩子，但是我们可以两个钩子使用同一个函数
add_action('created_category','ems_taxonomy_metadate',10,1);
add_action('edited_category','ems_taxonomy_metadate',10,1);
?>
