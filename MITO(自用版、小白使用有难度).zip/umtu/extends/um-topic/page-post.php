<?php
/* 
 * Template Name:快捷发布
 */ 

if( isset($_POST['tougao_form']) && $_POST['tougao_form'] == 'send') {
	global $wpdb;
	$current_url = 'https://umtu.cn/topic';   // 注意修改此处的链接地址

	$last_post = $wpdb->get_var("SELECT `post_date` FROM `$wpdb->posts` ORDER BY `post_date` DESC LIMIT 1");


	// 表单变量初始化
	$title =  isset( $_POST['tougao_title'] ) ? trim(htmlspecialchars($_POST['tougao_title'], ENT_QUOTES)) : '';
	$category =  isset( $_POST['cat'] ) ? (int)$_POST['cat'] : 0;
	$content =  isset( $_POST['tougao_content'] ) ? trim(htmlspecialchars($_POST['tougao_content'], ENT_QUOTES)) : '';
	$tags = isset( $_POST['tougao_tags'] ) ? $_POST['tougao_tags'] : '';
	
	$post_content = $content;

	$tougao = array(
		'post_title' => $content, 
		'post_content' => $post_content,
		'post_status' => 'publish',
		'tags_input' => $tags,
		'post_category' => array($category),
		'post_type' => 'topic' //tougao_type是要保存到的自定义文章类型
	);


	// 将文章插入数据库
	$status = wp_insert_post( $tougao );

	if ($status != 0) { 
		// 投稿成功给博主发送邮件
		// somebody#example.com替换博主邮箱
		// My subject替换为邮件标题，content替换为邮件内容
		wp_mail("109881698@qq.com","您有新的消息，请查收！","您的网站有新的消息，请查看！");

		print_r('<script>alert("发布成功！");</script><meta http-equiv="refresh" content="0;url=https://umtu.cn/topic">');
	}
	else {
		print_r('<script>alert("投稿失败，点击确定返回");window.location.href="https://umtu.cn/topic";</script>');
	}
}
?>

<div class="box uk-block-default b-r-4 uk-margin-large-bottom">
	<div class="box-title b-b b-t">
		<h3><i class="iconfont icon-icon-test5"></i> 来一发?</h3>
	</div>
	<div class="box-main">
		<?php if (!(current_user_can('level_0'))){ ?>
		
		<p>抱歉，<a href="/login" class="uk-text-warning" data-uk-tooltip title="点击登录">登录</a>后才可以发布文章！</p>
		<?php } else { ?>
	
		<div class="uk-grid">
			<div class="uk-width-1-1">
				<form class="uk-form" method="post" action="<?php echo $_SERVER["REQUEST_URI"]; $current_user = wp_get_current_user(); ?>">
					<div class="uk-form-row" style="display:none">
					<input type="text" id="tougao_tags" value="" name="tougao_tags" placeholder="话题分类 (选填)" />
					</div>
					<div class="uk-form-row">
						<textarea rows="5" cols="200" id="tougao_content" class="b-r-4"name="tougao_content" placeholder="说点什么呢? (必填)"></textarea>
					</div>

					<div class="uk-margin-top  uk-margin-bottom">
						<input type="hidden" value="send" name="tougao_form" />
						<button class="char-btn b-r-4 vary-bg uk-text-contrast" type="submit" value="提交" >提交</button>
						<button class="char-btn b-r-4 uk-text-muted" type="reset" value="重填" >清空</button>
					</div>
				</form>
				快捷发布：<a id="qiandao">#每日签到</a>
			</div>
		</div>
		<?php }?>
		
	</div>
</div>