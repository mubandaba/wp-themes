<?php

	//添加话题
	function my_custom_post_topic() {
		$labels = array(
			'name'               => _x( '碎碎念', 'post type 名称' ),
			'singular_name'      => _x( '话题', 'post type 单个 item 时的名称，因为英文有复数' ),
			'add_new'            => _x( '新建话题', '添加新内容的链接名称' ),
			'add_new_item'       => __( '新建话题' ),
			'edit_item'          => __( '编辑话题' ),
			'new_item'           => __( '新话题' ),
			'all_items'          => __( '所有话题' ),
			'view_item'          => __( '查看话题' ),
			'search_items'       => __( '搜索话题' ),
			'not_found'          => __( '没有找到有关话题' ),
			'not_found_in_trash' => __( '回收站里面没有相关话题' ),
			'parent_item_colon'  => '',
			'menu_name'          => '话题'
		);
		$args = array(
			'labels'        => $labels,
			'description'   => '话题信息',
			'public'        => true,
			'menu_position' => 5,
			'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'comments' ),
			'has_archive'   => true
		);
		register_post_type( 'topic', $args );
	}
	add_action( 'init', 'my_custom_post_topic' );

	//文章固定链接修改
	add_filter('post_type_link', 'custom_topic_link', 1, 3);
	function custom_topic_link( $link, $post = 0 ){
		if ( $post->post_type == 'topic' ){
			return home_url( 'topic/' . $post->ID .'.html' );
		} else {
			return $link;
		}
	}
	add_action( 'init', 'custom_topic_rewrites_init' );
	function custom_topic_rewrites_init(){
		add_rewrite_rule(
			'topic/([0-9]+)?.html$',
			'index.php?post_type=topic&p=$matches[1]',
			'top' );
		add_rewrite_rule(
			'topic/([0-9]+)?.html/comment-page-([0-9]{1,})$',
			'index.php?post_type=topic&p=$matches[1]&cpage=$matches[2]',
			'top'
		);
	}

?>