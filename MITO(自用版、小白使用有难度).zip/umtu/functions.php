<?php
/*
 * umtu 1.0
 * by umtu.cn
 * http://umtu.cn
 */


	include TEMPLATEPATH . '/extends/um-topic/setting.php';
	include TEMPLATEPATH . '/extends/um-avatar/simple-local-avatars.php';
	require_once get_theme_file_path() .'/inc/codestar-framework/codestar-framework.php';
	require get_template_directory() .'/inc/setting.php';
	require_once( dirname(__FILE__).'/extends/category_keywords.php' );


	$options = get_option( 'um_options' ); 

	//后台禁止加载谷歌字体
	function wp_style_del_web( $src, $handle ) {
		if( strpos(strtolower($src),'fonts.googleapis.com') ){
			$src=''; 
		}	
		return $src;
	}
	add_filter( 'style_loader_src', 'wp_style_del_web', 2, 2 );

	//js处理
	function wp_script_del_web( $src, $handle ) {
		$src_low = strtolower($src);
		if( strpos($src_low,'maps.googleapis.com') ){
			return  str_replace('maps.googleapis.com','ditu.google.cn',$src_low);  //google地图
		}	
		if( strpos($src_low,'ajax.googleapis.com') ){
			return  str_replace('ajax.googleapis.com','ajax.useso.com',$src_low);  //google库用360替代
		}
		if( strpos($src_low,'twitter.com') || strpos($src_low,'facebook.com')  || strpos($src_low,'youtube.com') ){
			return '';        //无法访问直接去除
		}	
		return $src;
	}
	add_filter( 'script_loader_src', 'wp_script_del_web', 2, 2 );


	//登录后跳转到首页
	function login_redirect( $redirect_to, $request, $user ){
		global $user;
		if ( isset( $user->roles ) && is_array( $user->roles ) ) {
			//如果登录用户是订阅者 或 投稿者 或 作者 的身份
			if ( in_array( 'subscriber', $user->roles ) || in_array( 'contributor', $user->roles ) || in_array( 'author', $user->roles ) ) {
				return home_url(); //指向首页
			} else {
				return admin_url(); //指向后台管理
			}
		}
		return;;
	}
	add_filter( 'login_redirect', 'login_redirect', 10, 3 );


	// 自定义菜单
	register_nav_menus(
		array(
			'head-nav' => __( '顶部菜单' ),
			'foot-nav' => __( '底部菜单' ),
			'page-nav' => __( '页面菜单' )
		)
	); 

	//去除菜单多余类名
	add_filter('nav_menu_css_class', 'my_css_attributes_filter', 100, 1);
	add_filter('nav_menu_item_id', 'my_css_attributes_filter', 100, 1);
	add_filter('page_css_class', 'my_css_attributes_filter', 100, 1);
	function my_css_attributes_filter($var) {
		return is_array($var) ? array_intersect($var, array('current-menu-item','current-post-ancestor','current-menu-ancestor','current-menu-parent')) : '';
	}

	//开启wordpress友情链接管理
	add_filter( 'pre_option_link_manager_enabled', '__return_true' );

	//wordpress上传文件重命名
	function git_upload_filter($file) {
		$time = date("YmdHis");
		$file['name'] = $time . "" . mt_rand(1, 100) . "." . pathinfo($file['name'], PATHINFO_EXTENSION);
		return $file;
	}
	add_filter('wp_handle_upload_prefilter', 'git_upload_filter');


	//添加特色缩略图支持
	if ( function_exists('add_theme_support') )add_theme_support('post-thumbnails');

	//输出缩略图地址
	function post_thumbnail_src(){
		global $post;
		if( $values = get_post_custom_values("thumb") ) {	//输出自定义域图片地址
			$values = get_post_custom_values("thumb");
			$post_thumbnail_src = $values [0];
		} elseif( has_post_thumbnail() ){    //如果有特色缩略图，则输出缩略图地址
			$thumbnail_src = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
			$post_thumbnail_src = $thumbnail_src [0];
		} else {
			$post_thumbnail_src = '';
			ob_start();
			ob_end_clean();
			$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
			$post_thumbnail_src = $matches [1] [0];   //获取该图片 src
			if(empty($post_thumbnail_src)){	//如果日志中没有图片，则显示随机图片
				$random = mt_rand(1, 10);
				echo get_bloginfo('template_url');
				echo '/static/images/default.jpg';
				//如果日志中没有图片，则显示默认图片
				//echo '/images/default_thumb.jpg';
			}
		};
		echo $post_thumbnail_src;
	}


	//删除文章时删除图片附件 
	function delete_post_and_attachments($post_ID) {
		global $wpdb;
		//删除特色图片
		$thumbnails = $wpdb->get_results( "SELECT * FROM $wpdb->postmeta WHERE meta_key = '_thumbnail_id' AND post_id = $post_ID" );
		foreach ( $thumbnails as $thumbnail ) {
			wp_delete_attachment( $thumbnail->meta_value, true );
		}
		//删除图片附件
		$attachments = $wpdb->get_results( "SELECT * FROM $wpdb->posts WHERE post_parent = $post_ID AND post_type = 'attachment'" );
		foreach ( $attachments as $attachment ) {
			wp_delete_attachment( $attachment->ID, true );
		}
		$wpdb->query( "DELETE FROM $wpdb->postmeta WHERE meta_key = '_thumbnail_id' AND post_id = $post_ID" );
	}
	add_action('before_delete_post', 'delete_post_and_attachments');


	//上下篇缩略图
	function um_pageturn_thumb($id){
		if (has_post_thumbnail($id)) {
			echo get_the_post_thumbnail( $id, '', '' );
			} else {
			$first_img = '';
			ob_start();
			ob_end_clean();
			$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', get_post( $id )->post_content, $matches);
			$first_img = $matches [1] [0];
			if(empty($first_img)){ //Defines a default image
				$random = mt_rand(1, 10);
				$first_img= get_bloginfo ( 'stylesheet_directory' ).'/images/random/'.$random.'.jpg';
			}
			echo '<img class="uk-overlay-scale" src="'.$first_img.'" alt="'.get_post( $post_id )->post_title.'" />';
		}
	}


	//给文章图片自动添加alt和title信息和图片灯箱
	add_filter('the_content', 'imagesalt');
	function imagesalt($content) {
		global $post;
		$group = "{group:'" .$post->ID ."'}";
		$pattern ="/<a(.*?)href=('|\")(.*?).(bmp|gif|jpeg|jpg|png)('|\")(.*?)>/i";
		$replacement = '<a$1href=$2$3.$4$5 data-uk-lightbox="'.$group.'" $6>';
		$content = preg_replace($pattern, $replacement, $content);
		return $content;
	}


	//图片自动添加title$alt
	function image_alt_tag($content){
		global $post;preg_match_all('/<img (.*?)\/>/', $content, $images);
		if(!is_null($images)) {foreach($images[1] as $index => $value)
		{$new_img = str_replace('<img', '<img alt="'.get_the_title().'-'.get_bloginfo('name').'" title="'.get_the_title().'-'.get_bloginfo('name').'"', $images[0][$index]);
		 $content = str_replace($images[0][$index], $new_img, $content);}}
		return $content;
	}
	add_filter('the_content', 'image_alt_tag', 99999);


	//获取文章中的图片数量  echo get_post_images_number().'张图片' 

	if( !function_exists('get_post_images_number') ){  
		function get_post_images_number(){  
			global $post;  
			$content = $post->post_content;    
			preg_match_all('/<img.*?(?: |\\t|\\r|\\n)?src=[\'"]?(.+?)[\'"]?(?:(?: |\\t|\\r|\\n)+.*?)?>/sim', $content, $result, PREG_PATTERN_ORDER);    
			return count($result[1]);    
		}  
	}  


	//文章随机略缩图
	if ( function_exists('add_theme_support') )
		add_theme_support('post-thumbnails');
	function catch_first_image() {
		global $post, $posts;$first_img = '';
		ob_start();
		ob_end_clean();
		$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
		$first_img = $matches [1] [0];
		if(empty($first_img)){
			$random = mt_rand(1, 10);
			echo get_bloginfo ( 'stylesheet_directory' );
			echo '/images/random/'.$random.'.jpg';
		}
		return $first_img;
	}



	//在[媒体库]只显示用户上传的文件
	add_action( 'init', 'check_user_role' );
	function check_user_role() {
		global $current_user;
		if( $current_user->roles[0] != 'administrator' ) {
			//在[媒体库]只显示用户上传的文件
			add_action('pre_get_posts','MBT_restrict_media_library');
			function MBT_restrict_media_library( $wp_query_obj ) {
				global $current_user, $pagenow;
				if( !is_a( $current_user, 'WP_User') )
					return;
				if( 'admin-ajax.php' != $pagenow || $_REQUEST['action'] != 'query-attachments' )
					return;
				if( !current_user_can('manage_media_library') )
					$wp_query_obj->set('author', $current_user->ID );
				return;
			}
		}
	}

	//访问计数
	function record_visitors(){
		if (is_singular()) {
			global $post;
			$post_ID = $post->ID;
			if($post_ID){
				$post_views = (int)get_post_meta($post_ID, 'views', true);
				if(!update_post_meta($post_ID, 'views', ($post_views+1))) 
				{
					add_post_meta($post_ID, 'views', 1, true);
				}
			}
		}
	}
	add_action('wp_head', 'record_visitors');  
	function post_views($before = '(点击 ', $after = ' 次)', $echo = 1)
	{
		global $post;
		$post_ID = $post->ID;
		$views = (int)get_post_meta($post_ID, 'views', true);
		if ($echo) echo $before, number_format($views), $after;
		else return $views;
	};


	//发布时间
	function dopt($e){
		return stripslashes(get_option($e));
	}

	function time_since($older_date, $newer_date = false)
	{
		$chunks = array(
			array(60 * 60 * 24 * 365 , '年'),
			array(60 * 60 * 24 * 30 , '月'),
			array(60 * 60 * 24 * 7, '周'),
			array(60 * 60 * 24 , '天'),
			array(60 * 60 , '小时'),
			array(60 , '分钟'),
		);

		$newer_date = ($newer_date == false) ? (time()+(60*60*get_settings("gmt_offset"))) : $newer_date;
		$since = $newer_date - abs(strtotime($older_date));

		//根据自己的需要调整时间段，下面的24则表示小时，根据需要调整吧
		if($since < 60 * 60 * 24){
			for ($i = 0, $j = count($chunks); $i < $j; $i++)
			{
				$seconds = $chunks[$i][0];
				$name = $chunks[$i][1];

				if (($count = floor($since / $seconds)) != 0)
				{
					break;
				}
			}

			$out = ($count == 1) ? '1 '.$name : "$count {$name}";
			return $out."前";
		}else{
			the_time(get_option('date_format'));
		}
	}


	//自动为文章添加标签
	add_action('save_post', 'auto_add_tags');
	function auto_add_tags(){
		$tags = get_tags( array('hide_empty' => false) );
		$post_id = get_the_ID();
		$post_content = get_post($post_id)->post_content;
		if ($tags) {
			foreach ( $tags as $tag ) {
				// 如果文章内容出现了已使用过的标签，自动添加这些标签
				if ( strpos($post_content, $tag->name) !== false)
					wp_set_post_tags( $post_id, $tag->name, true );
			}
		}
	}


	//面包屑
	function cmp_breadcrumbs() {
		$delimiter = '<i class="iconfont icon-icon-test26"></i>'; // 分隔符
		$before = '<span class="current">'; // 在当前链接前插入
		$after = '</span>'; // 在当前链接后插入
		if ( !is_home() && !is_front_page() || is_paged() ) {
			echo '<div class="crumb">'.__( '<i class="iconfont icon-home-fill"></i>' , 'cmp' );
			global $post;
			$homeLink = home_url();
			echo ' <a itemprop="breadcrumb" href="' . $homeLink . '">' . __( '首页' , 'cmp' ) . '</a> ' . $delimiter . ' ';
			if ( is_category() ) { // 分类 存档
				global $wp_query;
				$cat_obj = $wp_query->get_queried_object();
				$thisCat = $cat_obj->term_id;
				$thisCat = get_category($thisCat);
				$parentCat = get_category($thisCat->parent);
				if ($thisCat->parent != 0){
					$cat_code = get_category_parents($parentCat, TRUE, ' ' . $delimiter . ' ');
					echo $cat_code = str_replace ('<a','<a itemprop="breadcrumb"', $cat_code );
				}
				echo $before . '' . single_cat_title('', false) . '' . $after;
			} elseif ( is_day() ) { // 天 存档
				echo '<a itemprop="breadcrumb" href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' ';
				echo '<a itemprop="breadcrumb"  href="' . get_month_link(get_the_time('Y'),get_the_time('m')) . '">' . get_the_time('F') . '</a> ' . $delimiter . ' ';
				echo $before . get_the_time('d') . $after;
			} elseif ( is_month() ) { // 月 存档
				echo '<a itemprop="breadcrumb" href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' ';
				echo $before . get_the_time('F') . $after;
			} elseif ( is_year() ) { // 年 存档
				echo $before . get_the_time('Y') . $after;
			} elseif ( is_single() && !is_attachment() ) { // 文章
				if ( get_post_type() != 'post' ) { // 自定义文章类型
					$post_type = get_post_type_object(get_post_type());
					$slug = $post_type->rewrite;
					echo '<a itemprop="breadcrumb" href="' . $homeLink . '/' . $slug['slug'] . '/">' . $post_type->labels->singular_name . '</a> ' . $delimiter . ' ';
					echo $before . get_the_title() . $after;
				} else { // 文章 post
					$cat = get_the_category(); $cat = $cat[0];
					$cat_code = get_category_parents($cat, TRUE, ' ' . $delimiter . ' ');
					echo $cat_code = str_replace ('<a','<a itemprop="breadcrumb"', $cat_code );
					echo $before . get_the_title() . $after;
				}
			} elseif ( !is_single() && !is_page() && get_post_type() != 'post' ) {
				$post_type = get_post_type_object(get_post_type());
				echo $before . $post_type->labels->singular_name . $after;
			} elseif ( is_attachment() ) { // 附件
				$parent = get_post($post->post_parent);
				$cat = get_the_category($parent->ID); $cat = $cat[0];
				echo '<a itemprop="breadcrumb" href="' . get_permalink($parent) . '">' . $parent->post_title . '</a> ' . $delimiter . ' ';
				echo $before . get_the_title() . $after;
			} elseif ( is_page() && !$post->post_parent ) { // 页面
				echo $before . get_the_title() . $after;
			} elseif ( is_page() && $post->post_parent ) { // 父级页面
				$parent_id  = $post->post_parent;
				$breadcrumbs = array();
				while ($parent_id) {
					$page = get_page($parent_id);
					$breadcrumbs[] = '<a itemprop="breadcrumb" href="' . get_permalink($page->ID) . '">' . get_the_title($page->ID) . '</a>';
					$parent_id  = $page->post_parent;
				}
				$breadcrumbs = array_reverse($breadcrumbs);
				foreach ($breadcrumbs as $crumb) echo $crumb . ' ' . $delimiter . ' ';
				echo $before . get_the_title() . $after;
			} elseif ( is_search() ) { // 搜索结果
				echo $before ;
				printf( __( '搜索「%s」的结果如下：', 'cmp' ),  get_search_query() );
				echo  $after;
			} elseif ( is_tag() ) { //标签 存档
				echo $before ;
				printf( __( 'Tag Archives: %s', 'cmp' ), single_tag_title( '', false ) );
				echo  $after;
			} elseif ( is_author() ) { // 作者存档
				global $author;
				$userdata = get_userdata($author);
				echo $before ;
				printf( __( 'Author Archives: %s', 'cmp' ),  $userdata->display_name );
				echo  $after;
			} elseif ( is_404() ) { // 404 页面
				echo $before;
				_e( '没有找到', 'cmp' );
				echo  $after;
			}
			if ( get_query_var('paged') ) { // 分页
				if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() )
					echo sprintf( __( '( Page %s )', 'cmp' ), get_query_var('paged') );
			}
			echo '</div>';
		}
	}


	//分页
	function fenye(){
		$args = array(
			'prev_next'          => 0,
			'format'       => '?paged=%#%',
			'before_page_number' => '',
			'mid_size'           => 2,
			'current' => max( 1, get_query_var('paged') ),
			'prev_next'    => True,
			'prev_text'    => __('上一页'),
			'next_text'    => __('下一页'),

		);
		$page_arr=paginate_links($args); 
		if ($page_arr) {
			echo $page_arr;
		}else{
			
		}
	}

	//子分类  
	function get_category_root_id($cat) {  
		$this_category = get_category($cat); // 取得当前分类  
		while($this_category->category_parent) // 若当前分类有上级分类时，循环  
		{  
			$this_category = get_category($this_category->category_parent); // 将当前分类设为上级分类（往上爬  
		}  
		return $this_category->term_id; // 返回根分类的id号  
	}  


	//获取子分类的父分类
	function get_category_cat() { 
		$catID = get_query_var('cat'); // 当前分类ID
		$thisCat = get_category($catID);
		$parentCat = get_category($thisCat->parent);
		// 输出父分类的链接
		echo get_category_link($parentCat->term_id);
	}


	/*当前作者文章浏览总数*/
	if(!function_exists('cx_posts_views')) {
		function cx_posts_views($author_id = 1 ,$display = true) {
			global $wpdb;
			$sql = "SELECT SUM(meta_value+0) FROM $wpdb->posts left join $wpdb->postmeta on ($wpdb->posts.ID = $wpdb->postmeta.post_id) WHERE meta_key = 'views' AND post_author =$author_id";
			$comment_views = intval($wpdb->get_var($sql));
			if($display) {
				echo number_format_i18n($comment_views);
			} else {
				return $comment_views;
			}
		}
	}


	//个人资料添加字段
	add_filter('user_contactmethods', 'boke112_user_contact');
	function boke112_user_contact($user_contactmethods){
		$user_contactmethods['qq'] = 'QQ号';
		$user_contactmethods['weixin'] = '微信';
		$user_contactmethods['bg'] = '用户中心背景图';
		unset( $contactmethods['yim'] );
		unset( $contactmethods['aim'] );
		unset( $contactmethods['jabber'] );
		return $user_contactmethods;
	}


	//禁止用户编辑个人资料的某些字段
	global $pagenow;
	if ( !current_user_can( 'manage_options' ) && $pagenow == 'profile.php' ) {
		add_action( 'admin_footer', 'disable_userprofile_fields' );
	}

	function disable_userprofile_fields() {
	?>
	<script>
		jQuery(document).ready( function($) {
			//禁止编辑“个人说明”（textarea 举例）
			if ( $('input[name=medal]').length ) {
				$('input[name=medal]').attr("readonly", "readonly");
			}
			$('.user-language-wrap').hide();
			$('.user-first-name-wrap').hide();
			$('.user-last-name-wrap').hide();
			$('.show-admin-bar').hide();
			$('.user-comment-shortcuts-wrap').hide();
			$('.user-rich-editing-wrap').hide();

		});
	</script>
	<?php
	}

	//获取用户角色
	//echo get_user_role()
	function get_user_role() {
		$user_id=get_post($id)->post_author;   
		if(user_can($user_id,'administrator')){
			echo'<img src="https://umtu.cn/wp-content/themes/umtu/static/images/medal/img_admin.gif" data-uk-tooltip title="「优美图」管理员！" alt="「优美图」管理员" />';
		}elseif(user_can($user_id,'edit_others_posts')){
			echo'';
		}elseif(user_can($user_id,'author')){
			echo'<img src="https://umtu.cn/wp-content/themes/umtu/static/images/medal/img_edit.gif" data-uk-tooltip title="「优美图」特邀编辑！" alt="「优美图」图片编辑" />';
		}elseif(user_can($user_id,'delete_posts')){
			echo'';
		}elseif(user_can($user_id,'contributor')){
			echo'';
		}
		elseif(user_can($user_id,'subscriber')){
			echo'';
		}
	}

	//WordPress 修改用户角色
	add_action('init', 'fanly_change_role_name');
	function fanly_change_role_name() {
		global $wp_roles;
		if ( ! isset( $wp_roles ) )$wp_roles = new WP_Roles();
		$wp_roles->roles['author']['name'] = '特邀编辑';
		$wp_roles->role_names['author'] = '特邀编辑';
	}

	//WordPress 只允许已登录的用户查看文章内容
	add_shortcode( 'hide', 'hide_shortcode' );
	function hide_shortcode( $atts, $content = null ) 
	{
		if ( is_user_logged_in() && !empty( $content ) && !is_feed() )
		{
			return $content;
		}

		return '<div class="uk-alert uk-margin-large-top uk-alert-warning single-warning uk-text-center" data-uk-alert><a href="" class="uk-alert-close uk-close"></a><p ><a href="/login" class="uk-text-bold">「登录/注册」</a>后查看更多精彩内容！</p></div>';
	}


	// 登录查看按钮
	function appthemes_add_quicktags() {
	?> 
	<script type="text/javascript"> 
		QTags.addButton( 'hide', '隐藏内容', '[hide]', '[/hide]' );
	</script>
	<?php
	}
	add_action('admin_print_footer_scripts', 'appthemes_add_quicktags' );


	//支持中文名注册
	function git_sanitize_user ($username, $raw_username, $strict) {
		$username = wp_strip_all_tags( $raw_username );
		$username = remove_accents( $username );
		$username = preg_replace( '|%([a-fA-F0-9][a-fA-F0-9])|', '', $username );
		$username = preg_replace( '/&.+?;/', '', $username ); // Kill entities
		if ($strict) {
			$username = preg_replace ('|[^a-z\p{Han}0-9 _.\-@]|iu', '', $username);
		}
		$username = trim( $username );
		$username = preg_replace( '|\s+|', ' ', $username );
		return $username;
	}
	add_filter ('sanitize_user', 'git_sanitize_user', 10, 3);
	// 评论添加@，来自：http://www.ludou.org/wordpress-comment-reply-add-at.html
	function git_comment_add_at( $comment_text, $comment = '') {
		if( $comment->comment_parent > 0) {
			$comment_text = '@<a href="#comment-' . $comment->comment_parent . '">'.get_comment_author( $comment->comment_parent ) . '</a> ' . $comment_text;
		}
		return $comment_text;
	}
	add_filter( 'comment_text' , 'git_comment_add_at', 20, 2);


	//使用昵称替换用户名，通过用户ID进行查询
	add_filter( 'request', 'lxtx_wpdaxue_request' );
	function lxtx_wpdaxue_request( $query_vars )
	{
		if ( array_key_exists( 'author_name', $query_vars ) ) {
			global $wpdb;
			$author_id = $wpdb->get_var( $wpdb->prepare( "SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key='nickname' AND meta_value = %s", urldecode( $query_vars['author_name'] ) ) );
			if ( $author_id ) {
				$query_vars['author'] = $author_id;
				unset( $query_vars['author_name'] );
			}
		}
		return $query_vars;
	}


	//使用昵称替换链接中的用户名
	add_filter( 'author_link', 'lxtx_wpdaxue_author_link', 10, 3 );
	function lxtx_wpdaxue_author_link( $link, $author_id, $author_nicename )
	{
		$author_nickname = get_user_meta( $author_id, 'nickname', true );
		if ( $author_nickname ) {
			$link = str_replace( $author_nicename, $author_nickname, $link );
		}
		return $link;
	}


	//WordPress邮箱SMTP配置
	function mail_smtp( $phpmailer ) {
		$phpmailer->FromName = '『收录优美图片』'; //发件人名称
		$phpmailer->Host = 'smtp.qq.com'; //修改为你使用的邮箱SMTP服务器
		$phpmailer->Port = 465; //SMTP端口
		$phpmailer->Username = '450319497@qq.com'; //邮箱账户
		$phpmailer->Password = 'tuartiloyfilbiag'; //邮箱密码（此处填写QQ邮箱生成的授权码）
		$phpmailer->From = '450319497@qq.com'; //邮箱账户
		$phpmailer->SMTPAuth = true;
		$phpmailer->SMTPSecure = 'ssl'; //tls or ssl （port=25时->留空，465时->ssl）
		$phpmailer->IsSMTP();
	}
	add_action('phpmailer_init', 'mail_smtp');


	//自定义评论模板
	if ( ! function_exists( 'janezen_comment' ) ) :
	function janezen_comment( $comment, $args, $depth ) {
		$GLOBALS['comment'] = $comment;
		switch ( $comment->comment_type ) :
		case 'pingback' :
		case 'trackback' :
	?>
	<li <?php comment_class(); ?> id="comment-<?php comment_ID(); ?>">
		<p><?php _e( 'Pingback:', 'janezen' ); ?> <?php comment_author_link(); ?> <?php edit_comment_link( __( '(Edit)', 'janezen' ), '<span class="edit-link">', '</span>' ); ?></p>
		<?php
		break;
		default :
		global $post;
		?>
	<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
		<article id="comment-<?php comment_ID(); ?>" class="">
			<header class="comment-header">
				<?php
					if($comment->user_id!=0){
						$author_posts_url=get_author_posts_url($comment->user_id);
						$author_posts_url='<h5 class="uk-display-block">';
					}else{
						$author_posts_url='</h5>';
					}
					echo get_avatar( $comment, 44 );
					printf( '%1$s %2$s',
						   $author_posts_url.get_comment_author( $commentdata['comment_parent'] ).'</a>',
						   ( $comment->user_id === $post->post_author ) ? '<em class="uk-text-small b-r-4">' . __( '作者', 'janezen' ) . '</em>' : ''
						  );
					printf( '<span class="uk-float-right uk-text-small uk-text-muted"><time datetime="%2$s">%3$s</time></span>',
						   esc_url( get_comment_link( $comment->comment_ID ) ),
						   get_comment_time( 'c' ),
						   /* translators: 1: date, 2: time */
						   sprintf( __( '%1$s at %2$s', 'janezen' ), get_comment_date(), get_comment_time() )
						  );
				?>
			</header>

			<?php if ( '0' == $comment->comment_approved ) : ?>
			<p class="comment-awaiting-moderation"><?php _e( '<span class="uk-text-muted">你的评论正在审核中...<span>', 'janezen' ); ?></p>
			<?php endif; ?>

			<section class="comment-content">
				<?php comment_text(); ?>
				<div class="reply">
					<span class="uk-float-left"><?php comment_reply_link( array_merge( $args, array( 'reply_text' => __( '回复', 'janezen' ), 'after' => '', 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?></span>
					<span class="uk-float-right"><?php edit_comment_link( __( '编辑', 'janezen' ), '<p>', '</p>' ); ?></span>
				</div>
				
			</section>
		</article>
		<?php
		break;
		endswitch; //结束comment_type检查
	}
	endif;
	// 评论模板结束


	//最新评论
	function bg_recent_comments($no_comments = 3, $comment_len = 80, $avatar_size = 24) {
		$comments_query = new WP_Comment_Query();
		$comments = $comments_query->query( array( 'number' => $no_comments ) );
		$comm = '';
		if ( $comments ) : foreach ( $comments as $comment ) :
		$comm .= '<li class="b-b">' . get_avatar( $comment->comment_author_email, $avatar_size );
		$comm .= get_comment_author( $comment->comment_ID ). ' 评论: ';
		$comm .= '<p class="content"><a href="' . esc_url( get_comment_link($comment->comment_ID) ) . '">' . $comment->comment_content . '</a></p></li>';
		endforeach; else :
		$comm .= 'No comments.';
		endif;
		echo $comm;
	}


	// AJAX点赞
	function dotGood()
	{
		global $wpdb, $post;
		$id = $_POST["um_id"];
		if ($_POST["um_action"] == 'topTop') {
			$specs_raters = get_post_meta($id, 'dotGood', true);
			$expire = time() + 99999999;
			$domain = ($_SERVER['HTTP_HOST'] != 'localhost') ? $_SERVER['HTTP_HOST'] : false; // make cookies work with localhost
			setcookie('dotGood_' . $id, $id, $expire, '/', $domain, false);
			if (!$specs_raters || !is_numeric($specs_raters)) update_post_meta($id, 'dotGood', 1);
			else update_post_meta($id, 'dotGood', ($specs_raters + 1));
			echo get_post_meta($id, 'dotGood', true);
		}
		die;
	}

	add_action('wp_ajax_nopriv_dotGood', 'dotGood');
	add_action('wp_ajax_dotGood', 'dotGood');


	//分类描述删除p标签
	function deletehtml($description) {
		$description = trim($description);
		$description = strip_tags($description,'');
	return ($description);
	}
	add_filter('category_description', 'deletehtml');


	//去除分类标志代码
	add_action( 'load-themes.php',  'no_category_base_refresh_rules');
	add_action('created_category', 'no_category_base_refresh_rules');
	add_action('edited_category', 'no_category_base_refresh_rules');
	add_action('delete_category', 'no_category_base_refresh_rules');
	function no_category_base_refresh_rules() {
		global $wp_rewrite;
		$wp_rewrite -> flush_rules();
	}

	add_action('init', 'no_category_base_permastruct');
	function no_category_base_permastruct() {
		global $wp_rewrite, $wp_version;
		if (version_compare($wp_version, '3.4', '<')) {
			// For pre-3.4 support
			$wp_rewrite -> extra_permastructs['category'][0] = '%category%';
		} else {
			$wp_rewrite -> extra_permastructs['category']['struct'] = '%category%';
		}
	}
	add_filter('category_rewrite_rules', 'no_category_base_rewrite_rules');
	function no_category_base_rewrite_rules($category_rewrite) {
		$category_rewrite = array();
		$categories = get_categories(array('hide_empty' => false));
		foreach ($categories as $category) {
			$category_nicename = $category -> slug;
			if ($category -> parent == $category -> cat_ID)// recursive recursion
				$category -> parent = 0;
			elseif ($category -> parent != 0)
				$category_nicename = get_category_parents($category -> parent, false, '/', true) . $category_nicename;
			$category_rewrite['(' . $category_nicename . ')/(?:feed/)?(feed|rdf|rss|rss2|atom)/?$'] = 'index.php?category_name=$matches[1]&feed=$matches[2]';
			$category_rewrite['(' . $category_nicename . ')/page/?([0-9]{1,})/?$'] = 'index.php?category_name=$matches[1]&paged=$matches[2]';
			$category_rewrite['(' . $category_nicename . ')/?$'] = 'index.php?category_name=$matches[1]';
		}
		global $wp_rewrite;
		$old_category_base = get_option('category_base') ? get_option('category_base') : 'category';
		$old_category_base = trim($old_category_base, '/');
		$category_rewrite[$old_category_base . '/(.*)$'] = 'index.php?category_redirect=$matches[1]';
		return $category_rewrite;
	}
	add_filter('query_vars', 'no_category_base_query_vars');
	function no_category_base_query_vars($public_query_vars) {
		$public_query_vars[] = 'category_redirect';
		return $public_query_vars;
	}
	add_filter('request', 'no_category_base_request');
	function no_category_base_request($query_vars) {
		if (isset($query_vars['category_redirect'])) {
			$catlink = trailingslashit(get_option('home')) . user_trailingslashit($query_vars['category_redirect'], 'category');
			status_header(301);
			header("Location: $catlink");
			exit();
		}
		return $query_vars;
	}

	//七牛镜像存储
	if ( !is_admin() ) {
		add_action('wp_loaded','c7sky_ob_start');
		function c7sky_ob_start() {
			ob_start('c7sky_qiniu_cdn_replace');
		}
		function c7sky_qiniu_cdn_replace($html){
			$local_host = 'https://www.umtu.cn'; //你的网站域名  http或是https根据你的站点更换
			$qiniu_host = 'https://img.umtu.cn'; //你的七牛域名  http或是https根据你的站点更换
			$cdn_exts   = 'png|jpg|jpeg|gif'; //扩展名（使用|分隔）
			$cdn_dirs   = 'wp-content|wp-includes'; //目录（使用|分隔）
			$cdn_dirs   = str_replace('-', '\-', $cdn_dirs);
			if ($cdn_dirs) {
				$regex  =  '/' . str_replace('/', '\/', $local_host) . '\/((' . $cdn_dirs . ')\/[^\s\?\\\'\"\;\>\<]{1,}.(' . $cdn_exts . '))([\"\\\'\s\?]{1})/';
				$html =  preg_replace($regex, $qiniu_host . '/$1$4', $html);
			} else {
				$regex  = '/' . str_replace('/', '\/', $local_host) . '\/([^\s\?\\\'\"\;\>\<]{1,}.(' . $cdn_exts . '))([\"\\\'\s\?]{1})/';
				$html =  preg_replace($regex, $qiniu_host . '/$1$3', $html);
			}
			return $html;
		}
	}

	//使子分类的category页面渲染父category页面的模板
	add_filter('category_template', 'f_category_template');
	function f_category_template($template){
		$category = get_queried_object();
		if($category->parent !='0'){
			while($category->parent !='0'){
				$category = get_category($category->parent);
			}
		}

		$templates = array();

		if ( $category ) {
			$templates[] = "category-{$category->slug}.php";
			$templates[] = "category-{$category->term_id}.php";
		}
		$templates[] = 'category.php';
		return locate_template( $templates );
	}

?>
