<?php $options = get_option( 'um_options' );?>
		</main>
			<footer id="footer" class="footer uk-block-secondary uk-overflow-hidden uk-margin-large-top">
				<div class="uk-container uk-container-center">
					<div class="foot uk-grid">
						<?php 
							wp_nav_menu( array(
								'theme_location' => 'foot-nav',//用于在调用导航菜单时指定注册过的某一个导航菜单名，如果没有指定，则显示第一个
								'menu'   => 'foot-nav', //期望显示的菜单
								'container'  => 'nav',  //容器标签
								'container_class' => 'foot-nav uk-overflow-container uk-width-1-1 uk-width-large-1-2',//ul父节点class值
								'menu_id'   => '',  //ul节点id值
								'echo'  => true,//是否输出菜单，默认为真
							) );
						?>
						<div class="foot-social uk-width-1-2 uk-text-right uk-hidden-small">
							<a href="#wx" data-uk-modal>
								<i class="iconfont icon-wechat-fill" ></i>
							</a>
							<i class="iconfont icon-QQ"></i>
							<i class="iconfont icon-weibo"></i>
						</div>
					</div>

					<div class="foot-cop uk-text-center uk-overflow-container">
						<span><?php echo $options['um_foot_beian'];?></span>
						<span><?php echo $options['um_foot_cop'];?></span>
						<span><?php echo $options['um_foot_tj'];?></span>
						
						<?php global $user_ID; if( $user_ID && current_user_can('level_10') ) : ?>
						<span>加载时间：<?php timer_stop(1); ?></span>
						<?php endif; ?>
						
					</div>
				</div>
				<div class="go-top uk-animation-slide-bottom">
					<a id="go-top">
						<i class="iconfont icon-icon-test23"></i>
					</a>
					<a href="#wx" data-uk-modal>
						<i class="iconfont icon-wechat-fill"></i>
					</a>
					<a id="go-bottom">
						<i class="iconfont icon-icon-test25"></i>
					</a>
				</div>
				<!-- gotop -->
				<div id="wx" class="uk-modal">
					<div class="uk-modal-dialog b-r-4">
						<a class="uk-modal-close uk-close"></a>
						<div class="part-title uk-text-center">
							<h3 class="uk-display-inline-block uk-position-relative">关注「收录优美图片」</h3>
							<p class="uk-text-center">
								<img src="<?php echo $options['um_wx']; ?>" alt="扫一扫关注我们">
							</p>
							<p>扫一扫关注我们！</p>
						</div>
					</div>
				</div>
				<!-- 微信弹窗 -->
				<div id="reward" class="uk-modal">
					<div class="uk-modal-dialog b-r-4">
						<a class="uk-modal-close uk-close"></a>
						<div class="part-title uk-text-center">
							<h3 class="uk-display-inline-block uk-position-relative">为优美图做出贡献！</h3>
							<p class="uk-text-center">
								<img src="<?php echo $options['um_ds_wx']; ?>" alt="扫一扫添加微信">
							</p>
						</div>
					</div>
				</div>
				<!-- 打赏弹窗 -->	
				<div id="search" class="uk-modal">
					<div class="uk-modal-dialog b-r-4">
						<a class="uk-modal-close uk-close"></a>
						<div class="part-title uk-text-center">
							<h3 class="uk-display-inline-block uk-position-relative">搜一搜</h3>
						</div>
						<div class="search">
							<form method="get" class="uk-form uk-position-relative" action="<?php bloginfo('url'); ?>">
								<input type="search" placeholder="输入关键词进行搜索…" autocomplete="off" value="" name="s" required="required" class="search-input uk-form-large">
								<button type="submit" class="search-button uk-position-absolute"><i class="iconfont icon-sousuo"></i></button>
							</form>
							<div class="home-seach-hot seach-hot uk-margin-top uk-margin-bottom">
								<strong>热搜: </strong>
								<?php echo $options['um_home_seach']['hot']; ?>
							</div>
						</div>
					</div>
				</div>
				<!-- 搜索弹窗 -->
				<script type="text/javascript" src="<?php bloginfo('template_url');?>/static/js/jquery.min.js"></script>
				
				<script type="text/javascript" src="<?php bloginfo('template_url');?>/static/plugin/swiper/js/swiper.min.js"></script>
				<script type="text/javascript" src="<?php bloginfo('template_url');?>/static/js/uikit.min.js"></script>
				<script type="text/javascript" src="<?php bloginfo('template_url');?>/static/js/components/notify.min.js"></script>
				<script type="text/javascript" src="<?php bloginfo('template_url');?>/static/js/components/grid.min.js"></script>
				<?php if ( is_single() || is_page() ) { ?>
				<script type="text/javascript" src="<?php bloginfo('template_url');?>/static/js/components/lightbox.min.js"></script>
				<?php } ?>	
			
				<script type="text/javascript" src="<?php bloginfo('template_url');?>/static/js/components/tooltip.min.js"></script>
				<script type="text/javascript" src="<?php bloginfo('template_url');?>/static/js/index.js"></script>

			</footer>
		</div>
		<!-- 优美图设计  -->
	</body>

</html>