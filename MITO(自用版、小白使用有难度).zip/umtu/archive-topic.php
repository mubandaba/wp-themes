<?php
/* Template Name:topic */ 
get_header(); 
?>
<div class="topic">
	<div class=" uk-block-default b-t">
		<div class="uk-container uk-container-center">
			<div class="page-top part-title">
				<h3>碎碎念</h3>
				<p>很多自己觉得难以忘记的人或事，总会在不知不觉中淡忘。</p>	
			</div>
		</div>
	</div>
	<div class="uk-container uk-container-center uk-position-relative">
		<?php if(function_exists('cmp_breadcrumbs')) cmp_breadcrumbs();?>
		<div class="uk-grid">
			<div class="uk-width-1-1 uk-width-small-1-1 uk-width-medium-7-10 uk-width-large-7-10 uk-margin-bottom">
				<?php include(TEMPLATEPATH . '/extends/um-topic/page-post.php'); ?>	
				
				<div class="uk-block-default b-r-4">
					<div class="box-title b-b">
						<h3><i class="iconfont icon-shequ"></i> 全部话题</h3>
					</div>	
					<div class="topic-main ajax-ul">

						<?php while (have_posts()) : the_post(); ?>
						<?php $wp_query = new WP_Query('post_type=product&caller_get_posts=1&order=DESC&posts_per_page=10&paged='.$paged); ?>
						<div class="topic-item b-b ajax-li">
							<div class="uk-grid uk-grid-small">
								<div class="uk-width-1-5 uk-width-small-1-5 uk-width-medium-1-10 uk-width-large-1-10">
									<div class="m-avatar">
										<a href="/author/<?php the_author_login(); ?>" class="uk-display-block rotate"><?php echo get_avatar( get_the_author_meta('ID'), '200' );?></a>
									</div>
								</div>
								<div class="uk-width-4-5 uk-width-small-4-5 uk-width-medium-9-10 uk-width-large-9-10">
									<div>
										<div class="author-name uk-margin-bottom"><?php the_author(); ?><em class="uk-display-inline"><?php get_user_role();?></em></div>
										<h3 class="uk-margin-remove"><a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a></h3>
										<span class="topic-tag"><?php the_tags('#', '', '') ?></span>
										<div class="single-data uk-margin-top">
											<span><i class="iconfont icon-rili"></i> <?php echo time_since($post->post_date);?></span>
											<span><i class="iconfont icon-message"></i> <?php echo $post->comment_count; ?></span>	
											<span><i class="iconfont icon-eye"></i> <?php post_views('', ''); ?></span>
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php wp_reset_query(); ?>
						<?php endwhile; ?> 

					</div>
				</div>
				<div class="uk-margin-top">
					<div id="pagination" class="ajax-btn uk-block-default uk-display-block">
						<?php next_posts_link(__('点击查看更多')); ?>
					</div>
				</div>

			</div>
			<div class="uk-width-3-10 uk-hidden-small">
				<?php include(TEMPLATEPATH . '/template-parts/side/cat-side.php'); ?>
			</div>
		</div>
	</div>

<?php get_footer(); ?>
