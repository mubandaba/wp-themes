<?php get_header(); ?>
				<div class="search">
					<div class=" uk-block-default b-t">
						<div class="uk-container uk-container-center">
							<div class="page-top part-title">
								<h3><?php printf( __( ' %s', 'tanhaibonet' ), '<span>' . get_search_query() . '</span>' ); ?></h3>
								<p class="uk-text-muted"><?php printf( __( '搜索「%s」的结果如下：', 'tanhaibonet' ), '<span>' . get_search_query() . '</span>' ); ?></p>
							</div>
						</div>
					</div>

					<div class="uk-container uk-container-center">
						<?php if(function_exists('cmp_breadcrumbs')) cmp_breadcrumbs();?>
						<div class="pic-list uk-grid uk-grid-medium" data-uk-grid >
							<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

							<div class="uk-width-1-1 uk-width-small-1-1 uk-width-medium-1-2 uk-width-large-1-4 uk-margin-bottom">
								<?php include(TEMPLATEPATH . '/template-parts/loop/pic.php');?>
							</div>
							<?php endwhile; else: ?>

						</div>
						<div class="uk-alert uk-alert-warning uk-text-center">抱歉，您搜索的内容暂时没有任何收录！</div>
							<?php endif; ?>
						<div class="fenye">
							<?php fenye(); ?>
						</div>
					</div>
				</div>
<?php get_footer(); ?>



