<?php
/* 
 * Template Name:广告
 */ 
	$options = get_option( 'um_options' );
	$um_list_ad_set = $options['um_ad']['list_ad_set'];
	$um_list_ad_pic = $options['um_ad']['list_ad_pic']['url'];
	$um_list_ad_link = $options['um_ad']['list_ad_pic']['link'];
	$um_article_ad_set = $options['um_ad']['article_ad_set'];
	$um_article_ad_pic = $options['um_ad']['article_ad_pic']['url'];
	$um_article_ad_link = $options['um_ad']['article_ad_pic']['link'];
?>
<div class="uk-block-default b-t">
<div class="uk-container uk-container-center">
<?php
if( is_category() ){
	if ( !$um_list_ad_set ) {?>
<div class="page-top part-title">
<h3><?php single_cat_title(); ?></h3>
	<p><?php echo category_description(); ?></p>
</div>
<?php
	}else {
		echo '<div class="category-zz"><a href="' .$um_list_ad_link. '" target="_blank">';
		echo '<img src="' .$um_list_ad_pic. ' " class="b-r-4"></a></div>';
	}
}elseif ( is_single() ){
	if ( !$um_article_ad_set ) {
?>
<style>.category-ad{display:none}</style>
<?php
	}else {
		echo '<div class="category-zz">';
		echo '<a href="' .$um_article_ad_link. '" target="_blank">';
		echo '<img src="' .$um_article_ad_pic. ' " class="b-r-4"></a>';
		echo '</div>';
	}
}else{}
?>
</div>
</div>