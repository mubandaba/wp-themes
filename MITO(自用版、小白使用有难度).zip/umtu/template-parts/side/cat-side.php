<?php
/* 
 * Template Name:分类侧边栏
 */ 

?>
<div class="box uk-block-default b-r-4 uk-margin-bottom">
	<div class="box-title b-b b-t">
		<h3><i class="iconfont icon-icon-test15"></i> 活跃会员</h3>
	</div>
	<div class="box-main">
		<div class="uk-grid uk-grid-small">
			<div class="uk-width-1-4">
				<a href="/author/umtu" target="_blank" data-uk-tooltip title="优美图"><?php echo get_avatar(1, 50); ?></a>
			</div>
			<div class="uk-width-1-4">
				<a href="/author/nisho" target="_blank" data-uk-tooltip title="述风"><?php echo get_avatar(42, 50); ?></a>
			</div>
			<div class="uk-width-1-4">
				<a href="/author/于故" target="_blank" data-uk-tooltip title="于故"><?php echo get_avatar(40, 50); ?></a>
			</div>
			<div class="uk-width-1-4">
				<a href="/author/迷失" target="_blank" data-uk-tooltip title="迷失"><?php echo get_avatar(22, 50); ?></a>
			</div>
		</div>
	</div>
</div>
<div class="box uk-block-default b-r-4 uk-margin-bottom">
	<div class="box-title b-b b-t">
		<h3><i class="iconfont icon-dingdan"></i> 热门文章</h3>
	</div>
	<div class="box-main">
		<div class="box-list">
			<?php 
			$cat = get_the_category();
			foreach($cat as $key=>$category){
				$catid = $category->term_id;
			}
			$args = array('orderby' => 'rand','showposts' => 15,'cat' => $catid );
			$query_posts = new WP_Query();
			$query_posts->query($args);
			while ($query_posts->have_posts()) : $query_posts->the_post();
			?>
			
			<li class="b-b">
				<a href="<?php the_permalink(); ?>" ><?php the_title(); ?></a>
			</li> 
			<?php endwhile; wp_reset_query(); ?>

		</div>
	</div>
</div>
<div class="box uk-block-default b-r-4 uk-margin-bottom">
	<div class="box-title b-b b-t">
		<h3><i class="iconfont icon-dingdan"></i> 最新评论</h3>
	</div>
	<div class="box-main new-comment">
		<?php bg_recent_comments(); ?>
	</div>
</div>
<div class="box uk-block-default b-r-4 uk-margin-top">
	<div class="box-title b-b b-t">
		<h3><i class="iconfont icon-tags"></i> 热门标签</h3>
	</div>
	<div class="tags-li">
		<?php
		$tags_list = get_tags( array('number' => '18772', 'orderby' => '', 'order' => 'DESC', 'hide_empty' => false) );
		shuffle($tags_list); 
		$count=0; 
		if ($tags_list) {
			foreach($tags_list as $tag) {
				$count++;
				echo '<a title="' . $tag->count . '个话题" href="'.get_tag_link($tag->term_id).'" target="_blank" rel="noopener noreferrer">'.$tag->name.'</a>';
				if( $count >20 ) break;
			}
		}
		?>
	</div>
</div>
