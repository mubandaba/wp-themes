<?php
/* 
 * Template Name:文章侧边栏
 */ 

?>
<?php include(TEMPLATEPATH . '/template-parts/loop/author.php');?>
<div class="box uk-block-default b-r-4 uk-margin-bottom uk-margin-top">
	<div class="box-title b-b b-t">
		<h3><i class="iconfont icon-dingdan"></i> 热门文章</h3>
	</div>
	<div class="box-main">
		<div class="box-list">
			<?php 
			$cat = get_the_category();
			foreach($cat as $key=>$category){
				$catid = $category->term_id;
			}
			$args = array('orderby' => 'rand','showposts' => 10,'cat' => $catid );
			$query_posts = new WP_Query();
			$query_posts->query($args);
			while ($query_posts->have_posts()) : $query_posts->the_post();
			?>
			
			<li class="b-b">
				<a href="<?php the_permalink(); ?>" ><?php the_title(); ?></a>
			</li> 
			<?php endwhile; wp_reset_query(); ?>

		</div>
	</div>
</div>
<div class="box uk-block-default b-r-4 uk-margin-bottom">
	<div class="box-title b-b b-t">
		<h3><i class="iconfont icon-icon-test13"></i> 推荐图集</h3>
	</div>
	<div class="box-main">
		<div class="uk-grid uk-grid-small" data-uk-grid>
			<?php
			$args = array( 'numberposts' => 10, 'orderby' => 'rand', 'post_status' => 'publish');
			$rand_posts = get_posts( $args );
			foreach( $rand_posts as $post ) : 
			?>

			<li class="uk-width-1-2 uk-margin-bottom">
				<a href="<?php the_permalink(); ?>" target="_blank">
					<img class="uk-overlay-scale" src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" data-uk-tooltip title="<?php the_title(); ?>">
				</a>
			</li>
			<?php endforeach; ?>

		</div>
	</div>
</div>
<div class="box uk-block-default b-r-4 uk-margin-bottom">
	<div class="box-title b-b b-t">
		<h3><i class="iconfont icon-tags"></i> 热门标签</h3>
	</div>
	<div class="tags-li">
		<?php
		$tags_list = get_tags( array('number' => '18772', 'orderby' => '', 'order' => 'DESC', 'hide_empty' => false) );
		shuffle($tags_list); 
		$count=0; 
		if ($tags_list) {
			foreach($tags_list as $tag) {
				$count++;
				echo '<a title="' . $tag->count . '个话题" href="'.get_tag_link($tag->term_id).'" target="_blank" rel="noopener noreferrer">'.$tag->name.'</a>';
				if( $count >20 ) break;
			}
		}
		?>
	</div>
</div>
