<?php
/* Template Name:话题 */ 
	$options = get_option( 'um_options' );
?>

<div class="part">
	<div class="part-title uk-text-center">
		<h3>碎碎念</h3>
	</div>
	<div class="topci-container uk-position-relative uk-nbfc">
		<div class="swiper-wrapper">

			<?php
			$args = array(
				'post_type' => 'topic',
				'showposts' => 6,
			);
			$my_query = new WP_Query($args);
			if( $my_query->have_posts() ) {
				while ($my_query->have_posts()) : $my_query->the_post();
			?>

			<div class="swiper-slide uk-margin-bottom">
				<article class="article shadow uk-article uk-block-default uk-margin-bottom uk-nbfc b-r-4">
					<div class="item-info uk-margin-small-left">
						<a href="<?php the_permalink(); ?>" target="_blank">
							<p class="uk-text-muted"><?php 
				if (has_excerpt()) {
					echo $description = get_the_excerpt(); //文章编辑中的摘要
				}else {
					echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 40,"…");
					//文章编辑中若无摘要，自动截取文章内容字数做为摘要，0表示开始的位置，60表示结束的位置
				} 
								?></p>
						</a>
						<div class="data uk-text-small uk-margin-bottom uk-margin-top">
							<span class="uk-margin-right">
								<a href="/author/<?php the_author_login(); ?>" class="rotate uk-display-inline-block uk-border-circle uk-nbfc uk-margin-small-right"><?php echo get_avatar( get_the_author_meta('ID'), '20' );?></a><?php the_author(); ?>
							</span>
							<span class="uk-margin-right"><i class="iconfont icon-rili"></i><?php echo time_since($post->post_date);?></span>
							<span class="uk-margin-right"><i class="iconfont icon-xiaoxi"></i><?php echo $post->comment_count; ?></span>
						</div>
					</div>
				</article>
			</div>
			<?php endwhile; wp_reset_query(); } ?>	

		</div>
	</div>
</div>