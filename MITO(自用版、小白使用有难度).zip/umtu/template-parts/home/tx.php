<?php
/**
 * Template Name: 头像
 */
	$options = get_option( 'um_options' );
	$um_home_tx = $options['um_home_tx'];
	$um_home_tx_cat = $options['um_home_tx']['cat'];
	$um_home_tx_num = $options['um_home_tx']['num'];
?>


<div class="part">
	<div class="part-title">
		<h3><?php echo $um_home_tx['title']; ?></h3>
		<em class="uk-float-right"><a href="<?php echo get_category_link( $um_home_tx_cat ); ?>" target="_blank" >更多<i class="iconfont icon-icon-test26"></i></a></em>
	</div>
	<div class="uk-grid uk-grid-medium" data-uk-grid >
		<?php
		$args = array(
			'cat'=> $um_home_tx_cat,
			'showposts' => $um_home_tx_num,
		);
		$sticky_posts = new WP_Query( $args );
		while ( $sticky_posts->have_posts() ) : $sticky_posts->the_post();
		?>

		<div class="uk-width-1-1 uk-width-small-1-2 uk-width-medium-1-2 uk-width-large-1-4 uk-margin-bottom">
			<?php include(TEMPLATEPATH . '/template-parts/loop/pic.php'); ?>

		</div>
		<?php endwhile; wp_reset_query();?>

	</div>
</div>
