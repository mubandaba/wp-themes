<?php
/**
 * Template Name: 推荐美图
 */
	$options = get_option( 'um_options' );
	$um_home_mt = $options['um_home_mt'];
	$um_home_mt_cat = $options['um_home_mt']['cat'];
	$um_home_mt_num = $options['um_home_mt']['num'];
?>
<div class="part">
	<div class="part-title">
		<h3><?php echo $um_home_mt['title']; ?></h3>
		<em class="uk-float-right"><a href="<?php echo get_category_link( $um_home_mt_cat ); ?>" target="_blank" >更多<i class="iconfont icon-icon-test26"></i></a></em>
	</div>
	<div class="uk-grid uk-grid-medium" data-uk-grid >
		<?php
		$args = array(
			'cat'=> $um_home_mt_cat,
			'showposts' => $um_home_mt_num,
		);
		$sticky_posts = new WP_Query( $args );
		while ( $sticky_posts->have_posts() ) : $sticky_posts->the_post();
		?>

		<div class="uk-width-1-1 uk-width-small-1-2 uk-width-medium-1-2 uk-width-large-1-4 uk-margin-bottom">
			<?php include(TEMPLATEPATH . '/template-parts/loop/pic.php');?>

		</div>
		<?php endwhile; wp_reset_query();?>

	</div>
	<div class="uk-text-center uk-margin-large">
		<a href="/youmei" class="more vary-bg uk-display-inline-block uk-text-contrast b-r-4" target="_blank" >更多美图<i class="iconfont icon-icon-test26 uk-margin-small-left"></i></a>
	</div>
</div>