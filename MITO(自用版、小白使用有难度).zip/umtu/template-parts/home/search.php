<?php
/**
 * Template Name: 搜索
 */
?>
<div class="part home-seach uk-position-relative">
	<div class="bg" style="background: url(<?php echo $options['um_home_seach']['bg']; ?>) 0 -100px fixed;background-size: 100%;"></div>
	<div class="tip uk-position-relative"><?php echo $options['um_home_seach']['title']; ?></div>
	<div class="home-search-form uk-container-center">
		<div class="uk-margin-left uk-margin-right uk-position-relative">
			<form method="get" class="uk-form" action="<?php bloginfo('url'); ?>">
				<input type="search" placeholder="输入关键词，回车..." autocomplete="off" value="" name="s" required="required" class="uk-form-large">
				<button type="submit" class="home-search-button uk-position-absolute"><i class="iconfont icon-sousuo"></i></button>
			</form>
			<div class="home-seach-hot">
				<strong class="uk-text-contrast">热搜: </strong>
				<?php echo $options['um_home_seach']['hot']; ?>
			</div>
		</div>
	</div>	
</div>
