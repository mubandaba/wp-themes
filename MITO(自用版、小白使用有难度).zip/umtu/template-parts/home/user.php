<?php
/**
 * Template Name: 活跃用户
 */
$options = get_option( 'um_options' );
?>

<div class="part">
	<div class="part-title uk-text-center">
		<h3>活跃用户</h3>
	</div>
	<div class="uk-container uk-container-center">
		<div class="uk-grid">
			<div class="uk-width-1-4">
				<div class="author uk-position-relative uk-block-default b-r-4">
					<div class="author-bg uk-overflow-hidden"><?php echo get_avatar( get_the_author_meta('ID'), '200' );?></div>
					<div class="author-avatar l-avatar rotate uk-container-center uk-position-relative">
						<?php echo get_avatar( get_the_author_meta('ID'), '200' );?>
					</div>
					<div class="author-name uk-text-center uk-margin-small-top"><?php the_author(); ?><em class="uk-display-inline-block"><?php get_user_role();?></em></div>
					<div class="author-description uk-text-center uk-text-muted uk-margin-top">
						<?php the_author_description(); ?>
					</div>	
					<div class="author-data uk-container-center">
						<div class="author-data-item uk-text-center uk-text-muted">
							<strong class="uk-panel"><?php the_author_posts(); ?></strong>主题
						</div>
						<div class="author-data-item uk-text-center uk-text-muted">
							<strong class="uk-panel"><?php echo cx_posts_views(get_the_author_meta('ID')); ?></strong>浏览
						</div>
					</div>
				</div>
			</div>
			<div class="uk-width-1-4">
				<div class="author uk-position-relative uk-block-default b-r-4">
					<div class="author-bg uk-overflow-hidden"><?php echo get_avatar( get_the_author_meta('ID'), '200' );?></div>
					<div class="author-avatar l-avatar rotate uk-container-center uk-position-relative">
						<?php echo get_avatar( get_the_author_meta('ID'), '200' );?>
					</div>
					<div class="author-name uk-text-center uk-margin-small-top"><?php the_author(); ?><em class="uk-display-inline-block"><?php get_user_role();?></em></div>
					<div class="author-description uk-text-center uk-text-muted uk-margin-top">
						<?php the_author_description(); ?>
					</div>	
					<div class="author-data uk-container-center">
						<div class="author-data-item uk-text-center uk-text-muted">
							<strong class="uk-panel"><?php the_author_posts(); ?></strong>主题
						</div>
						<div class="author-data-item uk-text-center uk-text-muted">
							<strong class="uk-panel"><?php echo cx_posts_views(get_the_author_meta('ID')); ?></strong>浏览
						</div>
					</div>
				</div>
			</div>
			<div class="uk-width-1-4">
				<div class="author uk-position-relative uk-block-default b-r-4">
					<div class="author-bg uk-overflow-hidden"><?php echo get_avatar( get_the_author_meta('ID'), '200' );?></div>
					<div class="author-avatar l-avatar rotate uk-container-center uk-position-relative">
						<?php echo get_avatar( get_the_author_meta('ID'), '200' );?>
					</div>
					<div class="author-name uk-text-center uk-margin-small-top"><?php the_author(); ?><em class="uk-display-inline-block"><?php get_user_role();?></em></div>
					<div class="author-description uk-text-center uk-text-muted uk-margin-top">
						<?php the_author_description(); ?>
					</div>	
					<div class="author-data uk-container-center">
						<div class="author-data-item uk-text-center uk-text-muted">
							<strong class="uk-panel"><?php the_author_posts(); ?></strong>主题
						</div>
						<div class="author-data-item uk-text-center uk-text-muted">
							<strong class="uk-panel"><?php echo cx_posts_views(get_the_author_meta('ID')); ?></strong>浏览
						</div>
					</div>
				</div>
			</div>
			<div class="uk-width-1-4">
				<div class="author uk-position-relative uk-block-default b-r-4">
					<div class="author-bg uk-overflow-hidden"><?php echo get_avatar( get_the_author_meta('ID'), '200' );?></div>
					<div class="author-avatar l-avatar rotate uk-container-center uk-position-relative">
						<?php echo get_avatar( get_the_author_meta('ID'), '200' );?>
					</div>
					<div class="author-name uk-text-center uk-margin-small-top"><?php the_author(); ?><em class="uk-display-inline-block"><?php get_user_role();?></em></div>
					<div class="author-description uk-text-center uk-text-muted uk-margin-top">
						<?php the_author_description(); ?>
					</div>	
					<div class="author-data uk-container-center">
						<div class="author-data-item uk-text-center uk-text-muted">
							<strong class="uk-panel"><?php the_author_posts(); ?></strong>主题
						</div>
						<div class="author-data-item uk-text-center uk-text-muted">
							<strong class="uk-panel"><?php echo cx_posts_views(get_the_author_meta('ID')); ?></strong>浏览
						</div>
					</div>
				</div>
			</div>
		</div>

	</div>
</div>
