<?php
/* Template Name:文章 */ 
	$options = get_option( 'um_options' );
	$um_home_article = $options['um_home_article'];
	$um_home_article_cat = $options['um_home_article']['cat'];
	$um_home_article_num = $options['um_home_article']['num'];
?>

<div class="part">
	<div class="part-title">
		<h3><?php echo $um_home_article['title']; ?></h3>
		<em class="uk-float-right"><a href="<?php echo get_category_link( $um_home_article_cat ); ?>" target="_blank" >更多<i class="iconfont icon-icon-test26"></i></a></em>
	</div>
	<div class="uk-grid uk-grid-medium" data-uk-grid >
		<?php 
		query_posts(array(
			'showposts' => $um_home_article_num,
			'cat'=> $um_home_article_cat,
		)); 
		while (have_posts()) : the_post();
		?>

		<div class="uk-width-1-1 uk-width-small-1-1 uk-width-medium-1-2 uk-width-large-1-2 uk-margin-bottom">
			<?php include(TEMPLATEPATH . '/template-parts/loop/article.php');?>

		</div>
		<?php endwhile; ?>

	</div>
</div>