<?php
/**
 * Template Name: 音乐
 */
	$options = get_option( 'um_options' );
	$um_home_music = $options['um_home_music'];
	$um_home_music_cat = $options['um_home_music']['cat'];
	$um_home_music_num = $options['um_home_music']['num'];
?>


<div class="part">
	<div class="part-title">
		<h3><?php echo $um_home_music['title']; ?></h3>
		<em class="uk-float-right"><a href="<?php echo get_category_link( $um_home_music_cat ); ?>" target="_blank" >更多<i class="iconfont icon-icon-test26"></i></a></em>
	</div>
	<div class="uk-grid uk-grid-medium" data-uk-grid >
		<?php
		$args = array(
			'cat'=> $um_home_music_cat,
			'showposts' => $um_home_music_num,
		);
		$sticky_posts = new WP_Query( $args );
		while ( $sticky_posts->have_posts() ) : $sticky_posts->the_post();
		?>

		<div class="uk-width-1-1 uk-width-small-1-2 uk-width-medium-1-2 uk-width-large-1-4 uk-margin-bottom">
			<figure class="pic-item shadow uk-block-default uk-margin-bottom uk-nbfc b-r-4">
				<div class="uk-overlay uk-overlay-hover">
					<div class="uk-overlay pic-item-cover uk-overlay-hover" style="max-height:210px">
						<a href="<?php the_permalink(); ?>" target="_blank">
							<img class="uk-overlay-scale" src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>">
						</a>
					</div>
					<div class="item-info uk-margin-left uk-margin-right">
						<div class="author">
							<span class="s-avatar rotate uk-display-block"><a href="/author/<?php the_author_login(); ?>" target="_blank"><?php echo get_avatar( get_the_author_meta('ID'), '200' );?></a></span>
							<span class="uk-text-muted uk-margin-small-left uk-margin-small-top"><?php the_author(); ?></span>
						</div>
						<div class="category uk-margin-small-top">
							<?php the_category(' ') ?>
						</div>	
						<p class="uk-margin-top uk-h4"><a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a></p>
						<div class="data uk-text-small uk-margin-bottom uk-margin-top">
							<span class="uk-margin-right"><i class="iconfont icon-rili"></i><?php echo time_since($post->post_date);?></span>
							<span class="uk-margin-right"><i class="iconfont icon-eye"></i><?php post_views('', ''); ?></span>
							<span class="uk-hidden-small"><i class="iconfont icon-message"></i><?php echo $post->comment_count; ?></span>	
						</div>
					</div>
					</figure>

		</div>
		<?php endwhile; wp_reset_query();?>

	</div>
</div>
