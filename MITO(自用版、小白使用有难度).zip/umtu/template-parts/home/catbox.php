<?php
/**
 * Template Name: 分类滑块
 */
$options = get_option( 'um_options' );
$um_home_cat = $options['um_home_cat'];
?>

<div class="part">
	<div class="part-title uk-text-center">
		<h3><?php echo $options['um_home_cat_title'];?></h3>
	</div>
	<div class="category">
		<div class="category-container uk-position-relative uk-nbfc">
			<div class="swiper-wrapper">
				<?php if ($um_home_cat) { foreach ( $um_home_cat as $key => $value) { ?>
				<div class="swiper-slide">
					<div class="category-item uk-grid uk-grid-collapse b-r-4">
						<div class="category-img-l uk-width-7-10">
							<a href="<?php echo $um_home_cat[$key]['cat']['big_link'];?>" target="_blank" class="uk-position-relative">
								<img src="<?php echo  $um_home_cat[$key]['cat']['big_pic'];?>"/>
								<div class="cover uk-position-absolute">
									<h3><?php echo  $um_home_cat[$key]['cat']['title'];?></h3>
								</div>
							</a>
						</div>
						<div class="uk-width-3-10">
							<div class="category-img-s">
								<a href="<?php echo $um_home_cat[$key]['cat']['small_link']; ?>" target="_blank"><img src="<?php echo  $um_home_cat[$key]['cat']['small_pic'];?>"/></a>
							</div>
							<div class="category-img-s uk-position-relative">
								<img src="<?php echo  $um_home_cat[$key]['cat']['small_more'];?>"/>
								<a href="<?php echo $um_home_cat[$key]['cat']['link'];?>" target="_blank">
									<div class="cover uk-text-contrast uk-position-absolute">更多<i class="iconfont icon-icon-test26"></i></div>
								</a>
							</div>
						</div>
					</div>
				</div>
				<?php } }?>
			</div>
			<div class="category-pagination uk-text-center uk-margin-top"></div>
		</div>
	</div>
</div>