<?php
/**
 * Template Name: 猜你喜欢
 */
	$options = get_option( 'um_options' ); 
	$um_home_like = $options['um_home_like'];
	$um_home_like_cat =$um_home_like['cat'];
	$um_home_like_num =$um_home_like['num'];
?>
<div class="part">
	<div class="part-title uk-text-center">
		<h3><?php echo $um_home_like['title']; ?></h3>
	</div>
	<div class="uk-grid uk-grid-medium" data-uk-grid >
		<?php query_posts('posts_per_page=28&caller_get_posts=1'); ?>
		<?php while (have_posts()) : the_post(); ?>

		<div class="uk-width-1-1 uk-width-small-1-2 uk-width-medium-1-2 uk-width-large-1-4 uk-margin-bottom">
			<?php include(TEMPLATEPATH . '/template-parts/loop/waterfall.php');?>

		</div>
		<?php endwhile; ?> 

	</div>
	<div class="uk-text-center uk-margin-large">
		<a href="/youmei" class="more vary-bg uk-display-inline-block uk-text-contrast b-r-4" target="_blank" >查看更多<i class="iconfont icon-icon-test26 uk-margin-small-left"></i></a>
	</div>
</div>