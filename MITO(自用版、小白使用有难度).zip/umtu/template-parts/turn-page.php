<?php
/**
 * Template Name: 上下篇
 * 
 */
	$options = get_option( 'um_options' );
	$um_pageturn_set = $options['um_pageturn_set'];
?>
<div class="turn-page">
	<?php 
	if( $um_pageturn_set==0 ){
	?>
	<div class="uk-grid">
		<?php
		$categories = get_the_category();
		$categoryIDS = array();
		foreach ($categories as $category) {
			array_push($categoryIDS, $category->term_id);
		}
		$categoryIDS = implode(",", $categoryIDS);
		?>
		<div class="uk-width-1-2">
			<div class="uk-display-inline-block">
				<i class="iconfont icon-icon-test24 uk-margin-right"></i><?php if (get_previous_post($categoryIDS)) { previous_post_link('%link','%title',true);} else { echo "已是最后文章";} ?>
			</div>
		</div>
		<div class="uk-width-1-2 uk-text-right">
			<div class="uk-display-inline-block">
				<?php if (get_next_post($categoryIDS)) { next_post_link('%link','%title',true);} else { echo "已是最新文章";} ?><i class="iconfont icon-icon-test26 uk-margin-left"></i>
			</div>
		</div>
	</div>
	<?php }else { ?>

	<div class="uk-grid">
		<?php
		$current_category = get_the_category();//获取当前文章所属分类ID
		$prev_post = get_previous_post($current_category,'');//与当前文章同分类的上一篇文章
		$next_post = get_next_post($current_category,'');//与当前文章同分类的下一篇文章
		?>
		<div class="uk-width-1-2">
			<figure class="turn-page-thumb uk-overlay uk-overlay-hover b-r-4">
				<?php if (!empty( $prev_post )): ?>
				<?php um_pageturn_thumb($prev_post->ID);?>
				<a href="<?php echo get_permalink( $prev_post->ID ); ?>" >
					<figcaption class="uk-overlay-panel uk-ignore uk-overlay-background">
						<p class="uk-margin-bottom">上一篇</p>
						<i class="iconfont icon-icon-test24"></i><?php echo $prev_post->post_title; ?>
					</figcaption>
				</a>
				<?php endif; ?>
			</figure>
		</div>
		<div class="uk-width-1-2">
			<figure class="turn-page-thumb uk-overlay uk-overlay-hover b-r-4">
				<?php if (!empty( $next_post )): ?>
				<?php um_pageturn_thumb($next_post->ID);?>
				<a href="<?php echo get_permalink( $next_post->ID ); ?>" >
					<figcaption class="uk-overlay-panel uk-ignore uk-overlay-background uk-text-right">
						<p class="uk-margin-bottom">下一篇</p><?php echo $next_post->post_title; ?>
						<i class="iconfont icon-icon-test26"></i>
					</figcaption>
				</a>
				<?php endif; ?>
			</figure>
		</div>
	</div>
	<?php }?>
	
</div>
