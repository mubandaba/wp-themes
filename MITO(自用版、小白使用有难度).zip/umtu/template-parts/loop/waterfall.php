<?php
/* Template Name:瀑布流 */ 
?>

<figure class="pic-item shadow uk-block-default uk-margin-bottom uk-nbfc b-r-4">
	<div class="pic-item-cover uk-overlay uk-overlay-hover">
		<a href="<?php the_permalink(); ?>" target="_blank" class="">
			<img class="uk-overlay-scale" src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>">
		</a>
	</div>
	<div class="item-info uk-margin-left uk-margin-right">
		<div class="author">
			<span class="s-avatar rotate uk-display-block"><a href="/author/<?php the_author_login(); ?>" target="_blank"><?php echo get_avatar( get_the_author_meta('ID'), '200' );?></a></span>
			<span class="uk-text-muted uk-margin-small-left uk-margin-small-top"><?php the_author(); ?></span>
		</div>
		<div class="category uk-margin-small-top">
			<?php the_category(' ') ?>
		</div>	
		<p class="uk-h4"><a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a></p>
		<p class="uk-text-muted uk-nbfc"><?php 
			if (has_excerpt()) {
				echo $description = get_the_excerpt(); //文章编辑中的摘要
			}else {
				echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 60,"…");
				//文章编辑中若无摘要，自动截取文章内容字数做为摘要，0表示开始的位置，170表示结束的位置
			} 
			?></p>
		<div class="data uk-text-small uk-margin-bottom uk-margin-top">
			<span class="uk-margin-right"><i class="iconfont icon-rili"></i><?php echo time_since($post->post_date);?></span>
			<span class="uk-margin-right"><i class="iconfont icon-eye"></i><?php post_views('', ''); ?></span>
			<span class="uk-hidden-small"><i class="iconfont icon-message"></i><?php echo $post->comment_count; ?></span>	
		</div>
	</div>
</figure>