<?php
/* Template Name:作者卡片 */ 
?>

<div class="author uk-position-relative uk-block-default b-r-4">
	<div class="author-bg uk-overflow-hidden"><?php echo get_avatar( get_the_author_meta('ID'), '200' );?></div>
	<div class="author-avatar l-avatar rotate uk-container-center uk-position-relative">
		<a href="/author/<?php the_author_login(); ?>" target="_blank"><?php echo get_avatar( get_the_author_meta('ID'), '200' );?></a>
	</div>
	<div class="author-name uk-text-center uk-margin-small-top"><?php the_author(); ?><em class="uk-display-inline-block"><?php get_user_role();?></em></div>
	<div class="author-description uk-text-center uk-text-muted uk-margin-top">
		<?php the_author_description(); ?>
	</div>	
	<div class="author-data uk-container-center">
		<div class="author-data-item uk-text-center uk-text-muted">
			<strong class="uk-panel"><?php the_author_posts(); ?></strong>主题
		</div>
		<div class="author-data-item uk-text-center uk-text-muted">
			<strong class="uk-panel"><?php echo cx_posts_views(get_the_author_meta('ID')); ?></strong>浏览
		</div>
		<div class="author-data-item uk-text-center uk-text-muted">
			<div class="author-data-item uk-text-center uk-text-muted">
				<strong class="uk-panel"><?php wordpoints_display_points( get_post($id)->post_author , 'yd', '' );?>
				</strong>积分
			</div>
		</div>
	</div>
</div>
<div class="tools uk-block-default">
	<div class="tools-title b-t b-b">
		<i class="iconfont icon-icon-test15"></i> Ta的信息
	</div>
	<div class="author-info">
		<ul class=" uk-list">
			<li class="b-b">UID：<?php the_author_ID(); ?></li>
			<li class="b-b">微信：<?php if ( get_the_author_meta( 'weixin' ) ){echo get_the_author_meta( 'weixin' );}else {echo '暂无';}?></li>
			<li class="b-b">QQ ：<?php if ( get_the_author_meta( 'qq' ) ){echo get_the_author_meta( 'qq' );}else {echo '暂无';}?></li>
			<li class="b-b">站点：<?php if ( get_the_author_url() ){echo the_author_url();}else {echo '暂无';}?></li>
			<li>邮箱：<?php the_author_email(); ?></li>

		</ul>
	</div>
</div>