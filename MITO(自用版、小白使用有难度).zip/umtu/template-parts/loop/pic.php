<?php
/* Template Name:图片 */ 
	$options = get_option( 'um_options' );
?>

<figure class="pic-item shadow uk-block-default uk-margin-bottom uk-nbfc b-r-4">
	<div class="uk-overlay uk-overlay-hover">
		<div class="uk-overlay pic-item-cover uk-overlay-hover">
		<a href="<?php the_permalink(); ?>" target="_blank">
			<img class="uk-overlay-scale" src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>">
		</a>
	</div>
	<div class="item-info uk-margin-left uk-margin-right">
		<div class="author">
			<span class="s-avatar rotate uk-display-block"><a href="/author/<?php the_author_login(); ?>" target="_blank"><?php echo get_avatar( get_the_author_meta('ID'), '200' );?></a></span>
			<span class="uk-text-muted uk-margin-small-left uk-margin-small-top"><?php the_author(); ?></span>
		</div>
		<div class="category uk-margin-small-top">
			<?php the_category(' ') ?>
		</div>	
		<p class="uk-margin-top"><a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a></p>
		<div class="data uk-text-small uk-margin-bottom uk-margin-top">
			<span class="uk-margin-right"><i class="iconfont icon-rili"></i><?php echo time_since($post->post_date);?></span>
		</div>
	</div>
</figure>