<?php
/* Template Name:文章 */ 
?>

<article class="article shadow uk-article uk-block-default uk-margin-bottom uk-nbfc b-r-4">
	<div class="uk-grid uk-grid-medium">
		<div class="uk-width-1-1 uk-width-small-1-1 uk-width-medium-1-1 uk-width-large-2-5">
			<a href="<?php the_permalink(); ?>" target="_blank" class="article-cover uk-display-block uk-position-relative uk-overlay uk-overlay-hover">
				<img class="uk-overlay-scale" src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>">
			</a>
		</div>
		
		<div class="uk-width-1-1 uk-width-small-1-1 uk-width-medium-1-1 uk-width-large-3-5">
			<div class="item-info">
				<p class="uk-h4"><a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a></p>
				<p class="uk-text-muted"><?php 
					if (has_excerpt()) {
						echo $description = get_the_excerpt(); //文章编辑中的摘要
					}else {
						echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 60,"…");
						//文章编辑中若无摘要，自动截取文章内容字数做为摘要，0表示开始的位置，60表示结束的位置
					} 
					?></p>
				<div class="data uk-text-small uk-margin-bottom uk-margin-top">
					<span class="uk-margin-right">
						<a href="/author/<?php the_author_login(); ?>" class="rotate uk-display-inline-block uk-border-circle uk-nbfc uk-margin-small-right"><?php echo get_avatar( get_the_author_meta('ID'), '20' );?></a><?php the_author(); ?>
					</span>
					<span class="uk-margin-right"><i class="iconfont icon-rili"></i><?php echo time_since($post->post_date);?></span>
					<span class="uk-margin-right"><i class="iconfont icon-eye"></i><?php post_views('', ''); ?></span>
				</div>
			</div>
		</div>
	</div>
</article>
