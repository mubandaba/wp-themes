<?php
/**
 * 
 *主题的设置框架
 * .
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package um
 * @subpackage um
 * @since 1.0
 * @version 0.1
 */

?>
<?php if ( ! defined( 'ABSPATH' )  ) { die; } // Cannot access directly.
// 检查核心类是否有错误
if( class_exists( 'CSF' ) ) {

	// 设置一个独特的类似的 ID
	$prefix = 'um_options';

	// 创建选项
	CSF::createOptions( $prefix, array(
		'menu_title' => '主题设置',
		'menu_slug'  => 'um_options',
	) );

	//基础设置
	CSF::createSection( $prefix, array(
		'id'    => 'um_basic',
		'title' => '基本设置',
		'icon'  => 'fa fa-tachometer',
	) );	
	CSF::createSection( $prefix, array(
		'parent'      => 'um_basic',
		'title'  => '页眉',
		'fields' => array(
			array(
				'id'    => 'um_head_logo',
				'type'  => 'upload',
				'title' => '网站Logo',
			),
			array(
				'id'    => 'um_head_favicon',
				'type'  => 'upload',
				'title' => '网站favicon',
			),
			array(
				'id'    => 'um_head_code',
				'type'  => 'textarea',
				'title' => '页头代码',
			),

		)
	) );	
	CSF::createSection( $prefix, array(
		'parent'      => 'um_basic',
		'title'  => '页底',
		'fields' => array(
			array(
				'id'    => 'um_foot_beian',
				'type'  => 'text',
				'title' => '网站备案',
			),
			array(
				'id'    => 'um_foot_cop',
				'type'  => 'textarea',
				'title' => '网站版权',
			),
			array(
				'id'    => 'um_foot_tj',
				'type'  => 'textarea',
				'title' => '网站统计',
			),
			array(
				'id'    => 'um_wx',
				'type'  => 'upload',
				'title' => '个人微信二维码',
				'desc' => '显示位置：网站右下角返回顶部微信小图标',
			),
			array(
				'id'    => 'um_foot_code',
				'type'  => 'textarea',
				'title' => '页底代码',
			),

		)
	) );
	CSF::createSection( $prefix, array(
		'parent'      => 'um_basic',
		'title'  => 'SEO',
		'fields' => array(
			array(
				'id'    => 'um_home_title',
				'type'  => 'text',
				'title' => '网站首页标题',
			),
			array(
				'id'    => 'um_home_keywords',
				'type'  => 'text',
				'title' => '网站首页关键词',
				'after' => '<p>每个关键词之间用英文符号,间隔</p>',
			),
			array(
				'id'    => 'um_home_description',
				'type'  => 'textarea',
				'title' => '网站首页描述',
			),

		)
	) );
	CSF::createSection( $prefix, array(
		'parent'      => 'um_basic',
		'title'  => '其他',
		'fields' => array(
			array(
				'id'    => 'um_icon',
				'type'  => 'icon',
				'title' => 'Icon图标应用',
			),
			array(
				'id'    => 'um_author_bg',
				'type'  => 'upload',
				'title' => '用户中心默认背景图篇',
			),
			array(
				'id'      => 'um_article_cop',
				'type'    => 'textarea',
				'title'   => '文章底部版权提示',
			),
			array(
				'id'    => 'um_reward_set',
				'type'  => 'switcher',
				'title' => '开启/关闭打赏按钮',
			),
			array(
				'id'    => 'um_zan_set',
				'type'  => 'switcher',
				'title' => '开启/关闭点赞按钮',
			),
			array(
				'id'    => 'um_ds_wx',
				'type'  => 'upload',
				'title' => '微信打赏二维码',
			),
			array(
				'id'    => 'um_ds_alipay',
				'type'  => 'upload',
				'title' => '支付宝打赏二维码',
			),
			array(
				'id'    => 'um_comment_set',
				'type'  => 'switcher',
				'title' => '开启/关闭全站评论',
			),
			array(
				'id'    => 'um_pageturn_set',
				'type'  => 'switcher',
				'title' => '开启/关闭文章页上下篇略缩图',
			),
			array(
				'id'    => 'um_homeside_set',
				'type'  => 'switcher',
				'title' => '开启/关闭首页头部侧边栏按钮',
			),
			array(
				'id'    => 'um_homelink_set',
				'type'  => 'switcher',
				'title' => '开启/关闭首页友情链接',
			),
		)
	) );


	//首页布局
	CSF::createSection( $prefix, array(
		'id'    => 'um_home',
		'title' => '首页布局',
		'icon'  => 'fa fa-home',
	) );
	CSF::createSection( $prefix, array(
		'parent' => 'um_home',
		'title'  => '首页搜索模块',
		'icon'   => 'fa fa-list-ol',
		'fields'      => array(
			array(
				'id'     => 'um_home_seach',
				'type'   => 'fieldset',
				'title'  => '首页搜索模块编辑',
				'fields' => array(
					array(
						'id'    => 'um_home_wide_set',
						'type'  => 'switcher',
						'title' => '开启/关闭宽屏模式',
						'label'   => '宽屏模式下网站整体宽度为1440px',
					),
					array(
						'id'    => 'bg',
						'type'  => 'upload',
						'title' => '首页搜索框背景',
					),
					array(
						'id'    => 'title',
						'type'  => 'text',
						'title' => '首页搜索框标题',
					),
					array(
						'id'    => 'hot',
						'type'  => 'textarea',
						'title' => '首页热搜词',
						'subtitle' => '请使用html添加热搜词',
					),
					array(
						'type'    => 'notice',
						'style'   => 'success',
						'content' => '例：《a href="https://umtu.cn/youmei/meitu" target="_blank"》优美图片《/a》，将《》换成<>',
					),
				),
			),
			
		),
	) );
	
	CSF::createSection( $prefix, array(
		'parent'    => 'um_home',
		'title' => '首页分类模块',
		'icon'  => 'fa fa-list-ol',
		'fields' => array(
			array(
				'id'    => 'um_home_cat_title',
				'type'  => 'text',
				'title' => '首页分类模块标题',
			),
			array(
				'id'     => 'um_home_cat',
				'type'   => 'repeater',
				'title'  => '首页分类模块编辑',
				'fields' => array(
					array(
						'id'            => 'cat',
						'type'          => 'accordion',
						'title'         => '分类滑块',
						'accordions'    => array(
							array(
								'title'     => '分类滑块',
								'fields'    => array(
									array(
										'id'    => 'title',
										'type'  => 'text',
										'title' => '分类名称',
									),
									array(
										'id'    => 'big_pic',
										'type'  => 'upload',
										'title' => '分类大图',
									),
									array(
										'id'    => 'big_link',
										'type'  => 'text',
										'title' => '分类小图文章链接',
									),
									array(
										'id'    => 'small_pic',
										'type'  => 'upload',
										'title' => '分类小图',
									),
									array(
										'id'    => 'small_link',
										'type'  => 'text',
										'title' => '分类小图文章链接',
									),
									array(
										'id'    => 'small_more',
										'type'  => 'upload',
										'title' => '更多背景图',
									),
									array(
										'id'    => 'link',
										'type'  => 'text',
										'title' => '更多链接',
									),
								)
							),
						),
					),
				),
			),

		)
	) );
	
	CSF::createSection( $prefix, array(
		'parent' => 'um_home',
		'title'  => '首页头像模块',
		'icon'   => 'fa fa-list-ol',
		'fields'      => array(
			array(
				'id'     => 'um_home_tx',
				'type'   => 'fieldset',
				'title'  => '首页头像模块编辑',
				'fields' => array(
					array(
						'id'    => 'title',
						'type'  => 'text',
						'title' => '标题',
					),
					array(
						'id'    => 'cat',
						'type'  => 'text',
						'title' => '分类选择',
						'desc' => '-id为排除某分类，id为显示哪些分类，多选为id,id',
					),
					array(
						'id'    => 'num',
						'type'  => 'text',
						'title' => '获取文章数量',
					),
				),
			),

		),
	) );
	
	CSF::createSection( $prefix, array(
		'parent' => 'um_home',
		'title'  => '首页美图模块',
		'icon'   => 'fa fa-list-ol',
		'fields'      => array(
			array(
				'id'     => 'um_home_mt',
				'type'   => 'fieldset',
				'title'  => '首页美图模块编辑',
				'fields' => array(
					array(
						'id'    => 'title',
						'type'  => 'text',
						'title' => '标题',
					),
					array(
						'id'    => 'cat',
						'type'  => 'text',
						'title' => '分类选择',
						'desc' => '-id为排除某分类，id为显示哪些分类，多选为id,id',
					),
					array(
						'id'    => 'num',
						'type'  => 'text',
						'title' => '获取文章数量',
					),
				),
			),

		),
	) );
	
	CSF::createSection( $prefix, array(
		'parent' => 'um_home',
		'title'  => '首页文章模块',
		'icon'   => 'fa fa-list-ol',
		'fields'      => array(
			array(
				'id'     => 'um_home_article',
				'type'   => 'fieldset',
				'title'  => '首页文章模块编辑',
				'fields' => array(
					array(
						'id'    => 'title',
						'type'  => 'text',
						'title' => '标题',
					),
					array(
						'id'    => 'cat',
						'type'  => 'text',
						'title' => '分类选择',
						'desc' => '-id为排除某分类，id为显示哪些分类，多选为id,id',
					),
					array(
						'id'    => 'num',
						'type'  => 'text',
						'title' => '获取文章数量',
					),
				),
			),

		),
	) );

	CSF::createSection( $prefix, array(
		'parent' => 'um_home',
		'title'  => '首页音乐模块',
		'icon'   => 'fa fa-list-ol',
		'fields'      => array(
			array(
				'id'     => 'um_home_music',
				'type'   => 'fieldset',
				'title'  => '首页音乐模块编辑',
				'fields' => array(
					array(
						'id'    => 'title',
						'type'  => 'text',
						'title' => '标题',
					),
					array(
						'id'    => 'cat',
						'type'  => 'text',
						'title' => '分类选择',
						'desc' => '-id为排除某分类，id为显示哪些分类，多选为id,id',
					),
					array(
						'id'    => 'num',
						'type'  => 'text',
						'title' => '获取文章数量',
					),
				),
			),

		),
	) );
	
	CSF::createSection( $prefix, array(
		'parent' => 'um_home',
		'title'  => '猜你喜欢模块',
		'icon'   => 'fa fa-list-ol',
		'fields'      => array(
			array(
				'id'     => 'um_home_like',
				'type'   => 'fieldset',
				'title'  => '首页猜你喜欢',
				'fields' => array(
					array(
						'id'    => 'title',
						'type'  => 'text',
						'title' => '标题',
					),
					array(
						'id'    => 'cat',
						'type'  => 'text',
						'title' => '分类选择',
						'desc' => '-id为排除某分类，id为显示哪些分类，多选为id,id',
					),
					array(
						'id'    => 'num',
						'type'  => 'text',
						'title' => '获取数量',
					),
				),
			),

		),
	) );

	
	// 广告设置
	CSF::createSection( $prefix, array(
		'title'  => '广告设置',
		'icon'   => 'fa fa-flag',
		'fields' => array(
			array(
				'id'            => 'um_ad',//手风琴1
				'type'          => 'accordion',
				'title'         => 'Accordion',
				'accordions'    => array(
					array(
						'title'     => '列表页广告',
						'icon'      => 'fa fa-heart',
						'fields'    => array(
							array(
								'id'    => 'list_ad_set',
								'type'  => 'switcher',
								'title' => '开启/关闭广告',
							),
							array(
								'id'    => 'list_ad_pic',
								'type'  => 'media',
								'title' => '选择一张图片',
								'url'   => true,
							),
							array(
								'id'    => 'list_ad_link',
								'type'  => 'text',
								'title' => '广告链接',
							),
						)
					),
					array(
						'title'     => '文章页广告',//手风琴2
						'icon'      => 'fa fa-gear',
						'fields'    => array(
							array(
								'id'    => 'article_ad_set',
								'type'  => 'switcher',
								'title' => '开启/关闭广告',
							),
							array(
								'id'    => 'article_ad_pic',
								'type'  => 'media',
								'title' => '选择一张图片',
								'url'   => true,
							),
							array(
								'id'    => 'article_ad_link',
								'type'  => 'text',
								'title' => '广告链接',
							),
						)
					),
				)
			),
		)
	));

	// 其它
	CSF::createSection( $prefix, array(
		'title'       => '其它',
		'icon'        => 'fa fa-bolt',
		'description' => 'Visit documentation for more details: <a href="http://codestarframework.com/documentation/#/fields?id=others" target="_blank">Others</a>',
		'fields'      => array(

			array(
				'type'    => 'content',
				'content' => '

			<h2>我们使用的开源项目：</h2>
			<table>
				<tr>
					<td>_s:(主题框架)</td>
					<td>https://github.com/automattic/_s</td>
				</tr>
				<tr>
					<td>Codestar Framework（后台设置框架）</td>
					<td>http://codestarframework.com/</td>
				</tr>
			</table>


			',

			),



		)
	) );



}
