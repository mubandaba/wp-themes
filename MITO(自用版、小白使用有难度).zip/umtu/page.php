<?php get_header(); ?>
<div class="page">
	<div class="uk-block-default b-t">
		<div class="uk-container uk-container-center">
			<div class="page-top part-title">
				<h3><?php the_title(); ?></h3>
			</div>
		</div>
	</div>
	<div class="uk-container uk-container-center">
		<?php if(function_exists('cmp_breadcrumbs')) cmp_breadcrumbs();?>
		<div class="uk-block-default b-r-4">
			<?php while ( have_posts() ) : the_post(); ?>

			<div class="single-content">
				<?php the_content(); ?>
			</div>
			<?php endwhile; ?>

		</div>

	</div>
	<div class="uk-container uk-container-center uk-margin-large-top">
		<?php comments_template( '', true ); ?>
	</div>
</div>

<?php get_footer(); ?>