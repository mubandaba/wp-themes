<?php
/*
Template Name: 标签云
*/
get_header();?>

				<div class="tags">
					<div class="uk-block-default b-t">
						<div class="uk-container uk-container-center">
							<div class="page-top part-title">
								<h3><?php the_title(); ?></h3>
							</div>
						</div>
					</div>
					<div class="uk-container uk-container-center">
						<?php if(function_exists('cmp_breadcrumbs')) cmp_breadcrumbs();?>
						<div class="uk-grid" data-uk-grid>
							<?php 
							$tags_list = get_tags('orderby=count&order=DESC&number=44');
							if($tags_list) { 
								foreach($tags_list as $tag) {
									echo '<div class="uk-width-1-1 uk-width-small-1-2 uk-width-medium-1-2 uk-width-large-1-4 uk-margin-bottom"><div class="tags-item uk-block-default b-a b-r-4 shadow"><div class="uk-margin-bottom b-b"><a class="name uk-margin-bottom uk-display-inline-block uk-position-relative" href="'.get_tag_link($tag).'">'. $tag->name .'</a><small class="uk-text-muted">x '. $tag->count .'</small></div>'; 
									$posts = get_posts( "tag_id=". $tag->term_id ."&numberposts=5" );
									if( $posts ){
										foreach( $posts as $post ) {
											setup_postdata( $post );
											echo '<li><a href="'.get_permalink().'">';
											echo the_title();	
											echo '</a></li>';
										}
									}
									echo '</div></div>';
								} 
							} 
							?>
						</div>
					</div>
				</div>

<?php get_footer();?>