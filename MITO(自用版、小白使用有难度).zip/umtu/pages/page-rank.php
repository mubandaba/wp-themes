<?php
/* 
 *Template Name:排行榜
 */
get_header(); 
?>
<div class="uk-block-default b-t">
	<div class="uk-container uk-container-center">
		<div class="page-top part-title">
			<h3><?php the_title(); ?></h3>
		</div>
	</div>
</div>
<div class="uk-container uk-container-center uk-margin-large-top">
	<div class="rank uk-grid">
		<ul data-uk-switcher="{connect:'#rank'}" class="page-menu uk-width-2-10">
			<li class="b-a uk-block-default">
				<span>积分排行</span>
			</li>
			<li class="b-a uk-block-default">
				<span>主题排行</span>
			</li>
			<li class="b-a uk-block-default">
				<span>浏览排行</span>
			</li>
			<li class="b-a uk-block-default">
				<span>点赞排行</span>
			</li>
			<li class="b-a uk-block-default">
				<span>评论排行</span>
			</li>
		</ul>
		<ul id="rank" class="uk-switcher uk-block-default uk-width-8-10">
			<li>
				<div class="rank-point b-b">登上榜单，让您成为众多网友关注的焦点！</div>
				<?php while ( have_posts() ) : the_post(); ?>
				<div class="page-main page">
					<?php the_content(); ?>
				</div>
				<?php endwhile; ?>
			</li>	
			<li>
				<div class="rank-point b-b">登上榜单，让您成为众多网友关注的焦点！</div>
				<div class="page-main">
<!-- 
					<?php
					$rankusers = get_users( 
						array( 
							'fields' => array( 'display_name','user_email','ID' ),
							'orderby' => 'post_count',
							'order ' => 'DESC'
						) 
					);
					foreach ( $rankusers as $user ) {
						echo $user->display_name;
						$user_id = $user->user_email;
						echo get_avatar($user_id, 50);
					}
					?>
-->

					<div class="uk-grid uk-grid-medium">
						<div class="uk-width-1-3 uk-margin-bottom">
							<div class="rank-user b-a uk-clearfix">
								<a href="/author/优美图" target="_blank" class="m-avatar rotate uk-float-left"><?php echo get_avatar(1, 50); ?></a>
								<div class="rank-user-info uk-float-left">
									<h4>优美图</h4>
									<p class="uk-text-muted"><?php echo count_user_posts('1', 'post', false);?>主题</p>
								</div>
							</div>
						</div>
						<div class="uk-width-1-3 uk-margin-bottom">
							<div class="rank-user b-a uk-clearfix">
								<a href="/author/nisho" target="_blank" class="m-avatar rotate uk-float-left"><?php echo get_avatar(42, 50); ?></a>
								<div class="rank-user-info uk-float-left">
									<h4>珀尔修斯</h4>
									<p class="uk-text-muted"><?php echo count_user_posts('42', 'post', false);?>主题</p>
								</div>
							</div>
						</div>
						<div class="uk-width-1-3 uk-margin-bottom">
							<div class="rank-user b-a uk-clearfix">
								<a href="/author/情归酒肆" target="_blank" class="m-avatar rotate uk-float-left"><?php echo get_avatar(20, 50); ?></a>
								<div class="rank-user-info uk-float-left">
									<h4>情归酒肆</h4>
									<p class="uk-text-muted"><?php echo count_user_posts('20', 'post', false);?>主题</p>
								</div>
							</div>
						</div>
						<div class="uk-width-1-3 uk-margin-bottom">
							<div class="rank-user b-a uk-clearfix">
								<a href="/author/等风也等你" target="_blank" class="m-avatar rotate uk-float-left"><img src="https://img.umtu.cn/wp-content/uploads/2019/10/2019102109332251-200x200.jpg" /></a>
								<div class="rank-user-info uk-float-left">
									<h4>等风也等你</h4>
									<p class="uk-text-muted"><?php echo count_user_posts('2', 'post', false);?>主题</p>
								</div>
							</div>
						</div>
						<div class="uk-width-1-3 uk-margin-bottom">
							<div class="rank-user b-a uk-clearfix">
								<a href="/author/于故" target="_blank" class="m-avatar rotate uk-float-left"><?php echo get_avatar(40, 50); ?></a>
								<div class="rank-user-info uk-float-left">
									<h4>于故</h4>
									<p class="uk-text-muted"><?php echo count_user_posts('40', 'post', false);?>主题</p>
								</div>
							</div>
						</div>
						<div class="uk-width-1-3 uk-margin-bottom">
							<div class="rank-user b-a uk-clearfix">
								<a href="/author/迷失" target="_blank" class="m-avatar rotate uk-float-left"><?php echo get_avatar(22, 50); ?></a>
								<div class="rank-user-info uk-float-left">
									<h4><a href="/author/迷失" class="author-name">迷失</a></h4>
									<p class="uk-text-muted"><?php echo count_user_posts('22', 'post', false);?>主题</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</li>
			<li>
				<div class="rank-point b-b">登上榜单，让您成为众多网友关注的焦点！</div>
				<div class="page-main">
					<div class="rank-li">
						<ul>
							<?php 
							$args=array(
								'ignore_sticky_posts' => 1,
								'meta_key' => 'views',
								'orderby' => 'meta_value_num',
								'showposts' => 20
							);
							query_posts($args);
							if ( have_posts() ) : ?>
							<?php 
							while ( have_posts() ) : the_post();
							?>
							<li>
								<div class="rank-item b-b">
								<a href="<?php the_permalink(); ?>" target="_blank"><?php echo mb_strimwidth(get_the_title(), 0, 46,'…'); ?></a>
									<div class="uk-grid">
										<span class="uk-text-muted uk-width-1-3">
											<a href="/author/<?php the_author_login(); ?>" target="_blank" class="ss-avatar rotate uk-display-inline-block"><?php echo get_avatar( get_the_author_meta('ID'), '24' );?></a>
											<?php the_author(); ?>
										</span>
										<em class="uk-width-1-3 uk-text-muted"><i class="iconfont icon-eye"></i><?php post_views('', ''); ?></em>
									</div>
								</div>
							</li>
							<?php endwhile; endif;?>
						</ul>

					</div>
				</div>
			</li>
			<li>
				<div class="rank-point b-b">登上榜单，让您成为众多网友关注的焦点！</div>
				<div class="page-main">
					<div class="rank-li">
						<ul>
							<?php
							$args = array(
								'ignore_sticky_posts' => 1,
								'meta_key' => 'dotGood',
								'orderby' => 'meta_value_num',
								'showposts' => 20
							);	
							query_posts($args);
							if ( have_posts() ) : ?>
							<?php 
							while ( have_posts() ) : the_post();
							?>
							<li>
								<div class="rank-item b-b">
									<a href="<?php the_permalink(); ?>" target="_blank"><?php echo mb_strimwidth(get_the_title(), 0, 46,'…'); ?></a>
									<div class="uk-grid">
										<span class="uk-width-1-3 uk-text-muted">
											<a href="/author/<?php the_author_login(); ?>" target="_blank" class="ss-avatar rotate uk-display-inline-block"><?php echo get_avatar( get_the_author_meta('ID'), '24' );?></a>
											<?php the_author(); ?>
										</span>
										<em class="uk-width-1-3 uk-text-muted"><i class="iconfont icon-like"></i><?php echo ($dot_good=get_post_meta($post->ID, 'dotGood', true)) ? $dot_good : '0'; ?></em>
									</div>
								</div>
							</li>
							<?php endwhile; endif;?>

						</ul>
					</div>
				</div>
			</li>
			<li>
				<div class="rank-point b-b">登上榜单，让您成为众多网友关注的焦点！</div>
				<div class="page-main">
					<div class="rank-li">
						<ul>
							<?php
							$popular = new WP_Query( array(
								'post_type'             => array( 'post' ),
								'showposts'             => 20,
								'cat'                   => 'MyCategory',
								'ignore_sticky_posts'   => true,
								'orderby'               => 'comment_count', //–这个意思就是 取得评论数最多的文章
								'order'                 => 'dsc',
								'date_query' => array(
									array(
										'after' => '30 week ago', //近期一周的，这个是本文档的重点
									),
								),
							) );
							?>
							<?php while ( $popular->have_posts() ): $popular->the_post(); ?>
							<li>
								<div class="rank-item b-b">
									<a href="<?php the_permalink(); ?>" target="_blank"><?php echo mb_strimwidth(get_the_title(), 0, 46,'…'); ?></a>
									<div class="uk-grid">
										<span class="uk-width-1-3 uk-text-muted">
											<a href="/author/<?php the_author_login(); ?>" target="_blank" class="ss-avatar rotate uk-display-inline-block"><?php echo get_avatar( get_the_author_meta('ID'), '24' );?></a>
											<?php the_author(); ?>
										</span>
										<em class="uk-width-1-3 uk-text-muted"><i class="iconfont icon-message"></i><?php echo $post->comment_count; ?></em>
									</div>
								</div>
							</li>
							<?php endwhile; ?>

						</ul>
					</div>
				</div>
			</li>	
		</ul>
	</div>
</div>

<?php get_footer(); ?>