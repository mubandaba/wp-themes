<?php
/* 
 *Template Name:关于我们
 */
get_header(); 
?>
<div class="uk-block-default b-t">
	<div class="uk-container uk-container-center">
		<div class="page-top part-title">
			<h3>关于优美图</h3>
		</div>
	</div>
</div>
<div class="uk-container uk-container-center uk-margin-large-top">
	<div class="page about uk-grid uk-grid-collapse">
			<?php 
			wp_nav_menu( array(
				'theme_location' => 'page-nav',//用于在调用导航菜单时指定注册过的某一个导航菜单名，如果没有指定，则显示第一个
				'container'  => 'nav',  //容器标签
				'container_class' => 'uk-width-2-10',//ul父节点class值
				'menu_class'   => 'page-menu b-a uk-block-default uk-padding-remove',
				'echo'  => true,//是否输出菜单，默认为真
			) );
			?>
		<div class="uk-width-8-10">
			<div class="page-main uk-block-default uk-margin-bottom">
				<?php while ( have_posts() ) : the_post(); ?>
				<?php the_content(); ?>
				<?php endwhile; ?>
			</div>	
			<?php if (comments_open()) comments_template( '', true ); ?>
		</div>
	</div>
</div>

<?php get_footer(); ?>