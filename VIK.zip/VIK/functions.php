<?php
include ('inc/functions/xyz-install.php');
if($xyz_status) {
# 支持自定义功能
# ------------------------------------------------------------------------------
add_theme_support( 'customize-selective-refresh-widgets' );

# 清除wp所有自带的customize选项
# ------------------------------------------------------------------------------
    function remove_default_settings_customize( $wp_customize ) {
        $wp_customize->remove_section( 'title_tagline');
        $wp_customize->remove_section( 'colors');
        $wp_customize->remove_section( 'header_image');
        $wp_customize->remove_section( 'background_image');
        $wp_customize->remove_panel( 'nav_menus');
        $wp_customize->remove_section( 'static_front_page');
        $wp_customize->remove_section( 'custom_css');
        $wp_customize->remove_panel( 'widgets' );
    }
    add_action( 'customize_register', 'remove_default_settings_customize',50 );
# 引用功能
# ------------------------------------------------------------------------------
    require_once(dirname(__FILE__) . '/inc/functions/enqueue.php');
    require_once(dirname(__FILE__) . '/inc/functions/menu.php');
    require_once(dirname(__FILE__) . '/inc/functions/meta_framework.php');
    require_once(dirname(__FILE__) . '/inc/functions/customize_framework.php');
    require_once(dirname(__FILE__) . '/inc/functions/sidemenu_walker.php');
    require_once(dirname(__FILE__) . '/inc/functions/pagination.php');
    require_once(dirname(__FILE__) . '/inc/functions/seo.php');
    require_once(dirname(__FILE__) . '/inc/functions/site_colums.php');
    require_once(dirname(__FILE__) . '/inc/functions/wx_colums.php');
    require_once(dirname(__FILE__) . '/inc/post_type/site.php');
    require_once(dirname(__FILE__) . '/inc/post_type/wx.php');

# 支持特色图像并添加自定义裁剪尺寸
# ------------------------------------------------------------------------------
    add_theme_support('post-thumbnails');
    add_image_size('post_thumb', '248', '155', true);
    add_image_size('site_thumb', '80', '80', true);
    add_image_size('site_single', '200', '200', true);
# 自定义名称
# ------------------------------------------------------------------------------
    function xyz_archive_title($title)
    {
        if (is_category()) {
            $title = single_cat_title('', false);
        } elseif (is_tag()) {
            $title = single_tag_title('', false);
        } elseif (is_author()) {
            $title = '<span class="vcard">' . get_the_author() . '</span>';
        } elseif (is_post_type_archive()) {
            $title = post_type_archive_title('', false);
        } elseif (is_tax()) {
            $title = single_term_title('', false);
        }
        return $title;
    }

    add_filter('get_the_archive_title', 'xyz_archive_title');
# 输出图片
# ------------------------------------------------------------------------------
    function xyz_src($img_id = '', $size = '',$default='')
    {
        if ($img_id) {
            $img_src = wp_get_attachment_image_src($img_id, $size);
            echo 'src="' . $img_src[0] . '"';
        } elseif($default) {
            echo 'src="' . $default . '"';
        }else {
            echo 'src="' . get_template_directory_uri() . '/static/images/noimg.png"';
        }
    }

    xyz_theme_upgrader();

    if (!function_exists('xyz_img')) {
        function xyz_img($option = '', $default = '')
        {
            $options = get_option('vik_customize'); // Attention: Set your unique id of the framework
            return ( isset( $options[$option] ) ) ? $options[$option]['url'] : $default;
        }
    }

    function joy_add_page($title, $slug, $page_template = '')
    {
        $allPages = get_pages();
        $exists = false;
        foreach ($allPages as $page) {
            if (strtolower($page->post_name) == strtolower($slug)) {
                $exists = true;
            }
        }
        if ($exists == false) {
            $new_page_id = wp_insert_post(
                array(
                    'post_title' => $title,
                    'post_type' => 'page',
                    'post_name' => $slug,
                    'comment_status' => 'closed',
                    'ping_status' => 'closed',
                    'post_content' => '',
                    'post_status' => 'publish',
                    'post_author' => 1,
                    'menu_order' => 0
                )
            );
            if ($new_page_id && $page_template != '') {
                update_post_meta($new_page_id, '_wp_page_template', $page_template);
            }
        }
    }

    function joy_add_pages()
    {
        global $pagenow;
        if ('themes.php' == $pagenow && isset($_GET['activated'])) {
            joy_add_page('跳转页面--VIK主题创建的页面不要删除也不要做任何更改', 'go', 'page-go.php');
        }
    }
    add_action('load-themes.php', 'joy_add_pages');

# 获取
# ------------------------------------------------------------------------------
    function get_page_url($slug, $type="page"){
        global $wpdb;
        if ($type == "page") {
            $url_id = $wpdb->get_var("SELECT ID FROM $wpdb->posts WHERE post_name = '".$slug."'");
            echo get_permalink($url_id);
        }else{
            $url_id = $wpdb->get_var("SELECT term_id FROM $wpdb->terms WHERE slug = '".$slug."'");
            echo get_category_link($url_id);
        }
    }
}