<!--Music-->
<div class="h5 mb-3 mb-lg-4">
    <div class="d-flex flex-fill algin-items-center">
        <div class="flex-fill">最爱欢迎单曲</div>
        <div class="font-theme">
            <a class="font-theme text-muted text-xs" href="#">more+</a>
        </div>
    </div>
</div>
<div class="divider my-4"></div>
<div class="row mb-3">
    <?php
        $posts = get_posts("numberposts=20&post_type=music"); if($posts) : foreach( $posts as $post ) : setup_postdata( $post );
        $music_id = get_the_ID();
        $music_author = get_post_meta($music_id,'music_author',true);
        $music_img_url = get_post_meta($music_id,'music_img',true)['url'];
    ?>
<!--    <div class="col-xxl-10 col-xl-2 col-sm-3 col-6 mb-3">-->
<!--        <div class="card card-transparent card-box-hover-rise-alt">-->
<!--            <a href="--><?php //the_permalink();?><!--" class="card-img-wrapper rounded" data-toggle="modal" data-target="#music_--><?php //echo $music_id?><!--">-->
<!--                <div class="img-wrapper-overlay">-->
<!--                    <div class="overlay-btn-wrapper">-->
<!--                        <i class="fa fa-music" aria-hidden="true"></i>-->
<!--                    </div>-->
<!--                </div>-->
<!--                <img src="--><?php //echo $music_img_url?><!--" class="card-img-top rounded" alt="...">-->
<!--            </a>-->
<!--            <div class="text-left mt-2">-->
<!--                <h6 class="text-black text-truncate text-nowrap mb-1" style="font-size: 0.875rem">--><?php //the_title()?><!--</h6>-->
<!--                <p class="card-text text-black-50 text-truncate text-nowrap" style="font-size: 0.75rem">--><?php //echo $music_author?><!--</p>-->
<!--            </div>-->
<!--        </div>-->
<!--    </div>-->
    <div class="col-xxl-10 col-xl-2 col-sm-3 col-6 mb-3">
            <div class="card card-transparent card-box-hover-rise-alt">
                <a href="#" class="card-img-wrapper rounded" data-toggle="modal" data-target="#modal-bb3">
                    <div class="img-wrapper-overlay">
                        <div class="overlay-btn-wrapper">
                            <i class="fa fa-music" aria-hidden="true"></i>
                        </div>
                    </div>

                    <img src="https://theme.nicetheme.xyz/lighthouse/wp-content/uploads/sites/4/2019/11/2019111212521358.jpg"
                         class="card-img-top rounded" alt="...">
                </a>
                <div class="text-left mt-2">
                    <h6 class="text-black text-truncate text-nowrap mb-1" style="font-size: 0.875rem">Lover
                        情人</h6>
                    <p class="card-text text-black-50 text-truncate text-nowrap" style="font-size: 0.75rem">
                        Taylor Swift</p>
                </div>
            </div>
        </div>
    <div class="col-xxl-10 col-xl-2 col-sm-3 col-6 mb-3">
            <div class="card card-transparent card-box-hover-rise-alt">
                <a href="#" class="card-img-wrapper rounded" data-toggle="modal" data-target="#modal-bb3">
                    <div class="img-wrapper-overlay">
                        <div class="overlay-btn-wrapper">
                            <i class="fa fa-music" aria-hidden="true"></i>
                        </div>
                    </div>

                    <img src="https://theme.nicetheme.xyz/lighthouse/wp-content/uploads/sites/4/2019/11/2019111212521358.jpg"
                         class="card-img-top rounded" alt="...">
                </a>
                <div class="text-left mt-2">
                    <h6 class="text-black text-truncate text-nowrap mb-1" style="font-size: 0.875rem">Lover
                        情人</h6>
                    <p class="card-text text-black-50 text-truncate text-nowrap" style="font-size: 0.75rem">
                        Taylor Swift</p>
                </div>
            </div>
        </div>
        <div class="col-xxl-10 col-xl-2 col-sm-3 col-6 mb-3">
            <div class="card card-transparent card-box-hover-rise-alt">
                <a href="#" class="card-img-wrapper rounded" data-toggle="modal" data-target="#modal-bb3">
                    <div class="img-wrapper-overlay">
                        <div class="overlay-btn-wrapper">
                            <i class="fa fa-music" aria-hidden="true"></i>
                        </div>
                    </div>

                    <img src="https://theme.nicetheme.xyz/lighthouse/wp-content/uploads/sites/4/2019/11/2019111212521358.jpg"
                         class="card-img-top rounded" alt="...">
                </a>
                <div class="text-left mt-2">
                    <h6 class="text-black text-truncate text-nowrap mb-1" style="font-size: 0.875rem">Lover
                        情人</h6>
                    <p class="card-text text-black-50 text-truncate text-nowrap" style="font-size: 0.75rem">
                        Taylor Swift</p>
                </div>
            </div>
        </div>
        <div class="col-xxl-10 col-xl-2 col-sm-3 col-6 mb-3">
            <div class="card card-transparent card-box-hover-rise-alt">
                <a href="#" class="card-img-wrapper rounded" data-toggle="modal" data-target="#modal-bb3">
                    <div class="img-wrapper-overlay">
                        <div class="overlay-btn-wrapper">
                            <i class="fa fa-music" aria-hidden="true"></i>
                        </div>
                    </div>

                    <img src="https://theme.nicetheme.xyz/lighthouse/wp-content/uploads/sites/4/2019/11/2019111212521358.jpg"
                         class="card-img-top rounded" alt="...">
                </a>
                <div class="text-left mt-2">
                    <h6 class="text-black text-truncate text-nowrap mb-1" style="font-size: 0.875rem">Lover
                        情人</h6>
                    <p class="card-text text-black-50 text-truncate text-nowrap" style="font-size: 0.75rem">
                        Taylor Swift</p>
                </div>
            </div>
        </div>
        <div class="col-xxl-10 col-xl-2 col-sm-3 col-6 mb-3">
            <div class="card card-transparent card-box-hover-rise-alt">
                <a href="#" class="card-img-wrapper rounded" data-toggle="modal" data-target="#modal-bb3">
                    <div class="img-wrapper-overlay">
                        <div class="overlay-btn-wrapper">
                            <i class="fa fa-music" aria-hidden="true"></i>
                        </div>
                    </div>

                    <img src="https://theme.nicetheme.xyz/lighthouse/wp-content/uploads/sites/4/2019/11/2019111212521358.jpg"
                         class="card-img-top rounded" alt="...">
                </a>
                <div class="text-left mt-2">
                    <h6 class="text-black text-truncate text-nowrap mb-1" style="font-size: 0.875rem">Lover
                        情人</h6>
                    <p class="card-text text-black-50 text-truncate text-nowrap" style="font-size: 0.75rem">
                        Taylor Swift</p>
                </div>
            </div>
        </div>
        <div class="col-xxl-10 col-xl-2 col-sm-3 col-6 mb-3">
            <div class="card card-transparent card-box-hover-rise-alt">
                <a href="#" class="card-img-wrapper rounded" data-toggle="modal" data-target="#modal-bb3">
                    <div class="img-wrapper-overlay">
                        <div class="overlay-btn-wrapper">
                            <i class="fa fa-music" aria-hidden="true"></i>
                        </div>
                    </div>

                    <img src="https://theme.nicetheme.xyz/lighthouse/wp-content/uploads/sites/4/2019/11/2019111212521358.jpg"
                         class="card-img-top rounded" alt="...">
                </a>
                <div class="text-left mt-2">
                    <h6 class="text-black text-truncate text-nowrap mb-1" style="font-size: 0.875rem">Lover
                        情人</h6>
                    <p class="card-text text-black-50 text-truncate text-nowrap" style="font-size: 0.75rem">
                        Taylor Swift</p>
                </div>
            </div>
        </div>
        <div class="col-xxl-10 col-xl-2 col-sm-3 col-6 mb-3">
            <div class="card card-transparent card-box-hover-rise-alt">
                <a href="#" class="card-img-wrapper rounded" data-toggle="modal" data-target="#modal-bb3">
                    <div class="img-wrapper-overlay">
                        <div class="overlay-btn-wrapper">
                            <i class="fa fa-music" aria-hidden="true"></i>
                        </div>
                    </div>

                    <img src="https://theme.nicetheme.xyz/lighthouse/wp-content/uploads/sites/4/2019/11/2019111212521358.jpg"
                         class="card-img-top rounded" alt="...">
                </a>
                <div class="text-left mt-2">
                    <h6 class="text-black text-truncate text-nowrap mb-1" style="font-size: 0.875rem">Lover
                        情人</h6>
                    <p class="card-text text-black-50 text-truncate text-nowrap" style="font-size: 0.75rem">
                        Taylor Swift</p>
                </div>
            </div>
        </div>
        <div class="col-xxl-10 col-xl-2 col-sm-3 col-6 mb-3">
            <div class="card card-transparent card-box-hover-rise-alt">
                <a href="#" class="card-img-wrapper rounded" data-toggle="modal" data-target="#modal-bb3">
                    <div class="img-wrapper-overlay">
                        <div class="overlay-btn-wrapper">
                            <i class="fa fa-music" aria-hidden="true"></i>
                        </div>
                    </div>

                    <img src="https://theme.nicetheme.xyz/lighthouse/wp-content/uploads/sites/4/2019/11/2019111212521358.jpg"
                         class="card-img-top rounded" alt="...">
                </a>
                <div class="text-left mt-2">
                    <h6 class="text-black text-truncate text-nowrap mb-1" style="font-size: 0.875rem">Lover
                        情人</h6>
                    <p class="card-text text-black-50 text-truncate text-nowrap" style="font-size: 0.75rem">
                        Taylor Swift</p>
                </div>
            </div>
        </div>
    <div class="modal fade" id="music_<?php echo $music_id?>" tabindex="-1" role="dialog" aria-labelledby="music_<?php echo $music_id?>"
         aria-hidden="true">
        <div class="modal-dialog modal-dark modal-dialog-centered" role="document">
            <div class="modal-content bg-amy-crisp">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalScrollableTitle"><?php the_title()?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>
                        <?php the_content();?>
                    </p>

                </div>
                <div class="modal-footer d-block text-center">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">
                        赞一下
                    </button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal">
                        分享一下
                    </button>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach;endif;wp_reset_postdata();?>
</div>

<!--Music END-->