<!--Post-->
<div class="h5 mb-3 mb-lg-4">
    <div class="d-flex flex-fill algin-items-center">
        <div class="flex-fill">博客文章</div>
        <div class="font-theme">
            <a class="font-theme text-muted text-xs" href="#">more+</a>
        </div>
    </div>
</div>
<div class="divider my-4"></div>
<div class="row mb-3">

    <div class="col-xxl-5 col-lg-3 col-lg-post-4 col-lg-post-3 col-md-4 col-sm-6">
        <a href="#" class="card card-box-hover-rise mb-5">
            <div class="card-badges">
                <span class="badge badge-danger">博客文章</span>
            </div>
            <img src="<?php bloginfo('template_url')?>/static/images/post_demo.jpg" class="card-img-top" alt="...">
            <div class="card-body card-body-avatar">
                <div class="avatar-icon-wrapper">
                    <div class="avatar-icon"><img src="<?php bloginfo('template_url')?>/static/images/site-1.png" alt=""></div>
                </div>
                <h5 class="card-title text-black text-truncate text-nowrap" style="font-size: 1em">世界，您好!</h5>
                <p class="card-text text-black text-truncate text-nowrap" style="font-size: 0.85em">世界，您好!世界，您好!世界，您好!世界，您好!</p>
                <div class="card-date mt-2">
                    <i class="fa fa-clock text-muted mr-1"></i>
                    <small class="text-muted">
                        <?php the_time('Y-m-d');?>
                    </small>
                </div>
            </div>
        </a>
    </div>

</div>
<!--Post END-->