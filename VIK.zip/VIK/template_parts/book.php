<!--Book-->
<div class="h5 mb-3 mb-lg-4">
    <div class="d-flex flex-fill algin-items-center">
        <div class="flex-fill">编程书籍</div>
        <div class="font-theme">
            <a class="font-theme text-muted text-xs" href="#">more+</a>
        </div>
    </div>
</div>
<div class="divider my-4"></div>
<div class="row mb-3">
    <div class="col-6 col-xl-2 col-sm-3">
        <div class="card card-transparent mb-5">
            <a href="#" class="card-img-wrapper rounded" data-toggle="modal" data-target="#modal-bbb4">
                <div class="img-wrapper-overlay">
                    <div class="overlay-btn-wrapper">
                        <div class="card-title mb-2" style="font-size: 0.875rem">唯有孤独恒常如新</div>
                        <div class="card-text mb-2" style="font-size: 0.75rem">[美]伊丽莎白·毕肖普</div>
                    </div>
                </div>
                <img src="https://theme.nicetheme.xyz/lighthouse/wp-content/uploads/sites/4/2019/11/2019111212524662.jpg"
                     class="card-img-top rounded" alt="...">
            </a>
        </div>
    </div>
    <div class="col-6 col-xl-2 col-sm-3">
        <div class="card card-transparent mb-5">
            <a href="#" class="card-img-wrapper rounded" data-toggle="modal" data-target="#modal-bbb4">
                <div class="img-wrapper-overlay">
                    <div class="overlay-btn-wrapper">
                        <div class="card-title mb-2" style="font-size: 0.875rem">唯有孤独恒常如新</div>
                        <div class="card-text mb-2" style="font-size: 0.75rem">[美]伊丽莎白·毕肖普</div>
                    </div>
                </div>
                <img src="https://theme.nicetheme.xyz/lighthouse/wp-content/uploads/sites/4/2019/11/2019111212524662.jpg"
                     class="card-img-top rounded" alt="...">
            </a>
        </div>
    </div>
    <div class="col-6 col-xl-2 col-sm-3">
        <div class="card card-transparent mb-5">
            <a href="#" class="card-img-wrapper rounded" data-toggle="modal" data-target="#modal-bbb4">
                <div class="img-wrapper-overlay">
                    <div class="overlay-btn-wrapper">
                        <div class="card-title mb-2" style="font-size: 0.875rem">唯有孤独恒常如新</div>
                        <div class="card-text mb-2" style="font-size: 0.75rem">[美]伊丽莎白·毕肖普</div>
                    </div>
                </div>
                <img src="https://theme.nicetheme.xyz/lighthouse/wp-content/uploads/sites/4/2019/11/2019111212524662.jpg"
                     class="card-img-top rounded" alt="...">
            </a>
        </div>
    </div>
    <div class="col-6 col-xl-2 col-sm-3">
        <div class="card card-transparent mb-5">
            <a href="#" class="card-img-wrapper rounded" data-toggle="modal" data-target="#modal-bbb4">
                <div class="img-wrapper-overlay">
                    <div class="overlay-btn-wrapper">
                        <div class="card-title mb-2" style="font-size: 0.875rem">唯有孤独恒常如新</div>
                        <div class="card-text mb-2" style="font-size: 0.75rem">[美]伊丽莎白·毕肖普</div>
                    </div>
                </div>
                <img src="https://theme.nicetheme.xyz/lighthouse/wp-content/uploads/sites/4/2019/11/2019111212524662.jpg"
                     class="card-img-top rounded" alt="...">
            </a>
        </div>
    </div>
    <div class="col-6 col-xl-2 col-sm-3">
        <div class="card card-transparent mb-5">
            <a href="#" class="card-img-wrapper rounded" data-toggle="modal" data-target="#modal-bbb4">
                <div class="img-wrapper-overlay">
                    <div class="overlay-btn-wrapper">
                        <div class="card-title mb-2" style="font-size: 0.875rem">唯有孤独恒常如新</div>
                        <div class="card-text mb-2" style="font-size: 0.75rem">[美]伊丽莎白·毕肖普</div>
                    </div>
                </div>
                <img src="https://theme.nicetheme.xyz/lighthouse/wp-content/uploads/sites/4/2019/11/2019111212524662.jpg"
                     class="card-img-top rounded" alt="...">
            </a>
        </div>
    </div>
    <div class="col-6 col-xl-2 col-sm-3">
        <div class="card card-transparent mb-5">
            <a href="#" class="card-img-wrapper rounded" data-toggle="modal" data-target="#modal-bbb4">
                <div class="img-wrapper-overlay">
                    <div class="overlay-btn-wrapper">
                        <div class="card-title mb-2" style="font-size: 0.875rem">唯有孤独恒常如新</div>
                        <div class="card-text mb-2" style="font-size: 0.75rem">[美]伊丽莎白·毕肖普</div>
                    </div>
                </div>
                <img src="https://theme.nicetheme.xyz/lighthouse/wp-content/uploads/sites/4/2019/11/2019111212524662.jpg"
                     class="card-img-top rounded" alt="...">
            </a>
        </div>
    </div>

    <div class="col-6 col-xl-2 col-sm-3">
        <div class="card card-transparent mb-5">
            <a href="#" class="card-img-wrapper rounded" data-toggle="modal" data-target="#modal-bbb4">
                <div class="img-wrapper-overlay">
                    <div class="overlay-btn-wrapper">
                        <div class="card-title mb-2" style="font-size: 0.875rem">唯有孤独恒常如新</div>
                        <div class="card-text mb-2" style="font-size: 0.75rem">[美]伊丽莎白·毕肖普</div>
                    </div>
                </div>
                <img src="https://theme.nicetheme.xyz/lighthouse/wp-content/uploads/sites/4/2019/11/2019111212524662.jpg"
                     class="card-img-top rounded" alt="...">
            </a>
        </div>
    </div>
    <div class="col-6 col-xl-2 col-sm-3">
        <div class="card card-transparent mb-5">
            <a href="#" class="card-img-wrapper rounded" data-toggle="modal" data-target="#modal-bbb4">
                <div class="img-wrapper-overlay">
                    <div class="overlay-btn-wrapper">
                        <div class="card-title mb-2" style="font-size: 0.875rem">唯有孤独恒常如新</div>
                        <div class="card-text mb-2" style="font-size: 0.75rem">[美]伊丽莎白·毕肖普</div>
                    </div>
                </div>
                <img src="https://theme.nicetheme.xyz/lighthouse/wp-content/uploads/sites/4/2019/11/2019111212524662.jpg"
                     class="card-img-top rounded" alt="...">
            </a>
        </div>
    </div>
    <div class="col-6 col-xl-2 col-sm-3">
        <div class="card card-transparent mb-5">
            <a href="#" class="card-img-wrapper rounded" data-toggle="modal" data-target="#modal-bbb4">
                <div class="img-wrapper-overlay">
                    <div class="overlay-btn-wrapper">
                        <div class="card-title mb-2" style="font-size: 0.875rem">唯有孤独恒常如新</div>
                        <div class="card-text mb-2" style="font-size: 0.75rem">[美]伊丽莎白·毕肖普</div>
                    </div>
                </div>
                <img src="https://theme.nicetheme.xyz/lighthouse/wp-content/uploads/sites/4/2019/11/2019111212524662.jpg"
                     class="card-img-top rounded" alt="...">
            </a>
        </div>
    </div>
    <div class="col-6 col-xl-2 col-sm-3">
        <div class="card card-transparent mb-5">
            <a href="#" class="card-img-wrapper rounded" data-toggle="modal" data-target="#modal-bbb4">
                <div class="img-wrapper-overlay">
                    <div class="overlay-btn-wrapper">
                        <div class="card-title mb-2" style="font-size: 0.875rem">唯有孤独恒常如新</div>
                        <div class="card-text mb-2" style="font-size: 0.75rem">[美]伊丽莎白·毕肖普</div>
                    </div>
                </div>
                <img src="https://theme.nicetheme.xyz/lighthouse/wp-content/uploads/sites/4/2019/11/2019111212524662.jpg"
                     class="card-img-top rounded" alt="...">
            </a>
        </div>
    </div>
    <div class="col-6 col-xl-2 col-sm-3">
        <div class="card card-transparent mb-5">
            <a href="#" class="card-img-wrapper rounded" data-toggle="modal" data-target="#modal-bbb4">
                <div class="img-wrapper-overlay">
                    <div class="overlay-btn-wrapper">
                        <div class="card-title mb-2" style="font-size: 0.875rem">唯有孤独恒常如新</div>
                        <div class="card-text mb-2" style="font-size: 0.75rem">[美]伊丽莎白·毕肖普</div>
                    </div>
                </div>
                <img src="https://theme.nicetheme.xyz/lighthouse/wp-content/uploads/sites/4/2019/11/2019111212524662.jpg"
                     class="card-img-top rounded" alt="...">
            </a>
        </div>
    </div>
    <div class="col-6 col-xl-2 col-sm-3">
        <div class="card card-transparent mb-5">
            <a href="#" class="card-img-wrapper rounded" data-toggle="modal" data-target="#modal-bbb4">
                <div class="img-wrapper-overlay">
                    <div class="overlay-btn-wrapper">
                        <div class="card-title mb-2" style="font-size: 0.875rem">唯有孤独恒常如新</div>
                        <div class="card-text mb-2" style="font-size: 0.75rem">[美]伊丽莎白·毕肖普</div>
                    </div>
                </div>
                <img src="https://theme.nicetheme.xyz/lighthouse/wp-content/uploads/sites/4/2019/11/2019111212524662.jpg"
                     class="card-img-top rounded" alt="...">
            </a>
        </div>
    </div>
</div>
<!--Book Modal-->
<div class="modal fade" id="modal-bbb4" tabindex="-1" role="dialog" aria-labelledby="modal-bbb4">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-body p-0">
                <div class="row no-gutters">
                    <div class="col-lg-5">
                        <img src="https://theme.nicetheme.xyz/lighthouse/wp-content/uploads/sites/4/2019/11/2019111212524662.jpg"
                             class="rounded-left img-fit-container" alt="...">
                    </div>
                    <div class="col-lg-7 d-flex align-items-center">
                        <div class="tool-body p-xl-4 m-3">
                            <div class="tool-name h4">伯林传</div>
                            <div class="text-sm text-muted">
                                <ul class="list-unstyled text-black">
                                    <li class="my-2">作者：[加拿大] 叶礼庭</li>
                                    <li class="my-2">出版社：译林出版社</li>
                                    <li class="my-2">发布时间：2019-10</li>
                                    <li class="my-2">豆瓣书评：伊丽莎白·毕肖普，
                                        这位一生都在流浪和漫游中度过的诗人，诗作很少，却被誉为“诗人中的诗人”“狄金森之后美国最伟大的女诗人”。布罗茨基、希尼、帕斯等诺贝尔文学奖得主对其人其作均推崇备至。包揽普利策奖、美国国家图书奖、古根海姆奖等各类文学大奖。诗作入选美国大学教材和耶鲁大学公开课。
                                    </li>
                                </ul>
                            </div>
                            <button type="button" class="btn btn-outline-success">
                                <span class="btn-wrapper--icon">
                                    <i class="fa fa-heart-o" aria-hidden="true"></i>
                                </span>
                                <span class="btn-wrapper--label">赞</span>
                            </button>
                            <button type="button" class="btn btn-outline-info">
                                <span class="btn-wrapper--icon">
                                    <i class="fa fa-share-alt" aria-hidden="true"></i>
                                </span>
                                <span class="btn-wrapper--label">分享</span>
                            </button>
                            <button type="button" class="btn btn-outline-danger" data-dismiss="modal" aria-label="Close">
                                <span class="btn-wrapper--icon">
                                    <i class="fa fa-window-close" aria-hidden="true"></i>
                                </span>
                                <span class="btn-wrapper--label">退出</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--Book Modal END-->
<!--Book END-->