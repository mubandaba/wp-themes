
<!--Site-->
<div class="h5 mb-3 mb-lg-4">
    <div class="d-flex flex-fill algin-items-center">
        <div class="flex-fill"><?php $vik_customize = get_option('vik_customize'); echo $vik_customize['friend_title']?></div>
        <div class="text-muted"><i class="fa fa-handshake-o" aria-hidden="true"></i></div>
    </div>
</div>
<div class="divider my-4"></div>
<div class="row mb-3">
        <?php
            $friend_link_groups = $vik_customize['friend_link_group'];
            if ($friend_link_groups):foreach ($friend_link_groups as $friend_link_group):
            $friend_name = $friend_link_group['friend_name'];
            $friend_link = $friend_link_group['friend_link'];
        ?>
        <div class="col-xxl-10 col-lg-3 col-sm-3 col-6 mb-4">
            <div class="">
                <a class="row no-gutters" href="<?php echo $friend_link;?>">
                    <div class="col-3">
                        <div class="avatar-icon-wrapper">
                            <div class="avatar-icon-wrapper avatar-initials avatar-icon-xs">
                                <div class="avatar-icon text-white bg-dark">
                                    <?php echo mb_substr($friend_name,0,1,'utf-8')?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-9">
                        <div class="card-body p-1">
                            <h5 class="text-dark" style="font-size: 0.875rem"><?php echo $friend_name?></h5>
                        </div>
                    </div>
                </a>
            </div>
        </div>
        <?php endforeach;else:?>
        <div class="col-xxl-10 col-lg-3 col-sm-3 col-6 mb-4">
            <div class="">
                <a class="row no-gutters" href="https://www.joytheme.com">
                    <div class="col-3">
                        <div class="avatar-icon-wrapper">
                            <div class="avatar-icon-wrapper avatar-initials avatar-icon-xs">
                                <div class="avatar-icon text-white bg-dark">
                                    <?php echo mb_substr('JOYtheme',0,1,'utf-8')?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-9">
                        <div class="card-body p-1">
                            <h5 class="text-dark" style="font-size: 0.875rem">joytheme</h5>
                        </div>
                    </div>
                </a>
            </div>
        </div>
        <?php endif;?>
</div>
<!--Site END-->