!(function (e, n) {
    "object" == typeof exports && "undefined" != typeof module ? module.exports = n(require("jquery")) : "function" == typeof define && define.amd ? define(["jquery"], n) : (e = e || self).metisMenu = n(e.jQuery)
})(this, (function (e) {
    "use strict";

    function n() {
        return (n = Object.assign || function (e) {
            for (var n = 1; n < arguments.length; n++) {
                var t = arguments[n];
                for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i])
            }
            return e
        }).apply(this, arguments)
    }

    var t = (function (e) {
            var n = "transitionend", t = {
                TRANSITION_END: "mmTransitionEnd", triggerTransitionEnd: function (t) {
                    e(t).trigger(n)
                }, supportsTransitionEnd: function () {
                    return Boolean(n)
                }
            };

            function i(n) {
                var i = this, r = !1;
                return e(this).one(t.TRANSITION_END, (function () {
                    r = !0
                })), setTimeout((function () {
                    r || t.triggerTransitionEnd(i)
                }), n), this
            }

            return e.fn.mmEmulateTransitionEnd = i, e.event.special[t.TRANSITION_END] = {
                bindType: n,
                delegateType: n,
                handle: function (n) {
                    if (e(n.target).is(this)) return n.handleObj.handler.apply(this, arguments)
                }
            }, t
        })(e = e && e.hasOwnProperty("default") ? e.default : e), i = "metisMenu", r = e.fn[i],
        s = {toggle: !0, preventDefault: !0, triggerElement: "a", parentTrigger: "li", subMenu: "ul"}, a = {
            SHOW: "show.metisMenu",
            SHOWN: "shown.metisMenu",
            HIDE: "hide.metisMenu",
            HIDDEN: "hidden.metisMenu",
            CLICK_DATA_API: "click.metisMenu.data-api"
        }, o = "metismenu", g = "mm-active", u = "mm-show", h = "mm-collapse", l = "mm-collapsing", f = (function () {
            function i(e, t) {
                this.element = e, this.config = n({}, s, t), this.transitioning = null, this.init()
            }

            var r = i.prototype;
            return r.init = function () {
                var n = this, t = this.config, i = e(this.element);
                i.addClass(o), i.find(t.parentTrigger + "." + g).children(t.triggerElement).attr("aria-expanded", "true"), i.find(t.parentTrigger + "." + g).parents(t.parentTrigger).addClass(g), i.find(t.parentTrigger + "." + g).parents(t.parentTrigger).children(t.triggerElement).attr("aria-expanded", "true"), i.find(t.parentTrigger + "." + g).has(t.subMenu).children(t.subMenu).addClass(h + " " + u), i.find(t.parentTrigger).not("." + g).has(t.subMenu).children(t.subMenu).addClass(h), i.find(t.parentTrigger).children(t.triggerElement).on(a.CLICK_DATA_API, (function (i) {
                    var r = e(this);
                    if ("true" !== r.attr("aria-disabled")) {
                        t.preventDefault && "#" === r.attr("href") && i.preventDefault();
                        var s = r.parent(t.parentTrigger), a = s.siblings(t.parentTrigger),
                            o = a.children(t.triggerElement);
                        s.hasClass(g) ? (r.attr("aria-expanded", "false"), n.removeActive(s)) : (r.attr("aria-expanded", "true"), n.setActive(s), t.toggle && (n.removeActive(a), o.attr("aria-expanded", "false"))), t.onTransitionStart && t.onTransitionStart(i)
                    }
                }))
            }, r.setActive = function (n) {
                e(n).addClass(g);
                var t = e(n).children(this.config.subMenu);
                t.length > 0 && !t.hasClass(u) && this.show(t)
            }, r.removeActive = function (n) {
                e(n).removeClass(g);
                var t = e(n).children(this.config.subMenu + "." + u);
                t.length > 0 && this.hide(t)
            }, r.show = function (n) {
                var i = this;
                if (!this.transitioning && !e(n).hasClass(l)) {
                    var r = e(n), s = e.Event(a.SHOW);
                    if (r.trigger(s), !s.isDefaultPrevented()) {
                        if (r.parent(this.config.parentTrigger).addClass(g), this.config.toggle) {
                            var o = r.parent(this.config.parentTrigger).siblings().children(this.config.subMenu + "." + u);
                            this.hide(o)
                        }
                        r.removeClass(h).addClass(l).height(0), this.setTransitioning(!0);
                        r.height(n[0].scrollHeight).one(t.TRANSITION_END, (function () {
                            i.config && i.element && (r.removeClass(l).addClass(h + " " + u).height(""), i.setTransitioning(!1), r.trigger(a.SHOWN))
                        })).mmEmulateTransitionEnd(350)
                    }
                }
            }, r.hide = function (n) {
                var i = this;
                if (!this.transitioning && e(n).hasClass(u)) {
                    var r = e(n), s = e.Event(a.HIDE);
                    if (r.trigger(s), !s.isDefaultPrevented()) {
                        r.parent(this.config.parentTrigger).removeClass(g), r.height(r.height())[0].offsetHeight, r.addClass(l).removeClass(h).removeClass(u), this.setTransitioning(!0);
                        var o = function () {
                            i.config && i.element && (i.transitioning && i.config.onTransitionEnd && i.config.onTransitionEnd(), i.setTransitioning(!1), r.trigger(a.HIDDEN), r.removeClass(l).addClass(h))
                        };
                        0 === r.height() || "none" === r.css("display") ? o() : r.height(0).one(t.TRANSITION_END, o).mmEmulateTransitionEnd(350)
                    }
                }
            }, r.setTransitioning = function (e) {
                this.transitioning = e
            }, r.dispose = function () {
                e.removeData(this.element, "metisMenu"), e(this.element).find(this.config.parentTrigger).has(this.config.subMenu).children(this.config.triggerElement).off("click"), this.transitioning = null, this.config = null, this.element = null
            }, i.jQueryInterface = function (t) {
                return this.each((function () {
                    var r = e(this), a = r.data("metisMenu"), o = n({}, s, r.data(), "object" == typeof t && t ? t : {});
                    if (a || (a = new i(this, o), r.data("metisMenu", a)), "string" == typeof t) {
                        if (void 0 === a[t]) throw new Error('No method named "' + t + '"');
                        a[t]()
                    }
                }))
            }, i
        })();
    return e.fn[i] = f.jQueryInterface, e.fn[i].Constructor = f, e.fn[i].noConflict = function () {
        return e.fn[i] = r, f.jQueryInterface
    }, f
}));