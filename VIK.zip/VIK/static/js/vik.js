$((function () {
    $(".toggle-sidebar").click((function () {
        $("body").toggleClass("sidebar-collapsed"), $(".toggle-sidebar").toggleClass("is-active")
    }))
})), $((function () {
    $(".toggle-sidebar-mobile, .sidebar-mobile-overlay").click((function () {
        $("body").toggleClass("sidebar-open-mobile"), $(".toggle-sidebar-mobile").toggleClass("is-active")
    }))
})), $((function () {
    $(".toggle-inner-sidebar").click((function () {
        var e = $(this).attr("data-target");
        $(e).toggleClass("sidebar-inner-open"), $(".sidebar-inner-mobile-overlay").toggleClass("active")
    }))
})), $((function () {
    $(".sidebar-inner-mobile-overlay").click((function () {
        $(this).removeClass("active"), $(".app-content--sidebar").removeClass("sidebar-inner-open")
    }))
}));

$(document).on('click', '#modal_button', function (event) {
    event.preventDefault();
    that = $('#time');
    var num = 10;
    that.html(num);

    var sms_t = window.setInterval(function () {
        num = num - 1;
        if (num > 0) {
            that.html(num);
            console.log(num);
        } else {
            window.location.href =document.getElementById('site_link').innerHTML;
            clearInterval(sms_t)
        }
    }, 1000);

    $(document).on('click', '#cancel_button', function (event) {
        clearInterval(sms_t)
    });

});