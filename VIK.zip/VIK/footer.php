<?php if ( !is_page_template('page-go.php') ):?>
</div>
</div>
<?php endif;wp_footer();?>
</body>
</html>