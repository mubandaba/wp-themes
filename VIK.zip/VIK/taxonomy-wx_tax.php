<?php get_header();?>
    <div class="app-content">
        <div class="app-content--inner bg-white">
            <!--Site-->
            <div class="h5 mb-3 mb-lg-4">
                <div class="d-flex flex-fill algin-items-center">
                    <div class="flex-fill"><?php the_archive_title();?></div>
                    <a class="text-muted" href="<?php echo get_post_type_archive_link('site');?>">more+</a>
                </div>
            </div>
            <div class="divider my-4"></div>
            <div class="row mb-3">
                <?php
                    if (have_posts() ) : while (have_posts() ) :the_post();
                    $wx_id = get_the_ID();
                    $wx_desc = get_post_meta($wx_id,'wx_desc',true);
                    $wx_logo_id = get_post_meta($wx_id,'wx_logo',true)['id'];
                    $wx_code_id = get_post_meta($wx_id,'wx_code',true)['id'];
                ?>
                <div class="col-xl-3 col-xlg-3 col-lg-4 col-sm-12 col-xmd-2 mb-4">
                    <div class="card card-box-hover-shadow site-card">
                        <div class="row no-gutters">
                            <div class="col-3">
                                <a href="#" class="card-img-wrapper rounded card-img" data-toggle="modal" data-target="#wx_<?php echo $wx_id?>" style="width: 80px">
                                    <div class="img-wrapper-overlay">
                                        <div class="overlay-btn-wrapper">
                                            <i class="fa fa-qrcode fa-2x" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                    <img <?php xyz_src($wx_logo_id);?> class="card-img-top rounded" alt="...">
                                </a>
                            </div>
                            <div class="col-7">
                                <div class="card-body pb-0">
                                    <h5 class="text-black text-nowrap text-truncate" style="font-size: 0.875rem"><?php echo get_the_title()?></h5>
                                    <p class="card-text text-dark-50 d-inline-block text-truncate" style="max-width: 100%;font-size: 0.75rem">
                                        <small><?php echo $wx_desc?></small>
                                    </p>
                                </div>
                            </div>
                            <div class="d-flex align-items-center card-hover-indicator">
                                <i class="fa fa-chevron-circle-right"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal fade" id="wx_<?php echo $wx_id?>" tabindex="-1" role="dialog" aria-labelledby="wx_<?php echo $wx_id?>">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-body p-0">
                                <div class="card bg-secondary shadow-none border-0">
                                    <img <?php xyz_src($wx_code_id);?> class="card-img-top rounded" alt="...">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endwhile;endif;?>
            </div>
            <!--Site END-->
            <?php
            if ( function_exists('vik_pagination') )
                vik_pagination();
            ?>
        </div>
        <?php include 'template_parts/footer.php'?>
    </div>

<?php get_footer();?>