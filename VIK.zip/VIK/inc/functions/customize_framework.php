<?php
if( class_exists( 'CSF' ) ) {
    $prefix = 'vik_customize';
    CSF::createCustomizeOptions($prefix);

    CSF::createSection($prefix, array(
        'title'          => '基本设置',
        'transport'      => 'refresh',
        'capability'     => 'manage_options',
        'save_defaults'  => true,
        'enqueue_webfont'=> true,
        'async_webfont'  => true,
        'output_css'     => true,
        'assign'         => 'title_tagline',
        'fields'         => array(
            array(
                'id'      => 'blog_logo',
                'title'   => '站点LOGO',
                'type'    => 'media',
                'library' => 'image',
                'url'     => false,
                'subtitle'=> '67*54px',
            ),
            array(
                'id'      => 'web_favicon',
                'title'   => 'Favicon',
                'type'    => 'media',
                'library' => 'image',
                'url'     => false,
            ),
            array(
                'id'         => 'load_type',
                'type'       => 'radio',
                'title'      => '导航链接跳转形式',
                'inline'       => true,
                'options'    => array(
                    'load_page'  => '页面跳转',
                    'modal_link' => '弹窗',
                ),
                'default'    => 'load_page',
            ),
        )
    ));

    CSF::createSection($prefix, array(
        'title'          => '首页布局',
        'transport'      => 'refresh',
        'capability'     => 'manage_options',
        'save_defaults'  => true,
        'enqueue_webfont'=> true,
        'async_webfont'  => true,
        'output_css'     => true,
        'assign'         => 'title_tagline',
        'fields'         => array(
            array(
                'id'     => 'index_content_group',
                'type'   => 'group',
                'title'  => '首页布局',
                'fields' => array(
                    array(
                        'id'         => 'guide_title',
                        'type'       => 'text',
                        'title'      => '导航名称',
                        'default'    => '精选网站'
                    ),
                    array(
                        'id'         => 'guide_radio',
                        'type'       => 'radio',
                        'inline'     => true,
                        'title'      => '导航设置',
                        'options'    => array(
                            'site'   => '站点导航',
                            'wx'     => '公众号导航',
                            'ad'     => '广告',
                        ),
                        'default'    => 'site'
                    ),
                    array(
                        'id'            => 'site_list',
                        'type'          => 'select',
                        'title'         => '站点分类',
                        'options'       => 'categories',
                        'dependency'    => array('guide_radio', '==', 'site'),
                        'query_args'    => array(
                            'taxonomy'  => 'site_tax',
                            'orderby'   => 'post_date',
                            'order'     => 'DESC',
                        ),
                        'placeholder'   => '站点分类',
                    ),
                    array(
                        'id'            => 'wx_list',
                        'type'          => 'select',
                        'title'         => '公众号',
                        'options'       => 'categories',
                        'dependency'    => array('guide_radio', '==', 'wx'),
                        'query_args'    => array(
                            'taxonomy'  => 'wx_tax',
                            'orderby'   => 'post_date',
                            'order'     => 'DESC',
                        ),
                        'placeholder'   => '站点分类',
                    ),
                    array(
                        'id'           => 'ad_title',
                        'type'         => 'text',
                        'title'        => '广告名称',
                        'default'      => 'JOYtheme',
                        'dependency'   => array('guide_radio', '==', 'ad'),
                    ),
                    array(
                        'id'           => 'ad_link',
                        'type'         => 'text',
                        'title'        => '跳转链接',
                        'subtitle'     => 'http://或https://',
                        'dependency'   => array('guide_radio', '==', 'ad'),
                    ),
                    array(
                        'id'           => 'ad_img',
                        'type'         => 'media',
                        'title'        => '图片',
                        'library'      => 'image',
                        'url'          => false,
                        'dependency'   => array('guide_radio', '==', 'ad'),
                    ),
                    array(
                        'id'           => 'badge_switcher',
                        'type'         => 'switcher',
                        'title'        => '开启广告角标',
                        'text_on'      => '开',
                        'text_off'     => '关',
                        'help'         => '开启将在图片右下角显示"广告"字样',
                        'dependency'   => array('guide_radio', '==', 'ad'),
                    ),
                    array(
                        'id'           => 'index_data_num',
                        'type'         => 'slider',
                        'max'          => '40',
                        'unit'         => '篇',
                        'min'          => '4',
                        'title'        => '显示篇数',
                        'default'      => 30,
                        'dependency'   => array('guide_radio', '!=', 'ad'),

                    ),
                ),
            ),
        )
    ));

    CSF::createSection($prefix, array(
        'title'          => '社交媒体',
        'transport'      => 'refresh',
        'capability'     => 'manage_options',
        'save_defaults'  => true,
        'enqueue_webfont'=> true,
        'async_webfont'  => true,
        'output_css'     => true,
        'assign'         => 'title_tagline',
        'fields'         => array(
            array(
                'id'      => 'qq',
                'type'    => 'text',
                'title'   => 'QQ',
                'default' => '865852099',
            ),
            array(
                'id'      => 'weibo',
                'type'    => 'text',
                'title'   => '微博链接',
                'default' => 'https://www.joytheme.com/',
            ),
            array(
                'id'      => 'wechat',
                'type'    => 'media',
                'title'   => '微信二维码',
                'library' => 'image',
                'url'     => false,

            ),
        )
    ));

    CSF::createSection($prefix, array(
        'title'          => '友情链接设置',
        'transport'      => 'refresh',
        'capability'     => 'manage_options',
        'save_defaults'  => true,
        'enqueue_webfont'=> true,
        'async_webfont'  => true,
        'output_css'     => true,
        'assign'         => 'title_tagline',
        'fields'         => array(
            array(
                'id'      => 'friend_title',
                'type'    => 'text',
                'title'   => '版块标题',
                'default' => '友情链接'
            ),
            array(
                'id'      => 'friend_link_group',
                'type'    => 'group',
                'title'   => '友情链接设置',
                'fields'  => array(
                    array(
                        'id'      => 'friend_name',
                        'type'    => 'text',
                        'title'   => '标题',
                        'default' => '友情链接'
                    ),
                    array(
                        'id'      => 'friend_link',
                        'type'    => 'text',
                        'title'   => '链接',
                    ),

                ),
            ),
        )
    ));
}