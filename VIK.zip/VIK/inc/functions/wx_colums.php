<?php
add_filter( 'manage_edit-wx_columns', 'wam_wx_movie_columns' ) ;

function wam_wx_movie_columns( $columns ) {

    $columns = array(
        'cb'    => '&lt;input type="checkbox" />',
        'title' =>'标题',
        'logo'  =>'LOGO',
        'code'  =>'二维码',
        'desc'  =>'简介',
        'wx_tax'=>'分类',
        'date'  =>'日期',
    );

    return $columns;
}

add_action( 'manage_wx_posts_custom_column', 'wam_manage_wx_columns', 10, 2 );

function wam_manage_wx_columns( $column, $post_id ) {
    global $post;
    switch( $column ) {
        case 'link' :
            $web_link = get_post_meta( $post_id, 'web_link', true );
            if ( empty( $web_link ) )
                echo '无';
            else
                echo $web_link;
            break;
        case 'wx_tax' :
            $terms = get_the_terms( $post_id, 'wx_tax' );
            if ( !empty( $terms ) ) {
                $out = array();
                foreach ( $terms as $term ) {
                    $out[] = sprintf( '<a href="%s">%s</a>',
                        esc_url( add_query_arg( array( 'post_type' => $post->post_type, 'wx_tax' => $term->slug ), 'edit.php' ) ),
                        esc_html( sanitize_term_field( 'name', $term->name, $term->term_id, 'wx_tax', 'display' ) )
                    );
                }
                echo join( ', ', $out );
            }
            else {
                echo '无';
            }
            break;
        default :
            break;
        case 'logo' :
            $wx_logo = get_post_meta( $post_id, 'wx_logo', true );

            if ( empty( $wx_logo ) )
                echo '无';
            else
                echo '<img src="'.$wx_logo['url'].'" style="width:50px;height:50px">';
            break;
        case 'code' :
            $wx_code = get_post_meta( $post_id, 'wx_code', true );

            if ( empty( $wx_code ) )
                echo '无';
            else
                echo '<img src="'.$wx_code['url'].'" style="width:50px;height:50px">';
            break;
        case 'desc' :
            $wx_desc = get_post_meta( $post_id, 'wx_desc', true );

            if ( empty( $wx_desc ) )
                echo '无';
            else
                echo $wx_desc;
            break;
    }
}
function joy_filter_post_type_by_wx_tax() {
    global $typenow;
    $post_type = 'wx';
    $taxonomy  = 'wx_tax';
    if ($typenow == $post_type) {
        $selected      = isset($_GET[$taxonomy]) ? $_GET[$taxonomy] : '';
        $info_taxonomy = get_taxonomy($taxonomy);
        wp_dropdown_categories(array(
            'show_option_all' => '所有'.$info_taxonomy->label,
            'taxonomy'        => $taxonomy,
            'name'            => $taxonomy,
            'orderby'         => 'name',
            'selected'        => $selected,
            'show_count'      => true,
            'hide_empty'      => true,
        ));
    };
}
add_action('restrict_manage_posts', 'joy_filter_post_type_by_wx_tax');

function wx_tax_convert_id_to_term_in_query($query) {
    global $pagenow;
    $post_type = 'wx';
    $taxonomy  = 'wx_tax';
    $q_vars    = &$query->query_vars;
    if ( $pagenow == 'edit.php' && isset($q_vars['post_type']) && $q_vars['post_type'] == $post_type && isset($q_vars[$taxonomy]) && is_numeric($q_vars[$taxonomy]) && $q_vars[$taxonomy] != 0 ) {
        $term = get_term_by('id', $q_vars[$taxonomy], $taxonomy);
        $q_vars[$taxonomy] = $term->slug;
    }
}
add_filter('parse_query', 'wx_tax_convert_id_to_term_in_query');