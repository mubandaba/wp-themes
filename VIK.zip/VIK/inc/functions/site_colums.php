<?php
add_filter( 'manage_edit-site_columns', 'wam_site_movie_columns' ) ;

function wam_site_movie_columns( $columns ) {

    $columns = array(
        'cb'    => '&lt;input type="checkbox" />',
        'title' =>'站点名称',
        'link'  =>'链接',
        'logo'  =>'LOGO',
        'desc'  =>'简介',
        'site_tax'  =>'分类',
        'date'  =>'日期',
    );

    return $columns;
}

add_action( 'manage_site_posts_custom_column', 'wam_manage_site_columns', 10, 2 );

function wam_manage_site_columns( $column, $post_id ) {
    global $post;

    switch( $column ) {

        case 'link' :
            $web_link = get_post_meta( $post_id, 'web_link', true );

            if ( empty( $web_link ) )
                echo '无';
            else
                echo $web_link;
            break;

        case 'site_tax' :

            $terms = get_the_terms( $post_id, 'site_tax' );

            if ( !empty( $terms ) ) {

                $out = array();

                foreach ( $terms as $term ) {
                    $out[] = sprintf( '<a href="%s">%s</a>',
                        esc_url( add_query_arg( array( 'post_type' => $post->post_type, 'site_tax' => $term->slug ), 'edit.php' ) ),
                        esc_html( sanitize_term_field( 'name', $term->name, $term->term_id, 'site_tax', 'display' ) )
                    );
                }
                echo join( ', ', $out );
            }
            else {
                echo '无';
            }

            break;
        default :
            break;
        case 'logo' :
            $web_logo = get_post_meta( $post_id, 'web_logo', true );

            if ( empty( $web_logo ) )
                echo '无';
            else
                echo '<img src="'.$web_logo['url'].'" style="width:50px;height:50px">';
            break;
        case 'desc' :
            $web_desc = get_post_meta( $post_id, 'web_desc', true );

            if ( empty( $web_desc ) )
                echo '无';
            else
                echo $web_desc;
            break;
    }
}

function joy_filter_post_type_by_taxonomy() {
    global $typenow;
    $post_type = 'site';
    $taxonomy  = 'site_tax';
    if ($typenow == $post_type) {
        $selected      = isset($_GET[$taxonomy]) ? $_GET[$taxonomy] : '';
        $info_taxonomy = get_taxonomy($taxonomy);
        wp_dropdown_categories(array(
            'show_option_all' => '所有'.$info_taxonomy->label,
            'taxonomy'        => $taxonomy,
            'name'            => $taxonomy,
            'orderby'         => 'name',
            'selected'        => $selected,
            'show_count'      => true,
            'hide_empty'      => true,
        ));
    };
}
add_action('restrict_manage_posts', 'joy_filter_post_type_by_taxonomy');

function joy_convert_id_to_term_in_query($query) {
    global $pagenow;
    $post_type = 'site';
    $taxonomy  = 'site_tax';
    $q_vars    = &$query->query_vars;
    if ( $pagenow == 'edit.php' && isset($q_vars['post_type']) && $q_vars['post_type'] == $post_type && isset($q_vars[$taxonomy]) && is_numeric($q_vars[$taxonomy]) && $q_vars[$taxonomy] != 0 ) {
        $term = get_term_by('id', $q_vars[$taxonomy], $taxonomy);
        $q_vars[$taxonomy] = $term->slug;
    }
}
add_filter('parse_query', 'joy_convert_id_to_term_in_query');