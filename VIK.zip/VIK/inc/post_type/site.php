<?php
function create_site() {
    $labels = array(
        'name'               => '站点导航',
        'singular_name'      => '站点导航',
        'add_new'            => '新增站点',
        'add_new_item'       => '新增站点',
        'edit_item'          => '编辑站点',
        'new_item'           => '新站点',
        'all_items'          => '所有站点',
        'view_item'          => '查看站点',
        'search_items'       => '搜索站点',
        'not_found'          => '没有找到有关站点',
        'not_found_in_trash' => '回收站里面没有相关站点',
        'parent_item_colon'  => '',
        'menu_name'          => '站点导航'
    );
    $args = array(
        'labels'        => $labels,
        'description'   => '我们网站的站点导航信息',
        'public'        => true,
        'menu_position' => 5,
        'supports'      => array('title'),
        'menu_icon'     => 'dashicons-welcome-view-site',
        'has_archive'   => true
    );
    register_post_type( 'site', $args );
}
add_action( 'init', 'create_site' );
function create_site_tax() {
    $labels = array(
        'name'              =>'站点分类',
        'singular_name'     =>'站点分类',
        'search_items'      =>'搜索分类' ,
        'all_items'         =>'所有分类' ,
        'parent_item'       =>'该分类的上级分类' ,
        'parent_item_colon' =>'该分类的上级分类：' ,
        'edit_item'         =>'编辑分类' ,
        'update_item'       =>'更新分类' ,
        'add_new_item'      =>'添加新分类' ,
        'new_item_name'     =>'新分类' ,
        'menu_name'         =>'站点分类' ,
    );
    $args = array(
        'labels' => $labels,
        'hierarchical' => true,
    );
    register_taxonomy( 'site_tax', 'site', $args );
}
add_action( 'init', 'create_site_tax', 0 );