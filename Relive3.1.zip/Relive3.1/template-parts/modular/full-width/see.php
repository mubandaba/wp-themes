<?php 
    switch ( $id['modular_style_full_see'] ) {
		
		case '1':
			get_template_part( 'template-parts/modular/see/full-1');
			break;
		case '2':
			get_template_part( 'template-parts/modular/see/full-2');
			break;
		case '3':
			get_template_part( 'template-parts/modular/see/full-3');
			break;
		case '4':
			get_template_part( 'template-parts/modular/see/full-4');
			break;
		case '5':
			get_template_part( 'template-parts/modular/see/full-5');
			break;
		case '6':
			get_template_part( 'template-parts/modular/see/full-6');
			break;
		case '7':
			get_template_part( 'template-parts/modular/see/full-7');
			break;
		case '8':
			get_template_part( 'template-parts/modular/see/full-8');
			break;
		case '9':
			get_template_part( 'template-parts/modular/see/full-9');
			break;
		case '10':
			get_template_part( 'template-parts/modular/see/full-10');
			break;
		case '11':
			get_template_part( 'template-parts/modular/see/full-11');
			break;
		case '12':
			get_template_part( 'template-parts/modular/see/full-12');
			break;
		case '13':
			get_template_part( 'template-parts/modular/see/full-13');
			break;
		case '14':
			get_template_part( 'template-parts/modular/see/full-14');
			break;
		case '15':
			get_template_part( 'template-parts/modular/see/full-15');
			break;
		/*case '16':
			get_template_part( 'template-parts/modular/see/full-16');
			break;
		case '17':
			get_template_part( 'template-parts/modular/see/full-17');
			break;*/
		case '18':
			get_template_part( 'template-parts/modular/see/full-18');
			break;
		case '19':
			get_template_part( 'template-parts/modular/see/full-19');
			break;
		/*case '20':
			get_template_part( 'template-parts/modular/see/full-20');
			break;
		case '21':
			get_template_part( 'template-parts/modular/see/full-21');
			break;*/
		case '22':
			get_template_part( 'template-parts/modular/see/full-22');
			break;
		case '23':
			get_template_part( 'template-parts/modular/see/full-23');
			break;
		/*case '24':
			get_template_part( 'template-parts/modular/see/full-24');
			break;*/
		case '25':
			get_template_part( 'template-parts/modular/see/full-25');
			break;
		case '26':
			get_template_part( 'template-parts/modular/see/full-26');
			break;

    }
?>