<?php

add_filter('acf/settings/path', 'my_acf_settings_path');
function my_acf_settings_path( $path ) {
 
    $path = get_stylesheet_directory() . '/acf/';
    
    return $path;
    
}
 
// 2. customize ACF dir
add_filter('acf/settings/dir', 'my_acf_settings_dir');
 
function my_acf_settings_dir( $dir ) {
 
    // update path
    $dir = get_stylesheet_directory_uri() . '/acf/';
    
    // return
    return $dir;
    
}
 
// 主题小工具
require get_template_directory() . '/inc/hot-post.php';
require get_template_directory() . '/inc/widgets/index.php';


/**
 * 引入必要的css和js文件
 */
add_action( 'wp_enqueue_scripts', 'wphy_script_style' );

function wphy_script_style(){
	wp_enqueue_script('jquery');
	wp_enqueue_script( 'superfish', get_template_directory_uri() . '/js/superfish.js', array(), '', true );
    wp_enqueue_script( 'slicknav', get_template_directory_uri() . '/js/jquery.slicknav.js', array(), '', true );
    wp_enqueue_script( 'modernizr', get_template_directory_uri() . '/js/modernizr.js',array(), '', true ); 
    wp_enqueue_script( 'html5', get_template_directory_uri() . '/js/html5.js', array(), '', true );
    wp_enqueue_script( 'xs', get_template_directory_uri() . '/js/xs.js', array(), '', true );
	
	
	wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/css/bootstrap.css' ); 
	wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/css/font-awesome.min.css' ); 
	wp_enqueue_style( 'slicknav',get_template_directory_uri() . '/css/slicknav.min.css' );
	wp_enqueue_style( 'xs-style', get_stylesheet_uri() );
	wp_enqueue_style( 'responsive',get_template_directory_uri() . '/css/responsive.css' );

}

// 自定义菜单
register_nav_menus(
   array(
      'main-nav' => __( '顶部菜单' ),
	  'foot-nav' => __( '底部菜单' ),
   )

);
function default_menu() {
require get_template_directory() . '/inc/default-menu.php';
}

// 小工具
if (function_exists('register_sidebar')){
	register_sidebar( array(
		'name'          => '侧边栏',
		'id'            => 'sidebar-1',
		'description'   => '显示在左侧边栏',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
}


/* 文章图片自动添加alt和title信息
/* -------------------------------- */
function tin_image_alt($content){
	global $post;
	$pattern = "/<img(.*?)src=('|\")(.*?).(bmp|gif|jpeg|jpg|png)('|\")(.*?)>/i";
	$replacement = '<img$1src=$2$3.$4$5 alt="'.$post->post_title.'" title="'.$post->post_title.'"$6>';
	$content = preg_replace($pattern,$replacement,$content);
	return $content;
}
add_filter('the_content','tin_image_alt',15);


/* 中文名图片上传改名
/* ------------------- */
function tin_custom_upload_name($file){
	if(preg_match('/[一-龥]/u',$file['name'])):
	$ext=ltrim(strrchr($file['name'],'.'),'.');
	$file['name']=preg_replace('#^www\.#', '', strtolower($_SERVER['SERVER_NAME'])).'_'.date('Y-m-d_H-i-s').'.'.$ext;
	endif;
	return $file;
}
add_filter('wp_handle_upload_prefilter','tin_custom_upload_name',5,1);


// 去掉描述P标签
function deletehtml($description) {
	$description = trim($description);
	$description = strip_tags($description,"");
	return ($description);
}
add_filter('category_description', 'deletehtml');
add_filter('tag_description', 'deletehtml');
add_filter('term_description', 'deletehtml');
add_filter('the_excerpt', 'deletehtml');


remove_action('post_updated','wp_save_post_revision' );
 //custom widget tag cloud
 
add_filter( 'widget_tag_cloud_args', 'theme_tag_cloud_args' );
function theme_tag_cloud_args( $args ){
	$newargs = array(
		'smallest'    => 14,  //最小字号
		'largest'     => 14, //最大字号
		'unit'        => 'px',   //字号单位，可以是pt、px、em或%
		'number'      => 45,     //显示个数
		'format'      => 'flat',//列表格式，可以是flat、list或array
		'separator'   => "\n",   //分隔每一项的分隔符
		'orderby'     => 'name',//排序字段，可以是name或count
		'order'       => 'ASC', //升序或降序，ASC或DESC
		'exclude'     => null,   //结果中排除某些标签
		'include'     => null,  //结果中只包含这些标签
		'link'        => 'view' ,//taxonomy链接，view或edit
		'taxonomy'    => 'post_tag', //调用哪些分类法作为标签云
	);
	$return = array_merge( $args, $newargs);
	return $return;
}


function the_crumbs() {
	$delimiter = '>'; // 分隔符
	$before = '<span class="current">'; // 在当前链接前插入
	$after = '</span>'; // 在当前链接后插入
	if ( !is_home() && !is_front_page() || is_paged() ) {
		echo '<nav  class="crumbs"><div class="container"><div class="con">'.__( '现在位置:' , 'xs' );
		global $post;
		$homeLink = home_url();
		echo ' <a itemprop="breadcrumb" href="' . $homeLink . '">' . __( '首页' , 'xs' ) . '</a> ' . $delimiter . ' ';
		if ( is_category() ) { // 分类 存档
			global $wp_query;
			$cat_obj = $wp_query->get_queried_object();
			$thisCat = $cat_obj->term_id;
			$thisCat = get_category($thisCat);
			$parentCat = get_category($thisCat->parent);
			if ($thisCat->parent != 0){
				$cat_code = get_category_parents($parentCat, TRUE, ' ' . $delimiter . ' ');
				echo $cat_code = str_replace ('<a','<a itemprop="breadcrumb"', $cat_code );
			}
			echo $before . '' . single_cat_title('', false) . '' . $after;
		}  elseif ( is_single() ) { // 文章
			if ( get_post_type() == 'product' ) { // 自定义文章类型	
	$terms = wp_get_post_terms($post->ID, 'products', array("fields" => "all"));$termsid = $terms[0]->term_taxonomy_id;
    echo get_term_parents_list( $termsid , 'products',array( 'inclusive' => false ,'separator'=>' > ')  );
	echo get_the_term_list( $post->ID, 'products' ,'','>',' > ');
				echo '<span>正文</span>';
			} 
			if ( get_post_type() == 'forum' ) { // 自定义文章类型	

				echo get_the_title();
			} 
			if ( get_post_type() == 'topic' ) { // 自定义文章类型	

				echo get_the_title() ;
			} 
			if ( get_post_type() == 'post' ) { // 文章 post
				$cat = get_the_terms($id, 'category'); $cat = $cat[0];
				$cat_code = get_category_parents($cat, TRUE, ' ' . $delimiter . ' ');
				echo $cat_code = str_replace ('<a','<a itemprop="breadcrumb"', $cat_code );
				echo '<span>正文</span>';
			}
		}

		elseif ( is_tax() )   
		{ // 分类 存档
			    $query_obj = get_queried_object();
				// var_dump( $query_obj );
				$term_id   = $query_obj->term_id;
				$taxonomy   = $query_obj->taxonomy;
		echo get_term_parents_list( $term_id, $taxonomy,array( 'inclusive' => false ,'separator'=>' > ')  );
			echo $before . '' . single_cat_title('', false) . '' . $after;
		}
		elseif ( is_page() && !$post->post_parent ) { // 页面
			echo $before . get_the_title() . $after;
		} elseif ( is_page() && $post->post_parent ) { // 父级页面
			$parent_id  = $post->post_parent;
			$breadcrumbs = array();
			while ($parent_id) {
				$page = get_page($parent_id);
				$breadcrumbs[] = '<a itemprop="breadcrumb" href="' . get_permalink($page->ID) . '">' . get_the_title($page->ID) . '</a>';
				$parent_id  = $page->post_parent;
			}
			$breadcrumbs = array_reverse($breadcrumbs);
			foreach ($breadcrumbs as $crumb) echo $crumb . ' ' . $delimiter . ' ';
			echo $before . get_the_title() . $after;
		} elseif ( is_search() ) { // 搜索结果
			echo $before ;
			printf( __( '搜索结果是: %s', 'xs' ),  get_search_query() );
			echo  $after;
		} elseif ( is_404() ) { // 404 页面
			echo $before;
			_e( '您找的页面不存在', 'xs' );
			echo  $after;
		}
		if ( get_query_var('paged') ) { // 分页
			if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() )
				echo sprintf( __( '( 页面 %s )', 'xs' ), get_query_var('paged') );
		}
		
		echo '</div></div></nav>';
	}
}

//使WordPress支持post thumbnail
if ( function_exists( 'add_theme_support' ) ) {
    add_theme_support( 'post-thumbnails' );
}

// 禁止后台加载谷歌字体
function wp_remove_open_sans_from_wp_core() {
	wp_deregister_style( 'open-sans' );
	wp_register_style( 'open-sans', false );
	wp_enqueue_style('open-sans','');
}
add_action( 'init', 'wp_remove_open_sans_from_wp_core' );

//设置让文章内链接单独页面打开
function autoblank($text) {
	$return = str_replace('<a', '<a target="_blank"', $text);
	return $return;
}
add_filter('the_content', 'autoblank');

// 移除头部冗余代码
remove_action( 'wp_head', 'wp_generator' );// WP版本信息
remove_action( 'wp_head', 'rsd_link' );// 离线编辑器接口
remove_action( 'wp_head', 'wlwmanifest_link' );// 同上
remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0 );// 上下文章的url
remove_action( 'wp_head', 'feed_links', 2 );// 文章和评论feed
remove_action( 'wp_head', 'feed_links_extra', 3 );// 去除评论feed
remove_action( 'wp_head', 'wp_shortlink_wp_head', 10, 0 );// 短链接

// 友情链接
add_filter( 'pre_option_link_manager_enabled', '__return_true' );

    /**
* Disable the emoji's
*/
function disable_emojis() {
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
remove_action( 'admin_print_styles', 'print_emoji_styles' );
remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
add_filter( 'tiny_mce_plugins', 'disable_emojis_tinymce' );
}
add_action( 'init', 'disable_emojis' );
/**
* Filter function used to remove the tinymce emoji plugin.
*/
function disable_emojis_tinymce( $plugins ) {
if ( is_array( $plugins ) ) {
return array_diff( $plugins, array( 'wpemoji' ) );
} else {
return array();
}
}
//移除头部多余.recentcomments样式
function Fanly_remove_recentcomments_style() {
    global $wp_widget_factory;
    remove_action( 'wp_head', array( $wp_widget_factory->widgets['WP_Widget_Recent_Comments'], 'recent_comments_style' ) );
}
add_action( 'widgets_init', 'Fanly_remove_recentcomments_style' );


// 后台预览
add_editor_style( '/css/editor-style.css' );

include_once( get_stylesheet_directory() . '/acf/acf.php' );
include_once( get_stylesheet_directory() . '/inc/acf.php' );

if( function_exists('acf_add_options_page') ) {
    
    acf_add_options_page(array(
        'page_title'    => '网站设置',
        'menu_title'    => '网站设置',
        'menu_slug'     => 'theme-general-settings',
        'capability'    => 'edit_theme_options',
        'redirect'      => false
    ));
    
}

function wpdaxue_admin_bar() {
    global $wp_admin_bar;
    $wp_admin_bar->remove_menu('wp-logo'); //移除Logo
   //$wp_admin_bar->remove_menu('my-account'); //移除个人中心
    $wp_admin_bar->remove_menu('comments'); //移除评论
    $wp_admin_bar->remove_menu('my-sites');  //移除我的网站(多站点)
   // $wp_admin_bar->remove_menu('site-name'); //移除网站名称
    $wp_admin_bar->remove_menu('new-content'); // 移除“新建”
    $wp_admin_bar->remove_menu('search');  //移除搜索
    //$wp_admin_bar->remove_menu('updates'); //移除升级通知

}
add_action( 'wp_before_admin_bar_render', 'wpdaxue_admin_bar' );

function custom_dashboard_help() {
echo '
<p>
<ol><li>主题安装后，会在WP后台的左侧工具条上增加【<a href=/wp-admin/admin.php?page=theme-general-settings>网站设置</a>】选项，这是主题的核心设置，请知悉！</li>
<li>主题安装好第一件事不是去网站设置选项，而是创建好网站的<a href=/wp-admin/edit-tags.php?taxonomy=category>文章分类</a>和<a href=/wp-admin/edit.php?post_type=page>页面</a>！（已有分类和页面的老站除外）。</li>
<li>在网站设置里选择调用分类时，没有显示你的分类名？那是因为您没有新建分类！</li>
<li>通过编辑<a href=/wp-admin/edit-tags.php?taxonomy=category>分类目录</a>、<a href=/wp-admin/edit-tags.php?taxonomy=products&post_type=product>产品分类</a>，可以看到分类目录的SEO设置</li>
<li>通过<a href=/wp-admin/nav-menus.php>菜单</a>的<a href=/wp-admin/nav-menus.php?action=edit&menu=0>创建</a>功能可以创建出很多的菜单组，设置好菜单组，选择好菜单所要显示的位置！</li>
<li>通过<a href=/wp-admin/widgets.php>小工具</a>的功能可以创建出页面右侧边栏</li>
<li>最后，小兽wordpress在线QQ：<a  href="tencent://message/?uin=448696976&Menu=yes" title="QQ咨询" style="font-size: 14px;color: red;">448696976 </a>（工作日09:00-17:00在线，其他时间回复不及时见谅）更多wordpress信息请点击<a  href="http://www.seo628.com/" style="font-size: 14px;color: red;" target="_blank">小兽wordpress官网</a></li></ol>
</p>';
}
function example_add_dashboard_widgets() {
    wp_add_dashboard_widget('custom_help_widget', '小兽wordpress', 'custom_dashboard_help');
}
add_action('wp_dashboard_setup', 'example_add_dashboard_widgets' );

//删除仪表盘模块
function example_remove_dashboard_widgets() {
    // Globalize the metaboxes array, this holds all the widgets for wp-admin
    global $wp_meta_boxes;
    // 以下这一行代码将删除 "快速发布" 模块
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_quick_press']);
    // 以下这一行代码将删除 "引入链接" 模块
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_incoming_links']);
    // 以下这一行代码将删除 "插件" 模块
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_plugins']);
    // 以下这一行代码将删除 "近期评论" 模块
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_recent_comments']);
    // 以下这一行代码将删除 "近期草稿" 模块
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_recent_drafts']);
    // 以下这一行代码将删除 "WordPress 开发日志" 模块
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_primary']);
    // 以下这一行代码将删除 "其它 WordPress 新闻" 模块
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_secondary']);
    // 以下这一行代码将删除 "概况" 模块
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_right_now']);
}
add_action('wp_dashboard_setup', 'example_remove_dashboard_widgets' );
remove_action('welcome_panel', 'wp_welcome_panel');

function remove_dashboard_meta() {
        remove_meta_box( 'dashboard_activity', 'dashboard', 'normal');//3.8版开始
}
add_action( 'admin_init', 'remove_dashboard_meta' );


function change_post_menu_label() {
    global $menu;
    $menu[2][0] = '帮助中心';
}
function change_post_object_label() {
    
}
add_action( 'init', 'change_post_object_label' );
add_action( 'admin_menu', 'change_post_menu_label' );

function shapeSpace_screen_layout_columns($columns) {
    $columns['dashboard'] = 1;
    return $columns;
}
add_filter('screen_layout_columns', 'shapeSpace_screen_layout_columns');
function shapeSpace_screen_layout_dashboard() { return 1; }
add_filter('get_user_option_screen_layout_dashboard', 'shapeSpace_screen_layout_dashboard');

function remove_submenus() {
  global $submenu;
  unset($submenu['index.php'][10]); // Removes 'Updates'.
    remove_menu_page( 'edit.php?post_type=acf-field-group' );
}
add_action('admin_menu', 'remove_submenus');

?>