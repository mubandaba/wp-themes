<section id="footer" class="p30">

<div class="container">

<div class="footer-top clearfix">

<div class="copyr">
<div class="footer-menu clearfix mb10">
<?php wp_nav_menu( array( 'theme_location' => 'foot-nav', 'menu_class' => 'footer-menu-con', 'container'=>'','fallback_cb' => 'default_menu') ); ?>
</div>
<p>Copyright © <?php the_time('Y');?> <a href="<?php bloginfo('url')?>"><?php bloginfo('name')?></a> All Rights Reserved &nbsp;&nbsp;<a target="_blank" href="http://www.miibeian.gov.cn/" rel="nofollow"><?php the_field('btm-icp','option') ?></a><?php the_field('tjgj','option') ?>&nbsp;&nbsp;<a href="<?php bloginfo("url");?>/sitemap.xml" target="_blank">网站地图</a></p>
</div>
<div class="btm-search">
<form method="get" action="<?php bloginfo('url'); ?>" >
<input type="text" name="s" class="text" autocomplete="off"  placeholder="<?php _e('输入搜索内容','xs')?>">
<button class="btn-search"> <i class="fa fa-search"></i></button>
</form>
</div>
</div>
<?php if ( is_front_page() ) { ?><div class="link mt10"><ul><?php wp_list_bookmarks('title_li=&categorize=0'); ?></ul></div><?php } ?>
</div>

</section>
<?php wp_footer(); ?>
<?php if ( is_singular() ){ ?>
<!-- Baidu Button BEGIN -->
<script>
window._bd_share_config = {
    "common": {
        "bdSnsKey": {},
        "bdText": "",
        "bdMini": "2",
        "bdMiniList": false,
        "bdPic": "",
        "bdStyle": "0",
        "bdSize": "14"
    },
    "share": {}
};
with(document) 0[(getElementsByTagName('head')[0] || body).appendChild(createElement('script')).src = 'http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion=' + ~ ( - new Date() / 36e5)];
</script>
<!-- Baidu Button END -->
<?php } ?>
<div class="right_bar"> 
<ul> 
<li class="rtbar_li1" style="left: 0px;"> <a href="tel:<?php the_field('mini','option')?>"> <img src="<?php bloginfo('template_url');?>/images/rtbar_liicon3.png"><?php the_field('mini','option')?></a> </li> 
<li class="rtbar_li2"> <a href="javascript:void(0);"> <img src="<?php bloginfo('template_url');?>/images/rtbar_liicon4.png"> </a> 
<div class="rtbar_shwx" style="display: none;"> 
<img width="188" height="188" alt="公众账号" src="<?php if( get_field('wechat','option') ): ?><?php the_field('wechat','option') ?><?php else :?><?php bloginfo('template_url');?>/images/wechat.png<?php endif;?>"> 
</div> </li> 
<li class="rtbar_li3" style="left: 0px;"> <a href="tencent://message/?uin=<?php the_field('qq','option')?>&amp;Menu=yes"> <img src="<?php bloginfo('template_url');?>/images/rtbar_liicon2.png"> 点击咨询 </a> </li> 
<li class="rtbar_li4 gotop"> <a href=""> <img src="<?php bloginfo('template_url');?>/images/rtbar_liicon1.png"> </a></li> 
</ul> 
</div>
<script>
(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') {
        bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
    }
    else {
        bp.src = 'http://push.zhanzhang.baidu.com/push.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
</script>
</body>
</html>