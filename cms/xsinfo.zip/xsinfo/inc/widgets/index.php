<?php  
$currentDir = dirname(__FILE__);
include $currentDir . '/rand-post.php';
include $currentDir . '/hot-post.php';
?>