<?php
/**
 * The template for displaying all single comic posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Toocheke
 */
get_header();
get_template_part('template-parts/content', 'indexsingleseries');
get_sidebar();
get_footer();

