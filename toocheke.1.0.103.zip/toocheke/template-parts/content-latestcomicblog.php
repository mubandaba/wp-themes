<?php
/**
 * Template part for displaying single comic collection
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Toocheke
 */
$comic_order = get_option('toocheke-comics-order') ? get_option('toocheke-comics-order') : 'DESC';
$series_id = null;
if ('series' === get_post_type()) {
    $series_id = get_the_ID();
}

?>
<!-- START LATEST COMIC BLOG POST-->
                  <?php
$single_comics_args = array(
    'post_parent' => $series_id,
    'post_type' => 'comic',
    'post_status' => 'publish',
    'posts_per_page' => 1,
    'orderby' => 'post_date',
    'order' => $comic_order,
);
$single_comic_query = new WP_Query($single_comics_args);
/* Start the Loop */
while ($single_comic_query->have_posts()): $single_comic_query->the_post();

    ?>
			    	<header class="entry-header">
					<?php
    if (is_singular('comic')):
        the_title('<h1 class="entry-title">', '</h1>');
    else:
        the_title('<h2 class="entry-title"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h2>');
    endif;

    ?>
						<div class="entry-meta">
							<?php
    toocheke_posted_on();
    toocheke_posted_by();
    ?>
						</div><!-- .entry-meta -->

				</header><!-- .entry-header -->
			              <article class="post type-post ">

			                       <?php
    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo get_post_meta($post->ID, 'comic_blog_post_editor', true);
    ?>
			                     </article>

				                <?php

endwhile;

wp_reset_postdata();
?>


                   <!-- END LATEST COMIC BLOG POST-->



