<?php
/**
 * Template part for displaying list of comics
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Toocheke
 */

?>
<div id="comic" class="single-comic-wrapper">
<?php
$comic_layout = get_option('toocheke-comic-layout-devices');
$wrapper_id = $comic_layout === '1' ? 'two-comic-options' : 'one-comic-option';
echo '<div id="'. esc_attr( $wrapper_id ). '">';
echo '<div id="spliced-comic">';
 the_content( ) ;
 echo '</div>';
echo '<div id="unspliced-comic">';
$allowed_tags = array(
    'img' => array(
          'src' => array(),
          'alt' => array(),
          'width' => array(),
          'height' => array(),
          'class' => array()
    )
 );
 echo wp_kses(get_post_meta( $post->ID, 'desktop_comic_editor', true ), $allowed_tags);

 echo '</div>';
echo '</div>';

?>
</div>