<?php
/**
 * The template for displaying all single comic posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Toocheke
 */
$home_layout = get_theme_mod('home_layout_setting', 'default');
$collection_id = isset($_GET['col']) ? (int) $_GET['col'] : 0;
set_query_var('collection_id', $collection_id);
'default' === $home_layout || 'alt-3' === $home_layout || 'alt-5' === $home_layout ? get_header('comics') : get_header();
?>
<?php
if ('default' === $home_layout || 'alt-3' === $home_layout || 'alt-5' === $home_layout):
?>
<div class="row">
            <div class="col-lg-12">
               <div id="comic">
					 <?php
while (have_posts()):
    the_post();

    get_template_part('template-parts/content', get_post_type());
    ?>
							<b><?php esc_html_e('Published On:', 'toocheke');?></b>
							<?php
    the_date();

    toocheke_load_comic_carousel($collection_id);

    // If comments are open or we have at least one comment, load up the comment template.
    if (comments_open() || get_comments_number()):
        comments_template();
    endif;

endwhile; // End of the loop.
?>

</div>
            </div>
		 </div>
		 <?php
else:
?>
		 <div id="inner-content-row" class="row">
<div id="inner-content" class="col-lg-12">
               <div id="comic" class="single-comic-wrapper">
					 <?php
while (have_posts()):
    the_post();
    get_template_part('template-parts/content', get_post_type());
    get_template_part('template-parts/content', 'comicnavigation');
    if ($home_layout == 'alt-1' || $home_layout == 'alt-4') {
        ?>
			              <div class="blog-wrapper">
			              <header class="entry-header">
						<?php
    if (is_singular('comic')):
            the_title('<h1 class="entry-title">', '</h1>');
        else:
            the_title('<h2 class="entry-title"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h2>');
        endif;

        ?>
							<div class="entry-meta">
								<?php
    toocheke_posted_on();
        toocheke_posted_by();
        ?>
							</div><!-- .entry-meta -->

					</header><!-- .entry-header -->
			              <article class="post type-post ">

			                       <?php
    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo get_post_meta($post->ID, 'comic_blog_post_editor', true);
        ?>
			                     </article>
			              </div>
			        <?php
    }
    ?>

							<?php

    // If comments are open or we have at least one comment, load up the comment template.
    if (comments_open() || get_comments_number()):
        comments_template();
    endif;

endwhile; // End of the loop.
wp_reset_postdata();
?>

</div>
            </div>

		 <?php
endif;
?>
<?php
'default' === $home_layout || 'alt-3' === $home_layout || 'alt-5' === $home_layout ? get_footer('comics') : get_footer();
