<?php
/**
 * Toocheke functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Toocheke
 */

if( ! defined( 'ABSPATH' ) ) exit;


/**
 * Toocheke Functions
 *
 * @since Toocheke v1.0.15
 */
 //Load theme functions
 require_once get_template_directory() . '/inc/toocheke-functions.php';
 /**
  * Note: Do not add any custom code here. Please use a child theme so that your customizations aren't lost during updates.
  * http://codex.wordpress.org/Child_Themes
  */












