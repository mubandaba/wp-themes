<?php
/*导入主题后台设置*/
include_once 'option/setThemes.php';
/*导入短代码*/
include_once 'inc/shortcode.php';
/*导入小工具*/
include_once 'inc/widget.php';

function dopt($e){
    return stripslashes(get_option($e));
}
/*文章自动定时*/
function my_script(){
	if(is_admin()){
		wp_enqueue_script( 'setTime', get_bloginfo('template_url').'/js/setTime.js', array(), 'lastest', false );
	}
}
add_action('init', 'my_script');

/*小工具*/
if( function_exists('register_sidebar') ) {
	register_sidebar(array(
		'name' => '侧边',
		'before_widget' => '<div class="widget"><div class="widget-con">', // widget 的开始标签
		'after_widget' => '</div></div>', // widget 的结束标签
		'before_title' => '<h3 class="widget-title">', // 标题的开始标签
		'after_title' => '</h3>' // 标题的结束标签
	));
	register_sidebar(array(
		'name' => '内页侧边',
		'before_widget' => '<div class="widget"><div class="widget-con">', // widget 的开始标签
		'after_widget' => '</div></div>', // widget 的结束标签
		'before_title' => '<h3 class="widget-title">', // 标题的开始标签
		'after_title' => '</h3>' // 标题的结束标签
	));
	register_sidebar(array(
		'name' => '友情链接',
		'before_widget' => '<div class="widget blogroll"><div class="widget-con">', // widget 的开始标签
		'after_widget' => '</div></div>', // widget 的结束标签
		'before_title' => '<h3 class="widget-title">', // 标题的开始标签
		'after_title' => '</h3>' // 标题的结束标签
	));
}

/*自定义菜单*/
register_nav_menus(
	array(
	'top_left' => __( '顶部左菜单' ),
	'nav_left' => __( '导航栏-左' ),
	'nav_right' => __( '导航栏-右' ),
	'nav_footer' => __( '底部菜单' )
	)
);

/*-----------------------------------------*\
    获取第一张图片地址
\*-----------------------------------------*/
function get_the_img() {
  global $post, $posts;
  $first_img = '';
  ob_start();
  ob_end_clean();
  $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
  $first_img = $matches [1] [0];

  return $first_img;
}
/*-----------------------------------------*\
    输出第一张图片
\*-----------------------------------------*/
function the_img(){
  $imgurl = get_the_img();
  if(empty($imgurl)){
    echo '<img src="'.get_bloginfo('template_url').'/images/default.png" alt="" />';
  }else{
    echo '<img src="'.$imgurl.'" alt="" />';  
  }
}

/*缩略图功能*/
function post_thumbnail( $width = 100,$height = 80 ){
    global $post;
    if( has_post_thumbnail() ){    //如果有缩略图，则显示缩略图
        $timthumb_src = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
        $post_timthumb = '<img src="'.get_bloginfo("template_url").'/timthumb.php?src='.$timthumb_src[0].'&amp;h='.$height.'&amp;w='.$width.'&amp;zc=1" alt="'.$post->post_title.'" class="thumb" />';
        echo $post_timthumb;
    } else {
        $post_timthumb = '';
        ob_start();
        ob_end_clean();
        $output = preg_match('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $index_matches);    //获取日志中第一张图片
        $first_img_src = $index_matches [1];    //获取该图片 src
        if( !empty($first_img_src) ){    //如果日志中有图片
            $path_parts = pathinfo($first_img_src);    //获取图片 src 信息
            $first_img_name = $path_parts["basename"];    //获取图片名
            $first_img_pic = get_bloginfo('wpurl'). '/cache/'.$first_img_name;    //文件所在地址
            $first_img_file = ABSPATH. 'cache/'.$first_img_name;    //保存地址
            $expired = 604800;    //过期时间
            if ( !is_file($first_img_file) || (time() - filemtime($first_img_file)) > $expired ){
                copy($first_img_src, $first_img_file);    //远程获取图片保存于本地
                $post_timthumb = '<img src="'.$first_img_src.'" alt="'.$post->post_title.'" class="thumb" />';    //保存时用原图显示
            }
            $post_timthumb = '<img src="'.get_bloginfo("template_url").'/timthumb.php?src='.$first_img_pic.'&amp;h='.$height.'&amp;w='.$width.'&amp;zc=1" alt="'.$post->post_title.'" class="thumb" />';
        } else {    //如果日志中没有图片，则显示默认
            $post_timthumb = '<img src="'.get_bloginfo("template_url").'/images/default.png" alt="'.$post->post_title.'" class="thumb" />';
        }
        echo $post_timthumb;
    }
}
 
// 文章形式
add_theme_support( 'post-formats', array('status','image','quote','video','audio') );
// 链接自动识别播放
function auto_player_urls($c) {
    $s = array('/^(http:\/\/.*\.mp3)$/m' => '<embed class="mp3_player" src="'.get_bloginfo("template_url").'/mp3_player.swf?audio_file=$1&amp;color=ffffff" width="207" height="30" type="application/x-shockwave-flash"></embed></p>',
    '/^(http:\/\/www.xiami.com.*\.swf)$/m' => '<p><embed class="swf_player" src="$1" width="258" height="33" type="application/x-shockwave-flash" wmode="transparent"></embed></p>',
	'/^(http:\/\/box.baidu.com.*)$/m' => '<p><embed class="swf_player" src="$1" width="500" height="80" type="application/x-shockwave-flash" wmode="transparent"></embed></p>',
	'/^(http:\/\/.*\.swf)$/m' => '<p><embed class="swf_player" src="$1" width="640" height="480" type="application/x-shockwave-flash" wmode="transparent"></embed></p>');
    foreach($s as $p => $r){
        $c = preg_replace($p,$r,$c);
    }
    return $c;
}
add_filter( 'the_content', 'auto_player_urls' );


//自定义评论结构
function mytheme_comment($comment, $args, $depth) {
   $GLOBALS['comment'] = $comment;
   global $commentcount;
   if(!$commentcount) {
	   $page = ( !empty($in_comment_loop) ) ? get_query_var('cpage')-1 : get_page_of_comment( $comment->comment_ID, $args )-1;
	   $cpp=get_option('comments_per_page');
	   $commentcount = $cpp * $page;
	}
?>
   <li <?php comment_class(); ?> id="li-comment-<?php comment_ID() ?>">
		<div id="comment-<?php comment_ID(); ?>" class="comment-body">
			<div class="comment-author"><?php echo get_avatar( $comment, $size = '36'); ?></div>
			<div class="comment-head">
				<span class="name"><?php printf(__('%s'), get_comment_author_link()) ?></span>
				<span class="date"><?php if(!$parent_id = $comment->comment_parent) {printf(__('%1$s %2$s'), get_comment_date('Y-n-j'),  get_comment_time('H:i'));} ?> <?php if(!$parent_id = $comment->comment_parent) {printf('#%1$s', ++$commentcount);} ?></span>
				<span class="comment-entry"><?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth'], 'reply_text' => __('回复TA')))) ?></span>
			</div>
			<div class="comment-text"><?php comment_text() ?></div>
     </div>
<?php
}
//面包屑
function the_breadcrumb() { 
  $delimiter = '&raquo;';
  $name = '首页'; //text for the 'Home' link
  $currentBefore = '<span>';
  $currentAfter = '</span>';
 
  if ( !is_home() && !is_front_page() || is_paged() ) {
 
    echo '<div class="breadcrumb">';
 
    global $post;
    $home = get_bloginfo('url');
    echo '' . $name . ' ' . $delimiter . ' ';
 
    if ( is_category() ) {
      global $wp_query;
      $cat_obj = $wp_query->get_queried_object();
      $thisCat = $cat_obj->term_id;
      $thisCat = get_category($thisCat);
      $parentCat = get_category($thisCat->parent);
      if ($thisCat->parent != 0) echo(get_category_parents($parentCat, TRUE, ' ' . $delimiter . ' '));
      echo $currentBefore;
      single_cat_title();
      echo $currentAfter;
 
    } elseif ( is_day() ) {
      echo '' . get_the_time('Y') . ' ' . $delimiter . ' ';
      echo '' . get_the_time('F') . ' ' . $delimiter . ' ';
      echo $currentBefore . get_the_time('d') . $currentAfter;
 
    } elseif ( is_month() ) {
      echo '' . get_the_time('Y') . ' ' . $delimiter . ' ';
      echo $currentBefore . get_the_time('F') . $currentAfter;
 
    } elseif ( is_year() ) {
      echo $currentBefore . get_the_time('Y') . $currentAfter;
 
    } elseif ( is_single() ) {
      $cat = get_the_category(); $cat = $cat[0];
      echo get_category_parents($cat, TRUE, ' ' . $delimiter . ' ');
      echo $currentBefore;
      the_title();
      echo $currentAfter;
 
    } elseif ( is_page() && !$post->post_parent ) {
      echo $currentBefore;
      the_title();
      echo $currentAfter;
 
    } elseif ( is_page() && $post->post_parent ) {
      $parent_id  = $post->post_parent;
      $breadcrumbs = array();
      while ($parent_id) {
        $page = get_page($parent_id);
        $breadcrumbs[] = '' . get_the_title($page->ID) . '';
        $parent_id  = $page->post_parent;
      }
      $breadcrumbs = array_reverse($breadcrumbs);
      foreach ($breadcrumbs as $crumb) echo $crumb . ' ' . $delimiter . ' ';
      echo $currentBefore;
      the_title();
      echo $currentAfter;
 
    } elseif ( is_search() ) {
      echo $currentBefore . '搜索：“' . get_search_query() . '”' . $currentAfter.'的结果';
 
    } elseif ( is_tag() ) {
      echo $currentBefore . '标签：“';
      single_tag_title();
      echo '”' . $currentAfter.'中的文章';
 
    } elseif ( is_author() ) {
       global $author;
      $userdata = get_userdata($author);
      echo $currentBefore . 'Articles posted by ' . $userdata->display_name . $currentAfter;
 
    } elseif ( is_404() ) {
      echo $currentBefore . 'Error 404' . $currentAfter;
    }
 
    if ( get_query_var('paged') ) {
      if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ' (';
      echo __('Page') . ' ' . get_query_var('paged');
      if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ')';
    }
 
    echo '</div>';
 
  }
}

// 浏览量统计
function getPostViews($postID){
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return "0";
    }
    return $count;
}
function setPostViews($postID) {
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
       $count++;
        update_post_meta($postID, $count_key, $count);
    }
}
function the_view(){
	echo getPostViews(get_the_ID());
	if(is_single()){	
		setPostViews(get_the_ID());
	}
}



// 文章存档函数
 function Rcloud_archives_list() {
     if( !$output = get_option('Rcloud_archives_list') ){
         $output = '<div id="archives"><p>[<a id="al_expand_collapse" href="#">全部展开/收缩</a>] <em>(注: 点击月份可以展开)</em></p>';
         $the_query = new WP_Query( 'posts_per_page=-1&ignore_sticky_posts=1' ); //update: 加上忽略置顶文章
         $year=0; $mon=0; $i=0; $j=0;
         while ( $the_query->have_posts() ) : $the_query->the_post();
             $year_tmp = get_the_time('Y');
             $mon_tmp = get_the_time('m');
             $y=$year; $m=$mon;
             if ($mon != $mon_tmp && $mon > 0) $output .= '</ul></li>';
             if ($year != $year_tmp && $year > 0) $output .= '</ul>';
             if ($year != $year_tmp) {
                 $year = $year_tmp;
                 $output .= '<h3 class="al_year">'. $year .' 年</h3><ul class="al_mon_list">'; //输出年份
             }
             if ($mon != $mon_tmp) {
                 $mon = $mon_tmp;
                 $output .= '<li><span class="al_mon">'. $mon .' 月</span><ul class="al_post_list">'; //输出月份
             }
             $output .= '<li>'. get_the_time('d日: ') .'<a class="archivesPostList" href="'. get_permalink() .'">'. get_the_title() .'</a> <em>('. get_comments_number('0', '1', '%') .')</em></li>'; //输出文章日期和标题
         endwhile;
         wp_reset_postdata();
         $output .= '</ul></li></ul></div>';
         update_option('Rcloud_archives_list', $output);
     }
     echo $output;
 }
 function clear_zal_cache() {
     update_option('Rcloud_archives_list', ''); // 清空 存档
 }
 add_action('save_post', 'clear_zal_cache'); // 新发表文章/修改文章时

?>