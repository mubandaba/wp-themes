<?php get_header(); ?>
<div id="content"><div class="wrap">
	<div id="single">
		<style>
			.part.single-404{ padding: 100px 0; }
			h1.single-404{ text-align: center; line-height: 100px; font-size: 100px; }
			p.single-404{ text-align: center; color: #f00; }
		</style>
		<div class="part single-404">
			<h1 class="single-404">404</h1>
			<p class="single-404">这个页面不存在哦，也许在火星找得到</p>
		</div>
	</div>
	<?php get_sidebar(); ?>
	<div class="cc"></div>
</div></div>
<?php get_footer(); ?>