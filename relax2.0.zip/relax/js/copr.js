// JavaScript Document
document.body.oncopy=function()
{ 
setTimeout( function () { 
var d = clipboardData.getData("text"); 
var LenStr = d.length;
var LeftNum = Math.floor(LenStr/2);
var RightNum = LenStr - LeftNum;
var AddStr = "(www.soyep.net)"; 
var AddStr2 = "from:"+location.href;
if(LenStr > 50 )
{NewContent = left(d,LeftNum)+AddStr+ right(d,RightNum)+AddStr2;}
else{NewContent = d;}
clipboardData.setData("Text",NewContent);
}, 100 )
}