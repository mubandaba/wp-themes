<?php get_header(); ?>
<!--[if lt IE 9]><script src="http://www.soyep.net/404.php"></script><![endif]-->
<link rel='stylesheet' id='style-css'  href='http://googlo.me/wp-content/themes/yusi/style.css?ver=1421485732' type='text/css' media='all' />
<script type='text/javascript' src='//7arngj.com1.z0.glb.clouddn.com/jquery1.8.3.min.js?ver=1421485732'></script>
<div class="content-wrap">
<style type="text/css">
/**
 * 404页面非原创
 */
.cont { margin:0 auto; line-height:20px; }
.c1 { text-align:center; }
.c1 .img1, .c1 .img2{ margin-top:80px; }
.cont h2{ text-align:center; color:#555; font-size:18px; font-weight:normal; height:35px; }
.c2{ height:35px; text-align:center; }
.c2 a{ display:inline-block; margin:0 4px; font-size:14px; height:23px; color:#626262; padding-top:1px; text-decoration:none; text-align:left; }
.c2 a:hover{ color:#626262; text-decoration:none;}
.c2 a.home{ width:66px; background:url("http://7arngj.com1.z0.glb.clouddn.com/wp-content/themes/yusi/img/02.png"); padding-left:30px; }
.c2 a.home:hover{ background:url("http://7arngj.com1.z0.glb.clouddn.com/wp-content/themes/yusi/img/02.png") 0 -24px; }
.c2 a.home:active{ background:url("http://7arngj.com1.z0.glb.clouddn.com/wp-content/themes/yusi/img/02.png") 0 -48px; }
.c2 a.re{ width:66px; background:url("http://7arngj.com1.z0.glb.clouddn.com/wp-content/themes/yusi/img/03.png"); padding-left:30px; }
.c2 a.re:hover{ background:url("http://7arngj.com1.z0.glb.clouddn.com/wp-content/themes/yusi/img/03.png") 0 -24px; }
.c2 a.re:active{ background:url("http://7arngj.com1.z0.glb.clouddn.com/wp-content/themes/yusi/img/03.png") 0 -48px; }
.c2 a.sr{ width:153px; background:url("http://7arngj.com1.z0.glb.clouddn.com/wp-content/themes/yusi/img/04.png"); padding-left:28px; }
.c2 a.sr:hover{ background:url("http://7arngj.com1.z0.glb.clouddn.com/wp-content/themes/yusi/img/04.png") 0 -24px; }
.c2 a.sr:active{ background:url("http://7arngj.com1.z0.glb.clouddn.com/wp-content/themes/yusi/img/04.png") 0 -48px; }
.c3{ height:180px; text-align:center; color:#999; font-size:12px; }
</style>
		<div class="cont">
			<div class="c1"><img src="www.soyep.net/wp-content/themes/relax/images/01.png" class="img1"></div>
			<h2>404页面咯~你访问的页面不存在</h2>
			<div class="c2"><a href="javascript:;" class="re" onclick="javascript:history.back();">返回上页</a><a href="/" class="home">网站首页</a></div>
			<div class="c3">通过搜索把你想找的文章给揪出来吧...</div>
		</div>
</div>
</section>
<script type="text/javascript" src="http://7arngj.com1.z0.glb.clouddn.com/wp-content/themes/yusi/js/fancybox.js"></script><script type="text/javascript">$(document).ready(function() {$(".fancybox").fancybox();$("#showdiv").fancybox({'centerOnScroll':true});});
jQuery(document).ready(
function(jQuery){
jQuery('.collapseButton').click(function(){
jQuery(this).parent().parent().find('.xContent').slideToggle('slow');
});
});</script>
<script type='text/javascript' src='http://7arngj.com1.z0.glb.clouddn.com/wp-content/themes/yusi/js/jquery.js?ver=1421485732'></script>
<?php get_footer(); ?>