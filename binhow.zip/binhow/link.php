<?php
/*
Template Name: Link
*/
?>
<?php get_header(); ?>
<div id="content">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<script type="text/javascript">
jQuery(document).ready(function($){
$(".weisaylink a").each(function(e){
	$(this).prepend("<img src=http://www.google.com/s2/favicons?domain="+this.href.replace(/^(http:\/\/[^\/]+).*$/, '$1').replace( 'http://', '' )+" style=float:left;padding:5px;>");
}); 
});
</script>
<div id="map">
<div class="site">当前位置：<a href="<?php bloginfo('siteurl'); ?>/" title="返回首页">首页</a> > <?php the_title(); ?></div>
</div><div class="main">
<div class="article article_c">
<div class="weisaylink"><ul>
<?php wp_list_bookmarks('orderby=id&category_orderby=id'); ?></ul>
</div>
<div class="clear"></div>
<div class="linkstandard">
<h3>链接申请细则：</h3><ul>
<li>一、在您申请本站友情链接之前请先做好本站链接，否则不会通过，谢谢</li>
<li>二、如果您的站还未被baidu或google收录，申请链接暂不予受理</li>
<li>三、本站链接名称：<a href="<?php bloginfo('siteurl'); ?>/"><?php bloginfo('name'); ?></a></li>
<li>四、本站链接地址：<a href="<?php bloginfo('siteurl'); ?>/"><?php bloginfo('siteurl'); ?>/</a></li>
<li>做好本站链接后请在这下面，我们会在24小时之内添加上你的链接</li></ul>
</div>

</div>


<div class="article article_c article_b">
<?php comments_template(); ?>
</div>

	<?php endwhile; else: ?>
	<?php endif; ?></div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>