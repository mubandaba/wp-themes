<?php echo '<div class="thumbnail_box">
<div class="thumbnail">
';if ( get_post_meta($post->
    ID,'medium',true) ) : ;echo ' ';$image = get_post_meta($post->ID,'medium',true);;echo
    '
    <a href="';the_permalink() ;echo '" rel="bookmark" title="';the_title_attribute();;echo '">
        <img src="';echo $image;;echo '" alt="';the_title_attribute();;echo '" />
    </a>
    ';else: ;echo '
    </div>
    <!-- 截图 -->
    <div class="thumbnail">
        <a href="';the_permalink() ;echo '" rel="bookmark" title="';the_title_attribute();;echo '">
            ';if (has_post_thumbnail()) {the_post_thumbnail('medium');} else {;echo
            '
            <img class="home-thumb" src="';echo catch_first_image() ;echo '" alt="';the_title_attribute();;echo '"
            width="300" height="155" />
            ';};echo '
        </a>
        ';endif;;echo '
    </div>
    </div>
    '; ?>