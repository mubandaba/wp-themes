<?php
echo '<script type="text/javascript" src="';bloginfo('template_directory');;echo '/js/lazyload.js"></script>
<script type="text/javascript">
	jQuery(function() {          
    	jQuery(".article img, .articles img").not("#respond_box img").lazyload({
        	placeholder:"';bloginfo('template_url');;echo '/images/image-pending.gif",
            effect:"fadeIn"
          });
    	});
</script>';
?>