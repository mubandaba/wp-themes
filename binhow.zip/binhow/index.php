<?php
 get_header();;echo '<div id="content">
<div id="map">
<div class="site">
站点公告：<span>';echo get_option('binhow_announce');;echo '</span></div>
<!-- Baidu Button BEGIN -->
    <div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare">
        <a class="bds_tsina"></a>
        <a class="bds_tqq"></a>
        <a class="bds_tsohu"></a>
        <a class="bds_t163"></a>
        <a class="bds_tfh"></a>
        <a class="bds_tuita"></a>
        <a class="bds_baidu"></a>
        <span class="bds_more"></span>
    </div>
<script type="text/javascript" id="bdshare_js" data="type=tools" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
	document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + new Date().getHours();
</script>
<!-- Baidu Button END -->
</div>
<div class="main"><div class="slider">'
;if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('首页inter-top') ) :
; endif;
;echo '</div>'
;if(have_posts()):;while(have_posts()):the_post();;echo '<ul class="post1">
		<li>
		<div class="article">'
;include(TEMPLATEPATH . '/includes/articlepic.php');
		;echo'<h2><a href="'
;the_permalink() 
;echo '" rel="bookmark" title="'
;the_title_attribute();
;echo'">'
;echo mb_strimwidth(get_the_title(), 0, 32, '...'); ;
;echo '</a>'
;echo '</h2>'
;echo'<div class="info1">'
;echo '分类：';the_category(', ')
;echo ' &nbsp; 日期：';the_time('m-d')
;echo'</div>'
;echo'<div class="entry_post"><p>'
;echo mb_strimwidth(strip_tags(apply_filters('the_content($csseaser=true)',$post->
    post_content)),0,150,'...');;echo '
    </p>
    </div>
    <div class="clear">
    </div>
    <div class="info">';if(function_exists('the_ratings')) { ;echo expand_ratings_template('<span>%RATINGS_IMAGES%</span>', get_the_ID()); };echo'围观：'
	;echo getPostViews(get_the_ID());;echo'+';echo ' | ';comments_popup_link ('抢沙发','1条评论','%条评论');;echo '
    </div>
    </div>
    </li>
    </ul>
		';endwhile;;echo '		';endif;;echo ' 
	<div class="clear"></div>
<div class="navigation">';pagination($query_string);;echo '</div>
</div>
';get_sidebar();;echo '<div class="clear"></div>
';get_footer()
?>