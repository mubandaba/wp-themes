<?php
 get_header();;echo '<div id="content">

<div id="map">
<div class="site">当前位置：<a href="';bloginfo('siteurl');;echo '/" title="返回首页">首页</a> > “';echo $s;;echo '”的搜索结果</div>
</div><div class="main">
';if (have_posts()) : ;echo '	';while (have_posts()) : the_post();;echo '<div class="article article_c">
<h2><a href="';the_permalink() ;echo '" rel="bookmark" title="详细阅读 ';the_title_attribute();;echo '">';the_title();;echo '</a><span class="new">';include('includes/new.php');;echo '</span></h2>
';if (get_option('swt_thumbnail') == 'Display') {;echo '        ';if (get_option('swt_articlepic') == 'Display') {;echo '';include('includes/articlepic.php');;echo '    ';{echo '';};echo '			';}else {include(TEMPLATEPATH .'/includes/thumbnail.php');};echo '';{echo '';};echo '';}else {};echo '<div class="entry_post"><p>';echo mb_strimwidth(strip_tags(apply_filters('the_content',$post->post_content)),0,365,'...');;echo '</p>
</div>
<div class="clear"></div>
<div class="info">';the_time('Y年m月d日') ;echo ' | 分类：';the_category(', ') ;echo ' | ';if(function_exists('the_views')) {print '被围观 ';the_views();};echo ' | ';comments_popup_link ('抢沙发','1条评论','%条评论');;echo ' | 关键词：';the_tags('',',','');;echo '</div>
<div class="more"><a style="width: 30px; overflow: hidden;" class="read-more-icon" href="';the_permalink() ;echo '" title="详细阅读：';the_title_attribute();;echo '" rel="bookmark"><strong>Read more</strong><span></span></a></div></div></li></ul><div class="clear"></div>
		';endwhile;else: ;echo '<div class="article article_c">
<h3 class="center">非常抱歉，无法搜索到与之相匹配的信息。</h3>
</div>
		';endif;;echo ' 
<div class="navigation">';pagination($query_string);;echo '</div>
</div>
';get_sidebar();;echo '';get_footer();
?>