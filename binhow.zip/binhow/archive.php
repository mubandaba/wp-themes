<?php get_header();;echo '<div id="content">

<div id="map">
<div class="site">
';if ( is_category() ) {;echo '当前位置：<a href="';bloginfo( 'siteurl');;echo
'/" title="返回首页">首页</a> > ';echo get_category_parents( get_query_var( 'cat') ,true , ' > ');;echo
'文章';};echo '';if ( is_month() ) {;echo '当前位置：<a href="';bloginfo(
'siteurl');;echo '/" title="返回首页">首页</a> > ';the_time( 'Y, F');;echo '';};echo
'';if (function_exists( 'is_tag')) {if ( is_tag() ) {;echo
'当前位置：<a href="';bloginfo( 'siteurl');;echo '/" title="返回首页">首页</a> > 标签 > ';single_tag_title();;echo
'';};echo '';if ( is_day() ) {;echo '当前位置：<a href="';bloginfo( 'siteurl');;echo
'/" title="返回首页">首页</a> > ';the_time( 'Y, F jS');;echo '';};echo '';if ( is_year() ) {;echo
'当前位置：<a href="';bloginfo( 'siteurl');;echo '/" title="返回首页">首页</a> > ';the_time( 'Y');;echo
'';};echo '';if ( is_author() ) {;echo '当前位置：<a href="';bloginfo(
'siteurl');;echo '/" title="返回首页">首页</a> > 作者文章列表';};echo '';if ( isset($_GET[
'paged']) &&!empty($_GET[ 'paged'])) {;echo '当前位置：<a href="';bloginfo(
'siteurl');;echo '/" title="返回首页">首页</a> > 存档';};echo '';};echo '</div>
</div><div class="main">'
;if (have_posts()) : 
;echo '	'
;while (have_posts()) : the_post();
;echo '<ul class="post1">
		<li>
		<div class="article">'
;include(TEMPLATEPATH . '/includes/articlepic.php');
		;echo'<h2><a href="'
;the_permalink() 
;echo '" rel="bookmark" title="'
;the_title_attribute();
;echo'">'
;echo mb_strimwidth(get_the_title(), 0, 32, '...'); ;
;echo '</a>'
;echo '</h2>'
;echo'<div class="info1">'
;echo '分类：';the_category(', ')
;echo ' &nbsp; 日期：';the_time('m-d')
;echo'</div>'
;echo'<div class="entry_post"><p>'
;echo mb_strimwidth(strip_tags(apply_filters('the_content($csseaser=true)',$post->
    post_content)),0,150,'...');;echo '
    </p>
    </div>
    <div class="clear">
    </div>
    <div class="info">';if(function_exists('the_ratings')) { ;echo expand_ratings_template('<span>%RATINGS_IMAGES%</span>', get_the_ID()); };echo'围观：'
	;echo getPostViews(get_the_ID());;echo'+';echo ' | ';comments_popup_link ('抢沙发','1条评论','%条评论');;echo '
    </div>
    </div>
    </li>
    </ul>
    ';endwhile;;echo ' ';endif;;echo '
	<div class="clear"></div>
    <div class="navigation">
        ';pagination($query_string);;echo '
    </div>
    </div>
    ';get_sidebar();;echo '';get_footer(); ?>