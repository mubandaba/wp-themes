<?php
/*
Template Name: Tags Cloud
*/
?>
<?php get_header(); ?>
<div id="content">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div id="map">
<div class="site">当前位置：<a href="<?php bloginfo('siteurl'); ?>/" title="返回首页">首页</a> > <?php the_title(); ?></div>
</div><div class="main">
<div class="article article_c">
<h2><?php the_title(); ?></h2>
        <div class="context"><?php wp_tag_cloud('smallest=13&largest=13&unit=px&number=0&orderby=count&order=DESC');?></div>
</div>
<div class="article article_c article_b">
<?php comments_template(); ?>
</div>

	<?php endwhile; else: ?>
	<?php endif; ?></div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>