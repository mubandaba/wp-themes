/**
 * jQuery Sidebar JS
 *
 * Adds a toggle icon with slide animation for the sidebar on mobile devices
 *
 * Copyright 2015 ThemeZee
 * Free to use under the GPLv2 and later license.
 * http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Author: Thomas Weichselbaumer (themezee.com)
 *
 * @package zeeMagazine
 */

(function($) {
	
	/**--------------------------------------------------------------
	# Setup Sidebar Menu
	--------------------------------------------------------------*/
	$( document ).ready( function() {
		
		/* Show sidebar and fade content area */
		function showSidebar() {
			
			sidebar.show();
			sidebar.animate({ 'max-width' : '400px' }, 300 );
					
			overlay.show();
			
		}
		
		/* Hide sidebar and show full content area */
		function hideSidebar() {
			
			sidebar.animate({ 'max-width': '0' },  300, function(){
				sidebar.hide();
			});
					
			overlay.hide();
		}
		
		/* Reset sidebar on desktop screen sizes */
		function resetSidebar() {
			
			sidebar.show();
			sidebar.css({ 'max-width' : '100%' });
					
			overlay.hide();
		}
		
		/* Only do something if sidebar exists */
		if ( $( '.sidebar' ).length > 0 ) {
		
			/* Add sidebar toggle */
			$('#main-navigation').before('<button id=\"sidebar-toggle\" class=\"sidebar-navigation-toggle\"></button>');
			
			/* Add Overlay */
			$('body').append('<div id=\"sidebar-overlay\"></div>');
			
			/* Setup Selectors */
			var button = $('#sidebar-toggle'),
				sidebar = $('.sidebar'),
				overlay = $('#sidebar-overlay');
			
			/* Add sidebare toggle effect */
			button.on('click', function(){
				if( sidebar.is(':visible') ) {
					hideSidebar();
				}
				else {
					showSidebar();
				}
			});
					
		}
		
		/* Reset sidebar menu on desktop screens */
		if(typeof matchMedia == 'function') {
			var mq = window.matchMedia('(max-width: 60em)');
			mq.addListener(widthChange);
			widthChange(mq);
		}
		function widthChange(mq) {
			
			if (mq.matches) {
		
				sidebar.hide();
				
				/* Hide Sidebar when Content Area is clicked */
				overlay.on('click', function(e){
					if( sidebar.is(':visible') ) {
						e.preventDefault();
						hideSidebar();
					}
				});

			}
			else {
				
				/* Reset Sidebar Menu */
				resetSidebar();
				overlay.unbind( 'click' );
				
			}
			
		}

	} );

}(jQuery));