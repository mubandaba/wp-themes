** Installation **

1.When you are ready to install a theme, you must first upload the theme files and then activate the theme itself. The theme files can be uploaded in two ways:

 1.FTP Upload: Using your FTP program, upload the non-zipped theme folder into the /wp-content/themes/ folder on your server.
 2.WordPress Upload: Navigate to Appearance > Add New Themes > Upload. Go to browse, and select the zipped theme folder. Hit “Install Now” and the theme will be uploaded and installed.

Once the theme is uploaded, you need to activate it. Go to Appearance > Themes and activate your chosen theme.

2.Go to Appearance > Menus, create two menus and drag items into the menu areas, select both menu area locations and save the menu that you have setup.

3.The Class+ theme uses one area to customize the design of the theme. To access the main customization area go to Appearance > Customize within the WordPress dashboard.

Within this area you can customize everything from your logo, background image, site title, site color, footer area, and much more.



** Donate Me **
Paypal : mr.moyus@gmail.com
Alipay: moyuboy@gmail.com