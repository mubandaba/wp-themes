<?php  
/**
 * The template part for displaying a message that posts cannot be found.
 *
 * @package classPlus
 */
?>
<h3 class="page-title"><?php _e('No Posts Found.', 'twenty-theme'); ?></h3>