<?php



function fs_ajax_pagenavi(){
 if( isset($_GET['action'])&& $_GET['action'] == 'fs_ajax_pagenavi'  ){
	global $post,$wp_query, $wp_rewrite;
	$postid = isset($_GET['post']) ? $_GET['post'] : null;
	$pageid = isset($_GET['page']) ? $_GET['page'] : null;
	if(!$postid || !$pageid){
		fail(__('Error post id or comment page id.'));
	}
	// get comments
	$comments = get_comments('post_id='.$postid);

	$post = get_post($postid);

	if(!$comments){
		fail(__('Error! can\'t find the comments'));
	}

	if( 'desc' != get_option('comment_order') ){
		$comments = array_reverse($comments);
	}

	// set as singular (is_single || is_page || is_attachment)
	$wp_query->is_singular = true;

	// base url of page links
	$baseLink = '';
	if ($wp_rewrite->using_permalinks()) {
		$baseLink = '&base=' . user_trailingslashit(get_permalink($postid) . 'comment-page-%#%', 'commentpaged');
	}

	// response 注意修改callback为你自己的，没有就去掉callback
	echo '<ol class="comment-list" >';
	wp_list_comments('callback=devecomment&type=comment&page=' . $pageid . '&per_page=' . get_option('comments_per_page'), $comments);
	echo '</ol>';
	echo '<nav class="commentnav">';
	paginate_comments_links('current=' . $pageid . '&prev_text=«&next_text=»');
	echo '</nav>';
	die;
	}
}
add_action('init', 'fs_ajax_pagenavi');

?>