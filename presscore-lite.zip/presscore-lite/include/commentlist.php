<?php 
function devecomment($comment, $args, $depth) {
   $GLOBALS['comment'] = $comment;
   global $commentcount;
   if(!$commentcount) {
	   $page = ( !empty($in_comment_loop) ) ? get_query_var('cpage')-1 : get_page_of_comment( $comment->comment_ID, $args )-1;
	   $cpp=get_option('comments_per_page');
	   $commentcount = $cpp * $page;
	}
?>
<li class="comments" <?php if( $depth > 2){ echo ' style="margin-left:-50px;"';} ?> id="li-comment-<?php comment_ID() ?>">
  <div id="comment-<?php comment_ID(); ?>" class="comment-author"> <?php echo get_avatar( $comment, $size = '40'); ?> <cite id="author-<?php comment_ID() ?>"><?php printf(__('%s'), get_comment_author_link()) ?></cite><span class="floor"><!-- 主评论楼层号 by zwwooooo -->
    <?php
if(!$parent_id = $comment->comment_parent){
	switch ($commentcount){
		case 0 :echo "<font style='color:#cc0000'>沙发</font>";++$commentcount;break;
		case 1 :echo "<font style='color:#93BF20'>板凳</font>";++$commentcount;break;
		case 2 :echo "<font style='color:#000000'>地板</font>";++$commentcount;break;
		default:printf('%1$s楼', ++$commentcount);
	}
}
?>
    </span>
    <?php if($comment->comment_parent){// 如果存在父级评论
          $comment_parent_href = get_comment_ID( $comment->comment_parent );
          $comment_parent = get_comment($comment->comment_parent);
          ?>
    <span class="comment-to plr">回复</span> <span class="reply-comment-author"><a href="#comment-<?php echo $comment_parent_href;?>"><?php echo $comment_parent->comment_author;?></a></span>
    <?php }?>
    <span><?php echo time_ago(); ?></span>
    <section id="commentText-<?php comment_ID() ?>" class="comment-con">
      <?php comment_text() ?>
    </section>
	<div class="comment-reply">
    <?php comment_reply_link(array_merge( $args, array('reply_text' => '回复','depth' => $depth, 'max_depth' => $args['max_depth']))) ?> | 
<a onclick="SIMPALED.quote( 'author-<?php comment_ID() ?>','commentText-<?php comment_ID() ?>')" href="#respond" class="comment-reply-link ">引用</a>
    </div>
  </div>
  <?php
}

		function devepings($comment, $args, $depth) {
			   $GLOBALS['comment'] = $comment;
		?>
<li id="comment-<?php comment_ID(); ?>">
  <div class="pingdiv">
    <?php comment_author_link(); ?>
  </div>
  <?php }
?>