<?php 
/**
 * Fatesinger <header> in the theme.
 *
 *
 * @version 1.0
 * @package Bigfa
 * @copyright 2013 all rights reserved
 *
 */
 
function presscore_header() {
?>
	<div id="wrap">
<?php if ( dopt('d_notice_b') ){ ?>
<div class="header-notice">
<p class="notice-body">
<?php echo dopt('d_notice');?>
</p>
</div>
<?php } ?>
<header id="header" role="banner" class="clearfix">
<h1><a class="logo" title="<?php bloginfo('name');?>" href="<?php bloginfo('url');?>"><?php bloginfo('name');?>
</a></h1>
<div class="right-banner">
<div class="tool-menu right">
<a class="rss" title="RSS2.0" href="<?php bloginfo( 'rss2_url' ); ?>" target="_blank"></a>
</div>
<nav class="link-menu right">
<?php wp_nav_menu( array( 'theme_location' => 'top-menu','menu_id'=>'top-nav','menu_class'=> 'top-nav','container'=>'ul','fallback_cb' => 'link_to_menu_editor')); ?>
</nav>
</div>

</header>
<div id="navigation" role="navigation">
<nav class="menu-container">

	<?php wp_nav_menu( array( 'theme_location' => 'header-menu','menu_id'=>'menu-nav','menu_class'=>'fancy-rollovers','container'=>'ul','fallback_cb' => 'link_to_menu_editor')); ?>

</nav>

<div class="nav-right right">
<a class="show-search" href="javascript:;"></a>
<?php if ( dopt('d_show_case_b') && !wp_is_mobile()){ ?>
<a href="javascript:;" class="show-cat-list"></a>
<?php } ?>
<?php if ( wp_is_mobile()){ ?>
<div class="mobile-nav-container"><div class="show-mobile-nav"></div><div class="header-mobile-nav"><?php wp_nav_menu( array( 'theme_location' => 'header-menu','menu_id'=>'top-mobile-nav','menu_class'=>'fancy-rollovers','container'=>'ul')); ?></div></div>
<?php } ?>
</div>
</div>
<?php if ( dopt('d_show_case_b') && !wp_is_mobile()){ ?>
<div id="cat-list" class="fullwidth clearfix">
<div id="cat-list-inner" class="clearfix">
<div class="border"></div>
<div class="cat-list-item first live-list">
<h3 class="yahei">最新</h3>
<div id="top-newest-post">
<ul class="clearfix">
  <?php query_posts( $query_string . 'showposts=8&ignore_sticky_posts=1' );while(have_posts()) : the_post(); ?>
  <li><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
    <?php the_title(); ?>
    </a></li>
  <?php endwhile;wp_reset_query() ?>
</ul>
</div>
<a class="all-tags" title="更多观察" href="<?php bloginfo('url');?>">">更多 »</a>
</div>
<div class="cat-list-item recommend-subject">
<h3 class="yahei">推荐</h3>
<div class="recommend-subject-item first">
<a class="thumb" href="javascript:void(0);">
<img src="<?php echo dopt('d_show_case_img_1')?>">
</a>
<ul class="clearfix">
<?php query_posts( $query_string . '&cat='.dopt('d_show_case_1').'&orderby=rand&showposts=5&ignore_sticky_posts=1' );while(have_posts()) : the_post(); ?>
      <li><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
        <?php the_title(); ?>
        
       </a></li>
      <?php endwhile;wp_reset_query() ?>
</ul>
</div>
<div class="recommend-subject-item">
<a class="thumb" href="javascript:void(0);">
<img src="<?php echo dopt('d_show_case_img_2')?>">
</a>
<ul class="clearfix">

      <?php query_posts( $query_string . '&cat='.dopt('d_show_case_2').'&orderby=rand&showposts=5&ignore_sticky_posts=1' );while(have_posts()) : the_post(); ?>
      <li><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
        <?php the_title(); ?>
        
       </a></li>
      <?php endwhile;wp_reset_query() ?>
</ul>
</div>
</div>
</div>
</div>
<?php } ?>
<?php 
}
/**
 * Presscore <relatedpost> in the theme.
 *
 *
 * @version 1.0
 * @package Bigfa
 * @copyright 2013 all rights reserved
 *
 */
 
function presscore_relatedpost() { 

echo '<div class="rlt-post"><div class="bfd_title"><h3>暧昧帖</h3></div><div class="bfd_content"><ul>';
	$post_num = 8;
$exclude_id = $post->ID;
$posttags = get_the_tags(); $i = 0;
if ( $posttags ) {
	$tags = ''; foreach ( $posttags as $tag ) $tags .= $tag->term_id . ',';
	$args = array(
		'post_status' => 'publish',
		'tag__in' => explode(',', $tags),
		'post__not_in' => explode(',', $exclude_id),
		'ignore_sticky_posts' => 1,
		'orderby' => 'comment_date',
		'posts_per_page' => $post_num
	);
	query_posts($args);
	while( have_posts() ) { the_post(); ?>
		<li>
			
			<a href="<?php the_permalink(); ?>" ><?php the_title(); ?></a>
		</li>
	<?php
		$exclude_id .= ',' . $post->ID; $i ++;
	} wp_reset_query();
}
if ( $i < $post_num ) {
	$cats = ''; foreach ( get_the_category() as $cat ) $cats .= $cat->cat_ID . ',';
	$args = array(
		'category__in' => explode(',', $cats),
		'post__not_in' => explode(',', $exclude_id),
		'ignore_sticky_posts' => 1,
		'orderby' => 'comment_date',
		'posts_per_page' => $post_num - $i
	);
	query_posts($args);
	while( have_posts() ) { the_post(); ?>
		<li>
			
			<a href="<?php the_permalink(); ?>" ><?php the_title(); ?></a>
		</li>
 
	<?php $i++;
	} wp_reset_query();
}
if ( $i  == 0 )  echo '<li>没有相关文章!</li>';
	echo '</ul></div></div>';
}
?>
