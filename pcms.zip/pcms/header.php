<!DOCTYPE html><html dir="ltr" lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<?php $options = get_option('looooo_options'); ?>
<title><?php if (is_home()) { ?><?php echo($options['hometitle']); ?><?php } elseif (is_category()) { ?><?php echo category_description($cat_ID); ?><?php } elseif (is_single()) { ?><?php wp_title(''); ?>_<?php bloginfo('name'); ?><?php } else { ?><?php wp_title(''); ?>-<?php bloginfo('name'); ?><?php } ?></title>
<?php if (is_home()) { ?>
<meta name="Keywords" content="<?php echo($options['keywords']); ?>" />
<meta name="Description" content="<?php echo($options['description']); ?>" />
<?php } elseif (is_category()) { ?>
<meta name="Keywords" content="<?php echo category_description($cat_ID); ?>" />
<meta name="Description" content="<?php bloginfo('name'); ?>,<?php echo category_description($cat_ID); ?>" />
<?php } elseif (is_single()) { ?>
<meta name="Keywords" content="<?php wp_title(''); ?>" />
<meta name="Description" content="<?php bloginfo('name'); ?>:<?php wp_title(''); ?>" />
<?php } elseif (is_tag()) { ?>
<meta name="Keywords" content="<?php wp_title(''); ?>" />
<meta name="Description" content="<?php wp_title(''); ?>" />
<?php } else { ?><?php } ?>
<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo('stylesheet_url'); ?>" />
<link rel="Shortcut Icon" href="<?php bloginfo('template_url'); ?>/images/ico.ico" type="image/x-icon" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<?php wp_head(); ?>
</head>
<body>
<div id="quanju"><div id="topnavbar">	
		<div class="topnavbarleft">
			<p>PastDust欢迎您!创业交流群:13809070</p>
		</div>
		<div class="topnavbarright">
		<p><a href="http://list.qq.com/cgi-bin/qf_invite?id=9964f7ee8ee878e09706c8cefb06fc6f53510837a2806032" rel="nofollow" target="_blank">订阅本站</a>|<a href="/about/">关于博主</a>|<a href="/archives">文章归档</a></p>
		</div>
	</div>
<div id="header">
	<div class="headerleft">
		<a href="<?php echo get_settings('home'); ?>/"><img src="<?php bloginfo('template_url'); ?>/images/logo.jpg" width="266" height="100" alt="<?php bloginfo('description'); ?>" /></a>
	</div>
	<div class="headerright">
		<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/ad65860.js"></script>	
	</div>
</div>
<div id="navbar">
		<ul id="nav">
			<li><a href="<?php echo get_settings('home'); ?>">网站首页</a></li>
			<?php wp_list_categories('sort_column=name&title_li=&depth=1&exclude=6,7,9,11'); ?>
                        <li><a href="/tag/pcms">Pcms主题</a></li>
		</ul>	
</div>
<div style="clear:both;"></div>
<div id="ad960">
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/ad96060.js"></script>
</div>
<div style="clear:both;"></div>