<?php
function dp_clean($excerpt, $substr=0) {
	$string = strip_tags(str_replace('[...]', '...', $excerpt));
	if ($substr>0) {
		$string = substr($string, 0, $substr);
	}
	return $string;
}
add_filter( 'show_admin_bar', '__return_false' );
function catch_that_image() {
  global $post, $posts;
  $first_img = '';
  ob_start();
  ob_end_clean();
  $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
  $first_img = $matches [1] [0];

  if(empty($first_img)){ //Defines a default image
    $first_img = "/wp-content/themes/pcms/images/no_pic.png";
  }
  return $first_img;
}
function the_slug() {
    $post_data = get_post($post->ID, ARRAY_A);
    $slug = $post_data['post_name'];
    return $slug;
}

function the_category_slug(){
 $category = get_the_category();
 return ($category ? $category[0]->slug : "");
}


function deletehtml($description) { 
$description = trim($description); 
$description = strip_tags($description,""); 
return ($description);
}
add_filter('category_description', 'deletehtml');
include (TEMPLATEPATH . '/shezhi.php'); 
?>