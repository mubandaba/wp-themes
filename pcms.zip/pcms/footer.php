<div style="clear:both;"></div>
<div id="footer">
<?php if (is_home()) { ?>
 <p>友情链接:<?php get_links('', '<span>', '</span>', ' ', FALSE, 'id', FALSE, FALSE, -1, FALSE); ?></p>
<?php } else {?>
<?php } ?>
       	<p>Copyright &copy; 2008-2012 &middot; All Rights Reserved &middot; <a href="http://www.pastdust.com/net/20120913818.html" >Pcms theme</a> by <a href="http://www.pastdust.com" >PastDust</a> &middot; Powered by <a href="http://www.wordpress.org/" rel="nofollow" target="_blank">WordPress</a> &middot;</p></br>
</div>
<?php wp_footer(); ?>
</div>
<script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3Fcb7cda2625758fbc8d40206e6beb46f2' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=180241" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
	document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + new Date().getHours();
</script>
</body>
</html>