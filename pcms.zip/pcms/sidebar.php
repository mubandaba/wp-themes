<div id="sidebar">
	<div class="newsletter">
		<h2>分享本站</h2>
		<!-- Baidu Button BEGIN -->
    <div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare">
        <a class="bds_qzone"></a>
        <a class="bds_tsina"></a>
        <a class="bds_tqq"></a>
        <a class="bds_renren"></a>
        <a class="bds_baidu"></a>
        <span class="bds_more"></span>
		<a class="shareCount"></a>
    </div>
<!-- Baidu Button END -->	
	</div>
	<div class="adsense">	
			<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/ad300250.js"></script>	
	</div>
<div class="widgetarea">
	<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(1) ) : else : ?>
		<h2>最新文章</h2>
			<ul>
			<?php wp_get_archives('type=postbypost&limit=12'); ?> 
			</ul>
	<?php endif; ?>
	</div>	

<div class="tag">
<h2>热门标签</h2>	
<ul>
<li>
<?php wp_tag_cloud('number=30&largest=30&smallest=16&unit=px'); ?>
</li>
</ul>
	</div>
<div class="pinglun">
<h2>随机文章</h2>	
<?php wp_reset_query(); ?>  
<?php query_posts("showposts=12&caller_get_posts=1&order=DESC&orderby=rand"); ?>  
<ul>  
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>  
<li><a href="<?php the_permalink() ?>" title="<?php the_title() ?>"><?php echo mb_strimwidth(get_the_title(), 0, 45, ''); ?></a></li>  
<?php endwhile ?>  
<?php endif ?>  
</ul>   
<?php wp_reset_query(); ?>  
</div>
</div>