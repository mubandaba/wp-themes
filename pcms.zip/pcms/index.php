<?php get_header(); ?>
<div id="content">
	<div id="homepage">	
		<div id="homepagebottom">		
			<div class="hpbottom">			
				<h3>最近更新</h3>		
<?php  $recent = new WP_Query("showposts=4");while($recent->have_posts()) : $recent->the_post();?>		
                               <a href="<?php the_permalink() ?>" target="_blank"><img style="float:left;margin:0px 10px 0px 0px;" width="190" height="140" alt="<?php the_title(); ?>"  title="<?php the_title(); ?>" src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo catch_that_image() ?>&w=190&h=140&zc=1"></a>
                               <p><a href="<?php the_permalink() ?>" rel="bookmark"><font size="+1"><b><?php the_title(); ?></b></font></a></p>
                                <p><span>日期：<?php the_time('m月d日') ?></span>|                        
				   <span>分类：<?php the_category(', ') ?></span></p>
				<?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 240,"..."); ?>
				<p><span><?php the_tags(); ?></span>|                        
				   <span><a href="<?php the_permalink() ?>" rel="bookmark">阅读全文</a></span></p>	
				<div class="xian"></div>
				<?php endwhile; ?>			
</div></div>
<div id="homepageleft">
		<div class="hpfeatured">
			<h3>电子商务</h3>	
				<?php $recent = new WP_Query("cat=4&showposts=8"); while($recent->have_posts()) : $recent->the_post();?>	
				<div class="xian"><a href="<?php the_permalink() ?>"><?php echo mb_strimwidth(get_the_title(), 0, 45, ''); ?></a></div>
				<?php endwhile; ?>			
			</div>			
				
		</div>
		
		<div id="homepageright">
			<div class="hpfeatured">
			<h3>网络杂谈</h3>	
				<?php $recent = new WP_Query("cat=1&showposts=8"); while($recent->have_posts()) : $recent->the_post();?>	
				<div class="xian"><a href="<?php the_permalink() ?>"><?php echo mb_strimwidth(get_the_title(), 0, 45, ''); ?></a></div>						
				<?php endwhile; ?>			
			</div>			
			
		</div>
<div id="homepageleft">
		<div class="hpfeatured">
			<h3>网络网站</h3>	
				<?php $recent = new WP_Query("cat=3&showposts=8"); while($recent->have_posts()) : $recent->the_post();?>	
				<div class="xian"><a href="<?php the_permalink() ?>"><?php echo mb_strimwidth(get_the_title(), 0, 45, ''); ?></a></div>		
				<?php endwhile; ?></ul>				
			</div>			
				
		</div>
		
		<div id="homepageright">
			<div class="hpfeatured">
			<h3>资源分享</h3>	
				<?php $recent = new WP_Query("cat=5&showposts=8"); while($recent->have_posts()) : $recent->the_post();?>	
				<div class="xian"><a href="<?php the_permalink() ?>"><?php echo mb_strimwidth(get_the_title(), 0, 45, ''); ?></a></div>					
				<?php endwhile; ?>			
			</div>			
			
		</div>
	</div>
	
<?php include(TEMPLATEPATH."/sidebar.php");?>
		
</div>
<?php get_footer(); ?>