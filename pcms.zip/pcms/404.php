<?php get_header(); ?>

<div id="content">

	<div id="contentleft">
	
		<div class="postarea">
	
	
			
			<h1>对不住了,您所浏览的页面不存在</h1>
			<p>您还可以查看一下内容，希望这里能有您所需要的:</p>
			
				<b>页面:</b>
					<ul>
						<?php wp_list_pages('title_li='); ?>
					</ul>
				
				<b>文章归档:</b>
					<ul>
						<?php wp_get_archives('type=monthly'); ?>
					</ul>
							
				<b>分类:</b>
					<ul>
						<?php wp_list_cats('sort_column=name'); ?>
					</ul>
		</div>
		
	</div>
	
<?php include(TEMPLATEPATH."/sidebar.php");?>
		
</div>

<!-- The main column ends  -->

<?php get_footer(); ?>