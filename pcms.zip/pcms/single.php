<?php get_header(); ?>

<div id="content">

	<div id="contentleft">
	
		<div class="postarea">
		
		<div class="mianbaoxie"><a href="<?php bloginfo('home'); ?>" title="返回首页">home</a><<?php the_category(multiple); ?><
		<a><?php the_title(); ?></a></div>	
			
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<h1><?php the_title(); ?></h1>
			
			<div class="date">
			
				<div class="dateleft">
					<p><span class="time"><?php the_time('F j, Y'); ?></span> 作者: <?php the_author_posts_link(); ?> &nbsp;<?php edit_post_link('(Edit)', '', ''); ?> <br /> 分类: <?php the_category(', ') ?> Tags: <?php the_tags('') ?></p> 
				</div>				
			</div>
                        <div class="wenzhang">
			<?php the_content(__('Read more'));?>
                         <div class="xuxian">
                         <div>本文作者:<?php the_author_posts_link(); ?></div>
                         <div>文章链接:<a href="<?php the_permalink() ?>"><?php the_permalink() ?></a></div>
                         <div>版权申明:非特殊说明，本站所有内容皆为原创，转载请保留原文链接，谢谢！</div>                         
</div>
                        </div>
			<div style="clear:both;"></div>

			<div class="xian"></div>
			<div><?php if (get_previous_post()) { previous_post_link('上一篇: %link','%title',true);} else { echo "已是最后文章";} ?></div>
                        <div><?php if (get_next_post()) { next_post_link('下一篇: %link','%title',true);} else { echo "已是最新文章";} ?></div>	
			
						
			<?php endwhile; else: ?>
			
			<?php endif; ?>
		</div>
		
		<div class="adsense-post">
		<div id="wumiiDisplayDiv"></div>				
		</div>
		<div class="comments">
	
			<h4>评论</h4>
			<?php comments_template(); // Get wp-comments.php template ?>
			
		</div>	
				
	</div>
	
<?php include(TEMPLATEPATH."/sidebar.php");?>
		
</div>
<?php get_footer(); ?>