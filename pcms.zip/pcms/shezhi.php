<?php 
class loooooOptions {

	function getOptions() {
		$options = get_option('looooo_options');
		if (!is_array($options)) {
			$options['description'] = '';
			$options['keywords'] = '';
			$options['hometitle'] = '';
			$options['css'] = '';
			
			update_option('looooo_options', $options);
			
		}
		return $options;
	}

	function add() {
		if(isset($_POST['looooo_save'])) {
			$options = loooooOptions::getOptions();
			
			// meta
			$options['description'] = stripslashes($_POST['description']);
			$options['keywords'] = stripslashes($_POST['keywords']);
			$options['hometitle'] = stripslashes($_POST['hometitle']);
			$options['css'] = stripslashes($_POST['css']);
			
			// ads 
							
			update_option('looooo_options', $options);

		} else {
			loooooOptions::getOptions();
		}

		add_theme_page(__('Pcms主题设置'), __('Pcms主题设置'), 'edit_themes', basename(__FILE__), array('loooooOptions', 'display'));
	}

	function display() {
		$options = loooooOptions::getOptions();
?>

<form action="#" method="post" enctype="multipart/form-data" name="looooo_form" id="looooo_form">
<style>
.s1,.s1_x{padding:5px 0;}
.s1_x input,.s1_x textarea{padding:5px;border: 1px solid #ccc;line-height:20px;}
.none{display:none}
</style>
	<div class="wrap">
		<h2>Pcms主题设置</h2>
<div class="s1">首页标题</div>
<div class="s1_x">
<input type="text" name="hometitle" id="description" class="code" style="width:95%;" value="<?php echo($options['hometitle']); ?>">
</div>
<div class="s1">首页关键词</div>
<div class="s1_x">
<input type="text" name="keywords" id="keywords" class="code" style="width:95%;" value="<?php echo($options['keywords']); ?>">
</div>
<div class="s1">首页描述</div>
<div class="s1_x">
<textarea name="description" id="description" class="code" style="width:95%;height:90px;"><?php echo($options['description']); ?></textarea>
</div>
							
		<p class="submit">
			<input class="button-primary" type="submit" name="looooo_save" value="保存设置" />
		</p>
	</div>

</form>


<?php } }

add_action('admin_menu', array('loooooOptions', 'add')); 

?>