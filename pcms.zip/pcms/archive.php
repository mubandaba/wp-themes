<?php get_header(); ?>
<div id="content">
	<div id="contentleft">	
		<div class="postarea">	
                    <div class="mianbaoxie"><a href="<?php bloginfo('home'); ?>" title="返回首页">home</a><<?php if ( get_category($cat)->category_parent ) : ?>
							<?php echo '<a>'; the_category('</a>', 'multiple'); ?>
						<?php elseif ( is_tag() ): ?>
							<a>包含标签 <?php single_cat_title(); ?> 的文章</a>
						<?php else : ?>
							<a><?php single_cat_title(); ?></a>
						<?php endif; ?></div>		
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<a href="<?php the_permalink() ?>" target="_blank"><img style="float:left;margin:0px 10px 0px 0px;" width="200" height="150" alt="<?php the_title(); ?>"  title="<?php the_title(); ?>" src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo catch_that_image() ?>&w=200&h=150&zc=1"></a>
			<a href="<?php the_permalink() ?>" rel="bookmark"><font size="+1"><b><?php the_title(); ?></b></font></a>
                                <p><span>日期：<?php the_time('m月d日') ?></span>|                        
				   <span>标签：<?php the_tags(); ?></span></p>	
			<?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 250,"..."); ?>
                        <div class="xian"></div>			
			<?php endwhile; else: ?>			
			<p><?php _e('Sorry, no posts matched your criteria.'); ?></p><?php endif; ?>
			<p><?php posts_nav_link(' &#8212; ', __('&laquo; Previous Page'), __('Next Page &raquo;')); ?></p>
		</div>				
	</div>	
<?php include(TEMPLATEPATH."/sidebar.php");?>	
</div>
<?php get_footer(); ?>