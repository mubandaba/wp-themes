
<table class="table footertable">
    <tbody><tr>
    <td style="padding-right: 15px!important;">
          <?php the_widget('deve_widget9', array('title' => '最近评论', 'limit' => 5 ), array( 'before_title' => '<span>','after_title' => '</span>' ) ); ?>
	</td>
    <td style="padding-right: 15px!important;">
    	<?php the_widget( 'WP_Widget_Recent_Posts', array('title' => '最近文章', 'number' => 5 ), array( 'before_title' => '<span>','after_title' => '</span>' ) ); ?>
    </td>
    <td class="links"><span>友情链接</span><ul>  
		<?php wp_list_bookmarks('title_li=&categorize=0'); ?>
</ul></td></tr>
      </tbody>
    </table>


<span class="footi left">
	<?php if($options['footertext']=='') {?>
		Copyright &copy; <a href="<?php bloginfo('url') ?>"><?php bloginfo('name') ?></a>
	<?php } else { echo stripcslashes($options['footertext']); } ?>
</span>
<span class="copyr right">Theme DNSHH by <a href="http://dnshh.com" target="_blank">Hang</a> &amp; <a href="http://ben-lab.com/" target="_blank">Ben</a> &amp; <a href="http://s-kias.likecer.com" target="_blank">S-kias</a> / <a href="http://cn.wordpress.org" target="_blank" title="自豪地采用Wordpress。">Wordpress)))</a></span>
</div><div class="clear"></div>

<?php wp_footer(); $options = get_option('ice_options'); ?>

<?php if(is_single()||is_page()){?><div id="gotocomment" title="到评论列表"></div><?php }?>
<div id="gototop" title="到顶部"></div>
<div id="gotobottom" title="到底部"></div>

<?php if($options['opentongji']){ ?>
<div id="tongjicode"><?php echo stripcslashes($options['tongjicode']) ?></div>
<?php } ?>
<?php if($options['bodycode']!=""){ echo stripcslashes($options['bodycode']); }?>
</body>

<script type="text/javascript" src="<?php if($options['sinajquery']){echo 'http://lib.sinaapp.com/js/jquery/1.8.2/jquery.min.js';}else{echo get_bloginfo('template_directory').'/js/jQuery.js';}?>"></script>

<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/ice.js"></script>
<?php if ($options['fancybox']) {echo '<script type="text/javascript" src="'.get_bloginfo('template_directory').'/js/fb/fancybox.pack.js"></script>';}?>

<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/comments-ajax.js"></script>
</html>