<?php

//shortcode - old
//download
function downbox($atts, $content=null, $code="") {
	$return = "<div class='down codei'><div class='box-content'>";
	$return .= do_shortcode($content);
	$return .= "</div></div>";
	return $return;
}
add_shortcode('down' , 'downbox' );
//warning
function warningbox($atts, $content=null, $code="") {
	$return = "<div class='warning codei'><div class='box-content'>";
	$return .= do_shortcode($content);
	$return .= "</div></div>";
	return $return;
}
add_shortcode('warning' , 'warningbox' );	
//author
function authorbox($atts, $content=null, $code="") {
	$return = "<div class='panelauthor codei'><div class='box-content'>";
	$return .= do_shortcode($content);
	$return .= "</div></div>";
	return $return;
}
add_shortcode('author' , 'authorbox' );
//textbox
function textbox($atts, $content=null, $code="") {
	$return = "<div class='texticon codei'><div class='box-content'>";
	$return .= do_shortcode($content);
	$return .= "</div></div>";
	return $return;
}
add_shortcode('text' , 'textbox' );
//tutorial
function teachbox($atts, $content=null, $code="") {
	$return = "<div class='tutorial codei'><div class='box-content'>";
	$return .= do_shortcode($content);
	$return .= "</div></div>";
	return $return;
}
add_shortcode('tutorial' , 'teachbox' );
//project
function projectbox($atts, $content=null, $code="") {
	$return = "<div class='project codei'><div class='box-content'>";
	$return .= do_shortcode($content);
	$return .= "</div></div>";
	return $return;
}
add_shortcode('project' , 'projectbox' );
//error
function errorbox($atts, $content=null, $code="") {
	$return = "<div class='error codei'><div class='box-content'>";
	$return .= do_shortcode($content);
	$return .= "</div></div>";
	return $return;
}
add_shortcode('error' , 'errorbox' );
//question
function questionbox($atts, $content=null, $code="") {
	$return = "<div class='question codei'><div class='box-content'>";
	$return .= do_shortcode($content);
	$return .= "</div></div>";
	return $return;
}
add_shortcode('question' , 'questionbox' );
//blink
function blinkbox($atts, $content=null, $code="") {
	$return = "<div class='blink codei'><div class='box-content'>";
	$return .= do_shortcode($content);
	$return .= "</div></div>";
	return $return;
}
add_shortcode('blink' , 'blinkbox' );
//codee
function codeebox($atts, $content=null, $code="") {
	$return = "<div class='codee codei'><div class='box-content'>";
	$return .= do_shortcode($content);
	$return .= "</div></div>";
	return $return;
}
add_shortcode('codee' , 'codeebox' );

//shortcode - new
//download
function newdowndbox($atts, $content=null, $code="") {
	extract(shortcode_atts(array("title" => ''), $atts));
	$output = "<div class='newdown'><h2>".$title."</h2><div class='newcontent'>"; 
	$output .= do_shortcode($content);
	$output .= "</div></div>";
	return $output;
}
add_shortcode('newdown' , 'newdowndbox' );
//warning
function newwarningbox($atts, $content=null, $code="") {
	extract(shortcode_atts(array("title" => ''), $atts));
	$output = "<div class='newwarning'><h2>".$title."</h2><div class='newcontent'>"; 
	$output .= do_shortcode($content);
	$output .= "</div></div>";
	return $output;
}
add_shortcode('newwarning' , 'newwarningbox' );
//author
function newauthorbox($atts, $content=null, $code="") {
	extract(shortcode_atts(array("title" => ''), $atts));
	$output = "<div class='newauthor'><h2>".$title."</h2><div class='newcontent'>"; 
	$output .= do_shortcode($content);
	$output .= "</div></div>";
	return $output;
}
add_shortcode('newauthor' , 'newauthorbox' );
//text
function newtextbox($atts, $content=null, $code="") {
	extract(shortcode_atts(array("title" => ''), $atts));
	$output = "<div class='newtext'><h2>".$title."</h2><div class='newcontent'>"; 
	$output .= do_shortcode($content);
	$output .= "</div></div>";
	return $output;
}
add_shortcode('newtext' , 'newtextbox' );
//tutorial
function newtutorialbox($atts, $content=null, $code="") {
	extract(shortcode_atts(array("title" => ''), $atts));
	$output = "<div class='newtutorial'><h2>".$title."</h2><div class='newcontent'>"; 
	$output .= do_shortcode($content);
	$output .= "</div></div>";
	return $output;
}
add_shortcode('newtutorial' , 'newtutorialbox' );
//project
function newprojectbox($atts, $content=null, $code="") {
	extract(shortcode_atts(array("title" => ''), $atts));
	$output = "<div class='newproject'><h2>".$title."</h2><div class='newcontent'>"; 
	$output .= do_shortcode($content);
	$output .= "</div></div>";
	return $output;
}
add_shortcode('newproject' , 'newprojectbox' );
//error
function newerrorbox($atts, $content=null, $code="") {
	extract(shortcode_atts(array("title" => ''), $atts));
	$output = "<div class='newerror'><h2>".$title."</h2><div class='newcontent'>"; 
	$output .= do_shortcode($content);
	$output .= "</div></div>";
	return $output;
}
add_shortcode('newerror' , 'newerrorbox' );
//question
function newquestionbox($atts, $content=null, $code="") {
	extract(shortcode_atts(array("title" => ''), $atts));
	$output = "<div class='newquestion'><h2>".$title."</h2><div class='newcontent'>"; 
	$output .= do_shortcode($content);
	$output .= "</div></div>";
	return $output;
}
add_shortcode('newquestion' , 'newquestionbox' );
//link
function newlinkbox($atts, $content=null, $code="") {
	extract(shortcode_atts(array("title" => ''), $atts));
	$output = "<div class='newlink'><h2>".$title."</h2><div class='newcontent'>"; 
	$output .= do_shortcode($content);
	$output .= "</div></div>";
	return $output;
}
add_shortcode('newlink' , 'newlinkbox' );
//code
function newcodebox($atts, $content=null, $code="") {
	extract(shortcode_atts(array("title" => ''), $atts));
	$output = "<div class='newcode'><h2>".$title."</h2><div class='newcontent'>"; 
	$output .= do_shortcode($content);
	$output .= "</div></div>";
	return $output;
}
add_shortcode('newcode' , 'newcodebox' );


//-------------iconsbutton Optimization version by mugee
function button_download($atts, $content = null) {
	extract(shortcode_atts(array("href"=>'http://'), $atts));		
	return '<span class="but-down"><a href="'.$href.'" target="_blank"><span>'.$content.'</span></a></span>';
}
add_shortcode('butdown', 'button_download');

function button_heart($atts, $content = null) {
	extract(shortcode_atts(array("href"=>'http://'), $atts));		
	return '<span class="but-heart"><a href="'.$href.'" target="_blank"><span>'.$content.'</span></a></span>';
}
add_shortcode('butheart', 'button_heart');

function button_text($atts, $content = null) {
	extract(shortcode_atts(array("href"=>'http://'), $atts));		
	return '<span class="but-text"><a href="'.$href.'" target="_blank"><span>'.$content.'</span></a></span>';
}
add_shortcode('buttext', 'button_text');

function button_box($atts, $content = null) {
	extract(shortcode_atts(array("href"=>'http://'), $atts));		
	return '<span class="but-box"><a href="'.$href.'" target="_blank"><span>'.$content.'</span></a></span>';
}
add_shortcode('butbox', 'button_box');

function button_search($atts, $content = null) {
	extract(shortcode_atts(array("href"=>'http://'), $atts));		
	return '<span class="but-search"><a href="'.$href.'" target="_blank"><span>'.$content.'</span></a></span>';
}
add_shortcode('butsearch', 'button_search');

function button_document($atts, $content = null) {
	extract(shortcode_atts(array("href"=>'http://'), $atts));		
	return '<span class="but-document"><a href="'.$href.'" target="_blank"><span>'.$content.'</span></a></span>';
}
add_shortcode('butdocument', 'button_document');

function button_link($atts, $content = null) {
	extract(shortcode_atts(array("href"=>'http://'), $atts));		
	return '<span class="but-link"><a href="'.$href.'" target="_blank"><span>'.$content.'</span></a></span>';
}
add_shortcode('butlink', 'button_link');

function button_next($atts, $content = null) {
	extract(shortcode_atts(array("href"=>'http://'), $atts));		
	return '<span class="but-next"><a href="'.$href.'" target="_blank"><span>'.$content.'</span></a></span>';
}
add_shortcode('butnext', 'button_next');

function button_music($atts, $content = null) {
	extract(shortcode_atts(array("href"=>'http://'), $atts));		
	return '<span class="but-music"><a href="'.$href.'" target="_blank"><span>'.$content.'</span></a></span>';
}
add_shortcode('butmusic', 'button_music');

//music
function musiclink($atts, $content=null){
	extract(shortcode_atts(array("auto"=>'0',"replay"=>'0',),$atts));	
	return '<embed src="'.get_bloginfo("template_url").'/images/shortcode/dewplayer.swf?mp3='.$content.'&amp;autostart='.$auto.'&amp;autoreplay='.$replay.'" wmode="transparent" height="20" width="240" type="application/x-shockwave-flash" />';
}
add_shortcode('music','musiclink');

//----------toggle by mugee	 
function post_toggle($atts, $content=null){
	extract(shortcode_atts(array("title"=>''),$atts));	
	return '<div class="toggle_title">'.$title.'</div><div class="toggle_content">'.$content.'</div>';
} 
add_shortcode('toggle','post_toggle');

//////////////
function self_embed_handler_youku( $matches, $attr, $url, $rawattr ) { return apply_filters( 'embed_youku', '<embed src="http://player.youku.com/player.php/sid/' . esc_attr($matches[1]) . '/v.swf" quality="high" width="608" height="400" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" allowfullscreen="true" wmode="opaque"></embed>', $matches, $attr, $url, $rawattr ); }
wp_embed_register_handler( 'youku', '#http://v.youku.com/v_show/id_(.*?).html#i', 'self_embed_handler_youku' );

function self_embed_handler_tudou( $matches, $attr, $url, $rawattr ) { return apply_filters( 'embed_tudou', '<embed src="http://www.tudou.com/v/' . esc_attr($matches[1]) . '/v.swf"  quality="high" width="610" height="400" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" allowfullscreen="true" wmode="opaque"></embed>', $matches, $attr, $url, $rawattr );}
wp_embed_register_handler( 'tudou', '#http://www.tudou.com/programs/view/(.*?)/#i', 'self_embed_handler_tudou' );

function wp_embed_handler_ku6( $matches, $attr, $url, $rawattr ) { return apply_filters( 'embed_ku6', '<embed src="http://player.ku6.com/refer/' . esc_attr($matches[1]) . '/v.swf" quality="high" width="610" height="400" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" allowfullscreen="true" wmode="opaque"></embed>', $matches, $attr, $url, $rawattr ); }
wp_embed_register_handler( 'ku6', '#http://player.ku6.com/refer/(.*?)/v.swf#i', 'wp_embed_handler_ku6' );

function wp_embed_handler_yinyuetai( $matches, $attr, $url, $rawattr ) { return apply_filters( 'embed_yinyuetai', '<embed src="http://player.yinyuetai.com/swf/explayer.$31818.swf?videoId=' . esc_attr($matches[1]) . '&refererdomain=yinyuetai.com&epId=0" quality="high" width="610" height="400" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" allowfullscreen="true" wmode="opaque"></embed>', $matches, $attr, $url, $rawattr ); }
wp_embed_register_handler( 'yinyuetai', '#http://www.yinyuetai.com/video/(.*?)/#i', 'wp_embed_handler_yinyuetai' );

$options = get_option('light_options');
if($options['editor']) :
	function add_editor_buttons($buttons) { $buttons[] = 'fontselect'; $buttons[] = 'fontsizeselect'; $buttons[] = 'cleanup'; $buttons[] = 'styleselect'; $buttons[] = 'hr'; $buttons[] = 'del'; $buttons[] = 'sub'; $buttons[] = 'sup'; $buttons[] = 'copy'; $buttons[] = 'paste'; $buttons[] = 'cut'; $buttons[] = 'undo'; $buttons[] = 'image'; $buttons[] = 'anchor'; $buttons[] = 'backcolor'; $buttons[] = 'wp_page'; $buttons[] = 'charmap'; return $buttons; } add_filter("mce_buttons_3", "add_editor_buttons");
endif;
?>