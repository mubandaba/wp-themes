<div class="tempo-not-found">
	<h2><?php  echo tempo_not_found_message(); ?></h2>
	<p><?php echo tempo_not_found_description(); ?></p>

	<div class="clearfix"></div>
</div>