<?php    
    tempo_get_template_part(
        apply_filters( 'tempo_header_template', 'templates/header/partial/default' ),
        apply_filters( 'tempo_header_partial',  null )
    );
?>
