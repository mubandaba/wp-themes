<h1 class="tempo-title"><?php echo number_format_i18n( 404 ); ?></h1>
<big class="tempo-message"><?php  echo tempo_not_found_message(); ?></big>
<p class="tempo-description"><?php echo tempo_not_found_description(); ?></p>

<div class="tempo-search-form">
    <?php get_search_form(); ?>
</div>