<hr />
<div id="footer">
		Powered by
		<a href="http://wordpress.org/">WordPress</a> | 
		<a href="http://fairyfish.net/2008/08/13/purecss-theme/" title="PureCSS theme">PureCSS Theme</a> Produced by <a href="http://www.creadr.com/" title="PureCSS theme">CreaDr*</a> | 
		<a href="http://validator.w3.org/check/referer" title="This page validates as XHTML 1.0 Transitional">Valid <abbr title="eXtensible HyperText Markup Language">XHTML</abbr></a>
		<?php wp_footer(); ?>
</div>
</div>
</body>
</html>
