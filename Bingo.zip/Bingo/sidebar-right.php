<aside class="sidebar corner5px b1s" id="sidebar-right">
	<?php
		///if (is_home()) {
		//	if (function_exists('dynamic_sidebar') && dynamic_sidebar('widget_home_right')) : else :
		//		echo '<div class="widget-no m15">请前往<a href="/wp-admin/widgets.php">“后台 - 外观 - 小工具”</a>设置“首页侧边栏（右）”</div>';
		//	endif; 
		//} elseif (is_single() || is_page()) {
		//	if (function_exists('dynamic_sidebar') && dynamic_sidebar('widget_single_right')) : else :
		//		echo '<div class="widget-no m15">请前往<a href="/wp-admin/widgets.php">“后台 - 外观 - 小工具”</a>设置“文章页侧边栏（右）”</div>';
		//	endif; 
		//} else {
		//	if (function_exists('dynamic_sidebar') && dynamic_sidebar('widget_no_right')) : else :
		//		echo '<div class="widget-no m15">请前往<a href="/wp-admin/widgets.php">“后台 - 外观 - 小工具”</a>设置“其它页侧边栏（右）”</div>';
		//	endif; 
		//	}
	?>
	<div class="widget widegt_about widegt_about_left">
		<h3>关于<?php if ( is_single() ){echo '本文';} else {echo '博主';} ?></h3>
		<div class="widget-container m15">
			<div class="blog-avatar mr15">
				<img src="<?php $mail1=dopt('Bing_blog_email');Bing_avatar_url($mail=$mail1); ?>">
				<div class="name"><?php echo dopt('Bing_blog_name'); ?></div>
			</div>
			<div class="blog-about">
				<table>
					<?php if ( is_single() ){ ?>
					<tr><td>作者<br><?php the_author_posts_link(); ?></td><td>评论<br><a href="<?php the_permalink(); ?>#comments" title="《<?php the_title(); ?>》上的评论"><?php comments_popup_link('抢沙发', '2', '%', '', '没开启'); ?></td></tr>
					<tr><td>阅读<br><?php Bing_post_views('', ''); ?></td><td><?php echo get_num_queries(); ?><br><?php timer_stop(1); ?></td></tr>
					<?php } else { ?>
					<tr><td><?php $count_posts = wp_count_posts(); echo $published_posts = $count_posts->publish;?><br>篇文章</td><td><?php echo $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->comments");?><br>条评论</td></tr>
					<tr><td><?php echo floor((time()-strtotime(dopt('Bing_blog_date')))/86400); ?><br>天耕耘</td><td><?php echo get_num_queries(); ?><br><?php timer_stop(1); ?></td></tr>
					<?php } ?>
				</table>
			</div>
			<ul class="social">
			<li class="sinaweibo"><a href="<?php echo dopt('Bing_social_xlwb'); ?>" target="_blank" title="新浪微博">新浪微博</a></li>
			<li class="qqweibo"><a href="<?php echo dopt('Bing_social_txwb'); ?>" target="_blank" title="腾讯微博">腾讯微博</a></li>
			<li class="email"><a href="<?php echo dopt('Bing_social_email'); ?>" target="_blank" title="Emali">Email</a></li>
			<li class="rss"><a href="<?php echo dopt('Bing_social_rss'); ?>" target="_blank" title="RSS">RSS</a></li>
			</ul>
		</div>
	</div>

	<div class="widget widegt_new_single widegt_new_single_left">
		<h3>最新文章</h3>
		<div class="widget-container m15">
			<ul>
				<?php wp_get_archives('title_li=&type=postbypost&limit=10'); ?>
			</ul>
		</div>
	</div>

	<div class="widget widegt_ga widegt_new_single_left">
		<h3>标签云</h3>
		<div class="widget-container m15">
			<?php
			//彩色标签
			function colorCloud($text) {$text = preg_replace_callback('|<a (.+?)>|i','colorCloudCallback', $text);return $text;}
			function colorCloudCallback($matches) {
				$text = $matches[1];
				$color = dechex(rand(0,16777215));
				$pattern = '/style=(\'|\”)(.*)(\'|\”)/i';
				$text = preg_replace($pattern, "style=\"color:#{$color};$2;\"", $text);
				return "<a $text>";}
			add_filter('wp_tag_cloud', 'colorCloud', 1);
			?>
			<?php wp_tag_cloud('smallest=12&largest=18&unit=px&number=40');?>
		</div>
	</div>

	<?php if ( dopt('Bing_right_sidebar_ad') ) { ?>
	<div class="widget wideget_ad wideget_ad_right">
		<h3>广而告之</h3>
		<div class="widget-container m15">
			<div class="ad">
				<?php echo dopt('Bing_right_sidebar_ad_code'); ?>
			</div>
		</div>
	</div>
	<?php } ?>

	<div class="widget widget_new_comments widget_new_comments_right">
		<h3>最新评论</h3>
		<div class="widget-container m15">
			<ul>
				<?php
					$outer=dopt('Bing_blog_name');
					global $wpdb;
					$sql = "SELECT DISTINCT ID, post_title, post_password, comment_ID, comment_post_ID, comment_author, comment_date_gmt, comment_approved, comment_type,comment_author_url,comment_author_email, SUBSTRING(comment_content,1,16) AS com_excerpt FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID = $wpdb->posts.ID) WHERE comment_approved = '1' AND comment_type = '' AND post_password = '' AND user_id='0' AND comment_author != '".$outer."' ORDER BY comment_date_gmt DESC LIMIT 5";
					$comments = $wpdb->get_results($sql);
					$output = $pre_HTML;
					foreach ($comments as $comment) {$output .= "\n<li><a href=\"" . get_permalink($comment->ID) ."#comment-" . $comment->comment_ID . "\" title=\"发表在： " .$comment->post_title . "\">".get_avatar( $comment, 32,'',$comment->comment_author)."</a>" .strip_tags($comment->comment_author).":<br/><span>". strip_tags($comment->com_excerpt)."</span><br /></li>";}
					$output .= $post_HTML;
					echo $output;
				?>
			</ul>
		</div>
	</div>

	</div>
</aside>