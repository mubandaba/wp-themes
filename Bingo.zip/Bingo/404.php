<?php get_header();get_sidebar('left'); ?>
<article id="main" class="corner5px b1s">
	<div class="m15">
		<?php Bing_breadcrumbs(); ?>
		<h2>HTTP 404: Not Found</h2>
		<div style="margin:10px;font-size:20px;">
			<strong>请继续你的操作：</strong>
			<p><a href="<?php bloginfo('home'); ?>">返回首页</a></p>
			<p><a href="javascript:history.back();">返回前一页</a></p>
			<p><a href="/guestbook" target="_blank">留言将该错误链接提交给站长</a></p>
			<p>您还可以使用本站搜索功能找到你要的文章哦</p>
		</div>
	</div>
</article>
<?php get_sidebar('right');get_footer(); ?>