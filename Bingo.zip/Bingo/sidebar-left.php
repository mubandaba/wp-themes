<aside class="sidebar corner5px b1s" id="sidebar-left">
	<?php
		//if (is_home()) {
		//	if (function_exists('dynamic_sidebar') && dynamic_sidebar('widget_home_left')) : else :
		//		echo '<div class="widget-no m15">请前往<a href="/wp-admin/widgets.php">“后台 - 外观 - 小工具”</a>设置“首页侧边栏（左）”</div>';
		//	endif; 
		//} elseif (is_single() || is_page()) {
		//	if (function_exists('dynamic_sidebar') && dynamic_sidebar('widget_single_left')) : else :
		//		echo '<div class="widget-no m15">请前往<a href="/wp-admin/widgets.php">“后台 - 外观 - 小工具”</a>设置“文章页侧边栏（左）”</div>';
		//	endif; 
		//} else {
		//	if (function_exists('dynamic_sidebar') && dynamic_sidebar('widget_no_left')) : else :
		//		echo '<div class="widget-no m15">请前往<a href="/wp-admin/widgets.php">“后台 - 外观 - 小工具”</a>设置“其它页侧边栏（左）”</div>';
		//	endif; 
		//}
	?>
	<div class="widget widget_mood widget_mood_left">
		<h3>心情说</h3>
		<div class="widget-container m15">
			<?php
			$page_ID=dopt('Bing_mood_say_id');
			$num=dopt('Bing_mood_say_t');;
			?>
			<ul>
				<?php
				$announcement = '';
				$comments = get_comments("number=$num&post_id=$page_ID");
				if ( !empty($comments) ) {
					foreach ($comments as $comment) {
						$announcement .= '<li>'. convert_smilies($comment->comment_content) . '</li>';
					}
				}
				if ( empty($announcement) ) $announcement = '<li>欢迎光临本博！欢迎光临本博！欢迎光临本博！欢迎光临本博！</li>';
				echo $announcement;
				?>
			</ul>
			<?php if ($user_ID) echo '<p style="text-align:right;">[<a href="' . get_page_link($page_ID) . '#respond" rel="nofollow" class="anno">写心情</a>]</p>'; ?>
		</div>
	</div>

	<div class="widget widget_readers widget_readers_left">
		<h3>读者排行</h3>
		<div class="widget-container m15">
			<ul>
				<?php
				function Bing_readers($out,$timer,$limit){
					global $wpdb;    
					$counts = $wpdb->get_results("SELECT COUNT(comment_author) AS cnt, comment_author,comment_author_url,comment_author_email FROM {$wpdb->prefix}comments WHERE comment_date > date_sub( NOW(), INTERVAL $timer MONTH ) AND comment_approved = '1' AND comment_author_email AND comment_author_url != '".$out."' AND comment_type = ''  AND user_id = '0' GROUP BY comment_author ORDER BY cnt DESC LIMIT $limit");      
					foreach ($counts as $count) {
				            $c_url = $count->comment_author_url;
							if ($c_url == '') $c_url = 'javascript:;';
				            $mostactive .= '<li><a rel="nofollow" href="'. $c_url . '" title="' . $count->comment_author .' 留下 '. $count->cnt . ' 个脚印" target="_blank">' . get_avatar($count->comment_author_email, 90, '', $count->comment_author . ' 留下 ' . $count->cnt . ' 个脚印') . '</a></li>';
				        }
				        echo $mostactive;
				    } 
				?>
				<?php Bing_readers(dopt('Bing_blog_name'),dopt('Bing_dz_ts'),dopt('Bing_dz_t')); ?>
			</ul>
		</div>
	</div>

	<?php if ( dopt('Bing_left_sidebar_ad') ) { ?>
	<div class="widget wideget_ad wideget_ad_left">
		<h3>广而告之</h3>
		<div class="widget-container m15">
			<div class="ad">
				<?php echo dopt('Bing_left_sidebar_ad_code'); ?>
			</div>
		</div>
	</div>
	<?php } ?>

	<div class="widget wideget_nav_inks wideget_nav_inks_left">
		<h3>友情链接</h3>
		<div class="widget-container m15">
			<?php wp_nav_menu(array('theme_location'=>'links_menu')); ?>
		</div>
	</div>

</aside>