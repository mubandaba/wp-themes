<?php
//主题变量
$Bing_theme_name='Bingo';

//引入主题功能
include(TEMPLATEPATH.'/includes/option/Bing-theme.php');
//include(TEMPLATEPATH.'/includes/widget/widget.php');
include(TEMPLATEPATH.'/includes/thumbnail/thumbnail.php');

//引入主题函数
include(TEMPLATEPATH.'/functions/f_adminrss.php');
include(TEMPLATEPATH.'/functions/f_nav.php');
include(TEMPLATEPATH.'/functions/f_strimwidth.php');
include(TEMPLATEPATH.'/functions/f_pagenavi.php');
include(TEMPLATEPATH.'/functions/f_breadcrumbs.php');
include(TEMPLATEPATH.'/functions/f_visitors.php');
include(TEMPLATEPATH.'/functions/f_comments.php');
include(TEMPLATEPATH.'/functions/f_avatar.php');
include(TEMPLATEPATH.'/functions/f_page.php');
include(TEMPLATEPATH.'/functions/f_copyright.php');
include(TEMPLATEPATH.'/functions/f_pagenow.php');

//全部设置结束
?>