	</div>
</section>

<footer id="footer">
	<div id="footer-container">
		<p><nav class="nav" id="nav-footer"><?php wp_nav_menu(array('theme_location'=>'footer_menu')); ?></nav></p>
		<div class="theme-a">Power by WordPress | Theme <a href="http://www.bgbk.org" rel="external">Bingo</a><?php if( dopt('Bing_Statistics') ) { ?> | <?php echo dopt('Bing_Statistics_Code'); ?><?php } ?></div>
		<p><?php echo dopt('Bing_footer_copyright'); ?></p>
	</div>

</footer>
<script type="text/javascript" src="<?php bloginfo('template_directory');?>/js/theme.js"></script>
<?php
if( dopt('Bing_comment_ajax') ) { if ( is_single() || is_page() ) { ?>
<script type="text/javascript" src="<?php bloginfo('template_directory');?>/comments-ajax.js"></script>
<?php } } ?>
<?php wp_footer(); ?>
</body>
</html>