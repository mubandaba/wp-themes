<?php
function Bing_copyright(){
$custom_fields = get_post_custom_keys($post_id);
if (!in_array ('copyright', $custom_fields)) : ?>
<div class="copyright">
<p><strong>声明：</strong>本文由 <strong><a href="<?php bloginfo('url'); ?>" title="作者 <?php the_author(); ?> 的博客"><?php the_author(); ?></a></strong> 原创编译，转载请注明出自：<a href="<?php the_permalink() ?>" title="<?php the_title() ?>"><?php the_permalink() ?></a></p>
</div>
<?php else: ?>
<?php  $custom = get_post_custom($post_id);
$custom_value = $custom['copyright']; ?>
<div class="copyright">
<p><strong>声明：</strong>本文由 <strong><a href="<?php bloginfo('url'); ?>" title="作者 <?php the_author(); ?> 的博客"><?php the_author(); ?></a></strong> 整编自<a target="_blank" href="<?php echo $custom_value[0] ?>" title="本文参考文章的链接"><?php echo $custom_value[0] ?></a></p>
<p><strong>本文链接：</strong><a href="<?php the_permalink() ?>" title="<?php the_title() ?>"><?php the_permalink() ?></a></p>
</div>
<?php endif;} ?>