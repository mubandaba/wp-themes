<?php
//添加关于主题文章订阅
function custom_dashboard_widget() {
echo '<div class="rss-widget">';	 wp_widget_rss_output('http://www.bgbk.org/tag/Bingo/feed', array( 'show_author' => 1, 'show_date' => 1, 'show_summary' => 1 ));	 echo "</div>";
}
function add_custom_dashboard_widget() {
wp_add_dashboard_widget('custom_dashboard_widget', '主题动态', 'custom_dashboard_widget');
}
add_action('wp_dashboard_setup', 'add_custom_dashboard_widget');
?>