<?php
//启用主题或者插件自动跳转到设置页面
global $pagenow;
if ( is_admin() && isset( $_GET['activated'] ) && $pagenow == 'themes.php' ){
wp_redirect( admin_url( 'themes.php?page=Bing-theme.php' ) );
exit;
}
?>