<?php
//导航菜单
if ( function_exists('register_nav_menus') ) {
register_nav_menus( array(
	'header_menu' => '顶部菜单',
	'footer_menu' => '页脚菜单',
	'links_menu' => '友情链接',
) );
}
?>