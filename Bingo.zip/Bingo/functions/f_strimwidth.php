<?php
//摘要截断
function Bing_dm_strimwidth($str ,$start , $width ,$trimmarker ){
$output = preg_replace('/^(?:[\x00-\x7F]|[\xC0-\xFF][\x80-\xBF]+){0,'.$start.'}((?:[\x00-\x7F]|[\xC0-\xFF][\x80-\xBF]+){0,'.$width.'}).*/s','\1',$str); 
return $output.$trimmarker;
}

//任意内容截断
function Bing_strimwidth($title,$limit) {
    if(strlen($title) > $limit) {
        $title = substr($title, 0, $limit) . '...';
    }
    echo $title;
}
?>