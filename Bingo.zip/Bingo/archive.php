<?php get_header();get_sidebar('left'); ?>
<article id="main" class="corner5px b1s">
<div class="m15">
	<?php Bing_breadcrumbs(); ?>
	<div class="archive-img-div">
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<div class="archive-img part bt1d p105">
			<?php Bing_thumbnail(150,120); ?>
				<h3 class="title"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
				<p class="strimwidth"><?php echo Bing_dm_strimwidth(strip_tags($post->post_content),0,100,"..."); ?></p>
				<p class="postmeta"><span class="auth"><?php the_author_posts_link(); ?></span><span class="time"><time><?php the_time('Y年n月j日') ?></time></span><span class="eye"><?php Bing_post_views('', ''); ?></span><span class="comm"><a href="<?php the_permalink(); ?>#comments" title="《<?php the_title(); ?>》上的评论"><?php comments_popup_link('抢沙发', '2 次吐槽', '% 次吐槽', '', '吐槽系统没启动'); ?></a></span><span class="tag"><?php the_tags('', '   ', ''); ?></span></p>
		</div>
	<?php endwhile; ?>
	<?php else : ?>
	<p>这里好像什么文章都没有!~</p>
	<div class="b2"></div>
	<?php endif; ?>
	</div>
	<div class="page_navi"><?php Bing_par_pagenavi(9); ?></div>
</div>
</article>
<?php get_sidebar('right');get_footer(); ?>