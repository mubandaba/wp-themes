<?php get_header();get_sidebar('left'); ?>
<article id="main" class="corner5px bb1s">
	<div class="m15">
	<?php while ( have_posts() ) : the_post(); ?>
	<div class="content mt15">
		<?php Bing_breadcrumbs(); ?>
		<h2 class="title"><?php the_title(); ?></h2>
		<p class="postmeta mb15 bb1s"><span class="time"><time><?php the_time('Y年n月j日') ?></time></span><span class="eye"><?php Bing_post_views('', ''); ?></span><span class="comm"><a href="<?php the_permalink(); ?>#comments" title="《<?php the_title(); ?>》上的评论"><?php comments_popup_link('抢沙发', '2 次吐槽', '% 次吐槽', '', '吐槽系统没启动'); ?></a></span><span class="tag right"><?php the_tags('', '   ', ''); ?></span></p>
		<div class="context">
			<?php if ( dopt('Bing_single_text_ad') ) { ?>
			<div class="ad adst">
				<?php echo dopt('Bing_single_text_ad_code'); ?>
			</div>
			<?php } ?>
			<?php the_content(); ?>
		</div>
		<?php Bing_copyright(); ?>
		<?php if ( dopt('Bing_single_top_ad') ) { ?>
		<div class="ad adstop">
			<?php echo dopt('Bing_single_top_ad_code'); ?>
		</div>
		<?php } ?>
	</div>
	<?php endwhile; ?>
	<?php if (comments_open()) comments_template( '', true ); ?>
</article>
<?php get_sidebar('right');get_footer(); ?>