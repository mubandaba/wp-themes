<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<?php include('includes/seo.php'); ?>
<link rel="shortcut icon" href="<?php bloginfo('template_directory'); ?>/images/favicon.ico" type="image/x-icon" />
<link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet" type="text/css" />
<?php if( dopt('Bing_responsive') ) { ?><link href="<?php bloginfo('template_directory');?>/includes/css/responsive.css" rel="stylesheet" type="text/css" /><?php } ?>
<script type="text/javascript" src="<?php bloginfo('template_directory');?>/js/jquery.min.js"></script>
<!--[if IE 6]><script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/png.js"></script>
<script>DD_belatedPNG.fix('a,#logo,img');</script><![endif]-->
<!--[if lt IE 9]><script src="<?php bloginfo('template_directory'); ?>/js/html5.js"></script><![endif]-->
<?php include(TEMPLATEPATH.'/includes/tag-style.php'); ?>

<?php wp_head(); ?>
<body>
<header id="header">
	<div id="header-area">
		<h1 class="logo mr30"><a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?> | <?php bloginfo('description'); ?>"><?php bloginfo('name'); ?></a></h1>
		<nav class="nav" id="nav-top">
			<?php wp_nav_menu(array('theme_location'=>'header_menu')); ?>
		</nav>
		<form method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>" >
			<input class="search-input p47" name="s" type="text" placeholder="输入关键字搜索"<?php if( is_search() ){ echo ' value="'.$s.'"'; } ?> autofocus="" x-webkit-speech="">
			<input class="btn btn-primary search-submit p47" type="submit" value="搜索">
		</form>
	</div>
</header>
<section id="wrapper">
	<div id="maincont">