<?php get_header();get_sidebar('left'); ?>
<article id="main" class="corner5px bb1s">
	<div class="m15">
	<?php while ( have_posts() ) : the_post(); ?>
	<div class="content mt15">
		<?php Bing_breadcrumbs(); ?>
		<h2 class="title"><?php the_title(); ?></h2>
		<div class="context">
			<?php the_content(); ?>
		</div>
	</div>
	<?php endwhile; ?>
	<?php if (comments_open()) comments_template( '', true ); ?>
	</div>
</article>
<?php get_sidebar('right');get_footer(); ?>