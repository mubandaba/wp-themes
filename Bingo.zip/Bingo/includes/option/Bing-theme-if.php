<?php
//后台功能的判断

//更改后台字体
function Bing_admin_lettering(){
	echo'<style>*{font-family:"Microsoft YaHei" !important;}</style>';
}
if( dopt('Bing_Microsoft-YaHei') ) {add_action('admin_head', 'Bing_admin_lettering');}

//找回链接管理器
if( dopt('Bing_Link_Manager') ) {add_filter( 'pre_option_link_manager_enabled', '__return_true' );}

//固定后台管理工具条
function Bing_fixed_adminmenuwrap(){
  echo '<style type="text/css">#adminmenuwrap{position:fixed;left:0px;z-index:2;}</style>';
};
if( dopt('Bing_fixed_adminmenuwrap') ) {add_action('admin_head', 'Bing_fixed_adminmenuwrap');}

//后台评论快捷键回复
function Bing_admin_comment_ctrlenter(){
	echo '<script type="text/javascript">
		jQuery(document).ready(function($){
			$("textarea").keypress(function(e){
				if(e.ctrlKey&&e.which==13||e.which==10){
					$("#replybtn").click();
				}
			});
		});
	</script>';
};
if( dopt('Bing_admin_comment_ctrlenter') ) {add_action('admin_footer', 'Bing_admin_comment_ctrlenter');}

//增强默认编辑器
function Bing_editor_buttons($buttons){
$buttons[] = 'fontselect';
$buttons[] = 'fontsizeselect';
$buttons[] = 'backcolor';
$buttons[] = 'underline';
$buttons[] = 'hr';
$buttons[] = 'sub';
$buttons[] = 'sup';
$buttons[] = 'cut';
$buttons[] = 'copy';
$buttons[] = 'paste';
$buttons[] = 'cleanup';
$buttons[] = 'wp_page';
$buttons[] = 'newdocument';
return $buttons;
}
if( dopt('Bing_editor_buttons') ) {add_filter("mce_buttons_3", "Bing_editor_buttons");}

//隐藏版本更新提示
if( dopt('Bing_pre_site_transient') ) {add_filter('pre_site_transient_update_core', create_function('$a', "return null;"));}

//阻止站内文章互相Pingback 
function Bing_noself_ping( &$links ) {
  $home = get_option( 'home' );
  foreach ( $links as $l => $link )
  if ( 0 === strpos( $link, $home ) )
  unset($links[$l]);   
}
if( dopt('Bing_noself_ping') ) {add_action('pre_ping','Bing_noself_ping');}

//禁止自动保存草稿
function Bing_no_autosave() {
	wp_deregister_script('autosave');
}
if( dopt('Bing_no_autosav') ) {add_action( 'wp_print_scripts', 'Bing_no_autosave' );}

//移除头部无用信息
if( dopt('Bing_wp_generator') ) {
	remove_action( 'wp_head', 'wp_generator' );
}
if( dopt('Bing_wlwmanifest_link') ) {
	remove_action( 'wp_head', 'rsd_link' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
}
if( dopt('Bing_index_rel_link') ) {
	remove_action( 'wp_head', 'index_rel_link' );
	remove_action( 'wp_head', 'parent_post_rel_link', 10, 0 );
	remove_action( 'wp_head', 'start_post_rel_link', 10, 0 );
	remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0 );
}
if( dopt('Bing_feed_links') ) {
	remove_action( 'wp_head', 'feed_links', 2 );
	remove_action( 'wp_head', 'feed_links_extra', 3 );
}

//发布新文章通知百度PIGN服务器
if (!function_exists('noff_log')) {
    function noff_log($str = '') {
        if (defined('WP_DEBUG') && (WP_DEBUG == true)) {
            error_log($str . "\n", 3, WP_CONTENT_DIR . '/noff.log');
        }
    }
}
function ping_baidu_on_newpost($post_id) {
    $baiduXML = '
    <?xml version="1.0" encoding="UTF-8"?>
    <methodCall>
    <methodName>weblogUpdates.extendedPing</methodName>
    <params>
    <param>
    <value><string>' . get_option('blogname') . '</string></value>
    </param>
    <param>
    <value><string>' . home_url() . '</string></value>
    </param>
    <param>
    <value><string>' . get_permalink($post_id) . '</string></value>
    </param>
    <param>
    <value><string>' . get_feed_link() . '</string></value>
    </param>
    </params>
    </methodCall>';
    $wp_http_obj = new WP_Http();
    noff_log($baiduXML);
    $return = $wp_http_obj->post('http://ping.baidu.com/ping/RPC2', 
            array('body' => $baiduXML, 'headers' => array('Content-Type' => 'text/xml')));
    if(isset($return['body'])){
        if(strstr($return['body'], '<int>0</int>')){
            noff_log('ping baidu succeeded!');
        }
        else{
            noff_log('ping baidu failed!');
        }
    }else{
        noff_log('ping baidu failed!');
    }

}
function noff_on_newpost($post_id) {
    noff_log('start to ping baidu');
    ping_baidu_on_newpost($post_id);
}
if( dopt('Bing_ping_baidu') ) {add_action('publish_post', 'noff_on_newpost');}

//顶部挂钩代码
function Bing_header_code(){
	echo dopt('Bing_header_code');
}
add_filter("wp_head", "Bing_header_code");

//底部挂钩代码
function Bing_footer_code(){
	echo dopt('Bing_footer_code');
}
add_filter("wp_footer", "Bing_footer_code");
?>