<?php
$themename = $Bing_theme_name.'主题';

$options = array (

	//基本设置
	array( "name" => "基本设置","type" => "section","desc" => "主题的基本设置，包括模块是否开启和图片路径设置等。"),

	array( "name" => "响应式布局","type" => "tit"),	
	array( "id" => "Bing_responsive","type" => "checkbox" ),
	
	array( "name" => "头像缓存","type" => "tit"),	
	array( "id" => "Bing_avatar","type" => "checkbox" ),
	array( "id" => "Bing_avatar_shu","type" => "number","std" => "15","txt" => "缓存天数："),

	array( "name" => "博主昵称（用于在某些地方排除博主的信息）","type" => "tit"),	
	array( "id" => "Bing_blog_name","type" => "text","std" => "斌果","txt" => "博主昵称："),

	array( "name" => "博主邮箱（用于在某些地方显示博主的头像和信息）","type" => "tit"),	
	array( "id" => "Bing_blog_email","type" => "text","std" => "i@bgbk.org","txt" => "邮箱："),

	array( "name" => "建站日期","type" => "tit"),	
	array( "id" => "Bing_blog_date","type" => "text","std" => "20121001","txt" => "建站日期："),

	array( "name" => "timthumb裁剪缩略图","type" => "tit"),
	array( "id" => "Bing_timthumb","type" => "checkbox" ),

	array( "type" => "endtag"),
	
	//边栏控制
	array( "name" => "边栏控制","type" => "section","desc" => "主题侧边栏设置，包括板块数值设置等。"),
	
	array( "name" => "左侧边栏心情说","type" => "tit"),	
	array( "id" => "Bing_mood_say_id","type" => "number","std" => "745","txt" => "页面或文章id："),
	array( "id" => "Bing_mood_say_t","type" => "number","std" => "3","txt" => "显示条数："),

	array( "name" => "读者排行","type" => "tit"),	
	array( "id" => "Bing_dz_t","type" => "number","std" => "12","txt" => "显示条数："),
	array( "id" => "Bing_dz_ts","type" => "number","std" => "30","txt" => "几天内："),

	array( "name" => "关于信息 - 新浪微博地址","type" => "tit"),	
	array( "id" => "Bing_social_xlwb","type" => "text","std" => "http://www.bgbk.org/go?url=http://weibo.com/u/3479289377","txt" => "新浪微博地址："),

	array( "name" => "关于信息 - 腾讯微博地址","type" => "tit"),	
	array( "id" => "Bing_social_txwb","type" => "text","std" => "http://www.bgbk.org/go?url=http://t.qq.com/z719068600","txt" => "腾讯微博地址："),

	array( "name" => "关于信息 - 电子邮箱地址","type" => "tit"),	
	array( "id" => "Bing_social_email","type" => "text","std" => "http://www.bgbk.org/go?url=http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=HSosJC0rJSstLV1sbDN_cnA","txt" => "电子邮箱地址："),

	array( "name" => "关于信息 - RSS源地址","type" => "tit"),	
	array( "id" => "Bing_social_rss","type" => "text","std" => "http://www.bgbk.org/feed","txt" => "RSS源地址："),

	array( "type" => "endtag"),

	//评论系统
	array( "name" => "评论系统","type" => "section","desc" => "主题评论系统设置，完美提高用户体验，对症下药。"),

	array( "name" => "评论者链接go页面跳转","type" => "tit"),	
	array( "id" => "Bing_comment_about_go","type" => "checkbox" ),

	array( "name" => "Ajax无刷新评论","type" => "tit"),	
	array( "id" => "Bing_comment_ajax","type" => "checkbox" ),

	array( "name" => "官方人员","type" => "tit"),	
	array( "id" => "Bing_comment_gf","type" => "checkbox" ),

	array( "name" => "认证用户","type" => "tit"),	
	array( "id" => "Bing_comment_rz","type" => "checkbox" ),

	array( "name" => "评论等级","type" => "tit"),	
	array( "id" => "Bing_comment_author_class","type" => "checkbox" ),

	array( "type" => "endtag"),

	//首尾信息
	array( "name" => "网站信息","type" => "section","desc" => "主题的强化功能设置，默认全部不开启，请根据需要选择是否开启。"),
		
	array( "name" => "网站关键词（KeyWords）","type" => "tit"),
	array( "id" => "Bing_KeyWords","type" => "textarea","std" => "网站的关键词，SEO项目，及其重要。多个用英文半角逗号隔开。优化建议：一般不超过100个字符。"),

	array( "name" => "网站描述（Description）","type" => "tit"),
	array( "id" => "Bing_Description","type" => "textarea","std" => "网站的描述，SEO项目，及其重要。优化建议：一般不超过200个字符。"),

	array( "name" => "自定义版权信息","type" => "tit"),	
	array( "id" => "Bing_footer_copyright","type" => "textarea","std" => "Copyright 2012-2013 斌果博客	"),

	array( "name" => "统计代码","type" => "tit"),	
	array( "id" => "Bing_Statistics","type" => "checkbox" ),
	array( "id" => "Bing_Statistics_Code","type" => "textarea","std" => "网站的统计代码，推荐使用站长统计（www.cnzz.com）或者百度统计（tongji.baidu.com）。"),
	
	array( "name" => "移除Head无用信息中的“WordPress版本”","type" => "tit"),	
	array( "id" => "Bing_wp_generator","type" => "checkbox" ),

	array( "name" => "移除Head无用信息中的“离线编辑器接口”","type" => "tit"),	
	array( "id" => "Bing_wlwmanifest_link","type" => "checkbox" ),

	array( "name" => "移除Head无用信息中的“前后文、第一篇文章、主页meta信息”","type" => "tit"),	
	array( "id" => "Bing_index_rel_link","type" => "checkbox" ),

	array( "name" => "移除Head无用信息中的“Feed地址”","type" => "tit"),	
	array( "id" => "Bing_feed_links","type" => "checkbox" ),

	array( "name" => "在网站的头部添加如下代码（比如加载一段CSS或JS）","type" => "tit"),
	array( "id" => "Bing_header_code","type" => "textarea","std" => ""),

	array( "name" => "在网站的底部添加如下代码（比如加载一段JS）","type" => "tit"),
	array( "id" => "Bing_footer_code","type" => "textarea","std" => ""),

	array( "type" => "endtag"),
	
	//广告系统
	array( "name" => "广告系统","type" => "section","desc" => "主题集成的广告位是否开启和代码添加，拥有实时预览功能，避免反复调试刷新。"),
	
	array( "name" => "左侧边栏广告","type" => "tit"),
	array( "id" => "Bing_left_sidebar_ad","type" => "checkbox" ),
	array( "id" => "Bing_left_sidebar_ad_code","type" => "textarea","std" => ""),

	array( "name" => "右侧边栏广告","type" => "tit"),
	array( "id" => "Bing_right_sidebar_ad","type" => "checkbox" ),
	array( "id" => "Bing_right_sidebar_ad_code","type" => "textarea","std" => ""),

	array( "name" => "文章页下方广告","type" => "tit"),
	array( "id" => "Bing_single_top_ad","type" => "checkbox" ),
	array( "id" => "Bing_single_top_ad_code","type" => "textarea","std" => ""),

	array( "name" => "文章内容广告","type" => "tit"),
	array( "id" => "Bing_single_text_ad","type" => "checkbox" ),
	array( "id" => "Bing_single_text_ad_code","type" => "textarea","std" => ""),


	array( "type" => "endtag"),
	
	//后台杂项
	array( "name" => "后台杂项","type" => "section","desc" => "用此功能，可以减少绝大多数在优化或增强后台的插件。"),

	array( "name" => "找回“连接管理器”","type" => "tit"),	
	array( "id" => "Bing_Link_Manager","type" => "checkbox" ),
	
	array( "name" => "更改后台字体为“微软雅黑”","type" => "tit"),	
	array( "id" => "Bing_Microsoft-YaHei","type" => "checkbox" ),

	array( "name" => "固定后台管理工具栏","type" => "tit"),	
	array( "id" => "Bing_fixed_adminmenuwrap","type" => "checkbox" ),

	array( "name" => "后台评论添加 Ctrl+Enter 快捷回复","type" => "tit"),	
	array( "id" => "Bing_admin_comment_ctrlenter","type" => "checkbox" ),

	array( "name" => "增强 WordPress 默认文章编辑器","type" => "tit"),	
	array( "id" => "Bing_editor_buttons","type" => "checkbox" ),

	array( "name" => "隐藏主题、插件版本更新提示","type" => "tit"),	
	array( "id" => "Bing_pre_site_transient","type" => "checkbox" ),

	array( "name" => "阻止站内文章互相 Pingback","type" => "tit"),	
	array( "id" => "Bing_noself_ping","type" => "checkbox" ),

	array( "name" => "禁止 WordPress 默认文章编辑器自动保存草稿","type" => "tit"),	
	array( "id" => "Bing_no_autosave","type" => "checkbox" ),

	array( "name" => "发布新文章通知百度PIGN服务器（慎用）","type" => "tit"),	
	array( "id" => "Bing_ping_baidu","type" => "checkbox" ),

	array( "type" => "endtag"),

);

function dopt($e){
    return stripslashes(get_option($e));
}

function mytheme_add_admin() {
	global $themename, $options;
	if ( $_GET['page'] == basename(__FILE__) ) {
		if ( 'save' == $_REQUEST['action'] ) {
			foreach ($options as $value) {
				update_option( $value['id'], $_REQUEST[ $value['id'] ] ); 
			}
			/*
			foreach ($options as $value) {
				if( isset( $_REQUEST[ $value['id'] ] ) ) { update_option( $value['id'], $_REQUEST[ $value['id'] ]  ); }
				else { delete_option( $value['id'] ); } 
			}
			*/
			header("Location: admin.php?page=Bing-theme.php&saved=true");
			die;
			foreach ($options as $value) {delete_option( $value['id'] ); }
		}
		else if( 'reset' == $_REQUEST['action'] ) {
			header("Location: admin.php?page=Bing-theme.php&reset=true");
			die;
		}
	}
	$icon = get_template_directory_uri().'/includes/option/images/general.png';
	add_menu_page($themename." Options", $themename , 'edit_themes', basename(__FILE__), 'mytheme_admin' , $icon);
}

function mytheme_admin() {
	global $themename, $options;
	$i=0;
	if ( $_REQUEST['saved'] ) echo '<div class="d_message">'.$themename.'修改已保存</div>';
	if ( $_REQUEST['reset'] ) echo '<div class="d_message">'.$themename.'已恢复设置</div>';
?>
<?php
//获取站点所有分类的di
function Bing_show_category() {
	global $wpdb;
	$request = "SELECT $wpdb->terms.term_id, name FROM $wpdb->terms ";
	$request .= " LEFT JOIN $wpdb->term_taxonomy ON $wpdb->term_taxonomy.term_id = $wpdb->terms.term_id ";
	$request .= " WHERE $wpdb->term_taxonomy.taxonomy = 'category' ";
	$request .= " ORDER BY term_id asc";
	$categorys = $wpdb->get_results($request);
	foreach ($categorys as $category) { //调用菜单
		$output = '<span>'.$category->name."(".$category->term_id.')</span>';
		echo $output;
	}
}
//栏目列表结束
?>
<div class="wrap d_wrap">
	<link rel="stylesheet" href="<?php bloginfo('template_url') ?>/includes/option/Bing-theme.css"/>
	<h2><?php echo $themename; ?>设置
		<span class="d_themedesc">设计师：<a href="http://www.bgbk.org/" target="_blank">斌果</a> &nbsp;&nbsp; <script type="text/javascript" src="http://js.bgbk.org/themead/Bingo/Bingo.js"></script>
	</h2>
	
	<form method="post" class="d_formwrap">
		<div class="d_tab">
			<ul>
				<li class="d_tab_on">基本设置</li>
                <li>边栏控制</li>
                <li>评论系统</li>
                <li>首尾信息</li>
                <li>广告系统</li>
                <li>后台杂项</li>
			</ul>
		</div>
		<?php foreach ($options as $value) { switch ( $value['type'] ) { case "": ?>
			<?php break; case "tit": ?>
			</li><li class="d_li">
			<h4><?php echo $value['name']; ?>：</h4>
			<div class="d_tip"><?php echo $value['tip']; ?></div>
			
			<?php break; case 'text': ?>
			<input class="d_inp <?php echo $value['class']; ?>" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" value="<?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id'])  ); } else { echo $value['std']; } ?>" />

			<?php break; case 'number': ?>
			<label class="d_number"><?php echo $value['txt']; ?><input class="d_num <?php echo $value['class']; ?>" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" value="<?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id'])  ); } else { echo $value['std']; } ?>" /></label>
			
			<?php break; case 'textarea': ?>
			<textarea class="d_tarea" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" cols="" rows=""><?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id']) ); } else { echo $value['std']; } ?></textarea>
			
			<?php break; case 'select': ?>
			<?php if ( $value['desc'] != "") { ?><span class="d_the_desc" id="<?php echo $value['id']; ?>_desc"><?php echo $value['desc']; ?></span><?php } ?><select class="d_sel" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>">
				<?php foreach ($value['options'] as $option) { ?>
				<option <?php if (get_settings( $value['id'] ) == $option) { echo 'selected="selected" class="d_sel_opt"'; } ?>><?php echo $option; ?></option>
				<?php } ?>
			</select>
			
			<?php break; case "checkbox": ?>
			<?php if(get_settings($value['id']) != ""){ $checked = "checked=\"checked\""; }else{ $checked = "";} ?>
			<label class="d_check"><input type="checkbox" id="<?php echo $value['id']; ?>" name="<?php echo $value['id']; ?>" <?php echo $checked; ?> />开启</label>
			
			<?php break; case "section": $i++; ?>
			<div class="d_mainbox" id="d_mainbox_<?php echo $i; ?>">
				<ul class="d_inner">
					<li class="d_li">
				
			<?php break; case "endtag": ?>
			</li></ul>
			<div class="d_desc"><input class="button-primary" name="save<?php echo $i; ?>" type="submit" value="保存设置" /></div>
			</div>
			
		<?php break; }} ?>
				
		<input type="hidden" name="action" value="save" />

	</form>
<script src="<?php bloginfo('template_url') ?>/js/jquery.min.js"></script>
<script src="<?php bloginfo('template_url') ?>/includes/option/Bing-theme.js"></script>
</div>
<?php } ?>
<?php
add_action('admin_menu', 'mytheme_add_admin');
include('Bing-theme-if.php');
?>