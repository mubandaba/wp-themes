<style>
<?php if( dopt('Bing_hasfixed') ) { ?>#header{position:fixed;left:0px;z-index:2001;}#wrapper{margin-top:77px;}<?php } ?>
</style>