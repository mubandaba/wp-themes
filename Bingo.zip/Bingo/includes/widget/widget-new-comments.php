<?php  
//主题小工具：读者排行
add_action('widgets_init', create_function('', 'return register_widget("readers");'));

class readers extends WP_Widget {
	function readers() {
		global $prename;
		$this->WP_Widget('readers', $prename.'Bing - 读者排行 ', array( 'description' => '显示评论数量最多的几名网友！' ));
	}
	function widget($args, $instance) {
		extract($args, EXTR_SKIP);
		echo $before_widget;
		$title = apply_filters('widget_name', $instance['title']);
		$limit = $instance['limit'];
		$time = $instance['time'];

		echo $before_title.$title.$after_title; ?>
		<?php Bing_readers($out,$timer=$instance['time'],$limit=$instance['limit']); ?>
		<ul>
		<?php
		$counts = $wpdb->get_results("SELECT COUNT(comment_ID) AS cnt, comment_author, comment_author_url, comment_author_email FROM (SELECT * FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->posts.ID=$wpdb->comments.comment_post_ID) WHERE comment_date > date_sub( NOW(), INTERVAL 1 MONTH ) AND user_id='0' AND comment_author_email != '' AND post_password='' AND comment_approved='1' AND comment_type='') AS tempcmt GROUP BY comment_author_email ORDER BY cnt DESC LIMIT 7");//显示个数
		foreach ($counts as $count) {
		$a = 'http://www.gravatar.com/avatar/' .md5(strtolower($count->comment_author_email)). '?s=90&d=&r=G';
		$c_url = $count->comment_author_url;
		$mostactive .= '<li>' . '<a href="/go.php?url='. $c_url . '" title="' . $count->comment_author . ' (留下'. $count->cnt . '个脚印)" target="_blank" rel="external nofollow" class="SC_wpd_item"><img src="' . $a . ' "/></a></li>';
		}
		echo $mostactive;
		?>
		</ul>
		<?php echo $after_widget;
	}
	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['limit'] = strip_tags($new_instance['limit']);
		$instance['time'] = strip_tags($new_instance['time']);
		return $instance;
	}
	function form($instance) {
		$instance = wp_parse_args( (array) $instance, array( 
			'title' => '读者排行',
			'limit' => '12',
			'time' => '90',
			) 
		);
		$title = strip_tags($instance['title']);
		$limit = strip_tags($instance['limit']);
		$time = strip_tags($instance['time']);

?>
		<p>
			<label>
				标题：
				<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $instance['title']; ?>" />
			</label>
		</p>
		<p>
			<label>
				显示数目（最多显示20个）：
				<input class="widefat" id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="number" value="<?php echo $instance['limit']; ?>" />
			</label>
		</p>
		<p>
			<label>
				几天内：
				<input class="widefat" id="<?php echo $this->get_field_id('time'); ?>" name="<?php echo $this->get_field_name('time'); ?>" type="number" value="<?php echo $instance['time']; ?>" />
			</label>
		</p>
		<p>
			注意：本工具会自动过滤已登录的管理员用户的评论，管理员建议以登录状态回复网友评论。
		</p>
<?php
	}
}
?>