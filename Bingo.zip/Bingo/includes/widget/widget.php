<?php
//小工具定义
$before_widget='<div class="widget %2$s %2$s_left">';
$before_widget_right='<div class="widget %2$s %2$s_right">';
$after_widget='</div></div>';
$before_title='<h3>';
$after_title='</h3><div class="widget-container m15">';
if (function_exists('register_sidebar')){
	//首页侧边栏（左）
    register_sidebar(array(
        'name'          => '首页侧边栏（左）',
        'id'            => 'widget_home_left',
        'before_widget' => $before_widget,
        'after_widget'  => $after_widget,
        'before_title'  => $before_title,
        'after_title'   => $after_title,
    ));

    //文章页侧边栏（左）
    register_sidebar(array(
        'name'          => '文章页侧边栏（左）',
        'id'            => 'widget_single_left',
        'before_widget' => $before_widget,
        'after_widget'  => $after_widget,
        'before_title'  => $before_title,
        'after_title'   => $after_title,
    ));

    //其它页侧边栏（左）
    register_sidebar(array(
        'name'          => '其它页侧边栏（左）',
        'id'            => 'widget_no_left',
        'before_widget' => $before_widget,
        'after_widget'  => $after_widget,
        'before_title'  => $before_title,
        'after_title'   => $after_title,
    ));
	
    //首页侧边栏（右）
    register_sidebar(array(
        'name'          => '首页侧边栏（右）',
        'id'            => 'widget_home_right',
        'before_widget' => $before_widget_right,
        'after_widget'  => $after_widget,
        'before_title'  => $before_title,
        'after_title'   => $after_title,
    ));

    //文章页侧边栏（右）
    register_sidebar(array(
        'name'          => '文章页侧边栏（右）',
        'id'            => 'widget_single_right',
        'before_widget' => $before_widget_right,
        'after_widget'  => $after_widget,
        'before_title'  => $before_title,
        'after_title'   => $after_title,
    ));

    //其它页侧边栏（右）
    register_sidebar(array(
        'name'          => '其它页侧边栏（右）',
        'id'            => 'widget_no_right',
        'before_widget' => $before_widget_right,
        'after_widget'  => $after_widget,
        'before_title'  => $before_title,
        'after_title'   => $after_title,
    ));
}
//引入自定义小工具
include('widget-new-comments.php');
include('widget-comments-notice.php');
include('widget-comments-new.php');
?>