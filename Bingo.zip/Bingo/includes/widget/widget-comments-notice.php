<?php  
//主题小工具：评论公告
add_action('widgets_init', create_function('', 'return register_widget("mood");'));

class mood extends WP_Widget {
	function mood() {
		global $prename;
		$this->WP_Widget('mood', $prename.'Bing - 评论公告 ', array( 'description' => '以评论为控制的特色公告板！' ));
	}
	function widget($args, $instance) {
		extract($args, EXTR_SKIP);
		echo $before_widget;
		$title = apply_filters('widget_name', $instance['title']);
		$limit = $instance['limit'];
		$time = $instance['time'];

		echo $before_title.$title.$after_title; ?>
		<?php
		$page_ID=$time;
		$num=$limit;
		echo '<ul>';
			$announcement = '';
			$comments = get_comments("number=$num&post_id=$page_ID");
			if ( !empty($comments) ) {
				foreach ($comments as $comment) {
					$announcement .= '<li>'. convert_smilies($comment->comment_content) . '</li>';
				}
			}
			if ( empty($announcement) ) $announcement = '<li>欢迎光临本博！欢迎光临本博！欢迎光临本博！欢迎光临本博！</li>';
			echo $announcement;
			echo '</ul>';
			if ($user_ID) echo '<p style="text-align:right;">[<a href="' . get_page_link($page_ID) . '#respond" rel="nofollow" class="anno">发表公告</a>]</p>';
			?>
		<?php echo $after_widget;
	}
	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['limit'] = strip_tags($new_instance['limit']);
		$instance['time'] = strip_tags($new_instance['time']);
		return $instance;
	}
	function form($instance) {
		$instance = wp_parse_args( (array) $instance, array( 
			'title' => '公告板',
			'limit' => '1',
			'time' => '752',
			) 
		);
		$title = strip_tags($instance['title']);
		$limit = strip_tags($instance['limit']);
		$time = strip_tags($instance['time']);

?>
		<p>
			<label>
				标题：
				<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $instance['title']; ?>" />
			</label>
		</p>
		<p>
			<label>
				显示数目：
				<input class="widefat" id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="number" value="<?php echo $instance['limit']; ?>" />
			</label>
		</p>
		<p>
			<label>
				页面或文章id：
				<input class="widefat" id="<?php echo $this->get_field_id('time'); ?>" name="<?php echo $this->get_field_name('time'); ?>" type="number" value="<?php echo $instance['time']; ?>" />
			</label>
		</p>
<?php
	}
}

?>