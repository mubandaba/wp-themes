<?php  
//主题小工具：最新评论
add_action('widgets_init', create_function('', 'return register_widget("new_comments");'));

class new_comments extends WP_Widget {
	function new_comments() {
		global $prename;
		$this->WP_Widget('new_comments', $prename.'Bing - 最新评论 ', array( 'description' => '显示带头像的最新的几条评论！' ));
	}
	function widget($args, $instance) {
		extract($args, EXTR_SKIP);
		echo $before_widget;
		$title = apply_filters('widget_name', $instance['title']);
		$limit = $instance['limit'];
		$time = $instance['time'];

		echo $before_title.$title.$after_title; ?>
			<ul>
				<?php
					$outer=dopt('Bing_blog_name');
					global $wpdb;
					$sql = "SELECT DISTINCT ID, post_title, post_password, comment_ID, comment_post_ID, comment_author, comment_date_gmt, comment_approved, comment_type,comment_author_url,comment_author_email, SUBSTRING(comment_content,1,16) AS com_excerpt FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID = $wpdb->posts.ID) WHERE comment_approved = '1' AND comment_type = '' AND post_password = '' AND user_id='0' AND comment_author != '".$outer."' ORDER BY comment_date_gmt DESC LIMIT 20";
					$comments = $wpdb->get_results($sql);
					$output = $pre_HTML;
					foreach ($comments as $comment) {$output .= "\n<li>".get_avatar( $comment, 32,'',$comment->comment_author)." <a href=\"" . get_permalink($comment->ID) ."#comment-" . $comment->comment_ID . "\" title=\"发表在： " .$comment->post_title . "\">" .strip_tags($comment->comment_author).":<br/>". strip_tags($comment->com_excerpt)."</a><br /></li>";}
					$output .= $post_HTML;
					echo $output;
				?>
			</ul>
		<?php echo $after_widget;
	}
	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['limit'] = strip_tags($new_instance['limit']);
		return $instance;
	}
	function form($instance) {
		$instance = wp_parse_args( (array) $instance, array( 
			'title' => '最新评论',
			'limit' => '5',
			) 
		);
		$title = strip_tags($instance['title']);
		$limit = strip_tags($instance['limit']);

?>
		<p>
			<label>
				标题：
				<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $instance['title']; ?>" />
			</label>
		</p>
		<p>
			<label>
				显示数目：
				<input class="widefat" id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="number" value="<?php echo $instance['limit']; ?>" />
			</label>
		</p>
		<p>
			注意：本工具会自动过滤已登录的管理员用户的评论，管理员建议以登录状态回复网友评论。
		</p>
<?php
	}
}
?>