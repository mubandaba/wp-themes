<?php

/* 囤主题 www.tzhuti.com*
 * No Topics Feedback Part
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<?php echo '
    <div class="loading-dom pos-r"><div class="lm"><i class="iconfont zrz-icon-font-wuneirong"></i><p class="mar10-t fs13 gray">没有话题</p></div></div>
'; ?>
