<?php

/* 囤主题 www.tzhuti.com*
 * Logged In Feedback Part
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<?php echo zrz_empty_page('你已经登录了我的朋友'); ?>
