<?php

/* 囤主题 www.tzhuti.com*
 * No Forums Feedback Part
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<?php echo '
    <div class="loading-dom pos-r"><div class="lm"><i class="iconfont zrz-icon-font-wuneirong"></i><p class="mar10-t">没有任何板块</p></div></div>
'; ?>
