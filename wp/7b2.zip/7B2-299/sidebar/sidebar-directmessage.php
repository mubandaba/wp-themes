<?php
/* 囤主题 www.tzhuti.com
* 私信侧边栏，侧边栏
*/
?>
<section id="pages-2" class="widget widget_write mar10-b">
    <h2 class="widget-title l1 pd10 box-header">提示</h2>
    <div class="box">
        <ul>
            <li>
                <b>规范</b>
                <p>您可以通过私信和网站的其他人进行秘密沟通。</p>
                <p>沟通的过程中，请保持礼貌。</p>
                <p>禁止故意通过私信传播垃圾广告信息。</p>
            </li>
        <ul>
    </div>
</section>
