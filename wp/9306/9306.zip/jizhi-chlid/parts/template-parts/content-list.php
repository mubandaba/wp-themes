<div class="col-lg-6">
  <article id="post-<?php the_ID(); ?>" <?php post_class( 'post post-list' ); ?>>
  	<?php
	$site_lanmu_text = _cao('site_lanmu_text');
	if (is_array($site_lanmu_text)  && _cao('home_zypd_text') ) : ?>
  	<?php if ((_get_post_shop_status() || _get_post_shop_hide()) && _cao('grid_is_price',true)) : 
  	$post_price = _get_post_price();
  	$post_price =($post_price) ? '<i class="vwip30"></i>' : '<i class="vwip10"></i>' ;
  ?>
  	<?php echo ''.$post_price;?>
  <?php endif; ?>
  <?php endif; ?>
    <?php cao_entry_media(); ?>
    <div class="entry-wrapper">
      <?php cao_entry_header( array( 'category' => true ,'author'=>true ) ); ?>
      <div class="entry-excerpt u-text-format"><?php echo _get_excerpt(); ?></div>
      <?php get_template_part( 'parts/entry-footer' ); ?>
    </div>
  </article>
</div>