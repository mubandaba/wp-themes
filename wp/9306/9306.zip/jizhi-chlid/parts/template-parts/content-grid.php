<?php if (_cao('is_mobele_list') && wp_is_mobile()) {
    get_template_part( 'parts/template-parts/content','list');
}else{
  $post_author_id   = get_post()->post_author;
?>
<div class="col-lg-1-5 col-6 col-sm-6 col-md-4 col-lg-3">
  <article id="post-<?php the_ID(); ?>" <?php post_class( 'post post-grid' ); ?>>
  	<?php
	$site_lanmu_text = _cao('site_lanmu_text');
	if (is_array($site_lanmu_text)  && _cao('home_zypd_text') ) : ?>
  	<?php if ((_get_post_shop_status() || _get_post_shop_hide()) && _cao('grid_is_price',true)) : 
  	$post_price = _get_post_price();
  	$post_price =($post_price) ? '<i class="vwip30"></i>' : '<i class="vwip10"></i>' ;
  ?>
  	<?php echo ''.$post_price;?>
  <?php endif; ?>
  <?php endif; ?>
    <?php cao_entry_media(); ?>
    <div class="entry-wrapper">
      <?php if (_cao('grid_is_author',true)) { ?>
      <?php } ?>
      <?php cao_entry_header( array( 'category' => true ) ); ?>
      <?php if (_cao('grid_is_excerpt')) : ?>
       <div class="entry-excerpt u-text-format"><?php echo _get_excerpt(); ?></div>
      <?php endif; ?>
      <?php get_template_part( 'parts/entry-footer' ); ?>
    </div>
  </article>
</div>
<?php } ?>