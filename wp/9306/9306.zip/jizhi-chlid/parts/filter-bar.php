<?php 
    if (!_cao('is_filter_bar')) :
    $cat_ID = (is_category()) ? get_query_var('cat') : 0 ;
    $cat_orderby = _cao('is_filter_item_cat_orderby','id');
    ///////////S CACHE ////////////////
    $categories = get_terms('category', array('hide_empty' => 0,'parent' => 0,'orderby' =>$cat_orderby,'order' => 'DESC')); //缓存数据
    ///////////S CACHE ////////////////
?>

<div class="filter--content">
    <?php
    $site_lanmu_text = _cao('site_lanmu_text');
    if (is_array($site_lanmu_text)  && _cao('home_lanmu_text') ) : ?> 
	<div class="zhankr_type_bj">
	<span><?php echo $site_lanmu_text['lanmu_text']; ?><em class="text-p"><?php echo $site_lanmu_text['lanmu_down']; ?></em></span>
	<?php
    $site_lanmu_text = _cao('site_lanmu_text');
    if (is_array($site_lanmu_text)  && _cao('home_lanmuss_text') ) : ?> 
	<div class="header_search" style="float: right;height: 38px;line-height: 28;text-align: left; margin-top: 10px;border-radius: 4px;width: 360px;position: inherit;">
            <div class="search_form">
                <div class="search_input" data-search="top-banner" style="background: #fff;">
                    <div class="search_filter" id="header_filter_cate">
                    </div>
                    <input class="search-input" id="search-keywords-cate" placeholder="搜索当前分类..." type="text" name="s" autocomplete="off">
                    <input type="hidden" name="search-cate" class="btn_search" data-search-btn="search-btn">
                </div>
                <div class="search_btn" id="search-btn-cate"><i class="fa fa-search zhankr-icon"></i></div>
            </div>
        </div>
        <script>
            (function ($) {
                $(function () {
                    $("#search-btn-cate").on("click",function () {
                        location.href='/?s='+$("#search-keywords-cate").val()+'&cat=<?php $category = get_category( get_query_var( 'cat' ) );
                            $cat_id = $category->cat_ID;;
                        echo $cat_id;?>';
                    })
                })
            })(jQuery)
        </script>
    <?php endif; ?>
	</div>
	<?php endif; ?>
    <form class="mb-0 zhankr_lmdh" method="get" action="<?php echo home_url(); ?>">
        <input type="hidden" name="s">
        <div class="form-box search-properties mb-0">
            <!-- 一级分类 -->
            <?php if (_cao('is_filter_item_cat','1')) : ?>
            <div class="filter-item">
                <?php
                $content = '<ul class="filter-tag"><span><i class="fa fa-folder-open-o"></i> 分类</span>';
                foreach ($categories as $category) {
                    // 排除二级分类
                    $_oncss = ($category->term_id == $cat_ID) ? 'on' : '' ;
                    $content .= '<li><a href="'.get_category_link($category->term_id).'" class="'.$_oncss.'">'.$category->name.'</a></li>';
                }
                $content .= "</ul>";
                echo $content;
                ?>
            </div>
            <?php endif; ?>
            

            <?php 
            if (is_category()) {
                $child_categories = get_categories( array('hide_empty' => 0,'parent'=>$cat_ID) );//获取所有分类
                if (empty($child_categories)) {
                    $root_cat_ID = get_category_root_id($cat_ID);
                    $child_categories = get_categories( array('hide_empty' => 0,'parent'=>$root_cat_ID) );//获取所有分类
                }
            }
            if (!empty($child_categories) && _cao('is_filter_item_cat2','1')) : ?>
            <!-- 二级分类 -->
            <div class="filter-item">
                <?php
                    $content = '<ul class="filter-tag"><span><i class="fa fa-long-arrow-right"></i> 更多</span>';
                    foreach ($child_categories as $category) {
                        $_oncss = ($category->term_id == $cat_ID) ? 'on' : '' ;
                        $content .= '<li><a href="'.get_category_link($category->term_id).'" class="'.$_oncss.'">'.$category->name.'</a></li>';
                    }
                    $content .= "</ul>";
                    echo $content;
                ?>
            </div>
            <?php endif; ?>

            <!-- 相关标签 -->
            <?php if (_cao('is_filter_item_tags','1')){
                $cat_ID = (get_query_var('cat')) ? get_query_var('cat') : 0 ;
                $this_cat_arg = array( 'categories' => $cat_ID);
                ///////////S CACHE ////////////////
                $tags = _get_category_tags($this_cat_arg); //缓存数据
                ///////////S CACHE ////////////////
                
                if(!empty($tags)) {
                    echo '<div class="filter-item">';
                    $content = '<ul class="filter-tag"><span><i class="fa fa-tags"></i> 标签</span>';
                      foreach ($tags as $tag) {
                        $content .= '<li><a href="'.get_tag_link($tag->term_id).'">'.$tag->name.'</a></li>';
                      }
                    $content .= "</ul>";
                    echo $content;
                    echo '</div>';
                }
            }?>
            <!-- 自定义筛选 -->
            <?php if (_cao('is_custom_post_meta_opt', '0') && _cao('custom_post_meta_opt', '0')) {
                $custom_post_meta_opt = _cao('custom_post_meta_opt', '0');
                foreach ($custom_post_meta_opt as $filter) {
                    $opt_meta_category = (array_key_exists('meta_category',$filter)) ? $filter['meta_category'] : false ;
                    if (!$opt_meta_category || in_array($cat_ID,$opt_meta_category) ) {
                        $_meta_key = $filter['meta_ua'];
                        echo '<div class="filter-item">';
                            $is_on = !empty($_GET[$_meta_key]) ? $_GET[$_meta_key] : '';
                            $content = '<ul class="filter-tag"><span>'.$filter['meta_name'].'</span>';
                            $meta_opt_arr = array('all' => '全部');
                            $_oncssall = ($is_on == 'all') ? 'on' : '' ;
                            $content .= '<li><a href="'.add_query_arg($_meta_key,'all').'" class="'.$_oncssall.'">全部</a></li>';
                            foreach ($filter['meta_opt'] as $opt) {
                                $_oncss = ($is_on == $opt['opt_ua']) ? 'on' : '' ;
                                $content .= '<li><a href="'.add_query_arg($_meta_key,$opt['opt_ua']).'" class="'.$_oncss.'">'.$opt['opt_name'].'</a></li>';
                            }
                            $content .= "</ul>";
                            echo $content;
                        echo '</div>';
                    }
                   
                }
            }?>
            <?php if ( (_cao('is_filter_item_price', '0') || _cao('is_filter_item_order', '0')) && is_site_shop_open() ) : ?>
            <div class="filter-tab">
                <div class="row">
                    <div class="col-12 col-sm-6">
                        <?php if (_cao('is_filter_item_price','1')) : 
                            $is_on = !empty($_GET['cao_type']) ? $_GET['cao_type'] : '';
                            $cao_vip_name = _cao('site_vip_name');
                            $content = '<ul class="filter-tag"><span><i class="fa fa-filter"></i> 价格</span>';
                            $caotype_arr = array('0' => '全部','1' => '免费','2' => '付费' ,'3' => $cao_vip_name.'免费','4' => $cao_vip_name.'优惠');
                            foreach ($caotype_arr as $key => $item) {
                                $_oncss = ($is_on == $key) ? 'on' : '' ;
                                $content .= '<li><a href="'.add_query_arg("cao_type",$key).'" class="tab '.$_oncss.'"><i></i><em>'.$item.'</em></a></li>';
                            }
                            $content .= "</ul>";
                            echo $content;
                        endif; ?>
                    </div>
                    <div class="col-12 col-sm-6">
                        <!-- 排序 -->
                        <?php if (_cao('is_filter_item_order','1')) : 
                                $is_on = !empty($_GET['order']) ? $_GET['order'] : 'date';
                                $content = '<ul class="filter-tag" style="width: 100%;"><div class="right">';
                                $order_arr = array('date' => '发布日期','modified' => '修改时间','comment_count' => '评论数量','rand' => '随机','hot' => '热度');
                                foreach ($order_arr as $key => $item) {
                                    $_oncss = ($is_on == $key) ? 'on' : '' ;
                                    $content .= '<li class="rightss"><i class="fa fa-caret-down"></i> <a href="'.add_query_arg("order",$key).'" class="'.$_oncss.'">'.$item.'</a></li>';
                                }
                                $content .= "</div></ul>";
                                echo $content;
                        endif; ?>
                        
                    </div>
                </div>
            </div>
            <?php endif;?>

            <!-- .row end -->
        </div>
        <!-- .form-box end -->
    </form>
</div>
<?php endif;?>