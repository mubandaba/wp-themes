
<div class="cao_entry_header">
<?php edit_post_link('[编辑]'); ?>
<?php
$site_lanmu_text = _cao('site_lanmu_text');
if (is_array($site_lanmu_text)  && _cao('home_zybt_text') ) : ?>
<?php
  if ( ! is_page() ) {
    cao_entry_header( array( 'tag' => 'h1', 'link' => false) );
  } else {
  	cao_entry_header( array( 'tag' => 'h1') );
  }

 
  get_template_part( 'parts/entry-subheading' );
?>
<?php endif; ?>
<div class="zhankr-d"><i class="zhankr-title-iconse zhankr-float-rightse"></i></div>
<div class="zhankr-post-top">
  <div class="wrap">
    <a href="#singular_content" class="current">正文概述</a>
    <?php
	$site_lanmu_text = _cao('site_lanmu_text');
	if (is_array($site_lanmu_text)  && _cao('home_zybt_text') ) : ?>
    <span class="sjblog-name"><a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID', $author_id ) ) ); ?>"><i class="fa fa-user"></i> <?php the_author(); ?></a>&nbsp;&nbsp;<span class="sjblog-time"> <i class="fa fa-clock-o"></i>  <?php echo the_time('Y-m-j'); ?></span>&nbsp;&nbsp;<span class="sjblog-views"> <?php echo '<i class="fa fa-eye"></i> '._get_post_views();?> </span>
    </span>
    <?php endif; ?>
  </div>
</div>
</div>