<?php
  $email = get_the_author_meta( 'user_email' );
  $author_id = get_the_author_meta( 'ID' );
  $is_post_favcss = (is_get_post_fav(get_the_ID())) ? ' ok' : '';
?>
<!--常见问题-->
<?php
$site_zkfaq_text = _cao('site_zkfaq_text');
if (is_array($site_zkfaq_text)  && _cao('home_zkfaq_text') ) : ?>
<div id="help" class="m main">
  <h2 class="mt mt20">常见问题FAQ</h2>
  <div class="mb">
    <dl>
      <dt><i></i><?php echo $site_zkfaq_text['zkfaq1_text']; ?></dt>
      <dd style="display: block;"><i></i><?php echo $site_zkfaq_text['zkfaq1_down']; ?></dd>
    </dl>
    <dl>
      <dt><i></i><?php echo $site_zkfaq_text['zkfaq2_text']; ?></dt>
      <dd style="display: none;"><i></i><?php echo $site_zkfaq_text['zkfaq2_down']; ?></dd>
    </dl>
    <dl>
      <dt><i></i><?php echo $site_zkfaq_text['zkfaq3_text']; ?></dt>
      <dd style="display: none;"><i></i><?php echo $site_zkfaq_text['zkfaq3_down']; ?></dd>
    </dl>
    <dl>
      <dt><i></i><?php echo $site_zkfaq_text['zkfaq4_text']; ?></dt>
      <dd style="display: none;"><i></i><?php echo $site_zkfaq_text['zkfaq4_down']; ?></dd>
    </dl>
    
  </div>
</div>
<?php endif; ?>
<!--常见问题-->
<div class="article-footer">
  <?php if( _cao('single_disable_author_box') ) : ?>
  <div class="author-box">
    <div class="author-image">
      <?php echo get_avatar( get_the_author_meta( 'email' ), '140', null, get_the_author_meta( 'display_name' ) ); ?>
    </div>
    <div class="author-info">
      <h4 class="author-name">
        <a<?php echo _target_blank(); ?> href="javascript:;"><?php the_author(); ?></a>
        <?php $CaoUser = new CaoUser($author_id);
        if ($CaoUser->vip_status()) {
          echo '<span class="label label-warning"><i class="fa fa-diamond"></i> '.$CaoUser->vip_name().'</span>';
        }else{
          echo '<span class="label label-default"><i class="fa fa-diamond"></i> '.$CaoUser->vip_name().'</span>';
        }
        ?>
      </h4>
    </div>
  </div>
  <?php endif;?>
  <?php if (!_cao('post_share_mod','0')): ?>
  <div class="xshare">
      <span class="xshare-title">分享到：</span>
      <?php if (_cao('is_nav_myfav') && is_site_shop_open()): ?>
           <a href="javascript:;" title="收藏文章" etap="star" data-postid="<?php the_ID(); ?>" class="ripro-star<?php echo $is_post_favcss;?>"><i class="fa fa-star-o"></i></a>
      <?php endif; ?>
      <a href="" etap="share" data-share="qq" class="share-qq"><i class="fa fa-qq"></i></a>
      <a href="" etap="share" data-share="weibo" class="share-weibo"><i class="fa fa-weibo"></i></a>
      <?php if( _cao('poster_share_open') ){ ?>
        <a href="javascript:;" class="btn-bigger-cover share-weixin" data-nonce="<?php echo wp_create_nonce('mi-create-bigger-image-'.$post->ID );?>" data-id="<?php echo $post->ID; ?>" data-action="create-bigger-image" id="bigger-cover"><i class="fa fa-paper-plane"></i></a>
      <?php } ?>
  </div>
  <?php endif; ?>
 
</div>