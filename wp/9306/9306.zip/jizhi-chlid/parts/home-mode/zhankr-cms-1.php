<?php
// CMS模块-风格1
$mobile = _cao('zhankr-cms-1');
?>
<div class="home-first-screen"><div class="container">
<div class="parts row">

<div class="col-sm-6 col-md-3 part-first">
<div class="home-first-part home-menus">
<ul>
<li><a href="/shop" target="_blank"><i class="fa fa-desktop icoid1"></i><span>模板商城</span></a></li> 
<li><a href="/xueyuan" target="_blank"><i class="fa fa-book icoid1"></i><span>建站教程</span></a></li>
<li><a href="/question" target="_blank"><i class="fa fa-comments-o icoid1"></i><span>有求必应</span></a></li>
<li><a href="/gonggao" target="_blank"><i class="fa fa-bullhorn icoid1"></i><span>平台公告</span></a></li>
<li><a href="https://wpa.qq.com/msgrd?v=3&uin=80027422&site=qq&menu=yes" target="_blank"><i class="fa fa-users icoid1"></i><span>服务支持</span></a></li>
<li><a href="/svip" target="_blank"><i class="fa fa-diamond icoid1"></i><span>升级SVIP</span></a></li>
</ul>
</div>
</div>

<div class="col-sm-6 col-md-3">
<div class="home-first-part home-topics">
<h2 class="hf-title"><strong><a href="/svip">最新发布</a></strong><a href="/svip" target="_blank" class="more">SVIP</a></h2>
<div class="items">
<div class="row">
<div class="col-xs-6">
<a href="/svip" target="_blank"><span class="thumb" style="background-image:url(/wp-content/themes/jizhi-chlid/images/jrgx.png)"><img src="/wp-content/themes/jizhi-chlid/images/jrgx.png" alt="今日发布"></span><strong class="title">今日发布：<?php echo WeeklyUpdate();?>&nbsp;篇</strong></a>
</div>
<div class="col-xs-6">
<a href="/svip" target="_blank"><span class="thumb" style="background-image:url(/wp-content/themes/jizhi-chlid/images/zdtj.png)"><img src="/wp-content/themes/jizhi-chlid/images/zdtj.png" alt="本周发布"></span><strong class="title">本周发布：<?php echo get_week_post_count(); ?>&nbsp;篇</strong></a>
</div>
</div>
</div>
</div>
</div>

<div class="col-sm-6 col-md-3">
<div class="home-first-part home-subjects">
<h2 class="hf-title"><strong><a href="javascript:void(0);">服务定制</a></strong><a href="https://wpa.qq.com/msgrd?v=3&uin=80027422&site=qq&menu=yes" target="_blank" class="more">WEB</a></h2>
<div class="items">
<div class="row">
<div class="col-xs-6">
<a href="/web" target="_blank"><span class="thumb" style="background-image:url(/wp-content/themes/jizhi-chlid/images/djjc.png)"><img src="/wp-content/themes/jizhi-chlid/images/djjc.png" alt="网站建设"></span><strong class="title">网站建设</strong></a>
</div>
<div class="col-xs-6">
<a href="/seo" target="_blank"><span class="thumb" style="background-image:url(/wp-content/themes/jizhi-chlid/images/qym.png)"><img src="/wp-content/themes/jizhi-chlid/images/qym.png" alt="SEO优化"></span><strong class="title">SEO优化</strong></a>
</div>

</div>
</div>
</div>
</div>
<div class="col-sm-6 col-md-3">
<div class="home-first-part home-course">
<h2 class="hf-title"><strong><a href="/gonggao" target="_blank">平台公告</a></strong><a href="/gonggao" target="_blank" class="more">more</a></h2>
<div class="courses">
<div class="course-items">
<ul>
<li><a href="/" target="_blank"><strong>本站公告</strong><span>全部公告</span></a></li>
<li><a href="/" target="_blank"><strong>积分获取</strong><span>如何获取积分</span></a></li>
<li><a href="/" target="_blank"><strong>意见反馈</strong><span>意见反馈</span></a></li>
<li><a href="/" target="_blank"><strong>免费帮会员下载</strong><span>资源代下</span></a></li>

</ul>
</div>
</div>
</div>
</div>
</div></div></div>