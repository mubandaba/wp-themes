<!--站壳网www.zhankr.net-->

<?php
$site_zkhdp1_text = _cao('site_zkhdp1_text');
if (is_array($site_zkhdp1_text)  && _cao('home_zkhdp1_text') ) : ?>
<div class="toptu">
  <div class="item scroll">
    <img class="scroll-image lazyloaded" src="<?php echo $site_zkhdp1_text['zkhdp1_img1_text']; ?>" data-lazy-src="<?php echo $site_zkhdp1_text['zkhdp1_img1_text']; ?>" data-was-processed="true">
    <noscript>
      <img class="scroll-image" src="<?php echo $site_zkhdp1_text['zkhdp1_img1_text']; ?>"></noscript>
    <img class="scroll-image lazyloaded" src="<?php echo $site_zkhdp1_text['zkhdp1_img1_text']; ?>" data-lazy-src="<?php echo $site_zkhdp1_text['zkhdp1_img1_text']; ?>" data-was-processed="true">
    <noscript>
      <img class="scroll-image" src="<?php echo $site_zkhdp1_text['zkhdp1_img1_text']; ?>"></noscript>
    <div class="sc-1wssj0-17 hVBrzU">
      <img src="<?php echo $site_zkhdp1_text['zkhdp1_img2_text']; ?>" data-lazy-src="<?php echo $site_zkhdp1_text['zkhdp1_img2_text']; ?>" class="lazyloaded" data-was-processed="true">
      <noscript>
        <img src="<?php echo $site_zkhdp1_text['zkhdp1_img2_text']; ?>"></noscript>
    </div>
  </div>
  <div class="cl static htkYRs">
    <ul class="flex">
      <li class="st_one">
        <a href="<?php echo $site_zkhdp1_text['zkhdp11_link']; ?>" target="_blank">
          <img class="lazy card-main lazyloaded" alt="<?php echo $site_zkhdp1_text['zkhdp11_down']; ?>" src="<?php echo $site_zkhdp1_text['zkhdp11_img_text']; ?>" data-lazy-src="<?php echo $site_zkhdp1_text['zkhdp11_img_text']; ?>" data-was-processed="true">
          <noscript>
            <img class="lazy card-main" alt="<?php echo $site_zkhdp1_text['zkhdp11_down']; ?>" src="<?php echo $site_zkhdp1_text['zkhdp11_img_text']; ?>"></noscript>
          <h5 class="active-card-title"><?php echo $site_zkhdp1_text['zkhdp11_down']; ?></h5></a>
      </li>
      <li class="st_one">
        <a href="<?php echo $site_zkhdp1_text['zkhdp12_link']; ?>" target="_blank">
          <img class="lazy card-main lazyloaded" alt="<?php echo $site_zkhdp1_text['zkhdp12_down']; ?>" src="<?php echo $site_zkhdp1_text['zkhdp12_img_text']; ?>" data-lazy-src="<?php echo $site_zkhdp1_text['zkhdp12_img_text']; ?>" data-was-processed="true">
          <noscript>
            <img class="lazy card-main" alt="<?php echo $site_zkhdp1_text['zkhdp12_down']; ?>" src="<?php echo $site_zkhdp1_text['zkhdp12_img_text']; ?>">" ></noscript>
          <h5 class="active-card-title"><?php echo $site_zkhdp1_text['zkhdp12_down']; ?></h5></a>
      </li>
      <li class="st_one">
        <a href="<?php echo $site_zkhdp1_text['zkhdp13_link']; ?>" target="_blank">
          <img class="lazy card-main lazyloaded" alt="<?php echo $site_zkhdp1_text['zkhdp13_down']; ?>" src="<?php echo $site_zkhdp1_text['zkhdp13_img_text']; ?>"  data-lazy-src="<?php echo $site_zkhdp1_text['zkhdp13_img_text']; ?>" data-was-processed="true">
          <noscript>
            <img class="lazy card-main" alt="<?php echo $site_zkhdp1_text['zkhdp13_down']; ?>" src="<?php echo $site_zkhdp1_text['zkhdp13_img_text']; ?>" ></noscript>
          <h5 class="active-card-title"><?php echo $site_zkhdp1_text['zkhdp13_down']; ?></h5></a>
      </li>
      <li class="st_one">
        <a href="<?php echo $site_zkhdp1_text['zkhdp14_link']; ?>" target="_blank">
          <img class="lazy card-main lazyloaded" alt="<?php echo $site_zkhdp1_text['zkhdp14_down']; ?>" src="<?php echo $site_zkhdp1_text['zkhdp14_img_text']; ?>" data-lazy-src="<?php echo $site_zkhdp1_text['zkhdp14_img_text']; ?>" data-was-processed="true">
          <noscript>
            <img class="lazy card-main" alt="<?php echo $site_zkhdp1_text['zkhdp14_down']; ?>" src="<?php echo $site_zkhdp1_text['zkhdp14_img_text']; ?>" ></noscript>
          <h5 class="active-card-title"><?php echo $site_zkhdp1_text['zkhdp14_down']; ?></h5></a>
      </li>
      <li class="st_one">
        <a href="<?php echo $site_zkhdp1_text['zkhdp15_link']; ?>" target="_blank">
          <img class="lazy card-main lazyloaded" alt="<?php echo $site_zkhdp1_text['zkhdp15_down']; ?>" src="<?php echo $site_zkhdp1_text['zkhdp15_img_text']; ?>"  data-lazy-src="<?php echo $site_zkhdp1_text['zkhdp15_img_text']; ?>" data-was-processed="true">
          <noscript>
            <img class="lazy card-main" alt="<?php echo $site_zkhdp1_text['zkhdp15_down']; ?>" src="<?php echo $site_zkhdp1_text['zkhdp15_img_text']; ?>" ></noscript>
          <h5 class="active-card-title"><?php echo $site_zkhdp1_text['zkhdp15_down']; ?></h5></a>
      </li>
    </ul>
  </div>
</div>
<?php endif; ?>