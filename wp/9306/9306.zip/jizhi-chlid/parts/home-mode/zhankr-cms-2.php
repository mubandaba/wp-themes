<?php
$site_cms2_text = _cao('site_cms2_text');
if (is_array($site_cms2_text)  && _cao('home_cms2_text') ) : ?>
<div class="section zhankr-bj">
	<div class="home-first">
		<div class="container hide_sm">
				<div class="col-1-4">
					<div class="hf-widget hf-widget-1 hf-widget-software">
						<h3 class="hf-widget-title">
							<i class="fa fa-coffee"></i>
							<a href="<?php echo $site_cms2_text['cms2_11_link']; ?>" target="_blank"><?php echo $site_cms2_text['cms2_11_text']; ?></a>
							<span><?php echo $site_cms2_text['cms2_111_down']; ?></span>
							<div class="pages">
								<i class="next">
									<a href="<?php echo $site_cms2_text['cms2_112_link']; ?>" target="_blank"><i class="fa fa-angle-right"></i></a>
								</i>
							</div>
						</h3>
						<div class="hf-widget-content">
							<div class="scroll-h">
								<ul>
									<li>
										<a href="<?php echo $site_cms2_text['cms2_12_link']; ?>" rel="external nofollow" target="_blank">
											<i class="thumb " style="background-image:url(<?php echo $site_cms2_text['cms2_12_text']; ?>)"></i>
											<span><?php echo $site_cms2_text['cms2_12_down']; ?></span></a>
									</li>
									<li>
										<a href="<?php echo $site_cms2_text['cms2_13_link']; ?>" target="_blank">
											<i class="thumb " style="background-image:url(<?php echo $site_cms2_text['cms2_13_text']; ?>)"></i>
											<span><?php echo $site_cms2_text['cms2_13_down']; ?></span></a>
									</li>
									<li>
										<a href="<?php echo $site_cms2_text['cms2_14_link']; ?>" target="_blank">
											<i class="thumb " style="background-image:url(<?php echo $site_cms2_text['cms2_14_text']; ?>)"></i>
											<span><?php echo $site_cms2_text['cms2_14_down']; ?></span></a>
									</li>
									<li>
										<a href="<?php echo $site_cms2_text['cms2_15_link']; ?>" target="_blank">
											<i class="thumb " style="background-image:url(<?php echo $site_cms2_text['cms2_15_text']; ?>)"></i>
											<span><?php echo $site_cms2_text['cms2_15_down']; ?></span></a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="col-1-4 sxweb">
					<div class="hf-widget hf-widget-2">
						<h3 class="hf-widget-title">
							<i class="fa fa-briefcase"></i>
							<a href="<?php echo $site_cms2_text['cms2_21_link']; ?>" target="_blank"><?php echo $site_cms2_text['cms2_21_text']; ?></a>
							<span><?php echo $site_cms2_text['cms2_211_down']; ?></span></h3>
						<div class="hf-widget-content">
							<div class="no-scroll hf-tags">
								<a class="style_orange" href="<?php echo $site_cms2_text['cms2_22_link']; ?>" target="_blank">
									<span><?php echo $site_cms2_text['cms2_22_down']; ?></span></a>
								<a class="" href="<?php echo $site_cms2_text['cms2_23_link']; ?>" target="_blank">
									<span><?php echo $site_cms2_text['cms2_23_down']; ?></span></a>
								<a class="" href="<?php echo $site_cms2_text['cms2_24_link']; ?>" target="_blank">
									<span><?php echo $site_cms2_text['cms2_24_down']; ?></span></a>
								<a class="" href="<?php echo $site_cms2_text['cms2_25_link']; ?>" target="_blank">
									<span><?php echo $site_cms2_text['cms2_25_down']; ?></span></a>
								<a class="" href="<?php echo $site_cms2_text['cms2_26_link']; ?>" target="_blank">
									<span><?php echo $site_cms2_text['cms2_26_down']; ?></span></a>
								<a class="" href="<?php echo $site_cms2_text['cms2_27_link']; ?>" target="_blank">
									<span><?php echo $site_cms2_text['cms2_27_down']; ?></span></a>
								<a class="" href="<?php echo $site_cms2_text['cms2_28_link']; ?>" target="_blank">
									<span><?php echo $site_cms2_text['cms2_28_down']; ?></span></a>
								<a class="" href="<?php echo $site_cms2_text['cms2_29_link']; ?>" target="_blank">
									<span><?php echo $site_cms2_text['cms2_29_down']; ?></span></a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-1-4 sxweb">
					<div class="hf-widget hf-widget-1 hf-widget-hot-cats">
						<h3 class="hf-widget-title">
							<i class="fa fa-fire"></i>
							<a href="<?php echo $site_cms2_text['cms2_31_link']; ?>" target="_blank"><?php echo $site_cms2_text['cms2_31_text']; ?></a>
							<span><?php echo $site_cms2_text['cms2_311_down']; ?></span></h3>
						<div class="hf-widget-content">
							<div class="scroll-h">
								<ul>
								<li>
										<a href="<?php echo $site_cms2_text['cms2_32_link']; ?>" target="_blank">
											<i class="hhicon fa <?php echo $site_cms2_text['cms2_32_text']; ?>"></i>
											<span><?php echo $site_cms2_text['cms2_32_down']; ?></span></a>
									</li>
									<li>
										<a href="<?php echo $site_cms2_text['cms2_33_link']; ?>" target="_blank">
											<i class="hhicon fa <?php echo $site_cms2_text['cms2_33_text']; ?>"></i>
											<span><?php echo $site_cms2_text['cms2_33_down']; ?></span></a>
									</li>
									<li>
										<a href="<?php echo $site_cms2_text['cms2_34_link']; ?>" target="_blank">
											<i class="hhicon fa <?php echo $site_cms2_text['cms2_34_text']; ?>"></i>
											<span><?php echo $site_cms2_text['cms2_34_down']; ?></span></a>
									</li>
									<li>
										<a href="<?php echo $site_cms2_text['cms2_35_link']; ?>" target="_blank">
											<i class="hhicon fa <?php echo $site_cms2_text['cms2_35_text']; ?>"></i>
											<span><?php echo $site_cms2_text['cms2_35_down']; ?></span></a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="col-1-4 sxweb">
					<div class="hf-widget hf-widget-4">
						<h3 class="hf-widget-title">
							<i class="fa fa-gift"></i>
							<a href="<?php echo $site_cms2_text['cms2_41_link']; ?>" target="_blank"><?php echo $site_cms2_text['cms2_41_text']; ?></a>
							<span><?php echo $site_cms2_text['cms2_411_down']; ?></span>
							<div class="pages">
								<i class="next">
									<a href="<?php echo $site_cms2_text['cms2_412_link']; ?>" target="_blank"><i class="fa fa-angle-right"></i></a>
								</i>
							</div>
						</h3>
						<div class="hf-widget-content">
							<div class="scroll-h">
								<ul>
									<li>
										<h3>
											<a href="<?php echo $site_cms2_text['cms2_42_link']; ?>" target="_blank">
												<i class="icon-time"></i>
												<span><?php echo $site_cms2_text['cms2_42_down']; ?></span>
												<em><?php echo $site_cms2_text['cms2_42_text']; ?></em></a>
										</h3>
									</li>
									<li>
										<h3>
											<a href="<?php echo $site_cms2_text['cms2_43_link']; ?>" target="_blank">
												<i class="icon-time"></i>
												<span><?php echo $site_cms2_text['cms2_43_down']; ?></span>
												<em><?php echo $site_cms2_text['cms2_43_text']; ?></em></a>
										</h3>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
		</div>
	</div>
</div>
<?php endif; ?>