<?php
$mode_census = _cao('mode_census');
$count_posts = wp_count_posts(); 
$users = $wpdb->get_var("SELECT COUNT(ID) FROM $wpdb->users"); 
 
ob_start(); ?>
<div class="deanggwrap">
<div class="deangg comfff wow fadeInUp">
<div class="deanggspan"><i class="fa fa-volume-up"></i><span>最新发布</span></div>
<b></b>
<div class="deanggc"><!--[diy=deanggc]-->

<div class="announce-wrap">
<ul class="announce-list line" style="margin-top: 0px;">
<?php
	$post_num = 5; // 显示文章的数量.
	$args=array(
	'post_status' => 'publish',
	'paged' => $paged,
	'caller_get_posts' => 1,
	'posts_per_page' => $post_num
	);
	query_posts($args);
	// 主循环
	if ( have_posts() ) : while ( have_posts() ) : the_post();
?>
<li><a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a><span><?php echo the_time('Y-m-d')?></span></li>
<?php endwhile; else: endif; wp_reset_query();?>
</ul>
</div>


<!--[/diy]--></div>
<div class="clear"></div>
</div>
<div class="deanchart">
<ul>
<!--[diy=deanchart]-->
<div id="portal_block_396_content" class="dxb_bc">
<li class="deanchart5"><i></i>
<div class="deanchartdiv"><span>会员总数</span>
<div class="clear"></div>
<em id="num4"><?php $users = $wpdb->get_var("SELECT COUNT(ID) FROM $wpdb->users"); echo $users; ?></em></div>
<div class="clear"></div>
</li>
<li class="deanchart3"><i></i>
<div class="deanchartdiv"><span>今日发布</span>
<div class="clear"></div>
<em id="num4"><?php echo WeeklyUpdate();?></em></div>
<div class="clear"></div>
</li>
<li class="deanchart2"><i></i>
<div class="deanchartdiv"><span>本周发布</span>
<div class="clear"></div>
<em id="num6"><?php echo get_week_post_count(); ?></em></div>
<div class="clear"></div>
</li>
<li class="deanchart4"><i></i>
<div class="deanchartdiv"><span>资源总数</span>
<div class="clear"></div>
<em id="num3"><?php echo $published_posts = $count_posts->publish;?></em></div>
<div class="clear"></div>
</li>
</div>
<!--[/diy]-->
<div class="clear"></div>
</ul>
</div>
<div class="clear"></div>
</div>