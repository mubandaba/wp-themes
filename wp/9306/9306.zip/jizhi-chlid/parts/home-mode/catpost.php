<?php

$mode_catpost = _cao('mode_catpost');



foreach ($mode_catpost['catcms'] as $key => $cms) { 

	$args = array(
	    'cat'            => $cms['category'],
	    'ignore_sticky_posts' => true,
	    'post_status'         => 'publish',
	    'posts_per_page'      => $cms['count'],
	    'orderby'      => $cms['orderby'],
	);

	///////////S CACHE ////////////////
	$data = new WP_Query($args); //原始输出
	///////////S CACHE ////////////////
	$category = get_category( $cms['category'] ); ?>
	<div class="section pb-0">
	  <div class="container">
	  	<h3 class="section-title">
	  		<span><a href="<?php echo esc_url( get_category_link( $category->cat_ID ) ); ?>"><?php echo $category->cat_name; ?></a></span>
	  		<i class="category-num"><?php echo $category->count;?></i>
	  	</h3>
	  	<li class="zhankr-syli"><?php echo $category->category_description; ?></li>
	  	<!--站壳网CMS菜单-->
	  	<?php
		$site_zksycmscd_text = _cao('site_zksycmscd_text');
		if (is_array($site_zksycmscd_text)  && _cao('home_zksycmscd_text') ) : ?>
		<div class="choosetype">
		<a href="<?php echo $site_zksycmscd_text['zksycmscd1_link']; ?>" target="_blank"><?php echo $site_zksycmscd_text['zksycmscd1_text']; ?></a>
		<a href="<?php echo $site_zksycmscd_text['zksycmscd2_link']; ?>" target="_blank"><?php echo $site_zksycmscd_text['zksycmscd2_text']; ?></a>
		<a href="<?php echo $site_zksycmscd_text['zksycmscd3_link']; ?>" target="_blank"><?php echo $site_zksycmscd_text['zksycmscd3_text']; ?></a>
		<a href="<?php echo $site_zksycmscd_text['zksycmscd4_link']; ?>" target="_blank"><?php echo $site_zksycmscd_text['zksycmscd4_text']; ?></a>
		<a href="<?php echo $site_zksycmscd_text['zksycmscd5_link']; ?>" target="_blank"><?php echo $site_zksycmscd_text['zksycmscd5_text']; ?></a>
		<a href="<?php echo $site_zksycmscd_text['zksycmscd6_link']; ?>" target="_blank"><?php echo $site_zksycmscd_text['zksycmscd6_text']; ?></a> 
		</div>
		<?php endif; ?>
		<!--站壳网CMS菜单-->	  	
	  	<?php _the_cao_ads('ad_list_header', 'list-header');?>
		<div class="row cat-posts-wrapper">
		    <?php while ( $data->have_posts() ) : $data->the_post();
		      get_template_part( 'parts/template-parts/content',$cms['latest_layout'] );
		    endwhile; ?>
		</div>
		<?php _the_cao_ads('ad_list_footer', 'list-footer');?>
	  </div>
	</div>

	<?php 
	wp_reset_postdata();
}
?>