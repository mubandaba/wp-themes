
	<div class="header-banner2" >
   <div class="container2">
    <div class="header-banner-content wrapper">

    <?php
    $site_dingbu_text = _cao('site_dingbu_text');
    if (is_array($site_dingbu_text)  && _cao('home_dingbu_text') ) : ?>
    <div class="deangg1 comfff wow fadeInUp">
          <div class="deanggspan1"><i class="fa fa-volume-up"></i><span>最新公告</span></div>
          <b></b>
          <div class="deanggc"><li><?php echo $site_dingbu_text['dingbu_text']; ?><a href="<?php echo $site_dingbu_text['dingbu_link']; ?>" style="font-size: 12px;color: #3556fe;"><?php echo $site_dingbu_text['dingbu_down']; ?></a></li></div>
          <div class="clear"></div>
    </div>
    <?php endif; ?>

    <div class="clear"></div>

     <div class="header-banner-left">
      <div id="ym-menu" class="ym-menu">
      	<?php
      	$site_xiangguan_text = _cao('site_xiangguan_text');
      	if (is_array($site_xiangguan_text)  && _cao('home_xiangguan_text') ) : ?>
       <ul id="menu-header-top" class="menu81">
        <li><a href="<?php echo $site_xiangguan_text['xiangguan_link_1']; ?>" target="_blank"> <?php echo $site_xiangguan_text['xiangguan_down_1']; ?></a></li>
		<li><a href="<?php echo $site_xiangguan_text['xiangguan_link_2']; ?>" target="_blank"> <?php echo $site_xiangguan_text['xiangguan_down_2']; ?></a></li>
		<li><a href="<?php echo $site_xiangguan_text['xiangguan_link_3']; ?>" target="_blank"> <?php echo $site_xiangguan_text['xiangguan_down_3']; ?></a></li>
		<li><a href="<?php echo $site_xiangguan_text['xiangguan_link_4']; ?>" target="_blank"> <?php echo $site_xiangguan_text['xiangguan_down_4']; ?></a></li>
		<li><a href="<?php echo $site_xiangguan_text['xiangguan_link_5']; ?>" target="_blank"> <?php echo $site_xiangguan_text['xiangguan_down_5']; ?></a></li>
       </ul>
       <?php endif; ?>
      </div>
     </div>
    </div>
   </div>
</div>
<?php
  global $current_user;
  $container = _cao( 'navbar_full', false );
  $menu_class = 'main-menu hidden-xs hidden-sm hidden-md';
  if ( cao_compare_options( _cao( 'navbar_hidden', false ), rwmb_meta( 'navbar_hidden' ) ) == true ) {
    $menu_class .= ' hidden-lg hidden-xl';
  }
  $logo_regular = _cao( 'site_logo');
  $logo_regular_dark = _cao( 'site_dark_logo');

?>
<header class="site-header">
  <?php if ( $container == false ) : ?>
    <div class="container topnav">
        <div class="navbar">
            <div class="logo-wrapper">
                <?php if ( ! empty( $logo_regular ) ) : ?>
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                        <img class="logo regular tap-logo" src="<?php echo esc_url( $logo_regular ); ?>" data-dark="<?php echo esc_url(_cao( 'site_dark_logo')); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
                    </a>
                <?php else : ?>
                    <a class="logo text" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></a>
                <?php endif; ?>
            </div>
<!--            <div class="sep"></div>-->
        <?php
        $site_logo_text = _cao('site_logo_text');
        if (is_array($site_logo_text)  && _cao('home_logo_text') ) : ?>
            <div class="logotext10">
                <span class="navtenyear"><?php echo $site_logo_text['logo_textup']; ?></span><br>
                <span class="navtenyearcon"><?php echo $site_logo_text['logo_textdown']; ?></span>
            </div>
            <?php else : ?>
       <div class="sep"></div>
      <?php endif; ?>

            <div class="header_search">
                <div class="search_form">
                    <div class="search_input" data-search="top-banner">
                        <div class="search_filter" id="header_filter">
                        </div>
                        <input class="search-input" id="search-keywords" placeholder="懒得逛,试试搜索功能吧..." type="text" name="s" autocomplete="off">
                        <input type="hidden" name="search" class="btn_search" data-search-btn="search-btn">
                    </div>
                    <div class="search_btn" id="search-btn"><i class="icon_search"></i></div>
                </div>
                <!--<div class="hotword">
                    <span>热门搜索：</span>
                    <a href="/?s=网站源码">网站源码</a><a href="/?s=织梦模板">织梦模板</a><a href="/?s=企业模板">企业模板</a><a href="/?s=AE模板">AE模板</a><a href="/?s=PPT">PPT</a><a href="/?s=源码">源码</a><a href="/?s=视频教程">视频教程</a>
                </div>-->
        <?php
        $qaq_fly = _cao('qaq_fly');
        if (is_array($qaq_fly)  && _cao('home_qaq') ) : ?>
				<div class="wendashequ">
					<a href="<?php echo $qaq_fly['qaq_link']; ?>" class="wdsq"><i class="fa <?php echo $qaq_fly['qaq_down']; ?>"></i>  <?php echo $qaq_fly['qaq_text']; ?></a>
					<img src="<?php echo $qaq_fly['qaq_img']; ?>" alt="" style="max-width: none;position: absolute;right: 96px;margin: 0px 10px 4px 0px;bottom: 0;width: 56px;">
				</div>
      <?php endif; ?>
            </div>


            <div class="main-search">
                <?php get_search_form(); ?>
                <div class="search-close navbar-button"><i class="mdi mdi-close"></i></div>
            </div>

            <div class="actions">
                <?php
                $site_fly = _cao('site_fly');
                if (is_array($site_fly)  && _cao('home_fly') ) : ?>
                <div class="shanshan hidden-xsss">
                    <div data-microtip="升级SVIP会员无限下载" data-microtip-position="bottom-right" class="hsnah heshan">
                        <a href="<?php echo $site_fly['fly_link']; ?>" class="shanlian lianzi"><span class="ic_gif"></span>
                            <span class="txt"><i class="ic_mask"></i><?php echo $site_fly['fly_text']; ?></span></a>
                    </div>
                </div>
                <?php endif; ?>
                <?php if (is_site_shop_open()) : ?>
                    <!-- user -->
                    <?php if (is_user_logged_in()) : ?>
                        <?php if (_cao('is_navbar_newhover','1')) {
                            get_template_part( 'parts/navbar-hover' );
                        }else{ ?>
                            <a class="user-pbtn" href="<?php echo esc_url(home_url('/user')) ?>"><?php echo get_avatar($current_user->user_email); ?>
                                <?php if(!_cao('is_navbar_ava_name','0')){
                                    echo '<span>'.$current_user->display_name.'</span>';
                                }?>
                            </a>
                        <?php } ?>

                    <?php else: ?>
                        <div class="login-btn navbar-button"><i class="mdi mdi-account"></i>登录 / 注册</div>
                    <?php endif; ?>
                <?php endif; ?>
                <!-- user end -->
                <div class="search-open navbar-button"><i class="fa fa-search"></i></div>
                <div class="burger" style="display:block"><i class="fa fa-tasks"></i></div>
            </div>
        </div>
  <?php endif; ?>

  <?php if ( $container == false ) : ?>
    </div>
    <?php $zzzy_anniu = _cao('zzzy_anniu'); if (is_array($zzzy_anniu)  && _cao('home_zhankr_dhxx') ) : ?>
    <div style="border-bottom: 0.5px solid #E9E9E9;"></div>
    <?php endif; ?>
    <div class="container">
        <div class="navbar navbar2">
        	<?php $zzzy_anniu = _cao('zzzy_anniu'); if (is_array($zzzy_anniu)  && _cao('home_zzzy') ) : ?>
        	<div class="deansubnavsins"><i class="fa <?php echo $zzzy_anniu['zzzy_down']; ?>"></i>  <a href="<?php echo $zzzy_anniu['zzzy_link']; ?>"><?php echo $zzzy_anniu['zzzy_text']; ?></a></div>
        	<?php endif; ?>
            <nav class="<?php echo esc_attr( $menu_class ); ?>">
                <?php wp_nav_menu( array(
                    'container' => false,
                    'fallback_cb' => 'Cao_Walker_Nav_Menu::fallback',
                    'menu_class' => 'nav-list u-plain-list',
                    'theme_location' => 'menu-1',
                    'walker' => new Cao_Walker_Nav_Menu( true ),
                ) ); ?>
            </nav>
        </div>
    </div>
    <?php $zzzy_anniu = _cao('zzzy_anniu'); if (is_array($zzzy_anniu)  && _cao('home_zhankr_dhxx') ) : ?>
    <div style="border-bottom: 0.5px solid #E9E9E9;border-top: 0.5px solid #E9E9E9;"></div>
    <?php endif; ?>
    <style>
        @media screen and (max-width: 1248px){
            .header_search{
                left: 30%;
            }
            .logotext10{
                display: none;
            }
            .header_search{
                width: 320px;
            }
            .header_search .search_form .search_input{
                width: 238px;
            }
        }
        @media screen and (min-width: 931px){
            .header-gap {
                height: 150px;
            }
            span.navtenyear {
                font-size: 14px;
                padding: 1px 5px;
                background-color: #F67524;
                border-radius: 5px;
                color: #fff;
            }
            span.navtenyearcon {
                font-size: 12px;
            }
        }
        @media screen and (max-width: 971px){
            .navbar2 {
                height: 0px;
            }
            .logotext10{
                display: none;
            }
            .header_search{
                display: none;
            }
        }
    </style>
    <script>
        jQuery("#search-btn").on("click",function () {
            location.href='<?php echo esc_url( home_url( '/' ) ); ?>?s='+jQuery("#search-keywords").val();
        })
    </script>
  <?php endif; ?>
</header>
