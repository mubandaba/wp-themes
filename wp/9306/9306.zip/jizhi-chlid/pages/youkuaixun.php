<?php
/*
Template Name: 优快讯
*/
?>
<?php get_header(); ?>
<?php
	$sidebar = cao_sidebar();
	$column_classes = cao_column_classes( $sidebar );
	get_header();
?>
<style type="text/css">
.term-bar {
    display: none;
}
</style>
<div class="container">
	<div class="row">
		<div class="article-content <?php echo esc_attr( $column_classes[0] ); ?>">
			<div class="content-area">
				<main class="site-main">
				<!-- 站壳网快讯功能 -->
				 <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <header class="youkuaixun-header">
					<h1 class="kx-title">快讯</h1>
                        <h3 class="youkuaixun-title">目前有 <?php $count_posts = wp_count_posts('youkuaixun'); echo $published_posts = $count_posts->publish;?> 个快讯，于<?php $last = $wpdb->get_results("SELECT MAX(post_modified) AS MAX_m FROM $wpdb->posts WHERE (post_type = 'youkuaixun')");$last = date('Y年n月j日', strtotime($last[0]->MAX_m));echo $last; ?>更新，共 <?php echo ' '._get_post_views();?> 人浏览
                         </h3>
                    </header>
                        <main id="main" class="site-main" role="main">
                        <!--noptimize-->
                        <div class="youkuaixun">
                             <ul class="archives-monthlisting">
                             <?php $limit = get_option('posts_per_page');$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;query_posts('post_type=youkuaixun&post_status=publish&showposts=' . $limit=15 . '&paged=' . $paged);if (have_posts()) : while (have_posts()) : the_post(); ?>
                             <li>
                             <div class="youkuaixun-content">
							 <div class="calendar-year"><?php echo get_avatar( get_the_author_email(), 40 ); ?>
							 <span><?php the_author() ?>   <i class="fa fa-clock-o"></i>：<?php echo get_the_time('Y-m-d G:i:s'); ?> </span>
							 </div>
							 <br/>
							 <h2><?php the_title(); ?></h2>
							 <br/>
							 <?php the_content(); ?>
							 
							 
                             </div>
                             <?php endwhile;endif; ?>
                             </li>
                             </ul>
                        </div>
                        <!--/noptimize-->
                        </main>
                 </article>
				 <!-- 站壳网快讯功能 -->
				</main>
			</div>
		</div>
		<?php if ( $sidebar != 'none' ) : ?>
			<div class="<?php echo esc_attr( $column_classes[1] ); ?>">
				<?php get_sidebar(); ?>
			</div>
		<?php endif; ?>
	</div>
</div>
                
<?php get_footer(); ?>