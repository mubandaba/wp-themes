<?php
/*
Template Name: vip介绍
*/
?>
<?php get_header(); ?>
<?php
$site_vip_text = _cao('site_vip_text');
if (is_array($site_vip_text)  && _cao('home_vip_text') ) : ?>
<div class="vip-banner">
  <div class="vipbj">
    <h2><?php echo $site_vip_text['vip_1_text']; ?></h2>
    <p><?php echo $site_vip_text['vip_1_down']; ?></p>
    <a href="<?php echo $site_vip_text['vip_1_link']; ?>" title="" target="_blank"><?php echo $site_vip_text['vip_1_texte']; ?></a> </div>
</div>
<div class="module-line"> <span class="arrow left-arrow"></span> <span class="text"><?php echo $site_vip_text['vip_2_text']; ?></span> <span class="arrow right-arrow"></span> </div>
<ul class="vip-slogan">
  <li class="vip-slogan-box"><i class="fa fa-pie-chart"></i>
    <div class="vip-slogan-text">
      <p><?php echo $site_vip_text['vip_21_down']; ?></p>
      <p><?php echo $site_vip_text['vip_21_texte']; ?></p>
    </div>
  </li>
  <li class="vip-slogan-box"><i class="fa fa-jsfiddle " style="font-size: 60px"></i>
    <div class="vip-slogan-text">
      <p><?php echo $site_vip_text['vip_22_down']; ?></p>
      <p><?php echo $site_vip_text['vip_22_texte']; ?></p>
    </div>
  </li>
  <li class="vip-slogan-box"><i class="fa fa-gratipay" style="font-size: 55px"></i>
    <div class="vip-slogan-text">
      <p><?php echo $site_vip_text['vip_23_down']; ?></p>
      <p><?php echo $site_vip_text['vip_23_texte']; ?></p>
    </div>
  </li>
  <li class="vip-slogan-box"><i class="fa fa-vine"></i>
    <div class="vip-slogan-text">
      <p><?php echo $site_vip_text['vip_24_down']; ?></p>
      <p><?php echo $site_vip_text['vip_24_texte']; ?></p>
    </div>
  </li>
  <li class="vip-slogan-box"><i class="fa fa-weixin"></i>
    <div class="vip-slogan-text">
      <p><?php echo $site_vip_text['vip_25_down']; ?></p>
      <p><?php echo $site_vip_text['vip_25_texte']; ?></p>
    </div>
  </li>
  <li class="vip-slogan-box"><i class="fa fa-vimeo-square"></i>
    <div class="vip-slogan-text">
      <p><?php echo $site_vip_text['vip_26_down']; ?></p>
      <p><?php echo $site_vip_text['vip_26_texte']; ?></p>
    </div>
  </li>
</ul>
<div class="container">
  <article class="single-content">
    <div class="module-line"> <span class="arrow left-arrow"></span> <span class="text"><?php echo $site_vip_text['vip_3_text']; ?></span> <span class="arrow right-arrow"></span>
      <div class="vip-desc"><?php echo $site_vip_text['vip_3_down']; ?></div>
    </div>
    <div class="container">
      <div class="vip-row vip-block-wrapper" style="padding-bottom: 0; padding-top: 30px; margin-bottom: 0; "> 
        <!--  -->
        <div class="vip-block-item">
          <div class="home-vipbox">
            <h3 class="content0-title"><?php echo $site_vip_text['vip_311_down']; ?></h3>
            <p class="vip-home-price"><?php echo $site_vip_text['vip_312_down']; ?><i><?php echo $site_vip_text['vip_313_down']; ?></i></p>
            <p><?php echo $site_vip_text['vip_314_down']; ?></p>
            <p><?php echo $site_vip_text['vip_315_down']; ?></p>
            <p><?php echo $site_vip_text['vip_316_down']; ?></p>
            <p><?php echo $site_vip_text['vip_317_down']; ?></p>
            <a href="<?php echo $site_vip_text['vip_319_link']; ?>">
            <p class="vip-bt"><?php echo $site_vip_text['vip_318_texte']; ?></p>
            </a> </div>
        </div>
        
        <!--  -->
        <div class="vip-block-item">
          <div class="home-vipbox">
            <h3 class="content0-title"><?php echo $site_vip_text['vip_321_down']; ?></h3>
            <p class="vip-home-price"><?php echo $site_vip_text['vip_322_down']; ?><i><?php echo $site_vip_text['vip_323_down']; ?></i></p>
            <p><?php echo $site_vip_text['vip_324_down']; ?></p>
            <p><?php echo $site_vip_text['vip_325_down']; ?></p>
            <p><?php echo $site_vip_text['vip_326_down']; ?></p>
            <p><?php echo $site_vip_text['vip_327_down']; ?></p>
            <a href="<?php echo $site_vip_text['vip_329_link']; ?>">
            <p class="vip-bt"><?php echo $site_vip_text['vip_328_texte']; ?></p>
            </a> </div>
        </div>
        
        <!--  -->
        <div class="vip-block-item">
          <div class="home-vipbox">
            <h3 class="content0-title"><?php echo $site_vip_text['vip_331_down']; ?></h3>
            <p class="vip-home-price"><i>限时活动价：</i><?php echo $site_vip_text['vip_332_down']; ?><i><?php echo $site_vip_text['vip_333_down']; ?></i></p>
            <p><?php echo $site_vip_text['vip_334_down']; ?></p>
            <p><?php echo $site_vip_text['vip_335_down']; ?></p>
            <p><?php echo $site_vip_text['vip_336_down']; ?></p>
            <p><?php echo $site_vip_text['vip_337_down']; ?></p>
            <a href="<?php echo $site_vip_text['vip_339_link']; ?>">
            <p class="vip-bt"><?php echo $site_vip_text['vip_338_texte']; ?></p>
            </a> </div>
        </div>
      </div>
    </div>
  </article>
</div>
<div style="clear:both"></div>
<style type="text/css">
.site-content{ padding:0px;}
.term-bar{ display:none;}
</style>
<?php endif; ?>
<?php get_footer(); ?>
