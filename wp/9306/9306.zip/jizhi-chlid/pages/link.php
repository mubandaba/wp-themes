<?php
/**
 * Template name: 站长导航
 * Description:   A links page
 */

get_header();
?>
<link rel="stylesheet" href="/wp-content/themes/jizhi-chlid/css/uikit.min.css" />
<link rel='stylesheet' href='/wp-content/themes/jizhi-chlid/css/style.css' type='text/css' media='all' />
<script type='text/javascript' src='/wp-content/themes/jizhi-chlid/css/uikit.min.js'></script>
<?php
$site_daohang_text = _cao('site_daohang_text');
if (is_array($site_daohang_text)  && _cao('home_daohang_text') ) : ?>
<main class="main">
	<div class="site-head uk-flex uk-flex-middle uk-margin-bottom" style="background: url(/wp-content/themes/jizhi-chlid/images/nav2.jpg) no-repeat;background-size: 100%;background-color: #fff;">
	<div class="site-switcher uk-container uk-padding-large">
	<div style="text-align: center;">
		<h2 style="margin-top: 10px;margin-bottom: 5px;"><?php echo $site_daohang_text['daohang_1_text']; ?></h2>
			<p><?php echo $site_daohang_text['daohang_1_down']; ?></p>
	</div>
		<ul uk-switcher class="uk-list site-switcher-menu uk-text-center uk-text-nowrap">
			<li><span>常用</span></li>
			<li><span>灵感</span></li>
			<li><span>图标</span></li>
			<li><span>美图</span></li>
			<li><span>字体</span></li>
		</ul>
		<div class="site-switcher-main uk-switcher uk-margin-bottom" class="uk-list">
			<div class="b-a uk-flex uk-animation-slide-left-small">
				<select class="site-select">
					<option selected="selected" value="0">百度</option>
					<option value="1">谷歌</option>
					<option value="2">必应</option>
					<option value="3">360</option>
				</select>
				<div class="site-search">
					<div class="site-form" style="display: block;">
						<form class="uk-position-relative" action="https://www.baidu.com/baidu" target="_blank">
							<input type="text" name=word placeholder="百度 搜一搜">
							<button type="submit" value=""><i class="fa fa-search"></i></button>
						</form>
					</div>
					<div class="site-form">
						<form class="uk-position-relative" method="GET" action="https://www.google.com/search" target="_blank">  
							<input type="text" name="q"  maxlength="255"  value="" placeholder="谷歌 搜一搜"> 
							<button type="submit" name="btnG" value=""><i class="fa fa-search"></i></button>
						</form> 
					</div>
					<div class="site-form">
						<form class="uk-position-relative" action="https://cn.bing.com/search" target="_blank">
							<input type="text" id="search_input" name="q" placeholder="必应 搜一搜">
							<button type="submit" name="btnG" value=""><i class="fa fa-search"></i></button>
						</form>
					</div>
					<div class="site-form">
						<form class="uk-position-relative" action=" https://www.so.com/s" target="_blacnk">
							<input name="q" type="text" id="input"  autocomplete="off" x-webkit-speech placeholder="360 搜一搜">
							<button type="submit" name="btnG" value=""><i class="fa fa-search"></i></button>
						</form>
					</div>
				</div>
			</div>
			<!-- 常用搜索引擎 -->
			<div class="b-a uk-flex uk-animation-slide-left-small">
				<select class="site-select">
					<option selected="selected" value="0">站酷</option>
					<option value="1">花瓣</option>
					<option value="2">Behance</option>
					<option value="3">Dribbble</option>
				</select>
				<div class="site-search">
					<div class="site-form" style="display: block;">
						<form class="uk-position-relative" action="https://www.zcool.com.cn/search/content" target="_blank">
							<input type="text" name="word" placeholder="站酷 站内搜索">
							<button type="submit" value=""><i class="fa fa-search"></i></button>
						</form>
					</div>
					<div class="site-form">
						<form class="uk-position-relative" action="https://huaban.com/search" target="_blank">
							<input type="text" name="q" placeholder="花瓣 站内搜索">
							<button type="submit" value=""><i class="fa fa-search"></i></button>
						</form>
					</div>
					<div class="site-form">
						<form class="uk-position-relative" action="https://www.behance.net/search" target="_blank">
							<input type="text" name="search" placeholder="Behance 站内搜索">
							<button type="submit" value=""><i class="fa fa-search"></i></button>
						</form>
					</div>
					<div class="site-form">
						<form class="uk-position-relative" action="https://dribbble.com/search" target="_blank">
							<input type="text" name="q"placeholder="Dribbble 站内搜索">
							<button type="submit" value=""><i class="fa fa-search"></i></button>
						</form>
					</div>
				</div>
			</div>
			<!-- 灵感 -->
			<div class="b-a uk-flex uk-animation-slide-left-small">
				<select class="site-select">
					<option selected="selected" value="0">iconfont</option>
					<option value="1">iconmonstr</option>
				</select>
				<div class="site-search">
					<div class="site-form" style="display: block;">
						<form class="uk-position-relative" action="https://www.iconfont.cn/search/index" target="_blank">
							<input type="text" name="q" placeholder="iconfont 站内搜索">
							<button type="submit" value=""><i class="fa fa-search"></i></button>
						</form>
					</div>
					<div class="site-form">
						<form class="uk-position-relative" action="https://iconmonstr.com/" target="_blank">
							<input type="text" name="s" placeholder="iconmonstr 站内搜索">
							<button type="submit" value=""><i class="fa fa-search"></i></button>
						</form>
					</div>
				</div>
			</div>
			<!-- 图标 -->
			<div class="b-a uk-flex uk-animation-slide-left-small">
				<select class="site-select">
					<option selected="selected" value="0">优美图</option>
					<option value="1">pexels</option>
					<option value="3">500px</option>
				</select>
				<div class="site-search">
					<div class="site-form" style="display: block;">
						<form class="uk-position-relative" action="https://www.umtu.cn/" target="_blank">
							<input type="text" name="s" placeholder="优美图  站内搜索">
							<button type="submit" value=""><i class="fa fa-search"></i></button>
						</form>
					</div>
					<div class="site-form">
						<form class="uk-position-relative" action="https://www.pexels.com/search-photos/" target="_blank">
							<input type="text" name="s" placeholder="pexels 站内搜索">
							<button type="submit" value=""><i class="fa fa-search"></i></button>
						</form>
					</div>

					<div class="site-form">
						<form class="uk-position-relative" action="https://500px.com/search" target="_blank">
							<input type="text" name="q" placeholder="500px 站内搜索">
							<button type="submit" value=""><i class="fa fa-search"></i></button>
						</form>
					</div>
				</div>
			</div>
			<!-- 美图 -->
			<div class="b-a uk-flex uk-animation-slide-left-small">
				<select class="site-select">
					<option selected="selected" value="0">字体传奇</option>
					<option value="1">字由</option>
					<option value="2">求字体</option>
				</select>
				<div class="site-search">
					<div class="site-form" style="display: block;">
						<form class="uk-position-relative" action="https://www.ziticq.com/Works/" target="_blank">
							<input type="text" name="k" placeholder="字体传奇  站内搜索">
							<button type="submit" value=""><i class="fa fa-search"></i></button>
						</form>
					</div>
					<div class="site-form">
						<form class="uk-position-relative" action="https://www.hellofont.cn/search" target="_blank">
							<input type="text" name="word" placeholder="字由  站内搜索">
							<button type="submit" value=""><i class="fa fa-search"></i></button>
						</form>
					</div>
					<div class="site-form">
						<form class="uk-position-relative" action="https://www.qiuziti.com/search.html" target="_blank">
							<input type="text" name="fn" placeholder="求字体  站内搜索">
							<button type="submit" value=""><i class="fa fa-search"></i></button>
						</form>
					</div>
				</div>
			</div>
			<!-- 素材 -->
		</div>
	</div>
</div>	<div class="uk-container uk-position-relative">
		<div class="uk-grid-collapse" uk-grid uk-sticky="offset: 0; animation: uk-animation-slide-top;">
		<div class="uk-width-1-1@s uk-width-5-6@m uk-width-5-6@l uk-width-5-6@xl">
		<div class="sitenav b-a uk-margin-bottom uk-background-default" >
			<div class="uk-grid-collapse uk-flex uk-flex-middle" uk-grid>
				<div class="uk-width-auto">
					<li class="uk-text-bolder uk-display-inline-block"><b class="uk-display-block">资源</br>导航</b></li>
				</div>
				<ul class="uk-width-expand uk-padding-small uk-text-truncate uk-overflow-auto">
										<li class="uk-display-inline-block"><a href="<?php echo $site_daohang_text['daohang_21_link']; ?>" target="_blank" class="uk-display-block"><i class="iconfont icon-angle-right"></i><?php echo $site_daohang_text['daohang_21_text']; ?></a></li>
										<li class="uk-display-inline-block"><a href="<?php echo $site_daohang_text['daohang_22_link']; ?>" target="_blank" class="uk-display-block"><i class="iconfont icon-angle-right"></i><?php echo $site_daohang_text['daohang_22_text']; ?></a></li>
										<li class="uk-display-inline-block"><a href="<?php echo $site_daohang_text['daohang_23_link']; ?>" target="_blank" class="uk-display-block"><i class="iconfont icon-angle-right"></i><?php echo $site_daohang_text['daohang_23_text']; ?></a></li>
										<li class="uk-display-inline-block"><a href="<?php echo $site_daohang_text['daohang_24_link']; ?>" target="_blank" class="uk-display-block"><i class="iconfont icon-angle-right"></i><?php echo $site_daohang_text['daohang_24_text']; ?></a></li>
										<li class="uk-display-inline-block"><a href="<?php echo $site_daohang_text['daohang_25_link']; ?>" target="_blank" class="uk-display-block"><i class="iconfont icon-angle-right"></i><?php echo $site_daohang_text['daohang_25_text']; ?></a></li>
										<li class="uk-display-inline-block"><a href="<?php echo $site_daohang_text['daohang_26_link']; ?>" target="_blank" class="uk-display-block"><i class="iconfont icon-angle-right"></i><?php echo $site_daohang_text['daohang_26_text']; ?></a></li>
										<li class="uk-display-inline-block"><a href="<?php echo $site_daohang_text['daohang_27_link']; ?>" target="_blank" class="uk-display-block"><i class="iconfont icon-angle-right"></i><?php echo $site_daohang_text['daohang_27_text']; ?></a></li>
										<li class="uk-display-inline-block"><a href="<?php echo $site_daohang_text['daohang_28_link']; ?>" target="_blank" class="uk-display-block"><i class="iconfont icon-angle-right"></i><?php echo $site_daohang_text['daohang_28_text']; ?></a></li>
										<li class="uk-display-inline-block"><a href="<?php echo $site_daohang_text['daohang_29_link']; ?>" target="_blank" class="uk-display-block"><i class="iconfont icon-angle-right"></i><?php echo $site_daohang_text['daohang_29_text']; ?></a></li>
										<li class="uk-display-inline-block"><a href="<?php echo $site_daohang_text['daohang_210_link']; ?>" target="_blank" class="uk-display-block"><i class="iconfont icon-angle-right"></i><?php echo $site_daohang_text['daohang_210_text']; ?></a></li>
										<li class="uk-display-inline-block"><a href="<?php echo $site_daohang_text['daohang_211_link']; ?>" target="_blank" class="uk-display-block"><i class="iconfont icon-angle-right"></i><?php echo $site_daohang_text['daohang_211_text']; ?></a></li>
						
				</ul>
			</div>
		</div>
	</div>
	<div class="uk-width-1-6 uk-visible@s">
		<div class="uk-light">
			<a href="<?php echo $site_daohang_text['daohang_2_link']; ?>" target="_blank" class="btn-on b-r-4 site-submit uk-width-1-1 uk-display-inline-block uk-text-center"><?php echo $site_daohang_text['daohang_2_text']; ?></a>
		</div>
	</div>
</div>
		<div class="uk-visible@s">
						<section class="uk-container uk-margin-medium-bottom">
	<div class="fastlink uk-grid-medium" uk-grid>
		<div class="uk-width-1-1@s uk-width-1-4@m uk-width-1-4@l uk-width-1-4@xl">
			<div class="fastlink-item b-a b-r-4 uk-background-default uk-padding-small">
								<div class="fastlink-title b-b uk-flex uk-flex-middle uk-text-bolder">
					<i class="iconfont icon-earth"></i><?php echo $site_daohang_text['daohang_13_text']; ?><span class="uk-text-muted uk-margin-left uk-text-small"><?php echo $site_daohang_text['daohang_13_down']; ?></span>
				</div>
				
				<ul class="fastlink-list uk-padding-remove">
										<li><a href="<?php echo $site_daohang_text['daohang_131_link']; ?>" target="_blank" class="uk-text-truncate"><?php echo $site_daohang_text['daohang_131_down']; ?></a></li>
										<li><a href="<?php echo $site_daohang_text['daohang_132_link']; ?>" target="_blank" class="uk-text-truncate" rel="nofollow"><?php echo $site_daohang_text['daohang_132_down']; ?></a></li>
										<li><a href="<?php echo $site_daohang_text['daohang_133_link']; ?>" target="_blank" class="uk-text-truncate" rel="nofollow"><?php echo $site_daohang_text['daohang_133_down']; ?></a></li>
										<li><a href="<?php echo $site_daohang_text['daohang_134_link']; ?>" target="_blank" class="uk-text-truncate" rel="nofollow"><?php echo $site_daohang_text['daohang_134_down']; ?></a></li>
															
				</ul>
							</div>
			
		</div>
		<div class="uk-width-1-1@s uk-width-1-4@m uk-width-1-4@l uk-width-1-4@xl">
			<div class="fastlink-item b-a b-r-4 uk-background-default uk-padding-small">
								<div class="fastlink-title b-b uk-flex uk-flex-middle uk-text-bolder">
					<i class="iconfont icon-earth"></i><?php echo $site_daohang_text['daohang2_1_text']; ?><span class="uk-text-muted uk-margin-left uk-text-small"><?php echo $site_daohang_text['daohang2_1_down']; ?></span>
				</div>
				
				<ul class="uk-list fastlink-tags">
										<li><a href="<?php echo $site_daohang_text['daohang2_11_link']; ?>" target="_blank" class="btn b-r-4" rel="nofollow"><?php echo $site_daohang_text['daohang2_11_down']; ?></a></li>
										<li><a href="<?php echo $site_daohang_text['daohang2_12_link']; ?>" target="_blank" class="btn b-r-4" rel="nofollow"><?php echo $site_daohang_text['daohang2_12_down']; ?></a></li>
										<li><a href="<?php echo $site_daohang_text['daohang2_13_link']; ?>" target="_blank" class="btn b-r-4" rel="nofollow"><?php echo $site_daohang_text['daohang2_13_down']; ?></a></li>
										<li><a href="<?php echo $site_daohang_text['daohang2_14_link']; ?>" target="_blank" class="btn b-r-4" rel="nofollow"><?php echo $site_daohang_text['daohang2_14_down']; ?></a></li>
										<li><a href="<?php echo $site_daohang_text['daohang2_15_link']; ?>" target="_blank" class="btn b-r-4" rel="nofollow"><?php echo $site_daohang_text['daohang2_15_down']; ?></a></li>
										<li><a href="<?php echo $site_daohang_text['daohang2_16_link']; ?>" target="_blank" class="btn b-r-4" rel="nofollow"><?php echo $site_daohang_text['daohang2_16_down']; ?></a></li>
										<li><a href="<?php echo $site_daohang_text['daohang2_17_link']; ?>" target="_blank" class="btn b-r-4" rel="nofollow"><?php echo $site_daohang_text['daohang2_17_down']; ?></a></li>
										<li><a href="<?php echo $site_daohang_text['daohang2_18_link']; ?>" target="_blank" class="btn b-r-4" rel="nofollow"><?php echo $site_daohang_text['daohang2_18_down']; ?></a></li>
															
				</ul>
							</div>
		</div>
		<div class="uk-width-1-1@s uk-width-1-4@m uk-width-1-4@l uk-width-1-4@xl">
			<div class="fastlink-item b-a b-r-4 uk-background-default uk-padding-small">
								<div class="fastlink-title b-b uk-flex uk-flex-middle uk-text-bolder">
					<i class="iconfont icon-earth"></i><?php echo $site_daohang_text['daohang3_1_text']; ?><span class="uk-text-muted uk-margin-left uk-text-small"><?php echo $site_daohang_text['daohang3_1_down']; ?></span>
				</div>
				<ul class="uk-list fastlink-tags">
										<li><a href="<?php echo $site_daohang_text['daohang3_11_link']; ?>" target="_blank" class="btn b-r-4" rel="nofollow"><?php echo $site_daohang_text['daohang3_11_down']; ?></a></li>
										<li><a href="<?php echo $site_daohang_text['daohang3_12_link']; ?>" target="_blank" class="btn b-r-4" rel="nofollow"><?php echo $site_daohang_text['daohang3_12_down']; ?></a></li>
										<li><a href="<?php echo $site_daohang_text['daohang3_13_link']; ?>" target="_blank" class="btn b-r-4" rel="nofollow"><?php echo $site_daohang_text['daohang3_13_down']; ?></a></li>
										<li><a href="<?php echo $site_daohang_text['daohang3_14_link']; ?>" target="_blank" class="btn b-r-4" rel="nofollow"><?php echo $site_daohang_text['daohang3_14_down']; ?></a></li>
										<li><a href="<?php echo $site_daohang_text['daohang3_15_link']; ?>" target="_blank" class="btn b-r-4" rel="nofollow"><?php echo $site_daohang_text['daohang3_15_down']; ?></a></li>
										<li><a href="<?php echo $site_daohang_text['daohang3_16_link']; ?>" target="_blank" class="btn b-r-4" rel="nofollow"><?php echo $site_daohang_text['daohang3_16_down']; ?></a></li>
															
				</ul>
				
			</div>
		</div>
		<div class="uk-width-1-1@s uk-width-1-4@m uk-width-1-4@l uk-width-1-4@xl">
			<div class="fastlink-item b-a b-r-4 uk-background-default uk-padding-small">
								<div class="fastlink-title b-b uk-flex uk-flex-middle uk-text-bolder">
					<i class="iconfont icon-earth"></i><?php echo $site_daohang_text['daohang4_1_text']; ?><span class="uk-text-muted uk-margin-left uk-text-small"><?php echo $site_daohang_text['daohang4_1_down']; ?></span>
				</div>
				<div class="fastlink-img uk-position-relative">
					<a href="<?php echo $site_daohang_text['daohang4_12_link']; ?>" target="_blank" class="uk-display-block">
						<img src="<?php echo $site_daohang_text['daohang4_13_text']; ?>" class="uk-margin-top uk-width-1-1">
						<div class="cover uk-overlay uk-overlay-primary uk-position-bottom uk-light uk-text-small"><?php echo $site_daohang_text['daohang4_11_down']; ?></div>
					</a>
				</div>
							</div>
		</div>
	</div>
</section>
					</div>
</main>
<?php endif; ?>
<style>
.term-bar {
    display: none;
}
ul.plinks {
    position: relative;
    margin-top: 30px;
  width: 100%;
      padding: 0;
}

ul.plinks li.linkcat {
    padding: 20px 20px;
    border-radius: 6px;
}

ul.plinks li.linkcat h2 {
    margin: 0;
    font-weight: 700;
    font-size: 18px;
}

ul.plinks li.linkcat ul {
    overflow: hidden;
    margin: 0;
    padding: 0;
    list-style: none;
}

ul.plinks li.linkcat ul li {
    float: left;
    overflow: hidden;
    margin-top: 15px;
    width: calc(20% - 20px);
    box-shadow: 0px 2px 0px rgba(170,170,170,0.1);
    background: #fff;
    margin-bottom: 10px;
    border-radius: 3px;
    margin-left: 10px;
    margin-right: 10px;
}

ul.plinks li.linkcat ul li:hover {
    opacity: 0.6;
    -webkit-transition: all .3s ease-in-out;
    -moz-transition: all .3s ease-in-out;
    transition: all .3s ease-in-out;
}

ul.plinks li.linkcat ul li a {
    overflow: hidden;
    margin-bottom: 20px;
    display: block;
    cursor: pointer;
    padding: 20px 18px 0;
    color: #333;
}

ul.plinks li.linkcat ul li a:hover {
    color: #005fee;
}

ul.plinks li.linkcat ul li a img {
    width: 32px;
    height: 32px;
    border-radius: 32px;
    display: inline-block;
}

@media (max-width: 768px) {
    ul.plinks li.linkcat ul li {
        width:calc(50% - 20px);
    }
}

@media (max-width: 544px) {
    ul.plinks li.linkcat ul li {
        width:100%;
    }
}
ol, ul {
    list-style: none;
}

.row {
    margin-left: 0;
    margin-right: 0;
}



</style>
<section class="container" style="
    margin-top: -60px;
">
<div class="row">
    <ul class="plinks">
		<?php
		wp_list_bookmarks(array(
		    'show_description' => true,
		    'show_name'        => true,
		    'orderby'          => 'rating',
		    'title_before'     => '<h2><i class="fa fa-bookmark-o" aria-hidden="true"></i> ',
		    'title_after'      => '</h2>',
		    'order'            => 'DESC',
		    'show_description' => '0',
		));
		?>
	</ul>
</div>
</section>

<?php

get_footer();