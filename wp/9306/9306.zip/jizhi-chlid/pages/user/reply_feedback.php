<?php
global $current_user;
$wp_create_nonce = wp_create_nonce('caoclick-' . $current_user->ID);

if (empty($_GET['post_id'])) {
    echo "<h1>出错: ID为空</h1>";
    return ;
}

$post_id = $_GET['post_id'];

$post_get = $post = get_post($post_id);
if (empty($post) || $post->post_author != get_current_user_id()) {
    echo '<h1>无法回复</h1>';

    return;
}
setup_postdata($post);




?>
<style type="text/css"></style>
<div class="col-xs-12 col-sm-12 col-md-9">
    <form class="mb-0">
<!--    --><?php // if(_cao('is_all_publish_posts') || current_user_can('publish_posts')) : ?>
    <?php  if(true) : ?>
        <div class="form-box">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <h4 class="form--title">回复工单</h4>
                </div>
                <!-- .col-md-12 end -->
                <div class="col-xs-12 col-sm-12 col-md-6">
                    <div class="form-group">
                        <label>工单标题:  </label>
                        <span><?php the_title(); ?></span>
                        <br>
                    </div>
                </div>
            </div>
            <!-- .row end -->
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <h4 class="form--title">详情内容*</h4>
                </div>
                <!-- .col-md-12 end -->
                <div class="col-xs-12 col-sm-4 col-md-12">
                    <div id="editor22">
                        <p>
                            <?php
                            the_content();
                            ?>
                        </p>
                    </div>
                </div>
                <!-- .col-md-12 end -->

            </div>
        </div>
        <div class="form-box">

            <div id="comments" class="comments-area">
                <?php
                $comments = get_comments(array("post_id" => $post_id,'order'=>'asc'));
                if($comments){
                    foreach ($comments as $v){
                        ?>
                        <div class="row" >
                            <div style="width: 100%">
                                <div class="form-group">
                                    <div style="float: left"><span class="avatar-img"><?php echo get_avatar($v->user_id,26).'  '.$v->comment_author; ?>:</span>
                                        <br>
                                        <br>
                                        <?php echo $v->comment_content; ?>
                                    </div>
                                    <div style="float: right"><?php echo $v->comment_date; ?></div>
                                </div>
                            </div>
                        </div>
                        <div></div>
                        <br>
                        <br>
                <?php
                    }
                }
                ?>
            </div>

            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <h4 class="form--title">回复*</h4>
                </div>
                <!-- .col-md-12 end -->
                <div class="col-xs-12 col-sm-4 col-md-12">
                    <div id="editor2">
                        <p>
                        </p>
                    </div>
                </div>
                <!-- .col-md-12 end -->

            </div>

            <!-- .row end -->
        </div>
        <!-- .form-box end -->
        <a href="#" class="btn-reply_feedback btn btn--primary" data-nonce="<?php echo $wp_create_nonce; ?>">回复</a>
<!--        <a href="/user?action=feedback" class=" btn btn--primary" data-nonce="--><?php //echo $wp_create_nonce; ?><!--">返回列表</a>-->
    <?php else: ?>
        <div class="form-box">
            <div class="col-12 _404">
                <div class="_404-inner">
                    <div class="entry-content">您没有发布权限，请联系管理员开通！</div>
                </div>
            </div>
        </div>
    <?php endif; ?>
    </form>
</div>

<script src="<?php echo get_template_directory_uri() ?>/assets/js/plugins/wangEditor.min.js"></script>

<script>
    $(function () {


//发布任务 go-task_write_post write_post

        if (document.getElementById("editor2")) {

            //插入编辑器
            var E = window.wangEditor
            var editor2 = new E('#editor2')
            editor2.customConfig.uploadImgServer = caozhuti.ajaxurl
            // 将图片大小限制为 2M
            editor2.customConfig.uploadImgMaxSize = 2 * 1024 * 1024
            editor2.customConfig.uploadImgParams = {
                nonce2: $(".go-add_feedback").data("nonce2"),
                action: 'update_img'
            }
            editor2.customConfig.uploadFileName = 'file'
            editor2.create()

        }

        $('.btn-reply_feedback').on('click', function(event){
            // debugger
            event.preventDefault()
            var _this = $(this)
            var deft = _this.html()

            // var feedback_title = $("input[name='post_title']").val();
            // var feedback_cat = $("select[name='post_cat']").val();
            var feedback_content = editor2.txt.html();
            // _this.html(iconspin+deft)


            $.post(caozhuti.ajaxurl,
                {
                    post_id: <?php echo $post_id; ?>,
                    feedback_content: feedback_content,
                    nonce: "<?php echo wp_create_nonce('feedback') ?>",
                    action: 'reply_feedback'
                },
                function (data) {
                    if (data.status == 1) {
                        _this.html(deft)
                        Swal.fire({
                            html: data.msg,
                            type: 'success',
                        }).then((result) => {
                            if (result.value) {
                                location.reload()
                            }
                        })
                    }else{
                        _this.html(deft)
                        Swal.fire('',data.msg,'warning')
                    }
                }
            );
        });
    })
</script>
<style>
    .avatar-img img{
        display: inline;
    }
</style>
