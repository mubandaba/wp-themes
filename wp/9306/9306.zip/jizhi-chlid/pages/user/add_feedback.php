<?php
global $current_user;
$wp_create_nonce = wp_create_nonce('caoclick-' . $current_user->ID);
?>
<style type="text/css"></style>
<div class="col-xs-12 col-sm-12 col-md-9">
    <form class="mb-0">
<!--    --><?php // if(_cao('is_all_publish_posts') || current_user_can('publish_posts')) : ?>
    <?php  if(true) : ?>
        <div class="form-box">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <h4 class="form--title">创建工单</h4>
                </div>

                <!-- .col-md-12 end -->
                <div class="col-xs-12 col-sm-12 col-md-6">
                    <div class="form-group">
                        <label>标题*</label>
                        <input type="text" class="form-control" name="post_title" placeholder="请输入标题" value="" aria-required='true' required>
                    </div>
                </div>
                <?php $categories = get_categories( array('hide_empty' => 0,'taxonomy'=>'feedback-cat') );?>
                <div class="col-xs-12 col-sm-12 col-md-6">
                    <div class="form-group mb-0">
                        <label for="">问题分类</label>
                        <div class="select--box">
                            <select class="dropdown" name="post_cat">
                                <?php foreach($categories as $category){ ?>
<!--                                <option value="--><?php //echo $category->term_id; ?><!--">--><?php //echo $category->name; ?><!--</option>-->
                                <option value="<?php echo $category->name; ?>"><?php echo $category->name; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                </div>

            </div>
            <!-- .row end -->
        </div>
        <div class="form-box">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <h4 class="form--title">详情内容*</h4>
                </div>
                <!-- .col-md-12 end -->
                <div class="col-xs-12 col-sm-4 col-md-12">
                    <div id="editor2">
                        <p></p>
                    </div>
                </div>
                <!-- .col-md-12 end -->

            </div>
            <!-- .row end -->
        </div>
        <!-- .form-box end -->
        <a href="#" class="btn-add_feedback btn btn--primary" data-status="pending" data-nonce="<?php echo $wp_create_nonce; ?>">提交工单</a>
    <?php else: ?>
        <div class="form-box">
            <div class="col-12 _404">
                <div class="_404-inner">
                    <div class="entry-content">您没有发布权限，请联系管理员开通！</div>
                </div>
            </div>
        </div>
    <?php endif; ?>
    </form>
</div>

<script src="<?php echo get_template_directory_uri() ?>/assets/js/plugins/wangEditor.min.js"></script>

<script>
    $(function () {


//发布任务 go-task_write_post write_post

        if (document.getElementById("editor2")) {

            //插入编辑器
            var E = window.wangEditor
            var editor2 = new E('#editor2')
            editor2.customConfig.uploadImgServer = caozhuti.ajaxurl
            // 将图片大小限制为 2M
            editor2.customConfig.uploadImgMaxSize = 2 * 1024 * 1024
            editor2.customConfig.uploadImgParams = {
                nonce2: $(".go-add_feedback").data("nonce2"),
                action: 'update_img'
            }
            editor2.customConfig.uploadFileName = 'file'
            editor2.create()

        }

        $('.btn-add_feedback').on('click', function(event){
            // debugger
            event.preventDefault()
            var _this = $(this)
            var deft = _this.html()

            var feedback_title = $("input[name='post_title']").val();
            var feedback_cat = $("select[name='post_cat']").val();
            var feedback_content = editor2.txt.html();
            _this.html(iconspin+deft)

            if (feedback_title.length < 6) {
                _this.html(deft)
                Swal.fire('','工单标题最低6个字符','warning')
                return false;
            }

            $.post(caozhuti.ajaxurl,
                {
                    feedback_title: feedback_title,
                    feedback_cat: feedback_cat,
                    feedback_content: feedback_content,
                    nonce: "<?php echo wp_create_nonce('feedback') ?>",
                    action: 'add_feedback'
                },
                function (data) {
                    if (data.status == 1) {
                        _this.html(deft)
                        Swal.fire({
                            html: data.msg,
                            type: 'success',
                        }).then((result) => {
                            if (result.value) {
                                window.location.href = '/user?action=feedback'
                            }
                        })
                    }else{
                        _this.html(deft)
                        Swal.fire('',data.msg,'warning')
                    }
                }
            );
        });
    })
</script>
