<?php
global $current_user;
$wp_create_nonce = wp_create_nonce('caoclick-' . $current_user->ID);
?>
<style type="text/css"></style>
<?php
global $wp_query;
$args_where=array(
    'post_type'      => 'feedback',
    'post_status'    => 'publish',
    'author'    => get_current_user_id(),
    'posts_per_page' => 99,
);
if(!empty($_GET['id'])){
    $where_post_id=intval($_GET['id']);
    $args_where['post__in']=[$where_post_id];
}else{
    $where_post_id='';
}

$feedback_status = 0;
if ( ! empty($_GET['status'])) {
    $feedback_status = intval($_GET['status']);
    if ($feedback_status == 2) {
        $args_where['meta_key']   = 'feedback_status';
        $args_where['meta_value'] = $feedback_status;
    } elseif ($feedback_status == 1) {//进行中工单 包含处理中与已回复 meta key or 查询
//        $args_where['meta_query'] = array(
//            'relation' => 'OR',
//            array(
//                'meta_key'   => 'feedback_status',
//                'meta_value' => 0,
//            ),
//            array(
//                'meta_key'   => 'feedback_status',
//                'meta_value' => 1,
//            )
//        );
        $args_where['meta_query'] = $meta_query_args = array(
            'relation' => 'OR',
            array(
                'key'     => 'feedback_status',
                'value'   => '2',
                'compare' => '!='
            )
        );;
    }
}

$wp_query = new WP_Query( $args_where );

?>
<div class="col-xs-12 col-sm-12 col-md-9">
    <div class="feedback form-box" style="padding:10px 40px">
        <div class="row">
            <div class="mwz">
                <li class="cur"><a>我的工单</a></li>
                <li class="prompt r">总计 <span class="orange total"><?php echo $wp_query->post_count; ?></span> 个工单</li>
            </div>
        </div>

        <form method="get">
            <!-- 初始化页面input -->
            <input type="hidden" name="action" value="feedback">
            <input type="hidden" name="page" value="">
            <div class="row mso buy">
                <ul class="Search-box">
                    <div class="div_search">
                        <div>
                            <label>工单ID：</label>
                            <input name="id" placeholder="请输入工单ID" style="width:120px;" value="<?php echo $where_post_id; ?>" type="text">
                        </div>
                    </div>
                    <div class="div_search" style="margin-left:30px;">
                        <label>工单状态：</label>
                        <select name="status">
                            <option value="0">全部工单</option>
                            <option value="1">进行工单</option>
                            <option value="2" <?php if($feedback_status==2)echo 'selected'; ?>>结束工单</option>
                        </select>
                    </div>
                    <div class="div_search">
                        <input type="submit" class="search-btn" style="margin-left:30px;background-color: #265892;line-height: initial;padding:0 18px" value="搜索">
                        <a class="search-btn" style="margin-left:30px;" href="/user?action=add_feedback">创建工单</a>
                    </div>
                </ul>
            </div>
            <table class="table table-feedback">
                <thead>
                <tr>
                    <th class="text-center">工单ID</th>
                    <th class="text-center">工单标题</th>
                    <th class="text-center">问题分类</th>
                    <th class="text-center">提交时间</th>
                    <th class="text-center">状态</th>
                    <th class="text-center">操作</th>
                </tr>
                </thead>
                <tbody>
                <?php
                // 循环
                while (have_posts()) : the_post();
                    ?>
                    <tr>
                        <td class="text-center"><?php echo get_the_ID(); ?></td>
                        <td class="text-center" style="max-width: 500px;overflow: hidden;"><?php the_title(); ?></td>
                        <td class="text-center"><?php
                            $arr = get_the_terms(get_post(), 'feedback-cat');
                            if($arr){
                                echo $arr[0]->name;
                            }

                            ?></td>
                        <td class="text-center"><?php the_date(); ?></td>
                        <td class="text-center">
                            <?php
                            $feedback_status = get_post_meta(get_the_ID(), 'feedback_status', true);
                            if($feedback_status==0){
                                echo '<span class="feedback_start">处理中</span>';
                            }elseif($feedback_status==1){
                                echo '<span class="feedback_reply_status">已回复</span>';
                            }elseif($feedback_status==2){
                                echo '<span class="feedback_end_status">已结束</span>';
                            }
                            ?>
                        </td>
                        <td class="text-center">
                            <?php
                            $feedback_status = get_post_meta(get_the_ID(), 'feedback_status', true);
                            if ($feedback_status == 0) {
                                ?>
                                <span class="feedback_reply" data-id="<?php echo get_the_ID(); ?>">回复</span>
                                <span class="feedback_end" data-id="<?php echo get_the_ID(); ?>">结束</span>
                                <?php
                            } elseif ($feedback_status == 1) {
                                ?>
                                <span class="feedback_reply" data-id="<?php echo get_the_ID(); ?>">回复</span>
                                <span class="feedback_end" data-id="<?php echo get_the_ID(); ?>">结束</span>
                                <?php
                            } elseif ($feedback_status == 2) {
                                ?>
                                <span class="feedback_delete" data-id="<?php echo get_the_ID(); ?>">删除</span>
                                <?php
                            }
                            ?>


                        </td>
                    </tr>
                <?php
                endwhile;



                ?>
                <?php if(empty($wp_query->post_count)){ ?>
                <tr>
                    <td colspan="12" align="center"><strong>没有数据</strong></td>
                </tr>
                <?php }
                // 重置查询
                wp_reset_query();
                ?>
                </tbody>
            </table>
        </form>
    </div>
</div>
<?php
wp_enqueue_style('feedback',get_stylesheet_directory_uri().'/assets/css/feedback.css?vv=0.0.1');
wp_enqueue_script('feedbackjs',get_stylesheet_directory_uri().'/assets/js/feedback.js?vv=0.02');
?>
