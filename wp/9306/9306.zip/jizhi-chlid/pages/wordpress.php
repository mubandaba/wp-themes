<?php
/*
Template Name: WORDPRESS下载
*/
?>
<?php get_header(); ?>
<?php
$site_wpxz_text = _cao('site_wpxz_text');
if (is_array($site_wpxz_text)  && _cao('home_wpxz_text') ) : ?>
<link href="/wp-content/themes/jizhi-chlid/css/page.min.css" rel="stylesheet">
<header class="header text-white h-fullscreen" style="background-image: url(/wp-content/themes/jizhi-chlid/images/1.jpg)">
<div class="overlay opacity-90" style="background-color: #000"></div>
<div class="container text-center">
<div class="row h-100">
<div class="col-lg-8 mx-auto align-self-center">
<p><img src="/wp-content/themes/jizhi-chlid/images/wordpress.png" alt="logo"></p>
<h1 class="display-4 my-6"><strong><?php echo $site_wpxz_text['wpxz_1_text']; ?></strong></h1>
<p class="lead-3"> <b><?php echo $site_wpxz_text['wpxz_1_text']; ?></b> <?php echo $site_wpxz_text['wpxz_1_down']; ?> </b></br><?php echo $site_wpxz_text['wpxz_1_texte']; ?></p>
<p>
<a class="btn btn-xl btn-round btn-outline-light w-250" href="<?php echo $site_wpxz_text['wpxz_1_link']; ?>">立即下载</a>
<br>
<span class="opacity-60 small-3"><?php echo $site_wpxz_text['wpxz_b1_text']; ?></span>
</p>
</div>
</div>
</div>
</header>

<section class="section bg-gray">
<div class="container">
<header class="section-header">
<small></small>
<h2><?php echo $site_wpxz_text['wpxz_2_text']; ?></h2>
<hr>
<p class="lead"><?php echo $site_wpxz_text['wpxz_2_down']; ?></p>
</header>
<div data-provide="slider" data-dots="true" data-autoplay="false" data-slides-to-show="2">
<div class="p-5">
<div class="card border hover-shadow-6">
<div class="card-body px-5">
<div class="row">
<div class="col-auto mr-auto">
<h6><strong><?php echo $site_wpxz_text['wpxz_21_down']; ?></strong></h6>
</div>
<div class="col-auto">
<div class="rating mb-3">
<label class="fa fa-star active"></label>
<label class="fa fa-star active"></label>
<label class="fa fa-star active"></label>
<label class="fa fa-star active"></label>
<label class="fa fa-star active"></label>
</div>
</div>
</div>
<p><?php echo $site_wpxz_text['wpxz_211_down']; ?></p>
<p class="small-2 text-lighter mb-0">By <a class="text-inherit" href="" target="_blank"><em><?php echo $site_wpxz_text['wpxz_212_down']; ?></em></a></p>
</div>
</div>
</div>
<div class="p-5">
<div class="card border hover-shadow-6">
<div class="card-body px-5">
<div class="row">
<div class="col-auto mr-auto">
<h6><strong><?php echo $site_wpxz_text['wpxz_22_down']; ?></strong></h6>
</div>
<div class="col-auto">
<div class="rating mb-3">
<label class="fa fa-star active"></label>
<label class="fa fa-star active"></label>
<label class="fa fa-star active"></label>
<label class="fa fa-star active"></label>
<label class="fa fa-star active"></label>
</div>
</div>
</div>
<p><?php echo $site_wpxz_text['wpxz_221_down']; ?></p>
<p class="small-2 text-lighter mb-0">By <a class="text-inherit" href="" target="_blank"><em><?php echo $site_wpxz_text['wpxz_222_down']; ?></em></a></p>
</div>
</div>
</div>
<div class="p-5">
<div class="card border hover-shadow-6">
<div class="card-body px-5">
<div class="row">
<div class="col-auto mr-auto">
<h6><strong><?php echo $site_wpxz_text['wpxz_23_down']; ?></strong></h6>
</div>
<div class="col-auto">
<div class="rating mb-3">
<label class="fa fa-star active"></label>
<label class="fa fa-star active"></label>
<label class="fa fa-star active"></label>
<label class="fa fa-star active"></label>
<label class="fa fa-star active"></label>
</div>
</div>
</div>
<p><?php echo $site_wpxz_text['wpxz_231_down']; ?></p>
<p class="small-2 text-lighter mb-0">By <a class="text-inherit" href="" target="_blank"><em><?php echo $site_wpxz_text['wpxz_232_down']; ?></em></a></p>
</div>
</div>
</div>
<div class="p-5">
<div class="card border hover-shadow-6">
<div class="card-body px-5">
<div class="row">
<div class="col-auto mr-auto">
<h6><strong><?php echo $site_wpxz_text['wpxz_24_down']; ?></strong></h6>
</div>
<div class="col-auto">
<div class="rating mb-3">
<label class="fa fa-star active"></label>
<label class="fa fa-star active"></label>
<label class="fa fa-star active"></label>
<label class="fa fa-star active"></label>
<label class="fa fa-star active"></label>
</div>
</div>
</div>
<p><?php echo $site_wpxz_text['wpxz_241_down']; ?></p>
<p class="small-2 text-lighter mb-0">By <a class="text-inherit" href="" target="_blank"><em><?php echo $site_wpxz_text['wpxz_242_down']; ?></em></a></p>
</div>
</div>
</div>
</div>
</div>
</section>


</main>



<script src="/wp-content/themes/jizhi-chlid/css/page.min.js" type="46d61b4574d7d8b03cb88920-text/javascript"></script>
<script src="/wp-content/themes/jizhi-chlid/css/script.js" type="46d61b4574d7d8b03cb88920-text/javascript"></script>
<script src="/wp-content/themes/jizhi-chlid/css/rocket-loader.min.js" data-cf-settings="46d61b4574d7d8b03cb88920-|49" defer=""></script>
<?php endif; ?>

<?php get_footer(); ?>