<?php


/**
 * 子主题函数
 * RiPro是一个优秀的主题，首页拖拽布局，高级筛选，自带会员生态系统，超全支付接口，你喜欢的样子我都有！
 * 本子主题基于Ripro主题
 * 正版唯一购买地址，无需授权下载使用：https://www.zhankr.net/
 * 作者唯一QQ：80027422 （站壳网）
 * 承蒙您对本主题的喜爱，我们愿向小三一样，做大哥的女人，做大哥网站中最想日的一个。
 * 能理解使用盗版的人，但是不能接受传播盗版，本身主题没几个钱，主题自有支付体系和会员体系，盗版风险太高，鬼知道那些人乱动什么代码，无利不起早。
 * 开发者不易，感谢支持，更好的更用心的等你来调教
 */
//加载style.css 子主题样式
function ripro_chlid_style() {
    if (!is_admin()) {
    	//挂在父主题优先最前
        wp_register_style('ripro_chlid_style', get_stylesheet_directory_uri() . '/diy.css',  array('app'), '', 'all');
        wp_enqueue_style('ripro_chlid_style');
    }
}
add_action('init', 'ripro_chlid_style');
session_start();
$_SESSION['authcode'] = true;
//加载站壳网高级功能
/**
 * 后台设置
 */
require_once get_template_directory() . '/inc/codestar-framework/codestar-framework.php';

require_once plugin_dir_path( __FILE__ ) .'zhankr/options.theme.php';

require_once get_stylesheet_directory() . '/functions-feedback.php';//工单相关功能实现

require_once get_stylesheet_directory() . '/functions-zhankr.php';//高级功能实现

//  文章简码优化排版
require_once get_stylesheet_directory() . '/zhankr/inc/shortcodes/shortcodes.php';
require_once get_stylesheet_directory() . '/zhankr/inc/shortcodes/shortcodespanel.php'; 


// 每周更新的文章数量
function get_week_post_count(){
$date_query = array(
array(
'after'=>'1 week ago'
)
);$args = array(
'post_type' => 'post',
'post_status'=>'publish',
'date_query' => $date_query,
'no_found_rows' => true,
'suppress_filters' => true,
'fields'=>'ids',
'posts_per_page'=>-1
);
$query = new WP_Query( $args );
echo $query->post_count;
}
// 每日更新的文章数量
function WeeklyUpdate() {
$today = getdate();
$query = new WP_Query( 'year=' . $today["year"] . '&monthnum=' . $today["mon"] . '&day=' . $today["mday"]);
$postsNumber = $query->found_posts;
echo $postsNumber;
}

//文章数排序
/*
Plugin Name: Sort Users by Post Count
Description: Add a column to the Users page in the admin to sort users by post counts.https://github.com/ksemel/sort-users-by-post-count
Version: 1.0
Author: Katherine Semel
*/
if ( ! class_exists('Sort_Users_By_Post_Count') ) {
    class Sort_Users_By_Post_Count {
        function __construct() {
            // Make user table sortable by post count
            add_filter( 'manage_users_sortable_columns', array( $this, 'add_custom_user_sorts' ) );
        }
        /* Add sorting by post count to user page */
        function add_custom_user_sorts( $columns ) {
            $columns['posts'] = 'post_count';
            return $columns;
        }
    }
    $Sort_Users_By_Post_Count = new Sort_Users_By_Post_Count();
}

//用户注册时间排序
add_filter('manage_users_columns', function($column_headers){
	$column_headers['registered'] = '注册时间';
	return $column_headers;
});

add_filter('manage_users_custom_column', function($value, $column_name, $user_id){
	if($column_name=='registered'){
		$user = get_userdata($user_id);
		return get_date_from_gmt($user->user_registered);
	}else{
		return $value;
	}
},11,3);


add_filter('manage_users_sortable_columns', function($sortable_columns){
	$sortable_columns['reg_time'] = 'reg_time';
	return $sortable_columns;
});

add_action('pre_user_query', function($query){
	if(!isset($_REQUEST['orderby']) || $_REQUEST['orderby']=='reg_time' ){
		if( !in_array($_REQUEST['order'],array('asc','desc')) ){
			$_REQUEST['order'] = 'desc';
		}
		$query->query_orderby = "ORDER BY user_registered ".$_REQUEST['order']."";
	}
});


 // WordPress 自动为文章添加已使用过的标签
function array2object($array) { // 数组转对象
if (is_array($array)) {
$obj = new StdClass();
foreach ($array as $key => $val){
$obj->$key = $val;
}
}
else {
$obj = $array;
}
return $obj;
}
function object2array($object) { // 对象转数组
if (is_object($object)) {
foreach ($object as $key => $value) {
$array[$key] = $value;
}
}
else {
$array = $object;
}
return $array;
}
add_action('save_post', 'auto_add_tags');
function auto_add_tags(){
$tags = get_tags( array('hide_empty' => false) );
$post_id = get_the_ID();
$post_content = get_post($post_id)->post_content;
if ($tags) {
$i = 0;
$arrs = object2array($tags);shuffle($arrs);$tags = array2object($arrs);// 打乱顺序
foreach ( $tags as $tag ) {
// 如果文章内容出现了已使用过的标签，自动添加这些标签
if ( strpos($post_content, $tag->name) !== false){
if ($i == 5) { // 控制输出数量
break;
}
wp_set_post_tags( $post_id, $tag->name, true );
$i++;
}
}
}
}
/* 自动为文章内的标签添加内链 */
$match_num_from = 1;        //一篇文章中同一个标签少于几次不自动链接
$match_num_to = 1;      //一篇文章中同一个标签最多自动链接几次
function tag_sort($a, $b){
    if ( $a->name == $b->name ) return 0;
    return ( strlen($a->name) > strlen($b->name) ) ? -1 : 1;
}
function tag_link($content){
    global $match_num_from,$match_num_to;
        $posttags = get_the_tags();
        if ($posttags) {
            usort($posttags, "tag_sort");
            foreach($posttags as $tag) {
                $link = get_tag_link($tag->term_id);
                $keyword = $tag->name;
                $cleankeyword = stripslashes($keyword);
                $url = "<a href=\"$link\" title=\"".str_replace('%s',addcslashes($cleankeyword, '$'),__('【查看更多[%s]标签的文章】'))."\"";
                $url .= ' target="_blank"';
                $url .= ">".addcslashes($cleankeyword, '$')."</a>";
                $limit = rand($match_num_from,$match_num_to);
                $content = preg_replace( '|(<a[^>]+>)(.*)('.$ex_word.')(.*)(</a[^>]*>)|U'.$case, '$1$2%&&&&&%$4$5', $content);
                $content = preg_replace( '|(<img)(.*?)('.$ex_word.')(.*?)(>)|U'.$case, '$1$2%&&&&&%$4$5', $content);
                $cleankeyword = preg_quote($cleankeyword,'\'');
                $regEx = '\'(?!((<.*?)|(<a.*?)))('. $cleankeyword . ')(?!(([^<>]*?)>)|([^>]*?</a>))\'s' . $case;
                $content = preg_replace($regEx,$url,$content,$limit);
                $content = str_replace( '%&&&&&%', stripslashes($ex_word), $content);
            }
        }
    return $content;
}
add_filter('the_content','tag_link',1);

//启用友情链接

add_filter('pre_option_link_manager_enabled','__return_true');

//导航栏目统计
function wt_get_category_count($cat_ID) {
	$category = get_category($cat_ID);
	return $category->count;
}
function zhankr_nav_items_num( $items,$args ) {
	if(isset($args->theme_location) && $args->theme_location == 'menu-1') {
		foreach ( $items as $key=>$item ) {
			if($item->object == 'category') {
				//$cat = get_category_by_slug($slug);
				$catID = isset($item->object_id) ? $item->object_id : false;
				if($catID && $item->post_parent!=0) {
					$a=wt_get_category_count($catID);
					$items[$key]->title.= '<span class="zhankr-num">'.$a.'</span>';
				}
			}
		}
	}
	return $items;
}
add_filter( 'wp_nav_menu_objects', 'zhankr_nav_items_num',10,2 );

//站壳网添加文本编辑自定义快捷标签按钮
 add_action('after_wp_tiny_mce', 'bolo_after_wp_tiny_mce');
 function bolo_after_wp_tiny_mce($mce_settings) {
 ?>
 <script type="text/javascript">
 QTags.addButton( 'z_mhz', '迷幻紫', '<div id="zk_mhz">迷幻紫</div>\n', "" );
 QTags.addButton( 'z_xgh', '西瓜红', '<div id="zk_xgh">西瓜红</div>\n', "" );
 QTags.addButton( 'z_tkzj', '天空之境', '<div id="zk_tkzj">天空之境</div>\n', "" );
 QTags.addButton( 'z_xyz', '小宇宙', '<div id="zk_xyz">小宇宙</div>\n', "" );
 QTags.addButton( 'z_gll', '橄榄绿', '<div id="zk_gll">橄榄绿</div>\n', "" );
 QTags.addButton( 'z_xty', '小太阳', '<div id="zk_xty">小太阳</div>\n', "" );
 QTags.addButton( 'z_yyz', '优雅紫', '<div id="zk_yyz">优雅紫</div>\n', "" );
 QTags.addButton( 'z_szh', '深邃黑', '<div id="zk_szh">深邃黑</div>\n', "" );
 QTags.addButton( 'z_wbk', '无边框', '<div id="zk_wbk">无边框</div>\n', "" );
 function bolo_QTnextpage_arg1() {
 }
 </script>
 <?php
 }
//优快讯功能
add_action('init', 'my_shuoshuo');
function my_shuoshuo()
{ $labels = array( 'name' => '优快讯',
'singular_name' => '优快讯',
'add_new' => '发表快讯',
'add_new_item' => '发表快讯',
'edit_item' => '编辑快讯',
'new_item' => '新快讯',
'view_item' => '查看快讯',
'search_items' => '搜索快讯',
'not_found' => '暂无快讯',
'not_found_in_trash' => '没有已遗弃的快讯',
'parent_item_colon' => '', 'menu_name' => '优快讯' );
$args = array( 'labels' => $labels,
'public' => true,
'publicly_queryable' => true,
'show_ui' => true,
'show_in_menu' => true,
'exclude_from_search' =>true,
'query_var' => true,
'rewrite' => true,
'capability_type' => 'post',
'has_archive' => true, 'hierarchical' => false,
'menu_position' => null, 'supports' => array('editor','author','title','comments') );
register_post_type('youkuaixun',$args);
}
//游客提示登录
function curPageURL() 
{
    $pageURL = 'http';

    if ($_SERVER["HTTPS"] == "on") 
    {
        $pageURL .= "s";
    }
    $pageURL .= "://";

    $pageURL .= $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"];
    return $pageURL;
}

//////////////////////////////////////////////自定义功能添加到下面//////////////////////////////////////////////

