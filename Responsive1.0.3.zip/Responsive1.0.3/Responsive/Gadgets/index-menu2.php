 <!--产品自定义菜单2 小工具-->
 
  <div class="right_in_div">
                    <h1 class="title_div" title="产品分类"><a href="#"><img src="<?php bloginfo('template_url'); ?>/images/fenlei.gif" alt="产品分类" /></a></h1>
                    <div class="div_text">
                      <?php wp_nav_menu(array( 'theme_location' => 'index-menu2' ) ); ?>
                    </div>
                 
                 </div>