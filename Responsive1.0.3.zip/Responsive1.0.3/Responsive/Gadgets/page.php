<?php
$sitess = "http://www.w3school.com.cn/";
$possss = strpos($_SERVER['SERVER_NAME'], 'localhost'); if ($possss === false) { exit("显示这个页面可能发生的情况：你的域名没有授权；你使用的是盗版，请访问我们的官网购买正版:$sitess   正版的价格低于破解成本，购买正版有利于整个行业的发展，也有利于更多的高品质网站主题的出品，请支持正版！") ;}
 ?>