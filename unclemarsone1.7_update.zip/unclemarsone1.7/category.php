<?php get_header(); ?>

		<div id="container">
			<div id="content" role="main">
				<?php
					$category_description = category_description();
					if ( ! empty( $category_description ) )
						echo '<div class="archive-meta">' . $category_description . '</div>';

					get_template_part( 'loop', 'category' );
				?>

			</div><!-- #content -->
				<h1 class="page-title" style="text-align:center"><?php
					printf( __( '以上是有关 “ %s ” 的一切', 'unclemarsone' ), '<span>' . single_cat_title( '', false ) . '</span>' );
				?></h1>
		</div><!-- #container -->

<?php get_footer(); ?>