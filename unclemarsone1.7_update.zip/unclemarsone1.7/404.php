<?php get_header(); ?>

	<div id="container">
		<div id="content" role="main">

			<div id="post-0" class="post error404 not-found">
				<h1 class="entry-title"><?php _e( 'Orz 出错啦～', 'unclemarsone' ); ?></h1>
				<div class="entry-msgcontent">
					<p><?php _e( '也许这个页面之前存在...也许被我那粗心的主人误删了...也许你就是故意输错地址想看些什么...反正它现在不在了...怎么办...找我主人去呗...什么...联系方式？好吧告诉你，听好了 marsloong[at]gmail.com', 'unclemarsone' ); ?></p>
					<p><?php _e( '当然你也可以问问右上角那位搜索大哥', 'unclemarsone' ); ?></p>
					<a href="/">算了，回首页吧</a>
					<br /><br />
				</div><!-- .entry-content -->
			</div><!-- #post-0 -->

		</div><!-- #content -->
	</div><!-- #container -->
	<script type="text/javascript">
		// focus on search field after it has loaded
		document.getElementById('s') && document.getElementById('s').focus();
	</script>

<?php get_footer(); ?>