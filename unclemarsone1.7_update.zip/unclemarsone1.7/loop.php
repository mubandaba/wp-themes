<?php if ( ! have_posts() ) : ?>
	<div id="post-0" class="post error404 not-found">
		<h1 class="entry-title"><?php _e( '什么都木有', 'unclemarsone' ); ?></h1>
		<div class="entry-content">
			<p><?php _e( '这里空空如也，什么都木有，去别处转转吧', 'unclemarsone' ); ?></p>
			<?php get_search_form(); ?>
		</div><!-- .entry-content -->
	</div><!-- #post-0 -->
<?php endif; ?>

<?php $unclemarsone_theme_options = get_option('unclemarsone_theme_options') ?>

<div id="boxes">
<?php while ( have_posts() ) : the_post(); ?>

	<div class="box">
		<div class="rel">
			<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('homepage-thumb', array('alt' => '', 'title' => '')) ?></a>
	<?php if ($unclemarsone_theme_options['images_only'] == 0): ?>
			<div class="categories"><?php unclemarsone_posted_in(); ?></div>
			<h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
		<?php the_excerpt() ?>
			<div class="posted">
			<?php unclemarsone_posted_on() ?> <span class="main_separator">/</span>
			<?php echo comments_popup_link( __( '0 条评论', 'unclemarsone' ), __( '1 条评论', 'unclemarsone' ), __( '% 条评论', 'unclemarsone' ) ); ?> <span class="main_separator">/</span>
			<?php the_views() ?> 
			</div>
	<?php endif ?>
			<div class="texts">
	<?php if ($unclemarsone_theme_options['images_only'] == 1): ?>
				<a class="transparent" href="<?php the_permalink(); ?>"><?php the_post_thumbnail('homepage-thumb', array('alt' => '', 'title' => '')) ?></a>
	<?php endif ?>
				<div class="abs">
	<?php if ($unclemarsone_theme_options['images_only'] == 0): ?>
				<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('homepage-thumb', array('alt' => '', 'title' => '')) ?></a>
	<?php endif ?>
					<div class="categories"><?php unclemarsone_posted_in(); ?></div>
					<h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
		<?php the_excerpt() ?>
					<div class="posted">
					<?php unclemarsone_posted_on() ?> <span class="main_separator">/</span>
					<?php echo comments_popup_link( __( '0 条评论', 'unclemarsone' ), __( '1 条评论', 'unclemarsone' ), __( '% 条评论', 'unclemarsone' ) ); ?> <span class="main_separator">/</span>
					<?php the_views() ?> 
					</div>
				</div>
			</div>
		</div>
	</div>

<?php endwhile; ?>
</div>

<?php if ( $wp_query->max_num_pages > 1 ) :
	if ( $unclemarsone_theme_options['navigation'] == 0 ) : // Default ?>

<div class="fetch">
	<?php next_posts_link( __( '狠戳这里　加载更多', 'unclemarsone' ) ); ?>
</div>

<script type="text/javascript">
// Ajax-fetching "Load more posts"
$('.fetch a').live('click', function(e) {
	e.preventDefault();
	$(this).addClass('loading').text('加载中...');
	$.ajax({
		type: "GET",
		url: $(this).attr('href') + '#boxes',
		dataType: "html",
		success: function(out) {
			result = $(out).find('#boxes .box');
			nextlink = $(out).find('.fetch a').attr('href');
			$('#boxes').append(result).masonry('appended', result);
			$('.fetch a').removeClass('loading').text('狠戳这里　加载更多');
			if (nextlink != undefined) {
				$('.fetch a').attr('href', nextlink);
			} else {
				$('.fetch').remove();
			}
		}
	});
});
</script>

	<?php elseif ( $unclemarsone_theme_options['navigation'] == 1 ) : // Infinite scroll ?>

<div class="infinitescroll">
	<?php next_posts_link( __( '狠戳这里　加载更多', 'unclemarsone' ) ); ?>
</div>

<script type="text/javascript">
// Infinite Scroll
var href = 'first';
$(document).ready(function() {
	$('#boxes').infinitescroll({
		navSelector : '.infinitescroll',
		nextSelector : '.infinitescroll a',
		itemSelector : '#boxes .box',
		loadingImg : '<?php echo get_bloginfo('stylesheet_directory') ?>/images/loading.gif',
		loadingText : 'Loading...',
		donetext : 'No more pages to load.',
		debug : false
	}, function(arrayOfNewElems) {
		$('#boxes').masonry('appended', $(arrayOfNewElems));
		if (href != $('.infinitescroll a').attr('href'))
		{
			href = $('.infinitescroll a').attr('href');
		}
	});
});
</script>

	<?php endif; ?>

<?php endif; ?>