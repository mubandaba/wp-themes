<?php get_header(); ?>

		<div id="container" class="one-column">
			<div id="content" role="main">

			<?php get_template_part( 'loop', 'page' ); ?>

			</div><!-- #content -->
		</div><!-- #container -->

<?php get_footer(); ?>
