<?php get_header(); ?>

		<div id="container">
			<div id="content" role="main">
				<?php get_template_part( 'loop', 'tag' ); ?>
			</div><!-- #content -->
			<h1 class="page-title" style="text-align:center">
				<?php printf( __( '以上是有关 \'%s\' 的一切', 'unclemarsone' ), '<span>' . single_tag_title( '', false ) . '</span>' );?>
			</h1>
		</div><!-- #container -->

<?php get_footer(); ?>