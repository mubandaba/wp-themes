	</div><!-- #main -->

	<div id="footer">
		<div id="site-info">
			© 2012 <a href="/"><?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?></a><br />
			Theme by <a href="http://unclemars.me" target="_blank">UncleMars One</a>
			<span class="main_separator">/</span>
			Powered by <a href="http://www.wordpress.org" target="_blank">WordPress</a>
		</div><!-- #site-info -->
	</div><!-- #footer -->

</div><!-- .wrapper -->

<?php wp_footer(); ?>

<?php echo unclemarsonegoogle() ?>

</body>
</html>