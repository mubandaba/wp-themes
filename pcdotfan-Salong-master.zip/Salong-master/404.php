<?php
/*
*404
*/ 
get_header(); ?>
<!-- 面包屑与搜索 -->

<title>未知页面 | <?php bloginfo( 'name' ); ?></title>
<section class="container wrapper">
  <div class="content-width">
    <script type="text/javascript" src="http://www.qq.com/404/search_children.js" charset="utf-8"></script>
  </div>
</section>
<div class="clearfix"></div>
<?php get_footer(); ?>
