<aside class="post-copyright">
      <div class="author_avatar left"> <?php echo get_avatar( get_the_author_email(), '48' ); ?><h4 class="author_text"> 作者:<a href="<?php echo home_url(); ?>" title="<?php bloginfo( 'name' ); ?>"><?php the_author_nickname(); ?></a></h4></div>
      <div class="post-copy left">
  <?php   $custom_fields = get_post_custom_keys($post_id);
if (!in_array ('copyright', $custom_fields)) : ?>
  <a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a> 为 <a href="<?php echo home_url(); ?>" title="<?php bloginfo( 'name' ); ?>"><?php the_author_nickname(); ?></a> 原创，于 <?php echo human_time_diff(get_the_time('U'), current_time('timestamp')). '前'; ?> 发表在
    <?php the_category(', ') ?>
    分类下。
    <?php if (('open' == $post-> comment_status) && ('open' == $post->ping_status)) {?>
    <?php } elseif (('open' == $post-> comment_status) && !('open' == $post->ping_status)) { ?>
    <?php } ?>
    <br/>
    欢迎转载，并保留本文有效链接： <a href="<?php the_permalink() ?>
          " rel="bookmark" title="本文固定链接 <?php the_permalink() ?>"><?php the_title(); ?> | <?php bloginfo('name');?></a>
  <?php else: ?>
  <?php  $custom = get_post_custom($post_id);
$custom_value = $custom['copyright']; ?>
  <a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a> 来源： <a target="_blank" rel="nofollow" > <?php echo $custom_value[0] ?></a> ，由 <a href="<?php echo home_url(); ?>" title="<?php bloginfo( 'name' ); ?>"><?php the_author_nickname(); ?></a> 整理编辑，于 <?php echo human_time_diff(get_the_time('U'), current_time('timestamp')) . '前'; ?> 发表在 <?php the_category(', ') ?> 分类下。
    <?php if (('open' == $post-> comment_status) && ('open' == $post->ping_status)) {?>
    <?php } elseif (('open' == $post-> comment_status) && !('open' == $post->ping_status)) { ?>
    <?php } ?>
    <br/>
    链接地址： <a href="<?php the_permalink() ?> " rel="bookmark" title="本文固定链接 <?php the_permalink() ?>"><?php the_title(); ?> | <?php bloginfo('name');?></a>, 转载请保留本说明及本文有效链接！
  <?php endif; ?>
  <br>
  <span class="author-link"><a href="<?php echo home_url(); ?>" target="_blank" title="<?php bloginfo( 'name' ); ?>">作者主页</a>
  <a href="<?php echo stripslashes(get_option('sl_contribute_link')); ?>" target="_blank" title="<?php echo stripslashes(get_option('sl_contribute_text')); ?>"><?php echo stripslashes(get_option('sl_contribute_text')); ?></a>
  <a href="#alipay" title="<?php  bloginfo( 'name' ); ?>支付宝手机支付"><?php echo stripslashes(get_option('sl_alipay_text')); ?></a>
  <a href="<?php echo stripslashes(get_option('sl_feed_link')); ?>" target="_blank" title="<?php echo stripslashes(get_option('sl_feed_text')); ?>"><?php echo stripslashes(get_option('sl_feed_text')); ?></a>
  <a href="<?php echo stripslashes(get_option('sl_google_link')); ?>" target="_blank" title="<?php echo stripslashes(get_option('sl_google_text')); ?>"><?php echo stripslashes(get_option('sl_google_text')); ?></a></span>
  </div>
</aside>
<!--支付宝二维码按钮弹窗-->
<a href="#pay" class="overlay" id="alipay"></a>
<article class="popup weixin-popup">
  <h3>支付宝手机支付</h3>
    <?php $alipayqr_path = get_option('sl_alipayqr');
    if(!empty($alipayqr_path)) { ?>
        <img src="<?php echo $alipayqr_path; ?>" alt="<?php  bloginfo( 'name' ); ?>支付宝手机支付">
    <?php } ?>
    <p>请用支付宝钱包扫描</p>
</article>
