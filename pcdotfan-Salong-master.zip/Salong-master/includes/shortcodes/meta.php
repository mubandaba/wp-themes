<div class="shortcodes_control">
    <p>如果你想要使用简码请选择简码选项：</p>
<div>
<label>选择简码 <span></span></label>
<select name="items" class="shortcode_sel" size="1" onchange="document.forms.post.items_accumulated.value = this.options[selectedIndex].value;">

<option class="parentscat">1.消息框简码</option>
<option value="[yuanfangbox]远方的雪山[/yuanfangbox]">远方框</option>
<option value="[qixingbox]远方的雪山[/qixingbox]">骑行框</option>
<option value="[headsetbox]远方的雪山[/headsetbox]">音乐框</option>
<option value="[moviebox]远方的雪山[/moviebox]">电影框</option>
<option value="[shotbox]远方的雪山[/shotbox]">镜头框</option>
<option value="[painterbox]远方的雪山[/painterbox]">绘画框</option>
<option value="[ideabox]远方的雪山[/ideabox]">灯泡框</option>
<option value="[eventbox]远方的雪山[/eventbox]">事件框</option>
<option value="[wpbox]远方的雪山[/wpbox]">WP框</option>
<option value="[smilebox]远方的雪山[/smilebox]">笑脸框</option>

<option class="parentscat">2.按钮简码</option>
<option value="[scbutton link=&quot;#&quot; target=&quot;blank&quot; variation=&quot;red&quot;]远方的雪山[/scbutton]">红色</option>
<option value="[scbutton link=&quot;#&quot; target=&quot;blank&quot; variation=&quot;yellow&quot;]远方的雪山[/scbutton]">黄色</option>
<option value="[scbutton link=&quot;#&quot; target=&quot;blank&quot; variation=&quot;blue&quot;]远方的雪山[/scbutton]">蓝色</option>
<option value="[scbutton link=&quot;#&quot; target=&quot;blank&quot; variation=&quot;green&quot;]远方的雪山[/scbutton]">绿色</option>

<option class="parentscat">3.列表简码</option>
<option value="[ssredlist]<ul> <li>远方的雪山</li> <li>远方的雪山</li> <li>远方的雪山</li> </ul>[/ssredlist]">小红点</option>
<option value="[ssyellowlist]<ul> <li>远方的雪山</li> <li>远方的雪山</li> <li>远方的雪山</li> </ul>[/ssyellowlist]">小黄点</option>
<option value="[ssbluelist]<ul> <li>远方的雪山</li> <li>远方的雪山</li> <li>远方的雪山</li> </ul>[/ssbluelist]">小蓝点</option>
<option value="[ssgreenlist]<ul> <li>远方的雪山</li> <li>远方的雪山</li> <li>远方的雪山</li> </ul>[/ssgreenlist]">小绿点</option>

<option class="parentscat">4.视频简码</option>
<option value="[swf]Flash文件地址[/swf]">Flash</option>
<option value="[youku]视频ID[/youku]">优酷无广告视频</option>

<option class="parentscat">5.其它简码</option>
<option value="[toggle_box][toggle_item title=&quot;远方的雪山&quot; active=&quot;true&quot;]远方的雪山[/toggle_item][toggle_item title=&quot;远方的雪山&quot;]远方的雪山[/toggle_item][toggle_item title=&quot;远方的雪山&quot;]远方的雪山[/toggle_item][toggle_item title=&quot;远方的雪山&quot;]远方的雪山[/toggle_item][/toggle_box] ">开关菜单</option>
<option value="[tabgroup][tab title=&quot;远方的雪山&quot; id=&quot;1&quot;]&quot;远方的雪山&quot;[/tab][tab title=&quot;远方的雪山&quot; id=&quot;2&quot;]&quot;远方的雪山&quot;[/tab] [tab title=&quot;远方的雪山&quot; id=&quot;3&quot;]&quot;远方的雪山&quot;[/tab][/tabgroup]">TABS</option>
<option value="[reply]评论后可见内容[/reply]或[reply notice=&quot;自定义提醒回复内容&quot;]自定义提醒回复内容[/reply]">评论后可见内容</option>
<option value="<div id=&quot;directory&quot;><h3>文章目录</h3><ul><li><a href=&quot;#1&quot;>远方的雪山</a></li><li><a href=&quot;#2&quot;>远方的雪山</a></li><li><a href=&quot;#3&quot;>远方的雪山</a></li></ul></div> ">文章目录</option>
</select>
	<label>简码预览 <span>(在编辑框中复制简码)</span></label>
		<p>
			<textarea name="items_accumulated" rows="4"></textarea>
		</p>
</div>
</div>