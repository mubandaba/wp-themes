<?php
// 它季
class sl_taji_Widget extends WP_Widget{
    function sl_taji_Widget(){
    $widget_ops = array('classname'=>'sl_taji','description'=>'它季|专属民族格调商城！');
    $this->WP_Widget(false,'Salong-它季',$widget_ops);
    }
  function widget($instance){ ?>

<article class="sidebar-widget social_widget taji-widget">
  <h3>它季——专属民族格调商城！</h3>
  <section class="social-icons"> <a href="http://taji.me" title="它季|专属民族格调商城！" target="_blank"><img src="http://yfdxs.com/wp-content/uploads/2014/12/tajime.jpg" alt="它季|专属民族格调商城！"></a>
    <p>专属民族格调商城，在线销售普洱茶、大理石画、少数民族服饰、少数民族饰品！</p>
    <!-- 它季有赞 -->
    <article class="qr"><span><a href="http://taji.me" title="它季有赞微店商城" class="icons" target="_blank"><i class="icon-tajiyouzan"></i></a></span>
      <div class="weixin_content" style="display:none;">
        <div class="weixin_bg"> <img src="http://yfdxs.com/wp-content/uploads/2014/12/tajiyouzan.jpg" alt="它季有赞微店商城">
          <p>请扫描它季有赞微店商城二维码</p>
        </div>
      </div>
    </article>
    <!-- 它季有赞end -->
    <!-- 它季淘宝 -->
    <article class="qr"><span><a href="http://tajime.taobao.com" title="它季淘宝" class="icons" target="_blank"><i class="icon-tajitaobao"></i></a></span>
      <div class="weixin_content" style="display:none;">
        <div class="weixin_bg"> <img src="http://yfdxs.com/wp-content/uploads/2014/12/tajitaobao.jpg" alt="它季淘宝">
          <p>请用手机淘宝扫描它季二维码<br>或在淘宝中搜索"它季"添加收藏</p>
        </div>
      </div>
    </article>
    <!-- 它季淘宝end -->
    <!-- 它季首页 -->
    <article class="qr"><span><a href="http://taji.me" title="它季首页" class="icons" target="_blank"><i class="icon-tajihome"></i></a></span>
      <div class="clearfix"></div>
      <div class="weixin_content" style="display:none;">
        <div class="weixin_bg"> <img src="http://yfdxs.com/wp-content/uploads/2014/12/tajihome.jpg" alt="它季首页">
          <p>请用手机扫描二维码<br>
            在手机上浏览它季商城！</p>
        </div>
      </div>
    </article>
    <!-- 它季首页end -->
    <!-- 它季微信 -->
    <article class="qr"><span><a href="http://taji.me" title="它季微信公众号" class="icons" target="_blank"><i class="icon-weixin"></i></a></span>
      <div class="weixin_content" style="display:none;">
        <div class="weixin_bg"> <img src="http://yfdxs.com/wp-content/uploads/2014/12/tajiweixin.jpg" alt="它季微信公众号">
          <p>请用微信扫描它季微信公众号二维码<br>或在微信中搜索"tajishop"添加关注</p>
        </div>
      </div>
    </article>
    <!-- 它季微信end -->
    <div class="clearfix"></div>
  </section>
</article>
<?php } }
add_action('widgets_init',create_function('', 'return register_widget("sl_taji_Widget");'));
