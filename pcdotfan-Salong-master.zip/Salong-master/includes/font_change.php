<!-- 字体大小切换 -->
<div id="font-change" class="right">
<span id="font-dec"><a href="#" title="减小字体">-</a></span>
<span id="font-n"><a href="#" title="默认大小">N</a></span>
<span id="font-inc"><a href="#" title="增大字体">+</a></span>
</div>
<!-- 字体大小切换end -->