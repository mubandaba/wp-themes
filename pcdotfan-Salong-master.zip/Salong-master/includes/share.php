<section class="bdshare">
<span class="left"><b class="icon-share"></b><?php _e( '分享到您的社交平台：', 'salong' ); ?></span>
  <div class="bdsharebuttonbox right bdshare-button-style0-16" data-tag="share_1">
    <a class="icon-fbook" data-cmd="fbook"></a>
    <a class="icon-twi" data-cmd="twi"></a>
    <a class="icon-tsina" data-cmd="tsina"></a>
    <a class="icon-tqq" data-cmd="tqq"></a>
    <a class="icon-qzone" data-cmd="qzone"></a>
    <a class="icon-douban" data-cmd="douban"></a>
    <a class="icon-weixin" data-cmd="weixin"></a>
    <a class="icon-more" data-cmd="more"></a>
    <a class="bds_count" data-cmd="count"></a>
  </div>
</section>
<script>
  window._bd_share_config = {
    common : {
      bdText : '', 
      bdDesc : '', 
      bdUrl : '',   
      bdPic : ''
    },
    share : [{
      "bdSize" : 16
    }]
  }
  with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?cdnversion='+~(-new Date()/36e5)];
</script>