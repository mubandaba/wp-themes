<form method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>" >
  <input class="search-input" name="s" type="text" placeholder="站内搜索…" />
  <input title="站内搜索" class="search-submit" type="submit" value="">
</form>