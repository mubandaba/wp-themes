<?php get_header(); ?>
    <main class="main" role="main">
      <article class="hero-error">
        <div class="hero-error-content">
          <h2>优于别人，<br>并不高贵，<br>真正的高贵应该是优于过去的自己。</h2>
        </div>
      </article>
    </main>
<?php get_footer(); ?>