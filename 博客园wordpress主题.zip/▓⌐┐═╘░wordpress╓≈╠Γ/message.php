<?php
/*
Template Name: 留言板
*/
?>

<?php get_header(); ?>

<?php get_sidebar(); ?>

<div id="content">
	<?php if (have_posts()) : ?><?php while (have_posts()) : the_post(); ?>	
	<div class="post_nav_block_wrapper">
		<ul class="post_nav_block">
			<li><a <?php if ( is_home() && !(isset($_GET['order']))) echo 'class="current_nav"'; ?> href="<?php echo get_settings('home'); ?>">首页</a></li>
			<li><a <?php if ( isset($_GET['order']) && ($_GET['order']=='commented') ) echo 'class="current_nav"'; ?> href="<?php echo get_settings('home'); ?>?order=commented">热门文章</a></li>
			<li><a <?php if ( isset($_GET['order']) && ($_GET['order']=='rand') ) echo 'class="current_nav"'; ?> href="<?php echo get_settings('home'); ?>?order=rand">随便看看</a></li>
			<li><a class="current_nav" href="<?php echo curPageURL()?>"><?php the_title(); ?></a></li>
		</ul>
		<div id="feed"><a href="<?php bloginfo('rss2_url'); ?>" title="RSS">RSS</a></div>
		<div class="clear"></div>
    </div>
	<?php comments_template(); ?>
	<?php endwhile; ?><?php else : ?>
	<p class="center">非常抱歉，无与之相匹配的信息。</p>
	<?php include (TEMPLATEPATH . "/searchform.php"); ?>
	<?php endif; ?>
</div><!-- #content -->

<?php get_footer(); ?>