<?php get_header(); ?>

<?php get_sidebar(); ?>

<div id="main">
	<div class="post_nav_block_wrapper">
		<ul class="post_nav_block">
			<li><a <?php if ( is_home() && !(isset($_GET['order']))) echo 'class="current_nav"'; ?> href="<?php echo get_settings('home'); ?>">首页</a></li>
			<li><a <?php if ( isset($_GET['order']) && ($_GET['order']=='commented') ) echo 'class="current_nav"'; ?> href="<?php echo get_settings('home'); ?>?order=commented">热门文章</a></li>
			<li><a <?php if ( isset($_GET['order']) && ($_GET['order']=='rand') ) echo 'class="current_nav"'; ?> href="<?php echo get_settings('home'); ?>?order=rand">随便看看</a></li>
		</ul>
		<div id="feed"><a href="<?php bloginfo('rss2_url'); ?>" title="RSS">RSS</a></div>
		<div class="clear"></div>
    </div>

<?php
global $wp_query;

if ( isset($_GET['order']) && ($_GET['order']=='rand') ) 
{
	$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
	$args=array(
		'orderby' => 'rand',
		'paged' => $paged,
	);
	$arms = array_merge(
		$args,
		$wp_query->query
	);
	query_posts($arms);
}
else if ( isset($_GET['order']) && ($_GET['order']=='commented') )
{
	$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
	$args=array(
		'orderby' => 'comment_count',
		'order' => 'DESC',
		'paged' => $paged,
	);
    $arms = array_merge(
		$args,
		$wp_query->query
	);
    query_posts($arms);
}
else{
	$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
	$args=array(
		'orderby' => 'date',
		'order' => 'DESC',
		'paged' => $paged,
	);
    $arms = array_merge(
		$args,
		$wp_query->query
	);
    query_posts($arms);
}?>
	<!-- navigation -->	
	<div class="navigation"><?php pagination($query_string); ?></div>
	<div class="clear"></div>
	<!-- end: navigation -->
	<div id="post_list">
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<div class="post_item">
			<div class="indexdate">
				<div class="postdate">
					<span class="postday"><?php the_time('d') ?></span>
					<span class="postyear"><?php the_time('m') ?>/<?php the_time('y') ?></span>
				</div>
				<div class="clear"></div>
			</div>
			<div class="post_item_body">
				<h3><a href="<?php the_permalink() ?>" class="titlelnk" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
				<p class="post_item_summary">
					<?php if (has_excerpt())
						{ ?> 
							<?php the_excerpt() ?>
						<?php
						}
						else{
							echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 480,"...");
						} 
						?>
				</p>
				<div class="post_item_foot">
					<span class="postdate_icon">&nbsp;<?php echo date("Y-m-d H:i",get_the_time('U')); ?></span>
					<span class="category"><?php the_category(', ') ?></span>
					<span class="article_comment"><?php comments_popup_link('暂无评论', '评论(1)', '评论(%)'); ?></span>
					<?php if(function_exists('the_views')){ print ' <span class="article_view grayline">阅读(<span>'; the_views(); print '</span>)</span>';   } ?>
				</div>
				<div class="clear"></div>
			</div>
		</div>
		<?php endwhile; wp_reset_query(); ?>
		<?php endif; ?>
		<div class="navigation_b"><?php pagination($query_string); ?></div>
		<div class="clear"></div>
	</div>
</div><!-- #main -->

<?php get_footer(); ?>
