<?php get_header(); ?>

<?php get_sidebar(); ?>

<div id="content">
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

	<div id="map">
		<div class="browse">现在位置: &nbsp;&nbsp;
			<a title="返回首页" href="<?php echo get_settings('Home'); ?>/">首页</a>&nbsp;＞&nbsp;<?php the_category(', ') ?>&nbsp;＞&nbsp;正文</div>
		<div id="feed"><a href="<?php bloginfo('rss2_url'); ?>" title="RSS">RSS</a></div>	
	</div>

	<div class="entry_box_s">
		<div class="entry_title"><?php the_title(); ?></div>
		<div class="archive_info">
			<span class="postdate_icon">&nbsp;<?php echo date("Y-m-d H:i",get_the_time('U')); ?></span>
			<span class="category">  <?php the_category(', ') ?></span>
			<span class="article_comment"><?php comments_popup_link('暂无评论', '评论(1)', '评论(%)'); ?></span>
			<?php if(function_exists('the_views')){ print ' <span class="article_view grayline">阅读(<span>'; the_views(); print '</span>)</span>';   } ?>
			<span class="edit"><?php edit_post_link('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;', '  ', '  '); ?></span>
		</div>
		<div class="entry">
			<div id="entry">
				<?php the_content('Read more...'); ?>
				<?php wp_link_pages( array( 'before' => '<p class="pages">' . __( '日志分页:'), 'after' => '</p>' ) ); ?>
				<div class="clear"></div>
			</div>
			<div class="clear"></div>
		</div>
		<!-- end: entry -->
		<div class="archive_tags">
			<span class="content_tag"><?php the_tags('关键字: ', ', ', ''); ?></span>
		</div>
		<div class="authorbio">
			<div class="author_pic">
				<?php echo get_avatar( get_the_author_email(), '78' ); ?>
			</div>
			<div class="author_text">
				<span class="post_author">该日志由 <?php the_author() ?> 于<?php the_time('Y年m月d日') ?>发表在<?php the_category(', ') ?>分类下</span>
				<p class="spostinfo">本文版权归<?php bloginfo('name'); ?>所有，转载引用请完整注明以下信息：<br>
					本文作者：<?php the_author() ?><br>
					本文地址：<a href="<?php the_permalink() ?>" rel="bookmark" title="本文固定链接 <?php the_permalink() ?>"><?php the_title(); ?> | <?php bloginfo('name');?></a><a href="#" onclick="copy_code('<?php the_permalink() ?>'); return false;"></a></span>
				</p>
			</div>
		</div>
		<div class="prevnextblock">
			<?php previous_post_link('【上篇】%link') ?><br/><?php next_post_link('【下篇】%link') ?>
		</div>
		<div class="clear"></div>
	</div>
	<?php comments_template(); ?>
	<?php endwhile; else: ?>
	<?php endif; ?>
</div><!-- #content -->

<?php get_footer(); ?>