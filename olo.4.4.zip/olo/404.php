<?php get_header(); ?>
<div id="oloContainer">
	<div id="oloContent">
		<div class="clear"></div>
		<div class="error-404">
			<p><span class="bigger flickering">404</span></p>
			<p>ERROR</p>
			<p id="info">Move along, there's nothing to do here.</p>
		</div>
	</div><!-- #oloContent-->
</div><!-- #oloContainer-->
<?php get_footer(); ?>