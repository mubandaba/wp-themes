<form method="get" id="searchform" action="<?php bloginfo('home'); ?>/">
<div>
	<input class="search" type="text" value="Type you keyword here" onfocus="if (this.value == 'Type you keyword here') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Type you keyword here';}" name="s" id="s" size="30" /><!--<input class="submit" type="submit" id="searchsubmit" value="" /> -->
</div>
<div id="clear"></div>
</form>