<?php get_header(); ?>
<div id="contents">
	<div class="container">
		<div class="post">
            <div class="pleft">
				<div class="pdate">&nbsp;</div>
				<div class="pmonth">&nbsp;</div>
			</div>
			<div class="pright">
             <h2 class="title">404 Error - Not Found</h2>
			</div>
		</div>
        <div id="clear"></div>
    </div>
	<?php get_sidebar();?>
	<div id="clear"></div>
</div>
<?php get_footer();?>
<div id="clear"></div>
</div>
</body>
</html>