<div id="sidebar" class="sidebar">
<ul class="toplist">
<li>
	<div id="search">
		<?php include(TEMPLATEPATH . '/searchform.php'); ?>
	</div>
</li>
<li>
	<div class="sidebarads">
		<div class="ads1">
			<a href="#"><img src="<?php bloginfo('template_url'); ?>/images/bg_ads.gif" alt="Advertising" /></a>
		</div>
		<div class="ads2">
			<a href="#"><img src="<?php bloginfo('template_url'); ?>/images/bg_ads.gif" alt="Advertising" /></a>
		</div>
		<div id="clear"></div>
	</div>
	<div id="clear"></div>
</li>
<ul id="downlist">
<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar() ) : else : ?>
		<li>
			<h2><?php _e('Categories'); ?></h2>
			<ul>
					<?php wp_list_cats('sort_column=name&hierarchical=0&depth=0'); ?>
			</ul>
		</li>
		<li>
			<h2><?php _e('Meta'); ?></h2>
			<ul>
			<?php wp_register(); ?>
			<li><?php wp_loginout(); ?></li>
			<?php wp_meta(); ?>
			</ul>
		</li>
		<li>
			<h2><?php _e('Archives'); ?></h2>
			<ul>
			<?php wp_get_archives('type=monthly'); ?>
			</ul>
		</li>
<?php endif;?>
</ul>
</div>