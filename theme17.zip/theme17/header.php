<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">

	<title><?php if (is_home () ) { bloginfo('name'); echo ' - ' ; bloginfo('description');}
elseif ( is_category() ) { single_cat_title(); echo ' - ' ; bloginfo('name');}
elseif (is_single() ) { single_post_title(); echo ' - ' ; bloginfo('name');}
elseif (is_page() ) { single_post_title(); echo ' - ' ; bloginfo('name');}
else { wp_title('',true); } ?></title>

	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />	
	<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" /> <!-- leave this for stats please -->

	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
	<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
	<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />

	<?php wp_get_archives('type=monthly&format=link'); ?>
	<?php //comments_popup_script(); // off by default ?>
	<?php wp_head(); ?>
	<script type="text/javascript">
			
	</script>
</head>
<body>
	<div id="wrapper">
		<div id="header">
			<div class="blogname">
				<h1><a href="<?php bloginfo('url'); ?>"><? bloginfo('name'); ?></a></h1>
				<h3><?php bloginfo('description'); ?></h3>
			</div>
			<div class="rssfeed">
				<a href="<?php bloginfo('rss_url'); ?>"><img src="<? bloginfo('template_url'); ?>/images/rssfeed.png" align="absmiddle" /></a>
				<div id="clear"></div>
			</div>	
			<div id="clear"></div>
			<div id="blogposts">
				<div class="recentposts">
					<h2><?php _e('recent posts'); ?></h2>
				<ul>
				<?php
						global $post;
						$recent = get_posts('numberposts=3&orderby=date');
						foreach($recent as $post) : setup_postdata($post);
					?>				
				<li>
					<div class="pdate"><a href="<?php the_permalink(); ?>"><? the_time('j M Y'); ?></a></div>
					<div class="pexcerpt"><a href="<?php the_permalink(); ?>"><?php excerpt('6') ?></a></div>
				</li>	
				<?php endforeach; ?>
				</ul>
				</div>	
				<div class="recentcomments">
					<h2><?php _e('recent comments'); ?></h2>
					<? recent_comments('10'); ?>
				</div>
			</div>	
		</div>
		<div id="clear"></div>