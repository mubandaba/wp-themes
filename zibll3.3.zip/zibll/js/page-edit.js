_body.on("click", '.admin-set-page', function (e) {
    return $('#modal_admin_set').modal('show'),!1;
})
