<?php get_header(); ?>
<section id="content">
<!--[if lte IE 7]>
<div id="ie-warning">
<p>你知道吗？你在用一个很古老很古老很悲剧很难看的浏览器，如果你看到这个提示的话，我希望你能够换个更好的浏览器来访问我的网站。比如：<a href="http://www.maxthon.cn/" target="_blank">傲游浏览器3或更高版本</a>、<a href="http://www.google.cn/intl/zh-CN/chrome/browser/" target="_blank">Google Chrome</a>、<a href="http://www.mozilla.org/en-US/firefox/all/" target="_blank">Mozilla Firefox</a>或者<a href="http://www.opera.com/zh-cn/computer/windows" target="_blank">Opera</a>，这些都是很不错的浏览器。或者你可能在用三鹿灵套装，如果你还是愿意用三鹿灵的话就换上三鹿灵浏览器吧。IE6和IE7，都该淘汰了。</p>
</div>
<![endif]-->
  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
  <?php if ( is_sticky() ) : ?>
      <article id="post-<?php the_ID(); ?>" class="top-post">
      <div class="post-title">
        <h2><span class="top-post-text">[Top]</span><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></h2>
		<span class="post-comment"><?php comments_popup_link(__('No comment'), __('1 comment'), __('% comments')); ?></span>
		<div class="clear"></div>
      </div>
	  </article>
  <?php else : ?>
    <article id="post-<?php the_ID(); ?>" class="post">
      <div class="post-title">
        <h2><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></h2>
		<span class="post-comment"><?php comments_popup_link(__('No comment'), __('1 comment'), __('% comments')); ?></span>
		<div class="clear"></div>
      </div>
      <div class="entry"><?php the_content('Continue reading &rarr;'); ?></div>
	  <div class="post-meta"><?php the_time('Y.m.d'); ?> &#47; <?php the_category(',') ?></div>
    </article>
	<?php endif; ?>
    <?php endwhile;?>
    <?php endif; ?>
    <?php if (  $wp_query->max_num_pages > 1 ) : ?>
       <div class="pagenavi"><?php pagenavi(); ?></div>
    <?php endif; ?>

</section>
<?php get_footer(); ?>