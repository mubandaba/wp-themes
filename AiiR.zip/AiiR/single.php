<?php get_header(); ?>

<section id="content">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<article id="post-<?php the_ID(); ?>" class="post">

<div class="post-title">
<h2><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></h2>
<span class="post-comment"><?php comments_popup_link(__('No comment'), __('1 comment'), __('% comments')); ?></span>
<div class="clear"></div>
</div>

<div class="entry"><?php the_content(''); ?>
<?php wp_link_pages('before=<div id="post-pages">Pages:&#32;&after=</div>&next_or_number=number&link_before=<span class="pp-num">&link_after=</span>'); ?>
</div>

<div class="post-meta"><?php the_time('Y.m.d'); ?> &#47; <?php the_category(',') ?><?php edit_post_link('[Edit this post]', ' &#47; ', ''); ?></div>
<div id="post-navi"><span class="fll"><?php if (get_next_post()) {  echo '上一篇：'; next_post_link('%link'); } else {echo "这是最新一篇";}; ?></span><span class="flr"><?php if (get_previous_post()) {  echo '下一篇：'; previous_post_link('%link'); } else {echo "这是最后一篇";}; ?></span><div class="clear"></div></div>
</article>

<?php endwhile;?>
<?php endif; ?>

<?php comments_template( '', true ); ?>

</section>
<?php get_footer(); ?>
