<?php
//注册头部导航
if ( function_exists('register_nav_menus') ) {
	register_nav_menus(array('primary' => '头部导航栏'));
}

//Comments Ajax文件加载
if (!is_admin()) {
	function zfunc_scripts_method() {
		if (is_singular()) {
			wp_enqueue_script('comments_ajax_js', (get_template_directory_uri()."/comments-ajax.js"), false, '1.3', true);
		}
	}
	add_action('wp_enqueue_scripts', 'zfunc_scripts_method');
}


// 评论回复构架
function weisay_comment($comment, $args, $depth) {
   $GLOBALS['comment'] = $comment;
   global $commentcount;
   if(!$commentcount) {
	   $page = ( !empty($in_comment_loop) ) ? get_query_var('cpage')-1 : get_page_of_comment( $comment->comment_ID, $args )-1;
	   $cpp=get_option('comments_per_page');
	   $commentcount = $cpp * $page;
	}
?>
<li <?php comment_class(); ?> id="comment-<?php comment_ID() ?>">
   <div id="div-comment-<?php comment_ID() ?>" class="comment-body">
      <?php $add_below = 'div-comment'; ?>
		<div class="comment-author vcard"><?php echo get_avatar( $comment, $size = '40'); ?>
			<div class="floor"><?php if(!$parent_id = $comment->comment_parent) {printf('%1$s L', ++$commentcount);} ?><?php if( $depth > 1){printf('B%1$s', $depth-1);} ?></div>
					<strong class="name"><?php comment_author_link() ?></strong>:<span class="useragent"><?php if(function_exists('useragent_output_custom')) useragent_output_custom(); ?></span></div>
		<?php if ( $comment->comment_approved == '0' ) : ?>
			<span style="color:#C00; font-style:inherit">您的评论正在等待审核中。</span>
			<br />			
		<?php endif; ?>
<div class="text">
		<?php comment_text() ?>
</div>
		<div class="clear"></div><span class="datetime"><?php comment_date('Y-m-d') ?> <?php comment_time() ?> </span> <span class="reply"><?php comment_reply_link(array_merge( $args, array('reply_text' => '[回复]', 'add_below' =>$add_below, 'depth' => $depth, 'max_depth' => $args['max_depth']))); ?></span><?php edit_comment_link('编辑','&nbsp;&nbsp;',''); ?>
  </div>
<?php
}
function weisay_end_comment() {
		echo '</li>';
}
//Mini Gavatar Cache by Willin Kan. Modify by zwwooooo 
/*
function my_avatar_admin($avatar) {
     $tmp = strpos($avatar, 'http');
     $g = substr($avatar, $tmp, strpos($avatar, "'", $tmp) - $tmp);
     $tmp = strpos($g, 'avatar/') + 7;
     $f = substr($g, $tmp, strpos($g, "?", $tmp) - $tmp);
     $w = home_url(); // $w = get_bloginfo('url');
     $e = preg_replace('/wordpress\//', '', ABSPATH) .'avatar/'. $f .'.jpg';
     $t = 604800; //设定7天, 单位:秒
     if ( empty($default) ) $default = $w. '/avatar/default.jpg';
     if ( !is_file($e) || (time() - filemtime($e)) > $t ) //当头像不存在或者文件超过7天才更新
         copy(htmlspecialchars_decode($g), $e);
     else
         $avatar = strtr($avatar, array($g => $w.'/avatar/'.$f.'.jpg'));
     if (filesize($e) < 500) copy($default, $e);
     return $avatar;
 }
 add_filter('get_avatar', 'my_avatar_admin');
*/
//自动转义邮箱地址 By Ludou
function security_remove_emails($content) {
    $pattern = '/([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4})/i';
    $fix = preg_replace_callback($pattern, "security_remove_emails_logic", $content);

    return $fix;
}

function security_remove_emails_logic($result) {
    return antispambot($result[1]);
}

add_filter( 'the_content', 'security_remove_emails', 20 );
add_filter( 'comment_text', 'security_remove_emails', 20 );
 
//自定义表情路径
function custom_smilies_src($src, $img){
    return get_option('home') . '/wp-content/themes/AiiR/images/smilies/' . $img;
}
add_filter('smilies_src', 'custom_smilies_src', 10, 2);

// 去掉Category函数里的rel泛滥的HTML5错误
foreach(array(
    'rsd_link',//rel="EditURI"
    'index_rel_link',//rel="index"
    'start_post_rel_link',//rel="start"
    'wlwmanifest_link'//rel="wlwmanifest"
  ) as $xx)
  remove_action('wp_head',$xx);//X掉以上
  //rel="category"或rel="category tag", 这个最巨量
  function the_category_filter($thelist){
    return preg_replace('/rel=".*?"/','rel="tag"',$thelist);
  } 
  add_filter('the_category','the_category_filter');

//* Mini Pagenavi v1.0 by Willin Kan.
function pagenavi( $p = 3 ) {
if ( is_singular() ) return;
global $wp_query, $paged;
$max_page = $wp_query->max_num_pages;
if ( $max_page == 1 ) return;
if ( empty( $paged ) ) $paged = 1;
// echo '<span class="page-numbers">' . $paged . ' / ' . $max_page . ' </span> ';
if ( $paged > 1 ) p_link( $paged - 1, '更新的文章', '<span class="newer-post">&larr; Newer Post</span>' );
if ( $paged > $p + 1 ) p_link( 1, '第一页' );
if ( $paged > $p + 2 ) echo '<span class="page-numbers">...</span>';
for( $i = $paged - $p; $i <= $paged + $p; $i++ ) {
if ( $i > 0 && $i <= $max_page ) $i == $paged ? print "<span class='page-numbers current'>{$i}</span> " : p_link( $i );
}
if ( $paged < $max_page - $p - 1 ) echo '<span class="page-numbers">...</span>';
if ( $paged < $max_page - $p ) p_link( $max_page, '最后一页' );
if ( $paged < $max_page ) p_link( $paged + 1,'较旧的文章', '<span class="older-post">Older Post &rarr;</span>' );
}
function p_link( $i, $title = '', $linktype = '' ) {
if ( $title == '' ) $title = "第 {$i} 页";
if ( $linktype == '' ) { $linktext = $i; } else { $linktext = $linktype; }
echo "<a class='page-numbers' href='", esc_html( get_pagenum_link( $i ) ), "' title='{$title}'>{$linktext}</a> ";
}

/* comment_mail_notify v1.0 by willin kan. (所有回覆都發郵件) */
function comment_mail_notify($comment_id) {
  $comment = get_comment($comment_id);
  $parent_id = $comment->comment_parent ? $comment->comment_parent : '';
  $spam_confirmed = $comment->comment_approved;
  if (($parent_id != '') && ($spam_confirmed != 'spam')) {
    $wp_email = 'no-reply@' . preg_replace('#^www\.#', '', strtolower($_SERVER['SERVER_NAME'])); //e-mail 發出點, no-reply 可改為可用的 e-mail.
    $to = trim(get_comment($parent_id)->comment_author_email);
    $subject = '您在 [' . get_option("blogname") . '] 的留言有了回复';
    $message = '
    <div style="color:#111;border:1px #ccc solid;border-top:3px solid #58B2DC;max-width:600px">
      <div style="border-bottom:1px #ccc solid;padding: 2px 15px;background-color:#EFEFEF;"><p>您好！' . trim(get_comment($parent_id)->comment_author) . '，您在《' . get_the_title($comment->comment_post_ID) . '》的留言有了新的回复</p></div>
	  <div style="color:#111;padding: 2px 15px;">
      <p><strong>您</strong> 的留言:</p>
	  <blockquote style="background:#FFF;border:1px solid #CCC;border-left:3px solid #58B2DC;line-height:21px;margin:4px 0 17px;padding: 8px 6px;">
	  ' . nl2br(get_comment($parent_id)->comment_content) . '
	  </blockquote>
      <p><strong>' . trim($comment->comment_author) . '</strong> 给您的回复:</p>
	  <blockquote style="background:#FFF;border:1px solid #CCC;border-left:3px solid #58B2DC;line-height:21px;margin:4px 0 17px;padding: 8px 6px;">
	  ' . nl2br($comment->comment_content) . '
	  </blockquote>
      <p>想要知道更多详细内容，请点击右边 -> <a href="' . htmlspecialchars(get_comment_link($parent_id)) . '">查看完整的回复内容</a></p>
      <p style="text-align:right"> —— 来自：<a href="' . get_option('home') . '">' . get_option('blogname') . '</a></p>
      <p style="text-align:right">（此邮件由系统自动发出, 请不要回复。)</p>
    </div>
	</div>';
    $from = "From: \"" . get_option('blogname') . "\" <$wp_email>";
    $headers = "$from\nContent-Type: text/html; charset=" . get_option('blog_charset') . "\n";
    wp_mail( $to, $subject, $message, $headers );
    //echo 'mail to ', $to, '<br/> ' , $subject, $message; // for testing
  }
}
add_action('comment_post', 'comment_mail_notify');
// -- END ----------------------------------------

 /* Archives list by zwwooooo | http://zww.me */
 function zww_archives_list() {
     if( !$output = get_option('zww_archives_list') ){
         $the_query = new WP_Query( 'posts_per_page=-1&ignore_sticky_posts=1' ); //update: 加上忽略置顶文章
         $year=0; $mon=0; $i=0; $j=0;
         while ( $the_query->have_posts() ) : $the_query->the_post();
             $year_tmp = get_the_time('Y');
             $mon_tmp = get_the_time('m');
             $y=$year; $m=$mon;
             if ($mon != $mon_tmp && $mon > 0) $output .= '</ul>';
             if ($year != $year_tmp && $year > 0) $output .= '';
             if ($year != $year_tmp) {
                 $year = $year_tmp;
                 $output .= '<h2 class="al_year">'. $year .' 年</h2>'; //输出年份
             }
             if ($mon != $mon_tmp) {
                 $mon = $mon_tmp;
                 $output .= '<p style="font-size:20px"><span class="al_mon">'. $mon .' 月</span></p><ul class="al_post_list">'; //输出月份
             }
             $output .= '<li>'. get_the_time('d日: ') .'<a href="'. get_permalink() .'">'. get_the_title() .'</a> <em>('. get_comments_number('0', '1', '%') .')</em></li>'; //输出文章日期和标题
         endwhile;
         wp_reset_postdata();
         $output .= '</ul>';
         update_option('zww_archives_list', $output);
     }
     echo $output;
 }
 function clear_zal_cache() {
     update_option('zww_archives_list', ''); // 清空 zww_archives_list
 }
 add_action('save_post', 'clear_zal_cache'); // 新发表文章/修改文章时
?>
<?php

add_action('init', 'ajax_comment');
function ajax_comment(){
/**
 * WordPress jQuery-Ajax-Comments v1.3 by Willin Kan.
 * URI: http://kan.willin.org/?p=1271
 * for WP3.5+ | modified version URI: http://mufeng.me/wordpress3-5-willin-ajax-comment.html
 */
	if($_POST['action'] == 'ajax_comment' && 'POST' == $_SERVER['REQUEST_METHOD']){
		global $wpdb;
		nocache_headers();
		$comment_post_ID = isset($_POST['comment_post_ID']) ? (int) $_POST['comment_post_ID'] : 0;

		$post = get_post($comment_post_ID);

		if ( empty($post->comment_status) ) {
			do_action('comment_id_not_found', $comment_post_ID);
			ajax_comment_err(__('Invalid comment status.')); // 將 exit 改為錯誤提示
		}

		// get_post_status() will get the parent status for attachments.
		$status = get_post_status($post);

		$status_obj = get_post_status_object($status);

		if ( !comments_open($comment_post_ID) ) {
			do_action('comment_closed', $comment_post_ID);
			ajax_comment_err(__('Sorry, comments are closed for this item.')); // 將 wp_die 改為錯誤提示
		} elseif ( 'trash' == $status ) {
			do_action('comment_on_trash', $comment_post_ID);
			ajax_comment_err(__('Invalid comment status.')); // 將 exit 改為錯誤提示
		} elseif ( !$status_obj->public && !$status_obj->private ) {
			do_action('comment_on_draft', $comment_post_ID);
			ajax_comment_err(__('Invalid comment status.')); // 將 exit 改為錯誤提示
		} elseif ( post_password_required($comment_post_ID) ) {
			do_action('comment_on_password_protected', $comment_post_ID);
			ajax_comment_err(__('Password Protected')); // 將 exit 改為錯誤提示
		} else {
			do_action('pre_comment_on_post', $comment_post_ID);
		}

		$comment_author       = ( isset($_POST['author']) )  ? trim(strip_tags($_POST['author'])) : null;
		$comment_author_email = ( isset($_POST['email']) )   ? trim($_POST['email']) : null;
		$comment_author_url   = ( isset($_POST['url']) )     ? trim($_POST['url']) : null;
		$comment_content      = ( isset($_POST['comment']) ) ? trim($_POST['comment']) : null;
		$edit_id              = ( isset($_POST['edit_id']) ) ? $_POST['edit_id'] : null; // 提取 edit_id

		// If the user is logged in
		$user = wp_get_current_user();
		if ( $user->exists() ) {
			if ( empty( $user->display_name ) )
				$user->display_name=$user->user_login;
			$comment_author       = $wpdb->escape($user->display_name);
			$comment_author_email = $wpdb->escape($user->user_email);
			$comment_author_url   = $wpdb->escape($user->user_url);
			if ( current_user_can('unfiltered_html') ) {
				if ( wp_create_nonce('unfiltered-html-comment_' . $comment_post_ID) != $_POST['_wp_unfiltered_html_comment'] ) {
					kses_remove_filters(); // start with a clean slate
					kses_init_filters(); // set up the filters
				}
			}
		} else {
			if ( get_option('comment_registration') || 'private' == $status )
				ajax_comment_err(__('Sorry, you must be logged in to post a comment.')); // 將 wp_die 改為錯誤提示
		}

		$comment_type = '';

		if ( get_option('require_name_email') && !$user->exists() ) {
			if ( 6 > strlen($comment_author_email) || '' == $comment_author )
				ajax_comment_err( __('Error: please fill the required fields (name, email).') ); // 將 wp_die 改為錯誤提示
			elseif ( !is_email($comment_author_email))
				ajax_comment_err( __('Error: please enter a valid email address.') ); // 將 wp_die 改為錯誤提示
		}

		if ( '' == $comment_content )
			ajax_comment_err( __('Error: please type a comment.') ); // 將 wp_die 改為錯誤提示


		// 增加: 檢查重覆評論功能
		$dupe = "SELECT comment_ID FROM $wpdb->comments WHERE comment_post_ID = '$comment_post_ID' AND ( comment_author = '$comment_author' ";
		if ( $comment_author_email ) $dupe .= "OR comment_author_email = '$comment_author_email' ";
		$dupe .= ") AND comment_content = '$comment_content' LIMIT 1";
		if ( $wpdb->get_var($dupe) ) {
			ajax_comment_err(__('Duplicate comment detected; it looks as though you&#8217;ve already said that!'));
		}

		// 增加: 檢查評論太快功能
		if ( $lasttime = $wpdb->get_var( $wpdb->prepare("SELECT comment_date_gmt FROM $wpdb->comments WHERE comment_author = %s ORDER BY comment_date DESC LIMIT 1", $comment_author) ) ) { 
		$time_lastcomment = mysql2date('U', $lasttime, false);
		$time_newcomment  = mysql2date('U', current_time('mysql', 1), false);
		$flood_die = apply_filters('comment_flood_filter', false, $time_lastcomment, $time_newcomment);
		if ( $flood_die ) {
			ajax_comment_err(__('You are posting comments too quickly.  Slow down.'));
			}
		}

		$comment_parent = isset($_POST['comment_parent']) ? absint($_POST['comment_parent']) : 0;

		$commentdata = compact('comment_post_ID', 'comment_author', 'comment_author_email', 'comment_author_url', 'comment_content', 'comment_type', 'comment_parent', 'user_ID');

		// 增加: 檢查評論是否正被編輯, 更新或新建評論
		if ( $edit_id ){
			$comment_id = $commentdata['comment_ID'] = $edit_id;
			wp_update_comment( $commentdata );
		} else {
			$comment_id = wp_new_comment( $commentdata );
		}

		$comment = get_comment($comment_id);
		do_action('set_comment_cookies', $comment, $user);

		$comment_depth = 1;   //为评论的 class 属性准备的
		$tmp_c = $comment;
		while($tmp_c->comment_parent != 0){
			$comment_depth++;
			$tmp_c = get_comment($tmp_c->comment_parent);
		}
		
		//此处非常必要，无此处下面的评论无法输出 by mufeng
		$GLOBALS['comment'] = $comment;
		
		//以下是評論式樣, 不含 "回覆". 要用你模板的式樣 copy 覆蓋.
?>
	<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
		<div id="comment-<?php comment_ID(); ?>" class="comment-body">
		<div class="comment-author vcard">
			<?php echo get_avatar( $comment, $size = '40'); ?>
			<?php printf( __( '<cite class="fn">%s</cite>'), get_comment_author_link() ); ?>:
		</div>
		<?php if ( $comment->comment_approved == '0' ) : ?>
			<span style="color:#C00; font-style:inherit">您的评论正在等待审核中...</span>
			<br />
			
		<?php endif; ?>
		<div class="comment-body"><?php comment_text(); ?></div>
<span class="datetime"><?php comment_date('Y-m-d') ?> <?php comment_time() ?></span>
	</div>

		<?php die(); //以上是評論式樣, 不含 "回覆". 要用你模板的式樣 copy 覆蓋.
	}else{return;}
}

// 增加: 錯誤提示功能
function ajax_comment_err($a) { 
    header('HTTP/1.0 500 Internal Server Error');
	header('Content-Type: text/plain;charset=UTF-8');
    echo $a;
    exit;
}

//短代码
add_shortcode('check', 'check_sc');
function check_sc($atts, $content=null, $code="") {
    $return = '<div class="check_sc shortcode">';
    $return .= $content;
    $return .= '</div>';
    return $return;
}
add_shortcode('warn', 'warning_sc');
function warning_sc($atts, $content=null, $code="") {
    $return = '<div class="warning_sc shortcode">';
    $return .= $content;
    $return .= '</div>';
    return $return;
}
add_shortcode('light', 'light_sc');
function light_sc($atts, $content=null, $code="") {
    $return = '<div class="light_sc shortcode">';
    $return .= $content;
    $return .= '</div>';
    return $return;
}
add_shortcode('note', 'note_sc');
function note_sc($atts, $content=null, $code="") {
    $return = '<div class="note_sc shortcode">';
    $return .= $content;
    $return .= '</div>';
    return $return;
}
add_shortcode('star', 'star_sc');
function star_sc($atts, $content=null, $code="") {
    $return = '<div class="star_sc shortcode">';
    $return .= $content;
    $return .= '</div>';
    return $return;
}