<footer>
<p class="footer-msg flr"><a href="http://wordpress.org" target="_blank" title="本博客由WordPress构建">WordPress</a> Theme: <a href="http://aiir.in" target="_blank" title="本主题由Eiko拼凑而成">AiiR</a></p>
</footer>
<div id="back-to-top"><a href="#top">Top &spades;</a></div>
</section>
<?php wp_footer(); ?>
<script src="<?php bloginfo('template_directory'); ?>/js/main.js"></script>

</body>
</html>