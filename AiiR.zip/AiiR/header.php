<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">

<title><?php global $page, $paged;wp_title( '|', true, 'right' );bloginfo( 'name' );$site_description = get_bloginfo( 'description', 'display' );if ( $site_description && ( is_home() || is_front_page() ) ) echo " | $site_description";if ( $paged >= 2 || $page >= 2 ) echo ' | ' . sprintf( __( '第 %s 页'), max( $paged, $page ) );?></title>
<?php if (is_home()){ 
    $description = "Just a blog.";
    $keywords = "Wordpress,blog,life";
} elseif (is_single()){    
    $description =  substr(strip_tags($post->post_content),0,220);
    $keywords = "Wordpress,blog,life";        
    $tags = wp_get_post_tags($post->ID);
    foreach ($tags as $tag ) {
        $keywords = $keywords . $tag->name . ", ";
    }
}
?>
<meta name="description" content="<?=$description?>" />
<meta name="keywords" content="<?=$keywords?>" />
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js'></script>
<!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

<!--[if lt IE 9]>
    <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
<![endif]-->
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="alternate" type="application/rss+xml" title="RSS" href="<?php bloginfo('rss2_url'); ?>"/>

<?php wp_head(); ?>

</head>
<body>
<section id="main">

<form method="get" id="searchform" class="searchform" action="/">
<input type="text" placeholder="Search here" name="s" id="s" size="15"/>
</form>

<header id="header-top">
<h1 id="logo"><a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('description'); ?>"><?php bloginfo('name'); ?></a></h1>
<p><?php bloginfo('description'); ?></p>


<nav class="header-nav">
<?php wp_nav_menu( array('menu' => 'header-menu', 'menu_class' => 'menu' )); ?>
</nav>
<div class="clear"></div>
</header>