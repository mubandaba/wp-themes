<?php get_header(); ?>
<section id="content">
<div class="archive-meta"><h2>
		<?php if ( is_tag() ) : ?>
			<?php printf( __( '标签: %s' ), '<a>' . single_tag_title( '', false ) . '</a>' ); ?>
		<?php elseif ( is_category() ) : ?>
			<?php printf( __( '分类: %s' ), '<a>' . single_cat_title( '', false ) . '</a>' ); ?>
		<?php else : ?>
			<?php _e( 'Blog Archives' ); ?>
		<?php endif; ?>
		</h2></div>
  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <article id="post-<?php the_ID(); ?>" class="post">
      <div class="post-title">
        <h2><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></h2>
		<span class="post-comment"><?php comments_popup_link(__('No comment'), __('1 comment'), __('% comments')); ?></span>
		<div class="clear"></div>
      </div>
      <div class="entry"><?php the_content('Continue reading &rarr;'); ?></div>
	  <div class="post-meta"><?php the_time('Y.m.d'); ?> &#47; <?php the_category(',') ?></div>
    </article>
    <?php endwhile;?>
	<?php else : ?>
	<h2 class="search-404">Nothing Found</h2>
    <?php endif; ?>
    <?php if (  $wp_query->max_num_pages > 1 ) : ?>
       <div class="pagenavi"><?php pagenavi(); ?></div>
    <?php endif; ?>
</section>
<?php get_footer(); ?>