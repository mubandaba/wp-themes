<?php get_header(); ?>
<section id="content">
    <article class="post">
        <div class="entry">
          <p style="text-align: center;font-size:42px;text-transform: uppercase;font-family:'Century Gothic', 'Times New Roman', Times, serif;">404 NOT FOUND</p>
        </div>
    </article>
</section>
<?php get_footer(); ?>