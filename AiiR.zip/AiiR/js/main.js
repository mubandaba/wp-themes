//评论带@ 依然可用，但评论Ajax翻页后会失效，正常翻页有效
/*
jQuery(document).ready(function($){
$('.reply').click(function() {
    var atid = '"#' + $(this).parent().parent().attr("id") + '"';
    var atname = $(this).parent().find('.name').text();
$("#comment").attr("value","<a href=" + atid + ">@" + atname + "：" + " </a>").focus();
});
$('.cancel_comment_reply a').click(function() {
$("#comment").attr("value",'');
});
})
*/

//评论带@ from 大发的主题
jQuery.fn.ajaxReply = function(){$(this).click(//@ + username
	function(){
		var atid = '"#' + $(this).parent().parent().attr("id") + '"';
    var atname = $(this).parent().find('.name').text();
$("#comment").attr("value","<a href=" + atid + ">@" + atname + "：" + " </a>").focus();
});
$('.cancel_comment_reply a').click(function() {
$("#comment").attr("value",'');
	});
};
$(".reply").ajaxReply();
//评论Ajax翻页 来源同上
jQuery(document).ready(function($) {
	$body = (window.opera) ? (document.compatMode == "CSS1Compat" ? $('html') : $('body')) : $('html,body');//commentnav ajax
	$('.commentnav a').live('click',function(e) {
		e.preventDefault();
		$.ajax({
			type: "GET",
			url: $(this).attr('href'),
			beforeSend: function() {
				$('.commentnav').remove();
				$('.commentlist').remove();
				$('#loading-comments').slideDown();
			},
			dataType: "html",
			success: function(out) {
				result = $(out).find('.commentlist');
				nextlink = $(out).find('.commentnav');
				$('#loading-comments').slideUp(550);
				$('#loading-comments').after(result.fadeIn(800));
				$('.commentlist').after(nextlink);
				$(".reply").ajaxReply();//绑定@事件
				$(".text p a").bigfaCom();
				$(".commentsgood").bigfaReply();
			}
		});
	});	
});
//指向@评论链接时悬浮显示内容
//可参考：http://fatesinger.com/archives/1158.html
jQuery.fn.bigfaCom = function(){
var id = /^#comment-/;
var at = /^@/;
$(this).each(function() {
	if ($(this).attr('href').match(id) && $(this).text().match(at)) {
		$(this).addClass('atreply');
	}
});
$('.atreply').hover(function() {
	$($(this).attr('href')).find('div:first').clone().hide().insertAfter("body").attr('id', '').addClass('tip').fadeIn(200);
},
function() {
	$('.tip').fadeOut(400,
	function() {
		$(this).remove();
	});
});
$('.atreply').mousemove(function(e) {
	$('.tip').css({
		left: (e.pageX + 18),
		top: (e.pageY + 18)
	})
});
};
$(".text p a").bigfaCom();
//回到顶部
jQuery(document).ready(function(){
	$(function () {
	$("#back-to-top").click(function(){
		$('body,html').animate({scrollTop: '0px'},1000);
	});
	});
});

//很蛋疼的首页Ajax翻页
/*

预留自行开启，想玩的就自行把结构改成这样：（除了index.php貌似archive.php还有search.php都可以改）
<section id="content">
<div class="content-inside">加这一句
--------略--------
</div>还有这一句
</section>
然后把下面的JS的注释删了就可以玩了

//来源：http://fatesinger.com/archives/938.html
*/
/*
$(function(){

					$body = (window.opera) ? (document.compatMode == 'CSS1Compat' ? $('html') : $('body')) : $('html,body');
					$('.pagenavi a').live('click', function(e){
						e.preventDefault();
						$.ajax({
							type: 'GET',
							url: $(this).attr('href'),
							beforeSend: function(){
								$('.content-inside').slideUp(400, function(){$('.content-inside').remove();});

							},
							dataType: 'html',
							success: function(out){
								result = $(out).find('.content-inside').hide();

								$('#content').append(result.slideDown(400));
								$body.animate({scrollTop:$('.content-inside').offset().top}, 900);
							}
						});
					});
				});
*/