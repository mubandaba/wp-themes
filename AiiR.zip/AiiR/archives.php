<?php 
/*
Template Name: 文章归档
*/ 
?>
<?php get_header(); ?>
<section id="content">
<article class="post" style="border-bottom:none;">
<div class="post-title">
<h2><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></h2>
<div class="clear"></div>
</div>
<div class="entry">
<?php zww_archives_list(); ?>
</div>
</article>
</section>
<?php get_footer(); ?>