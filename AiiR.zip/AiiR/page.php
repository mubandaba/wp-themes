<?php get_header(); ?>
<section id="content">
  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <article id="post-<?php the_ID(); ?>" class="post">
        <div class="entry"><?php the_content(''); ?></div>
		<div class="post-meta"><?php the_time('Y.m.d'); ?><?php edit_post_link('[编辑本文]', ' &#47; ', ''); ?></div>
    </article>
    <?php endwhile;?>
    <?php endif; ?>
    <?php comments_template( '', true ); ?>
</section>
<?php get_footer(); ?>