<?php get_header(); 
 
get_template_part( 'index/pic' );

get_template_part( 'index/news' );
get_template_part( 'index/works_1' );


get_footer(); ?>