<?php
$x = 'D9810B607744318D59A4C98C6B3B68A3';
				$x = '9993E2CB95B7B24B1A8232931F936BCB';
				$x = '</nav>';
				Bing_footer_copyrights();

								$x = '84122DA5B51C58EF54D7045814144010';
			$x = '</div>';
						$x = '</section>';
					wp_footer();
					$x = '61D50B494A725EAD0767741368B186AC';
					?>