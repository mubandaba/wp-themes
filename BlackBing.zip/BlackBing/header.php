<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <?php Bing_include('seo'); ?>
	<!--[if IE 6]>
		<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/png.js"></script>
		<script>DD_belatedPNG.fix('a,.logo,img');</script>
	<![endif]-->
	<!--[if lt IE 9]>
		<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/html5.js"></script>
	<![endif]-->
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<section id="wrapper" class="clearfix">
	<header id="header" class="clearfix">
		<div class="top">
			<div class="top-box">
				<h1 class="logo">
					<a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?> | <?php bloginfo('description'); ?>">
						<img src="<?php if(panel('logo')!='') panel('logo',1);else echo get_bloginfo('template_directory').'/images/logo.png'; ?>" alt="logo" class="logo-img">
					</a>
				</h1>
				<nav class="nav" id="navright">
					<?php wp_nav_menu(array('theme_location'=>'header_right_menu','container'=>false,'items_wrap'=>'<ul id="rightmenu">%3$s</ul>')); ?>
				</nav>
			</div>
		</div>
		<div class="bottom">
			<nav class="nav" id="navtop" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
				<?php wp_nav_menu(array('theme_location'=>'header_menu','container'=>false,'items_wrap'=>'<ul id="topmenu">%3$s</ul>')); ?>
			</nav>
			<?php get_search_form(); ?>
		</div>
	</header>
	<section id="main" class="clearfix">
		<div class="container clearfix">
			<div class="containermain">
				<div class="containermain-box">