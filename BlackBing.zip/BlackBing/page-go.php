<?php
//Template Name:链接跳转
?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<title><?php _e('链接跳转','Bing'); ?> | <?php bloginfo('name'); ?></title>
<style>
html,body,*{margin:0;padding:0;outline:0;border:0;vertical-align:baseline;word-wrap:break-word;}
body{text-align:center;}
.screenshot img{max-width:200px;height:auto;width:90%;margin-top:10px;margin-bottom:10px;}
</style>
</head>
<body>
<div class="loading">
	<div class="screenshot">
		<a href="<?php echo $_GET['url']; ?>">
			<img src="http://0907.org/screenshot/screenshot_it.php?site=<?php echo $_GET['url']; ?>&x=1000&y=1324&format=PNG">
		</a>
	</div>
	<div class="name">
		<h3><?php _e('您的访问目标已经超出本站范围，本站将无法继续保证您的安全。','Bing'); ?></h3>
		<p><a href="javascript:history.back();"><?php _e('我点错了，点此返回上一页','Bing'); ?></a></p>
		<p><a href="<?php echo $_GET['url']; ?>"><?php _e('我仍要访问','Bing'); ?></a></p>
	</div>
</div>
</body>
</html>