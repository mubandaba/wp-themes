<?php  
/*
	*Bing - 主题小工具：搜索
	*From：http://www.bgbk.org
	*一般主题用户不需要修改
*/
add_action('widgets_init', create_function('', 'return register_widget("search");'));

class search extends WP_Widget {
	function search() {
		global $prename;
		$this->WP_Widget('search', $prename.'Bing - '.__('搜索'), array( 'description' => __('侧边栏全新搜索框！') ));
	}
	function widget($args, $instance) {
		extract($args, EXTR_SKIP);
		//小工具内容开始
		echo $before_widget;
			get_search_form();
		echo $after_widget;
		//小工具内容结束
	}
}

//本页设置结束
?>