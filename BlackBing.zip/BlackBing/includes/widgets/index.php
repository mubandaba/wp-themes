<?php
/*
    *Bing - 小工具配置
    *Form:www.bgbk.org
    *一般主题用户不需要修改
*/

//小工具定义
function Bing_widgets_init(){
    $before_widget = '<div class="widget %2$s clearfix">';
    $after_widget  = '</div>';
    $before_title  = '<h3 class="hd">';
    $after_title   = '</h3>';
    if (function_exists('register_sidebar')){
        //默认侧边
        register_sidebar(array(
            'name'          => __('默认侧边栏'),
            'id'            => 'widget_default',
            'description'   => __('没有被单独定义的侧边栏都会调用这里的内容。'),
            'before_widget' => $before_widget,
            'after_widget'  => $after_widget,
            'before_title'  => $before_title,
            'after_title'   => $after_title,
        ));

        //文章页边栏
        register_sidebar(array(
            'name'          => __('文章页侧边栏'),
            'id'            => 'widget_post',
            'description'   => __('文章和页面会调用这里。'),
            'before_widget' => $before_widget,
            'after_widget'  => $after_widget,
            'before_title'  => $before_title,
            'after_title'   => $after_title,
        ));

    }
}
add_action('widgets_init','Bing_widgets_init');

//注销小工具
function Bing_calendar_widget() {
    unregister_widget('WP_Widget_Search');//搜索
    unregister_widget('WP_Widget_Tag_Cloud');//标签云
    unregister_widget('WP_Widget_Recent_Comments');//最新评论
    unregister_widget('WP_Widget_Recent_Posts');//近期文章
}
add_action('widgets_init','Bing_calendar_widget');

//本页设置结束
?>