<?php  
/*
	*Bing - 主题小工具：热门标签
	*From：http://www.bgbk.org
	*一般主题用户不需要修改
*/
add_action('widgets_init', create_function('', 'return register_widget("tags");'));

class tags extends WP_Widget {
	function tags() {
		global $prename;
		$this->WP_Widget('tags', $prename.'Bing - '.__('热门标签'), array( 'description' => __('呈现固定条数的彩色标签！') ));
	}
	function widget($args, $instance) {
		extract($args, EXTR_SKIP);
		//小工具内容开始
		echo $before_widget;
		$title     = apply_filters('widget_name', $instance['title']);
		$limit     = $instance['limit'];
		$bigsize   = $instance['bigsize'];
		$smallsize = $instance['smallsize'];

		echo $before_title.$title.$after_title; 

		wp_tag_cloud('smallest='.$smallsize.'&largest='.$bigsize.'&unit=px&number='.$limit);

		echo $after_widget;
		//小工具内容结束
	}
	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title']     = strip_tags($new_instance['title']);
		$instance['limit']     = strip_tags($new_instance['limit']);
		$instance['bigsize']   = strip_tags($new_instance['bigsize']);
		$instance['smallsize'] = strip_tags($new_instance['smallsize']);
		return $instance;
	}
	function form($instance) {
		$instance = wp_parse_args( (array) $instance, array( 
			'title'     => '热门标签',
			'limit'     => '50',
			'bigsize'   => '18',
			'smallsize' => '12'
			) 
		);
		$limit     = strip_tags($instance['title']);
		$limit     = strip_tags($instance['limit']);
		$bigsize   = strip_tags($instance['bigsize']);
		$smallsize = strip_tags($instance['smallsize']);

?>
		<p>
			<label>
				标题：
				<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $instance['title']; ?>" />
			</label>
		</p>
		<p>
			<label>
				显示数目：
				<input class="widefat" id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="number" value="<?php echo $instance['limit']; ?>" />
			</label>
		</p>
		<p>
			<label>
				最大字号（像素）：
				<input class="widefat" id="<?php echo $this->get_field_id('bigsize'); ?>" name="<?php echo $this->get_field_name('bigsize'); ?>" type="number" value="<?php echo $instance['bigsize']; ?>" />
			</label>
		</p>
		<p>
			<label>
				最小字号（像素）：
				<input class="widefat" id="<?php echo $this->get_field_id('smallsize'); ?>" name="<?php echo $this->get_field_name('smallsize'); ?>" type="number" value="<?php echo $instance['smallsize']; ?>" />
			</label>
		</p>


<?php
	}
}

//彩色标签
function Bing_colorCloud($text){
	$text = preg_replace_callback('|<a (.+?)>|i','Bing_colorCloudCallback',$text);
	return $text;
}
function Bing_colorCloudCallback($matches){
	$text = $matches[1];
	$color = dechex(rand(0,16777215));
	$pattern = '/style=(\'|\”)(.*)(\'|\”)/i';
	$text = preg_replace($pattern, "style=\"color:#{$color};$2;\"", $text);
	return "<a $text>";
}
add_filter('wp_tag_cloud', 'Bing_colorCloud',1);

//本页设置结束
?>