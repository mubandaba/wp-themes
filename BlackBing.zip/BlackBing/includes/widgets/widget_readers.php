<?php  
/*
	*Bing - 主题小工具：读者排行
	*From：http://www.bgbk.org
	*一般主题用户不需要修改
*/
add_action('widgets_init', create_function('', 'return register_widget("readers");'));

class readers extends WP_Widget {
	function readers() {
		global $prename;
		$this->WP_Widget('readers', $prename.'Bing - '.__('读者排行'), array( 'description' => __('显示一段时间内评论最多的读者！') ));
	}
	function widget($args, $instance) {
		extract($args, EXTR_SKIP);
		//小工具内容开始
		echo $before_widget;
		$title = apply_filters('widget_name', $instance['title']);
		$limit = $instance['limit'];
		$timer = $instance['timer'];
		echo $before_title.$title.$after_title; 

		echo '<ul>';
		Bing_readers(panel('bloggers_nickname'),$timer,$limit);
		echo '</ul>';

		echo $after_widget;
		//小工具内容结束
	}
	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['limit'] = strip_tags($new_instance['limit']);
		$instance['timer'] = strip_tags($new_instance['timer']);
		return $instance;
	}
	function form($instance) {
		$instance = wp_parse_args( (array) $instance, array( 
			'title' => '读者排行',
			'limit' => '12',
			'timer' => '30' 
			) 
		);
		$title = strip_tags($instance['title']);
		$limit = strip_tags($instance['limit']);
		$timer = strip_tags($instance['timer']);

?>
		<p>
			<label>
				标题：
				<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $instance['title']; ?>" />
			</label>
		</p>
		<p>
			<label>
				显示数目：
				<input class="widefat" id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="number" value="<?php echo $instance['limit']; ?>" />
			</label>
		</p>
		<p>
			<label>
				几天内：
				<input class="widefat" id="<?php echo $this->get_field_id('timer'); ?>" name="<?php echo $this->get_field_name('timer'); ?>" type="number" value="<?php echo $instance['timer']; ?>" />
			</label>
		</p>

<?php
	}
}

function Bing_readers($out,$timer,$limit){
	global $wpdb;    
	$counts = $wpdb->get_results("SELECT COUNT(comment_author) AS cnt, comment_author,comment_author_url,comment_author_email FROM {$wpdb->prefix}comments WHERE comment_date > date_sub( NOW(), INTERVAL $timer MONTH ) AND comment_approved = '1' AND comment_author_email AND comment_author_url != '".$out."' AND comment_type = ''  AND user_id = '0' GROUP BY comment_author ORDER BY cnt DESC LIMIT $limit");      
	foreach ($counts as $count) {
	$c_url = $count->comment_author_url;
	if ($c_url == '') $c_url = 'javascript:;';
	$mostactive .= '<li><a rel="nofollow" href="'. $c_url . '" title="' . $count->comment_author .' 留下 '. $count->cnt . ' 个脚印" target="_blank">' . get_avatar($count->comment_author_email, 90, '', $count->comment_author . ' 留下 ' . $count->cnt . ' 个脚印') . '</a></li>';
	}
	echo $mostactive;
}

//本页设置结束
?>