<?php  
/*
	*Bing - 主题小工具：推荐文章
	*From：http://www.bgbk.org
	*一般主题用户不需要修改
*/
add_action('widgets_init', create_function('', 'return register_widget("postlist");'));

class postlist extends WP_Widget {
	function postlist() {
		global $prename;
		$this->WP_Widget('postlist', $prename.'Bing - '.__('推荐文章'), array( 'description' => __('以各种方式呈现博客文章（最新文章 + 热门文章 + 随机文章）！') ));
	}
	function widget($args, $instance) {
		extract($args, EXTR_SKIP);
		echo $before_widget;
		$title        = apply_filters('widget_name', $instance['title']);
		$limit        = $instance['limit'];
		$cat          = $instance['cat'];
		$showpic      = $instance['showpic'];
		$orderby      = $instance['orderby'];
		$commentcount = $instance['commentcount'];

		//小工具内容开始
		echo $before_title.$title.$after_title;

		if($showpic=='text') $className = 'postlist_txt'; 
		if($showpic=='pic') $className = 'postlist_pic';
		if($showpic=='pictext') $className = 'postlist_pictxt';
		echo '<ul class="'.$className.'">';
		echo Bing_posts_list( $orderby,$commentcount,$limit,$showpic,$cat );
		echo '</ul>';

		echo $after_widget;
		//小工具内容结束
	}
	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title']        = strip_tags($new_instance['title']);
		$instance['limit']        = strip_tags($new_instance['limit']);
		$instance['cat']          = strip_tags($new_instance['cat']);
		$instance['showpic']      = strip_tags($new_instance['showpic']);
		$instance['orderby']      = strip_tags($new_instance['orderby']);
		$instance['commentcount'] = strip_tags($new_instance['commentcount']);
		return $instance;
	}
	function form($instance) {
		$instance = wp_parse_args( (array) $instance, array( 
			'title'        => '推荐文章',
			'limit'        => '6',
			'cat'          => '',
			'showpic'      => '',
			'orderby'      => 'date',
			'commentcount' => '' 
			) 
		);
		$title        = strip_tags($instance['title']);
		$limit        = strip_tags($instance['limit']);
		$cat          = strip_tags($instance['cat']);
		$showpic      = strip_tags($instance['showpic']);
		$orderby      = strip_tags($instance['orderby']);
		$commentcount = strip_tags($instance['commentcount']);
?>
		<p>
			<label>
				标题：
				<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $instance['title']; ?>" />
			</label>
		</p>

		<p>
			<label>
				排序：
				<select class="widefat" id="<?php echo $this->get_field_id('orderby'); ?>" name="<?php echo $this->get_field_name('orderby'); ?>" style="width:100%;">
					<option value="comment_count" <?php selected('comment_count', $instance['orderby']); ?>>按评论数</option>
					<option value="date" <?php selected('date', $instance['orderby']); ?>>按发布时间</option>
					<option value="rand" <?php selected('rand', $instance['orderby']); ?>>随机显示</option>
				</select>
			</label>
		</p>
		<p>
			<label>
				显示方式：
				<select class="widefat" id="<?php echo $this->get_field_id('showpic'); ?>" name="<?php echo $this->get_field_name('showpic'); ?>" style="width:100%;">
					<option value="text" <?php selected('text', $instance['showpic']); ?>>文章标题</option>
					<option value="pic" <?php selected('pic', $instance['showpic']); ?>>文章缩略图</option>
					<option value="pictext" <?php selected('pictext', $instance['showpic']); ?>>缩略图+标题</option>
				</select>
			</label>
		</p>
		<p>
			<label>
				分类限制：
				<a style="font-weight:bold;color:#f60;text-decoration:none;" href="javascript:;" title="格式：1,2 &nbsp;表限制ID为1,2分类的文章&#13;格式：-1,-2 &nbsp;表排除分类ID为1,2的文章&#13;也可直接写1或者-1；注意逗号须是英文的">？</a>
				<input class="widefat" id="<?php echo $this->get_field_id('cat'); ?>" name="<?php echo $this->get_field_name('cat'); ?>" type="text" value="<?php echo attribute_escape($cat); ?>" size="24" />
			</label>
		</p>
		<p>
			<label>
				显示数目：
				<input class="widefat" id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="number" value="<?php echo attribute_escape($limit); ?>" size="24" />
			</label>
		</p>
		<p>
			<label>
				<input style="vertical-align:-3px;margin-right:4px;" class="checkbox" type="checkbox" <?php checked( $instance['commentcount'], 'on' ); ?> id="<?php echo $this->get_field_id('commentcount'); ?>" name="<?php echo $this->get_field_name('commentcount'); ?>">显示文章评论数
			</label>
		</p>
<?php
	}
}

//本页设置结束
?>