<?php  
/*
	*Bing - 主题小工具：站点统计
	*From：http://www.bgbk.org
	*一般主题用户不需要修改
*/
add_action('widgets_init', create_function('', 'return register_widget("statistics");'));

class statistics extends WP_Widget {
	function statistics() {
		global $prename;
		$this->WP_Widget('statistics', $prename.'Bing - '.__('站点统计'), array( 'description' => __('统计网站的各种数据！') ));
	}
	function widget($args, $instance) {
		extract($args, EXTR_SKIP);
		//小工具内容开始
		echo $before_widget;
		$title   = apply_filters('widget_name', $instance['title']);
		$single  = $instance['single'];
		$page    = $instance['page'];
		$archive = $instance['archive'];
		$tags    = $instance['tags'];
		$comment = $instance['comment'];
		$day     = $instance['day'];
		$inquiry = $instance['inquiry'];
		$date    = $instance['date'];

		echo $before_title.$title.$after_title; 

		echo '<ul>';

		$count_posts = wp_count_posts();
		if($single=='on')  echo '<li>文章：'.$published_posts = $count_posts->publish.'篇';
		$count_pages = wp_count_posts('page');
		if($page=='on')    echo '<li>页面：'.$page_posts = $count_pages->publish.'个';
		if($archive=='on') echo '<li>分类：'.$count_categories = wp_count_terms('category').'个';
		if($tags=='on')    echo '<li>标签：'.$count_tags = wp_count_terms('post_tag').'个';
		$count_comments = get_comment_count();
		if($comment=='on') echo '<li>评论：'.$count_comments['approved'].'条';
		if($day=='on')     echo '<li>运行：'.floor((time()-strtotime(panel('found_blog_date')))/86400).'天';
		if($inquiry=='on') echo '<li>查询：'.get_num_queries().'次';
		if($date=='on')    echo '<li>建站：'.panel('found_blog_date');

		echo '</ul>';

		echo $after_widget;
		//小工具内容结束
	}
	function update($new_instance, $old_instance) {
		$instance            = $old_instance;
		$instance['title']   = strip_tags($new_instance['title']);
		$instance['single']  = strip_tags($new_instance['single']);
		$instance['page']    = strip_tags($new_instance['page']);
		$instance['archive'] = strip_tags($new_instance['archive']);
		$instance['tags']    = strip_tags($new_instance['tags']);
		$instance['comment'] = strip_tags($new_instance['comment']);
		$instance['day']     = strip_tags($new_instance['day']);
		$instance['inquiry'] = strip_tags($new_instance['inquiry']);
		$instance['date']    = strip_tags($new_instance['date']);
		return $instance;
	}
	function form($instance) {
		$instance = wp_parse_args( (array) $instance, array( 
			'title'   => '站点统计',
			'single'  => 'on',
			'page'    => 'on',
			'archive' => 'on',
			'tags'    => 'on',
			'comment' => 'on',
			'day'     => 'on',
			'inquiry' => 'on',
			'date' => 'on',
			) 
		);
		$title    = strip_tags($instance['title']);
		$single   = strip_tags($instance['single']);
		$page     = strip_tags($instance['page']);
		$archive  = strip_tags($instance['archive']);
		$tags     = strip_tags($instance['tags']);
		$comment  = strip_tags($instance['comment']);
		$day      = strip_tags($instance['day']);
		$inquiry  = strip_tags($instance['inquiry']);
		$date     = strip_tags($instance['date']);

?>
		<p>
			<label>
				标题：
				<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $instance['title']; ?>" />
			</label>
		</p>
		<p>
			<label>
				<input style="vertical-align:-3px;margin-right:4px;" class="checkbox" type="checkbox" <?php checked( $instance['single'], 'on' ); ?> id="<?php echo $this->get_field_id('single'); ?>" name="<?php echo $this->get_field_name('single'); ?>">显示【文章篇数】
			</label>
		</p>
		<p>
			<label>
				<input style="vertical-align:-3px;margin-right:4px;" class="checkbox" type="checkbox" <?php checked( $instance['page'], 'on' ); ?> id="<?php echo $this->get_field_id('page'); ?>" name="<?php echo $this->get_field_name('page'); ?>">显示【页面个数】
			</label>
		</p>
		<p>
			<label>
				<input style="vertical-align:-3px;margin-right:4px;" class="checkbox" type="checkbox" <?php checked( $instance['archive'], 'on' ); ?> id="<?php echo $this->get_field_id('archive'); ?>" name="<?php echo $this->get_field_name('archive'); ?>">显示【分类个数】
			</label>
		</p>
		<p>
			<label>
				<input style="vertical-align:-3px;margin-right:4px;" class="checkbox" type="checkbox" <?php checked( $instance['tags'], 'on' ); ?> id="<?php echo $this->get_field_id('tags'); ?>" name="<?php echo $this->get_field_name('tags'); ?>">显示【标签个数】
			</label>
		</p>
		<p>
			<label>
				<input style="vertical-align:-3px;margin-right:4px;" class="checkbox" type="checkbox" <?php checked( $instance['comment'], 'on' ); ?> id="<?php echo $this->get_field_id('comment'); ?>" name="<?php echo $this->get_field_name('comment'); ?>">显示【评论条数】
			</label>
		</p>
		<p>
			<label>
				<input style="vertical-align:-3px;margin-right:4px;" class="checkbox" type="checkbox" <?php checked( $instance['day'], 'on' ); ?> id="<?php echo $this->get_field_id('day'); ?>" name="<?php echo $this->get_field_name('day'); ?>">显示【运行天数】
			</label>
		</p>
		<p>
			<label>
				<input style="vertical-align:-3px;margin-right:4px;" class="checkbox" type="checkbox" <?php checked( $instance['inquiry'], 'on' ); ?> id="<?php echo $this->get_field_id('inquiry'); ?>" name="<?php echo $this->get_field_name('inquiry'); ?>">显示【查询次数】
			</label>
		</p>
		<p>
			<label>
				<input style="vertical-align:-3px;margin-right:4px;" class="checkbox" type="checkbox" <?php checked( $instance['date'], 'on' ); ?> id="<?php echo $this->get_field_id('date'); ?>" name="<?php echo $this->get_field_name('date'); ?>">显示【建站时间】
			</label>
		</p>
<?php
	}
}

//本页设置结束
?>