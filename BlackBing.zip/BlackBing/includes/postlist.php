<?php
//博文列表样式
function Bing_blog_list(){
?>
	<li<?php if(!panel('Bing_thumbnail')) echo' style="height:auto;"'; ?>>
		<?php if(panel('Bing_thumbnail')) Bing_thumbnail(160,125); ?>
		<h3 class="title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
		<p class="summary"><?php echo mb_strimwidth(strip_tags(get_the_content()),0,280,"..."); ?></p>
		<?php Bing_meta(false); ?>
	</li>
<?php
}

//博文列表
function Bing_main_blog_list(){
	echo '<section class="box box-blog-main clearfix">';
		if(have_posts()):
			echo '<ul class="postlist">';
			while(have_posts()):the_post();
				Bing_blog_list();
			endwhile;
			echo '</ul>';
		else:
			Bing_no_post();
		endif;
	echo '</section>';
	Bing_par_pagenavi();
}

?>