<title><?php
	$delimiter = '|';
	global $page, $paged;
	wp_title($delimiter,true,'right');
	bloginfo( 'name' );
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) )
		echo " ".$delimiter." $site_description";
	if ( $paged >= 2 || $page >= 2 )
		echo' '.$delimiter.' '.sprintf(__('第 %s 页'),max($paged,$page));
	?></title>
<?php if (is_home() || is_front_page())
	{
	$description = panel('Bing_description');
	$keywords = panel('Bing_keywords');
	}
	elseif (is_category())
	{
	$description = strip_tags(trim(category_description()));
	$keywords = single_cat_title('', false);
	}
	elseif (is_tag())
	{
	$description = sprintf( __( '与标签 %s 相关联的文章列表'), single_tag_title('', false));
    $keywords = single_tag_title('', false);
	}
	elseif (is_single())
	{
     if ($post->post_excerpt) {$description = $post->post_excerpt;} 
	 else {$description = mb_strimwidth(strip_tags($post->post_content),0,260,"");}
    $keywords = "";
    $tags = wp_get_post_tags($post->ID);
    foreach ($tags as $tag ) {$keywords = $keywords . $tag->name . ", ";}
	}
	elseif (is_page())
	{
	$keywords = get_post_meta($post->ID, "keywords", true);
	$description = get_post_meta($post->ID, "description", true);
	}
	?>
	<meta name="keywords" content="<?php echo $keywords ?>" />
	<meta name="description" content="<?php echo $description?>" />
