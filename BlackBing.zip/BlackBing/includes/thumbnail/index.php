<?php
/*
	*Bing - 缩略图
	*From：http://www.bgbk.org
	*一般主题用户不需要修改
*/

//添加特色缩略图支持
if(function_exists('add_theme_support')) add_theme_support('post-thumbnails');

//输出缩略图地址
function Bing_post_thumbnail_src(){
    global $post;
	if($values = get_post_custom_values("thumb")){
		$values = get_post_custom_values("thumb");
		$post_thumbnail_src = $values [0];
	}elseif(has_post_thumbnail()){
        $thumbnail_src = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
		$post_thumbnail_src = $thumbnail_src[0];
    }else{
		$post_thumbnail_src = '';
		ob_start();
		ob_end_clean();
		$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
		$post_thumbnail_src = $matches [1] [0];
		if(empty($post_thumbnail_src)){
			$random = mt_rand(1, 10);
			if(panel('Bing_no_img')=='random') echo get_bloginfo('template_url').'/includes/thumbnail/img/'.$random.'.png';
			else echo get_bloginfo('template_url').'/includes/thumbnail/img/default_thumb.png';
		}
	};
	echo $post_thumbnail_src;
}

//定义缩略图
function Bing_thumbnail($picw,$pich=''){
	if($pich=='') $pich = $picw;
?>
	<a href="<?php the_permalink() ?>" class="pic-a" rel="bookmark" title="<?php the_title(); ?>">
		<img src="<?php if(panel('Bing_timthumb')): ?><?php bloginfo('template_directory'); ?>/includes/thumbnail/timthumb.php?src=<?php endif; ?><?php echo Bing_post_thumbnail_src() ?><?php if(panel('Bing_timthumb')): ?>&h=<?php echo $pich ?>&w=<?php echo $picw ?>&q=<?php panel('timthumb_q',1); ?>&zc=<?php if(panel('Bing_timthumb_class')=='cut') echo '1';else echo '0';endif; ?>" class="pic" width="<?php echo $picw; ?>" height="<?php echo $pich; ?>" alt="<?php the_title(); ?>" />
	</a>
<?php
}

//本页设置结束
?>