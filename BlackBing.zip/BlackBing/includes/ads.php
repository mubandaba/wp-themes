<?php
//输出广告
function Bing_echo_ads($name){
	if(panel('ads_'.$name)):
		if(panel('ads_'.$name.'_code')!='') echo htmlspecialchars_decode(panel('ads_'.$name.'_code'));
		else{
			if(panel('ads_'.$name.'_url')!='') echo '<a href="'.panel('ads_'.$name.'_url').'" class="adscode"';
				if(panel('ads_'.$name.'_url')!=''&&panel('ads_'.$name.'_tab')) echo ' target="_blank"';
			if(panel('ads_'.$name.'_url')!='') echo ' rel="nofollow" title="'.panel('ads_'.$name.'_alt').'">';
				echo '<img src="'.panel('ads_'.$name.'_img').'" />';
			if(panel('ads_'.$name.'_url')!='') echo '</a>';
		}
	endif;
}

?>