<?php
//mate
function Bing_meta($cms=true){
	echo '<p class="postmeta">';

		if(!$cms):
		echo '<span class="auth">';
			the_author_posts_link();
		echo '</span>';
		endif;

		echo '<span class="time">';
			if(!$cms) the_time('Y'.__('年','Bing').'n'.__('月','Bing').'j'.__('日','Bing'));
			else the_time('Y/n/j');
		echo '</span>';

		echo '<span class="eye">';
			if(function_exists('the_views')) the_views();
			else Bing_post_views('','');
		echo '</span>';

		echo '<span class="comm">';
			echo '<a href="'.get_permalink().'#comments" title="'.sprintf(__('《%s》上的文章','Bing'),get_the_title()).'">';
				if(!$cms) comments_popup_link(__('抢沙发','Bing'), '2 '.__('条评论','Bing'), '% '.__('条评论','Bing'), '', __('评论未开启','Bing'));
				else comments_popup_link(__('无','Bing'), '2', '%', '', __('关','Bing'));
			echo '</a>';
		echo '</span>';	

		if(!$cms):
			the_tags('<span class="tag">', '   ', '</span>');
		endif;

	echo '</p>';
	Bing_wrap();
}

?>