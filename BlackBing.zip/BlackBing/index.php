<?php
get_header();
if(panel('breadcrumbs')&&!is_home()) Bing_breadcrumbs();
$before = '<div class="archive-header">';
$after = '</div>';
if(is_author()){
	echo $before;
		global $author;
		$userdata = get_userdata($author);
		echo '<h2 class="title">'.$userdata->display_name.'</h2>';
		if(get_the_author_meta('description')!='') echo '<p class="description">'.get_the_author_meta('description').'</p>';
	echo $after;
}elseif(is_tag()){
	echo $before;
		echo '<h2 class="title">'.single_cat_title('',false).'</h2>';
	echo $after;
}elseif(is_date()){
	echo $before;
		if(is_day()) echo '<h2 class="title">'.get_the_time('Y').__('年','Bing').get_the_time('m').__('月','Bing').get_the_time('d').__('日','Bing').'</h2>';
		if(is_month()) echo '<h2 class="title">'.get_the_time('Y').__('年','Bing').get_the_time('m').__('月','Bing').'</h2>';
		if(is_year()) echo '<h2 class="title">'.get_the_time('Y').__('年','Bing').'</h2>';
	echo $after;
}elseif(is_search()){
	echo $before;
		echo '<h2 class="title">'.get_search_query().'</h2>';
		echo '<p class="description">'.sprintf( __( '关于 “%s” 的搜索结果' , 'Bing' ) , get_search_query() ).'</p>';
	echo $after;
}elseif(!is_home()){
	echo $before;
		$category_id = get_query_var('cat');
		echo '<h2 class="title">'.single_cat_title('',false).'</h2>';
		if(category_description()!='') echo '<p class="description">'.category_description().'</p>';
	echo $after;
}
Bing_main_blog_list();
get_sidebar();
get_footer();
?>