<?php
/*
  *Bing - function - 评论系统
  *Form:www.bgbk.org
  *一般主题用户不需要修改
*/

//评论回复
function weisay_comment($comment, $args, $depth) {
   $GLOBALS['comment'] = $comment;
global $commentcount,$wpdb, $post;
     if(!$commentcount) { //初始化楼层计数器
          $comments = $wpdb->get_results("SELECT * FROM $wpdb->comments WHERE comment_post_ID = $post->ID AND comment_type = '' AND comment_approved = '1' AND !comment_parent");
          $cnt = count($comments);//获取主评论总数量
          $page = get_query_var('cpage');//获取当前评论列表页码
          $cpp=get_option('comments_per_page');//获取每页评论显示数量
         if (ceil($cnt / $cpp) == 1 || ($page > 1 && $page  == ceil($cnt / $cpp))) {
             $commentcount = $cnt + 1;//如果评论只有1页或者是最后一页，初始值为主评论总数
         } else {
             $commentcount = $cpp * $page + 1;
         }
     }
?>
<li <?php comment_class(); ?> id="comment-<?php comment_ID() ?>">
   <div id="div-comment-<?php comment_ID() ?>" class="comment-body">
      <?php $add_below = 'div-comment'; ?>
    <div class="comment-author vcard">
      <img src="<?php echo Bing_avatar_url($comment->comment_author_email); ?>" alt class="avatar" />
      <strong><?php comment_author_link();if(user_can($comment->user_id,1)&&panel('comment_admin')) echo '<a title="官方人员" class="vip"></a>';if(panel('comment_vip')) Bing_author_vip($comment->comment_author_email);edit_comment_link('[编辑]','',''); ?>：</strong><p class="datetime"><?php comment_date('Y-m-d') ?> <?php comment_time();if(panel('comment_author_class')) get_author_class($comment->comment_author_email,$comment->user_id); ?></p>
      <div class="floor">
            <?php
              if(!$parent_id = $comment->comment_parent){
              switch ($commentcount){
              default:printf('#%1$s', --$commentcount);
              }
           }
           ?>
      </div>
    </div>
    <?php if ( $comment->comment_approved == '0' ) : ?>
      <span style="color:#C00;font-style:inherit"><?php _e('您的评论正在等待审核中...'); ?></span>
      <br />      
    <?php endif; ?>
    <?php comment_text(); ?>
    <div class="clear"></div>
    <span class="reply"><?php comment_reply_link(array_merge( $args, array('reply_text' => '回复TA', 'add_below' =>$add_below, 'depth' => $depth, 'max_depth' => $args['max_depth']))); ?></span>
  </div>
<?php
}
function weisay_end_comment() {
    echo '</li>';
}

//更改表情路径
function Bing_smilies_src($img_src, $img, $siteurl){
  return get_bloginfo('template_directory').'/images/smilies/'.$img;
}
add_filter('smilies_src','Bing_smilies_src',1,10); 

//评论作者链接新窗口打开  
function Bing_comment_author_link() {
  $url = get_comment_author_url( $comment_ID );
  if(panel('comment_about_go')) $url = '/go?url='.base64_encode(get_comment_author_url($comment_ID));
  $author = get_comment_author( $comment_ID );
  if ( empty( $url ) || 'http://' == $url )
    return $author;
  else
    return '<a href="'.$url.'" rel="external nofollow" target="_blank" class="url">'.$author.'</a>';
}
add_filter('get_comment_author_link', 'Bing_comment_author_link');

//获取访客VIP样式
function get_author_class($comment_author_email,$user_id){
    global $wpdb;
    $author_count = count($wpdb->get_results(
    "SELECT comment_ID as author_count FROM $wpdb->comments WHERE comment_author_email = '$comment_author_email' "));
    $adminEmail = get_option('admin_email');if($comment_author_email ==$adminEmail) return;
    if($author_count>=5 && $author_count<10)
    echo '<a class="vip1" title="初级达人"></a>';
    else if($author_count>=10 && $author_count<50)
    echo '<a class="vip2" title="中级达人"></a>';
    else if($author_count>=50 && $author_count<200)
    echo '<a class="vip3" title="资深精英"></a>';
    else if($author_count>=200 && $author_count<500)
    echo '<a class="vip4" title="发烧友"></a>';
    else if($author_count>=500 &&$author_count<750)
    echo '<a class="vip5" title="博客元老"></a>';
    else if($author_count>=750 && $author_count<1000)
    echo '<a class="vip6" title="堪比博主的敬业精神"></a>';
    else if($author_count>=1000)
    echo '<a class="vip7" title="神一样的人物 V1000+"></a>';
}

//获取认证用户
function Bing_author_vip($email){
$links=explode("\n",panel('comment_vip_user'));
if(in_array($email,$links))
    echo '<a class="vp" title="认证用户"></a>';
}

//本页设置结束
?>