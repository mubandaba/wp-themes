<?php
/*
  *Bing - function - qrcode
  *Form:www.bgbk.org
  *一般主题用户不需要修改
*/

//二维码缓存
function Bing_qr($url,$path,$qrpic){
	set_time_limit (10);
	$destination_folder = $path?$path.'/':''; 
	$localname = $destination_folder .$qrpic;     
	$file = fopen ($url, "rb");
	if($file){
	  $newf = fopen ($localname, "wb");
		if($newf)     
			while(!feof($file)){     
				fwrite( $newf, fread($file, 1024 * 2 ), 1024 * 2 );
	    	}     
		}     
	if($file){     
		fclose($file);
	}     
	if($newf){     
		fclose($newf);    
	}
}

//生成二维码地址
function Bing_echo_qr($imgsize = 150,$echo = 1){
	if(is_single() || is_page()) $imgname = get_the_id();
	elseif (is_home() || is_front_page())  $imgname = 'home';
	elseif(is_category()) $imgname = 'cat-'.get_query_var('cat');
	elseif(is_tag()) $imgname = 'tag-'.get_query_var('tag_id');
	if(!is_home()) $permalink = get_permalink();
	else $permalink = get_option('home');
	if(panel('Bing_qr')){
		$localqr =  ABSPATH .'qrcode/'.$imgname.'.jpg';
		if(!file_exists($localqr)){
			Bing_qr("http://chart.googleapis.com/chart?cht=qr&chs=".$imgsize."x".$imgsize."&choe=UTF-8&chld=L|0&chl=".$permalink ,"qrcode", $imgname.".jpg");
	    }
		$main = get_home_url('').'/qrcode/'.$imgname.'.jpg';
  	}
  	else $main = "http://chart.googleapis.com/chart?cht=qr&chs=".$imgsize."x".$imgsize."&choe=UTF-8&chld=L|0&chl=".$permalink;
  	if($echo) echo $main;
  	else return $main;
}

//输出二维码
function Bing_echo_qrcode($imgsize = 150){
?>
	<img src="<?php Bing_echo_qr($imgsize); ?>" class="qrcode pic" width="<?php echo $imgsize; ?>" height="<?php echo $imgsize; ?>" alt="qrcode" />
<?php
}

//本页设置结束
?>