<?php
/*
  *Bing - function - avatar
  *Form:www.bgbk.org
  *一般主题用户不需要修改
*/

//头像缓存
function Bing_avatar($avatar) {
  $tmp = strpos($avatar, 'http');
  $g = substr($avatar, $tmp, strpos($avatar, "'", $tmp) - $tmp);
  $tmp = strpos($g, 'avatar/') + 7;
  $f = substr($g, $tmp, strpos($g, "?", $tmp) - $tmp);
  $w = get_bloginfo('wpurl');
  $e = ABSPATH .'avatar/'. $f .'.png';
  $t = panel('Bing_avatar_day')*24*60*60; 
  if ( !is_file($e) || (time() - filemtime($e)) > $t ) 
    copy(htmlspecialchars_decode($g), $e);
  else  
    $avatar = strtr($avatar, array($g => $w.'/avatar/'.$f.'.png'));
  if ( filesize($e) < 500 ) 
    copy(get_bloginfo('template_directory').'/images/default.png', $e);
  return $avatar;
}
if(panel('Bing_avatar')) add_filter('get_avatar','Bing_avatar');

//输出头像地址
function Bing_avatar_url($mail){ 
  $p = get_bloginfo('template_directory').'/images/default.png';
  if($mail=='') return $p;
  preg_match("/src='(.*?)'/i", get_avatar( $mail,$size,$p ), $matches);
  return $matches[1];
}

//本页设置结束

?>