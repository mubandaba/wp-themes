<?php
/*
	*Bing - function - nav
	*Form:www.bgbk.org
	*一般主题用户不需要修改
*/

//建立菜单
if ( function_exists('register_nav_menus') ) {
register_nav_menus( array(
	'header_menu'      => __('顶部菜单'),
	'header_right_menu' => __('顶部右边小菜单'),
	'footer_menu'      => __('页脚菜单'),
) );
}

//移除菜单的多余CSS选择器
function Bingo_nav_class_id($var) {
	return is_array($var) ? array_intersect($var, array('current-menu-item','current-post-ancestor','current-menu-ancestor','current-menu-parent')) : '';
}
add_filter('nav_menu_css_class', 'Bingo_nav_class_id', 100, 1);
add_filter('nav_menu_item_id', 'Bingo_nav_class_id', 100, 1);
add_filter('page_css_class', 'Bingo_nav_class_id', 100, 1);

//本页设置结束
?>