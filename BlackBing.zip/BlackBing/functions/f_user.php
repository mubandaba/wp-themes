<?php
/*
	*Bing - function - user
	*Form:www.bgbk.org
	*如果需要自定义函数请在本文件的 //本页设置结束 前添加，以免直接在 functions.php 添加，导致升级主题被覆盖。
*/






//本页设置结束
?>