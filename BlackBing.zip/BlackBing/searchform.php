<div class="search">
	<form method="get" class="search-form" action="<?php echo esc_url(home_url( '/' )); ?>" >
		<?php $search = __('点击搜索...','Bing');if(is_search()&&$_GET['s']!='') $search = $_GET['s']; ?>
		<input class="search-text" name="s" type="text" value="<?php echo $search; ?>" onfocus="if (this.value == '<?php echo $search; ?>') {this.value = '';}" onblur="if (this.value == '') {this.value = '<?php echo $search; ?>';}" x-webkit-speech="">
		<input class="search-submit" type="submit" value="搜索">
	</form>
</div>