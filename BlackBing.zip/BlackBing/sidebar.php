	</div>
</div>
<aside id="sidebar" class="clearfix">
	<?php
	//重置主循环
	wp_reset_query();
	//输出
	if(is_singular()){
		if(function_exists('dynamic_sidebar')&&dynamic_sidebar('widget_post')):else:
			echo '<div class="widget-no">'.sprintf(__('请在 “后台 - 外观 - 小工具” 设置小工具区：%s','Bing'),'文章页侧边栏').'</div>';
		endif;
	}else{
		if(function_exists('dynamic_sidebar')&&dynamic_sidebar('widget_default')):else:
			echo '<div class="widget-no">'.sprintf(__('请在 “后台 - 外观 - 小工具” 设置小工具区：%s','Bing'),'首页侧边栏').'</div>';
		endif;
	}
	?>
</aside>