<?php
/*
	*Bing - custom
	*Form:www.bgbk.org
	*一般主题用户不需要修改
*/

//wrap
function Bing_wrap(){
	echo "\n";
}

//panel hedaer_code
function Bing_panel_hedaer_code(){
	//Style
	echo '<style>';
	Bing_wrap();
    	do_action('Bing_hook_style');
    echo '</style>';
    Bing_wrap();

	//自定义页脚代码
	if(panel('hedaer_code')!=''):
		echo htmlspecialchars_decode(panel('hedaer_code'));
		Bing_wrap();
	endif;
}
add_action('wp_head','Bing_panel_hedaer_code',1);

//panel footer_code
function Bing_panel_footer_code(){
	//自定义页脚代码
	if(panel('footer_code')!=''):
		echo htmlspecialchars_decode(panel('footer_code'));
		Bing_wrap();
	endif;
}
add_action('wp_footer','Bing_panel_footer_code',1);

//clear
function Bing_clear(){
	echo '<div class="clear"></div>';
	Bing_wrap();
}

//not post
function Bing_no_post(){
	echo '<div class="no-post">';
		_e('这里好像什么东西都没有，你可以尝试利用本站的搜索功能找到你需要的内容：','Bing');
		get_search_form();
	echo '</div>';
	Bing_clear();
}

//JS CSS
function Bing_init_js_css(){
	wp_register_script('google','http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.js');
	wp_register_script('sina','http://lib.sinaapp.com/js/jquery/1.8.3/jquery.min.js');
	wp_register_script('default',get_template_directory_uri().'/js/jquery.min.js');
	wp_register_script('theme',get_template_directory_uri().'/js/theme.js');
	wp_deregister_script('jquery');  
	if(panel('Bing_jquery_url')=='google') wp_enqueue_script('google');
	elseif(panel('Bing_jquery_url')=='sina') wp_enqueue_script('sina');
	else wp_enqueue_script('default');
	wp_enqueue_style('default');
	//wp_enqueue_script('theme');
	wp_register_style('default',get_template_directory_uri().'/style.css');
	wp_enqueue_style('default');
}
add_action('wp_enqueue_scripts','Bing_init_js_css');

//include
function Bing_include($name = null){
	if($name!=null) include(TEMPLATEPATH.'/includes/'.$name.'.php');
}

//Panel
include(TEMPLATEPATH.'/panel/mpanel-ui.php');
include(TEMPLATEPATH.'/panel/mpanel-functions.php');
include(TEMPLATEPATH.'/panel/mpanel-default.php');

//Include
include(TEMPLATEPATH.'/includes/thumbnail/index.php');
include(TEMPLATEPATH.'/includes/postlist.php');
include(TEMPLATEPATH.'/includes/meta.php');
include(TEMPLATEPATH.'/includes/ads.php');

//Function
include(TEMPLATEPATH.'/functions/f_avatar.php');
include(TEMPLATEPATH.'/functions/f_comments.php');
include(TEMPLATEPATH.'/functions/f_nav.php');
include(TEMPLATEPATH.'/functions/f_pagenav.php');
include(TEMPLATEPATH.'/functions/f_posts.php');
include(TEMPLATEPATH.'/functions/f_visitors.php');
include(TEMPLATEPATH.'/functions/f_firstchar.php');
include(TEMPLATEPATH.'/functions/f_panel.php');
include(TEMPLATEPATH.'/functions/f_user.php');
include(TEMPLATEPATH.'/functions/f_qrcode.php');
include(TEMPLATEPATH.'/functions/f_page.php');
include(TEMPLATEPATH.'/functions/f_breadcrumbs.php');

//Widgets
include(TEMPLATEPATH.'/includes/widgets/index.php');
include(TEMPLATEPATH.'/includes/widgets/widget_postlist.php');
include(TEMPLATEPATH.'/includes/widgets/widget_statistics.php');
include(TEMPLATEPATH.'/includes/widgets/widget_search.php');
include(TEMPLATEPATH.'/includes/widgets/widget_newcomments.php');
include(TEMPLATEPATH.'/includes/widgets/widget_tags.php');
include(TEMPLATEPATH.'/includes/widgets/widget_readers.php');

//本页设置结束
?>