<?php
/*
  *Bing - panel - ui
  *Form:www.bgbk.org
  *一般主题用户不需要修改
*/

function panel_options(){ 

	$categories_obj = get_categories('hide_empty=0');
	$categories = array();
	foreach ($categories_obj as $pn_cat) {
		$categories[$pn_cat->cat_ID] = $pn_cat->cat_name;
	}
	
	$sliders = array();
	$custom_slider = new WP_Query( array( 'post_type' => 'Bing_slider', 'posts_per_page' => -1 ) );
	while ( $custom_slider->have_posts() ) {
		$custom_slider->the_post();
		$sliders[get_the_ID()] = get_the_title();
	}
	
	
$save='
	<div class="mpanel-submit">
		<input type="hidden" name="action" value="test_theme_data_save" />
        <input type="hidden" name="security" value="'. wp_create_nonce("test-theme-data").'" />
		<input name="save" class="mpanel-save" type="submit" value="'.__('保存设置','Bing').'" />    
	</div>'; 
?>
		
		
<div id="save-alert"></div>

<div class="mo-panel">

	<div class="mo-panel-tabs">
		<div class="logo"></div>
		<ul>
			<li class="Bing-tabs general"><a href="#tab1"><span></span><?php _e('基本设置','Bing'); ?></a></li>
			<li class="Bing-tabs header"><a href="#tab9"><span></span><?php _e('头部设置','Bing'); ?></a></li>
			<li class="Bing-tabs article"><a href="#tab6"><span></span><?php _e('文章设置','Bing'); ?></a></li>
			<li class="Bing-tabs footer"><a href="#tab7"><span></span><?php _e('页脚设置','Bing'); ?></a></li>
			<li class="Bing-tabs styling"><a href="#tab13"><span></span><?php _e('样式设置','Bing'); ?></a></li>
			<li class="Bing-tabs Social"><a href="#tab4"><span></span><?php _e('社交网络','Bing'); ?></a></li>
			<li class="Bing-tabs advanced"><a href="#tab10"><span></span><?php _e('高级功能','Bing'); ?></a></li>
		</ul>
		<div class="clear"></div>
	</div> <!-- .mo-panel-tabs -->
	
	
	<div class="mo-panel-content">
	<form action="/" name="Bing_form" id="Bing_form">

	
		<div id="tab1" class="tabs-wrap">
			<h2><?php _e('基本设置'); ?></h2> <?php echo $save ?>

			<div class="tiepanel-item">
				<h3><?php _e('缩略图'); ?></h3>
				<?php
					Bing_options(
						array(	"name" => __('显示缩略图'),
								"id" => "Bing_thumbnail",
								"help"=>__('缩略图获取方式：文章特色图形 > 文章第一张图片 > 随机（唯一）图片'),
								"type" => "checkbox")); 
				?>
				<div id="Bing_thumbnail_on">
				<?php
					Bing_options(
						array( 	"name" => __('当文章没有图片时'),
								"id" => "Bing_no_img",
								"type" => "radio",
								"options" => array( "random"=>__('随机图片') ,
													"one"=>__('唯一图片') )));

					Bing_options(
						array(	"name" => 'Timthumb '.__('裁剪缩略图'),
								"id" => "Bing_timthumb",
								"help"=> __('需要主机支持 GD 库，并把 “主题目录/includes/thumbnail/cache” 文件夹赋予权限 775 或者 777'),
								"type" => "checkbox")); 
				?>
				<?php
					Bing_options(
						array( 	"name" => 'Timthumb '.__('裁剪方式'),
								"id" => "Bing_timthumb_class",
								"type" => "radio",
								"options" => array( "cut"=>__('按比例缩放后裁剪（推荐）') ,
													"google"=>__('直接强制压缩后裁剪') )));
					Bing_options(
						array(	"name" => 'Timthumb '.__('缩略图质量'),
								"id" => "timthumb_q",
								"type" => "slider",
								"unit" => "%",
								"help" => __('裁剪图片的质量，越大质量越高'),
								"max" => 100,
								"min" => 1 ));
				?>
				</div>
			</div>

			<div class="tiepanel-item">
				<h3><?php _e('面包屑导航'); ?></h3>
				<?php
					Bing_options(
						array(	"name" => __('显示面包屑导航'),
								"id" => "breadcrumbs",
								"type" => "checkbox"));

					Bing_options(
						array(	"name" => __('面包屑分隔符'),
								"id" => "breadcrumbs_delimiter",
								"type" => "short-text"));
				?>
			</div>

			<div class="tiepanel-item">
				<h3>Favicon</h3>
				<?php
					Bing_options(
						array(	"name" => __('自定义 Favicon 图标地址'),
								"id" => "favicon",
								"type" => "text"));
				?>
			</div>

			<div class="tiepanel-item">
				<h3><?php _e('头部代码'); ?></h3>
				<div class="option-item">
					<small><?php _e('添加一些代码，会被添加到 &lt;head&gt; 标签里，可以添加一些 CSS 和 JS。'); ?></small>
					<textarea id="header_code" name="Bing_options[header_code]" style="width:100%" rows="7"><?php echo htmlspecialchars_decode(panel('header_code'));  ?></textarea>				
				</div>
				<?php
					Bing_options(
						array( 	"name" => 'jQuery '.__('引用方式'),
								"id" => "Bing_jquery_url",
								"type" => "radio",
								"options" => array( "home"=>__('调用本地') ,
													"sina"=>__('新浪外链（推荐）'),
													"google"=>__('Google 外链') )));
				?>
			</div>
			
			<div class="tiepanel-item">
				<h3><?php _e('底部代码'); ?></h3>
				<div class="option-item">
					<small><?php _e('添加一些代码，会被添加到网页底部，可以引入一些 JS，提高加载速度。'); ?></small>

					<textarea id="footer_code" name="Bing_options[footer_code]" style="width:100%" rows="7"><?php echo htmlspecialchars_decode(panel('footer_code'));  ?></textarea>				
				</div>
			</div>	
			
		</div>
		
		<div id="tab9" class="tabs-wrap">
			<h2><?php _e('头部设置'); ?></h2> <?php echo $save ?>
			
			<div class="tiepanel-item">
				<h3>Logo</h3>				
				<?php
					Bing_options(
						array(	"name" => __('Logo 地址'),
								"id" => "Logo",
								"help" => _('可以直接填写地址；如果留空，则默认调用 主题目录/images/logo.png'),
								"type" => "text"));
				?>

			</div>
			

			<div class="tiepanel-item">
				<h3><?php _e('移除头部无用信息'); ?></h3>
				<?php
					Bing_options(
						array(	"name" => 'WordPress '.__('版本'),
								"id" => "Bing_wp_generator",
								"type" => "checkbox"));	

					Bing_options(
						array(	"name" => __('离线编辑器接口'),
								"id" => "Bing_wlwmanifest_link",
								"type" => "checkbox"));	

					Bing_options(
						array(	"name" => __('前后文、第一篇文章、主页meta信息'),
								"id" => "Bing_index_rel_link",
								"type" => "checkbox"));	

					Bing_options(
						array(	"name" => 'Feed '.__('地址'),
								"id" => "Bing_feed_links",
								"type" => "checkbox"));	
				?>		
			</div>
			
			<div class="tiepanel-item">
				<h3>SEO：首页关键词（KeyWords）</h3>
				<div class="option-item">
					<textarea id="Bing_keywords" name="Bing_options[Bing_keywords]" style="width:100%" rows="4"><?php echo panel('Bing_keywords'); ?></textarea>				
				</div>
			</div>
			
			<div class="tiepanel-item">
				<h3>SEO：首页描述（Description）</h3>
				<div class="option-item">
					<textarea id="Bing_description" name="Bing_options[Bing_description]" style="width:100%" rows="4"><?php echo panel('Bing_description'); ?></textarea>				
				</div>
			</div>
		</div> <!-- Header Settings -->
		
		<div id="tab4" class="tabs-wrap">
			<h2><?php _e('社交网络'); ?></h2> <?php echo $save ?>
			<div class="tiepanel-item">
				<h3><?php _e('必填信息'); ?></h3>
							
				<?php
					Bing_options(
						array(	"name" => __('博主昵称'),
								"id" => "bloggers_nickname",
								"help" => __('例如：斌果'),
								"type" => "text"));
								
					Bing_options(
						array(	"name" => __('建站日期'),
								"id" => "found_blog_date",
								"help" => __('例如：“20121001”表示2012年10月11日'),
								"type" => "text"));
				?>
			</div>
			
			<div class="tiepanel-item">
				<h3><?php _e('选填信息'); ?></h3>
				<p style="padding:10px; color:red;"><?php _e('注意网址开头需要填写 “http://”。'); ?></p>
				<?php						
					Bing_options(
						array(	"name" => "QQ",
								"id" => "social_qq",
								"type" => "text"));

					Bing_options(
						array(	"name" => __('邮箱'),
								"id" => "social_email",
								"type" => "text"));

					Bing_options(
						array(	"name" => "Twitter",
								"id" => "social_twitter",
								"type" => "text"));

					Bing_options(
						array(	"name" => __('腾讯微博'),
								"id" => "social_tweibo",
								"type" => "text"));

					Bing_options(
						array(	"name" => __('新浪微博'),
								"id" => "social_sweibo",
								"type" => "text"));

					Bing_options(
						array(	"name" => 'G+ '.__('地址'),
								"id" => "social_rss",
								"type" => "text"));

					Bing_options(
						array(	"name" => 'Rss '.__('地址'),
								"id" => "social_rss",
								"type" => "text"));

					Bing_options(
						array(	"name" => __('腾讯邮件列表').' ID',
								"id" => "social_temailrss_list",
								"type" => "text"));
				?>
			</div>			
		</div><!-- Social Networking -->
						
		<div id="tab6" class="tab_content tabs-wrap">
			<h2><?php _e('文章设置'); ?></h2> <?php echo $save ?>

			<div class="tiepanel-item">
				<h3><?php _e('文章链接'); ?></h3>
				<?php
					Bing_options(
						array(	"name" => __('文章内容全部链接新窗口打开'),
								"id" => "post_url_blank",
								"type" => "checkbox"));

					Bing_options(
						array(	"name" => __('文章内容外链添加 nofollow 并在新窗口打开'),
								"id" => "post_url_blank_nofollow",
								"type" => "checkbox"));
				?>
			</div>

		</div> <!-- Article Settings -->
		
		
		<div id="tab7" class="tabs-wrap">
			<h2><?php _e('页脚设置'); ?></h2> <?php echo $save ?>
						
			<div class="tiepanel-item">
				<h3><?php _e('页脚文本区域'); ?></h3>
				<div class="option-item">
					<textarea id="Bing_footer_one" name="Bing_options[footer_one]" style="width:100%" rows="4"><?php echo htmlspecialchars_decode(panel('footer_one')); ?></textarea>				
				</div>
			</div>

		</div><!-- Footer Settings -->
						
		<div id="tab13" class="tab_content tabs-wrap">
			<h2><?php _e('样式设置'); ?></h2>	<?php echo $save ?>	
			<div class="tiepanel-item">
				<h3><?php _e('自定义 CSS'); ?></h3>	
				<div class="option-item">
					<p><strong><?php _e('自定义 CSS：'); ?></strong></p>
					<textarea id="Bing_css" name="Bing_options[css]" style="width:100%" rows="7"><?php echo panel('css');  ?></textarea>
				</div>	
				<div class="option-item">
					<p><strong><?php _e('响应式 CSS：'); ?></strong><?php _e('响应式 1000px 以下'); ?></p>
					<textarea id="Bing_css" name="Bing_options[css_1000_px]" style="width:100%" rows="7"><?php echo panel('css_1000_px');  ?></textarea>
				</div>
				<div class="option-item">
					<p><strong><?php _e('响应式 CSS：'); ?></strong><?php _e('响应式 800px 以下'); ?></p>
					<textarea id="Bing_css" name="Bing_options[css_800_px]" style="width:100%" rows="7"><?php echo panel('css_800_px');  ?></textarea>
				</div>
				<div class="option-item">
					<p><strong><?php _e('响应式 CSS：'); ?></strong><?php _e('响应式 600px 以下'); ?></p>
					<textarea id="Bing_css" name="Bing_options[css_600_px]" style="width:100%" rows="7"><?php echo panel('css_600_px');  ?></textarea>
				</div>	
				<div class="option-item">
					<p><strong><?php _e('响应式 CSS：'); ?></strong><?php _e('响应式 400px 以下'); ?></p>
					<textarea id="Bing_css" name="Bing_options[css_400_px]" style="width:100%" rows="7"><?php echo panel('css_400_px');  ?></textarea>
				</div>	
			</div>	

		</div> <!-- Styling -->

		<div id="tab10" class="tab_content tabs-wrap">
			<h2><?php _e('高级功能'); ?></h2>	<?php echo $save ?>	

			<div class="tiepanel-item">
				<h3><?php _e('头像缓存'); ?></h3>
				<?php
					Bing_options(
						array(	"name" => __('头像缓存'),
								"id" => "Bing_avatar",
								"type" => "checkbox",
								"help" => __('开启后可以把用户头像缓存到本地，提升速度。如果开启需要在网站根目录，即与 wp-content 文件夹同目录新建一个文件夹命名为 avatar 并赋予权限为 777'))); 
					
					Bing_options(
						array(	"name" => __('头像缓存天数'),
								"id" => "Bing_avatar_day",
								"type" => "slider",
								"unit" => "天",
								"max" => 60,
								"min" => 2 ));
				?>
			</div>

			<div class="tiepanel-item">
				<h3><?php _e('后台功能'); ?></h3>
				<?php
					Bing_options(
						array(	"name" => __('找回“连接管理器”'),
								"id" => "link_manager",
								"type" => "checkbox"));

					Bing_options(
						array(	"name" => __('后台评论添加 [Ctrl+Enter] 快捷回复'),
								"id" => "admin_comment_ctrlenter",
								"type" => "checkbox"));

					Bing_options(
						array(	"name" => __('阻止站内文章互相 Pingback'),
								"id" => "noself_ping",
								"type" => "checkbox"));

					Bing_options(
						array(	"name" => __('增强 WordPress 默认文章编辑器'),
								"id" => "editor_buttons",
								"type" => "checkbox"));

					Bing_options(
						array(	"name" => __('隐藏主题、插件版本更新提示'),
								"id" => "pre_site_transient",
								"type" => "checkbox"));

					Bing_options(
						array(	"name" => __('禁止 WordPress 默认文章编辑器自动保存草稿'),
								"id" => "no_autosave",
								"type" => "checkbox"));		
				?>
			</div>

			<div class="tiepanel-item">
				<h3><?php _e('评论系统'); ?></h3>
				<?php
					Bing_options(
						array(	"name" => __('Ajax 无刷新评论'),
								"id" => "comment_ajax",
								"type" => "checkbox"));

					Bing_options(
						array(	"name" => __('评论表情样式'),
								"id" => "comment_smilies",
								"type" => "checkbox"));	

					Bing_options(
						array(	"name" => __('评论回复邮件通知'),
								"id" => "comment_email",
								"type" => "checkbox"));	

					Bing_options(
						array(	"name" => __('垃圾评论拦截'),
								"id" => "comment_anti",
								"help" => __('比 Akismet 插件更高效的垃圾评论拦截方法，开启前为避免冲突请关闭 Akismet 插件'),
								"type" => "checkbox"));	
				?>
			</div>

		</div> <!-- Advanced -->
		
		
		<div class="mo-footer">
			<?php echo $save; ?>
		</form>

			<form method="post">
				<div class="mpanel-reset">
					<input type="hidden" name="resetnonce" value="<?php echo wp_create_nonce('reset-action-code'); ?>" />
					<input name="reset" class="mpanel-reset-button" type="submit" onClick="if(confirm('<?php _e('所有的设置将会被恢复初始情况，无法恢复。你确定？'); ?>')) return true ; else return false; " value="<?php _e('恢复初始设置'); ?>" />
					<input type="hidden" name="action" value="reset" />
				</div>
			</form>
		</div>

	</div><!-- .mo-panel-content -->
</div><!-- .mo-panel -->


<?php
}

//本页设置结束
?>