<?php get_header(); ?>
<?php while(have_posts()):the_post(); ?>
<?php if(panel('breadcrumbs')) Bing_breadcrumbs(); ?>
	<div class="post-header">
		<h2 class="title"><?php the_title(); ?></h2>
		<?php Bing_meta(false); ?>
	</div>
<div class="postcontainer bc94">
	<div class="context">
		<?php the_content(); ?>
	</div>
</div>
<?php if(comments_open()):echo '<div class="commentsbox">';comments_template( '', true );echo '</div>';endif; ?>
<?php endwhile; ?>
<?php get_sidebar();get_footer(); ?>