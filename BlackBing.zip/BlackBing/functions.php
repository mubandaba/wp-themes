<?php
/*
	*Bing - functions
	*Form:www.bgbk.org
*/

//Custom
define('theme_name',wp_get_theme());
include(TEMPLATEPATH.'/custom-functions.php');

//Page End。。。。
?>