<div class="sidebar">
	<div id="search">
        <?php
        	include (TEMPLATEPATH.'/searchform.php');
        ?>
    </div>
    <ul>
        <?php
        if (function_exists('dynamic_sidebar') && dynamic_sidebar()):
            else :
        ?>
        <li>
        	<h2>
	            <?php
	            _e('recent posts');
	            ?>
	        </h2>
            <ul>
                <?php
                global $post;
                $recent = get_posts('numberposts=5&orderby=date');
                foreach ($recent as $post):
                    setup_postdata($post);
                ?>
                <li>
                	<a href="<?php the_permalink(); ?>">
                    	<div><?php the_time('d M Y'); ?></div>
                        <?php
                        the_title();
                        ?>
                    </a>
                </li>
                <?php endforeach; ?>
            </ul>
        </li>
        <li>
            <h2>
                <?php
                _e('Categories');
                ?>
            </h2>
            <ul>
                <?php
                	wp_list_cats('sort_column=name&hierarchical=0');
                ?>
            </ul>
        </li>
        <li>
        	<h2>our sponsors</h2>
			<ul>
				<li>
					<div class="sidebarads">
						<div class="ads">
							<a href="#"><img src="<?php bloginfo('template_url'); ?>/images/ads.png" alt="Advertising" /></a>
						</div>
						<div class="ads">
							<a href="#"><img src="<?php bloginfo('template_url'); ?>/images/ads.png" alt="Advertising" /></a>
						</div>
					</div>
					<div id="clear"></div>
				</li>
			</ul>
        </li>
        <?php
        endif;
        ?>
    </ul>
</div>
