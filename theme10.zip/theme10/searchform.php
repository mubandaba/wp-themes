<form method="get" id="searchform" action="<?php bloginfo('home'); ?>/">
	<div>
		<input class="search" type="text" value="Looking for something..?" onfocus="if (this.value == 'Looking for something..?') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Looking for something..?';}" name="s" id="s" />
		<input class="search_btn" type="submit" id="searchsubmit" value="" />
	</div>
	<div id="clear"></div>
</form>