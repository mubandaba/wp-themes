<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head profile="http://gmpg.org/xfn/11">
        <title>
            <?php if (is_home () ) { bloginfo('name'); echo ' - ' ; bloginfo('description');}

			elseif ( is_category() ) { single_cat_title(); echo ' - ' ; bloginfo('name');}

			elseif (is_single() ) { single_post_title(); echo ' - ' ; bloginfo('name');}

			elseif (is_page() ) { single_post_title(); echo ' - ' ; bloginfo('name');}

			else { wp_title('',true); } ?>
        </title>
        <meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
        <meta name="generator" content="WordPress <?php bloginfo('version'); ?>" />
        <!-- leave this for stats please -->
        <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
        <link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
        <link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
        <link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />
        <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
        <?php
        wp_get_archives('type=monthly&format=link');
        ?>
        <?php//comments_popup_script(); // off by default?>
        <?php
        wp_head();
        ?>
    </head>
    <body>
        <div id="wrapper">
            <div id="header">
                <h1>
                	<a href="<?php bloginfo('url');?>">
                        <?php bloginfo('name'); ?>
                    </a>
				</h1>
				<div id="header_menu">
					<div id="menu">
						<ul>
		                    <li class="page_item <? if(is_home()) echo 'current_page_item'; ?>">
		                        <a href="<? bloginfo('url'); ?>" title="Home">Home</a>
		                    </li>
		                    <?php
		                    	wp_list_pages( array ('title_li'=>'', 'depth'=>1));
		                    ?>
		                </ul>
					</div>
					<div id="rss">
						<a href="<?php bloginfo('rss_url'); ?>">RSS FEEDS <img src="<?php bloginfo('template_url'); ?>/images/rss.png" alt="RSS Feeds" align="middle" /></a>
					</div>
					<div id="clear"></div>
				</div>
				<div id="header_btm">
					<div class="featured">
						<h2>featured post</h2>
						<div class="featured_post">
							<?php
			                global $post;
			                $recent = get_posts('numberposts=1&category_name=featured');
			                foreach ($recent as $post):
			                    setup_postdata($post);
			                ?>
			                <div>
			                	<?php
		                        	the_excerpt();
		                        ?>
			                </div>
			                <?php endforeach; ?>
						</div>
						<div id="clear"></div>
						<div class="featured_postmetadata">
							<div>
								<span><?php _e('Category : '); ?> <?php the_category(', '); ?><?php edit_post_link('Edit', '|&nbsp;', ''); ?></span><?php _e('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'); ?><span><?php _e('By : '); ?><a href="#"><?php the_author_link(); ?></a></span><?php _e('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'); ?><span><?php _e('Posted On : '); ?><a href="#"><?php the_time('d M Y'); ?></a></span>
							</div>
						</div>
						<div id="clear"></div>
					</div>
					<div class="featured_img">
						<img src="<?php bloginfo('template_url'); ?>/images/header_logo.png" alt="" />
					</div>
					<div id="clear"></div>
				</div>
				<div id="clear"></div>
			</div>
			<div id="clear"></div>
