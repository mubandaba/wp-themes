<?php get_header(); ?>

	<div id="content">

		<div id="container">

			<?php if(have_posts()) : ?><?php while(have_posts()) : the_post(); ?>      

			<div class="post">

				<div class="post_heading">

					<div class="date">

						<div class="dat"><?php the_time(j);?></div>

						<div class="month"><?php the_time(M);?></div>

					</div>

					<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>

					<div id="clear"></div>

				</div>

				<div id="clear"></div>

				<div class="entry">

					<?php the_excerpt(); ?>
					<div id="clear"></div>
					<div class="postmetadata"> 

						<div>

							<span class="readmore"><a href="?p=<?php the_ID();?>">Read Full Story</a></span><?php _e('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'); ?><img src="<?php bloginfo('template_url'); ?>/images/comments.png" alt="" align="absmiddle" /><?php _e('&nbsp;&nbsp;'); ?><?php comments_popup_link('No Comments', '1 Comments', '% Comments'); ?><?php edit_post_link('Edit', ' &#124; ', ''); ?>

						</div>

					</div>

				</div>

			</div>

			<?php endwhile; ?>

				<div class="navigation">

					<div class="left-nav"><?php previous_posts_link('Previous Page', ''); ?></div>

					<div class="right-nav"><?php next_posts_link('Next Page', ''); ?> </div>

				</div>

				<?php else: ?>

				<div class="post" id="post-<?php the_ID();?>">

					<h2><?php _e('Not Found');?></h2>

				</div>

			<?php endif; ?>

		</div>

		<?php get_sidebar();?>

		<div id="clear"></div>

	</div>

	<?php get_footer();?>

</div>

</body>

</html>