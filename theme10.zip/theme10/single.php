<?php get_header(); ?>

	<div id="content">

		<div id="container">

			<?php if(have_posts()) : ?><?php while(have_posts()) : the_post(); ?>

	      	<div class="post">

				<div class="post_heading">

					<div class="date">

						<div class="dat"><?php the_time(j);?></div>

						<div class="month"><?php the_time(M);?></div>

					</div>

					<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>

					<div id="clear"></div>

				</div>

				<div id="clear"></div>

				<div class="entry">

					<?php the_content(); ?>

					<?php link_pages('<p><strong>Pages:</strong> ', '</p>', 'number'); ?>
					<div id="clear"></div>
					<div class="postmetadata"> 

						<div>

							<span class="readmore"><a href="?p=<?php the_ID();?>">Read Full Story</a></span>

						</div>

					</div>

					<div id="clear"></div>

				</div>

				<div class="comments-template">

					<?php comments_template(); ?>

				</div>

			</div>

			<?php endwhile; ?>

				<div class="navigation">

					<div class="left-nav"><?php previous_post_link('&laquo; %link') ?></div>

	                <div class="right-nav"><?php next_post_link(' %link &raquo;') ?></div>

				</div>

				<?php else: ?>

				<div class="post" id="post-<?php the_ID();?>">

					<h2><?php _e('Not Found');?></h2>

				</div>		

			<?php endif; ?>

		</div>

		<?php get_sidebar();?>

		<div id="clear"></div>

	</div>

	<?php get_footer();?>

</div>

</body>

</html>