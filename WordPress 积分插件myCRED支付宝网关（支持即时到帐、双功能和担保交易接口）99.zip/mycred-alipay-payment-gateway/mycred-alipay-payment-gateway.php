<?php
/**
 * Plugin Name: Alipay-buyCRED Gateway for myCRED
 * Plugin URI:  http://www.wpdaxue.com/mycred-alipay-buycred-gateway.html
 * Description: Adding Alipay payment gateway to myCred:buyCRED.
 * Version: 1.3.1
 * Author: Changmeng Hu
 * Author URI: http://www.wpdaxue.com
 * Text Domain: mycred-alipay
 * Domain Path: /languages
 * License: Copyrighted
 */

if(!defined('ABSPATH')){ exit; }

define( 'MYCRED_ALI_DOMAIN', 'mycred-alipay' );
define( 'MYCRED_ALI_VER', '1.0' );
defined('MYCRED_ALI_THIS') or define( 'MYCRED_ALI_THIS', __FILE__ );
defined('MYCRED_ALI_BASENAME') or define('MYCRED_ALI_BASENAME',plugin_basename( MYCRED_ALI_THIS));
define( 'MYCRED_ALI_URL', plugin_dir_url( MYCRED_ALI_THIS ) );
define( 'MYCRED_ALI_DIR', plugin_dir_path( MYCRED_ALI_THIS ) );

/*I18N*/
function mycred_alipay_i18n(){

		$locale = apply_filters( 'plugin_locale', get_locale(),MYCRED_ALI_DOMAIN );

		load_textdomain( MYCRED_ALI_DOMAIN,  trailingslashit( WP_LANG_DIR ) . "MYCRED_ALI_DOMAIN-$locale.mo" );
		load_plugin_textdomain( MYCRED_ALI_DOMAIN, false, dirname( MYCRED_ALI_BASENAME ) . '/languages/' );

}

add_action('plugins_loaded','mycred_alipay_i18n');



require_once( ABSPATH . '/wp-admin/includes/plugin.php' );

if (is_plugin_active('mycred/mycred.php')){


		function alipay_gateway_load_for_mycred(){

			if ( version_compare(PHP_VERSION, '5.3', '>') && version_compare(PHP_VERSION, '5.4', '<')){
				require_once(dirname(MYCRED_ALI_THIS).'/includes/class-mycred-alipay-3.php');
			}elseif ( version_compare(PHP_VERSION, '5.4', '>') && version_compare(PHP_VERSION, '5.5', '<')){
				require_once(dirname(MYCRED_ALI_THIS).'/includes/class-mycred-alipay-4.php');
			}
			require_once(dirname(MYCRED_ALI_THIS).'/includes/shortcode.php');

			require_once(dirname(MYCRED_ALI_THIS).'/includes/mycred-backend-charge.php');
			require_once(dirname(MYCRED_ALI_THIS).'/includes/buycred-addtional-options.php');
			require_once(dirname(MYCRED_ALI_THIS).'/includes/class-mycred-management.php');

			/*For developers*/
			do_action('mycred_alipay_ready');

		}
		add_action('mycred_buycred_load_gateways','alipay_gateway_load_for_mycred');


add_filter('mycred_setup_gateways', 'mycred_register_alipay_gateway',10,1);
function mycred_register_alipay_gateway($gateways) {
    // Using a gateway class
    $gateways['mycred_alipay'] = array(
        'title' => __('Aliapy',MYCRED_ALI_DOMAIN),
        'callback' => array( 'Alipay_For_myCRED' )
    );

    return $gateways;
}



		/*
		FOR DEVELOPER: CHECK IF THE buy-creds ADD-ON HAS BE ACTIVATED.
		=======================================================
		$mycred_addons=get_option('mycred_pref_addons');
		$activated_mycred_addons=array();
		$activated_mycred_addons=$mycred_addons['active'];
		$activated=in_array('buy-creds',$activated_mycred_addons);
		=======================================================

		if($activated){

			add_action('mycred_buycred_load_gateways','alipay_gateway_load_for_mycred');

		}else{

			function mycred_alipay_need_mycred_buycred_notice(){
				?>
				<div class="update-nag">
					<p><?php printf(
						__('Please activate the %1$s component of %2$s before %3$s working fine for you.',MYCRED_ALI_DOMAIN),
					'<a href="'.admin_url('admin.php?page=myCRED_page_addons#ui-id-5').'"><strong>buy</strong>CRED</a>',
					'<strong>myCRED</strong>',
					'<strong>myCRED:Alipay-buyCRED Gateway</strong>'
					);?></p>
				</div>
				<?php
			}

			add_action('admin_notices','mycred_alipay_need_mycred_buycred_notice');

		}
		=======================================================
		*/

/*		add_action('mycred_alipay_after_settings_output_action','mycred_alipay_after_settings_output_action');
		function mycred_alipay_after_settings_output_action(){
			?>

			<label class="subheader"><?php _e( 'Exchange Rate', MYCRED_ALI_DOMAIN ); ?></label>
			<ol>
				<?php $this->alipay_exchange_rate(); ?>
			</ol>
			<?php

		}*/



}else{

	/*Admin notice: myCRED was not be activated.*/
	function mycred_alipay_need_mycred_notice(){
		?>
		<div class="update-nag">
			<p><?php printf(
				__('Please install and activate %1$s before %2$s working fine for you.',MYCRED_ALI_DOMAIN),
			'<a href="'.admin_url('plugin-install.php?tab=search&s=mycred').'" target="_blank"><strong>myCRED</strong></a>',
			'<strong>Alipay-buyCRED Gateway for myCRED</strong>'
			);?></p>
		</div>
		<?php
	}

	add_action('admin_notices','mycred_alipay_need_mycred_notice');
}

								/*
								FOR DEVELOPER:
								$this->sl_dev_tip($pending_payment);
								==========================================================
								$pending_payment data:

								array(6) {

									["to"]=> int(1)
									["from"]=> int(1)
									["amount"]=> string(1) "1"
									["cost"]=> string(4) "0.01"
									["currency"]=> string(3) "CNY"
									["ctype"]=> string(14) "slnet_gold"

								}
								==========================================================
								*/
/*-----------------------------------------------------------------------------------*/
# Check PHP version
/*-----------------------------------------------------------------------------------*/
function mycred_alipay_php_version_notice(){
	$phpVer = PHP_VERSION;
	if ( version_compare($phpVer, '5.3', '<') || version_compare($phpVer, '5.5', '>')){
		?>
		<div class="update-nag">
			<?php echo sprintf(__('Alipay-buyCRED Gateway for myCRED can only be used in PHP 5.3.x and PHP 5.4.x series of PHP environments, your current PHP version is %s, does not meet the requirements!',MYCRED_ALI_DOMAIN), $phpVer ) ?>
		</div>
		<?php
	}
}
add_action('admin_notices', 'mycred_alipay_php_version_notice');
/*All Done!*/