<?php
/**
 * @author: suifengtec coolwp.com
 * @date:   2015-09-22 01:22:54
 * @last Modified by:   suifengtec coolwp.com
 * @last Modified time: 2015-09-22 02:16:40
 */

defined( 'ABSPATH' ) || exit;

/**
 * CWP_Debuger
 * @version 0.9.0
 * @author suifengtec
 */

if(!class_exists('CWP_Debuger')){

    class CWP_Debuger{

            private $path = '';

            public function __construct( $base_file = '', $nicename = ''  ) {

                $base_file = (''==$base_file)?__FILE__:$base_file;

                if(function_exists('wp_upload_dir')){


                    $upload_dir = wp_upload_dir();

                    $this->path = $upload_dir['basedir'] . '/cwp-logs/';

                 }else{

                    $this->path = dirname($base_file).DIRECTORY_SEPARATOR.'debug'.DIRECTORY_SEPARATOR;
                 }

                 if(''!=$nicename){
                    
                     $file_name = 'debug_'.$nicename;

                 }else{

                    $file_name = 'debug_'.md5($base_file);
                 }
                
                
                $this->log_file_name = (function_exists('apply_filters'))?apply_filters('cwp_debuger_log_file_name',$file_name):$file_name;

                $this->full_path = $this->path.$this->log_file_name.'.log';


            }


        public function  add( $text ) {

            if(function_exists('date_default_timezone_set')){

                date_default_timezone_set('Asia/Shanghai');

            }
            

            if(
                (is_array( $text )||is_object( $text ))
                &&function_exists( 'json_encode' )

                ){

                $text = json_encode($text);

            }


            if(!$this->is_writable_file()){

                return false;
            }

            $fp = fopen( $this->full_path, "a" );

            $type = is_resource($fp)?get_resource_type($fp):false;

            if('stream'!=$type){
                return false;
            }

            flock( $fp, LOCK_EX ) ;
            fwrite( $fp,"".date("Y-m-d H:i:s",time())."\n".$text."\n\n" );
            flock( $fp, LOCK_UN );
            fclose( $fp );
           
        }

        private function is_writable_file(  ){

            if(!file_exists( $this->full_path ) ){

                $this->check_log_file();
            }
            if(is_writable( $this->full_path )){

                chmod($this->full_path, 0777);
            }

            $r = is_writable( $this->full_path );

            return $r;

        }



        private function is_path_readable(){

            $r = (is_dir( $this->path ))?true:false;

            return $r;
        }

        private function check_log_file(){

            $is_dir = is_dir( $this->path );

            if(!$is_dir){

                $md = mkdir( $this->path, 0777, true );
                chmod( $this->path, 0777 );

            }

            $is_file = file_exists( $this->full_path );

            if($is_file){

                 return true;
            }
            if(!$is_file){


                if(!$is_file){

                    $fp = fopen( $this->full_path, "a" );
                    if(is_resource($fp)){


                        fclose($fp);

                    }

                }
            }
        }


    }

}

?>