<?php
if(!defined('ABSPATH')){ exit; }


add_action('mycred_add_menu','mycred_alipay_ready');
function mycred_alipay_ready(){

	global $mycred;
	if ( $mycred->exclude_user() ) return;

	$mycred_backend_recharge_submenu_position=apply_filters('mycred_backend_recharge_submenu_position','users.php');

	$page=add_submenu_page(
								$mycred_backend_recharge_submenu_position,
								__('Points recharge',MYCRED_ALI_DOMAIN),
								__('Points recharge',MYCRED_ALI_DOMAIN),
								'read',
								'points-recharge',
								'mycred_backend_recharge_page'
							);


/*add_action( 'admin_print_styles-' . $page, 'mycred_backend_recharge_header' );
add_action( 'load-' . $page,  'screen_options' );*/

}

/*
function mycred_backend_recharge_header() {
			wp_enqueue_script( 'mycred-edit-log' );
			wp_enqueue_style( 'mycred-inline-edit' );
}
*/

function mycred_backend_recharge_page(){

	if ( ! is_user_logged_in() )
		wp_die( __( 'Access Denied', MYCRED_ALI_DOMAIN ) );
?>
<style>

.mycred-backend-recharge form
{

	padding:16px 0;
}
</style>
	<div class="wrap" id="mycred-recharge-wrap">
		<h2><?php _e( 'Points recharge', MYCRED_ALI_DOMAIN ); ?></h2>
		<p>
			<?php do_action('mycred_backend_recharge_before_form_action'); ?>
		</p>
		<div class="mycred-backend-recharge">
		<?php
			$backend_recharge_form=apply_filters('mycred_backend_recharge_form_filter',do_shortcode('[mycred_go]'));
			echo $backend_recharge_form;
		?>
		</div>
		<?php do_action('mycred_backend_recharge_after_form_action'); ?>
		<div class="clear"></div>
	</div>
<?php
}



/*Change the mycred backend recharge submenu position.*/
function mycred_backend_recharge_submenu_position($parent_menu_slug){

	/*
	You can use:

	'user.php'
	'tools.php'
	'myCRED'
	'index.php'
	'options-general.php'
	'plugins.php'
	'themes.php'

	or other slug as you like.

	*/
/*	$parent_menu_slug='user.php';*/
	return $parent_menu_slug;

}
add_filter('mycred_backend_recharge_submenu_position','mycred_backend_recharge_submenu_position');

/*Change/add the myCRED backend recharge form shortcode or HTML output content.*/
function mycred_backend_recharge_form_filter($output){

	/*you can change the output of the myCRED backend recharge page here.*/

	/*$output.='DEMO CONTENT:<br>'.do_shortcode('[mycred_buy_form ctype=myCRED_gold]');*/

	return $output;
}
/*add_filter('mycred_backend_recharge_form_filter','mycred_backend_recharge_form_filter');*/

/*Add your description for the myCRED backend recharge page or other content you like.*/

function mycred_backend_recharge_before_form_action(){

	$output='<p>Demo content:This is your description for the myCRED backend recharge page.</p>';
	echo $output;
}
/*add_action('mycred_backend_recharge_before_form_action','mycred_backend_recharge_before_form_action');*/

/*Add your content after the myCRED backend recharge form.*/

function mycred_backend_recharge_after_form_action(){
	$output='<p>Demo content:This is your content after the myCRED backend recharge form.</p>';
	echo $output;
}
/*add_action('mycred_backend_recharge_after_form_action','mycred_backend_recharge_after_form_action');*/

/*DONE*/