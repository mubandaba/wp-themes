<?php
if(!defined('ABSPATH')){ exit; }
/**
 * myCRED_Addtiional_Options class
 *
 * @since 1.0
 * @version 1.0
 */
add_action( 'plugins_loaded', 'mycred_addtional_optional_sl', 25 );
function mycred_addtional_optional_sl() {

	if ( ! class_exists( 'myCRED_Module' ) ) return;
	if ( ! class_exists( 'myCRED_Addtiional_Options' ) ) {
		class myCRED_Addtiional_Options extends myCRED_Module {

			/**
			 * Construct
			 */
			function __construct() {
				parent::__construct( 'myCRED_Addtiional_Options', array(
					'module_name' => 'addtionaloptions',
					'defaults'    => array(
						'contentbefore'  => esc_attr__('Enter the description of the purchase form here with p tag like this.',MYCRED_ALI_DOMAIN),
						'contentafter'  => '',
						'css'	=>'
									form.myCRED-buy-form input,
									form.myCRED-buy-form select
									{
										height:2.8em;
										line-height:1.1;
										padding: 0.5em;
									}
									form.myCRED-buy-form input[type=submit]
									{
										margin-top:2em!important;
									}
								',
						'use'       => 0,
					),
					'register'    => false,
					'add_to_core' => true
				) );

				add_filter('mycred_super_shortcode_css',array($this,'custom_css'));

				add_action('mycred_backend_recharge_before_form_action',array($this,'before'));
				add_action('mycred_backend_recharge_after_form_action',array($this,'after'));

				add_filter('mycred_frontend_recharge_before_form_filter',array($this,'frontend_before'),10,1);
				add_filter('mycred_frontend_recharge_after_form_filter',array($this,'frontend_after'),10,1);

				add_filter('mycred_admin_add_points_log',array($this,'add_points_log_template'));
				add_filter('mycred_admin_sub_points_log',array($this,'sub_points_log_template'));


			}

			public function add_points_log_template($tmp){
				$settings = $this->addtionaloptions;
				$template=$settings['add_log'];
				if(!empty($template)){
					$tmp=$template;
				}
				return $tmp;

			}
			public function sub_points_log_template($tmp){
				$settings = $this->addtionaloptions;
				$template=$settings['sub_log'];
				if(!empty($template)){
					$tmp=$template;
				}
				return $tmp;

			}
			/**
			 * Module Init
			 * @since 1.0
			 * @version 1.1
			 */
			public function module_init() {
				if ( ! is_user_logged_in() ) return;

			}
			public function custom_css($css){

				$settings = $this->addtionaloptions;
				if(!empty($settings['css']))
				$css.=$settings['css'];

				return $css;
			}
			public function before(){

				if(is_admin()){
					$settings = $this->addtionaloptions;
					if(!empty($settings['contentbefore'])){
						echo $settings['contentbefore'];
					}
				}

			}
			public function after(){

				if(is_admin()){
					$settings = $this->addtionaloptions;
					if(!empty($settings['contentafter'])){
						echo $settings['contentafter'];
					}
				}

			}

			public function frontend_before($c){

				if(is_admin()) return $c;

				$settings = $this->addtionaloptions;
					if(!empty($settings['contentbefore'])&&$settings['use']){

						$c= $settings['contentbefore'];
					}
				return $c;
			}
			public function frontend_after($c){
				if(is_admin()) return $c;

				$settings = $this->addtionaloptions;

					if(!empty($settings['contentafter'])&&$settings['use']){

						$c= $settings['contentafter'].$c;
					}
				return $c;
			}
			/**
			 * myCRED Add
			 * @since 1.0
			 * @version 1.2.1
			 */
			public function mycred_add( $reply, $request ) {

				return $reply;
			}

			/**
			 * Settings Page
			 * @since 1.0
			 * @version 1.1
			 */
			public function after_general_settings($mycred) {

				$settings = $this->addtionaloptions; ?>

					<h4><div class="icon icon-active"></div><?php _e( 'Addtional Options', MYCRED_ALI_DOMAIN ); ?></h4>
					<div class="body" style="display:none;">

						<label class="subheader"><?php _e( 'Content berore the purchase form', MYCRED_ALI_DOMAIN ); ?></label>
						<ol>
							<li>
								<textarea name="mycred_pref_core[addtionaloptions][contentbefore]" id="myCRED-addtionaloptions-contentbefore" rows="5" style="width: 50%;"><?php echo $settings['contentbefore']; ?></textarea><br />
								<span class="description"><?php _e( 'You can use HTML tags.', MYCRED_ALI_DOMAIN ); ?></span>
							</li>
						</ol>
						<label class="subheader"><?php _e( 'Content after the purchase form', MYCRED_ALI_DOMAIN ); ?></label>
						<ol>
							<li>
								<textarea name="mycred_pref_core[addtionaloptions][contentafter]" id="myCRED-addtionaloptions-contentafter" rows="5" style="width: 50%;" /><?php echo $settings['contentafter']; ?></textarea><br />
								<span class="description"><?php _e( 'You can use HTML tags.', MYCRED_ALI_DOMAIN ); ?></span>
							</li>
						</ol>

						<label class="subheader"><?php _e( 'Custom CSS', MYCRED_ALI_DOMAIN ); ?></label>
						<ol>
							<li>
								<textarea name="mycred_pref_core[addtionaloptions][css]" id="myCRED-addtionaloptions-css" rows="5" style="width: 50%;"><?php echo $settings['css']; ?></textarea><br />
								<span class="description"><?php esc_attr_e( 'Enter you custom css without <style> tag here.', MYCRED_ALI_DOMAIN ); ?></span>
							</li>
						</ol>
						<label class="subheader"><?php _e( 'Also for the frontend form?', MYCRED_ALI_DOMAIN ); ?></label>
						<ol>
							<li>
								<input type="checkbox" name="mycred_pref_core[addtionaloptions][use]" id="myCRED-addtionaloptions-use" <?php checked( $settings['use'], 1 ); ?> value="1" /> <label for="myCRED-addtionaloptions-use"><?php _e( 'if you want the above settings apply to the frontend  form,check this option.or it just for backend forms', MYCRED_ALI_DOMAIN ); ?></label>
							</li>
						</ol>

						<label class="subheader"><?php _e( 'Custom admin add point log template', MYCRED_ALI_DOMAIN ); ?></label>
						<ol>
							<li>
								<textarea name="mycred_pref_core[addtionaloptions][add_log]" id="myCRED-addtionaloptions-add_log" rows="5" style="width: 50%;"><?php echo $settings['add_log']; ?></textarea><br />
								<span class="description"><?php esc_attr_e( 'Enter you custom admin add point log template.allowed tags:', MYCRED_ALI_DOMAIN ); ?><?php esc_attr_e( 'point type-', MYCRED_ALI_DOMAIN ); ?><code>%point_type%</code><?php esc_attr_e( 'point amount-', MYCRED_ALI_DOMAIN ); ?><code>%amount%</code></span>
							</li>
						</ol>
						<label class="subheader"><?php _e( 'Custom admin subtract point log template', MYCRED_ALI_DOMAIN ); ?></label>
						<ol>
							<li>
								<textarea name="mycred_pref_core[addtionaloptions][sub_log]" id="myCRED-addtionaloptions-sub_log" rows="5" style="width: 50%;"><?php echo $settings['sub_log']; ?></textarea><br />
								<span class="description"><?php esc_attr_e( 'Enter you custom admin subtract point log template.allowed tags:', MYCRED_ALI_DOMAIN ); ?><?php esc_attr_e( 'point type-', MYCRED_ALI_DOMAIN ); ?><code>%point_type%</code><?php esc_attr_e( 'point amount-', MYCRED_ALI_DOMAIN ); ?><code>%amount%</code></span>
							</li>
						</ol>
					</div>
			<?php
			}

			/**
			 * Sanitize & Save Settings
			 * @since 1.0
			 * @version 1.1
			 */
			public function sanitize_extra_settings( $new_data, $data, $general ) {

				$settings=$data['addtionaloptions'];
				/*sanitize_text_field()*/
				$new_data['addtionaloptions']['contentbefore'] =  $settings['contentbefore'] ;
				$new_data['addtionaloptions']['contentafter'] = trim($settings['contentafter'] );
				$new_data['addtionaloptions']['css'] = trim($settings['css'] );

				$new_data['addtionaloptions']['use'] = ( isset( $settings['use'] ) ) ? 1 : 0;
				$new_data['addtionaloptions']['add_log'] = trim($settings['add_log'] );
				$new_data['addtionaloptions']['sub_log'] = trim($settings['sub_log'] );
				unset($settings);

				return $new_data;
			}
		}
		$addtionaloptions = new myCRED_Addtiional_Options();
		$addtionaloptions->load();
	}

}
/*DONE*/