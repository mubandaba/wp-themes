<?php

if(!defined('ABSPATH')){ exit; }


final class myCRED_Manage_Points{

    protected static $_instance = null;


    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    public function __clone() {
        _doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?', MYCRED_ALI_DOMAIN ), '1.0' );
    }

    public function __wakeup() {
        _doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?', MYCRED_ALI_DOMAIN ), '1.0' );
    }

    public function __construct() {

    	/*date_default_timezone_set("Asia/Shanghai");*/
    	add_action('mycred_add_menu',array($this,'_menu'));
    	add_action('mycred_admin_init',array($this,'process'));
    	add_action('mycred_init',array($this,'sc_init'));

    	/*add_action('mycred_enqueue_admin',array($this,'enqueue_admin'));*/
    	add_action('admin_enqueue_scripts',array($this,'enqueue_admin'));

    	add_action( 'wp_ajax_sl_search_users', array($this,'sl_search_users' ));
    }

    public function sl_search_users(){

			if(isset( $_POST['sl_action_id'])=='sl_user_search_mycred_point_management') {

				$search_query = trim( $_POST['user_name'] );

				$found_users = get_users( array(
						'number' => 9999,
						'search' => $search_query . '*'
					)
				);

				if( $found_users ) {
					$user_list = '<ul>';
						foreach( $found_users as $user ) {
							$user_list .= '<li><a href="#" data-login="' . esc_attr( $user->user_login ) . '">' . esc_html( $user->user_login ) . '</a></li>';
						}
					$user_list .= '</ul>';

					echo json_encode( array( 'results' => $user_list, 'id' => 'found' ) );

				} else {
					echo json_encode( array( 'msg' => __( 'No users found', MYCRED_ALI_DOMAIN ), 'results' => 'none', 'id' => 'fail' ) );
				}

			}
			die();
    }

    public function enqueue_admin($hook){

    	global $mycred_page_points_management;
    	$pages=array($mycred_page_points_management);
    	$pages=apply_filters('sl_user_search_filter',$pages);
    	if(in_array($hook,$pages)){
			wp_enqueue_script('sl-ajax-20150117',MYCRED_ALI_URL.'assets/js/ajax.js',array('jquery'),MYCRED_ALI_VER,true);
    	}

    }
    public function _menu(){

			global $mycred,$mycred_page_points_management;
			$mycred_backend_recharge_submenu_position=apply_filters('mycred_backend_recharge_submenu_position','users.php');

			$mycred_page_points_management=add_submenu_page(
										'myCRED',
										__('Manage Points',MYCRED_ALI_DOMAIN),
										__('Manage Points',MYCRED_ALI_DOMAIN),
										'manage_options',
										'points_management',
										array($this,'_manage_points')
									);

    }

    public function _manage_points(){

		if ( ! is_user_logged_in() )
			wp_die( __( 'Access Denied', MYCRED_ALI_DOMAIN ) );
		?>
			<style>.mycred-backend-recharge form{padding:16px 0;}</style>
			<div class="wrap" id="mycred-recharge-wrap">
				<h2><?php _e( 'Points Manage', MYCRED_ALI_DOMAIN ); ?></h2>
				<p>
					<?php do_action('mycred_backend_manage_before_form_action'); ?>
				</p>
				<div class="mycred-backend-manage">
				<?php
					$backend_recharge_form=apply_filters('mycred_backend_manage_form_filter',do_shortcode('[mycred_add_sub gift_to="input"]'));
					echo $backend_recharge_form;
				?>
				</div>
				<?php do_action('mycred_backend_manage_after_form_action'); ?>
				<div class="clear"></div>
			</div>
		<?php
    }

    public function sc_init(){


		add_shortcode('mycred_add_sub',array($this,'add_sub'));
    }

 	public function add_sub($atts, $content = ''){

 			global $mycred,$buy_creds;
 			$buy_creds = new myCRED_buyCRED_Module();

 			/*$allow_to_be_purchased=$mycred->buy_creds['types'];*/
 			$allow_to_be_purchased= mycred_get_types();


			extract( shortcode_atts( array(
				'all'=>'true',
				'exclude'=>'',
				'button'  => '',
				'gateway' => '',
				'ctype'   => $allow_to_be_purchased[0],
				'amount'  => '',
				'gift_to' => 'select',
				'login'   => $mycred->template_tags_general( $mycred->buy_creds['login'] ),
			), $atts ) );

			if ( ! is_user_logged_in() ) return '<p class="mycred-buy login">' . $login . '</p>';

			$installed =$buy_creds->get();

			// Prep
			$buy_author = false;
			$buy_member = isset($_GET['gift_to']) ? $_GET['gift_to'] :false;
			$buy_others = false;
			$buy_self = false;
			$classes = array( 'myCRED-manage-form' );


			if (( 'select' == $gift_to )||( 'input' == $gift_to )) {
				$user_id = isset($_GET['gift_to']) ? $_GET['gift_to'] :'';
				$buy_others = true;
			}



			// Button

				$button_label = __( 'Process', MYCRED_ALI_DOMAIN );

			$button_label = $mycred->template_tags_general( $button_label );


			/**
			*	You can custom your own CSS here or using the following filter hook 'mycred_super_shortcode_css'.
			*
			*/
			$style=apply_filters('mycred_super_shortcode_css',
				'
					form.myCRED-manage-form { display: block; min-height: 80px; }
					form.myCRED-manage-form > div { float: left; margin-right: 24px; }
					form.myCRED-manage-form > div label { display: block; }
					#sl_user_search_results {
						position: absolute;
					}
					#sl_user_search_results ul {
						padding: 10px 10px 4px;
						margin: 0;
						background: #f0f0f0;
						border: 1px solid #DFDFDF;
						width: 300px;
						max-height: 200px;
						overflow-y: scroll;
					}



				');

			/*$form.=apply_filters('mycred_recharge_before_form_action','');*/
			$form.='<style type="text/css">'.$style.'</style>

			<div class="mycred-manage">';

			$form.=apply_filters('mycred_frontend_recharge_before_form_filter','');


			/*------------------------reason-------------------------*/
			$form.='<form method="post" action="" class="' . implode( ' ', $classes ) . '">';

			$form .='<div class="reason" style="width:334px;margin-bottom:16px">';
			/* placeholder="'.__('Enter the change reason',MYCRED_ALI_DOMAIN).'" */
			$form .='<label>'.__('Point change reason:',MYCRED_ALI_DOMAIN).'</label><input type="text" name="reason" style="width:100%"  value="'.__('Admin add/sub %point_type% %amount%',MYCRED_ALI_DOMAIN).'">';

			$form .='<div class="clear"></div></div><div class="clear"></div>';

			/*------------------------//reason-------------------------*/


			if ( $buy_author ) {
				$form .= '<input type="hidden" name="post_id" value="' . $post_id . '" />';
			}elseif ( $buy_member ) {
				//$form .= '<input type="hidden" name="gift_to" value="' . $user_id . '" />';
				$user_info = get_userdata($user_id);
				$form .= '<div class="select-to"><label>' . __( 'User name', MYCRED_ALI_DOMAIN ) . ':</label><input type="text" name="gift_to" value="' . $user_info->user_login . '" size="20" /></div>';
			}elseif ( $buy_others ) {
				// Select gift recipient from a drop-down
				if ( $gift_to == 'select' ) {
					$select = '<select name="gift_to">';
					$blog_users = get_users();
					if ( ! empty( $blog_users ) ) {
						foreach ( $blog_users as $blog_user ) {
							if ( $mycred->exclude_user( $blog_user->ID ) || $blog_user->ID === get_current_user_id() ) continue;
							$select .= '<option value="' . $blog_user->ID . '">' . $blog_user->display_name . '</option>';
						}
						unset( $blog_users );
					}
					else {
						$select .= '<option value="">' . __( 'No users found', MYCRED_ALI_DOMAIN ) . '</option>';
					}
					$select .= '</select>';

					/*$select = '<input type="text" name="gift_to" value="" class="pick-user" size="20" />';*/
				}
				// Nominate user
				else {
					$select = '

					<input type="text" name="gift_to" value=""  id="sl-user"  class="pick-user sl-user-search" size="20" autocomplete="off" />
						<img class="sl-ajax waiting" src="'.admin_url('images/wpspin_light.gif').'" style="display: none;"/>
						<div id="sl_user_search_results"></div>

					';
				}
				$form .= '<div class="select-to"><label>' . __( 'User name', MYCRED_ALI_DOMAIN ) . ':</label>' . $select . '</div>';
			}

			// Amount
			$no_of_amounts = 0;
			$minimum = $mycred->number( $mycred->buy_creds['minimum'] );
			if ( ! empty( $amount ) )
				$no_of_amounts = sizeof( array_filter( explode( ',', $amount ), create_function( '$a', 'return !empty($a);' ) ) );
			// Multiple amounts set
			if ( $no_of_amounts > 1 ) {
				// Let user select from this list of amounts
				$amount = explode( ',', $amount );
				$form .= '
							<div class="select-amount">
								<label>' . __( 'Select Amount', MYCRED_ALI_DOMAIN ) . ':</label>
								<select name="amount">';

										foreach ( $amount as $number ) {
											$form .= '<option value="' . $number . '">' . $number . '</option>';
										}

										$form .= '
								</select>
							</div>';
			}elseif ( (int) $no_of_amounts == 1 ) {
				$form .= '<input type="hidden" name="amount" value="' . $mycred->number( $amount ) . '" />';
			}else {
				$form .= '
						<div class="select-amount">
							<label>' . __( 'Amount', MYCRED_ALI_DOMAIN ) . ':</label>
							<input type="text" name="amount" value="' . (int)$minimum . '" size="5" />
						</div>';
			}



			if(('true'==$all)&&(count($allow_to_be_purchased)>1)){

				$point_type_text=__('Select point type',MYCRED_ALI_DOMAIN);


				$exclude_array=explode(',', $exclude);


				$form .='
						<div class="select-amount">
						<label>'.$point_type_text.':</label>
						<select name="type" class="mycred-type-select">';

						$default_type=false;
						foreach($allow_to_be_purchased as $k=>$v){

							if(
								in_array(trim($k),$exclude_array)
								||in_array(trim($v),$exclude_array)
								)
			 					continue;
					/*		if(
								!in_array(trim($k),$allow_to_be_purchased)

								)
			 					continue;*/
			 					if(!$default_type)
			 					$default_type=$k;


							$form .='<option value="'.$k.'">'.$v.'</option>';

						}

						$form .='</select>

						</div>

				';

				/*Related Post ID*/
				$relatedPostId = isset($_GET['post_id']) ? $_GET['post_id'] :false;
				$form .= '<div class="custom-post-id">
								<label>'.__('Related Post ID',MYCRED_ALI_DOMAIN).':</label>
								<input type="text" name="related_post_id" value="'.$relatedPostId.'" />
						  </div>';

			}

			if(!$default_type)$default_type='mycred_default';
			$form .= '
				<input type="hidden" name="token" value="' . wp_create_nonce( 'mycred-manage-points' ) . '" />

				<input type="hidden" name="mycred-manage-points-action_id" value="mycred-manage-points" />
				<input type="hidden" class="hidden-type" name="point-type" value="' . $default_type . '" />
				<div class="clear"></div>
				<div>
				<input type="submit" name="submit" style="margin-top:16px;" value="' . $button_label . '" class="mycred-buy button button-primary button-large btn btn-primary btn-lg" />
				</div>
				<div class="clear clearfix"></div>
			</form>
			<div class="clear"></div>
			</div>';


			$form.=apply_filters('mycred_frontend_manage_after_form_filter','<div class="clear"></div>');
			return $form;

 	}

 	public function process(){


 		if(
 			!isset($_REQUEST['mycred-manage-points-action_id'])
 		/*	||!$_REQUEST['gift_to']*/
 			||!$_REQUEST['amount']
 			||!$_REQUEST['point-type']
 			) return;

/*  wp_die( 'Security check failed.' );*/

 		if(!is_admin()||!is_user_logged_in()) return;

		global $mycred;
		if(!$mycred->can_edit_creds()) return;

		if ( ! wp_verify_nonce( $_REQUEST['token'], 'mycred-manage-points' ) ) {

		     die( 'Security check failed.' );

		} else {




			$amount=$_REQUEST['amount'];

			$type=$_REQUEST['point-type'];
			$point_type = mycred( $type );
			$point_types=mycred_get_types();
			$point_name=$point_types[$type];

			$related_post_id=!empty($_REQUEST['related_post_id'])?$_REQUEST['related_post_id']:false;

			if($related_post_id){

				update_post_meta( (int)$related_post_id, 'post_'.$type, $amount );

				/**
				 * wp_die($related_post_id.'---'.'post_'.$type.'---'.$amount);
				 */
			}
			global $mycred;
			$admin=wp_get_current_user();
			$admin_login=$admin->user_login;
			$add_log=apply_filters('mycred_admin_add_points_log',sprintf(
				__('Admin %1$s Add  %2$s %3$s',MYCRED_ALI_DOMAIN),
				'<strong>'.$admin_login.'</strong>',
				$point_name,
				$amount


				));
			$sub_log=apply_filters('mycred_admin_sub_points_log',sprintf(
				__('Admin %1$s Subtract %2$s %3$s',MYCRED_ALI_DOMAIN),
				'<strong>'.$admin_login.'</strong>',
				$point_name,
				$amount
				));

			$logs= array(
						'add'  => $add_log,
						'sub' => $sub_log,
					);
			$user_login=trim($_REQUEST['gift_to']);
			$related_user=get_user_by('login',$user_login);

			$user_id=$related_user->ID;

			if(!$user_id) {
				echo '<div class="error"><p>'.__('ERROR:User name is wrong? ',MYCRED_ALI_DOMAIN).'</p></div>';

			}

			$reason=false;
			if(isset($_REQUEST['reason'])&&!empty($_REQUEST['reason'])){
				$reason=trim($_REQUEST['reason']);
			}



			$to_user=get_user_by('id',$user_id);
			$to_whom=$to_user->user_login;


			if($amount<0){
					$abs_amount=abs($amount);
					$amount=0-$abs_amount;
					$log=$reason?$reason:$logs['sub'];
					$action_tip=sprintf(__('%1$s %2$s has substract from %3$s',MYCRED_ALI_DOMAIN),$point_name,$abs_amount,'<strong>'.$to_whom.'</strong>');

			}else{
					$log=$reason?$reason:$logs['add'];
					$action_tip=sprintf(__('%1$s %2$s has added to %3$s',MYCRED_ALI_DOMAIN),$point_name,$amount,'<strong>'.$to_whom.'</strong>');
			}



			/*wp_die($reason);*/
			$log=str_replace('%amount%', $abs_amount, $log);
			$log=str_replace('%point_type%', $point_name, $log);

			$data = array( 'ref_type' => 'user' );

			$balance = $point_type->get_users_cred( $user_id, $type );
			$point_type->add_creds(
					'admin_manage',
					$user_id,
					$amount,
					$log,
					'1',
					$data,
					$type
				);

		if($user_id)
			echo '<div class="updated"><p>'.$action_tip.'</p></div>';
		}

 	}


}/*//CLASS*/
global $mycred_manage_points;
$mycred_manage_points = myCRED_Manage_Points::instance();
/**
 * http://www.wpdaxue.com/user-row-actions.html
 */
add_filter( 'post_row_actions', 'mycred_alipay_post_row_actions', 10, 2 );
function mycred_alipay_post_row_actions( $actions, $post ) {
  $user_info = get_userdata($post->post_author);
  if(current_user_can('manage_options')) {
    $actions['add_mycred_points'] = '<a href="'.admin_url().'admin.php?page=points_management&gift_to='.$user_info->ID.'&post_id='.$post->ID.'" target="_blank">'.__('Reward',MYCRED_ALI_DOMAIN).'</a>';
  }
  return $actions;
}
/*ALL DONE.*/
?>