<?php
if(!defined('ABSPATH')){ exit; }

if(!class_exists('MYCRED_SUPER_SORTCODE')):

	final class MYCRED_SUPER_SORTCODE{

			    protected static $_instance = null;

			    public static function instance() {
			        if ( is_null( self::$_instance ) ) {
			            self::$_instance = new self();
			        }
			        return self::$_instance;
			    }


			    public function __clone() {
			        _doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?', MYCRED_ALI_DOMAIN ), '1.0' );
			    }

			    public function __wakeup() {
			        _doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?', MYCRED_ALI_DOMAIN ), '1.0' );
			    }

   				 public function __construct() {

   				 	add_action('init',array($this,'reg'),99);
   				 	/*add_shortcode('mycred_go',array($this,'go'));*/

			 	}

			 	public function reg(){

			 		add_shortcode('mycred_go',array($this,'render_shortcode_form'));
			 		/*add_shortcode('mycred_buy',array($this,'render_shortcode_form'));*/

			 		/*mycred_front_enqueue*/
			 		add_action('mycred_front_enqueue',array($this,'enqueue'));
			 		/*mycred_admin_enqueue*/
			 		add_action('mycred_admin_enqueue',array($this,'enqueue'));
			 	}

				/**
				*	Generate a point purchase form for myCRED with point types.
				*
				*	@param string:
				*				all=true:the select options will output all your installed myCRED point types,this also is its default value.
				*
				*				exclude: give it a value of the point type you want to exclude from the options.
				*
				*				other parameters are same as the parameters of myCRED.
				*
				*	@return string.
				*	@package myCRED:Alipay-buyCRED Gateway
				*	@since 1.0
				*	@author suifengtec
				*/

			 	public function render_shortcode_form($atts, $content = ''){

			 			global $mycred,$buy_creds;
			 			$buy_creds = new myCRED_buyCRED_Module();

			 			$allow_to_be_purchased=$mycred->buy_creds['types'];

						extract( shortcode_atts( array(
							'all'=>'true',
							'exclude'=>'',
							'button'  => '',
							'gateway' => '',
							'ctype'   => $allow_to_be_purchased[0],
							'amount'  => '',
							'gift_to' => '',
							'login'   => $mycred->template_tags_general( $mycred->buy_creds['login'] ),
						), $atts ) );

						if ( ! is_user_logged_in() ) return '<p class="mycred-buy login">' . $login . '</p>';

						$installed =$buy_creds->get();

						if ( empty( $installed ) ) return __( 'No gateways installed.', MYCRED_ALI_DOMAIN );
						if ( ! empty( $gateway ) && ! array_key_exists( $gateway, $installed ) ) return __( 'Gateway does not exist.', MYCRED_ALI_DOMAIN );

						if ( empty( $buy_creds->active ) ) return __( 'No active gateways found.', MYCRED_ALI_DOMAIN );

						if ( ! empty( $gateway ) && ! $buy_creds->is_active( $gateway ) ) return __( 'The selected gateway is not active.', MYCRED_ALI_DOMAIN );
						// Prep
						$buy_author = false;
						$buy_member = false;
						$buy_others = false;
						$buy_self = false;
						$classes = array( 'myCRED-buy-form' );

						// Gifting is enabled
						if ( $mycred->buy_creds['gifting']['authors'] ) {

							// This is a gift to the post author
							if ( $gift_to == 'author' ) {
								global $post;
								$user_id = $post->post_author;
								$buy_author = true;
							}

							// This is a gift and we want to select who gets this
							elseif ( $gift_to == 'select' ) {
								$user_id = '';
								$buy_others = true;
							}

							// This is a gift to a specific user that we have provided an id for
							elseif ( is_numeric( $gift_to ) ) {
								$user_id = absint( $gift_to );
								$buy_member = true;
							}

							// This is a purchase for ourselves
							else {
								$user_id = get_current_user_id();
								$buy_self = true;
							}

						}else {
								$user_id = get_current_user_id();
								$buy_self = true;
						}


						// Button
						if ( ! empty( $gateway ) && isset( $installed[ $gateway ]['title'] ) && empty( $button ) )
							$button_label = __( 'Buy with %gateway%', MYCRED_ALI_DOMAIN );

						elseif ( ! empty( $button ) )
							$button_label = $button;

						else
							$button_label = __( 'Buy Now', MYCRED_ALI_DOMAIN );

						$button_label = $mycred->template_tags_general( $button_label );

						if ( ! empty( $gateway ) ) {
							$gateway_name = explode( ' ', $installed[ $gateway ]['title'] );
							$button_label = str_replace( '%gateway%', $gateway_name[0], $button_label );
							$classes[] = $gateway_name[0];
						}


						/**
						*	You can custom your own CSS here or using the following filter hook 'mycred_super_shortcode_css'.
						*
						*/
						$style=apply_filters('mycred_super_shortcode_css',
							'
								form.myCRED-buy-form { display: block; min-height: 80px; }
								form.myCRED-buy-form > div { float: left; margin-right: 24px; }
								form.myCRED-buy-form > div label { display: block; }


							');

						/*$form.=apply_filters('mycred_recharge_before_form_action','');*/
						$form.='<style type="text/css">'.$style.'</style>
						<div class="mycred-recharge">';

						$form.=apply_filters('mycred_frontend_recharge_before_form_filter','');

						$form.='<form method="post" action="" class="' . implode( ' ', $classes ) . '">';
						if ( $buy_author ) {
							$form .= '<input type="hidden" name="post_id" value="' . $post_id . '" />';
						}elseif ( $buy_member ) {
							$form .= '<input type="hidden" name="gift_to" value="' . $user_id . '" />';
						}elseif ( $buy_others ) {
							// Select gift recipient from a drop-down
							if ( $gift_to == 'select' ) {
								$select = '<select name="gift_to">';
								$blog_users = get_users();
								if ( ! empty( $blog_users ) ) {
									foreach ( $blog_users as $blog_user ) {
										if ( $mycred->exclude_user( $blog_user->ID ) || $blog_user->ID === get_current_user_id() ) continue;
										$select .= '<option value="' . $blog_user->ID . '">' . $blog_user->display_name . '</option>';
									}
									unset( $blog_users );
								}
								else {
									$select .= '<option value="">' . __( 'No users found', MYCRED_ALI_DOMAIN ) . '</option>';
								}
								$select .= '</select>';
							}
							// Nominate user
							else {
								$select = '<input type="text" name="gift_to" value="" class="pick-user" size="20" />';
							}
							$form .= '<div class="select-to"><label>' . __( 'To', MYCRED_ALI_DOMAIN ) . ':</label>' . $select . '</div>';
						}

						// Amount
						$no_of_amounts = 0;
						$minimum = $mycred->number( $mycred->buy_creds['minimum'] );
						if ( ! empty( $amount ) )
							$no_of_amounts = sizeof( array_filter( explode( ',', $amount ), create_function( '$a', 'return !empty($a);' ) ) );
						// Multiple amounts set
						if ( $no_of_amounts > 1 ) {
							// Let user select from this list of amounts
							$amount = explode( ',', $amount );
							$form .= '
										<div class="select-amount">
											<label>' . __( 'Select Amount', MYCRED_ALI_DOMAIN ) . ':</label>
											<select name="amount">';

													foreach ( $amount as $number ) {
														$form .= '<option value="' . $number . '">' . $number . '</option>';
													}

													$form .= '
											</select>
										</div>';
						}elseif ( (int) $no_of_amounts == 1 ) {
							$form .= '<input type="hidden" name="amount" value="' . $mycred->number( $amount ) . '" />';
						}else {
							$form .= '
									<div class="select-amount">
										<label>' . __( 'Amount', MYCRED_ALI_DOMAIN ) . ':</label>
										<input type="text" name="amount" value="' . $minimum . '" size="5" /><br />
										<em>' . __( 'min.', MYCRED_ALI_DOMAIN ) . ' ' . (int)$minimum . '</em>
									</div>';
						}



						if(('true'==$all)&&(count($allow_to_be_purchased)>1)){
							$point_type_text=__('Select point type',MYCRED_ALI_DOMAIN);


							$exclude_array=explode(',', $exclude);


							$form .='
									<div class="select-amount">
									<label>'.$point_type_text.':</label>
									<select name="type" class="mycred-type-select">';
									$point_types = mycred_get_types();



									foreach($point_types as $k=>$v){

										if(
											in_array(trim($k),$exclude_array)
											||in_array(trim($v),$exclude_array)
											)
						 					continue;
										if(
											!in_array(trim($k),$allow_to_be_purchased)

											)
						 					continue;
										$form .='<option value="'.$k.'">'.$v.'</option>';

									}

									$form .='</select>

									</div>

							';
						}

						// No gateway nominated - User needs to select
						if ( $gateway == '' ) {
							$form .= '
									<div class="select-gateway">
										<label>' . __( 'Select Gateway', MYCRED_ALI_DOMAIN ) . ':</label>
										<select name="mycred_buy">';

												foreach ( $installed as $gateway_id => $data ) {
													if ( ! $buy_creds->is_active( $gateway_id ) ) continue;
													$form .= '<option value="' . $gateway_id . '">' . $data['title'] . '</option>';
												}

												$form .= '
										</select>
									</div>';
						}else {
							$form .= '<input type="hidden" name="mycred_buy" value="' . $gateway . '" />';
						}

						$form .= '
							<input type="hidden" name="token" value="' . wp_create_nonce( 'mycred-buy-creds' ) . '" />
							<input type="hidden" name="transaction_id" value="' . strtoupper( wp_generate_password( 6, false, false ) ) . '" />
							<input type="hidden" class="hidden-type" name="ctype" value="' . $ctype . '" />
							<input type="submit" name="submit" style="margin-top:18px;" value="' . $button_label . '" class="mycred-buy button button-primary button-large btn btn-primary btn-lg" />
							<div class="clear clearfix"></div>
						</form>
						<div class="clear"></div>
						</div>
						';
						$form.=apply_filters('mycred_frontend_recharge_after_form_filter','<div class="clear"></div>');
						return $form;

			 	}

			 	public function enqueue(){

			 			wp_enqueue_script('mycred-s-sc',MYCRED_ALI_URL.'assets/js/sc.js',array('jquery'),MYCRED_ALI_VER,true);


			 	}

	}

	global $mycred_s_sc;
	$mycred_s_sc = MYCRED_SUPER_SORTCODE::instance();

endif;
/*DONE*/