/**
*	This script is just for 'myCRED:Alipay-buyCRED Gateway'.
*
*/
;jQuery(function(){jQuery('.mycred-type-select').each(function(){jQuery(this).change(function(){jQuery('.hidden-type').val(jQuery(this).val());});});});