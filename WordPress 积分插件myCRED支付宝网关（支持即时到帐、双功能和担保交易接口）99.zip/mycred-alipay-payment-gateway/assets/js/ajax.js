/*all right received by suifengtec suoling.net*/
jQuery(document).ready(function($) {
	$('.sl-user-search').keyup(function() {
		var user_search = $(this).val();
		$('.sl-ajax').show();
		data = {
			action: 'sl_search_users',
			user_name: user_search,
			sl_action_id: 'sl_user_search_mycred_point_management'
		};

		$.ajax({
         type: "POST",
         data: data,
         dataType: "json",
         url: ajaxurl,
			success: function (search_response) {

				$('.sl-ajax').hide();

				$('#sl_user_search_results').html('');

				if(search_response.id == 'found') {
					$(search_response.results).appendTo('#sl_user_search_results');
				} else if(search_response.id == 'fail') {
					$('#sl_user_search_results').text(search_response.msg);
				}
			}
		});
	});

	$('body').on('click.slSelectUser', '#sl_user_search_results a', function(e) {
		e.preventDefault();
		var login = $(this).data('login');
		$('#sl-user').val(login);
		$('#sl_user_search_results').html('');
	});

});