var weisaytheme_latest_version = "1.4";
var downloand_add = "http://sharepic.googlecode.com/files/weisaysimple.zip"
var author_add = "http://www.weisay.com/blog/wordpress-theme-weisay-simple.html"