<form role="search" method="get" id="searchform" class="search-form" action="<?php bloginfo('url');?>">
	<div class="right"><button type="submit"></button><input type="text" name="s" id="s" class="search-input"  value="" placeholder="站内搜索"></div>
</form>