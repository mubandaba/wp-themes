(function( $ ) {
    'use strict';

    /**
	 * Markup compatibility issue for form fields by default
	 * Comment form
	 */	
    $( 'input[name="password"]').addClass( 'form-control' );
    $( 'input[name="author"]').addClass( 'form-control' );
    $( 'input[name="email"]').addClass( 'form-control' );
    $( 'input[name="url"]').addClass( 'form-control' );
	
})( jQuery );
