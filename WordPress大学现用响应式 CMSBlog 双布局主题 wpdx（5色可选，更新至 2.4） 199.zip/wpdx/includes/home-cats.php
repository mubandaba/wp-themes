<?php
function get_home_cats( $cat_data ){ ?>
<?php
global $count2 ;
$Cat_ID = $cat_data['id'];
$Posts = $cat_data['number'];
$order = $cat_data['order'];
$thumb = $cat_data['thumb'];
$post_ids = '';
if($cat_data['post_ids'] || $cat_data['post_ids'] !='')$post_ids = explode(',', $cat_data['post_ids'] );
if($post_ids){
	$args = array( 'post__in' => $post_ids ,'posts_per_page'=> $Posts , 'orderby'=>'post__in','ignore_sticky_posts' => 1 ,'no_found_rows' => 1);
	$cat_query = new WP_Query( $args );
}elseif($Cat_ID){
	if( $order == 'rand') {
		$rand ="&orderby=rand";
		$cat_query = new WP_Query('no_found_rows=true&cat='.$Cat_ID.'&posts_per_page='.$Posts.$rand);
	} else {
		$cat_query = new WP_Query('no_found_rows=true&cat='.$Cat_ID.'&posts_per_page='.$Posts);
	}
}
$cat_title = $cat_data['title'] ? $cat_data['title'] : get_the_category_by_ID($Cat_ID);
$count = 0;
$home_layout = $cat_data['style'];
$icon = $cat_data['icon'] ? $cat_data['icon']:'fa-list';
$more_text = $cat_data['more_text'] ? $cat_data['more_text']:'More';
$more_url = $cat_data['more_url'];
$who = $cat_data['who'];
if( $who == 'logged' && !is_user_logged_in()):
	// return none;
elseif( $who == 'anonymous' && is_user_logged_in()):
	// return none;
else:
?>
<?php if( $home_layout == '3c'): ?>
	<section class="span4 column2">
		<div class="widget-box">
			<div class="widget-title">
				<?php if($more_url): ?>
					<span class="more"><a target="_blank" href="<?php echo $more_url; ?>"><?php echo $more_text; ?></a></span>
				<?php endif; ?>
				<span class="icon"> <i class="fa fa <?php echo $icon; ?> fa-fw fa-fw"></i> </span>
				<h2><a href="<?php echo get_category_link( $Cat_ID ); ?>" <?php echo cmp_target_blank();?>><?php echo $cat_title ; ?></a></h2>
			</div>
			<div class="widget-content">
				<?php if($cat_query->have_posts()): ?>
					<ul>
						<?php while ( $cat_query->have_posts() ) : $cat_query->the_post();?>
							<?php if ( $thumb == '' || $thumb == 'n') : ?>
								<li class="other-news">
									<span><?php the_time('m-d'); ?></span>
									<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><i class="fa fa-angle-right"></i><?php the_title(); ?></a>
								</li>
							<?php else: ?>
								<li class="other-posts">
									<?php if ( $thumb == 'a') : ?>
										<a class="post-thumbnail" href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) )?>" title="<?php sprintf( esc_attr__( 'View all posts by %s', 'cmp' ), get_the_author() ) ?>" <?php echo cmp_target_blank();?>><?php echo get_avatar( get_the_author_meta('user_email'), 45 )?>
										</a>
									<?php elseif($thumb == 't'): ?>
										<a class="post-thumbnail" href="<?php the_permalink(); ?>" title="<?php printf( esc_attr__( 'Permalink to %s', 'cmp' ), the_title_attribute( 'echo=0' ) ); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><?php cmp_post_thumbnail(45,45) ?>
										</a>
									<?php endif; ?>
									<h3><a href="<?php the_permalink(); ?>" title="<?php printf( esc_attr__( 'Permalink to %s', 'cmp' ), the_title_attribute( 'echo=0' ) ); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><?php the_title(); ?></a></h3>
									<p class="post-meta">
										<span><i class="fa fa-clock-o fa-fw"></i><?php if (function_exists('cmp_get_time')) cmp_get_time();?></span>
										<span><i class="fa fa-eye fa-fw"></i><?php if(function_exists('the_views')) { the_views(); } ?></span>
										<span><i class="fa fa-comment-o fa-fw"></i><?php comments_popup_link('0','1','%' ); ?></span>
									</p>
									<div class="clear"></div>
								</li>
							<?php endif; ?>
						<?php endwhile;?>
					</ul>
					<div class="clear"></div>
				<?php endif; wp_reset_query();?>
			</div><!-- .cat-box-content /-->
		</div>
	</section> <!-- Three Columns -->
<?php elseif( $home_layout == '2c'): ?>
	<?php $count2++; ?>
	<section class="span6 column2 <?php if($count2 == 1 || $count2 == 3 ) { echo 'first-column'; $count2=1; } ?>">
		<div class="widget-box">
			<div class="widget-title">
				<?php if($more_url): ?>
					<span class="more"><a target="_blank" href="<?php echo $more_url; ?>"><?php echo $more_text; ?></a></span>
				<?php endif; ?>
				<span class="icon"> <i class="fa <?php echo $icon; ?> fa-fw"></i> </span>
				<h2><a href="<?php echo get_category_link( $Cat_ID ); ?>" <?php echo cmp_target_blank();?>><?php echo $cat_title ; ?></a></h2>
			</div>
			<div class="widget-content">
				<?php if($cat_query->have_posts()): ?>
					<ul>
						<?php while ( $cat_query->have_posts() ) : $cat_query->the_post(); $count ++ ;?>
							<?php if($count == 1) : ?>
								<li class="first-posts">
									<a class="post-thumbnail" href="<?php the_permalink(); ?>" title="<?php printf( esc_attr__( 'Permalink to %s', 'cmp' ), the_title_attribute( 'echo=0' ) ); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><?php cmp_post_thumbnail(330,200) ?></a>
									<h3><a class="first-posts-title" href="<?php the_permalink(); ?>" title="<?php printf( esc_attr__( 'Permalink to %s', 'cmp' ), the_title_attribute( 'echo=0' ) ); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><?php the_title(); ?></a></h3>
									<p class="summary">
										<?php cmp_excerpt_home() ?>
									</p>
									<p class="post-meta">
										<span><i class="fa fa-clock-o fa-fw"></i><?php if (function_exists('cmp_get_time')) cmp_get_time();?></span>
										<span><i class="fa fa-eye fa-fw"></i><?php if(function_exists('the_views')) { the_views(); } ?></span>
										<span><i class="fa fa-comment-o fa-fw"></i><?php comments_popup_link('0','1','%' ); ?></span>
									</p>
								</li>
								<div class="clear"></div>
							<?php else: ?>
								<?php if ( $thumb == '' || $thumb == 'n') : ?>
									<li class="other-news">
										<span><?php the_time('m-d'); ?></span>
										<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><i class="fa fa-angle-right"></i><?php the_title(); ?></a>
									</li>
								<?php else: ?>
									<li class="other-posts">
										<?php if ( $thumb == 'a') : ?>
											<a class="post-thumbnail" href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) )?>" title="<?php sprintf( esc_attr__( 'View all posts by %s', 'cmp' ), get_the_author() ) ?>" <?php echo cmp_target_blank();?>><?php echo get_avatar( get_the_author_meta('user_email'), 45 )?>
											</a>
										<?php elseif($thumb == 't'): ?>
											<a class="post-thumbnail" href="<?php the_permalink(); ?>" title="<?php printf( esc_attr__( 'Permalink to %s', 'cmp' ), the_title_attribute( 'echo=0' ) ); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><?php cmp_post_thumbnail(45,45) ?>
											</a>
										<?php endif; ?>
										<h3><a href="<?php the_permalink(); ?>" title="<?php printf( esc_attr__( 'Permalink to %s', 'cmp' ), the_title_attribute( 'echo=0' ) ); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><?php the_title(); ?></a></h3>
										<p class="post-meta">
											<span><i class="fa fa-clock-o fa-fw"></i><?php if (function_exists('cmp_get_time')) cmp_get_time();?></span>
											<span><i class="fa fa-eye fa-fw"></i><?php if(function_exists('the_views')) { the_views(); } ?></span>
											<span><i class="fa fa-comment-o fa-fw"></i><?php comments_popup_link('0','1','%' ); ?></span>
										</p>
										<div class="clear"></div>
									</li>
								<?php endif; ?>
							<?php endif; ?>
						<?php endwhile;?>
					</ul>
					<div class="clear"></div>
				<?php endif; wp_reset_query();?>
			</div><!-- .cat-box-content /-->
		</div>
	</section> <!-- Two Columns -->
<?php elseif( $home_layout == '1c' ):   ?>
	<section class="span12 two-row">
		<div class="widget-box">
			<div class="widget-title">
				<?php if($more_url): ?>
					<span class="more"><a target="_blank" href="<?php echo $more_url; ?>"><?php echo $more_text; ?></a></span>
				<?php endif; ?>
				<span class="icon"> <i class="fa <?php echo $icon; ?> fa-fw"></i> </span>
				<h2><a href="<?php echo get_category_link( $Cat_ID ); ?>" <?php echo cmp_target_blank();?>><?php echo $cat_title ; ?></a></h2>
			</div>
			<div class="widget-content">
				<?php if($cat_query->have_posts()): ?>
					<ul>
						<?php while ( $cat_query->have_posts() ) : $cat_query->the_post(); $count ++ ;?>
							<?php if($count == 1 || $count == 2) : ?>
								<li class="span6 first-posts">
									<div class="inner-content">
										<a href="<?php the_permalink(); ?>" class="post-thumbnail" title="<?php printf( esc_attr__( 'Permalink to %s', 'cmp' ), the_title_attribute( 'echo=0' ) ); ?>" rel="bookmark" <?php echo cmp_target_blank();?>>
											<?php cmp_post_thumbnail(330,200) ?>
										</a>
										<div class="first-content">
											<h3><a href="<?php the_permalink(); ?>" title="<?php printf( esc_attr__( 'Permalink to %s', 'cmp' ), the_title_attribute( 'echo=0' ) ); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><?php the_title(); ?></a></h3>
											<p class="summary">
												<?php cmp_excerpt_home() ?>
											</p>
											<p class="post-meta">
												<span><i class="fa fa-clock-o fa-fw"></i><?php if (function_exists('cmp_get_time')) cmp_get_time();?></span>
												<span><i class="fa fa-eye fa-fw"></i><?php if(function_exists('the_views')) { the_views(); } ?></span>
												<span><i class="fa fa-comment-o fa-fw"></i><?php comments_popup_link('0','1','%' ); ?></span>
											</p>
										</div>
										<div class="clear"></div>
									</div>
								</li><!-- .first-posts -->
							<?php else: ?>
								<?php if($count == 3) echo '<div class="clear"></div>' ;?>
								<?php if ( $thumb == '' || $thumb == 'n') : ?>
									<li class="span6 other-news">
										<span><?php the_time('m-d'); ?></span>
										<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><i class="fa fa-angle-right"></i><?php the_title(); ?></a>
									</li>
								<?php else: ?>
									<li class="span6 other-posts">
										<?php if ( $thumb == 'a') : ?>
											<a class="post-thumbnail" href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) )?>" title="<?php sprintf( esc_attr__( 'View all posts by %s', 'cmp' ), get_the_author() ) ?>" <?php echo cmp_target_blank();?>><?php echo get_avatar( get_the_author_meta('user_email'), 45 )?>
											</a>
										<?php elseif($thumb == 't'): ?>
											<a class="post-thumbnail" href="<?php the_permalink(); ?>" title="<?php printf( esc_attr__( 'Permalink to %s', 'cmp' ), the_title_attribute( 'echo=0' ) ); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><?php cmp_post_thumbnail(45,45) ?>
											</a>
										<?php endif; ?>
										<h3><a href="<?php the_permalink(); ?>" title="<?php printf( esc_attr__( 'Permalink to %s', 'cmp' ), the_title_attribute( 'echo=0' ) ); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><?php the_title(); ?></a></h3>
										<p class="post-meta">
											<span><i class="fa fa-clock-o fa-fw"></i><?php if (function_exists('cmp_get_time')) cmp_get_time();?></span>
											<span><i class="fa fa-eye fa-fw"></i><?php if(function_exists('the_views')) { the_views(); } ?></span>
											<span><i class="fa fa-comment-o fa-fw"></i><?php comments_popup_link('0','1','%' ); ?></span>
										</p>
										<div class="clear"></div>
									</li>
								<?php endif; ?>
							<?php endif; ?>
						<?php endwhile;?>
					</ul>
					<div class="clear"></div>
				<?php endif; wp_reset_query();?>
			</div>
		</div><!-- .cat-box-content /-->
	</section><!-- Wide Box -->
<?php else :   //************** list **********************************************************************************  ?>
	<section class="span12 three-row">
		<div class="widget-box">
			<div class="widget-title">
				<?php if($more_url): ?>
					<span class="more"><a target="_blank" href="<?php echo $more_url; ?>"><?php echo $more_text; ?></a></span>
				<?php endif; ?>
				<span class="icon"> <i class="fa <?php echo $icon; ?> fa-fw"></i> </span>
				<h2><a href="<?php echo get_category_link( $Cat_ID ); ?>" <?php echo cmp_target_blank();?>><?php echo $cat_title ; ?></a></h2>
			</div>
			<div class="widget-content">
				<?php if($cat_query->have_posts()): ?>
					<ul>
						<?php while ( $cat_query->have_posts() ) : $cat_query->the_post(); $count ++ ;?>
							<?php if($count == 1 || $count == 2 || $count == 3) : ?>
								<li class="span4 first-posts">
									<a href="<?php the_permalink(); ?>" class="post-thumbnail" title="<?php printf( esc_attr__( 'Permalink to %s', 'cmp' ), the_title_attribute( 'echo=0' ) ); ?>" rel="bookmark" <?php echo cmp_target_blank();?>>
										<?php cmp_post_thumbnail(330,200) ?>
									</a>
									<h3><a href="<?php the_permalink(); ?>" title="<?php printf( esc_attr__( 'Permalink to %s', 'cmp' ), the_title_attribute( 'echo=0' ) ); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><?php the_title(); ?></a></h3>
									<p class="summary">
										<?php cmp_excerpt_home() ?>
									</p>
									<p class="post-meta">
										<span><i class="fa fa-clock-o fa-fw"></i><?php if (function_exists('cmp_get_time')) cmp_get_time();?></span>
										<span><i class="fa fa-eye fa-fw"></i><?php if(function_exists('the_views')) { the_views(); } ?></span>
										<span><i class="fa fa-comment-o fa-fw"></i><?php comments_popup_link('0','1','%' ); ?></span>
									</p>
									<div class="clear"></div>
								</li><!-- .first-posts -->
								<?php if($count == 3) echo '<div class="clear bt10"></div>' ;?>
							<?php else: ?>
								<?php if ( $thumb == '' || $thumb == 'n') : ?>
									<li class="span4 other-news">
										<span><?php the_time('m-d'); ?></span>
										<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><i class="fa fa-angle-right"></i><?php the_title(); ?></a>
									</li>
								<?php else: ?>
									<li class="span4 other-posts">
										<?php if ( $thumb == 'a') : ?>
											<a class="post-thumbnail" href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) )?>" title="<?php sprintf( esc_attr__( 'View all posts by %s', 'cmp' ), get_the_author() ) ?>" <?php echo cmp_target_blank();?>><?php echo get_avatar( get_the_author_meta('user_email'), 45 )?>
											</a>
										<?php elseif($thumb == 't'): ?>
											<a class="post-thumbnail" href="<?php the_permalink(); ?>" title="<?php printf( esc_attr__( 'Permalink to %s', 'cmp' ), the_title_attribute( 'echo=0' ) ); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><?php cmp_post_thumbnail(45,45) ?>
											</a>
										<?php endif; ?>
										<h3><a href="<?php the_permalink(); ?>" title="<?php printf( esc_attr__( 'Permalink to %s', 'cmp' ), the_title_attribute( 'echo=0' ) ); ?>" rel="bookmark" <?php echo cmp_target_blank();?>><?php the_title(); ?></a></h3>
										<p class="post-meta">
											<span><i class="fa fa-clock-o fa-fw"></i><?php if (function_exists('cmp_get_time')) cmp_get_time();?></span>
											<span><i class="fa fa-eye fa-fw"></i><?php if(function_exists('the_views')) { the_views(); } ?></span>
											<span><i class="fa fa-comment-o fa-fw"></i><?php comments_popup_link('0','1','%' ); ?></span>
										</p>
									</li>
								<?php endif; ?>
							<?php endif; ?>
						<?php endwhile;?>
					</ul>
					<div class="clear"></div>
				<?php endif; wp_reset_query();?>
			</div>
		</div><!-- .cat-box-content /-->
	</section><!-- List Box -->
<?php endif; ?>
<?php endif;//$who ?>
<?php } ?>