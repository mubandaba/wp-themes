<div id="top-bar" class="navbar navbar-inverse">
    <div id="logo">
        <hgroup itemscope itemtype="http://schema.org/WPHeader">
            <?php if (is_home()) { ?>
            <h1 class="logoimg"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php bloginfo( 'name' ) ?></a></h1>
            <?php  } else { ?>
            <div class="logoimg"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php bloginfo( 'name' ) ?></a></div>
            <?php } ?>
        </hgroup>
    </div>
    <ul class="nav user-nav">
        <?php
        $url_this = 'http://'.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"];
        if( cmp_get_option('show_login')):
            if(is_user_logged_in()){
                // if(class_exists("fep_main_class")){
                //     global $FrontEndPM;
                //     @$numNew = $FrontEndPM->getNewMsgs();
                //     $pmtip = '<span class="label label-important tip-bottom" title="'.$numNew.__('unread messages','cmp').'">'.$numNew.'</span>';
                // }
                ?>
                <li class="dropdown" id="menu-messages"><a href="#" data-toggle="dropdown" data-target="#menu-messages" class="dropdown-toggle"><i class="fa fa-fw fa-user"></i> <span class="text"><?php _e('Manage','cmp'); ?></span><?php //if(@$numNew && @$numNew != 0) echo $pmtip; ?><b class="caret"></b></a>
                    <ul class="dropdown-menu user-dashboard">
                        <?php if(current_user_can( 'manage_options' )) {
                            if(function_exists('wp_nav_menu')) wp_nav_menu(array('container' => false, 'items_wrap' => '%3$s', 'theme_location' => 'admin-menu', 'fallback_cb' => 'cmp_nav_fallback','walker' => new wp_bootstrap_navwalker()));
                        }
                        if(function_exists('wp_nav_menu') && cmp_get_option('user_menu')) wp_nav_menu(array('container' => false, 'items_wrap' => '%3$s', 'theme_location' => 'user-menu', 'fallback_cb' => 'cmp_nav_fallback','walker' => new wp_bootstrap_navwalker()));
                        ?>
                    </ul>
                </li>
                <li class="user-btn"><a href="<?php echo wp_logout_url($url_this); ?>" title="<?php _e('Logout','cmp'); ?>" rel="nofollow"><i class="fa fa-sign-out fa-fw"></i><span class="text"><?php _e('Logout','cmp'); ?></span></a></li>
                <?php
            } else {
                if(cmp_get_option('password_url')){
                    $password_url = htmlspecialchars_decode(cmp_get_option('password_url')) ;
                }else{
                    $password_url = wp_lostpassword_url();
                }
                ?>
                <li  class="dropdown" id="profile-messages" ><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle popup-login"><i class="fa fa-sign-in fa-fw"></i><span class="text"><?php _e('Login','cmp'); ?></span><b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <form class="user-login" name="loginform" action="<?php echo wp_login_url($url_this); ?>" method="post">
                            <li><i class="fa fa-user fa-fw"></i><input class="ipt" placeholder="<?php _e('Username','cmp') ?>" type="text" name="log" value="" size="18"></li>
                            <li><i class="fa fa-lock fa-fw"></i><input class="ipt" placeholder="<?php _e('Password','cmp') ?>" type="password" name="pwd" value="" size="18"></li>
                            <li><input name="rememberme" id="rememberme" type="checkbox" checked="checked" value="forever" /> <?php esc_attr_e( 'Remember Me' ); ?></li>
                            <li class="btn"><input class="login-btn" type="submit" name="submit" value="<?php _e('Login','cmp'); ?>"></li>
                            <li><a class="pw-reset" rel="nofollow" href="<?php echo $password_url; ?>"><i class="fa fa-lightbulb-o fa-fw"></i> <?php _e('Lost password ?','cmp'); ?></a></li>
                            <?php if(class_exists('WPUF_Login')): ?>
                                <input type="hidden" name="redirect_to" value="" />
                                <input type="hidden" name="wpuf_login" value="true" />
                                <input type="hidden" name="action" value="login" />
                                <?php wp_nonce_field( 'wpuf_login_action' ); ?>
                            <?php endif; ?>
                        </form>
                        <?php if(function_exists('open_social_login_form')) open_social_login_form(); ?>
                    </ul>
                </li>
                <?php
                if(cmp_get_option('register_url')){
                    $register_url = htmlspecialchars_decode(cmp_get_option('register_url')) ;
                }else{
                    $register_url = wp_registration_url();
                }
                if(get_option('users_can_register') == '1' ) :?>
                <li class="user-btn user-reg"><a class="popup-register" href="<?php echo $register_url; ?>" title="<?php _e('Register','cmp'); ?>" rel="nofollow"><i class="fa fa-key fa-fw"></i><span class="text"><?php _e('Register','cmp'); ?></span></a></li>
            <?php endif; ?>
            <?php }
            endif; ?>
            <?php
            if( cmp_get_option('show_qqqun')){
                echo '<li id="qqqun" class="other-nav"><a target="_blank" title="'.cmp_get_option('qqqun_title').'" href="'.cmp_get_option('qqqun_url').'" rel="nofollow"><i class="fa fa-group fa-fw"></i> '.__('Join QQ group','cmp').'</a></li>';
            }
            if( cmp_get_option('show_qq')){
                echo '<li id="qq" class="other-nav">'.htmlspecialchars_decode( cmp_get_option('qq_code') ).'</li>';
            }
            if( cmp_get_option('show_wx') && cmp_get_option('weixin_img')){
                echo '<li class="wx other-nav"><a href="#" rel="nofollow"><i class="fa fa-qrcode fa-fw"></i> '.__('Weixin','cmp').'<span class="weixin"><img src="'.cmp_get_option('weixin_img').'" alt="'.__('Weixin','cmp').'"></span></a></li>';
            }
            if( cmp_get_option('show_weibo')){
                echo '<li id="swb" class="other-nav"><wb:follow-button uid="'.cmp_get_option('weibo_uid').'" type="'.cmp_get_option('weibo_type').'" height="24"></wb:follow-button></li>';
            }
            if( cmp_get_option('show_qqweibo')){
                echo'<li id="qwb" class="other-nav"><iframe src="http://follow.v.t.qq.com/index.php?c=follow&a=quick&name='.cmp_get_option('qqweibo_name').'&style=5&t='.cmp_get_option('qqweibo_t').'&f='.cmp_get_option('qqweibo_f').'" frameborder="0" scrolling="auto" width="150" height="24" marginwidth="0" marginheight="0" allowtransparency="true"></iframe></li>';
            }
            ?>
        </ul>
        <?php
        if(cmp_get_option( 'baidu_search' )){
            $action = 'http://'.cmp_get_option( 'search_domain' ).'/cse/search';
            $search_id = '<input type="hidden" name="s" value="'.cmp_get_option( 'search_id' ).'">';
            $name = 'q';
        }else{
            $action = home_url();
            $search_id = '';
            $name = 's';
        }
        ?>
        <div id="search">
            <div class="toggle-search">
                <i class="fa fa-search fa-white fa-fw"></i>
            </div>
            <div class="search-expand">
                <div class="search-expand-inner">
                    <form method="get" class="searchform themeform" action="<?php echo $action ?>" <?php if(cmp_get_option( 'search_target' )) echo 'target="_blank"'; ?>>
                        <div>
                            <?php echo $search_id ?>
                            <input type="text" class="search" name="<?php echo $name ?>" onblur="if(this.value=='')this.value='<?php _e('Input and press Enter','cmp'); ?>';" onfocus="if(this.value=='<?php _e('Input and press Enter','cmp'); ?>')this.value='';" value="<?php _e('Input and press Enter','cmp'); ?>" x-webkit-speech />
                            <button type="submit" id="submit-bt" title="<?php _e('Search' , 'cmp'); ?>"><i class="fa fa-search"></i></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php if(cmp_get_option('theme_layout') == 'vertical' ) get_template_part('includes/ad-top-right' );?>
    </div>