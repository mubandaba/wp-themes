<?php
function get_home_scroll( $cat_data ){
global $post;
$Cat_ID = $cat_data['id'];
$Posts = $cat_data['number'];
$Box_Title = $cat_data['title'] ? $cat_data['title'] : get_the_category_by_ID($Cat_ID);
$icon = $cat_data['icon'] ? $cat_data['icon']:'fa-list';
$more_text = $cat_data['more_text'] ? $cat_data['more_text']:'More';
$more_url = $cat_data['more_url'];
$post_ids = '';
if($cat_data['post_ids'] || $cat_data['post_ids'] !='')$post_ids = explode(',', $cat_data['post_ids'] );
if($post_ids){
	$args = array( 'post__in' => $post_ids ,'posts_per_page'=> $Posts , 'orderby'=>'post__in' ,'ignore_sticky_posts' => 1,'no_found_rows' => 1);
	$cat_query = new WP_Query( $args );
}else{
	$cat_query = new WP_Query('no_found_rows=true&cat='.$Cat_ID.'&posts_per_page='.$Posts);
}
$who = $cat_data['who'];
if( $who == 'logged' && !is_user_logged_in()):
	// return none;
elseif( $who == 'anonymous' && is_user_logged_in()):
	// return none;
else:
?>
<section class="span12 scroll-box">
	<div class="widget-box">
		<div class="widget-title">
			<?php if($more_url): ?>
				<span class="more"><a target="_blank" href="<?php echo $more_url; ?>"><?php echo $more_text; ?></a></span>
			<?php endif; ?>
			<span class="icon"> <i class="fa <?php echo $icon; ?> fa-fw"></i> </span>
			<h2><?php echo $Box_Title ; ?></h2>
		</div>
		<div class="widget-content pic-list">
			<?php if($cat_query->have_posts()): ?>
				<ul class="cat-scroll">
					<?php while ( $cat_query->have_posts() ) : $cat_query->the_post()?>
						<li>
							<a href="<?php the_permalink(); ?>" title="<?php printf( esc_attr__( 'Permalink to %s', 'cmp' ), the_title_attribute( 'echo=0' ) ); ?>" rel="bookmark" <?php echo cmp_target_blank();?>>
								<?php cmp_post_thumbnail(250,330) ?>
							</a>
						</li>
					<?php endwhile;?>
				</ul>
				<div class="clear"></div>
			</div>
		<?php endif; ?>
	</div>
</section>
<script type="text/javascript">
	jQuery(function() {
		jQuery('.cat-scroll').bxSlider({
			minSlides: 5,
			maxSlides: 5,
			slideWidth: 250,
			slideMargin: 30,
			auto: true,
			autoHover: true,
			autoDelay:2,
			pause: 6000,
			captions: false,
			controls: true,
			pager: false
		});
	});
</script>
<?php endif;//$who ?>
<?php } ?>