<?php
/* Add HighSlide Image Code */
add_filter('the_content', 'addhighslideclass_replace');
function addhighslideclass_replace ($content)
{   global $post;
    $pattern = "/<a(.*?)href=('|\")([^>]*).(bmp|gif|jpeg|jpg|png)('|\")(.*?)>(.*?)<\/a>/i";
    $replacement = '<a$1href=$2$3.$4$5 class="highslide-image" onclick="return hs.expand(this);"$6>$7</a>';
    $content = preg_replace($pattern, $replacement, $content);
    return $content;
}
/* Add HighSlide */
add_action( 'wp_enqueue_scripts', 'cmp_highslide' );
function cmp_highslide() {
  wp_register_script( 'highslide', get_template_directory_uri() . '/js/highslide.js', array('jquery'), theme_ver, 1,true );
  wp_register_style( 'highslide', get_template_directory_uri() . '/css/highslide.css','',theme_ver );
  if(is_single() || is_page()){
    wp_enqueue_script( 'highslide' );
    wp_localize_script( 'highslide', 'h_var', array(
      'gDir' => get_template_directory_uri().'/images/highslide/',
        'loadingText' => __('Loading...','cmp'),
        'loadingTitle' => __('Click to cancel','cmp'),
        'focusTitle' => __('Click to bring to front','cmp'),
        'fullExpandTitle' => __('Expand to actual size (f)','cmp'),
        'previousText' => __('Previous','cmp'),
        'nextText' => __('Next','cmp'),
        'moveText' => __('Move','cmp'),
        'closeText' => __('Close','cmp'),
        'closeTitle' => __('Close (esc)','cmp'),
        'resizeTitle' => __('Resize','cmp'),
        'playText' => __('Play','cmp'),
        'playTitle' => __('Play slideshow (spacebar)','cmp'),
        'pauseText' => __('Pause','cmp'),
        'pauseTitle' => __('Pause slideshow (spacebar)','cmp'),
        'previousTitle' => __('Previous (arrow left)','cmp'),
        'nextTitle' => __('Next (arrow right)','cmp'),
        'moveTitle' => __('Move','cmp'),
        'fullExpandText' => __('1:1','cmp'),
        'number' => __('Image %1 of %2','cmp'),
        'restoreTitle' => __('Click to close image, click and drag to move. Use arrow keys for next and previous.','cmp')
      )
    );
    wp_enqueue_style( 'highslide' );
  }
}