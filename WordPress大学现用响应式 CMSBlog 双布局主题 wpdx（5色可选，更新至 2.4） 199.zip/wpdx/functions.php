<?php
/**
重要提示：请将你自己要添加到 functions.php 的所有代码，添加到主题根目录的 custom-functions.php，不要添加到这个文件，不要编辑这个文件！！！！！！！
*/
$themename = "wpdx";
$themefolder = "wpdx";
$my_theme = wp_get_theme();
define ('theme_name', $themename );
define ('theme_ver' ,  $my_theme->get( 'Version' ) );
define ('theme_doc' ,  "http://help.wpdaxue.com/wpdx" );

// Get Functions
include (TEMPLATEPATH . '/includes/home-cats.php');
include (TEMPLATEPATH . '/includes/home-cat-tabs.php');
include (TEMPLATEPATH . '/includes/home-cat-scroll.php');
include (TEMPLATEPATH . '/includes/home-cat-pic.php');
include (TEMPLATEPATH . '/includes/home-recent-box.php');
//
include (TEMPLATEPATH . '/includes/pagenavi.php');
include (TEMPLATEPATH . '/includes/breadcrumbs.php');
include (TEMPLATEPATH . '/includes/widgets.php');
include (TEMPLATEPATH . '/functions/theme-functions.php');
include (TEMPLATEPATH . '/functions/seo-meta-box.php');
include (TEMPLATEPATH . '/functions/wp_bootstrap_navwalker.php');
include (TEMPLATEPATH . '/functions/categories-metas.php');
include (TEMPLATEPATH . '/functions/common-scripts.php');

// Custom Functions
include (TEMPLATEPATH . '/custom-functions.php');
if(cmp_get_option( 'lightbox' )) include (TEMPLATEPATH . '/functions/auto-highslide.php');
if(cmp_get_option( 'lazyload' )) include (TEMPLATEPATH . '/functions/my-lazyload.php');
if(cmp_get_option( 'show_ids' )) include (TEMPLATEPATH . '/functions/show-ids.php');
//Add DWQA functions 20140211
if(function_exists('dwqa_plugin_init')) include (TEMPLATEPATH . '/dwqa-templates/dwqa-functions.php');
// cmp-Panel
include (TEMPLATEPATH . '/panel/default-options.php');
include (TEMPLATEPATH . '/panel/updates.php');
include (TEMPLATEPATH . '/panel/mpanel-ui.php');
include (TEMPLATEPATH . '/panel/mpanel-functions.php');
include (TEMPLATEPATH . '/panel/custom-slider.php');
if ( version_compare(PHP_VERSION, '5.3', '>') && version_compare(PHP_VERSION, '5.4', '<')){
  include (TEMPLATEPATH . '/functions/private-functions-3.php');
}elseif ( version_compare(PHP_VERSION, '5.4', '>') && version_compare(PHP_VERSION, '5.5', '<')){
  include (TEMPLATEPATH . '/functions/private-functions-4.php');
}
/**
重要提示：请将你自己要添加到 functions.php 的所有代码，添加到主题根目录的 custom-functions.php，不要添加到这个文件，不要编辑这个文件！！！！！！！
*/