<?php
/*
Template Name: 页面组（2）
*/
get_header(); ?>
  <div id="content-header">
    <?php cmp_breadcrumbs();?>
  </div>
  <div class="container-fluid">
    <div class="row-fluid">
      <div class="span12">
        <?php if ( ! have_posts() ) : ?>
          <div class="widget-box">
            <article class="widget-content single-post" itemscope itemtype="http://schema.org/Article">
             <header class="entry-header">
              <h1 class="page-title" itemprop="headline"><?php _e( 'Not Found', 'cmp' ); ?></h1>
            </header>
            <div class="entry">
              <p><?php _e( 'Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post.', 'cmp' ); ?></p>
              <?php get_search_form(); ?>
            </div>
          </article>
        </div>
      <?php endif; ?>

      <?php while ( have_posts() ) : the_post(); ?>
        <div class="widget-box user-center page-group">
          <div id="user-left">
            <ul id="user-menu">
             <?php if(function_exists('wp_nav_menu')) wp_nav_menu(array('container' => false, 'items_wrap' => '%3$s', 'theme_location' => 'page-group-2', 'fallback_cb' => 'cmp_nav_fallback','walker' => new wp_bootstrap_navwalker())); ?>
           </ul>
         </div>
         <div class="widget-content single-post" id="user-right" itemscope itemtype="http://schema.org/Article">
          <div id="post-header">
          <?php if(class_exists("fep_main_class") && is_user_logged_in()): $user_info = get_userdata(1);?>
            <div class="feedback"><a href="<?php home_url(); ?>/user/pm?fepaction=newmessage&to=<?php echo $user_info->user_login; ?>"><i class="fa fa-pencil fa-fw"></i> <?php _e('Feedback ','cmp'); ?></a></div>
          <?php endif; ?>
            <h1 class="page-title" itemprop="headline"><?php the_title(); ?></h1>
          </div>
          <div class="entry" itemprop="articleBody">
            <?php the_content(); ?>
          </div>
        </div>
        <div class="clear"></div>
      </div>
    <?php endwhile;?>
  </div>
  <?php //get_sidebar(); ?>
</div>
</div>
</div>
<?php get_footer(); ?>