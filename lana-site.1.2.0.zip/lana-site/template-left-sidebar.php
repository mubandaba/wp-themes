<?php
/**
 * Template Name: Left Sidebar Page
 * Description: Page Template with a main sidebar in left side.
 */
?>

<?php get_header(); ?>

    <div class="row">

        <div <?php lana_site_sidebar_class(); ?>>
			<?php dynamic_sidebar( 'primary' ); ?>
        </div>

        <div <?php lana_site_content_class(); ?>>

			<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

                <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

                    <h3 class="page-title">
						<?php the_title(); ?>
                    </h3>

                    <div class="panel panel-primary">
                        <div class="panel-body">
							<?php the_content(); ?>
                        </div>

						<?php wp_link_pages(); ?>

						<?php if ( comments_open() || get_comments_number() ) : ?>
                            <div class="panel-footer">
								<?php comments_template(); ?>
                            </div>
						<?php endif; ?>
                    </div>

                </div>

			<?php endwhile; ?>

			<?php else : ?>
                <p><?php _e( 'Sorry, this page does not exist.', 'lana-site' ); ?></p>
			<?php endif; ?>

        </div>

    </div>

<?php get_footer(); ?>