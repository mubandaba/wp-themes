<?php get_header(); ?>

<div class="row">

	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

        <div class="col-md-12">

            <div class="panel text-center">
                <h3 class="partner-title">
					<?php _e( 'Partner', 'lana-site' ); ?>
                </h3>
				<?php if ( has_post_thumbnail() ) : ?>
                    <div class="partner-picture" title="<?php the_title_attribute(); ?>">
						<?php the_post_thumbnail(); ?>
                    </div>
				<?php endif; ?>
                <h2>
					<?php the_title(); ?>
                </h2>
                <div class="panel-body partner-description">
					<?php the_content(); ?>
                </div>

				<?php wp_link_pages(); ?>
            </div>
        </div>

	<?php endwhile; ?>

	<?php else : ?>
        <div class="col-md-12">
            <p><?php _e( 'Sorry, this page does not exist.', 'lana-site' ); ?></p>
        </div>
	<?php endif; ?>

</div>

<?php get_footer(); ?>
