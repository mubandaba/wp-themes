jQuery(function () {
    'use strict';

    /**
     * Scroll to top
     */
    jQuery(window).on('scroll load', function () {
        if (jQuery(document).scrollTop() > (jQuery('.header').height())) {
            jQuery('.scroll-to-top').find('.up-icon').addClass('show-icon');
        } else {
            jQuery('.scroll-to-top').find('.up-icon').removeClass('show-icon');
        }
    });

    jQuery('.scroll-to-top').click(function () {
        jQuery('html, body').animate({scrollTop: 0}, 'slow');
        return false;
    });

    /**
     * Main Content
     * min-height
     */
    jQuery(window).load(function () {
        var htmlHeight = jQuery('html').outerHeight(true);
        var bodyHeight = jQuery('body').outerHeight(true);

        var $mainContent = jQuery('.main-content');
        var mainContentHeight = $mainContent.outerHeight(true);

        var otherHeight = bodyHeight - mainContentHeight;

        var mainContentMinHeight = Math.floor(htmlHeight - otherHeight);

        if ($mainContent.length && mainContentMinHeight > mainContentHeight) {
            $mainContent.css('min-height', mainContentMinHeight + 'px');
        }
    });

    /**
     * Sticky navbar
     * @typedef {object} lana_site_navbar_sticky
     * @typedef {int} lana_site_navbar_sticky.theme_mod
     */
    if (lana_site_navbar_sticky.theme_mod == true) {

        var $header = jQuery('.header');

        jQuery('.navbar-in-header').find('.navbar').affix({
            offset: {
                top: $header.outerHeight()
            }
        });
        jQuery('.navbar-in-content').find('.navbar').affix({
            offset: {
                top: $header.outerHeight() + 80
            }
        });

        jQuery('.boxed-navigation').find('.navbar')
            .on('affix.bs.affix', function () {
                jQuery(this).find('.without-container').addClass('container')
            })
            .on('affix-top.bs.affix', function () {
                jQuery(this).find('.without-container').removeClass('container')
            });
    }
});
