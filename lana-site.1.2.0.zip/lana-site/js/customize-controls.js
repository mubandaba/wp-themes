/**
 * @typedef {object} lana_l10n
 */
jQuery(function () {

    var $customizeThemeControls = jQuery('#customize-theme-controls');

    var sections = [
        $customizeThemeControls.find('#accordion-section-lana_site_display'),
        $customizeThemeControls.find('#accordion-section-lana_site_header'),
        $customizeThemeControls.find('#accordion-section-lana_site_post'),
        $customizeThemeControls.find('#accordion-section-background_image'),
        $customizeThemeControls.find('#accordion-section-lana_site_footer')
    ];

    jQuery.each(sections, function (id, section) {
        section.find('.accordion-section-title').append(
            jQuery('<span>').addClass('pull-right').addClass('label').addClass('label-primary').text(lana_l10n['lana_site_label'])
        );
    });

    /**
     * When change footer type
     * show or hide footer text
     */
    $customizeThemeControls.find('#sub-accordion-section-lana_site_footer').find('#customize-control-lana_site_footer_type_select').find('select').on('change', function () {

        var $controlFooterText = jQuery(this).closest('#sub-accordion-section-lana_site_footer').find('#customize-control-lana_site_footer_text_text');

        if (jQuery(this).val() == 'text') {
            $controlFooterText.show();
        } else {
            $controlFooterText.hide();
        }

    }).trigger('change');

});