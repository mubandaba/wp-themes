# smarty_hankin

#### 介绍
------------------
> 一款开源wordpress主题 smarty_hankin主题

- pjax无刷新体验
- 12种配色，5种布局，支持暗黑模式
- 侧边栏小工具，音乐播放器，内置Mac界面代码高亮行号显示，
- 强大的后台设置
- 丰富的自定义页面
- 还有更多...

主题预览 [www.hankin.cn](https://www.hankin.cn)

![add image](https://github.com/hankin-han/smarty_hankin/blob/master/screenshot.jpg)

<img src="https://www.hankin.cn/wp-content/themes/smarty_hankin/screenshot.jpg" width="600" height="450" />