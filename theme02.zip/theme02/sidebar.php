<div id="sidebar" class="sidebar">

<ul>
<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar() ) : else : ?>
		<li>
			<h2>search</h2>
			<div id="search">
				<?php include(TEMPLATEPATH . '/searchform.php'); ?>
			</div>
        </li>
		<li>
			<h2><?php _e('Categories'); ?></h2>
			<ul>
					<?php wp_list_cats('sort_column=name&hierarchical=0&depth=0'); ?>
			</ul>
		</li>
		<li>
			<h2><?php _e('recent posts'); ?></h2>
			<ul>
			<?php
					global $post;
					$recent = get_posts('numberposts=5&orderby=date');
					foreach($recent as $post) : setup_postdata($post);
				?>				
			<li>
				<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
			</li>	
			<?php endforeach; ?>
			</ul>
		</li>

		<li>
			<h2><?php _e('Archives'); ?></h2>
			<ul>
			<?php wp_get_archives('type=monthly'); ?>
			</ul>
		</li>
		<li>
			<h2><?php _e('Meta'); ?></h2>
			<ul>
			<?php wp_register(); ?>
			<li><?php wp_loginout(); ?></li>
			<?php wp_meta(); ?>
			</ul>
		</li>

<?php endif;?>
</ul>
</div>