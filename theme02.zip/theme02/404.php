<?php get_header(); ?>
<div id="contents">
	<?php get_sidebar();?>
	<div class="container">
		<div class="post">
             <h2>404 Error - Not Found</h2>
		</div>
        <div id="clear"></div>
    </div>
	<div id="clear"></div>
</div>
<?php get_footer();?>
<div id="clear"></div>
</div>
</body>
</html>