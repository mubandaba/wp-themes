<form method="get" id="searchform" action="<?php bloginfo('home'); ?>/">
<div>
	<input class="search" type="text" value="Search Here..." onfocus="if (this.value == 'Search Here...') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Search Here...';}" name="s" id="s" size="30" /><input class="submit" type="submit" id="searchsubmit" value="" />
</div>
<div id="clear"></div>
</form>