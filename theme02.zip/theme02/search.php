<?php get_header(); ?>
<div id="contents">
	<?php get_sidebar();?>
	<div class="container">
          <?php if(have_posts()) : ?><?php while(have_posts()) : the_post(); ?>
         <div class="post">
            <div class="pleft">
				<h2><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
				<div class="postmetadata">
					<?php _e('Category : '); ?> <?php the_category(', '); ?> <?php _e('| By : '); ?><?php the_author_link(); ?> <?php edit_post_link('Edit', '|&nbsp;', ''); ?>
				</div>
			</div>
			<div class="pright">
				<div class="pdate"><?php the_time('j'); ?></div>
				<div class="pmonth"><?php the_time('M'); ?></div>
			</div>
			<div id="clear"></div> 
            <?php the_excerpt(); ?>
			<div id="clear"></div>         
          </div>
             <?php endwhile; ?>
			      <div class="navigation">
                  <div class="left-nav"><?php previous_posts_link('Previous Page', ''); ?>
</div>
<div class="right-nav"><?php next_posts_link('Next Page', ''); ?> </div>
                  </div>
                <?php else: ?>
                <div class="post" id="post-<?php the_ID();?>">
					<h2><?php _e('Not Found');?></h2>
		  		</div>		
             <?php endif; ?>
		<div id="clear"></div>
    </div>
<div id="clear"></div>
</div>
<?php get_footer();?>
<div id="clear"></div>
</div>
</body>

</html>