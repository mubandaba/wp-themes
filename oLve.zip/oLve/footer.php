  	
  		<?php // get_sidebar(); ?>
  		<footer>
        <div class="infomation">
          <span class="copyr">&copy; Copyright <a href="<?php echo home_url(); ?>/" title="<?php bloginfo('description'); ?>"><?php bloginfo('name'); ?></a></span>
          <span class="aboutr"><a href="<?php echo home_url(); ?>/about" title="关于博主">About</a> / <a href="<?php echo home_url(); ?>/feed" title="订阅“<?php bloginfo('name'); ?>”吧~~">RSS</a> / <?php echo base64_decode('PGEgaHJlZj0iaHR0cDovL3llZmVuZ3MuY29tL3RoZW1lL29sdmUiIHRpdGxlPSJUaGVtZSBieSB5ZWZlbmdzIj5vTHZlPC9hPg=='); ?> / <a rel="nofollow" href="javascript:void(0);" onclick="MGJS.goTop();return false;">Top</a></span>
        </div>
  		</footer>

  		<?php wp_footer(); ?>
		  </section>
	  </div>
    <div id="scriptbox">
  <?php $options = get_option('yefengs_olve_options'); 
   if($options['lazyload']): ?>
    <script src="<?php bloginfo('template_url'); ?>/js/lazyload.js"></script>
    <script  type="text/javascript">$(document).ready(function () {$('.articlepost .contentpost img,.status .author_avater img,.comment_body .author img,.avatar,.imagespost img').lazyload({effect : "fadeIn"}); });</script>
  <?php endif; 
     if($options['phzoom']): ?>
       <script src="<?php bloginfo('template_url'); ?>/js/phzoom.js"></script>
       <script type="text/javascript">jQuery(document).ready(function($) {$("body a").filter(function(){return/\.(?:jpe?g|png|gif)/i.test(this.href)}).phzoom({returnOrigin:false});});</script>
  <?php endif; 
   if($options['Analytics']): 
    echo($options['Analytics']); 
     endif; ?>
</div>
    <div id="abackground"><div>
	</body>
</html>
