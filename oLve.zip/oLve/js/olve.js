
//你妹的HTML5玩意儿~

document.createElement('header');
document.createElement('footer');
document.createElement('section');
document.createElement('aside');
document.createElement('nav');
document.createElement('article');

//
(function(a){a.backstretch=function(k,i,l){function m(c){try{f={left:0,top:0};d=e.width();b=d/j;if(b>=e.height()){g=(b-e.height())/2;h.centeredY&&a.extend(f,{top:"-"+g+"px"})}else{b=e.height();d=b*j;g=(d-e.width())/2;h.centeredX&&a.extend(f,{left:"-"+g+"px"})}a("#backstretch img").width(d).height(b).css(f)}catch(n){}typeof c=="function"&&c()}var h={centeredX:true,centeredY:true,speed:0},e="onorientationchange"in window?a(document):a(window),j,d,b,g,f;i&&typeof i=="object"&&a.extend(h,i);a(document).ready(function(){if(k){var c= a("<div />").attr("id","backstretch").css({left:0,top:0,position:"fixed",overflow:"hidden",zIndex:-9999}),n=a("<img />").css({position:"relative",display:"none"}).bind("load",function(o){var p=a(this);j=a(o.target).width()/a(o.target).height();m(function(){p.fadeIn(h.speed,function(){typeof l=="function"&&l()})})}).appendTo(c);a("body").prepend(c);n.attr("src",k);a(window).resize(m)}});return this}})(jQuery);


	$(document).ready(function() {
		$("#myneighbor").hide('slow');
		$("#neighborlink").click(function() {
			$(this).toggleClass("active").next().slideToggle('slow');
			return false
		})
	});
//超链接样式
jQuery(document).ready(function($) {

	$('a').hover(function() {
		if (!jQuery(this).is(":animated")) {
			jQuery(this).animate({
				opacity: ".7"
			},
			220).animate({
				opacity: "1"
			},
			180);
		}
	});

	$(".comment_data").hover(function() {
		$(this).find('.reply,.quotebox').stop(true, true).fadeIn(400);
			},
		function() {
		$(this).find('.reply,.quotebox').stop(true, true).fadeOut(800)
			});
});
function up() {
	$wd = $(window);
	$wd.scrollTop($wd.scrollTop() - 1);
	fq = setTimeout("up()", 10)
};
//Respond @XXX
$(document).ready(function() {
	respond();
	function respond() {
		$('#smilies').hide();
		$('#readrtavatar').hide();
		$('#comment').focus(function() {
			$('#smilies').slideDown('slow');
			$('#readrtavatar').slideDown('slow');
		});
		$('.reply').click(function() {
			var atid = '"#' + $(this).parent().parent().attr("id") + '"';
			var atname = $(this).parent().find('.name').text();
			atname = $.trim(atname);
			$('#comment').attr("value", "<a href=" + atid + "><em>@" + atname + "</em>：</a>").focus()
		});
		$('.quotes').click(function() {
		var atid = '"#' + $(this).parent().parent().parent().attr("id") + '"';
		var commencon = $(this).parent().parent().find('.text').text();
		var atname = $(this).parent().parent().find('.name').text();
		atname = $.trim(atname); //去空行啊~你妹
		commencon = $.trim(commencon); //去空行啊~你妹
		$('#comment').attr("value", "<blockquote><a href=" + atid + "><strong><em>" + atname + ":</em></strong></a>"+ commencon +"</blockquote>")
		});
		$('.cancel_comment_reply a').click(function() {
			$('#comment').attr("value", '');
			$('#smilies').slideUp('slow');
			$('#readrtavatar').slideUp('slow');
		})
	}
});

//这是Ajax评论翻页调用的函数
jQuery.fn.yReply = function() {
	$(this).click(function() {
		var atid = '"#' + $(this).parent().parent().attr("id") + '"';
		var atname = $(this).parent().find('.name').text();
		atname = $.trim(atname);
		$('#comment').attr("value", "<a href=" + atid + ">@" + atname + " </a>").focus()
	});
	$('.quote').click(function() {
		var atid = '"#' + $(this).parent().parent().parent().attr("id") + '"';
		var commencon = $(this).parent().parent().find('.text').text();
		var atname = $(this).parent().parent().find('.name').text();
		atname = $.trim(atname); 
		commencon = $.trim(commencon); 
		$('#comment').attr("value", "<blockquote><a href=" + atid + "><strong><em>" + atname + ":</em></strong></a>"+ commencon +"</blockquote>")
		});
	$('.cancel_comment_reply a').click(function() {
		$('#comment').attr("value", '');
		$('#smilies').slideUp('slow');
		$('#readrtavatar').slideUp('slow');
	})
};
jQuery(document).ready(function($)  {
zRespondPatch=$('#respond').html();
$body = (window.opera) ? (document.compatMode == "CSS1Compat" ? $('html') : $('body')) : $('html,body');
$('.commentnav a').live('click',
function(e) 
{
		if ($('#wp-temp-form-div').length) {
		$('#wp-temp-form-div').attr('id', 'respond').html(zRespondPatch).show();
	}
	e.preventDefault();
	$.ajax({
		type: "GET",
		url: $(this).attr('href'),
		beforeSend: function() {
			$('.commentnav').remove();
			$('.commentlist').animate({opacity: ".6"},520);
			$('#loading-comments').slideDown()
		},
		dataType: "html",
		success: function(out) {
			result = $(out).find('.commentlist');
			nextlink = $(out).find('.commentnav');
			$('#loading-comments').slideUp(500);
			$('.commentlist').remove();
			$('#comments').after(result.fadeIn(800));
			$('#loading-comments').after(nextlink);
			$('.commentlist').animate({opacity: "1"},520);
			$(".comment_data").hover(function() {
				$(this).find('.reply,.quotebox').stop(true, true).fadeIn(400);
					},
				function() {
				$(this).find('.reply,.quotebox').stop(true, true).fadeOut(800)
					});
			$(".reply").yReply()
		}
	})
});
});

//评论框字数统计
jQuery(document).ready(function(a) {
	a("#comment").bind("focus keyup input paste",
	function() {
		this.value.length > 800 ? (this.value = a(this).attr("value").substring(0, 800), a("#num").text("\u4e0a\u9650800")) : a("#num").text(a(this).attr("value").length)
	});
});
/*
Author: mg12
Update: 2008/05/05
Author URI: http://www.neoease.com/
*/
(function() {

function $(id) {
	return document.getElementById(id);
}

function setStyleDisplay(id, status) {
	$(id).style.display = status;
}

function goTop(a, t) {
	a = a || 0.1;
	t = t || 16;

	var x1 = 0;
	var y1 = 0;
	var x2 = 0;
	var y2 = 0;
	var x3 = 0;
	var y3 = 0;

	if (document.documentElement) {
		x1 = document.documentElement.scrollLeft || 0;
		y1 = document.documentElement.scrollTop || 0;
	}
	if (document.body) {
		x2 = document.body.scrollLeft || 0;
		y2 = document.body.scrollTop || 0;
	}
	var x3 = window.scrollX || 0;
	var y3 = window.scrollY || 0;

	var x = Math.max(x1, Math.max(x2, x3));
	var y = Math.max(y1, Math.max(y2, y3));

	var speed = 1 + a;
	window.scrollTo(Math.floor(x / speed), Math.floor(y / speed));
	if(x > 0 || y > 0) {
		var f = "MGJS.goTop(" + a + ", " + t + ")";
		window.setTimeout(f, t);
	}
}
window['MGJS'] = {};
window['MGJS']['$'] = $;
window['MGJS']['setStyleDisplay'] = setStyleDisplay;
window['MGJS']['goTop'] = goTop;
})();

