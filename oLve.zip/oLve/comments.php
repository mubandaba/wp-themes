<?php if ( post_password_required() ) { ?>
  <p class="nocomments">This post is password protected. Enter the password to view comments.</p>
<?php return; } ?>

<!-- You can start editing here. -->

<?php if ( have_comments() ) : ?>
	<h3 id="comments"><?php comments_number('暂无评论', '1 个评论', '% 个评论');?> </h3>
	<ol class="commentlist">
	<?php
						/**
						 * 调用这个 直接用callback 回调到 wp_list_comments()中去了.
						 * 你妹的的这个可以不用放到 fuctions中去了
						 * @subpackage Funtions，我操~fucktions
						 *要不哥整个楼层显示？，貌似还可以~~~ 
						 */
	function commentlist($comment,$args,$depth)
	{
		$GLOBALS['comment']=$comment; 
		//下面的是楼层显示 但是我没有看懂是怎么回事~
		global $commentcount,$comment_depth;
		$otakism_comment_depth = $comment_depth-1;
		if(!$otakism_comment_depth){
			$otakism_comment_depth = '0&nbsp;';
			}
		if(!$commentcount) {
			$page = ( !empty($in_comment_loop) ) ? get_query_var('cpage')-1 : get_page_of_comment( $comment->comment_ID, $args )-1;
			$cpp=get_option('comments_per_page');
			$commentcount = $cpp * $page;
			}

		?>
	<li <?php comment_class(); ?> id="li-comment-<?php comment_ID ?>">
		<div id="comment-<?php comment_ID(); ?>" class="comment_body">
		 <div class="comment-floor right">
            <?php //楼层显示
				if(get_option('default_comments_page')=='newest'){ //get_option('default_comments_page')=='newest'是什么意思？
					if(!$parent_id = $comment->comment_parent ){
						++$commentcount;
						}
					echo '<span>'.$commentcount.'<strong>.'.$otakism_comment_depth .'</strong></span>';
				}else{
					if(!$parent_id = $comment->comment_parent ){
						--$commentcount;
						}
					echo '<span>'.$commentcount.'<strong>.'.$otakism_comment_depth .'</strong></span>';
				}
			?>
            </div> 
			<div class="author"><?php echo get_avatar($comment,'35'); ?></div>
			<div class="comment_data">
				<span class="name"><?php comment_author_link() ?></span>
				<div class="time"><?php echo commenttime_ago(); ?><?php edit_comment_link('编辑','&nbsp;&nbsp;',''); ?></div>
				<div class="quotebox">
					<a class="quotes" title="Quote" href="#respond">引用</a>
				</div>
				<div class="reply">
					<?php comment_reply_link(array_merge($args,array('reply_text' =>'回复','depth' =>$depth,'max_depth'=>$args['max_depth']))) ?>
				</div>
				<?php if($comment->comment_approved=='0'): ?>
					<em><span class="moderation"><?php _e('Your comment is awaiting moderation.') ?></span></em>
				<?php endif; ?>
				<div class="text">
					<?php comment_text() ?>
				</div>
				
			</div>
		</div>	
			<?php
			 }
 			wp_list_comments("type=comment&callback=commentlist");
			?>
	</ol>
		<div id="loading-comments"></div>
			<nav class="commentnav">
				<?php paginate_comments_links('prev_text=«&next_text=»');?>
			</nav>
			<hr class="clearfix" />
			<div style="height:1px;"></div>
 <?php else : // this is displayed if there are no comments so far ?>
	<?php if ( comments_open() ) : ?>

	 <?php else : // comments are closed ?>
	  <?php if(!is_page()) { ?>
		<p class="nocomments">Comments are closed.</p>
    <?php } ?>

	<?php endif; ?>
<?php endif; ?>

<?php if (comments_open()) : ?>
		<div id="respond">
			<div class="cancel_comment_reply">
				<?php cancel_comment_reply_link('取消回复'); ?>
			</div>
			<form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform">
				<?php if($user_ID): ?>
					<div>已登录<a href="<?php echo get_option('siteurl'); ?>/wp-admin/profile.php"><?php echo $user_identity; ?></a>&nbsp;，&nbsp;<a href="<?php echo wp_logout_url(get_permalink()); ?>" title="Log out of this account">注销？</a></div>
				<?php else: ?>
					<div class="welcome">
						<?php if($comment_author): ?>
							欢迎回来！亲爱的<?php echo $comment_author; ?>(<a href="javascript:showCommentAuthorInfo();">换个马甲</a>)！ 
							<?php echo WelcomeCommentAuthorBack($comment_author_email); ?>
								<script type="text/javascript" charset="utf-8">
										//<![CDATA[
									jQuery(document).ready(function() {
									jQuery('#commentinfobox').hide();
									});
									function showCommentAuthorInfo() {
									jQuery('#commentinfobox').show();
										}
										//]]>
									</script>
						<?php else: ?>
							告诉你一个秘密，只要填写<strong>昵称</strong>和<strong>邮箱</strong>就可以留言了...
						<?php endif; ?>
					</div>
				<div id="commentinfobox">
					<div class="commentinfo">
						<label>昵称：</label>
						<input type="text" name="author" id="author" value="<?php echo $comment_author; ?>" tabindex="1" <?php if($req) echo "aria-required='true'"; ?> />
					</div>
					<div class="commentinfo">
						<label>邮箱：</label>
						<input type="text" name="email" id="email" value="<?php echo $comment_author_email; ?>" tabindex="2" <?php if($req) echo "aria-required='true'"; ?> />
					</div>
					<div class="commentinfo">
						<label>网站：</label>
						<input type="text" name="url" id="url" value="<?php echo $comment_author_url; ?>" tabindex="3" />
					</div>
				</div>
				<?php endif; ?>
				<div id="comment_textarea">
					<div id="readrtavatar">
					<span class="textcount">您输入了&nbsp;<i id="num" > 0/800 </i>&nbsp;字</span>
					<?php if(isset($_COOKIE['comment_author_email_'.COOKIEHASH])) : ?>
						<?php echo get_avatar($comment_author_email, 25);?>
						<?php else :?>
						<?php global $user_email;?><?php echo get_avatar($user_email, 25); ?>
						<?php endif;?>
				</div>
					<textarea name="comment" id="comment" tabindex="4" onkeydown="if(event.ctrlKey&&event.keyCode==13){document.getElementById('submit').click();return false};"></textarea>
				</div>
				<?php include('include/smilies.php'); ?>
				<div>
					<input name="submit" type="submit" id="submit" tabindex="5" value="确认" />
					<?php comment_id_fields(); ?>
				</div>
				<?php do_action('comment_form',$post->ID); ?>
			</form>
		</div>
<?php endif; // if you delete this the sky will fall on your head ?>
