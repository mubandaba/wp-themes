<?php get_header(); ?>
	<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>

<?php
		$post_format = function_exists('get_post_format'); // WP3.0 compatibility
	$format = get_post_format();
	if(!$post_format || !in_array($format, array('status','quote', 'image','audio'))) {//normal post
?>		
			<article class="articlepost" id="post-<?php the_ID(); ?>">
				<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
			<div class="contentpost">	
				<?php the_content('全文阅读 &raquo;'); ?>
				<hr class="clearfix" />
			</div>
			 	<?php wp_link_pages('before=<p>&after=</p>&next_or_number=number&pagelink=page %'); ?>
			 <div class="shadows"></div>
			<div class="postmetadata">
			<time class="postmetinfo"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_time("m/d/Y"); ?></a></time>
			<span class="commentnum"><?php edit_post_link('Edit', '[', ']'); ?>  <?php comments_popup_link('暂无言论', '1 条言论', '% 条言论'); ?></span>
			</div>
			<span class="shadow"></span>
			</article>
<?php
	} else if($format == 'status') {//aside
?>
		<div class="status" id="post-<?php the_ID(); ?>">
			<div class="author_avater">
				<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>">
				<?php echo get_avatar( get_the_author_email(), 49 ); ?>
			</a></h2>
				<span><?php comments_popup_link('评论(0)', '评论(1)', ' 评论(%)'); ?></span>
			</div>
			<div class="status_content">
				<div class="statusbox">
					<span><?php echo time_ago(); ?>前说：</span>
					<?php the_content('全文阅读 &raquo;'); ?>
				</div>
			</div>
			<div class="statusoo"></div>
			<hr class="clearfix" />
		</div>
<?php
	} else if($format == 'quote') {//quote	
		$matches = array();
		if(preg_match('/<cite(?:>|[^>]+>)((?!<\/cite>)[\w\W]*)<\/cite>/i',  $post->post_content, $matches)) {
			$source = $matches[1];
		} else if($post->post_title) {
			$source = $post->post_title;
		} else {
			$source = null;
		}
		$quote_type = $quote = null;
		$matches = array();
		if(preg_match('/<(blockquote|q)(?:>|[^>]+>)((?!<\/(?:blockquote|q)>)[\w\W]*)?<\/(?:blockquote|q)>/i',  $post->post_content, $matches)) {
			$quote_type = $matches[1];
			$quote = $matches[2];
		} else {
			$quote = $post->post_content;
			$quote_type = 'blockquote';
		}
		$quote = "<$quote_type><span class=\"quote-left\">&ldquo;</span>" . trim($quote, '\u0022\u2018\u2019\u0027\u201c\u201d') . "<span class=\"quote-right\">&rdquo;</span></$quote_type>";
?>
			<article class="quote" id="post-<?php the_ID(); ?>">
			<div class="contentpost">

					<a href="<?php the_permalink(); ?>"><?php echo $quote; ?></a>
				<?php if($source) { ?>
					<h2 class="quoteh2"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php echo $source; ?>">——<?php echo $source; ?></a></h2>

				<?php } ?>
				<hr class="clearfix zhanwei" />
			</div>
			 <div class="shadows"></div>
			<div class="postmetadata">
			<time class="postmetinfo"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_time("m/d/Y"); ?></a></time>
			<span class="commentnum"><?php edit_post_link('Edit', '[', ']'); ?>  <?php comments_popup_link('暂无言论', '1 条言论', '% 条言论'); ?></span>
			</div>
			<span class="shadow"></span>
			</article>

<?php
	} else if($format == 'image') {//image
		
		$match = array();
		$title = null;
		$source = filter_var(trim($post->post_content), FILTER_VALIDATE_URL);

		if(!$source && preg_match('/<img [^>]*src=[\"\']?([^\"\'\s]+)/is', $post->post_content, $match)) {
		

		//	/<img [^>]*src=[\"\']?([^\"\'\s]+)/i
		//	/<img([^\/>]+)src="([^"]+)"([^\/>]+)\/>/is

		$source = $match[1];
		$allPics = count($match);
	

		}
		if($post->post_title) {
			$title = $post->post_title;
		}
		
?>			
			<article class="imagespost" id="post-<?php the_ID(); ?>">
				<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>	
					<?php if($source) { ?>
						<a href="<?php the_permalink(); ?>" class="cover"><img src="<?php echo $source; ?>"<?php if($title) { echo ' alt="' . $title . '" title="' . $title . '"'; } ?> /></a>
					<?php }?>
				<hr class="clearfix" />

			 	<?php wp_link_pages('before=<p>&after=</p>&next_or_number=number&pagelink=page %'); ?>
			 <div class="shadows"></div>
			<div class="postmetadata">
			<time class="postmetinfo"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_time("m/d/Y"); ?></a></time>
			<span class="commentnum"><?php edit_post_link('Edit', '[', ']'); ?>  <?php comments_popup_link('暂无赏析', '1 次赏析', '% 次赏析'); ?></span>
			</div>
			<span class="shadow"></span>
			</article>

<?php
	} else if($format == 'audio') {//video or audio
		$match = array();
		$title = $content = null;
		if(preg_match('/(<(video|audio|object|embed|iframe)[^>]+(?:>(?:(?!<\/\2>)[\w\W]*)?<\/\2>|\/>))/i', apply_filters('the_content', apply_filters('get_the_content', $post->post_content)), $match)) {
			$content = $match[1];
		}
		if($post->post_title) {
			$title = $post->post_title;
		}
		$music = array();
		$source = filter_var(trim($post->post_content), FILTER_VALIDATE_URL);
		if(!$source && preg_match('/<img [^>]*src=[\"\']?([^\"\'\s]+)/i', $post->post_content, $music)) {
			$source = $music[1];
		}

?>		

			<article class="musicpost" id="post-<?php the_ID(); ?>">
				<div class="musicthumb">
					<div class="musicimg">

<img src="<?php bloginfo('template_url');?>/timthumb.php?src=<?php echo $source; ?>&amp;w=120&amp;h=120&amp;zc=0.8" alt="<?php the_title(); ?>" width="120" height="120" />

					</div>
					<div class="thumbbg"></div>
				</div>
			<div class="musicbox">	
						<?php if($content) { ?>
						<?php if($title) { ?><h2><a href="<?php the_permalink() ?>" title="放下烦恼，聆听一首《<?php echo $title; ?>》吧！" rel="bookmark"><?php echo $title; ?></a></h2><?php } ?>
						<span class="musicplayer"><?php echo $content; ?></span><?php	} ?>
						<p class="mcontent"><?php echo cut_str(strip_tags(apply_filters('the_content',$post->post_content)),90); ?>
							</p>
				<hr class="clearfix zhanwei" />
			</div>
			 	<hr class="clearfix" />
			 <div class="shadows"></div>
			<div class="postmetadata">
			<time class="postmetinfo"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_time("m/d/Y"); ?></a></time>
			<span class="commentnum"><?php edit_post_link('Edit', '[', ']'); ?>  <?php comments_popup_link('暂无悦言', '1次悦赏', '% 次悦赏'); ?></span>
			</div>
			<span class="shadow"></span>
			</article>
<?php
	}
?>
		<?php endwhile; ?>
			<?php  if ( $wp_query->max_num_pages > 1 ) : ?>
		        <nav class="pagenavi">
		           <?php par_pagenavi(5); ?>
		        </nav>
		    <?php endif; ?>
	<?php else : ?>
		<article class="noposts">
			<h2>404 - Content Not Found</h2>
			<div class="contentpost">	
			<p>We don't seem to be able to find the content you have requested - why not try a search below?</p>
			<?php get_search_form(); ?>
				<hr class="clearfix" />
			</div>
			 <div class="shadows"></div>
			<div class="postmetadata"></div>
		</article>
	</div>
	<?php endif; ?>
<?php get_footer(); ?>
