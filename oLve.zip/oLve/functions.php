<?php
register_nav_menus( array('topbar' => __( '顶部菜单栏'),));



// 添加文章样式
add_theme_support( 'post-formats', array( 'status', 'image', 'quote','audio') );


add_filter( 'pre_option_link_manager_enabled', '__return_true' );

 // 翻页
 function par_pagenavi($range = 9){
  global $paged, $wp_query;
  if ( !$max_page ) {$max_page = $wp_query->max_num_pages;}
  if($max_page > 1){if(!$paged){$paged = 1;}
  if($paged != 1){echo "<a href='" . get_pagenum_link(1) . "' class='extend' title='".'第一页'."'>".'«'."</a>";}
  previous_posts_link('‹');
    if($max_page > $range){
    if($paged < $range){for($i = 1; $i <= ($range + 1); $i++){echo "<a href='" . get_pagenum_link($i) ."'";
    if($i==$paged)echo " class='current'";echo ">$i</a>";}}
    elseif($paged >= ($max_page - ceil(($range/2)))){
    for($i = $max_page - $range; $i <= $max_page; $i++){echo "<a href='" . get_pagenum_link($i) ."'";
    if($i==$paged)echo " class='current'";echo ">$i</a>";}}
  elseif($paged >= $range && $paged < ($max_page - ceil(($range/2)))){
    for($i = ($paged - ceil($range/2)); $i <= ($paged + ceil(($range/2))); $i++){echo "<a href='" . get_pagenum_link($i) ."'";if($i==$paged) echo "";echo ">$i</a>";}}}
    else{for($i = 1; $i <= $max_page; $i++){echo "<a href='" . get_pagenum_link($i) ."'";
    if($i==$paged)echo " class='current'";echo ">$i</a>";}}
  next_posts_link('›');
    if($paged != $max_page){echo "<a href='" . get_pagenum_link($max_page) . "' class='extend' title='".'最后一页'."'>".'»'."</a>";}}
}
  function time_ago( $type = 'post' ) {$d = 'comment' == $type ? 'get_comment_time' : 'get_post_time';return human_time_diff($d('U'),current_time('timestamp'));}
  

   function commenttime_ago( $type = 'commennt', $day = 30 ) {  $d = $type == 'post' ? 'get_post_time' : 'get_comment_time';  $timediff = time() - $d('U');  if ($timediff <= 60*60*24*$day){  echo  human_time_diff($d('U'), strtotime(current_time('mysql', 0))), '前';  }  if ($timediff > 60*60*24*$day){  echo  date('Y/m/d',get_comment_date('U')), ' ', get_comment_time('H:i');  };}

if ( function_exists('add_theme_support') )
 add_theme_support('post-thumbnails');
function catch_first_image() {global $post, $posts;$first_img = '';
  ob_start();
  ob_end_clean();
  $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
  $first_img = $matches [1] [0];
  if(empty($first_img)){
    $random = mt_rand(1, 20);
    echo get_bloginfo ( 'stylesheet_directory' );
    //echo '/images/random/tb'.$random.'.jpg';
    //$first_img = "/images/default.jpg";
    echo '/images/thumbimg.png';
    }
  return $first_img;};


//留言信息
    function WelcomeCommentAuthorBack($email = ''){
      if(empty($email)){
        return;
      }
      global $wpdb;
      $past_30days = gmdate('Y-m-d H:i:s',((time()-(24*60*60*30))+(get_option('gmt_offset')*3600)));
      $sql = "SELECT count(comment_author_email) AS times FROM $wpdb->comments
              WHERE comment_approved = '1'
              AND comment_author_email = '$email'
              AND comment_date >= '$past_30days'";
      $times = $wpdb->get_results($sql);
      $times = ($times[0]->times) ? $times[0]->times : 0;
      $message = $times ? sprintf(__('在过去30天里亲有<strong>%1$s</strong>次留言，感谢亲的关注!' ), $times) : '你好久抹油给我说话了，这次给我说点啥？';
      return $message;
    }
    //评论表情
    add_filter('smilies_src','custom_smilies_src',1,10);function custom_smilies_src ($img_src, $img, $siteurl){return get_bloginfo('template_directory').'/images/smilies/'.$img;}


//添加评论回复邮件通知
  function comment_mail_notify($comment_id) {
    $admin_notify = '1'; // admin 要不要收回复通知 ( '1'=要 ; '0'=不要 )
    $admin_email = get_bloginfo ('admin_email'); // $admin_email 可改为你指定的 e-mail.
    $comment = get_comment($comment_id);
    $comment_author_email = trim($comment->comment_author_email);
    $parent_id = $comment->comment_parent ? $comment->comment_parent : '';
    global $wpdb;
    if ($wpdb->query("Describe {$wpdb->comments} comment_mail_notify") == '')
      $wpdb->query("ALTER TABLE {$wpdb->comments} ADD COLUMN comment_mail_notify TINYINT NOT NULL DEFAULT 0;");
    if (($comment_author_email != $admin_email && isset($_POST['comment_mail_notify'])) || ($comment_author_email == $admin_email && $admin_notify == '1'))
      $wpdb->query("UPDATE {$wpdb->comments} SET comment_mail_notify='1' WHERE comment_ID='$comment_id'");
    $notify = $parent_id ? get_comment($parent_id)->comment_mail_notify : '0';
    $spam_confirmed = $comment->comment_approved;
    if ($parent_id != '' && $spam_confirmed != 'spam' && $notify == '1') {
      $wp_email = 'no-reply@' . preg_replace('#^www\.#', '', strtolower($_SERVER['SERVER_NAME'])); // e-mail 发出点, no-reply 可改为可用的 e-mail.
      $to = trim(get_comment($parent_id)->comment_author_email);
      $subject = ' [' . get_option("blogname") . '] 的信使';
      $message = '
      <div style="background-color:#fff; border:1px solid #666666; color:#111;border-radius:8px; font-size:13px; width:702px; margin:0 auto; margin-top:10px; font-family:微软雅黑, Arial;">
      <div style="background:#666666; width:100%; height:60px; color:white; border-radius:6px 6px 0 0; "><span style="height:60px; line-height:60px; margin-left:30px; font-size:20px;">您在<a style="text-decoration:none; color:#00bbff;font-weight:600;" href="' . get_option('home') . '" target="_blank">' . get_option('blogname') . '</a>博客上的留言有回复啦！</span></div>
      <div style="width:90%; margin:0 auto">
      <p>' . trim(get_comment($parent_id)->comment_author) . ', 您好!</p>
      <p>您曾在《' . get_the_title($comment->comment_post_ID) . '》的留言:</p>
      <p style="background-color: #EEE;border: 1px solid #DDD;padding: 10px 5px;margin: 15px 0;">'
      . trim(get_comment($parent_id)->comment_content) . '</p>
      <p>' . trim($comment->comment_author) . ' 给您的回复:</p>
      <p style="background-color: #EEE;border: 1px solid #DDD;padding:10px 5px;margin: 15px 0;">
      '. trim($comment->comment_content) . '</p>
      <p>您可以点击 <a style="text-decoration:none; color:#00bbff" href="' . htmlspecialchars(get_comment_link($parent_id)) . '">查看回复的完整內容</a></p>
      <p>欢迎再次光临 <a style="text-decoration:none; color:#00bbff" href="' . get_option('home') . '">' . get_option('blogname') . '</a></p>
      <p style="color:red;">(温馨提示：本邮件由系统自动发出，切勿回复)</p>
      </div>
      </div>';
      $from = "From: \"" . get_option('blogname') . "\" <$wp_email>";
      $headers = "$from\nContent-Type: text/html; charset=" . get_option('blog_charset') . "\n";
      wp_mail( $to, $subject, $message, $headers );
      //echo 'mail to ', $to, '<br/> ' , $subject, $message; // for testing
      }
    }
    add_action('comment_post', 'comment_mail_notify');

//添加没有头像的友友们漂亮的头像~~
  add_filter( 'avatar_defaults', 'default_avatar' ); 
  function default_avatar ( $avatar_defaults ) { 
  $myavatar = get_bloginfo('template_url'). '/images/olve.jpg'; //默认图片路径 
  $avatar_defaults[$myavatar] = "自定义头像"; //后台显示名称 
  return $avatar_defaults; 
  }
  
//调用方式 all_img($post->post_content);

    function all_img($soContent){
    $soImages = '/<img [^>]*src=[\"\']?([^\"\'\s]+)/i';
    //$soImages = '<a href='.the_permalink().'" rel="bookmark" title="love you '.the_title_attribute().'>'.$soImages.'</a>';
    preg_match_all( '/<img([^\/>]+)src="([^"]+)"([^\/>]+)\/>/is', $soContent, $thePics );
    $allPics = count($thePics);
    if( $allPics > 0 ){
    foreach($thePics[0] as $v){
    echo $v;
  
      }
    }
    else {
       // echo "<img src='";
       // echo bloginfo('template_url');
       // echo "/images/thumb.gif'>";
    }
    }

  function doubanplayer($atts, $content=null){
  extract(shortcode_atts(array("auto"=>'0'),$atts));
  return '<embed src="'.get_bloginfo("template_url").'/images/Mp3player.swf?url='.$content.'&amp;autoplay='.$auto.'" type="application/x-shockwave-flash" wmode="transparent" allowscriptaccess="always" width="270" height="26" />';
  }
  add_shortcode('mp3','doubanplayer');

//mp3 短链添加
add_action( 'admin_print_footer_scripts', 'shortcode_buttons', 100 );function shortcode_buttons() { ?><script type="text/javascript">QTags.addButton( 'music', 'MP3播放器', '[mp3]MP3地址[/mp3]');</script><?php } 
  // 中文截断文字
 function cut_str($string, $sublen, $start = 0, $code = 'UTF-8'){if($code == 'UTF-8'){$pa = "/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|\xe0[\xa0-\xbf][\x80-\xbf]|[\xe1-\xef][\x80-\xbf][\x80-\xbf]|\xf0[\x90-\xbf][\x80-\xbf][\x80-\xbf]|[\xf1-\xf7][\x80-\xbf][\x80-\xbf][\x80-\xbf]/";preg_match_all($pa, $string, $t_string);if(count($t_string[0]) - $start > $sublen) return join('', array_slice($t_string[0], $start, $sublen))."...";return join('', array_slice($t_string[0], $start, $sublen));}else{$start = $start*2;$sublen = $sublen*2;$strlen = strlen($string);$tmpstr = '';for($i=0; $i<$strlen; $i++){ if($i>=$start && $i<($start+$sublen)){if(ord(substr($string, $i, 1))>129) $tmpstr.= substr($string, $i, 2);else $tmpstr.= substr($string, $i, 1);}if(ord(substr($string, $i, 1))>129) $i++;}if(strlen($tmpstr)<$strlen ) $tmpstr.= "...";return $tmpstr;}};

/* Auto-description v1.3 by Willin Kan & Modified by winy */
        function head_desc_and_keywords() {
          global $s, $post;
          $description = '';
          $keywords = '';
          $blog_name = get_bloginfo('name');
          if ( is_singular() ) {
          if(!empty($post->post_password)){//有密码保护的文章不输出
            $text = "受保护的文章,输入密码查看！";
            $keywords = '';
          }else{
              $text = $post->post_content;
            if ( get_the_tags( $post->ID ) ) {
            foreach ( get_the_tags( $post->ID ) as $tag ) $keywords .= $tag->name . ', ';
            }
            foreach ( get_the_category( $post->ID ) as $category ) $keywords .= $category->cat_name . ', ';
              }
            $description = trim( str_replace( array( "\r\n", "\r", "\n", "　", " "), " ", str_replace( "\"", "'", strip_tags( $text ) ) ) );
            if ( !( $description ) ) $description = $blog_name . " - " . trim( wp_title('', false) );
          $keywords = substr_replace( $keywords, "" , -2 );
          } elseif ( is_home () )    {
          $description = get_bloginfo('description'); 
/**

* 注意这里的的关键词需要你自己修改

* 注意每个关键词要用半角“ , ”分开。

**/
          $keywords = '工作,wordpress,life,blog'; // 首頁要自己加
          } elseif ( is_tag() )      { 
          $description = $blog_name . "有关 '" . single_tag_title('', false) . "' 的文章";
          $keywords = single_tag_title('', false);
          } elseif ( is_category() ) {
          $description = $blog_name . "有关 '" . single_cat_title('', false) . "' 的文章";
          $keywords = single_cat_title('', false);
          } elseif ( is_archive() )  {
          $description = $blog_name . "在: '" . trim( wp_title('', false) ) . "' 的文章";
          $keywords = trim( wp_title('', false) );
          } elseif ( is_search() )   {
          $description = $blog_name . ": '" . esc_html( $s, 1 ) . "' 的搜索結果";
          $keywords = esc_html( $s, 1 );
          } else { 
          $description = $blog_name . "有关 '" . trim( wp_title('', false) ) . "' 的文章";
           $keywords = trim( wp_title('', false) );
          }  
          if ( $keywords ) {
            echo "<meta name=\"keywords\" content=\"$keywords\" />\n";
          }
          $description = mb_substr( $description, 0, 97, 'utf-8' ) . '..';//截取文章的前97个字符作为描述
          echo "<meta name=\"description\" content=\"$description\" />\n";
        }

        remove_action('init','wp_admin_bar_init');
        //禁用修改历史记录
        remove_action('pre_post_update','wp_save_post_revision');
        //禁止在head泄露wordpress版本号
        remove_action('wp_head','wp_generator');
        //移除head中的rel="EditURI"
        remove_action('wp_head','rsd_link');
          //强化WP后台可视化编辑器 
          //去掉输出短链接
          remove_action('wp_head', 'wp_shortlink_wp_head');
          /*
          *
          *去掉默认的最新评论css
          */
          function remove_recent_comments_style() {
            global $wp_widget_factory;
            remove_action( 'wp_head', array( $wp_widget_factory->widgets['WP_Widget_Recent_Comments'], 'recent_comments_style' ) );
          }
          add_action( 'widgets_init', 'remove_recent_comments_style' );
          /*移除li中空行*/
          function remove_white_space( $content ) {return str_replace(array("\n", "\r", "\t"), "", $content); }
          add_filter( 'wp_list_pages', 'remove_white_space' );
          add_filter( 'wp_list_categories', 'remove_white_space' );
        /**
       * common head links
       * 优化SEO，
       * function copy from philna2 & modified by winy 10.01.24
       */
      function lastwishHeadItem(){
        if(get_option('Abook_feed')!=""){
          $feed_url=get_option('Abook_feed');
        }else{
          $feed_url=get_bloginfo('rss_url');
         }
        echo
        '<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />',"\n";
        if(is_singular()){
        echo '<link rel="pingback" href="'.get_bloginfo('pingback_url').'"/>',"\n";
        }
        if(is_home() || is_front_page() || is_single() || is_page()){
          echo '<meta name="robots" content="index,follow" />', "\n";
        }elseif(is_day() || is_tag() || is_search() || is_author()){
          echo '<meta name="robots" content="noindex,follow,noodp" />', "\n";
        }else{
          echo '<meta name="robots" content="noindex,follow" />', "\n";
        }
        if(is_bot()){ wp_get_archives('type=monthly&format=link'); } // for bots
      }function is_bot(){
        $bots = array('Baiduspider1'=>'Baiduspider','Baiduspider2'=>'Baiduspider+','Google Bot1' => 'googlebot', 'Google Bot2' => 'google', 'Google AdSense' => 'Mediapartners', 'MSN' => 'msnbot', 'Yahoo Bot1' => 'yahoo', 'Yahoo Bot2' => 'Yahoo! Slurp','Yahoo Bot3' => 'Yahoo! Slurp China','YodaoBot' => 'YodaoBot','iaskspider' => 'iaskspider','Sogou web spider' => 'Sogou web spider','Sogou Push Spider' => 'Sogou Push Spider','Sosospider' => 'Sosospider','Alex' => 'ia_archiver', 'Bot'=>'bot','Spider'=>'spider','for_test'=>'sFirefox');
        $useragent = $_SERVER['HTTP_USER_AGENT'];
        foreach ($bots as $name => $lookfor) {
          if (stristr($useragent, $lookfor) !== false) {
            return true;
            break;
          }
        }
      }
 
?>
<?php
class OlveOptions {
  function getOptions() {
    $options = get_option('yefengs_olve_options');
    if (!is_array($options)) {
      $options['wrapper_box'] = false;
      $options['wrapper_url1'] = '';
      $options['wrapper_url2'] = '';
      $options['wrapper_url3'] = '';
      $options['wrapper_url4'] = '';
      $options['wrapper_url5'] = '';
      $options['wrapper_url6'] = '';
      $options['lazyload'] = false;
      $options['phzoom'] = false;
      $options['Analytics'] = '';
      update_option('yefengs_olve_options', $options);
    } return $options; }
  function init() {if(isset($_POST['classic_save'])) {
      $options = OlveOptions::getOptions();
      if ($_POST['wrapper_box']) {$options['wrapper_box'] = (bool)true;} else {$options['wrapper_box'] = (bool)false;};
      if ($_POST['lazyload']) {$options['lazyload'] = (bool)true;} else {$options['lazyload'] = (bool)false;};
      if ($_POST['phzoom']) {$options['phzoom'] = (bool)true;} else {$options['phzoom'] = (bool)false;};
      $options['wrapper_url1'] = stripslashes($_POST['wrapper_url1']);
      $options['wrapper_url2'] = stripslashes($_POST['wrapper_url2']);
      $options['wrapper_url3'] = stripslashes($_POST['wrapper_url3']);
      $options['wrapper_url4'] = stripslashes($_POST['wrapper_url4']);
      $options['wrapper_url5'] = stripslashes($_POST['wrapper_url5']);
      $options['wrapper_url6'] = stripslashes($_POST['wrapper_url6']); 
      $options['Analytics'] = stripslashes($_POST['Analytics']);
      update_option('yefengs_olve_options', $options);
      echo "<div id='message' class='updated fade'><p><strong>设置已保存</strong></p></div>";
    } else {OlveOptions::getOptions();}add_theme_page("主题设置", "主题设置", 'edit_themes', basename(__FILE__), array('OlveOptions', 'display'));}
  function display() { $options = OlveOptions::getOptions();
?>
<style type="text/css">#wrapbox{position:relative;background:url(data:image/gif;base64,R0lGODlhCAAIAJEAAMzMzP///////wAAACH5BAEHAAIALAAAAAAIAAgAAAINhG4nudroGJBRsYcxKAA7);font-family:'微软雅黑',Arial,sans-serif;font-size:13px;width:600px;margin:30px auto 40px auto;border:solid 1px #bab;box-shadow:5px 5px 5px rgba(0,0,0,0.5);border-radius:5px 5px}#wrapbox h1{color:rgb(255,123,123);text-shadow:2px 2px 5px #000;font-size:60px;text-align:center;font-style:italic;font-family:Georgia,serif}#wrapbox .yefengstheme{float:right;color:rgb(68,68,68);padding-right:20px;text-shadow:1px 1px 1px rgba(255,255,255,0.8),2px 2px 3px rgba(0,0,0,0.8)}#wrapbox .banben{padding-right:8px;position:absolute;top:60px;right:80px;font-style:italic;color:rgb(248,82,82);text-shadow:1px 1px 1px rgba(255,255,255,0.8),2px 2px 3px rgba(0,0,0,0.8)}#tabtop{height:30px;text-align:center;border-bottom:1px solid rgb(187,170,187);position:relative}#tabtopbox{position:absolute;bottom:7px}#tabtop span{font-size:14px;cursor:pointer;border-radius:5px 5px 1px 1px;margin-left:8px;display:block;float:left;margin-bottom:-8px;border:1px solid rgb(187,170,187);padding:2px 5px 5px 5px;background:#eee}#tabtop .selected{background:#fff;border-bottom:1px solid #fff}.nodisplay{display:none}.yefengstab{width:100%;heght:400px;background:#FFF}.choice{border-bottom:1px solid #ddd;padding:4px 7px;overflow:hidden}.choice .span1{float:left}.choice .span2{float:left;margin-top:10px}.choice .span3{float:right;width:333px;color:rgba(0,0,0,0.4)}.choice input[type=text]{width:350px;border:1px solid #1E221C;padding:2px 1px}.choice .input1{width:320px !important}.choice .input2{width:150px !important}.choice .input3{width: 505px !important;margin-left: 10px;}.sns_title{width: 70px;display: inline-table;}.choice textarea{padding:8px 4px;border:1px solid #1E221C;margin:9px;width:570px}.submit{margin-top:7px;margin-left:7px;padding:0;float:left}.submit input,.submit input:active{margin:4px 10px;width:87px;height:26px;color:#393939;text-align:center;text-shadow:0px 1px 0px #fff;box-shadow:2px 2px 2px #000;margin-top:8px;border:1px solid #ddd;box-shadow:0 2px 10px #eee,inset 0 -2px 10px #eee;-moz-border-radius:5px;-webkit-border-radius:5px;border-radius:5px;-moz-transition:all .5s ease-in-out;-webkit-transition:all .5s ease-in-out;-o-transition:all .5s ease-in-out;-ms-transition:all .5s ease-in-out;transition:all .5s ease-in-out}.submit input:hover{border:1px solid #aaa;cursor:pointer}</style>
<script type='text/javascript'>jQuery(document).ready(function(a){a(".settabbox #tabtop span").click(function(){a(this).addClass("selected").siblings().removeClass();a(".settabbox .settingbox").slideUp("10").eq(a(".settabbox #tabtop span").index(this)).slideDown("10")})});</script>
<form action="#" method="post" enctype="multipart/form-data" name="yefengs_form" id="yefengs_form">
  <div id="wrapbox">  
    <h1>Olve</h1><span class="yefengstheme">I love you girl.</span><span class="banben">v 5.2.0</span><br/>
  <div class="settabbox">
          <div id="tabtop">
                  <div id="tabtopbox">
          <span class="selected">基本设置</span>
          <span>背景幻灯片</span>
                  </div>
          </div>
        <div class="settingbox">
    <div class="yefengstab">
      <br />
      <div class="choice">
        <span class="span1">lazyload图片延迟加载：</span>
        <div class="choice_radio">
          <label><input name="lazyload" class="lazyload" type="checkbox" value="checkbox" <?php if($options['lazyload']) echo "checked='checked'"; ?> />开启</label>
        </div>
      </div>
      <div class="choice">
        <span class="span1">phzoom图片放大：</span>
        <div class="choice_radio">  
          <label><input name="phzoom" class="phzoom" type="checkbox" value="checkbox" <?php if($options['phzoom']) echo "checked='checked'"; ?> />开启</label>
        </div>
      </div>
    <div class="choice">
      <span class="span2">统计信息</span>
      <textarea name="Analytics" rows="4" id="Analytics"><?php echo($options['Analytics']); ?></textarea>
    </div>

           </div>
          </div>        
          <div class="settingbox nodisplay">
                  <div class="yefengstab">
                    <br />
             <div class="choice">
            <span class="span1">自定义随机背景：</span>
            <div class="choice_radio">
              <label>
                <input name="wrapper_box" class="wrapper_box" type="checkbox" value="checkbox"<?php if($options['wrapper_box']) echo "checked='checked'"; ?> /> 开启
              </label>
            </div>
            <span class="span1">第一张：</span>
            <div class="choice_radio">
            <br/>图片URL<input class="input3"  type="text" id="wrapper_url1" name="wrapper_url1" value="<?php echo($options['wrapper_url1']); ?>" />
            </div>
            <span class="span1">第二张：</span>
            <div class="choice_radio">
            <br/>图片URL<input class="input3"  type="text" id="wrapper_url2" name="wrapper_url2" value="<?php echo($options['wrapper_url2']); ?>" />
            </div>
            <span class="span1">第三张：</span>           
            <div class="choice_radio">
            <br/>图片URL<input class="input3"  type="text" id="wrapper_url3" name="wrapper_url3" value="<?php echo($options['wrapper_url3']); ?>" />
            </div>
            <span class="span1">第四张：</span>
            <div class="choice_radio">
            <br/>图片URL<input class="input3"  type="text" id="wrapper_url4" name="wrapper_url4" value="<?php echo($options['wrapper_url4']); ?>" />
            </div>
            <span class="span1">第五张：</span>
            <div class="choice_radio">
            <br/>图片URL<input class="input3"  type="text" id="wrapper_url5" name="wrapper_url5" value="<?php echo($options['wrapper_url5']); ?>" />
            </div>
            <span class="span1">第六张：</span>           
            <div class="choice_radio">
            <br/>图片URL<input class="input3"  type="text" id="wrapper_url6" name="wrapper_url6" value="<?php echo($options['wrapper_url6']); ?>" />
            </div>
            <p>
              注意：若开启自定义背景，请务必定义6张壁纸URL，否则可能出现不可预知的问题。
            </p>
            <p></p>
          </div>
          </div>
          </div>
      <p class="submit">
      <input type="submit" name="classic_save" value="更新设置" />
    </p><br/>
    <p><span style="float:right;padding-right:30px;">感谢您的使用! 若在使用过程中若有问题请到<a href="http://yefengs.com/theme/olve">yefengs.com</a>留言。</span></p>
    <p></p>
    <div style="clear:both"></div>  
  </div>
</div>
</form>
<?php
  }
}
add_action('admin_menu', array('OlveOptions', 'init'));
?>