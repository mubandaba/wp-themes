<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html <?php language_attributes(); ?>>
	<head>
		<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
		<title><?php if ( is_tag() ) { echo wp_title('Tag:');if($paged > 1) printf(' - 第%s页',$paged);echo ' | '; bloginfo( 'name' );} elseif ( is_archive() ) {echo wp_title('');  if($paged > 1) printf(' - 第%s页',$paged);    echo ' | ';    bloginfo( 'name' );} elseif ( is_search() ) {echo '&quot;'.wp_specialchars($s).'&quot;的搜索结果 | '; bloginfo( 'name' );} elseif ( is_home() ) {bloginfo( 'name' );$paged = get_query_var('paged'); if($paged > 1) printf(' - 第%s页',$paged);}  elseif ( is_404() ) {echo '404错误 页面不存在！ | '; bloginfo( 'name' );} else {echo wp_title( ' | ', false, right )  ; bloginfo( 'name' );} ?></title>
		<?php  head_desc_and_keywords();  lastwishHeadItem(); ?>
		<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
		<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
		<script type='text/javascript' src='http://lib.sinaapp.com/js/jquery/1.4.4/jquery.min.js'></script>
		<script type="text/javascript">window.jQuery || document.write('<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/jquery.js">\x3C/script>')</script>
		<script src="<?php bloginfo('template_directory'); ?>/js/olve.js"></script>
		<!--[if IE 7]><script>alert ("\u4eb2~~ \n \u4f60\u5c06\u8981\u770b\u5230\u51cc\u4e71\u7684\u9875\u9762\uff0c\u4f60\u53ef\u77e5\u9053\u6211\u6bd4\u4f60\u66f4\u51cc\u4e71\uff0c\u4f60\u8bf4\u4f60\u7684\u6d4f\u89c8\u5668\u81f3\u5c11\u662f\u4e2aIE7\u5427\uff01");</script>  <![endif]-->
		<?php if(is_singular()): ?>
			<script src="<?php bloginfo('template_directory'); ?>/include/comments-ajax.js"></script>
		<?php endif; ?>
		<?php wp_head(); ?>
		<script type="text/javascript"> $.backstretch("<?php $options = get_option('yefengs_olve_options');if($options['wrapper_box']){$a=rand(1,5);switch ($a){  case 1:  echo $options['wrapper_url1']; break;case 2:  echo $options['wrapper_url2']; break;	case 3:  echo $options['wrapper_url3']; break;case 4:  echo $options['wrapper_url4']; break;	case 5:  echo $options['wrapper_url5']; break;	default: echo $options['wrapper_url6']; break;}}else{bloginfo('template_directory');echo "/images/Bigbg/".rand(1,6).".jpg";} ?>", {speed: 850});</script>
	</head>

	<?php if($options['lazyload']): ?>
	<script src="<?php bloginfo('template_url'); ?>/js/lazyload.js"></script>
	<script  type="text/javascript">$(document).ready(function () {$('.post img,.commentlist img,.avatar,#recentcomments li img').lazyload({effect : "fadeIn"}); });</script>
	<?php endif; ?>


	<body>
	  <div id="wrapper">
<div id="headerbox">
  		<header>
  			<div id="logo"><a href="<?php echo home_url(); ?>/" title="<?php bloginfo('description'); ?>">
				<img alt="<?php bloginfo('name'); ?>" src="<?php bloginfo('template_directory'); ?>/images/header.png" height="84" width="84"/>
  			  </a>
  			</div>
			<div id="headers">
	  				<h1>
	  					<a href="<?php echo home_url(); ?>/" title="<?php bloginfo('description'); ?>"><?php bloginfo('name'); ?></a>
	  				</h1>
	  			<div id="description"><?php bloginfo('description'); ?></div>
	  			<nav id="hmenu">
	  				<?php wp_nav_menu( array( 'container_class' => 'menu1', 'theme_location' => 'topbar' ) ); ?>
	  			<nav>
			</div> 
	  			<h3 id="neighborlink">友情链接</h3>
	  			<div id="myneighbor">
					<ul class="neighborlist">
						<?php wp_list_bookmarks('title_li=&categorize=0'); ?>
					</ul>
	  			</div>
	  			<div class="searchbox">
						<form id="searchform" method="get" action="<?php echo $_SERVER['PHP_SELF']; ?>">
						<input type="text" value="搜索一下...." name="s" id="s" style="width: 100%;color:#999" onfocus="if (this.value == '搜索一下....') {this.value = '';}" onblur="if (this.value == '') {this.value = '搜索一下....';}" x-webkit-speech="x-webkit-speech"/></form>
				</div>
  		</header>

  	</div>
  	<div id="postlist">
  		<section>
  			<div id="autologo">
  			 	<div id="logo"><a href="<?php echo home_url(); ?>/" title="<?php bloginfo('description'); ?>">
  			 	<img alt="<?php bloginfo('name'); ?>" src="<?php bloginfo('template_directory'); ?>/images/header.png" height="84" width="84"/></a>
  				</div>
  			</div>