<?php get_header(); ?>
			<article class="articlepost" >
				<h2>404 Error</h2>
				<div class="contentpost">
				<span style="font-size:100px;margin:40px;text-align:center;text-shadow: 6px 6px 4px rgba(0,0,0,0.2);">404</span>	
				<p>对不起！您请求的页面不存在，请检查你的链接是否有误！</p>
				<hr class="clearfix" />
			</div>
			 <div class="shadows"></div>
			<div class="postmetadata">
			<span class="commentnum">404 - Content Not Found</span>
			</div>
			</article>



<?php get_footer(); ?>