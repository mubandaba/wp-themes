<?php
/*
Template Name: Archives
*/
?>

<?php get_header(); ?>

	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<article class="articlepost" id="post-<?php the_ID(); ?>">
				<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
			<div class="contentpost">	
							<?php the_content('全文阅读 &raquo;'); ?>
					<div id="control" style="cursor:pointer;color:#666666;text-shadow: 0 0 2px rgb(46, 99, 180);float: right;font-size: 15px;">全部展开/收起</div>
									<hr class="clearfix" />
						<div class="my-archive">
							<?php
								$previous_year = $year = 0;
								$previous_month = $month = 0;
								$ul_open = false;
								$myposts = get_posts('numberposts=-1&orderby=post_date&order=DESC');
							?>
							<?php foreach($myposts as $post) : ?>
							<?php
								setup_postdata($post);
								$year = mysql2date('Y', $post->post_date);
								$month = mysql2date('n', $post->post_date);
								$day = mysql2date('j', $post->post_date);
							?>
							<?php if($year != $previous_year || $month != $previous_month) : ?>
							<?php if($ul_open == true) : ?>
							</ul>
								<?php endif; ?>
								<h4 style="cursor:pointer;color:#000000;"><?php the_time('Y年 m月'); ?></h4>
							<ul>
								<?php $ul_open = true; ?>
								<?php endif; ?>
								<?php $previous_year = $year; $previous_month = $month; ?>
							<li><span> <?php the_time('d'); ?>日 <a href="<?php the_permalink(); ?>" title="阅读「<?php the_title(); ?>」吧~"><?php the_title(); ?></a><span style="float:right;"><a href="<?php comments_link(); ?>" title="查看 <?php the_title(); ?> 的评论"><?php comments_number('0', '1', '%'); ?>人吐槽</a></span><span style="float:right; padding-right:20px;"><?php //post_views(' ', '℉'); ?></span></span></li>
							<?php endforeach; ?>
							</ul>
							</div>
							<script type="text/javascript">
								jQuery(function($){
									$('.my-archive ul:gt(0)').hide();//第0和1 列默认显示，其他默认隐藏
									$('.my-archive h4').click(function() {//点击标题动作
									$('.my-archive ul').slideUp(300);//展开选择列
									$(this).next('ul').slideDown(500);//缩放同级其他元素
									});
									//一下是全局的操作
									$('#control').toggle(
									function(){
										$('.my-archive ul').slideUp();
									},
									function(){
										$('.my-archive ul').slideDown();
									});	
								});	
							</script>
				<hr class="clearfix" />
			</div>
			 <div class="shadowss"></div>
			<div class="normalpostmetadata">
			<time class="postmetinfo">
				<a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_time(get_option('date_format')) ?></a></time>
				标签：<?php the_tags('', '/ ' ,  ''); ?>
		        归档：<?php the_category(', '); ?>
			<span class="commentnum"><?php edit_post_link('Edit', '[', ']'); ?>  <?php comments_popup_link('No Comment', '1 Comment', '% Comments'); ?></span>
			</div>
			<div class="shadowsr"></div>
			<?php comments_template(); ?>
			</article>
	<?php endwhile; else: ?>
		<p>Sorry, no posts matched your criteria.</p>
	<?php endif; ?>

<?php get_footer(); ?>
