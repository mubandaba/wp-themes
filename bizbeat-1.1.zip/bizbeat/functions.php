<?php
////////////////////////////////////////////////////////////////////////////////
// Global Define
////////////////////////////////////////////////////////////////////////////////
// do not change this, its for translation and options string
define('TEMPLATE_DOMAIN', 'bizbeat');
// do not change this, its for translation and options string
define('TEMPLATE_OPTIONS', TEMPLATE_DOMAIN . '_theme_options');
define('SUPER_STYLE', 'no');

////////////////////////////////////////////////////////////////////////////////
// Add Language Support
////////////////////////////////////////////////////////////////////////////////
load_theme_textdomain( TEMPLATE_DOMAIN, get_template_directory() . '/languages' );

////////////////////////////////////////////////////////////////////////////////
// Additional Theme Support
////////////////////////////////////////////////////////////////////////////////
if ( function_exists( 'add_theme_support' ) ) {
add_theme_support( 'post-thumbnails' );
// Add default posts and comments RSS feed links to head
add_theme_support( 'automatic-feed-links' );
add_editor_style();
if( class_exists('woocommerce') ) { add_theme_support('woocommerce'); }
// Add support for custom background.
$custom_background_support = array(
	'default-color'          => '',
	'default-image'          => '',
	'wp-head-callback'       => '_custom_background_cb',
	'admin-head-callback'    => '',
	'admin-preview-callback' => ''
);
add_theme_support( 'custom-background', $custom_background_support );


// Add support for custom headers.
$custom_header_support = array(
// The default header text color.
		'default-text-color' => '',
        'default-image' => '',
        'header-text'  => false,
		// The height and width of our custom header.
		'width' => 1440,
		'height' => 300,
		// Support flexible heights.
		'flex-height' => true,
		// Random image rotation by default.
	   'random-default'	=> false,
		// Callback for styling the header.
		'wp-head-callback' => '',
		// Callback for styling the header preview in the admin.
		'admin-head-callback' => '',
		// Callback used to display the header preview in the admin.
		'admin-preview-callback' => '',
);
add_theme_support( 'custom-header', $custom_header_support );

if ( ! isset( $content_width ) ) $content_width = 550;
}

if ( function_exists( 'register_nav_menus' ) ) {
add_theme_support( 'menus' );
register_nav_menus( array(
'top' => __( 'Top Menu', TEMPLATE_DOMAIN ),
'primary' => __( 'Primary Menu', TEMPLATE_DOMAIN ),
'footer' => __( 'Footer Menu', TEMPLATE_DOMAIN ),
));
function revert_wp_menu_page($args) {
$pages_args = array(
		'depth'      => 0,
		'echo'       => false,
		'exclude'    => '',
		'title_li'   => ''
	);
$menu = wp_page_menu( $pages_args );
$menu = str_replace( array( '<div class="menu"><ul>', '</ul></div>' ), array( '<ul class="sf-menu">', '</ul>' ), $menu );
echo $menu;
 ?>
<?php }

if ( !function_exists( 'wp_dtheme_page_menu_args' ) ) :
function wp_dtheme_page_menu_args( $args ) {
$args['show_home'] = true; return $args; }
add_filter( 'wp_page_menu_args', 'wp_dtheme_page_menu_args' );
endif;

}

function theme_custom_style_init() {
global $theme_version,$is_IE;
if($is_IE): ?>
<style type="text/css">
#top-navigation,#main-navigation,.post-meta,a.button,input[type='button'], input[type='submit'],h1.post-title,.wp-pagenavi a,#sidebar .item-options,.iegradient,h3.widget-title,.footer-bottom,.sf-menu .current_page_item a, .sf-menu .current_menu_item a, .sf-menu .current-menu-item a,.sf-menu .current_page_item a:hover, .sf-menu .current_menu_item a:hover, .sf-menu .current-menu-item a:hover {filter: none !important;}
</style>
<?php endif; ?>


<?php print "<style type='text/css' media='all'>";
$feat_size = get_theme_option('feat_img_size');
if($feat_size == ''){ $feat_size = 'thumbnail'; }
$thumb_w = get_option($feat_size.'_size_w');
$thumb_h = get_option($feat_size.'_size_h');
?>

<?php if($feat_size != 'large'){ ?>
#post-entry div.post-thumb {float:left;width:<?php echo $thumb_w; ?>px;}
#post-entry article .post-right {margin:0 0 0 <?php echo $thumb_w + 10; ?>px;}
<?php } else { ?>
#post-entry div.post-thumb {width:100%;}
#post-entry article .post-right {width:100%;float:left;margin:1em 0 0;}
#post-entry article .post-right span.post-calendar {top: -30px;right: -50px;}
<?php } ?>

<?php get_template_part ( '/lib/options/options-css' ); ?>
<?php if( get_theme_option('custom_css') ): ?><?php echo get_theme_option('custom_css'); ?><?php endif; ?>
<?php print "</style>"; ?>
<?php }
add_action('wp_head','theme_custom_style_init');

///////////////////////////////////////////////////////////////////////////////
// Load Theme Default Fonts
///////////////////////////////////////////////////////////////////////////////
/*---------------------------load google webfont style--------------------------------------*/
function mp_theme_load_gwf_styles() {

if( get_theme_option('body_font') == 'Choose a font' || get_theme_option('body_font') == '') {
wp_register_style('default_body_gwf', '');
wp_enqueue_style( 'default_body_gwf');
}

if( get_theme_option('headline_font') == 'Choose a font' || get_theme_option('headline_font') == '') {
wp_register_style('default_headline_gwf', '');
wp_enqueue_style( 'default_headline_gwf');
}

if( get_theme_option('navigation_font') == 'Choose a font' || get_theme_option('navigation_font') == '') {
wp_register_style('default_navigation_gwf', '');
wp_enqueue_style( 'default_navigation_gwf');
}

}
//add_action('wp_enqueue_scripts', 'mp_theme_load_gwf_styles');

///////////////////////////////////////////////////////////////////////////////
// Load Theme Styles and Javascripts
///////////////////////////////////////////////////////////////////////////////
/*---------------------------load styles--------------------------------------*/
if ( ! function_exists( 'theme_load_styles' ) ) :
function theme_load_styles() {
global $theme_version,$is_IE;

wp_enqueue_style( 'superfish', get_template_directory_uri(). '/lib/scripts/superfish-menu/css/superfish.css', array(), $theme_version );

wp_enqueue_style( 'tabber', get_template_directory_uri() . '/lib/scripts/tabber/tabber.css', array(), $theme_version );

if( get_theme_option('jcarousel_on') == 'Enable' ) {
wp_enqueue_style( 'jcarousel-css', get_template_directory_uri() . '/lib/scripts/jcarousel/jcarousel.responsive.css', array(), $theme_version );
}

if ( ( is_home() || is_front_page() || is_page_template('page-templates/template-blog.php') ) && get_theme_option('slider_on') == 'Enable'  ) {
wp_enqueue_style( 'jd-gallery-css', get_template_directory_uri(). '/lib/scripts/jd-gallery/jd.gallery.css', array(), $theme_version );
}

/*load font awesome */
wp_enqueue_style( 'font-awesome-cdn', '//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css', array(), $theme_version );

?>
<?php
}
endif;
add_action( 'wp_enqueue_scripts', 'theme_load_styles' );

/*---------------------------load js scripts--------------------------------------*/
if ( ! function_exists( 'theme_load_scripts' ) ) :
function theme_load_scripts() {
global $theme_version,$is_IE;
wp_enqueue_script("jquery");
wp_enqueue_script('hoverIntent');

wp_enqueue_script('modernizr', get_template_directory_uri() . '/lib/scripts/modernizr/modernizr.js', false, $theme_version, true );

if($is_IE):
wp_enqueue_script('html5shim', '//html5shiv.googlecode.com/svn/trunk/html5.js', false,$theme_version, false );
endif;

wp_enqueue_script( 'tabber', get_template_directory_uri() . '/lib/scripts/tabber/tabber.js', false, $theme_version, true );

if( get_theme_option('jcarousel_on') == 'Enable' ) {
wp_enqueue_script( 'jcarousel-min', get_template_directory_uri() . '/lib/scripts/jcarousel/jquery.jcarousel.min.js', false, $theme_version, true );
wp_enqueue_script( 'jcarousel-responsive', get_template_directory_uri() . '/lib/scripts/jcarousel/jcarousel.responsive.js', false, $theme_version, true );
}

wp_enqueue_script('superfish-js', get_template_directory_uri() . '/lib/scripts/superfish-menu/js/superfish.js', false, $theme_version, true );
wp_enqueue_script('supersub-js', get_template_directory_uri() . '/lib/scripts/superfish-menu/js/supersubs.js', false, $theme_version, true );


if ( ( is_home() || is_front_page() || is_page_template('page-templates/template-blog.php') ) && get_theme_option('slider_on') == 'Enable' ) {
wp_enqueue_script('mootools-js', get_template_directory_uri(). '/lib/scripts/jd-gallery/mootools.v1.11.js', false, $theme_version, true );
wp_enqueue_script('jd-gallery2-js', get_template_directory_uri(). '/lib/scripts/jd-gallery/jd.gallery.v2.js', false, $theme_version, true );
wp_enqueue_script('jd-gallery-set-js', get_template_directory_uri(). '/lib/scripts/jd-gallery/jd.gallery.set.js', false, $theme_version, true );
wp_enqueue_script('jd-gallery-transitions-js', get_template_directory_uri(). '/lib/scripts/jd-gallery/jd.gallery.transitions.js', false, $theme_version, true );
}

wp_enqueue_script('custom-js', get_template_directory_uri() . '/lib/scripts/custom.js', false,$theme_version, true );

if ( is_singular() && get_option( 'thread_comments' ) && comments_open() ) wp_enqueue_script( 'comment-reply' ); ?>

<?php }
endif;
add_action( 'wp_enqueue_scripts', 'theme_load_scripts' );


function add_header_social_button() { get_template_part( 'lib/templates/social-box' ); }
add_action('bp_inside_topnav','add_header_social_button');

function add_header_breadcrumbs() { if( !is_home() && !is_404() ) { get_template_part( 'lib/templates/breadcrumbs' ); } }
add_action('bp_before_blog_home','add_header_breadcrumbs');

/* add custom image header */
function mp_add_custom_header() {
if( get_header_image() ) {
echo "<div class='innerwrap-custom-header'>";
echo "<div id='custom-img-header'><img src='". header_image() . "' alt='' /></div>";
echo "</div>";
}
}
add_action('bp_after_nav','mp_add_custom_header',10);

/* add jcarousel */
function mp_add_jcarousel() {
if( get_theme_option('jcarousel_on') == 'Enable' ) {
get_template_part( 'lib/sliders/jcarousel' );
}
}
add_action('bp_after_nav','mp_add_jcarousel',5);


/* add slider */
function mp_add_slider_frontpage() {
global $page, $paged;
$paged = get_query_var( 'paged' );
if( ( is_home() || is_front_page() || is_page_template('page-templates/template-blog.php')) && get_theme_option('slider_on') == 'Enable'):
if ( !$paged ) { ?>
<?php get_template_part( 'lib/sliders/gallery-slider' ); ?>
<?php }
endif;
}
add_action('bp_before_blog_entry','mp_add_slider_frontpage');

////////////////////////////////////////////////////////////////////////////////
// Add Theme Custom Functions
////////////////////////////////////////////////////////////////////////////////
include( get_template_directory() . '/lib/functions/theme-functions.php' );
include( get_template_directory() . '/lib/functions/option-functions.php' );
include( get_template_directory() . '/lib/functions/widget-functions.php' );

////////////////////////////////////////////////////////////////////////////////
// Add Theme Extra Functions
////////////////////////////////////////////////////////////////////////////////
if ( file_exists( get_template_directory() . '/dev-functions.php' ) ) {
include( get_template_directory() . '/dev-functions.php' );
}
?>