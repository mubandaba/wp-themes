<?php
$jcarousel_on = get_theme_option('jcarousel_on');
$jcarousel_category = get_theme_option('jcarousel_cat');
$jcarousel_number = get_theme_option('jcarousel_cat_count');
$jcarousel_post = get_theme_option('jcarousel_post');
?>

<?php if($jcarousel_on == 'Enable'): ?>
<?php if(!$jcarousel_category && !$jcarousel_post): ?>
<?php else: ?>
<?php if($jcarousel_category): ?>

<div class="jcarousel-wrapper">
<div class="jcarousel">
<ul>
<?php
$query = new WP_Query( "cat=$jcarousel_category&posts_per_page=$jcarousel_number&orderby=date" );
while ( $query->have_posts() ) : $query->the_post();
$thepostlink = '<a href="'. get_permalink() . '" title="' . the_title_attribute('echo=0') . '">';
?>
<?php echo get_featured_post_image("<li>".$thepostlink, "</a><span>" . the_title_attribute('echo=0') . "</span></li>", 200, 200, "alignleft", "thumbnail", 'image-'.get_the_ID() ,the_title_attribute('echo=0'), false); ?>
<?php endwhile; wp_reset_query(); ?>
</ul>
</div>
<a href="#" class="jcarousel-control-prev">&lsaquo;</a>
<a href="#" class="jcarousel-control-next">&rsaquo;</a>
<p class="jcarousel-pagination"></p>
</div>

<?php elseif($jcarousel_post && !$jcarousel_category): ?>

<div class="jcarousel-wrapper">
<div class="jcarousel">
<ul>
<?php
$allposttype = mp_get_all_posttype();
query_posts( array( 'post__in' => explode(',', $jcarousel_post), 'post_type'=> $allposttype, 'posts_per_page' => 100, 'ignore_sticky_posts' => 1, 'orderby' => 'post__in', 'order' => '' ) );
while ( have_posts() ) : the_post();
$thepostlink = '<a href="'. get_permalink() . '" title="' . the_title_attribute('echo=0') . '">';
?>
<?php echo get_featured_post_image("<li>".$thepostlink, "</a><span>" . the_title_attribute('echo=0') . "</span></li>", 200, 200, "alignleft", "thumbnail", 'image-'.get_the_ID() ,the_title_attribute('echo=0'), false); ?>
<?php endwhile; wp_reset_query(); ?>
</ul>
</div>
<a href="#" class="jcarousel-control-prev">&lsaquo;</a>
<a href="#" class="jcarousel-control-next">&rsaquo;</a>
<p class="jcarousel-pagination"></p>
</div>

<?php endif; ?>
<?php endif; ?>
<?php endif; ?>