<?php
/* options css */
$header_image = get_header_image();
$bg_image = get_background_image();
$bg_color = get_background_color();
?>

<?php if(!$bg_image && !$bg_color) { ?>
body {background: #0d4d7c url(<?php echo get_template_directory_uri(); ?>/images/bg.jpg) repeat-x top center;}
<?php } ?>

<?php
if( get_theme_option('body_font') == 'Choose a font' || get_theme_option('body_font') == '') { ?>
body { font-family: arial, sans-serif; font-weight: normal; }
<?php } else { ?>
body { font-family: <?php echo get_theme_option('body_font'); ?> !important; font-weight: <?php echo get_theme_option('body_font_weight'); ?>; }
<?php } ?>

<?php
if( get_theme_option('headline_font') == 'Choose a font' || get_theme_option('headline_font') == '') { ?>
<?php } else { ?>
#siteinfo div,h1,h2,h3,h4,h5,h6,.header-title,#main-navigation, #featured #featured-title, #cf .tinput, #wp-calendar caption,.flex-caption h1,#portfolio-filter li,.nivo-caption a.read-more,.form-submit #submit,ol.commentlist li div.comment-post-meta, .home-post span.post-category a,ul.tabbernav li a,#post-entry .post-meta span a,#post-entry .post-meta span abbr {
font-family:  <?php echo get_theme_option('headline_font'); ?> !important; font-weight: <?php echo get_theme_option('headline_font_weight'); ?>;}
<?php } ?>

<?php
if( get_theme_option('navigation_font') == 'Choose a font' || get_theme_option('navigation_font') == '') { ?>
#main-navigation, .sf-menu li a { font-family:verdana,arial; font-weight: normal;}
<?php } else { ?>
#main-navigation, .sf-menu li a { font-family:  <?php echo get_theme_option('navigation_font'); ?> !important; font-weight: <?php echo get_theme_option('navigation_font_weight'); ?>;}
<?php } ?>