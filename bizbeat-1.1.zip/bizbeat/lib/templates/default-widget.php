<aside class="widget">
<h3 class="widget-title"><?php _e('Search', TEMPLATE_DOMAIN); ?></h3>
<?php get_search_form(); ?>
</aside>

<?php get_template_part('lib/templates/tabber-widget'); ?>

<?php $get_right_ads_code = get_theme_option('ads_right_sidebar'); if($get_right_ads_code != '') { ?>
<aside class="widget ctr-ad">
<div class="textwidget adswidget"><?php echo stripcslashes($get_right_ads_code); ?></div>
</aside>
<?php } ?>

<?php get_template_part('lib/templates/advertisement'); ?>

<?php get_template_part('lib/templates/sidebar-feat-cat'); ?>

<aside class="widget">
<h3 class="widget-title"><?php _e('Topics', TEMPLATE_DOMAIN); ?></h3>
<ul><?php wp_list_categories('orderby=name&show_count=1&title_li='); ?></ul>
</aside>

<aside class="widget widget_recent_entries">
<h3 class="widget-title"><?php _e('Recent Posts', TEMPLATE_DOMAIN); ?></h3>
<ul><?php wp_get_archives('type=postbypost&limit=5'); ?></ul>
</aside>