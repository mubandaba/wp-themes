<?php
global $post;
if( get_theme_option('social_on') == 'Enable') { ?>
<div class="share_box">
<p class="fb"><a title="<?php _e('Share this post in Facebook', TEMPLATE_DOMAIN); ?>" href="http://www.facebook.com/sharer.php?u=<?php echo urlencode(get_permalink()); ?>"><i class="fa fa-facebook-square">&nbsp;</i></a></p>
<p class="tw"><a title="<?php _e('Share this post in Twitter', TEMPLATE_DOMAIN); ?>" href="http://twitter.com/share?text=<?php echo urlencode( the_title_attribute('echo=0')); ?>&url=<?php echo urlencode(get_permalink()); ?>"><i class="fa fa-twitter-square">&nbsp;</i></a></p>
<p class="gp"><a title="<?php _e('Share this post in Google+', TEMPLATE_DOMAIN); ?>" href="https://plus.google.com/share?url=<?php echo urlencode(get_permalink()); ?>"><i class="fa fa-google-plus-square">&nbsp;</i></a></p>
</div>
<?php } ?>