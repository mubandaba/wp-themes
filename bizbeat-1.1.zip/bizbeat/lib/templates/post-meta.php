<div class="post-meta the-icons<?php global $in_bbpress; if( is_page() || $in_bbpress == 'true' ){ echo ' meta-no-display'; } ?>">
<?php get_template_part( 'lib/templates/share-box' ); ?>

<span class="post-author vcard"><?php _e('By', TEMPLATE_DOMAIN); ?> <?php the_author_posts_link(); ?></span>


<?php if( get_post_type() != 'post' && get_post_type() != 'page' ) { ?>
<?php echo the_taxonomies('before=<span class="post-category post-tax">&after=</span>'); ?>
<?php } else { ?>
<span class="post-category"> <?php _e('in', TEMPLATE_DOMAIN); ?> <?php if( !is_singular() ) { ?><?php echo get_singular_cat(); ?><?php } else { ?><?php the_category(', ') ?><?php } ?></span>
<?php } ?>

<?php if ( comments_open() ) { ?>
<span class="post-comment"> - <?php comments_popup_link(__('No Comment',TEMPLATE_DOMAIN), __('1 Comment',TEMPLATE_DOMAIN), __('% Comments',TEMPLATE_DOMAIN) ); ?></span><?php } ?>

<span class="post-time entry-date meta-no-display"><abbr class="published" title="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo the_time( get_option( 'date_format' ) ); ?></abbr></span>

<span class="post-calendar"><p class="p-date"><?php the_time('j'); ?></p><p class="p-month"><?php the_time('M'); ?></p></span>

<?php $getmodtime = get_the_modified_time(); if( !$getmodtime ) { $modtime = '<span class="date updated meta-no-display">'. get_the_time('c') . '</span>'; } else { $modtime = '<span class="date updated meta-no-display">'. get_the_modified_time('c') . '</span>'; } ?>
<span class="meta-no-display"><a href="<?php echo esc_url( get_permalink() ); ?>" rel="bookmark"><?php echo the_title_attribute(); ?></a></span><?php echo $modtime; ?>

</div>