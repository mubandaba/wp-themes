<?php if( has_tag() ) { ?>
<div class="post-meta the-icons pmeta-bottom">
<span class="post-tags fa fa-tags"><?php the_tags('', ', '); ?></span>
</div>
<?php } ?>