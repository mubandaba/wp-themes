<div id="socialbox">

<p class="rss"><span><a title="<?php _e('Subscribe to rss feed', TEMPLATE_DOMAIN); ?>" href="<?php if( get_theme_option('rss_feed') ): ?><?php echo stripcslashes( get_theme_option('rss_feed') ); ?><?php else: ?><?php echo bloginfo('rss2_url'); ?><?php endif; ?>">&nbsp;</a></span></p>

<?php if( get_theme_option('facebook_page') ): ?>
<p class="facebook"><span><a title="<?php _e('Like us on Facebook', TEMPLATE_DOMAIN); ?>" href="<?php echo stripcslashes( get_theme_option('facebook_page') ); ?>">&nbsp;</a></span></p>
<?php endif; ?>

<?php if( get_theme_option('twitter_page') ): ?>
<p class="twitter"><span><a title="<?php _e('Follow us on Twitter', TEMPLATE_DOMAIN); ?>" href="<?php echo stripcslashes( get_theme_option('twitter_page') ); ?>">&nbsp;</a></span></p>
<?php endif; ?>

<?php if( get_theme_option('gplus_page') ): ?>
<p class="gplus"><span><a title="<?php _e('Check out our Google Plus profile', TEMPLATE_DOMAIN); ?>" href="<?php echo stripcslashes( get_theme_option('gplus_page') ); ?>">&nbsp;</a></span></p>
<?php endif; ?>

</div>