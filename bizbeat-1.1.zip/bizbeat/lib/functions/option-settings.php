<?php
$global_options = array (
/*header setting*/
array(
"header-title" => __("Header Setting", TEMPLATE_DOMAIN),
"name" => __("Site Logo", TEMPLATE_DOMAIN),
"section" => "header",
	"description" => __("Enter your logo url path here.", TEMPLATE_DOMAIN),
	"id" => "header_logo",
    "filename" => "header_logo",
	"type" => "text",
	"default" => ""),

array(
"name" => __("Favourite Icon", TEMPLATE_DOMAIN),
	"description" => __("Enter your fav icon url path here.", TEMPLATE_DOMAIN),
    "section" => "header",
    "id" => "fav_icon",
    "filename" => "fav_icon",
	"type" => "text",
	"default" => ""),


/* typography setting */
array(
"header-title" => __("Typography Settings", TEMPLATE_DOMAIN),
"name" => __("Body Font", TEMPLATE_DOMAIN),
	"description" => __("Choose a font for the body text.", TEMPLATE_DOMAIN),
    "section" => "typography",
    "id" => "body_font",
	"type" => "select-fonts",
	"default" => ""),

array(
"name" => __("Body Font Weight", TEMPLATE_DOMAIN),
	"description" => "",
    "section" => "typography",
    "id" => "body_font_weight",
	"type" => "select-fonts-weight",
	"default" => ""),

array(
"name" => __("Headline and Title Font", TEMPLATE_DOMAIN),
	"description" => __("Choose a font for the headline text.", TEMPLATE_DOMAIN),
    "section" => "typography",
    "id" => "headline_font",
	"type" => "select-fonts",
	"default" => ""),

array(
"name" => __("Headline Font Weight", TEMPLATE_DOMAIN),
	"description" => "",
    "section" => "typography",
    "id" => "headline_font_weight",
	"type" => "select-fonts-weight",
	"default" => ""),


array(
"name" => __("Navigation Font", TEMPLATE_DOMAIN),
	"description" => __("Choose a font for the navigation text.", TEMPLATE_DOMAIN),
    "section" => "typography",
    "id" => "navigation_font",
	"type" => "select-fonts",
	"default" => ""),
    
array(
"name" => __("Navigation Font Weight", TEMPLATE_DOMAIN),
	"description" => "",
    "section" => "typography",
    "id" => "navigation_font_weight",
	"type" => "select-fonts-weight",
	"default" => ""),

/* Posts setting */
array(
"header-title" => __("Posts Settings", TEMPLATE_DOMAIN),
"name" => __("Featured Image Size", TEMPLATE_DOMAIN),
"description" => __("Choose if you want to thumbnail, medium or large for featured images.", TEMPLATE_DOMAIN),
    "section" => "post",
    "id" => "feat_img_size",
	"type" => "radio-image-size",
	"default" => "thumbnail"),

array(
"name" => __("Enable Author Bio", TEMPLATE_DOMAIN),
"description" => __("Choose if you want to enable or disable post author bio.", TEMPLATE_DOMAIN),
    "section" => "post",
"id" => "author_bio",
	"type" => "radio-enable-disable",
	"default" => "Disable"),


/* Jcarousel setting */
array(
"header-title" => __("Jcarousel Settings", TEMPLATE_DOMAIN),
"name" => __("Enable Jcarousel posts", TEMPLATE_DOMAIN),
"description" => __("Choose if you want to enable or disable featured jcarousel posts.", TEMPLATE_DOMAIN),
    "section" => "jcarousel",
"id" => "jcarousel_on",
	"type" => "radio-enable-disable",
	"default" => "Disable"),

array(
"name" => __("Categories ID", TEMPLATE_DOMAIN),
"description" => __("Add a list of category ids if you want to use category as jcarousel. <em>*leave blank to use bottom post ids featured</em><br /><small>example: 3,4,68</small>", TEMPLATE_DOMAIN),
    "section" => "jcarousel",
"id" => "jcarousel_cat",
	"type" => "text",
	"default" => ""),

array(
"name" => __("Limit to how many posts", TEMPLATE_DOMAIN),
"description" => __("How many jcarousel posts in categories you listed you want to show?", TEMPLATE_DOMAIN),
    "section" => "jcarousel",
"id" => "jcarousel_cat_count",
	"type" => "select-count",
	"default" => ""),

array(
"name" => __("Posts ID", TEMPLATE_DOMAIN),
"description" => __("Add a list of post ids if you want to use posts as jcarousel. <em>*leave blank to use above category ids featured</em><br /><small>example: 136,928,925,80,77,55,49</small>", TEMPLATE_DOMAIN),
     "section" => "jcarousel",
"id" => "jcarousel_post",
	"type" => "text",
	"default" => ""),


/* Slider setting */
array(
"header-title" => __("Featured Posts Settings", TEMPLATE_DOMAIN),
"name" => __("Enable Featured posts", TEMPLATE_DOMAIN),
"description" => __("Choose if you want to enable or disable featured posts.", TEMPLATE_DOMAIN),
    "section" => "slider",
"id" => "slider_on",
	"type" => "radio-enable-disable",
	"default" => "Disable"),

array(
"name" => __("Categories ID", TEMPLATE_DOMAIN),
"description" => __("Add a list of category ids if you want to use category as featured. <em>*leave blank to use bottom post ids featured</em><br /><small>example: 3,4,68</small>", TEMPLATE_DOMAIN),
    "section" => "slider",
"id" => "feat_cat",
	"type" => "text",
	"default" => ""),

array(
"name" => __("Limit to how many posts", TEMPLATE_DOMAIN),
"description" => __("How many posts in categories you listed you want to show?", TEMPLATE_DOMAIN),
    "section" => "slider",
"id" => "feat_cat_count",
	"type" => "select-count",
	"default" => ""),


array(
"name" => __("Posts ID", TEMPLATE_DOMAIN),
"description" => __("Add a list of post ids if you want to use posts as featured. <em>*leave blank to use above category ids featured</em><br /><small>example: 136,928,925,80,77,55,49</small>", TEMPLATE_DOMAIN),
     "section" => "slider",
"id" => "feat_post",
	"type" => "text",
	"default" => ""),


/* Sidebar Featured setting */
array(
"header-title" => __("Featured Sidebar", TEMPLATE_DOMAIN),
"name" => __("Enable Featured Category Sidebar", TEMPLATE_DOMAIN),
"description" => __("Choose if you want to enable or disable featured category sidebar. <em>*leave blank if not use</em>", TEMPLATE_DOMAIN),
     "section" => "sidebar",
"id" => "feat_sidebar_on",
	"type" => "radio-enable-disable",
	"default" => "Disable"),


array(
"name" => __("Sidebar Featured Category 1", TEMPLATE_DOMAIN),
"description" => __("Choose which category to featured.", TEMPLATE_DOMAIN),
	"section" => "sidebar",
    "id" => "side_feat_cat1",
	"type" => "select-cat",
	"default" => ""),
array(
"name" => __("Featured Category 1 Count", TEMPLATE_DOMAIN),
"description" => __("How many posts you want to list in this category?", TEMPLATE_DOMAIN),
	"section" => "sidebar",
    "id" => "side_feat_cat1_count",
	"type" => "select-count",
	"default" => ""),

array(
"name" => __("Sidebar Featured Category 2", TEMPLATE_DOMAIN),
"description" => __("Choose which category to featured.", TEMPLATE_DOMAIN),
	"section" => "sidebar",
    "id" => "side_feat_cat2",
	"type" => "select-cat",
	"default" => ""),
array(
"name" => __("Featured Category 2 Count", TEMPLATE_DOMAIN),
"description" => __("How many posts you want to list in this category?", TEMPLATE_DOMAIN),
	"section" => "sidebar",
    "id" => "side_feat_cat2_count",
		"type" => "select-count",
	"default" => ""),


array(
"name" => __("Sidebar Featured Category 3", TEMPLATE_DOMAIN),
"description" => __("Choose which category to featured.", TEMPLATE_DOMAIN),
	"section" => "sidebar",
    "id" => "side_feat_cat3",
	"type" => "select-cat",
	"default" => ""),
array(
"name" => __("Featured Category 3 Count", TEMPLATE_DOMAIN),
"description" => __("How many posts you want to list in this category?", TEMPLATE_DOMAIN),
	"section" => "sidebar",
    "id" => "side_feat_cat3_count",
	"type" => "select-count",
	"default" => ""),


array(
"name" => __("Sidebar Featured Category 4", TEMPLATE_DOMAIN),
"description" => __("Choose which category to featured.", TEMPLATE_DOMAIN),
	"section" => "sidebar",
    "id" => "side_feat_cat4",
	"type" => "select-cat",
	"default" => ""),
array(
"name" => __("Featured Category 4 Count", TEMPLATE_DOMAIN),
"description" => __("How many posts you want to list in this category?", TEMPLATE_DOMAIN),
	"section" => "sidebar",
    "id" => "side_feat_cat4_count",
	"type" => "select-count",
	"default" => ""),


/*adsense setting*/
array(
"header-title" => __("Advertisment Settings", TEMPLATE_DOMAIN),
"name" => __("Advertisment in Top Header", TEMPLATE_DOMAIN),
  "description" => __("Insert script code or banner code for the top header. Leave blank if not use.", TEMPLATE_DOMAIN),
	 "section" => "ads",
     "id" => "ads_header",
	"type" => "textarea",
	"default" => ""),

array(
"name" => __("Advertisment in Post First Loop", TEMPLATE_DOMAIN),
  "description" => __("Insert script code or banner code for the first post loop. It will appeared after <em>first post</em>. Leave blank if not use.", TEMPLATE_DOMAIN),
	 "section" => "ads",
     "id" => "ads_loop_one",
	"type" => "textarea",
	"default" => ""),


array(
"name" => __("Advertisment in Post Second Loop", TEMPLATE_DOMAIN),
  "description" => __("Insert script code or banner code for the second post loop. It will appeared after <em>second post</em>. Leave blank if not use.", TEMPLATE_DOMAIN),
	 "section" => "ads",
     "id" => "ads_loop_two",
	"type" => "textarea",
	"default" => ""),

array(
"name" => __("Advertisment in Single Post Top", TEMPLATE_DOMAIN),
  "description" => __("Insert script code or banner code for the top single post page. It will appeared before <em>post_content()</em>. Leave blank if not use.", TEMPLATE_DOMAIN),
	 "section" => "ads",
     "id" => "ads_single_top",
	"type" => "textarea",
	"default" => ""),

array( "name" => __("Advertisment in Single Post Bottom", TEMPLATE_DOMAIN),
  "description" => __("Insert script code or banner code for the bottom single post page. It will appeared after <em>post_content()</em>. Leave blank if not use.", TEMPLATE_DOMAIN),
	 "section" => "ads",
     "id" => "ads_single_bottom",
	"type" => "textarea",
	"default" => ""),


array( "name" => __("Advertisment in Right Sidebar", TEMPLATE_DOMAIN),
  "description" => __("Insert script code or banner code for the right sidebar. 300x250 or 250x250 dimension preferable. Leave blank if not use.", TEMPLATE_DOMAIN),
	 "section" => "ads",
     "id" => "ads_right_sidebar",
	"type" => "textarea",
	"default" => ""),

array( "name" => __("Header Code", TEMPLATE_DOMAIN),
	"description" => __("Insert any code in header. <em>*this will appearead after wp_head()</em>", TEMPLATE_DOMAIN),
	 "section" => "ads",
     "id" => "header_code",
	"type" => "textarea",
	"default" => ""),


array( "name" => __("Footer Code", TEMPLATE_DOMAIN),
	"description" => __("Insert any code in footer. <em>*this will appearead after wp_footer()</em>", TEMPLATE_DOMAIN),
	 "section" => "ads",
     "id" => "footer_code",
	"type" => "textarea",
	"default" => ""),


/*banner setting*/

array(
"header-title" => __("Sidebar Banner Settings", TEMPLATE_DOMAIN),
"name" => __("Banner Ads 1", TEMPLATE_DOMAIN),
	"description" => __("Insert banner 1 HTML code. <em>*leave blank if not use</em>", TEMPLATE_DOMAIN),
     "section" => "banner",
    "id" => "sponsor_banner_one",
	"type" => "textarea",
	"default" => ""),

array( "name" => __("Banner Ads 2", TEMPLATE_DOMAIN),
	"description" => __("Insert banner 2 HTML code. <em>*leave blank if not use</em>", TEMPLATE_DOMAIN),
    "section" => "banner",
    "id" => "sponsor_banner_two",
	"type" => "textarea",
	"default" => ""),

array( "name" => __("Banner Ads 3", TEMPLATE_DOMAIN),
	"description" => __("Insert banner 3 HTML code. <em>*leave blank if not use</em>", TEMPLATE_DOMAIN),
    "section" => "banner",
    "id" => "sponsor_banner_three",
	"type" => "textarea",
	"default" => ""),

array( "name" => __("Banner Ads 4", TEMPLATE_DOMAIN),
	"description" => __("Insert banner 4 HTML code. <em>*leave blank if not use</em>", TEMPLATE_DOMAIN),
    "section" => "banner",
    "id" => "sponsor_banner_four",
	"type" => "textarea",
	"default" => ""),

array( "name" => __("Banner Ads 5", TEMPLATE_DOMAIN),
	"description" => __("Insert banner 5 HTML code. <em>*leave blank if not use</em>", TEMPLATE_DOMAIN),
    "section" => "banner",
    "id" => "sponsor_banner_five",
	"type" => "textarea",
	"default" => ""),

array( "name" => __("Banner Ads 6", TEMPLATE_DOMAIN),
	"description" => __("Insert banner 6 HTML code. <em>*leave blank if not use</em>", TEMPLATE_DOMAIN),
    "section" => "banner",
    "id" => "sponsor_banner_six",
	"type" => "textarea",
	"default" => ""),


/* services setting */
array(
"header-title" => __("Social Settings", TEMPLATE_DOMAIN),
"name" => __("Social Submit links in Posts", TEMPLATE_DOMAIN),
	"description" => __("Enable social share in posts", TEMPLATE_DOMAIN),
    "section" => "social",
    "id" => "social_on",
	"type" => "radio-enable-disable",
	"default" => "Disable"),


array(
"name" => __("RSS Feed url", TEMPLATE_DOMAIN),
	"description" => __("Insert your RSS Feed url like feed url for feedburner<br /><em>* must include full url with http://</em>", TEMPLATE_DOMAIN),
     "section" => "social",
"id" => "rss_feed",
	"type" => "text",
	"default" => ""),

array(
"name" => __("Facebook page url", TEMPLATE_DOMAIN),
	"description" => __("Insert your facebook page url", TEMPLATE_DOMAIN),
       "section" => "social",
    "id" => "facebook_page",
	"type" => "text",
	"default" => ""),

array(
"name" => __("Twitter page url", TEMPLATE_DOMAIN),
	"description" => __("Insert your twitter page url", TEMPLATE_DOMAIN),
      "section" => "social",
    "id" => "twitter_page",
	"type" => "text",
	"default" => ""),

array(
"name" => __("Google Plus page url", TEMPLATE_DOMAIN),
	"description" => __("Insert your google plus <strong>business</strong> page url", TEMPLATE_DOMAIN),
   "section" => "social",
"id" => "gplus_page",
	"type" => "text",
	"default" => "")

);
?>
