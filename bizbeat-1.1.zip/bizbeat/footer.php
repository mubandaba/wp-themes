</div><!-- CONTAINER WRAP END -->

</section><!-- CONTAINER END -->


<footer class="footer-top">
<div class="innerwraps">
<div class="ftop">
<div class="footer-container-wrap">
<div class="fbox">
<div class="widget-area the-icons">
<?php if ( is_active_sidebar( 'first-footer-widget-area' ) ) : ?>
<?php dynamic_sidebar( 'first-footer-widget-area' ); ?>
<?php else: ?>
<aside class="widget widget_recent_entries">
<h3 class="widget-title"><?php _e('Recent Posts', TEMPLATE_DOMAIN); ?></h3>
<ul><?php wp_get_archives('type=postbypost&limit=5'); ?></ul>
</aside>
<?php endif; ?>
</div>
</div>


<div class="fbox wider-cat">
<div class="widget-area the-icons">
<?php if ( is_active_sidebar( 'second-footer-widget-area' ) ) : ?>
<?php dynamic_sidebar( 'second-footer-widget-area' ); ?>
<?php else: ?>
<aside class="widget">
<h3 class="widget-title"><?php _e('Recent Comments', TEMPLATE_DOMAIN); ?></h3>
<?php get_avatar_recent_comment(5); ?>
</aside>
<?php endif; ?>
</div>
</div>


<div class="fbox">
<div class="widget-area the-icons">
<?php if ( is_active_sidebar( 'third-footer-widget-area' ) ) : ?>
<?php dynamic_sidebar( 'third-footer-widget-area' ); ?>
<?php else: ?>
<aside class="widget">
<h3 class="widget-title"><?php _e('Hot Topics',TEMPLATE_DOMAIN); ?></h3>
<?php get_hot_topics(5); ?>
</aside>
<?php endif; ?>
</div>
</div>


</div>
</div>
</div>

</footer><!-- FOOTER TOP END -->


<footer class="footer-bottom">
<div class="innerwraps">
<div class="fbottom">
<div class="footer-left">
<?php _e('Copyright &copy;', TEMPLATE_DOMAIN); ?> <?php echo gmdate(__('Y', TEMPLATE_DOMAIN)); ?>. <?php bloginfo('name'); ?>
</div><!-- FOOTER LEFT END -->

<div class="footer-right">
<?php if ( function_exists( 'wp_nav_menu' ) ) { // Added in 3.0 ?>
<?php if ( has_nav_menu('footer') ) { ?>
	<?php wp_nav_menu( array(
	'theme_location' => 'footer',
	'container' => false,
	'depth' => 1,
	'fallback_cb' => 'none'
	)); ?>
   <?php echo '<br />'; } ?>
<?php } ?> <?php echo mp_theme_author_credit_info(); ?>
</div>

</div>
<!-- FOOTER RIGHT END -->

</div>
</footer><!-- FOOTER BOTTOM END -->


</div><!-- BODYCONTENT END -->
</div><!-- INNERWRAP BODYWRAP END -->

</div><!-- WRAPPER MAIN END -->
</div><!-- WRAPPER END -->

<div class="cleariefloat"></div>

<?php wp_footer(); ?>

<?php $footer_code = get_theme_option('footer_code'); echo stripcslashes($footer_code); ?>

</body>

</html>