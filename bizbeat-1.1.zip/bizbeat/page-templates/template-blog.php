<?php
/*
Template Name: Blog
*/
?>

<?php get_header(); ?>

<?php do_action( 'bp_before_content' ) ?>
<!-- CONTENT START -->
<div class="content">
<div class="content-inner">

<?php do_action( 'bp_before_blog_home' ) ?>

<!-- POST ENTRY START -->
<div id="post-entry">

<?php do_action( 'bp_before_blog_entry' ) ?>

<section class="post-entry-inner">
<?php
global $page,$paged,$more; $more = 0;
$postcount = 1;
$max_num_post = get_option('posts_per_page');
if('page' == get_option( 'show_on_front' )) {
$page = (get_query_var('page')) ? get_query_var('page') : 1;
} else {
$page = (get_query_var('paged')) ? get_query_var('paged') : 1;
}
query_posts("posts_per_page=$max_num_post&paged=$page");

if( !wp_is_mobile() ){
$feat_size = get_theme_option('feat_img_size');
if($feat_size == ''){ $feat_size = 'thumbnail'; }
} else {
$feat_size = 'large';
}
$thumb_w = get_option($feat_size.'_size_w');
$thumb_h = get_option($feat_size.'_size_h');

while ( have_posts() ) : the_post();
$thepostlink = '<a href="'. get_permalink() . '" title="' . the_title_attribute('echo=0') . '">';
?>
<?php do_action( 'bp_before_blog_post' ) ?>

<!-- POST START -->
<article <?php post_class($oddpost); ?> id="post-<?php the_ID(); ?>">

<?php echo get_featured_post_image("<div class='post-thumb'>$thepostlink", "</a></div>", $thumb_w, $thumb_h, "alignleft", $feat_size, the_title_attribute('echo=0'),the_title_attribute('echo=0'), false); ?>

<div class="post-right">
<h2 class="post-title entry-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
<?php get_template_part( 'lib/templates/post-meta' ); ?>
<div class="post-content entry-content"><?php echo get_custom_the_excerpt(30,''); ?></div>
</div>

</article>
<!-- POST END -->

<?php
$get_ads_code_one = get_theme_option('ads_loop_one');
$get_ads_code_two = get_theme_option('ads_loop_two');
if( 1 == $postcount ){ ?>
<?php if($get_ads_code_one) { echo '<div class="adsense-post">'. stripcslashes(do_shortcode($get_ads_code_one)) . '</div>'; } ?>
<?php } elseif( 2 == $postcount ){ ?>
<?php if($get_ads_code_two) { echo '<div class="adsense-post">'. stripcslashes(do_shortcode($get_ads_code_two)) . '</div>'; } ?>
<?php } ?>

<?php do_action( 'bp_after_blog_post' ); ?>

<?php ($oddpost == "alt-post") ? $oddpost="" : $oddpost="alt-post"; $postcount++; ?>
<?php endwhile; ?>
<?php get_template_part( 'lib/templates/paginate' ); ?>

</section>
</div>
<!-- POST ENTRY END -->

<?php do_action( 'bp_after_blog_home' ) ?>

</div><!-- CONTENT INNER END -->
</div><!-- CONTENT END -->

<?php do_action( 'bp_after_content' ) ?>

<?php get_sidebar(); ?>

<?php get_footer(); ?>