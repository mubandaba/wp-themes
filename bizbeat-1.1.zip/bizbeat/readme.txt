Copyright 2005-2014, Ronald KSY and MagPress.com, use only as authorized

***********************************
Please read this license carefully before using MAGPRESS free wordpress theme
By using this theme, you are bound to the terms of this license.
***********************************

***********************************
Developer's License
***********************************
Thank You For Using WordPress Theme By MagPress.com

Don't Forget to Subscribe Our Free NewsLetter In Order To Receive Theme's Updates and Fixes.
http://feedburner.google.com/fb/a/mailverify?uri=MagPress&loc=en_US

Please Note: This Free version contained theme author credits link. check license and terms http://www.magpress.com/license-terms

If you're interested in purchasing a developer's license (clean footer or sidebar) for this theme.

please go to this developer license purchase page at the theme page or developer page at http://www.magpress.com/developer-license

