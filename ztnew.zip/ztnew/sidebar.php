<div id="secondary" class="widget-area" role="complementary">
<aside id="search-2" class="widget widget_search"><h1 class="widget-title">站内搜索：</h1>	
	<form method="get" id="searchform" action="<?php echo get_option('home'); ?>" role="search">
		<label for="s" class="assistive-text">Search</label>
		<input type="text" class="field" name="s" value="" id="s" placeholder="Search …">
		<input type="submit" class="submit" name="submit" id="searchsubmit" value="Search">
	</form>
</aside>
</div>