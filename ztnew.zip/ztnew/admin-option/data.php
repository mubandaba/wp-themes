<?php

$data=array(
	'top-title'=>array('title'=>'顶部','type'=>'line'),
	'logo'=>array('title'=>'logo上传','type'=>'upload','size'=>'60','des'=>'手动填写地址/wp-content/themes/ztnew/images/logo.png , 或者上传文件插入地址','tips'=>'大小宜为104x147'),
	'foot-2'=>array('title'=>'其它代码','type'=>'textarea','width'=>'500px','height'=>'100px','tips'=>'输入分享、浮动客服等js代码'),
	'other-title'=>array('title'=>'其它','type'=>'line'),
	'other-2'=>array('title'=>'seo功能','type'=>'checkbox','value'=>array('开启'=>'on'),'des'=>'开启则载入seo模块，可以自定义首页、文章页、分类页的title、keywords、description标签。'),
);