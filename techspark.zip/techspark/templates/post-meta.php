<footer class="entry-meta meta-top<?php if( is_page() ) { echo ' meta-no-display'; } ?>">
<span class="entry-author vcard"><i class="fa fa-user"></i><?php the_author_posts_link(); ?></span>
<span class="entry-date"><i class="fa fa-clock-o"></i><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo the_time( get_option( 'date_format' ) ); ?></time></span>


<?php if( get_post_type() == 'post' ) { ?>
<span class="entry-category"><i class="fa fa-file-o"></i><?php echo frkw_get_singular_cat(); ?></span>
<?php } else { ?>
<?php frkw_get_post_taxonomy(', ','<span class="entry-category"><i class="fa fa-file-o"></i>','</span>'); ?>
<?php } ?>
<?php if ( comments_open() ) { ?>
<span class="entry-comment"><i class="fa fa-comments-o"></i><?php comments_popup_link(__('0','techspark'), __('1','techspark'), __('%','techspark') ); ?></span>
<?php } ?>


</footer>