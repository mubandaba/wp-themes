<?php
$home_feat = get_theme_mod('home_feat_post');
if($home_feat) {
if( is_home() || is_front_page() ){
$paged = get_query_var( 'paged' );
if ( !$paged ) { ?>
<div id="feat-post-box"><div class="innerwrap">
<?php
$post_count = 1;
//$post_types = get_post_type_object( 'forum' );;
//print_r($post_types);
//echo $post_types->exclude_from_search;

//echo "<br /><br />";

//$post_types_alt = get_post_type_object( 'product' );;
//print_r($post_types_alt);
//echo $post_types_alt->exclude_from_search;

$allposttype = frkw_get_all_posttype();

print_r($allposttype);

query_posts( array( 'post_type'=> $allposttype, 'post__in' => explode(',', $home_feat), 'posts_per_page' => 100, 'ignore_sticky_posts' => 1, 'orderby' => 'post__in' ) );

$post_array = array(2,5,8,11,14,17,20);

while (have_posts()) : the_post();
$thepostlink =  '<a href="'. get_permalink() . '" title="' . the_title_attribute('echo=0') . '">';
if ( in_array($post_count, $post_array) ) {
$post_alt = 'loop-center';
} else {
$post_alt = '';
}
?>
<article <?php post_class('feat-post ' . $post_alt); ?> id="post-<?php the_ID(); ?>">
<?php echo frkw_get_featured_image("<div class='feat-post-thumb'>".$thepostlink, "</a></div>", 500, 400, "alignnone", 'medium', frkw_get_image_alt_text(),the_title_attribute('echo=0'), false); ?>
<div class="feat-post-wrapper">
<h2 class="post-title entry-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
<div class="post-content entry-content">
<?php echo frkw_get_custom_the_excerpt(20); ?>
</div>
</div>
</article>
<?php $post_count++; endwhile; wp_reset_query(); ?>
</div></div>

<?php } } } ?>