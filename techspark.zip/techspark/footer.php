<?php do_action( 'mp_before_end_wrapper' ); ?>
</div>
</div>
<?php do_action( 'mp_after_wrapper' ); ?>
</div>
<?php do_action( 'mp_after_wrapper_main' ); ?>
<?php wp_footer(); ?>
</body>
</html>