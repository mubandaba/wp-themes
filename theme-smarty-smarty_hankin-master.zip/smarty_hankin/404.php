<?php get_header(); ?>
<?php get_template_part( 'layouts/home/404' );?>
<?php get_footer(); ?>