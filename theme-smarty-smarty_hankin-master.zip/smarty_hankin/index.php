<?php get_header(); ?>
<?php get_template_part( 'layouts/home/main' );?>
<?php get_footer(); ?>
