<div class="r_comment"><h3>最新评论</h3>
<ul>
<?php
$show_comments = 5; //更改这里的数字改变调用条数
$my_email = get_bloginfo ('admin_email');
$i = 1;
$comments = get_comments('number=100&status=approve&type=comment');
foreach ($comments as$rc_comment) {
if ($rc_comment->comment_author_email != $my_email) {
?>
<li><?php echo get_avatar($rc_comment->comment_author_email,32);?><?php echo$rc_comment->comment_author; ?> :<a href="<?php echo get_permalink($rc_comment->comment_post_ID);?>#comment-<?php echo$rc_comment->comment_ID;?>"><?php echo convert_smilies($rc_comment->comment_content); ?></a></li>
<?php
if ($i == $show_comments) break;
$i++;
}
}
?>
</ul>
</div>