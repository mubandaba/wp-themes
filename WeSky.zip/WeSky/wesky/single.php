<?php get_header(); ?>
<div id="roll"><div title="回到顶部" id="roll_top"></div><div title="查看评论" id="ct"></div><div title="转到底部" id="fall"></div></div>
<div id="content">
<div class="main"><?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="left">
<div class="article">
<h2 style="text-align: center;"><?php the_title(); ?></h2>
<div class="article_info">作者：<?php the_author() ?> &nbsp; 发布：<?php the_time('Y-m-d H:i') ?> &nbsp; 栏目：<?php the_category(', ') ?> &nbsp; 点击：<?php post_views('', '次'); ?> &nbsp; <?php comments_popup_link ('抢沙发','1条评论','%条评论'); ?> &nbsp; <?php edit_post_link('编辑', ' [ ', ' ] '); ?></div><div class="clear"></div>
        <div class="context">
        <?php the_content('Read more...'); ?><hr style="border-top: 1px solid #666;"><p>本文固定链接: <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_permalink() ?> | <?php bloginfo('name');?></a></p></div>
</div>
</div>
<div class="articles">
<div class="author_pic">
					<a href="#Tokin" title="<?php the_author_description(); ?>"><?php echo get_avatar( get_the_author_email(), '30' ); ?></a>
				</div>
<div class="author_text">
			<span class="spostinfo">
				作者：<?php the_author() ?> 于<?php the_time('Y年m月d日') ?>发表 & <?php the_tags('关键词: ', ', ', ''); ?></br>
				<?php if (('open' == $post-> comment_status) && ('open' == $post->ping_status)) {?>
				除非注明 否则文章均为原创，转载请注明出处：
				<?php } elseif (('open' == $post-> comment_status) && !('open' == $post->ping_status)) { ?>
				通告目前不可用，你可以至底部留下评论。
				<?php } ?>
				<a href="<?php the_permalink() ?>" rel="bookmark" title="文章来自 <?php the_permalink() ?>"><?php the_title(); ?></a> | <?php bloginfo('name');?>	
			</span>
				</div>
</div>

<div class="articles">
<?php previous_post_link('【上一篇】%link') ?><br/><?php next_post_link('【下一篇】%link') ?>
</div>

<div class="articles">
<?php include('includes/related.php'); ?>
<div class="clear"></div>
</div>

<div class="articles">
<?php comments_template(); ?>
</div>

	<?php endwhile; else: ?>
	<?php endif; ?>
</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>