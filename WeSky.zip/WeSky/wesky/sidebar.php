<div id="sidebar">
<div style="margin-top:10px;">
	<div class="slider_box">
	<div class="hot_box">
			<div id="hot_n">
	<div id="hot_tag">最 新 被 评</div>
	<div class="widgets">
	<div id="rolld">
<?php $pop = $wpdb->get_results("SELECT DISTINCT comment_post_ID FROM $wpdb->comments WHERE comment_approved = 1 AND comment_post_ID NOT IN 
( SELECT ID FROM $wpdb->posts WHERE post_type != 'post' OR post_status != 'publish' OR post_password != '' ) 
ORDER BY comment_date_gmt DESC LIMIT 5"); ?> <?php foreach($pop as $post) : ?> 
	<ul>
	<li><a href="<?php echo get_permalink($post->comment_post_ID); ?>" rel="bookmark" title="详细阅读 <?php the_title(); ?>"><?php echo mb_strimwidth(get_the_title($post->comment_post_ID),0,34,'...'); ?></a></li>
	</ul>
<?php endforeach; ?>
</div></div>
	<i class="lt"></i>
	<i class="rt"></i>
	<i class="lb"></i>
	<i class="rb"></i>
</div><script type="text/javascript">
function up(x){var Mar=document.getElementById(x);var child_div=Mar.getElementsByTagName("ul")
var picH=26;var scrollstep=2;var scrolltime=20;var stoptime=3000;var tmpH=0;Mar.innerHTML+=Mar.innerHTML;function start(){if(tmpH<picH){tmpH+=scrollstep;if(tmpH>picH)tmpH=picH;Mar.scrollTop=tmpH;setTimeout(start,scrolltime);}else{tmpH=0;Mar.appendChild(child_div[0]);Mar.scrollTop=0;setTimeout(start,stoptime);}}
setTimeout(start,stoptime);}
up("rolld")
</script></div>
	</div></div>

<div class="widget">
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('小工具1') ) : ?>
	<?php endif; ?>
</div>

<div class="widget"><div class="widgets"><div id="tab-title"><?php include('includes/r_tab.php'); ?></div></div></div>

<div class="widget"><div class="top_comment">
	<?php if (get_option('swt_wallreaders') == 'Hide') { ?>
	<?php { echo ''; } ?>
	<?php } else { include(TEMPLATEPATH . '/includes/top_comment.php'); } ?></div>
</div>

<div class="widget">
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('小工具2') ) : ?>
	<?php endif; ?>
</div>

<?php if (get_option('swt_adc') == 'Display') { ?>
<?php if(is_home()) { ?> <!--仅在首页加载-->
<div class="widget"><div class="sponsor"><h3>广而告之</h3><?php echo stripslashes(get_option('swt_adccode')); ?></div></div><?php { echo ''; } ?><?php } else { } ?>
<?php } ?>

<?php if (get_option('swt_ada') == 'Display') { ?>
<?php if(is_single()) { ?> <!--仅在文章页加载-->
<div class="widget"><div class="sponsor"><h3>广而告之</h3><?php echo stripslashes(get_option('swt_adacode')); ?></div></div><?php { echo ''; } ?><?php } else { } ?>
<?php } ?>

<div class="widget">
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('小工具3') ) : ?>
	<?php endif; ?>
</div>

<div class="widget"><?php include('includes/r_comment.php'); ?></div>

<div class="widget"><?php include('includes/r_tags.php'); ?></div>

<?php if(is_single()) { ?> <!--仅在文章页加载-->
<div id="tab-content">
<div class="widget"><div class="widgets"><div class="notice">
<h3>推荐文章</h3>
<ul><?php include_once(ABSPATH . WPINC . '/rss.php');$rss = fetch_rss('http://www.gsky.org/feed');$maxitems = 10;$items = array_slice($rss->items, 0, $maxitems); ?>
<?php if (empty($items)) echo '<li>精彩内容获取超时，请稍候...</li>'; //获取超时
else foreach ( $items as $item ) : ?> 
<li><a href='<?php echo $item['link']; ?>' title='<?php echo $item['title']; ?>' target="_blank"> <?php echo mb_strimwidth($item['title'] , 0, 34, '...') ; ?> </a></li>
<?php endforeach; ?></ul>
</div></div></div></div>
<?php if (get_option('swt_adc') == 'Display') { ?>
<div class="widget"><div class="sponsor"><h3>广而告之</h3><?php echo stripslashes(get_option('swt_adccode')); ?></div></div>
<?php { echo ''; } ?><?php } else { } ?>
<div class="widget"><?php include('includes/r_statistics.php'); ?></div>
<?php } ?>

<?php if ( is_home() ) { ?>
<div class="widget">
<div class="r_links">
<h3>友情链接</h3>
<div class="v-links"><ul><?php wp_list_bookmarks('orderby=link_id&categorize=0&category='.get_option('swt_links').'&title_li='); ?></ul></div></div>
</div>
<?php } ?>

</div>
</div>