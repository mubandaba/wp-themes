    <footer>
		<div class="footer-inner content clear">
			<div class="footer-part">
				<h2 class="tit">关于本站</h2>
				<?php 
					$top_nav = wp_nav_menu( array( 'theme_location'=>'ft1', 'fallback_cb'=>'', 'container'=>'', 'menu_class'=>'tmtpost', 'echo'=>false, 'after'=>'' ) );
					$top_nav = str_replace( "</li>\n</ul>", "</li>\n</ul>", $top_nav );
					echo $top_nav;
				?>
			</div>
			<div class="footer-part">
				<h2 class="tit">社会化信息</h2>
					<ul class="tmtpost">
					  <li class="weibo"><i class="icon-weibo"></i><a target="_blank" href="<?php echo stripslashes( get_option( 'xlwb' ) ); ?>">新浪微博</a></li>
					  <li class="tentent"><i class="icon-qq"></i><a target="_blank" href="">群<?php echo stripslashes( get_option( 'qqqh' ) ); ?></a></li>
					  <li class="weixin"><i class="icon-tencent"></i><a target="_blank" href="<?php echo stripslashes( get_option( 'txwb' ) ); ?>">腾讯微博</a></li>
					  <li class="qr-code_open" data-popup-ordinal="0" id="open_82954191"><i class="icon-wechat fz13"></i>
					  
					  <a href="" class="tooltips"> <b style="margin-left: -4px;font-weight: inherit;">微信公众号</b>
						<span><img src="<?php echo get_option( 'wxewm' ); ?>" width="100" height="100" class="qrcod fl"></span>
					  </a>
					  </li>
					</ul>
			</div>
			<div class="footer-part">
				<h2 class="tit">网站服务</h2>
				<?php 
					$top_nav = wp_nav_menu( array( 'theme_location'=>'ft3', 'fallback_cb'=>'', 'container'=>'', 'menu_class'=>'tmtpost', 'echo'=>false, 'after'=>'' ) );
					$top_nav = str_replace( "</li>\n</ul>", "</li>\n</ul>", $top_nav );
					echo $top_nav;
				?>
			</div>
			<div class="footer-part">
				<h2 class="tit">帮助中心</h2>
				<?php 
					$top_nav = wp_nav_menu( array( 'theme_location'=>'ft4', 'fallback_cb'=>'', 'container'=>'', 'menu_class'=>'tmtpost', 'echo'=>false, 'after'=>'' ) );
					$top_nav = str_replace( "</li>\n</ul>", "</li>\n</ul>", $top_nav );
					echo $top_nav;
				?>
			</div>
			<div class="copyright">
				<?php echo stripslashes( get_option( 'foot-1' ) ); ?>
			</div>
      </div>
	</footer>
	
<div id="totop" style="display: none;"></div>
<script type="text/javascript">$(function(){var win_width=$(window).width();var wrap_width=$('.customize-support').width();var totop_width=$('#totop').width();var totop_posi=([win_width-wrap_width]/25-totop_width);$('#totop').css({'right':totop_posi});$(window).scroll(function(){if($(window).scrollTop()>=200){$('#totop').slideDown(200)}else{$('#totop').slideUp(200)}});$('#totop').click(function(){$('body,html').animate({scrollTop:0},200)})})
</script>
<script src="<?php bloginfo( 'template_url' ); ?>/js/js.js" type="text/javascript"></script>
<?php echo stripslashes( get_option( 'foot-2' ) ); ?>
<?php wp_footer(); ?>
</body>
</html>