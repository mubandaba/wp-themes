<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php bloginfo( 'charset' );?>" />
<title><?php wp_title( '|', true, 'right' ); ?></title>
<link href="<?php bloginfo( 'stylesheet_url' ); ?>" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/normalize.css">
<link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/main.css">
<?php
	if ( is_singular() && get_option( 'thread_comments' ) ) wp_enqueue_script( 'comment-reply' );
	wp_enqueue_script( 'jquery' );
	wp_head();
?>
<!--[if IE 8]> <link href="<?php bloginfo('template_directory'); ?>/ie8.css" type="text/css" rel="stylesheet" /> <![endif]-->
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/tagscloud.js"></script>
<script type="text/javascript">
document.createElement("section");
document.createElement("article");
document.createElement("footer");
document.createElement("header");
document.createElement("hgroup");
document.createElement("nav");
document.createElement("menu");
</script>
</head>
<body>
<header>
<div class="head-1">
	<div class="cont">
	<a class="logoa" href="<?php bloginfo( 'url' ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"/><img class="logo" src="<?php echo get_option( 'logo' ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" /></a>
	<form action="<?php echo get_option('home'); ?>" class="top-serarch-form">
		<input name="s" type="text" class="top-search">
		<button class="btn-search"><i class="icon-search"></i></button>
	</form>
	  <span class="right fr">
			<a class="login_link" href="/wp-login.php">登录评论</a> <span>|</span>
			<a href="/wp-login.php?action=register">会员注册</a>
	   </span>
	</div>
</div>
<div class="head-2">
	<div class="cont clear">
		<div class="submit"><a href="/"><i class="icon-write"></i>我要投稿</a></div>
		<?php if(function_exists('wp_nav_menu')) {wp_nav_menu(array('theme_location'=>'main','menu_id'=>'nav', 'menu_class'=>'class','container'=>'ul'));}?>
		<script type="text/javascript"> jQuery(document).ready(function($) {$('#nav li').hover(function() {$('ul', this).slideDown(100)},function() {$('ul', this).slideUp(100)});});</script><!--二级导航js-->  
	</div>
</div>
</header>