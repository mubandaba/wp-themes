<?php get_header();?>
<div class="content clear index column-life">
 
	<div class="fast"><i class="icon-home"></i><?php if (function_exists('get_breadcrumbs')){get_breadcrumbs(); } ?></div>
	
	<section class="main">
	<?php while( have_posts() ): the_post(); $p_id = get_the_ID(); ?>
        <div class="left fl">
		<div class="mod-tit">
			<h2 class="tit"><?php the_title(); ?></h2>
		</div>
		<div class="about-cont">
			<?php the_content(); ?>
        </div>
        </div>
	<?php endwhile; ?>	
        <div class="sidebar fr">
          <div class="mod-sb-panel">
			<?php 
				$top_nav = wp_nav_menu( array( 'theme_location'=>'page', 'fallback_cb'=>'', 'container'=>'', 'menu_class'=>'page-nav', 'echo'=>false, 'after'=>'' ) );
				$top_nav = str_replace( "</li>\n</ul>", "</li>\n</ul>", $top_nav );
				echo $top_nav;
			?>
          </div>
		</div>
	</section>
    </div>



<?php get_footer(); ?>