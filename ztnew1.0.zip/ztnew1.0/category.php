<?php get_header();?>

<div class="content clear column">


      <div class="fast"><i class="icon-home"></i><?php if (function_exists('get_breadcrumbs')){get_breadcrumbs(); } ?></div>
	  
	  <section class="main clear">
        <div class="articles fl">
		<?php 
			query_posts(array(
				"category__in" => array(get_query_var("cat")), 
				"post__in" => get_option("sticky_posts")
				)
			);
			while(have_posts()) : the_post(); 
		?>
	    <div class="recommend">
            <div class="mod-tit">
              <h2 class="tit">推荐阅读</h2>
            </div>
            <div class="content">
            <a target="_blank" href="<?php the_permalink(); ?>" class="pic"><img src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&w=640&h=300&zc=1" alt="<?php the_title(); ?>" class="thumbnail"/><div class="shadow"></div></a>
              <div class="show"><a target="_blank" href="<?php the_permalink(); ?>" class="tit"><?php the_title(); ?></a>
                <p class="info">
					<a target="_blank" href="<?php echo get_option('home'); ?>/author/<?php the_author_login(); ?>" class="author"><?php the_author_link (); ?></a>
                	<span class="point">•</span>
                	<span class="time"> <?php the_time('m月d日 G:H'); ?></span>
                	<span> <i class="icon-comment"></i><?php comments_popup_link ('0 条评论','1 条评论','% 条评论'); ?></span>
                  <span class="fr praise index-praise">
                    <i class="icon-praise"></i>
                    <a href="javascript:;" data-action="ding" data-id="<?php the_ID(); ?>" class="favorite<?php if(isset($_COOKIE['bigfa_ding_'.$post->ID])) echo ' done';?>"><span class="count">
						<?php if( get_post_meta($post->ID,'bigfa_ding',true) ){            
								echo get_post_meta($post->ID,'bigfa_ding',true);
							 } else {
								echo '0';
							 }?></span> 赞
					</a>
                  </span>
                </p>
              </div>
            </div>
        </div>
		<?php 
			endwhile;
			wp_reset_query();
		?>
  
<div class="recent-article">
	<div class="mod-tit">
	<h2 class="tit">最近更新</h2>
	</div>
	<ul class="mod-article-list">
	  <?php while(have_posts()) : the_post(); ?>
	  <?php if(!is_sticky()){?>
		<li class="clear article">
			  <a target="_blank" href="<?php the_permalink(); ?>" class="pic fl"><img src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&w=200&h=150&zc=1" alt="<?php the_title(); ?>" class="thumbnail"/></a>
			<div class="show">
			  <a target="_blank" href="<?php the_permalink(); ?>" class="tit"><?php the_title(); ?></a>
			  <p class="info">
				<a target="_blank" href="<?php echo get_option('home'); ?>/author/<?php the_author_login(); ?>" class="author"><?php the_author_link (); ?></a>
				<span class="point">•</span>
				<span class="time"><?php the_time('m月d日 G:H'); ?></span>
				<span>
				  <span class="comment">
					  <i class="icon-comment"></i><?php comments_popup_link ('0','1','%'); ?>
				  </span>
				</span>
			  </p>
			  <p class="part"><?php echo mb_strimwidth(strip_tags($post->post_content),0,110,'...');?></p>
				<div class="tags">
					<i class="icon-bookmark"></i>
					<span><?php the_tags('', ' ', ''); ?></span>
				</div>
			</div>
		</li>
		<?php } endwhile;?>
	</ul>
	
	
	
    <div class="pages">
        <ul class="page-list"><?php par_pagenavi(9); ?></ul>    
		
	</div>
  </div>
        </div>
		
		<?php get_sidebar(); ?>
		
      </section>
    </div>

<?php get_footer(); ?>