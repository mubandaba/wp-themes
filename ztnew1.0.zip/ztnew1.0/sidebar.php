        <div class="sidebar fl">

<div class="hot-article">
    <div class="mod-tit">
        <h2 class="tit">热门文章</h2>
    </div>
    <ul class="article-list">
<?php
global $post;
$cats = wp_get_post_categories($post->ID);
if ($cats) {
    $args = array(
          'category__in' => array( $cats[0] ),
          'post__not_in' => array( $post->ID ),
          'showposts' => 5,
		  'post_status' => 'publish',
		  'orderby' => 'comment_count',
          'caller_get_posts' => 1
      );
  query_posts($args);
  if (have_posts()) {
    while (have_posts()) {
      the_post(); update_post_caches($posts); ?>
		<li class="clear">
			<a target="_blank" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" class="pic fl"><img src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&w=60&h=60&zc=1" alt="<?php the_title(); ?>" class="thumbnail"/></a>
			<div class="show">
				<a target="_blank" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" class="tit"><?php the_title(); ?></a>
				<p class="info"><?php the_time('m月d日 G:H'); ?> <span class="comm"><i class="icon-comment"></i><?php comments_popup_link ('0','1','%'); ?></span></p>
			</div>
		</li>
	<?php
    }
  }
  else {
    echo '<li>暂无相关</li>';
  }
  wp_reset_query();
}
else {
  echo '<li>暂无相关</li>';
}
?>		
	</ul>
</div>


<div class="hot-auction">
    <div class="mod-tit">
        <h2 class="tit">广告而知</h2>
        <a href="#" class="more">更多<span class="icon-shape"></span></a>
    </div>
    <div class="slide-panel">
        <?php echo stripslashes( get_option( 'ad1' ) ); ?>
    </div>
</div>


<div class="hot-auction">
    <div class="mod-tit">
        <h2 class="tit">标签云</h2>
        <a href="#" class="more">更多<span class="icon-shape"></span></a>
    </div>
    <div class="tagsyun">
		<div id="tagscloud">
			<?php wp_tag_cloud('number=20&orderby=count&order=DESC&smallest=12&largest=12&unit=px'); ?>
		</div>	
    </div>
</div>


<div id="float">   
<div class="hot-auction">
    <div class="mod-tit">
        <h2 class="tit">标签云</h2>
    </div>
	<div class="aside-social__qrcode">
		<img src="<?php echo get_option( 'wxewm' ); ?>" width="250" height="250"><br>
		<span style="width: 250px;line-height: 30px;text-align: center;display: block;">微信扫描二维码，关注我们</span>
	</div>
</div>
</div>


        </div>