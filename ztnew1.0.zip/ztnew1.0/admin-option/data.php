<?php

$data=array(
	'tab-1'=>array('type'=>'tab1'),
	
	'logo'=>array('title'=>'logo上传','type'=>'upload','size'=>'60','value'=>'/wp-content/themes/ztnew/images/logo.jpg','tips'=>'大小宜为112x39'),
	
	
	'wxewm'=>array('title'=>'微信二维码上传','type'=>'upload','size'=>'60','value'=>'/wp-content/themes/ztnew/images/weixin.jpg','tips'=>'大小宜为324x324'),
	
	
	
	
	'tab-2'=>array('type'=>'tab2'),
	
	'list'=>$args=array('title'=>'侧栏4格文章','type'=>'cat','tips'=>'选择侧栏4格文章调用的分类'),
	
	
	
	
	'tab-3'=>array('type'=>'tab3'),
	
	'ad1'=>array('title'=>'侧栏广而告之','type'=>'textarea','width'=>'500px','height'=>'100px','tips'=>'输入侧栏广而告之html代码'),
	
	
	
	
	'tab-4'=>array('type'=>'tab4'),
	
	'xlwb'=>array('title'=>'底部新浪微博地址','type'=>'textarea','width'=>'500px','height'=>'25px','tips'=>'输入底部新浪微博地址'),
	'qqqh'=>array('title'=>'QQ群号','type'=>'textarea','width'=>'500px','height'=>'25px','tips'=>'输入底部QQ群号'),
	'txwb'=>array('title'=>'底部腾讯微博地址','type'=>'textarea','width'=>'500px','height'=>'25px','tips'=>'输入底部腾讯微博地址'),
	
	
	
	
	'foot-1'=>array('title'=>'底部版权','type'=>'textarea','width'=>'500px','height'=>'100px','des'=>'请用&lt;p&gt;文字&lt;/p&gt;结构','tips'=>'输入底部版权文本、统计代码等html代码'),
	'foot-2'=>array('title'=>'其它代码','type'=>'textarea','width'=>'500px','height'=>'100px','tips'=>'输入分享、浮动客服等js代码'),
	'other-title'=>array('title'=>'其它','type'=>'line'),
	'other-2'=>array('title'=>'seo功能','type'=>'checkbox','value'=>array('开启'=>'on'),'des'=>'开启则载入seo模块，可以自定义首页、文章页、分类页的title、keywords、description标签。'),
);