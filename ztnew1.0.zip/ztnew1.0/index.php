<?php get_header(); ?>

<h1 style="display: none;"><?php bloginfo('name'); ?></h1>
<div class="content clear column index">
	<section class="title hot-title">
	<h2 class="tit">热门标签</h2>
		<span class="point">·</span>
		<div class="list">
			<?php wp_tag_cloud('number=10&orderby=count&order=RAND&smallest=14&largest=14&unit=px'); ?> 	
		</div>
	</section>

    <section class="main clear">
	
	
	<div class="hot-articles">
        <div class="recommend clear">
		<?php $recent = new WP_Query('meta_key=hot_value&orderby=date&showposts=1&caller_get_posts=1'); while($recent->have_posts()) : $recent->the_post();?>
            <div class="content fl index_top_first">
				<a target="_blank" href="<?php the_permalink(); ?>" class="pic">
					<img src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&w=640&h=346&zc=1" alt="<?php the_title(); ?>" class="thumbnail"/>
				</a>
				<div class="shadow"></div>
				<div class="show">
					<a target="_blank" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" class="tit"><?php the_title(); ?></a>
					<p class="info">
						<a target="_blank" href="<?php echo get_option('home'); ?>/author/<?php the_author_login(); ?>" class="author"><?php the_author_link (); ?></a>
						<span class="point">•</span>
						<span class="time"><?php echo human_time_diff(get_the_time('U'), current_time('timestamp')) . '前'; ?></span>
						<span><i class="icon-comment"></i>
							<?php comments_popup_link ('0 条评论','1 条评论','% 条评论'); ?>
						</span>
						<span class="fr praise index-praise">
							<i class="icon-praise"></i>
								<a href="javascript:;" data-action="ding" data-id="<?php the_ID(); ?>" class="favorite<?php if(isset($_COOKIE['bigfa_ding_'.$post->ID])) echo ' done';?>"><span class="count">
									<?php if( get_post_meta($post->ID,'bigfa_ding',true) ){            
											echo get_post_meta($post->ID,'bigfa_ding',true);
										 } else {
											echo '0';
										 }?></span> 赞
								</a>
						</span>
					</p>
					<div class="abs"><?php echo mb_strimwidth(strip_tags($post->post_content),0,300,'...');?></div>
				</div>
            </div>
        <?php endwhile; ?>
            <div class="hot-list fr">
                <div class="inner">
                    <ul class="list">
					<?php $recent = new WP_Query('meta_key=hot_value&orderby=date&showposts=4&offset=1&caller_get_posts=4'); while($recent->have_posts()) : $recent->the_post();?>
						<li>
							<a href="<?php the_permalink(); ?>" target="_blank">
							<img src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&w=60&h=60&zc=1" alt="<?php the_title(); ?>" class="thumbnail pict"/>
								<div class="cont">
									<span class="tit"><?php the_title(); ?></span>
									<span class="time"><?php the_time('m月d日 G:H'); ?></span>
								</div>
							</a>
						</li>
					<?php endwhile; ?>
                    </ul>
                </div>
            </div>
            <script>
                $(function(){
                    $(".hot-articles .content").mouseover(function(){
                        $(this).find(".show").addClass("show-all")
                    }).mouseout(function(){
                        $(this).find(".show").removeClass("show-all")
                    })
                })
            </script>
        </div>
    </div>
	
	
	
    <div class="articles left fl">
        <div class="recent-article">
			<div class="mod-tit">
				<h2 class="tit">推荐文章</h2>
			</div>
			<ul class="mod-article-list">
			<?php while(have_posts()) : the_post(); ?>
				<?php if(!is_sticky()){?>
				<li class="clear article">
					<div class="pic fl">
						<a target="_blank" href="<?php the_permalink(); ?>">
							<img src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&w=200&h=150&zc=1" alt="<?php the_title(); ?>" class="thumbnail"/>
						</a>
						<div class="type-sign"><?php the_category(); ?></div>
					</div>
					<div class="show">
						<a target="_blank" href="<?php the_permalink(); ?>" class="tit"><?php the_title(); ?></a>
					<p class="info">
						<a target="_blank" href="<?php echo get_option('home'); ?>/author/<?php the_author_login(); ?>" class="author"><?php the_author_link (); ?></a>
						<span class="point">•</span>
						<span class="time"><?php the_time('m月d日 G:H'); ?></span>
						<span class="point">•</span>
						<span class="column">
							<?php the_category(', ') ?>
						</span>
						<span class="comment">
							<i class="icon-comment"></i>
							<?php comments_popup_link ('0','1','%'); ?>
						</span>
					</p>
					<p class="abstract"><?php echo mb_strimwidth(strip_tags($post->post_content),0,110,'...');?></p>
					<div class="tags">
						<i class="icon-bookmark"></i>
						<span><?php the_tags('', ' ', ''); ?></span>
					</div>
					</div>
				</li>
			<?php } endwhile;?>
			</ul>
			<div class="post-read-more load-more">
				<?php next_posts_link('更多+','');//下一页的链接 ?>
			</div>
		</div>
    </div>
	
	
    <div class="sidebar fl">
	
	<?php $cid = get_option( 'list' ); include( 'cl-list.php' ); ?>





<div class="hot-auction">
    <div class="mod-tit">
        <h2 class="tit">广告而知</h2>
        <a href="#" class="more">更多<span class="icon-shape"></span></a>
    </div>
    <div class="slide-panel">
        <?php echo stripslashes( get_option( 'ad1' ) ); ?>
    </div>
</div>


<div class="hot-auction">
    <div class="mod-tit">
        <h2 class="tit">标签云</h2>
        <a href="#" class="more">更多<span class="icon-shape"></span></a>
    </div>
    <div class="tagsyun">
		<div id="tagscloud">
			<?php wp_tag_cloud('number=20&orderby=count&order=DESC&smallest=12&largest=12&unit=px'); ?>
		</div>	
    </div>
</div>


<div class="hot-article">
    <div class="mod-tit">
        <h2 class="tit">热门文章</h2>
        <!-- <a href="/" class="more">更多<span class="icon-shape"></span></a> -->
    </div>
    <ul class="article-list">
	
		<?php 
		$post_num = 5; // 设置调用条数 
		$args = array( 
		'post_password' => '', 
		'post_status' => 'publish', // 只选公开的文章. 
		'post__not_in' => array($post->ID),//排除当前文章 
		'caller_get_posts' => 1, // 排除置顶文章. 
		'orderby' => 'comment_count', // 依评论数排序. 
		'posts_per_page' => $post_num 
		); 
		$query_posts = new WP_Query(); 
		$query_posts->query($args); 
		while( $query_posts->have_posts() ) { $query_posts->the_post(); ?> 
		<li class="clear">
			<a target="_blank" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" class="pic fl"><img src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&w=60&h=60&zc=1" alt="<?php the_title(); ?>" class="thumbnail"/></a>
			<div class="show">
				<a target="_blank" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" class="tit"><?php the_title(); ?></a>
				<p class="info"><?php the_time('m月d日 G:H'); ?> <span class="comm"><i class="icon-comment"></i><?php comments_popup_link ('0','1','%'); ?></span></p>
			</div>
		</li>
	<?php } wp_reset_query();?> 		
	</ul>
</div>


<div id="float">   
<div class="hot-auction">
    <div class="mod-tit">
        <h2 class="tit">扫码关注</h2>
    </div>
	<div class="aside-social__qrcode">
		<img src="<?php echo get_option( 'wxewm' ); ?>" width="250" height="250"><br>
		<span style="width: 250px;line-height: 30px;text-align: center;display: block;">微信扫描二维码，关注我们</span>
	</div>
</div>
</div> 



</div>	
    </section>
</div>





<section class="friendship-links">
	<div class="content">
		<h2 class="title-links">友情链接：</h2>
		<ul class="links">
			<?php wp_list_bookmarks('title_li=&categorize=0&limit=100'); ?>
		</ul>
	</div>
</section>

<?php get_footer(); ?>