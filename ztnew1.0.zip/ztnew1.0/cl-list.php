	<div class="i-make">
		<div class="mod-tit">
			<h2 class="tit"><?php echo get_cat_name( $cid ); ?></h2>
			<a href="<?php echo get_category_link( $cid ); ?>" class="more" style="display:block">
				<span class="underline">更多</span>
				<span class="icon-shape"></span>
			</a>
		</div>
		<ul class="article-list clear">
			<?php 
				query_posts( array( 'cat'=>$cid, 'posts_per_page'=>4, 'ignore_sticky_posts'=>true ) );
				while( have_posts() ): the_post(); 
			?>
			<li class="fl">
				<a target="_blank" href="<?php the_permalink(); ?>" class="pic">
					<img src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&w=140&h=140&zc=1" alt="<?php the_title(); ?>" class="thumbnail"/>
				</a>
				<div class="shadow"></div>
				<div class="show">
					<a target="_blank" href="<?php the_permalink(); ?>" class="tit" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a>
				</div>
			</li>
			<?php endwhile; wp_reset_query(); ?>
		</ul>
	</div>