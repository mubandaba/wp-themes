<?php get_header();?>

<div class="content article column">

	<div class="fast"><i class="icon-home"></i><?php if (function_exists('get_breadcrumbs')){get_breadcrumbs(); } ?></div>
	
	<section class="main clear">
	  
        <div class="cont fl">
		<?php while( have_posts() ): the_post(); $p_id = get_the_ID(); ?>	
          <article class="article-cont">
            <h1 class="tit"><?php the_title(); ?></h1>
            <div class="detail">
            	<span id="author_baidu"><a target="_blank" href="<?php echo get_option('home'); ?>/author/<?php the_author_login(); ?>" class="author"><?php the_author_link (); ?></a></span>
            	<span class="point">•</span>
            	<span id="pubtime_baidu"><?php the_time('Y-m-d G:H:s'); ?></span>
				<span class="point">•</span>
            	<?php the_category(', ') ?>            	
				<span class="point" id="source_baidu">• 来源： <a class="blue" href="<?php echo get_option('home'); ?>" target="_blank"><?php bloginfo('name'); ?></a></span>    
                <span class="comment">
                    <a href="#comment"><i class="icon-comment"></i><?php echo get_post($post->ID)->comment_count; ?></a>
                </span>
            </div>


            <div class="tags-top"><?php the_tags('', ' ', ''); ?></div>
            <div class="point">
              <p class="fz14"><?php echo mb_strimwidth(strip_tags($post->post_content),0,110,'...');?><!--<?php the_excerpt();?>--></p>
            </div>
            <div class="paragraph">
            	<?php the_content(); ?>
            </div>
            <div class="reminder">
              <p class="article-source">
              （本文系作者@<span class="keyword"><a class="blue" href="<?php echo get_option('home'); ?>/author/<?php the_author_login(); ?>" title="由 <?php the_author_link (); ?> 发布" rel="author"><?php the_author_link (); ?></a></span> 授权<?php bloginfo('name'); ?>发表，并经<?php bloginfo('name'); ?>编辑，转载请注明出处和<a href="<?php the_permalink(); ?>" target="_blank" style="color:#205b87;">本文链接</a>)</p>
            </div>


			
            <div class="js-operate js-operate-out">
              <div class="left-part">
              	<span class="js-like ">
              		<i class="icon-heart"></i>
              		<i class="png-icon icon-heart-current"></i>
              		<span class="num like-num"><a href="javascript:;" data-action="ding" data-id="<?php the_ID(); ?>" class="favorite<?php if(isset($_COOKIE['bigfa_ding_'.$post->ID])) echo ' done';?>">
									<?php if( get_post_meta($post->ID,'bigfa_ding',true) ){            
											echo get_post_meta($post->ID,'bigfa_ding',true);
										 } else {
											echo '0';
										 }?> 
								</a></span>喜欢
              	 </span>
                <a class="js-inform" href="#" target="_blank">
                  <i class="icon-inform gradient"></i> 举报
                </a>
                <span class="js-share">
                  <i class="icon-share gradient"></i>
				</span>
              </div>
				<span class="share">分享到：
					<div class="bdsharebuttonbox">
					<a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a>
					<a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a>
					<a href="#" class="bds_weixin" data-cmd="weixin" style="padding-left:0px" title="分享到微信"></a>
					</div>
				<script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"1","bdSize":"16"},"share":{}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script>
				</span>
            </div>
			
			
		</article>
		<?php endwhile; ?>
		  
		  
		  

		  
          <div class="wechat clear"><img src="<?php echo get_option( 'wxewm' ); ?>" width="80" height="80" class="qrcod fl" data-bd-imgshare-binded="1">
            <div class="right">第一时间获取TMT行业新鲜资讯和深度商业分析，请在微信公众账号中搜索「<span class="keyword">钛媒体</span>」或者「<span class="keyword">taimeiti</span>」，或用手机扫描左方二维码，即可获得钛媒体每日精华内容推送和最优搜索体验，并参与编辑活动。</div>
          </div>
		  
		  
		  
		  
		  
		<div class="related-articles clear">
		
		<div class="bfd_div"><div class="bfd_title">猜您喜欢</div>
		
		
		
		
		<div class="bfd_message">
		
			<ul>
<?php
global $post;
$cats = wp_get_post_categories($post->ID);
if ($cats) {
    $args = array(
          'category__in' => array( $cats[0] ),
          'post__not_in' => array( $post->ID ),
          'showposts' => 3,
          'caller_get_posts' => 1
      );
  query_posts($args);
  if (have_posts()) {
    while (have_posts()) {
      the_post(); update_post_caches($posts); ?>
			<li class="bfd_li_dt"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" target="_blank" ></a>
			<div class="div_mess"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" target="_blank">
			<img src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&w=200&h=150&zc=1" alt="<?php the_title(); ?>" class="bfd_img thumbnail"/>
			<div class="bfd_name"><?php the_title(); ?></div></a></div></li>
<?php
    }
  }
  else {
    echo '<li>暂无相关信息</li>';
  }
  wp_reset_query();
}
else {
  echo '<li>暂无相关信息</li>';
}
?>			

			</ul>
		</div>
		</div>
		</div>
		
		<div class="mod-comment" id="comment">
            <div class="mod-tit">
              <h3 class="tit"><span class="total"><?php echo get_post($post->ID)->comment_count; ?></span>条评论</h3>
            </div>
			<?php comments_template(); ?>

		</div>
        </div>
		
		<?php get_sidebar(); ?>
      </section>
    </div>

<?php get_footer(); ?>