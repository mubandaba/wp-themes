Theme Name: BunnyPress
Theme URI: https://yws.tokyo/bunnypresslite/
Contributors: Yossybunny
Author: yossy's web service
Author URI: https://yws.tokyo/
Requires at least: WordPress 5.5
Requires PHP: 7.0
Tested up to: 5.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Description: A WordPress theme created by Yossy's web service.
Stable tag: 1.0.10


************************* License *************************

BunnyPress WordPress Theme, Copyright 2020 yossy's web service
BunnyPress WordPress Theme, Copyright 2020 TIJAJI
BunnyPress is distributed under the terms of the GNU GPL
http://www.gnu.org/licenses/gpl-2.0.html

* Screenshots
Screenshot images are all licensed under CC0 Universal
https://pxhere.com/en/photo/1382903
https://pxhere.com/en/photo/810735
https://pxhere.com/en/photo/568976