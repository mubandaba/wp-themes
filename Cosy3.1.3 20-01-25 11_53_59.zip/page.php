<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @package Cosy19
 */

get_header();
?>
	<?php while ( have_posts() ) : the_post(); ?>
	    <main class="py-4 py-md-5">
			<div class="container">
				<div class="row">
				    <div class="col-lg-9">
				        <div class="post">
				            <h1 class="post-title h2 mb-3 mb-md-4">
				            	<?php the_title() ?>
				            </h1>
				            <div class="content-style content">
				                <?php the_content() ?>
				            </div>
				        </div>
				        <?php
				            if ( comments_open() || get_comments_number() ) :
				                comments_template();
				            endif;
				        ?>
				    </div>
				    <div class="col-md-3 d-none d-lg-block">
				        <?php get_sidebar() ?>
				    </div>
				</div>
			</div>
		</main><!-- #main -->
	<?php endwhile; // End of the loop.?>
<?php
get_footer();
