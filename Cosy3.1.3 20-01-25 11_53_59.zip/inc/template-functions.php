<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package Cosy19
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function cosy19_body_classes( $classes ) {
    $black_magic = get_field('kuang_style_nice', 'option');
    if ( ! is_admin() ) {
        $radius = $black_magic['card_radius'] == 1 ? ' nice-style-radius ' : '';
        $shadow = $black_magic['card_shadow'] == 1 ? ' nice-style-shadow ' : '';
        $bordered = $black_magic['card_bordered'] == 1 ? ' nice-style-border ' : '';
        $hover = $black_magic['card_hover'] == 1 ? ' nice-style-hover ' : '';
        $classes[] = $radius.$shadow.$bordered.$hover;
    }
	// Adds a class of no-sidebar when there is no sidebar present.
	if ( ! is_active_sidebar( 'main-sidebar' ) ) {
		$classes[] = 'no-sidebar';
	}

	return $classes;
}
add_filter( 'body_class', 'cosy19_body_classes' );

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function cosy19_pingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
	}
}
add_action( 'wp_head', 'cosy19_pingback_header' );

/**
 * 评论列表 & 表单
 */
function cosy19_comment($comment, $args, $depth) {
    get_template_part('comment');
}
function cosy19_end_comment() {
    echo '</li>';
}

// add @
function cosy_comment_add_at( $comment_text, $comment = '') {
    if( $comment->comment_parent > 0) {
        $comment_text = '<a rel="nofollow" class="comment_at" href="#comment-' . $comment->comment_parent . '">@'.get_comment_author( $comment->comment_parent ) . '：</a> ' . $comment_text;
    }
    return $comment_text;
}
add_filter( 'comment_text' , 'cosy_comment_add_at', 10, 2);

/**
 * 时间定制
 */
function cosy19_timeago($ptime = null) {
    global $post;
    $ptime = $ptime ?: get_post_time('G', true, $post);
    $etime = abs(time() - $ptime);
    if($etime < 1) return __( 'Just now', 'cosy19' );
    $interval = array (
        12 * 30 * 24 * 60 * 60  =>  date('Y-m-d', $ptime),
        30 * 24 * 60 * 60       =>  date('m-d', $ptime),
        7 * 24 * 60 * 60        =>  date('m-d', $ptime),
        24 * 60 * 60            =>  __( ' day(s) ago', 'cosy19' ),
        60 * 60                 =>  __( ' hour(s) ago', 'cosy19' ),
        60                      =>  __( ' min(s) ago', 'cosy19' ),
        1                       =>  __( ' sec(s) ago', 'cosy19' ),
    );
    foreach ($interval as $secs => $str) {
        if( $etime - ( 24 * 60 * 60 ) > 0 ){
            return $str;
        } else {
           $d = $etime / $secs;
           if ($d >= 1) {
               $r = round($d);
               return $r . $str;
           }
        }

    }
}

/**
 * 字符串截取，支持中文和其他编码
 *
 * @param string $str 需要转换的字符串
 * @param string $start 开始位置
 * @param string $length 截取长度
 * @param string $charset 编码格式
 * @param string $suffix 截断字符串后缀
 * @return string
 */
function cosy19_substr_ext($str, $start = 0, $length = 0, $charset = 'utf-8', $suffix = '') {
    if(function_exists("mb_substr")){
         return mb_substr($str, $start, $length, $charset).$suffix;
    }
    elseif(function_exists('iconv_substr')){
         return iconv_substr($str,$start,$length,$charset).$suffix;
    }
    $re['utf-8']  = "/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|[\xe0-\xef][\x80-\xbf]{2}|[\xf0-\xff][\x80-\xbf]{3}/";
    $re['gb2312'] = "/[\x01-\x7f]|[\xb0-\xf7][\xa0-\xfe]/";
    $re['gbk']    = "/[\x01-\x7f]|[\x81-\xfe][\x40-\xfe]/";
    $re['big5']   = "/[\x01-\x7f]|[\x81-\xfe]([\x40-\x7e]|\xa1-\xfe])/";
    preg_match_all($re[$charset], $str, $match);
    $slice = join("",array_slice($match[0], $start, $length));
    return $slice.$suffix;
}

function cosy19_reverse_strrchr($haystack, $needle, $trail) {
	$length = (strrpos($haystack, $needle) + $trail);
    return strrpos($haystack, $needle) ? substr($haystack,0,$length) : false;
}

/**
 * 获取完整的句子
 */
function cosy19_print_excerpt($length, $post = null, $echo = true) {
	global $post;
	$text = $post->post_excerpt;

	if ( '' == $text ) {
		$text = get_the_content();
		$text = strip_shortcodes($text);
		$text = apply_filters('the_content', $text);
		$text = str_replace(']]>', ']]>', $text);
	}

	$text = strip_shortcodes($text);
	$text = strip_tags($text);

	$text = cosy19_substr_ext($text,0,$length);
	$excerpt = cosy19_reverse_strrchr($text, '。', 3);

	if( $excerpt ) {
		$result = strip_tags(apply_filters('the_excerpt',$excerpt)).'...';
	} else {
		$result = strip_tags(apply_filters('the_excerpt',$text)).'...';
	}
	if ($echo == true) echo $result; else return $result;
}

function cosy19_add_menuclass($ulclass) {
    return preg_replace('/<a /', '<a class="nav-link"', $ulclass);
}
add_filter('wp_nav_menu','cosy19_add_menuclass');
 
function cosy19_post_thumbnail_src($post = null) {
	if( $post === null ){
    	global $post;
	}
    $post_thumbnail_src = '';

   	if (has_post_thumbnail($post)) {
        $post_thumbnail_src = get_post_thumbnail_id($post->ID);
        $post_thumbnail_src = wp_get_attachment_image_src($post_thumbnail_src, 'full');
        $post_thumbnail_src = $post_thumbnail_src[0];
    } else {
        $post_thumbnail_src = '';
        $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
        if (!empty($matches[1][0])) {
            global $wpdb;
            $att = $wpdb->get_row( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE guid LIKE '%s'", $matches[1][0] ) );

            if( $att ){
                $post_thumbnail_src =  wp_get_attachment_image_src($att->ID, 'full');
                $post_thumbnail_src = $post_thumbnail_src[0];
            }else{
                $post_thumbnail_src = $matches[1][0];
            }
        } else {
            $site_default_img = get_field('default_thumbnail', 'option');
            if( isset( $site_default_img ) && !empty( $site_default_img ) ){
                $post_thumbnail_src = $site_default_img;
            } else { 
                $post_thumbnail_src = get_template_directory_uri().'/images/default.png';
            }
        }
    }
    return $post_thumbnail_src;
}


function cosy19_get_head_img( $id, $size = array('w' => 900, 'h' => 300) ) {
    $head_img = get_field('head_img', $id);
    if ($head_img === NULL || $head_img === '1') {
        $img = !empty(get_field('head_img_url', $id)) ? get_field('head_img_url', $id) : cosy19_post_thumbnail_src(get_post($id));
        return timthumb($img, $size);
    }
    return '';
}

function cosy19_get_hearts($postID) {
    if ( get_post_meta($postID,'suxing_ding',true) ) {
        return get_post_meta($postID,'suxing_ding',true);
    }
    return '0';
}

function cosy19_get_footer_year() {
    $initial_year = get_field('footer_bottom', 'option')['initial_year'];
    $current_year = intval(date('Y'));
    if (!empty($initial_year)) {
        return $initial_year == $current_year ? $current_year : $initial_year.'-'.$current_year;
    }
    return $current_year;
}

function cosy19_record_visitors() {
    if (is_singular()) {
        global $post;
        $post_ID = $post->ID;
        if($post_ID)
        {
          $post_views = (int)get_post_meta($post_ID, 'views', true);
          if(!update_post_meta($post_ID, 'views', ($post_views+1)))
          {
            add_post_meta($post_ID, 'views', 1, true);
          }
        }
    }
}
add_action('wp_head', 'cosy19_record_visitors');

function cosy19_post_views($before = '(点击 ', $after = ' 次)', $echo = 1) {
    global $post;
    $post_ID = $post->ID;
    $views = (int)get_post_meta($post_ID, 'views', true);
    if ($echo) echo $before, number_format($views), $after;
    else return $views;
}

function timthumb( $src, $size = null, $set = null ) {

    $modular = get_field('thumbnail_handle', 'option');
    
	if( $set == 'original' || !$size ) {
		return $src;
	}

	if( is_numeric( $src ) ){
		if( $modular == 'timthumb_php' ){
			$src = image_downsize( $src, $size['w'].'-'.$size['h'] );
		}else{
			$src = image_downsize( $src, 'full' );
		}
		$src = $src[0];
	}

	if( 'qiniu' == $modular ){

		if( !empty( $size ) ){

			$sep = get_field('thumbnail_handle_qiniu_sep', 'option');
			$sep = empty( $sep ) ? '!' : $sep;

			return sprintf( $src . $sep . 'imageView2/1/w/%s/h/%s/sharpen/1/interlace/1', round( $size['w'] ), round( $size['h'] ) );

		}else{
			return $src;
		}

	}

	if( 'upyun' == $modular ){

		if(!empty( $size ) ){

			$sep = get_field('thumbnail_handle_upyun_sep', 'option');
			$sep = empty( $sep ) ? '!' : $sep;

			return sprintf( $src . $sep . 'upyun520/both/%sx%s/quality/100/unsharp/true/progressive/true', round( $size['w'] ), round( $size['h'] ) );

		}else{
			return $src;
		}

	}

	if( 'aliyunoss' == $modular ){

		if( !empty( $size ) ){

			$sep = get_field('thumbnail_handle_aliyunoss_sep', 'option');
			$sep = empty( $sep ) ? '?' : $sep;

			return sprintf( $src . $sep . 'x-oss-process=image/resize,w_%s,h_%s,m_fill/sharpen,100', round( $size['w'] ), round( $size['h'] ) );

		}else{
			return $src;
		}

	}

	if ($modular == 'timthumb_php' || empty($modular) || $set == 'tim') {
		return get_stylesheet_directory_uri().'/timthumb.php?src='.$src.'&h='.$size["h"].'&w='.$size['w'].'&zc=1&a=c&q=100&s=1';
	} else {
		return $src;
	}

}

function cosy19_the_thumbnail($post = null, $size = array('w' => 450, 'h' => 300), $set = 'small') {
    echo timthumb(cosy19_post_thumbnail_src($post), $size, $set);
}

add_filter( 'get_the_archive_title', function ($title) {
    if ( is_category() ) {
        $title = single_cat_title( '', false );
    } elseif ( is_tag() ) {
        $title = single_tag_title( '', false );
    } elseif ( is_author() ) {
        $title = get_the_author();
    }

    return $title;
});


add_action('wp_ajax_nopriv_ajax_comment', 'ajax_comment_callback');
add_action('wp_ajax_ajax_comment', 'ajax_comment_callback');
function ajax_comment_callback(){
    global $wpdb;
    $comment_post_ID = isset($_POST['comment_post_ID']) ? (int) $_POST['comment_post_ID'] : 0;
    $post = get_post($comment_post_ID);
    $post_author = $post->post_author;
    if ( empty($post->comment_status) ) {
        do_action('comment_id_not_found', $comment_post_ID);
        ajax_comment_err('Invalid comment status.');
    }
    $status = get_post_status($post);
    $status_obj = get_post_status_object($status);
    if ( !comments_open($comment_post_ID) ) {
        do_action('comment_closed', $comment_post_ID);
        ajax_comment_err(__( 'Sorry, comments are closed.', 'cosy19' ));
    } elseif ( 'trash' == $status ) {
        do_action('comment_on_trash', $comment_post_ID);
        ajax_comment_err(__( 'Unknown error.', 'cosy19' ));
    } elseif ( !$status_obj->public && !$status_obj->private ) {
        do_action('comment_on_draft', $comment_post_ID);
        ajax_comment_err(__( 'Unknown error.', 'cosy19' ));
    } elseif ( post_password_required($comment_post_ID) ) {
        do_action('comment_on_password_protected', $comment_post_ID);
        ajax_comment_err(__( 'Password protected.', 'cosy19' ));
    } else {
        do_action('pre_comment_on_post', $comment_post_ID);
    }

    $comment_author       = ( isset($_POST['author']) )  ? trim(strip_tags($_POST['author'])) : null;
    $comment_author_email = ( isset($_POST['email']) )   ? trim($_POST['email']) : null;
    $comment_author_url   = ( isset($_POST['url']) )     ? trim($_POST['url']) : null;
    $comment_content      = ( isset($_POST['comment']) ) ? trim($_POST['comment']) : null;
    $user = wp_get_current_user();
    if ( $user->exists() ) {
        if ( empty( $user->display_name ) )
            $user->display_name=$user->user_login;
        $comment_author       = esc_sql($user->display_name);
        $comment_author_email = esc_sql($user->user_email);
        $comment_author_url   = esc_sql($user->user_url);
        $user_ID              = esc_sql($user->ID);

    } else {
        if ( get_option('comment_registration') || 'private' == $status )
            ajax_comment_err('<p>'.__('Sorry, you must be logged in to leave a comment', 'cosy19').'</p>'); // 抱歉，您必须登录后才能发表评论。
    }
    $comment_type = '';
    if ( get_option('require_name_email') && !$user->exists() ) {
        if ( 6 > strlen($comment_author_email) || '' == $comment_author )
            ajax_comment_err( '<p>'.__('Please fill in the required options (Name, Email).', 'cosy19').'</p>' ); // 错误：请填写必须的选项（姓名，电子邮件）。
        elseif ( !is_email($comment_author_email))
            ajax_comment_err( '<p>'.__('Please input a valid email address.', 'cosy19').'</p>' ); // 错误：请输入有效的电子邮件地址。
    }
    if ( '' == $comment_content )
        ajax_comment_err( '<p>'.__('Say something...', 'cosy19').'</p>' ); // 说点什么吧
    $dupe = "SELECT comment_ID FROM $wpdb->comments WHERE comment_post_ID = '$comment_post_ID' AND ( comment_author = '$comment_author' ";
    if ( $comment_author_email ) $dupe .= "OR comment_author_email = '$comment_author_email' ";
    $dupe .= ") AND comment_content = '$comment_content' LIMIT 1";
    if ( $wpdb->get_var($dupe) ) {
        ajax_comment_err('<p>'.__('Please do not repeat your comments. :)', 'cosy19').'</p>'); // Do not repeat comments aha~似乎说过这句话了
    }

    if ( $lasttime = $wpdb->get_var( $wpdb->prepare("SELECT comment_date_gmt FROM $wpdb->comments WHERE comment_author = %s ORDER BY comment_date DESC LIMIT 1", $comment_author) ) ) {
        $time_lastcomment = mysql2date('U', $lasttime, false);
        $time_newcomment  = mysql2date('U', current_time('mysql', 1), false);
        $flood_die = apply_filters('comment_flood_filter', false, $time_lastcomment, $time_newcomment);
        if ( $flood_die ) {
            ajax_comment_err('<p>'.__('You reply too fast. Take it easy.', 'cosy19').'</p>'); // 你回复太快啦。慢慢来。
        }
    }
    $comment_parent = isset($_POST['comment_parent']) ? absint($_POST['comment_parent']) : 0;
    $commentdata = compact('comment_post_ID', 'comment_author', 'comment_author_email', 'comment_author_url', 'comment_content', 'comment_type', 'comment_parent', 'user_ID');

    $comment_id = wp_new_comment( $commentdata );


    $comment = get_comment($comment_id);
    do_action('set_comment_cookies', $comment, $user);
    $comment_depth = 1;
    $tmp_c = $comment;
    while($tmp_c->comment_parent != 0){
        $comment_depth++;
        $tmp_c = get_comment($tmp_c->comment_parent);
    }
    $GLOBALS['comment'] = $comment;
    get_template_part('comment');
    ?>
    <?php
        die();
}
function ajax_comment_err($a) {
    header('HTTP/1.0 500 Internal Server Error');
    header('Content-Type: text/plain;charset=UTF-8');
    echo $a;
    exit;
}

function qrcode_test() {   
	global $pagenow;    
	if ( 'themes.php' == $pagenow && isset( $_GET['activated'] ) ){   
		require_once get_template_directory() . '/modules/phpqrcode.php';
		@QRcode::tryTest();
	}   
}   
add_action( 'load-themes.php', 'qrcode_test' ); 

add_action('wp_ajax_nopriv_ajax_load_comments', 'ajax_load_comments');
add_action('wp_ajax_ajax_load_comments', 'ajax_load_comments');

function ajax_load_comments(){

	global $wp_query;

	$type  = sanitize_text_field( $_POST['type'] );
	$paged = sanitize_text_field( $_POST['paged'] );


    $q = sanitize_text_field( $_POST['query'] );

    if( $paged < 1 || $paged > $_POST['commentcount'] ){
        wp_die();
    }

    if ($type === 'page') {
        $wp_query = new WP_Query( array( 'page_id' => $q, 'cpage' => $paged ) );
    }

    if ($type === 'post') {
        $wp_query = new WP_Query( array( 'p' => $q, 'cpage' => $paged ) );
    }

    if ( have_posts() ) {
        while ( have_posts() ) {
            the_post();
            comments_template();
        }
    }

	wp_reset_postdata();
	wp_die();
}

/**
 * 获取评论下一页页码
 */
function get_next_page_number() {
	$page_number = get_comment_pages_count();
	if( get_option('default_comments_page') == 'newest' ){
		$next_page = $page_number - 1;
	}else{
		$next_page = 2;
	}
	return $next_page;
}

function cosy19_get_posts_view_count($authorID = '') {
    if ($authorID) {
        $count = 0;
        $author_query = new WP_Query('posts_per_page=-1&author=' . $authorID);
        while ($author_query->have_posts()) {
            $author_query->the_post();
            $count = $count + get_post_meta(get_the_ID(), 'views', true);
        }
        wp_reset_postdata();
        return $count;
    }
    return false;
}

function cosy19_remove_wpautop_function() {
    remove_filter('acf_the_content', 'wpautop');
}
add_action( 'after_setup_theme', 'cosy19_remove_wpautop_function' );

add_action('wp_ajax_nopriv_cosy19_like', 'cosy19_like');
add_action('wp_ajax_cosy19_like', 'cosy19_like');
function cosy19_like() {
    global $wpdb,$post;
    $id = $_POST["id"];
    $action = $_POST["like_action"];
    $cosy19_raters = get_post_meta($id,'suxing_ding',true);
    $domain = ($_SERVER['HTTP_HOST'] != 'localhost') ? $_SERVER['HTTP_HOST'] : false;
    if ($action == 'like') {
        $expire = time() + 99999999;
        if (!isset($_COOKIE['suxing_ding_'.$id])) {
            setcookie('suxing_ding_'.$id,$id,$expire,'/',$domain,false);
            if (!$cosy19_raters || !is_numeric($cosy19_raters)) {
                update_post_meta($id, 'suxing_ding', 1);
            } else {
                update_post_meta($id, 'suxing_ding', ($cosy19_raters + 1));
            }
        }
    }
    if ($action == 'unlike') {
        $expire = time() - 1;
        if (isset($_COOKIE['suxing_ding_'.$id])) {
            setcookie('suxing_ding_'.$id,$id,$expire,'/',$domain,false);
            update_post_meta($id, 'suxing_ding', ($cosy19_raters - 1));
        }
    }
    echo get_post_meta($id,'suxing_ding',true);
    die;
}


/**
 * ajax 加载文章
 */
add_action('wp_ajax_nopriv_ajax_load_posts', 'ajax_load_posts');
add_action('wp_ajax_ajax_load_posts', 'ajax_load_posts');

function ajax_load_posts() {

	global $wp_query;

	$page  = sanitize_text_field( $_POST['page'] );
    $paged = sanitize_text_field( $_POST['paged'] );
    

	if( $page == 'home' ){

		$tabcid = isset( $_POST['tabcid'] ) ? sanitize_text_field( $_POST['tabcid'] ) : null;

		if( $tabcid < 1 ){
			$fmt = explode('.', $tabcid);
			$tabcid = $fmt[0];
        }

		switch ($tabcid) {
			case -1: // order by
				
				$tabs = get_field('index_tab', 'option');

				$tab = $tabs['list'][$fmt[1]]; // 获取 index 对应的设置项
				$strtotime = strtotime('-'.$tab['days'].' days');

				switch ( $tab['sort_type'] ) {
					case 'view':
						$args = array_merge( 
							$wp_query->query_vars, 
							array( 
								'paged'               => $paged, 
								'post_status'         => 'publish', 
								'ignore_sticky_posts' => 1,
								'orderby'             => 'meta_value_num',
								'meta_key'            => 'views',
								'date_query'          => array(
									array(
										'before' => date( 'Y-m-d', time() ),
									),
									array(
										'after' => date( 'Y-m-d', $strtotime ),
									),

								), 
							) 
						);

						break;

					case 'like':
						$args = array_merge( 
							$wp_query->query_vars, 
							array( 
								'paged'               => $paged, 
								'post_status'         => 'publish', 
								'ignore_sticky_posts' => 1,
								'orderby'             => 'meta_value_num',
								'meta_key'            => 'suxing_ding',
								'date_query'          => array(
									array(
										'before' => date( 'Y-m-d', time() ),
									),
									array(
										'after' => date( 'Y-m-d', $strtotime ),
									),

								), 
							) 
						);

						break;

					case 'comment':
						
						$args = array_merge( 
							$wp_query->query_vars, 
							array( 
								'paged'               => $paged, 
								'post_status'         => 'publish', 
								'ignore_sticky_posts' => 1,
								'orderby'             => 'comment_count',
								'date_query'          => array(
									array(
										'before' => date( 'Y-m-d', time() ),
									),
									array(
										'after' => date( 'Y-m-d', $strtotime ),
									),

								), 
							) 
						);

						break;
				}

                break;
                
			case -2: // home latest
				
                $masking_cats = get_field('masking_cats', 'option');
				$args = array_merge( $wp_query->query_vars, array( 'paged' => $paged, 'post_status' => 'publish', 'ignore_sticky_posts' => 1 ) );

				if( is_array( $masking_cats ) ){
					$args['category__not_in'] = $masking_cats;
				}

				break;

			case null:
				// 兼容
				$masking_cats = get_field('masking_cats', 'option');

				$args = array_merge( $wp_query->query_vars, array( 'paged' => $paged, 'post_status' => 'publish', 'ignore_sticky_posts' => 1 ) );

				if( is_array( $masking_cats ) ){
					$args['category__not_in'] = $masking_cats;
				}

				break;
			
            default:
				$args = array_merge( $wp_query->query_vars, array( 'paged' => $paged, 'post_status' => 'publish', 'cat' => $tabcid, 'ignore_sticky_posts' => 1 ) );
				break;
		}

		$queryPosts = new WP_Query( $args );
		if( $queryPosts->have_posts() ) {
			$index = 0;
			while ( $queryPosts->have_posts() ) {
				$queryPosts->the_post();
				$index++;
				
				if ($tabcid == -2 && $paged < 2) {
					// AD
					$index_list_ad = get_field('index_list_ad', 'option');

					// Topic Card
					$index_insert_topic_card = get_field('index_insert_topic_card', 'option');
					$index_insert_topics = get_field('index_insert_topics', 'option');

					if ($index_insert_topic_card && in_array($index, array_column($index_insert_topics, 'position'))):
						get_template_part_with_vars('template-parts/post-cards/card-topic', array('index_insert_topics' => $index_insert_topics, 'index' => $index));
					endif;

					if ($index_list_ad['position'] == $index):
						get_template_part('template-parts/post-cards/card-ad');
					endif;
				}
				get_template_part_with_vars("template-parts/post-cards/card-small", array('type' => ''));
			}
		}
	}

	if( $page == 'cat' ) {
		
        $q = sanitize_text_field( $_POST['query'] );
        
        $cat_style = get_field('cat_style', "category_$q");
        $cat_style = empty($cat_style) ? 'small' : $cat_style;

		$args = array_merge( $wp_query->query_vars, array( 'paged' => $paged, 'post_status' => 'publish', 'cat' => $q, 'ignore_sticky_posts' => 1 ) );
        $queryPosts = new WP_Query( $args );
        
		if ( $queryPosts->have_posts() ) {
			while ( $queryPosts->have_posts() ) {
                $queryPosts->the_post();
                get_template_part_with_vars("template-parts/post-cards/card-$cat_style", array('type' => 'cat'));
			}
        }
	}

	if( $page == 'tag' ) {

        $q = sanitize_text_field( $_POST['query'] );
        
        $tag_style = get_field('tag_style', "option");
        $tag_style = empty($tag_style) ? 'small' : $tag_style;

		$args = array_merge( $wp_query->query_vars, array( 'paged' => $paged, 'post_status' => 'publish', 'tag' => $q, 'ignore_sticky_posts' => 1 ) );
		$queryPosts = new WP_Query( $args );

		if ( $queryPosts->have_posts() ) {
			while ( $queryPosts->have_posts() ) {
				$queryPosts->the_post();
                get_template_part_with_vars("template-parts/post-cards/card-$tag_style", array('type' => ''));
			}
		}
	}

	if( $page == 'tax' ){

        $q = sanitize_text_field( $_POST['query'] );
    
		$tax = array(
			array(
				'taxonomy' => 'special',
				'field'    => 'name',
				'terms' => $q
			),
		);

		$args = array_merge( $wp_query->query_vars, array( 'paged' => $paged, 'post_status' => 'publish', 'tax_query' => $tax, 'ignore_sticky_posts' => 1 ) );
		$queryPosts = new WP_Query( $args );

		if ( $queryPosts->have_posts() ) {
			while ( $queryPosts->have_posts() ) {
				$queryPosts->the_post();
                get_template_part_with_vars("template-parts/post-cards/card-small", array('type' => ''));
			}
        }
	}

	if( $page == 'search' ){

        $q = sanitize_text_field( $_POST['query'] );
        
        $search_style = get_field('search_style', "option");
        $search_style = empty($search_style) ? 'small' : $search_style;

		$args = array_merge( $wp_query->query_vars, array( 'paged' => $paged, 'post_type' => 'post', 'post_status' => 'publish', 's' => $q, 'ignore_sticky_posts' => 1 ) );
		$queryPosts = new WP_Query( $args );

		if ( $queryPosts->have_posts() ) {
			while ( $queryPosts->have_posts() ) {
                $queryPosts->the_post();
                get_template_part_with_vars("template-parts/post-cards/card-$search_style", array('type' => ''));
			}
        }

    }
    
    if( $page == 'author' ) {
		
        $q = sanitize_text_field( $_POST['query'] );

        $author_style = get_field('author_style', "option") ?: 'small';
		$args = array_merge( $wp_query->query_vars, array( 'paged' => $paged, 'post_status' => 'publish', 'author' => $q, 'ignore_sticky_posts' => 1 ) );
        $queryPosts = new WP_Query( $args );
        
		if ( $queryPosts->have_posts() ) {
			while ( $queryPosts->have_posts() ) {
                $queryPosts->the_post();
                get_template_part_with_vars("template-parts/post-cards/card-$author_style", array('type' => ''));
			}
        }
	}

    wp_reset_postdata();
	wp_die();
}

/**
 * 文章历史
 */
add_action('wp_ajax_nopriv_load_view_history', 'load_view_history');
add_action('wp_ajax_load_view_history', 'load_view_history');

function load_view_history() {
    $ids_array = json_decode(stripslashes($_POST['post_id']));
    $ids = array_column(array_map(function($o){return(array)$o;}, $ids_array), 'id');
    if (is_array($ids) && count($ids) > 0) {
        $args = array(
            'posts_per_page' => 20,
            'post__in' => $ids,
            'ignore_sticky_posts' => 1
        );
        $queryPosts = new WP_Query( $args );
        
        if ( $queryPosts->have_posts() ) {
            while ( $queryPosts->have_posts() ) {
                $queryPosts->the_post();
                get_template_part_with_vars("template-parts/post-cards/card-small", array('type' => ''));
            }
        }
    
        wp_reset_postdata();
    }
    wp_die();
}


function get_translated_role_name($role) {
    global $wp_roles;
    $name = translate_user_role( $wp_roles->roles[ $role ]['name'] );
    switch($name) {
        case 'Administrator':
            return '站长';
        case 'Contributor':
            return '投稿用户';
        case 'Author':
            return '特约作者';
        case 'Editor':
            return '认证编辑';
        case 'Subscriber':
            return '订阅者';
    }
    return false;
}

/**
 * Load a component into a template while supplying data.
 *
 * @param string $slug The slug name for the generic template.
 * @param array $params An associated array of data that will be extracted into the templates scope
 * @param bool $output Whether to output component or return as string.
 * @return string
 */
function get_template_part_with_vars($slug, array $params = array(), $output = true) {
	if(!$output) ob_start();
	$template_file = locate_template("{$slug}.php", false, false);
    extract(array('template_params' => $params), EXTR_SKIP);
    require($template_file);
	if(!$output) return ob_get_clean();
}


/**
 * 文章引用
 */
function insert_posts_shortcode($atts, $content = null) {
    extract( shortcode_atts( array(
        'ids' => ''
    ),$atts ) );
    global $post;
    $content = '';
    $postids =  explode(',', $ids);
    $insert_posts = get_posts(array('post__in'=>$postids));
    foreach ($insert_posts as $key => $post) {
        setup_postdata( $post );
        include( get_stylesheet_directory() . '/template-parts/shortcodes/insert-post.php' );
        $content .= $insert_post;
        wp_reset_postdata();
    }
    return $content;
}
add_shortcode('suxing_insert_post', 'insert_posts_shortcode');

/**
 * 评论引用
 */
function insert_comments_shortcode($atts, $content = null) {
	extract( shortcode_atts( array(
		'ids' => ''
	),$atts ) );
	$content = '';
	$comment_ids =  explode(',', $ids);
	$comments = get_comments( array(
		'comment__in' => $comment_ids
	) );

	foreach ($comments as $key => $value) {
		include( get_stylesheet_directory() . '/template-parts/shortcodes/insert-comments.php' );
		$content .= $comment;
	}

	return $content;
}
add_shortcode( 'suxing_insert_comments', 'insert_comments_shortcode' );

function format_big_numbers($num) {
    return $num >= 1000 ? floor($num / 1000).'K' : $num;
}

add_filter( "get_comment_author_link", "cosy19_modifiy_comment_author_anchor" );
function cosy19_modifiy_comment_author_anchor( $author_link ){
    return str_replace( "<a", "<a target='_blank'", $author_link );
}
