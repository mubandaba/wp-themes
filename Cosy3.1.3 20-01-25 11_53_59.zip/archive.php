<?php
/**
 * The template for displaying archive pages
 *
 * @package Cosy19
 */

global $wp_query;

if (is_category() || is_archive() && !is_author()) {
	$tpage = 'cat';
	$query = $cat;
	$style = get_field('cat_style', "category_$cat");
	$top_posts = get_field('top_posts', "category_$cat");
}
if (is_tag()) {
	$tpage = 'tag';
	$query = $wp_query->queried_object->name;
	$style = get_field('tag_style', 'option');
}

$style = empty($style) ? 'small' : $style;
$ajax_loading = get_field('archive_ajax_loading', 'option');
if ($style == 'plain') $grid_class = 'list-archive list-grid list-grid-padding list-bordered list-tb-padding my-n4';
if ($style == 'medium') $grid_class = 'row-lg list-archive list-grouped list-tb-padding';
if ($style == 'small') $grid_class = 'row-md list-archive list-grouped list-tb-padding';

get_header();
?>
	<?php if (is_category() && $top_posts): ?>
		<?php get_template_part_with_vars('template-parts/top-posts', array('style' => $style)); ?>
	<?php endif; ?>
	<main class="py-4 py-md-5">
		<div class="container">
			<?php if ($style == 'plain'): ?>
				<div class="row justify-content-md-center">
					<div class="col-lg-9">
			<?php endif; ?>
				<div class="list-header mb-3 mb-md-4">
					<?php the_archive_title( '<div class="h4">', '</div>' ); ?>
				</div>
				<?php if ( have_posts() ) : ?>
				<div class="<?php echo $grid_class ?>">
					<?php while ( have_posts() ) : the_post(); ?>
						<?php get_template_part_with_vars("template-parts/post-cards/card-$style", array('type' => is_category() ? 'cat' : '')); ?>
					<?php endwhile; ?>
				</div>
				<?php
					get_template_part_with_vars('template-parts/post-navigation', array(
						'ajax_loading' => $ajax_loading,
						'page' => $tpage,
						'query' => $query,
						'style' => $style,
						'append' => 'list-archive'
					));
				?>
				<?php else : ?>
					<div class="content-error h-v-66">
						<?php get_template_part('template-parts/not-found-svg'); ?>
			            <p class="text-lg text-muted mt-5"><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'cosy19' ); ?></p>
			        </div>
				<?php endif; ?>
				<?php get_template_part('template-parts/ad/tax-ad'); ?>
			<?php if ($style == 'plain'): ?>
					</div>
				</div>
			<?php endif; ?>
		</div>
	</main>

<?php
get_footer();