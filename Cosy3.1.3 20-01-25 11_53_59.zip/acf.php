<?php
/*
            /$$
    /$$    /$$$$
   | $$   |_  $$    /$$$$$$$
 /$$$$$$$$  | $$   /$$_____/
|__  $$__/  | $$  |  $$$$$$
   | $$     | $$   \____  $$
   |__/    /$$$$$$ /$$$$$$$/
          |______/|_______/
================================
        Keep calm and get rich.
                    Is the best.
*/

define( 'COSY19_DIR', dirname(__FILE__) );

define( 'COSY19_RELATIVE_DIR', COSY19_DIR );

define( 'COSY19_VERSION', '3.0' );

// nc store check
if( !defined('NC_STORE_ROOT_PATH') ){

	add_action( 'admin_notices', 'cosy19_init_check' );
	function cosy19_init_check(){
		$script_url = get_template_directory_uri() . '/js/nc-store-install.js';
		$html = '<div class="notice notice-error">
			<p><b>错误：</b> Cosy 主题 缺少依赖插件 <code>WP 积木</code> 请先安装并启用 <code>WP 积木</code> 插件。<a href="javascript:;" class="install-nc-store-now">现在安装？</a></p>
		</div><script type="text/javascript" src="' . $script_url . '"></script>';
		echo $html;
	}

	if( !is_admin() ){
		wp_die('Cosy 主题 缺少依赖插件 <code>WP 积木</code> 请先安装并启用 <a href="https://www.nicetheme.cn/nicetheme-plugins-store.html">WP 积木</a> 插件。');
	}

} else {


	acf_add_options_sub_page(
		array(
			'page_title'      => 'Cosy 主题设置',
			'menu_title'      => 'Cosy 主题设置',
			'menu_slug'       => 'cosy19-options',
			'parent_slug'     => 'nc-modules-store',
			'capability'      => 'manage_options',
			'update_button'   => '保存',
			'updated_message' => '设置已保存！'
		)
	);


	add_filter('nc_save_json_paths', 'cosy19_acf_json_save_point');

	function cosy19_acf_json_save_point( $path ) {

	    // update path
	    $path[] = COSY19_DIR . '/conf';

	    // return
	    return $path;

	}

	add_filter('acf/settings/load_json', 'cosy19_acf_json_load_point');

	function cosy19_acf_json_load_point( $paths ) {

	    // append path
	    $paths[] = COSY19_DIR . '/conf';

	    // return
	    return $paths;

	}
}