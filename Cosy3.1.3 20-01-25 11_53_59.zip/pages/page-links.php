<?php
/*
Template Name: Friend Links
*/
get_header();
$link_cats = get_field('link_cats', get_the_ID());
?>

    <main class="py-4 py-md-5" >
        <div class="container">
            <div class="row">
                <div class="col-md-9 col-lg-10 order-md-1">
                <?php if (is_array($link_cats) && count($link_cats) > 0): ?>
					<?php foreach ($link_cats as $link_cat): ?>
                    <?php
                        $cat = get_term($link_cat['cat'], 'link_category');
                        $links = get_bookmarks(array(
                            'category' => $link_cat['cat']
                        ));
                    ?>
                    <div class="list-links py-4 py-md-5 border-bottom border-light"  id="<?php echo "list-item-".$link_cat['cat'] ?>">
                        <div class="list-header text-muted mb-3 mb-md-4"><?php echo $cat->name ?></div>
                       
                            <div class="list-grid row my-n2">
                            <?php foreach($links as $link): ?>
                                <div class="col-md-6 col-lg-4 py-2">
                                    <div class="list-item">
                                        <div class="media w-56">
                                            <a class="media-content" href="<?php echo $link->link_url; ?>" target="<?php echo $link->link_target; ?>" style="background-image: url('<?php echo $link->link_image; ?>')">
                                            </a>
                                        </div>
                                        <div class="list-content">
                                            <div class="list-body">
                                                <a href="<?php echo $link->link_url; ?>" target="<?php echo $link->link_target; ?>" class="list-title"><?php echo $link->link_name; ?></a>
                                            </div>
                                            <div class="list-footer text-xs text-muted"><span class="h-1x"><?php echo $link->link_description ?></span></div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                       
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
                </div>
                <div class="links-sidebar col-md-3 col-lg-2 order-md-2 d-none d-md-block py-0">
                    <nav class="list-spy-nav nav" id="links-nav">
                    <?php if (is_array($link_cats) && count($link_cats) > 0): ?>
                        <?php $index = 0; ?>
					    <?php foreach ($link_cats as $link_cat): ?>
                            <?php $cat = get_term($link_cat['cat'], 'link_category'); ?>
                             <a class="nav-link js-scroll-trigger"  href="<?php echo "#list-item-".$link_cat['cat'] ?>">
                                <span class="nav-dot"></span><span class="nav-content"><span class="h-1x"><?php echo $cat->name ?></span></span>
                            </a>
                            <?php $index++; ?>
                        <?php endforeach ?>
                    <?php endif; ?>
                    </nav>
                </div>
            </div>
        </div>
    </main>
<?php
get_footer();
