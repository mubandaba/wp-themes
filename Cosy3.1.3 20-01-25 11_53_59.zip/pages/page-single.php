<?php
/*
Template Name: Single Page
*/
get_header();
?>
    <?php while ( have_posts() ) : the_post() ?>
        <main class="py-4 py-md-5">
            <div class="container">
                <div class="row justify-content-md-center">
                    <div class="col-12 col-lg-10 p-lg-5">
                        <div class="post">
                            <h1 class="post-title h2 mb-3 mb-md-4"><?php the_title() ?></h1>
                            <div class="content-style content">
                                <?php the_content() ?>
                            </div>
                        </div>
                        <?php
                            if ( comments_open() || get_comments_number() ) :
                                comments_template();
                            endif;
                        ?>
                    </div>
                </div>
            </div>
        </main>
    <?php endwhile; ?>
<?php
get_footer();
