<?php
/*
Template Name: Browsing History
*/
get_header();
?>
    <?php while ( have_posts() ) : the_post() ?>
        <main class="py-4 py-md-5">
            <div class="container">
                    <div class="list-header p-0 mb-3 mb-lg-4">
                        <div class="h4 mb-2"><?php the_title(); ?></div>
                        <p class="text-muted"><?php esc_html_e( 'Recent browsing history is only stored on your drive and keeps up to 20 records at maximum.', 'cosy19' ); ?></p>
                    </div>
                    <div class="content-error h-v-66 d-none"><?php get_template_part('template-parts/not-found-svg'); ?><p class="text-lg text-muted mt-5"><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'cosy19' ); ?></p></div>
                    <div class="row-md list-history list-grouped list-tb-padding"></div>
            </div>
        </main>
    <?php endwhile; ?>
<?php
get_footer();
