<?php
/*
Template Name: Portfolio
*/
get_header();
$top_topics = get_field('top_topics', get_the_ID());
?>
<?php while (have_posts()) : the_post(); ?>
<?php if(is_array($top_topics) && count($top_topics) > 0): ?>
<div class="bg-light py-4 py-md-5">
    <div class="container">
        <div class="row list-topic">
            <?php foreach($top_topics as $topic): ?>
                <?php $term = get_term($topic['id']); ?>
                <?php $cover = get_field('cover', $term); ?>
                <div class="col-6 col-md-3">
                    <div class="list-item list-overlay custom-hover">
                        <div class="media">
                            <a class="media-content custom-hover-img" style="background-image: url(<?php echo $cover ?>)">
                                <span class="overlay"></span>
                            </a>
                        </div>
                        <a href="<?php echo get_term_link($term->term_id) ?>" class="list-content">
                            <div class="list-body ">
                                <div class="list-title">
                                    <div class="h6 mb-2"><?php echo $term->name ?></div>
                                    <div class="list-subtitle d-none d-lg-block text-sm mb-2"><div class="h-2x"><?php echo $term->description; ?></div></div>
                                    <div class="list-meta text-xs"><?php echo $term->count; ?> <?php _e('posts', 'cosy19') // 篇文章 ?></div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php endif; ?>
<?php
    $topics = get_terms(
        array(
            'taxonomy'   => 'special',
            'hide_empty' => false,
            'exclude'    => is_array($top_topics) ? array_column($top_topics, 'id') : 0,
        )
    );
?>
<main class="py-3 py-md-5">
    <div class="container">
        <div class="row list-topic my-n3">
            <?php foreach($topics as $topic): ?>
                <?php $cover = get_field('cover', $topic) ?>
                <div class="col-6 col-md-3 py-3">
                    <div class="list-item list-overlay custom-hover ">
                        <div class="media">
                            <a class="media-content custom-hover-img" style="background-image: url(<?php echo $cover ?>)">
                                <span class="overlay"></span>
                            </a>
                        </div>
                        <a href="<?php echo get_term_link($topic->term_id) ?>" class="list-content">
                            <div class="list-body ">
                                <div class="list-title">
                                    <div class="h6 mb-2"><?php echo $topic->name ?></div>
                                    <div class="list-subtitle d-none d-lg-block text-sm mb-2"> <div class="h-2x"><?php echo $topic->description ?></div></div>
                                    <div class="list-meta text-xs"><?php echo $topic->count ?> <?php _e('posts', 'cosy19') // 篇文章 ?> </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</main>

<?php endwhile;
get_footer();?>
