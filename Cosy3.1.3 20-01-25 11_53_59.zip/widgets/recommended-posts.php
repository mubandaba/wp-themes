<?php
/*
            /$$
    /$$    /$$$$
   | $$   |_  $$    /$$$$$$$
 /$$$$$$$$  | $$   /$$_____/
|__  $$__/  | $$  |  $$$$$$
   | $$     | $$   \____  $$
   |__/    /$$$$$$ /$$$$$$$/
          |______/|_______/
================================
        Keep calm and get rich.
                    Is the best.

  	@Author: Dami
  	@Date:   2017-09-11 15:45:50
  	@Last Modified by:   Dami
  	@Last Modified time: 2018-09-25 14:38:50

*/

class Recommended_Posts extends WP_Widget {

	/**
	 * Sets up the widgets name etc
	 */
	public function __construct() {
		$widget_ops = array(
			'classname' => 'Recommended_Posts',
			'description' => 'COSY - 文章聚合',
		);
		parent::__construct( 'Recommended_Posts', 'COSY - 文章聚合', $widget_ops );
	}

	/**
	 * Outputs the content of the widget
	 *
	 * @param array $args
	 * @param array $instance
	 */
	public function widget( $args, $instance ) {

		// extract($args);
		$num   = $instance['num'];
		$who   = $instance['who'];
		$days  = $instance['days'];
		$strtotime = strtotime('-'.$days.' days');


		$title = ! empty( $instance['title'] ) ? $instance['title'] : __( 'Recommended Posts' );
		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

		echo $args['before_widget'];
		if ( $title ) {
			echo $args['before_title'] . $title . $args['after_title'];
		}

		switch ($who) {
			case 'new_posts':
				$query_args = array(
					'type'                => 'post',
					'posts_per_page'           => $num,
					'ignore_sticky_posts' => 1
				);
				break;

			case 'random_posts':
				$query_args = array(
					'type'                => 'post',
					'posts_per_page'           => $num,
					'orderby'             => 'rand',
					'ignore_sticky_posts' => 1
				);
				break;

			case 'comment_posts':
				$query_args = array(
					'type'                => 'post',
					'posts_per_page'           => $num,
					'orderby'             => 'comment_count',
					'ignore_sticky_posts' => 1,
					'date_query'          => array(
						array(
							'before' => date( 'Y-m-d H:i:s', time() ),
						),
						array(
							'after' => date( 'Y-m-d H:i:s', $strtotime ),
						),
					),
				);
				break;

			case 'related_posts':
				$queried_object_id = get_queried_object_id();
				$post_tags = get_the_tags($queried_object_id);
				$cats = get_the_category($queried_object_id);

				if ($post_tags) {
					$query_args = array(
						'posts_per_page' => $num,
						'orderby' => 'rand',
						'tax_query' => array(
							'relation' => 'OR',
							array(
								'taxonomy' => 'category',
								'field' => 'id',
								'terms' => array_column($cats, 'term_id')
							),
							array(
								'taxonomy' => 'post_tag',
								'field' => 'id',
								'terms' => array_column($post_tags, 'term_id'),
							)
						)
					);
				} else {
					$query_args = array(
						'posts_per_page' => $num,
						'orderby' => 'rand',
						'tax_query' => array(
							'taxonomy' => 'category',
							'field' => 'id',
							'terms' => array_column($cats, 'term_id')
						)
					);
				}

				break;

			case 'like_posts':
				$query_args = array(
					'type'                => 'post',
					'posts_per_page'           => $num,
					'orderby'             => 'meta_value_num',
					'meta_key'            => 'suxing_ding',
					'ignore_sticky_posts' => 1,
					'date_query'          => array(

						array(
							'before' => date( 'Y-m-d H:i:s', time() ),
						),
						array(
							'after' => date( 'Y-m-d H:i:s', $strtotime ),
						),

					),
				);
				break;

			case 'views_posts':
				$query_args = array(
					'type'                => 'post',
					'posts_per_page'           => $num,
					'orderby'             => 'meta_value_num',
					'meta_key'            => 'views',
					'ignore_sticky_posts' => 1,
					'date_query'          => array(
						array(
							'before' => date( 'Y-m-d H:i:s', time() ),
						),
						array(
							'after' => date( 'Y-m-d H:i:s', $strtotime ),
						),
					),
				);
				break;

			default:
				$query_args = null;
				break;
		}

		$queryPosts = new WP_Query($query_args);
?>
	<div class="list-grid list-grid-padding p-0 my-n2">
		<?php
			if ($queryPosts->have_posts()) :
				while ($queryPosts->have_posts()) : $queryPosts->the_post();
		?>
			<div class="list-item">
				<div class="media media-4x3 col-4">
					<a href="<?php the_permalink() ?>" target="_blank" class="media-content" style="background-image:url('<?php echo cosy19_the_thumbnail(null, array('w' => 200, 'h' => 150)) ?>')"></a>
					<?php if ('image' == get_post_format()): ?>
					<div class="media-action">
						<i class="iconfont icon-pic-s"></i>
					</div>
					<?php endif; ?>
					<?php if ('video' == get_post_format()): ?>
					<div class="media-action">
						<i class="iconfont icon-bofang"></i>
					</div>
					<?php endif; ?>
				</div>
				<div class="list-content pl-3">
					<div class="list-body">
						<a href="<?php the_permalink() ?>" target="_blank" class="list-title text-sm h-2x"><?php the_title() ?></a>
					</div>
					<div class="list-footer text-muted text-xs m-0">
						<div><?php cosy19_the_time(); ?></div>
					</div>
				</div>
			</div>
		<?php
				endwhile;
			else:
				echo '<div class="list-item"><div class="list-content"><span>暂时没有文章！</span></div></div>';
			endif;
			wp_reset_postdata();
		?>
	</div>

<?php
	echo $args['after_widget'];
}

	/**
	 * Outputs the options form on admin
	 *
	 * @param array $instance The widget options
	 */
	public function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array(
				'title' => '聚合文章',
				'num'   => 4,
				'days'  => 7,
				'who'   => 'new_posts'
			)
		);
?>
		<p>
			<label> 标题：
				<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $instance['title']; ?>" />
			</label>
		</p>
		<p>
			<label> 显示数量：
				<input class="widefat" id="<?php echo $this->get_field_id('num'); ?>" name="<?php echo $this->get_field_name('num'); ?>" type="number" step="1" value="<?php echo $instance['num']; ?>" />
			</label>
		</p>
		<p>
			<label> 显示类型：
				<select class="widefat mi_select_handle" id="<?php echo $this->get_field_id('who'); ?>" name="<?php echo $this->get_field_name('who'); ?>">
					<option <?php mi_selected( $instance['who'], 'new_posts' ); ?> value="new_posts">最新文章</option>
					<option <?php mi_selected( $instance['who'], 'related_posts' ); ?> value="related_posts">相关文章</option>
					<option <?php mi_selected( $instance['who'], 'random_posts' ); ?> value="random_posts">随机文章</option>
					<option <?php mi_selected( $instance['who'], 'comment_posts' ); ?> value="comment_posts">评论最多</option>
					<option <?php mi_selected( $instance['who'], 'like_posts' ); ?> value="like_posts">点赞最多</option>
					<option <?php mi_selected( $instance['who'], 'views_posts' ); ?> value="views_posts">浏览最多</option>
				</select>
			</label>
		</p>
		<?php if ($instance['who'] == 'new_posts' || $instance['who'] == 'random_posts' ||  $instance['who'] == 'related_posts'){ ?>
		<p id="<?php echo $this->get_field_id('who'); ?>-box" style="display: none">
		<?php } else { ?>
		<p id="<?php echo $this->get_field_id('who'); ?>-box">
		<?php } ?>
			<label>
				显示
				<input class="tiny-text" id="<?php echo $this->get_field_id('days'); ?>" name="<?php echo $this->get_field_name('days'); ?>" type="number" step="1" value="<?php echo $instance['days']; ?>" />
				<span>
				<?php
					switch ($instance['who']) {
						case 'comment_posts':
							echo '天内评论最多的文章';
							break;

						case 'like_posts':
							echo '天内点赞最多的文章';
							break;
						case 'views_posts':
							echo '天内浏览最多的文章';
							break;
						default:
							break;
					}
				?>
				</span>
			</label>
		</p>
<?php
	}
}

function reg_recommended_posts() {
	register_widget("Recommended_Posts");
}

add_action( 'widgets_init', 'reg_recommended_posts');

function mi_selected( $t, $i ){
	if( $t == $i ){
		echo 'selected';
	}
}

/**
 * 加载一段JS
 */
function mi_select_handle() {
?>
	<script>

		jQuery( document ).ready( function() {
			if( jQuery('.mi_select_handle').length > 0 ){
				jQuery('.mi_select_handle').each(function(index, el) {
					mi_select_handle( jQuery(this).attr('id') );
				});
			}

		});

		jQuery(document).on('change', '.mi_select_handle', function(event) {
			event.preventDefault();
			mi_select_handle( jQuery(this).attr('id') );
		});

		function mi_select_handle( id ){
			var selected = jQuery('#'+id+' option:selected');
			if( selected.val() == 'comment_posts' || selected.val() == 'like_posts' || selected.val() == 'views_posts' ){
				jQuery('#'+id+'-box label span').text( ' 天内' + selected.text() + '的文章' );
		 		jQuery('#'+id+'-box').show();
		 	}else{
		 		jQuery('#'+id+'-box').hide();
		 	}
		}
	</script>
<?php
}
add_action( 'admin_footer', 'mi_select_handle' );

