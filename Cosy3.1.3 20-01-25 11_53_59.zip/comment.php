<li id="comment-<?php comment_ID() ?>" <?php comment_class(); ?>>
    <article id="div-comment-<?php comment_ID() ?>" class="d-flex flex-fill comment-body mt-4">
        <div class="d-flex flex-shrink-0 mr-3 comment-avatar-author vcard">
            <?php echo get_avatar( $comment, 50 ); ?>
        </div><!-- .comment-author -->
        <div class="flex-fill flex-column comment-text">
            <div class="d-flex align-items-center comment-info mb-2">
                <div class="comment-author text-sm">
                	<?php comment_author_link() ?>
                	<?php cosy19_comment_official( $comment->user_id ); ?>
                </div>
            </div>
            <div class="comment-content d-inline-block text-sm bg-light px-2 py-1 ">
                <?php
                	comment_text();
                ?>
                <?php if ( $comment->comment_approved == '0' ) : ?>
                <p class="tip-comment-check"><?php echo esc_html_e( 'Your comment is awaiting moderation.', 'cosy19' ) ?></p>
	            <?php endif; ?>
            </div><!-- .comment-content -->
            <div class="text-xs text-muted pt-2">
                <time class="comment-date"><?php echo cosy19_timeago(get_comment_time('U', true) ) ?></time>
               <a class="comment-reply-link" onclick="return addComment.moveForm( 'comment-<?php comment_ID() ?>','<?php comment_ID() ?>', 'respond','<?php echo $comment->comment_post_ID; ?>' ) " href="?replytocom=<?php comment_ID() ?>#respond" class="text-secondary comment-reply-link" rel="nofollow"><i class="fal fa-repeat"></i> <?php esc_html_e( 'Reply', 'cosy19' ) ?></a>
            </div>
        </div><!-- .comment-text -->
    </article><!-- .comment-body -->