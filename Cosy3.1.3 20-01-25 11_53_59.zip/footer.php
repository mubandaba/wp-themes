<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @package Cosy19
 */
$current_user = wp_get_current_user();
$mobile_navheader_bg = get_field('mobile_navheader_bg', 'option');
$footer_layout = get_field('footer_layout', 'option')['style'] ?: 'footer3';
?>
<?php get_template_part("template-parts/footer/$footer_layout") ?>
<aside class="sidebar-collapse">
	<div class="sidebar-mobile bg-light">
		<?php if (get_option('users_can_register')): ?>
		<div class="sidebar-mobile-header bg-white">
			<div class="bg-effect bg-cover <?php if (empty($mobile_navheader_bg)): ?>bg-dark<?php endif; ?>  nc-no-lazy" <?php if (!empty($mobile_navheader_bg)): ?> style="background-image: url(<?php echo esc_url($mobile_navheader_bg) ?>)"<?php endif; ?> >
				<span class="overlay"></span>
			</div>
			<div class="sidebar-mobile-action">
				<button type="button" class="link-action" id="sidebar-mobile-close"><i class="iconfont icon-iconfontradiobox"></i></button>
			</div>
			<div class="sidebar-mobile-user">
			<?php if ($current_user->ID == 0): ?>
				<div class="d-flex align-items-center">
					<a href="<?php echo esc_url( wp_login_url() ); ?>">
						<span class="w-56 avatar bg-light">
		                    <i class="text-xl iconfont icon-person-outline"></i>
		                </span>
					</a>
		    		<div class="mx-3">
		    			<a class="sign-action" href="<?php echo esc_url( wp_login_url() ); ?>">未登录</a>
		    			<div class="text-light text-xs">立即登录 / 注册，享受更多福利</div>
		    		</div>
	    		</div>
			<?php else: ?>
				<div class="d-flex align-items-center">
					<a href="<?php echo get_edit_profile_url();?>" class="avatar w-56">
						<?php echo get_avatar( $current_user->data->ID, 56, '', '', array('class' => '') ); ?>
					</a>
		    		<div class="d-flex flex-column flex-fill mx-3">
		    			<a class="sign-action" href="<?php echo get_edit_profile_url();?>"><?php echo $current_user->display_name; ?></a>
		    			<div class="text-light text-xs">
							<?php echo get_translated_role_name($current_user->roles[0]) ?>
						</div>
		    		</div>
	    		</div>
			<?php endif; ?>
	    		<div class="flex-fill"></div>
	    		<div class="d-flex align-items-center">
	    			<a href="" class="more-action text-light text-md"><i class="iconfont icon-right1"></i></a>
	    		</div>
			</div>
		</div>
		<?php else: ?>
			<div class="sidebar-mobile-action bg-white">
				<button type="button" class="link-action text-muted" id="sidebar-mobile-close"><i class="iconfont icon-iconfontradiobox"></i></button>
			</div>
		<?php endif; ?>
		<div class="sidebar-mobile-tab-menu">
	        <ul id="mobile-tab-menu-id" class="mobile-tab-menu">
	            <?php
	                if ( function_exists( 'wp_nav_menu' ) && has_nav_menu('menu-2') ) {
	                 wp_nav_menu( array( 'container' => false, 'items_wrap' => '%3$s', 'theme_location' => 'menu-2', 'depth'=>2 ) );
	              } else {
	                _e('<li><a href="/wp-admin/nav-menus.php">Please set up your first menu at [Admin -> Appearance -> Menus]</a></li>', 'cosy19');
	            }
	            ?>
	        </ul>
		</div>
	</div>
</aside>
<?php get_template_part('template-parts/popup/search-popup') ?>
<?php get_template_part('template-parts/popup/author-popup') ?>
<a id="nice-back-to-top" href="#">
	<span class="icon-stack">
        <i class="text-xs iconfont icon-up"></i>
        <span class="back-to-top-text">Top</span>
    </span>
</a>
<?php wp_footer(); ?>
</body>
</html>