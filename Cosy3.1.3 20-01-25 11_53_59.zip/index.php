<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @package Cosy19
 */

// AD
$index_list_ad = get_field('index_list_ad', 'option');

// Topic Card
$index_insert_topic_card = get_field('index_insert_topic_card', 'option');
$index_insert_topics = get_field('index_insert_topics', 'option');

$ajax_loading = get_field('index_ajax_loading', 'option');

$index = 0;

get_header();
?>
	<?php get_template_part('template-parts/list-magazine'); ?>
	<main class="py-3 py-md-5">
        <div class="container">
			<?php get_template_part('template-parts/home-notice'); ?>
	        <?php get_template_part('template-parts/list-pushes'); ?>
			<?php get_template_part('template-parts/list-ajax-nav'); ?>
			<?php if ( have_posts() ) :?>
				<section class="list-home row-md list-grouped list-tb-padding">
					<?php while ( have_posts() ) : the_post(); ?>
						<?php $index++ ?>

						<?php if ($index_insert_topic_card && in_array($index, array_column($index_insert_topics, 'position'))): ?>
							<?php get_template_part_with_vars('template-parts/post-cards/card-topic', array('index_insert_topics' => $index_insert_topics, 'index' => $index)) ?>
						<?php endif;?>

						<?php if ($index_list_ad['position'] == $index): ?>
							<?php get_template_part('template-parts/post-cards/card-ad') ?>
						<?php endif;?>
						<?php get_template_part_with_vars("template-parts/post-cards/card-small", array('type' => '')); ?>
					<?php endwhile; ?>
				</section>
				<?php
					get_template_part_with_vars('template-parts/post-navigation', array(
						'ajax_loading' => $ajax_loading,
						'page' => 'home',
						'query' => '',
						'style' => 'small',
						'append' => 'list-home'
					));
				?>
				<?php get_template_part('template-parts/ad/index-ad'); ?>
			<?php endif; ?>
		</div>
	</main>

	<?php get_template_part('template-parts/recommended/recommended-sections'); ?>

<?php
get_footer();
