<?php
/**
 * The sidebar containing the main widget area

 *
 * @package Cosy19
 */
?>

<aside id="secondary" class="widget-area pt-5 pt-lg-0">
	<?php
		if ( is_home() || !is_active_sidebar( 'sidebar-archive' ) && !is_active_sidebar( 'sidebar-page' ) && !is_active_sidebar( 'sidebar-single' )) {
			dynamic_sidebar( 'main-sidebar' );
		}
		if (is_category() && is_archive()) {
			dynamic_sidebar( 'sidebar-archive' );
		}
		if (is_page()) {
			dynamic_sidebar( 'sidebar-page' );
		}
		if (is_single()) {
			dynamic_sidebar( 'sidebar-single' );
		}
	?>
</aside><!-- #secondary -->
