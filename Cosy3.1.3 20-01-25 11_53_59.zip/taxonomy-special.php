<?php
/**
 * The template for displaying archive pages
 *
 * @package Cosy19
 */

global $wp_query;

$query = $wp_query->queried_object->name;
$tax = get_queried_object();
$style = empty($style) ? 'small' : $style;
$ajax_loading = get_field('archive_ajax_loading', 'option');
if ($style == 'plain') $grid_class = 'list-grid list-grid-padding list-bordered list-tb-padding my-n4';
if ($style == 'medium') $grid_class = 'row-lg list-archive list-grouped list-tb-padding';
if ($style == 'small') $grid_class = 'row-md list-archive list-grouped list-tb-padding';

get_header();
?>
	<main class="py-3 py-md-5">
		<div class="container">
			<div class="card card-special-cover bg-dark mb-3 mb-md-5">
		    	<div class="bg-effect bg-dark bg-special"></div>
		    	<div class="bg-effect bg-cover" data-img="<?php the_field('cover',  'special_'.$tax->term_id) ?>"></div>
	          	<div class="bg-dark-overlay d-flex flex-fill">
	          		<div class="position-relative text-center px-4 py-5 m-auto">
		          		<div class="media d-inline-block w-96">
	      					<div class="media-content media-special" style="background-image: url(<?php the_field('cover',  'special_'.$tax->term_id) ?>)"></div>
	      				</div>
	      				<div class="pt-3">
		      				<div class="h5 text-white"><?php echo $tax->name ?></div>
							<div class="text-sm text-white h-2x mt-2 mt-md-2"><?php echo $tax->description ?></div>
		                    <div class="text-xs text-light mt-2 mt-md-3"><span class="px-2">文章 <?php echo $tax->count ?></span><span class="px-2">阅读 <?php cosy19_the_special_view_count($tax->term_id) ?></span></div>
	                    </div>
                    </div>
		        </div>
		        <div class="arrow-next d-md-none"><i class="iconfont icon-arrowdown"></i></div>
			</div>
			<?php if ($style == 'plain'): ?>
				<div class="row justify-content-md-center">
					<div class="col-lg-9">
			<?php endif; ?>
				<?php if ( have_posts() ) : ?>
				<div class="<?php echo $grid_class ?>">
					<?php while ( have_posts() ) : the_post(); ?>
						<?php get_template_part_with_vars("template-parts/post-cards/card-$style", array('type' => '')); ?>
					<?php endwhile; ?>
				</div>
				<?php
					get_template_part_with_vars('template-parts/post-navigation', array(
						'ajax_loading' => $ajax_loading,
						'page' => 'tax',
						'query' => $query,
						'style' => $style,
						'append' => 'list-archive'
					));
				?>
				<?php else : ?>
					<div class="content-error h-v-66">
						<?php get_template_part('template-parts/not-found-svg'); ?>
			            <p class="text-lg text-muted mt-5"><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'cosy19' ); ?></p>
			        </div>
				<?php endif; ?>
				<?php get_template_part('template-parts/ad/tax-ad'); ?>
			<?php if ($style == 'plain'): ?>
					</div>
				</div>
			<?php endif; ?>
		</div>
	</main>

<?php
get_footer();