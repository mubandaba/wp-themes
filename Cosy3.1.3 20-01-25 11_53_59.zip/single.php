<?php
/**
 * The template for displaying all single posts#single-post
 *
 * @package Cosy19
 */

get_header();
?>
    <?php while ( have_posts() ) : the_post() ?>
        <?php get_template_part('template-parts/content/content', get_post_format()) ?>
        <?php get_template_part('template-parts/bigger-cover') ?>
        <?php get_template_part('template-parts/related-posts') ?>
    <?php endwhile; ?>
<?php
get_footer();
