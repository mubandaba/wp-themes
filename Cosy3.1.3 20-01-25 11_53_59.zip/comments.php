<?php
/**
 * The template for displaying comments
 *
 * This is the template that displays the area of the page that contains both the current comments
 * and the comment form.

 *
 * @package Suxing2019
 */

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() ) {
	return;
}
if( isset($_POST['action']) && $_POST['action'] == 'ajax_load_comments' ){
    wp_list_comments('avatar_size=48&type=comment&callback=cosy19_comment&end-callback=cosy19_end_comment&max_depth=2');
    die();
}
?>
	<div id="comments" class="comments mt-5">
		<div class="h5 mb-4">
			<?php
				$cosy19_comment_count = get_comments_number();
				echo esc_html__( 'Comments', 'cosy19' );
				echo ' <small class="font-theme text-sm">('.number_format_i18n( $cosy19_comment_count ).')</small>';
			?>
		</div>
	<?php if ( comments_open() ) : ?>
		<div id="respond" class="comment-respond">
			<?php if( get_option('comment_registration') && !$user_ID ) : ?>
				<div class="logged-in-as rounded bg-light text-center p-4 p-md-5 ">
					<p class="mb-3"><?php _e( 'Please login to leave a comment.', 'cosy19' ) ?></p>
					<a class="btn btn-secondary btn-sm" href="<?php echo esc_url( wp_login_url() ); ?>"><?php _e( 'Login now.', 'cosy19' ) ?></a>
				</div>
			<?php else : ?>
				<form method="post" action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" id="commentform" class="comment-form">
					<div class="d-flex w-100">
						<div class="d-flex flex-shrink-0 mr-3 comment-avatar-author">
							<?php
								if ( $user_ID ) {
									echo get_avatar( $user_ID, 48 );
								}else if ( $comment_author_email != '' ){
									echo get_avatar( $comment_author_email, 48 );
								}else{
									echo '<img src="'.get_field('default_comment_avatar', 'option').'" class="avatar avatar-48 photo avatar-default" height="48" width="48">';
								}
							?>
						</div>
						<div class="flex-fill comment-from-author">
							<?php if ( $user_ID ) : ?>
								<div class="comment-author-info text-sm mb-2">
									<div class="logged-in-as text-sm"><?php echo $user_identity; ?>  <a class="text-muted px-2" href="<?php echo wp_logout_url(get_permalink()); ?>" title="<?php _e( 'Logout', 'cosy19' ) ?>"><i class="text-md iconfont icon-zhuxiaodenglu"></i></a></div>
								</div>
							<?php elseif ( '' != $comment_author ): ?>
								<div class="comment-author-infotext-sm mb-2">
									<div class="logged-in-as text-sm"><?php printf(__('%s'), $comment_author); ?>
										<a class="text-muted px-2" href="javascript:toggleCommentAuthorInfo();" id="toggle-comment-author-info"><i class="text-md iconfont icon-bianji"></i></a>
									</div>
								</div>
							<?php endif; ?>
							<?php if ( ! $user_ID ): ?>
								<div class="comment-form-info">
									<div class="row-sm my-n2 pb-3">
										<div class="col-12 col-lg-4 py-2">
											<div class="form-group comment-form-author m-0">
												<input class="form-control text-sm" id="author" placeholder="<?php _e( 'Nickname', 'cosy19' ) ?>" name="author" type="text" value="<?php echo $comment_author; ?>" required="required">
											</div>
										</div>
										<div class="col-12 col-lg-4 py-2">
											<div class="form-group comment-form-email m-0">
												<input id="email" class="form-control text-sm" name="email" placeholder="<?php _e( 'Email', 'cosy19' ) ?>" type="email" value="<?php echo $comment_author_email; ?>" required="required">
											</div>
										</div>
										<div class="col py-2">
											<div class="form-group comment-form-url m-0">
												<input class="form-control text-sm" placeholder="<?php _e( 'Website', 'cosy19' ) ?>" id="url" name="url" type="url" value="<?php echo $comment_author_url; ?>">
											</div>
										</div>
									</div>
								</div>
							<?php endif; ?>
							<div class="comment-form-text">
								<div class="form-group comment-textarea">
									<textarea id="comment" name="comment" class="form-control form-control-sm" rows="3"></textarea>
								</div>
								<div class="form-submit text-right">
									<a rel="nofollow" id="cancel-comment-reply-link" style="display: none" class="btn btn-light text-sm mr-2" href="javascript:;"><?php _e( 'Back', 'cosy19' ) ?></a>
									<input name="submit" type="submit" id="submit" class="btn btn-primary text-sm" value="<?php _e( 'Submit', 'cosy19' ) ?>">
									<?php comment_id_fields(); ?>
								</div>
							</div>
						</div>
					</div>
				</form>
			<?php endif; ?>
		</div>
		<ul class="comment-list">
			<?php
				wp_list_comments('type=comment&callback=cosy19_comment&end-callback=cosy19_end_comment&max_depth=2');
			?>
		</ul><!-- .comment-list -->
		<?php if (get_comment_pages_count() > 1) { ?>
			<div class="text-center pt-3 pt-md-4">
				<button
					id="comments-next-button"
					<?php if (is_page()): ?>
						data-type="page"
					<?php endif; ?>
					<?php if (is_single()): ?>
						data-type="post"
					<?php endif; ?>
					data-query="<?php the_ID(); ?>"
					data-action="ajax_load_comments"
					data-paged="<?php echo get_next_page_number(); ?>"
					data-commentcount="<?php echo get_comment_pages_count(); ?>"
					data-commentspage="<?php echo get_option( 'default_comments_page' ); ?>"
					data-append="comment-list"
					class="btn btn-light text-sm"><?php esc_html_e( 'Load more...', 'cosy19' ); ?></button>
			</div>
		<?php } ?>
	<?php else: ?>
		<p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'cosy19' ); ?></p>
	<?php endif; ?>
	</div>
<!-- #comments -->
