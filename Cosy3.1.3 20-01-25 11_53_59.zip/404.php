<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package Cosy19
 */

get_header();
?>
<main class="py-3 py-md-5">
    <div class="container">
    	<div class="content-error h-v-66">
    		<?php get_template_part('template-parts/404-svg'); ?>
            <h1 class="display-1 font-theme">404</h1>
            <h4 class="py-4"><?php esc_html_e( 'Oops! That page can&rsquo;t be found.', 'cosy19' ); ?></h4>
            <p class="text-muted"><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'cosy19' ); ?></p>
        </div>
    </div>
</main>
<?php
get_footer();
