<?php
global $post;
get_header();
?>
    <?php while ( have_posts() ) : the_post() ?>
        <main class="py-4 py-md-5">
            <div class="container">
                <div class="row justify-content-md-center">
                    <div class="col-12 col-lg-10 p-lg-5">
                        <div class="post">
                            <h1 class="post-title h2 mb-3 mb-md-4"><?php the_title() ?></h1>
                            <div class="content-style content">
                                <?php if ( wp_attachment_is_image( $post->id ) ) : $att_image = wp_get_attachment_image_src( $post->id, "full"); ?>
                                    <p class="attachment"><a href="<?php echo wp_get_attachment_url($post->id); ?>" title="<?php the_title(); ?>" rel="attachment"><img src="<?php echo $att_image[0];?>" width="<?php echo $att_image[1];?>" height="<?php echo $att_image[2];?>"  class="attachment-medium" alt="<?php $post->post_excerpt; ?>" /></a>
                                    </p>
                                <?php else : ?>
                                    <a href="<?php echo wp_get_attachment_url($post->ID) ?>" title="<?php echo wp_specialchars( get_the_title($post->ID), 1 ) ?>" rel="attachment"><?php echo basename($post->guid) ?></a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php
                            if ( comments_open() || get_comments_number() ) :
                                comments_template();
                            endif;
                        ?>
                    </div>
                </div>
            </div>
        </main>
    <?php endwhile; ?>
<?php
get_footer();
