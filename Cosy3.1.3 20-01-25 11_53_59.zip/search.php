<?php
/**
 * The template for displaying search results pages#search-result
 *
 * @package Cosy19
 */
$tpage = 'search';
$query = $wp_query->query['s'];
$style = get_field('search_style', 'option');

$style = empty($style) ? 'small' : $style;
$ajax_loading = get_field('archive_ajax_loading', 'option');
if ($style == 'plain') $grid_class = 'list-archive list-grid list-grid-padding list-bordered list-tb-padding my-n4';
if ($style == 'medium') $grid_class = 'row-lg list-archive list-grouped list-tb-padding';
if ($style == 'small') $grid_class = 'row-md list-archive list-grouped list-tb-padding';

get_header();
?>
	<main class="py-4 py-md-5">
		<div class="container">
			<?php if ($style == 'plain'): ?>
			<div class="row justify-content-md-center">
            	<div class="col-md-9">
			<?php endif; ?>
					<div class="list-header p-0 mb-3">
						<div class="h4">
							<?php _e( 'Search: ', 'cosy19' ); ?><span><?php echo get_search_query(); ?></span>
						</div>
					</div>
					<?php if ( have_posts() ) : ?>
					<div class="search-list <?php echo $grid_class ?>">
						<?php while ( have_posts() ) : the_post(); ?>
							<?php get_template_part_with_vars("template-parts/post-cards/card-$style", array('type' => '')); ?>
						<?php endwhile; ?>
					</div>
					<?php
						get_template_part_with_vars('template-parts/post-navigation', array(
							'ajax_loading' => $ajax_loading,
							'page' => $tpage,
							'query' => $query,
							'style' => $style,
							'append' => 'search-list'
						));
					?>
					<?php else : ?>
					<div class="content-error h-v-66">
						<?php get_template_part('template-parts/not-found-svg'); ?>
			            <p class="text-lg text-muted mt-5"><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'cosy19' ); ?></p>
			        </div>
					<?php endif; ?>
					<?php get_template_part('template-parts/ad/tax-ad'); ?>
			<?php if ($style == 'plain'): ?>
				</div>
			</div>
			<?php endif; ?>
		</div>
	</main>

<?php
get_footer();
