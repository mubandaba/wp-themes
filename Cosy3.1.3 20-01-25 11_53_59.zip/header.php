<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">

 *
 * @package Cosy19
 */
$index_menu_style = get_field('index_menu_style', 'option');
$current_user = wp_get_current_user();
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" />

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<header class="header">
		<nav class="navbar navbar-expand-lg <?php if (is_home() && ($index_menu_style == 'immersed' || $index_menu_style == 'dark' || $index_menu_style == 'image')) : ?>fixed-top<?php endif; ?> ">
			<div class="container">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" class="navbar-brand m-0 order-1 order-lg-1">
					<img src="<?php echo cosy19_get_logo() ?>" class="nc-no-lazy" alt="<?php bloginfo( 'name' ); ?>">
				</a>
				<!-- / brand -->
				<div class="collapse navbar-collapse order-lg-2">
					<ul class="navbar-nav main-menu mx-auto px-4">
						<?php
							if ( function_exists( 'wp_nav_menu' ) && has_nav_menu('menu-1') ) {
								wp_nav_menu( array( 'container' => false, 'items_wrap' => '%3$s', 'theme_location' => 'menu-1' ) );
							} else {
								_e('<li><a href="/wp-admin/nav-menus.php">Please set up your first menu at [Admin -> Appearance -> Menus]</a></li>', 'cosy19');
							}
						?>
					</ul>
				</div>
				<ul class="nav nav-pills nav-submenu align-items-center order-2 order-lg-3">
					<li class="nav-item">
						<a href="#" class="nav-link search-popup"><i class="text-lg iconfont icon-sousuo"></i></a>
					</li>
					<?php cosy19_the_view_history_link() ?>
					<li class="nav-item d-lg-none">
						<a href="#" id="sidebar-mobile-trigger" class="nav-link pr-0"><i class="text-lg iconfont icon-menu-outline"></i></a>
					</li>
					<?php if (get_option('users_can_register')): ?>
						<li class="nav-item d-none d-lg-inline-block">
							<a href="<?php echo admin_url('post-new.php') ?>" class="nav-link"><i class="text-lg iconfont icon-bianji"></i></a>
						</li>
						<?php if (is_user_logged_in()): ?>
						<li class="nav-item">
							<a href="<?php echo get_edit_profile_url();?>" class="nav-link pr-0">
								<span class="avatar w-32">
									<?php echo get_avatar( $current_user->data->ID, 32, '', '', array('class' => '') ); ?>
						        </span>
							</a>
						</li>
						<?php else: ?>
						<li class="nav-item">
							<a class="nav-link sign-link active" href="<?php echo wp_login_url() ?>"><?php _e('Sign in', 'cosy19') ?></a>
						</li>
						<?php endif; ?>
					<?php endif; ?>
				</ul>
				<form role="search" method="get" class="navbar-search-wrap" action="<?php echo home_url( '/' ) ?>" style="display: none;"><input type="search" class="form-control navbar-search-input" placeholder="<?php _e('Type Something...', 'cosy19') ?>" name="s"> <i class="iconfont icon-quxiao" id="navbar-search-close"></i></form>
				<!-- brand -->
				<div class="navbar-scroll  order-3 d-lg-none">
					
		            <ul class="navbar-nav flex-row">
		                  <?php
		                    if ( function_exists( 'wp_nav_menu' ) && has_nav_menu('menu-3') ) {
		                        wp_nav_menu( array( 'container' => false, 'items_wrap' => '%3$s', 'theme_location' => 'menu-3', 'depth' => 1 ) );
		                      } else {
														_e('<li><a href="/wp-admin/nav-menus.php">Please set up your first menu at [Admin -> Appearance -> Menus]</a></li>', 'cosy19');
		                    }
		                    ?>
		            </ul>
		          
		        </div>
			</div>
			
		</nav>
		
	</header>