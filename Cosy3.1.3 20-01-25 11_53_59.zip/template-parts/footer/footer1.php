<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @package Cosy19
 */
$footer_bottom = get_field('footer_bottom', 'option');
$social_connect = get_field('social_connect', 'option');
$footer_text = $footer_bottom['footer_text'];
$miitbeian = $footer_bottom['miitbeian'];
$miitbeian_button = $footer_bottom['miitbeian_button'];
$gabeian_button = $footer_bottom['gabeian_button'];
$gabeian = $footer_bottom['gabeian'];
$gabeian_link = $footer_bottom['gabeian_link'];
?>
<footer class="footer bg-white border-top border-light text-center py-4 py-md-5">
    <div class="container">
        <div class="footer-social text-md">
            <?php echo $social_connect['weibo'] ? '<a href="'.$social_connect['weibo'].'" target="_blank" class="btn btn-light btn-icon btn-md btn-rounded mx-md-1">
            <span><i class="iconfont icon-weibo"></i></span></a>' : ''; ?>
            <?php echo $social_connect['weixin']['title'] ? '<a href="javascript:" 
            class="single-popup btn btn-light btn-icon btn-md btn-rounded mx-md-1" data-img="'.$social_connect['weixin']['img'].'" data-title="'.$social_connect['weixin']['title'].'" data-desc="'.$social_connect['weixin']['desc'].'"><span><i class="iconfont icon-weixin"></i></span></a>' : ''; ?>
            <?php echo $social_connect['qq'] ? '<a href="'.$social_connect['qq'].'" target="_blank" class="btn btn-light btn-icon btn-md btn-rounded mx-md-1"><span><i class="iconfont icon-qq"></i></span></a>' : ''; ?>
            <?php echo $social_connect['facebook'] ? '<a href="'.$social_connect['facebook'].'" target="_blank" class="btn btn-light btn-icon btn-md btn-rounded mx-md-1"><span><i class="iconfont icon-facebook"></i></span></a>' : ''; ?>
            <?php echo $social_connect['twitter'] ? '<a href="'.$social_connect['twitter'].'" target="_blank" class="btn btn-light btn-icon btn-md btn-rounded mx-md-1"><span><i class="iconfont icon-twitter"></i></span></a>' : ''; ?>
            <?php echo $social_connect['linkedin'] ? '<a href="'.$social_connect['linkedin'].'" target="_blank" class="btn btn-light btn-icon btn-md btn-rounded mx-md-1"><span><i class="iconfont icon-linkedin"></i></span></a>' : ''; ?>
        </div>
        <div class="footer-copyright text-muted mt-4">
            <?php
                if ( is_home() && $gabeian_button) : $footer_text .= ' <a href="'.$gabeian_link.'" target="_blank" rel="nofollow" class="d-none d-lg-inline-block"><i class="icon icon-beian"></i>'.$gabeian.'</a> '; endif;
                if ( is_home() && $miitbeian_button) : $footer_text .= ' <a href="http://beian.miit.gov.cn/" target="_blank" rel="nofollow" class="d-none d-lg-inline-block">'.$miitbeian.'</a>'; endif;
                echo 'Copyright © '.cosy19_get_footer_year().' <a href="'.get_bloginfo('url').'" title="'.get_bloginfo('name').'" rel="home">'.get_bloginfo('name').'</a>. Designed by <a href="https://www.nicetheme.cn" title="nicetheme奈思主题-资深的原创WordPress主题开发团队" target="_blank">nicetheme</a>. '.$footer_text;
            ?>
        </div>
    </div>
</footer>
