<?php

$post_tags = get_the_tags() ? get_the_tags() : array();
$exclude_id = get_the_ID();
$cats = get_the_category();

$tagArgs = array(
    'type'                => 'post',
    'tag__in'             => array_column($post_tags, 'term_id'),
    'post__not_in'        => array(get_the_ID()),
    'posts_per_page'      => 4,
    'ignore_sticky_posts' => 1,
);
$recentPosts = new WP_Query($tagArgs);

if ($recentPosts->found_posts < 4) {
    $catArgs = array(
        'type'                => 'post',
        'category__in'        => array_column($cats, 'term_id'),
        'post__not_in'        => array_merge(array(get_the_ID()), array_column($recentPosts->posts, 'ID')),
        'posts_per_page'      => 4 - $recentPosts->found_posts,
        'ignore_sticky_posts' => 1
    );
    $catRecentPosts = new WP_Query($catArgs);
    $ids = array_merge(array_column($recentPosts->posts, 'ID'), array_column($catRecentPosts->posts, 'ID'));
    $recentPosts = new WP_Query(
        array(
            'post__in' => $ids,
            'posts_per_page' => 4
        )
    );
}

// 随机判断
if ($recentPosts->found_posts < 4) {
    $randArgs = array(
        'type'                => 'post',
        'orderby'             => 'rand',
        'post__not_in'        => array_merge(array(get_the_ID()), array_column($recentPosts->posts, 'ID')),
        'posts_per_page'      => 4 - $recentPosts->found_posts,
        'ignore_sticky_posts' => 1
    );
    $morePosts = new WP_Query($randArgs);
    $ids = array_merge(array_column($recentPosts->posts, 'ID'), array_column($morePosts->posts, 'ID'));
    $recentPosts = new WP_Query(
        array(
            'post__in' => $ids,
            'posts_per_page' => 4
        )
    );
}
?>
<?php $index = 5; ?>
<?php if ($recentPosts->have_posts()): ?>
<section class="list-related bg-light py-4 py-md-5">
    <div class="container">
        <div class="list-header h4 mb-3 mb-md-4"><?php _e('Related Posts', 'cosy19') ?></div>
        <div class="list-grouped list-scroll-x">
            <div class="row-md">
                <?php while ($recentPosts->have_posts() && --$index) : ?>
                    <?php $recentPosts->the_post(); ?>
                    <div class="col-6 col-md-3">
                        <div class="list-item list-nice-overlay custom-hover">
                            <div class="media media-3x2">
                                <a href="<?php the_permalink() ?>" class="media-content custom-hover-img" style="background-image:url('<?php cosy19_the_thumbnail(); ?>')"><span class="overlay"></span></a>
                                <?php if ('image' == get_post_format()): ?>
                                <div class="media-action">
                                    <i class="iconfont icon-pic-s"></i>
                                </div>
                                <?php endif; ?>
                                <?php if ('video' == get_post_format()): ?>
                                <div class="media-action">
                                    <i class="iconfont icon-bofang"></i>
                                </div>
                                <?php endif; ?>
                                <?php if ('audio' == get_post_format()): ?>
                                <div class="media-action">
                                    <i class="iconfont icon-yinle"></i>
                                </div>
                                <?php endif; ?>
                            </div>
                            <div class="list-content">
                                <div class="list-body">
                                    <a href="<?php the_permalink() ?>" class="list-title h-2x"><?php the_title() ?></a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>
<?php wp_reset_postdata(); ?>