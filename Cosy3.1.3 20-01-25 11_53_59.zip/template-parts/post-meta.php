<?php 
    $post_copyright = get_field('post_copyright', get_the_ID());
    $category = get_the_category();
    $meta_layout = get_field('meta_layout', 'option');
?>
<div class="post-meta d-flex align-items-center flex-row text-sm text-muted my-4">
    <div class="flex-fill d-flex align-items-center">
        <div class="author-avatar">
            <a href="#" class="author-popup">
                <?php echo get_avatar( $post->post_author, 40, '', '', array('class' => 'w-40') ); ?>
            </a>
        </div>
        <div class="author-name d-flex flex-wrap flex-column mx-2 mx-md-3">
            <div class="text-md"><a href="#" class="author-popup"><?php the_author(); ?></a></div>
            <div class="text-xs text-muted">
                <time class="date mr-1"><?php cosy19_the_time(); ?></time><i class="d-none d-md-inline-block"><?php _e('Posted on', 'cosy19') ?></i> <a class="text-secondary" href="<?php echo get_category_link($category[0]->term_id ); ?>" rel="category tag" target="_blank"><?php echo $category[0]->cat_name; ?></a><?php edit_post_link('[编辑]', '', ''); ?>
            </div>
        </div>
    </div>
    <div class="post-data text-nowrap align-items-center">
        <?php if ($meta_layout['view'] === '1'): ?>
        <span class="d-none d-md-inline-block">
            <i class="text-lg iconfont icon-view"></i>
            <small><?php cosy19_post_views('',''); ?></small>
        </span>
        <?php endif; ?>
        <?php if (comments_open()): ?>
        <span class="d-none d-md-inline-block">
            <a href="#comments">
                <i class="text-lg iconfont icon-duanxin"></i>
                <small><?php echo $post->comment_count; ?></small>
            </a>
        </span>
        <?php endif; ?>
        <?php if ($meta_layout['like'] === '1'): ?>
        <span class="d-inline-block">
            <?php $is_liked = isset($_COOKIE['suxing_ding_'.$post->ID]); ?>
            <a class="<?php if ($is_liked) echo 'current'; ?> post-like"
                href="javascript:;"
                data-action="<?php echo $is_liked ? 'unlike' : 'like' ?>" data-id="<?php the_ID(); ?>"
                >
                <i class="text-lg iconfont icon-shoucang"></i>
                <small class="like-count"><?php echo cosy19_get_hearts(get_the_ID()) ?></small>
            </a>
        </span>
        <?php endif; ?>
    </div>
</div>