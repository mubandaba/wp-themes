<?php

/*
            /$$
    /$$    /$$$$
   | $$   |_  $$    /$$$$$$$
 /$$$$$$$$  | $$   /$$_____/
|__  $$__/  | $$  |  $$$$$$
   | $$     | $$   \____  $$
   |__/    /$$$$$$ /$$$$$$$/
          |______/|_______/
================================
        Keep calm and get rich.
                    Is the best.

  	@Author: Dami
  	@Date:   2017-09-11 11:13:39
  	@Last Modified by:   Dami
  	@Last Modified time: 2017-09-11 11:14:04

*/
?>
<div class="row-sm my-n1 pt-5">
    <?php
        $prev_post = get_previous_post(false,'');
        $next_post = get_next_post(false,'');

        $prev_class = empty($next_post) ? 'col d-flex py-1' : 'col-12 col-md-6 d-flex py-1';
        $next_class = empty($prev_post) ? 'col d-flex py-1' : 'col-12 col-md-6 d-flex py-1';
    ?>
    <?php if (!empty($prev_post)): ?>
    <div class="<?php echo $prev_class; ?>">
        <div class="list-item list-auto-overlay custom-hover">
            <div class="media media-4x1">
                <a class="media-content custom-hover-img" style="background-image: url('<?php echo cosy19_the_thumbnail(get_post($prev_post->ID)) ?>')"><span class="overlay"></span></a>
            </div>
            <a href="<?php echo get_permalink($prev_post->ID); ?>" class="list-content">
                <div class="list-body ">
                    <div class="list-title">
                        <div class="text-xs text-muted mb-2"><?php _e('Previous', 'cosy19') ?></div>
                        <div class="h-md-1x h-2x h6 text-white">
                            <?php echo $prev_post->post_title ?>
                        </div>
                    </div>
                </div>
            </a>
        </div>
    </div>
    <?php endif; ?>
    <?php if (!empty($next_post)): ?>
    <div class="<?php echo $next_class; ?>">
        <div class="list-item list-auto-overlay custom-hover">
            <div class="media media-4x1">
                <a class="media-content custom-hover-img" style="background-image: url('<?php echo cosy19_the_thumbnail(get_post($next_post->ID)) ?>')"><span class="overlay"></span></a>
            </div>
            <a href="<?php echo get_permalink($next_post->ID); ?>" class="list-content">
                <div class="list-body ">
                    <div class="list-title">
                        <div class="text-xs text-muted mb-2"><?php _e('Next', 'cosy19') ?></div>
                        <div class="h-md-1x h-2x h6 text-white">
                            <?php echo $next_post->post_title ?>
                        </div>
                    </div>
                </div>
            </a>
        </div>
    </div>
    <?php endif; ?>
</div>