
<svg width="191px" height="213px" viewBox="0 0 191 213" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <defs>
        <filter x="-21.5%" y="-222.4%" width="143.1%" height="544.9%" filterUnits="objectBoundingBox" id="filter-1">
            <feGaussianBlur stdDeviation="8.89787946" in="SourceGraphic"></feGaussianBlur>
        </filter>
        <circle id="path-2" cx="17.6" cy="17.6" r="17.6"></circle>
        <filter x="-36.9%" y="-31.2%" width="173.9%" height="173.9%" filterUnits="objectBoundingBox" id="filter-3">
            <feOffset dx="0" dy="2" in="SourceAlpha" result="shadowOffsetOuter1"></feOffset>
            <feGaussianBlur stdDeviation="4" in="shadowOffsetOuter1" result="shadowBlurOuter1"></feGaussianBlur>
            <feColorMatrix values="0 0 0 0 0.250980392   0 0 0 0 0.418771979   0 0 0 0 1  0 0 0 0.405315897 0" type="matrix" in="shadowBlurOuter1"></feColorMatrix>
        </filter>
    </defs>
    <g id="Empty-States" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g id="4.1_No-Purchases" transform="translate(-103.000000, -142.000000)">
            <g id="Artwork" transform="translate(106.000000, 145.000000)">
                <g id="bag">
                    <g id="Group-7" transform="translate(0.000000, 12.000000)">
                        <polygon id="Rectangle-19-Copy-2" fill="#1B3554" filter="url(#filter-1)" points="19 164 143 164 143 176 19 176"></polygon>
                        <polygon id="Rectangle-19-Copy" fill="#E0E5EC" points="20 0 144 0 144 79 20 79"></polygon>
                        <polygon id="Rectangle-3" fill="#CFD4DC" points="20 0 20 120 0 120 0 47.4365922 10.0015776 32.0863839"></polygon>
                        <polygon id="Rectangle-3-Copy-3" fill="#CFD4DC" transform="translate(153.000000, 60.000000) scale(-1, 1) translate(-153.000000, -60.000000) " points="163 0 163 120 143 120 143 47.4365922 153.001578 32.0863839"></polygon>
                        <path d="M0,47 L163,47 L163,183 C163,185.761424 160.761424,188 158,188 L5,188 C2.23857625,188 3.38176876e-16,185.761424 0,183 L0,47 Z" id="Rectangle-19" fill="#FFFFFF"></path>
                    </g>
                    <g id="Group-2" transform="translate(49.000000, 111.000000)" fill="#1B3554" opacity="0.5">
                        <path d="M2.44188146,1.12786189 C4.1779756,0.376042652 5.88993922,0.000133034543 7.57777231,0.000133034543 C9.22968121,0.000133034543 10.8815901,0.360211064 12.533499,1.08036712 L12.5335012,1.08036213 C14.0314899,1.7334161 15,3.21218633 15,4.84633741 L15,4.84633741 C15,5.62848367 14.3659452,6.26253849 13.5837989,6.26253849 C13.3738469,6.26253849 13.1665214,6.21585733 12.97683,6.12587411 C11.1786154,5.27284506 9.36632512,4.84633741 7.53996556,4.84633741 C5.7046081,4.84633741 3.86925064,5.27705795 2.03389318,6.13849904 L2.03389002,6.13849231 C1.32025258,6.47344429 0.470202899,6.16645906 0.135250921,5.45282162 C0.0461776652,5.26304513 2.56735631e-17,5.05597797 0,4.84633741 L-8.8817842e-16,4.84633741 C-1.08601047e-15,3.23091611 0.959489652,1.76981245 2.4418806,1.12785992 Z" id="Rectangle-3-Copy"></path>
                        <path d="M53.4418815,1.12786189 C55.1779756,0.376042652 56.8899392,0.000133034543 58.5777723,0.000133034543 C60.2296812,0.000133034543 61.8815901,0.360211064 63.533499,1.08036712 L63.5335012,1.08036213 C65.0314899,1.7334161 66,3.21218633 66,4.84633741 L66,4.84633741 C66,5.62848367 65.3659452,6.26253849 64.5837989,6.26253849 C64.3738469,6.26253849 64.1665214,6.21585733 63.97683,6.12587411 C62.1786154,5.27284506 60.3663251,4.84633741 58.5399656,4.84633741 C56.7046081,4.84633741 54.8692506,5.27705795 53.0338932,6.13849904 L53.03389,6.13849231 C52.3202526,6.47344429 51.4702029,6.16645906 51.1352509,5.45282162 C51.0461777,5.26304513 51,5.05597797 51,4.84633741 L51,4.84633741 C51,3.23091611 51.9594897,1.76981245 53.4418806,1.12785992 Z" id="Rectangle-3-Copy-2"></path>
                        <path d="M33,31.0060637 C41.836556,31.0060637 49,25.8426197 49,17.0060637 C33,16.9539919 29.5583028,17.2616351 17,17.0060637 C17,25.8426197 24.163444,31.0060637 33,31.0060637 Z" id="Oval-10"></path>
                    </g>
                    <circle id="Oval" fill="#1B3554" opacity="0.149343297" cx="45" cy="74" r="6"></circle>
                    <circle id="Oval-Copy" fill="#1B3554" opacity="0.149343297" cx="118" cy="74" r="6"></circle>
                    <path d="M45,73.6926143 L45,36.5 C45,16.3416066 61.3416066,0 81.5,0 C101.658393,0 118,16.3416066 118,36.5 L118,73.6926143" id="Oval-15" stroke="#5E7085" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" fill-rule="nonzero"></path>
                </g>
                <g id="indicator" transform="translate(145.000000, 155.000000)">
                    <g id="Oval-2">
                        <use fill="black" fill-opacity="1" filter="url(#filter-3)" xlink:href="#path-2"></use>
                        <use fill="#6A88F7" fill-rule="evenodd" xlink:href="#path-2"></use>
                    </g>
                    <text id="0" font-family="Helvetica" font-size="17.6" font-weight="normal" letter-spacing="-0.16761905" fill="#FFFFFF">
                        <tspan x="13.1896689" y="24.4">0</tspan>
                    </text>
                </g>
            </g>
        </g>
    </g>
</svg>