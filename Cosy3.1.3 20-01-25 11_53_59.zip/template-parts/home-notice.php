<?php $notice = get_field('index_notice', 'option') ?>
<?php if (!empty($notice) && $notice !== 'close'): ?>
    <?php $content = get_field('index_notice_content', 'option') ?>
    <?php
        $button_html = '';
        if ($content['button_type'] !== 'close') {
            $button_class = $content['button_type'] == 'dark' ? 'btn btn-secondary btn-sm' : 'btn btn-primary btn-sm';
            $button_html = '<div class="notice-action mx-n1 mx-md-0 pl-md-4 pt-2 pt-md-0">'
                            .'<span class="d-inline-block p-1 px-md-0"><a class="'.$button_class.'" href="'.$content['button_link'].'" target="_blank">'.$content['button_title'].'</a></span>'
                            .'</div>';
        }
    ?>
    <?php if ($notice == 'plain'): ?>
        <div class="push-notice mb-3 mb-md-4">
            <div class="index-notice bg-light">
                <div class="notice-content d-flex flex-fill flex-column flex-md-row flex-md-warp align-items-md-center p-3 p-md-4">
                    <div class="notice-text">
                        <p><?php echo $content['content'] ?></p>
                    </div>
                    <div class="flex-md-fill"></div>
                    <?php echo $button_html ?>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="push-notice mb-3 mb-md-4">
            <div class="index-notice image-notice">
                <div class="media ">
                    <div class="media-content" style="background-image:url('<?php the_field('index_notice_bg', 'option') ?>')"></div>
                </div>
                <div class="notice-content d-flex flex-fill flex-column flex-md-row flex-md-warp align-items-md-center p-3 p-md-4">
                    <div class="notice-text">
                        <p><?php echo $content['content'] ?></p>
                    </div>
                    <div class="flex-md-fill"></div>
                    <?php echo $button_html ?>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>