<?php $ajax_loading = get_field('index_ajax_loading', 'option') ?>
<?php if ($ajax_loading): ?>
<?php $index_tab = get_field('index_tab', 'option') ?>
    <?php if (is_array($index_tab['list'])): ?>
        <div class="list-ajax-nav text-md-center mb-3">
            <ul class="d-flex flex-nowrap flex-md-wrap justify-content-md-center">
                <li class="flex-shrink-0"><button class="btn btn-link btn-sm active" data-cid="-2.1"><?php echo empty( $index_tab['display_name'] ) ? '最新' : $index_tab['display_name']; ?></button></li>
                <?php
                    foreach ($index_tab['list'] as $index => $tab) {
                        if( $tab['type'] == 'cat' ) {
                            echo sprintf( '<li class="flex-shrink-0"><button class="btn btn-link btn-sm" data-cid="%s">%s</button></li>', $tab['cat'], $tab['display_name'] );
                        } else {
                            echo sprintf( '<li class="flex-shrink-0"><button class="btn btn-link btn-sm" data-cid="%s">%s</button></li>', '-1.'.$index, $tab['display_name'] );
                        }
                    }
                ?>
            </ul>
        </div>
    <?php endif; ?>
<?php endif; ?>