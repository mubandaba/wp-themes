<?php $ad = get_field('single_ad', 'option'); ?>
<?php if (!empty($ad['type'] && $ad['type'] != 'closed')): ?>
    <section class="list-sales d-none d-lg-block">
        <?php if ($ad['type'] == 'code'): ?>
            <?php echo $ad['code_pc'] ?>
        <?php else: ?>
                <a href="<?php echo esc_url($ad['link']); ?>" target="_blank"><img src="<?php echo $ad['image_pc']; ?>"></a>
        <?php endif; ?>
    </section>
    <section class="list-sales d-lg-none">
        <?php if ($ad['type'] == 'code'): ?>
            <?php echo $ad['code_mobile'] ?>
        <?php else: ?>
                <a href="<?php echo esc_url($ad['link']); ?>" target="_blank"><img src="<?php echo $ad['image_mobile']; ?>"></a>
        <?php endif; ?>
    </section>
<?php endif; ?>