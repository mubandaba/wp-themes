<?php $ad = get_field('tax_ad', 'option'); ?>
<?php if (!(empty($ad['type']) || $ad['type'] == 'closed')): ?>
    <div class="list-sales mt-3 mt-md-5 d-none d-lg-block">
        <?php if ($ad['type'] == 'code'): ?>
            <?php echo $ad['code_pc'] ?>
        <?php else: ?>
                <a href="<?php echo esc_url($ad['link']); ?>" target="_blank"><img src="<?php echo $ad['image_pc']; ?>"></a>
        <?php endif; ?>
    </div>
    <div class="list-sales mt-3 mt-md-5 d-lg-none">
        <?php if ($ad['type'] == 'code'): ?>
            <?php echo $ad['code_mobile'] ?>
        <?php else: ?>
                <a href="<?php echo esc_url($ad['link']); ?>" target="_blank"><img src="<?php echo $ad['image_mobile']; ?>"></a>
        <?php endif; ?>
    </div>
<?php endif; ?>