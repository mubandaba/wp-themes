<?php $meta_layout = get_field('meta_layout', 'option') ?: array(); ?>
<div id="author-popup-wrap">
    <div class="author-popup-cover">
        <div class="media media-16x9 bg-dark-gradient">
            <div class="bg-effect bg-dark-gradient bg-author"></div>
            <div class="bg-effect bg-cover" data-img="<?php echo get_avatar_url(get_the_author_meta('user_email')) ?>"></div>
        </div>
        <div class="author-popup-meta mt-n5">
            <div class="px-4">
                <div class="d-flex align-items-center justify-content-center">
                    <a href="<?php echo get_author_posts_url(get_the_author_meta( 'ID' )); ?>" class="avatar mx-2 w-96" taget="_blank" >
                        <?php echo get_avatar(get_the_author_meta('user_email'), 96, '', '', array('class' => 'nc-no-lazy')) ?>
                    </a>
                </div>
                <div class="text-center mt-3">
                    <a href="<?php echo get_author_posts_url(get_the_author_meta( 'ID' )); ?>" class="h5" target="_blank" ><?php the_author_meta('display_name') ?></a>
                    <div class="d-block text-sm text-muted mt-2"><span class="h-2x"><?php echo get_the_author_meta('description') ?: get_translated_role_name(get_the_author_meta('roles')[0]) ?></span></div>
                </div>
            </div>
            <?php if (!in_array('0', $meta_layout)): ?>
            <div class="row no-gutters text-center">
                <a href="<?php echo get_author_posts_url(get_the_author_meta( 'ID' )); ?>" class="col py-3" target="_blank">
                    <span class="font-theme text-lg d-block"><?php echo count_user_posts(get_the_author_meta('ID')) ?></span>
                    <small class="text-xs text-muted"><?php _e('Posts', 'cosy19') ?></small>
                </a>
                <div class="col py-3">
                    <span class="font-theme text-lg d-block"><?php cosy19_the_author_comment_count(get_the_author_meta('ID')) ?></span>
                    <small class="text-xs text-muted"><?php _e('Comments', 'cosy19') ?></small>
                </div>
                <div class="col py-3">
                    <span class="font-theme text-lg d-block"><?php cosy19_the_author_like_count(get_the_author_meta('ID')) ?></span>
                    <small class="text-xs text-muted"><?php _e('Likes', 'cosy19') ?></small>
                </div>
            </div>
            <?php endif; ?>
      </div>
    </div>
</div>
