<?php $search = get_field('search_layout', 'option'); ?>
<?php
    $tags = $search['tags'];
    $tags = empty($tags) ? get_terms(array(
        'taxonomy' => 'post_tag',
        'orderby' => 'count',
        'order' => 'DESC',
    )) : $tags;
?>
<div id="search-popup-wrap">
    <div class="search-popup-cover bg-light px-3 px-lg-5 py-5">
        <div class="bg-effect bg-cover nc-no-lazy" style="background-image: url('<?php echo $search['background'] ?>')">
            <span class="overlay"></span>
        </div>
        <form role="search" id="searchform" class="search-popup-form py-lg-5" method="get" action="<?php echo home_url( '/' ) ?>">
           <input class="form-control form-control-lg form-transparent" type="text" placeholder="<?php _e('Type Something...', 'cosy19') ?>" name="s" id="s" required>
        </form>
    </div>
    <?php if (is_array($tags) && count($tags) > 0): ?>
    <div class="search-key-push px-3 px-lg-5 py-3 py-lg-4">
        <div class="h6 mb-3"><?php _e('Top Keywords', 'cosy19') ?></div>
        <ul class="nav nav-pills m-n1">
            <?php foreach(array_slice($tags, 0, 18) as $tag): ?>
                <li class="nav-item p-1"><a href="<?php echo empty($search['tags']) ? get_term_link($tag) : '/?s='.$tag['tag'] ?>" target="_blank" class="btn btn-light btn-sm"><?php echo empty($search['tags']) ? $tag->name : $tag['tag'] ?></a></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>
</div>
