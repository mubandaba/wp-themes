<?php $episode_mode = get_field('episode_mode', get_the_ID()); ?>
<?php if ($episode_mode): ?>
<?php 
    $args = array(
        'posts_per_page' => -1,
        'cat' => get_field('episode_cat', get_the_ID()),
        'ignore_sticky_posts' => 1,
        'meta_key' => 'episode_no',
        'orderby'  => 'meta_value',
        'order' => 'ASC'
    );
    $current_no = get_field('episode_no', get_the_ID());
    $episodePosts = new WP_Query($args);
?>
    <?php if ( $episodePosts->have_posts() ): ?>
    <div class="list-video-nav border-top pt-4 mt-4 mb-5">
        <div class="text-sm text-muted mb-3"><?php _e('Episodes', 'cosy19') ?></div>
        <div class="list-scroll-x">
            <ul class="nav nav-pills font-theme flex-nowrap flex-md-wrap mx-n1 mx-md-n2">
                <?php while ( $episodePosts->have_posts() ) : $episodePosts->the_post(); ?>
                    <li class="nav-item px-1 px-md-2">
                        <a class="nav-link bg-light <?php if ($current_no == get_field('episode_no', get_the_ID())):?>active<?php endif; ?>" href="<?php the_permalink() ?>"><?php the_field('episode_no', get_the_ID()) ?></a>
                    </li>
                <?php endwhile; ?>
            </ul>
        </div>
    </div>
    <?php endif; ?>
    <?php wp_reset_postdata(); ?>
<?php endif; ?>