<?php
    $s = new MiShare();
    $share_channel = get_field('share_channel', 'option');

    global $post;

    $url = get_the_permalink(get_the_ID());
    $title = get_the_title();
    $image = cosy19_post_thumbnail_src();
    $description = cosy19_print_excerpt(150, $post, false);

    $s->config = array(
        'url' => $url,
        'title' => $title,
        'des'   => $description
    );
?>
<div class="post-social">
    <?php if ($share_channel == 'all' || $share_channel == 'domestic'): ?>
    <a href="<?php echo $s->weibo() ?>" target="_blank" class="weibo"><i class="iconfont icon-weibo"></i></a>
    <a href="javascript:" class="weixin single-popup" data-img="<?php echo $s->weixin() ?>" data-title="微信扫一扫 分享朋友圈" data-desc="在微信中请长按二维码"><i class="iconfont icon-weixin"></i></a>
    <a href="<?php echo $s->qq() ?>" target="_blank" class="qq"><i class="iconfont icon-qq"></i></a>
    <?php endif; ?>
    <?php if ($share_channel == 'all' || $share_channel == 'abroad'): ?>
    <a href="<?php echo $s->facebook() ?>" target="_blank" class="facebook"><i class="iconfont icon-facebook"></i></a>
    <a href="<?php echo $s->twitter() ?>" target="_blank" class="twitter"><i class="iconfont icon-twitter"></i></a>
    <a href="<?php echo $s->linkedin() ?>" target="_blank" class="linkedin"><i class="iconfont icon-linkedin"></i></a>
    <?php endif; ?>
</div>