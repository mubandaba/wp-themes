<?php
    extract($template_params, EXTR_SKIP);
    $authors = $item['authors'];
    $meta_layout = get_field('meta_layout', 'option');
?>
<section class="list-author-pushes py-3 py-md-5 <?php echo $item['bg_color'] ?>">
    <div class="container">
        <div class="list-header h4 mb-3"><?php echo $item['title'] ?> <small class="text-md text-muted px-2"><?php echo $item['description'] ?></small></div>
        <div class="list-scroll-5x">
            <div class="row-md list-grouped list-tb-padding">
                <?php foreach ($authors as $author): ?>
                    <div class="col-6 col-md-3 d-flex">
                        <div class="list-item block flex-fill">
                            <div class="media media-21x9 bg-dark-gradient">
                                <div class="bg-effect bg-dark-gradient bg-author"></div>
                                <div class="bg-effect bg-cover" data-img="<?php echo get_avatar_url($author['ID']); ?>"></div>
                            </div>
                            <div class="list-content mt-n5">
                                <div class="d-flex align-items-center justify-content-center">
                                    <a href="<?php echo get_author_posts_url($author['ID']) ?>" target="_blank" class="avatar mx-2 w-80">
                                        <?php echo get_avatar( $author['ID'], 80, '', '' ); ?>
                                    </a>
                                </div>
                                <div class="d-flex flex-column flex-fill text-center mt-3 mb-3 mb-md-2">
                                    <a href="<?php echo get_author_posts_url($author['ID']) ?>" target="_blank" class="h6"><?php echo $author['display_name'] ?></a>
                                    <div class="d-block text-xs text-muted mt-2 px-2"><span class="h-2x"><?php echo $author['user_description'] ?></span></div>
                                    <?php if (!in_array('0', $meta_layout)): ?>
                                    <div class="row no-gutters text-center text-xs mt-auto d-none d-md-flex">
                                        <a href="<?php echo get_author_posts_url($author['ID']) ?>" class="col px-1 pt-3 pb-1" target="_blank">
                                            <span class="font-theme text-md d-block"><?php echo count_user_posts($author['ID']) ?></span>
                                            <small class="text-xs text-muted"><?php _e('Posts', 'cosy19') ?></small>
                                        </a>
                                        <div class="col px-1 pt-3 pb-1">
                                            <span class="font-theme text-md d-block"><?php cosy19_the_author_comment_count($author['ID']) ?></span>
                                            <small class="text-xs text-muted"><?php _e('Comments', 'cosy19') ?></small>
                                        </div>
                                        <div class="col px-1 pt-3 pb-1">
                                            <span class="font-theme text-md d-block"><?php cosy19_the_author_like_count($author['ID']) ?></span>
                                            <small class="text-xs text-muted"><?php _e('Likes', 'cosy19') ?></small>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>

                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>