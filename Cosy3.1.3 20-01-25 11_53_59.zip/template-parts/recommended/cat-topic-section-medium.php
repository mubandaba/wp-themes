<?php
    extract($template_params, EXTR_SKIP);
    $queryPosts = new WP_Query($args);
?>
<?php if ( $queryPosts->have_posts() ): ?>
<section class="list-style-3 py-3 py-md-5 <?php echo $item['bg_color'] ?>">
    <div class="container">
        <div class="list-header h4 text-center mb-3"><?php echo empty($item['title']) ? $tax->name : $item['title'] ?> <small class="text-md text-muted px-2 d-block"><?php echo empty($item['description']) ? $tax->slug : $item['description'] ?></small></div>
        <div class="row-sm my-n2">
            <?php while ( $queryPosts->have_posts() ) : $queryPosts->the_post(); ?>
            <div class="col-6 col-md-3 py-2">
                <div class="list-item list-nice-overlay custom-hover">
                    <div class="media media-3x2">
                        <a class="media-content" href="<?php the_permalink() ?>">
                            <img src="<?php echo cosy19_the_thumbnail(null, array('w' => 300, 'h' => 200)) ?>">
                            <span class="overlay"></span>
                        </a>
                    </div>
                    <div class="list-content p-2">
                        <div class="list-body ">
                            <a href="<?php the_permalink() ?>" class="list-title h-2x">
                                <?php the_title() ?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
</section>
<?php endif; ?>
<?php wp_reset_postdata(); ?>