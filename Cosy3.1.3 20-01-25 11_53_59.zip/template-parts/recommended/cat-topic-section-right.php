
<?php
    $index = 0;
    extract($template_params, EXTR_SKIP);
    $content = $item['content'];
    $queryPosts = new WP_Query($args);
?>
<section class="list-style-2 py-3 py-md-5 <?php echo $item['bg_color'] ?>">
    <div class="container">
        <div class="list-header h4 mb-3"><?php echo empty($item['title']) ? $tax->name : $item['title'] ?> <small class="d-block d-md-inline-block text-md text-muted px-md-2"><?php echo empty($item['description']) ? $tax->slug : $item['description'] ?></small></div>
        <div class="row-sm">
            <div class="col-12 col-md-9  order-2 order-md-1">
                <div class="row-sm my-n2">
                <?php while ( $queryPosts->have_posts() ) : $queryPosts->the_post(); $index++; ?>
                    <div class="col-6 col-md-3 py-2">
                        <div class="list-item list-nice-overlay custom-hover">
                            <div class="media media-3x2">
                                <a class="media-content" href="<?php the_permalink() ?>">
                                    <img src="<?php echo cosy19_the_thumbnail(null, array('w' => 300, 'h' => 300)) ?>">
                                    <span class="overlay"></span>
                                </a>
                            </div>
                            <div class="list-content p-2">
                                <div class="list-body ">
                                    <a href="<?php the_permalink() ?>" class="list-title h-2x">
                                        <?php the_title() ?>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
                </div>
            </div>
            <div class="col-12 col-md-3 d-flex order-1 order-md-2 mb-3 mb-md-0">
                <div class="list-item list-overlay custom-hover flex-fill">
                    <div class="media media-3x2 d-flex flex-fill">
                        <a href="<?php echo get_term_link($tax); ?>" class="media-content" style="background-image: url(<?php echo empty($content['image']) ? get_field('cover', 'special_'.$tax->term_id) : $content['image'] ?>)"><span class="overlay"></span></a>
                    </div>
                    <div class="list-content p-3">
                        <div class="list-body ">
                            <a href="<?php echo get_term_link($tax); ?>" class="list-title h4 text-left m-0">
                                <?php echo $tax->name; ?>
                            </a>
                        </div>
                        <div class="list-footer d-flex align-items-center text-muted text-xs m-0">
                            <div><?php echo $content['type'] == 'special' ? __('special', 'cosy19') : __('Category', 'cosy19') ?></div>
                            <div class="flex-fill"></div>
                            <div class="text-nowrap">
                                <span class="d-inline-block pl-2">
                                    <?php echo $tax->count; ?> <?php _e('posts', 'cosy19') // 篇文章 ?> 
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php wp_reset_postdata(); ?>