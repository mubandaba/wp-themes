<?php global $wp_query ?>
<?php $template_params = isset($template_params) ? $template_params : array() ?>
<?php
    if ($template_params['style'] == 'plain') $row_class = 'row mt-4 mt-md-5 mb-2 mb-md-0';
    if ($template_params['style'] == 'medium') $row_class = 'row-lg  mt-4 mt-md-5  mb-2 mb-md-0';
    if ($template_params['style'] == 'small') $row_class = 'row-sm mt-4 mt-md-5  mb-2 mb-md-0';
?>
<?php
    if ($template_params['style'] == 'plain') $class = 'col-12';
    if ($template_params['style'] == 'medium') $class = 'col-12 col-md-4';
    if ($template_params['style'] == 'small') $class = 'col-12 col-md-6';
?>
<?php if ($template_params['ajax_loading']): ?>
    <nav class="posts-ajax-load pagination-ajax justify-content-md-center <?php echo $row_class ?> ">
        <div class="<?php echo $class ?>">
            <div class="ajax-loading"><span class="dot1"></span><span class="dot2"></span></div>
            <button
                data-page="<?php echo $template_params['page'] ?>"
                data-query="<?php echo $template_params['query']; ?>"
                data-action="ajax_load_posts"
                data-paged="2"
                data-append="<?php echo $template_params['append'] ?>"
                class="dposts-ajax-load btn btn-light btn-block"><?php _e('Load more...', 'cosy19') ?></button>
        </div>
    </nav>
<?php else: ?>
    <?php
        the_posts_pagination( array(
            'prev_text'          =>'<i class="text-md iconfont icon-arrowleft"></i>',
            'next_text'          =>'<i class="text-md iconfont icon-arrowright"></i>',
            'screen_reader_text' => 'Posts Navigation',
            'mid_size' => 1,
        ) );
    ?>
<?php endif; ?>