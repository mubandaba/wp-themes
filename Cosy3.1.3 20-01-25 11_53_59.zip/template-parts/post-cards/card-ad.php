<?php $ad = get_field('index_list_ad', 'option'); ?>
<?php if (!empty($ad['type'] && $ad['type'] != 'closed')): ?>
    <!--下面是web端显示的-->
    <div class="col-6 col-md-3 d-none d-lg-flex">
        <div class="list-item block flex-fill">
            <div class="media flex-fill">
                <?php if ($ad['type'] == 'code'): ?>
                    <div class="media-content flex-fill">
                        <?php echo $ad['code'] ?>
                    </div>
                <?php else: ?>
                    <a href="<?php echo esc_url($ad['link']); ?>" class="media-content flex-fill" style="background-image: url(<?php echo $ad['image']; ?>)" target="_blank"></a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!--下面是手机端显示的，代码需要修改下-->
    <div class="col-6 col-md-3 d-flex d-lg-none">
        <div class="list-item block flex-fill">
            <div class="media flex-fill">
                <?php if ($ad['type'] == 'code'): ?>
                    <div class="media-content flex-fill">
                        <?php echo $ad['code'] ?>
                    </div>
                <?php else: ?>
                    <a href="<?php echo esc_url($ad['link']); ?>" class="media-content flex-fill" style="background-image: url(<?php echo $ad['image']; ?>)" target="_blank"></a>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php endif; ?>