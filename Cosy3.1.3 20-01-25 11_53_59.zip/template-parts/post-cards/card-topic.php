<?php 
    extract($template_params, EXTR_SKIP);
    $tax = array_column($index_insert_topics, 'topic', 'position')[$index];
    $args = array(
        'posts_per_page' => 1,
        'tax_query' => array(
            array(
                'taxonomy' => 'special',
                'terms'    => $tax->term_id,
            ),
        ),
    );
    $queryPosts = new WP_Query($args);
?>
<?php if ($tax): ?>
    <div class="col-6 col-md-3 d-flex">
        <div class="list-item list-overlay block flex-fill">
            <div class="media d-flex flex-fill">
                <a class="media-content" href="<?php echo get_term_link($tax); ?>" style="background-image: url(<?php the_field('cover', 'special_'.$tax->term_id) ?>)"><span class="overlay"></span></a>
            </div>
            <div class="list-content">
                <div class="list-body">
                    <div class="mb-3">
                        <a href="<?php echo get_term_link($tax); ?>">
                            <span class="badge badge-md text-uppercase bg-white-overlay"><?php echo $tax->name; ?></span>
                        </a>
                    </div>
                    <?php while ( $queryPosts->have_posts() ) : $queryPosts->the_post(); $index++; ?>
                        <a href="<?php echo get_term_link($tax); ?>" target="_blank" class="list-title h-2x mb-2"><?php the_title() ?></a>
                    <?php endwhile; ?>
                </div>
                <div class="list-footer d-flex align-items-center text-muted text-xs m-0">
                    <div><?php _e('Topic', 'cosy19') ?></div>
                    <div class="flex-fill"></div>
                    <div class="text-nowrap">
                        <span class="d-inline-block px-2">
                            <?php echo $tax->count; ?> <?php _e('posts', 'cosy19') // 篇文章 ?> 
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php wp_reset_postdata(); ?>