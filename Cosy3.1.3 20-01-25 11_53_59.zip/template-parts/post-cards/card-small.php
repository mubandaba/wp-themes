<?php global $post ?>
<?php $category = get_the_category(); $meta_layout = get_field('meta_layout', 'option'); ?>
<div class="col-6 col-md-3 d-flex">
    <div class="list-item block custom-hover">
        <div class="media media-3x2">
            <a class="media-content" href="<?php the_permalink() ?>" target="_blank">
                <img src="<?php cosy19_the_thumbnail() ?>" alt="<?php the_title() ?>">
                <span class="overlay"></span>
            </a>
            <?php if ('image' == get_post_format()): ?>
            <div class="media-action">
                <i class="iconfont icon-pic-s"></i>
            </div>
            <?php endif; ?>
            <?php if ('video' == get_post_format()): ?>
            <div class="media-action">
                <i class="iconfont icon-bofang"></i>
            </div>
            <?php endif; ?>
            <?php if ('audio' == get_post_format()): ?>
            <div class="media-action">
                <i class="iconfont icon-yinle"></i>
            </div>
            <?php endif; ?>
        </div>
        <div class="list-content">
            <div class="list-body">
                <?php if (!is_single() && !(is_category() || $template_params['type'] == 'cat')): ?>
                    <?php get_template_part_with_vars("template-parts/post-cards/partials/card-cat", array('style' => 'small', 'cat' => $category[0])); ?>
                <?php endif; ?>
                <a href="<?php the_permalink() ?>" class="list-title text-md h-2x" target="_blank"><?php the_title() ?></a>
            </div>
            <div class="list-footer d-flex align-items-center text-muted text-xs mt-2">
                <div><?php cosy19_the_time(); ?></div>
                <div class="flex-fill"></div>
                <div class="text-nowrap">
                    <?php if ($meta_layout['view'] === '1'): ?>
                    <span class="<?php cosy19_the_meta_class('view') ?>">
                        <i class="text-sm iconfont icon-view"></i>
                        <small><?php cosy19_post_views('',''); ?></small>
                    </span>
                    <?php endif; ?>
                    <?php if (comments_open()): ?>
                    <span class="<?php cosy19_the_meta_class('comment') ?> px-2">
                        <i class="text-sm iconfont icon-duanxin"></i> <?php echo $post->comment_count; ?>
                    </span>
                    <?php endif; ?>
                    <?php if ($meta_layout['like'] === '1'): ?>
                    <span class="<?php cosy19_the_meta_class('like') ?>">
                        <i class="iconfont icon-shoucang"></i> <?php echo cosy19_get_hearts(get_the_ID()) ?>
                    </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>