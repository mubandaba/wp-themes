<?php $category = get_the_category(); $meta_layout = get_field('meta_layout', 'option'); ?>
<?php global $post ?>
<div class="list-item custom-hover">
    <div class="media media-3x2 col-5 col-md-4">
        <a class="media-content" href="<?php the_permalink() ?>" target="_blank">
            <img src="<?php cosy19_the_thumbnail() ?>" alt="<?php the_title() ?>">
            <span class="overlay"></span>
        </a>
        <?php if ('image' == get_post_format()): ?>
        <div class="media-action">
            <i class="iconfont icon-pic-s"></i>
        </div>
        <?php endif; ?>
        <?php if ('video' == get_post_format()): ?>
        <div class="media-action">
            <i class="iconfont icon-bofang"></i>
        </div>
        <?php endif; ?>
        <?php if ('audio' == get_post_format()): ?>
        <div class="media-action">
            <i class="iconfont icon-yinle"></i>
        </div>
        <?php endif; ?>
    </div>
    <div class="list-content py-lg-2">
        <div class="list-body">
            <?php if (!is_single() && !(is_category() || $template_params['type'] == 'cat')): ?>
                <?php get_template_part_with_vars("template-parts/post-cards/partials/card-cat", array('style' => 'plain', 'cat' => $category[0])); ?>
            <?php endif; ?>
            <a href="<?php the_permalink() ?>" class="list-title text-lg h-2x"><?php the_title() ?></a>
            <div class="list-subtitle text-sm text-muted d-none d-lg-block mt-lg-3"><span class="h-2x"><?php cosy19_print_excerpt(140) ?></span></div>
        </div>
        <div class="list-footer d-flex align-items-center text-muted text-xs m-0">
            <div><?php cosy19_the_time(); ?></div>
            <div class="flex-fill"></div>
            <div class="text-nowrap">
                <?php if ($meta_layout['view'] === '1'): ?>
                <span class="<?php cosy19_the_meta_class('view') ?>">
                    <i class="text-sm iconfont icon-view"></i>
                    <small><?php cosy19_post_views('',''); ?></small>
                </span>
                <?php endif; ?>
                <?php if (comments_open()): ?>
                 <span class="<?php cosy19_the_meta_class('comment') ?> px-2 px-md-3">
                    <i class="text-sm iconfont icon-duanxin"></i> <?php echo $post->comment_count; ?>
                </span>
                <?php endif; ?>
                <?php if ($meta_layout['like'] === '1'): ?>
                <span class="<?php cosy19_the_meta_class('like') ?>">
                    <i class="iconfont icon-shoucang"></i> <?php echo cosy19_get_hearts(get_the_ID()) ?>
                </span>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>