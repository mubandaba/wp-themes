<?php
    $class = 'd-none d-lg-block text-xs ';

    if ($template_params['style'] == 'small') $class .= 'mb-1 ';
    if ($template_params['style'] == 'medium') $class .= 'my-2 ';
    if ($template_params['style'] == 'plain') $class .= 'mb-1 ';

    $dot = get_field('kuang_style_nice', 'option')['card_dot'];
    if ($dot == 'hollow') $class .= 'list-cat-style list-cat-dot-circle ';
    if ($dot == 'solid') $class .= 'list-cat-style list-cat-dot ';

    if ($dot) {
        $color = get_field('card_dot_color', 'category_'.$template_params['cat']->term_id);
        if (!$color) $color = get_field('card_dot_color_customize', 'category_'.$template_params['cat']->term_id);
        $color_style = $dot == 'hollow' ? "border-color: $color;" : "background-color: $color;"; 
    }
?>
<div class="<?php echo $class ?>">
    <?php if ($dot): ?><i class="cat-dot" style="<?php echo $color_style ?>"></i><?php endif; ?>
    <a href="<?php echo get_category_link($template_params['cat']->term_id); ?>" class="text-muted" target="_blank"><?php echo $template_params['cat']->cat_name; ?></a>
</div>