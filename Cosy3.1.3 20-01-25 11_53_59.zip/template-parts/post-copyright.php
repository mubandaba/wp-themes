<?php

/*
            /$$
    /$$    /$$$$
   | $$   |_  $$    /$$$$$$$
 /$$$$$$$$  | $$   /$$_____/
|__  $$__/  | $$  |  $$$$$$
   | $$     | $$   \____  $$
   |__/    /$$$$$$ /$$$$$$$/
          |______/|_______/
================================
        Keep calm and get rich.
                    Is the best.

  	@Author: Dami
  	@Date:   2017-09-11 11:04:51
  	@Last Modified by:   Dami
  	@Last Modified time: 2017-12-18 21:36:30

*/
$post_copyright = get_field( 'post_copyright', get_the_ID() );
// if (empty($post_copyright)) $post_copyright = 1;
if ($post_copyright == 2) {
    $copyright_author = get_field( 'post_copyright_name', get_the_ID() );
    $copyright_url = get_field( 'post_copyright_link', get_the_ID() );
}
?>

<?php if ($post_copyright): ?>
    <div class="hr-short"></div>
    <?php if ($post_copyright == 1): ?>
        <div class="post-declare mt-3 mt-md-4"><p>本文系作者 @<?php the_author_posts_link(); ?> 原创发布在 <?php bloginfo( 'name' ); ?>。未经许可，禁止转载。</p></div><?php endif; ?>
    <?php if ($post_copyright == 2): ?>
        <div class="post-declare mt-3 mt-md-4"><p>本文系作者 @<a href="<?php echo $copyright_url; ?>" target="_blank"><?php echo $copyright_author; ?></a> 授权发布在 <?php bloginfo( 'name' ); ?>。未经许可，禁止转载。</p></div>
    <?php endif; ?>
<?php endif; ?>