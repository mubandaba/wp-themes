<?php $categories = get_categories(array('child_of' => $cat)); ?>
<?php if (!empty($categories)): ?>
<div class="navbar-collapse">
    <ul class="navbar-nav ml-auto">
    <?php foreach($categories as $category):  ?>
        <li class="menu-item"><a href="<?php echo get_category_link( $category->term_id ) ?>" target="_blank" class="nav-link"><?php echo $category->name; ?></a></li>
    <?php endforeach; ?>
    </ul>
</div>
<?php endif; ?>