<?php
    $term = get_queried_object();
    $list_style = $template_params['style'];
    if ($list_style == 'plain') {
        $card_class = 'col-6 col-md-4';
        $row_class = 'row';
    }
    if ($list_style == 'medium') {
        $card_class = 'col-6 col-md-4';
        $row_class = 'row-lg';
    }
    if ($list_style == 'small') {
        $card_class = 'col-6 col-md-3';
        $row_class = 'row-md';
    }
    if (is_category()) {
        $args = array(
            'posts_per_page' => in_array($list_style, array('plain', 'medium')) ? 3 : 4,
            'cat' => $term->term_id,
            'post__in' => get_option( 'sticky_posts' ),
            'ignore_sticky_posts' => 1
        );
    }
    if( is_tag() ){
        $args = array(
            'posts_per_page' => in_array($list_style, array('plain', 'medium')) ? 3 : 4,
            'tag_id' => $term->term_id,
            'post__in' => get_option( 'sticky_posts' ),
            'ignore_sticky_posts' => 1
        );
    }
    $topPosts = new WP_Query($args);
?>
<?php if ( $topPosts->have_posts() ): ?>
<div class="bg-light py-4 py-md-5">
    <div class="container">
        <div class="row <?php echo $list_style == 'plain' ? 'justify-content-md-center' : '' ?>">
            <div class="<?php echo $list_style == 'plain' ? 'col-lg-9' : 'col-12' ?>">
                <div class="list-header h4 mb-3 mb-md-4"><?php _e('Top Posts', 'cosy19') ?></div>
                <div class="list-grouped list-scroll-x">
                    <div class=" <?php echo $row_class ?>">
                        <?php while ( $topPosts->have_posts() ) : $topPosts->the_post(); ?>
                            <?php global $post ?>
                            <div class="<?php echo $card_class ?>">
                                <div class="list-item list-nice-overlay custom-hover">
                                    <div class="media media-3x2">
                                        <a href="<?php the_permalink() ?>" class="media-content custom-hover-img" style="background-image:url('<?php cosy19_the_thumbnail() ?>')"><span class="overlay"></span></a>
                                    </div>
                                    <div class="list-content ">
                                        <div class="list-body">
                                            <a href="<?php the_permalink() ?>" class="list-title h-2x"><?php the_title() ?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php wp_reset_postdata(); ?>