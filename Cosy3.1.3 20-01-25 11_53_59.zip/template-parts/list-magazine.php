<?php
    $posts_id = is_array(get_field('index_focus_posts', 'option')) ? array_column(get_field('index_focus_posts', 'option'), 'post') : array();
    $index_menu_style = get_field('index_menu_style', 'option');

    $bg_color = '';
    if ($index_menu_style == 'plain') $bg_color = ' bg-light ';
    if ($index_menu_style == 'dark') $bg_color = ' bg-dark';
?>
<?php if (!empty($index_menu_style) && $index_menu_style !== 'close'): ?>
    <section class="list-magazine<?php if ($index_menu_style == 'immersed' || $index_menu_style == 'dark' || $index_menu_style == 'image'): ?> list-fixed <?php endif; ?><?php echo $bg_color ?>">
    <?php $post = get_post($posts_id[0]) ?>
        <?php if ($index_menu_style == 'immersed'): ?>
            <div class="bg-effect bg-dark bg-image-color"></div>
            <div class="bg-effect bg-cover bg-magazine" data-img="<?php cosy19_the_thumbnail(get_post($post->ID), array('w' => 600, 'h' => 600)) ?>"></div>
        <?php elseif ($index_menu_style == 'image'): ?>
        <div class="bg-effect bg-cover" style="background-image:url('<?php the_field('index_menu_image_upload', 'option') ?>')"></div>
        <?php endif; ?>
        <div class="container">
            <div class="row-sm">
                <div class="col-12 col-md-6 d-flex">
                    <div class="list-item list-nice-overlay custom-hover flex-fill">
                        <div class="media d-flex flex-fill">
                            <a href="<?php the_permalink($post->ID) ?>" class="media-content" style="background-image: url('<?php cosy19_the_thumbnail(get_post($post->ID), array('w' => 450, 'h' => 450)) ?>')">
                                <span class="overlay"></span>
                            </a>
                        </div>
                        <div class="list-content">
                            <div class="list-body">
                                <a href="<?php the_permalink($post->ID) ?>" class="list-title text-lg h-2x" target="_blank">
                                    <?php echo get_the_title($post->ID) ?>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 mt-2 mt-md-0">
                    <div class="list-scroll-2x">
                        <div class="row-sm row-scroll my-n1 my-md-n2">
                            <?php foreach (array_slice($posts_id, 1) as $post_id): ?>
                                <?php $post = get_post($post_id) ?>
                                <div class="col-6 py-1 py-md-2">
                                    <div class="list-item list-nice-overlay custom-hover">
                                        <div class="media">
                                            <a href="<?php the_permalink($post->ID) ?>" class="media-content" style="background-image: url('<?php cosy19_the_thumbnail(get_post($post->ID), array('w' => 300, 'h' => 300)) ?>')">
                                                <span class="overlay"></span>
                                            </a>
                                        </div>
                                        <div class="list-content">
                                            <div class="list-body">
                                                <div class="mt-auto">
                                                    <a href="<?php the_permalink($post->ID) ?>" class="list-title text-md h-2x ">
                                                        <?php echo get_the_title($post->ID) ?>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php wp_reset_postdata(); ?>