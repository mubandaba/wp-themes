<main class="py-4 py-md-5">
    <div class="container">
        <?php cosy19_breadcrumbs() ?>
        <div class="row no-gutters">
            <div class="col-12 col-lg-9 pr-lg-5">
                <div class="post">
                    <?php if (!empty(cosy19_get_head_img(get_the_ID()))): ?>
                    <div class="post-cover mb-4">
                        <div class="media media-3x1">
                            <div class="media-content" style="background-image:url('<?php echo cosy19_get_head_img(get_the_ID(), array('w' => 900, 'h' => 300)) ?>')"></div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <h1 class="post-title h3"><?php the_title() ?></h1>
                    <?php get_template_part('template-parts/post-meta') ?>
                    <div class="content-style content">
                        <?php the_content() ?>
                    </div>
                    <?php get_template_part('template-parts/ad/single-ad'); ?>
                    <div class="post-tags mt-3 mt-md-4">
                        <?php the_tags('', '', '') ?>
                    </div>
                    <?php get_template_part('template-parts/post-copyright') ?>
                    <?php get_template_part('template-parts/post-footer') ?>
                    <?php get_template_part('template-parts/post-nav-link') ?>
                </div>
                <?php
                    if ( comments_open() || get_comments_number() ) :
                        comments_template();
                    endif;
                ?>
            </div>
            <div class="sidebar col-lg-3 d-none d-lg-block">
                <?php get_template_part('template-parts/toc') ?>
                <?php get_sidebar() ?>
            </div>
        </div>
    </div>
</main>