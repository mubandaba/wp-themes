<main class="py-4 py-md-5">
    <div class="container">
        <?php if (!empty(cosy19_get_head_img(get_the_ID()))): ?>
            <div class="post-cover">
                <div class="d-flex flex-fill bg-img bg-dark text-center h-v-33" style="background-image: url('<?php echo cosy19_get_head_img(get_the_ID(), array('w' => 1200, 'h' => 300)) ?>');">
                    <div class="d-flex flex-fill flex-column align-items-center bg-dark-overlay py-5">
                        <div class="m-auto p-4">
                            <h1 class="h3 text-white"><?php the_title() ?></h1>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <div class="row justify-content-lg-center">
            <div class="col-12 col-lg-10 px-lg-5">
                <div class="post">
                    <?php get_template_part('template-parts/post-meta') ?>
                    <div class="content-style content">
                        <?php the_content() ?>
                    </div>
                    <?php get_template_part('template-parts/ad/single-ad'); ?>
                    <div class="post-tags mt-3 mt-md-4">
                        <?php the_tags('', '', '') ?>
                    </div>
                    <?php get_template_part('template-parts/post-copyright') ?>
                    <?php get_template_part('template-parts/post-footer') ?>
                    <?php get_template_part('template-parts/post-nav-link') ?>
                </div>
                <?php
                    if ( comments_open() || get_comments_number() ) :
                        comments_template();
                    endif;
                ?>
            </div>
        </div>
    </div>
</main>