<?php

/*
            /$$
    /$$    /$$$$
   | $$   |_  $$    /$$$$$$$
 /$$$$$$$$  | $$   /$$_____/
|__  $$__/  | $$  |  $$$$$$
   | $$     | $$   \____  $$
   |__/    /$$$$$$ /$$$$$$$/
          |______/|_______/
================================
        Keep calm and get rich.
                    Is the best.

  	@Author: Dami
  	@Date:   2017-12-25 12:50:06
  	@Last Modified by:   Dami
  	@Last Modified time: 2017-12-25 13:23:03
*/

$ding = get_post_meta($post->ID,'suxing_ding',true);
$ding = $ding ? $ding : 0;
$category = get_the_category(get_the_ID());
$insert_post = '
<div class="list-archive list-grid list-grid-padding list-bordered">
    <div class="list-item custom-hover">
        <div class="media media-3x2 col-4 col-md-3">
            <a class="media-content" href="'.get_the_permalink().'" target="_blank" title="'.get_the_title().'">
            <img src="'.timthumb( cosy19_post_thumbnail_src(), array( 'w' => '160', 'h' => '120' ) ).'" alt="'.get_the_title().'" title="'.get_the_title().'">
                <span class="overlay"></span>
            </a>
        </div>
        <div class="list-content py-lg-2">
            <div class="list-body">
                <a href="'.get_the_permalink().'" class="list-title text-md h-2x" target="_blank" title="'.get_the_title().'">'.get_the_title().'</a>
                <div class="list-subtitle text-sm text-muted d-none d-lg-block mt-lg-3"><span class="h-2x">'.cosy19_print_excerpt(60,null,false).'</span></div>
            </div>
            <div class="list-footer d-flex align-items-center text-muted text-xs m-0">
                <div>'.cosy19_timeago() .'</div>
            </div>
        </div>
    </div>
</div>';

return $insert_post;