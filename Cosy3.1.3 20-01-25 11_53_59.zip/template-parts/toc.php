<?php global $post; ?>
<?php $toc = get_field('toc', $post->ID) ?>

<?php if ($toc): ?>
<?php
    $matches = array();
    $tag = get_field('toc_tag', $post->ID);
    $r = "@<h$tag.*?>(.*?)<\/h$tag>@";
?>
    <?php if (preg_match_all($r, $post->post_content, $matches)): ?>
        <section id="widget-toc" class="widget widget_post_subtitle">
            <div class="widget-title">文章目录</div>
            <nav class="list-spy-nav nav" id="links-nav">
            <?php foreach($matches[1] as $index => $title): ?>
                <a class="nav-link js-scroll-trigger <?php echo $index == 0 ? 'active' : '' ?>" href="<?php echo "#toc-$index" ?>" title="<?php echo sanitize_text_field($title) ?>">
                    <span class="nav-dot"></span><span class="nav-content"><span class="h-1x"><?php echo sanitize_text_field($title) ?></span>
                </a>
            <?php endforeach; ?>
            </nav>
        </section>
    <?php endif; ?>
<?php endif; ?>