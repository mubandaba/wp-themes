<?php 
    $bigger_cover = get_field('api_generation_poster', 'option');
    $meta_layout = get_field('meta_layout', 'option');
?>
<div class="post-action pt-5">
    <?php if ($meta_layout['like'] === '1'): ?>
    <div class="post-like text-center">
        <?php $is_liked = isset($_COOKIE['suxing_ding_'.$post->ID]); ?>
        <a href="javascript:" data-action="<?php echo $is_liked ? 'unlike' : 'like' ?>" data-id="<?php the_ID(); ?>" class="<?php if ($is_liked) echo 'current'; ?> post-like btn btn-lg btn-primary"><i class="iconfont icon-yishoucang"></i> <?php _e('Like', 'cosy19') ?><small>(<span class="like-count"><?php echo (int)get_post_meta(get_the_ID(),'suxing_ding',true); ?></span>)</small></a>
    </div>
    <?php endif; ?>
    <div class="post-share <?php if ($bigger_cover == 1) echo 'justify-content-between' ; else echo 'justify-content-center'; ?> mt-4">
        <?php if ($bigger_cover == 1): ?>
            <div class="post-play">
                <!-- <a href="">
                    <i class="text-lg iconfont icon-star-1"></i> 收藏 <small class="text-muted">(123)</small>
                </a>
                <span class="px-3 text-light"> &Iota;</span> -->
                <a class="btn-bigger-cover" id="btn-bigger-cover" href="javascript:;" data-id="<?php the_ID(); ?>">
                    <i class="text-lg iconfont icon-daochu"></i> 海报
                </a>
            </div>
        <?php endif; ?>
        <?php get_template_part('template-parts/post-share-section') ?>
    </div>
</div>