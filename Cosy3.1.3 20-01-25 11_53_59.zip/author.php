<?php
/**
 * The template for displaying archive pages
 *
 * @package Cosy19
 */

global $wp_query;

$tpage = 'author';
$query = get_the_author_meta('ID');

$author = get_queried_object();

$style = get_field('author_style', 'option') ?: 'small';
$meta_layout = get_field('meta_layout', 'option');

$ajax_loading = get_field('archive_ajax_loading', 'option');
if ($style == 'plain') $grid_class = 'list-author list-grid list-grid-padding list-bordered list-tb-padding my-n4';
if ($style == 'medium') $grid_class = 'row-lg list-author list-grouped list-tb-padding';
if ($style == 'small') $grid_class = 'row-md list-author list-grouped list-tb-padding';

get_header();
?>
	<main class="py-4 py-md-5">
		<div class="container">
			<div class="card bg-dark bg-cover rounded mb-4 mb-md-5"  <?php if (!empty(get_field('author_header_bg', 'option'))): ?>style="background-image: url('<?php echo timthumb(get_field('author_header_bg', 'option'), array('w' => 1200, 'h' => 200)) ?>')"<?php endif; ?>>
		      	<div class="bg-dark-overlay rounded">
			        <div class="d-md-flex align-items-md-center">
			         	<div class="position-relative p-5">
			            	<div class="d-flex flex-column flex-md-row justify-content-start">
				               	<span class="avatar w-64">
								   <?php echo get_avatar($author->user_email, 64, '', '', array('class' => '')) ?>
								</span>
			              		<div class="mx-md-3">
			                		<h5 class="text-white mt-3 mt-md-2"><?php echo $author->display_name ?></h5>
			                		<div class="text-white text-sm mt-2 mt-md-0"><span class="h-2x"><?php echo $author->description ?: get_translated_role_name($author->roles[0]) ?></span></div>
			              		</div>
			            	</div>
			         	</div>
			          	<span class="flex-fill"></span>
						<?php if (!in_array('0', $meta_layout)): ?>
			          	<div class="d-flex flex-nowrap align-items-center flex-shrink-0 p-5 mx-n2">
				            <span class="text-white text-md-center p-2">
				                <span class="font-theme text-xl"><?php echo count_user_posts($author->ID) ?></span>
				                <small class="d-md-block text-light">文章</small>
				            </span>
				            <span class="text-white text-md-center p-2">
				                <span class="font-theme text-xl"><?php cosy19_the_author_comment_count($author->ID) ?></span>
				                <small class="d-md-block text-light">评论</small>
				            </span>
				            <span class="text-white text-md-center p-2">
				                <span class="font-theme text-xl"><?php cosy19_the_author_like_count($author->ID) ?></span>
				                <small class="d-md-block text-light">赞</small>
				            </span>
			         	</div>
						<?php endif; ?>
		        	</div>
		      	</div>
			</div>
			<?php if ($style == 'plain'): ?>
				<div class="row justify-content-md-center">
					<div class="col-lg-9">
			<?php endif; ?>
				<?php if ( have_posts() ) : ?>
				<div class="<?php echo $grid_class ?>">
					<?php while ( have_posts() ) : the_post(); ?>
						<?php get_template_part_with_vars("template-parts/post-cards/card-$style", array('type' => is_category() ? 'cat' : '')); ?>
					<?php endwhile; ?>
				</div>
				<?php
					get_template_part_with_vars('template-parts/post-navigation', array(
						'ajax_loading' => $ajax_loading,
						'page' => $tpage,
						'query' => $query,
						'style' => $style,
						'append' => 'list-author'
					));
				?>
				<?php else : ?>
					<div class="content-error h-v-66">
						<?php get_template_part('template-parts/not-found-svg'); ?>
			            <p class="text-lg text-muted mt-5"><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'cosy19' ); ?></p>
			        </div>
				<?php endif; ?>
				<?php get_template_part('template-parts/ad/tax-ad'); ?>
			<?php if ($style == 'plain'): ?>
					</div>
				</div>
			<?php endif; ?>
		</div>
	</main>

<?php
get_footer();