<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
<input type="text" style="width:250px;height:30px;font-size:14px;padding-left:4px;" value="你在找啥?搜搜看..." name="s" id="s" onfocus="this.value = this.value == this.defaultValue ? '' : this.value" onblur="this.value = this.value == '' ? this.defaultValue : this.value">
</form>