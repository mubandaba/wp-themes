<div id="postlist">
	<?php if(have_posts()) : while (have_posts()) : the_post(); ?>
		<div id="post-<?php the_ID(); ?>" class="post-home">
		<div class="post-title"><h1><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h1></div>
		<div class="post-messages"><div class="post-messages-1"><?php the_time('Y.m.d'); ?> / 标签: <?php the_tags('', ', ', ' '); ?> / 分类: <?php the_category(',') ?></div></div>
		<div class="post-messages-2"><?php comments_popup_link('Sofa', '1°', '%°'); ?></div>
		<div class="post-content"><p><?php echo mb_strimwidth(strip_tags(get_the_content('')),0,300,"..."); ?></p><p class="read-more"><a href="<?php the_permalink(); ?>" rel="nofollow">Read More &raquo;</a></p></div>
		</div>
		<?php endwhile; endif; ?>
		<div class="pagenavi"><?php pagenavi(); ?></div>
</div>
