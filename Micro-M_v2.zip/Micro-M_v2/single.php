<?php get_header(); ?>
<div id="wrapper">
<div id="content"><script type="text/javascript">$("#home-loading div").animate({width:"30%"})</script>
	<div id="postlist">
	<?php if(have_posts()) : while (have_posts()) : the_post(); ?>
		<div id="post-<?php the_ID(); ?>" class="post-home">
		<div class="post-title"><h1><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h1></div>
		<div class="post-messages"><div class="post-messages-1"><?php the_time('Y.m.d'); ?> / 标签: <?php the_tags('', ', ', ' '); ?> / 分类: <?php the_category(',') ?></div></div>
		<div class="post-messages-2"><?php comments_popup_link('Sofa', '1°', '%°'); ?></div>
		<div class="post-content"><?php the_content(__('阅读全文')); ?></div>
		</div>
	<?php endwhile; endif; ?>
	<div id="comments"><?php comments_template('', true); ?></div>
	</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>