<?php get_header(); ?>
<div id="wrapper">
<div id="content"><script type="text/javascript">$("#home-loading div").animate({width:"30%"})</script>
	<div id="postlist">
		<div class="post-single">
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<div class="post-title"><h1><?php the_title(); ?></h1></div>
		<div class="post-content"><?php the_content(); ?></div>
		</div>
		<?php endwhile; endif; ?>
		<div id="comments"><?php comments_template('/page-comments.php', true); ?></div>
	</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>