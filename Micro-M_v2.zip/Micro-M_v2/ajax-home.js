function fanye (){
$("#postlist.pagenavi a").click(function() {
			var z = $(this).attr("href");
			$.ajax({
			url: z,
			type:"POST",
			data:"action=ajax_post",
			beforeSend:function(){
			$("#postlist.pagenavi").html('<p class="ajaxloading">载入中</p>');
			},
			success: function (data){
			$("#content").slideUp(300).html(data).slideDown(500,function() {
					$body.animate({
						scrollTop: $(this).offset().top - 100
					},
					500)
				});
			fanye();
			img();
			}			
			});
			return false;
		});
}
fanye();