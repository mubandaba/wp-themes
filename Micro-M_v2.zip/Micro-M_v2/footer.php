<div class="clear"></div>
</div>
</div>
<?php wp_footer(); ?>
<script type="text/javascript">$("#home-loading div").animate({width:"85%"})</script>
<div id="footer">
<div id="inner-footer">
<p style="text-align:center">Copyright © 2012-2013 .<?php bloginfo('name'); ?> All rights reserved. <a href="<?php bloginfo('url'); ?>/sitemap.html" target="_blank">Baidu SiteMap</a>, <a href="<?php bloginfo('url'); ?>/sitemap.xml" target="_blank">Google SiteMap</a>. Theme by <a href="http://www.microhu.cn">Microhu</a>.
</div>
</div>
</div>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/Micro-M.js"></script>
<?php if ( is_singular() ){ ?>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/comments-ajax.js"></script>
<?php } ?>
<script type="text/javascript">$("#home-loading div").animate({width:"100%"})</script>
</body>
</html>