<?php get_header(); ?>
<div id="content">
	<div id="postlist">
		<div class="post-home">
		<div class="post-title"><h1>您撞墙啦！！！</h1></div>
		伟大的404页面的出现也就意味着：你要找的页面不存在了，再搜索看看，说不定还在呢！
		</div>
	</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>