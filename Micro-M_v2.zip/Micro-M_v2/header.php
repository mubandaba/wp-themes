<!DOCTYPE HTML>
<html dir="ltr" lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php if(isset($_COOKIE['comment_author_'.COOKIEHASH])) { $lastCommenter = $_COOKIE['comment_author_'.COOKIEHASH]; echo "«". $lastCommenter ."»欢迎回来! - "; } ?>
<?php if ( is_home() ) { ?><?php bloginfo('name'); ?> - <?php bloginfo('description'); ?><?php } ?>
<?php if ( is_tag() ) { ?><?php single_tag_title(); ?> - <?php bloginfo('name'); ?><?php } ?>
<?php if ( is_category() ) { ?><?php single_cat_title(); ?> - <?php bloginfo('name'); ?><?php } ?>
<?php if ( is_single() || is_page() ) { ?><?php single_post_title(''); ?> - <?php bloginfo('name'); ?><?php } ?>
<?php if ( is_search() ) { ?>“<?php echo $s; ?>”的搜索结果 - <?php bloginfo('name'); ?><?php } ?>
<?php if ( is_404() ) { ?>404页面 - <?php bloginfo('name'); ?><?php } ?>
<?php if ( is_author() ) { ?>文章列表 - <?php bloginfo('name'); ?><?php } ?>
<?php if ( is_month() || is_day() ) { ?><?php the_time('Y - F'); ?> - <?php bloginfo('name'); ?><?php } ?>
</title>
<meta name="keywords" content="<?php if (is_single()) { if (get_post_meta($post->ID, "Meta", true)) echo get_post_meta($post->ID, "Meta", true);} else {echo ('');}?>"/>
<meta name="description" content="<?php if (is_single()) { echo mb_strimwidth(strip_tags(apply_filters('the_content',$post->post_content)),0,220,"...");} else {echo ('');}?>"/>
<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo('stylesheet_url'); ?>" />
<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>"/>
<?php wp_head(); ?>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/jquery.min.1.4.0.js"></script>
</head>
<body>
<div id="container">
<div id="home-loading"><div></div></div>
<div id="header">
<div id="inner-header">
<script type="text/javascript">$("#home-loading div").animate({width:"15%"})</script>
	<div id="logo">
	<a href="<?php echo get_settings('home'); ?>"><?php bloginfo('name'); ?></a>
	<div class="description"><?php bloginfo('description'); ?></div>
	</div>
	<div id="social">
 <?php include (TEMPLATEPATH . '/searchform.php'); ?>
	</div>
</div>
</div>
<div id="navi">
<?php wp_nav_menu(array( 'theme_location'=>'primary','container_id' => 'menu')); ?>
</div>