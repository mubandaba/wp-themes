<div id="sidebar">
<script type="text/javascript">$("#home-loading div").animate({width:"70%"})</script>
<?php if (is_home()) { ?>
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>
	<?php endif; ?>
<?php } elseif( is_single() ) { ?>
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar(2) ) : ?>
	<?php endif; ?>
<?php } else { ?>
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar(3) ) : ?>
	<?php endif; ?>
<?php } ?>
</div>