<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<footer class="main-footer sticky footer-type-1">
                <div class="footer-inner">
                    <div class="footer-text">
                        &copy; <?php echo date('Y'); ?>
                        Design by <a href="http://webstack.cc" target="_blank"><strong>Webstack</strong></a>&nbsp;&nbsp;&nbsp;&nbsp;Modify by <a href="https://www.seogo.me" target="_blank"><strong>Seogo</strong></a>
                    </div>
                    <div class="go-up">
                        <a href="#" rel="go-top">
                            <i class="fa-angle-up"></i>
                        </a>
                    </div>
                </div>
            </footer>
        </div>
</div>
<?php if ($this->is('index')): ?>
    <script type="text/javascript">
    var href = "";
    var pos = 0;
    $("a.smooth").click(function(e) {
        $("#main-menu li").each(function() {
            $(this).removeClass("active");
        });
        $(this).parent("li").addClass("active");
        e.preventDefault();
        href = $(this).attr("href");
        pos = $(href).position().top - 30;
        $("html,body").animate({
            scrollTop: pos
        }, 500);
    });
    </script>
<?php endif; ?>
    <script src="<?php $this->options->themeUrl('js/bootstrap.min.js'); ?>"></script>
    <script src="<?php $this->options->themeUrl('js/TweenMax.min.js'); ?>"></script>
    <script src="<?php $this->options->themeUrl('js/resizeable.js'); ?>"></script>
    <script src="<?php $this->options->themeUrl('js/joinable.js'); ?>"></script>
    <script src="<?php $this->options->themeUrl('js/xenon-api.js'); ?>"></script>
    <script src="<?php $this->options->themeUrl('js/xenon-toggles.js'); ?>"></script>
    <script src="<?php $this->options->themeUrl('js/xenon-custom.js'); ?>"></script>
</body>
</html>