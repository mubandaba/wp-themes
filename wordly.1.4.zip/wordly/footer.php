<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package wordly
 */

?>
</div>
</div><!-- #content -->

<footer id="colophon" class="site-footer clearfix">

	<div class="content-wrap">
		<?php if ( is_active_sidebar( 'footerwidget-1' ) ) : ?>
		<div class="footer-column-wrapper">
			<div class="footer-column-three footer-column-left">
				<?php dynamic_sidebar( 'footerwidget-1' ); ?>
			</div>
		<?php endif; ?>

		<?php if ( is_active_sidebar( 'footerwidget-2' ) ) : ?>
		<div class="footer-column-three footer-column-middle">
			<?php dynamic_sidebar( 'footerwidget-2' ); ?>
		</div>
	<?php endif; ?>

	<?php if ( is_active_sidebar( 'footerwidget-3' ) ) : ?>
	<div class="footer-column-three footer-column-right">
		<?php dynamic_sidebar( 'footerwidget-3' ); ?>				
	</div>
<?php endif; ?>

</div>

<div class="site-info">
	&copy;<?php echo date_i18n( _x( 'Y', 'copyright date format; check date() on php.net', 'wordly' ) ) ?> <?php bloginfo( 'name' ); ?>
	<!-- Delete below lines to remove copyright from footer -->
	<span class="footer-info-right">
		<?php echo esc_html_e(' | Theme:', 'wordly') ?> <a href="<?php echo esc_url( __( 'https://superbthemes.com/wordly/', 'wordly' ) ); ?>"><?php echo esc_html_e(' Wordly', 'wordly') ?></a> <?php echo esc_html_e(' by SuperbThemes', 'wordly') ?> 
	</span>
	<!-- Delete above lines to remove copyright from footer -->
</div>
</div>



</footer><!-- #colophon -->
</div><!-- #page -->

<div id="smobile-menu" class="mobile-only"></div>
<div id="mobile-menu-overlay"></div>

<?php wp_footer(); ?>
</body>
</html>
