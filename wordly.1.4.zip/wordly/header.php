<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package wordly
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<?php wp_body_open(); ?>
	<a class="skip-link screen-reader-text" href="#content"><?php _e( 'Skip to content', 'wordly' ); ?></a>

	<div id="page" class="site">

		<header id="masthead" class="sheader site-header clearfix">
			<nav id="primary-site-navigation" class="primary-menu main-navigation clearfix">

				<a href="#" id="pull" class="smenu-hide toggle-mobile-menu menu-toggle" aria-controls="secondary-menu" aria-expanded="false"><?php esc_html_e( 'Menu', 'wordly' ); ?></a>

				<div class="top-nav-wrapper">
					<div class="content-wrap">
						<div class="logo-container"> 
							<?php if ( has_custom_logo() ) : ?>
								<?php the_custom_logo(); ?>
								<?php else : ?>
									<a class="logofont" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
								<?php endif; ?>
							</div>
							<div class="center-main-menu">
								<?php
								wp_nav_menu( array(
									'theme_location'	=> 'menu-1',
									'menu_id'			=> 'primary-menu',
									'menu_class'		=> 'pmenu'
								) );
								?>
							</div>
						</div>
					</div>
				</nav>

				<div class="super-menu clearfix">
					<div class="super-menu-inner">
						<?php if ( has_custom_logo() ) : ?>
							<?php the_custom_logo(); ?>
							<?php else : ?>
								<a class="logofont" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
							<?php endif; ?>
						</a>
						<a href="#" id="pull" class="toggle-mobile-menu menu-toggle" aria-controls="secondary-menu" aria-expanded="false"></a>
					</div>
				</div>
				<div id="mobile-menu-overlay"></div>


				<!-- Header content start -->
				<?php
				$pages = array();
				for ( $count = 1; $count <= 5; $count++ ) {
					$mod = get_theme_mod( 'showcase-page-' . $count );
					if ( 'page-none-selected' != $mod ) {
						$pages[] = $mod;
					}
				}
				$args = array(
					'posts_per_page' => 1,
					'post_type' => 'page',
					'post__in' => $pages,
					'orderby' => 'post__in'
				);
				$query = new WP_Query( $args );
				if ( $query->have_posts() ) :
					$count = 1;
					while ( $query->have_posts() ) : $query->the_post();
						?>
						<div <?php post_class( 'featured-' . $count ); ?>>
							<!-- Page content stuff end -->
							<?php if ( is_front_page() ) : ?>
								<!-- Header img -->
								<div class="header-content-wrap-outer">
									<div class="header-content-wrap">
										<div class="bottom-header-title"><?php the_title(); ?></div>
										<div class="bottom-header-paragraph"> <?php esc_html_e('Written', 'wordly') ?> <?php echo get_the_date(); ?></div>
										<!-- Button-->
										<div class="buttons-wrapper">
											<a href="<?php the_permalink() ?>" class="header-button-solid"><?php esc_html_e('READ MORE', 'wordly') ?></a>
										</div>
										<!--Buttons -->
									</div>
								</div>
							<?php endif; ?>
							<!-- / Header img -->
							<!-- Header content end -->
							<!-- Page content stuff start -->
						</div>
						<?php
						$count++;
					endwhile;
				endif;
				wp_reset_postdata();
				?>
				<!-- Page content stuff end -->
				<!-- Header bg start-->
			</header>



			<div id="content" class="site-content clearfix">
				<div class="content-wrap">
