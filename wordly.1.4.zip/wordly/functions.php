<?php
/**
 * wordly functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package wordly
 */


if ( ! function_exists( 'wordly_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */

function wordly_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on wordly, use a find and replace
		 * to change 'wordly' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'wordly', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );
		set_post_thumbnail_size( 300 );

		add_image_size( 'wordly-grid', 350 , 230, true );
		add_image_size( 'wordly-slider', 850 );
		add_image_size( 'wordly-small', 300 , 180, true );


		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'menu-1'	=> esc_html__( 'Primary', 'wordly' ),
			) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'wordly_custom_background_args', array(
			'default-color' => '#f1f1f1',
			'default-image' => '',
			'default-image' => '',
			) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'flex-width'  => true,
			'flex-height' => true,
			) );
	}
	endif;
	add_action( 'after_setup_theme', 'wordly_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function wordly_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'wordly_content_width', 640 );
}
add_action( 'after_setup_theme', 'wordly_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function wordly_widgets_init() {

	register_sidebar( array(
		'name'          => esc_html__( 'Footer Widget (1)', 'wordly' ),
		'id'            => 'footerwidget-1',
		'description'   => esc_html__( 'Add widgets here.', 'wordly' ),
		'before_widget' => '<section id="%1$s" class="fbox widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<div class="swidget"><h3 class="widget-title">',
		'after_title'   => '</h3></div>',
		) );

	register_sidebar( array(
		'name'          => esc_html__( 'Footer Widget (2)', 'wordly' ),
		'id'            => 'footerwidget-2',
		'description'   => esc_html__( 'Add widgets here.', 'wordly' ),
		'before_widget' => '<section id="%1$s" class="fbox widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<div class="swidget"><h3 class="widget-title">',
		'after_title'   => '</h3></div>',
		) );

	register_sidebar( array(
		'name'          => esc_html__( 'Footer Widget (3)', 'wordly' ),
		'id'            => 'footerwidget-3',
		'description'   => esc_html__( 'Add widgets here.', 'wordly' ),
		'before_widget' => '<section id="%1$s" class="fbox widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<div class="swidget"><h3 class="widget-title">',
		'after_title'   => '</h3></div>',
		) );
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'wordly' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'wordly' ),
		'before_widget' => '<section id="%1$s" class="fbox swidgets-wrap widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<div class="sidebar-headline-wrapper"><div class="sidebarlines-wrapper"><div class="widget-title-lines"></div></div><h4 class="widget-title">',
		'after_title'   => '</h4></div>',
		) );
	
}




add_action( 'widgets_init', 'wordly_widgets_init' );


/**
 * Enqueue scripts and styles.
 */
function wordly_scripts() {
	wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/css/font-awesome.min.css' );
	wp_enqueue_style( 'wordly-style', get_stylesheet_uri() );
	wp_enqueue_script( 'wordly-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20170823', true );
	wp_enqueue_script( 'wordly-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20170823', true );	
	wp_enqueue_script( 'wordly-flex-slider', get_template_directory_uri() . '/js/jquery.flexslider.js', array('jquery'), '20150423', true );
	wp_enqueue_script( 'wordly-script', get_template_directory_uri() . '/js/script.js', array(), '20160720', true );
	wp_enqueue_script( 'wordly-accessibility', get_template_directory_uri() . '/js/accessibility.js', array(), '20160720', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'wordly_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}

/**
 * Google fonts, credits can be found in readme.
 */

function wordly_google_fonts() {

	wp_enqueue_style( 'wordly-google-fonts', '//fonts.googleapis.com/css?family=Lato:300,400,700', false ); 
}

add_action( 'wp_enqueue_scripts', 'wordly_google_fonts' );


/**
 * Dots after excerpt
 */

function new_excerpt_more( $more ) {
	if ( is_admin() ) return $more;
	return '...';
}
add_filter('excerpt_more', 'new_excerpt_more');



/**
 * Blog Pagination 
 */
if ( !function_exists( 'wordly_numeric_posts_nav' ) ) {
	
	function wordly_numeric_posts_nav() {
		
		global $wp_query;
		$total = $wp_query->max_num_pages;
		$big = 999999999; // need an unlikely integer
		if( $total > 1 )  {
			if( !$current_page = get_query_var('paged') )
				$current_page = 1;
			if( get_option('permalink_structure') ) {
				$format = 'page/%#%/';
			} else {
				$format = '&paged=%#%';
			}
			echo wp_kses_post(paginate_links(array(
				'base'			=> str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
				'format'		=> $format,
				'current'		=> max( 1, get_query_var('paged') ),
				'total' 		=> $total,
				'mid_size'		=> 3,
				'type' 			=> 'list',
				'prev_text'		=> 'Previous',
				'next_text'		=> 'Next',
				) ));
		}
	}
	
}



/**
 * Fix skip link focus in IE11.
 *
 * This does not enqueue the script because it is tiny and because it is only for IE11,
 * thus it does not warrant having an entire dedicated blocking script being loaded.
 *
 * @link https://git.io/vWdr2
 */
function wordly_skip_link_focus_fix() {
	// The following is minified via `terser --compress --mangle -- js/skip-link-focus-fix.js`.
	?>
	<script>
	/(trident|msie)/i.test(navigator.userAgent)&&document.getElementById&&window.addEventListener&&window.addEventListener("hashchange",function(){var t,e=location.hash.substring(1);/^[A-z0-9_-]+$/.test(e)&&(t=document.getElementById(e))&&(/^(?:a|select|input|button|textarea)$/i.test(t.tagName)||(t.tabIndex=-1),t.focus())},!1);
	</script>
<?php
}
add_action( 'wp_print_footer_scripts', 'wordly_skip_link_focus_fix' );


/**
 * Copyright and License for Upsell button by Justin Tadlock - 2016-2019 © Justin Tadlock. customizer button https://github.com/justintadlock/trt-customizer-pro
 */
require_once( trailingslashit( get_template_directory() ) . 'justinadlock-customizer-button/class-customize.php' );


/**
 * Compare page CSS
 */

function wordly_comparepage_css($hook) {
	if ( 'appearance_page_wordly-info' != $hook ) {
		return;
	}
	wp_enqueue_style( 'wordly-custom-style', get_template_directory_uri() . '/css/compare.css' );
}
add_action( 'admin_enqueue_scripts', 'wordly_comparepage_css' );

/**
 * Compare page content
 */

add_action('admin_menu', 'wordly_themepage');
function wordly_themepage(){
	$theme_info = add_theme_page( __('Wordly Info','wordly'), __('Wordly Info','wordly'), 'manage_options', 'wordly-info.php', 'wordly_info_page' );
}

function wordly_info_page() {
	$user = wp_get_current_user();
	?>
	<div class="wrap about-wrap wordly-add-css">
		<div>
			<h1>
<?php echo esc_html_e('Welcome to Wordly!','wordly'); ?>
			</h1>

			<div class="feature-section three-col">
				<div class="col">
					<div class="widgets-holder-wrap">
						<h3><?php echo esc_html_e("Contact Support", "wordly"); ?></h3>
						<p><?php echo esc_html_e("Getting started with a new theme can be difficult, if you have issues with Wordly then throw us an email.", "wordly"); ?></p>
						<p><a target="blank" href="https://superbthemes.com/help-contact/" class="button button-primary">
<?php echo esc_html_e("Contact Support", "wordly"); ?>
						</a></p>
					</div>
				</div>
				<div class="col">
					<div class="widgets-holder-wrap">
						<h3><?php echo esc_html_e("View our other themes", "wordly"); ?></h3>
						<p><?php echo esc_html_e("Do you like our concept but feel like the design doesn't fit your need? Then check out our website for more designs.", "wordly"); ?></p>
						<p><a target="blank" href="https://superbthemes.com/wordpress-themes/" class="button button-primary">
<?php echo esc_html_e("View All Themes", "wordly"); ?>
						</a></p>
					</div>
				</div>
				<div class="col">
					<div class="widgets-holder-wrap">
						<h3><?php echo esc_html_e("Premium Edition", "wordly"); ?></h3>
						<p><?php echo esc_html_e("If you enjoy Wordly and want to take your website to the next step, then check out our premium edition here.", "wordly"); ?></p>
						<p><a target="blank" href="https://superbthemes.com/wordly/" class="button button-primary">
<?php echo esc_html_e("Read More", "wordly"); ?>
						</a></p>
					</div>
				</div>
			</div>
		</div>
		<hr>

		<h2><?php echo esc_html_e("Free Vs Premium","wordly"); ?></h2>
		<div class="wordly-button-container">
			<a target="blank" href="https://superbthemes.com/wordly/" class="button button-primary">
<?php echo esc_html_e("Read Full Description", "wordly"); ?>
			</a>
			<a target="blank" href="https://superbthemes.com/demo/wordly/" class="button button-primary">
<?php echo esc_html_e("View Theme Demo", "wordly"); ?>
			</a>
		</div>


		<table class="wp-list-table widefat">
			<thead>
				<tr>
					<th><strong><?php echo esc_html_e("Theme Feature", "wordly"); ?></strong></th>
					<th><strong><?php echo esc_html_e("Basic Version", "wordly"); ?></strong></th>
					<th><strong><?php echo esc_html_e("Premium Version", "wordly"); ?></strong></th>
				</tr>
			</thead>

			<tbody>
				<tr>
					<td><?php echo esc_html_e("Header Background Color", "wordly"); ?></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
				</tr>
				<tr>
					<td><?php echo esc_html_e("Custom Navigation Logo Or Text", "wordly"); ?></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
				</tr>
				<tr>
					<td><?php echo esc_html_e("Hide Logo Text", "wordly"); ?></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
				</tr>

				<tr>
					<td><?php echo esc_html_e("Premium Support", "wordly"); ?></td>
					<td><span class="cross"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/cross.png' ); ?>" alt="<?php echo esc_attr("No", "wordly"); ?>" /></span></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
				</tr>
				<tr>
					<td><?php echo esc_html_e("Recent Posts Widget", "wordly"); ?></td>
					<td><span class="cross"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/cross.png' ); ?>" alt="<?php echo esc_attr("No", "wordly"); ?>" /></span></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
				</tr>
				<tr>
					<td><?php echo esc_html_e("Easy Google Fonts", "wordly"); ?></td>
					<td><span class="cross"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/cross.png' ); ?>" alt="<?php echo esc_attr("No", "wordly"); ?>" /></span></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
				</tr>
				<tr>
					<td><?php echo esc_html_e("Pagespeed Plugin", "wordly"); ?></td>
					<td><span class="cross"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/cross.png' ); ?>" alt="<?php echo esc_attr("No", "wordly"); ?>" /></span></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
				</tr>

				<tr>
					<td><?php echo esc_html_e("Only Show Header on Front Page", "wordly"); ?></td>
					<td><span class="cross"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/cross.png' ); ?>" alt="<?php echo esc_attr("No", "wordly"); ?>" /></span></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
				</tr>
				<tr>
					<td><?php echo esc_html_e("Show Header On All Pages", "wordly"); ?></td>
					<td><span class="cross"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/cross.png' ); ?>" alt="<?php echo esc_attr("No", "wordly"); ?>" /></span></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
				</tr>
				<tr>
					<td><?php echo esc_html_e("Custom Header Padding", "wordly"); ?></td>
					<td><span class="cross"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/cross.png' ); ?>" alt="<?php echo esc_attr("No", "wordly"); ?>" /></span></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
				</tr>
				<tr>
					<td><?php echo esc_html_e("Custom Header Title & Tagline", "wordly"); ?></td>
					<td><span class="cross"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/cross.png' ); ?>" alt="<?php echo esc_attr("No", "wordly"); ?>" /></span></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
				</tr>
				<tr>
					<td><?php echo esc_html_e("Custom Header Button, Text & Link", "wordly"); ?></td>
					<td><span class="cross"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/cross.png' ); ?>" alt="<?php echo esc_attr("No", "wordly"); ?>" /></span></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
				</tr>
				<tr>
					<td><?php echo esc_html_e("Only Show Header Background Image On Front Page", "wordly"); ?></td>
					<td><span class="cross"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/cross.png' ); ?>" alt="<?php echo esc_attr("No", "wordly"); ?>" /></span></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
				</tr>
				<tr>
					<td><?php echo esc_html_e("Show Header Background Image On All Pages But Not Text", "wordly"); ?></td>
					<td><span class="cross"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/cross.png' ); ?>" alt="<?php echo esc_attr("No", "wordly"); ?>" /></span></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
				</tr>
				<tr>
					<td><?php echo esc_html_e("Custom Text On Header Image", "wordly"); ?></td>
					<td><span class="cross"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/cross.png' ); ?>" alt="<?php echo esc_attr("No", "wordly"); ?>" /></span></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
				</tr>
				<tr>
					<td><?php echo esc_html_e("Custom Button Text/Link On Header Image", "wordly"); ?></td>
					<td><span class="cross"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/cross.png' ); ?>" alt="<?php echo esc_attr("No", "wordly"); ?>" /></span></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
				</tr>
				<tr>
					<td><?php echo esc_html_e("Only Show Upper Widgets On Front Page", "wordly"); ?></td>
					<td><span class="cross"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/cross.png' ); ?>" alt="<?php echo esc_attr("No", "wordly"); ?>" /></span></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
				</tr>
				<tr>
					<td><?php echo esc_html_e("Lower Image Resolution To Increase Website Performance", "wordly"); ?></td>
					<td><span class="cross"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/cross.png' ); ?>" alt="<?php echo esc_attr("No", "wordly"); ?>" /></span></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
				</tr>
				<tr>
					<td><?php echo esc_html_e("Replace Copyright Text", "wordly"); ?></td>
					<td><span class="cross"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/cross.png' ); ?>" alt="<?php echo esc_attr("No", "wordly"); ?>" /></span></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
				</tr>
				<tr>
					<td><?php echo esc_html_e("Customize Background Color", "wordly"); ?></td>
					<td><span class="cross"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/cross.png' ); ?>" alt="<?php echo esc_attr("No", "wordly"); ?>" /></span></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
				</tr>
				<tr>
					<td><?php echo esc_html_e("Customize Navigation Color", "wordly"); ?></td>
					<td><span class="cross"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/cross.png' ); ?>" alt="<?php echo esc_attr("No", "wordly"); ?>" /></span></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
				</tr>
				<tr>
					<td><?php echo esc_html_e("Customize Header Colors", "wordly"); ?></td>
					<td><span class="cross"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/cross.png' ); ?>" alt="<?php echo esc_attr("No", "wordly"); ?>" /></span></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
				</tr>
				<tr>
					<td><?php echo esc_html_e("Customize Post/Page Color", "wordly"); ?></td>
					<td><span class="cross"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/cross.png' ); ?>" alt="<?php echo esc_attr("No", "wordly"); ?>" /></span></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
				</tr>
				<tr>
					<td><?php echo esc_html_e("Customize Blog Feed Color", "wordly"); ?></td>
					<td><span class="cross"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/cross.png' ); ?>" alt="<?php echo esc_attr("No", "wordly"); ?>" /></span></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
				</tr>
				<tr>
					<td><?php echo esc_html_e("Customize Sidebar Color", "wordly"); ?></td>
					<td><span class="cross"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/cross.png' ); ?>" alt="<?php echo esc_attr("No", "wordly"); ?>" /></span></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
				</tr>
				<tr>
					<td><?php echo esc_html_e("Customize Background Color", "wordly"); ?></td>
					<td><span class="cross"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/cross.png' ); ?>" alt="<?php echo esc_attr("No", "wordly"); ?>" /></span></td>
					<td><span class="checkmark"><img src="<?php echo esc_url( get_template_directory_uri() . '/icons/check.png' ); ?>" alt="<?php echo esc_attr("Yes", "wordly"); ?>" /></span></td>
				</tr>
			</tbody>
		</table>

	</div>
<?php
}








