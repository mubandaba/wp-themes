<?php
/*
	Template Name:5=读者墙
*/

/*
	说明：
	1、如果博客中的注册会员和未注册会员的email信息一致，那么会导致统计偏差
	显示的数据将小于实际数据
	2、如果手动删除了mysql中的会员数据，那么也会导致统计偏差
	显示的数据将小于实际数据
	3、以评论email的最后一条评论信息基准
	4、排序是以email的统计为准，但显示的数据是以上3条为准，所以你懂得
	5、读者墙对数据的查询消耗非常大，所以建议您控制显示的数量
	5、最后更新：2013年1月19日23:11:25
	6、使用范围：yundanran-2 主题
*/



$GLOBALS['yundanran_onlypage']=1;


global $wpdb;

$admin_email=get_bloginfo('admin_email');
$limit=1;

/*
	感谢sql作者 邹磊
	2013年1月21日22:45:36
*/
$sql="select a.*,c.row from $wpdb->comments as a right join
(
	select max(comment_ID) as maxid,comment_author_email from $wpdb->comments group by comment_author_email
)
as b on a.comment_ID=b.maxid left join 
(
	select count(comment_ID)as row,comment_author_email from $wpdb->comments group by comment_author_email
)
as c on a.comment_author_email =c.comment_author_email order by c.row desc limit 21";

$comments = $wpdb->get_results($sql);

?>
<?php 
get_header();?>

<div id="BODY" class="layout readers-wall main">
	<h1>读者墙</h1>
	
<?php
	
	
	$html='<ul class="content float">';
	foreach ($comments as $comment)
	{
		$avatar = yundanran_avatar_cache(get_avatar( $comment->comment_author_email,100));
		
		$user_email=$comment->comment_author_email;

		$last_comment_content	=yundanran_face2html($comment->comment_content);
		$last_comment_href		=get_permalink($comment->comment_post_ID).'#comments';
		$last_comment_time		=$comment->comment_date;
		$last_comment_timeago	=yundanran_time_ago(strtotime($last_comment_time));
		$comment_count			=$comment->row;
		$comment_author_text	=$comment->comment_author;
		$comment_level			=yundanran_comment_level($comment_count);
		$comment_level_desc 	=yundanran_comment_level_desc($comment_level);

		$deg1=rand(1,10);
		$deg2=rand(1,10);
		$deg=$deg1-$deg2;
		$transform='transform:rotate('.$deg.'deg);-webkit-transform:rotate('.$deg.'deg);-moz-transform:rotate('.$deg.'deg);-o-transform:rotate('.$deg.'deg);';
		
		$html.='
		<li style="">
			<div class="img author left">
				'.$avatar.'
				<p class="level">'.yundanran_comment_level_html($comment_level).$comment_level_desc.'</p>
				<p class="clear"></p>
			</div>
			<div class="info right">
				<div class="wrap">
					<p class="line line-1"><b>'.$comment_author_text.'</b>最近说：</p>
					<p class="line line-2"><span>'.$last_comment_content.'</span></p>
					<p class="line line-3">
						<span class="time" title="评论/回复于：'.$last_comment_time.'">'.$last_comment_timeago.'</span>
					</p>
					<p class="line line-4">
						<span class="count">共'.$comment_count.'条评论</span>
						<a class="read" href="'.$last_comment_href.'" title="查看评论详情»">[评论详情]</a>
					</p>
				</div>
			</div>
		</li>';
	}
	$html.='</ul>';
	echo $html;
	?>
	<div class="clear"></div>
</div>
<link rel="stylesheet" href="<?=bloginfo('template_url')?>/public/style/diy-readerswall.css?v=2012-12-30 21:02:06">
<?php 
get_footer(); ?>
