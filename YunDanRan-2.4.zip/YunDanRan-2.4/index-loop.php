<?php
global $wp_query, $wp_rewrite;
// $args = array_merge( $wp_query->query_vars, array( 'post_type' => array('blabla','images','post') ) );
// query_posts( $args );
$comment_author=isset($_COOKIE["comment_author_".COOKIEHASH])?esc_attr($_COOKIE["comment_author_".COOKIEHASH]):'';
$comment_author_email=isset($_COOKIE["comment_author_email_".COOKIEHASH])?esc_attr($_COOKIE["comment_author_email_".COOKIEHASH]):'';
$comment_author_url=isset($_COOKIE["comment_author_url_".COOKIEHASH])?esc_attr($_COOKIE["comment_author_url_".COOKIEHASH]):'';
?>
<?php if (have_posts()) : while (have_posts()) : the_post();
	$post_id 		=get_the_ID();
	$title 			=get_the_title();
	$title_attr		=esc_attr(strip_tags($title));
	$link 			=get_permalink();
	$author_id		=$post->post_author;
	$author_email	=get_userdata($author_id)->user_email;
	$author_name 	=get_the_author();
	$author_url		=get_author_posts_url(get_the_author_meta( 'ID' ));
	$time			=get_the_time('Y年m月d日 H:i:s',$post);
	$time_ago		=yundanran_time_ago(strtotime(get_the_time('YmdHis',$post)));
	$views 			=yundanran_getPostViews($post_id);
	$comments_link	=get_comments_link();
	$comments_num 	=get_comments_number();
	$summary 		=yundanran_set_reply2view(yundanran_content_summary(get_the_excerpt(),300,'<span class="end">[...全文未完]</span>'),$post_id);
	$content		=yundanran_set_reply2view(yundanran_the_content(),$post_id);
	$post_class_arr	=get_post_class($post_id);
	$post_class		="$post_class_arr[0] $post_class_arr[2] $post_class_arr[3] $post_class_arr[4]";
	$post_type		=get_post_type($post_id);
	$post_format	=get_post_format($post_id)?get_post_format($post_id):'standard';
	$is_sticky		=is_sticky($post_id);
	$is_new			=time()-strtotime(get_the_time('YmdHis',$post))<=3*24*60*60?true:false;
	$new_html		=$is_new?'<span class="new">new!</span>':'';
	/*
	文章格式： 
	标准（standard）- 文章
	日志（aside） - 典型样式就是没有标题。类似于 Facebook 或人人网中更新的一条日志。
	相册（gallery） - 图像陈列厅。文章中通常会有“gallery”代码和相应的图像附件。
	链接（link） - 链接到其它网站的链接。主题可能会使用文章中的第一个 <a href=""> 标签作为文章的外部链接。有可能有的文章至包含一个 URL，那么这个 URL 将会被使用；同时，文章标题（post_title）将会是附加到它的锚的名称。
	图像（image） - 单张图像。文章中的首个 <img /> 标记将会被认为是该图片。另外，如果文章只包含一个 URL 链接，则被认为是该图片的 URL 地址，而文章标题（post_title）将会作为图片的标题属性。
	引语（quote） - 引用他人的一段话。通常使用 blockquote 来包裹引用内容。或者，可能直接将引语写入文章，并将其出处写在标题栏。
	状态（status） - 简短更新，通常最多 140 个字符。类似于微博 Twitter 状态消息。
	视频（video） - 单一视频。文章中第一个 <video /> 或 object 或 embed 将被作为视频处理。或者，文章可以仅包含视频的 URL，甚至一些主题和插件可以支持自动嵌入您的文章附件中的视频。
	音频（audio） - 一个音频文件。可以用于播客（podcasting）等。
	聊天（chat） - 聊天记录
	*/
?>

<!-- article <?=$post_id?> 开始 -->
<article class="article index-article <?=$post_class?>" id="article-<?=$post_id?>">
	<div class="format-icon" title="<?=yundanran_get_post_format($post_id);?>"></div>
	<div class="wrap">
		<?php if($post_format=='aside'): ?>
		<!-- //post_format:aside -->
		<div class="clear"></div>
		<div class="body float">
			<div class="author-avatar"><?=yundanran_avatar_cache(get_avatar($author_email,60));?></div>
			<div class="text">
				<?=$new_html?><?=$content?>
				<p class="follow"><a href="<?=$link?>" title="碎碎念：《<?=$title?>》">follow碎碎念»</a></p>
			</div>
		</div>
		<div class="clear"></div>
		<div class="meta">
			<p class="author" title="文章作者：<?=$author_name?>"><i></i><span><?php the_author_posts_link();?><?php edit_post_link('(再编辑&raquo;)', '', ''); ?></span></p>
			<p class="time" title="发布时间：<?=$time?>"><i></i><span><?=$time_ago?></span></p>
			<p class="view" title="浏览次数：<?=$views?>"><i></i><span><?=$views?></span></p>
			<p class="comment"><a href="<?=$comments_link?>" title="评论条数：<?=$comments_num?>"><i></i><span><?=$comments_num?></span></a></p>
			<p class="copy" data-title="<?=$title?>" data-link="<?=$link?>"><i></i><span>复制标题、链接</span></p>
			<div class="message"><!-- 这里显示消息的内容！ --></div>
			<a class="quick-toggle" title="快捷评论（一句话点评）" href="#"></a>
		</div>
		<!-- //post_format:aside -->
		
		
		
		<?php elseif($post_format=='video'): ?>
		<!-- //post_format:video -->
		<h2 class="title"><?=$new_html?><a href="<?=$link?>" title="《<?=$title_attr?>》" data-post_id="<?=$post_id?>"><?=$title?></a></h2>
		<div class="clear"></div>
		<div class="body float">
			<div class="text"><?=$content?></div>
		</div>
		<div class="clear"></div>
		<div class="meta">
			<p class="author" title="文章作者：<?=$author_name?>"><i></i><span><?php the_author_posts_link();?><?php edit_post_link('(再编辑&raquo;)', '', ''); ?></span></p>
			<p class="time" title="发布时间：<?=$time?>"><i></i><span><?=$time_ago?></span></p>
			<p class="view" title="浏览次数：<?=$views?>"><i></i><span><?=$views?></span></p>
			<p class="comment"><a href="<?=$comments_link?>" title="评论条数：<?=$comments_num?>"><i></i><span><?=$comments_num?></span></a></p>
			<p class="copy" data-title="<?=$title?>" data-link="<?=$link?>"><i></i><span>复制标题、链接</span></p>
			<div class="message"><!-- 这里显示消息的内容！ --></div>
			<a class="quick-toggle" title="快捷评论（一句话点评）" href="#"></a>
		</div>
		<!-- //post_format:video -->
		
		
		
		<?php elseif($post_format=='image'): ?>
		<!-- //post_format:image -->
		<h2 class="title"><?=$new_html?><a href="<?=$link?>" title="《<?=$title_attr?>》" data-post_id="<?=$post_id?>"><?=$title?></a></h2>
		<div class="clear"></div>
		<div class="body float">
			<div class="text"><?=yundanran_get_post_1stimg($post_id);?></div>
		</div>
		<div class="clear"></div>
		<div class="meta">
			<p class="author" title="文章作者：<?=$author_name?>"><i></i><span><?php the_author_posts_link();?><?php edit_post_link('(再编辑&raquo;)', '', ''); ?></span></p>
			<p class="time" title="发布时间：<?=$time?>"><i></i><span><?=$time_ago?></span></p>
			<p class="view" title="浏览次数：<?=$views?>"><i></i><span><?=$views?></span></p>
			<p class="comment"><a href="<?=$comments_link?>" title="评论条数：<?=$comments_num?>"><i></i><span><?=$comments_num?></span></a></p>
			<p class="copy" data-title="<?=$title?>" data-link="<?=$link?>"><i></i><span>复制标题、链接</span></p>
			<div class="message"><!-- 这里显示消息的内容！ --></div>
			<a class="quick-toggle" title="快捷评论（一句话点评）" href="#"></a>
		</div>
		<!-- //post_format:image -->
		
		
		
		<?php elseif($post_format=='gallery'): ?>
		<!-- //post_format:gallery -->
		<h2 class="title"><?=$new_html?><a href="<?=$link?>" title="《<?=$title_attr?>》" data-post_id="<?=$post_id?>"><?=$title?></a></h2>
		<div class="clear"></div>
		<div class="body float">
			<div class="text"><?=$content?></div>
		</div>
		<div class="clear"></div>
		<div class="meta">
			<p class="author" title="文章作者：<?=$author_name?>"><i></i><span><?php the_author_posts_link();?><?php edit_post_link('(再编辑&raquo;)', '', ''); ?></span></p>
			<p class="time" title="发布时间：<?=$time?>"><i></i><span><?=$time_ago?></span></p>
			<p class="view" title="浏览次数：<?=$views?>"><i></i><span><?=$views?></span></p>
			<p class="comment"><a href="<?=$comments_link?>" title="评论条数：<?=$comments_num?>"><i></i><span><?=$comments_num?></span></a></p>
			<p class="copy" data-title="<?=$title?>" data-link="<?=$link?>"><i></i><span>复制标题、链接</span></p>
			<div class="message"><!-- 这里显示消息的内容！ --></div>
			<a class="quick-toggle" title="快捷评论（一句话点评）" href="#"></a>
		</div>
		<!-- //post_format:gallery -->




		<?php else:?>
		<!-- //post_format:standard -->
		<h2 class="title">
			<?=$is_sticky?'<span class="sticky">置顶</span>':''?><?=$new_html?><a href="<?=$link?>" title="《<?=$title_attr?>》" data-post_id="<?=$post_id?>"><?=$title?></a>
		</h2>
		<div class="meta meta1">
			<p class="author" title="文章作者：<?=$author_name?>"><i></i><span><?php the_author_posts_link();?><?php edit_post_link('(再编辑&raquo;)', '', ''); ?></span></p>
			<p class="time" title="发布时间：<?=$time?>"><i></i><span><?=$time_ago?></span></p>
			<p class="view" title="浏览次数：<?=$views?>"><i></i><span><?=$views?></span></p>
			<p class="comment"><a href="<?=$comments_link?>" title="评论条数：<?=$comments_num?>"><i></i><span><?=$comments_num?></span></a></p>
			<p class="copy" data-title="<?=$title?>" data-link="<?=$link?>"><i></i><span>复制标题、链接</span></p>
			<div class="message"><!-- 这里显示消息的内容！ --></div>
		</div>
		<div class="clear"></div>
		<?php if($post_id%2==0){?>
		<div class="body float odd">
			<div class="text">
				<div class="left thumbnail"><?php echo yundanran_get_post_thumbnail($post_id); ?></div>
				<?=$summary?>
			</div>
		</div>
		<?php }else{?>
		<div class="body float even">
			<div class="text">
				<div class="right thumbnail"><?php echo yundanran_get_post_thumbnail($post_id); ?></div>
				<?=$summary?>
			</div>
		</div>
		<?php }?>
		<div class="clear"></div>
		<div class="meta meta2">
			<p class="cat" title="文章所在分类"><i></i><span><?php the_category(' , ');?></span></p>
			<p class="tag" title="文章所有标签"><i></i><span><?php the_tags('',' , ',''); ?></span></p>
			<a class="share share-sina" title="分享到新浪微博" data-title="<?=$title?>" data-link="<?=$link?>" data-summary="" href="#"></a>
			<a class="share share-qqt" title="分享到腾讯微博" data-title="<?=$title?>" data-link="<?=$link?>" data-summary="" href="#"></a>
			<a class="share share-qqz" title="分享到QQ空间" data-title="<?=$title?>" data-link="<?=$link?>" data-summary="" href="#"></a>
			<a class="quick-toggle" title="快捷评论（一句话点评）" href="#"></a>
		</div>
		<!-- //post_format:standard -->
		
		
		
		<?php endif; ?>
	</div>
	<div class="quick-comment">
		<?php if(is_user_logged_in()): ?>
		<p class="line0">
			尊敬的<b><?=$GLOBALS['user_display_name']?></b>您好：
		</p>
		<?php elseif($comment_author!=''): ?>
		<p class="line0">
			欢迎您回来，<b><?=$comment_author?></b>：
		</p>
		<?php else: ?>
		<p class="line0">
			<script>document.write('请在右上角点击<b>登录</b>操作，然后才可以一句话点评。');</script>
		</p>
		<?php endif; ?>
		<p><textarea name="" id="" placeholder="一句话点评"></textarea></p>
		<p class="end">
			<span class="message"></span>
			<script>document.write('<a href="javascript:;" class="y_button yes right" data-post_id="<?=$post_id?>"><span>一句话点评</span></a>');</script>
		</p>
	</div>
	<div class="bg1"></div>
	<div class="bg2"></div>
</article>
<!-- article <?=$post_id?> 结束 -->

<?php endwhile; ?>
<!-- page 开始 -->
<?php
	$current = $wp_query->query_vars['paged'] > 1 ? $wp_query->query_vars['paged'] : 1;
	$total_page=$wp_query->max_num_pages;
	$paginate_links_args = array
	(
		'base'         => @add_query_arg('paged','%#%'),
		'format'       => '',
		'total'        => $total_page,
		'current'      => $current,
		'show_all'     => False,
		// 'end_size'     => 1,
		// 'mid_size'     => 2,
		'prev_next'    => True,
		'prev_text'    => '&laquo; 上一页',
		'next_text'    => '下一页 &raquo;',
		'type'         => 'plain',
		// 'add_args'     => False,	//增加参数
		'add_fragment' =>'' 	//链接前字符 
	); 
	if( $wp_rewrite->using_permalinks() )
	{
		$paginate_links_args['base'] = user_trailingslashit( trailingslashit( remove_query_arg('s',get_pagenum_link(1) ) ) . 'page/%#%/', 'paged');
	}

	if( !empty($wp_query->query_vars['s']) )
	{
		$paginate_links_args['add_args'] = array('s'=>get_query_var('s'));	
	}

	if(paginate_links($paginate_links_args)!='')
	{
		echo '<div id="page" class="page index-page align-center">
		'.paginate_links($paginate_links_args).'</div>';
		'<script>yundanran.total_page='.$total_page.';yundanran.current_page='.$current.';</script>';
	}
?>	
<!-- page 结束 -->

<?php else:
	$post_id 		=-1;
	$title 			='~~~~(>_<)~~~~ 404了';
	$link 			=get_bloginfo('url');
	$name 			=get_bloginfo('name');
?>

<!-- 404 开始 -->
<article class="article index-article article-404">
	<div class="wrap">
		<h2 class="title"><span><?=$title?></span></h2>
		<div class="clear"></div>
		<div class="body float">
			<div class="text">
				可能原因是：<hr>
				<ul>
					<li>没有被发表；</li>
					<li>已转移了链接地址；</li>
					<li>已被删除；</li>
					<li>不存在；</li>
					<li>其他原因。</li>
					<li><a href="<?=$link?>" title="回到<?=$name?>首页">点击回到<?=$name?>首页</a></li>
				</ul>
			</div>
		</div>
		<div class="clear"></div>
	</div>
	<div class="bg1"></div>
	<div class="bg2"></div>
</article>	
<!-- 404 结束 -->

<?php endif; ?>
<?php wp_reset_query();?>