<?php
	$import_option='yundanran-viewsimport';
	if(isset($_POST['meta']))
	{
		$meta=stripslashes(strip_tags($_POST['meta']));
		if($meta!='')
		{
			yundanran_views_import($meta);
		}
		else
		{
			echo '<div class="error">错误：字段不能为空！</div>';
		}
	}
	function yundanran_views_import($meta)
	{
		$import_option='yundanran-viewsimport';
		// 尚未导入
		if(get_option($import_option,'')=='')
		{
			$args=array
			(
				'posts_per_page'=>-1,
				'offset'=>'',
				'orderby'=>'id',
				'order'=>'asc',
				'post_type'=>'any',
			);
			$posts=get_posts($args);
			$k=0;
			foreach($posts as $post)
			{
				$post_id=$post->ID;
				$views=get_post_meta($post_id,$meta,true);
				if(!empty($views))
				{
					$views=intval($views);
					$c=get_post_meta($post_id,YDR_POST_VIEWS_META,true);
					empty($c)?
					add_post_meta($post_id,YDR_POST_VIEWS_META,$views,true):
					update_post_meta($post_id,YDR_POST_VIEWS_META,$views+$c);
					// 不要删除插件数据
					// delete_post_meta($post_id,$meta);
					$k++;
				}
			}
			add_option($import_option,date('Y-m-d H:i:s',time()));
			echo '<div class="success">已成功导入 <b>'.$k.'篇</b> 文章的阅读统计数据。</div>
			<script type="text/javascript">
			location.reload();
			</script>
			';
		}
		else
		{
			$d=get_option($import_option,'');
			echo '<div class="error">文章的阅读统计数据曾在 <b>'.$d.'</b> 已经导入了。</div>';
		}
	}
?>
<div id="yundanran-form">
<h1>导入 wp-post-views 插件统计的阅读数据到 yundanran-2 主题</h1>
<?php
	if(get_option($import_option,'')=='')
	{
?>
<p>您目前尚未导入 wp-post-views 插件统计的阅读数据</p>
<form action="<?=admin_url()?>themes.php?page=import" method="post">
	<ul>
		<li>
			<b>字段</b>
			<input type="text" name="meta" class="regular-text" value="views" />
			<span class="required">*</span>
			<span class="desc">默认字段是“views”，如果是其他字段请重新填写</span>
		</li>
		<li class="end">
			<input type="submit" value="导入 wp-post-views 插件统计的阅读数据到 yundanran-2 主题" class="button button-primary" />
		</li>
	</ul>
</form>

<?php
	}
	else
	{
		echo '<p>您已于 <b>'.get_option($import_option,'').'</b> 导入了 wp-post-views 插件统计的阅读数据到yundanran-2主题中。</p>';
	}
?>
</div>
<style type="text/css">
div.alert,
div.error,
div.success,
div.tip
{
	padding: 0 10px;
	margin: 5px 15px;
	border-radius:3px;
}
.alert{color: #D67012;background: #F8F8C6;border: 1px solid #D8C889;padding:2px 6px;}
.error{color: #A20000;background:#FCEDED;border: 1px solid #DAA3A3;padding:2px 6px;}
.success{color: #098CF3;background:#E4F4FA;border: 1px solid #81C1DA;padding:2px 6px;}
.tip{color: #0A721B;background: #B8FFC1;border: 1px solid #8CD58C;padding:2px 6px;}
#yundanran-form
{}
#yundanran-form .required
{
	color:#f00;
}
#yundanran-form .desc
{
	color:#888;
	margin-left:10px;
}
#yundanran-form .textarea
{
	color:#0579B2;
	display:block;
	width:90%;
	height:90px;
	line-height:20px;
	padding:4px;
}
#yundanran-form li
{
	line-height:30px;
	padding-left:100px;
	zoom:1;
}
#yundanran-form li.end
{
	padding-left:0;
}
#yundanran-form li b
{
	position:absolute;
	left:0;
	width: 90px;
	text-align: right;
}
#yundanran-form input.regular-text
{
	height:30px;
	line-height:20px;
}
</style>