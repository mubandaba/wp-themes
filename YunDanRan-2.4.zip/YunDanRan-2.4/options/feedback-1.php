<?php
	if(isset($_POST['name']) && isset($_POST['email']) && isset($_POST['password']) && isset($_POST['password2']))
	{
		$name=strtolower(trim(stripslashes(strip_tags($_POST['name']))));
		$email=strtolower(trim(stripslashes(strip_tags($_POST['email']))));
		$password=$_POST['password'];
		$password2=$_POST['password2'];
		$userurl=strtolower(trim(stripslashes(strip_tags($_POST['url']))));
		if($name!='' && preg_match("/^\w{3,11}$/",$name) && is_email($email) && $password!='' && $password===$password2)
		{
			echo '
			<script>
			jQuery(function($)
			{
				$("#yundanran-message").removeClass().addClass("alert").html("正在注册，请稍后……").fadeIn(333);
			});
			</script>
			';
			$params=array
			(
				'action'=>'2',
				'name'=>$name,
				'email'=>$email,
				'password'=>$password,
				'url'=>$userurl,
			);
			$args=array
			(
				'body'=>$params
			);
			$response=wp_remote_post(YUNDANRAN2_FEEDBACK_URL,$args);
			if(is_wp_error($response))
			{
				echo '
				<script>
				jQuery(function($)
				{
					$("#yundanran-message").removeClass().addClass("error").html("网络错误，请稍后再试！").fadeIn(333);
				});
				</script>
				';
			}
			else
			{
				$json=json_decode($response['body']);
				if($json->data==0)
				{
					$info=$json->info;
					update_option('yundanran-username',$info->username);
					update_option('yundanran-userpass',$info->userpass);
					echo '
					<script>
					jQuery(function($)
					{
						$("#yundanran-message").removeClass().addClass("success").html("注册成功！").fadeIn(333);
						location.reload();
					});
					</script>
					';
				}
				else
				{
					echo '
					<script>
					jQuery(function($)
					{
						$("#yundanran-message").removeClass().addClass("error").html("'.$json->info.'").fadeIn(333);
					});
					</script>
					';
				}
			}
		}
		else
		{
			echo '<div class="error">错误：请按要求填写。</div>';
		}
	}
?>
<div id="yundanran-form">
	<div id="yundanran-message" style="display:none;"></div>
	<h1>注册到 http://qianduanblog.com</h1>
	<p>您是初次使用主题反馈功能，您必须填写相关内容注册到http://qianduanblog.com。注册成功后，您的用户数据将在http://qianduanblog.com永久保留，并且可以在http://qianduanblog.com登录。</p>
	<form action="<?=admin_url()?>themes.php?page=theme-feedback" method="post">
		<ul>
			<li>
				<b>用户名</b>
				<input type="text" name="name" class="regular-text" required />
				<span class="required">*</span>
				<span class="desc">英文用户名3-11位</span>
			</li>
			<li>
				<b>邮箱</b>
				<input type="email" name="email" class="regular-text" required />
				<span class="required">*</span>
				<span class="desc">邮箱格式</span>
			</li>
			<li>
				<b>密码</b>
				<input type="password" name="password" class="regular-text" required />
				<span class="required">*</span>
				<span class="desc">密码3-11位</span>
			</li>
			<li>
				<b>确认密码</b>
				<input type="password" name="password2" class="regular-text" required />
				<span class="required">*</span>
				<span class="desc">确认密码3-11位，与密码相同</span>
			</li>
			<li>
				<b>注册网站</b>
				<input type="url" name="url" class="regular-text" value="<?=get_bloginfo('url')?>" required />
				<span class="required">*</span>
				<span class="desc">默认主题安装的地址</span>
			</li>
			<li class="end">
				<input type="submit" value="注册到 http://qianduanblog.com" class="button button-primary" />
			</li>
		</ul>
	</form>
</div>
