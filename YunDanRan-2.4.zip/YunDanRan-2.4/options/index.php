<!--//禁止列目录-->
<!DOCTYPE html>
<meta charset="utf-8">
<title>本路径禁止列目录</title>
<div style="width:800px;height:auto;border:3px double #E5290D;color:#E5290D;font-size:14px;font-family:微软雅黑;margin:0 auto;padding:10px;text-align:center;">
	<h1>本路径禁止列目录</h1>
	<a href="<?=get_bloginfo('url')?>">返回<?=get_bloginfo('name')?>首页</a>
</div>