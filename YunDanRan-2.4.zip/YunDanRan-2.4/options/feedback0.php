<?php
if(isset($_POST['content']) && $_POST['content']!='')
{
	echo '
	<script>
	jQuery(function($)
	{
		$("#yundanran-message").removeClass().addClass("alert").html("正在反馈，请稍后……").fadeIn(333);
	});
	</script>
	';
	$content=trim(stripslashes(strip_tags($_POST['content'])));
	// YUNDANRAN2_FEEDBACK_URL
	$params=array
	(
		'action'=>'3',
		'username'=>get_option('yundanran-username',''),
		'userpass'=>get_option('yundanran-userpass',''),
		'ip'=>yundanran_get_access_ip(),
		'agent'=>$_SERVER['HTTP_USER_AGENT'],
		'content'=>$content,
	);
	$args=array
	(
		'body'=>$params
	);
	$response=wp_remote_post(YUNDANRAN2_FEEDBACK_URL,$args);
	if(is_wp_error($response))
	{
		echo '
		<script>
		jQuery(function($)
		{
			$("#yundanran-message").removeClass().addClass("error").html("网络错误，请稍后再试！").fadeIn(333);
		});
		</script>
		';
	}
	else
	{
		$json=json_decode($response['body']);
		if($json->data==0)
		{
			echo '
			<script>
			jQuery(function($)
			{
				$("#yundanran-message").removeClass().addClass("success").html("反馈成功！").fadeIn(333);
				location.reload();
			});
			</script>
			';
		}
		else
		{
			echo '
			<script>
			jQuery(function($)
			{
				$("#yundanran-message").removeClass().addClass("error").html("'.$json->info.'").fadeIn(333);
			});
			</script>
			';
		}
	}
}
?>
<div id="yundanran-form">
	<div id="yundanran-message" style="display:none;"></div>
	<h1>主题使用反馈</h1>
	<form action="<?=admin_url()?>themes.php?page=theme-feedback" method="post">
		<p>
		已在http://qianduanblog.com注册的用户名：<b><?=get_option('yundanran-username','')?></b>，密码：<b><?=get_option('yundanran-userpass','')?></b>。
		您可以随时 <a href="http://qianduanblog.com/wp-login.php" target="_blank">登录http://qianduanblog.com</a> ，享受会员资格。
		或者访问<a target="_blank" href="<?=YUNDANRAN2_FEEDBACK_POST?>"><?=YUNDANRAN2_FEEDBACK_POST?></a>来查看更多反馈以及反馈回复。
		</p>
		<ul>
			<li class="end">
				反馈内容
				<textarea name="content" id="" class="textarea"></textarea>
			</li>
			<li class="end">
				<input type="submit" value="提交反馈到 http://qianduanblog.com" class="button button-primary" />
			</li>
		</ul>
	</form>
	<p>目前不支持在您的网站浏览您所有反馈的内容。</p>
</div>