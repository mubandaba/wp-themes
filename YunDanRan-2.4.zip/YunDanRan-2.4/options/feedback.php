<?php
	// 获取注册在http://qianduanblog.com的userid
	$username=get_option('yundanran-username','');
	$userpass=get_option('yundanran-userpass','');
	
	// 如果不存在
	if($username=='' || $userpass=='')
	{
		include_once('feedback-1.php');
	}
	// 如果存在
	else
	{
		$params=array
		(
			'action'=>'1',
			'username'=>$username,
			'userpass'=>$userpass,
		);
		$args=array
		(
			'body'=>$params
		);
		$response=wp_remote_post(YUNDANRAN2_FEEDBACK_URL,$args);
		if(is_wp_error($response))
		{
			echo '<div class="error">网络错误，验证失败！</div>';
		}
		else
		{
			$json=json_decode($response['body']);
			// 如果已经注册
			if($json->data==0)
			{
				include_once('feedback0.php');
			}
			// 如果没有注册
			else
			{
				include_once('feedback-1.php');
			}
		}
	}
?>
<style type="text/css">
div.alert,
div.error,
div.success,
div.tip
{
	padding: 0 10px;
	margin: 5px 15px;
	border-radius:3px;
}
.alert{color: #D67012;background: #F8F8C6;border: 1px solid #D8C889;padding:2px 6px;}
.error{color: #A20000;background:#FCEDED;border: 1px solid #DAA3A3;padding:2px 6px;}
.success{color: #098CF3;background:#E4F4FA;border: 1px solid #81C1DA;padding:2px 6px;}
.tip{color: #0A721B;background: #B8FFC1;border: 1px solid #8CD58C;padding:2px 6px;}
#yundanran-form
{}
#yundanran-form .required
{
	color:#f00;
}
#yundanran-form .desc
{
	color:#888;
	margin-left:10px;
}
#yundanran-form .textarea
{
	color:#0579B2;
	display:block;
	width:90%;
	height:90px;
	line-height:20px;
	padding:4px;
}
#yundanran-form li
{
	line-height:30px;
	padding-left:100px;
	zoom:1;
}
#yundanran-form li.end
{
	padding-left:0;
}
#yundanran-form li b
{
	position:absolute;
	left:0;
	width: 90px;
	text-align: right;
}
#yundanran-form input.regular-text
{
	height:30px;
	line-height:20px;
}
</style>