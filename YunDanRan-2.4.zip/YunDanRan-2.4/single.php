<?php get_header(); ?>

<?php if(!$GLOBALS['ie6']): ?>
	<div id="BODY" class="layout main-sub">
	<!-- #BODY -->
		<section class="main left w-1000">
			<?php get_template_part( 'single-content', get_post_format() );?>
			<?php comments_template(); ?>
		</section>

		<section class="sub right w-310" style="display:none;">
			<?php get_sidebar();?>
		</section>
	<!-- #BODY -->
	</div>
<?php endif; ?>

<?php get_footer(); ?>