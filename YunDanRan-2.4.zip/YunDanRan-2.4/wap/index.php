<?php
	include_once('header.php');
?>

<div id="BODY" class="layout">
<?php 
global $wp_query, $wp_rewrite;
// $args = array_merge( $wp_query->query_vars, array( 'post_type' => array('blabla','images','post') ) );
// query_posts( $args );
$comment_author=isset($_COOKIE["comment_author_".COOKIEHASH])?esc_attr($_COOKIE["comment_author_".COOKIEHASH]):'';
$comment_author_email=isset($_COOKIE["comment_author_email_".COOKIEHASH])?esc_attr($_COOKIE["comment_author_email_".COOKIEHASH]):'';
$comment_author_url=isset($_COOKIE["comment_author_url_".COOKIEHASH])?esc_attr($_COOKIE["comment_author_url_".COOKIEHASH]):'';
?>
<?php if (have_posts()) : while (have_posts()) : the_post();
	$post_id 		=get_the_ID();
	$title 			=get_the_title();
	$title_attr		=esc_attr(strip_tags($title));
	$link 			=get_permalink();
	$author_id		=$post->post_author;
	$author_email	=get_userdata($author_id)->user_email;
	$author_name 	=get_the_author();
	$author_url		=get_author_posts_url(get_the_author_meta( 'ID' ));
	$time			=get_the_time('Y年m月d日 H:i:s',$post);
	$time_ago		=yundanran_time_ago(strtotime(get_the_time('YmdHis',$post)));
	$views 			=yundanran_getPostViews($post_id);
	$comments_link	=get_comments_link();
	$comments_num 	=get_comments_number();
	$summary 		=yundanran_set_reply2view(yundanran_content_summary(get_the_excerpt(),300,'<span class="end">[...全文未完]</span>'),$post_id);
	$content		=yundanran_set_reply2view(yundanran_the_content(),$post_id);
	$post_class_arr	=get_post_class($post_id);
	$post_class		="$post_class_arr[0] $post_class_arr[2] $post_class_arr[3] $post_class_arr[4]";
	$post_type		=get_post_type($post_id);
	$post_format	=get_post_format($post_id)?get_post_format($post_id):'standard';
?>
	<!-- article <?=$post_id?> 开始 -->
	<div class="article index-article">
		<h2 class="title"><a href="<?=$link?>" title="<?=$title_attr?>"><?=$title?></a></h2>
		<div class="meta">
			<span>作者：<?=$author_name?></span>
			<span>时间：<?=$time_ago?></span>
			<span>分类：<?php the_category(' , ');?></span>
			<span>评论：<?=$comments_num?></span>
		</div>
	</div>
	<!-- article <?=$post_id?> 结束 -->
<?php endwhile;?>	
<!-- page 开始 -->
<?php
	$current = $wp_query->query_vars['paged'] > 1 ? $wp_query->query_vars['paged'] : 1;
	$total_page=$wp_query->max_num_pages;
	$paginate_links_args = array
	(
		'base'         => @add_query_arg('paged','%#%'),
		'format'       => '',
		'total'        => $total_page,
		'current'      => $current,
		'show_all'     => False,
		// 'end_size'     => 1,
		// 'mid_size'     => 2,
		'prev_next'    => True,
		'prev_text'    => '&laquo; 上一页',
		'next_text'    => '下一页 &raquo;',
		'type'         => 'plain',
		// 'add_args'     => False,	//增加参数
		'add_fragment' =>'' 	//链接前字符 
	); 
	if( $wp_rewrite->using_permalinks() )
	{
		$paginate_links_args['base'] = user_trailingslashit( trailingslashit( remove_query_arg('s',get_pagenum_link(1) ) ) . 'page/%#%/', 'paged');
	}

	if( !empty($wp_query->query_vars['s']) )
	{
		$paginate_links_args['add_args'] = array('s'=>get_query_var('s'));	
	}

	if(paginate_links($paginate_links_args)!='')
	{
		echo '<div id="page" class="page index-page align-center">
		'.paginate_links($paginate_links_args).'</div>';
		'<script>yundanran.total_page='.$total_page.';yundanran.current_page='.$current.';</script>';
	}
?>	
<!-- page 结束 -->

<?php else:
	$post_id 		=-1;
	$title 			='~~~~(>_<)~~~~ 404了';
	$link 			=get_bloginfo('url');
	$name 			=get_bloginfo('name');
?>

<!-- 404 开始 -->
<div class="article index-article article-404">
	<h2 class="title"><?=$title?></h2>
	<div class="text">
		可能原因是：<hr>
		<ul>
			<li>没有被发表；</li>
			<li>已转移了链接地址；</li>
			<li>已被删除；</li>
			<li>不存在；</li>
			<li>其他原因。</li>
			<li><a href="<?=$link?>" title="回到<?=$name?>首页">点击回到<?=$name?>首页</a></li>
		</ul>
	</div>
</div>	
<!-- 404 结束 -->

<?php endif; ?>
<?php wp_reset_query();?>
</div>
<?php
	include_once('footer.php');
?>