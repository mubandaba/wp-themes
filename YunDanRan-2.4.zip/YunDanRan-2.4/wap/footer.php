<?php
$ct 		=wp_get_theme();
$name		=$ct->display('Name');
$author		=$ct->display('Author');
$version	=$ct->display('Version');
?>
<!-- 尾部 开始 -->
<div class="layout" id="FOOTER">
	<div class="border"></div>
	<div class="layout">
		<p class="align-center">
			<?php
			if(trim(YDR_DOMAIN)!='')
			echo "®：".YDR_DOMAIN." //";
			?>
			设计：<a href="http://qianduanblog.com/" title="设计：云淡然">云淡然</a>//
			编程：<a href="http://qianduanblog.com/" title="编程：云淡然">云淡然</a>//
			<script type="text/javascript">
			document.writeln("联系：<a title=\"email联系云淡然\" href=\"http://mail.163.com/share/mail2me.htm#email=099108111117100099111109101064049054051046099111109\" target=\"_blank\" rel=\"external nofollow\">云淡然</a>//");
			</script>
			服务器：localhost//
			<script type="text/javascript">
			document.writeln("基于：<a title=\"基于：Wordpress V<?=$wp_version;?>\" href=\"http://wordpress.org/\" target=\"_blank\" rel=\"external nofollow\">Wordpress V<?=$wp_version;?></a>//");
			</script>
		</p>
		<p class="align-center">
			主题：<?=$name?>//
			版本：<?=$version?>//
			作者：<?=$author?>//
		</p>
		<p class="align-center">
			查询：<?=get_num_queries();?>//
			耗时：<?=timer_stop(0);?>//
		</p>
		<p class="align-center">
			<?=yundanran_copyright();?>
		</p>
	</div>
</div>
<!-- 尾部 结束 -->