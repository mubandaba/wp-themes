<?php
// 判断是否支持gzip
$GLOBALS['is_gzip']			=(isset($_SERVER['HTTP_ACCEPT_ENCODING']) && false !== stripos($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip'))?true:false;
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<meta name="keywords" content="<?=yundanran_header_meta($posts,'keywords')?>" />
<meta name="description" content="<?=yundanran_header_meta($posts,'description')?>" />
<title><?=yundanran_header_title()?></title>
<link rel="Shortcut Icon" type="image/x-icon" href="<?=get_bloginfo('url')?>/favicon.ico?v=2013-2-2 23:37:09" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<link rel="alternate" type="application/rss+xml" title="RSS 2.0 - 所有文章" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="application/rss+xml" title="RSS 2.0 - 所有评论" href="<?php bloginfo('comments_rss2_url'); ?>" />

<?php if($GLOBALS['is_gzip']): ?>
<link rel="stylesheet" type="text/css" href="<?=get_bloginfo('template_url')?>/wap/style.css?v=<?=time()?>2013-2-2 23:04:55" media="all" />
<?php else:?>
<link rel="stylesheet" type="text/css" href="<?=get_bloginfo('template_url')?>/wap/style.css?v=<?=time()?>2013-2-2 23:04:55" media="all" />
<?php endif; ?>

<?php
if(YDR_BLOG_BACKGROUND!=get_bloginfo('template_url').'/public/image/fullbody.png')
{
	echo '<style type="text/css">body{background:url('.YDR_BLOG_BACKGROUND.');}</style>';
}
?>
</head>
<body <?=body_class()?>>
<div class="layout">
	<?php wp_nav_menu(array
	(
		'theme_location'=>'primary',//菜单名
		'container'=>'div',//ul父节点标签类型=div(默认)
		'container_class'=>'float',//ul父节点标签class
		'container_id'=>'NAV',//ul父节点标签id
		// 'menu_class'=>'',//ul节点的class
		'menu_id'=>'menu-item',//ul节点的id
		'echo'=>true,//true=直接输出(默认),false=输出html
		// 'fallback_cb=>'',//如果菜单不存在调用的函数
		// 'before'=>'菜单链接前文本',//每个菜单链接前的文本
		'after'=>'<i></i>',//每个菜单链接后的文本
		// 'link_before'=>'链接前文本',//每个菜单链接文本前的文本
		// 'link_after'=>'链接后文本',//每个菜单链接文本后的文本
		// 'walker'=>'',//自定义遍历对象
		'depth'=>1 //深度,0=所有(默认),1=1层
	) );?>
	<div class="clear"></div>
</div>
