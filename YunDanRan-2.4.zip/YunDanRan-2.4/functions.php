<?php
date_default_timezone_set('PRC');						//timezone

include_once(TEMPLATEPATH.'/require/base.php');		//base
include_once(TEMPLATEPATH.'/require/config.php');		//config
include_once(TEMPLATEPATH.'/require/post.php');		//post
include_once(TEMPLATEPATH.'/require/admin.php');		//admin
include_once(TEMPLATEPATH.'/require/comment.php');		//comment
include_once(TEMPLATEPATH.'/require/user.php');		//user
include_once(TEMPLATEPATH.'/require/layout.php');		//layout
include_once(TEMPLATEPATH.'/require/sidebar.php');		//yundanran-2 sidebar ajax page


include_once(TEMPLATEPATH.'/require/test.php');		//test