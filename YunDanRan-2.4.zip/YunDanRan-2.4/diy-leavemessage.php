<?php

/*
	Template Name:4=留言板
*/
// <!-- 获取选项 --> 


//参数用于ajax翻页
$ajax=(isset($_POST['yundanran_ajax']))?$_POST['yundanran_ajax']:0;
$ajax=(is_numeric($ajax))?(int)$ajax:0;



$GLOBALS['yundanran_commentsonly'] = 1;//单独评论
$GLOBALS['yundanran_commentstab']='博客留言';//评论标签的名称



$post_id=$posts[0]->ID;
?>

<?php if($ajax==0): get_header();?>

<script type="text/javascript">yundanran.post_id=<?=$post_id?></script>
<link rel="stylesheet" href="<?=bloginfo('template_url')?>/public/style/diy-leavemessage.css?v=2012-10-4 18:00:04" />
<div id="BODY" class="layout main Leave_message">
	<div class="intro">
		<p>在这里您可以畅所欲言。</p>
		<p>无论是对<?=get_bloginfo('name')?>的赞美还是批评，无论是对主题设计的意见或者建议，无论是对主题编码的褒扬抑或贬谪，无论是对博客文章的深究还是浅谈，都欢迎说出您的良言。</p>
		<p>您可以通过以下几种方式联系我：</p>
		<ol>
			<li><strong>留言板留言、评论，更快、更及时、更直观、更直接。</strong></li>
			<li>邮件：<a title="email联系云淡然" href="http://mail.163.com/share/mail2me.htm#email=099108111117100099111109101064049054051046099111109" target="_blank">点击写邮件给“云淡然”</a></li>
			<li>QQ：<a title="点击这里给云淡然发QQ消息" target="_blank" href="http://sighttp.qq.com/authd?IDKEY=618c91aa764179287f3e3aa428e40dcdd6e3c3cd5cce99a1"><img border="0"  src="http://wpa.qq.com/imgd?IDKEY=618c91aa764179287f3e3aa428e40dcdd6e3c3cd5cce99a1&pic=41" alt="QQ在线"></a></li>
		</ol>
	</div>

<?php endif; ?>
	
	
	<?php comments_template(); ?>
	
<?php if($ajax==0): ?>

</div>
<?php get_footer(); ?>

<?php endif; ?>