<?php
// 判断是否支持gzip
$GLOBALS['is_gzip']			=(isset($_SERVER['HTTP_ACCEPT_ENCODING']) && false !== stripos($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip'))?true:false;

if(is_user_logged_in())
{
	global $current_user;
	get_currentuserinfo();
	$user_id 			=$current_user->ID;
	$user_data			=get_userdata($user_id);
	$user_email 		=$current_user->user_email;
	$user_login 		=$current_user->user_login;
	$user_info 			=get_userdata($user_id);
	$user_nickname 		=$user_info->display_name;
	$user_url 			=$user_info->user_url;
	$user_url 			=($user_url=='')?get_author_posts_url($user_id):$user_url;
	$home_url 			=get_bloginfo('url');
	$comment_level			=yundanran_comment_level($user_email);
	$comment_level_desc		=yundanran_comment_level_desc($comment_level);

	$GLOBALS['user_display_name'] 		= $user_nickname;
	$GLOBALS['user_url'] 				= $user_url;
	$GLOBALS['user_id'] 				= $user_id;
	$GLOBALS['user_email'] 				= $user_email;
	$GLOBALS['user_login'] 				= $user_login;
	$GLOBALS['comment_level']			= $comment_level;
	$GLOBALS['comment_level_desc']		= $comment_level_desc;

	$user_registered	=date('Y年m月d日 H:i:s',strtotime($user_info->user_registered));
	$user_comment		=yundanran_get_user_comment_count($user_email);
	$user_login_time	=(isset($_COOKIE['login_time']))?$_COOKIE['login_time']:'未计算';
	$user_role 			=yundanran_get_user_role($user_id);


	$key = 'show_admin_bar_front';
	$single = true;
	$admin_bar = get_user_meta( $user_id, $key, $single );
	$admin_bar_height	=$admin_bar=='true'?30:0;
}
else
{
	$GLOBALS['user_id']				=0;
	$GLOBALS['user_login']			='';
	$GLOBALS['user_display_name']	=isset($_COOKIE["comment_author_".COOKIEHASH])?$_COOKIE["comment_author_".COOKIEHASH]:'';
	$GLOBALS['user_email']			=isset($_COOKIE["comment_author_email_".COOKIEHASH])?$_COOKIE["comment_author_email_".COOKIEHASH]:'';
	$GLOBALS['user_url']			=isset($_COOKIE["comment_author_url_".COOKIEHASH])?$_COOKIE["comment_author_url_".COOKIEHASH]:'';
	$GLOBALS['comment_level']		=0;
	$GLOBALS['comment_level_desc']	='';
	$admin_bar						='false';
	$admin_bar_height=				0;
}
$_SESSION['__yundanran__']=md5(date('YmdHi',time()).$_SERVER['HTTP_USER_AGENT']);


$GLOBALS['is_admin']=($GLOBALS['user_id']==YDR_ADMIN_ID)?1:0;

$AB=yundanran_get_access_browser();
$GLOBALS['ie6']=($AB['browser_code']=='ie' && (int)$AB['browser_ver']==6)?1:0;
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<meta name="keywords" content="<?=yundanran_header_meta($posts,'keywords')?>" />
<meta name="description" content="<?=yundanran_header_meta($posts,'description')?>" />
<title><?=yundanran_header_title()?></title>
<link rel="Shortcut Icon" type="image/x-icon" href="<?=get_bloginfo('url')?>/favicon.ico?v=2013-2-2 23:37:09" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<link rel="alternate" type="application/rss+xml" title="RSS 2.0 - 所有文章" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="application/rss+xml" title="RSS 2.0 - 所有评论" href="<?php bloginfo('comments_rss2_url'); ?>" />
<script type="text/javascript">
var yundanran=
{
	__yundanran__		:'<?=$_SESSION['__yundanran__']?>',						//验证提交唯一性
	domain				:'<?=get_bloginfo('url')?>',
	admin_email			:'<?=get_bloginfo('admin_email')?>',						//管理员eamil
	blog_name			:'<?=get_bloginfo('name')?>',
	is_admin			:<?=$GLOBALS['is_admin']?>,								//是否管理员
	is_gzip				:<?=$GLOBALS['is_gzip']?>,								//是否支持gzip
	is_login			:<?=($GLOBALS['user_id']==0)?0:1;?>,					//是否登录
	theme_url			:'<?=get_bloginfo('template_url')?>',						//主题url
	layout				:1000,													//主题布局宽度
	user_id				:<?=$GLOBALS['user_id']?>,								//当前用户id
	user_login			:'<?=$GLOBALS['user_login']?>',							//当前用户用户名
	user_display_name	:'<?=$GLOBALS['user_display_name']?>',					//当前用户昵称
	user_email			:'<?=$GLOBALS['user_email']?>',							//当前用户email
	user_url			:'<?=$GLOBALS['user_url']?>',							//当前用户url
	comment_level		:<?=$GLOBALS['comment_level']?>,						//当前评论等级
	comment_level_desc	:'<?=$GLOBALS['comment_level_desc']?>',					//当前评论等级描述
	comment_author		:'<?=$GLOBALS['user_display_name']?>',					//当前评论作者
	comment_author_email:'<?=$GLOBALS['user_email']?>',							//当前评论作者email
	comment_author_url	:'<?=$GLOBALS['user_url']?>',							//当前评论作者url
	comment_order		:'desc',												//评论排序
	comment_page		:0,														//当前评论页码
	total_page			:1,														//文章列表(首页)总页数，默认=1
	current_page		:1,														//文章列表(首页)当前页码，默认=1
	admin_bar			:<?=$admin_bar=='true'?'1':'0';?>,						//固定栏是否显示
	admin_bar_height	:<?=$admin_bar_height?>,								//固定栏高度
	post_id				:0,														//文章id（非首页），默认=1
	require_name_email	:<?=get_option('require_name_email')?>,					//是否需要评论邮箱
	page_type			:'<?=yundanran_get_page_type();?>',						//页面类型：首页（home）、文章页（single）、仅评论页（only-comment）、无评论页（none-comment）
	comment_min_limit	:<?=YDR_MIN_WORD_LIMIT?>,								//评论要求最少字符数
	comment_max_limit	:<?=YDR_MAX_WORD_LIMIT?>,								//评论要求最多字符数
	notice_date			:'<?=YDR_NOTICE_DATE?>',								//通知截止日期
	notice_id			:'<?=YDR_NOTICE_ID?>',									//通知id
	jquery_url			:'http://lib.sinaapp.com/js/jquery/1.7.2/jquery.min.js'
	// jquery_url			:'<?=get_bloginfo('template_url')?>/public/script/jquery.js'
};

if(window.top!=window)
{
	try
	{
		window.top.location.replace(window.location.href);
	}
	catch(e)
	{
		throw(yundanran.domain+'试图提醒您“网站似乎不是+'+yundanran.domain+'”被拒绝！');
	}
}

var image_array=
[
	<?=yundanran_get_wallpaper_html();?>
];
</script>

<?php if(!$GLOBALS['ie6']): ?>
	<?php if($GLOBALS['is_gzip']): ?>
	<link rel="stylesheet" type="text/css" href="<?=get_bloginfo('template_url')?>/style.min.css.php?v=2013-3-25 22:09:00" media="all" />
	<?php else:?>
	<link rel="stylesheet" type="text/css" href="<?=get_bloginfo('template_url')?>/style.min.css?v=2013-3-25 22:09:00" media="all" />
	<?php endif; ?>
<?php else:?>
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/public/style/ie6.css?v=2013-3-23 22:27:14" media="all" />
<?php endif; ?>


<?php if(yundanran_get_page_type()=='single' && !$GLOBALS['ie6']):?>
	<link rel="stylesheet" media="screen" href="<?=get_bloginfo('template_url')?>/public/style/SH.min.css?v=2013-3-23 22:44:50">
<?php endif; ?>


<!--[if lt IE 9]>
	<script src="<?=get_bloginfo('template_url')?>/public/script/ie-html5.js"></script>
<![endif]-->

<?php wp_head(); ?>


<?php
if(defined('YDR_BLOG_BACKGROUND') && trim(YDR_BLOG_BACKGROUND)!='' && YDR_BLOG_BACKGROUND!=get_bloginfo('template_url').'/public/image/fullbody.png')
{
	echo '<style type="text/css">body{background:url('.YDR_BLOG_BACKGROUND.');}</style>';
}
?>

</head>


<body <?=body_class()?>>
<?php if(!$GLOBALS['ie6']): ?>
<!-- 背景 开始 -->
<div id="background-image">
	<div class="image">
		<img src="" alt="" />
	</div>
</div>
<div id="background"></div>
<!-- 背景 结束 -->


<!-- 进度条 开始 -->
<div id="LOADING"></div>
<!-- 进度条 结束 -->

<!-- TOP 开始 -->
<div id="TOP">
	<?php wp_nav_menu(array
	(
		'theme_location'=>'primary',//菜单名
		'container'=>'div',//ul父节点标签类型=div(默认)
		'container_class'=>'navigator float',//ul父节点标签class
		'container_id'=>'',//ul父节点标签id
		'menu_class'=>'float',//ul节点的class
		'menu_id'=>'NAV',//ul节点的id
		'echo'=>true,//true=直接输出(默认),false=输出html
		// 'fallback_cb=>'',//如果菜单不存在调用的函数
		// 'before'=>'菜单链接前文本',//每个菜单链接前的文本
		'after'=>'<i></i>',//每个菜单链接后的文本
		// 'link_before'=>'链接前文本',//每个菜单链接文本前的文本
		// 'link_after'=>'链接后文本',//每个菜单链接文本后的文本
		// 'walker'=>'',//自定义遍历对象
		'depth'=>0 //深度,0=所有(默认),1=1层
	) );?>
	
	<div id="SEARCH">
	<form name="search" role="search" method="get"  action="<?=YDR_GOOGLE_PAGE?>">
		<?php if(YDR_GOOGLE_PAGE==get_bloginfo('url')):?>
		<!--//system-->
		<input name="s" class="text" type="text" value="" />
		<?php else: ?>
		<!--//google-->
		<input name="q" class="text" type="text" value="" />
		<?php endif; ?>
		<input type="submit" class="button" value="" />
	</form>
	</div>
	<div class="setting" id="setting">
		<a href="#" title="背景定时随机切换：<?=(isset($_COOKIE['yundanran-background-toggle']) && $_COOKIE['yundanran-background-toggle']=='is-open')?'开':'关';?>" class="right background-toggle <?=(isset($_COOKIE['yundanran-background-toggle']) && $_COOKIE['yundanran-background-toggle']=='is-open')?'is-open':'is-close';?>"></a>
		<a rel="external nofollow" href="<?=YDR_WEIBO_URL?>" target="_blank" class="sina-weibo right" title="<?=bloginfo('name')?> - 新浪微博"></a>
		<a rel="external nofollow" href="<?=YDR_QQT_URL?>" target="_blank" class="tencent-weibo right" title="<?=bloginfo('name')?> - 腾讯微博"></a>
		<a rel="external nofollow" href="<?=YDR_QQ_URL?>" target="_blank" class="qq-online right" title="<?=bloginfo('name')?> - QQ在线"></a>
		<div id="user" class="right">
			<?php if(is_user_logged_in()):?>
			<a href="#" class="online" title="打开我的信息"><?=yundanran_avatar_cache(get_avatar($user_email,20));?></a>
			<?php else: ?>
			<a href="#" class="offline" title="点击登录"></a>
			<?php endif; ?>
			
			<?php if(is_user_logged_in()): ?>
			<div class="online expand ">
				<ul>
					<li class="odd">
						<strong>用户名：</strong>
						<span><?=$user_login?>(<?=$user_role['role_desc']?>)</span>
						<?php echo current_user_can('publish_posts')?'<a style="margin-left:10px;" href="'.get_bloginfo('url').'/wp-admin/post-new.php" title="新建文章">新建文章</a>':'';?>
						<a href="<?=get_bloginfo('url')?>/wp-admin">后台管理</a>
					</li>
					<li class="even"><strong>昵称：</strong><span><?=$user_nickname?></span></li>
					<li class="odd"><strong>注册时间：</strong><span><?=$user_registered?></span></li>
					<li class="even"><strong>讨论数：</strong><span><?=$user_comment?></span></li>
					<li class="odd"><strong>评论等级：</strong><?=yundanran_comment_level_html($GLOBALS['comment_level']);?>【<?=$GLOBALS['comment_level_desc']?>】</li>
					<li class="even"><strong>个人资料：</strong><span><a title="点击进入->个人资料" href="<?=$home_url?>/wp-admin/profile.php">点击进入->个人资料</a></span></li>
					<?php if($GLOBALS['is_admin']):?>
					<li class="odd"><strong>主题功能：</strong><span>
						<a title="主题设置选项" href="<?=admin_url()?>themes.php?page=options-framework">设置选项</a>
						<a title="主题帮助手册" href="<?=admin_url()?>themes.php?page=theme-help">帮助手册</a>
						<a title="主题使用反馈" href="<?=admin_url()?>themes.php?page=theme-feedback">使用反馈</a>
					</span></li>
					<?php endif;?>
				</ul>
				<a href="<?php echo wp_logout_url('http://'.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']);?>" class="logout setting" title="注销登录">×</a>
				<a href="javascript:;" class="back setting" title="最小化">≡</a>
			</div>
			<?php else: ?>
			<script>
			document.write('<div class="offline expand tab"><ul class="tab-ul"><li class="current">用户登录</li><li>用户注册</li><li>游客登记</li></ul><div class="tab-content"><ul class="tab-body current" id="login-box"><li><b>用户名</b><input type="text" id="login-name" class="text" /><em>*</em></li><li><b>密码</b><input type="password" id="login-pass" class="text" /><em>*</em></li><li class="end"><a id="login-submit" href="#" class="y_button yes"><span>登录</span></a><a id="login-qq" href="#" class="y_button disabled"><span>QQ授权登录</span></a></li></ul><ul class="tab-body" id="reg-box"><li><b>用户名</b><input type="text" id="reg-name" class="text"><em>*</em></li><li><b>密码</b><input type="password" id="reg-pass" class="text"><em>*</em></li><li><b>确认密码</b><input type="password" id="reg-pass2" class="text"><em>*</em></li><li><b>邮箱</b><input type="email" id="reg-email" class="text"><em>*</em></li><li><b>验证码</b><span id="reg-verify-span"></span><input type="text" id="reg-verify" class="text2"><em>*</em></li><li class="end"><a id="reg-submit" href="#" class="y_button yes"><span>注册新用户</span></a></li></ul><ul class="tab-body" id="guest-box"><li><b>昵称</b><input id="guest-name" type="text" class="text" value="<?=$GLOBALS['user_display_name']?>" /><em>*</em></li><li><b>邮箱</b><input id="guest-email" type="email" class="text" value="<?=$GLOBALS['user_email']?>" /><?php echo get_option('require_name_email') ? '<em>*</em>' : ''; ?></li><li><b>网址</b><input id="guest-url" type="url" name="comment_author_url" class="text" value="<?=$GLOBALS['user_url']?>" /></li><li class="end"><a id="guest-submit" href="#" class="y_button yes"><span>保存信息</span></a></li></ul></div><a href="javascript:;" class="back setting" title="最小化">≡</a></div>');
			</script>
			<?php endif; ?>					
		</div>
	</div>
</div>
<!-- TOP 结束 -->

<!-- 头部 开始 -->
<?php
$logobg=(defined('YDR_BLOG_LOGO') && trim(YDR_BLOG_LOGO)!='' && YDR_BLOG_LOGO!=get_bloginfo('template_url').'/public/image/logo.png')?
' style="background-image:url('.YDR_BLOG_LOGO.')"':
'';
?>
<div id="HEADER">
	<div class="layout">
		<h1 class="logo"<?=$logobg?>><a href="<?=bloginfo('url')?>"><?=bloginfo('name')?></a></h1>
		<h2 class="url">——<?=bloginfo('description')?><a href="<?=bloginfo('url')?>"><?=bloginfo('url')?></a></h2>
	</div>
</div>
<!-- 头部 结束 -->




<?php endif; ?>
<!-- 主体 开始 -->