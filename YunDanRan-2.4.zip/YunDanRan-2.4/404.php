<?php 
	$post_id 		=-1;
	$title 			='~~~~(>_<)~~~~ 404了';
	$link 			=get_bloginfo('url');
	$name 			=get_bloginfo('name');
	function yundanran_get_current_url() 
	{
		$pageURL = 'http';
		$pageURL .= (isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] == "on")?"s":"";
		$pageURL .= "://";

		$pageURL .= ($_SERVER["SERVER_PORT"] != "80") ?
		$_SERVER["SERVER_NAME"] . ":" . $_SERVER["SERVER_PORT"] . $_SERVER["REQUEST_URI"]:
		$_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"];
		return $pageURL;
	}
	function yundanran_change2seo_url($old_url)
	{
		$pattern		="/(.*)article\/?(\w+)?(\/)?(.*)/i";
		$replacement1 	="\$1\$2.html\$3\$4";
		$replacement2 	="\$1\$2\$3\$4";
		preg_match($pattern,$old_url,$matches);
		
		if(count($matches)>=2 && is_numeric($matches[2]))
		{
			$seo_url=preg_replace($pattern, $replacement1, $old_url);
		}
		else
		{
			$seo_url=preg_replace($pattern, $replacement2, $old_url);
		}
		return $seo_url;
	}
	$current_url=yundanran_get_current_url();
	$seo_url=yundanran_change2seo_url($current_url);
get_header(); 

?>

<div id="BODY" class="layout page-404 main-sub">
<!-- #BODY 开始 -->
	<section class="main w-690 left">
		<article class="article article-404">
			<div class="wrap">
				<h2 class="title"><span><?=$title?></span></h2>
				<div class="clear"></div>
				<div class="body float">
					<div class="text">
						访问的链接不存在！<br>
						可能原因是：<hr>
						<ul>
							<li>文章没有被发表；</li>
							<li>文章被设置为隐私；</li>
							<li>文章已被删除；</li>
							<li>文章不存在；</li>
							<li>其他原因。</li>
						</ul>
						<p>您是不是要访问：</p>
						<ul>
							<li><a href="<?=$seo_url?>"><?=$seo_url?></a></li>
							<li><a href="<?=$link?>" title="回到<?=$name?>首页"><?=$link?></a></li>
						</ul>
					</div>
				</div>
				<div class="clear"></div>
			</div>
			<div class="bg1"></div>
			<div class="bg2"></div>
		</article>
	</section>	
	<aside class="right w-310 sub">
		<div class="rand-article">
			<h2 class="title">您是不是要找：</h2>
			<?php
			$article=yundanran_rand_article(6);
			$html='<ul class="rank-list wrap">';
			foreach ($article as $key => $value)
			{
				$i=$key+1;
				$comment_link=$value['link'].'#comments';
				$html.='
				<li class="float">
				<div class="li li-'.$i.'">'.$i.'</div>
				<div class="info">
					<div class="line line-1 title"><span><a title="《'.$value['title'].'》" href="'.$value['link'].'">'.$value['title'].'</a></span></div>
					<div class="line line-2 meta">
						<p class="time" title="发布时间：'.$value['time'].'"><i></i><span>'.$value['time_ago'].'</span></p>
						<p class="comment" title="评论条数：'.$value['comment'].'"><a href="'.$comment_link.'"><i></i><span>'.$value['comment'].'</span></a></p>
					</div>
				</div>
				</li>
				';
			}
			$html.='</ul>';
			echo $html;
			?>	
		</div>
	</aside>
<!-- #BODY 结束 -->
</div>

	
<?php get_footer(); ?>
