<?php
/*
	Template Name:1=所有标签
*/
get_header();?>

<div id="BODY" class="layout all-tag all-tags main">
	<div class="wrap">
		<h6 class="title">所有标签</h6>
		<ul class="float wrap">
			<?php
			$args=array
			(
				'number' => '',
				'orderby' => 'count',
				'order' => 'DESC',
				'hide_empty' => 0
			);
			$tags=get_tags($args);
			$html='';
			foreach($tags as $tag)
			{
				$link = get_tag_link($tag->term_id);
				$name=$tag->name;
				$name_attr=esc_attr(strip_tags($name));
				$count=$tag->count;
				$html.="
				<li>
					<a href='{$link}' title='标签：{$name_attr}'>{$name}</a>×<span class='num'>{$count}</span>
				</li>\n";
			}
			echo $html;
			?>
		</ul>
	</div>
</div>

<?php get_footer();?>