<?php

/*
	Template Name:6=时光轴
*/
// <!-- 获取选项 --> 
$GLOBALS['yundanran_onlypage']=1;



get_header();
global $wpdb;
// 最近
$time1			=time();
$year1			=intval(date('Y',$time1));
$month1			=intval(date('m',$time1));

// 最久
$sql2		="select post_date from $wpdb->posts where post_status='publish' order by post_date asc";
$s2			=$wpdb->get_results($wpdb->prepare($sql2,''));
$time2		=$s2[0]->post_date;
$year2		=date('Y',strtotime($time2));
$month2		=date('m',strtotime($time2));

$chinese_month=array
(
	'零','元','二','三','四','五','六','七','八','九','十','十一','十二'
);

?>

<div id="BODY" class="layout main Time_line">
	<div class="left left-time">
		<?php 
		$html='';
		for($y=$year1;$y>=$year2;$y--)
		{
			$html.='
			<div class="year">
				<p class="year-'.$y.'">'.$y.'年</p>';
				if($y==$year1)
				{
					$html.='
					<ul class="month">
					';
					for($m=$month1;$m>=1;$m--)
					{
						$html.='
						<li data-year="'.$y.'" data-monthnum="'.$m.'" class="month-'.$m.'" title="'.$y.'年'.$chinese_month[$m].'月">'.$chinese_month[$m].'月</li>
						';
					}
					$html.='
					</ul>
					';
				}
				else if($y==$year2)
				{
					$html.='<ul class="month">';
					for($m=12;$m>=$month2;$m--)
					{
						$html.='
						<li data-year="'.$y.'" data-monthnum="'.$m.'" class="month-'.$m.'" title="'.$y.'年'.$chinese_month[$m].'月">'.$chinese_month[$m].'月</li>
						';
					}
					$html.='</ul>';
				}
				else
				{
					$html.='<ul class="month">';
					for($m=12;$m>=1;$m--)
					{
						$html.='
						<li data-year="'.$y.'" data-monthnum="'.$m.'" class="month-'.$m.'" title="'.$y.'年'.$chinese_month[$m].'月">'.$chinese_month[$m].'月</li>
						';
					}
					$html.='</ul>';
				}
			$html.='</div>';
		}
		echo $html;
		?>
	</div>
	<div class="right right-content">
		<ul class="rank-list">
		</ul>
	</div>
</div>

<link rel="stylesheet" href="<?=bloginfo('template_url')?>/public/style/diy-timeline.css?v=2012-11-3 1:16:05" />


<?php get_footer(); ?>

<script type="text/javascript" src="<?=bloginfo('template_url')?>/public/script/diy-timeline.js?v=2012-12-30 20:53:07"></script>