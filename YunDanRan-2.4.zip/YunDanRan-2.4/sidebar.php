<!-- tab 1 最新博文 最热博文 随机博文 -->
<article class="article-list has-tab rank-list">
	<h2 class="title">
		<i></i>
		<ul class="tab">
			<li>最热博文</li>
			<li>最新博文</li>
			<li>随机博文</li>
		</ul>
	</h2>
	<div class="wrap tab-content">
		<div class="tab-body">
			<div class="body hot-article-body" data-action="hot-article"></div>
		</div>
		<div class="tab-body  ">
			<div class="body last-article-body" data-action="last-article"></div>
		</div>
		<div class="tab-body">
			<div class="body rand-article-body" data-action="rand-article"></div>
		</div>
	</div>
</article>

<!-- tab 最近评论 热门评论 -->
<article class="comment-list has-tab rank-list">
	<h2 class="title">
		<i></i>
		<ul class="tab">
			<li class="">最近评论&回复</li>
			<li>热门评论</li>
		</ul>
	</h2>
	<div class="wrap tab-content">
		<div class="tab-body  ">
			<div class="body last-comment-body" data-action="last-comment" id="last-comment"></div>
		</div>
		<div class="tab-body">
			<div class="body hot-comment-body" data-action="hot-comment"></div>
		</div>
	</div>
</article>

<!-- tab 2 所有分类 所有标签 博文存档 -->
<article class="cat-list tag-list archive-list has-tab">
	<h2 class="title">
		<i></i>
		<ul class="tab">
			<li class="">所有分类</li>
			<li>所有标签</li>
			<li>博文存档</li>
		</ul>
	</h2>
	<div class="wrap tab-content">
		<div class="tab-body">
			<div class="body all-cat-body" data-action="all-cat"></div>
		</div>
		<div class="tab-body">
			<div class="body all-tag-body float" data-action="all-tag"></div>
		</div>
		<div class="tab-body">
			<div class="body all-archive-body" data-action="all-archive"></div>
		</div>
	</div>
</article>

<!-- tab 3 友情链接 博客统计 -->
<article class="friend-link count-blog has-tab">
	<h2 class="title">
		<i></i>
		<ul class="tab">
			<li class="click">友情链接</li>
			<li>博客统计</li>
		</ul>
	</h2>
	<div class="wrap tab-content">
		<div class="tab-body current">
			<div class="body friend-link-body" data-action="friend-link" data-have="0">
			<?php
			$args=array
			(
				'orderby'          => 'name',
				'order'            => 'ASC',
				'limit'            => -1,
				'category'         => '',
				'exclude_category' => '',
				'category_name'    => '',
				'hide_invisible'   => 1,
				'show_updated'     => 0,
				'categorize'       => 1,
				'title_li'         => '',
				'category_orderby' => 'name',
				'category_order'   => 'ASC',
				'class'            => 'linkcat',
				'category_before'  => '<li class="linkcat">',
				'category_after'  	=> '</li>',
	    		'title_before'		=>'<p class="cat">',
				'title_after'		=>'</p>',
				'link_before'		=>'',
				'link_after'		=>'',
				'show_images'		=>1,
				'show_name'			=>1,
				'fav_url'			=>'http://www.google.com/s2/favicons?domain=',
				'echo'				=>0
			);
			$html='<ul class="friend-link">';
			$html.=yundanran_list_bookmarks($args);
			$html.='</ul>';
			echo $html;
			?>
			</div>
		</div>
		<div class="tab-body">
			<div class="body count-blog-body float" data-action="count-blog"></div>
		</div>
	</div>
</article>

<article class="has-tab about">
	<h2 class="title">
		<i></i>
		<ul class="tab">
			<li class="click">关于<?=get_bloginfo('name')?></li>
		</ul>
	</h2>
	<div class="wrap tab-content">
		<div class="tab-body current"><?=yundanran_seo_about()?></div>
	</div>
</article>
