<?php
	$is_wap=(yundanran_get_access_type()=='wap')?true:false;
	if($is_wap)
	{
		include_once(TEMPLATEPATH.'/wap/index.php');
		exit;
	}
?>

<?php
	//参数用于ajax翻页
	$ajax=(isset($_POST['yundanran_ajax']))?$_POST['yundanran_ajax']:0;
	$ajax=(is_numeric($ajax))?(int)$ajax:0;
?>

<?php if($ajax==0)get_header(); ?>

<?php if($ajax==0): ?>
	<div id="BODY" class="layout main-sub" style="<?php echo ($GLOBALS['ie6'])?'display:none;':''; ?>">
	<!-- #BODY -->
		<section class="main left w-690">
			<?php 
			if(is_tag() || is_archive() || is_category() || is_search())
			{
				echo '<h6 class="title">'.yundanran_header_title().'</h6>';
			}
			get_template_part('index-loop',get_post_format());
			?>
		</section>
		<section class="sub right w-310">
			<?php get_sidebar();?>
		</section>
	<!-- #BODY -->
	</div>
<?php else: ?>
	<!-- 此页仅用于ajax翻页 开始 -->
	<?php get_template_part( 'index-loop', get_post_format() );?>
	<!-- 此页仅用于ajax翻页 结束 -->
<?php endif; ?>

<?php if($ajax==0)get_footer(); ?>