<?php
$ct 		=wp_get_theme();
$name		=$ct->display('Name');
$author		=$ct->display('Author');
$version	=$ct->display('Version');
?>
<!-- 主体 结束 -->

<?php if(!$GLOBALS['ie6']): ?>
<!-- 尾部 开始 -->
<footer>
	<div class="border"></div>
	<div class="layout">
		<p class="align-center">
			<?php
			if(trim(YDR_DOMAIN)!='')
			echo "®：".YDR_DOMAIN." //";
			?>
			设计：<a href="http://qianduanblog.com/" title="设计：云淡然" target="_blank">云淡然</a>//
			编程：<a href="http://qianduanblog.com/" title="编程：云淡然" target="_blank">云淡然</a>//
			<script type="text/javascript">
			document.writeln("联系：<a title=\"email联系云淡然\" href=\"http://mail.163.com/share/mail2me.htm#email=099108111117100099111109101064049054051046099111109\" target=\"_blank\" rel=\"external nofollow\">云淡然</a>//");
			</script>
			服务器：<?=trim(YDR_HOST)!=''?YDR_HOST:'localhost'?>//
			<script type="text/javascript">
			document.writeln("基于：<a title=\"基于：Wordpress V<?=$wp_version;?>\" href=\"http://wordpress.org/\" target=\"_blank\" rel=\"external nofollow\">Wordpress V<?=$wp_version;?></a>//");
			</script>
		</p>
		<p class="align-center">
			主题：<?=$name?>//
			版本：<?=$version?>//
			作者：<?=$author?>//
		</p>
		<p class="align-center">
			查询：<?=get_num_queries();?>//
			耗时：<?=timer_stop(0);?>//
		</p>
		<p class="align-center">
			<?=yundanran_copyright();?>
		</p>
	</div>
</footer>
<!-- 尾部 结束 -->


<!-- 快捷按钮 开始 -->
<section id="scrollbar">
	<?php if(is_single() || ( is_page() && 
	(!isset($GLOBALS['yundanran_onlypage']) || !$GLOBALS['yundanran_onlypage']) && 
	(!isset($GLOBALS['yundanran_commentsonly']) || !$GLOBALS['yundanran_commentsonly'])
	) ):?>
	<p class="toggle-sidebar" title="打开/关闭侧边栏"></p>
	<?php endif;?>
	<p class="go-to-top" title="返回顶部"></p>
	<?php if(is_single() || ( is_page() && 
	(!isset($GLOBALS['yundanran_onlypage']) || !$GLOBALS['yundanran_onlypage'])
	) ):?>
	<p class="go-to-comment" title="我有话要说"></p>
	<?php endif;?>
</section>
<!-- 快捷按钮 结束 -->


<!-- 提示 开始 -->
<section id="tip">
	<div class="wrap">
		<h6 class="title">提示标题 <a href="javascript:void(0);" class="close"></a></h6>
		<div class="body">内容区</div>
	</div>
	<div class="caret caret-left">
		<b class="caret-1"></b>
		<b class="caret-2"></b>
	</div>
</section>
<!-- 提示 开始 -->



<!-- 文章索引 开始 -->
<section id="article-index" style="display:none; position:fixed; margin-left: 800px; top:80px; z-index:99999;">
	<div class="name" style="cursor:move;"><span>文章索引(可拖动)</span><a title="点击折叠" class="slide">－</a></div>
	<div class="cont"></div>
</section>
<!-- 文章索引 结束 -->


<!-- 评论删除确认 开始 -->
<section class="delete-comment-confirm">
	<ul class="wrap">
		<li class="line">确认要删除这条评论/回复？</li>
		<li class="line">
			<a class="y_button yes" data-id="0"><span>确定</span></a>
			<span></span>
			<a class="y_button no"><span>取消</span></a>
		</li>
		<li class="line message"></li>
	</ul>
</section>
<!-- 评论删除确认 结束 -->

<!-- 公告内容 开始 -->
<textarea id="yundanran_notice_content" style="display:none;">
	<div id="yundanran-notice-here">
		<div class="content">
			<img title="通知" class="notice-icon" src="<?php bloginfo('template_url'); ?>/public/image/notice.gif" alt="！" />
			<div class="notice-text"><?=YDR_NOTICE_CONTENT?></div>
			<a title="已阅" class="notice-close" href="#">×</a>
		</div>
	</div>
</textarea>
<!-- 公告内容 结束 -->

<?php endif; ?>


<?php
$GLOBALS['is_gzip']=isset($GLOBALS['is_gzip'])?$GLOBALS['is_gzip']:(isset($_SERVER['HTTP_ACCEPT_ENCODING']) && false !== stripos($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip'))?true:false;
$is_gizp=$GLOBALS['is_gzip']; if($is_gizp):?>

<!--//已gzip压缩-->
<?php if(!$GLOBALS['ie6']){ ?>
<script src="<?=get_bloginfo('template_url')?>/public/script/head.min.js.php?v=2013-3-24 23:12:48"></script>
<script>
// 首页
if(yundanran.page_type=='home')
{
	head.js
	(
		{'jquery':yundanran.jquery_url},
		{'home':yundanran.theme_url+'/public/script/home.min.js.php?v=2013-3-24 23:12:48'}
	);
}
// 文章页 // 留言页
else if(yundanran.page_type=='single' || yundanran.page_type=='only-comment')
{
	head.js
	(
		{'jquery':yundanran.jquery_url},
		{'single':yundanran.theme_url+'/public/script/single.min.js.php?v=2013-3-24 23:12:48'}
	);
}
// 其他页
else if(yundanran.page_type=='none-comment')
{
	head.js
	(
		{'jquery':yundanran.jquery_url},
		{'public':yundanran.theme_url+'/public/script/public.min.js.php?v=2013-3-24 23:12:48'}
	);
}
</script>
<!--//已gzip压缩-->
<?php } ?>

<?php else: ?>

<!--//未gzip压缩-->
<?php if(!$GLOBALS['ie6']){ ?>
<script src="<?=get_bloginfo('template_url')?>/public/script/head.min.js?v=2013-3-24 23:12:48"></script>
<script>
// 首页
if(yundanran.page_type=='home')
{
	head.js
	(
		{'jquery':yundanran.jquery_url},
		{'home':yundanran.theme_url+'/public/script/home.min.js?v=2013-3-24 23:12:48'}
	);
}
// 文章页 // 留言页
else if(yundanran.page_type=='single' || yundanran.page_type=='only-comment')
{
	head.js
	(
		{'jquery':yundanran.jquery_url},
		{'single':yundanran.theme_url+'/public/script/single.min.js?v=2013-3-24 23:12:48'}
	);
}
// 其他页
else if(yundanran.page_type=='none-comment')
{
	head.js
	(
		{'jquery':yundanran.jquery_url},
		{'public':yundanran.theme_url+'/public/script/public.min.js?v=2013-3-24 23:12:48'}
	);
}
</script>
<!--//未gzip压缩-->
<?php } ?>

<?php endif;?>


<!-- 统计代码 开始 -->
<div style="display:none;"><?=YDR_BLOG_TOGNJI?></div>
<!-- 统计代码 结束 -->

<?php if($GLOBALS['ie6']){ ?>
	<!-- ie6 开始 -->
	<div id="ie6">
		<h1>郑重警告</h1>
		<div class="wrap">
			<h2>10年了，ie6已经服役期满！</h2>
			<h2>请更换更高级的浏览器来访问<?=get_bloginfo('name');?>，感谢您的配合！</h2>
			<h2><?=get_bloginfo('name');?>——<?=get_bloginfo('url');?></h2>
			<p>By yundanran-2 http://qianduanblog.com @云淡然</p>
		</div>
	</div>
	<!-- ie6 结束 -->
	<script src="<?php bloginfo('template_url'); ?>/public/script/ie6.js?v=2013-3-23 22:27:14"></script>
<?php }?>

<?php wp_footer();?>

</body>
</html>