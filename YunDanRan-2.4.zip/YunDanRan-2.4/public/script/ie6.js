var
oIe6=document.getElementById('ie6'),
flag=true,
left=20;
var t=setInterval(function()
{
	if(left<=0)
	{
		clearInterval(t);
		oIe6.style.left='0px';
	}
	flag?
	oIe6.style.left=left+'px':
	oIe6.style.left='-'+left+'px';
	left--;
	flag=!flag;
},111);