$(function()
{
	$('a').each(function()
	{
		($(this).prop('title')=='')?$(this).prop('title',$(this).text()):'';
	});

	var $back=$('#back');//返回封面
	var $open=$('#open');//打开简历
	var $cover=$('#cover');//封面
	var $content=$('#content');//内容
	var $tab=$('#tab');//tab
	var width=$cover.width();
	
	$open.click(function()
	{
		$content.fadeIn(500);
		$cover.stop(true,false).animate({left:'-'+width+'px'},1000,function()
		{		
			$back.fadeIn(500);
		});
	});
	
	$back.click(function()
	{
		$back.fadeOut(500);
		$cover.stop(true,false).animate({left:'0px'},1000,function()
		{
			$content.fadeOut(500);
		});		
	});
	
	$tab.find('.tab-nav li').click(function()
	{
		$(this).addClass('click').siblings().removeClass('click');
		var index=$(this).index();
		$tab.find('.tab-content .content').eq(index).fadeIn(500).siblings().fadeOut(500);
	});
	$tab.find('.tab-nav li').eq(0).trigger('click');
	
	$content.find('.content li:odd').each(function()
	{
		$(this).addClass('hover');
	});
});

$(window).load(function()
{
	$('body>center').hide();
});