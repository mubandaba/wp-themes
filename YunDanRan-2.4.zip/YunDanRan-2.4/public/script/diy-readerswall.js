head.ready('jquery',function()
{

$(function()
{

});

});