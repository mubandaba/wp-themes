head.ready('jquery',function()
{

$(function()
{
	var $li=$('#BODY.blog-archive').find('li.cat-item');
	var li_json=
	{		
		id:[]
	};
	//新建一个json对象，比数组优秀而且更易操作
	var ba_target=null;//当前打开的对象
	$li.find('a').click(function(e)
	{
		var $this=$(this).closest('li.cat-item');
		var pos='#BODY.blog-archive '+get_index($this);
		var id=parseInt(RegExp(/\d+/).exec($this.attr('class')));
		var find=false;
		$.each(li_json.id,function(k,v)
		{
			if(parseInt(v)==id)
			{
				return find=true;
			}
		});
		if(!find)//json中不存在，就是没有加载过
		{
			li_json.id[li_json.id.length]=id;//写入json数组
			var html='<ul class="post-list" style="display:none;" data-open="1">';
			html+='<li>正在加载……</li>';
			html+='</ul>';
			$.ajax(
			{
				url:window.location.href,
				type:'post',
				dataType:'json',
				data:{action:'_yundanran_get_post_by_catid',catid:id},
				beforeSend:function()
				{
					if($this.find('ul.children').size()>0)
					{
						$(html).insertBefore(pos+'>ul.children').slideDown(300);
					}
					else
					{
						$(html).appendTo(pos).slideDown(300);
					}				
				},
				success:function(json)
				{
					// alert(json.info);
					if($this.find('ul.children').size()>0)
					{
						$this.find('ul.children').prev('ul.post-list').html(json.info);
					}
					else
					{
						$this.find('ul.post-list').html(json.info);
					}
				}
			});
		}
		else if(find)
		{
			if($this.find('ul.children').size()>0)
			{
				var open=$this.find('ul.children').prev('ul.post-list').attr('data-open');
				if(open=='1')
				{
					$this.find('ul.children').prev('ul.post-list').slideUp(300).attr('data-open','0')
				}
				else
				{
					$this.find('ul.children').prev('ul.post-list').slideDown(300).attr('data-open','1');
				}
			}
			else
			{
				var open=$this.find('ul.post-list').attr('data-open');			
				if(open=='1')
				{
					$this.find('ul.post-list').slideUp(300).attr('data-open','0');
				}
				else
				{
					$this.find('ul.post-list').slideDown(300).attr('data-open','1');
				}
			}			
		}
		return false;
	});
	
	var $btn=$('#close-all');
	$btn.click(function()
	{
		$('#BODY.blog-archive').find('ul.post-list').each(function()
		{
			if($(this).attr('data-open')=='1')
			{
				$(this).attr('data-open','0').slideUp(300);
			}
		});
		return false;
	});
	
	/*
		计算li的路径
	*/
	function get_index($this)
	{
		if(!$this)return;
		var arr=new Array();
		var str='';
		for(i=2;i>=0;i--)
		{
			if(i==2)
			{
				arr[i]=$this.index();
			}
			else if(i==1)
			{
				if($this.parent().closest('li.cat-item').size()>0)
				arr[i]=$this.parent().closest('li.cat-item').index();
				else
				arr[i]='-1';
			}
			else if(i==0)
			{
				if($this.parent().closest('li.cat-item').parent().closest('li.cat-item').size()>0)
				arr[i]=$this.parent().closest('li.cat-item').parent().closest('li.cat-item').index();
				else
				arr[i]='-1';
			}
		}
		for(k in arr)
		{
			if(arr[k]=='-1')continue;
			str+='>ul>li.cat-item:eq('+arr[k]+')';
		}
		return $.trim(str);
	}

});

});