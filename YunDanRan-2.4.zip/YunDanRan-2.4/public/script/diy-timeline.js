head.ready('jquery',function()
{

$(function()
{
	var $time	=$('#BODY .left-time'),
		$cont	=$('#BODY .right-content ul');
		on_load2	=0;
	$time.find('li').click(function()
	{
		if(on_load2)return false;
		
		var $li	=$(this);
		if($li.hasClass('current'))return false;
		
		var h1=$li.closest('.year').position().top,
			h2=$li.closest('.year').children('p').outerHeight(),
			h3=$li.position().top,
			h=h1+h2+h3;
		$cont.css({'margin-top':h});
		
		var year		=$(this).attr('data-year'),
			monthnum	=$(this).attr('data-monthnum');
		on_load2=1;
		
		$.ajax(
		{
			url:location.href,
			data:{action:'_yundanran_get_post_by_time',year:year,monthnum:monthnum},
			type:'post',
			dataType:'json',
			beforeSend:function()
			{
				$cont.html('<li class="none alert">正在加载'+year+'年'+monthnum+'月发表的文章<img src="'+yundanran.theme_url+'/public/image/waiting.gif"/></li>');
			},
			success:function(json)
			{
				$cont.html(json.info);
				on_load2=0;
				$time.find('li').removeClass('current');
				$li.addClass('current');
				var h=$li.offset().top-yundanran.admin_bar_height;
				$('html,body').animate({'scrollTop':h},333);
			},
			error:function()
			{
				$cont.html('<li class="none error">加载失败！</li>');
				on_load2=0;
			}
		});
	});
	
	$time.find('.year:first li:first').trigger('click');
});

});