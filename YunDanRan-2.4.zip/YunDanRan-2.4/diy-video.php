<?php
/*
	Template Name:9=视频解析
*/
?>
<!DOCTYPE html>
<meta charset="utf-8" />
<?php
$youku='http://v.youku.com/player/getPlayList/VideoIDS/XNTA2MDA2NTg0/timezone/+08/version/5/source/out?password=&ran=2513&n=3';
$yyyy=wp_remote_get($youku,null);
// print_r($yyyy['body']);


// echo getClientIp()?'111':'222';

require_once(TEMPLATEPATH."/require/VideoUrlParser.class.php");
$urls=array
(
	// "http://v.qq.com/cover/o/o9tab7nuu0q3esh.html?vid=97abu74o4w3_0",
	// "http://v.youku.com/v_show/id_XNTA2MDA2NTg0.html?f=18878835",
	// "http://v.youku.com/v_show/id_XNTA1NDYwMzky.html",
	// "http://www.tudou.com/programs/view/MPoYOe0jkkU/?fr=rec2",
	// "http://www.tudou.com/listplay/--hPPLb3XDE.html",//未通过
	// "http://v.ku6.com/film/show_520/3X93vo4tIS7uotHg.html",
	// "http://v.ku6.com/special/show_4926690/Klze2mhMeSK6g05X.html",
	// "http://v.ku6.com/show/7US-kDXjyKyIInDevhpwHg...html",
	// "http://www.56.com/u60/v_ODI5OTMyODk.html",
	// "http://www.letv.com/ptv/vplay/1168109.html",
	// "http://my.tv.sohu.com/u/vw/5101536",
	// "http://video.sina.com.cn/v/b/48717043-1290055681.html",
);
foreach($urls as $url)
{
	$info = VideoUrlParser::parse($url);
	if(!empty($info))
	{
	echo 'title=>'.$info['title'];echo '<br>';
	echo 'img=>'.$info['img'];echo '<br>';
	echo 'url=>'.$info['url'];echo '<br>';
	echo 'swf=>'.$info['swf'];echo '<br>';
	}
	else
	{
		echo "视频地址：{$url}暂时无法解析。";
	}
	echo '<hr>';
}

?>