<?php
/*
	Template Name:2=所有存档
	Time:2012-6-16 22:49:13
*/
// <!-- 获取选项 --> 
$GLOBALS['yundanran_onlypage']=1;
// $ONLYPAGE=1;
?>
<?php get_header();?>
<div id="BODY" class="layout blog-archive main">
	<h6 class="title">
		所有存档
		<a href="#" class="y_button yes" id="close-all" title="折叠所有展开"><span>折叠所有</span></a>
	</h6>
	<ul class="rank-list">
	<?php
		$args=array
		(
			'orderby'=>'name',
			'order'=>'asc',
			'show_count'=>1,
			'hide_empty'=>0,
			'title_li'=>'',
			'use_desc_for_title'=>1,
			'hierarchical'=>1,//分层
			'echo'=>1,
			'depth'=>0,
			'pad_counts'=>1
		);
		wp_list_categories($args); 
	?>
	</ul>
</div>
<?php get_footer(); ?>

<script src="<?=bloginfo('template_url')?>/public/script/diy-archive.js?v=2012-12-30 21:01:13"></script>