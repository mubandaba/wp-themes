<?php get_header();
	$curauth = (get_query_var('author_name')) ? 
	get_user_by('slug', get_query_var('author_name')) : 
	get_userdata(get_query_var('author'));
	
	$role_arr=yundanran_get_user_role($curauth->ID);
	$role_name=$role_arr['role_name'];
	$role_desc=$role_arr['role_desc'];

	$author_name=$curauth->display_name;
	$title=get_bloginfo('name').$role_desc.'：'.$author_name;

	$author_arg=array
	(
		'ID',
		'display_name',
		'sina_weibo',
		'tx_weibo',
		'qq_num',
		'user_email',
		'user_registered',
		'user_url',
		'description',
	);
	$author_des=array
	(
		'ID',
		'昵称',
		'新浪微博',
		'腾讯微博',
		'QQ号',
		'邮箱',
		'注册时间',
		'个人网站',
		'个人说明',
	);

	function cut_email($email)
	{
		// 按@分割成数组
		$arr=explode('@',$email);
		$str0=$arr[0];
		$str1=$arr[1];
		
		// 第一段字符总长度
		$len0=strlen($str0);
		
		// 要星号的个数
		$len=ceil($len0/2);
		
		$str2=substr_replace($str0,'*',-$len,$len);
		return $str2.'@'.$str1;
	}
	
	$comment_level			=yundanran_comment_level($curauth->user_email);
	$comment_level_desc		=yundanran_comment_level_desc($comment_level);
?>
<div id="BODY" class="layout main">
	<!-- BODY 开始 -->
	<article class="article author-article">
		<div class="wrap main">
			<h6 class="title"><?=$title?></h6>
			<div class="clear"></div>
			<div class="body float">
				<div class="left avatar">
					<p class="img">
						<?=yundanran_avatar_cache(get_avatar($curauth->user_email,'160'));?>
					</p>
					<p class="level">
						<?=yundanran_comment_level_html($comment_level)?>
						<?=$comment_level_desc?>
					</p>
				</div>
				<div class="right summary">
					<ul>
						<?php 
							$html='';
							$px='even';
							foreach($author_arg as $key=>$value)
							{
								$px=($px=='even')?'odd':'even';
								$html.=($value=='user_email')?
								'<li class="'.$px.'"><strong>'.$author_des[$key].'：</strong><span>'.cut_email($curauth->$value).'</span></li>':
								'<li class="'.$px.'"><strong>'.$author_des[$key].'：</strong><span>'.$curauth->$value.'</span></li>';
							}
							echo $html;
						?>
					</ul>

				</div>
			</div>
			<div class="clear"></div>
		</div>
		<div class="bg1"></div>
		<div class="bg2"></div>
	</article>
	<!-- BODY 结束 -->
</div>
<?php get_footer(); ?>
