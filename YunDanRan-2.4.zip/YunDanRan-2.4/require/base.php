<?php

/*
	生成验证码放在session里
	2013年3月24日21:48:46
*/
function yundanran_create_verify()
{
	$v1=rand(1,100);
	$v2=rand(1,100);
	$_SESSION['verify']=$v1+$v2;
	return $v1.'+'.$v2.'=';
}
function _yundanran_create_verify()
{
	if(isset($_POST['action']) && $_POST['action']=='_yundanran_create_verify')
	{
		$json['data']=1;
		$json['info']=yundanran_create_verify();
		header("Content-Type: application/json");
		echo json_encode($json);
		exit;
	}
}
add_action('init', '_yundanran_create_verify');


/****************************************************
	**	输出avatar头像的src
	@	email地址
	@	尺寸
	@	图片，如果图片不存在则根据get_avatar读取
	**	2012年8月25日14:13:26
	**	2013年1月13日0:23:06
****************************************************/
function yundanran_get_avatar_src($email,$size,$img=null)
{
	$img=$img==null?
	get_avatar($email,$size):
	$img;
	$pt="/<img.*\ssrc=[\"']([^\"']*?)[\"'].*>/";
	preg_match($pt,$img,$ms);
	return $ms[1];
}




/*****************************************************
	jQuery
	sina jquery
	暂停头部加载jquery
******************************************************/
function yundanran_script()
{
    wp_deregister_script( 'jquery' );
    // wp_register_script( 'jquery', 'http://lib.sinaapp.com/js/jquery/1.8/jquery.min.js');
    // wp_enqueue_script( 'jquery');
}    
add_action('wp_enqueue_scripts','yundanran_script');


/*
	去除默认的js、css版本号
*/
function yundanran_script_remove_version( $src )
{
    $parts = explode('?', $src);
    return $parts[0];
}
add_filter( 'script_loader_src', 'yundanran_script_remove_version', 15, 1 );
add_filter( 'style_loader_src', 'yundanran_script_remove_version', 15, 1 );


// 恢复WP3.5的链接管理器
add_filter('pre_option_link_manager_enabled', '__return_true');


/*
	防止中文乱码
	修改文件上传名
*/
function yundanran_wp_handle_upload_prefilter($file)
{
	$time=date("YmdHis");
	$file['name'] = $time.".".pathinfo($file['name'],PATHINFO_EXTENSION);
	return $file;
}
add_filter('wp_handle_upload_prefilter','yundanran_wp_handle_upload_prefilter');





/*******************************************************
	**	yundanran mp3 播放器代码
	**	参数1：	mp3地址或flash地址
	**	参数2：	播放器类型【dew,simple】
	**	参数3：	播放器参数数组【array(auto,loop)】
*******************************************************/
function yundanran_mp3player($src,$type,$param=array())
{
	$simple_swf		=get_bloginfo('template_url').'/public/player/simple.swf';
	$dewmini_swf	=get_bloginfo('template_url').'/public/player/dewplayer-mini.swf';
	$mini_swf		=get_bloginfo('template_url').'/public/player/mini.swf';
	
	$dft=array
	(
		'auto'=>0,
		'loop'=>1,
	);
	$opt=wp_parse_args( $param, $dft );
	extract( $opt, EXTR_SKIP );
	
	switch($type)
	{
		// case 'xiami':
		// $html='
		// <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0" width="257" height="33">
			// <param name="movie" value="'.$src.'" />
			// <param name="wmode" value="transparent" />
			// <param name="quality" value="high" />
			// <embed src="'.$src.'" menu="false" wmode="transparent" quality="high" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="257" height="33"></embed>
		// </object>
		// ';break;

		case 'dew':
		$auto	=$opt['auto']?'1':'0';
		$loop	=$opt['loop']?'1':'0';
		$html='
		<object type="application/x-shockwave-flash" data="'.$dewmini_swf.'" width="160" height="20" name="dewplayer">
			<param name="wmode" value="transparent" />
			<param name="movie" value="'.$dewmini_swf.'" />
			<param name="flashvars" value="mp3='.$src.'&autostart='.$auto.'&autoreplay='.$loop.'&showtime=1" />
		</object>
		';break;
		
		case 'mini':
		$auto	=$opt['auto']?'true':'false';
		$loop	=$opt['loop']?'true':'false';
		$html='
		<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="150" height="20">
			<param name="movie" value="'.$mini_swf.'?file='.$src.'&width=150&songVolume=100&backColor=CEE3EA&frontColor=298EB7&autoStart='.$auto.'&repeatPlay='.$loop.'&showDownload=false" />
			<param name="quality" value="high" />
			<param name="wmode" value="transparent" />
			<embed src="'.$mini_swf.'?file='.$src.'&width=150&songVolume=100&backColor=CEE3EA&frontColor=298EB7&autoStart='.$auto.'&repeatPlay='.$loop.'&showDownload=false" width="150" height="20" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash"></embed>
		</object>
		';break;
		
		case 'simple':
		default:
		$auto	=$opt['auto']?'yes':'no';
		$loop	=$opt['loop']?'yes':'no';
		$html='
		<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="290" height="24">
			<param name="movie" value="'.$simple_swf.'?soundFile='.$src.'&bg=0xcccccc&leftbg=0xdddddd&lefticon=0xF2F2F2&rightbg=0xdddddd&rightbghover=0xcccccc&righticon=0xffffff&righticonhover=0xFFFFFF&text=0x444444&slider=0x888888&track=0xFFFFFF&border=0xFFFFFF&loader=0xeeeeee&autostart='.$auto.'&loop='.$loop.'" />
			<param name="quality" value="high" />
			<param name="wmode" value="transparent" />
			<embed src="'.$simple_swf.'?soundFile='.$src.'&bg=0xCDDFF3&leftbg=0x357DCE&lefticon=0xF2F2F2&rightbg=0x357DCE&rightbghover=0x4499EE&righticon=0xF2F2F2&righticonhover=0xFFFFFF&text=0x357DCE&slider=0x357DCE&track=0xFFFFFF&border=0xFFFFFF&loader=0x8EC2F4&autostart='.$auto.'&loop='.$loop.'"" width="290" height="24" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash"></embed>
		</object>
		';break;
	}
	return $html;
}



/*************************************************
**	获得当前页面类型
**	2012年11月14日22:50:35
**	首页：home
**	文章页：single
**	仅评论页：only-comment
**	无评论页：none-comment
**************************************************/
function yundanran_get_page_type()
{
	$p='home';
	if(is_home() || is_tag() || is_category() || is_author() || is_404() || is_archive())
	{
		$p='home';
		// home.js
	}
	else if(isset($GLOBALS['yundanran_commentsonly']) && $GLOBALS['yundanran_commentsonly'])
	{
		$p='only-comment';
		// single.js
	}
	else if(isset($GLOBALS['yundanran_onlypage']) && $GLOBALS['yundanran_onlypage'])
	{
		$p='none-comment';
		// null
	}
	else if(is_single() || is_attachment() || is_page())
	{
		$p='single';
		// home.js
		// single.js
	}
	return $p;
}





/***********************************************************
	**	session
	**	2012年8月18日11:37:34
***********************************************************/
add_action('init', 'yundanran_session_start', 1);
function yundanran_session_start()
{
    if(!session_id())
	{
        session_start();
    }
}

/***************************************************
**	返回访问的类型（wap web）
**	2012年12月2日22:21:20
**	2012年12月3日22:30:00
***************************************************/
function yundanran_get_access_type()
{
	/*
		主题关闭了wap功能将返回web
		2013年1月20日21:28:04
	*/
	if(YDR_WAP==-1)return 'web';
	
	
	$user_agent = $_SERVER['HTTP_USER_AGENT'];
	
	// 模拟iphone
	// $user_agent='Mozilla/5.0 (iPhone; CPU iPhone OS 5_0 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9A334 Safari/7534.48.3';

	$mobile_agents = Array
	(
		"240x320","acer","acoon","acs-","abacho","ahong","airness",
		"alcatel","amoi","android","anywhereyougo.com","applewebkit/525",
		"applewebkit/532","asus","audio","au-mic","avantogo",
		"becker","benq","bilbo","bird","blackberry","blazer","bleu",
		"cdm-","compal","coolpad","danger","dbtel","dopod","elaine",
		"eric","etouch","fly ","fly_","fly-","go.web","goodaccess",
		"gradiente","grundig","haier","hedy","hitachi","htc",
		"huawei","hutchison","inno","ipad","ipaq","ipod","jbrowser",
		"kddi","kgt","kwc","lenovo","lg ","lg2","lg3","lg4","lg5",
		"lg7","lg8","lg9","lg-","lge-","lge9","longcos","maemo",
		"mercator","meridian","micromax","midp","mini","mitsu",
		"mmm","mmp","mobi","mot-","moto","nec-","netfront","newgen",
		"nexian","nf-browser","nintendo","nitro","nokia","nook",
		"novarra","obigo","palm","panasonic","pantech","philips",
		"phone","pg-","playstation","pocket","pt-","qc-","qtek",
		"rover","sagem","sama","samu","sanyo","samsung","sch-",
		"scooter","sec-","sendo","sgh-","sharp","siemens","sie-",
		"softbank","sony","spice","sprint","spv","symbian","tablet",
		"talkabout","tcl-","teleca","telit","tianyu","tim-","toshiba",
		"tsm","up.browser","utec","utstar","verykool","virgin","vk-",
		"voda","voxtel","vx","wap","wellco","wig browser","wii",
		"windows ce","wireless","xda","xde","zte"
	);
	$is_wap = false;
	foreach ($mobile_agents as $device) 
	{
		if (stristr($user_agent, $device)) 
		{
			$is_wap = true;
			break;
		}
	}
	
	return $is_wap?'wap':'web';
}

/*****************************************************
获得访问浏览信息（浏览器、操作系统||掌上电脑）
部分函数源于：wordpress show_useragent 插件 V1.0.8
返回数组：
'country_o2c'=>国家名称2位简码
'country_o3c'=>国家名称3位简码
'country_oname'=>国家名称
'browser_name'=>浏览器名称
'browser_code'=>浏览器代码 
'browser_ver'=>浏览器版本 
'os_name'=>操作系统名称
'os_code'=>操作系统代码
'os_ver'=>操作系统版本
'pda_name'=>掌上电脑名称（包括手机、平板电脑等手持设备）
'pda_code'=>掌上电脑代码
'pda_ver'=>掌上电脑版本
2012年11月10日19:39:02
******************************************************/
require_once('ip2country.php');
function yundanran_get_access_browser($ua=null,$ip=null) 
{
	$browser_name = $browser_code = $browser_ver = $os_name = $os_code = $os_ver = $pda_name = $pda_code = $pda_ver = null;
	if($ua==null)$ua=$_SERVER['HTTP_USER_AGENT'];
	if($ip==null)$ip=yundanran_get_access_ip();
	
	$ip=(!preg_match('/\d+\.\d+\.\d+\.\d/',$ip,$tmp))?'127.0.0.1':$ip;
	
	$ua = preg_replace("/FunWebProducts/i", "", $ua);
	if (preg_match('#MovableType[ /]([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'MovableType';
		$browser_code = 'mt';
		$browser_ver = $matches[1];
	} elseif (preg_match('#WordPress[ /]([a-zA-Z0-9.]*)#i', $ua, $matches)) {
		$browser_name = 'WordPress';
		$browser_code = 'wp';
		$browser_ver = $matches[1];
	} elseif (preg_match('#typepad[ /]([a-zA-Z0-9.]*)#i', $ua, $matches)) {
		$browser_name = 'TypePad';
		$browser_code = 'typepad';
		$browser_ver = $matches[1];
	} elseif (preg_match('#drupal#i', $ua)) {
		$browser_name = 'Drupal';
		$browser_code = 'drupal';
		$browser_ver = count($matches) > 0 ? $matches[1] : "";
	} elseif (preg_match('#symbianos/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$os_name = "SymbianOS";
		$os_ver = $matches[1];
		$os_code = 'symbian';
	} elseif (preg_match('#avantbrowser.com#i', $ua)) {
		$browser_name = 'Avant Browser';
		$browser_code = 'avantbrowser';
	} elseif (preg_match('#(Camino|Chimera)[ /]([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Camino';
		$browser_code = 'camino';
		$browser_ver = $matches[2];
		$os_name = "Mac OS";
		$os_code = "macos";
		$os_ver = "X";
	} elseif (preg_match('#anonymouse#i', $ua, $matches)) {
		$browser_name = 'Anonymouse';
		$browser_code = 'anonymouse';
	} elseif (preg_match('#PHP#', $ua, $matches)) {
		$browser_name = 'PHP';
		$browser_code = 'php';
	} elseif (preg_match('#danger hiptop#i', $ua, $matches)) {
		$browser_name = 'Danger HipTop';
		$browser_code = 'danger';
	} elseif (preg_match('#w3m/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'W3M';
		$browser_code = 'w3m';
		$browser_ver = $matches[1];
    } elseif (preg_match('#Shiira[/]([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Shiira';
		$browser_code = 'shiira';
		$browser_ver = $matches[1];
		$os_name = "Mac OS";
		$os_code = "macos";
		$os_ver = "X";
	} elseif (preg_match('#Dillo[ /]([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Dillo';
		$browser_code = 'dillo';
		$browser_ver = $matches[1];
	} elseif (preg_match('#Epiphany/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Epiphany';
		$browser_code = 'epiphany';
		$browser_ver = $matches[1];
		list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
	} elseif (preg_match('#UP.Browser/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Openwave UP.Browser';
		$browser_code = 'openwave';
		$browser_ver = $matches[1];
	} elseif (preg_match('#DoCoMo/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'DoCoMo';
		$browser_code = 'docomo';
		$browser_ver = $matches[1];
		if ($browser_ver == '1.0') {
			preg_match('#DoCoMo/([a-zA-Z0-9.]+)/([a-zA-Z0-9.]+)#i', $ua, $matches);
			$browser_ver = $matches[2];
		} elseif ($browser_ver == '2.0') {
			preg_match('#DoCoMo/([a-zA-Z0-9.]+) ([a-zA-Z0-9.]+)#i', $ua, $matches);
			$browser_ver = $matches[2];
		}
	} elseif (preg_match('#(SeaMonkey)/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Mozilla SeaMonkey';
		$browser_code = 'seamonkey';
		$browser_ver = $matches[2];
		if (preg_match('/Windows/i', $ua)) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
		} else {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}
	} elseif (preg_match('#Kazehakase/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Kazehakase';
		$browser_code = 'kazehakase';
		$browser_ver = $matches[1];
		if (preg_match('/Windows/i', $ua)) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
		} else {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}
	} elseif (preg_match('#Flock/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Flock';
		$browser_code = 'flock';
		$browser_ver = $matches[1];
		if (preg_match('/Windows/i', $ua)) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
		} else {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}
	} elseif (preg_match('#(Firefox|Phoenix|Firebird|BonEcho|GranParadiso|Minefield|Iceweasel)/4([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Mozilla Firefox';
		$browser_code = 'firefox';
		$browser_ver = '4'.$matches[2];
		if (preg_match('/Windows/i', $ua)) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
		} else {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}
	} elseif (preg_match('#(Firefox|Phoenix|Firebird|BonEcho|GranParadiso|Minefield|Iceweasel)/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Mozilla Firefox';
		$browser_code = 'firefox';
		$browser_ver = $matches[2];
		if (preg_match('/Windows/i', $ua)) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
		} else {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}
	} elseif (preg_match('#Minimo/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Minimo';
		$browser_code = 'mozilla';
		$browser_ver = $matches[1];
		if (preg_match('/Windows/i', $ua)) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
		} else {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}
	} elseif (preg_match('#MultiZilla/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'MultiZilla';
		$browser_code = 'mozilla';
		$browser_ver = $matches[1];
		if (preg_match('/Windows/i', $ua)) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
		} else {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}
	} elseif (preg_match('#SE 2([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'SouGou Browser';
		$browser_code = 'sogou';
		$browser_ver = '2'.$matches[1];
		if (preg_match('/Windows/i', $ua)) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
		} else {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}
	} elseif (preg_match('#baidubrowser ([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'BaiDu Browser';
		$browser_code = 'baidubrowser';
		$browser_ver = $matches[1];
		if (preg_match('/Windows/i', $ua)) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
		} else {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}
	} 
	/*****
		***新增区分360se（安全浏览器） 和 360ee（极速浏览器）
		***2012年11月11日12:03:37
	*****/
	elseif (preg_match('#360ee#i', $ua, $matches)) {
		$browser_name = '360 extreme explorer';
		$browser_code = '360ee';
		$browser_ver = isset($matches[1])?$matches[1]:'';
		if (preg_match('/Windows/i', $ua)) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
		} else {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}
	} elseif (preg_match('#360se#i', $ua, $matches)) {
		$browser_name = '360 safe explorer';
		$browser_code = '360se';
		$browser_ver = $matches[1];
		if (preg_match('/Windows/i', $ua)) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
		} else {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}
	} 	
	elseif (preg_match('#QQBrowser/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'QQ Browser';
		$browser_code = 'qqbrowser';
		$browser_ver = $matches[1];
		if (preg_match('/Windows/i', $ua)) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
		} else {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}
	} elseif (preg_match('/PSP \(PlayStation Portable\)\; ([a-zA-Z0-9.]+)/', $ua, $matches)) {
		$pda_name = "Sony PSP";
		$pda_code = "sony-psp";
		$pda_ver = $matches[1];
	} elseif (preg_match('#Galeon/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Galeon';
		$browser_code = 'galeon';
		$browser_ver = $matches[1];
		list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
	} elseif (preg_match('#iCab/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'iCab';
		$browser_code = 'icab';
		$browser_ver = $matches[1];
		$os_name = "Mac OS";
		$os_code = "macos";
		if (preg_match('#Mac OS X#i', $ua)) {
			$os_ver = "X";
		}
	} elseif (preg_match('#K-Meleon/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'K-Meleon';
		$browser_code = 'kmeleon';
		$browser_ver = $matches[1];
		if (preg_match('/Windows/i', $ua)) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
		} else {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}
	} elseif (preg_match('#Lynx/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Lynx';
		$browser_code = 'lynx';
		$browser_ver = $matches[1];
		list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
	} elseif (preg_match('#Links \\(([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Links';
		$browser_code = 'lynx';
		$browser_ver = $matches[1];
		list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
	} elseif (preg_match('#ELinks[/ ]([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'ELinks';
		$browser_code = 'lynx';
		$browser_ver = $matches[1];
		list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
	} elseif (preg_match('#ELinks \\(([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'ELinks';
		$browser_code = 'lynx';
		$browser_ver = $matches[1];
		list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
	} elseif (preg_match('#Konqueror/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Konqueror';
		$browser_code = 'konqueror';
		$browser_ver = $matches[1];
		list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		if (!$os_name) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_pad_os($ua);
		}
	} elseif (preg_match('#NetPositive/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'NetPositive';
		$browser_code = 'netpositive';
		$browser_ver = $matches[1];
		$os_name = "BeOS";
		$os_code = "beos";
	} elseif (preg_match('#OmniWeb#i', $ua)) {
		$browser_name = 'OmniWeb';
		$browser_code = 'omniweb';
		$os_name = "Mac OS";
		$os_code = "macos";
		$os_ver = "X";
	} elseif (preg_match('#Chrome/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
	$browser_name = 'Google Chrome'; $browser_code = 'chrome'; $browser_ver = $matches[1]; 
	if (preg_match('/Windows/i', $ua)) {
	list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
	} else {
	list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
	} 
	} elseif (preg_match('#Arora/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Arora';
		$browser_code = 'arora';
		$browser_ver = $matches[1];
		if (preg_match('/Windows/i', $ua)) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
		} else {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}
	} elseif (preg_match('#Maxthon( |\/)([a-zA-Z0-9.]+)#i', $ua,$matches)) {
		$browser_name = 'Maxthon';
		$browser_code = 'maxthon';
		$browser_ver = $matches[2];
		if (preg_match('/Win/i', $ua)) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
		} else {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}
	} elseif (preg_match('#CriOS/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Chrome for iOS';
		$browser_code = 'crios';
		$browser_ver = $matches[1];
		if (preg_match('/Windows/i', $ua)) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
		} else {
		 	list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}		
	} elseif (preg_match('#Safari/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Safari';
		$browser_code = 'safari';
		$browser_ver = $matches[1];
		if (preg_match('/Windows/i', $ua)) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
		} else {
		 	list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}		
	} elseif (preg_match('#opera mini#i', $ua)) {
		$browser_name = 'Opera Mini';
		$browser_code = 'opera';
		preg_match('#Opera/([a-zA-Z0-9.]+)#i', $ua, $matches);
		$browser_ver = $matches[1];
		if (preg_match('/Windows/i', $ua)) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
		} else {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}
	} elseif (preg_match('#Opera.(.*)Version[ /]([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Opera';
		$browser_code = 'opera';
		$browser_ver = $matches[2];
		if (preg_match('/Windows/i', $ua)) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
		} else {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}
		if (!$os_name) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}
		if (!$os_name) {
			list($os_name, $os_code, $os_ver, $pda_name, $pda_code, $pda_ver) = yundanran_get_access_browser_of_pad_os($ua);
		}
		if (!$os_name) {
			if (preg_match('/Wii/i', $ua)) {
				$os_name = "Nintendo Wii";
				$os_code = "nintendo-wii";
			}
		}
	} elseif (preg_match('#Opera/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Opera Mini';
		$browser_code = 'opera';
		$browser_ver = $matches[1];
		if (preg_match('/Windows/i', $ua)) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
		} else {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}
	} elseif (preg_match('#WebPro/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'WebPro';
		$browser_code = 'webpro';
		$browser_ver = $matches[1];
		$os_name = "PalmOS";
		$os_code = "palmos";
	} elseif (preg_match('#WebPro#i', $ua, $matches)) {
		$browser_name = 'WebPro';
		$browser_code = 'webpro';
		$os_name = "PalmOS";
		$os_code = "palmos";
	} elseif (preg_match('#Netfront/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Netfront';
		$browser_code = 'netfront';
		$browser_ver = $matches[1];
		list($os_name, $os_code, $os_ver, $pda_name, $pda_code, $pda_ver) = yundanran_get_access_browser_of_pad_os($ua);
	} elseif (preg_match('#Xiino/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Xiino';
		$browser_code = 'xiino';
		$browser_ver = $matches[1];
	} elseif (preg_match('/wp-blackberry\/([a-zA-Z0-9.]*)/i', $ua, $matches)) {
		$browser_name = "WordPress for BlackBerry";
		$browser_code = "wordpress";
		$browser_ver = $matches[1];
		$pda_name = "BlackBerry";
		$pda_code = "blackberry";
	} elseif (preg_match('#Blackberry([0-9]+)#i', $ua, $matches)) {
		$pda_name = "Blackberry";
		$pda_code = "blackberry";
		$pda_ver = $matches[1];
	} elseif (preg_match('#Blackberry#i', $ua)) {
		$pda_name = "Blackberry";
		$pda_code = "blackberry";
	} elseif (preg_match('#SPV ([0-9a-zA-Z.]+)#i', $ua, $matches)) {
		$pda_name = "Orange SPV";
		$pda_code = "orange";
		$pda_ver = $matches[1];
	} elseif (preg_match('#LGE-([a-zA-Z0-9]+)#i', $ua, $matches)) {
		$pda_name = "LG";
		$pda_code = 'lg';
		$pda_ver = $matches[1];
	} elseif (preg_match('#MOT-([a-zA-Z0-9]+)#i', $ua, $matches)) {
		$pda_name = "Motorola";
		$pda_code = 'motorola';
		$pda_ver = $matches[1];
	} elseif (preg_match('#Nokia ?([0-9]+)#i', $ua, $matches)) {
		$pda_name = "Nokia";
		$pda_code = "nokia";
		$pda_ver = $matches[1];
	} elseif (preg_match('#NokiaN-Gage#i', $ua)) {
		$pda_name = "Nokia";
		$pda_code = "nokia";
		$pda_ver = "N-Gage";
	} elseif (preg_match('#Blazer[ /]?([a-zA-Z0-9.]*)#i', $ua, $matches)) {
		$browser_name = "Blazer";
		$browser_code = "blazer";
		$browser_ver = $matches[1];
		$os_name = "Palm OS";
		$os_code = "palm";
	} elseif (preg_match('#SIE-([a-zA-Z0-9]+)#i', $ua, $matches)) {
		$pda_name = "Siemens";
		$pda_code = "siemens";
		$pda_ver = $matches[1];
	} elseif (preg_match('#SEC-([a-zA-Z0-9]+)#i', $ua, $matches)) {
		$pda_name = "Samsung";
		$pda_code = "samsung";
		$pda_ver = $matches[1];
	} elseif (preg_match('/wp-iphone\/([a-zA-Z0-9.]*)/i', $ua, $matches)) {
		$browser_name = "WordPress for iOS";
		$browser_code = "wordpress";
		$browser_ver = $matches[1];
		$pda_name = "iPhone & iPad";
		$pda_code = "ipad";
	} elseif (preg_match('/wp-android\/([a-zA-Z0-9.]*)/i', $ua, $matches)) {
		$browser_name = "WordPress for Android";
		$browser_code = "wordpress";
		$browser_ver = $matches[1];
		$pda_name = "Android";
		$pda_code = "android";
	} elseif (preg_match('/wp-windowsphone\/([a-zA-Z0-9.]*)/i', $ua, $matches)) {
		$browser_name = "WordPress for Windows Phone 7";
		$browser_code = "wordpress";
		$browser_ver = $matches[1];
		$pda_name = "Windows Phone 7";
		$pda_code = "windows_phone7";
	} elseif (preg_match('/wp-nokia\/([a-zA-Z0-9.]*)/i', $ua, $matches)) {
		$browser_name = "WordPress for Nokia";
		$browser_code = "wordpress";
		$browser_ver = $matches[1];
		$pda_name = "Nokia";
		$pda_code = "nokia";
	} elseif (preg_match('#SAMSUNG-(S.H-[a-zA-Z0-9_/.]+)#i', $ua, $matches)) {
		$pda_name = "Samsung";
		$pda_code = "samsung";
		$pda_ver = $matches[1];
		if (preg_match('#(j2me|midp)#i', $ua)) {
		$browser_name = "J2ME/MIDP Browser";
		$browser_code = "j2me";
		}
	} elseif (preg_match('#SonyEricsson ?([a-zA-Z0-9]+)#i', $ua, $matches)) {
		$pda_name = "SonyEricsson";
		$pda_code = "sonyericsson";
		$pda_ver = $matches[1];
	} elseif (preg_match('#(j2me|midp)#i', $ua)) {
		$browser_name = "J2ME/MIDP Browser";
		$browser_code = "j2me";
	// mice
	} elseif (preg_match('/GreenBrowser/i', $ua)) {
		$browser_name = 'GreenBrowser';
		$browser_code = 'greenbrowser';
		if (preg_match('/Win/i', $ua)) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
		} else {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}
	} elseif (preg_match('#TencentTraveler ([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'tencent TT Browser';
		$browser_code = 'tencenttraveler';
		$browser_ver = $matches[1];
		if (preg_match('/Windows/i', $ua)) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
		} else {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}
	} elseif (preg_match('#UCWEB([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'UCWEB';
		$browser_code = 'ucweb';
		$browser_ver = $matches[1];
		if (preg_match('/Windows/i', $ua)) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
		} else {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}
	} elseif (preg_match('#MSIE ([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Internet Explorer';
		$browser_ver = $matches[1];
		if ( strpos($browser_ver, '7') !== false || strpos($browser_ver, '8') !== false)
			$browser_code = 'ie8';
		elseif ( strpos($browser_ver, '9') !== false)
			$browser_code = 'ie9';
		elseif ( strpos($browser_ver, '10') !== false)
			$browser_code = 'ie10';
		else
			$browser_code = 'ie';
		list($os_name, $os_code, $os_ver, $pda_name, $pda_code, $pda_ver) = yundanran_get_access_browser_of_windows_os($ua);
	} elseif (preg_match('#Universe/([0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Universe';
		$browser_code = 'universe';
		$browser_ver = $matches[1];
		list($os_name, $os_code, $os_ver, $pda_name, $pda_code, $pda_ver) = yundanran_get_access_browser_of_pad_os($ua);
	}elseif (preg_match('#Netscape[0-9]?/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Netscape';
		$browser_code = 'netscape';
		$browser_ver = $matches[1];
		if (preg_match('/Windows/i', $ua)) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
		} else {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}
	} elseif (preg_match('#^Mozilla/5.0#i', $ua) && preg_match('#rv:([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Mozilla';
		$browser_code = 'mozilla';
		$browser_ver = $matches[1];
		if (preg_match('/Windows/i', $ua)) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
		} else {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}
	} elseif (preg_match('#^Mozilla/([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$browser_name = 'Netscape Navigator';
		$browser_code = 'netscape';
		$browser_ver = $matches[1];
		if (preg_match('/Win/i', $ua)) {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_windows_os($ua);
		} else {
			list($os_name, $os_code, $os_ver) = yundanran_get_access_browser_of_unix_os($ua);
		}
	}else{
        $browser_name = 'Unknow Browser';
		$browser_code = 'null';
	  }
	
	  if (!$pda_name && !$os_name){
        $pda_name = 'Unknow Os';
		$pda_code = 'other';
        $os_name = 'Unknow Os';
		$os_code = 'other';
	  }
	  
	/*
		新增了ip=》国家
		2012年11月10日20:04:10
		将解析ip归功于新浪服务器
		2012年11月30日23:53:22
	*/
	$ip2c = new ip2country();
	$res = $ip2c->get_country($ip);
	if ($res == false)
	{
		$o2c='zz';
		$o3c='zzz';
		$oname='undefined country';
	}
	else
	{
	  $o2c = $res['id2'];
	  $o3c = $res['id3'];
	  $oname = $res['name'];
	}
	$ipinfo=yundanran_get_access_ip_info($ip);
	
	 
	return array
	(
		'country_o2c'=>$o2c,
		'country_o3c'=>$o3c,
		'country_oname'=>$oname,
		'browser_name'=>$browser_name, 
		'browser_code'=>$browser_code, 
		'browser_ver'=>$browser_ver, 
		'os_name'=>$os_name, 
		'os_code'=>$os_code, 
		'os_ver'=>$os_ver, 
		'pda_name'=>$pda_name,
		'pda_code'=>$pda_code, 
		'pda_ver'=>$pda_ver,
		'ipinfo'=>$ipinfo,
	);
}

function yundanran_get_access_ip_info($ip)
{
	// 为了防止页面加载时间被延迟，此方法已屏蔽！！
	// 2013年1月13日18:18:36
	// $url='http://int.dpool.sina.com.cn/iplookup/iplookup.php?format=json&ip=';
	// $str=file_get_contents($url.$ip);
	// $json=json_decode($str);
	// $c=	isset($json->country)?$json->country:'未知国家';
	// $p=	isset($json->province)?$json->province:'未知省份';
	// $c=	trim($c)==''?'未知国家':$c;
	// $p=	trim($p)==''?'未知省份':$p;
	// return $c.' '.$p;
	// $ip='218.192.3.42';
	return '<span class="yundanran-ip2query" data-ip="'.$ip.'">正在查询<img src="'.get_bloginfo('template_url').'/public/image/waiting.gif" alt="..." style="vertical-align:baseline;" /></span>';
}

function yundanran_get_access_browser_of_windows_os($ua) 
{
	$os_name = $os_code = $os_ver = $pda_name = $pda_code = $pda_ver = null;

	if (preg_match('/Windows 95/i', $ua) || preg_match('/Win95/', $ua)) {
		$os_name = "Windows";
		$os_code = "windows";
		$os_ver = "95";
	} elseif (preg_match('/Windows NT 5.0/i', $ua) || preg_match('/Windows 2000/i', $ua)) {
		$os_name = "Windows";
		$os_code = "windows";
		$os_ver = "2000";
	} elseif (preg_match('/Win 9x 4.90/i', $ua) || preg_match('/Windows ME/i', $ua)) {
		$os_name = "Windows";
		$os_code = "windows";
		$os_ver = "ME";
	} elseif (preg_match('/Windows.98/i', $ua) || preg_match('/Win98/i', $ua)) {
		$os_name = "Windows";
		$os_code = "windows";
		$os_ver = "98";
	} elseif (preg_match('/Windows NT 6.0/i', $ua)) {
		$os_name = "Windows";
		$os_code = "windows_vista";
		$os_ver = "Vista";
	} elseif (preg_match('/Windows NT 6.1/i', $ua)) {
		$os_name = "Windows";
		$os_code = "windows_win7";
		$os_ver = "7";	
	} elseif (preg_match('/Windows NT 6.2/i', $ua)) {
		$os_name = "Windows";
		$os_code = "windows_win8";
		$os_ver = "8";	
	} elseif (preg_match('/Windows NT 5.1/i', $ua)) {
		$os_name = "Windows";
		$os_code = "windows";
		$os_ver = "XP";
	} elseif (preg_match('/Windows NT 5.2/i', $ua)) {
		$os_name = "Windows";
		$os_code = "windows";
		if (preg_match('/Win64/i', $ua)) {
			$os_ver = "XP 64 bit";
		} else {
			$os_ver = "Server 2003";
		}
	}
	elseif (preg_match('/Mac_PowerPC/i', $ua)) {
		$os_name = "Mac OS";
		$os_code = "macos";
	}elseif (preg_match('/Windows Phone/i', $ua)) {
		$matches = explode(';',$ua);
		$os_name = $matches[2];
		$os_code = "windows_phone7";
	} elseif (preg_match('/Windows NT 4.0/i', $ua) || preg_match('/WinNT4.0/i', $ua)) {
		$os_name = "Windows";
		$os_code = "windows";
		$os_ver = "NT 4.0";
	} elseif (preg_match('/Windows NT/i', $ua) || preg_match('/WinNT/i', $ua)) {
		$os_name = "Windows";
		$os_code = "windows";
		$os_ver = "NT";
	} elseif (preg_match('/Windows CE/i', $ua)) {
		list($os_name, $os_code, $os_ver, $pda_name, $pda_code, $pda_ver) = yundanran_get_access_browser_of_pad_os($ua);
		$os_name = "Windows";
		$os_code = "windows";
		$os_ver = "CE";
		if (preg_match('/PPC/i', $ua)) {
			$os_name = "Microsoft PocketPC";
			$os_code = "windows";
			$os_ver = '';
		}
		if (preg_match('/smartphone/i', $ua)) {
			$os_name = "Microsoft Smartphone";
			$os_code = "windows";
			$os_ver = '';
		}
	} else{
        $os_name = 'Unknow Os';
		$os_code = 'other';
	  }
	
	return array($os_name, $os_code, $os_ver, $pda_name, $pda_code, $pda_ver);
}

function yundanran_get_access_browser_of_unix_os($ua) 
{
	$os_name = $os_ver = $os_code = null;
		if (preg_match('/Linux/i', $ua)) {
		$os_name = "Linux";
		$os_code = "linux";
		if (preg_match('#Debian#i', $ua)) {
			$os_code = "debian";
			$os_name = "Debian GNU/Linux";
		} elseif (preg_match('#Mandrake#i', $ua)) {
			$os_code = "mandrake";
			$os_name = "Mandrake Linux";
		} elseif (preg_match('#Kindle Fire#i',$ua)) {//for Kindle Fire
			$matches = explode(';',$ua);
			$os_code = "kindle";
			$matches2 = explode(')',$matches[4]);
			$os_name = $matches[2].$matches2[0];
		} elseif (preg_match('#Android#i',$ua)) {//Android
			$matches = explode(';',$ua);
			$os_code = "android";
			$matches2 = explode(')',$matches[4]);
			$os_name = $matches[2].$matches2[0];
		} elseif (preg_match('#SuSE#i', $ua)) {
			$os_code = "suse";
			$os_name = "SuSE Linux";
		} elseif (preg_match('#Novell#i', $ua)) {
			$os_code = "novell";
			$os_name = "Novell Linux";
		} elseif (preg_match('#Ubuntu#i', $ua)) {
			$os_code = "ubuntu";
			$os_name = "Ubuntu Linux";
		} elseif (preg_match('#Red ?Hat#i', $ua)) {
			$os_code = "redhat";
			$os_name = "RedHat Linux";
		} elseif (preg_match('#Gentoo#i', $ua)) {
			$os_code = "gentoo";
			$os_name = "Gentoo Linux";
		} elseif (preg_match('#Fedora#i', $ua)) {
			$os_code = "fedora";
			$os_name = "Fedora Linux";
		} elseif (preg_match('#MEPIS#i', $ua)) {
			$os_name = "MEPIS Linux";
		} elseif (preg_match('#Knoppix#i', $ua)) {
			$os_name = "Knoppix Linux";
		} elseif (preg_match('#Slackware#i', $ua)) {
			$os_code = "slackware";
			$os_name = "Slackware Linux";
		} elseif (preg_match('#Xandros#i', $ua)) {
			$os_name = "Xandros Linux";
		} elseif (preg_match('#Kanotix#i', $ua)) {
			$os_name = "Kanotix Linux";
		} 
	} elseif (preg_match('/FreeBSD/i', $ua)) {
		$os_name = "FreeBSD";
		$os_code = "freebsd";
	} elseif (preg_match('/NetBSD/i', $ua)) {
		$os_name = "NetBSD";
		$os_code = "netbsd";
	} elseif (preg_match('/OpenBSD/i', $ua)) {
		$os_name = "OpenBSD";
		$os_code = "openbsd";
	} elseif (preg_match('/IRIX/i', $ua)) {
		$os_name = "SGI IRIX";
		$os_code = "sgi";
	} elseif (preg_match('/SunOS/i', $ua)) {
		$os_name = "Solaris";
		$os_code = "sun";
	} elseif (preg_match('#iPod.*.CPU.([a-zA-Z0-9.( _)]+)#i', $ua, $matches)) {
		$os_name = "iPod";
		$os_code = "iphone";
		$os_ver = $matches[1];
	} elseif (preg_match('#iPhone.*.CPU.([a-zA-Z0-9.( _)]+)#i', $ua, $matches)) {
		$os_name = "iPhone";
		$os_code = "iphone";
		$os_ver = $matches[1];
	} elseif (preg_match('#iPad.*.CPU.([a-zA-Z0-9.( _)]+)#i', $ua, $matches)) {
		$os_name = "iPad";
		$os_code = "ipad";
		$os_ver = $matches[1];
	} elseif (preg_match('/Mac OS X.([0-9. _]+)/i', $ua, $matches)) {
		$os_name = "Mac OS";
		$os_code = "macos";
		if(count(explode(7,$matches[1]))>1) $matches[1] = 'Lion '.$matches[1];
		elseif(count(explode(8,$matches[1]))>1) $matches[1] = 'Mountain Lion '.$matches[1];
		$os_ver = "X ".$matches[1];
	} elseif (preg_match('/Macintosh/i', $ua)) {
		$os_name = "Mac OS";
		$os_code = "macos";
	} elseif (preg_match('/Unix/i', $ua)) {
		$os_name = "UNIX";
		$os_code = "unix";
	} elseif (preg_match('/CrOS/i', $ua)){
		$os_name="Google Chrome OS";
		$os_code="chromeos";
	} elseif (preg_match('/Fedor.([0-9. _]+)/i', $ua, $matches)){
		$os_name="Fedora";
		$os_code="fedora";
		$os_ver = $matches[1];
	} else{
        $os_name = 'Unknow Os';
		$os_code = 'other';
	}
	  
	return array($os_name, $os_code, $os_ver);
}

function yundanran_get_access_browser_of_pad_os($ua) 
{
	$os_name = $os_code = $os_ver = $pda_name = $pda_code = $pda_ver = null;
	if (preg_match('#PalmOS#i', $ua)) {
		$os_name = "Palm OS";
		$os_code = "palm";
	} elseif (preg_match('#Windows CE#i', $ua)) {
		$os_name = "Windows CE";
		$os_code = "windows";
	} elseif (preg_match('#QtEmbedded#i', $ua)) {
		$os_name = "Qtopia";
		$os_code = "linux";
	} elseif (preg_match('#Zaurus#i', $ua)) {
		$os_name = "Linux";
		$os_code = "linux";
	} elseif (preg_match('#Symbian#i', $ua)) {
		$os_name = "Symbian OS";
		$os_code = "symbian";
	} elseif (preg_match('#PalmOS/sony/model#i', $ua)) {
		$pda_name = "Sony Clie";
		$pda_code = "sony";
	} elseif (preg_match('#Zaurus ([a-zA-Z0-9.]+)#i', $ua, $matches)) {
		$pda_name = "Sharp Zaurus " . $matches[1];
		$pda_code = "zaurus";
		$pda_ver = $matches[1];
	} elseif (preg_match('#Series ([0-9]+)#i', $ua, $matches)) {
		$pda_name = "Series";
		$pda_code = "nokia";
		$pda_ver = $matches[1];
	} elseif (preg_match('#Nokia ([0-9]+)#i', $ua, $matches)) {
		$pda_name = "Nokia";
		$pda_code = "nokia";
		$pda_ver = $matches[1];
	} elseif (preg_match('#SIE-([a-zA-Z0-9]+)#i', $ua, $matches)) {
		$pda_name = "Siemens";
		$pda_code = "siemens";
		$pda_ver = $matches[1];
	} elseif (preg_match('#dopod([a-zA-Z0-9]+)#i', $ua, $matches)) {
		$pda_name = "Dopod";
		$pda_code = "dopod";
		$pda_ver = $matches[1];
	} elseif (preg_match('#o2 xda ([a-zA-Z0-9 ]+);#i', $ua, $matches)) {
		$pda_name = "O2 XDA";
		$pda_code = "o2";
		$pda_ver = $matches[1];
	} elseif (preg_match('#SEC-([a-zA-Z0-9]+)#i', $ua, $matches)) {
		$pda_name = "Samsung";
		$pda_code = "samsung";
		$pda_ver = $matches[1];
	} elseif (preg_match('#SonyEricsson ?([a-zA-Z0-9]+)#i', $ua, $matches)) {
		$pda_name = "SonyEricsson";
		$pda_code = "sonyericsson";
		$pda_ver = $matches[1];
	} elseif (preg_match('#Kindle\/([a-zA-Z0-9. ×\(.\)]+)#i',$ua, $matches)) {//for Kindle
		$pda_name = "kindle";
		$pda_code = "kindle";
		$pda_ver = $matches[1];
	} else {
		$pda_name = 'Unknow Os';
		$pda_code = 'other';
	  }
	  
	return array($os_name, $os_code, $os_ver, $pda_name, $pda_code, $pda_ver);
}

/***********************************************************
	**	获得访问ip
	**	返回ip
	**	1在发布微博同步微博的时候需要用到
	**	2在检测访问信息需要用到
	**	2012年11月3日21:53:20
	**	2012年11月10日19:59:33
***********************************************************/
function yundanran_get_access_ip()
{
	if (isset ( $_SERVER )) {
		if (isset ( $_SERVER ['HTTP_X_FORWARDED_FOR'] )) {
			$aIps = explode ( ',', $_SERVER ['HTTP_X_FORWARDED_FOR'] );
			foreach ( $aIps as $sIp ) {
				$sIp = trim ( $sIp );
				if ($sIp != 'unknown') {
					$sRealIp = $sIp;
					break;
				}
			}
		} elseif (isset ( $_SERVER ['HTTP_CLIENT_IP'] )) {
			$sRealIp = $_SERVER ['HTTP_CLIENT_IP'];
		} else {
			if (isset ( $_SERVER ['REMOTE_ADDR'] )) {
				$sRealIp = $_SERVER ['REMOTE_ADDR'];
			} else {
				$sRealIp = '0.0.0.0';
			}
		}
	} else {
		if (getenv ( 'HTTP_X_FORWARDED_FOR' )) {
			$sRealIp = getenv ( 'HTTP_X_FORWARDED_FOR' );
		} elseif (getenv ( 'HTTP_CLIENT_IP' )) {
			$sRealIp = getenv ( 'HTTP_CLIENT_IP' );
		} else {
			$sRealIp = getenv ( 'REMOTE_ADDR' );
		}
	}
	$sRealIp=(!preg_match('/\d+\.\d+\.\d+\.\d/',$sRealIp,$tmp))?'127.0.0.1':$sRealIp;
	
	if($sRealIp=='127.0.0.1')
	{
		$socket = socket_create(AF_INET, SOCK_STREAM, 6);  
		$ret = @socket_connect($socket,'ns1.dnspod.net',6666);  
		$buf = @socket_read($socket, 16);  
		socket_close($socket);
		if($buf)$sRealIp=$buf;
	}	

	
	return $sRealIp;
}





/*
******************************************************************
	kv 数据表
	k不能重复 255 长度
	v可以重复 255 长度
	
	*增		yundanran_kv_add($key,$value);
	*删		yundanran_kv_delete($key);
	*改		yundanran_kv_update($old_key,$new_value);
	*查		yundanran_kv_find($key);
	
	2012年6月19日20:38:44
*******************************************************************	
*/
function yundanran_kv_is()
{
	global $wpdb;
	$table = $wpdb->prefix.'yundanran_kv';
	if($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table)
	{
		$sql="CREATE TABLE ".$table." 
		(
		   k varchar(255) NOT NULL,
		   v varchar(255) NOT NULL
		)  CHARSET=UTF8;
		";
		$s=$wpdb->query($sql);
		$sql2="ALTER TABLE `".$table."` ADD INDEX (`k`)";
		$s=$wpdb->query($sql2);
	}
}
function yundanran_kv_add($key,$value)
{
	if(!$key || !$value)return -1;
	yundanran_kv_is();
	$s=yundanran_kv_has($key);
	if($s==1)return -2;//重复了
	global $wpdb;
	$table = $wpdb->prefix.'yundanran_kv';
	$array=$wpdb->escape(array('k'=>$key,'v'=>$value));
	$num=$wpdb->insert($table,$array);
	return $num;
}
function yundanran_kv_delete($key)
{
	if(!$key)return -1;
	yundanran_kv_is();
	$s=yundanran_kv_has($key);
	if($s!=1)return -2;//没有找到
	global $wpdb;
	$table = $wpdb->prefix.'yundanran_kv';
	$array=$wpdb->escape(array('k'=>$key));
	$num=$wpdb->delete($table,$array);
	return $num;
}
function yundanran_kv_update($old_key,$new_value)
{
	if(!$old_key || !$new_value)return -1;
	yundanran_kv_is();
	global $wpdb;
	$table = $wpdb->prefix.'yundanran_kv';
	$old_key=$wpdb->escape($old_key);
	$new_value=$wpdb->escape($new_value);
	$s=yundanran_kv_has($old_key);
	if($s==0)//没有找到就新增
	{
		$num=yundanran_kv_add($old_key,$new_value);
	}
	else if($s==1)//找到就修改
	{
		$new=$wpdb->escape(array('v'=>$new_value));
		$old=$wpdb->escape(array('k'=>$old_key));
		$num=$wpdb->update($table,$new,$old);
	}
	return $num;
}
function yundanran_kv_find($key)
{
	if(!$key)return -1;
	yundanran_kv_is();
	global $wpdb;
	$table = $wpdb->prefix.'yundanran_kv';
	$key=$wpdb->escape($key);
	$s=$wpdb->get_results("SELECT * FROM $table WHERE k='$key' limit 1");
	if($s)
		$value=$s[0]->v;
	else
		$value=0;
	return $value;
}
function yundanran_kv_has($key)
{
	if(!$key)return -1;
	yundanran_kv_is();
	global $wpdb;
	$table = $wpdb->prefix.'yundanran_kv';
	$sql="SELECT * FROM $table WHERE k='$key' limit 1";
	$s=$wpdb->get_results($sql);
	if(count($s)==0)return 0;
	else return 1;
	// return count($s);
}


/*
	time 
	多少分钟以前
*/
function yundanran_time_period($cur_time)
{
	$hour=(int)date('H',$cur_time);
	if($hour>23 || $hour<1)
	{
		$hour='午夜'.$hour;
	}
	else if($hour>=1 && $hour<5)
	{
		$hour='凌晨'.$hour;
	}
	else if($hour>=5 && $hour<12)
	{
		$hour='上午'.$hour;
	}
	else if($hour>=12 && $hour<13)
	{
		$hour='中午'.$hour;
	}
	else if($hour>=13 && $hour<16)
	{
		$hour='下午'.$hour;
	}
	else if($hour>=16 && $hour<18)
	{
		$hour='傍晚'.$hour;
	}
	else if($hour>=18 && $hour<24)
	{
		$hour='晚上'.$hour;
	}
	return $hour;
}


function yundanran_time_ago($cur_time)
{
	$cur_time=(int)$cur_time;
	$agoTime = time() - $cur_time;
	// $hour=yundanran_time_period($cur_time);
	$hour=(int)date('H',$cur_time);
    if ($agoTime<=60) 
	{
		$agoTime=($agoTime<0)?0:$agoTime;
        return '刚刚';
    }
	else if($agoTime<=60*60 && $agoTime > 60 )
	{
        return intval($agoTime/60) .' 分钟前';
    }
	else if(date('Y',time())==date('Y',$cur_time) && date('m',time())==date('m',$cur_time) && date('d',time())==date('d',$cur_time) && $agoTime>60*60)
	{
		$_H=date('H',time())-date('H',$cur_time);
		return $_H.'小时前';
    }
	else if(date('Y',time())==date('Y',$cur_time) && date('m',time())==date('m',$cur_time) && date('d',time())-1==date('d',$cur_time))
	{
		return '昨天 '.$hour.date(':i',$cur_time);
    }
	else if(date('Y',time())==date('Y',$cur_time) && date('m',time())==date('m',$cur_time) && date('d',time())-1==date('d',$cur_time))
	{
		return '前天 '.$hour.date(':i',$cur_time);
    }
	else
	{
		$cur_year=date('Y',$cur_time);
		$this_year=date('Y',time());
		$year=($cur_year-$this_year==0)?
		'':
		substr($cur_year,-2).'年';



		$month=(int)date('m',$cur_time);
		($month<10)?substr($month.'',1,1):$month;
		$month.='月';
		
		$day=(int)date('d',$cur_time);
		($day<10)?substr($day.'',1,1):$day;
		$day.='日 ';
		
		$min=':'.date('i',$cur_time);
		
		$yundanran_time_ago=$year.$month.$day.$hour.$min;
        return $yundanran_time_ago;
    }
}
	
/*
	定义 mb_strlen
*/
// /*
if ( !function_exists('mb_strlen') ) 
{
	function mb_strlen ($text, $encode) 
	{
		if (strtoupper($encode)=='UTF-8')
		{
			return preg_match_all('%(?:
					  [\x09\x0A\x0D\x20-\x7E]           # ASCII
					| [\xC2-\xDF][\x80-\xBF]            # non-overlong 2-byte
					|  \xE0[\xA0-\xBF][\x80-\xBF]       # excluding overlongs
					| [\xE1-\xEC\xEE\xEF][\x80-\xBF]{2} # straight 3-byte
					|  \xED[\x80-\x9F][\x80-\xBF]       # excluding surrogates
					|  \xF0[\x90-\xBF][\x80-\xBF]{2}    # planes 1-3
					| [\xF1-\xF3][\x80-\xBF]{3}         # planes 4-15
					|  \xF4[\x80-\x8F][\x80-\xBF]{2}    # plane 16
					)%xs',$text,$out);
		}
		else
		{
			return strlen($text);
		}
	}
}
// */

/*
	定义 mb_substr
*/
// /*
if (!function_exists('mb_substr')) 
{
    function mb_substr($str, $start, $len = '', $encoding="UTF-8")
	{
        $limit = strlen($str);
 
        for ($s = 0; $start > 0;--$start) 
		{// found the real start
            if ($s >= $limit)
			{
                break;
			}
            if ($str[$s] <= "\x7F")
            {
				++$s;
			}
            else 
			{
                ++$s; // skip length
 
                while ($str[$s] >= "\x80" && $str[$s] <= "\xBF")
                    ++$s;
            }
        }
 
        if ($len == '')
		{
            return substr($str, $s);
        }
		else
		{
            for ($e = $s; $len > 0; --$len) 
			{//found the real end
                if ($e >= $limit)
                {
					break;
				}
                if ($str[$e] <= "\x7F")
                {
					++$e;
				}
                else 
				{
                    ++$e;//skip length
                    while ($str[$e] >= "\x80" && $str[$e] <= "\xBF" && $e < $limit)
                    {
						++$e;
					}
                }
            }
		}
        return substr($str, $s, $e - $s);
    }
}
// */

/*
	统计字符数量
*/
function yundanran_string_count($string)
{   
	$search = array 
	(
		"'<script[^>]*?>.*?</script>'si",  // 去掉 javascript 
		"'<[\/\!]*?[^<>]*?>'si",           // 去掉 HTML 标记 
		"'([\r\n])[\s]+'",                 // 去掉空白字符 
		"'&(quot|#34);'i",                 // 替换 HTML 实体 
		"'&(amp|#38);'i", 
		"'&(lt|#60);'i", 
		"'&(gt|#62);'i", 
		"'&(nbsp|#160);'i", 
		"'&(iexcl|#161);'i", 
		"'&(cent|#162);'i", 
		"'&(pound|#163);'i", 
		"'&(copy|#169);'i", 
		"'&#(\d+);'e"
	);                   

	$replace = array 
	(
		"", 
		"", 
		"\\1", 
		"\"", 
		"&", 
		"<", 
		">", 
		" ", 
		chr(161), 
		chr(162), 
		chr(163), 
		chr(169), 
		"chr(\\1)"
	); 
	$string2 = preg_replace($search, $replace, $string); 
	// $string3 = str_replace(" ","",$string2); //去掉空格 

	$length=0; 
	$string3=(string)$string2;
	$length=mb_strlen($string3,'utf-8');
	return $length; 
}



/***********************************************************
 * 生成摘要【含有标签样式的摘要】
 * @param (string) $body
 *  正文
 * @param (int) $size
 *  摘要长度
 * @param (string) $end_str
 *  结束字符
***********************************************************/
function yundanran_content_summary($body,$size,$end_str)
{
	$end_str=($end_str=='')?'...':$end_str;	
	$_size=mb_strlen($body, 'utf-8');
	if($_size<=$size)
	{
		return $body;
	}
	$strlen_var=strlen($body);
	
	// 不包含 html 标签
	if(strpos($body, '<') === false)
	{
		return mb_substr($body, 0, $size).$end_str;
	}

	// 包含截断标志，优先
	if($e = strpos($body, '<!-- break -->'))
	{
		return mb_substr($body, 0, $e).$end_str;
	}

	// html 代码标记
	$html_tag = 0;

	// 摘要字符串
	$summary_string = '';

	/**
	* 数组用作记录摘要范围内出现的 html 标签
	* 开始和结束分别保存在 left 和 right 键名下
	* 如字符串为：<h3><p><b>a</b></h3>，假设 p 未闭合
	* 数组则为：array('left' => array('h3', 'p', 'b'), 'right' => 'b', 'h3');
	* 仅补全 html 标签，<? <% 等其它语言标记，会产生不可预知结果
	*/
	$html_array = array('left' => array(), 'right' => array());
	for($i = 0; $i < $strlen_var; ++$i)
	{
		if(!$size)
		{
		  break;
		}
	 
		$current_var = substr($body, $i, 1);
	 
		if($current_var == '<')
		{
		  // html 代码开始
		  $html_tag = 1;
		  $html_array_str = '';
		}
		else if($html_tag == 1)
		{
			// 一段 html 代码结束
			if($current_var == '>')
			{
				//去除首尾空格，如 <br /  > < img src="" / > 等可能出现首尾空格
				$html_array_str = trim($html_array_str);

				// 判断最后一个字符是否为 /，若是，则标签已闭合，不记录
				if(substr($html_array_str, -1) != '/')
				{

					// 判断第一个字符是否 /，若是，则放在 right 单元
					$f = substr($html_array_str, 0, 1);
					if($f == '/')
					{
						// 去掉 /
						$html_array['right'][] = str_replace('/', '', $html_array_str);
					}
					else if($f != '?' && $f!='<{')
					{
						// 判断是否为 ?，若是，则为 PHP 代码，跳过
						 //2011年12月9日11:45:51
						 //判断是否为<{thinkPHP模板标记
						/**
						 * 判断是否有半角空格，若有，以空格分割，第一个单元为 html 标签
						 * 如 <h2 class="a"> <p class="a">
						 */
						if(strpos($html_array_str, ' ') !== false)
						{
						  // 分割成2个单元，可能有多个空格，如：<h2 class="" id="">
						  $html_array['left'][] = strtolower(current(explode(' ', $html_array_str, 2)));
						}
						else
						{
						  /**
						   * * 若没有空格，整个字符串为 html 标签，如：<b> <p> 等
						   * 统一转换为小写
						   */
						  $html_array['left'][] = strtolower($html_array_str);
						}
					}
				}
		 
				// 字符串重置
				$html_array_str = '';
				$html_tag = 0;
			}
			else
			{
				// * 将< >之间的字符组成一个字符串
				// * 用于提取 html 标签
				$html_array_str .= $current_var;
			}
		}
		else
		{
			// 非 html 代码才记数
			--$size;
		}
		 
		$ord_var_c = ord($body{$i});
		 
		switch (true)
		{
			case (($ord_var_c & 0xE0) == 0xC0):// 2 字节
			$summary_string .= substr($body, $i, 2);
			$i += 1;
			break;
			
			case (($ord_var_c & 0xF0) == 0xE0):// 3 字节
			$summary_string .= substr($body, $i, 3);
			$i += 2;
			break;
			
			case (($ord_var_c & 0xF8) == 0xF0):// 4 字节
			$summary_string .= substr($body, $i, 4);
			$i += 3;
			break;
			
			case (($ord_var_c & 0xFC) == 0xF8):// 5 字节
			$summary_string .= substr($body, $i, 5);
			$i += 4;
			break;
			
			case (($ord_var_c & 0xFE) == 0xFC):// 6 字节
			$summary_string .= substr($body, $i, 6);
			$i += 5;
			break;
			
			default:// 1 字节
			$summary_string .= $current_var;
		}
	}

	if($html_array['left'])
	{
		/**
		 * 比对左右 html 标签，不足则补全
		 */
		 
		/**
		 * 交换 left 顺序，补充的顺序应与 html 出现的顺序相反
		 * 如待补全的字符串为：<h2>abc<b>abc<p>abc
		 * 补充顺序应为：</p></b></h2>
		 */
		$html_array['left'] = array_reverse($html_array['left']);
	 
		foreach($html_array['left'] as $index => $tag)
		{
			// 判断该标签是否出现在 right 中
			$key = array_search($tag, $html_array['right']);
			if($key !== false)
			{
				// 出现，从 right 中删除该单元
				unset($html_array['right'][$key]);
			}
			else
			{
				// 没有出现，需要补全
				$summary_string .= '</'.$tag.'>';
			}
		}
	}
	
	$summary_string.=$end_str;
	
	return $summary_string;
}




/************************************************************
	**	截取中文字符串
	**	2012年11月3日21:55:31
*************************************************************/
function yundanran_substr_cn($str, $start=0 ,$length)
{
	$length-=1;
	$lgocl_str=$str;
    if(strlen($str) < $start+1)
    {
        return '';
    }
    preg_match_all("/./su", $str, $ar);
    $str = '';
    $tstr = '';

    //为了兼容mysql4.1以下版本,与数据库varchar一致,这里使用按字节截取
    for($i=0; isset($ar[0][$i]); $i++)
    {
        if(strlen($tstr) < $start)
        {
            $tstr .= $ar[0][$i];
        }
        else
        {
            if(strlen($str) < $length + strlen($ar[0][$i]) )
            {
                $str .= $ar[0][$i];
            }
            else
            {
                break;
            }
        }
    }
    return $str;
}








/**
 * @package     BugFree
 * @version     $Id: FunctionsMain.inc.php,v 1.32 2005/09/24 11:38:37 wwccss Exp $
 *
 *
 * Sort an two-dimension array by some level two items use array_multisort() function.
 *
 * yundanran_2array_sort($Array,"Key1","SORT_ASC","SORT_RETULAR","Key2"……)
 * @author                      Chunsheng Wang <wwccss@263.net>
 * @param  array   $ArrayData   the array to sort.
 * @param  string  $KeyName1    the first item to sort by.
 * @param  string  $SortOrder1  the order to sort by("SORT_ASC"|"SORT_DESC")
 * @param  string  $SortType1   the sort type("SORT_REGULAR"|"SORT_NUMERIC"|"SORT_STRING")
 * @return array                sorted array.
 */
function yundanran_2array_sort($ArrayData,$KeyName1,$SortOrder1 = "SORT_ASC",$SortType1 = "SORT_REGULAR")
{
    if(!is_array($ArrayData)) return $ArrayData;
    
    // Get args number.
    $ArgCount = func_num_args();
    // Get keys to sort by and put them to SortRule array.
    for($I = 1;$I < $ArgCount;$I ++)
    {
        $Arg = func_get_arg($I);
        if(!eregi("SORT",$Arg))
        {
            $KeyNameList[] = $Arg;
            $SortRule[]    = '$'.$Arg;
        }
        else $SortRule[]   = $Arg;
    }
    // Get the values according to the keys and put them to array.
    foreach($ArrayData AS $Key => $Info)
    {
        foreach($KeyNameList AS $KeyName) ${$KeyName}[$Key] = strtolower($Info[$KeyName]);
    }
    
    // Create the eval string and eval it.
    $EvalString = 'array_multisort('.join(",",$SortRule).',$ArrayData);';
    eval ($EvalString);
    return $ArrayData;
}