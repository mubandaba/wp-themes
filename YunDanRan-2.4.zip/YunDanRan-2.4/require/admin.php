<?php
/*
	默认邮件
*/
// 更改默认发信地址
function yundanran_mail_from()
{
	return YDR_MAIL_FROM;
}
add_filter('wp_mail_from','yundanran_mail_from');

// 更改默认发信人名字
function yundanran_mail_from_name()
{
	return YDR_MAIL_NAME;
}
add_filter('wp_mail_from_name','yundanran_mail_from_name');


//更改默认发信文本格式
function yundanran_mail_content_type()
{
	return 'text/html';
}
add_filter('wp_mail_content_type','yundanran_mail_content_type');

// add_filter('wp_mail_content_type',create_function('', 'return "text/html";'));
// add_filter('wp_mail_from',create_function('', 'return "admin@yundanran.com";'));
// add_filter('wp_mail_from_name',create_function('', 'return "云淡然（博客）";'));



//去掉控制面板首页不必要模块
function yundanran_remove_dashboard_widgets() 
{
    global $wp_meta_boxes;

    // 以下这一行代码将删除 "快速发布" 模块
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_quick_press']);

    // 以下这一行代码将删除 "引入链接" 模块
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_incoming_links']);

    // 以下这一行代码将删除 "插件" 模块
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_plugins']);

    // 以下这一行代码将删除 "近期评论" 模块
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_recent_comments']);

    // 以下这一行代码将删除 "近期草稿" 模块
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_recent_drafts']);

    // 以下这一行代码将删除 "WordPress 开发日志" 模块
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_primary']);

    // 以下这一行代码将删除 "其它 WordPress 新闻" 模块
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_secondary']);

    // 以下这一行代码将删除 "概况" 模块
    // unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_right_now']);
}
add_action('wp_dashboard_setup', 'yundanran_remove_dashboard_widgets' );

/*
	jpeg图片质量100%
*/
add_filter('jpeg_quality', create_function('','return 100;'));


/*
	编辑器增强
*/
function yundanran_editor_ext($initArray) 
{
	$ext = 'pre[id|name|class|style],span[class|style]';  //注意：格式为“标签一[属性一|属性二],标签二[属性一|属性二|属性三]”
	if ( isset( $initArray['extended_valid_elements'] ) ) 
	{
		$initArray['extended_valid_elements'] .= ',' . $ext;
	}
	else 
	{
		$initArray['extended_valid_elements'] = $ext;
	}
	return $initArray;

}
add_filter('tiny_mce_before_init', 'yundanran_editor_ext');	//添加合法标签

function yundanran_spellchecker_languages($initArray)
{
	$initArray['spellchecker_languages'] = '+Chinese=zh,English=en';
	return $initArray;
}
add_filter('tiny_mce_before_init', 'yundanran_spellchecker_languages');		//添加中文拼写检查

add_editor_style('public/style/editor.20130203.css');  	//增加编辑器内容样式

/*
加粗（bold）、斜体（italic）、下划线（underline）、删除线（strikethrough）、
左对齐（justifyleft）、居中（justifycenter）、右对齐（justfyright）、
两端对齐（justfyfull）、无序列表（bullist）、编号列表（numlist）、
减少缩进（outdent）、缩进（indent）、剪切（cut）、复制（copy）、粘贴（paste）、
撤销（undo）、重做（redo）、插入超链接（link）、取消超链接（unlink）、
插入图片（image）、清除格式（removeformat）、帮助（wp_help）、
打开HTML代码编辑器（code）、水平线（hr）、清除冗余代码（cleanup）、
格式选择（formmatselect）、字体选择（fontselect）、字号选择（fontsizeselect）、
样式选择（styleselect）、上标（sub）、下标（sup）、字体颜色（forecolor）、
字体背景色（backcolor）、特殊符号（charmap）、隐藏按钮显示开关（wp_adv）、
隐藏按钮区起始部分（wp_adv_start）、隐藏按钮区结束部分（wp_adv_end）、
锚文本（anchor）、新建文本（类似于清空文本）（newdocument）、
插入more标签（wp_more）、插入分页标签（wp_page）、拼写检查（spellchecker）。
*/
function yundanran_editor_buttons_1($buttons)
{
	$buttons[] = 'forecolor';   
	$buttons[] = 'backcolor';   
	return $buttons;   
}
add_filter("mce_buttons", "yundanran_editor_buttons_1"); 

function yundanran_editor_buttons_2($buttons)
{   
	$buttons[] = 'image';   
	$buttons[] = 'hr';   
	// $buttons[] = 'del';   
	// $buttons[] = 'sub';   
	// $buttons[] = 'sup';    
	// $buttons[] = 'fontselect';   
	// $buttons[] = 'fontsizeselect';   
	// $buttons[] = 'cleanup';      
	// $buttons[] = 'styleselect';   
	// $buttons[] = 'wp_page';   
	// $buttons[] = 'anchor';   
	return $buttons;   
}   
add_filter("mce_buttons_2", "yundanran_editor_buttons_2");  


/*
	注册菜单
*/
register_nav_menus(array('primary' => '多级菜单'));//注册菜单



function yundanran_user_contactmethods($contactmethods) 
{
	unset($contactmethods['aim']);
	unset($contactmethods['yim']);
	unset($contactmethods['jabber']);
	$contactmethods['sina_weibo'] = '新浪微博';
	$contactmethods['tx_weibo'] = '腾讯微博';
	$contactmethods['qq_num'] = 'QQ号码';
	return $contactmethods;
}
add_filter('user_contactmethods','yundanran_user_contactmethods');




function yundanran_admin_footer()
{
	if(strpos($_SERVER['PHP_SELF'],'post-new.php') || strpos($_SERVER['PHP_SELF'],'post.php'))
	{
		require_once(TEMPLATEPATH.'/require/editor.php');
	}
}
add_action('admin_footer','yundanran_admin_footer');