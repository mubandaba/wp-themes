<?php

/*#################################################
解析 youku tudou 56 ku6 sina 视频的信息
2013年1月26日16:46:35
#################################################*/
function yundanran_parse_video_info($url)
{
	require_once("VideoUrlParser.class.php");
	$info = VideoUrlParser::parse($url);
	// print_r($info);
	if(!empty($info))
	{
		$info['data']=0;
		return $info;//title、img、url、swf、object
	}
	else
	{
		return array('data'=>-1);
	}
}
add_action('init', '_yundanran_parse_video_info');
function _yundanran_parse_video_info()
{
	if(isset($_POST['action']) && $_POST['action']=='_yundanran_parse_video_info')
	{
		if(isset($_POST['url']) && $_POST['url']!='')
		{
			$url=		trim(stripslashes(strip_tags($_POST['url'])));
			
			$width=		isset($_POST['width'])?(int)trim(stripslashes(strip_tags($_POST['width']))):600;
			$width=		(empty($width))?600:$width;
			
			$height=	isset($_POST['height'])?(int)trim(stripslashes(strip_tags($_POST['height']))):400;
			$height=	(empty($height))?400:$height;
			
			$auto=		isset($_POST['auto'])?trim(stripslashes(strip_tags($_POST['auto']))):false;
			$auto=		!$auto?false:true;
			$auto_num=	$auto?1:0;
			
			$arr=yundanran_parse_video_info($url);
			if($arr['data']==0)
			{
				$data=0;
				$info=$arr;
			}
			else
			{
				$data=-1;
				$info='错误：该url暂时无法解析。';
			}
		}
		else
		{
			$data=-99;
			$info='错误：解析url不能为空。';
		}
		$json['data']=$data;
		$json['info']=$info;
		header("Content-Type: application/json");
		echo json_encode($json);
		exit;	
	}
}




/****************************************************
	**	替换img的src为new_src
	@	头像，图片
	@	新地址
	**	2013年1月26日16:53:30
****************************************************/
function yundanran_replace_image_src($avatar,$new_src)
{
	$pt="/<img(.*)>/";
	preg_match($pt,$avatar,$ms);
	$attr_arr=explode(" ",trim($ms[1]));
	foreach($attr_arr as $key=>$attr)
	{
		if(preg_match("/^src=[\"']([^\"']+)[\"']/",trim($attr),$attrs))
		{
			$attr_arr[$key]="src='{$new_src}'";
		}
	}
	$new_attr=implode(" ",$attr_arr);
	return "<img {$new_attr} />";
}


/*=====================================
==	头像缓存
==	直接filter会导致用户后台设置的评论默认头像挂掉
==	2013年1月24日23:40:36
======================================*/
// add_filter('get_avatar', 'yundanran_avatar_cache');
function yundanran_avatar_cache($avatar)
{
	if(!YDR_AVATAR_CACHE)return $avatar;
	
	$src=yundanran_get_avatar_src("","",$avatar);
	
	$dt=30*24*60*60;//缓存时间
	$url=get_bloginfo('template_url').'/public/image/avatar';
	$path=TEMPLATEPATH."/public/image/avatar/";
	$arr = parse_url($src);
	preg_match("/[^\/]+$/",$arr['path'],$path_arr);
	$md5=$path_arr?$path_arr[0]:"null";
	
	$file=$path.$md5.".png";
	
	
	// 如果头像不文件存在 || 不在缓存时间内
	if(!is_file($file) || (time()-filemtime($file))>$dt)
	{
		preg_match("/s=([^=&]+)&/",$arr['query'],$query);
		
		// 解析URL的query值
		$query_arr=yundanran_parse_url_query($arr['query']);
		
		// s修改为100
		$query_arr['s']=100;
		$new_query=yundanran_url_query2string($query_arr);
		$arr['query']=$new_query;
		$new_src=$arr['scheme'].'://'.$arr['host'].$arr['path'];
		$new_src.=isset($arr['query'])?$arr['query'].'?'.$arr['query']:'';
		
		if(!is_dir($path))mkdir($path);
		
		// 如果不能get请求到头像信息，则返回
		$args=array
		(
			'body'=>''
		);
		$response=wp_remote_get($src,$args);
		if(is_wp_error($response))
		{
			$dft_src=get_bloginfo('template_url').'/public/image/avatar.png';
			return yundanran_replace_image_src($avatar,$dft_src);
		}
		
		// 复制在想头像到文件夹
		copy(htmlspecialchars_decode($new_src), $file);
	}
	$out=$url."/{$md5}.png";
	
	return yundanran_replace_image_src($avatar,$out);
}
function yundanran_parse_url_query($query)
{ 
	$queryParts = explode('&', $query); 
	
	$params = array(); 
	foreach ($queryParts as $param) 
	{ 
		$item = explode('=', $param); 
		$params[$item[0]] = $item[1]; 
	} 
	
	return $params; 
}
function yundanran_url_query2string($query_array)
{
	$string="";
	$i=0;
	foreach($query_array as $key=>$value)
	{
		$string.=($i==0)?
		"$key=$value":
		"&$key=$value";
		$i++;
	}
	return $string;
}




/*=============================================================
==	主题禁止评论表单评论
==	杜绝非法评论，任何垃圾评论都会被拒绝
==	评论机器也会拒之门外
==	2012年11月10日18:37:27
==============================================================*/
function yundanran_preprocess_comment($incoming_comment)
{
	$ct 		=wp_get_theme();
	$name		=$ct->display('Name');
	$author		=$ct->display('Author');
	$version	=$ct->display('Version');
	if(!isset($_POST['__yundanran__']) || $_POST['__yundanran__']!=$_SESSION['__yundanran__'] || !isset($_SESSION['__yundanran__']))
	{
		$error='<b style="color:#950003;">错误：非法评论，'.get_bloginfo('name')."已禁止评论表单评论！</b>(<a href='javascript:history.go(-1);' title='点击返回刚才页面'>点击返回刚才页面</a>)
		<p style='text-align:right;color:#ED4B4D;'>主题：<b>$name</b><em style='margin:0 10px;'>V$version</em>By<b style='margin-left:10px;'>$author</b></p>
		";
		wp_die($error);
	}
	
	
	$comment_content=$incoming_comment['comment_content'];
	
	if($comment_content!='' 
	&& yundanran_string_count($comment_content)>=YDR_MIN_WORD_LIMIT 
	&& yundanran_string_count($comment_content)<=YDR_MAX_WORD_LIMIT)
	{
		// 是否限制用户输入字符类型
		if(YDR_WORD_LIMIT)
		{
			if(!preg_match("/[\x{4e00}-\x{9fa5}]+/u",$comment_content))
			{
				wp_die('错误：评论内容必须有中文字符！');
			}
		}
	}
	else if($comment_content=='')
	{
		wp_die('错误：评论内容不能为空！');
	}
	else if(yundanran_string_count($comment_content)<YDR_MIN_WORD_LIMIT)
	{
		wp_die('错误：评论内容最少'.YDR_MIN_WORD_LIMIT.'字！');
	}
	else if(yundanran_string_count($comment_content)>YDR_MAX_WORD_LIMIT)
	{
		wp_die('错误：评论内容最多'.YDR_MAX_WORD_LIMIT.'字！');
	}
	return($incoming_comment);
}
add_filter('preprocess_comment','yundanran_preprocess_comment');



add_action('init', '_yundanran_get_comments_li');
function _yundanran_get_comments_li()
{
	if(isset($_POST['post_id']) && isset($_POST['page_id']) && isset($_POST['action']) && $_POST['action']='_yundanran_get_comments_li')
	{
		$post_id=intval(stripslashes(strip_tags($_POST['post_id'])));
		$page_id=intval(stripslashes(strip_tags($_POST['page_id'])));
		$comment_order		=get_option('comment_order');
		$per_page			=get_option('comments_per_page');
		$default_comments_page			=get_option('default_comments_page');//newest oldest
		if($post_id<=0 || $page_id<=0 || !is_numeric($post_id) || !is_numeric($page_id))
		{
			wp_die('文章id或分页id错误！');
			exit;
		}
		global $wp_query,$wpdb;
		
		if(is_user_logged_in())
		{
			global $current_user;
			get_currentuserinfo();
			$user_ID 			=$current_user->ID;
		}
		else
		{
			$comment_author=isset($_COOKIE["comment_author_".COOKIEHASH])?$_COOKIE["comment_author_".COOKIEHASH]:'';
			$comment_author_email=isset($_COOKIE["comment_author_email_".COOKIEHASH])?$_COOKIE["comment_author_email_".COOKIEHASH]:'';
		}
		
		// 用户登录
		if ( $user_ID)
		{
			$comments_query = $wpdb->get_results($wpdb->prepare("SELECT * FROM $wpdb->comments WHERE comment_post_ID = %d AND (comment_approved = '1' OR ( user_id = %d AND comment_approved = '0' ) )  ORDER BY comment_date_gmt", $post_id, $user_ID));
		}
		// 无登录
		else if ( empty($comment_author) )
		{
			$comments_query = get_comments( array('post_id' => $post_id, 'status' => 'approve', 'order' => 'ASC') );
		}
		// 访客登录
		else
		{
			$comments_query = $wpdb->get_results($wpdb->prepare("SELECT * FROM $wpdb->comments WHERE comment_post_ID = %d AND ( comment_approved = '1' OR ( comment_author = %s AND comment_author_email = %s AND comment_approved = '0' ) ) ORDER BY comment_date_gmt", $post_id, wp_specialchars_decode($comment_author,ENT_QUOTES), $comment_author_email));
		}
		
		$args = array
		(
			'post_id'       =>$post_id,
			'status'		=>'approve',
			'order'			=>'ASC',//为了评论，还是固定吧
		);
		$wp_query->comments = $comments_query;
		echo '<ol>';
		yundanran_list_comments($page_id);
		echo '</ol>';
		// 一级评论总数
		$comment_count=$wpdb->get_var("SELECT count(*) FROM $wpdb->comments WHERE comment_post_ID = $post_id AND comment_type = '' AND comment_approved = 1 AND comment_parent=0");
		// 分页总数
		$page_count=ceil($comment_count/$per_page);
		
		$paged=$default_comments_page=='newest'?$page_id-1:$page_id+1;
		if($page_id>=1 && $page_count>=1 && $paged<=$page_count && $paged>=1)
		{
			echo '<div id="page" class="comments-page"><a href="#" data-page_id="'.$paged.'">点击载入更多评论</a></div>';
		}
		// wp_reset_query();
		exit;
	}
}




/*
	*给评论作者的链接新窗口打开
	*2012年6月23日21:00:23
*/
function yundanran_get_comment_author_link($url)
{
	$return=$url;
	$p1="/^<a .*/i";
	$p2="/^<a ([^>]*)>(.*)/i";
	if(preg_match($p1,$return))
	{
		$return=preg_replace($p2,"<a $1 target='_blank'>$2",$return);
	}
	return $return;
}
add_filter('get_comment_author_link','yundanran_get_comment_author_link');


/****************************************************************
	列出最近的评论
	如果有最近评论id，那么输出的评论都在这条评论之后的评论
	参数1	输出数量
	参数2	是否显示 admin 的评论,默认false
	参数3	最近的评论id，默认0
	2012年4月28日21:53:22
	2012年11月11日13:58:34
*****************************************************************/
function yundanran_last_comments($limit,$admin=false,$last_comment_ID=0)
{
	global $wpdb;
	global $comment;
	if(is_user_logged_in())
	{
		global $current_user;
		get_currentuserinfo();
		$user_id 			=$current_user->ID;
		$is_admin=($user_id==YDR_ADMIN_ID)?1:0;
	}
	else
	{
		$is_admin=0;
	}
	if($limit=='' || !$limit)$limit=10;
	$sql="select * from ".$wpdb->comments;
	$sql.=($admin==false)?" where user_id!='1' and":" where";
	$sql.=" comment_ID>$last_comment_ID";
	$sql.=$is_admin?" and (comment_approved='1' or comment_approved='0')":" and comment_approved='1'";
	$sql.=" and (comment_type='' or comment_type='comment') order by comment_date desc limit ".$limit;
	$arr= $wpdb->get_results($sql);
	if(count($arr)>0)
	{
		foreach($arr as $key=>$value)
		{
			$comment					=get_comment($value->comment_ID);
			$out[$key]['id']			=$value->comment_ID;
			$out[$key]['url']			=get_comment_link($comment);
			$out[$key]['link']			=get_permalink($comment->comment_post_ID).'#comments';
			$out[$key]['content']		=yundanran_face2html($value->comment_content);
			$out[$key]['display_name']	=$comment->comment_author;
			$out[$key]['email']			=$comment->comment_author_email;
			$out[$key]['time']			=date('Y年m月d日 H:i:s',strtotime($comment->comment_date));
			$out[$key]['time_ago']		=yundanran_time_ago(strtotime($comment->comment_date));
			$out[$key]['hot']			=yundanran_get_comment_hot($value->comment_ID);
			$out[$key]['approved']		=$comment->comment_approved;
		}
	}
	else
	{
		$out=null;
	}
	return $out;
}




/*
	回复邮件通知设置
	2012年6月26日22:28:22
*/
function _yundanran_comment_email_notice()
{
	if(isset($_POST['action']) && $_POST['action']=='yundanran_comment_email_notice')
	{
		$comment_auto_notice=(int)trim(stripslashes(strip_tags($_POST['comment_auto_notice'])));
		
		
		if($comment_auto_notice==1 || $comment_auto_notice==0)
		{
			if(is_user_logged_in())
			{
				$user = wp_get_current_user();
				$comment_auto_to=$user->user_email;
			}
			else
			{
				$comment_auto_to=strtolower(trim(stripslashes(strip_tags($_POST['comment_email']))));
			}
			
			if(is_email($comment_auto_to))
			{
				yundanran_kv_update('comment_notice》'.$comment_auto_to,$comment_auto_notice);
				$data=1;
				$info=(int)yundanran_kv_find('comment_notice》'.$comment_auto_to);
			}
			else
			{
				$data=-1;
				$info='错误：邮件地址不正确！'.$comment_auto_to;
			}
		}
		else
		{
			$data=-2;
			$info='错误：设置参数不正确';
		}
		$json['data']=$data;
		$json['info']=$info;
		header("Content-Type: application/json");
		echo json_encode($json);
		exit;	
	}
}
add_action('init', '_yundanran_comment_email_notice');


/******************************************
	**	评论li
	**	@评论ID
	**	@评论楼层
	**	@评论深度
	**	@评论li样式
	**	2012年8月19日2:58:59
	**	2012年12月4日23:13:39
*******************************************/
function yundanran_comment_li($comment_id,$comment_floor,$comment_depth,$comment_li_cls='')
{
	// 设置管理员的id
	// $admin_id=1;
	// 
	$comment						=get_comment($comment_id);
	$post_id						=$comment->comment_post_ID;
	$comment_user_id				=$comment->user_id;//如果是游客将返回0
	if($comment_user_id>0)
	{
		$comment_user_data				=get_userdata($comment_user_id);
		$comment_user_display_name		=$comment_user_data->display_name;
		$comment_user_url				=$comment_user_data->user_url;
		$comment_user_url				=$comment_user_url==''?get_author_posts_url($comment_user_id):$comment_user_url;
	}
	
	$comment_parent_id					=0;
	$comment_parent_user_id				=0;
	if($comment->comment_parent>0)
	{
		$comment_parent						=get_comment($comment->comment_parent);
		if($comment_parent)
		{
			$comment_parent_id					=$comment_parent->comment_ID;
			$comment_parent_user_id				=$comment_parent->user_id;//如果是游客，将返回0
			$comment_parent_author				=$comment_parent->comment_author;
			if($comment_parent_user_id>0)
			{
				$comment_parent_user_data			=get_userdata($comment_parent_user_id);
				$comment_parent_user_display_name	=$comment_parent_user_data->display_name;
				$comment_parent_user_url			=$comment_parent_user_data->user_url;
			}
			$comment_parent_hash		='<a href="#comment-'.$comment_parent_id.'">@<strong>'.$comment_parent_author.'</strong></a>&nbsp;&nbsp;&nbsp;&nbsp;';
		}
	}
	
	// $comment_depth=$depth;
	$comment_max_depth				=get_option('thread_comments_depth');
	$comment_author					=$comment->comment_author;
	$comment_author_email			=$comment->comment_author_email;
	$comment_author_LV				=yundanran_comment_level($comment_author_email);
	$comment_comment_level_text		=yundanran_comment_level_desc($comment_author_LV);
	
	$avatar_size					=(0!=$comment_parent_id)?30:50;
	// $comment_floor					=get_comment_floor($comment_id);

	
	
	// $comment_parent_author_link=get_comment_author_link($comment_parent);
	if($comment_parent_id!=0)
	{
		$comment_parent_author_link=($comment_parent_user_id>0)?
		'<a href="'.$comment_parent_user_url.'" target="_blank">'.$comment_parent_user_display_name.'</a>':
		get_comment_author_link($comment_parent_id);
	}
	
	$comment_approved=$comment->comment_approved;
	
	// $comment_parent_text=(0!=$comment_parent_id)?'<p class="to">对<strong>'.$comment_parent_author_link.'</strong>说：</p>':'<p class="to">说：</p>';
	// $comment_parent_text='<p class="to">说：</p>';
	
	$comment_caret_text=(0==$comment_parent_id)?
	'<div class="caret caret-left">
		<b class="caret-1"></b>
		<b class="caret-2"></b>
	</div>':'';

	$comment_bg_text=(0==$comment_parent_id)?
	'<div class="bg-1"></div><div class="bg-2"></div>':'';

	$comment_floor_text=($comment_floor==-1)?'':'#'.$comment_floor;
	
	$comment_avatar_text=yundanran_avatar_cache(get_avatar($comment_author_email,$avatar_size));
	$comment_datetime_title=date('Y年m月d日 H:i:s',strtotime($comment->comment_date));
	$comment_datetime_text=yundanran_time_ago(strtotime($comment->comment_date));
	$comment_author_text=($comment_user_id>0)?
	'<a href="'.$comment_user_url.'" target="_blank" rel="external nofollow">'.$comment_user_display_name.'</a>':
	get_comment_author_link($comment_id);
	$comment_reply_text=($comment_depth==$comment_max_depth)?
	'':
	'<div class="input" data-comment_depth="'.$comment_depth.'" data-comment_id="'.$comment_id.'" data-post_id="'.$post_id.'" data-comment_parent="'.$comment_id.'"><span>有话对 '.$comment_author.' 说：</span></div>';
	
	// 评论内容
	$comment_content_text=(0!=$comment_parent_id)?
	$comment_parent_hash:'';
	$comment_content_text.='<span class="word">'.yundanran_face2html(get_comment_text($comment)).'</span>';
	
	// 评论审核
	$comment_verify_text=($comment_approved=='0')?'<div class="alert">此留言正等待管理员审核中，评论附件将不可见。</div>':'';
	
	
	// $comment_author_VIP_text='<span title="'.$VIP_tt.'" class="VIP'.$VIP_cls.'"></span>';
	
	$comment_li_cls=($comment_li_cls=='')?
	comment_class('',$comment_id,$post_id,false):
	' class="'.$comment_li_cls.'"';

	$role_arr=yundanran_get_user_role($comment->user_id);
	$role_name=$role_arr['role_name'];
	$role_desc=$role_arr['role_desc'];


	// 评论附件：外链图片
	$comment_attach_image_url=get_comment_meta($comment_id,"comment_attach_image", true);
	$comment_attach_image=($comment_attach_image_url!='' && $comment_approved!='0')?
	'
	<div class="image-wrap">
		<div class="image-box"><img src="'.$comment_attach_image_url.'" alt="外链图片" /></div>
	</div>
	':'';

	
	// 评论附件：外链视频
	$comment_attach_video_url=	get_comment_meta($comment_id,"comment_attach_video", true);
	$comment_attach_video_img=	get_comment_meta($comment_id,"comment_attach_video_img", true);
	$comment_attach_video_title=get_comment_meta($comment_id,"comment_attach_video_title", true);
	$comment_attach_video=($comment_attach_video_url!=''  && $comment_approved!='0')?
	(
		// 如果存在视频缩略图
		$comment_attach_video_img?
		'
		<div class="video-wrap">
			<div class="video-ico">
				<a class="has-img" title="打开外链视频" href="javascript:;" data-src="'.$comment_attach_video_url.'">
					<img height="80" src="'.$comment_attach_video_img.'" alt="'.$comment_attach_video_title.'" /><br/>
					<span>'.$comment_attach_video_title.'</span>
					<i></i>
				</a>
			</div>
			<p class="video-title">'.$comment_attach_video_title.'</p>
			<div class="video-box"></div>
			<a href="#" class="video-close close" title="关闭视频"></a>
		</div>
		':
		'
		<div class="video-wrap">
			<div class="video-ico"><a title="打开外链视频" href="javascript:;" data-src="'.$comment_attach_video_url.'"><span>打开外链视频</span><i></i></a></div>
			<p class="video-title">未获取视频标题</p>
			<div class="video-box"></div>
			<a href="#" class="video-close close" title="关闭视频"></a>
		</div>
		'
	)
	:
	'';

	// 评论附件：酷狗flash音乐
	$comment_attach_music_url=get_comment_meta($comment_id,"comment_attach_music", true);
	$comment_attach_music=($comment_attach_music_url!=''  && $comment_approved!='0')?
	'
	<div class="music-wrap">
		<div class="music-ico"><a title="打开酷狗音乐" href="javascript:;" data-src="'.$comment_attach_music_url.'"><span>打开酷狗音乐</span><i></i></a></div>
		<div class="music-box"></div>
	</div>
	':'';

	// 评论附件：外链mp3音乐
	$comment_attach_mp3_url=get_comment_meta($comment_id,"comment_attach_mp3", true);
	$comment_attach_mp3=($comment_attach_mp3_url!=''  && $comment_approved!='0')?
	'<div class="mp3-wrap"><i></i>'.yundanran_mp3player($comment_attach_mp3_url,'simple').'</div>':'';	
	
	if(is_user_logged_in())
	{
		$user = wp_get_current_user();
		$user_id=$user->ID;	
	}
	else
	{
		$user_id=0;
	}

	$comment_edit_text=($user_id!=0 && $user_id==$comment_user_id || $user_id==YDR_ADMIN_ID)?
	'<a class="edit" title="再编辑这条评论" href="javascript:;" data-comment_user_id="'.$comment_user_id.'" data-comment_id="'.$comment_id.'"></a>':'';

	$comment_delete_text=($user_id!=0 && $user_id==$comment_user_id || $user_id==YDR_ADMIN_ID)?
	'<a class="delete" title="删除这条评论！" href="javascript:;" data-comment_user_id="'.$comment_user_id.'" data-comment_id="'.$comment_id.'"></a>':'';

	/* ==========================
	// 2012年12月4日23:17:23
	// wap版的comment_li结构
	============================*/
	$is_web=(!isset($GLOBALS['access_type']) || $GLOBALS['access_type']!='wap')?true:false;
	
	$comment_li=
	$is_web?
	'
	<li '.$comment_li_cls.' id="comment-'.$comment_id.'">
		<div class="content ">
			<div class="user-photo">'.$comment_avatar_text.'</div>
			<div class="body">
				<div class="meta float">
					<p class="'.$role_name.'">
						<i title="'.$role_desc.'"></i>
						<strong>'.$comment_author_text.'</strong>
						'.yundanran_comment_level_html($comment_author_LV).'
					</p>
					<p class="access">'.yundanran_comment_access_html($comment_id).'</p>
					<p class="time" title="评论时间：'.$comment_datetime_title.'"><i></i>'.$comment_datetime_text.'</p>
					<p class="setting">
					'.$comment_edit_text.'
					'.$comment_delete_text.'
					</p>
				</div>
				<div style="display:none;" class="floor" title="'.$comment_floor_text.'楼">'.$comment_floor_text.'</div>
				<div class="text">
					'.$comment_content_text.'
					'.$comment_attach_image.'
					'.$comment_attach_video.'
					'.$comment_attach_music.'
					'.$comment_attach_mp3.'
				</div>
				'.$comment_verify_text.'
				'.$comment_reply_text.'
				'.$comment_caret_text.'
				<div class="clear"></div>
			</div>
		</div>
		'.$comment_bg_text.'
	':
	'
	<li '.$comment_li_cls.' id="comment-'.$comment_id.'">
		<div class="photo">'.$comment_avatar_text.'</div>
		<div class="content">
			<div class="meta"><strong>'.$comment_author_text.'</strong>at'.$comment_datetime_text.'say：</div>
			<div class="text">'.$comment_content_text.'</div>
		</div>
		<div class="clear"></div>
	';
	return $comment_li;
}


function yundanran_comment_attach($comment_id,$comment_attach_image,$comment_attach_video_array,$comment_attach_music)
{
	$attach='';
	$_image=stripos($comment_attach_image,'qianduanblog.com');
	if(!$_image)
	{
		$_image_2=preg_match("/\.(png|gif|bmp|jpeg|jpg)$/i",$comment_attach_image);
		if($_image_2)
		{
			add_comment_meta($comment_id,'comment_attach_image',$comment_attach_image,true);
		}
		else
		{
			$attach.='错误：不能发布非图片格式的图片媒体！';
		}
	}
	else
	{
		$attach.='错误：不能发布本站图片！';
	}

	
	$comment_attach_video=		$comment_attach_video_array['swf'];
	$comment_attach_video_img=	$comment_attach_video_array['img'];
	$comment_attach_video_title=$comment_attach_video_array['title'];
	$_youku_video=stripos($comment_attach_video,'qianduanblog.com');
	if(!$_youku_video)
	{
		$ccc=preg_match("/\.(swf)/i",$comment_attach_video);
		if($ccc)
		{
			add_comment_meta($comment_id,'comment_attach_video',$comment_attach_video,true);
			add_comment_meta($comment_id,'comment_attach_video_img',$comment_attach_video_img,true);
			add_comment_meta($comment_id,'comment_attach_video_title',$comment_attach_video_title,true);
		}
		else
		{
			$attach.='错误：不能发布不含“.swf”的视频媒体！';
		}
	}
	else
	{
		$attach.='错误：不能发布本站视频！';
	}

	$_kugou_music=stripos($comment_attach_music,'qianduanblog.com');
	if(!$_kugou_music)
	{
		$ccc=preg_match("/\.(mp3)$/i",$comment_attach_music);
		if($ccc)
		{
			add_comment_meta($comment_id,'comment_attach_mp3',$comment_attach_music,true);
		}
		else
		{
			$attach.='错误：不能发布非“.mp3”后缀音乐媒体！';
		}
	}
	else if($_kugou_music)
	{
		$attach.='错误：不能发布本站mp3音乐！';
	}

	if($attach!='')
		return $json['attach']=$attach;
	else
		return  $json['attach']='附件已添加';
}




/********************************************
	**	ajax评论
	**	for yundanran-2
	**	2012年8月25日13:49:33
********************************************/
function _yundanran_comment()
{
	if(isset($_POST['action']) && $_POST['action']=='yundanran_comment' && isset($_POST['__yundanran__']) && $_POST['__yundanran__']!='')
	{
		$__yundanran__=stripslashes(strip_tags($_POST['__yundanran__']));
		// /*
		$VERIFY				=0;//一步验证是否通过
		$VERIFY2			=0;//二步验证是否通过
		$VERIFY3			=0;//三步验证是否通过
		$user_is_register	=0;//用户是否注册
		// 如果识别码正确
		if($__yundanran__===$_SESSION['__yundanran__'])
		{
			global $wpdb;
			$post_user_id 			=stripslashes(strip_tags($_POST['user_id']));
			$comment_content		=trim(stripslashes(strip_tags($_POST['comment'])));
			$comment_post_ID 		=stripslashes(strip_tags($_POST['comment_post_ID']));
			$comment_parent_id 		=stripslashes(strip_tags($_POST['comment_parent']));
			$comment_depth 			=stripslashes(strip_tags($_POST['comment_depth']));
			$comment_attach_image 	=stripslashes(strip_tags($_POST['comment_attach_image']));
			$comment_attach_video_swf 	=stripslashes(strip_tags($_POST['comment_attach_video_swf']));
			$comment_attach_video_img 		=stripslashes(strip_tags($_POST['comment_attach_video_img']));
			$comment_attach_video_title 	=stripslashes(strip_tags($_POST['comment_attach_video_title']));
			$comment_attach_music 	=stripslashes(strip_tags($_POST['comment_attach_music']));
		
			// 只有未登录的时候才判断这些值
			$comment_author			=stripslashes(strip_tags($_POST['comment_author']));
			$comment_author_email	=stripslashes(strip_tags($_POST['comment_author_email']));
			$comment_author_url		=stripslashes(strip_tags($_POST['comment_author_url']));
			
			
			
			// 如果登录
			if(is_user_logged_in())
			{
				// ====================== login ==========================
				if(is_numeric($post_user_id))
				{
					$post_user_id 		=(int)$post_user_id;
					$user 				=wp_get_current_user();
					$current_user_id 	=$user->ID;
					if($post_user_id==$current_user_id)
					{
						$user_is_register=1;
						$VERIFY=1;
					}
					else
					{
						$data=-1;
						$info='错误：非法用户请求！';
						$VERIFY=0;
					}
				}
				else
				{
					$data=-1;
					$info='错误：非法请求！';
					$VERIFY=0;
				}
				// ====================== login ========================== 
			}
			else
			{
				// ====================== unlogin ========================== 
				$sql="SELECT display_name, user_email FROM $wpdb->users WHERE display_name = %s OR user_email = %s";
				$res=$wpdb->get_results($wpdb->prepare($sql,$comment_author,$comment_author_email));
				//匹配到注册会员
				if($res)
				{
					if ($res[0]->display_name == $comment_author)
					{
						$data=-91;
						$info='错误：昵称不能与注册会员相同！';
						$VERIFY=0;
					} 
					else if(strtolower($res[0]->user_email) == strtolower($comment_author_email))
					{
						$data=-92;
						$info='错误：邮箱不能与注册会员相同！';
						$VERIFY=0;
					}
				}
				// 未匹配到
				else
				{
					if($comment_author!='')
					{
						if(get_option('require_name_email'))
						{
							if($comment_author_email!='' && is_email($comment_author_email))
							{
								//网址可以为空，如果不为空，但必须符合规范
								$p="/http[s]?:\/\/.*+/i";
								if($comment_author_url!='' && !preg_match($p,$comment_author_url))
								{
									$data=-93;
									$info='错误：网址必须以http(s)://开头！';
									$VERIFY=0;
								}
								else
								{
									$VERIFY=1;
									$user_is_register=0;
									setcookie('comment_author_' . COOKIEHASH, $comment_author, time() + 30000000, COOKIEPATH, COOKIE_DOMAIN);
									setcookie('comment_author_email_' . COOKIEHASH, $comment_author_email, time() + 30000000, COOKIEPATH, COOKIE_DOMAIN);
									setcookie('comment_author_url_' . COOKIEHASH, esc_url($comment_author_url), time() + 30000000, COOKIEPATH, COOKIE_DOMAIN);
								}
							}
							else if($comment_author_email=='')
							{
								$data=-92;
								$info='错误：邮箱不能为空！';
								$VERIFY=0;
							}
							else
							{
								$data=-92;
								$info='错误：邮箱格式不正确！';
								$VERIFY=0;
							}
						}
						else
						{
							//网址可以为空，如果不为空，但必须符合规范
							$p="/http[s]?:\/\/.*+/i";
							if($comment_author_url!='' && !preg_match($p,$comment_author_url))
							{
								$data=-93;
								$info='错误：网址必须以http(s)://开头！';
								$VERIFY=0;
							}
							else
							{
								$VERIFY=1;
								$user_is_register=0;
								setcookie('comment_author_' . COOKIEHASH, $comment_author, time() + 30000000, COOKIEPATH, COOKIE_DOMAIN);
								setcookie('comment_author_email_' . COOKIEHASH, $comment_author_email, time() + 30000000, COOKIEPATH, COOKIE_DOMAIN);
								setcookie('comment_author_url_' . COOKIEHASH, esc_url($comment_author_url), time() + 30000000, COOKIEPATH, COOKIE_DOMAIN);
							}
						}
					}
					else
					{
						$data=-91;
						$info='错误：昵称不能为空！';
						$VERIFY=0;
					}
				}
				
				// $data=-2;
				// $info='错误：您尚未登录！';				
				// ====================== unlogin ==========================
			}
			
			// 如果用户验证正确，评论文章id、父评论id、评论层级都为数字
			if($VERIFY)
			{
				if(is_numeric($comment_post_ID) && is_numeric($comment_parent_id) && is_numeric($comment_depth))
				{
					$comment_post_ID 	=intval($comment_post_ID);
					$comment_parent_id 	=intval($comment_parent_id);
					$comment_depth 		=intval($comment_depth);

					$post_status=get_post_status($comment_post_ID);
					$post=get_post($comment_post_ID);
					$post_comment_status=$post->comment_status;

					// 文章已公开
					if($post_status && $post_status=='publish' && $post)
					{
						if($post_comment_status=='open' || $post_comment_status=='registered_only')
						{
							if($comment_parent_id>=0)
							{
								if($comment_parent_id==0)
								{
									$VERIFY2=1;//进一步验证评论内容
								}
								else
								{
									$comment_parent=get_comment($comment_parent_id);
									if($comment_parent)
									{
										$comment_parent_approved=$comment_parent->comment_approved;
										if($comment_parent_approved=='1')
										{
											$VERIFY2=1;//进一步验证评论内容
										}
										else
										{
											$data=-13;
											$info='错误：被评论未经审核！';
										}
									}
									else
									{
										$data=-12;
										$info='错误：被评论不存在！';
									}
								}
							}
							else
							{
								$data=-11;
								$info='错误：被评论数据错误！';
							}
						}
						// 文章评论关闭
						else
						{
							$data=-5;
							$info='错误：文章已关闭评论';
						}						
					}
					else
					{
						$data=-4;
						$info='错误：文章未公开或不存在。';
					}
				}
				// 参数不正确
				else
				{
					$data=-3;
					$info='错误：提交参数不正确！';
				}
			}
		}
		// 非法请求
		else
		{
			$data=-1;
			$info='错误：非法请求或请求过期，请<a href="javascript:location.replace(location.href);">刷新页面重试</a>。';
		}

		
		// 验证评论内容
		if($VERIFY2==1)
		{
			if($comment_content!='' && yundanran_string_count($comment_content)>=YDR_MIN_WORD_LIMIT && yundanran_string_count($comment_content)<=YDR_MAX_WORD_LIMIT)
			{
				// 是否限制用户输入字符类型
				if(YDR_WORD_LIMIT)
				{
					if(preg_match("/[\x{4e00}-\x{9fa5}]+/u",$comment_content))
					{
						$VERIFY3=1;
					}
					else
					{
						$data=-10;
						$info='错误：评论内容必须有中文字符！';
					}
				}
				else
				{
					$VERIFY3=1;
				}	
			}
			else if($comment_content=='')
			{
				$data=-7;
				$info='错误：评论内容不能为空！';
			}
			else if(yundanran_string_count($comment_content)<YDR_MIN_WORD_LIMIT)
			{
				$data=-8;
				$info='错误：评论内容最少'.YDR_MIN_WORD_LIMIT.'字！';
			}
			else if(yundanran_string_count($comment_content)>YDR_MAX_WORD_LIMIT)
			{
				$data=-9;
				$info='错误：评论内容最多'.YDR_MAX_WORD_LIMIT.'字！';
			}
		}
		

		if($VERIFY3==1)
		{

			$comment_author       	= $user_is_register?$wpdb->escape($user->display_name):$comment_author;
			$comment_author_email 	= $user_is_register?$wpdb->escape($user->user_email):$comment_author_email;
			$comment_author_url   	= $user_is_register?$wpdb->escape($user->user_url):$comment_author_url;
			$user_id				= $user_is_register?$wpdb->escape($user->ID):'';
			$comment_post_ID 		= $wpdb->escape($comment_post_ID);
			$comment_parent 		= $wpdb->escape($comment_parent_id);
			$comment_content 		= $wpdb->escape($comment_content);
			$comment_type 			= $wpdb->escape('');

			$comment_max_depth	=get_option('thread_comments_depth');	//最大层级			
			if($comment_depth<$comment_max_depth)
			{
				$comment_depth+=1;
				$dupe = "SELECT comment_ID FROM $wpdb->comments WHERE comment_post_ID = %d AND ( comment_author = %s ";
				if ($comment_author_email){$dupe .= "OR comment_author_email = %s ";}
				$dupe .= ") AND comment_content = %s LIMIT 1";
				if ( !$wpdb->get_var($wpdb->prepare($dupe,$comment_post_ID,$comment_author,$comment_author_email,$comment_content)) )
				{
					$comment_author_IP=yundanran_get_access_ip();
					$commentdata = compact('comment_post_ID','comment_author',
					'comment_author_email','comment_author_url',
					'comment_author_IP','comment_parent',   'comment_content', 
					'comment_type', 'user_id');
					
					$comment_id=wp_new_comment($commentdata);
					
					if(is_wp_error($comment_id))
					{
						$data=-16;
						$info='错误：评论操作失败！';
					}
					else
					{
						$comment_post_id 			=$comment_post_ID;		//被评论的文章id
						$comment_author 			=$comment_author;	//评论作者
						$comment_author_id 			=$user_id;
						$comment_post_author_id 	=get_post($comment_post_id)->post_author;
						$comment_post_author_info 	=get_userdata($comment_post_author_id);

						$comment_li_cls='comment ';
						$comment_li_cls.=($comment_author_id==$comment_post_author_id)?' bypostauthor':'';
						$comment_li_cls.=' depth-'.$comment_depth;
						$comment_li_cls.=$comment_id%2==0?' odd':' even';

						if($comment_parent>0)
						{
							// 非父评论，检测是否设置了邮件通知
							$parent_comment = get_comment($comment_parent);
							$to=$parent_comment->comment_author_email;
							
							// 如果没有设置，就默认回复
							$comment_notice_to_parent=
							!yundanran_kv_has('comment_notice》'.$to)?
							1:
							(
								yundanran_kv_find('comment_notice》'.$to)==1?
								1:
								0
							);
							
							// 如果设置了评论邮件通知，并且不是回复自己的评论
							if( $comment_notice_to_parent && $comment_author_email!=$to)
							{
								yundanran_comment_email_user($comment_id,$comment_parent_id);				
							}
						}
						
						// 发送邮件给作者
						yundanran_comment_email_author($comment_id);

						
						if($comment_parent_id==0 )
						{
							$comment_attach_video_array=array
							(
								'swf'=>$comment_attach_video_swf,
								'img'=>$comment_attach_video_img,
								'title'=>$comment_attach_video_title,
							);
							$json['attach']=yundanran_comment_attach($comment_id,$comment_attach_image,$comment_attach_video_array,$comment_attach_music);
						}
						else if($comment_parent_id!=0)
						{
							$json['attach']='非父评论不能添加媒体（图片/视频/音乐）附件。';
						}
						
						$html=yundanran_comment_li($comment_id,'?',$comment_depth,$comment_li_cls).'</li>';					
						$data=$comment_id;
						$info=$html;
					}
				}
				else
				{
					$data=-15;
					$info='错误：重复评论！';
				}				
			}
			else
			{
				$data=-14;
				$info='错误：评论层级过深！';
			}
		}
		
		// */
		$json['data']=$data;
		$json['info']=$info;
		header("Content-Type: application/json");
		echo json_encode($json);
		exit;
	}
}
add_action('init', '_yundanran_comment');





/**********************************************
	**	删除评论
	**	2012-9-3 23:30:23
**********************************************/
function _yundanran_delete_comment()
{
	// $admin_id=1;
	if(isset($_POST['action']) && $_POST['action']=='_yundanran_delete_comment' && isset($_POST['__yundanran__']) && $_POST['__yundanran__']!='')
	{
		if(isset($_POST['comment_id']) && isset($_POST['user_id'])
		 && $_POST['comment_id']!='' && $_POST['user_id']!='')
		{
			$__yundanran__=stripslashes(strip_tags($_POST['__yundanran__']));
			if($__yundanran__===$_SESSION['__yundanran__'])
			{
				$comment_id=stripslashes(strip_tags($_POST['comment_id']));
				$user_id=stripslashes(strip_tags($_POST['user_id']));
				if(is_numeric($comment_id) && is_numeric($user_id))
				{
					$comment_id=(int)$comment_id;
					$user_id=(int)$user_id;
					$current_user = wp_get_current_user();
					$current_user_id=$current_user->ID;
					if($user_id==$current_user_id && $comment_id>=1)
					{
						$sql_comment=get_comment($comment_id);
						if($sql_comment)
						{
							$sql_comment_parent=$sql_comment->comment_parent;
							global $wpdb;
							$sql_1=$wpdb->prepare("select count(comment_ID) from $wpdb->comments where comment_parent=%d and comment_approved='1' ",$comment_id);
							$res_1=$wpdb->get_var($sql_1);
							// $res_1=(int)$res_1;
							if($res_1==0)//没有子评论
							{
								$sql_comment_user_id=$sql_comment->user_id;
								if($current_user_id==YDR_ADMIN_ID || $sql_comment_user_id==$user_id)
								{
									$res_2=wp_delete_comment($comment_id,1);//删除的id，是否强制删除
									// wp_update_comment_count($sql_comment->comment_post_ID);
									delete_comment_meta($comment_id,'comment_attach_image');
									delete_comment_meta($comment_id,'comment_attach_video');
									delete_comment_meta($comment_id,'comment_attach_music');
									if($res_2)
									{
										$data=0;
										$info='删除成功！';
									}
									else
									{
										$data=-7;
										$info='错误：删除失败！';
									}
								}
								else
								{
									$data=-6;
									$info='错误：您的权限不足！';
								}
							}
							else
							{
								$data=-5;
								$info='错误：该评论/回复下有回复！';
							}
						}
						else
						{
							$data=-4;
							$info='错误：待删除的评论不存在！';
						}
					}
					else
					{
						$data=-3;
						$info='用户ID或评论ID错误。';
					}
				}
				else
				{
					$data=-2;
					$info='错误：参数不正确。';
				}
			}
			else
			{
				$data=-9;
				$info='错误：非法请求或请求过期。';
			}
		}
		else
		{
			$data=-1;
			$info='错误：参数不完整。';
		}
		$json['data']=$data;
		$json['info']=$info;
		header("Content-Type: application/json");
		echo json_encode($json);
		exit;
	}
}
add_action('init', '_yundanran_delete_comment');


/**********************************************
	**	再编辑评论
	**	2012年9月3日23:30:39
**********************************************/
function _yundanran_edit_comment()
{
	// $admin_id=1;
	if(isset($_POST['action']) && $_POST['action']=='_yundanran_edit_comment' && isset($_POST['__yundanran__']) && $_POST['__yundanran__']!='')
	{
		if(isset($_POST['comment_id']) && isset($_POST['user_id'])
		 && $_POST['comment_id']!='' && $_POST['user_id']!='')
		{
			$__yundanran__	=stripslashes(strip_tags($_POST['__yundanran__']));
			$VERIFY			=0;//1验证
			$VERIFY2		=0;//2验证
			if($__yundanran__===$_SESSION['__yundanran__'])
			{
				$comment_id=stripslashes(strip_tags($_POST['comment_id']));
				$user_id=stripslashes(strip_tags($_POST['user_id']));
				if(is_numeric($comment_id) && is_numeric($user_id))
				{
					$comment_id=(int)$comment_id;
					$user_id=(int)$user_id;
					$current_user = wp_get_current_user();
					$current_user_id=$current_user->ID;
					if($user_id==$current_user_id && $comment_id>=1)
					{
						$sql_comment=get_comment($comment_id);
						if($sql_comment)
						{
							$sql_comment_user_id=$sql_comment->user_id;
							if($current_user_id==YDR_ADMIN_ID || $sql_comment_user_id==$user_id)
							{
								$sql_comment_content=$sql_comment->comment_content;
								$comment_content=stripslashes(strip_tags($_POST['comment_content']));
								if($sql_comment_content!=$comment_content)
								{
									$VERIFY=1;
								}
								else if($sql_comment_content==$comment_content)
								{
									$data=-6;
									$info='错误：编辑内容没有改变！';
								}
							}
							else
							{
								$data=-5;
								$info='错误：您的权限不足！';
							}
						}
						else
						{
							$data=-4;
							$info='错误：待编辑的评论不存在！';
						}
					}
					else
					{
						$data=-3;
						$info='用户ID或评论ID错误。';
					}
				}
				else
				{
					$data=-2;
					$info='错误：参数不正确。';
				}
			}
			else
			{
				$data=-9;
				$info='错误：非法请求或请求过期。';
			}
		}
		else
		{
			$data=-1;
			$info='错误：参数不完整。';
		}
		
		if($VERIFY==1)
		{
			if($comment_content!='' && yundanran_string_count($comment_content)>=YDR_MIN_WORD_LIMIT && yundanran_string_count($comment_content)<=YDR_MAX_WORD_LIMIT)
			{
				if(YDR_WORD_LIMIT)
				{
					if(preg_match("/[\x{4e00}-\x{9fa5}]+/u",$comment_content))
					{
						$VERIFY2=1;
					}
					else
					{
						$data=-10;
						$info='错误：编辑内容必须有中文字符！';
					}
				}
				else
				{
					$VERIFY2=1;
				}
			}
			else if($comment_content=='')
			{
				$data=-7;
				$info='错误：编辑内容为空！';
			}
			else if(yundanran_string_count($comment_content)<YDR_MIN_WORD_LIMIT)
			{
				$data=-8;
				$info='错误：编辑内容最少'.YDR_MIN_WORD_LIMIT.'字！';
			}
			else if(yundanran_string_count($comment_content)>YDR_MAX_WORD_LIMIT)
			{
				$data=-9;
				$info='错误：编辑内容最多'.YDR_MAX_WORD_LIMIT.'字！';
			}
		}
		
		
		
		if($VERIFY2==1)									
		{
			global $wpdb;
			$comment_ID 		=$wpdb->escape($comment_id);
			$comment_content 	=$wpdb->escape($comment_content);
			$commentarr 		=compact('comment_ID','comment_content');
			$s=wp_update_comment($commentarr);
			if($s==1)
			{
				$data=0;
				$info=yundanran_face2html($comment_content);
			}
			else
			{
				$data=-11;
				$info='更新失败，请稍后再试！';
			}
		}

		
		
		$json['data']=$data;
		$json['info']=$info;
		header("Content-Type: application/json");
		echo json_encode($json);
		exit;
	}	
}
add_action('init', '_yundanran_edit_comment');





/***************************************************************
**	审核评论【pass、nopass】
**	2012年11月11日21:03:55
***************************************************************/
add_action('init', '_yundanran_approved_comment');
function _yundanran_approved_comment()
{
	if(isset($_POST['action']) && $_POST['action']=='_yundanran_approved_comment' && isset($_POST['__yundanran__']) && $_POST['__yundanran__']!='')
	{
		if(isset($_POST['comment_id']) && isset($_POST['user_id'])
		 && $_POST['comment_id']!='' && $_POST['user_id']!='')
		{
			$__yundanran__=stripslashes(strip_tags($_POST['__yundanran__']));
			if($__yundanran__===$_SESSION['__yundanran__'])
			{
				$comment_id=stripslashes(strip_tags($_POST['comment_id']));
				$user_id=stripslashes(strip_tags($_POST['user_id']));
				if(is_numeric($comment_id) && is_numeric($user_id))
				{
					$comment_id=(int)$comment_id;
					$user_id=(int)$user_id;
					$current_user = wp_get_current_user();
					$current_user_id=$current_user->ID;
					if($user_id==$current_user_id && $comment_id>=1)
					{
						$sql_comment=get_comment($comment_id);
						if($sql_comment)
						{
							//审核操作只针对管理员
							if($current_user_id==YDR_ADMIN_ID)
							{
								$status=strtolower(stripslashes(strip_tags($_POST['status'])));
								if($status=='approve' || $status=='spam')
								{
									$res=wp_set_comment_status($comment_id,$status);
									if($res)
									{
										$data=0;
										$info='操作成功！';
									}
									else
									{
										$data=-7;
										$info='错误：操作失败！';
									}
								}
								else
								{
									$data=-6;
									$info='错误：审核参数不正确！';
								}
							}
							else
							{
								$data=-5;
								$info='错误：您的权限不足！';
							}
						}
						else
						{
							$data=-4;
							$info='错误：待审核的评论不存在！';
						}
					}
					else
					{
						$data=-3;
						$info='用户ID或评论ID错误。';
					}
				}
				else
				{
					$data=-2;
					$info='错误：参数不正确。';
				}
			}
			else
			{
				$data=-9;
				$info='错误：非法请求或请求过期。';
			}
		}
		else
		{
			$data=-1;
			$info='错误：参数不完整。';
		}
		$json['data']=$data;
		$json['info']=$info;
		header("Content-Type: application/json");
		echo json_encode($json);
		exit;
	}
}
// /************
// 将评论审核通过
// *************/
// function yundanran_approved_comment2pass($comment_ID)
// {
	// wp_set_comment_status($comment_id,'approved');
// }
// /************
// 将评论审核不通过
// *************/
// function yundanran_approved_comment2nopass($comment_ID)
// {

// }



/**********************************************
	**	评论通知作者
	**	2012年8月25日13:50:35
**********************************************/
function yundanran_comment_email_author($comment_id)
{
	$comment=get_comment($comment_id);
	$comment_content=yundanran_face2html($comment->comment_content);

	$post_id=$comment->comment_post_ID;		//被评论的文章id
	$post_title=get_post($post_id)->post_title;
	$post_link=get_comments_link($post_id);
	$comment_link=get_comment_link($comment);

	$comment_author=$comment->comment_author;	//评论作者
	$comment_post_author_id=get_post($post_id)->post_author;
	$comment_post_author_info=get_userdata($comment_post_author_id);
	$comment_post_author_display_name=$comment_post_author_info->display_name;
	$comment_post_author_email=$comment_post_author_info->user_email;

	$subject=get_option('blogname').' - 评论回复通知';

	$message_author='
	<div style="position:relative; width:auto; height:auto;border:3px double #ddd; background-color:#fff; padding:10px; margin:0px auto; font-family:微软雅黑;">
		<header style="font-size:16px; color:#000; font-weight:900; text-align:center;">'.get_option('blogname').'邮件通知</header>
		<content style="font-size:14px; color:#444;">
			<p>尊敬的<strong style="padding:10px;">'.$comment_post_author_display_name.'</strong>作者您好，在本博客有人回复了您写的<strong>《'.$post_title.'》</strong>一文。</p>
			<div style="border: 1px dashed #FBCC27;color:#000;background-color: #FFFAE8;padding:4px 10px;">
				<strong style="padding:10px;">'.$comment_author.'</strong>说:
				<p style="padding: 0px;margin:0px;text-align: justify;white-space: pre-line;">'.$comment_content.'</p>
			</div>
			<p>这条评论链接：<a href="'.$comment_link.'">'.$comment_link.'</a></p>
			<p>全部评论链接：<a href="'.$post_link.'">'.$post_link.'</a></p>
			<hr/>
			<p style="color:#af0000;">这是一封系统自动发出的邮件,请勿回复!</p>
			<p style="text-align:right;">感谢您一如既往的支持<a href="'.get_bloginfo('url').'">'.get_option('blogname').'</a>！</p>
			<p style="text-align:right;">'.date('Y年m月d日 H:i:s',time()).'</p>
		</content>
	</div>
	';
	//发送邮件给文章的作者
	wp_mail($comment_post_author_email, $subject, $message_author);
}


/**********************************************
	**	评论通知用户
	**	2012年8月25日13:50:35
**********************************************/
function yundanran_comment_email_user($comment_id,$comment_parent_id)
{
	$comment=get_comment($comment_id);
	$comment_content=htmlspecialchars_decode($comment->comment_content);
	$post_id=$comment->comment_post_ID;		//被评论的文章id
	$post_title=get_post($post_id)->post_title;
	$post_link=get_comments_link($post_id);
	$comment_link=get_comment_link($comment);
	$comment_author=$comment->comment_author;

	$parent_comment=get_comment($comment_parent_id);
	$parent_comment_content=yundanran_face2html($parent_comment->comment_content);
	$parent_comment_author_email=$parent_comment->comment_author_email;
	$user_display_name=$parent_comment->comment_author;

	$subject=get_option('blogname').' - 评论回复通知';

	$message_user='
	<div style="position:relative; width:auto; height:auto;border:3px double #ddd; background-color:#fff; padding:10px; margin:0px auto; font-family:微软雅黑;">
		<header style="font-size:16px; color:#000; font-weight:900;text-align:center;">'.get_option('blogname').'的邮件通知</header>
		<content style="font-size:14px; color:#444;">
			<p>尊敬的<strong style="padding:10px;">'.$user_display_name.'</strong>您好，在本博客有人回复了您的评论。</p>
			<div style="border: 1px dashed #3B90DB;color:#000;background-color: #DBEDFC;padding:4px 10px;">
				<strong style="padding-right:10px;">您</strong>说:
				<p style="padding: 0px;margin:0px;text-align: justify;white-space: pre-line;">'.$parent_comment_content.'</p>
			</div>
			<div style="border: 1px dashed #FBCC27;color:#000;background-color: #FFFAE8;padding:4px 10px;margin-top: 10px;">
				<strong style="padding-right:10px;">'.$comment_author.'</strong>说:
				<p style="padding: 0px;margin:0px;text-align: justify;white-space: pre-line;">'.$comment_content.'</p>
			</div>
			<p>这条评论链接：<a href="'.$comment_link.'">'.$comment_link.'</a></p>
			<p>全部评论链接：<a href="'.$post_link.'">'.$post_link.'</a></p>
			<hr/>
			<p style="color:#af0000;">这是一封系统自动发出的邮件,请勿回复!</p>
			<p style="text-align:right;">感谢您一如既往的支持<a href="'.get_bloginfo('url').'">'.get_option('blogname').'</a>！</p>
			<p style="text-align:right;">'.date('Y年m月d日 H:i:s',time()).'</p>
		</content>
	</div>
	';
	wp_mail( $parent_comment_author_email, $subject, $message_user);	
}





/***********************************************
	**	评论嵌套
	**	修改来源于官方主题 twentyeleven
	**	2012年8月25日13:52:49
	**	2012年11月24日22:32:28
************************************************/
function yundanran_comment_nested( $comment, $args, $depth )
{
	global $comment_page_floor, $page, $wpdb;
	$comment_id						=$comment->comment_ID;
	$comment_parent_id				=$comment->comment_parent;
	$post_id						=$comment->comment_post_ID;
	$comment_order					=get_option('comment_order');
	$default_comments_page			=get_option('default_comments_page');//默认显示？最新的：最久的
	$page							=$args['page'];
	$per_page						=$args['per_page'];

	
	
	$comment_floor=0;
	/*
	
	暂时取消评论楼层，有BUG，等待修复
	2012年12月21日0:21:18
	
	if(!$comment_page_floor)
	{
		// 一级评论总数
		$comment_count=$wpdb->get_var("SELECT count(*) FROM $wpdb->comments WHERE comment_post_ID = $post_id AND comment_type = '' AND comment_approved = 1 AND comment_parent=0");
		
		// 最后一页评论数量
		$last_page_count=$comment_count%$per_page;
		
		// 分页总数
		$page_count=ceil($comment_count/$per_page);
		
		// 倒序
		if($comment_order=='desc')
		{
			// 最后一页
			if($page==$page_count)
			{
				$comment_page_floor=$comment_count;
			}
			else
			{
				$comment_page_floor=$per_page*$page;
			}
		}
		// 顺序
		else
		{
			// 最后一页
			if($page==$page_count)
			{
				$comment_page_floor=1;
			}
			else
			{
				$comment_page_floor=$per_page*($page_count-$page-1)+$last_page_count+1;
			}
		}
	}

	if($comment_parent_id==0)
	{
		$comment_floor=$comment_order=='desc'?
		$comment_page_floor--:
		$comment_page_floor++;
	}
	else
	{
		$comment_floor='';
	}
	// */
	
	switch ( $comment->comment_type )
	{
		case 'pingback' :$html='<li>';break;
		case 'trackback' :$html='<li>';break;
		default :
		$html=yundanran_comment_li($comment_id,$comment_floor,$depth);
		break;
	}

	echo $html;
}


/***********************************************
	**	评论列表
	**	2012年8月25日13:52:49
************************************************/
function yundanran_list_comments($pageid)
{
	$args = array
	(
		'per_page' =>get_option('comments_per_page'),
		'callback'=>'yundanran_comment_nested',
		'page'=>$pageid
	);
	$html=wp_list_comments($args);
	return $html;
}





/*******************************************************
	**	ajax获得评论表情
	**	2012年8月25日13:56:57
*******************************************************/
function _yundanran_face()
{
	if(isset($_POST['action']) && $_POST['action']=='yundanran_face')
	{
		$html='';
		$src=YDR_FACE_URL.'e';
		$face_arr=array();
		// $j=100;
		for($i=0;$i<=89;$i++)
		{
			$j=100+$i;;
			$face_arr[$i]=$src.$j.'.gif';
		}	

		$title_arr=array
		(
			'微笑','撇嘴','色','发呆','得意','流泪','害羞','闭嘴','睡','大哭','尴尬','发怒','调皮','呲牙','惊讶',
			'难过','酷','冷汗','抓狂','吐','偷笑','可爱','白眼','傲慢','饥饿','困','惊恐','冷汗','憨笑','大兵',
			'奋斗','咒骂','疑问','嘘','晕','折磨','衰','骷髅','敲打','再见','擦汗','抠鼻','鼓掌','糗大了','坏笑',
			'左哼哼','右哼哼','哈欠','鄙视','委屈','快哭了','阴险','亲亲','吓','可怜','菜刀','西瓜','啤酒','篮球','乒乓',
			'咖啡','饭','猪头','玫瑰','凋谢','示爱','爱心','心碎','蛋糕','闪电','炸弹','刀','足球','瓢虫','便便',
			'晚安','太阳','礼物','抱抱','强','弱','握手','胜利','抱拳','勾引','拳头','差劲','我爱你','NO','OK'
		);
		foreach($face_arr as $key=>$value)
		{
			$html.='<li class="face-li" title="'.$title_arr[$key].'" style="background-image:url('.$value.');"></li>';
		}
		$html.='';
		$json['data']=1;
		$json['info']=$html;
		header("Content-Type: application/json");
		echo json_encode($json);
		exit;
	}
}
add_action('template_redirect','_yundanran_face');



/*****************************************************
	**	表情[face=xx]
	**	转换成image
	**	2012年8月19日20:47:13
*****************************************************/
function yundanran_face2html($string)
{
	// $src='http://ctc.qzonestyle.gtimg.cn/qzone/em/e';
	$src=YDR_FACE_URL.'e';
	$face_arr=array();
	for($i=0;$i<=89;$i++)
	{
		$j=100+$i;
		$face_arr[$i]=$src.$j.'.gif';
	}	

	$title_arr=array
	(
		'微笑','撇嘴','色','发呆','得意','流泪','害羞','闭嘴','睡','大哭','尴尬','发怒','调皮','呲牙','惊讶',
		'难过','酷','冷汗','抓狂','吐','偷笑','可爱','白眼','傲慢','饥饿','困','惊恐','冷汗','憨笑','大兵',
		'奋斗','咒骂','疑问','嘘','晕','折磨','衰','骷髅','敲打','再见','擦汗','抠鼻','鼓掌','糗大了','坏笑',
		'左哼哼','右哼哼','哈欠','鄙视','委屈','快哭了','阴险','亲亲','吓','可怜','菜刀','西瓜','啤酒','篮球','乒乓',
		'咖啡','饭','猪头','玫瑰','凋谢','示爱','爱心','心碎','蛋糕','闪电','炸弹','刀','足球','瓢虫','便便',
		'晚安','太阳','礼物','抱抱','强','弱','握手','胜利','抱拳','勾引','拳头','差劲','我爱你','NO','OK'
	);
	$k=0;
	$html='';
	foreach($title_arr as $key=>$title)
	{
		$t='/'.$title;
		if(preg_match_all('#'.$t.'#',$string,$s))
		{
			$face='<img class="face" src="'.$face_arr[$key].'" title="'.$title.'" />';
			$string=str_replace($t,$face,$string);
		}
	}	
	return $string;

}


/****************************************************
	**	评论等级0-20
	@	评论email或者评论数量
	**	2012年8月25日13:59:37
	**	2012年11月10日22:33:15
****************************************************/
function yundanran_comment_level($user_email_or_comment_count)
{
	if(is_email($user_email_or_comment_count))
	{
		$user_email=$user_email_or_comment_count;
		$amout=yundanran_get_user_comment_count($user_email);
	}
	else if(is_numeric($user_email_or_comment_count))
	{
		$amout=$user_email_or_comment_count;
	}
	else
	{
		$amout=1;
	}
	
	if($amout==0)
	{
		$LV=0;
	}
	else if($amout==1)
	{
		$LV=1;
	}
	else if($amout==2 || $amout==3)
	{
		$LV=2;
	}
	else if($amout>=4 && $amout<=6)
	{
		$LV=3;
	}
	else if($amout>=7 && $amout<=10)
	{
		$LV=4;
	}
	else if($amout>=11 && $amout<=15)
	{
		$LV=5;
	}
	else if($amout>=16 && $amout<=21)
	{
		$LV=6;
	}
	else if($amout>=22 && $amout<=28)
	{
		$LV=7;
	}
	else if($amout>=29 && $amout<=36)
	{
		$LV=8;
	}
	else if($amout>=37 && $amout<=50)
	{
		$LV=9;
	}
	else if($amout>=51 && $amout<=100)
	{
		$LV=10;
	}
	else if($amout>=101 && $amout<=250)
	{
		$LV=11;
	}
	else if($amout>=251 && $amout<=400)
	{
		$LV=12;
	}
	else if($amout>=401 && $amout<=700)
	{
		$LV=13;
	}
	else if($amout>=701 && $amout<=1000)
	{
		$LV=14;
	}
	else if($amout>=1001 && $amout<=1500)
	{
		$LV=15;
	}
	else if($amout>=1501 && $amout<=2300)
	{
		$LV=16;
	}
	else if($amout>=2301 && $amout<=3300)
	{
		$LV=17;
	}
	else if($amout>=3301 && $amout<=4500)
	{
		$LV=18;
	}
	else if($amout>=4501 && $amout<=9999)
	{
		$LV=19;
	}
	else if($amout>=10000)
	{
		$LV=20;
	}
	return $LV;
}



/****************************************
*	评论等级描述
*	2012年11月10日22:32:51
*****************************************/
function yundanran_comment_level_desc($comment_level)
{
	$comment_level=(!$comment_level || !is_numeric($comment_level))?0:(int)$comment_level;
	$touxiang=array
	(
		'伶仃幼儿园',//0
		'小学一年级',//1
		'小学二年级',//2
		'小学三年级',//3
		'小学四年级',//4
		'小学五年级',//5
		'小学六年级',//6
		'初中一年级',//7
		'初中二年级',//8
		'初中三年级',//9
		'高中一年级',//10
		'高中二年级',//11
		'高中三年级',//12
		'大学一年级',//13
		'大学二年级',//14
		'大学三年级',//15
		'大学四年级',//16
		'宗师一年级',//17
		'宗师二年级',//18
		'宗师三年级',//19
		'举世无双级',//20
	);
	$comment_level_desc=$touxiang[$comment_level];
	return $comment_level_desc;
}


/**********************************
**	评论等级的html代码
**	@参数1：等级：0-20，默认：0
**	@参数2：是否直接输出，默认：false
**	2012年11月8日23:31:15
**********************************/
function yundanran_comment_level_html($level=0,$echo=false)
{
	// 0-1
	if($level<=1)
	{
		$color=1;
	}
	// 2-6
	else if($level>=2 && $level<=6)
	{
		$color=2;
	}
	// 7-13
	else if($level>=7 && $level<=13)
	{
		$color=3;
	}
	// 14-20
	else
	{
		$color=4;
	}
	$desc=yundanran_comment_level_desc($level);
	$html=
	'
	<span class="y_level y_level-color'.$color.'" title="LV '.$level.'：'.$desc.'">
		<span class="y_level-lv y_level-lv'.$level.'"></span>
	</span>
	';
	if($echo)
		echo $html;
	else
		return $html;
}


/*******************************************
	**	1级评论根据hot来查询
	**	2012年8月22日19:50:02
******************************************/
function yundanran_1_comment_by_hot()
{
	global $wpdb;
	$q="SELECT * FROM $wpdb->comments where comment_parent=0 and comment_approved=1  order by comment_date desc";
	$s=$wpdb->get_results($wpdb->prepare($q,''));
	$out=array();
	if(count($s)>=1)
	{
		foreach ($s as $key => $value)
		{
			$comment=get_comment($value->comment_ID);
			$comment_link=get_comment_link($comment);
			$out[$key]['content']=yundanran_face2html($value->comment_content);
			$out[$key]['url']=$comment_link;
			$out[$key]['link']=get_permalink($comment->comment_post_ID).'#comments';
			$out[$key]['id']=$value->comment_ID;
			$out[$key]['email']=$comment->comment_author_email;
			$out[$key]['comment']=yundanran_get_comment_hot($value->comment_ID);
			$out[$key]['time']=date('Y年m月d日 H:i:s',strtotime($comment->comment_date));
			$out[$key]['time_ago']=yundanran_time_ago(strtotime($comment->comment_date));
		}
	}
	else
	{
		$out[0]['content']='没有评论';
		$out[0]['url']=get_option('home');
		$out[0]['link']=get_option('home');
		$out[0]['id']=0;
		$out[0]['comment']=0;
		$out[0]['time']='从未';
		$out[0]['email']=get_bloginfo('admin_email');
	}

	return $out;
}

/*******************************************
	**	热门评论
	**	2012年8月22日19:50:02
******************************************/
function yundanran_get_hot_comment($limit)
{
	// array_push  追加
	// array_unshift  前置
	$comments=yundanran_1_comment_by_hot();
	$limit=$limit?intval($limit)-1:9;
	$limit>count($comments)?count($comments)-1:$limit;
	
	$new_comments=array();
	$max_hot=0;
	$new_hot=0;
	//2维数组排序==base.php
	//数组，键名，排序，类型
	$new_comments=yundanran_2array_sort($comments,'comment','SORT_DESC','SORT_NUMERIC');
	return array_slice($new_comments,0,$limit);
}

/****************************************************
	**	获得评论的热度
	**	2012年8月22日20:14:00
****************************************************/
function yundanran_get_comment_hot($comment_ID)
{
	global $wpdb;
	$comment_max_depth=get_option('thread_comments_depth');
	$count=0;
	$id_arr[0]=array($comment_ID);
	for($i=0;$i<=$comment_max_depth-1;$i++)
	{
		$id_arr[$i+1]=array();
		foreach ($id_arr[$i] as $key => $value)
		{
			$id=$value;
			$q="SELECT comment_ID FROM $wpdb->comments where comment_parent=$id && comment_approved=1 order by comment_date desc";
			$s=$wpdb->get_results($q);
			$count+=count($s);
			foreach ($s as $k => $v)
			{
				array_push($id_arr[$i+1],$v->comment_ID);
			}
		}
	}
	
	if($count)return $count;
	else return 0;
}



function yundanran_comment_access_html($comment_ID=0,$echo=false)
{
	$comment=get_comment($comment_ID);
	if($comment)
	{
		$ua=$comment->comment_agent;
		$ip=$comment->comment_author_IP;
		// 本地架设的服务器ip返回的是::1，是错误的，如果要试用，请上传到服务器
	}
	else
	{
		$ua=null;
		$ip=null;
		// 不要return false，这里将用于非评论处
	}
	$AB=yundanran_get_access_browser($ua,$ip);
	if($AB['os_name']!='')
	{
		$OPname	=$AB['os_name'];
		$OPcode	=$AB['os_code'];
		$OPver	=$AB['os_ver'];
	}
	else
	{
		$OPname	=$AB['pda_name'];
		$OPcode	=$AB['pda_code'];
		$OPver	=$AB['pda_ver'];
	}
	$ipinfo=	$AB['ipinfo'];
	$html='
	<img src="'.YDR_COUNTRY_URL.strtolower($AB['country_o2c']).'.png" alt="'.$AB['country_o2c'].'" title="来自：'.$AB['country_oname'].'" />	
	<img src="'.YDR_BROWSER_URL.strtolower($OPcode).'.png" alt="'.$OPcode.'" title="操作系统：'.$OPname.' '.$OPver.'"/>
	<img src="'.YDR_BROWSER_URL.strtolower($AB['browser_code']).'.png" alt="'.$AB['browser_code'].'" title="浏览器：'.$AB['browser_name'].' '.$AB['browser_ver'].'"/>
	('.$ipinfo.')
	';
	if($echo)echo trim($html);
	else return trim($html);
}