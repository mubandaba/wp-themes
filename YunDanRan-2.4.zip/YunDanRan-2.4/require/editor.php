<?php
	$local_host	=$_SERVER['HTTP_HOST'];
	$time		=ceil(date('YmdH')/2);
?>
<style type="text/css">
#yundanran-face-box
{
	width:465px;
	position: absolute;
	height: auto;
	border: 1px solid #DDD;
	box-shadow: 2px 2px 4px #DDD;
	z-index: 9999;
	background: white;
	padding: 10px;
	top: 28px;
	border-radius: 3px;
	zoom: 1;
	display:none;
}
#yundanran-face-box .float{display:table\0;}
#yundanran-face-box .float::after{content:'\20';display:block;height:0;clear:both;}
#yundanran-face-box .alert{color: #D67012;background: #F8F8C6;border: 1px solid #D8C889;padding:2px 6px;}
#yundanran-face-box .error{color: #A20000;background:#FCEDED;border: 1px solid #DAA3A3;padding:2px 6px;}
#yundanran-face-box .success{color: #098CF3;background:#E4F4FA;border: 1px solid #81C1DA;padding:2px 6px;}
#yundanran-face-box .tip{color: #0A721B;background: #B8FFC1;border: 1px solid #8CD58C;padding:2px 6px;}

#yundanran-face-box h6
{
	height: 20px;
	line-height: 20px;
	border-bottom: 1px solid #DDD;
	margin:0;
}
#yundanran-face-box h6 .close
{
	position: absolute;
	top: 0;
	right: 0;
	width: 20px;
	height: 20px;
	background: url("<?=get_bloginfo('template_url')?>/public/image/public.png?v=20121125") -70px 0;
	cursor: pointer;
}
#yundanran-face-box h6 .close:hover
{
	background-position:-70px -20px;
}
#yundanran-face-box .wrap
{
	margin:10px;
}
#yundanran-face-box .wrap li
{
	width: 24px;
	height: 24px;
	border: 1px solid #DDD;
	padding: 2px;
	float: left;
	margin-left: 4px;
	margin-top: 4px;
	cursor: pointer;
	background-repeat: no-repeat;
	background-position: center center;
}
#yundanran-face-box .wrap li:hover
{
	border-color:#444;
}
#yundanran-editor-tools
{
	border: 1px solid #FFA5A5;
	border-radius: 4px;
	background: #FDF2F2;
	position:relative;
	margin-bottom:10px;
}
#yundanran-editor-tools .yundanran-title
{
	margin: 0;
	color: red;
	padding: 5px;
	height: 20px;
	line-height: 20px;
	background: #FFC2C2;
}
#yundanran-editor-tools .yundanran-content
{
	padding:10px;
	border-top:1px solid #FF5959;
}
#yundanran-editor-tools .yundanran-close
{
	position: absolute;
	top: 6px;
	right: 10px;
	color: #A00;
	border: 1px solid #FC8989;
	width: 14px;
	height: 14px;
	text-align: center;
	line-height: 14px;
	text-decoration: none;
	font-size: 14px;
	font-weight: 900;
	background: #FFCACA;
}
#yundanran-editor-tools .yundanran-close:hover
{
	color:#fff;
	background: #CA0000;
	border: 1px solid #700;
}
#yundanran-editor-tools .button
{
	margin-right: 10px;
	margin-bottom: 10px;
}
#yundanran-tip
{
	color:#0A8B00;
}
#yundanran-alert
{
	color:#DC6800;
}
#yundanran-error
{
	color:#9D0C00;
}
#yundanran-success
{
	color:#0363A5;
}
#yundanran-reply2view
{
	color:#f00;
}
</style>
<script type="text/javascript">
function yundanran_mp3player($src,$type,$auto,$loop)
{
	$simple_swf		='<?=get_bloginfo('template_url')?>/public/player/simple.swf';
	$dewmini_swf	='<?=get_bloginfo('template_url')?>/public/player/dewplayer-mini.swf';
	$mini_swf		='<?=get_bloginfo('template_url')?>/public/player/mini.swf';

	switch($type)
	{
		case 'dew':
		$auto	=$auto?'1':'0';
		$loop	=$loop?'1':'0';
		var $html=''
		+'<object type="application/x-shockwave-flash" data="'+$dewmini_swf+'" width="160" height="20" name="dewplayer">'
			+'<param name="wmode" value="transparent" />'
			+'<param name="movie" value="'+$dewmini_swf+'" />'
			+'<param name="flashvars" value="mp3='+$src+'&autostart='+$auto+'&autoreplay='+$loop+'&showtime=1" />'
		+'</object>';
		break;
		
		case 'mini':
		$auto	=$auto?'true':'false';
		$loop	=$loop?'true':'false';
		var $html=''
		+'<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="150" height="20">'
			+'<param name="movie" value="'+$mini_swf+'?file='+$src+'&width=150&songVolume=100&backColor=CEE3EA&frontColor=298EB7&autoStart='+$auto+'&repeatPlay='+$loop+'&showDownload=false" />'
			+'<param name="quality" value="high" />'
			+'<param name="wmode" value="transparent" />'
			+'<embed src="'+$mini_swf+'?file='+$src+'&width=150&songVolume=100&backColor=CEE3EA&frontColor=298EB7&autoStart='+$auto+'&repeatPlay='+$loop+'&showDownload=false" width="150" height="20" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash"></embed>'
		+'</object>';break;
		
		case 'simple':
		default:
		$auto	=$auto?'yes':'no';
		$loop	=$loop?'yes':'no';
		var $html=''
		+'<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="290" height="24">'
			+'<param name="movie" value="'+$simple_swf+'?soundFile='+$src+'&bg=0xcccccc&leftbg=0xdddddd&lefticon=0xF2F2F2&rightbg=0xdddddd&rightbghover=0xcccccc&righticon=0xffffff&righticonhover=0xFFFFFF&text=0x444444&slider=0x888888&track=0xFFFFFF&border=0xFFFFFF&loader=0xeeeeee&autostart='+$auto+'&loop='+$loop+'" />'
			+'<param name="quality" value="high" />'
			+'<param name="wmode" value="transparent" />'
			+'<embed src="'+$simple_swf+'?soundFile='+$src+'&bg=0xCDDFF3&leftbg=0x357DCE&lefticon=0xF2F2F2&rightbg=0x357DCE&rightbghover=0x4499EE&righticon=0xF2F2F2&righticonhover=0xFFFFFF&text=0x357DCE&slider=0x357DCE&track=0xFFFFFF&border=0xFFFFFF&loader=0x8EC2F4&autostart='+$auto+'&loop='+$loop+'"" width="290" height="24" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash"></embed>'
		+'</object>';break;
	}
	return $html;
}
jQuery(document).ready(function($)
{
	var html='<div id="yundanran-editor-tools"><a class="yundanran-close" href="#" title="折叠工具箱">-</a>';
	html+='<h6 class="yundanran-title"><b>提示：</b>您必须切换到可视化面板，然后点击按钮相应操作即可。</h6><div class="yundanran-content">';
	html+='<input type="button" value="修改图片meta" id="yundanran-image-meta" class="button" />';
	html+='<input type="button" value="移除图片链接" id="yundanran-image-unlink" class="button" />';
	html+='<input type="button" value="插入表情" id="yundanran-face" class="button" />';
	html+='<input type="button" value="插入代码" id="yundanran-code" class="button" />';
	html+='<input type="button" value="插入mp3" id="yundanran-mp3" class="button" />';
	html+='<input type="button" value="插入提示内容" id="yundanran-tip" class="button" />';
	html+='<input type="button" value="插入警告内容" id="yundanran-alert" class="button" />';
	html+='<input type="button" value="插入错误内容" id="yundanran-error" class="button" />';
	html+='<input type="button" value="插入正确内容" id="yundanran-success" class="button" />';
	html+='<input type="button" value="插入回复可见内容" id="yundanran-reply2view" class="button" />';
	html+='</div></div>';
	
	var html2='<div id="yundanran-fullscreen-tip" style="display:none; width:100%; height:100%; left:0px; top:0px; position:absolute; background-color:#fff; z-index:99999;">';
	html2+='<div class="tip" style="position:fixed;width:800px; height:auto; top:30%;left:50%; margin-left:-404px; color: #A00;font-size: 14px;border: 1px solid #FA0;padding: 4px; background-color:#FFE0A2; ">';
	html2+='<span></span>';
	html2+='<input disabled="disabled" style="position: absolute;right: 100px;top: 100%;" type="button" class="close button" value="确认并关闭">';
	html2+='<input style="position: absolute;right: 0px;top: 100%;" type="button" class="cancel button" value="取消并关闭">';
	html2+='</div></div>';
	
	var html3='<div id="yundanran-face-box">'
	+'<h6>插入表情<a href="#" class="close"></a></h6>'
	+'<div class="wrap"><ul class="float"></ul></div>'
	+'</div>';
	
	$(html).insertBefore($('#postdivrich'));
	$('#wp-content-media-buttons').css({'display':'inline'});
	$('body').append(html2);
	$(html3).appendTo(document.body);
	
	var $tools			=$('#yundanran-editor-tools'),
		$content		=$tools.find('.yundanran-content'),
		$close			=$tools.find('.yundanran-close');
	$close.toggle(function()
	{
		$(this).text('+');
		$content.stop(1,0).slideUp(333);
	},
	function()
	{
		$(this).text('-');
		$content.stop(1,0).slideDown(333);
	});

	var $tip			=$('#yundanran-fullscreen-tip');
	var $web			=$('#yundanran-upload-web');
	var $image_width	=$('#yundanran-image-width');
	var $image_meta		=$('#yundanran-image-meta');
	var $image_unlink	=$('#yundanran-image-unlink');
	var $code			=$('#yundanran-code');
	var $mp3			=$('#yundanran-mp3');
	var $face			=$('#yundanran-face');
	var $face_box		=$('#yundanran-face-box');
	var $div_alert		=$('#yundanran-alert');
	var $div_tip		=$('#yundanran-tip');
	var $div_success	=$('#yundanran-success');
	var $div_error		=$('#yundanran-error');
	var $reply2view		=$('#yundanran-reply2view');
	var IFRAME			='#content_parent iframe,#content iframe,#content_ifr';
	var $textarea		=$('#content[name=content]');
	// 同步更新到textarea
	function yundanran_sync2_textarea()
	{
		var content=$(IFRAME).contents().find('body').html();
		//	修复BUG
		//	清除原有的图片地址保存信息,防止默认编辑器还原图片地址
		//	非常重要
		$(IFRAME).contents().find('body').find('img').removeAttr('data-mce-src');
		//
		//
		if($textarea.length)
		{
			$textarea.val(content);
			$textarea.html(content);
		}
	}
	

	$image_meta.click(function()
	{
		var title=$('#title').val();
		var html='';
		var count=0;
		$(IFRAME).contents().find('body').find('img:not(.face)').each(function(index)
		{
			count++;
			$(this).attr({'alt':title,'title':title});
		});	
		yundanran_sync2_textarea();
		if(count==0)
		{
			html+='未检索到任何图片!<br/>';
		}
		else
		{
			html+='文章所有图片的元信息已经全部修改为【文章标题】!';
		}
		
		var H=$(document).height();
		$tip.height(H).fadeIn(555)
		.find('input.close').prop('disabled',false);
		$tip.find('.tip span').html(html);
	});

	$image_unlink.click(function()
	{
		var html='';
		var count=0;
		$(IFRAME).contents().find('body').find('img').each(function(index)
		{
			var a_link=($(this).parent('a').length>0)?1:0;
			a_link?$(this).unwrap('a'):'';
		});	
		yundanran_sync2_textarea();
		if(count==0)
		{
			html+='未检索到任何图片!<br/>';
		}
		else
		{
			html+='文章所有图片已经去除链接指向!<br/>';
		}
		
		var H=$(document).height();
		$tip.height(H).fadeIn(555).find('input.close').prop('disabled',false);
		$tip.find('.tip span').html(html);
	});
	
	function filter(str)
	{
		str = str.replace(/&/g, '&amp;');
		str = str.replace(/</g, '&lt;');
		str = str.replace(/>/g, '&gt;');
		str = str.replace(/'/g, '&#39;');
		str = str.replace(/"/g, '&quot;');
		str = str.replace(/\|/g, '&brvbar;');
		return str;
	}
	function insert_code(lang,code)
	{ 
		var str='<pre class="brush:'+lang+';toolbar:false;" data-lang="'+lang+'" data-toobar="false">';
		str=str+filter(code)+"</pre>";
		str=str+"&nbsp;";
		tinyMCE.execCommand('mceInsertContent',false,str);
		yundanran_sync2_textarea();
	}
	$code.click(function()
	{
		var code_html='';
		code_html+='<label>先选择代码的语言(默认是 javascript)'
		+'<select id="yundanran-code-lang" style="margin-left:10px;width: 120px;">'
		+'<option value="javascript">javascript</option>'
		+'<option value="html">html</option>'
		+'<option value="css">css</option>'
		+'<option value="php">php</option>'
		+'</select></label>'
		+'<label style="margin-left:10px;">然后输入相应的代码<br/>'
		+'<textarea id="yundanran-code-code" style="width:100%;min-width:100%;max-width:100%;min-height:200px;height:200px;"></textarea>'
		+'</label>';
		var H=$(document).height();
		$tip.height(H).fadeIn(555,function()
		{
			$(this).find('#yundanran-code-code').focus();
		})
		.find('input.close').prop('disabled',false);
		$tip.find('.tip span').html(code_html);
	});

	function insert_mp3(src,type,auto,loop)
	{ 
		var mp3=yundanran_mp3player(src,type,auto,loop);
		tinyMCE.execCommand('mceInsertContent',false,mp3);
		yundanran_sync2_textarea();
	}
	$mp3.click(function()
	{
		var mp3_html=''
		+'<div>'
		+'<label>选择mp3播放器'
		+'<select class="type">'
		+'<option value="simple">simple播放器</option>'
		+'<option value="mini">mini播放器</option>'
		+'<option value="dew">dew播放器</option>'
		+'</select>'
		+'</label>'
		+'<label style="margin-left:20px;">是否自动播放'
		+'<select class="auto">'
		+'<option value="1">自动播放</option>'
		+'<option value="0">不自动播放</option>'
		+'</select>'
		+'</label>'
		+'<label style="margin-left:20px;">是否循环播放'
		+'<select class="loop">'
		+'<option value="1">循环播放</option>'
		+'<option value="0">不循环播放</option>'
		+'</select>'
		+'</label>'
		+'</div>'
		+'<div><label><p>填入mp3地址：</p>'
		+'<textarea id="yundanran-mp3-src" style="width:100%;min-width:100%;max-width:100%;min-height:40px;height:40px;"></textarea>'
		+'</label></div>';
		var H=$(document).height();
		$tip.find('.tip span').html(mp3_html);
		$tip.height(H).fadeIn(555,function()
		{
			$(this).find('#yundanran-mp3-src').focus();
		})
		.find('input.close').prop('disabled',false);
	});


	$div_alert.click(function()
	{
		var _html='<input type="hidden" name="div-type" id="yundanran-div-type" value="alert" />'
		+'<div><label><p>输入警告样式的内容：</p>'
		+'<textarea id="yundanran-div-content" style="width:100%;min-width:100%;max-width:100%;min-height:70px;height:70px;line-height:20px;"></textarea>'
		+'</label></div>';
		var H=$(document).height();
		$tip.find('.tip span').html(_html);
		$tip.height(H).fadeIn(555,function()
		{
			$(this).find('#yundanran-div-content').focus();
		})
		.find('input.close').prop('disabled',false);
	});
	$div_error.click(function()
	{
		var _html='<input type="hidden" name="div-type" id="yundanran-div-type" value="error" />'
		+'<div><label><p>输入错误样式的内容：</p>'
		+'<textarea id="yundanran-div-content" style="width:100%;min-width:100%;max-width:100%;min-height:70px;height:70px;line-height:20px;"></textarea>'
		+'</label></div>';
		var H=$(document).height();
		$tip.find('.tip span').html(_html);
		$tip.height(H).fadeIn(555,function()
		{
			$(this).find('#yundanran-div-content').focus();
		})
		.find('input.close').prop('disabled',false);
	});
	$div_success.click(function()
	{
		var _html='<input type="hidden" name="div-type" id="yundanran-div-type" value="success" />'
		+'<div><label><p>输入正确样式的内容：</p>'
		+'<textarea id="yundanran-div-content" style="width:100%;min-width:100%;max-width:100%;min-height:70px;height:70px;line-height:20px;"></textarea>'
		+'</label></div>';
		var H=$(document).height();
		$tip.find('.tip span').html(_html);
		$tip.height(H).fadeIn(555,function()
		{
			$(this).find('#yundanran-div-content').focus();
		})
		.find('input.close').prop('disabled',false);
	});
	$div_tip.click(function()
	{
		var _html='<input type="hidden" name="div-type" id="yundanran-div-type" value="tip" />'
		+'<div><label><p>输入提示样式的内容：</p>'
		+'<textarea id="yundanran-div-content" style="width:100%;min-width:100%;max-width:100%;min-height:70px;height:70px;line-height:20px;"></textarea>'
		+'</label></div>';
		var H=$(document).height();
		$tip.find('.tip span').html(_html);
		$tip.height(H).fadeIn(555,function()
		{
			$(this).find('#yundanran-div-content').focus();
		})
		.find('input.close').prop('disabled',false);
	});
	
	
	function insert_div(type,content)
	{
		var div='<div class="'+type+'">\n'
		+'<div class="icon"></div>\n'
		+'<div class="cont">'+content+'</div>\n'
		+'</div>&nbsp;\n';
		tinyMCE.execCommand('mceInsertContent',false,div);
		yundanran_sync2_textarea();
	}
	
	
	
	
	
	var face_html='',
		$face_message=null;
	function face_message(t,c)
	{
		var m='<span style="display:none;position:absolute;top:8px;left:80px;"></span>';
		$face_message=(!$face_message)?
		$(m).insertBefore($face_box.find('.wrap')):
		$face_message;
		(t=='alert')?
		$face_message.removeClass().addClass(t).html(c).stop(1,0).fadeIn(333):
		$face_message.removeClass().addClass(t).html(c).stop(1,0).fadeIn(333).delay(2222).fadeOut(333);
	}
	$face_box.find('a.close').click(function()
	{
		$face_box.slideUp(333,function()
		{
			if($face_message)$face_message.fadeOut(1);
		});
		tinyMCE.execCommand('mceInsertContent',false,'');
		return false;
	});
	$face.click(function()
	{
		var t	=$(this).offset().top+$(this).outerHeight(),
			l	=$(this).offset().left;
		$face_box.css(
		{
			'top':t,
			'left':l
		}).slideDown(333);
		if(face_html=='')
		{
			$.ajax(
			{
				url:'<?=get_bloginfo('url')?>',
				dataType:'json',
				type:'post',
				data:{action:'yundanran_face'},
				beforeSend:function()
				{
					face_message('alert','正在载入表情……');
				},
				success:function(json)
				{
					face_message('success','表情载入成功。');
					face_html=json.info;
					$face_box.find('.wrap .float').html(face_html);
				},
				error:function()
				{
					face_message('error','网络错误，请稍后再试！');
				}
			});
		}
	});
	
	$(document).on('click','#yundanran-face-box .wrap li',function()
	{
		var src=$(this).css('background-image');
		src=src.replace(/^url\(/,'');
		src=src.replace(/\)$/,'');
		var tt=$(this).attr('title');
		var img='<img src="'+src+'" class="face" alt="'+tt+'" title="'+tt+'">';
		tinyMCE.execCommand('mceInsertContent',false,img);
	});
	
	$reply2view.click(function()
	{
		var _html=''
		+'<div><label><p>输入需要评论回复后可见的内容：</p>'
		+'<textarea id="yundanran-reply2view-content" style="width:100%;min-width:100%;max-width:100%;min-height:70px;height:70px;line-height:20px;"></textarea>'
		+'</label></div>';
		var H=$(document).height();
		$tip.find('.tip span').html(_html);
		$tip.height(H).fadeIn(555,function()
		{
			$(this).find('#yundanran-reply2view-content').focus();
		})
		.find('input.close').prop('disabled',false);
	});
	
	$tip.find('input.close').click(function()
	{
		if($tip.find('#yundanran-code-code').length>0)
		{
			var lang=$('#yundanran-code-lang option:selected').val();
			var code=$('#yundanran-code-code').val();
			(code=='')?'':insert_code(lang,code);
		}
		else if($tip.find('#yundanran-mp3-src').length>0)
		{
			var type	=$tip.find('.type option:selected').val(),
				auto	=$tip.find('.auto option:selected').val(),
				loop	=$tip.find('.loop option:selected').val(),
				src		=$tip.find('#yundanran-mp3-src').val();
			auto=(auto=='1')?1:0;
			loop=(loop=='1')?1:0;
			(src=='')?'':insert_mp3(src,type,auto,loop);
		}
		else if($tip.find('#yundanran-div-content').length>0)
		{
			var cont	=$tip.find('#yundanran-div-content').val(),
				type	=$tip.find('#yundanran-div-type').val();
			cont!=''?insert_div(type,cont):'';
		}
		else if($tip.find('#yundanran-reply2view-content').length>0)
		{
			var cont	=$tip.find('#yundanran-reply2view-content').val();
			var html=''
			+'<!--回复可见：开始-->'
			+'<div class="reply2view">'
			+'<p class="reply2view-title">以下内容需要评论回复后方可阅读：</p>'
			+'<div class="reply2view-content">'
			+cont
			+'</div>'
			+'</div>'
			+'<!--回复可见：结束-->'
			+'&nbsp;';
			tinyMCE.execCommand('mceInsertContent',false,html);
			yundanran_sync2_textarea();
		}
		$tip.fadeOut(555);
	});
	$tip.find('input.cancel').click(function()
	{
		tip_close();
	});
	function tip_close()
	{
		$tip.fadeOut(555,function()
		{
			tinyMCE.execCommand('mceInsertContent',false,'');
		});
	}
});
</script>