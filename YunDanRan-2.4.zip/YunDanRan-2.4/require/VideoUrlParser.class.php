<?php
/**

重新修改于 2013年1月24日19:20:46
by 云淡然
http://qianduanblog.com
部分url仍无法解析，太复杂了，如下：
部分土豆视频 http://www.tudou.com/listplay/--hPPLb3XDE.html
优酷视频全解析，推荐优酷视频



 * Video 
 * 
 * @package 
 * @version 1.2
 * @copyright 2005-2011 HDJ.ME 
 * @author Dijia Huang <huangdijia@gmail.com> 
 * @license PHP Version 3.0 {@link http://www.php.net/license/3_0.txt}
 *
 * Usage
 * require_once "VideoUrlParser.class.php";
 * $urls[] = "http://v.youku.com/v_show/id_XMjI4MDM4NDc2.html";
 * $urls[] = "http://www.tudou.com/playlist/p/l13087099.html";
 * $urls[] = "http://www.tudou.com/programs/view/ufg-A3tlcxk/";
 * $urls[] = "http://v.ku6.com/special/show_4926690/Klze2mhMeSK6g05X.html";
 * $urls[] = "http://www.56.com/u68/v_NjI2NTkxMzc.html";
 * $urls[] = "http://www.letv.com/ptv/vplay/1168109.html";
 * $urls[] = "http://video.sina.com.cn/v/b/46909166-1290055681.html";
 *
 * foreach($urls as $url){
 *     $info = VideoUrlParser::parse($url);
 *     //var_dump($info);
 *     echo "<a href='{$info['url']}' target='_new'>{$info['title']}</a>";
 *     echo "<br />";
 *     echo $info['object'];
 *     echo "<br />";
 * }
 *
 *
 */
class VideoUrlParser
{
    const USER_AGENT = "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.10 (KHTML, like Gecko)
        Chrome/8.0.552.224 Safari/534.10";
    const CHECK_URL_VALID = "/(youku\.com|tudou\.com|ku6\.com|56\.com|letv\.com|video\.sina\.com\.cn|(my\.)?tv\.sohu\.com|v\.qq\.com)/";

    /**
     * parse 
     * 
     * @param string $url 
     * @static
     * @access public
     * @return void
     */
    static public function parse($url=''){
        $lowerurl = strtolower($url);
        preg_match(self::CHECK_URL_VALID, $lowerurl, $matches);
        if(!$matches) return false;

        switch($matches[1]){
        case 'youku.com':
            $data = self::_parseYouku($url);
            break;
        case 'tudou.com':
            $data = self::_parseTudou($url);
            break;
        case 'ku6.com':
            $data = self::_parseKu6($url);
            break;
        case '56.com':
            $data = self::_parse56($url);
            break;
        case 'letv.com':
            $data = self::_parseLetv($url);
            break;
        case 'video.sina.com.cn':
            $data = self::_parseSina($url);
            break;
        case 'my.tv.sohu.com':
        case 'tv.sohu.com':
        case 'sohu.com':
            $data = self::_parseSohu($url);
            break;
        case 'v.qq.com':
            $data = self::_parseQq($url);
            break;
        default:
            $data = false;
        }

        return $data;
    }
    /**
     * 腾讯视频 
     * http://v.qq.com/cover/o/o9tab7nuu0q3esh.html?vid=97abu74o4w3_0
     * http://v.qq.com/play/97abu74o4w3.html
     * http://v.qq.com/cover/d/dtdqyd8g7xvoj0o.html
     * http://v.qq.com/cover/d/dtdqyd8g7xvoj0o/9SfqULsrtSb.html
     * http://imgcache.qq.com/tencentvideo_v1/player/TencentPlayer.swf?vid=97abu74o4w3
     */ 
    private function _parseQq($url)
	{
        $html=wp_remote_get($url);
		if(is_wp_error($html))return false;
		$body=$html['body'];
		preg_match("/vid=([^\_]+)/", $url, $matches);
		
		// 获得vid
		$vid = isset($matches[1])?$matches[1]:null;
		// print_r($matches);
		
		
		// 没有vid的要从js里读取
		if(!$vid)
		{
			preg_match("/vid=\"([^\"]+)\"/", $body, $matches);
			// print_r($matches);
			$vid = isset($matches[1])?$matches[1]:null;
		}
		
		// 还没有获取到则返回假
		if(!$vid)return false;
		
		preg_match("/<li[^>]*\sid=[\"']li_".$vid."[\"']?[^>]*>?(.*?)<\/li>/msi",$body,$matches);
		if(!$matches)return false;
		$li=$matches[1];
		
		preg_match("/<div[^>]*\sclass=[\"']info[\"']?[^>]*>?(.*?)<\/div>/msi",$li,$matches);
		if(!$matches)return false;
		$ap=$matches[1];
		
		preg_match("/<img[^>]*\s_src=[\"']([^>\"']*)[\"']?[^>]*>?/msi",$ap,$matches);
		if(!$matches)return false;
		$img=$matches[1];
		
		preg_match("/<p>?.*?<a[^>]*>?(.*?)<\/a>.*?<\/p>?/msi",$ap,$matches);
		if(!$matches)return false;
		$title=$matches[1];
		
		$swf="http://imgcache.qq.com/tencentvideo_v1/player/TencentPlayer.swf?vid=".$vid;
        $data['img'] = $img;
        $data['url'] = $url;
        $data['title'] = $title;
        $data['swf'] = $swf;
        return $data;
    }
    

    /**
     * 优酷网 
	 * http://v.youku.com/v_show/id_XNTA2MDA2NTg0.html?f=18878835
     * http://v.youku.com/v_show/id_XMjI4MDM4NDc2.html
     * http://player.youku.com/player.php/sid/XMjU0NjI2Njg4/v.swf
     */ 
    private function _parseYouku($url)
	{
        preg_match("#id\_(\w+)#", $url, $matches);
        $link = "http://v.youku.com/player/getPlayList/VideoIDS/{$matches[1]}/timezone/+08/version/5/source/out?password=&ran=2513&n=3";
		$retval=wp_remote_get($link,null);
        if (!is_wp_error($retval)) {
            $json = json_decode($retval['body'], true);
            $data['img'] = $json['data'][0]['logo'];
            $data['title'] = $json['data'][0]['title'];
            $data['url'] = $url;
            $data['swf'] = "http://player.youku.com/player.php/sid/{$matches[1]}/v.swf";
			$data['swf_old']='http://static.youku.com/v/swf/qplayer.swf?VideoIDS='.$matches[1];
            return $data;
        } else {
            return false;
        }
    }

    /**
     * 土豆网
     * http://www.tudou.com/programs/view/Wtt3FjiDxEE/
     * http://www.tudou.com/v/Wtt3FjiDxEE/v.swf
     * 
     // * http://www.tudou.com/playlist/p/a65718.html?iid=74909603
     // * http://www.tudou.com/l/G5BzgI4lAb8/&iid=74909603/v.swf
	 *
	 * http://www.tudou.com/listplay/--hPPLb3XDE.html
	 * http://www.tudou.com/l/--hPPLb3XDE/&resourceId=0_04_05_99&iid=161920844/v.swf
	 * 
    **/
    private function _parseTudou($url){
        preg_match("#view/([-\w]+)/#", $url, $matches);
		
        if (empty($matches)) 
		{
            return false;
        }

        $host = "www.tudou.com";
        $path = "/v/{$matches[1]}/v.swf";

        $ret = self::_fsget($path, $host);

        if (preg_match("#\nLocation: (.*)\n#", $ret, $mat)) {
            parse_str(parse_url(urldecode($mat[1]), PHP_URL_QUERY));

            $data['img'] = $snap_pic;
            $data['title'] = $title;
            $data['url'] = $url;
            $data['swf'] = "http://www.tudou.com/v/{$matches[1]}/v.swf";

            return $data;
        }
        return false;
    }

    /**
     * 酷6网 
     * http://v.ku6.com/film/show_520/3X93vo4tIS7uotHg.html
     * http://v.ku6.com/special/show_4926690/Klze2mhMeSK6g05X.html
     * http://v.ku6.com/show/7US-kDXjyKyIInDevhpwHg...html
     * http://player.ku6.com/refer/3X93vo4tIS7uotHg/v.swf
	 vid=7US-kDXjyKyIInDevhpwHg..&channel=101000&uid=11143784&ref=http%3A%2F%2Fv.ku6.com%2Fshow%2F7US-kDXjyKyIInDevhpwHg...html&type=0&cid=ku6player&activityurl=http%3A%2F%2Fjf.ku6.com&clogo=%2F%2Fcss.ku6cdn.com%2Fent%2F2012%2F1129%2F78x19.png
     */
    private function _parseKu6($url){
        if(preg_match("/show\_/", $url)){
            preg_match("#/([-\w]+)\.html#", $url, $matches);
            $url = "http://v.ku6.com/fetchVideo4Player/{$matches[1]}.html";
			$html=wp_remote_get($url);
			if(is_wp_error($html))return false;
			$html=$html['body'];

            if ($html) {
                $json = json_decode($html, true);
                
                $data['img'] = $json['data']['picpath'];
                $data['title'] = $json['data']['t'];
                $data['url'] = $url;
                $data['swf'] = "http://player.ku6.com/refer/{$matches[1]}/v.swf";

                return $data;
            } else {
                return false;
            }
        }
		elseif(preg_match("/show\//", $url, $matches))
		{
			$html=wp_remote_get($url);
			if(is_wp_error($html))return false;
			$html=$html['body'];
			
			$html=mb_convert_encoding($html,"UTF-8","GB2312");
            preg_match("/VideoInfo:(.*});/si", $html, $matches);
            $str = $matches[1];
			
            // img
            preg_match("/cover\s?:\s?\"([^\"]+)\"/", $str, $matches);
            $data['img'] = $matches[1];
			
            // title
            // preg_match("/<title>(.*)<\/title>/", $html, $title_arr);
            preg_match("/title\s?:\s?\"([^\"]+)\"/", $str, $matches);
            $data['title'] = self::decodeUnicode($matches[1]);
			
            // url
            $data['url'] = $url;
            // query
			// http://player.ku6cdn.com/default/common/player/201301252009/player.swf?vid=7US-kDXjyKyIInDevhpwHg..
			preg_match("/vid=([^&]*)&?/msi", $html, $matches);
			if(!$matches)return false;
			$vid=$matches[1];
            preg_match("/\/\/player\.ku6cdn\.com[^\"\']+/", $html, $matches);
            $data['swf'] = 'http:'.$matches[0].'?vid='.$vid;
            
            return $data;
        }
    }

    /**
     * 56网
     * http://www.56.com/u73/v_NTkzMDcwNDY.html
     * http://player.56.com/v_NTkzMDcwNDY.swf
     */
    private function _parse56($url){
        preg_match("#/v_(\w+)\.html#", $url, $matches);

        if (empty($matches)) return false;

        $link="http://vxml.56.com/json/{$matches[1]}/?src=out";

		$retval=wp_remote_get($link);
		if(is_wp_error($retval))return false;
		$retval=$retval['body'];

        if ($retval) {
            $json = json_decode($retval, true);
			if(empty($json['info']))return false;
            $data['img'] = $json['info']['img'];
            $data['title'] = $json['info']['Subject'];
            $data['url'] = $url;
            $data['swf'] = "http://player.56.com/v_{$matches[1]}.swf";

            return $data;
        } else {
            return false;
        } 
    }

    /**
     * 乐视网 
     * http://www.letv.com/ptv/vplay/1168109.html
     * http://www.letv.com/player/x1168109.swf
     */
    private function _parseLetv($url){
		
		$html=wp_remote_get($url);
		if(is_wp_error($html))return false;
		$html=$html['body'];
		
        preg_match("#var __INFO__=(.*)video : {(.*)},//视频图片(.*)var LISTCACHE=\[\];#smi", $html, $ms1);
		$info1=trim($ms1[2]);
		$info_arr=explode("\n",$info1);
		$title_str=$info_arr[0];
		preg_match("#title:\"([^\"]+)\"#",$title_str,$title_arr);
		$title=$title_arr[1];
		
		$img_str=$info_arr[7];
		preg_match("#share:{pic:\"([^\"]+)#",$img_str,$img_arr);
		$img=$img_arr[1];
		
        preg_match("#vplay/(\d+)#", $url, $matches);
		$data['img'] = $img;
        $data['title'] = $title;
        $data['url'] = $url;
        $data['swf'] = "http://www.letv.com/player/x{$matches[1]}.swf";

        return $data;
    }

    // 搜狐TV http://my.tv.sohu.com/u/vw/5101536
    private function _parseSohu($url){
       
		$html=wp_remote_get($url);
		if(is_wp_error($html))return false;
		$html=$html['body'];
	   
		$html=mb_convert_encoding($html,"UTF-8","GB2312");
        preg_match_all("/og:(?:title|image|videosrc)\"\scontent=\"([^\"]+)\"/s", $html, $matches);
        $data['title'] = $matches[1][1];
        $data['swf'] = $matches[1][0];
        $data['url'] = $url;
        $data['img'] = $matches[1][2];
        return $data;
    }
        
    /*
     * 新浪播客
     * http://video.sina.com.cn/v/b/48717043-1290055681.html
     * http://you.video.sina.com.cn/api/sinawebApi/outplayrefer.php/vid=48717043_1290055681_PUzkSndrDzXK+l1lHz2stqkP7KQNt6nki2O0u1ehIwZYQ0/XM5GdatoG5ynSA9kEqDhAQJA4dPkm0x4/s.swf
     */
    private function _parseSina($url){
        preg_match("/(\d+)(?:\-|\_)(\d+)/", $url, $matches);
        $url = "http://video.sina.com.cn/v/b/{$matches[1]}-{$matches[2]}.html";
        
		$html=wp_remote_get($url);
		if(is_wp_error($html))return false;
		$html=$html['body'];
		
        preg_match("/video\s?:\s?([^<]+)}/", $html, $matches);
        $find = array("/\n/", "/\s*/", "/\'/", "/\{([^:,]+):/", "/,([^:]+):/", "/:[^\d\"]\w+[^\,]*,/i");
        $replace = array('', '', '"', '{"\\1":', ',"\\1":', ':"",');
        $str = preg_replace($find, $replace, $matches[1]);
        $arr = json_decode($str, true);

        $data['img'] = $arr['pic'];
        $data['title'] = $arr['title'];
        $data['url'] = $url;
        $data['swf'] = $arr['swfOutsideUrl'];
        
        return $data;
    }


    /*
     * 通过 fsockopen 获取内容
     */
    private function _fsget($path='/', $host='', $user_agent=''){
        if(!$path || !$host) return false;
		$html="";
        $user_agent = $user_agent ? $user_agent : self::USER_AGENT;

        $out = <<<HEADER
GET $path HTTP/1.1
Host: $host
User-Agent: $user_agent
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
Accept-Language: zh-cn,zh;q=0.5
Accept-Charset: GB2312,utf-8;q=0.7,*;q=0.7\r\n\r\n
HEADER;
        $fp = @fsockopen($host, 80, $errno, $errstr, 10);
        if (!$fp)  return false;
        if(!fputs($fp, $out)) return false;
        while ( !feof($fp) ) {
            $html .= fgets($fp, 1024);
        }
        fclose($fp);
        // 判断是否gzip压缩
        if($dehtml = self::_gzdecode($html))
            return $dehtml;
        else
            return $html;
    }

   
    private function _gzdecode($data) {
        $len = strlen ( $data );
        if ($len < 18 || strcmp ( substr ( $data, 0, 2 ), "\x1f\x8b" )) {
            return null; // Not GZIP format (See RFC 1952) 
        }
        $method = ord ( substr ( $data, 2, 1 ) ); // Compression method 
        $flags = ord ( substr ( $data, 3, 1 ) ); // Flags 
        if ($flags & 31 != $flags) {
            // Reserved bits are set -- NOT ALLOWED by RFC 1952 
            return null;
        }
        // NOTE: $mtime may be negative (PHP integer limitations) 
        $mtime = unpack ( "V", substr ( $data, 4, 4 ) );
        $mtime = $mtime [1];
        $xfl = substr ( $data, 8, 1 );
        $os = substr ( $data, 8, 1 );
        $headerlen = 10;
        $extralen = 0;
        $extra = "";
        if ($flags & 4) {
            // 2-byte length prefixed EXTRA data in header 
            if ($len - $headerlen - 2 < 8) {
                return false; // Invalid format 
            }
            $extralen = unpack ( "v", substr ( $data, 8, 2 ) );
            $extralen = $extralen [1];
            if ($len - $headerlen - 2 - $extralen < 8) {
                return false; // Invalid format 
            }
            $extra = substr ( $data, 10, $extralen );
            $headerlen += 2 + $extralen;
        }
     
        $filenamelen = 0;
        $filename = "";
        if ($flags & 8) {
            // C-style string file NAME data in header 
            if ($len - $headerlen - 1 < 8) {
                return false; // Invalid format 
            }
            $filenamelen = strpos ( substr ( $data, 8 + $extralen ), chr ( 0 ) );
            if ($filenamelen === false || $len - $headerlen - $filenamelen - 1 < 8) {
                return false; // Invalid format 
            }
            $filename = substr ( $data, $headerlen, $filenamelen );
            $headerlen += $filenamelen + 1;
        }
     
        $commentlen = 0;
        $comment = "";
        if ($flags & 16) {
            // C-style string COMMENT data in header 
            if ($len - $headerlen - 1 < 8) {
                return false; // Invalid format 
            }
            $commentlen = strpos ( substr ( $data, 8 + $extralen + $filenamelen ), chr ( 0 ) );
            if ($commentlen === false || $len - $headerlen - $commentlen - 1 < 8) {
                return false; // Invalid header format 
            }
            $comment = substr ( $data, $headerlen, $commentlen );
            $headerlen += $commentlen + 1;
        }
     
        $headercrc = "";
        if ($flags & 1) {
            // 2-bytes (lowest order) of CRC32 on header present 
            if ($len - $headerlen - 2 < 8) {
                return false; // Invalid format 
            }
            $calccrc = crc32 ( substr ( $data, 0, $headerlen ) ) & 0xffff;
            $headercrc = unpack ( "v", substr ( $data, $headerlen, 2 ) );
            $headercrc = $headercrc [1];
            if ($headercrc != $calccrc) {
                return false; // Bad header CRC 
            }
            $headerlen += 2;
        }
     
        // GZIP FOOTER - These be negative due to PHP's limitations 
        $datacrc = unpack ( "V", substr ( $data, - 8, 4 ) );
        $datacrc = $datacrc [1];
        $isize = unpack ( "V", substr ( $data, - 4 ) );
        $isize = $isize [1];
     
        // Perform the decompression: 
        $bodylen = $len - $headerlen - 8;
        if ($bodylen < 1) {
            // This should never happen - IMPLEMENTATION BUG! 
            return null;
        }
        $body = substr ( $data, $headerlen, $bodylen );
        $data = "";
        if ($bodylen > 0) {
            switch ($method) {
                case 8 :
                    // Currently the only supported compression method: 
                    $data = gzinflate ( $body );
                    break;
                default :
                    // Unknown compression method 
                    return false;
            }
        } else {
            //...
        }
     
        if ($isize != strlen ( $data ) || crc32 ( $data ) != $datacrc) {
            // Bad format!  Length or CRC doesn't match! 
            return false;
        }
        return $data;
    }

	private function decodeUnicode($str)
	{
		return preg_replace_callback('/\\\\u([0-9a-f]{4})/i',
			create_function(
				'$matches',
				'return mb_convert_encoding(pack("H*", $matches[1]), "UTF-8", "UCS-2BE");'
			),
			$str);
	}
}