<?php
/*
	注册侧边栏
*/
// if( function_exists('register_sidebar') ) 
// {
	// register_sidebar(array(
		// 'name' => 'sidebar',
		// 'before_widget' => '',
		// 'after_widget' => '',
		// 'before_title' => '<div>',
		// 'after_title' => '</div>'
	// ));
// }





/*************************************************************
**	输出壁纸
**	2012年11月15日19:23:58
*************************************************************/
function yundanran_get_wallpaper_html($echo=false)
{
	$file = file(YDR_WALLPAPER_PATH);//读取全部内容; 
	$p='/[\n\r\t]/';
	$r='';
	
	foreach($file as $line => $content)
	{
		$line_url=trim($content)!=''?
		'"'.$content.'"':
		'';
		$line_url=preg_replace($p,$r,$line_url);
		$images[]=$line_url;
	}
	$l=count($images)-1;
	$html=join("\n,",$images);
	if($echo)echo $html;
	else return $html;
}



/**************************************************************
	**	返回页面 keywords、description
	**	2012年11月3日21:18:52
	**	@参数：keywords 或 description
**************************************************************/
function yundanran_header_meta($posts,$keys_or_description)
{
	$arr=array('search','Google_search','谷歌自定义搜索');	
	$home_keys=YDR_BLOG_KEY;
	$home_desc=YDR_BLOG_DESC;
	if (is_home())
	{
		$keywords = $home_keys;
		$description = $home_desc;
	}
	else if (is_single() || is_page())
	{
		$post=$posts[0];
		$tags = wp_get_post_tags($post->ID);
		$tag_arr=array();
		foreach($tags as $tag)
		{
			$tag_arr[]=$tag->name;
		}
		$keywords=join('，',$tag_arr);
		$keywords=($keywords=='')?$home_keys:$keywords;

		if ($post->post_excerpt)
		{
			$description = $post->post_excerpt;
		}
		else
		{
			$description = yundanran_substr_cn(htmlspecialchars(trim(stripslashes(strip_tags($post->post_content)))),0,200);
		}
	}
	else if(is_404())
	{
		$keywords = $home_keys;
		$description = $home_desc;
	}
	else if(is_category())
	{
		$keywords = trim(single_cat_title('',0));
		$description = $home_desc;
	}
	else if(is_tag())
	{
		$keywords = trim(single_tag_title('',0));
		$description = $home_desc;
	}
	else
	{
		$keywords = trim(wp_title('',0));
		$description = $home_desc;
	}
	$p='/[\n\r\t]/';
	$r='';
	//去掉回车等换行符
	$keywords		=preg_replace($p,$r,$keywords);
	$description	=preg_replace($p,$r,$description);
	return $keys_or_description=='keywords'?
	$keywords:$description;
}



/**************************************************************
	**	返回页面title
	**	if else 顺序不可换！
	**	谷歌搜索结果页的文章标题请设置为“search”
	**	2012年10月1日12:50:18
**************************************************************/
function yundanran_header_title()
{
	global $post;
	$ydr_google_page=of_get_option('ydr_google_page');
	$se_page_name=$ydr_google_page?get_page($ydr_google_page)->post_title:'';
	$arr=array($se_page_name);	
	$header='';
	if(is_home())
	{
		$paged=get_query_var('paged');
		if($paged)$header.="第{$paged}页 - ";
		$header.= YDR_BLOG_NAME.' - '.YDR_BLOG_DESC;
	}
	else if(is_attachment())
	{
		$header.='附件：'.wp_title('',0).' - '.YDR_BLOG_NAME;
	}
	else if(is_search() || is_page($arr))
	{
		YDR_GOOGLE_PAGE==get_bloginfo('url')?
		($q=isset($_GET['s'])?$_GET['s']:''):
		($q=isset($_GET['q'])?$_GET['q']:'');
		$header.='“'.$q.'”的搜索结果 - '.YDR_BLOG_NAME;
	}
	else if(is_page() 
	&& (
	isset($GLOBALS['yundanran_onlypage']) && $GLOBALS['yundanran_onlypage']==1)
	|| (isset($GLOBALS['yundanran_commentsonly']) && $GLOBALS['yundanran_commentsonly']==1)
	)
	{
		$header.=single_post_title('',0).' - '.YDR_BLOG_NAME;
	}
	else if(is_single() || is_page())
	{
		$format=yundanran_get_post_format($post->ID);
		$header.=$format.'：《'.single_post_title('',0).'》 - ';
		$header.=YDR_BLOG_NAME;
	}
	else if(is_404())
	{
		$header.='404：页面未找到 - '.YDR_BLOG_NAME;
	}
	else if(is_author())
	{
		$curauth = (get_query_var('author_name')) ? 
		get_user_by('slug', get_query_var('author_name')) : 
		get_userdata(get_query_var('author'));
		$role_arr=yundanran_get_user_role($curauth->ID);
		$role_name=$role_arr['role_name'];
		$role_desc=$role_arr['role_desc'];
		$author_name=$curauth->display_name;
		$header.=$role_desc.'：'.$author_name.' - '.YDR_BLOG_NAME;
	}
	else if(is_tag())
	{
		$header.='标签：'.single_tag_title('', 0).' - '.YDR_BLOG_NAME;
	}
	else if(is_category())
	{
		$header.= '分类：'.single_cat_title('',0).' - '.YDR_BLOG_NAME;
	}
	else if(is_archive())
	{
		$header.='存档：'.wp_title('',0).' - '.YDR_BLOG_NAME;
	}
	else
	{
		$header.=wp_title('',0).' - '.YDR_BLOG_NAME;
	}
	return $header;
}


/****************************************
	**	底部版权
****************************************/
function yundanran_copyright() 
{
	global $wpdb;
	$copyright_dates = $wpdb->get_results("
	SELECT
	YEAR(min(post_date_gmt)) AS firstdate,
	YEAR(max(post_date_gmt)) AS lastdate
	FROM
	$wpdb->posts
	WHERE
	post_status = 'publish'
	");
	$output = '&copy;：<a href="'.get_bloginfo('url').'" title="'.get_bloginfo('name').'">'.get_bloginfo('name').'</a> ';
	if($copyright_dates) 
	{
		$copyright =$copyright_dates[0]->firstdate;
		if($copyright_dates[0]->firstdate != $copyright_dates[0]->lastdate) 
		{
			$copyright .= '-' . $copyright_dates[0]->lastdate;
		}
		$output .= $copyright;
	}
	return $output;
}


/*********************************************************************
	**	友情链接
	**	加上fav图标
	**	默认解析网站：http://www.google.com/s2/favicons?domain=
	**	新增参数：fav_url
	**	2012年8月18日16:29:35
**********************************************************************/
function my_bookmarks($bookmarks, $args = '' ) 
{
	$defaults = array
	(
		'fav_url'=>'http://www.google.com/s2/favicons?domain=',
		'show_updated' => 0, 
		'show_description' => 0,
		'show_images' => 1, 
		'show_name' => 0,
		'between' => "\n",
		'show_rating' => 0, 
		'link_before' => '', 
		'link_after' => '',
		'nofollow' =>0
	);

	$r = wp_parse_args( $args, $defaults );
	extract( $r, EXTR_SKIP );

	$output = ''; // Blank string to start with.

	foreach ( (array) $bookmarks as $bookmark )
	{
		if ( !isset($bookmark->recently_updated) )
			$bookmark->recently_updated = false;

		$output .='<li>';

		if ( $show_updated && $bookmark->recently_updated )
			$output .= get_option('links_recently_updated_prepend');

		$the_link = '#';
		if ( !empty($bookmark->link_url) )
			$the_link = esc_url($bookmark->link_url);

		$rel = ' rel="external';
		if ($nofollow)
			$rel .= ' nofollow';
		if ( '' != $bookmark->link_rel )
			$rel .= ' ' . $bookmark->link_rel;
		$rel .= '"';

		$desc = esc_attr(sanitize_bookmark_field('link_description', $bookmark->link_description, $bookmark->link_id, 'display'));
		$name = esc_attr(sanitize_bookmark_field('link_name', $bookmark->link_name, $bookmark->link_id, 'display'));
 		$title = $desc;

		if ( $show_updated )
			if ( '00' != substr($bookmark->link_updated_f, 0, 2) )
			{
				$title .= ' (';
				$title .= sprintf(__('Last updated: %s'), date(get_option('links_updated_date_format'), $bookmark->link_updated_f + (get_option('gmt_offset') * 3600)));
				$title .= ')';
			}

		if ( '' != $title )
			$title = ' title="' . $title . '"';
		else
			$title = ' title="' . $name . '"';

		$alt = ' alt="' . $name . '"';

		$target = $bookmark->link_target;
		if ( '' != $target )
			$target = ' target="' . $target . '"';

		$output .= "<a href='$the_link' $title target='_blank' $rel>";

		$output .= $link_before;

		if ( $show_images )
		{
			if ( $bookmark->link_image != null)
			{
				if ( strpos($bookmark->link_image, 'http') !== false )
					$output .= "link_image\" $alt $title />";
				else // If it's a relative path
					$output .= "link_image\" $alt $title />";
			} 
			else
			//否则显示网站的Favicon
			{
				if (preg_match('/^(https?:\/\/)?([^\/]+)/i',$the_link,$URI))
				//提取域名
				{
					$domains = $URI[2];
					$__p=$URI[0];
				}
				else
				//域名提取失败，显示默认小地球
				{
					$domains = "example.com";
				}
				$output .= '<img src="'.$fav_url.$domains.'" width="16" height="16" />';
			}
		}

		$output .= $name;
		$output .= $link_after;
		$output .= '</a>';

		if ( $show_updated && $bookmark->recently_updated )
			$output .= get_option('links_recently_updated_append');

		if ( $show_description && '' != $desc )
			$output .= $between . $desc;

		if ($show_rating) {
			$output .= $between . sanitize_bookmark_field('link_rating', $bookmark->link_rating, $bookmark->link_id, 'display');
		}

		$output .= "</li>\n";
	} // end while
	$output.='';
	return $output;
}

function yundanran_list_bookmarks($args = '')
{
	$defaults = array
	(
		'orderby' => 'name',
		'order' => 'ASC',
		'limit' => -1,
		'category' => '',
		'exclude_category' => '',
		'category_name' => '',
		'hide_invisible' => 1,
		'show_updated' => 0, 
		'echo' => 1,
		'categorize' => 1, 
		'title_li' => __('Bookmarks'),
		'title_before' => '',
		'title_after' => '',
		'category_orderby' => 'name',
		 'category_order' => 'ASC',
		'class' => 'linkcat', 
		'category_before' => '',
		'category_after' => '',
		'nofollow' => 0
	);

	$r = wp_parse_args( $args, $defaults );
	extract( $r, EXTR_SKIP );

	$output = '';

	if ( $categorize ) {
		//Split the bookmarks into ul's for each category
		$cats = get_terms('link_category', array('name__like' => $category_name, 'include' => $category, 'exclude' => $exclude_category, 'orderby' => $category_orderby, 'order' => $category_order, 'hierarchical' => 0));

		foreach ( (array) $cats as $cat ) {
			$params = array_merge($r, array('category'=>$cat->term_id));
			$bookmarks = get_bookmarks($params);
			if ( empty($bookmarks) )
				continue;
			$output .= str_replace(array('%id', '%class'), array("linkcat-$cat->term_id", $class), $category_before);
			$catname = apply_filters( "link_category", $cat->name );
			$output .= "$title_before$catname$title_after\n\t\n<ul class=\"xoxo blogroll\">";
			$output .= my_bookmarks($bookmarks, $r);
			$output .= "</ul>\n\t\n$category_after\n";
		}
	} else {
		//output one single list using title_li for the title
		$bookmarks = get_bookmarks($r);

		if ( !empty($bookmarks) ) {
			if ( !empty( $title_li ) ){
				$output .= str_replace(array('%id', '%class'), array("linkcat-$category", $class), $category_before);
				$output .= "$title_before$title_li$title_after\n\t\n";
				$output .= my_bookmarks($bookmarks, $r);
				$output .= "\n\t\n$category_after\n";
			} else {
				$output .= my_bookmarks($bookmarks, $r);
			}
		}
	}

	$output = apply_filters( 'wp_list_bookmarks', $output );

	if ( !$echo )
		return $output;
	echo $output;
}


function yundanran_seo_about()
{
	$str=get_bloginfo('name').'主要包括'.YDR_BLOG_KEY.'等信息，是基于wordpress的个人博客，'.YDR_BLOG_DESC
	.'。博客主题来自云前端博客（http://qianduanblog.com）。';
	return $str;
}