<?php
/*
	ajax 注册用户
	2013年3月16日19:57:05
*/
// /*
function _yundanran_register()
{
	if(isset($_POST['action']) && $_POST['action']=='_yundanran_register')
	{
		$username=trim(stripslashes(strip_tags($_POST['n'])));
		$userpass=$_POST['p'];
		$useremail=strtolower(trim(stripslashes(strip_tags($_POST['e']))));
		$verify=trim(stripslashes(strip_tags($_POST['v'])));
		$s_verify=$_SESSION['verify'];
		
		if(preg_match("/^\w{3,12}$/",$username) && !username_exists($username)
		&& !email_exists($useremail) && is_email($useremail)
		&& $userpass!=''
		&& $verify==$s_verify)
		{
			$params=array
			(
				'user_login'=>$username,
				'user_email'=>$useremail,
				'user_pass'=>$userpass
			);
			$user=wp_insert_user($params);
			if(is_wp_error($user))
			{
				$data=-1;
				$info=$user->get_error_message();
			}
			else
			{
				$creds['user_login'] = $username;
				$creds['user_password'] = $userpass;
				$creds['remember']=true;
				$user2 = wp_signon( $creds, false );//array,是否加密cookie
				if(is_wp_error($user2))
				{
					$data=-99;
					$info='错误：注册成功，但登录失败！';
				}
				else
				{
					$data=1;
					$info='注册成功。';
				}
			}
		}
		else if($username=='')
		{
			$data=-1;
			$info='错误：用户名不能为空！';
		}
		else if(!preg_match("/^\w{3,11}$/",$username))
		{
			$data=-1;
			$info='错误：用户名必须是3-12位英文或数字下划线！';
		}
		else if(username_exists($username))
		{
			$data=-1;
			$info='错误：用户名已存在！';
		}
		else if($userpass=='')
		{
			$data=-2;
			$info='错误：密码不能为空！';
		}
		else if($useremail=='')
		{
			$data=-3;
			$info='错误：邮箱不能为空！';
		}
		else if(!is_email($useremail))
		{
			$data=-3;
			$info='错误：邮箱格式错误！';
		}
		else if(email_exists($useremail))
		{
			$data=-3;
			$info='错误：邮箱已被注册！';
		}
		else if($verify!=$s_verify)
		{
			$data=-4;
			$info='错误：验证码填写错误！';
		}
		else
		{
			$data=-99;
			$info='错误：未知的错误';
		}
		$json['data']=$data;
		$json['info']=$info;
		header("Content-Type: application/json");
		echo json_encode($json);
		exit;
	}
}
add_action('init', '_yundanran_register');
// */



/******************************************************
	**	ajax-sidebar- yundanran_login
	**	登录
	**	2012年8月25日14:15:22
	**	2013年3月16日19:57:08
******************************************************/
function _yundanran_login()
{
	if(isset($_POST['action']) && $_POST['action']=='_yundanran_login')
	{
		$type	=isset($_POST['type'])?(int)stripslashes($_POST['type']):1;//0=游客，1=用户
		
		if($type==1)
		{
			if(!is_user_logged_in())
			{
				$creds = array();
				$creds['user_login'] = strtolower(stripslashes($_POST['n']));
				$creds['user_password'] = stripslashes($_POST['p']);
				$creds['remember']=true;

				if($creds['user_login']!='' && $creds['user_password']!='')
				{
					$user = wp_signon( $creds, false );//array,是否加密cookie
					if (is_wp_error($user) )
					{
						$data=-4;
						$info='错误：用户名密码不匹配！';
					}
					else
					{
						$data=1;
						$info='成功：已登录，等待页面刷新。';
					}
				}			
				else if($creds['user_login']=='')
				{
					$data=-1;
					$info='错误：用户名不能为空！';
				}
				else if($creds['user_password']=='')
				{
					$data=-2;
					$info='错误：密码不能为空！';
				}
			}
			else
			{
				$data=0;
				$info='错误：您已经登录了！';
			}
		}
		else
		{
			$comment_author			=stripslashes(strip_tags($_POST['n']));
			$comment_author_email	=stripslashes(strip_tags($_POST['e']));
			$comment_author_url		=stripslashes(strip_tags($_POST['u']));
			global $wpdb;
			$sql="SELECT display_name, user_email FROM $wpdb->users WHERE display_name =%s OR user_email = %s";
			$res=$wpdb->get_results($wpdb->prepare($sql,$comment_author,$comment_author_email));
			//匹配到注册会员
			if($res)
			{
				if ($res[0]->display_name == $comment_author)
				{
					$data=-1;
					$info='错误：昵称不能与注册用户相同！';
					$VERIFY=0;
				} 
				else if(strtolower($res[0]->user_email) == strtolower($comment_author_email))
				{
					$data=-2;
					$info='错误：邮箱不能与注册用户相同！';
					$VERIFY=0;
				}
			}
			else
			{		
				if($comment_author!='')
				{
					if(get_option('require_name_email'))
					{
						if($comment_author_email!='' && is_email($comment_author_email))
						{
							$p="/http[s]?:\/\/.*+/i";
							if($comment_author_url!='' && !preg_match($p,$comment_author_url))
							{
								$data=-3;
								$info='错误：网址必须以http(s)://开头!';
							}
							else
							{
								setcookie('comment_author_' . COOKIEHASH, $comment_author, time() + 30000000, COOKIEPATH, COOKIE_DOMAIN);
								setcookie('comment_author_email_' . COOKIEHASH, $comment_author_email, time() + 30000000, COOKIEPATH, COOKIE_DOMAIN);
								setcookie('comment_author_url_' . COOKIEHASH, esc_url($comment_author_url), time() + 30000000, COOKIEPATH, COOKIE_DOMAIN);
								$data=1;
								$info='成功：已保存您的用户信息。';
							}
						}
						else if($comment_author_email=='')
						{
							$data=-2;
							$info='错误：邮箱不能为空!';
						}
						else
						{
							$data=-2;
							$info='错误：邮箱格式不正确!';
						}
					}
					else
					{
						$p="/http[s]?:\/\/.*+/i";
						if($comment_author_url!='' && !preg_match($p,$comment_author_url))
						{
							$data=-3;
							$info='错误：网址必须以http(s)://开头!';
						}
						else
						{
							setcookie('comment_author_' . COOKIEHASH, $comment_author, time() + 30000000, COOKIEPATH, COOKIE_DOMAIN);
							setcookie('comment_author_email_' . COOKIEHASH, $comment_author_email, time() + 30000000, COOKIEPATH, COOKIE_DOMAIN);
							setcookie('comment_author_url_' . COOKIEHASH, esc_url($comment_author_url), time() + 30000000, COOKIEPATH, COOKIE_DOMAIN);
							$data=1;
							$info='成功：已保存您的用户信息。';
						}
					}
				}
				else
				{
					$data=-1;
					$info='错误：昵称不能为空！';
				}
			}
		}

		$json['data']=$data;
		$json['info']=$info;
		header("Content-Type: application/json");
		echo json_encode($json);
		exit;
	}
}
add_action('init', '_yundanran_login');




function _yundanran_logout()
{
	if(isset($_POST['action']) && $_POST['action']=='yundanran_logout')
	{
		if($_POST['user_id']!='')
		{
			wp_clear_auth_cookie();
			$data=1;
			$info='';
		}
		else
		{
			$data1=-1;
			$info='';
		}
		$json['data']=$data;
		$json['info']=$info;
		header("Content-Type: application/json");
		echo json_encode($json);
		exit;		
	}
}
add_action('init', '_yundanran_logout');




/****************************************************
	**	用户数量
	**	2012年8月25日14:13:26
****************************************************/
function yundanran_count_user()
{
	global $wpdb;
	$q="select count(ID) from $wpdb->users";
	$s=$wpdb->get_var($q);
	return $s;
}





/****************************************************
	**	获得用户角色
	**	2012年8月25日14:13:26
****************************************************/
function yundanran_get_user_role($user_id)
{
	$role='unknow';
	$role2='游客';
	
	$user_id = (int)$user_id;
	
	if(!$user_id || $user_id==0)return
	$role_arr=array
	(
		'role_name'=>$role,
		'role_desc'=>$role2
	);
	$user	=new WP_User($user_id);
	$role	=$user->roles[0];
	if($role=='subscriber')
	{
		// $role='subscriber';//订阅者
		$role2='订阅者';
	}
	else if($role=='contributor')
	{
		// $role='contributor';//投稿者
		$role2='投稿者';
	}
	else if($role=='author')
	{
		// $role='author';//作者
		$role2='作者';
	}
	else if($role=='editor')
	{
		// $role='editor';//编辑
		$role2='编辑';
	}
	else if($role=='administrator')
	{
		// $role='administrator';//管理员
		$role2='管理员';
	}
	else
	{
		$role='unknow';
		$role2='游客';
	}

	return
	$role_arr=array
	(
		'role_name'=>$role,
		'role_desc'=>$role2
	);
}




/*****************************************************
	**	获得用户评论数量
	**	@user_id or user_email
	**	2012年8月25日14:16:51
*****************************************************/
function yundanran_get_user_comment_count($user_id_or_email)
{
	/*
		为了统计正确，先查找此email是否是会员email
		因为有可能，会员先前使用游客登录，后来注册的，是相同的email
		这个时候，如果单纯使用email统计就会出错
		2012年11月18日22:20:40
	*/
	if(is_email($user_id_or_email))
	{
		$email=strtolower(trim($user_id_or_email));
		$user=get_user_by('email',$email);
		$user_id=($user)?$user->ID:0;
		/*
			如果不是会员，那么忽略评论表的user_id字段
			防止因为删除了该会员信息，导致该会员的id在评论表还存在
			2013年1月19日22:48:18
		*/
		$c=$user?
		"comment_author_email='$email' and user_id=$user_id":
		"comment_author_email='$email'";
	}
	else if(is_numeric($user_id_or_email))
	{
		$user_id=(int)$user_id_or_email;
		/*
			防止因为先前删除的用户id和当前
			清除id自增后新增的用户id重复
			所以还必须判断user_email
			2013年1月19日22:57:15
		*/
		$user_email=get_user_by('id',$user_id)->user_email;
		$c="user_id=$user_id and comment_author_email='$user_email'";
	}
	else
	{
		return 0;
	}
	
	global $wpdb;
	$q="SELECT count(comment_ID) FROM $wpdb->comments  where $c";
	$s=$wpdb->get_var($q);
	return $s;
}




/*
	**	待删除
	**	目前用于读者墙
*/
function yundanran_user_info($email,$info='',$class='',$show_data=true)
{
	global $wpdb;
	$r=$wpdb->get_results("SELECT ID, display_name, user_email FROM $wpdb->users WHERE user_email = '".$email."'");
	$role=($r[0]->user_email == $email)?'user':'guest';
	$id=(!$r[0]->ID || $r[0]->ID=='' || $r[0]->ID==0)?0:$r[0]->ID;
	$can=(user_can($id,'subscriber'))?'订阅者':
	(user_can($id,'contributor'))?'贡献者':
	(user_can($id,'author'))?'作者':
	(user_can($id,'editor'))?'编辑':
	(user_can($id,'administrator'))?'管理员':'读者';
	$s=yundanran_is_qq_bind($id);
	$is_qq=$s?' from-qq ':' from-null ';
	$title=$s?'来自QQ互联':'';
	$data=$show_data?' data-id="'.$id.'" data-role="'.$role.'" data-can="'.$can.'" ':' ';
	$class2=$show_data?' user-card ':' ';
	$str=' class="'.$class.$class2.$is_qq.'"'.$data.' data-info="'.$info.'"><i title="'.$title.'" class="user-from '.$is_qq.'"></i';
	$st2222222222222='>';//《================无意义语句！！！！
	
	return $str;
}