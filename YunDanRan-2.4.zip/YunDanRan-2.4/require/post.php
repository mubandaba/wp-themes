<?php
/*
	获得第一篇文章的发布时间
	2013年3月9日19:18:13
	获得最后一篇文章的发布时间 get_lastpostdate($timezone);
*/
function yundanran_get_firstpostdate($format = "Y-m-d")
{
	// Setup get_posts arguments
	$ax_args = array
	(
		'numberposts' => -1,
		'post_status' => 'publish',
		'order' => 'ASC'
	);
	// Get all posts in order of first to last
	$ax_get_all = get_posts($ax_args);
	// Extract first post from array
	$ax_first_post = $ax_get_all[0];
	// Assign first post date to var
	$ax_first_post_date = $ax_first_post->post_date;
	// return date in required format
	$output = date($format, strtotime($ax_first_post_date));
	return $output;
}


/*=========================== //增加文章形式 ==============================*/
add_theme_support( 'post-formats', array('aside','image','gallery','video')); 



/*====================== 开启文章缩略图 ========================*/
add_theme_support( 'post-thumbnails' );
set_post_thumbnail_size( 160, 190 ,1); //文章缩略图：长、宽、是否裁剪【模型（盒、裁剪）】




add_filter("the_content","yundanran_the_content_replace_img_original");
function yundanran_the_content_replace_img_original($content)
{
	if(!YDR_IMAGE_LAZY)return $content;
	return yundanran_replace_img_original($content);
}
/**
	*替换的真实地址
	*2013年1月24日23:31:20
**/
function yundanran_replace_img_original($string)
{
	$p="/<img([^>]*)>/";
	return preg_replace_callback($p,"yundanran_replace_img_original_cb",$string);
}
function yundanran_replace_img_original_cb($matches)
{
	
	$attr_arr=explode(" ",trim($matches[1]));
	
	foreach($attr_arr as $key=>$attr)
	{
		preg_match("/^src=[\"']([^\"']+)[\"']/",trim($attr),$srcs);
		if($srcs)$src=$srcs[1];
		$attr_arr[$key]=preg_replace("/^(src=).*/","\\1'".YDR_IMAGE_REPLACE."'",trim($attr));
	}
	$attr_arr[]="data-original='{$src}'";
	
	return "<img ".implode(" ",$attr_arr)." />";
}



/*#############################################
###	相册
###	2013年1月15日19:37:45
##############################################*/
add_filter('post_gallery','yundanran_post_gallery',10,2);
function yundanran_post_gallery($output,$attr=array())
{
	// 全局post
	global $post;
	
	// 静态id自增
	static $instance = 0;
	$instance++;
	
	// 序列化参数
	extract(shortcode_atts(array(
		'order'      => 'ASC',
		'orderby'    => 'menu_order ID',
		'id'         => intval($post->ID),
		'itemtag'    => 'dl',
		'icontag'    => 'dt',
		'captiontag' => 'dd',
		'columns'    => 3,
		'size'       => 'thumbnail',
		'include'    => '',
		'exclude'    => ''
	), $attr));

	// post图像附件
	$attachments = get_children( array(
		'post_parent'    => $id,
		'post_status'    => 'inherit',
		'post_type'      => 'attachment',
		'post_mime_type' => 'image',
		'order'          => $order,
		'orderby'        => $orderby,
		'exclude'        => $exclude,
		'include'        => $include
	) );
	
	// 如果为空或者是feed页面，返回空使用默认样式
	if ( empty( $attachments ) || is_feed() ) {
		return '';
	}
	
	
	
	
	$output = "<ul id='gallery-{$instance}' class='yundanran-gallery float'>\n";
	foreach ($attachments as $id => $attachment )
	{
		$src=wp_get_attachment_image_src($id,'thumbnail',false);
		$real_src=wp_get_attachment_image_src($id,'full',false);
		$attr=array
		(
			'real-src'=>$real_src[0],
			'real-width'=>$real_src[1],
			'real-height'=>$real_src[2],
		);
		
		if(YDR_IMAGE_LAZY)$attr['data-original']=$src[0];
		
		$image=wp_get_attachment_image($id,'thumbnail',false,$attr);
		
		if(YDR_IMAGE_LAZY)$image=yundanran_replace_image_src($image,YDR_IMAGE_REPLACE);
		
		$output.= "<li class='gallery-item'>$image</li>";
	}
	$output.="</ul><div class='clear'></div>\n";
	
	return $output;
}





/******************************************
	**	获得文章缩略图
	**	优先级如下：
	**	1、文章设置的特色图像
	**	2、文章所属第一个分类的图像
	**	3、预先设置的图像
	**	参数 post_id
	**	2013年1月9日20:35:26
******************************************/
function yundanran_get_post_thumbnail($post_id)
{
	$post			=get_post($post_id);
	if(!$post)return false;
	$link 			=get_permalink($post_id);
	$title 			=esc_attr(strip_tags(get_the_title($post_id)));
	$attr=array
	(
		'class'=>'thumbnail-img'
	);
	if(has_post_thumbnail($post_id))
	{
		$tb=get_the_post_thumbnail($post_id,'post-thumbnail',$attr);
	}
	else
	{
		//不存在特殊图像，则读取文章分类的图像
		$cats=get_the_category($post_id);
		$cat_id=0;
		if(count($cats)>0)
		{
			foreach($cats as $cat)
			{
				if($cat_id>0)return false;
				$cat_id=$cat->term_id;
				$cat_name=$cat->cat_name;
			}
			$src=of_get_option('ydr_cat_'.$cat_id,get_bloginfo('template_url').'/public/image/null.gif');
			$src=$src?$src:get_bloginfo('template_url').'/public/image/null.gif';
		}
		else
		{
			$src=get_bloginfo('template_url').'/public/image/null.gif';
		}
		$tb='<img class="thumbnail-img" src="'.$src.'" cat_id="'.$cat_id.'" alt="'.$cat_name.'" width="160" height="190" />';
	}
	$p='/[\n\r\t]/';
	$r='';
	$tb='<a href="'.$link.'" title="详细阅读《'.$title.'》">'.$tb.'</a>';
	$tb2=preg_replace($p,$r,$tb);
	return $tb2;
}

/************************************************
	获得文章的第一张图片，出去class=face的图片
	通常用于图片格式的文章
	2013年1月9日20:58:15
************************************************/
function yundanran_get_post_1stimg($post_id)
{
	$post			=get_post($post_id);
	if(!$post)return false;
	$content 		=$post->post_content;
	$link 			=get_permalink($post_id);
	$title 			=esc_attr(strip_tags(get_the_title($post_id)));
	preg_match_all('/<img([^>]*)src=[\'"]([^\'">]*)[\'"]+?([^>]*)>+?/sim', $content, $str, PREG_PATTERN_ORDER);
	$n = count($str[2]);
	if($n==0 || preg_match('/class=[\'"][^\'">]*face[^\'">]*[\'"]+?/',$str[1][0],$s) || preg_match('/class=[\'"][^\'">]*face[^\'">]*[\'"]+?/',$str[3][0],$s2))
	{
		return '<span class="has-no-img">暂无图片</span>';
	}
	else
	{
		$image=YDR_IMAGE_LAZY?
		'<img class="first-img" data-original="'.$str[2][0].'" src="'.YDR_IMAGE_REPLACE.'"/>':
		'<img class="first-img" src="'.$str[2][0].'"/>';
		return '<a href="'.$link.'" title="详阅《'.$title.'》">'.$image.'</a>';
	}
}


/*
	使return的内容样式化
	2013年1月2日22:18:18
*/
function yundanran_the_content($more_link_text = null, $stripteaser = false)
{
	$content = get_the_content($more_link_text, $stripteaser);
	$content = apply_filters('the_content', $content);
	$content = str_replace(']]>', ']]&gt;', $content);
	return $content;
}




/*################################
###	设置回复可见内容
###	return string
###	2012年12月27日20:36:57
##################################*/
function yundanran_set_reply2view($str,$post_id)
{
	$post=get_post($post_id);
	if(!$post)return;
	
	// 作者email
	$author_email=get_userdata($post->post_author)->user_email;
	
	// 访问者的email
	if(is_user_logged_in())
	{
		global $current_user;
		get_currentuserinfo();
		$access_email 		=$current_user->user_email;
	}
	else
	{
		$access_email=isset($_COOKIE["comment_author_email_".COOKIEHASH])?$_COOKIE["comment_author_email_".COOKIEHASH]:'';
	}
	
	global $wpdb;
	$sql="select count(comment_ID) from $wpdb->comments where comment_post_ID=%d and comment_author_email=%s limit 1";
	$s=$wpdb->get_var($wpdb->prepare($sql,$post_id,$access_email));
	
	
	// 如果是作者或者已经评论回复了文章
	if($access_email==$author_email || $s>0)
	{
		$new=preg_replace_callback("/<!--回复可见：开始-->(.*?)<!--回复可见：结束-->/sm","yundanran_set_reply2view_callback",$str);
		$bool='true';
	}
	else
	{
		$new=preg_replace("/<!--回复可见：开始-->(.*?)<!--回复可见：结束-->/sm",'<div class="reply2view lock"><i></i>此处内容需要评论回复后方可阅读。</div>',$str);
		$bool='false';
	}
	return $new."
	<script>
	yundanran.is_reply=$bool;
	</script>
	";
}
function yundanran_set_reply2view_callback($matches)
{
	if($matches[0])
	{
		$cont=yundanran_get_reply2view($matches[0]);
		return $cont[0];
	}
	else
	{
		return '没有内容可以显示！';
	}
}


/*################################
###	获取回复可见内容
###	return array
###	2012年12月27日20:36:57
##################################*/
function yundanran_get_reply2view($str)
{
	preg_match_all("/(<!--回复可见：开始-->)(.*?)(<!--回复可见：结束-->)/sm",$str,$res);
	if($res[2])
	{
		$cont=array();
		foreach($res[2] as $key=>$value)
		{
			preg_match_all("/<(div class=['\"]reply2view-content['\"].*?)>(.*?)(<\/div>)/sm",$value,$res2);
			array_push($cont,'<div class="reply2view unlock"><i></i>'.$res2[2][0].'</div>');
		}
		return $cont;
	}
	else
	{
		return array('没有内容可以显示！');
	}
}




/*++++++++++++++++++++++++++++++
++	ajax获取回复可见的内容
++	2012年12月27日23:48:05
+++++++++++++++++++++++++++++++*/
add_action('init','_yundanran_get_reply2view_content');
function _yundanran_get_reply2view_content()
{
	if(isset($_POST['action']) && $_POST['action']=='_yundanran_get_reply2view_content')
	{
		$post_id=intval(stripslashes(strip_tags($_POST['post_id'])));
		$post=get_post($post_id);
		if($post)
		{
			$content=$post->post_content;
			$data=0;
			$info=yundanran_get_reply2view($content);
		}
		else
		{
			$data=-1;
			$info='错误：文章不存在！';
		}
		$json['data']=$data;
		$json['info']=$info;
		header("Content-Type: application/json");
		echo json_encode($json);
		exit;
	}
}






/*===========================================
===	给文章的外链加上nofollow
===	2012年11月23日20:32:58
============================================*/
add_filter('the_content','yundanran_the_content_nofollow',999);
function yundanran_the_content_nofollow($content)
{
	return preg_replace_callback('/<a([^>]+)(>[^>]+a>)/i','yundanran_the_content_nofollow_callback', $content);
}
function yundanran_the_content_nofollow_callback($matches)
{
	$begin	='<a';
	$link 	= $matches[1];
	$end	=$matches[2];
	$site_link = get_bloginfo('url');

	if (strpos($link, 'rel') === false)
	{
		$link = preg_replace("%(href=\S(?!$site_link))%i", 'rel="external nofollow" $1', $link);
	}
	return $begin.$link.$end;
}




/**********************************
	**	获取某分类下的文章
	**	用于文章存档页
	**	2012年9月20日22:29:29
*******************************/
function _yundanran_get_post_by_catid()
{
	if(isset($_POST['action']) && $_POST['action']=='_yundanran_get_post_by_catid')
	{
		$catid=intval(stripslashes(strip_tags($_POST['catid'])));
		if($catid>=0)
		{
			global $post;
			$args=array
			(
				'cat'=>$catid,
				'orderby'=>'date',
				'order'=>'desc',
				'post_status'=>'publish',
				'posts_per_page'=>-1,
			);
			query_posts($args);
			$i=0;
			if(have_posts())
			{
				$info='';
				while(have_posts()):the_post();
				$i++;
				$post_id 		=get_the_ID();
				$time			=yundanran_time_ago(strtotime(get_the_time('YmdHis',$post)));
				$link			=get_permalink();
				$comment_link	=$link.'#comments';
				$comment		=$post->comment_count;
				$title			=$post->post_title;
				$author_name 	=get_the_author();
				$views 			=yundanran_getPostViews($post_id);

				$info.='
				<li class="float">
					<div class="li li-'.$i.'">'.$i.'</div>
					<div class="info">
						<div class="line line-1 title"><span><a title="《'.$title.'》" href="'.$link.'">'.$title.'</a></span></div>
						<div class="line line-2 meta">
							<p class="author" title="文章作者：'.$author_name.'"><i></i><span>'.$author_name.'</span></p>
							<p class="time" title="发布时间：'.$time.'"><i></i><span>'.$time.'</span></p>
							<p class="view" title="浏览次数：'.$views.'"><i></i><span>'.$views.'</span></p>
							<p class="comment" title="评论条数：'.$comment.'"><a href="'.$comment_link.'"><i></i><span>'.$comment.'</span></a></p>
						</div>
					</div>
				</li>
				';
				endwhile;
			}
			else
			{
				$info='<li>该分类下没有任何文章！</li>';
			}
			wp_reset_query();
			$data=1;
		}
		else
		{
			$data=-1;
			$info='<li>AJAX参数不正确！</li>';
		}
	
		$json['data']=$data;
		$json['info']=$info;
		header("Content-Type: application/json");
		echo json_encode($json);
		exit;
	}
}
add_action('init','_yundanran_get_post_by_catid');




function _yundanran_get_post_by_time()
{
	if(isset($_POST['action']) && $_POST['action']=='_yundanran_get_post_by_time')
	{
		$year		=stripslashes($_POST['year']);
		$monthnum	=stripslashes($_POST['monthnum']);
		global $wpdb;
		global $post;
		$time1	=$year.'-'.$monthnum.'-01';
		$time2	=$year.'-'.$monthnum.'-31';
		$sql	="select ID from $wpdb->posts where post_date>=%s and post_date<=%s and post_status='publish' and post_type='post' order by post_date desc";
		$s		=$wpdb->get_results($wpdb->prepare($sql,$time1,$time2));
		$info	='';
		$i		=0;
		$data	=1;
		if(count($s)>0)
		{
			foreach($s as $key=>$value)
			{
				$post_ID		=$value->ID;
				$post			=get_post($post_ID);
				$i++;
				$time			=get_the_time('Y年m月d日 H:i:s',$post);
				$time_ago		=yundanran_time_ago(strtotime(get_the_time('YmdHis',$post)));
				$link			=get_permalink($post_ID);
				$comment_link	=$link.'#comments';
				$comment		=get_comments_number($post_ID);
				$title			=get_the_title($post_ID);
				$author_name 	=get_userdata($post->post_author)->display_name;
				$views 			=yundanran_getPostViews($post_ID);

				$info.='
				<li class="float">
					<div class="left li li-'.$i.'">'.$i.'</div>
					<div class="left info">
						<div class="line line-1 title"><span><a title="《'.$title.'》" href="'.$link.'">'.$title.'</a></span></div>
						<div class="line line-2 meta">
							<p class="author" title="文章作者：'.$author_name.'"><i></i><span>'.$author_name.'</span></p>
							<p class="time" title="发布时间：'.$time.'"><i></i><span>'.$time_ago.'</span></p>
							<p class="view" title="浏览次数：'.$views.'"><i></i><span>'.$views.'</span></p>
							<p class="comment" title="评论条数：'.$comment.'"><a href="'.$comment_link.'"><i></i><span>'.$comment.'</span></a></p>
						</div>
					</div>
				</li>
				';
			}
		}
		else
		{
			
			$info.='<li class="none">'.$_POST['year'].'年'.$_POST['monthnum'].'月没有发表过任何文章！</li>';
		}
		
		$json['data']=$data;
		$json['info']=$info;
		header("Content-Type: application/json");
		echo json_encode($json);
		exit;
	}
}
add_action('init','_yundanran_get_post_by_time');






/*
	文章摘要长度
*/
function yundanran_excerpt_length($length)
{
	return 500;
}
add_filter( 'excerpt_length', 'yundanran_excerpt_length',999);

/*
	自定义文章摘要更多字样
*/
function yundanran_excerpt_more($more)
{
	return '<span class="end">[...全文未完]</span>';
}
add_filter('excerpt_more', 'yundanran_excerpt_more',999);






/*************************************************************
	列出最新文章
	参数1:	数量
	输出文章列表id
	2012年4月25日21:59:17
*************************************************************/
function yundanran_last_article($limit)
{
	global $post;
	$limit=($limit=='' || !$limit)?10:$limit;
	$new_args=array
	(
		// 'tag__in'=>$post_tag_id,
		// 'category_in'=>$post_cat_id,
		// 'post__not_in'=>array($post_id),
		'orderby'=>'date',
		'order'=>'desc',
		'posts_per_page'=>$limit,
		'post_status'=>'publish',
	);
	query_posts($new_args);
	if(have_posts())
	{
		$out=array();
		$k=0;
		while(have_posts()):the_post();
			$post_id=$post->ID;
			$out[$k]['id']			=$post_id;
			$out[$k]['title']		=$post->post_title;
			$out[$k]['link']		=get_permalink();
			$out[$k]['comment']		=$post->comment_count;
			$out[$k]['time']		=get_the_time('Y年m月d日 H:i:s',$post);
			$out[$k]['time_ago']	=yundanran_time_ago(strtotime(get_the_time('YmdHis',$post)));
			$out[$k]['view']		=yundanran_getPostViews($post_id);
			$out[$k]['author']		='<a title="作者:'.get_the_author_link().'" href="'.get_author_posts_url($post->post_author,get_the_author_link()).'">'.get_the_author_link().'</a>';
			$k++;
		endwhile;
	}
	else
	{
		$out=null;
	}
	wp_reset_query();
	return $out;
}




add_action('init','_yundanran_relative_article');
function _yundanran_relative_article()
{
	if(isset($_POST['action']) && $_POST['action']=='_yundanran-relative-article')
	{
		$post_id=trim(stripslashes($_POST['post_id']));
		if(is_numeric($post_id))
		{
			$post_id=(int)$post_id;
			$article=yundanran_relative_article($post_id,10);
			$html='<ul class="rank-list">';
			if(is_array($article) && count($article)>=1)
			{
				foreach($article as $key => $value)
				{
					$i=$key+1;
					$comment_link=$value['link'].'#comments';
					$html.='
					<li class="float">
						<div class="li li-'.$i.'">'.$i.'</div>
						<div class="info">
							<div class="line line-1 title"><span><a title="《'.$value['title'].'》" href="'.$value['link'].'">'.$value['title'].'</a></span></div>
							<div class="line line-2 meta">
								<p class="time" title="发布时间：'.$value['time'].'"><i></i><span>'.$value['time_ago'].'</span></p>
								<p class="comment" title="评论条数：'.$value['comment'].'"><a href="'.$comment_link.'"><i></i><span>'.$value['comment'].'</span></a></p>
								<p class="item">('.$value['item'].')</p>
							</div>
						</div>
					</li>
					';
				}
			}
			else
			{
				$html.='
					<li style="padding-left:0;">
						<div style="padding:4px 10px;border-radius:4px;" class="alert no-article">这篇博文独一无二，没有检索到与之相关的任何其他内容！</div>
					</li>
				';
			}
			$html.='</ul>';
			$data=0;
		}
		else
		{
			$data=-1;
			$html='错误1：参数缺失！';
		}
		$json['data']=$data;
		$json['info']=$html;
		header("Content-Type: application/json");
		echo json_encode($json);
		exit;
	}
}



/**************************************************************
	列出相关文章
	参数1:	文章id
	参数2:	数量
	输出文章列表id
	2012年4月19日10:29:17
	2012年11月27日22:29:25
***************************************************************/
function yundanran_relative_article($post_id,$limit)
{
// global $post;
	$post_id		=($post_id=='' || !$post_id)?1:intval($post_id);
	
	$limit			=($limit=='' || !$limit)?10:intval($limit);
	
	$post_tag_id	=wp_get_post_tags($post_id,array('fields'=>'ids'));
	
	$cats			=get_the_category($post_id);
	$post_cat_id	=array();
	foreach($cats as $key=>$cat)
	{
		array_push($post_cat_id,$cat->cat_ID);
	}
	
	$post_format	=get_post_format($post_id)?get_post_format($post_id):'standard';
	if($post_format=='standard')
	{
		$format_array=array
		(
			'post-format-video',
			'post-format-image',
			'post-format-aside',
		);
		$arg=array
		(
			array
			(
				'taxonomy' => 'post_format',
				'field' => 'slug',
				'terms' => $format_array,
				'operator' => 'NOT IN'
			),
		);
	}
	else
	{
		$arg=array
		(
			array
			(
				'taxonomy' => 'post_format',
				'field' => 'slug',
				'terms' => array('post-format-'.$post_format),
				'operator' => 'IN'
			),
		);
	}	
	
	$post_author	=get_userdata(get_post($post_id)->post_author)->user_login;
	
	
	$k				=0;
	$exclude_id 	=array();
	$exclude_id[]	.=$post_id;
	$out			=array();
	
	// 优先根据文章的标签获取相关文章并且标签不为空
	if(count($post_tag_id)>0)
	{
		$args1=array
		(
			'tag__in'=>$post_tag_id,
			'post__not_in'=>array($post_id),
			'orderby'=>'comment_date',
			'order'=>'desc',
			'showposts'=>$limit,
			'post_status'=>'publish',
			'post_type'=>'post',
			'ignore_sticky_posts' => 1, // 排除置頂文章.
		);
		$args1['tax_query']=$arg;
		$the_query=new WP_Query($args1);
		if($the_query->have_posts())
		{
			while($the_query->have_posts()):$the_query->the_post();
				$post=$the_query->post;
				$out[$k]['id']			=$post->ID;
				$out[$k]['title']		=$post->post_title;
				$out[$k]['link']		=get_permalink();
				$out[$k]['comment']		=$post->comment_count;
				$out[$k]['time']		=get_the_time('Y年m月d日 H:i:s',$post);
				$out[$k]['time_ago']	=yundanran_time_ago(strtotime(get_the_time('YmdHis',$post)));
				$out[$k]['author']		='<a title="作者:'.get_the_author_link().'" href="'.get_author_posts_url($post->post_author,get_the_author_link()).'">'.get_the_author_link().'</a>';
				$out[$k]['item']		='有相同标签';
				$k++;
				$exclude_id[].=$post->ID;
			endwhile;
		}
		wp_reset_query();
		wp_reset_postdata();
	}
	
	// 如果序列小于总数量-1，并且分类不为空
	if($k<$limit-1 && count($post_cat_id)>0)
	{
		$args2=array
		(
			'post__not_in'=>$exclude_id,
			'category__in'=>$post_cat_id,
			'orderby'=>'comment_date',
			'order'=>'desc',
			'showposts'=>$limit-$k,
			'post_status'=>'publish',
			'post_type'=>'post',
			'ignore_sticky_posts' => 1, // 排除置頂文章.
		);
		$args2['tax_query']=$arg;
		$the_query=new WP_Query($args2);
		if($the_query->have_posts())
		{
			while($the_query->have_posts()):$the_query->the_post();
				$post=$the_query->post;
				$out[$k]['id']=$post->ID;
				$out[$k]['title']=$post->post_title;
				$out[$k]['link']=get_permalink();
				$out[$k]['comment']=$post->comment_count;
				$out[$k]['time']		=get_the_time('Y年m月d日 H:i:s',$post);
				$out[$k]['time_ago']	=yundanran_time_ago(strtotime(get_the_time('YmdHis',$post)));
				$out[$k]['author']='<a title="作者:'.get_the_author_link().'" href="'.get_author_posts_url($post->post_author,get_the_author_link()).'">'.get_the_author_link().'</a>';
				$out[$k]['item']='有相同分类';
				$k++;
				$exclude_id[].=$post->ID;
			endwhile;
		}
		wp_reset_query();
		wp_reset_postdata();
	}
	
	// 如果序列小于总数-1，根据作者来读取
	if($k<$limit-1)
	{
		$args3=array
		(
			'author_name' => $post_author,
			'post__not_in'=>$exclude_id,
			'orderby'=>'comment_date',
			'order'=>'desc',
			'showposts'=>$limit-$k,
			'post_status'=>'publish',
			'post_type'=>'post',
			'ignore_sticky_posts' => 1, // 排除置頂文章.
		);
		$args3['tax_query']=$arg;
		$the_query=new WP_Query($args3);
		if($the_query->have_posts())
		{
			while($the_query->have_posts()):$the_query->the_post();
				$post=$the_query->post;
				$out[$k]['id']=$post->ID;
				$out[$k]['title']=$post->post_title;
				$out[$k]['link']=get_permalink();
				$out[$k]['comment']=$post->comment_count;
				$out[$k]['time']		=get_the_time('Y年m月d日 H:i:s',$post);
				$out[$k]['time_ago']	=yundanran_time_ago(strtotime(get_the_time('YmdHis',$post)));
				$out[$k]['author']='<a title="作者:'.get_the_author_link().'" href="'.get_author_posts_url($post->post_author,get_the_author_link()).'">'.get_the_author_link().'</a>';
				$out[$k]['item']='有相同作者';
				$k++;
				$exclude_id[].=$post->ID;
			endwhile;
		}
		wp_reset_query();
		wp_reset_postdata();
	}
	
	// 如果以上条件仍然小于总数-1，则随机读取文章
	if($k<$limit-1)
	{
		$args4=array
		(
			'post__not_in'=>$exclude_id,
			'orderby'=>'rand',
			'showposts'=>$limit-$k,
			'post_status'=>'publish',
			'post_type'=>'post',
			'ignore_sticky_posts' => 1, // 排除置頂文章.
		);
		$args4['tax_query']=$arg;
		$the_query=new WP_Query($args4);
		if($the_query->have_posts())
		{
			while($the_query->have_posts()):$the_query->the_post();
				$post=$the_query->post;
				$out[$k]['id']=$post->ID;
				$out[$k]['title']=$post->post_title;
				$out[$k]['link']=get_permalink();
				$out[$k]['comment']=$post->comment_count;
				$out[$k]['time']		=get_the_time('Y年m月d日 H:i:s',$post);
				$out[$k]['time_ago']	=yundanran_time_ago(strtotime(get_the_time('YmdHis',$post)));
				$out[$k]['author']='<a title="作者:'.get_the_author_link().'" href="'.get_author_posts_url($post->post_author,get_the_author_link()).'">'.get_the_author_link().'</a>';
				$out[$k]['item']='随机文章';
				$k++;
				$exclude_id[].=$post->ID;
			endwhile;
		}
		wp_reset_query();
		wp_reset_postdata();
	}
	
	return $out;
}

/******************************************************************
	列出随机文章
	参数1:	数量
	输出文章列表id
	2012年4月25日21:59:17
*****************************************************************/
function yundanran_rand_article($limit)
{
	global $post;
	$limit=($limit=='' || !$limit)?10:$limit;
	$rand_args=array
	(
		// 'tag__in'=>$post_tag_id,
		// 'category_in'=>$post_cat_id,
		// 'post__not_in'=>array($post_id),
		'orderby'=>'rand',
		// 'order'=>'desc',
		'posts_per_page'=>$limit,
		'post_status'=>'publish',
		'post_password' => '',
	);
	query_posts($rand_args);
	if(have_posts())
	{
		$out=array();
		$k=0;
		while(have_posts()):the_post();
			$post_id=$post->ID;
			$out[$k]['id']			=$post_id;
			$out[$k]['title']		=$post->post_title;
			$out[$k]['link']		=get_permalink();
			$out[$k]['comment']		=$post->comment_count;
			$out[$k]['view']		=yundanran_getPostViews($post_id);
			$out[$k]['time']		=get_the_time('Y年m月d日 H:i:s',$post);
			$out[$k]['time_ago']	=yundanran_time_ago(strtotime(get_the_time('YmdHis',$post)));
			$out[$k]['author']		='<a title="作者:'.get_the_author_link().'" href="'.get_author_posts_url($post->post_author,get_the_author_link()).'">'.get_the_author_link().'</a>';
			$k++;
		endwhile;
	}
	else
	{
		$out=null;
	}
	wp_reset_query();
	return $out;
}


/*************************************************************
	**	查找热门文章
	**	查找规则【评论次数】
	**	2012年9月30日10:58:50
*************************************************************/
function yundanran_hot_article($limit)
{
	global $post;
	$limit=($limit=='' || !$limit)?10:$limit;
	$hot_args=array
	(
		// 'tag__in'=>$post_tag_id,
		// 'category_in'=>$post_cat_id,
		// 'post__not_in'=>array($post_id),
		'orderby'=>'comment_count',
		'order'=>'desc',
		'posts_per_page'=>$limit,
		'post_status'=>'publish',
		'post_password' => '',
	);
	query_posts($hot_args);
	if(have_posts())
	{
		$out=array();
		$k=0;
		while(have_posts()):the_post();
			$post_id=$post->ID;
			$out[$k]['id']			=$post_id;
			$out[$k]['title']		=$post->post_title;
			$out[$k]['link']		=get_permalink();
			$out[$k]['comment']		=$post->comment_count;
			$out[$k]['view']		=yundanran_getPostViews($post_id);
			$out[$k]['time']		=get_the_time('Y年m月d日 H:i:s',$post);
			$out[$k]['time_ago']	=yundanran_time_ago(strtotime(get_the_time('YmdHis',$post)));
			$out[$k]['author']		='<a title="作者:'.get_the_author_link().'" href="'.get_author_posts_url($post->post_author,get_the_author_link()).'">'.get_the_author_link().'</a>';
			$k++;
		endwhile;
	}
	else
	{
		$out=null;
	}
	wp_reset_query();
	return $out;	
}








//按长度排序
function tag_sort($a, $b)
{
	if ( $a->name == $b->name ) return 0;
	return ( strlen($a->name) > strlen($b->name) ) ? -1 : 1;
}

/****************************************************
	**	文章内容标签链接
	**	2012年9月30日10:54:06
****************************************************/
function yundanran_tag_link($content)
{
	//连接数量
	$match_num_from = 1;  //一个关键字少于多少不替换
	$match_num_to = 10; //一个关键字最多替换
	$posttags = get_the_tags();
	$ignore_pre=0;
	
	if ($posttags) 
	{
		usort($posttags, "tag_sort");
		foreach($posttags as $tag) 
		{
			$link = get_tag_link($tag->term_id);
			$keyword = $tag->name;
			$cleankeyword = stripslashes($keyword);
			$ex_word = preg_quote($cleankeyword,'\'');
			$case = "i";
			//连接代码
			$url = "<a href=\"$link\" title=\"".str_replace('%s',addcslashes($cleankeyword, '$'),'查看 “%s” 标签下的所有文章')."\"";
			$url .= ' class="tag_link"';
			$url .= "><strong>".addcslashes($cleankeyword, '$')."</strong></a>";
			$limit = rand($match_num_from,$match_num_to);

			//不连接的 代码
			$content = preg_replace( '|(<a[^>]+>)(.*)('.$ex_word.')(.*)(</a[^>]*>)|U'.$case, '$1$2%&&&&&%$4$5', $content);
			$content = preg_replace( '|(<img)(.*?)('.$ex_word.')(.*?)(>)|U'.$case, '$1$2%&&&&&%$4$5', $content);

			if( $num_pre = preg_match_all("/<pre.*?>.*?<\/pre>/is", $content,$ignore_pre) )
			{
				for($i=1;$i<=$num_pre;$i++)
				{
					$content = preg_replace( "/<pre.*?>.*?<\/pre>/is", "%ignore_pre_$i%", $content, 1);
				}
			}

			$content = preg_replace( '|(<pre[^>]+>)('.$ex_word.')(</pre[^>]*>)|U'.$case, '$1%&&&&&%$3', $content);
			$cleankeyword = preg_quote($cleankeyword,'\'');
			$regEx = '\'(?!((<.*?)|(<a.*?)))('. $cleankeyword . ')(?!(([^<>]*?)>)|([^>]*?</a>))\'s' . $case;
			$content = preg_replace($regEx,$url,$content,$limit);
			$content = str_replace( '%&&&&&%', stripslashes($ex_word), $content);

			if($ignore_pre)
			{
				for($i=1;$i<=$num_pre;$i++)
				{
					$content = str_replace( "%ignore_pre_$i%", $ignore_pre[0][$i-1], $content);
				}
			}

		}
	}
	return $content;
}
add_filter('the_content','yundanran_tag_link',1);



/*
	统计文章浏览次数
*/
function yundanran_getPostViews($postID)
{
	$count = get_post_meta($postID, YDR_POST_VIEWS_META, true);
	return $count?$count:1;
}
function yundanran_setPostViews($postID)
{
	$count = get_post_meta($postID, YDR_POST_VIEWS_META, true);
	$count?
	update_post_meta($postID, YDR_POST_VIEWS_META,++$count):
	add_post_meta($postID, YDR_POST_VIEWS_META, 1);
}
function yundanran_count_view()
{
	global $wpdb;
	$count=0;
	$sql="SELECT * FROM $wpdb->postmeta WHERE meta_key=%s";
	$views= $wpdb->get_results($wpdb->prepare($sql,YDR_POST_VIEWS_META));  //所有阅读次数
	foreach($views as $key=>$value)
	{
		$meta_value=$value->meta_value;
		if($meta_value!='')
		{
			$count+=(int)$meta_value;
		}
	}
	return $count;
}





/*======================================
==	获得post类型，中文
==	2012年11月20日23:32:02
=======================================*/
function yundanran_get_post_format($post_ID)
{
	if(!is_numeric($post_ID))return false;
	
	$post = get_post($post_ID);
	
	if(!$post)return false;
	
	$post_format=get_post_format($post_ID);

	// 'aside','image','video'
	if($post_format=='aside')
	{
		$format='碎碎念';
	}
	else if($post_format=='image')
	{
		$format='图片集';
	}
	else if($post_format=='gallery')
	{
		$format='相册';
	}
	else if($post_format=='video')
	{
		$format='视频';
	}
	else
	{
		$format='博文';
	}
	return $format;
}