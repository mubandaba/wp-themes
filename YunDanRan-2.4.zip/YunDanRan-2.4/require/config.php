<?php

require_once(TEMPLATEPATH.'/options/options-framework.php');		//设置

// 主题设置文件夹
define( 'OPTIONS_FRAMEWORK_URL', get_template_directory_uri() . '/options/' );

add_action('admin_menu', 'yundanran_admin_menu_help');
function yundanran_admin_menu_help()
{
	add_theme_page('主题帮助手册','主题帮助手册', 'edit_theme_options', 'theme-help','yundanran_theme_help');
}
function yundanran_theme_help()
{
	require_once(TEMPLATEPATH.'/options/help.php');
}

add_action('admin_menu', 'yundanran_admin_menu_feedback');
function yundanran_admin_menu_feedback()
{
	add_theme_page('主题使用反馈','主题使用反馈', 'edit_theme_options', 'theme-feedback','yundanran_theme_feedback');
}
function yundanran_theme_feedback()
{
	require_once(TEMPLATEPATH.'/options/feedback.php');
}


add_action('admin_menu', 'yundanran_admin_menu_import');
function yundanran_admin_menu_import()
{
	add_theme_page('导入插件数据','导入插件数据', 'edit_theme_options', 'theme-import','yundanran_theme_import');
}
function yundanran_theme_import()
{
	require_once(TEMPLATEPATH.'/options/import.php');
}

#############################################################################################################
						######	主题配置文件，请勿更改	########
						######	2012年11月11日12:56:09	########
						######	by 云淡然				########
#############################################################################################################


// 主题反馈地址
define( 'YUNDANRAN2_FEEDBACK_URL', 'http://qianduanblog.com/feedback/yundanran-2.php' );

// 主题反馈浏览的文章
define( 'YUNDANRAN2_FEEDBACK_POST', 'http://qianduanblog.com/?p=1656#comments' );

########################################## tab-1 ##############################################

// 管理员id
define('YDR_ADMIN_ID',of_get_option('ydr_admin_id',1));

// 博客名称
define('YDR_BLOG_NAME',of_get_option('ydr_blog_name',get_bloginfo('name')));

// 博客关键字
define('YDR_BLOG_KEY',of_get_option('ydr_blog_key','淡然，云淡然，前端开发，WEB前端，HTML，CSS，HTML5，CSS3，javascript，jQuery，PHP，ThinkPHP，Wordpress'));

// 博客描述
define('YDR_BLOG_DESC',of_get_option('ydr_blog_desc',get_bloginfo('description')));

// 博客独立域名
define('YDR_DOMAIN',of_get_option('ydr_domain','qianduanblog.com'));

// 网站服务器
define('YDR_HOST',of_get_option('ydr_host','localhost'));

// 博客统计
define('YDR_BLOG_TOGNJI',of_get_option('ydr_blog_tongji',''));

// 新浪微博url
define('YDR_WEIBO_URL',of_get_option('ydr_weibo_url','http://weibo.com/cloudcome'));

// 腾讯微博url
define('YDR_QQT_URL',of_get_option('ydr_qqt_url','http://t.qq.com/cloudcome'));

// 联系QQurl
define('YDR_QQ_URL',of_get_option('ydr_qq_url','http://sighttp.qq.com/authd?IDKEY=618c91aa764179287f3e3aa428e40dcdd6e3c3cd5cce99a1'));

// 缩略图的txt路径
define('YDR_THUMBNAIL_PATH',TEMPLATEPATH.'/require/thumbnail.txt');

// 壁纸txt路径
define('YDR_WALLPAPER_PATH',TEMPLATEPATH.'/require/wallpaper.txt');





########################################## tab-2 ##############################################



// 博客静态背景
define('YDR_BLOG_BACKGROUND',of_get_option('ydr_blog_background',get_bloginfo('template_url').'/public/image/fullbody.png'));







########################################## tab-2 ##############################################
// 博客谷歌自定义搜索页面
$ydr_google_page=of_get_option('ydr_google_page');
define('YDR_GOOGLE_PAGE',$ydr_google_page?get_permalink($ydr_google_page):get_bloginfo('url'));

// 博客谷歌自定义搜索脚本
define('YDR_GOOGLE_SEARCH',of_get_option('ydr_google_search',''));

// 所有标签页的url
$ydr_tag_page=of_get_option('ydr_tag_page');
define('YDR_TAG_URL',$ydr_tag_page?get_permalink($ydr_tag_page):get_bloginfo('url'));

// 是否开启wap样式的主题
define('YDR_WAP',of_get_option('ydr_wap',0));





########################################## tab-2 ##############################################
// 是否开启头像缓存
define('YDR_AVATAR_CACHE',of_get_option('ydr_avatar_cache',true)?1:0);


// 是否开启主机发送邮件
define('YDR_EMAIL',of_get_option('ydr_email',true)?1:0);

// 邮件发送地址
// admin@yundanran.com
$admin=get_userdata(YDR_ADMIN_ID);
define('YDR_MAIL_FROM',of_get_option('ydr_mail_from',$admin->user_email));

// 邮件发送名称
define('YDR_MAIL_NAME',of_get_option('ydr_mail_name',get_bloginfo('name')));

// 评论要求中文
define('YDR_WORD_LIMIT',of_get_option('ydr_word_limit',true)?1:0);

// 评论要求最少字数
define('YDR_MIN_WORD_LIMIT',of_get_option('ydr_min_word_limit',10));

// 评论要求最多字数
define('YDR_MAX_WORD_LIMIT',of_get_option('ydr_max_word_limit',140));

// qq表情的url
define('YDR_FACE_URL',get_bloginfo('template_url').'/public/image/face/');

// 浏览器标识url
define('YDR_BROWSER_URL',get_bloginfo('template_url').'/public/image/browser/');

// 国家标识url
define('YDR_COUNTRY_URL',get_bloginfo('template_url').'/public/image/country/');




########################################## tab-3 ##############################################
// 简单统计阅读次数的的meta字段
// 为了兼容，这里去除定义设置功能
define('YDR_POST_VIEWS_META','yundanran_post_views_count');


// 是否启用文章内图片延时载入。
define('YDR_IMAGE_LAZY',of_get_option('ydr_image_lazy',true)?1:0);
define('YDR_IMAGE_REPLACE',of_get_option('ydr_image_replace',get_bloginfo('template_url').'/public/image/loving.gif'));



########################################## tab-4 ##############################################



########################################## tab-5 ##############################################
// 通知内容
define('YDR_NOTICE_ID',of_get_option('ydr_notice_id',''));

// 通知内容
define('YDR_NOTICE_CONTENT',of_get_option('ydr_notice_content',''));

// 通知期限
define('YDR_NOTICE_DATE',of_get_option('ydr_notice_date','2013-1-1'));



#############################################################################################################
#############################################################################################################