<?php

// sidebar page，just for yundanran-2
// edit by yundanran
// cloudcome@163.com
// 2012年8月18日15:14:38


function _yundanran_last_article()
{
	if(isset($_POST['action']) && $_POST['action']=='_yundanran-last-article')
	{
		$num=(isset($_POST['num']) && $_POST['num']!='' && is_numeric($_POST['num']))?
		(int)$_POST['num']:10;
		
		$article=yundanran_last_article($num);
		
		$html='<ul>';
		foreach ($article as $key => $value)
		{
			$i=$key+1;
			$comment_link=$value['link'].'#comments';
			$html.='
			<li class="float">
			<div class="li li-'.$i.'">'.$i.'</div>
			<div class="info">
				<div class="line line-1 title"><span><a title="《'.$value['title'].'》" href="'.$value['link'].'">'.$value['title'].'</a></span></div>
				<div class="line line-2 meta">
					<p class="time" title="发布时间：'.$value['time'].'"><i></i><span>'.$value['time_ago'].'</span></p>
					<p class="comment" title="评论条数：'.$value['comment'].'"><a href="'.$comment_link.'"><i></i><span>'.$value['comment'].'</span></a></p>
				</div>
			</div>
			</li>
			';
		}
		$html.='</ul>';

		$json['data']=$data=0;
		$json['info']=$html;
		header("Content-Type: application/json");
		echo json_encode($json);
		exit;
	}
}
add_action('init','_yundanran_last_article');




function _yundanran_hot_article()
{
	if(isset($_POST['action']) && $_POST['action']=='_yundanran-hot-article')
	{
		$num=(isset($_POST['num']) && $_POST['num']!='')?
		(int)$_POST['num']:
		$num=10;
		$article=yundanran_hot_article($num);
		
		$html='<ul>';
		foreach ($article as $key => $value)
		{
			$i=$key+1;
			$comment_link=$value['link'].'#comments';
			$html.='
			<li class="float">
			<div class="li li-'.$i.'">'.$i.'</div>
			<div class="info">
				<div class="line line-1 title"><span><a title="《'.$value['title'].'》" href="'.$value['link'].'">'.$value['title'].'</a></span></div>
				<div class="line line-2 meta">
					<p class="time" title="发布时间：'.$value['time'].'"><i></i><span>'.$value['time_ago'].'</span></p>
					<p class="comment" title="评论条数：'.$value['comment'].'"><a href="'.$comment_link.'"><i></i><span>'.$value['comment'].'</span></a></p>
				</div>
			</div>
			</li>
			';
		}
		$html.='</ul>';

		$json['data']=$data=0;
		$json['info']=$html;
		header("Content-Type: application/json");
		echo json_encode($json);
		exit;
	}	
}
add_action('init','_yundanran_hot_article');




function _yundanran_rand_article()
{
	if(isset($_POST['action']) && $_POST['action']=='_yundanran-rand-article')
	{
		$num=(isset($_POST['num']) && $_POST['num']!='')?
		(int)$_POST['num']:
		$num=10;
		$article=yundanran_rand_article($num);
		
		$html='<ul>';
		foreach ($article as $key => $value)
		{
			$i=$key+1;
			$comment_link=$value['link'].'#comments';
			$html.='
			<li class="float">
			<div class="li li-'.$i.'">'.$i.'</div>
			<div class="info">
				<div class="line line-1 title"><span><a title="《'.$value['title'].'》" href="'.$value['link'].'">'.$value['title'].'</a></span></div>
				<div class="line line-2 meta">
					<p class="time" title="发布时间：'.$value['time'].'"><i></i><span>'.$value['time_ago'].'</span></p>
					<p class="comment" title="评论条数：'.$value['comment'].'"><a href="'.$comment_link.'"><i></i><span>'.$value['comment'].'</span></a></p>
				</div>
			</div>
			</li>
			';
		}
		$html.='</ul>';

		$json['data']=$data=0;
		$json['info']=$html;
		header("Content-Type: application/json");
		echo json_encode($json);
		exit;
	}	
}
add_action('init','_yundanran_rand_article');



function _yundanran_last_comment()
{
	if(isset($_POST['action']) && $_POST['action']=='_yundanran-last-comment')
	{
		$num=(isset($_POST['num']) && $_POST['num']!='' && is_numeric($_POST['num']))?
		(int)$_POST['num']:10;
		
		$id=(isset($_POST['id']) && $_POST['id']!='' && is_numeric($_POST['id']))?
		(int)$_POST['id']:0;

		$last=yundanran_last_comments($num,false,$id);
		
		if(is_user_logged_in())
		{
			global $current_user;
			get_currentuserinfo();
			$user_id 			=$current_user->ID;
			$is_admin=$user_id==YDR_ADMIN_ID?1:0;
		}
		else
		{
			$is_admin=0;
		}
		
		$html='<ul>';
		if(count($last)>0)
		{
			foreach ($last as $key => $value)
			{
				$i=$key+1;
				$comment_link=$value['link'];
				$approved=$value['approved']==1?
				'
				<span title="已通过审核" class="approved-true"></span>
				<a title="删除评论！" href="#" class="approved-delete"></a>
				':
				'
				<a title="通过审核" href="#" class="approved-pass"></a>
				<a title="不通过审核" href="#" class="approved-nopass"></a>
				<a title="删除评论！" href="#" class="approved-delete"></a>
				';
				$approved_txt=$is_admin?
				'<p class="approved">'.$approved.'</p>':
				'';
				$cls=$value['approved']==1?'':' approved';
				$html.='
				<li class="float'.$cls.'" data-id="'.$value['id'].'">
					<div class="li" title="'.$value['display_name'].'">'.yundanran_avatar_cache(get_avatar($value['email'],20)).'</div>
					<div class="info">
						<div class="line line-1 title"><span title="'.yundanran_substr_cn(stripslashes(strip_tags($value['content'])),0,140).'">'.$value['content'].'</span></div>
						<div class="line line-2 meta">
							<p class="time" title="评论/回复时间：'.$value['time'].'"><i></i><span>'.$value['time_ago'].'</span></p>
							<p class="comment" title="回复数量：'.$value['hot'].'"><a href="'.$comment_link.'"><i></i><span>'.$value['hot'].'</span></a></p>
							'.$approved_txt.'
						</div>
					</div>
				</li>
				';
			}
		}
		else
		{
			$html.='<li>最近暂无评论。</li>';
		}
		$html.='</ul><script>$(function(){image_fail_reload()});</script>';

		$json['data']=count($last);
		$json['info']=$html;
		header("Content-Type: application/json");
		echo json_encode($json);
		exit;
	}	
}
add_action('init','_yundanran_last_comment');



function _yundanran_hot_comment()
{
	if(isset($_POST['action']) && $_POST['action']=='_yundanran-hot-comment')
	{
		$num=(isset($_POST['num']) && $_POST['num']!='')?
		(int)$_POST['num']:
		$num=10;
		$article=yundanran_get_hot_comment($num);
		
		$html='<ul>';
		foreach ($article as $key => $value)
		{
			$i=$key+1;
			$comment_link=$value['link'];
			$html.='
			<li class="float">
				<div class="li">'.yundanran_avatar_cache(get_avatar($value['email'],20)).'</div>
				<div class="info">
					<div class="line line-1 title"><span title="'.yundanran_substr_cn(stripslashes(strip_tags($value['content'])),0,140).'">'.$value['content'].'</span></div>
					<div class="line line-2 meta">
						<p class="time" title="评论时间：'.$value['time'].'"><i></i><span>'.$value['time_ago'].'</span></p>
						<p class="comment" title="回复数量：'.$value['comment'].'"><a href="'.$comment_link.'"><i></i><span>'.$value['comment'].'</span></a></p>
					</div>
				</div>
			</li>
			';
		}
		$html.='</ul><script>$(function(){image_fail_reload()});</script>';

		$json['data']=$data=0;
		$json['info']=$html;
		header("Content-Type: application/json");
		echo json_encode($json);
		exit;
	}	
}
add_action('init','_yundanran_hot_comment');



function _yundanran_all_cat()
{
	if(isset($_POST['action']) && $_POST['action']=='_yundanran-all-cat')
	{
		//depth=0&title_li=&orderby=id&show_count=1&hide_empty=0&child_of=0
		$args = array
		(
			// 'show_option_all'    => '',
			'orderby'            => 'name',
			'order'              => 'ASC',
			// 'style'              => 'list',
			'show_count'         => 1,
			'hide_empty'         => 0,
			// 'use_desc_for_title' => 1,
			'child_of'           => 0,
			// 'feed'               => '',
			// 'feed_type'          => '',
			// 'feed_image'         => '',
			// 'exclude'            => '',
			// 'exclude_tree'       => '',
			// 'include'            => '',
			// 'hierarchical'       => true,
			'title_li'           => '',
			// 'show_option_none'   => __('No categories'),
			// 'number'             => null,
			'depth'              => 0,
			// 'current_category'   => 0,
			// 'pad_counts'         => 0,
			// 'taxonomy'           => 'category',
			// 'walker'             => 'Walker_Category'
			'echo'               => 0
		);
		$html='<ul class="side-category">';
		$html.=wp_list_categories($args);
		$html.='</ul>';
		
		$json['data']=$data=0;
		$json['info']=$html;
		header("Content-Type: application/json");
		echo json_encode($json);
		exit;
	}	
}
add_action('init','_yundanran_all_cat');



function _yundanran_all_tag()
{
	if(isset($_POST['action']) && $_POST['action']=='_yundanran-all-tag')
	{
		$args=array
		(
			'number' => 20,
			'orderby' => 'count',
			'order' => 'DESC',
			'hide_empty' => true
		);
		$tags=get_tags($args);

		$html="<ul class='all-tag'>";
		foreach($tags as $tag)
		{
			$link = get_tag_link($tag->term_id);
			$name=$tag->name;
			$name_attr=esc_attr(strip_tags($name));
			$count=$tag->count;
			$html.="
			<li>
				<a href='{$link}' title='标签：{$name_attr}'>{$name}</a>×<span class='num'>{$count}</span>
			</li>\n";
		}
		$html.="
		<li class='more'><a title='所有标签' href='".YDR_TAG_URL."'>所有标签»</a></li>
		</ul>";

		$json['data']=0;
		$json['info']=$html;
		header("Content-Type: application/json");
		echo json_encode($json);
		exit;
	}	
}
add_action('init','_yundanran_all_tag');




function _yundanran_all_archive()
{
	if(isset($_POST['action']) && $_POST['action']=='_yundanran-all-archive')
	{
		$args = array
		(
			'type'            => 'monthly',
			'limit'           => '',
			'format'          => 'html', 
			'before'          => '',
			'after'           => '',
			'show_post_count' => 1,
			'echo'            => 0
    	); 

		$html='<ul class="all-archive">';
		$html.=wp_get_archives($args);
		$html.='</ul>';

		$json['data']=$data=0;
		$json['info']=$html;
		header("Content-Type: application/json");
		echo json_encode($json);
		exit;
	}	
}
add_action('init','_yundanran_all_archive');




function _yundanran_friend_link()
{
	if(isset($_POST['action']) && $_POST['action']=='_yundanran-friend-link')
	{
		$args=array
		(
			'orderby'          => 'name',
			'order'            => 'ASC',
			'limit'            => -1,
			'category'         => '',
			'exclude_category' => '',
			'category_name'    => '',
			'hide_invisible'   => 1,
			'show_updated'     => 0,
			'categorize'       => 1,
			'title_li'         => '',
			'category_orderby' => 'name',
			'category_order'   => 'ASC',
			'class'            => 'linkcat',
			'category_before'  => '<li class="linkcat">',
			'category_after'  	=> '</li>',
    		'title_before'		=>'<p class="cat">',
			'title_after'		=>'</p>',
			'link_before'		=>'',
			'link_after'		=>'',
			'show_images'		=>1,
			'show_name'			=>1,
			'fav_url'			=>'http://g.etfv.co/',
			'echo'				=>0
		);
		$html='<ul class="friend-link">';
		$html.=yundanran_list_bookmarks($args);
		$html.='</ul><script>$(function(){image_fail_reload()});</script>';

		$json['data']=$data;
		$json['info']=$html;
		header("Content-Type: application/json");
		echo json_encode($json);
		exit;
	}	
}
add_action('init','_yundanran_friend_link');







function _yundanran_count_blog()
{
	if(isset($_POST['action']) && $_POST['action']=='_yundanran-count-blog')
	{
		global $wpdb;
		$start=yundanran_get_firstpostdate();
		$end=get_lastpostdate();
		$live 				=floor((time()-strtotime($start))/86400);
		$post 				=wp_count_posts()->publish;
		$comment 			=$wpdb->get_var("SELECT COUNT(comment_ID) FROM $wpdb->comments WHERE comment_approved = '1'");
		$view 				=yundanran_count_view();
		$cat 				=wp_count_terms('category');
		$tag 				=wp_count_terms('post_tag');
		$page 				=wp_count_posts('page')->publish;
		$user 				=yundanran_count_user();
		$link 				=$wpdb->get_var("SELECT COUNT(link_id) FROM $wpdb->links WHERE link_visible = 'Y'");

		$html='
		<ul class="count-blog">
			<li><strong>最后更新</strong><span>'.$end.'</span></li>
			<li><strong>博客存活</strong><span>'.$live.'天</span></li>
			<li><strong>发布文章</strong><span>'.$post.'篇</span></li>
			<li><strong>留下评论</strong><span>'.$comment.'条</span></li>
			<li><strong>总共阅读</strong><span>'.$view.'回</span></li>
			<li><strong>分类总数</strong><span>'.$cat.'项</span></li>
			<li><strong>标签总数</strong><span>'.$tag.'个</span></li>
			<li><strong>页面总数</strong><span>'.$page.'页</span></li>
			<li><strong>注册用户</strong><span>'.$user.'人</span></li>
			<li><strong>友链总数</strong><span>'.$link.'目</span></li>
		</ul>
		';
		$json['data']=$data=0;
		$json['info']=$html;
		header("Content-Type: application/json");
		echo json_encode($json);
		exit;
	}	
}
add_action('init','_yundanran_count_blog');