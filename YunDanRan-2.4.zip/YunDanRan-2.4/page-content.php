<!-- 正文 -->
<?php if (have_posts()) : the_post(); update_post_caches($posts);
	$post_id 		=get_the_ID();
	$title 			=get_the_title();
	$link 			=get_permalink();
	$author_name 	=get_the_author();
	$time 			=yundanran_time_ago(strtotime(get_the_time('YmdHis',$post)));
	$views 			=yundanran_getPostViews($post_id);yundanran_setPostViews(get_the_ID());
	$comments_link	=get_comments_link();
	$comments_num 	=get_comments_number();
	$summary 		=yundanran_content_summary(get_the_excerpt(),300,'<span class="end">[...全文未完]</span>');
?>
<article class="article page-article single-article">
	<div class="wrap">
		<h2 class="title"><span><strong><?=$title?></strong></span></h2>
		<div class="meta">
			<p class="author" title="文章作者：<?=$author_name?>"><i></i><span><?php the_author_posts_link();?><?php edit_post_link('(再编辑&raquo;)', '', ''); ?></span></p>
			<p class="time" title="发布时间：<?=$time?>"><i></i><span><?=$time?></span></p>
			<p class="view" title="浏览次数：<?=$views?>"><i></i><span><?=$views?></span></p>
			<p class="comment" title="评论条数：<?=$comments_num?>"><a href="<?=$comments_link?>" title="评论这篇文章"><i></i><span><?=$comments_num?></span></a></p>
			<p class="copy" title="复制文章标题、链接" data-title="<?=$title?>" data-link="<?=$link?>"><i></i><span>复制</span></p>
		</div>
		<div class="clear"></div>
		<div class="body">
			<div class="text"><?=the_content();?></div>
		</div>
		<div class="clear"></div>
		<div class="meta">
			<a class="share share-sina" title="分享到新浪微博" data-title="<?=$title?>" data-link="<?=$link?>" data-summary=""></a>
			<a class="share share-qqt" title="分享到腾讯微博" data-title="<?=$title?>" data-link="<?=$link?>" data-summary=""></a>
			<a class="share share-qqz" title="分享到QQ空间" data-title="<?=$title?>" data-link="<?=$link?>" data-summary=""></a>
		</div>
		<div class="message">这里显示消息的内容！</div>
	</div>
	<div class="bg1"></div>
	<div class="bg2"></div>
</article>
<?php else:
	$post_id 		=-1;
	$title 			='这是一篇无法显示的文章。';
	$link 			=get_bloginfo('url');
	$author_name 	='佚名';
	$time 			='上古时代';
	$views 			=yundanran_getPostViews($post_id);
	$comments_link	=get_bloginfo('url');
	$comments_num 	=-1;
	$summary 		='';
?>

<article class="article single-article">
	<div class="wrap">
		<h2 class="title"><span><a href="<?=$link?>" title="《<?=$title?>》"><?=$title?></a></span></h2>
		<div class="meta">
			<p class="author" title="文章作者：<?=$author_name?>"><i></i><span><?php the_author_posts_link();?><?php edit_post_link('(再编辑&raquo;)', '', ''); ?></span></p>
			<p class="time" title="发布时间：<?=$time?>"><i></i><span><?=$time?></span></p>
			<p class="view" title="浏览次数：<?=$views?>"><i></i><span><?=$views?></span></p>
			<p class="comment" title="评论条数：<?=$comments_num?>"><i></i><a href="<?=$comments_link?>" title="评论这篇文章"><span><?=$comments_num?></span></a></p>
			<p class="copy" title="复制文章标题、链接" data-title="<?=$title?>" data-link="<?=$link?>"><i></i><span></span></p>
		</div>
		<div class="clear"></div>
		<div class="body ">
			<div class=" text">
				<p>这是一篇无法显示的文章。</p>
				<p>可能原因是：</p>
				<ul>
					<li>文章没有被发表；</li>
					<li>文章被设置为隐私；</li>
					<li>文章已被删除；</li>
					<li>文章不存在；</li>
					<li>其他原因。</li>
				</ul>
				<p><a href="http://mail.163.com/share/mail2me.htm#email=099108111117100099111109101064049054051046099111109" target="_blank" title="给博主发送邮件说明情况">给博主发送邮件说明情况</a></p>
				<span class="end">[全文完]</span>
			</div>
		</div>
		<div class="clear"></div>
		<div class="meta">
			<p class="cat" title="文章所在分类"><i></i><span><?php the_category(' , ');?></span></p>
			<p class="tag" title="文章所有标签"><i></i><span><?php the_tags('',' , ',''); ?></span></p>
			<p class="share share-sina" title="分享到新浪微博" data-title="<?=$title?>" data-link="<?=$link?>" data-summary=""><i></i><span></span></p>
			<p class="share share-qqt" title="分享到腾讯微博" data-title="<?=$title?>" data-link="<?=$link?>" data-summary=""><i></i><span></span></p>
			<p class="share share-qqz" title="分享到QQ空间" data-title="<?=$title?>" data-link="<?=$link?>" data-summary=""><i></i><span></span></p>
		</div>
	</div>
	<div class="bg1"></div>
	<div class="bg2"></div>
</article>	
<?php endif; ?>
<!-- 正文 -->