<?php
/*
Template Name:3=谷歌自定义搜索
*/
$GLOBALS['yundanran_onlypage']=1;
?>
<?php get_header(); ?>
<!-- Put the following javascript before the closing </head> tag. -->
<?=YDR_GOOGLE_SEARCH?>
<div id="BODY" class="layout main google-search">
	<gcse:search></gcse:search>
</div>
<?php get_footer(); ?>