<?php
/*
	Template Name:0=关于云淡然
*/
// <!-- 获取选项 --> 
?>  
<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8" />
<title>关于“云淡然”</title>
<link rel="stylesheet" href="<?=bloginfo('template_url')?>/public/style/diy-aboutme.css?v=2012-11-2 23:28:10" type="text/css" media="screen" />
<script type="text/javascript" src="http://lib.sinaapp.com/js/jquery/1.8/jquery.min.js"></script>
<script type="text/javascript" src="<?=bloginfo('template_url')?>/public/script/diy-aboutme.js?v=2012-6-10 22:36:07"></script>
<!--[if lt IE 9]>
	<script src="<?php bloginfo('template_url'); ?>/public/script/ie-html5.js"></script>
<![endif]-->
</head>
<body>

<div id="wrapper">
	<header>
		<h1>张**（云淡然）的个人简历</h1>
		<div id="back" title="返回封面"></div>
	</header>
	<div id="body">
	
		<section id="cover"><!--//封面-->
			<ul>
				<li><strong>姓名</strong><span>张**（云淡然）</span></li>
				<li><strong>联系</strong><span>188'****'****</span></li>
				<li><strong>职位</strong><span>前端开发</span></li>
			</ul>
			<div id="open" title="打开下一页"></div>
		</section>
		
		<section id="content"><!--//内页-->
			<div id="tab">
				<ul class="tab-nav">
					<li>个人简介</li>
					<li>成长历程</li>
					<li>开发项目</li>
					<li>未来展望</li>
				</ul>
				<div class="tab-content">
					<div class="content content-0">
						<ul>
							<li><strong>姓名</strong><span>张**</span></li>
							<li><strong>年龄</strong><span>25</span></li>
							<li><strong>籍贯</strong><span>皖黄山市</span></li>
							<li><strong>户口</strong><span>皖黄山市</span></li>
							<li><strong>地址</strong><span>浙杭州市</span></li>
							<li><strong>性别</strong><span>男</span></li>
							<li><strong>民族</strong><span>汉族</span></li>
							<li><strong>身高</strong><span>171CM</span></li>
							<li><strong>健康</strong><span>健康</span></li>
							<li><strong>体重</strong><span>50KG</span></li>
							<li><strong>学历</strong><span>本科</span></li>
							<li><strong>毕业</strong><span>安徽理工大学</span></li>
							<li><strong>技能</strong><span>HTML、XHTML、javascript、CSS、jQuery、PHP、ThinkPHP、Mysql、HTML5、CSS3、photoshop、dreamweaver等</span></li>
						</ul>
					</div>
					<div class="content content-1">
						<ul>
							<li><strong>2012.6-今</strong><span>阅读《Javascript权威指南》中……</span></li>
							<li><strong>2012.4-2012.5</strong><span>专注前端开发，开始学习HTML5和CSS3</span></li>
							<li><strong>2012.3-2012.4</strong><span>开始制作<a href="http://yundanran.com/" target="_blank">第二个网站</a></span></li>
							<li><strong>2012.2-2012.3</strong><span>继续学习jQuery及AJAX</span></li>
							<li><strong>2012.1-2012.2</strong><span>看完《jQuery权威指南》</span></li>
							<li><strong>2011.11-2011.12</strong><span>开始学习Sina App Engine</span></li>
							<li><strong>2011.10-2011.11</strong><span>开始学习PHP和ThinkPHP，开始制作<a href="http://imyun.sinaapp.com/" target="_blank">第一个网站</a></span></li>
							<li><strong>2011.9-2011.10</strong><span>开始学习javascript和jQuery</span></li>
							<li><strong>2011.8-2011.9</strong><span>开始学习CSS</span></li>
							<li><strong>2011.7-2011.8</strong><span>开始学习HTML</span></li>
							<li><strong>2011.7</strong><span>成为一名苦逼的毕业生</span></li>
						</ul>						
					</div>
					<div class="content content-2">
						<ul>
							<li><strong>亿商机械网</strong><span>亿商机械网前台页面设计及编写，目前正在开发阶段。</span></li>
							<li><strong>亿商网</strong><span>新版亿商网前台页面设计及编写，目前正在测试阶段。</span></li>
							<li><strong>个人博客</strong><span><a href="http://yundanran.com/" target="_blank">http://yundanran.com/</a>——基于Wordpress开源程序的二次开发，改动的部分包含大量的AJAX运用、第三方登录、用户体验等。</span></li>
							<li><strong>个人网站</strong><span>http://imyun.sinaapp.com（已删除）——基于ThinkPHP开源框架的二次开发，新增的部分非常多，涉及面非常广，包括后台数据库的操作和前台人机交互等等方面，因工作量比较大，目前已停止开发。</span></li>
							<li><strong>淘宝SDK模板</strong><span>杭州御美工坊电子商务公司开发的高级SDK模板，基于淘宝高级SDK平台，开发PHP环境下的div+CSS项目。（<a href="http://zx.taobao.com/designer_detail.htm?designerId=37365" target="_blank">点击了解详情</a>）</span></li>
						</ul>												
					</div>
					<div class="content content-3">
						<ul>
							<li><strong>职业方向</strong><span>前端开发，包括前台页面的构造、表现、用户体验、兼容、性能、交互等方面。</span></li>
						</ul>																		
					</div>
				</div>
			</div>
			<div id="up" title="返回上一层"></div>
		</section>		
	</div>
	<footer><a class="index" href="<?=get_bloginfo('url')?>" title="回到主页"></a>&copy;2012</footer>
</div>

</body>
</html>