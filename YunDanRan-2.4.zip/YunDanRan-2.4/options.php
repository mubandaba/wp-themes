<?php

// add_action( 'admin_notices', 'yundanran_admin_notices' ); //升级提示
// function yundanran_admin_notices() 
// {
	// $version=@fopen("http://yundanran.com/version.php","r");
	// $ver=@fgets($version);
	// @fclose($version);
	// $my_theme = wp_get_theme();
	// $lin=$my_theme->Version;
	// if($lin<$ver)
	// {
		// echo "
		// <div style='top:5px;position:absolute;width:400px;left:50%;margin-left:-200px;background-color:#FFF2F3;border-radius: 3px;border:2px solid #FF8B8B;color:#FF6969;padding:4px 10px;box-shadow:0px 0px 4px #FF0202;z-index:2;'>
			// <p style='margin:0;'>当前主题版本为：".$lin."，发现主题新版本号为：".trim($ver)."，请立即更新！</p>
		// </div>
		// ";
	// }
// }

// 上传图片路径
$imagepath =  get_template_directory_uri() . '/options/upload/';

function optionsframework_options()
{
	// 所有分类
	$options_categories = array();

	$cat_args=array
	(
		'type'                     => 'post',
		'child_of'                 => 0,
		'parent'                   => '',
		'orderby'                  => 'id',
		'order'                    => 'ASC',
		'hide_empty'               => 0,
		'hierarchical'             => 0,
		'exclude'                  => '',
		'include'                  => '',
		'number'                   => '',
		'taxonomy'                 => 'category',
		'pad_counts'               => false
	);
	$options_categories_obj = get_categories($cat_args);
	foreach ($options_categories_obj as $category) 
	{
		$options_categories[$category->cat_ID] = $category->cat_name;
	}


	// 所有标签
	$options_tags = array();
	$options_tags_obj = get_tags();
	foreach ( $options_tags_obj as $tag ) 
	{
		$options_tags[$tag->term_id] = $tag->name;
	}


	// 所有页面
	$options_pages = array();
	$options_pages_obj = get_pages('sort_column=post_parent,menu_order');
	$options_pages[''] = '选择页面';
	foreach ($options_pages_obj as $page) 
	{
		$options_pages[$page->ID] = $page->post_title;
	}




	$options = array();

	// tab-1
	$options[] = array
	(
		'name' => '基本设置',
		'type' => 'heading',
	);
	$options[] = array
	(
		'name' => '★提示★',
		'desc' => '当前主题属于公开测试版，不代表最终效果。欢迎踊跃的提交意见和建议，可以点击“外观 -> <a href="'.admin_url().'themes.php?page=theme-feedback" title="主题使用反馈" target="_blank">主题使用反馈</a>”页面反馈。
		第一次运行本主题，请依次修改并保存各选项卡的设置选项，否则会使用默认值！',
		'type' => 'info',
		'class'=>'tip',
	);
	$options[] = array
	(
		'name' =>'管理员ID',
		'desc' =>'默认是1。',
		'id' => 'ydr_admin_id',
		'std' => '1',
		'class' => 'mini',
		'type' => 'text'
	);
	$admin=get_userdata(of_get_option('ydr_admin_id',1));
	$options[] = array
	(
		'name' =>'博客的名称',
		'desc' =>'默认读取系统设置。',
		'id' => 'ydr_blog_name',
		'std' => get_bloginfo('name'),
		'class' => 'small',
		'type' => 'text'
	);
	$options[] = array
	(
		'name' =>'博客的关键字',
		'desc' =>'此关键字主要用于首页，其他页面会读取页面文章的标签。',
		'id' => 'ydr_blog_key',
		'std' => '博客,关键字',
		'class' => 'mini',
		'type' => 'textarea'
	);	
	$options[] = array
	(
		'name' =>'博客的描述',
		'desc' =>'默认读取系统设置，此描述主要用于首页，其他页面会截取文章的摘要作为描述。',
		'id' => 'ydr_blog_desc',
		'std' => get_bloginfo('description'),
		'class' => 'mini',
		'type' => 'textarea'
	);	
	$options[] = array
	(
		'name' =>'博客独立域名',
		'desc' =>'默认是 “qianduanblog.com”，不需要加“http://”',
		'id' => 'ydr_domain',
		'std' => 'qianduanblog.com',
		'class' => 'small',
		'type' => 'text'
	);
	$options[] = array
	(
		'name' =>'网站所在的服务器',
		'desc' =>'默认是 “localhost”，可以是链接形式',
		'id' => 'ydr_host',
		'std' => 'localhost',
		'class' => 'mini',
		'type' => 'textarea'
	);
	$options[] = array
	(
		'name' =>'博客的统计代码',
		'desc' =>'粘贴您的统计代码，但为了美观不会在前台页面显示出来。',
		'id' => 'ydr_blog_tongji',
		'std' => '',
		'class' => 'mini',
		'type' => 'textarea'
	);	
	$options[] = array
	(
		'name' =>'新浪微博url',
		'desc' =>'将会显示在首页的右上角图标链接。',
		'id' => 'ydr_weibo_url',
		'std' => 'http://weibo.com/cloudcome',
		'class' => '',
		'type' => 'text'
	);
	$options[] = array
	(
		'name' =>'腾讯微博url',
		'desc' =>'将会显示在首页的右上角图标链接。',
		'id' => 'ydr_qqt_url',
		'std' => 'http://t.qq.com/cloudcome',
		'class' => '',
		'type' => 'text'
	);
	$options[] = array
	(
		'name' =>'QQ联系url',
		'desc' =>'将会显示在首页的右上角图标链接。',
		'id' => 'ydr_qq_url',
		'std' => 'http://sighttp.qq.com/authd?IDKEY=618c91aa764179287f3e3aa428e40dcdd6e3c3cd5cce99a1',
		'class' => '',
		'type' => 'text'
	);
	
	
	// tab-2
	$options[] = array
	(
		'name' => '样式设置',
		'type' => 'heading'
	);
	$options[] = array
	(
		'name' => '博客的LOGO',
		'desc' => '请上传宽度500px以内，高度100px的图片作为LOGO。如果没有上传将使用默认图片（'.get_bloginfo('template_url').'/public/image/logo.png）。',
		'id' => 'ydr_blog_logo',
		'std'=>get_bloginfo('template_url').'/public/image/logo.png',
		'type' => 'upload'
	);
	$options[] = array
	(
		'name' => '博客的背景图',
		'desc' => '因为博客的主体是白色的，所以您务必上传深色的图片作为博客的背景，背景图将全屏平铺。如果没有上传将使用默认图片（'.get_bloginfo('template_url').'/public/image/fullbody.png）。',
		'id' => 'ydr_blog_background',
		'std'=>get_bloginfo('template_url').'/public/image/fullbody.png',
		'type' => 'upload'
	);


	// tab-2
	$options[] = array
	(
		'name' => '页面设置',
		'type' => 'heading'
	);
	$options[] = array
	(
		'name' =>'谷歌自定义搜索页面',
		'desc' =>'选择“谷歌自定义搜索”模板页并发布之后才可以选择，如果未选择任何页面，将使用系统默认的搜索。',
		'id' => 'ydr_google_page',
		'type' => 'select',
		'options'=>$options_pages
	);
	$options[] = array
	(
		'name' =>'博客的谷歌自定义搜索js部分',
		'desc' =>'粘贴您的谷歌自定义搜索js代码(即”&lt;script>js代码&lt;/script>“部分)，只需要粘贴js代码即可，<a target="_blank" href="http://www.google.com/cse/tools/create_onthefly">申请谷歌自定义搜索地址</a>',
		'id' => 'ydr_google_search',
		'std' => '',
		'class' => '',
		'type' => 'textarea'
	);	
	$options[] = array
	(
		'name' =>'所有标签页',
		'desc' =>'您必须在后台新建页面并且选择“1=所有标签”模板页发布之后，才可以选择页面',
		'id' => 'ydr_tag_page',
		'type' => 'select',
		'options' => $options_pages
	);
	$options[] = array
	(
		'name' =>'是否主题支持wap功能',
		'desc' =>'选择开启之后将在用户通过wap方式访问站点时，显示wap版的主题',
		'id' => 'ydr_wap',
		'type' => 'radio',
		'std' => '-1',
		'options' => array
		(
			'0'=>'推荐开启',
			'-1'=>'关闭【公开测试版未完善wap版样式】',
		)
	);
	
	
	
	
	// tab-2
	$options[] = array
	(
		'name' => '评论设置',
		'type' => 'heading'
	);
	$options[] = array
	(
		'id'=>'ydr_avatar_cache',
		'name' => '是否开启评论头像缓存【30天】',
		'desc' => '头像缓存在“public/image/avatar/”下面，第一次启用缓存会因为保存头像缓慢，下次就会很快了。',
		'type' => 'radio',
		'std'=>'1',
		'options' => array
		(
			'1'=>'推荐开启',
			'0'=>'关闭'
		),
	);
	$is_mail_exists=function_exists('mail')?'支持':'不支持';
	$options[] = array
	(
		'name' => '是否自定义邮件地址',
		'desc' => 'Wordpress默认的发信地址是wordpress@qianduanblog.com。（主机mail函数检测结果：<b>'.$is_mail_exists.'</b>。）',
		'id' => 'ydr_mail',
		'std' => '0',
		'type' => 'radio',
		'options' => array
		(
			'0'=>'使用Wordpress默认的邮件地址',
			'1'=>'自定义邮件地址'
		),
	);
	$options[] = array
	(
		'name' =>'发送评论邮件通知的email地址',
		'desc' =>'默认读取管理员的email。',
		'id' => 'ydr_mail_from',
		'std' => $admin->user_email,
		'class' => of_get_option('ydr_mail',0)?'':'hide',
		'type' => 'text'
	);
	$options[] = array
	(
		'name' =>'发送评论邮件通知的发信人名字',
		'desc' =>'默认读取博客的名称。',
		'id' => 'ydr_mail_name',
		'std' => get_bloginfo('name'),
		'class' => of_get_option('ydr_mail',0)?'':'hide',
		'type' => 'text'
	);
	$options[] = array
	(
		'name' => '是否要求评论必须含有中文',
		'desc' => '限制评论的输入字符类型。',
		'id' => 'ydr_word_limit',
		'std' => '1',
		'type' => 'radio',
		'options' => array
		(
			'0'=>'不限制',
			'1'=>'必须含有中文字符'
		),
	);
	$options[] = array
	(
		'name' => '评论要求最少字符数',
		'desc' => '限制评论的输入字符数量。',
		'id' => 'ydr_min_word_limit',
		'std' => '10',
		'type' => 'radio',
		'options' => array
		(
			'1'=>'最少要求1个字符',
			'10'=>'最少要求10个字符'
		),
	);
	$options[] = array
	(
		'name' => '评论要求最多字符数',
		'desc' => '限制评论的输入字符数量。',
		'id' => 'ydr_max_word_limit',
		'std' => '140',
		'type' => 'radio',
		'options' => array
		(
			'99999'=>'不限制(=99999字符)',
			'140'=>'最多要求140个字符'
		),
	);
	

	// tab-3
	$options[] = array
	(
		'name' => '阅读设置',
		'type' => 'heading'
	);
	$options[] = array
	(
		'name' => '关于 “wp-post-views” 插件统计的数据',
		'desc' => '主题支持一键导入“wp-post-views” 插件统计的文章浏览次数，让你的文章阅读次数不会因为更换主题而出现重新统计的现象。具体的导入页面 <a href="'.admin_url().'themes.php?page=theme-import" title="点击前往wp-postview插件统计数据导入主题页面" target="_blank">点击这里</a>，导入成功后将记录导入时间，避免多次重复导入，导入的数据对“yundanran”系列主题都有效。',
		'type' => 'info',
		'class'=> 'important',
	);
	$options[] = array
	(
		'id'=>'ydr_image_lazy',
		'name' => '是否启用文章内图片延时载入，该功能不支持部分短代码中包含的图片',
		'desc' => '文章内的图片在页面滚动到该位置时才载入图像，缓解服务器压力。更多参考jquery-lazy插件。',
		'type' => 'radio',
		'std' => '1',
		'class'=> '',
		'options' => array
		(
			'1'=>'启用',
			'0'=>'关闭'
		),
	);
	$options[] = array
	(
		'id'=>'ydr_image_replace',
		'name' => '启用图片延时载入的占位图',
		'desc' => '默认图像是”public/image/loving.gif“，您可以替换成您喜欢的其他图像。',
		'std'=>get_bloginfo('template_url').'/public/image/loving.gif',
		'type' => 'upload',
		'class'=>of_get_option('ydr_image_lazy',1)?'':'hide',
	);
	
	
	
	// tab-5
	$options[] = array
	(
		'name' => '广播设置',
		'type' => 'heading'
	);
	$options[] = array
	(
		'name' =>'广播ID',
		'desc' =>'您修改广播内容并保存的时候会自动生成。',
		'id' => 'ydr_notice_id',
		'std' => '',
		'class' => 'hide',
		'type' => 'text'
	);
	$options[] = array
	(
		'name' =>'全站顶部广播【不建议插入外部的js代码】',
		'desc' =>'如果广播不为空，那么广播会在您设置时间段里显示在全站顶部(不含特殊页面)，并且接受访客的关闭操作。填写广播内容，可以是html代码。',
		'id' => 'ydr_notice_content',
		'std' => '',
		'class' => '',
		'type' => 'textarea'
	);
	$options[] = array
	(
		'name' =>'广播截止时间（今日：'.date('Y-m-d',time()).'）',
		'desc' =>'您必须填写“2013-1-1”此类格式的日期，在此日期之前都会一直显示广播。',
		'id' => 'ydr_notice_date',
		'std' => '2013-1-1',
		'class' => 'mini',
		'type' => 'text'
	);
	
	// tab-6
	$options[] = array
	(
		'name' => '分类设置',
		'type' => 'heading',
	);
	
	foreach($options_categories_obj as $category) 
	{
		$options[] = array
		(
			'name' => '“'.$category->cat_name.'”的图标',
			'desc' => '不限制尺寸，如果图片缺省将使用主题/public/image/null.gif作为分类图标。',
			'id' => 'ydr_cat_'.$category->cat_ID,
			'std'=>get_bloginfo('template_url').'/public/image/null.gif',
			'type' => 'upload',
		);
	}
	
	
	// end return
	return $options;
}



add_action('optionsframework_custom_scripts', 'optionsframework_custom_scripts');
function optionsframework_custom_scripts() 
{
?>

<script type="text/javascript">
jQuery(document).ready(function($) 
{
	var $ml		=$('#section-ydr_mail'),
		ml		='#section-ydr_mail_from,#section-ydr_mail_name',	
		$lz		=$('#section-ydr_image_lazy'),
		lz		='#section-ydr_image_replace';
	
	s($ml,ml);
	s($lz,lz);
	
	function s($id,id)
	{
		$id.find('input:radio').change(function()
		{
			parseInt($(this).val())==1?
			$(id).stop(1,0).slideDown(333):
			$(id).stop(1,0).slideUp(333);
		});
	}
	
	var $n_id=$('#ydr_notice_id'),
		$n_cn=$('#ydr_notice_content');
	$n_cn.change(function()
	{
		// 生成的id唯一
		var id=new Date().getTime();
		if($n_cn.val()!='')$n_id.val(id);
		else $n_id.val('');
	});
	
	
	
	var $date=$('#ydr_notice_date');
	$date.focusout(function()
	{
		$(this).val(function()
		{
			return $.trim(this.value);
		});
	});
	function check_date()
	{
		var v=$date.val();
		if(v=='' || /^\d{4}-\d{1,2}-\d{1,2}$/.test(v))
		{
			return true;
		}
		else
		{
			message($date,'日期格式填写错误！');
			return false;
		}
	}
	
	var $options=$('#optionsframework'),
		$submit=$('#optionsframework-submit input:submit');
	function message($ipt,content)
	{
		$options.find('input,textarea').removeClass('wrong');
		$options.find('.options-jserror').stop(1,1).hide();
		var $h	=$ipt.closest('.section').find('h4.heading'),
			$m	=$h.find('.options-jserror').length?$h.find('.options-jserror'):$('<span class="options-jserror"></span>').appendTo($h);
		$ipt.addClass('wrong').focus();
		$m.html(content).fadeIn(111);
	}
	$submit.click(function()
	{
		// return false;
		if(!check_date())return false;
	});
	
	
	
});
</script>

<?php
}