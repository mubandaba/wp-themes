<?php
if (have_posts()) : the_post(); update_post_caches($posts);
	$post_id 		=get_the_ID();
	$title 			=get_the_title();
	$title_attr		=esc_attr(strip_tags($title));
	$link 			=get_permalink();
	$author_id		=$post->post_author;
	$author_email	=get_userdata($author_id)->user_email;
	$author_name 	=get_the_author();
	$time			=get_the_time('Y年m月d日 H:i:s',$post);
	$time_ago		=yundanran_time_ago(strtotime(get_the_time('YmdHis',$post)));
	yundanran_setPostViews(get_the_ID());
	$views 			=yundanran_getPostViews($post_id);
	$comments_link	=get_comments_link();
	// $comments_link	='#comments';
	$comments_num 	=get_comments_number();
	$content		=yundanran_set_reply2view(yundanran_the_content(),$post_id);
	$post_class_arr	=get_post_class($post_id);
	$post_class		="$post_class_arr[0] $post_class_arr[2] $post_class_arr[3] $post_class_arr[4]";
	$post_type		=get_post_type($post_id);
	$post_format	=get_post_format($post_id)?get_post_format($post_id):'standard';
	$is_sticky		=is_sticky($post_id);
	$is_new			=time()-strtotime(get_the_time('YmdHis',$post))<=3*24*60*60?true:false;
	$new_html		=$is_new?'<span class="new">new!</span>':'';
?>

<script type="text/javascript">yundanran.post_id=<?=$post_id?></script>
<!-- article <?=$post_id?> 开始 -->
<article class="article single-article <?=$post_class?>" id="article-<?=$post_id?>">
	<div class="format-icon" title="<?=yundanran_get_post_format($post_id);?>"></div>
	<div class="wrap">
	
		<?php if($post_format=='image'): ?>
		<!-- //post_format:image -->
		<h2 class="title"><span><strong><?=$title?></strong></span></h2>
		<div class="clear"></div>
		<div class="body float">
			<div class="text"><?=$new_html?><?=$content;?></div>
		</div>
		<div class="clear"></div>
		<div class="meta">
			<p class="author" title="文章作者：<?=$author_name?>"><i></i><span><?php the_author_posts_link();?><?php edit_post_link('(再编辑&raquo;)', '', ''); ?></span></p>
			<p class="time" title="发布时间：<?=$time?>"><i></i><span><?=$time_ago?></span></p>
			<p class="view" title="浏览次数：<?=$views?>"><i></i><span><?=$views?></span></p>
			<p class="comment"><a href="<?=$comments_link?>" title="评论条数：<?=$comments_num?>"><i></i><span><?=$comments_num?></span></a></p>
			<p class="copy" data-title="<?=$title?>" data-link="<?=$link?>"><i></i><span>复制标题、链接</span></p>
			<div class="message"><!-- 这里显示消息的内容！ --></div>
		</div>
		<!-- //post_format:image -->
		
		
		<?php elseif($post_format=='gallery'): ?>
		<!-- //post_format:gallery -->
		<div class="body float">
			<div class="text"><?=$new_html?><?=$content;?></div>
		</div>
		<div class="clear"></div>
		<div class="meta">
			<p class="author" title="文章作者：<?=$author_name?>"><i></i><span><?php the_author_posts_link();?><?php edit_post_link('(再编辑&raquo;)', '', ''); ?></span></p>
			<p class="time" title="发布时间：<?=$time?>"><i></i><span><?=$time_ago?></span></p>
			<p class="view" title="浏览次数：<?=$views?>"><i></i><span><?=$views?></span></p>
			<p class="comment"><a href="<?=$comments_link?>" title="评论条数：<?=$comments_num?>"><i></i><span><?=$comments_num?></span></a></p>
			<p class="copy" data-title="<?=$title?>" data-link="<?=$link?>"><i></i><span>复制标题、链接</span></p>
			<div class="message"><!-- 这里显示消息的内容！ --></div>
		</div>
		<!-- //post_format:gallery -->
		

		
		
		<?php elseif($post_format=='aside'): ?>
		<!-- //post_format:aside -->
		<div class="clear"></div>
		<div class="body float">
			<div class="author-avatar"><?=yundanran_avatar_cache(get_avatar($author_email,60));?></div>
			<div class="text"><?=$new_html?><?=$content?></div>
		</div>
		<div class="clear"></div>
		<div class="meta">
			<p class="author" title="文章作者：<?=$author_name?>"><i></i><span><?php the_author_posts_link();?><?php edit_post_link('(再编辑&raquo;)', '', ''); ?></span></p>
			<p class="time" title="发布时间：<?=$time?>"><i></i><span><?=$time_ago?></span></p>
			<p class="view" title="浏览次数：<?=$views?>"><i></i><span><?=$views?></span></p>
			<p class="comment"><a href="<?=$comments_link?>" title="评论条数：<?=$comments_num?>"><i></i><span><?=$comments_num?></span></a></p>
			<p class="copy" data-title="<?=$title?>" data-link="<?=$link?>"><i></i><span>复制标题、链接</span></p>
			<div class="message"><!-- 这里显示消息的内容！ --></div>
		</div>
		<!-- //post_format:aside -->
		
		
		
		<?php else: ?>
		<!-- //post_format:standard -->
		<h2 class="title"><?=$is_sticky?'<span class="sticky">置顶</span>':''?><?=$new_html?><?=$title?></h2>
		<div class="meta">
			<p class="author" title="文章作者：<?=$author_name?>"><i></i><span><?php the_author_posts_link();?><?php edit_post_link('(再编辑&raquo;)', '', ''); ?></span></p>
			<p class="time" title="发布时间：<?=$time?>"><i></i><span><?=$time_ago?></span></p>
			<p class="view" title="浏览次数：<?=$views?>"><i></i><span><?=$views?></span></p>
			<p class="comment"><a href="<?=$comments_link?>" title="评论条数：<?=$comments_num?>"><i></i><span><?=$comments_num?></span></a></p>
			<p class="copy" data-title="<?=$title?>" data-link="<?=$link?>"><i></i><span>复制标题、链接</span></p>
			<div class="message"><!-- 这里显示消息的内容！ --></div>
		</div>
		<div class="clear"></div>
		<div class="body">
			<div class="text"><?=$content?></div>
			<div class="sep-line"></div>
		</div>
		<div class="clear"></div>
		<div class="meta">
			<p class="cat" title="文章所在分类"><i></i><span><?=the_category(' , ');?></span></p>
			<p class="tag" title="文章所有标签"><i></i><span><?=the_tags('',' , ',''); ?></span></p>
			<a class="share share-sina" title="分享到新浪微博" data-title="<?=$title?>" data-link="<?=$link?>" data-summary="" href="#"></a>
			<a class="share share-qqt" title="分享到腾讯微博" data-title="<?=$title?>" data-link="<?=$link?>" data-summary="" href="#"></a>
			<a class="share share-qqz" title="分享到QQ空间" data-title="<?=$title?>" data-link="<?=$link?>" data-summary="" href="#"></a>
		</div>
		<!-- //post_format:standard -->
		
		
		
		<?php endif; ?>
	</div>
	<div class="bg1"></div>
	<div class="bg2"></div>
</article>
<!-- article <?=$post_id?> 结束 -->


<div id="prev-next">
	<ul class="float">
		<?php if( get_previous_post() ) : ?>
		<li class="left prev">上一篇：<?php previous_post_link('%link');?></li>
		<?php endif; ?>
		
		<?php if( get_next_post() ) :?>
		<li class="right next">下一篇：<?php next_post_link('%link'); ?></li>
		<?php endif; ?>
	</ul>
</div>

<?php else://else 404
	$post_id 		=-1;
	$title 			='这是一篇无法显示的文章。';
	$link 			=get_bloginfo('url');
	$author_name 	='佚名';
	$time_ago 		='上古时代';
	$views 			=yundanran_getPostViews($post_id);
	$comments_link	=get_bloginfo('url');
	$comments_num 	=-1;
	$summary 		='';
?>

<!-- 404 开始 -->
<article class="article single-article">
	<div class="wrap">
		<h2 class="title"><span><a href="<?=$link?>" title="《<?=$title?>》"><?=$title?></a></span></h2>
		<div class="meta">
			<p class="author" title="文章作者：<?=$author_name?>"><i></i><span><?php the_author_posts_link();?><?php edit_post_link('(再编辑&raquo;)', '', ''); ?></span></p>
			<p class="time" title="发布时间：<?=$time_ago?>"><i></i><span><?=$time_ago?></span></p>
			<p class="view" title="浏览次数：<?=$views?>"><i></i><span><?=$views?></span></p>
			<p class="comment" title="评论条数：<?=$comments_num?>"><i></i><a href="<?=$comments_link?>" title="评论这篇文章"><span><?=$comments_num?></span></a></p>
			<p class="copy" title="复制文章标题、链接" data-title="<?=$title?>" data-link="<?=$link?>"><i></i><span></span></p>
		</div>
		<div class="clear"></div>
		<div class="body ">
			<div class=" text">
				<p>这是一篇无法显示的文章。</p>
				<p>可能原因是：</p>
				<ul>
					<li>文章没有被发表；</li>
					<li>文章被设置为隐私；</li>
					<li>文章已被删除；</li>
					<li>文章不存在；</li>
					<li>其他原因。</li>
				</ul>
				<p><a href="http://mail.163.com/share/mail2me.htm#email=099108111117100099111109101064049054051046099111109" target="_blank" title="给博主发送邮件说明情况">给博主发送邮件说明情况</a></p>
				<span class="end">[全文完]</span>
			</div>
		</div>
		<div class="clear"></div>
		<div class="meta">
			<p class="cat" title="文章所在分类"><i></i><span><?php the_category(' , ');?></span></p>
			<p class="tag" title="文章所有标签"><i></i><span><?php the_tags('',' , ',''); ?></span></p>
			<p class="share share-sina" title="分享到新浪微博" data-title="<?=$title?>" data-link="<?=$link?>" data-summary=""><i></i><span></span></p>
			<p class="share share-qqt" title="分享到腾讯微博" data-title="<?=$title?>" data-link="<?=$link?>" data-summary=""><i></i><span></span></p>
			<p class="share share-qqz" title="分享到QQ空间" data-title="<?=$title?>" data-link="<?=$link?>" data-summary=""><i></i><span></span></p>
		</div>
	</div>
	<div class="bg1"></div>
	<div class="bg2"></div>
</article>
<!-- 404 结束 -->

<?php endif; //end-have post?>