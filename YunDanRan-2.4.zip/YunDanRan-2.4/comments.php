<?php
	//参数用于ajax翻页
	$ajax=(isset($_POST['yundanran_ajax']))?$_POST['yundanran_ajax']:0;
	$ajax=(is_numeric($ajax))?(int)$ajax:0;
	$comment_author=isset($_COOKIE["comment_author_".COOKIEHASH])?esc_attr($_COOKIE["comment_author_".COOKIEHASH]):'';
	$comment_author_email=isset($_COOKIE["comment_author_email_".COOKIEHASH])?esc_attr($_COOKIE["comment_author_email_".COOKIEHASH]):'';
	$comment_author_url=isset($_COOKIE["comment_author_url_".COOKIEHASH])?esc_attr($_COOKIE["comment_author_url_".COOKIEHASH]):'';
	$role_arr=yundanran_get_user_role($GLOBALS['user_id']);
	$role_name=$role_arr['role_name'];
	$role_desc=$role_arr['role_desc'];
	$commentstab=(!isset($GLOBALS['yundanran_commentstab']) || $GLOBALS['yundanran_commentstab']=='')?'博文讨论':$GLOBALS['yundanran_commentstab'];
?>

<!--  评论 & 相关博文 开始 -->
<article class="has-tab <?php echo (isset($GLOBALS['yundanran_commentsonly']) && $GLOBALS['yundanran_commentsonly']==1)?'commentsonly':'haverelative';?>">
	<h2 class="title">
		<i></i>
		<ul class="tab">
			<li class="click"><?=$commentstab?>(<span id="comments-number"><?=get_comments_number($post->ID)?></span>)</li>
			<?php echo(isset($GLOBALS['yundanran_commentsonly']) && $GLOBALS['yundanran_commentsonly'])?'':'<li class="">博文相关</li>';?>
		</ul>
	</h2>
	<div class="tab-content">
		<div class="tab-body current comments" id="comments">
			<?php if(!is_user_logged_in()): ?>
			<div class="notice">
				<p>您可以作为游客或者匿名评论/回复，但您的评论/回复将受到限制。</p>
				<p>在右上角登录之后，将享有更丰富、高级的评论等特权（将可以发表图片、视频、音乐等多媒体附件、可以再编辑、删除自己的评论）以及贴心的在线交流服务。</p>
			</div>
			<?php endif; ?>
			
			<!--评论列表-->
			<ol class="wrap comments-parent">
				<?php if(is_user_logged_in()): ?>
				<li class="comment current-user depth-1">
					<div class="content">
						<div class="user-photo"><?=yundanran_avatar_cache(get_avatar($GLOBALS['user_email'],'50'));?></div>
						<div class="body">
							<div class="meta float">
								<p class="<?=$role_name?>">
									<i title="<?=$role_desc?>"></i>
									<strong><a target="_blank" href="<?=$GLOBALS['user_url']?>"><?=$GLOBALS['user_display_name']?></a></strong>
									<?=yundanran_comment_level_html($GLOBALS['comment_level'])?>
									<em>【<?=$GLOBALS['comment_level_desc']?>】</em>
								</p>
								<p class="access">
									<?=yundanran_comment_access_html()?>
								</p>
							</div>
							<div class="floor" style="display:none;">#0</div>
							<div class="input current-user" data-comment_parent="0" data-comment_depth="0" data-comment_id="0" data-post_id="<?=$post->ID?>"><span>我有话要说：</span></div>
							<div class="caret caret-left">
								<b class="caret-1"></b>
								<b class="caret-2"></b>
							</div>
							<div class="clear"></div>
						</div>					
					</div>
					<div class="bg-1"></div>
					<div class="bg-2"></div>
				</li>
				<?php else: 
					$avatar 	= $comment_author_email?yundanran_avatar_cache(get_avatar($comment_author_email,50)) :'未登录';
					$level 		= $comment_author_email?yundanran_comment_level($comment_author_email):0;
					$level_desc	= yundanran_comment_level_desc($level);
					$author 	= $comment_author?
						($comment_author_url?'<a href="'.$comment_author_url.'" target="_blank" rel="external nofollow">'.$comment_author.'</a>':$comment_author):
						'未登录';
				?>
				<li class="comment current-user depth-1">
					<div class="content">
						<div class="user-photo"><?=$avatar?></div>
						<div class="body">
							<div class="meta float">
								<p class="unknow">
									<i title="游客"></i>
									<strong><?=$author?></strong>
									<?=yundanran_comment_level_html($level)?>
									<em>【<?=$level_desc?>】</em>
								</p>
								<p class="access">
									<?=yundanran_comment_access_html()?>
								</p>
							</div>
							<div class="floor" style="display:none;">#0</div>
							<div class="input current-user" data-comment_parent="0" data-comment_depth="0" data-comment_id="0" data-post_id="<?=$post->ID?>"><span>我有话要说：</span></div>
							<div class="caret caret-left">
								<b class="caret-1"></b>
								<b class="caret-2"></b>
							</div>
							<div class="clear"></div>
						</div>					
					</div>
					<div class="bg-1"></div>
					<div class="bg-2"></div>
				</li>
				<?php endif; ?>
				<?php
				$paged = (get_query_var('cpage')) ? get_query_var('cpage') : 1;
				// echo yundanran_list_comments($paged);
				?>
				<script type="text/javascript">
				yundanran.comment_page=<?=$paged?>;
				</script>
				
			</ol>
			<!--/评论列表-->
			<!--__yundanran_comment_page__-->
			<?php
				// if($paged>1 && $paged!='')
				// {
					// echo '<div id="page" class="comments-page">';
					// previous_comments_link('单击加载更多评论');
					// echo '</div>';
				// }
			?>
			
			<div id="comment-post" class="post">
			<?php if(!is_user_logged_in()): ?>
				<?php if($comment_author!=''):?>
				<p class="welcome">欢迎您回来，<b><?=$comment_author?></b>(<a href="#">编辑</a>)：</p>
				<?php endif;?>
				<ul class="unlogin" style="<?=$comment_author!=''?'display:none;':''?>">
					<li>
						<label for="comment_author">昵称：
							<input type="text" name="comment_author" id="comment_author" class="" value="<?=$comment_author?>" />
						</label><?php echo $req ? '<span class="required">*</span>' : ''; ?>
						<em></em>
					</li>
					<li>
						<label for="comment_author_email">邮箱：
							<input type="email" name="comment_author_email" id="comment_author_email" class="" value="<?=$comment_author_email?>" />
						</label><?php echo $req ? '<span class="required">*</span>' : ''; ?>
						<em></em>
					</li>
					<li>
						<label for="comment_author_url">网址：
							<input type="url" name="comment_author_url" id="comment_author_url" class="" value="<?=$comment_author_url?>" />
						</label>
						<em></em>
					</li>
				</ul>
			<?php endif; ?>
				<div class="textarea">
					<?php if(is_user_logged_in()): ?>
					<div id="comment-attach-image" class="attach-image attach-box">
						<strong>外链图片附件:</strong>
						<p></p>
						<i class="close" title="删除外链图片附件"></i>
					</div>
					<div id="comment-attach-youku-video" class="attach-youku-video attach-box">
						<strong>优酷视频附件:</strong>
						<p></p>
						<i class="close" title="删除优酷视频附件"></i>
					</div>
					<div id="comment-attach-kugou-music" class="attach-kugou-music attach-box">
						<strong>酷狗音乐附件:</strong>
						<p></p>
						<i class="close" title="删除酷狗音乐附件"></i>
					</div>
					<?php endif; ?>
					<div class="textarea-wrap"><textarea name="content" title="支持“ctrl + enter”提交评论"></textarea></div>
					<p class="count"><strong>0</strong>/<span>140</span><i class="close" title="清空评论内容"></i></p>
				</div>
				<div class="attach">
					<div class="left button">
						<a href="javascript:;" class="icon face" title="插入表情"></a>
						<?php if(is_user_logged_in()): ?>
						<a href="javascript:;" class="icon image" title="插入外链图片"></a>
						<a href="javascript:;" class="icon youku-video" title="插入优酷(youku.com)视频"></a>
						<a href="javascript:;" class="icon mp3" title="插入mp3音乐"></a>
						<?php endif; ?>
					</div>
					<div class="right for-post button current">
						<?php
							$c_email=$GLOBALS['user_login']?$GLOBALS['user_email']:(isset($_COOKIE["comment_author_email_".COOKIEHASH])?$_COOKIE["comment_author_email_".COOKIEHASH]:'');
							// 如果没有找到设置值就默认邮件通知
							// 如果邮件为空，默认不邮件通知
							$c_new=$c_email==''?
							0:
							(
								yundanran_kv_has('comment_notice》'.$c_email)?
								(
									yundanran_kv_find('comment_notice》'.$c_email)==1?
									1:
									0
								):
								1
							);
						?>
						<a href="javascript:;" title="<?php echo ($c_new==1)?'已设置':'已取消';?>：评论邮件通知。" class="icon email <?php echo ($c_new==1)?'click':'';?>" data-set="<?php echo ($c_new==1)?'1':'0';?>"></a>
						<?php if(is_user_logged_in()): ?>
						<a href="javascript:;" class="icon syncQQ" title="未支持：同步评论到QQ空间。"></a>
						<a href="javascript:;" class="icon syncQT" title="未支持：同步评论到腾讯微博。"></a>
						<?php endif; ?>
						<a href="javascript:;" class="y_button yes button to-post"><span>发表评论</span></a>
					</div>
					<?php if(is_user_logged_in()): ?>
					<div class="right for-edit">
						<a href="javascript:;" class="y_button yes button to-edit"><span>再编辑</span></a>
					</div>
					<?php endif; ?>
					<div class="popup face">
						<h6 class="name">
							<span>插入表情</span>
							<i class="close" title="关闭之"></i>
						</h6>
						<div class="wrap">
							<ul class="float">
							</ul>
							<div class="clear"></div>
						</div>
						<div class="caret caret-top">
							<b class="caret-1"></b>
							<b class="caret-2"></b>
						</div>
					</div>
					<?php if(is_user_logged_in()): ?>
					<div class="popup image">
						<h6 class="name">
							<span>附件：添加外链图片</span>
							<i class="close" title="关闭之"></i>
						</h6>
						<div class="wrap">
							<ul>
								<li class="line line-0">提示：路径的合法结尾是图片后缀，如果没有可以添加“.jpg”。</li>
								<li class="line line-1"><input type="text" class="text" name="" id="" value="输入图片外链地址" data-old="输入图片外链地址"></li>
								<li class="line line-2"><a href="#" class="y_button yes"><span>插入外链图片</span></a></li>
							</ul>
							<span class="message"><!--这里显示的是消息内容--></span>
						</div>
						<div class="caret caret-top">
							<b class="caret-1"></b>
							<b class="caret-2"></b>
						</div>
					</div>
					<div class="popup youku-video">
						<h6 class="name">
							<span>附件：添加外链flash视频</span>
							<i class="close" title="关闭之"></i>
						</h6>
						<div class="wrap">
							<ul>
								<li class="line line-0"><b>推荐使用优酷视频！</b>提示：支持国内大部分视频网站，部分土豆视频不支持。只需要填写浏览器地址栏里播放视频的url即可。</li>
								<li class="line line-1"><input type="text" class="text" name="" id="" value="输入优酷视频flash地址" data-old="输入优酷视频flash地址"></li>
								<li class="line line-2"><a href="#" class="y_button yes"><span>插入视频URL</span></a></li>
							</ul>
							<span class="message"><!--这里显示的是消息内容--></span>
						</div>
						<div class="caret caret-top">
							<b class="caret-1"></b>
							<b class="caret-2"></b>
						</div>
					</div>
					<div class="popup mp3">
						<h6 class="name">
							<span>附件：添加外链MP3音乐</span>
							<i class="close" title="关闭之"></i>
						</h6>
						<div class="wrap">
							<ul>
								<li class="line line-0">提示：目前仅支持外链mp3音乐，在输入框里填写音乐的mp3（路径的合法结尾是“.mp3”）地址即可。</li>
								<li class="line line-1"><input type="text" class="text" name="" id="" value="输入外链mp3音乐地址" data-old="输入外链mp3音乐地址"></li>
								<li class="line line-2"><a href="#" class="y_button yes"><span>插入外链MP3</span></a></li>
							</ul>
							<span class="message"><!--这里显示的是消息内容--></span>
						</div>
						<div class="caret caret-top">
							<b class="caret-1"></b>
							<b class="caret-2"></b>
						</div>
					</div>
					<?php endif; ?>
				</div>
				<div class="message"><span class="error"><!--这里显示的是消息内容--></span></div>
			</div>
			<!-- 评论 -->
		</div>
		
		<?php if(!isset($GLOBALS['yundanran_commentsonly']) || !$GLOBALS['yundanran_commentsonly']):?>
		<div class="tab-body relative-article">
			<!-- 相关博文 -->
			<div class="loading">
				<p>加载中<i class="waiting"></i></p>
			</div>
			<div class="body"></div>
			<!-- 相关博文 -->
		</div>
		<?php endif;?>

	</div>
</article>
<!--  评论 & 相关博文 结束 -->