<?php

	global $wp_version;

	if ( $wp_version >= 4.1 ) :

		the_posts_pagination( array( 'prev_text' => __( '上一页', 'free-1' ), 'next_text' => __( '下一页', 'free-1' ) ) );
	
	endif;

?>