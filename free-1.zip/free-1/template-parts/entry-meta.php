<div class="entry-meta clear">

	<span class="entry-author"><?php esc_html_e('作者:', 'free-1'); ?> <?php the_author_posts_link(); ?></span>
	<span class="entry-date"><?php esc_html_e('发布:', 'free-1'); ?> <?php echo get_the_date(); ?></span>
	<span class="entry-category"> <?php esc_html_e('分类:', 'free-1'); ?> <?php free1_first_category(); ?></span>
	<span class="entry-comment-number"><?php comments_popup_link( '0', '1', '%', 'comments-link', ''); ?></span>

</div><!-- .entry-meta -->