<?php get_header(); ?>

	<?php

		$sticky = get_option( 'sticky_posts' );
		$args = array(
		    'posts_per_page' => 4,
		    'post__in'  => $sticky,
		    'ignore_sticky_posts' => 1
		);

		// The Query
		$the_query = new WP_Query( $args );

		$i = 1;

		if ( ( isset($sticky[0]) ) && (!get_query_var('paged')) && ( get_theme_mod('featured-content-on', 'true') == true ) ) :

	?>

		<div id="featured-content" class="clear">

		<?php
			// The Loop
			while ( $the_query->have_posts() ) : $the_query->the_post();
		?>	

		<div class="hentry <?php if( $i % 4 == 0) { echo "last"; }?>">

			<?php if ( has_post_thumbnail() ) { ?>
				<a target="_blank" class="thumbnail-link" href="<?php the_permalink(); ?>">
					<div class="thumbnail-wrap">
						<?php 
							the_post_thumbnail('post_thumb');  
						?>
					</div><!-- .thumbnail-wrap -->
				</a>
			<?php } ?>

			<div class="entry-header">
				<h2 class="entry-title"><a target="_blank" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
				<div class="entry-meta">
					<span class="entry-category"><?php free1_first_category(); ?></span>
				</div><!-- .entry-meta -->
			</div><!-- .entry-header -->

		</div><!-- .hentry -->

		<?php   
			$i++;
			endwhile;
		?>

		<div class="ribbon"><span>置顶文章</span></div>

		</div><!-- #featured-content -->

	<?php
		endif;
		wp_reset_postdata();
	?>	

	<div id="primary" class="content-area clear">	

		<main id="main" class="site-main clear">

			<div id="recent-content" class="content-loop">

				<?php

				// Define custom query args
				$custom_query_args = array( 
				    // exclude all sticky posts
				    'post__not_in' => get_option( 'sticky_posts' ) ,
				    // don't forget to paginate!
	  				'paged' => get_query_var('paged')
				);  
				// globalize $wp_query
				global $wp_query;
				// Merge custom args with default query args
				$merged_query_args = array_merge( $wp_query->query, $custom_query_args );
				// process the query
				query_posts( $merged_query_args );

				if ( $wp_query->have_posts() ) :	
				
				/* Start the Loop */
				while ( $wp_query->have_posts() ) : $wp_query->the_post();

					get_template_part('template-parts/content', 'loop');

				endwhile;

				else :

					get_template_part( 'template-parts/content', 'none' );

				endif; 

				?>

			</div><!-- #recent-content -->		

		</main><!-- .site-main -->

		<?php get_template_part( 'template-parts/pagination', '' ); ?>

	</div><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>
