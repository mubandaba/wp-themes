<?php
/** zuluoCMS options */
class zuluoCMSOptions {
	function getOptions() {
		$options = get_option('zuluoCMS_options');
		if (!is_array($options)) {
			$options['notice'] = true;
			$options['notice_content'] = '煮IT网——我的轻媒体';
			$options['head_logo'] = bloginfo('template_url') . '/images/logo.gif';
			$options['head_ads'] = bloginfo('template_url') . '/images/ad_header.png';
			$options['head_ads_link'] = 'http://www.cnzooit.com';
			$options['footer_content'] = '';	
			$options['hide'] = false;
			$options['index_hide'] = '';
			$options['sidebar_hide'] = '';
			$options['hotnews'] = true;
			$options['headline'] = '';
			$options['slider'] = '';
			$options['hotlist'] = '';
			$options['banner'] = false;
			$options['banner_content'] = '';
			$options['share'] = false;
			$options['share_content'] = '';		
			$options['single_ads'] = false;
			$options['single_ads_content'] = '';			
			$options['analytics'] = false;
			$options['analytics_content'] = '';
			update_option('zuluoCMS_options', $options);
		}
		return $options;
	}

	function add() {
		if(isset($_POST['zuluoCMS_save'])) {
			$options = zuluoCMSOptions::getOptions();

			// notice
			if ($_POST['notice']) {
				$options['notice'] = (bool)true;
			} else {
				$options['notice'] = (bool)false;
			}
			$options['notice_content'] = stripslashes($_POST['notice_content']);

			// head_left Logo
			$options['head_logo'] = stripslashes($_POST['head_logo']);

			// head_right ads
			$options['head_ads'] = stripslashes($_POST['head_ads']);

			// head_right ads link
			$options['head_ads_link'] = stripslashes($_POST['head_ads_link']);
			
			//hide some category
			if ($_POST['hide']) {
				$options['hide'] = (bool)true;
			} else {
				$options['hide'] = (bool)false;
			}
			//index_hide
			$options['index_hide'] = stripslashes($_POST['index_hide']);
			//sidebar_hide
			$options['sidebar_hide'] = stripslashes($_POST['sidebar_hide']);

			//hotnews
			if ($_POST['hotnews']) {
				$options['hotnews'] = (bool)true;
			} else {
				$options['hotnews'] = (bool)false;
			}
			//headline
			$options['headline'] = stripslashes($_POST['headline']);
			//slider
			$options['slider'] = stripslashes($_POST['slider']);
			//hotlist
			$options['hotlist'] = stripslashes($_POST['hotlist']);

			// banner
			if ($_POST['banner']) {
				$options['banner'] = (bool)true;
			} else {
				$options['banner'] = (bool)false;
			}
			$options['banner_content'] = stripslashes($_POST['banner_content']);

			// share
			if ($_POST['share']) {
				$options['share'] = (bool)true;
			} else {
				$options['share'] = (bool)false;
			}
			$options['share_content'] = stripslashes($_POST['share_content']);
			
			// head_right ads
			$options['footer_content'] = stripslashes($_POST['footer_content']);

			// share
			if ($_POST['single_ads']) {
				$options['single_ads'] = (bool)true;
			} else {
				$options['single_ads'] = (bool)false;
			}
			$options['single_ads_content'] = stripslashes($_POST['single_ads_content']);
			
			// head_right ads
			$options['footer_content'] = stripslashes($_POST['footer_content']);

			// analytics
			if ($_POST['analytics']) {
				$options['analytics'] = (bool)true;
			} else {
				$options['analytics'] = (bool)false;
			}
			$options['analytics_content'] = stripslashes($_POST['analytics_content']);

			update_option('zuluoCMS_options', $options);

		} else {
			zuluoCMSOptions::getOptions();
		}

		add_theme_page(__('Theme Options', 'zuluoCMS'), __('Theme Options', 'zuluoCMS'), 'edit_themes', basename(__FILE__), array('zuluoCMSOptions', 'display'));
	}

	function display() {
		$options = zuluoCMSOptions::getOptions();
?>

<style type="text/css">
/* Shows the same border as on front end */

small {
	color:#999;
}
hr{
	border:0;	
	border-bottom:1px solid #ddd;
	margin:-5px auto;
}
</style>

<form action="#" method="post" enctype="multipart/form-data" name="zuluoCMS_form" id="zuluoCMS_form">
	<div class="wrap">
		<h2><?php _e('Theme Options', 'zuluoCMS'); ?></h2>

		<h3><?php _e('Header Setup', 'zuluoCMS'); ?></h3><hr>

		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row">
						<?php _e('Notice', 'zuluoCMS'); ?>
						<br/>
						<small style="font-weight:normal;"><?php _e('HTML enabled', 'zuluoCMS'); ?></small>
					</th>
					<td>
						<div style="width:98%;">
							<div style="float:left;">
								<label>
									<input name="notice" type="checkbox" value="checkbox" <?php if($options['notice']) echo "checked='checked'"; ?> />
									 <?php _e('Show notice.', 'zuluoCMS'); ?>
								</label>
							</div>
							<div style="clear:both;"></div>
						</div>
						<label>
							<input type="text" name="notice_content" id="notice_content" class="code" size="70%" value="<?php echo($options['notice_content']); ?>">
						</label>
					</td>
				</tr>
			</tbody>
		</table>

		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row">
						<?php _e('Head Logo', 'zuluoCMS'); ?>
						<br/>
						<small style="font-weight:normal;"><?php _e('HTML enabled', 'zuluoCMS'); ?></small>
					</th>
					<td>
						<div style="width:98%;">
							<input type="text" name="head_logo" id="head_logo" class="code" size="70%" value="<?php echo($options['head_logo']); ?>">
						</div>
						<?php _e('Enter the URL of your Logo.', 'zuluoCMS'); ?>
					</td>
				</tr>
			</tbody>
		</table>

		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row">
						<?php _e('Head Ads', 'zuluoCMS'); ?>
						<br/>
						<small style="font-weight:normal;"><?php _e('HTML enabled', 'zuluoCMS'); ?></small>
					</th>
					<td>
						<div style="width:98%;">
							<input type="text" name="head_ads" id="head_ads" class="code" size="70%" value="<?php echo($options['head_ads']); ?>">
						</div>
						<?php _e('Enter the URL of the Ads picture.', 'zuluoCMS'); ?>
					</td>
				</tr>
			</tbody>
		</table>

		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row">
						<?php _e('Head Ads Link', 'zuluoCMS'); ?>
					</th>
					<td>
						<div style="width:98%;">
							<input type="text" name="head_ads_link" id="head_ads_link" class="code" size="70%" value="<?php echo($options['head_ads_link']); ?>">
						</div>
						<?php _e('Enter the Link URL.', 'zuluoCMS'); ?>
					</td>
				</tr>
			</tbody>
		</table>

		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row">
						<?php _e('Sidebar Banner', 'zuluoCMS'); ?>
						<br/>
						<small style="font-weight:normal;"><?php _e('HTML enabled', 'zuluoCMS'); ?></small>
					</th>
					<td>
						<!-- banner START -->						
						<div style="width:98%;">
							<div style="float:left;">
								<input name="banner" type="checkbox" value="checkbox" <?php if($options['banner']) echo "checked='checked'"; ?> />
									 <?php _e('Show banner.', 'zuluoCMS'); ?>
								&nbsp;&nbsp;&nbsp;
								<?php _e('This banner will display at the top of the sidebar.', 'zuluoCMS'); ?>
							</div>
							<div style="clear:both;"></div>
						</div>
						<label>
							<textarea name="banner_content" id="banner_content" cols="50" rows="6" style="width:98%;font-size:12px;" class="code"><?php echo($options['banner_content']); ?></textarea>
						</label>
						<!-- banner END -->
					</td>
				</tr>
			</tbody>
		</table>

		<h3><?php _e('Footer Content', 'zuluoCMS'); ?></h3><hr>

		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row">
						<?php _e('Footer Content', 'zuluoCMS'); ?>
						<br/>
						<small style="font-weight:normal;"><?php _e('HTML enabled', 'zuluoCMS'); ?></small>
					</th>
					<td>
						<label>
							<textarea name="footer_content" cols="50" rows="6" id="footer_content" class="code" style="width:98%;font-size:12px;"><?php echo($options['footer_content']); ?></textarea>
						</label>
					</td>
				</tr>
			</tbody>
		</table>
		
		<h3><?php _e('Hide Setup', 'zuluoCMS'); ?></h3><hr>

		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row"><br/>
						<?php _e('Index Hide Category', 'zuluoCMS'); ?>
						<br/>
						<small style="font-weight:normal;"><?php _e('Do not show as a module in index', 'zuluoCMS'); ?></small>
					</th>
					<td>
						<div style="width:98%;">
							<div style="float:left;">
								<label>
									<input name="hide" type="checkbox" value="checkbox" <?php if($options['hide']) echo "checked='checked'"; ?> />
									 <?php _e('Run Hide', 'zuluoCMS'); ?>
								</label>
							</div>
							<div style="clear:both;"></div>
						</div>
						<div style="width:98%;">
							<input type="text" name="index_hide" id="index_hide" class="code" size="70%" value="<?php echo($options['index_hide']); ?>">
						</div>
						<?php _e("Enter the category ID,use comma to split.", 'zuluoCMS'); ?>
					</td>
				</tr>
			</tbody>
		</table>

		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row">
						<?php _e('Sidebar Hide Category', 'zuluoCMS'); ?>
						<br/>
						<small style="font-weight:normal;"><?php _e('Do not show in sidebar', 'zuluoCMS'); ?></small>
					</th>
					<td>
						<div style="width:98%;">
							<input type="text" name="sidebar_hide" id="sidebar_hide" class="code" size="70%" value="<?php echo($options['sidebar_hide']); ?>">
						</div>
						<?php _e("Add a '-' before the category ID,use comma to split.", 'zuluoCMS'); ?>
					</td>
				</tr>
			</tbody>
		</table>

		<h3><?php _e('Hotnews Setup', 'zuluoCMS'); ?></h3><hr>

		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row"><br/>
						<?php _e('Headline', 'zuluoCMS'); ?>
						<br/>
						<small style="font-weight:normal;"><?php _e('The Headline in the Hotnews', 'zuluoCMS'); ?></small>
					</th>
					<td>
						<div style="width:98%;">
							<div style="float:left;">
								<label>
									<input name="hotnews" type="checkbox" value="checkbox" <?php if($options['hotnews']) echo "checked='checked'"; ?> />
									 <?php _e('Run Hotnews', 'zuluoCMS'); ?>
								</label>
							</div>
							<div style="clear:both;"></div>
						</div>
						<div style="width:98%;">
							<input type="text" name="headline" id="headline" class="code" size="70%" value="<?php echo($options['headline']); ?>">
						</div>
						<?php _e('Enter the post ID as a headline.', 'zuluoCMS'); ?>
					</td>
				</tr>
			</tbody>
		</table>

		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row">
						<?php _e('Slide Photo Show(five post id)', 'zuluoCMS'); ?>
						<br/>
						<small style="font-weight:normal;"><?php _e('Five hot photos slider', 'zuluoCMS'); ?></small>
					</th>
					<td>
						<div style="width:98%;">
							<input type="text" name="slider" id="slider" class="code" size="70%" value="<?php echo($options['slider']); ?>">
						</div>
						<?php _e('Enter five post ID as slider,use comma to split.', 'zuluoCMS'); ?>
					</td>
				</tr>
			</tbody>
		</table>

		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row">
						<?php _e('Hot List Show(five post id)', 'zuluoCMS'); ?>
						<br/>
						<small style="font-weight:normal;"><?php _e('Five hot list', 'zuluoCMS'); ?></small>
					</th>
					<td>
						<div style="width:98%;">
							<input type="text" name="hotlist" id="hotlist" class="code" size="70%" value="<?php echo($options['hotlist']); ?>">
						</div>
						<?php _e('Enter five post ID as hot list,use comma to split.', 'zuluoCMS'); ?>
					</td>
				</tr>
			</tbody>
		</table>

		<h3><?php _e('Share Tools Setup', 'zuluoCMS'); ?></h3><hr>

		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row">
						<?php _e('Share Tools', 'zuluoCMS'); ?>
						<br/>
						<small style="font-weight:normal;"><?php _e('HTML enabled', 'zuluoCMS'); ?></small>
					</th>
					<td>
						<label>
							<input name="share" type="checkbox" value="checkbox" <?php if($options['share']) echo "checked='checked'"; ?> />
							 <?php _e('Add share tools code to your site. (e.g. jiathis.com, ...)', 'zuluoCMS'); ?>
						</label>
						<label>
							<textarea name="share_content" cols="50" rows="6" id="share_content" class="code" style="width:98%;font-size:12px;"><?php echo($options['share_content']); ?></textarea>
						</label>
					</td>
				</tr>
			</tbody>
		</table>
		
		<h3><?php _e('Advertise Setup', 'zuluoCMS'); ?></h3><hr>

		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row">
						<?php _e('Single Advertise', 'zuluoCMS'); ?>
						<br/>
						<small style="font-weight:normal;"><?php _e('HTML enabled', 'zuluoCMS'); ?></small>
					</th>
					<td>
						<label>
							<input name="single_ads" type="checkbox" value="checkbox" <?php if($options['single_ads']) echo "checked='checked'"; ?> />
							 <?php _e('Add advertise code to your single page.', 'zuluoCMS'); ?>
						</label>
						<label>
							<textarea name="single_ads_content" cols="50" rows="6" id="single_ads_content" class="code" style="width:98%;font-size:12px;"><?php echo($options['single_ads_content']); ?></textarea>
						</label>
					</td>
				</tr>
			</tbody>
		</table>
		
		<h3><?php _e('Analytics Setup', 'zuluoCMS'); ?></h3><hr>

		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row">
						<?php _e('Web Analytics', 'zuluoCMS'); ?>
						<br/>
						<small style="font-weight:normal;"><?php _e('HTML enabled', 'zuluoCMS'); ?></small>
					</th>
					<td>
						<label>
							<input name="analytics" type="checkbox" value="checkbox" <?php if($options['analytics']) echo "checked='checked'"; ?> />
							 <?php _e('Add web analytics code to your site. (e.g. Google Analytics, Yahoo! Web Analytics, ...)', 'zuluoCMS'); ?>
						</label>
						<label>
							<textarea name="analytics_content" cols="50" rows="5" id="analytics_content" class="code" style="width:98%;font-size:12px;"><?php echo($options['analytics_content']); ?></textarea>
						</label>
					</td>
				</tr>
			</tbody>
		</table>


		<p class="submit">
			<input class="button-primary" type="submit" name="zuluoCMS_save" value="<?php _e('Save Changes', 'zuluoCMS'); ?>" />
		</p>
	</div>

</form>

<?php
	}
}

// Register functions
add_action('admin_menu', array('zuluoCMSOptions', 'add'));

/** l10n */
function theme_init(){
	load_theme_textdomain('zuluoCMS', get_template_directory() . '/languages');
}
add_action ('init', 'theme_init');

?>