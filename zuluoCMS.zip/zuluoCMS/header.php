<!DOCTYPE html>
<!--[if IE 6]>
<html id="ie6" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 7]>
<html id="ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html id="ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 6) | !(IE 7) | !(IE 8)  ]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<meta name="viewport" content="width=device-width" />
<title><?php
	/*
	 * Print the <title> tag based on what is being viewed.
	 */
	global $page, $paged;

	wp_title( '|', true, 'right' );

	// Add the blog name.
	bloginfo( 'name' );

	// Add the blog description for the home page.
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) )
		echo " | $site_description";

	?></title>
<?php
	$options = get_option('zuluoCMS_options');
	if (is_home() || is_page()) {
	    $description = get_bloginfo( 'description');
	    $keywords = get_bloginfo( 'description');
	}
	elseif (is_single()) {
	    $description1 = get_post_meta($post->ID, "description", true);
	    $description2 = mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 200, "…");	    
	    $description = $description1 ? $description1 : $description2;
	    $keywords = get_post_meta($post->ID, "keywords", true);
	    if($keywords == '') {
		$tags = wp_get_post_tags($post->ID);    
		foreach ($tags as $tag ) {        
		    $keywords = $keywords . $tag->name . ", ";    
		}
		$keywords = rtrim($keywords, ', ');
	    }
	}
	elseif (is_category()) {
	    $description = category_description();
	    $keywords = single_cat_title('', false);
	}
	elseif (is_tag()){
	    $description = tag_description();
	    $keywords = single_tag_title('', false);
	}
	$description = trim(strip_tags($description));
	$keywords = trim(strip_tags($keywords));
?>
<meta name="description" content="<?php echo $description; ?>" />
<meta name="keywords" content="<?php echo $keywords; ?>" />
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<?php
	if ( is_singular() && get_option( 'thread_comments' ) )
		wp_enqueue_script( 'comment-reply' );
	wp_head();
?>
</head>

<body <?php body_class(); ?>>
	<div id="header">
	
		<div id="topnavi">
			<?php 
				//show notice
				if($options['notice'] && $options['notice_content']) {
					echo '<span id="notice">'.$options['notice_content'].'</span>';
				}
			?>
			<?php
				//set top mebubar	
				wp_nav_menu(array('theme_location' => 'top_navi'));
			?>			
		</div>

		<div id="head">
			<div id="head_left">
				<a href="<?php	bloginfo( 'url' );	?>"><img src="<?php echo $options['head_logo']; ?>"></a>
			</div>
			<div id="head_right">
				<a href="<?php	echo $options['head_ads_link'];	?>"><img src="<?php echo $options['head_ads']; ?>"></a>
			</div>
			<div class="clear"></div>
		</div>

		<div id="navi">
			<ul>
				<?php
					wp_nav_menu(array('theme_location' => 'menu_navi',
						'link_before' => '<span>', 
						'link_after' =>	'</span>'));
				?>  
			</ul>
			<div id="searchform" >
				<form role="search" method="get" action="<?php echo home_url(); ?>" >
				<input type="text" value="" name="s" id="s" /><input type="submit" id="searchsubmit" value=" " />	
				</form>
			</div>
		</div>
		<div class="clear"></div>

	</div>	

