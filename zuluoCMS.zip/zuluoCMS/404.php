<?php get_header(); ?>

	<div id="wrap">
		
		<div id="content">

		<!--- Post Starts -->
			<div id="position">
				 <a href="<?php bloginfo( 'url' ); ?>"><?php bloginfo( 'name' ); ?></a> 
				 <?php the_category(',' , get_the_ID()); ?>
			</div>	
			
			<div id="post-<?php the_ID(); ?>" class="post">
			
				<h2><?php _e('404 Error: Not found.', 'zuluoCMS'); ?></h2>
				
				<div class="entry">
					<p><?php _e('The page you want does not exist,or be deleted,please try to search or you my like below articles:', 'zuluoCMS'); ?></p>
				
					<?php wp_reset_query(); ?> 
		
					<h2><?php _e('Latest Posts', 'zuluoCMS'); ?></h2><br/>
					<ul>
					
					<?php query_posts('post_type="post"&post_status="publish"&showposts=9'); ?>
					<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
							<li><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></li>
						<?php endwhile; ?>
						<?php endif; ?>
						<?php wp_reset_query(); ?> 
					</ul>
					
					<h2><?php _e('Pages', 'zuluoCMS'); ?></h2><br/>
					<ul>
						<?php wp_list_pages('title_li='); ?>
					</ul>
				</div>
				
			</div>
			
			<!--- Post Ends -->
			
		</div>
		
		<?php get_sidebar(); ?>
	</div>
	
<?php get_footer(); ?>