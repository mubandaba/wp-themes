<?php get_header(); ?>

	<div id="wrap">
		
		<div id="content">

			<div id="position">
				 <a href="<?php bloginfo( 'url' ); ?>"><?php bloginfo( 'name' ); ?></a> 
				 <?php the_title(); ?>
			</div>		
 		
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		
			<div id="page-<?php the_ID(); ?>" <?php post_class(); ?>>
				
				<h2><?php the_title(); ?></h2>
				<?php edit_post_link(__( 'Edit', 'zuluoCMS' )); ?>
				
				<div class="entry">
					<?php the_content(); ?>	
					<div class="clear"></div>
					<?php wp_link_pages(); ?>
				</div>
				
			</div>

		<?php endwhile; ?>

		<?php endif; ?>
		
		<?php comments_template(); ?>
		
		</div>
		
		<?php get_sidebar(); ?>
	</div>
	
<?php get_footer(); ?>	