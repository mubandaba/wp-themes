<?php get_header(); ?>

	<div id="wrap">
			
		<div id="content">

			<div id="position">
				 <a href="<?php bloginfo( 'site_url' ); ?>"><?php bloginfo( 'name' ); ?></a>
				 <?php the_category(' ' , get_the_ID()); ?><?php _e('Content', 'zuluoCMS'); ?>
			</div>
		
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>		
			<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>	

				<h2 class="single"><?php the_title(); ?></h2>
				<div class="postmeta postmeta_single">
					<span class="date"><a href="<?php the_permalink() ?>"><?php the_time(get_option('date_format')); ?></a> </span> 
					<span class="author">
					<?php
						//show the add field zuluo_from
						if ( get_post_meta($post->ID, 'zuluo_from', true) ) {
							echo get_post_meta($post->ID, 'zuluo_from', true);
						}
						else
							the_author();
					?> 
					</span> 
					<span class="folder"><?php the_category(', ') ?> </span> 
				</div>
				
				<div class="entry entry_single">
	<?php
        if (is_single() or is_page()) {
            the_content();
        } else {
            the_excerpt();
        } 
       ?>
					<?php wp_link_pages(); ?>
					
					<?php
						//show the add field zuluo_say
						if ( get_post_meta($post->ID, 'zuluo_say', true) ) {
							echo '<div id="zuluo_say">' . get_post_meta($post->ID, 'zuluo_say', true) . '</div>';
						}
					?>
					</p>
				</div>	

			</div>

<?php
		$options = get_option('zuluoCMS_options');
		if($options['share'])	{//show the share tools code		
?>	
			<div class="similarity">		
<?php	echo $options['share_content'];	?>		
			</div>
<?php	}	?>		

<?php
		//show the ads code in single.php, the ads shown on the top of sidebar
		if($options['single_ads'] && $options['single_ads_content']) :		
?>	
			<div class="single_ads">		
<?php	echo $options['single_ads_content'];	?>		
			</div>
			<div class="similarity" style="width: 310px; height: 228px; float: left; ">
<?php	else:	?>	
			<div class="similarity">
<?php	endif;	?>	
				<h2><?php _e('Related posts', 'zuluoCMS'); ?></h2>			
				<ul>
				<?php
				$post_tags = wp_get_post_tags($post->ID);
				if ($post_tags) {
				foreach ($post_tags as $tag) {
					// get the tag array
					$tag_list[] .= $tag->term_id;
				}

				// get one tag radon
				$post_tag = $tag_list[0];

				// use query_posts() to get related posts
				$args = array(
						'tag__in' => array($post_tag),
						'category__not_in' => array(NULL),
						'post__not_in' => array($post->ID),
						'showposts' => 9, 
						'caller_get_posts' => 1
					);
				query_posts($args);

				if (have_posts()) : 
					while (have_posts()) : the_post(); update_post_caches($posts); 
				?>
				<li><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></li>
				<?php endwhile; else : ?>
					<li><?php _e('No related posts', 'zuluoCMS'); ?></li>
				<?php endif; wp_reset_query(); } ?>
				</ul>
			</div>
<div class="clear"></div>			
		<?php endwhile; ?>

		<?php endif; ?>
			
		<?php comments_template(); ?>
		
		</div>
		
		<?php get_sidebar(); ?>
	</div>
	
<?php get_footer(); ?>	