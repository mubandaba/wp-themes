	<div id="footer">
		<div id="foot">
<?php
	$options = get_option('zuluoCMS_options');
	if($options['footer_content']) //show the bottom html
		echo $options['footer_content'];
?>			

<?php
	$options = get_option('zuluoCMS_options');
	if($options['analytics']) //show the analyse code
		echo $options['analytics_content'];
?>
		</div>
	</div>
</div>

<?php wp_footer(); ?>

</body>
</html>