<?php 
	//load theme setup function
	require_once(TEMPLATEPATH . '/theme_setup.php');

	add_theme_support('post-thumbnails');

	if (function_exists('register_nav_menus')) {
		register_nav_menus( array( 'top_navi' => __('Top Menubar', 'zuluoCMS') ) );
		register_nav_menus( array( 'menu_navi' => __('Main Menubar', 'zuluoCMS') ) );
	} 

	if ( function_exists('register_sidebar') ) {
		register_sidebar( array(
			'name' => __( 'Sidebar Home', 'zuluoCMS' ),
			'id' => 'sidebar-home',
			'description' => __( 'The sidebaer in home', 'zuluoCMS' ),
			'before_widget' => '<li>',
			'after_widget' => '</li>',
			'before_title' => '<h2>',
			'after_title' => '</h2>',
		) );
		register_sidebar( array(
			'name' => __( 'Sidebar Category', 'zuluoCMS' ),
			'id' => 'sidebar-category',
			'description' => __( 'The sidebaer in category', 'zuluoCMS' ),
			'before_widget' => '<li>',
			'after_widget' => '</li>',
			'before_title' => '<h2>',
			'after_title' => '</h2>',
		) );
		register_sidebar( array(
			'name' => __( 'Sidebar Single', 'zuluoCMS' ),
			'id' => 'sidebar-single',
			'description' => __( 'The sidebaer in single', 'zuluoCMS' ),
			'before_widget' => '<li>',
			'after_widget' => '</li>',
			'before_title' => '<h2>',
			'after_title' => '</h2>',
		) );
	}

function cut_str($sourcestr,$cutlength)
{
	$returnstr='';
	$i=0;
	$n=0;
	$str_length=strlen($sourcestr);
	while (($n<$cutlength) and ($i<=$str_length))
	{
		$temp_str=substr($sourcestr,$i,1);
		$ascnum=Ord($temp_str);
		if ($ascnum>=224)
		{
			$returnstr=$returnstr.substr($sourcestr,$i,3);
			$i=$i+3;
			$n++;
		}
		elseif ($ascnum>=192)
		{
			$returnstr=$returnstr.substr($sourcestr,$i,2);
			$i=$i+2;
			$n++;
		}
		elseif ($ascnum>=65 && $ascnum<=90)
		{
			$returnstr=$returnstr.substr($sourcestr,$i,1);
			$i=$i+1;
			$n++;
		}
		else
		{
			$returnstr=$returnstr.substr($sourcestr,$i,1);
			$i=$i+1;
			$n=$n+0.5;
		}
	}
	if ($str_length>$cutlength){
		$returnstr = $returnstr . "";
	}
	return $returnstr;
}

//get the first photo in content as thumb.
function get_the_thumb($id) {
	$post=get_post($id);
	$first_img = '';

	//if set the thumbnail, then get the photo url and return
	if ( has_post_thumbnail($id) ) {
		$imgstr = explode('src="', get_the_post_thumbnail($id));
		$img = explode('"', $imgstr[1]);
		$first_img = $img[0];
	} 
	else {//get the first photo in content
		$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches); 
		$first_img = $matches[1][0];
		if ($first_img=='') {
			$tags=get_the_tags($post->ID);
			if($tags) {
				foreach($tags as $tag) {
					$first_img =site_url().'/thumb/'.$tag->name.'.gif';
				}
			}
			else
				$first_img =site_url()."/nopic_small.gif";
		}
	}
	return $first_img;
}
	
?>