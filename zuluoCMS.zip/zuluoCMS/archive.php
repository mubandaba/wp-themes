<?php get_header(); ?>

	<div id="wrap">
			
		<div id="content">

			<div id="position">
				 <a href="<?php bloginfo( 'url' ); ?>"><?php bloginfo( 'name' ); ?></a> 
				 <?php the_category(',' , get_the_ID()); ?>
			</div>		
 
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>		
			<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>	

				<h2><a href="<?php the_permalink() ?>" rel="bookmark" target="_blank"><?php the_title(); ?></a></h2>
				<div class="postmeta">

				</div>
		<?php
			echo '<a href="';
			the_permalink();
			echo '" rel="bookmark" target="_blank">';
			echo '<img class=list src="'.get_the_thumb($post->ID).'">';
			echo '</a>';
       ?>						
				<div class="entry entry_list">
	<?php
        if (is_single() or is_page()) {
            the_content();
        } else {
            the_excerpt();
        } 
       ?>
					<?php wp_link_pages(); ?>
				</div>
				
				<div class="postinfo">
					<span class="date"><a href="<?php the_permalink() ?>"><?php the_time(get_option('date_format')); ?></a> </span>
					<span class="author"><?php the_author(); ?> </span>
					<span class="folder"><?php the_category(', ') ?> </span>
					<?php if (get_the_tags()) echo'<span class="tag">'; the_tags('', ', '); echo '</span>'; ?>
					<span class="comment"><a href="<?php the_permalink() ?>#comments"><?php comments_number(__('No comments', 'zuluoCMS'),__('One comment','zuluoCMS'),__('% comments','zuluoCMS')); ?></a></span>					
					<?php edit_post_link(__( 'Edit', 'zuluoCMS' ), ' | '); ?>
				</div>
				<span class='more-link'><a href="<?php the_permalink() ?>"><?php _e('More···', 'zuluoCMS'); ?></a></span>

			</div>

		<?php endwhile; ?>
			
			<?php if(function_exists('wp_pagenavi')) { // if PageNavi is activated ?>
				<div class="more_posts">
					<?php wp_pagenavi(); ?>
				</div>
			<?php } else { // Otherwise, use traditional Navigation ?>
				<div class="more_posts">
					<span class="post_links"><?php next_posts_link(__('&laquo; Older Entries', 'zuluoCMS')) ?> &nbsp; <?php previous_posts_link (__('Recent Entries &raquo;', 'zuluoCMS')) ?></span>
				</div>
			<?php }?>

		<?php endif; ?>

		</div>

		<?php get_sidebar(); ?>

	</div>	
<?php get_footer(); ?>	