<?php
	if(is_home()):		
?>
<div id="sidebar_index">
<?php
	else:		
?>
<div id="sidebar">
<?php
	endif;		
?>
<ul>
<?php
	$options = get_option('zuluoCMS_options');
	if($options['banner']) //show the right banner on the top of sidebar
	{	echo $options['banner_content'];	}
?>
<?php 
	if (function_exists('dynamic_sidebar')){
		if(is_home()){	
			if(!dynamic_sidebar('sidebar-home')) {	
				mysidebar();	
			}
		}
		elseif(is_category()||is_archive()){
			if(!dynamic_sidebar('sidebar-category')) {
				mysidebar();
			}	
		}
		elseif(is_single()||is_page()){
			if(!dynamic_sidebar('sidebar-single')) {
				mysidebar();
			}
		}
		else {	
			if(!dynamic_sidebar('sidebar-home')) {	
				mysidebar();	
			}
		}
	}
	else {
		mysidebar();
	}
?>

<?php
function mysidebar() {
?>

	<li><h2><?php _e('Latest Posts', 'zuluoCMS'); ?></h2>
		<?php query_posts( array( 'post__not_in' => get_option( 'sticky_posts' ), 'cat' =>$options['sidebar_hide'], 'showposts' =>'6' ) );  ?>
		<ul>   
			<?php while (have_posts()) : the_post(); ?>  
				<li class="li_pic">
					<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" target="_blank">
					<img src="<?php echo get_the_thumb($post->ID); ?>">
					<p><?php the_title(); ?></p></a>
				</li>   
		<?php 
			endwhile;
			// Reset Query
			wp_reset_query();			
		?>   
		</ul> 
	</li>

	<li><h2><?php _e('Hotest posts', 'zuluoCMS'); ?></h2>
	<ul> 
	<?php 
		query_posts( array( 'post__not_in' => get_option( 'sticky_posts' ), 'orderby' => 'comment_count' , 'order' =>'DESC' , 'showposts' =>'6' ) );
		while (have_posts()) : the_post(); 
	?>
		<li class="li_pic">
			<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
			<img src="<?php echo get_the_thumb($post->ID); ?>">
			<p><?php the_title(); ?></p></a>
		</li>   
	<?php 
		endwhile;
		// Reset Query
		wp_reset_query();			
	?>   
	</ul>
	</li>
	
<?php } ?>

</ul>
</div>