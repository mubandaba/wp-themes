<?php get_header(); ?>

	<div id="wrap_index">
			
		<div id="content_index">
<?php
$options = get_option('zuluoCMS_options');
if($options['hotnews']) ://show the hotnews block
	//show the headline option
	$headline = $options['headline'];

	if ($headline) :
		$headline_post = get_post($headline);
		$img[]	=	get_the_thumb($headline); 
		$title[]	=	cut_str(strip_tags(apply_filters('the_title', $headline_post->post_title)), 22);
		$links[]	=	get_permalink($headline);	
		$description[]	=	cut_str(strip_tags(apply_filters('the_excerpt', $headline_post->post_excerpt)), 60);	
	else :
		$img[]	=	get_the_thumb(get_the_ID()); 
		$title[]	=	cut_str(strip_tags(apply_filters('the_title', get_the_title())), 22);
		$links[]	=	get_permalink(get_the_ID());	
		$description[]	=	cut_str(strip_tags(apply_filters('the_excerpt', get_the_excerpt())), 60);
	endif;

	if ($options['slider']) :
		//show the slider option
		$slider = explode(',', $options['slider']);
		foreach ( $slider as  $slider_ID) {
			$slide_post = get_post($slider_ID);
			$img[]	=	get_the_thumb($slider_ID); 
			$title[]	=	cut_str(strip_tags(apply_filters('the_title', $slide_post->post_title)), 22);
			$links[]	=	get_permalink($slider_ID);	
			$description[]	=	cut_str(strip_tags(apply_filters('the_excerpt', $slide_post->post_excerpt)), 60);
		}
	else:
		query_posts('showposts=5');
		while (have_posts()) : the_post();
			$img[]	=	get_the_thumb(get_the_ID()); 
			$title[]	=	cut_str(strip_tags(apply_filters('the_title', get_the_title())), 22);
			$links[]	=	get_permalink(get_the_ID());	
			$description[]	=	cut_str(strip_tags(apply_filters('the_excerpt', get_the_excerpt())), 60);
		endwhile;
		// Reset Query
		wp_reset_query();
	endif;

	if ($options['hotlist']) :
		//show the hot lists
		$hotlist = explode(',', $options['hotlist']);		
		foreach ( $hotlist as  $hot_ID) {
			$hot_post = get_post($hot_ID);
			$img[]	=	get_the_thumb($hot_ID); 
			$title[]	=	cut_str(strip_tags(apply_filters('the_title', $hot_post->post_title)), 22);
			$links[]	=	get_permalink($hot_ID);	
			$description[]	=	cut_str(strip_tags(apply_filters('the_excerpt', $hot_post->post_excerpt)), 60);
		}
	else:
		query_posts('showposts=7');
		while (have_posts()) : the_post();
			$img[]	=	get_the_thumb(get_the_ID()); 
			$title[]	=	cut_str(strip_tags(apply_filters('the_title', get_the_title())), 22);
			$links[]	=	get_permalink(get_the_ID());	
			$description[]	=	cut_str(strip_tags(apply_filters('the_excerpt', get_the_excerpt())), 60);
		endwhile;
		// Reset Query
		wp_reset_query();
	endif;
?>
			<div id="hotshow" class="radius">
				<div id="slide">
<script type="text/javascript">
//<![CDATA[
var interval_time=0;
var focus_width=320;
var focus_height=210;
var text_height=24;
var text_align="center";
var swf_height=focus_height+text_height;
var pics="<?php echo $img[1]; ?>|<?php echo $img[2]; ?>|<?php echo $img[3]; ?>|<?php echo $img[4]; ?>|<?php echo $img[5]; ?>";
var links="<?php echo $links[1]; ?>|<?php echo $links[2]; ?>|<?php echo $links[3]; ?>|<?php echo $links[4]; ?>|<?php echo $links[5]; ?>";
var texts="<?php echo $title[1]; ?>|<?php echo $title[2]; ?>|<?php echo $title[3]; ?>|<?php echo $title[4]; ?>|<?php echo $title[5]; ?>";
document.write('<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" width="'+ focus_width +'" height="'+ swf_height +'">');
document.write('<param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="<?php bloginfo( 'template_url' ); ?>/images/focus.swf" /><param name="quality" value="high" /><param name="bgcolor" value="#F0F0F0">');
document.write('<param name="menu" value="false"><param name=wmode value="opaque">');
document.write('<param name="FlashVars" value="pics='+pics+'&links='+links+'&texts='+texts+'&borderwidth='+focus_width+'&borderheight='+focus_height+'&textheight='+text_height+'">');
document.write('<embed src="<?php bloginfo( 'template_url' ); ?>/images/focus.swf" wmode="opaque" FlashVars="pics='+pics+'&links='+links+'&texts='+texts+'&borderwidth='+focus_width+'&borderheight='+focus_height+'&textheight='+text_height+'" menu="false" bgcolor="#F0F0F0" quality="high" width="'+ focus_width +'" height="'+ swf_height +'" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />');
document.write('</object>');
//]]>
</script>
				</div>
				<div id="hotnews">	
					<h2><a href="<?php echo $links[0]; ?>" rel="bookmark" target="_blank"><?php echo $title[0]; ?></a></h2>
					<p><?php echo $description[0]; ?>…</p>	
					<ul>
						<li><a href="<?php echo $links[6]; ?>" rel="bookmark" target="_blank"><?php echo $title[6]; ?></a></li>
						<li><a href="<?php echo $links[7]; ?>" rel="bookmark" target="_blank"><?php echo $title[7]; ?></a></li>
						<li><a href="<?php echo $links[8]; ?>" rel="bookmark" target="_blank"><?php echo $title[8]; ?></a></li>
						<li><a href="<?php echo $links[9]; ?>" rel="bookmark" target="_blank"><?php echo $title[9]; ?></a></li>
						<li><a href="<?php echo $links[10]; ?>" rel="bookmark" target="_blank"><?php echo $title[10]; ?></a></li>
						<li><a href="<?php echo $links[11]; ?>" rel="bookmark" target="_blank"><?php echo $title[9]; ?></a></li>
					</ul>
				</div>
			</div>	
<?php endif; ?>

<?php
			//get the hide category in home page,exclude it in the query.
			$index_hide = $options['index_hide'];
			$cat_style='cat_left';//是否左边div
			foreach(get_categories('exclude='.$index_hide.'&orderby=slug&order=ASC') as $category) {//cat_ID cat_name				
?>
			<div id="post-<?php echo $category->cat_ID; ?>" class="<?php echo $cat_style; ?> radius">			
				<h2><?php echo $category->cat_name; ?><a href="<?php echo get_category_link($category->cat_ID); ?>"><span></span></a></h2>
				<ul>
<?php
					query_posts('showposts=6&cat='.$category->cat_ID);
					$is_first=1;//the first aritcle show photo,others show in the list.
					while (have_posts()) : the_post();	
						if($is_first==1):
							echo "<h3>". '<a href="'.get_permalink().'" target="_blank">' . cut_str(strip_tags(apply_filters('the_title', $post->post_title)), 28) . "</a></h3>"; 
							echo '<a href="';
							the_permalink();
							echo '" rel="bookmark" target="_blank">';
							echo '<img class=list src="'.get_the_thumb($post->ID).'">';
							echo '</a>';
							echo "<p>". cut_str(strip_tags(apply_filters('the_excerpt', $post->post_excerpt)), 55) . "…</p>";
							$is_first=0;
						else:												
?>
					<li><a href="<?php the_permalink(); ?>" rel="bookmark" target="_blank"><?php echo cut_str(strip_tags(apply_filters('the_title', $post->post_title)), 28); ?></a></li>
<?php
						endif;	
					endwhile;
					// Reset Query
					wp_reset_query();
?>
				</ul>
			</div>
<?php	
				if ($cat_style=='cat_left'):
					$cat_style='cat_right';
				else:
					$cat_style='cat_left';
				endif;
			} 
?>
		</div>

		<?php get_sidebar(); ?>

	</div>	
<?php get_footer(); ?>	