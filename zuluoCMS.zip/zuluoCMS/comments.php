<?php 
	
	// Do not delete these lines
	if (!empty($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
		die (__('Please do not load this page directly. Thanks!', 'zuluoCMS'));

	if ( post_password_required()) { ?>
		<p><?php _e('Enter password to view comments.', 'zuluoCMS'); ?></p>
	<?php return; } ?>
	
<?php if ( comments_open() ) : ?>
	<?php comment_form(array('comment_notes_after' => '')); ?>
	<div class="clear"></div>
<?php endif; ?>

<?php if ( have_comments() ) : ?>

<div id="comments">
	<?php if ( get_comment_pages_count() > 1 ) : ?>
	<div class="commentnavi">
		<?php paginate_comments_links(); ?>
	</div>
	<div class="clear"></div>
	<?php endif; ?>
	
	<ol class="commentlist">
	<?php wp_list_comments(array('avatar_size' => 32)); ?>
	</ol>

	<?php if ( get_comment_pages_count() > 1 ) : ?>
	<div class="commentnavi">
		<?php paginate_comments_links(); ?>
	</div>
	<div class="clear"></div>
	<?php endif; ?>
</div>
 <?php else : ?>

	<?php if ( ! comments_open() and !is_page() ) : ?>
		<p class="nocomments"><?php _e('Comments are closed.', 'zuluoCMS'); ?></p>
	<?php endif; ?>
<?php endif; ?>
