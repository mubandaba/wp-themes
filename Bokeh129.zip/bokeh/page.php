<?php 
get_header(); 
?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<article class="post">
    <header class="entry-header">
		<h2 class="entry-name">
			<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
		</h2>
		<div class="post-meta">
			<span><?php the_time('d,m,Y');?></span>
			<span><?php the_category(','); ?></span>
			<span><?php mzw_post_views(' views');?></span>
			<span><i class="single-love-count"><?php if( get_post_meta($post->ID,'mzw_ding',true) ){
						$love_num =  get_post_meta($post->ID,'mzw_ding',true);
						$love_num = intval($love_num);
						echo $love_num.'</i>';
						if($love_num > 1) {echo ' likes';}else{echo ' like';}
					 } else {
						echo '0</i> like';
					 }?></span>
		</div>
    </header>
    <div class="entry-content" itemprop="description">
        <?php the_content();; ?>
    </div>
	<footer class="entry-footer clearfix">
		<span class="left"><?php if ( get_the_tags() ) { echo '#'; the_tags('', '  #', ' ');}?></span>
		<ul class="entry-meta right">
			<li class="post-love">
			<a href="javascript:;" data-action="ding" data-id="<?php the_ID(); ?>" class="favorite post-love-link <?php if(isset($_COOKIE['mzw_ding_'.$post->ID])) echo ' done';?>" title="Like it"><i class="fa fa-heart-o"></i> 
			</a></li>
			<li class="post-share single-post-share">
				<a class="share-btn" href="javascript:;" title="Share"><i class="fa fa-share-alt"></i></a>
				<ul class="share-list">
				<li><a href="http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=<?php the_permalink(); ?>&title=<?php the_title(); ?>" target="_blank"><i class="fa fa-qq"></i></a></li>
				<li><a href="http://service.weibo.com/share/share.php?title=<?php the_title(); ?>&url=<?php the_permalink(); ?>" target="_blank"><i class="fa fa-weibo"></i></a></li>
				<li><a href="http://share.renren.com/share/buttonshare?link=<?php the_permalink(); ?>&title=<?php the_title(); ?>" target="_blank"><i class="fa fa-renren"></i></a></li>
				<li><a href="http://twitter.com/share?url=<?php the_permalink(); ?>&text=<?php the_title(); ?>" target="_blank"><i class="fa fa-twitter"></i></a></li>
				</ul>

			</li>
		</ul>
	</footer>
</article>

<?php comments_template('', true); ?>
	
<?php endwhile; endif;?>
<?php get_footer(); ?>