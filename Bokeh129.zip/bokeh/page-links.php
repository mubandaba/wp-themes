<?php 
/*
Template Name: 友情链接模板
*/
get_header(); 
?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<article class="post">
	<header class="entry-header">
		<h2 class="entry-name">
			<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
		</h2>
	</header>
	<div class="clearfix" itemprop="description">
		<?php 
		$bookmarks = get_bookmarks();

		if ( !empty($bookmarks) ){
			echo '<ul class="link-content clearfix">';
			foreach ($bookmarks as $bookmark) {
				echo '<li><a href="' . $bookmark->link_url . '" title="' . $bookmark->link_description . '" target="_blank" >'. $bookmark->link_name .'</a></li>';
			}
			echo '</ul>';
		}
		?>
    </div>
	<footer class="entry-footer clearfix">
		<span class="left"><?php if ( get_the_tags() ) { echo '#'; the_tags('', '  #', ' ');}?></span>
		<ul class="entry-meta right">
			<li class="post-love">
			<a href="javascript:;" data-action="ding" data-id="<?php the_ID(); ?>" class="favorite post-love-link <?php if(isset($_COOKIE['mzw_ding_'.$post->ID])) echo ' done';?>" title="Like it"><i class="fa fa-heart-o"></i> 
			</a></li>
			<li class="post-share single-post-share">
				<a class="share-btn" href="javascript:;" title="Share"><i class="fa fa-share-alt"></i></a>
				<ul class="share-list">
				<li><a href="http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=<?php the_permalink(); ?>&title=<?php the_title(); ?>" target="_blank"><i class="fa fa-qq"></i></a></li>
				<li><a href="http://service.weibo.com/share/share.php?title=<?php the_title(); ?>&url=<?php the_permalink(); ?>" target="_blank"><i class="fa fa-weibo"></i></a></li>
				<li><a href="http://share.renren.com/share/buttonshare?link=<?php the_permalink(); ?>&title=<?php the_title(); ?>" target="_blank"><i class="fa fa-renren"></i></a></li>
				<li><a href="http://twitter.com/share?url=<?php the_permalink(); ?>&text=<?php the_title(); ?>" target="_blank"><i class="fa fa-twitter"></i></a></li>
				</ul>

			</li>
		</ul>
	</footer>
</article>
	
<?php endwhile; endif;?>
<?php get_footer(); ?>