<?php get_header(); ?>

<?php if( have_posts() ){  ?>

<div class="archive-meta">
	<h3 class="title-meta"><?php echo $s; ?></h3>
	<div class="blockDivider "><span class="blockDivider-name"><?php _e('Search Result', 'bokeh' );?></span></div>
</div>

<?php 
	while ( have_posts() ){
			the_post(); 
			get_template_part( 'inc/post-format/content', get_post_format() );
		}
	} else {
?>
<div class="archive-meta">
	<h3 class="title-meta"><?php echo $s; ?></h3>
	<div class="blockDivider "><span class="blockDivider-name"><?php _e('Search Result', 'bokeh' );?></span></div>
	<div class="desc-meta"><p><?php _e('Apologies, but no results were found.', 'bokeh')?></p></div>
</div>
<?php } ?>
<?php ajax_show_more_button();?>
<?php get_footer(); ?>