<?php 
get_header(); 
?>

<article class="post">
    <header class="entry-header">
		<h2 class="entry-name">
			<?php _e("404. That's an error.", 'bokeh');?>
		</h2>
	</header>
	<div class="entry-content" itemprop="description" style="min-height: 300px;">
		<?php _e("The requested URL was not found on this server. That’s all we know.", 'bokeh'); ?>
	</div>
</article>

<?php get_footer(); ?>