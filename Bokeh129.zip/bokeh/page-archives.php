<?php 
/*
Template Name: 归档页面
*/

get_header(); 

?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<?php if(!is_mobile()) {?>
<article class="post">
	<header class="entry-header">
		<h2 class="entry-name">
			<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
		</h2>
	</header>
    <div class="clearfix" itemprop="description">
        <div class="archives">
        <?php
        $previous_year = $year = 0;
        $previous_month = $month = 0;
        $ul_open = false;

        $myposts = get_posts('numberposts=-1&orderby=post_date&order=DESC');

        foreach($myposts as $post) :
            setup_postdata($post);

            $year = mysql2date('Y', $post->post_date);
            $month = mysql2date('n', $post->post_date);
            $day = mysql2date('j', $post->post_date);

            if($year != $previous_year || $month != $previous_month) :
                if($ul_open == true) : 
                    echo '</ul>';
                endif;

                echo '<h3 class="m-title">'; echo the_time('Y-m'); echo '</h3>';
                echo '<ul class="archives-monthlisting">';
                $ul_open = true;

            endif;

            $previous_year = $year; $previous_month = $month;
        ?>
            <li>
                 <a href="<?php the_permalink(); ?>"><span><?php the_time('Y-m-j'); ?></span>
               <div class="atitle"><?php the_title(); ?></div></a>

            </li>
        <?php endforeach; ?>
        </ul>
    </div>
    </div>
</article>
<?php } else { ?>
	<article class="post"><ol class="mobile-archive">
	<?php
		$myposts = get_posts('numberposts=-1&orderby=post_date&order=DESC');
        foreach($myposts as $post) :
		 ?>
		<li>
			<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		</li>
        <?php endforeach; ?>
	</ol></article>

<?php } ?>
<?php endwhile; endif;?>

<?php get_footer(); ?>