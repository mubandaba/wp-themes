	</section>
	<footer id="footer">
		<p><?php echo dopt('d_notice_bottom');?></p>
	</footer>
	<div id="search-full">
		<div class="container">
			<form id="search-form" method="get" action="<?php echo get_bloginfo ('url'); ?>">
				<input id="search-field" type="text" name="s" value="" placeholder="<?php _e('Type something to search then hit Enter...', 'bokeh');?>">
			</form>
			<p><a id="close-search"><i class="fa fa-times"></i><?php _e('Close', 'bokeh');?></a></p>
		</div>
	</div>
	<a id="gotop" href="javascript:;"><i class="fa fa-arrow-up"></i></a>
<?php
if( dopt('d_track_b') != '' ) echo dopt('d_track');
if( dopt('d_footcode_b') != '' ) echo dopt('d_footcode');
if(!is_mobile() && dopt('d_sidebar_b')) {
	get_sidebar(); 
}
wp_footer();?>  
</body>
</html>