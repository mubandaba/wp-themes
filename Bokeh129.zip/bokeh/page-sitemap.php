<?php 
/*
Template Name: 网站地图
*/

get_header(); 

?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<article class="post">
	<header class="entry-header">
		<h2 class="entry-name">
			<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
		</h2>
	</header>
	<div class="clearfix" itemprop="description">
		<div class="archives-content clearfix">
			<div class="ordered-list">
				<h3><span><?php _e('Latest posts', 'bokeh');?></span></h3>
				<ol>
				<?php
					$myposts = get_posts('numberposts=20&orderby=post_date&order=DESC');

					foreach($myposts as $post) :
						setup_postdata($post);
				?>
					<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
				<?php
					endforeach;
				?>
				</ol>
			</div>

			<div class="ordered-list">
				<h3><span><?php _e('All Categories', 'bokeh');?></span></h3>
				<ul>
				<?php
					$terms = get_terms('category', 'orderby=name&hide_empty=0' );
					$count = count($terms);
					if($count > 0){
						foreach ($terms as $term) {
							echo '<li><a href="'.get_term_link($term, $term->slug).'" title="'.$term->name.'">'.$term->name.'</a></li>';
						}
					}
				?>
				</ul>
			</div>

			<div class="ordered-list">
				<h3><span><?php _e('All pages', 'bokeh');?></span></h3>
				<ul>
				<?php
					$myposts = get_posts('numberposts=-1&orderby=post_date&order=DESC&post_type=page');

					foreach($myposts as $post) :
						setup_postdata($post);
				?>
					<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
				<?php
					endforeach;
				?>                      
				</ul>
			</div>
		</div>
	</div>
</article>
	
<?php endwhile; endif;?>
<?php get_footer(); ?>