<article class="post">
    <header class="entry-header">
		<h2 class="entry-name">
			<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
		</h2>
		<div class="post-meta">
			<span><?php the_time('d,m,Y');?></span>
			<span><?php the_category(','); ?></span>
			<span><?php mzw_post_views(' views');?></span>
			<span><i class="single-love-count"><?php if( get_post_meta($post->ID,'mzw_ding',true) ){
						$love_num =  get_post_meta($post->ID,'mzw_ding',true);
						$love_num = intval($love_num);
						echo $love_num.'</i>';
						if($love_num > 1) {echo ' likes';}else{echo ' like';}
					 } else {
						echo '0</i> like';
					 }?></span>
		</div>
    </header>
    <div class="entry-content clearfix" itemprop="description">
        <?php the_content(); ?>
    </div>
	<footer class="entry-footer clearfix">
		<span class="left"><?php if ( get_the_tags() ) { echo '#'; the_tags('', '  #', ' ');}?></span>
		<ul class="entry-meta right">
			<li class="post-love">
			<a href="javascript:;" data-action="ding" data-id="<?php the_ID(); ?>" class="favorite post-love-link <?php if(isset($_COOKIE['mzw_ding_'.$post->ID])) echo ' done';?>" title="Like it"><i class="fa fa-heart-o"></i> 
			</a></li>
			<li class="post-share single-post-share">
				<a class="share-btn" href="javascript:;" title="Share"><i class="fa fa-share-alt"></i></a>
				<ul class="share-list">
				<li><a href="http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=<?php the_permalink(); ?>&title=<?php the_title(); ?>" target="_blank"><i class="fa fa-qq"></i></a></li>
				<li><a href="http://service.weibo.com/share/share.php?title=<?php the_title(); ?>&url=<?php the_permalink(); ?>" target="_blank"><i class="fa fa-weibo"></i></a></li>
				<li><a href="http://share.renren.com/share/buttonshare?link=<?php the_permalink(); ?>&title=<?php the_title(); ?>" target="_blank"><i class="fa fa-renren"></i></a></li>
				<li><a href="http://twitter.com/share?url=<?php the_permalink(); ?>&text=<?php the_title(); ?>" target="_blank"><i class="fa fa-twitter"></i></a></li>
				</ul>

			</li>
		</ul>
	</footer>
	<nav class="nav-prev-next">
		<?php if (get_previous_post()) {mzw_prev_post_link('%link'); }?>
		<?php if (get_previous_post()) {mzw_next_post_link('%link'); }?>
	</nav>
</article>

<div class="post-author">
	<div class="post-author-avatar"><?php echo get_avatar( get_the_author_email(), $size = '90' , '' );?></div>
	<h6 class="post-author-name"><?php the_author(); ?></h6>
	<p class="post-author-bio"><?php the_author_description(); ?></p>
	<?php if( dopt('d_sns_open') ) {
			echo '<p class="post-author-social">';
			if( dopt('d_rss_b') ) echo '<a class="rss" href="'.dopt('d_rss').'"><i class="fa fa-rss"></i></a>';
			if( dopt('d_mail_b') ) echo '<a class="mail" href="'.dopt('d_mail').'"><i class="fa fa-envelope"></i></a>';
			if( dopt('d_rss_sina_b') ) echo '<a class="weibo" href="'.dopt('d_rss_sina').'"><i class="fa fa-weibo"></i></a>';
			if( dopt('d_rss_twitter_b') ) echo '<a class="twitter" href="'.dopt('d_rss_twitter').'"><i class="fa fa-twitter"></i></a>';
			if( dopt('d_rss_google_b') ) echo '<a class="google" href="'.dopt('d_rss_google').'"><i class="fa fa-google-plus "></i></a>';
			if( dopt('d_rss_facebook_b') ) echo '<a class="facebook" href="'.dopt('d_rss_facebook').'"><i class="fa fa-facebook"></i></a>';
			if( dopt('d_rss_github_b') ) echo '<a class="github" href="'.dopt('d_rss_github').'"><i class="fa fa-github"></i></a>';
			if( dopt('d_rss_tencent_b') ) echo '<a class="tweibo" href="'.dopt('d_rss_tencent').'"><i class="fa fa-tencent-weibo"></i></a>';
			if( dopt('d_rss_linkedin_b') ) echo '<a class="linkedin" href="'.dopt('d_rss_linkedin').'"><i class="fa fa-linkedin"></i></a>';
			//if( dopt('d_rss_b') ) echo '<a class="weixin" href="'.dopt('d_rss').'"><i class="fa fa-weixin"></i></a>';
			echo '</p>';
		}
		?>
</div>

<?php include_once('relatedpost.php')?>

<?php comments_template('', true); ?>