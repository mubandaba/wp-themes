<figure class="effect-layla">
	<img src="<?php
	$big_img_url = get_post_meta($post->ID, 'big_img_url', true);
	if($big_img_url != '')
		echo $big_img_url;
	else {
		$timthumb_src = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'imaj' ); 
		echo $timthumb_src[0]; 
	}
		?>" alt="<?php the_title(); ?>">
	<figcaption>
		<h2><?php the_title(); ?></h2>
		<p><?php echo strip_tags(get_the_excerpt());?></p>
		<a href="<?php the_permalink(); ?>">View more</a>
	</figcaption>
</figure>