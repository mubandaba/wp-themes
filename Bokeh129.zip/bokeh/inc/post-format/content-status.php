<article class="status">
	<div class="quote"><i class="fa fa-quote-left"></i>
        <?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 400,"……"); ?>
    </div>
</article>