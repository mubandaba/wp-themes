<article class="audio">
	<?php the_content('');?>
</article>