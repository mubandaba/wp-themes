<!DOCTYPE html>
<html lang="zh-CN" <?php if( dopt('d_autospace_b') != '' ) echo 'class="han-la"';?>>
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="initial-scale=1.0,user-scalable=no,minimal-ui" />
	<meta http-equiv="Cache-Control" content="no-transform" />
	<meta http-equiv="Cache-Control" content="no-siteapp" />
    <title>
	<?php
	if(is_front_page() || is_home()) { 
		bloginfo('name');
	} else if(is_single() || is_page()) {
		 wp_title(''); 
	} else if(is_category()) {
		printf(__('Category Archives: %1$s', 'bokeh' ), single_cat_title('', false));
	} else if(is_search()) {
		printf(__('Search Result: %1$s', 'bokeh' ), wp_specialchars($s, 1));
	} else if(is_tag()) {
		printf(__('Tag Archives: %1$s', 'bokeh' ), single_tag_title('', false));
	} else if(is_date()) {
		_e('Archives by Date', 'bokeh');
	} else {
		bloginfo('name');
	}
	?></title>
    <link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet" media="screen">
	<link href="<?php bloginfo('template_directory');?>/css/font-awesome.min.css" rel="stylesheet" media="screen">
	<?php if( dopt('d_headcode_b') != '' ) echo dopt('d_headcode');?>
	<?php wp_head(); ?>
</head>
<body>
<?php 
	if( is_mobile() ) {
	echo '<div id="mobile-nav" class="f12 yahei"><form class="mm-search" action="'.get_bloginfo('url').'" method="get" role="search"><input type="text" autocomplete="off" placeholder="Search" name="s" value=""><input id="mobilesubmit" type="submit" value="Search"></form> ';
	if(function_exists('wp_nav_menu')) {
						wp_nav_menu(array( 'theme_location' => 'header-menu','container' => 'ul', 'menu_class' => 'nav')); 
					}
	echo '</div>';
	} else {
?>
	<?php if(is_home() && dopt('d_index_open')) {?>
	<header id="header">
		<section class="navigation">
			<?php 
				if(function_exists('wp_nav_menu')) {
					wp_nav_menu(array( 'theme_location' => 'index-menu','container' => 'ul')); 
				}
			?>
		</section>
		<section class="title-desc"> 
			<h1 class="title"><a href="<?php bloginfo('url'); ?>"><?php bloginfo('name')?></a></h1>
			<p><?php bloginfo('description')?></p>
		</section>
		<section class="roll">
			<i class="fa fa-angle-down"></i>
		</section>
	</header>
	<?php } else if(dopt('d_bigimg_b') && in_category(dopt('d_bigimg')) && !is_archive() ) { ?>
	<header id="header" style="background-image:url(<?php
	$big_img_url = get_post_meta($post->ID, 'big_img_url', true);
	if($big_img_url != '')
		echo $big_img_url;
	else {
		$timthumb_src = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'imaj' ); 
		echo $timthumb_src[0]; 
	}
		?>)">
		<section class="single-title-desc"> 
			<h1><?php the_title(); ?></h1>
			<p><?php echo strip_tags(get_the_excerpt());?></p>
			<p><span><?php the_time('d,m,Y');?></span>
			<span><?php mzw_post_views(' views');?></span>
			<span><i class="single-love-count"><?php if( get_post_meta($post->ID,'mzw_ding',true) ){
						$love_num =  get_post_meta($post->ID,'mzw_ding',true);
						$love_num = intval($love_num);
						echo $love_num.'</i>';
						if($love_num > 1) {echo ' likes';}else{echo ' like';}
					 } else {
						echo '0</i> like';
					 }?></span></p>
		</section>
		<section class="roll">
			<i class="fa fa-angle-down"></i>
		</section>
	</header>
	<?php } else {?>
	<div></div>
	<?php } ?>
	<div id="head-nav">
		<div class="head-nav-wrap clearfix">
			<h1 class="site-title left"><a href="<?php bloginfo('url'); ?>" data-dummy="<?php bloginfo('name'); ?>"><?php bloginfo('name')?></a></h1>
			<?php if(dopt('d_sidebar_b')) {?><span class="right sidebar-btn"><i class="fa fa-reorder"></i></span><?php } ?>
			<span class="right search-btn"><i class="fa fa-search"></i></span>
			<?php 
				if(function_exists('wp_nav_menu')) {
					wp_nav_menu(array( 'theme_location' => 'header-menu','container' => 'ul', 'menu_class' => 'nav')); 
				}
			?>
		</div>
	</div>
	<?php } ?>
	<section id="content" class="<?php if(is_archive() || is_search()) echo 'page-archive';?>">
	
	<?php if(is_mobile()) {
		echo '<header id="mobile-head"><a href="javascript:;" class="open-nav"><i class="fa fa-bars"></i></a><a href="';
		bloginfo('url'); 
		echo '"><h1>';
		bloginfo("name");
		echo '</h1></a></header>';
	} ?>