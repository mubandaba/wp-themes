<?php get_header(); ?>

<div class="archive-meta">
	<h3 class="title-meta"><?php single_cat_title(); ?></h3>
	<div class="blockDivider "><span class="blockDivider-name"><?php _e('Category Archives', 'bokeh' );?></span></div>
	<?php if ( category_description() ) echo '<div class="desc-meta">'.category_description().'</div>'; ?>
</div>

<?php 
	if(dopt('d_bigimg_b') && in_category(dopt('d_bigimg'))) {
		echo '<div class="grid">';
		if( have_posts() ){ 
			while ( have_posts() ){
				the_post(); 
				get_template_part( 'inc/post-format/category', 'bigimg' );
			}
		}
		ajax_show_more_button();
		echo '</div>';
	} else {
		if( have_posts() ){ 
			while ( have_posts() ){
				the_post(); 
				get_template_part( 'inc/post-format/content', get_post_format() );
			}
		}
		ajax_show_more_button();
	}
?>
<?php get_footer(); ?>