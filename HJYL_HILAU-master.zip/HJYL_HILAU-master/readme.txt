== HJYL_HILAU WordPress Theme==
Author:HJYL
* by hjyl.org
Requires at least: 5.0+
Tested up to: 5.2.3

== ABOUT HJYL_HILAU ==
For questions, comments or bug reports, please go to
https://hjyl.org/wordpress-theme-HJYL_HILAU/

Bundled with the theme are licensed under the [GNU GPL](https://www.gnu.org/licenses/gpl-3.0.html)


== Theme Options ==
HJYL_HILAU has theme options page:Go into your Wordpress Admin, navigate to 'Appearance > Theme Options'

* Theme options User Guide please visit here: https://hjyl.org/wordpress-theme-HJYL_HILAU/#HJYL_HILAU-theme-options

== Language Package:  ==
* Chinese (zh_CN): HJYL

== Changelog ==
2019.09.09	HJYL_HILAU is comming.
2019.10.08	WordPress theme HJYL_HILAU 开源发布.
2019.10.09	将font-awesome图标插件换成SVG Sprite技术实现小图标，大大减少了主题包的大小，减少了1.6M左右.
2019.10.10  整站换一种字体“play”，来自于inlojv.com，感觉非常舒服的字体.
			修复文章图片在相册下超宽的情况.
2019.10.12  更换网站英文字体play为谷歌字体链接.
			添加归档页面，建立一个页面别名必须为“Archives”.
			在自定义添加一个选项：如果选中，主题可以支持博客模式，即简单的隐藏CMS首页中间部分.
2019.10.13	修正评论标题和边栏标题下划线的位置.
			style.css抬头属性的修改.
			修改评论回复邮件通知勾选框美化.
2019.10.14	给文章内容外链转内链go跳转.
			添加单独下载页面.
2019.10.17	添加自定义widget：读者墙、带头像的最新评论、博客统计、随机文章、热门文章、相关文章.
2019.10.19	修改自定义widget：博客统计、相关文章的样式和输出形式；
			添加页面随滚动条加载进度条[位置顶部].
2019.11.08  修正PHP版本bug；更新版本3.2