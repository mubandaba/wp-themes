<?php

/** inpad options */
class InpadOptions {

	function getOptions() {
		$options = get_option('inpad_options');
		if (!is_array($options)) {
			$options['themewidth'] = '980px';
			$options['colorset'] = 'grey';
			$options['notice'] = false;
			$options['notice_title'] = '';
			$options['notice_content'] = '';
			$options['feed'] = false;
			$options['feed_url'] = '';
			$options['twitter'] = false;
			$options['twitter_username'] = '';
			$options['douban'] = false;
			$options['douban_username'] = '';
			$options['facebook'] = false;
			$options['facebook_username'] = '';
			$options['lastfm'] = false;
			$options['lastfm_username'] = '';
			$options['xiami'] = false;
			$options['xiami_username'] = '';
			$options['analytics'] = false;
			$options['analytics_content'] = '';
			update_option('inpad_options', $options);
		}
		return $options;
	}

	function add() {
		if(isset($_POST['inpad_save'])) {
			$options = InpadOptions::getOptions();
			// theme width
			$options['themewidth'] = $_POST['themewidth'];

			// color set
			$options['colorset'] = $_POST['colorset'];

			// notice
			if ($_POST['notice']) {
				$options['notice'] = (bool)true;
			} else {
				$options['notice'] = (bool)false;
			}
			$options['notice_title'] = stripslashes($_POST['notice_title']);
			$options['notice_content'] = stripslashes($_POST['notice_content']);

			// feed
			if ($_POST['feed']) {
				$options['feed'] = (bool)true;
			} else {
				$options['feed'] = (bool)false;
			}
			$options['feed_url'] = stripslashes($_POST['feed_url']);
			if (!$_POST['feed_readers']) {
				$options['feed_readers'] = (bool)false;
			} else {
				$options['feed_readers'] = (bool)true;
			}

			// twitter
			if ($_POST['twitter']) {
				$options['twitter'] = (bool)true;
			} else {
				$options['twitter'] = (bool)false;
			}
			$options['twitter_username'] = stripslashes($_POST['twitter_username']);

			// douban
			if ($_POST['douban']) {
				$options['douban'] = (bool)true;
			} else {
				$options['douban'] = (bool)false;
			}
			$options['douban_username'] = stripslashes($_POST['douban_username']);

			// facebook
			if ($_POST['facebook']) {
				$options['facebook'] = (bool)true;
			} else {
				$options['facebook'] = (bool)false;
			}
			$options['facebook_username'] = stripslashes($_POST['facebook_username']);

			// lastfm
			if ($_POST['lastfm']) {
				$options['lastfm'] = (bool)true;
			} else {
				$options['lastfm'] = (bool)false;
			}
			$options['lastfm_username'] = stripslashes($_POST['lastfm_username']);

			// xiami
			if ($_POST['xiami']) {
				$options['xiami'] = (bool)true;
			} else {
				$options['xiami'] = (bool)false;
			}
			$options['xiami_username'] = stripslashes($_POST['xiami_username']);

			// analytics
			if ($_POST['analytics']) {
				$options['analytics'] = (bool)true;
			} else {
				$options['analytics'] = (bool)false;
			}
			$options['analytics_content'] = stripslashes($_POST['analytics_content']);

			update_option('inpad_options', $options);

		} else {
			InpadOptions::getOptions();
		}

		add_theme_page(__('Inpad Options', 'inpad'), __('Inpad Options', 'inpad'), 'edit_themes', basename(__FILE__), array('InpadOptions', 'display'));
	}

	function display() {
		$options = InpadOptions::getOptions();
?>

<form action="" method="post" enctype="multipart/form-data" name="inpad_form" id="inpad_form">
	<div class="wrap">
		<h2><?php _e('Inpad Options', 'inpad'); ?></h2>

		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row">
						<?php _e('Theme width', 'inpad'); ?>
					</th>
					<td>
						<!-- color START -->
						<div style="width:98%;">
							<div>
									<input type="radio" name="themewidth" value="fullscreen" <?php if($options['themewidth'] == fullscreen) echo ' checked '; ?>/><?php _e('Fullscreen', 'inpad'); ?>
									<input type="radio" name="themewidth" value="980px" <?php if($options['themewidth'] == '980px') echo ' checked '; ?>/><?php _e('980px', 'inpad'); ?>
							</div>
							<div style="clear:both;"></div>
						</div>
						<!-- color END -->
					</td>
				</tr>
			</tbody>
		</table>

		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row">
						<?php _e('Color set', 'inpad'); ?>
					</th>
					<td>
						<!-- color START -->
						<div style="width:98%;">
							<div>
									<input type="radio" name="colorset" value="grey" <?php if($options['colorset'] == grey) echo ' checked '; ?>/><?php _e('Grey', 'inpad'); ?>
									<input type="radio" name="colorset" value="darkblue" <?php if($options['colorset'] != grey && $options['colorset'] != pink && $options['colorset'] != orange) echo ' checked '; ?>/><?php _e('Darkblue', 'inpad'); ?>
									<input type="radio" name="colorset" value="pink" <?php if($options['colorset'] != grey && $options['colorset'] != darkblue && $options['colorset'] != orange) echo ' checked '; ?>/><?php _e('Pink', 'inpad'); ?>
									<input type="radio" name="colorset" value="orange" <?php if($options['colorset'] != grey && $options['colorset'] != darkblue && $options['colorset'] != pink) echo ' checked '; ?>/><?php _e('Orange', 'inpad'); ?>
									<p><?php _e('If you designed a new color set,Please share it with others.','inpad'); ?></p>
							</div>
							<div style="clear:both;"></div>
						</div>
						<!-- color END -->
					</td>
				</tr>
			</tbody>
		</table>

		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row">
						<?php _e('Notice', 'inpad'); ?>
						<br/>
						<small style="font-weight:normal;"><?php _e('HTML enabled', 'inpad'); ?></small>
					</th>
					<td>
						<!-- notice START -->
						<div style="width:98%;">
							<div>
								<label>
									<input name="notice" type="checkbox" value="checkbox" <?php if($options['notice']) echo "checked='checked'"; ?> />
									 <?php _e('This notice bar will display in the sidebar on homepage.', 'inpad'); ?>
								</label>
							</div>
							<div>
								<?php _e('Notice title:','inpad'); ?>
									<input name="notice_title" id="notice_title" type="text" /><br/>
								<?php _e('Notice content:','inpad'); ?>
									<textarea name="notice_content" id="notice_content" cols="50" rows="10" style="width:98%;font-size:12px;" class="code"><?php echo($options['notice_content']); ?></textarea>
							</div>
							<div style="clear:both;"></div>
						</div>
						<!-- notice END -->
					</td>
				</tr>
			</tbody>
		</table>

		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row"><?php _e('Feed', 'inpad'); ?></th>
					<td>
						<label>
							<input name="feed" type="checkbox" value="checkbox" <?php if($options['feed']) echo "checked='checked'"; ?> />
							 <?php _e('Using custom feed.', 'inpad'); ?>
						</label>
						<br />
						<?php _e('Feed URL:', 'inpad'); ?>
						 <input type="text" name="feed_url" id="feed_url" class="code" size="40" value="<?php echo($options['feed_url']); ?>">
					</td>
				</tr>
			</tbody>
		</table>

		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row"><?php _e('Twitter', 'inpad'); ?></th>
					<td>
						<label>
							<input name="twitter" type="checkbox" value="checkbox" <?php if($options['twitter']) echo "checked='checked'"; ?> />
							 <?php _e('Add Twitter button to menubar.', 'inpad'); ?>
						</label>
						<br />
						 <?php _e('Twitter username:', 'inpad'); ?>
						 <input type="text" name="twitter_username" id="twitter_username" class="code" size="40" value="<?php echo($options['twitter_username']); ?>">
						<br />
						<a href="http://twitter.com/cantonbolo/" onclick="window.open(this.href);return false;">Follow bolo</a>
					</td>
				</tr>
			</tbody>
		</table>

		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row"><?php _e('Douban', 'inpad'); ?></th>
					<td>
						<label>
							<input name="douban" type="checkbox" value="checkbox" <?php if($options['douban']) echo "checked='checked'"; ?> />
							 <?php _e('Add Douban button to menubar.', 'inpad'); ?>
						</label>
						<br />
						 <?php _e('Douban username:', 'inpad'); ?>
						 <input type="text" name="douban_username" id="douban_username" class="code" size="40" value="<?php echo($options['douban_username']); ?>">
						<br />
						<a href="http://www.douban.com/people/cantonbolo" onclick="window.open(this.href);return false;">Follow bolo</a>
					</td>
				</tr>
			</tbody>
		</table>

		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row"><?php _e('Facebook', 'inpad'); ?></th>
					<td>
						<label>
							<input name="facebook" type="checkbox" value="checkbox" <?php if($options['facebook']) echo "checked='checked'"; ?> />
							 <?php _e('Add Facebook button to menubar.', 'inpad'); ?>
						</label>
						<br />
						 <?php _e('Facebook username:', 'inpad'); ?>
						 <input type="text" name="facebook_username" id="facebook_username" class="code" size="40" value="<?php echo($options['facebook_username']); ?>">
						<br />
						<a href="http://www.facebook.com/cantonbolo" onclick="window.open(this.href);return false;">Follow bolo</a>
					</td>
				</tr>
			</tbody>
		</table>

		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row"><?php _e('LastFM', 'inpad'); ?></th>
					<td>
						<label>
							<input name="lastfm" type="checkbox" value="checkbox" <?php if($options['lastfm']) echo "checked='checked'"; ?> />
							 <?php _e('Add LastFM button to menubar.', 'inpad'); ?>
						</label>
						<br />
						 <?php _e('LastFM username:', 'inpad'); ?>
						 <input type="text" name="lastfm_username" id="lastfm_username" class="code" size="40" value="<?php echo($options['lastfm_username']); ?>">
						<br />
						<a href="http://www.last.fm/user/cantonbolo" onclick="window.open(this.href);return false;">Follow bolo</a>
					</td>
				</tr>
			</tbody>
		</table>

		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row"><?php _e('Xiami', 'inpad'); ?></th>
					<td>
						<label>
							<input name="xiami" type="checkbox" value="checkbox" <?php if($options['xiami']) echo "checked='checked'"; ?> />
							 <?php _e('Add Xiami button to menubar.', 'inpad'); ?>
						</label>
						<br />
						 <?php _e('Xiami ID:', 'inpad'); ?>
						 <input type="text" name="xiami_username" id="xiami_username" class="code" size="40" value="<?php echo($options['xiami_username']); ?>">
						<br />
						<a href="http://www.xiami.com/u/597034" onclick="window.open(this.href);return false;">Follow bolo</a>
					</td>
				</tr>
			</tbody>
		</table>

		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row">
						<?php _e('Web Analytics', 'inpad'); ?>
						<br/>
						<small style="font-weight:normal;"><?php _e('HTML enabled', 'inpad'); ?></small>
					</th>
					<td>
						<label>
							<input name="analytics" type="checkbox" value="checkbox" <?php if($options['analytics']) echo "checked='checked'"; ?> />
							 <?php _e('Add web analytics code to your site. (e.g. Google Analytics, Yahoo! Web Analytics, ...)', 'inpad'); ?>
						</label>
						<label>
							<textarea name="analytics_content" cols="50" rows="10" id="analytics_content" class="code" style="width:98%;font-size:12px;"><?php echo($options['analytics_content']); ?></textarea>
						</label>
					</td>
				</tr>
			</tbody>
		</table>

		<p class="submit">
			<input class="button-primary" type="submit" name="inpad_save" value="<?php _e('Save Changes', 'inpad'); ?>" />
		</p>
	</div>

</form>

<!-- donation -->
<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
	<div class="wrap" style="background:#E3E3E3; margin-bottom:1em;">

		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row">Donation</th>
					<td>
						If you find my work useful and you want to encourage the development of more free resources, you can do it by donating...
						<br />
<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="9310317">
<input type="image" src="https://www.paypal.com/en_US/i/btn/btn_donate_SM.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypal.com/zh_XC/i/scr/pixel.gif" width="1" height="1">
</form>
					</td>
				</tr>
			</tbody>
		</table>

	</div>
</form>

<?php
	}
}

// register functions
add_action('admin_menu', array('InpadOptions', 'add'));


/** l10n */
function theme_init(){
	load_theme_textdomain('inpad', get_template_directory() . '/languages');
}
add_action ('init', 'theme_init');

/** widgets */
if( function_exists('register_sidebar') ) {
	register_sidebar(array(
		'before_widget' => '<div class="widget %2$s">',
		'after_widget' => '<div class="fixed"></div></div>',
		'before_title' => '<h3>',
		'after_title' => '</h3>',
	));
}

/* 
Plugin Name: Recent Comments 
Plugin URI: http://mtdewvirus.com/code/wordpress-plugins/ 
*/ 

function ip_recent_comments($no_comments = 10, $comment_len = 50) { 
    global $wpdb; 
	
	$request = "SELECT * FROM $wpdb->comments";
	$request .= " JOIN $wpdb->posts ON ID = comment_post_ID";
	$request .= " WHERE comment_approved = '1' AND post_status = 'publish' AND post_password ='' AND comment_type = ''"; 
	$request .= " ORDER BY comment_date DESC LIMIT $no_comments"; 
		
	$comments = $wpdb->get_results($request);
		
	if ($comments) { 
		foreach ($comments as $comment) { 
			ob_start();
			?>
				<li>
					&#8250;<a href="<?php echo get_permalink( $comment->comment_post_ID ) . '#comment-' . $comment->comment_ID; ?>"><?php echo ip_get_author($comment); ?>:</a>
					<?php echo get_cut(preg_replace('/\<(.+?)\>/', '',apply_filters('get_comment_text', $comment->comment_content)), $comment_len); ?>[...]
				</li>
			<?php
			ob_end_flush();
		} 
	} else { 
		echo "<li>No comments</li>";
	}
}

// 支持截取中文  
/** 
* UTF-8编码字符串的截取 
* 
* @param string $str 
* @param int $len 
* @param string $dot 
* @return string 
*/  
function get_cut($String,$Length) {
	if (mb_strwidth($String, 'UTF8') <= $Length ) {
	return $String;
	} else {
		$I = 0;
		$len_word = 0;
			while ($len_word < $Length){
				$StringTMP = substr($String,$I,1);
				if ( ord($StringTMP) >=224 ){
					$StringTMP = substr($String,$I,3);
					$I = $I + 3;
					$len_word = $len_word + 2;
				} elseif ( ord($StringTMP) >=192 ){
					$StringTMP = substr($String,$I,2);
					$I = $I + 2;
					$len_word = $len_word + 2;
				} else {
					$I = $I + 1;
					$len_word = $len_word + 1;
				}  
				$StringLast[] = $StringTMP;  
			}  
		/* raywang edit it for dirk for (es/index.php)*/  
		if (is_array($StringLast) && !empty($StringLast)){  
			$StringLast = implode("",$StringLast);  
		}  
		return $StringLast;   
	}   
}    

function ip_get_author($comment) {
	$author = "";

	if ( empty($comment->comment_author) )
		$author = __('Anonymous','inpad');
	else
		$author = $comment->comment_author;
		
	return $author;
}

/* Comments */
if (function_exists('wp_list_comments')) {
	// comment count
	function comment_count( $commentcount ) {
		global $id;
		$_comments = get_comments('status=approve&post_id=' . $id);
		$comments_by_type = &separate_comments($_comments);
		return count($comments_by_type['comment']);
	}
}

// custom comments
function custom_comments($comment, $args, $depth) {
	$GLOBALS['comment'] = $comment;
	global $commentcount;
	if(!$commentcount) {
		$commentcount = 0;
	}
?>
	<li id="comment-<?php comment_ID() ?>" class="comment<?php if($comment->comment_type == 'pingback' || $comment->comment_type == 'trackback') {echo ' pingcomment';} else if($comment->comment_author_email == get_the_author_email()) {echo ' admincomment';} else {echo ' regularcomment';} ?>">

		<div class="info<?php if($comment->comment_type == 'pingback' || $comment->comment_type == 'trackback') {echo ' pinginfo';} else if($comment->comment_author_email == get_the_author_email()) {echo ' admininfo';} else {echo ' regularinfo';} ?>">
			<div class="author">
				<?php if (get_comment_author_url()) : ?>
					<a class="authorname" id="commentauthor-<?php comment_ID() ?>" href="<?php comment_author_url() ?>" rel="external nofollow">
				<?php else : ?>
					<span class="authorname" id="commentauthor-<?php comment_ID() ?>">
				<?php endif; ?>

				<?php comment_author() ?>

				<?php if(get_comment_author_url()) : ?>
					</a>
				<?php else : ?>
					</span>
				<?php endif; ?>
				<div class="date"><?php printf( __('%1$s at %2$s', 'inpad'), get_comment_date(get_option(’date_format’)), get_comment_time(get_option('time_format')) ); ?></div>
			</div>
			<?php
				if($comment->comment_type != 'pingback' && $comment->comment_type != 'trackback') {
					// Support avatar for WordPress 2.5 or higher
					if (function_exists('get_avatar') && get_option('show_avatars')) {
						echo '<div class="pic">';
						echo get_avatar($comment, 36);
						echo '</div>';
					// Support Gravatar for WordPress 2.3.3 or lower
					} else if (function_exists('gravatar')) {
						echo '<div class="pic"><img class="avatar" src="';
						gravatar("G", 36);
						echo '" alt="avatar" /></div>';
					}
				}
			?>
			<div class="fixed"></div>
		</div>

		<?php if($comment->comment_type != 'pingback' && $comment->comment_type != 'trackback') : ?>
			<div class="content">
				<?php if ($comment->comment_approved == '0') : ?>
					<p><small>Your comment is awaiting moderation.</small></p>
				<?php endif; ?>

				<div id="commentbody-<?php comment_ID() ?>">
					<?php comment_text() ?>
				</div>
			<div class="count">
				<?php if($comment->comment_type != 'pingback' && $comment->comment_type != 'trackback') : ?>
					<?php if (!get_option('thread_comments')) : ?>
						<a href="javascript:void(0);" onclick="inpad_ds.reply('commentauthor-<?php comment_ID() ?>', 'comment-<?php comment_ID() ?>', 'comment');"><?php _e('Reply', 'inpad'); ?></a> | 
					<?php else : ?>
						<?php comment_reply_link(array('depth' => $depth, 'max_depth'=> $args['max_depth'], 'reply_text' => __('Reply', 'inpad'), 'after' => ' | '));?>
					<?php endif; ?>
				<?php endif; ?>
				<?php edit_comment_link(__('Edit', 'inpad'), '', ' | '); ?>
				<a href="#comment-<?php comment_ID() ?>"><?php printf('#%1$s', ++$commentcount); ?></a>
			</div>
			</div>
				<div class="fixed"></div>
		<?php endif; ?>

		<div class="fixed"></div>

<?php
}
?>