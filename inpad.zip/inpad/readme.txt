Inpad is a no picture WordPress theme.Designed and build by Bolo(http://imbolo.com/).

Support widgets,two columns,fixed width,multi-colorset,I18N.

You can spread and modify this theme free.But I'm not available any supports who remove my sign.
Thank you for use my theme!