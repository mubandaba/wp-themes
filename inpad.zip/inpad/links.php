<?php
	//Template Name:Links
?>
<?php get_header(); ?>

<div id="main">
	<div id="post">

	<?php if (have_posts()) : the_post(); update_post_caches($posts); ?>
	<div class="post" id="post-<?php the_ID(); ?>">
		<h2><?php the_title(); ?></h2>
		<div class="content">
		<?php
		$linkcats = $wpdb->get_results("SELECT T1.name AS name FROM $wpdb->terms T1, $wpdb->term_taxonomy T2 WHERE T1.term_id = T2.term_id AND T2.taxonomy = 'link_category'");
		$link_rel = $bookmark->link_rel;
		if ($link_rel) {
			$link_rel = 'nofollow external';
		} else {
			$link_rel = 'external';
		}
		if($linkcats) : foreach($linkcats as $linkcat) : ?>
		<div class="linkbox">
		<h4><?php echo $linkcat->name; ?></h4>
		<ul>
			<?php
				$bookmarks = get_bookmarks('orderby=name&category_name=' . $linkcat->name);
				if ( !empty($bookmarks) ) {
					foreach ($bookmarks as $bookmark) {
						echo '<li><a href="' . $bookmark->link_url . '" rel="' . $link_rel . '" title="' . $bookmark->link_description . '">' . $bookmark->link_name . '</a></li>';
					}
				}
			?>
		</ul>
		<div class="fixed"></div>
		</div>
		<?php endforeach; endif; ?>
			<?php the_content(); ?>
			<div class="fixed"></div>
		</div>
	</div>
	<?php else : ?>
	<div class="messagebox">
		<?php _e('Sorry, no posts matched your criteria.', 'inpad'); ?>
	</div>
	<?php endif; ?>

<?php
	if (function_exists('wp_list_comments')) {
		comments_template('', true);
	} else {
		comments_template();
	}
?>

	</div>
    <!-- post END -->

    <?php get_sidebar(); ?>
    <div class="fixed"></div>

</div>
<!-- main END -->
<?php get_footer(); ?>