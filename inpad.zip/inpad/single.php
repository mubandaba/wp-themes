<?php get_header(); ?>

<div id="main">
	<div id="post">
<?php if (have_posts()) : while (have_posts()) : the_post(); update_post_caches($posts); ?>
	<div class="post" id="post-<?php the_ID(); ?>">
	<div id="breadnavi">
		<a title="<?php _e('Go to homepage', 'inpad'); ?>" href="<?php echo get_settings('home'); ?>/"><?php _e('Home', 'inpad'); ?></a>
		 &gt; <?php the_category(', '); ?>
		 &gt; <?php the_title(); ?>
	</div>
		<h2><?php the_title(); ?></h2>
		<div class="info">
			<span class="date"><?php the_time(get_option('date_format')) ?></span>
			<?php if ($options['author']) : ?><span class="author"><?php the_author_posts_link(); ?></span><?php endif; ?>
			<?php edit_post_link(__('Edit', 'inpad'), '<span class="editpost">', '</span>'); ?>
			<span class="comments"><?php comments_popup_link(__('No comments', 'inpad'), __('1 comment', 'inpad'), __('% comments', 'inpad'), '', __('Comments off', 'inpad')); ?></span>
			<div class="fixed"></div>
		</div>
		<div class="content">
			<?php the_content(); ?>
			<div class="fixed"></div>
		</div>
		<div id="pagenavi">
			<?php wp_link_pages('before='); ?>
			<div class="fixed"></div>
		</div>
		<div class="under">
			<span class="categories"><?php _e('Categories: ', 'inpad'); ?><?php the_category(', '); ?></span>
			<span class="tags"><?php _e('Tags: ', 'inpad'); ?><?php the_tags('', ', ', ''); ?></span>
		</div>
			<div class="fixed"></div>

		<div id="morepost">
			<p class="prev"><?php next_post_link('<strong>'.__('Preview Post:','inpad').' </strong> %link') ?></p>
			<p class="next"><?php previous_post_link('<strong>'.__('Next Post:','inpad').' </strong> %link') ?></p>
		</div>

	</div>
<?php endwhile; else : ?>
	<div class="errorbox">
		<?php _e('Sorry, no posts matched your criteria.', 'inpad'); ?>
	</div>
<?php endif; ?>

<?php
	if (function_exists('wp_list_comments')) {
		comments_template('', true);
	} else {
		comments_template();
	}
?>

	</div>
    <!-- post END -->

    <?php get_sidebar(); ?>
    <div class="fixed"></div>

</div>
<!-- main END -->
<?php get_footer(); ?>