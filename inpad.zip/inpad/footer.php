<div id="copyright">
<div class="fixwidth">
	<span class="floatleft">
		<?php
			global $wpdb;
			$post_datetimes = $wpdb->get_row($wpdb->prepare("SELECT YEAR(min(post_date_gmt)) AS firstyear, YEAR(max(post_date_gmt)) AS lastyear FROM $wpdb->posts WHERE post_date_gmt > 1970"));
			if ($post_datetimes) {
				$firstpost_year = $post_datetimes->firstyear;
				$lastpost_year = $post_datetimes->lastyear;

				$copyright = __('Copyright &copy; ', 'inpad') . $firstpost_year;
				if($firstpost_year != $lastpost_year) {
					$copyright .= '-'. $lastpost_year;
				}
				$copyright .= ' ';

				echo $copyright;
				bloginfo('name');
			}
		?>
	</span>
	<span class="floatright">
		<a href="#" target="_top">TOP</a>
	</span>
	<div class="fixed"></div>
</div>
</div>
<!-- copyright END -->
<div id="footer">
<div class="fixwidth">
	<p>Theme Inpad designed by <a href="http://imbolo.com/">Bolo</a>.</p>
	<p>
		Power by <a href="http://www.wordpress.org/">WordPress</a>.Valid <a href="http://www.w3.org">W3C</a>.
<?php
	$options = get_option('inpad_options');
	if ($options['analytics'] && $options['analytics_content']) {
		echo($options['analytics_content']);
	}
?>
	</p>
</div>
</div>
<!-- footer END -->
</div>
<!-- container END -->
</div>
<!-- warp END -->
<?php wp_footer(); ?>
</body>
</html>