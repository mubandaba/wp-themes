<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	<title><?php bloginfo('name'); ?><?php wp_title(); ?></title>
	<link rel="alternate" type="application/rss+xml" title="<?php _e('RSS 2.0 - all posts', 'inpad'); ?>" href="<?php echo $feed; ?>" />
	<link rel="alternate" type="application/rss+xml" title="<?php _e('RSS 2.0 - all comments', 'inpad'); ?>" href="<?php bloginfo('comments_rss2_url'); ?>" />

	<!-- style START -->
	<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/404.css" type="text/css" media="screen" />
	<!-- style END -->

	<?php wp_head(); ?>
</head>

<body>

<div id="container">
	<div id="talker">
		<?php
			if (function_exists('get_avatar') && get_option('show_avatars')) {
				echo get_avatar(get_option('admin_email'), 96);
			}
		?>
	</div>
	<h1><?php _e('Welcome to 404 error page!', 'inpad'); ?></h1>
	<div id="notice">
	<div id="content">
		<p><?php _e("You can try to search other posts...", 'inpad'); ?><p>
	<div id="searchbox">
		<form method="get" id="searchform" action="http://localhost/wp/" >
			<div>
			    <label class="screen-reader-text" for="s">Search for:</label>
				<input type="text" value="" name="s" id="s" />
				<input type="submit" id="searchsubmit" value="Search" />
			</div>
		</form>
    </div>
			<p><?php _e("or go to my", 'inpad'); ?><a href"<?php echo get_settings('home'); ?>"><?php _e(" Home page", 'inpad') ?></a><p>
	</div>
	</div>
	<div class="fixed"></div>
</div>

</body>
</html>
