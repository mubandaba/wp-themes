<?php get_header(); ?>

<div id="main">
	<div id="post">

	<?php if (have_posts()) : the_post(); update_post_caches($posts); ?>
	<div class="post" id="post-<?php the_ID(); ?>">
		<h2><?php the_title(); ?></h2>
		<div class="content">
			<?php the_content(); ?>
			<div class="fixed"></div>
		</div>
	</div>
	<?php else : ?>
	<div class="messagebox">
		<?php _e('Sorry, no posts matched your criteria.', 'inpad'); ?>
	</div>
	<?php endif; ?>

<?php
	if (function_exists('wp_list_comments')) {
		comments_template('', true);
	} else {
		comments_template();
	}
?>

	</div>
    <!-- post END -->

    <?php get_sidebar(); ?>
    <div class="fixed"></div>

</div>
<!-- main END -->
<?php get_footer(); ?>