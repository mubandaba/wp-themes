<?php
	$options = get_option('inpad_options');
	if($options['feed'] && $options['feed_url']) {
		if (substr(strtoupper($options['feed_url']), 0, 7) == 'HTTP://') {
			$feed = $options['feed_url'];
		} else {
			$feed = 'http://' . $options['feed_url'];
		}
	} else {
		$feed = get_bloginfo('rss2_url');
	}
	if($options['themewidth'] == fullscreen) {
		$container = 'fullscreen';
	} else {
		$container = 'container';
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />

<title><?php wp_title('&laquo;', true, 'right'); ?> <?php bloginfo('name'); ?></title>

<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<link rel="alternate" type="application/rss+xml" title="<?php _e('RSS 2.0 - all posts', 'inpad'); ?>" href="<?php echo $feed; ?>" />
<link rel="alternate" type="application/rss+xml" title="<?php _e('RSS 2.0 - all comments', 'inpad'); ?>" href="<?php bloginfo('comments_rss2_url'); ?>" />

<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/style.php?color=<?php echo $options['colorset']; ?>" type="text/css" media="screen" />
		
	<!--[if IE]>
		<link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/ie.css" type="text/css" media="screen" />
	<![endif]-->
	<!-- style END -->

<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/base.js"></script>

<?php wp_head(); ?>
</head>

<?php
	if (is_home()) {
		$home_menu = 'current_page_item';
	} else {
		$home_menu = 'page_item';
	}
?>
<body>
<div id="wrap">
<div id="<?php echo $container ?>">
<div id="header">
<div class="fixwidth">
	<div id="searchbox">
		<form method="get" id="searchform" action="<?php bloginfo('home'); ?>/" >
			<div>
			    <label class="screen-reader-text" for="s">Search for:</label>
				<input type="text" value="" name="s" id="s" />
				<input type="submit" id="searchsubmit" value="Search" />
			</div>
		</form>
    </div>
	<!-- searchbox -->
	<h1 id="title"><a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a></h1>
    <div class="fixed"></div>
	<p id="tagline"><?php bloginfo('description'); ?></p>
    <div class="fixed"></div>
</div>
</div>
<!-- herder END -->

<div id="navigation">
	<!-- menus START -->
	<ul id="menus">
		<li class="<?php echo($home_menu); ?>"><a class="home" title="<?php _e('Home', 'inpad'); ?>" href="<?php echo get_settings('home'); ?>/"><?php _e('Home', 'inpad'); ?></a></li>
		<?php wp_list_pages('title_li=0&orderby=name&show_count=0&depth=1'); ?>
	</ul>
	<!-- menus END -->
	<div class="fixed"></div>
</div>
<!-- navigation END -->