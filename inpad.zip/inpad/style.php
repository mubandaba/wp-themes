<?php
if ( extension_loaded('zlib') and !ini_get('zlib.output_compression') and ini_get('output_handler') != 'ob_gzhandler' and ((version_compare(phpversion(), '5.0', '>=') and ob_get_length() == false) or ob_get_length() === false) ) {
	ob_start('ob_gzhandler');
}else{
	ob_start();
}

$folder = "color/";
$color = $_GET['color'];
$css = $folder.$color.".css";

@header("Cache-Control: public");
@header("Pragma: cache");

$expiresOffset = 3600*24*365;
@header( "Vary: Accept-Encoding" ); // Handle proxies
@header( "Expires: " . gmdate( "D, d M Y H:i:s", time() + $expiresOffset ) . " GMT" );

@header('Content-Type: text/css; charset: UTF-8');
	$data = file_get_contents($css);
	$data .= file_get_contents('style.css');
	$data = preg_replace(array('/\s*([,;:\{\}])\s*/', '/[\t\n\r]/', '/\/\*.+?\*\//'), array('\\1', '',''), $data);
	echo $data;
?>