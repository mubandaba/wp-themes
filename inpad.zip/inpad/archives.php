<?php
	//Template Name:Archive
?>
<?php get_header(); ?>

<div id="main">
	<div id="post">
	<div class="post" id="post-<?php the_ID(); ?>">
		<h2><?php the_title(); ?></h2>
		<div class="content">
		<?php if (function_exists('wp_easyarchives')) : ?>
			<?php wp_easyarchives(); ?>
		<?php else : ?>
			<div class="messagebox">
				<?php _e('Sorry, please activate WP-EasyArchives plugin.', 'inpad'); ?>
			</div>
		<?php endif; ?>
			<div class="fixed"></div>
		</div>
	</div>

	</div>
    <!-- post END -->

    <?php get_sidebar(); ?>
    <div class="fixed"></div>

</div>
<!-- main END -->
<?php get_footer(); ?>