<?php
/**
 * @package WordPress
 * @subpackage inpad
 */
?>
<?php get_header(); ?>

<div id="main">
	<div id="post">
<?php if (have_posts()) : while (have_posts()) : the_post(); update_post_caches($posts); ?>
	<div class="post" id="post-<?php the_ID(); ?>">
		<h2><a class="title" href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></h2>
		<div class="info">
			<span class="date"><?php the_time(get_option('date_format')) ?></span>
			<?php edit_post_link(__('Edit', 'inpad'), '<span class="editpost">', '</span>'); ?>
			<span class="comments"><?php comments_popup_link(__('No comments', 'inpad'), __('1 comment', 'inpad'), __('% comments', 'inpad'), '', __('Comments off', 'inpad')); ?></span>
			<div class="fixed"></div>
		</div>
		<div class="content">
			<?php the_content(__('&raquo;Continue...', 'inpad')); ?>
			<div class="fixed"></div>
		</div>
		<div class="under">
			<span class="categories"><?php _e('Categories: ', 'inpad'); ?><?php the_category(', ') ?></span>
			<span class="tags"><?php _e('Tags: ', 'inpad'); ?><?php the_tags('', ', ', ''); ?></span>
			<div class="fixed"></div>
		</div>
	</div>
<?php endwhile; else : ?>
	<div class="messagebox">
		<?php _e('Sorry, no posts matched your criteria.', 'inpad'); ?>
	</div>
<?php endif; ?>
<div id="pagenavi">
	<?php if(function_exists('wp_pagenavi')) : ?>
		<?php wp_pagenavi() ?>
	<?php else : ?>
		<span class="newer"><?php previous_posts_link(__('Newer Entries&raquo;', 'inpad')); ?></span>
		<span class="older"><?php next_posts_link(__('&laquo;Older Entries', 'inpad')); ?></span>
	<?php endif; ?>
	<div class="fixed"></div>
</div>
	</div>
    <!-- post END -->

    <?php get_sidebar(); ?>
    <div class="fixed"></div>

</div>
<!-- main END -->
<?php get_footer(); ?>