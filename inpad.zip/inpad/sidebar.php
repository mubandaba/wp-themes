<?php
	$options = get_option('inpad_options');
	if ($options['feed'] && $options['feed_url']) {
		if (substr(strtoupper($options['feed_url']), 0, 7) == 'HTTP://') {
			$feed = $options['feed_url'];
		} else {
			$feed = 'http://' . $options['feed_url'];
		}
	} else {
		$feed = get_bloginfo('rss2_url');
	}
?>

<div id="sidebar">
	<div id="social">
    	<a href="<?php echo $feed; ?>">RSS</a>
		<?php if ($options['twitter'] && $options['twitter_username']) : ?>
		<a href="http://twitter.com/<?php echo $options['twitter_username'] ?>"><?php _e('Twitter', 'inpad'); ?></a>
		<?php endif; ?>
		<?php if ($options['douban'] && $options['douban_username']) : ?>
		<a href="http://www.douban.com/people/<?php echo $options['douban_username'] ?>"><?php _e('Douban', 'inpad'); ?></a>
		<?php endif; ?>
		<?php if ($options['facebook'] && $options['facebook_username']) : ?>
		<a href="http://www.facebook.com/<?php echo $options['facebook_username'] ?>"><?php _e('Facebook', 'inpad'); ?></a>
		<?php endif; ?>
		<?php if ($options['lastfm'] && $options['lastfm_username']) : ?>
		<a href="http://www.last.fm/user/<?php echo $options['lastfm_username'] ?>"><?php _e('LastFM', 'inpad'); ?></a>
		<?php endif; ?>
		<?php if ($options['xiami'] && $options['xiami_username']) : ?>
		<a href="http://www.xiami.com/u/<?php echo $options['xiami_username'] ?>"><?php _e('Xiami', 'inpad'); ?></a>
		<?php endif; ?>
	<div class="fixed"></div>
	</div>
	<!-- social END -->
	<div class="fixed"></div>

	<?php if (is_home() && $options['notice'] && $options['notice_content']) : ?>
	<div class="widget">
	<?php if ($options['notice_title']) : ?>
		<h3><?php echo $options['notice_title'] ?></h3>
	<?php endif; ?>
		<p><?php echo $options['notice_content'] ?></p>
	</div>
	<div class="fixed"></div>
	<?php endif; ?>
	<!-- notice END -->

	<div class="recent">
		<ul class="tabs">
			<li><a class="active" href="#tab-comments">Recent Comments</a></li>
			<li><a href="#tab-posts">Recent Posts</a></li>
			<li><a style="margin-right:0px;" href="#tab-tags">Tags</a></li>
		</ul>
		<div class="fixed"></div>
		<ul id="tab-comments">
		<?php ip_recent_comments(5); ?>
		</ul> 
		<ul id="tab-posts">
			<?php $posts = get_posts("numberposts=10&orderby=post_date&order=DESC"); foreach($posts as $post) : ?>	
			<li>&#8250;<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
			<?php endforeach; ?>
		</ul>
		<div id="tab-tags">
			<?php wp_tag_cloud('smallest=12&largest=16'); ?>
		</div>
	</div>
	<div class="fixed"></div>
	<!-- recent END -->

<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>
	<div class="widget">
		<h3>Categories</h3>
			<ul>
				<?php wp_list_categories('title_li=&sort_column=name&optioncount=0&depth=1'); ?>
			</ul>
	</div>

	<div class="widget">
	<h3>Mete</h3>
		<ul>
			<?php wp_register('<li>&#8250;  '); ?>
			<li>&#8250;  <?php wp_loginout(); ?></li>
		</ul>
	</div>
	<!-- mete END -->
<?php endif; ?>

</div>
<!-- sidebar -->