function reply(authorId, commentId, commentBox) {
	var author = inpad.$(authorId).innerHTML;
	var insertStr = '<a href="#' + commentId + '">@' + author.replace(/\t|\n|\r\n/g, "") + ' </a> \n';

	appendReply(insertStr, commentBox);
}

function appendReply(insertStr, commentBox) {
	if(inpad.$(commentBox) && inpad.$(commentBox).type == 'textarea') {
		field = inpad.$(commentBox);

	} else {
		alert("The comment box does not exist!");
		return false;
	}

	if (field.value.indexOf(insertStr) > -1) {
		alert("You've already appended this reply!");
		return false;
	}

	if (field.value.replace(/\s|\t|\n/g, "") == '') {
		field.value = insertStr;
	} else {
		field.value = field.value.replace(/[\n]*$/g, "") + '\n\n' + insertStr;
	}
	field.focus();
}

window['inpad_ds'] = {};
window['inpad_ds']['reply'] = reply;