<?php 
/**
 * Template Name: 留言
 *
 */
 get_header(); ?>
<div id="gongaobox"><div id="gongao">当前位置：<a title="回到首页" href="<?php echo get_settings('home'); ?>/">首页</a>　<?php the_title(); ?></div>
<div id="gongaor">建站日期：<strong><?php echo get_option('lovnvns_date');?></strong>　运行天数：<strong><?php echo floor((time()-strtotime(get_option('lovnvns_date')))/86400); ?></strong> 天　最后更新：<strong><?php $last = $wpdb->get_results("SELECT MAX(post_modified) AS MAX_m FROM $wpdb->posts WHERE (post_type = 'post' OR post_type = 'page') AND (post_status = 'publish' OR post_status = 'private')");$last = date('Y-n-j', strtotime($last[0]->MAX_m));echo $last; ?></strong></div>
</div>
<div id="divcom">
<div class="main">

<?php if(have_posts()) : ?><?php while(have_posts()) : the_post(); ?>
<div id="divleft">
<div id="single_list">
<h1><?php the_title(); ?></h1>
<div class="hr"></div>
<div class="single_content"><h2>感谢各位对本站的支持！</h2>
<ul class="walltop"><?php wall(YEAR,160); ?></ul>
<p>欢迎大家多多灌水，有访必回！</p></div></div></div>
<?php comments_template(); ?>
</div><?php endwhile; ?>
        <?php endif; ?>
<?php get_sidebar(); ?></div>
<div class="clear"></div>
<?php get_footer(); ?>