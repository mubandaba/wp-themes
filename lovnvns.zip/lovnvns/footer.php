<div id="footer">
<div id="bot_main"><div id="bot_mainf"><p>&copy; 2012 <a href="<?php bloginfo('siteurl'); ?>/"><strong><?php bloginfo('name'); ?></strong> </a> All Rights reserved Powered by <a href="<?php bloginfo('siteurl'); ?>/"><?php echo get_option('lovnvns_url'); ?></a> <?php echo get_option('lovnvns_stat'); ?> <?php echo get_option('lovnvns_Designed'); ?></p>
<p><?php if(get_option('lovnvns_statistics')!="") echo get_option('lovnvns_statistics'); ?></p></div><div id="bot_mainr"><img src="<?php bloginfo('template_directory'); ?>/images/logo1.gif" />
        </div></div></div>
</body>
</html>
<!-- Baidu Button BEGIN -->
<script type="text/javascript" id="bdshare_js" data="type=slide&img=0&pos=left" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
		var bds_config = {"bdTop":63};
		document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + new Date().getHours();
</script>
<!-- Baidu Button END -->