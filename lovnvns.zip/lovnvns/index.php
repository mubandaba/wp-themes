<?php get_header(); ?>
<div id="gongaobox"><div id="gongao"><ul><li><span></span><?php if(get_option('lovnvns_announce')!="") echo get_option('lovnvns_announce');else echo "<a href='http://www.110880.com/wordpress/lovnvns1-0-wordpress-cms%e4%b8%bb%e9%a2%98/'><strong>本站主题免费下载</strong></a>！" ?></li></ul></div>
<div id="gongaor">建站日期：<strong><?php echo get_option('lovnvns_date');?></strong>　运行天数：<strong><?php echo floor((time()-strtotime(get_option('lovnvns_date')))/86400); ?></strong> 天　最后更新：<strong><?php $last = $wpdb->get_results("SELECT MAX(post_modified) AS MAX_m FROM $wpdb->posts WHERE (post_type = 'post' OR post_type = 'page') AND (post_status = 'publish' OR post_status = 'private')");$last = date('Y-n-j', strtotime($last[0]->MAX_m));echo $last; ?></strong></div>
</div>
<div id="divcom">
<div class="main">
<div id="divleft1">
<div class="zt_imglist" id="KinSlideshow"><?php $previous_posts = get_posts('numberposts=5&meta_key=banner&meta_value=on'); foreach($previous_posts as $post) : setup_postdata($post); ?>
<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php lovnvns_slide_image()?></a>
<?php endforeach; ?></div><script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/flash.js"></script>
<div class="zt_con">
<?php    
        $sticky = get_option('sticky_posts');
        rsort( $sticky );
        $sticky = array_slice( $sticky, 0, 1);
		
        query_posts( array( 'post__in' => $sticky,
                                   'caller_get_posts' => 1 ) );
        if (have_posts()) :
        while (have_posts()) : the_post();
?><h1><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h1>
<p>分类：<?php the_category(', ') ?> | <?php comments_popup_link ('评论数：0','评论数：1','评论数：%'); ?> | <?php if(function_exists('the_views')) { print '被围观 '; the_views(); print '+';  } ?></p>
<span><?php echo wp_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 90,"……"); ?></span><?php endwhile; ?><?php endif; ?>
<div class="hr"></div>
<ul>
<?php
        $sticky = get_option('sticky_posts');
        rsort( $sticky );
        $sticky = array_slice( $sticky, 1, 6);
		
        query_posts( array( 'post__in' => $sticky,
                                   'caller_get_posts' => 1 ) );
        if (have_posts()) :
        while (have_posts()) : the_post();
?>
<li>
<a href="<?php the_permalink(); ?>"
title="<?php the_title(); ?>">
<?php the_title(); ?></a>
</li><?php     endwhile;  endif;  ?></ul>
</div></div>
<div id="divleft">
<div id="imglist_home">
<ul>
<?php global $query_string;query_posts($query_string.'&showposts=6&caller_get_posts=1'); ?>
<?php if (have_posts()) : ?><?php while (have_posts()) : the_post(); ?><?php
$content = $post->post_content;
$searchimages = '~<img [^>]* />~';
/*用preg_match_all函数来检查日志中是否有<img>标签，并把检查结果存储在$pics中*/
preg_match_all( $searchimages, $content, $pics );
// 看看是否有至少1张图片
$iNumberOfPics = count($pics[0]);
if ( $iNumberOfPics > 0 ) {
echo '<li class="thumbnail"><a href="';
echo the_permalink();
echo '">';
echo '<img src="';
echo  catch_first_image(); 
echo '" alt="';
echo the_title();
echo '" ';
echo ' />';
echo '</a>';
echo '</li>';
}
?><?php endwhile; ?><?php endif; ?>
</ul></div>
</div>
<!-- cms -->
<div id="divleftcms">
<?php
// 得到所有分类列表
$categories = get_categories();

// 循环所有分类
foreach ($categories as $cat) {

// 得到分类ID
$catid = $cat->cat_ID;

// 得到分类下10篇最新文章
 ?>
<div id="divleftl">
<?php query_posts(array('cat'=>$catid,'posts_per_page' => 1,'post__in' => get_option('sticky_posts'),'caller_get_posts' => 1));?>
<?php if(have_posts()):while(have_posts()):the_post(); ?>
<div id="titlebg">
<h2><?php the_category(', ') ?></h2><span class="counts">共有<span class="red"><?php
   echo get_category($catid)->count; 
?></span>篇</span></div>
<div id="textlist">
<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
<p><?php the_time('Y年m月d日') ?> | <?php comments_popup_link ('评论数：0','评论数：1','评论数：%'); ?> | <?php if(function_exists('the_views')) { print '被围观 '; the_views(); print '+';  } ?></p>
<div id="textlistl"><?php include('includes/thumbnail.php'); ?></div>
<div id="textlistr"><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 132,"……"); ?><?php endwhile;?></div>
<div class="hr"></div>
<?php query_posts( array('showposts' => 4,'cat' =>$catid,'post__not_in' => get_option("sticky_posts"))); ?>
<ul>
<?php while (have_posts()) : the_post(); ?>
<li><em><?php the_time('m/d') ?></em><a href="<?php the_permalink() ?>"  title="<?php the_title(); ?>"><?php echo cut_str($post->post_title,40); ?></a></li>
<?php endwhile; ?><?php endif; ?></ul></div></div><?php } ?></div>
<!-- end: cms -->

</div>
<?php get_sidebar(); ?>
</div>
<div id="botcont">
<div id="botcontbar"><strong>友情链接</strong></div>
<div id="botcontbody"><ul><?php wp_list_bookmarks('title_li=&categorize=0&category=2&orderby=rand&show_images=0'); ?></ul></div>
</div>

<?php get_footer(); ?>