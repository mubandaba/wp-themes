<?php
	$cats = wp_get_post_categories($post->ID);//通过分类来获取相关文章
	echo $cat;
	if ($cats) {		
		$limit='5';//设置显示数量
		$cat = get_category( $cats[0] );
		$first_cat = $cat->cat_ID;
		$related = $wpdb->get_results("
			SELECT wp_posts.post_title, wp_posts.guid,wp_posts.post_name 
			FROM wp_posts, wp_term_relationships, wp_term_taxonomy
			WHERE wp_posts.ID = wp_term_relationships.object_id
			AND {$wpdb->prefix}term_taxonomy.taxonomy = 'category'
			AND {$wpdb->prefix}term_taxonomy.term_taxonomy_id = {$wpdb->prefix}term_relationships.term_taxonomy_id
			AND {$wpdb->prefix}posts.post_status = 'publish'
			AND {$wpdb->prefix}posts.post_type = 'post'
			AND {$wpdb->prefix}term_taxonomy.term_id = '" . $first_cat . "'
			AND {$wpdb->prefix}posts.ID != '" . $post->ID . "'
			ORDER BY RAND( )
			LIMIT $limit"
		);//查询数据库	
		if ( $related ) {
			foreach ($related as $row) {
				echo $rp= "<li>"."<a href='" . $row->post_name. "/' title='" . $row->post_title . "'>".cut_str($row->post_title,44) ."</a>"."</li>";
			}//遍历查询结果并输出数据
		}
		else
			echo "<li>"."暂无相关文章"."</li>";//如果没有相关文章输出以下的值
	}
?>