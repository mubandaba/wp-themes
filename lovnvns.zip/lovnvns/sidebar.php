<div id="sidebar">
<?php if(get_option('lovnvns_sidebar_ad')!="") echo get_option('lovnvns_sidebar_ad');else echo "<div  class='sidebar_ad'><a href='http://www.110880.com/' target='_blank'><img src=http://www.110880.com/wp-content/themes/lovnvns/images/ad/sidebar.jpg /></a></div>" ?>
<div class="widget">
<div id="tab-title"><span class="selected">热门文章</span><span>随机文章</span></div>
	<div id="tab-content">
	<ul><?php simple_get_most_viewed(); ?></ul>
	<ul class="hide"><?php Get_Random_Post(10,28) ?></ul>
	</div></div>
	<div class="widget2"><div class="widget4">关键词：
  <?php wp_tag_cloud('smallest=12&largest=16&unit=px&number=65&orderby=count&order=RAND');?></div></div>
   <div class="widget3"><ul><?php wall(); ?></ul></div>
<div id="comments">
<h3>最新评论</h3>
<ul id="slider"><?php Get_Recent_Comment(); ?></ul>
</div>
<div id="newcomments">
<h3>最新文章</h3>
<ul><?php query_posts("showposts=12&caller_get_posts=1&orderby=date&order=DESC"); ?>
	<ul><?php if (have_posts()) : while (have_posts()) : the_post(); ?><li><a href="<?php the_permalink() ?>" title="<?php the_title() ?>"><?php echo mb_strimwidth(get_the_title(), 0, 42, '...'); ?></a></li><?php endwhile; endif; ?></ul>
	</div>
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('小工具1') ) : ?>
	<?php endif; ?>
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('小工具2') ) : ?>
	<?php endif; ?>
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('小工具3') ) : ?>
	<?php endif; ?>
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('小工具4') ) : ?>
	<?php endif; ?>
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('小工具5') ) : ?>
	<?php endif; ?>
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('小工具6') ) : ?>
	<?php endif; ?>
	</div>