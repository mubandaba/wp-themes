<?php
/**
 * Template Name: 友情链接
 *
 */
 get_header(); ?>
<div id="gongaobox"><div id="gongao">当前位置：<a title="回到首页" href="<?php echo get_settings('home'); ?>/">首页</a>　<?php the_title(); ?></div>
<div id="gongaor">建站日期：<strong><?php echo get_option('lovnvns_date');?></strong>　运行天数：<strong><?php echo floor((time()-strtotime(get_option('lovnvns_date')))/86400); ?></strong> 天　最后更新：<strong><?php $last = $wpdb->get_results("SELECT MAX(post_modified) AS MAX_m FROM $wpdb->posts WHERE (post_type = 'post' OR post_type = 'page') AND (post_status = 'publish' OR post_status = 'private')");$last = date('Y-n-j', strtotime($last[0]->MAX_m));echo $last; ?></strong></div>
</div>
<div id="divcom">
<div class="main">

<?php if(have_posts()) : ?><?php while(have_posts()) : the_post(); ?>
<div id="divleft">
<div id="single_list">
<h1><?php the_title(); ?></h1>
<div class="hr"></div>
<div class="single_content"><p>
                	<b>链接要求</b>：PR大于等于1或者更新频繁的网站<br />
                    <b>链接名称</b>：<a href="<?php bloginfo('siteurl'); ?>/"><strong>7m篮球比分</strong></a><br />
                  <b>链接地址</b>：<a href="<?php bloginfo('siteurl'); ?>/"><?php bloginfo('siteurl'); ?>/</a></p>
                <p> 申请本站友情链接的请先加上本站链接到您的的网站，然后在这下面留言告诉我们，我们会在24小时之内添加上你的链接！</p>
				<div class="links">
				<ul><?php wp_list_bookmarks('orderby=link_id&categorize=0&title_li='); ?></ul></div></div></div></div>
<?php comments_template(); ?>
</div><?php endwhile; ?>
        <?php endif; ?>
<?php get_sidebar(); ?></div>
<div class="clear"></div>
<?php get_footer(); ?>