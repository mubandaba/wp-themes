<footer class="footer">
    <p>2019 © <a href="http://WordPress.org/" target="_blank">WordPress</a> theme by <a target="_blank" href="http://www.htm.fun/">shanran</a><?php if(cs_get_option('plus_footer_record')): ?> 国家神秘组织统一代码：<a target="_blank" href="http://beian.miit.gov.cn"><?php echo cs_get_option('plus_footer_record') ?></a><?php endif; ?></p>
    <span>本页共执行<?php echo get_num_queries(); ?>次查询操作耗时<?php timer_stop(3); ?>秒</span>
</footer>
<div class="go-to-top">
    <i class="czs-paper-plane"></i>
</div>