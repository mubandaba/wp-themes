## 主题主页
[http://www.htm.fun/74.html](http://www.htm.fun/74.html)

> 我失业了！！！对你没看错，我失业了。很难受，就在你们开学的日子，9月1日，我毅然决然的辞去了5K(好少)的工作，现在我就是个无业游民！啊，我是个网络乞丐！！所以，大佬们，如果觉得主题用着还舒服，打赏一下吧！五块十块不嫌少，一百两百不嫌多！哈哈哈，开玩笑的啦！

## 主题介绍
### UZero由来
U是Unemployment，失业的意思。
Zero是‘零’。
本人失业了，让一切重新开始吧，所以就有了这个名字，UZero代表着希望与开始。
### 主题功能
- [x] HTML5
- [x] CSS3
- [x] 响应式
- [x] 4套皮肤[后期可以无限续杯]
- [x] ajax评论
- [x] ajax评论分页
- [x] 文章置顶单独样式
- [x] 轮播图
- [x] 图片灯箱
- [x] 代码高亮 [请配合[WP Githuber MD](https://github.com/terrylinooo/githuber-md "WP Githuber MD")使用，程序员怎么能不会MD呢？]
- [x] 内部链接iframe打开[增强体验感]
- [x] 完整的SEO设置
- [x] 友情链接页面
- [ ] 文章归档页面
- [ ] 全站pjax[可选，看需求量]
- [ ] 前台登录[or用户中心，但是感觉用户中心没卵用]
- [ ] 更多功能请提交需求

## 下载主题

https://github.com/Ysnv1997/UZero/releases/tag/UZero
如果你觉得不错请给一个小星星哟！
注:本主题不带后台自动更新，如需获取主题最新消息请加入QQ群[729193505](https://jq.qq.com/?_wv=1027&k=5NIqiSH "729193505")获取最新消息。


## 捐赠主题

啊哈~我都失业！你忍心吗？啊？你忍心如此英俊潇洒玉树临风的我受冻挨饿？打赏我把！金额随意！

| 微信 | 支付宝  |
| :------------: | :------------: |
|  ![](http://www.htm.fun/wp-content/uploads/2019/08/1566632180-%E5%BE%AE%E4%BF%A1.png) |  ![](http://www.htm.fun/wp-content/uploads/2019/08/1566632181-%E6%94%AF%E4%BB%98%E5%AE%9D.png) |

### 捐赠列表

| 时间  | 捐助者  | 金额  |
| :------------:  | :------------:  | :------------:  |
| 2019-9-3  | 今天出了索米也出了芙兰卡  | 5.00￥  |

## 主题展示

在线展示：本站

![](http://www.htm.fun/wp-content/uploads/2019/09/2019090306373895.jpg?imageView2/1/w/1024/h/683/interlace/1/q/75#)
![](http://www.htm.fun/wp-content/uploads/2019/09/2019090306373734.jpg?imageView2/1/w/1024/h/683/interlace/1/q/75#)
![](http://www.htm.fun/wp-content/uploads/2019/09/2019090306373716.jpg?imageView2/1/w/1024/h/683/interlace/1/q/75#)
![](http://www.htm.fun/wp-content/uploads/2019/09/2019090306373891.jpg?imageView2/1/w/1024/h/683/interlace/1/q/75#)
![](http://www.htm.fun/wp-content/uploads/2019/09/2019090306373668.jpg?imageView2/1/w/1024/h/683/interlace/1/q/75#)
![](http://www.htm.fun/wp-content/uploads/2019/09/2019090306431893.jpg?imageView2/1/w/1024/h/683/interlace/1/q/75#)
### 更新日志
[2019年9月5日] :
- 新增回复可见
- 新增公告栏
- 新增百度自动提交
- 新增SMTP发邮件
- 新增评论邮件通知
- 新增图片logo
- 新增友情链接页面
- 新增iframe跳转开关
- 新增返回顶部按钮
- 新增接入草莓图标库
- 修复轮播图不能自动切换
- 修复轮播图分页不能点击
- 修复自定义js代码无法添加script标签
- 修复文章页右侧个人资料
- 修复二级回复业务逻辑错误
- 优化页面布局
[2019年9月3日] :
发布UZero1.0版本