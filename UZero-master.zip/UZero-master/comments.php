<?php if ( post_password_required() ) { return; } ?>
<div id="comments" class="clearfix">
    <?php if ( ! comments_open() ):?>
    <div id="respond">
        <div class="comment-open-box">
            <div class="tips">
                <?php echo '评论已关闭。'; ?>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="respond-box">
	       <h3 class="comments-title"><i class="iconfont icon-comment commentIcon"></i> 评论<span style="font-size: 16px;"> (<?php echo get_comments_number();?>)</span></h3>
        <?php if ( get_option( 'comment_registration') && !$user_ID ) : ?>
        <div class="comment-open-box">
            <div class="tips">
                <a class="but but-diy" href="<?php echo get_option('siteurl'); ?>/wp-login.php?redirect_to=<?php echo urlencode(get_permalink()); ?>">LOGIN</a>
                <p><i class="iconfont icon-tubiao-"></i> 你必须登录之后才能评论</p>
            </div>
        </div>

        <?php else : ?>
        <div id="respond">
                    <form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform" class="commentform">
            <?php if ( $user_ID ) : ?>
            <div class="comment-from-main">
                <div class="logged-in-as">你好，
                    <?php echo $user_identity; ?>！
                    <a href="<?php echo wp_logout_url(get_permalink()); ?>" title="退出">
                        <?php echo '退出'; ?>
                    </a>
                </div>
            </div>
            <?php elseif ( '' !=$comment_author ): ?>
            <div class="comment-from-main">
                <div class="logged-in-as">
                    <?php printf(__( '你好，%s，'), $comment_author); ?>    
                </div>
            </div>
            <?php endif; ?>
            <?php if ( ! $user_ID ): ?>
            <div class="row">
                <p class="comment-note" style="color: #999;font-size: 14px; padding:0 1.5rem;">
                    人生在世，错别字在所难免，无需纠正。
                </p>
                <div class="col-sm-4">
                    <input required="required" type="text" name="author" id="author" placeholder="昵称orQQ" value="<?php echo $comment_author; ?>">
                </div>
                
                <div class="col-sm-4">
                    <input required="required" type="text" name="email" id="email" placeholder="邮箱"value="<?php echo $comment_author_email; ?>">
                </div>
                <div class="col-sm-4">
                    <input class="float-right" type="text" name="url" id="url" placeholder="网址（选填）"value="<?php echo $comment_author_url; ?>">
                </div>
            </div>
            
            <?php endif; ?>
            <div class="comment-from-textarea">
                <textarea required="required" class="form-control form-control-light" name="comment"></textarea>
            </div>
            <?php comment_id_fields(); ?>
            <?php do_action( 'comment_form', $post->ID); ?>
            <div class="form-submit">
                <span id="cancel-comment-reply" class="pull-left"><?php cancel_comment_reply_link('取消评论'); ?></span>
                <input name="submit" type="submit" id="submit" class="link iframe btn btn-primary pull-right" value="提交评论"
                />
            </div>
        </form>
        </div>

        <?php endif; ?>
    </div>
    <?php if( !have_comments() ): ?>
        <p class="no-comment-list">这篇文章还没有评论者，快来成为第一位！</p>
    <?php else: ?>
    <div class="commentlist">
            <?php wp_list_comments( 'avatar_size=40&type=comment&callback=wpmee_comment&end-callback=wpmee_end_comment&max_depth='.get_option( 'thread_comments_depth')); ?>
    </div>
    <?php if ( get_comment_pages_count()>1 && get_option( 'page_comments' ) ) : ?>
        <div id="comments-navi">
            <?php paginate_comments_links( 'prev_text=<i class="iconfont icon-left"></i>&next_text=<i class="iconfont icon-right"></i>'); ?>
        </div>
    <?php endif;?>
    <?php endif;?>
    <?php endif; ?>
</div>