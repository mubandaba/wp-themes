<article>
<div class="postlist">
<h2 class="title entry-title">
<?php if( is_sticky() ) echo '<span style="color:red;"><strong>推荐&nbsp;</strong></span>'; ?>
<a href="<?php the_permalink() ?>" rel="external" title="<?php the_title(); ?>"><?php the_title(); ?></a>
<?php include('includes/new.php'); ?>
</h2>

<div class="postlist-info">
<span class="vcard author" style="float:left;">
<?php $custom_fields = get_post_custom_keys($post_id);  if (!in_array ('copyright', $custom_fields)) : ?>
<a class="fn" href="<?php bloginfo('url') ?>"><?php the_author('nickname'); ?></a>
<?php else: ?>
<?php $custom = get_post_custom($post_id);$custom_url=$custom['copyrighturl'] ;$custom_value = $custom['copyright']; ?>
<a class="fn" rel="external" href="<?php echo $custom_url[0] ?>" ><?php echo $custom_value[0] ?></a>
<?php endif; ?>
</span>
&nbsp;/
<?php if ((get_the_modified_time('Y')*365+get_the_modified_time('z')) > (get_the_time('Y')*365+get_the_time('z'))) { ?>
<div class="date updated" style="float:right;">
<time datetime="<?php the_modified_time('Y-m-d') ?>"><abbr title="<?php the_modified_time('n月, j日, Y年  H:i, l') ?>" style="cursor:help" >最后更新: <?php the_modified_time('Y-m-d  H:i') ?></abbr></time>
</div>
<span>
<?php } else { ?>
<span class="date updated">
<?php } ?>
<time datetime="<?php the_time('Y-m-d') ?>"><a href="<?php $year=get_the_time('Y');$month=get_the_time('m');$day=get_the_time('d');echo get_day_link($year,$month,$day); ?>" title="查看<?php the_time('Y年n月j日') ?>发布的文章"><?php the_time('Y-m-d') ?></a></time>
</span>
&nbsp;/
<span>
<?php the_category(', ') ?>
</span>
<?php edit_post_link('编辑文章', ' &bull; ', ''); ?>
</div>
<div class="clear"></div>

<div class="entry-post">
<div class="thumbnail_box">
<div class="thumbnail">
<a href="<?php the_permalink() ?>" rel="bookmark external" title="<?php the_title(); ?>">
<?php $thumb_img = has_post_thumbnail() ? get_the_post_thumbnail( $post->ID, array(430,230), array('alt' => trim(strip_tags( $post->post_title )),'title'=> trim(strip_tags( $post->post_title ))) ) : get_post_img(220,120,1);?>
<?php echo $thumb_img;?>
</a>
</div>
</div>
<span><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)),0,480,"..."); ?></span>
<div class="clear"></div>
<div class="tags"><?php getColorTags(); ?></div>
<a class="readmore" href="<?php the_permalink() ?>" rel="external" title="<?php the_title(); ?>">阅读全文 →</a>
<div class="clear"></div>
</div>
</div>
</article>