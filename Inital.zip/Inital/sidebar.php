<div id="sidebar">
<?php if(is_home()) { ?>
<?php if(is_dynamic_sidebar()) dynamic_sidebar('首页侧边栏');?>
<?php } else { ?>
<?php if(is_dynamic_sidebar()) dynamic_sidebar('其他侧边栏');?>
<?php } ?>
</div>
<div class="clear"></div>