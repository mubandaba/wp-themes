<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('includes/seo.php'); ?>
<meta charset="UTF-8">
<meta property="v:site_name" content="<?php bloginfo('name') ?>"/>
<meta property="v:local" content="zh_CN"/>
<meta name="msvalidate.01" content="20F0040B651CAF068D05DECF1B28DBE3" />
<meta name="viewport" content="width=device-width,maximum-scale=1;" />
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/style.css"/>
<link rel="shortcut icon" href="<?php bloginfo('template_directory'); ?>/images/favicon.ico" type="image/x-icon"/>
<link rel="pingback" href="<?php bloginfo('pingback_url') ?>"/>
<!--[if lt IE 9]><link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/includes/IE8-style.css" /><![endif]-->
<script src="http://libs.baidu.com/jquery/1.8.3/jquery.min.js"></script>
<?php wp_head(); ?>
</head>

<body>
<div id="page">
<div id="nav">
    <div class="nav-item">
        <h1 class="nav-logo"><a href="<?php bloginfo('url') ?>"><?php bloginfo('name') ?></a></h1>
        <a><span class="nav-enter btn">导航菜单</span></a>
        <div class="nav-menu">
            <div class="nav-menu-list">
                <?php if(function_exists('wp_nav_menu')) {wp_nav_menu(array('theme_location'=>'primary','menu_id'=>'menu','container'=>'false'));}?>
            </div>
            <div class="nav-exit btn"><a>↑ 收起菜单</a></div>
        </div>
        <div class="nav-icon">
            <a class="nav-mail icon-mail" title="邮件联系" href="http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&amp;email=<?php if (get_option('ini_mail')!==""){ echo stripslashes(get_option('ini_mail'));} else { bloginfo('admin_email'); } ?>" rel="external nofollow"></a>
            <?php if (get_option('ini_weibo')!=""){ ?><a class="nav-weibo icon-weibo" title="新浪微博" href="<?php echo stripslashes(get_option('ini_weibo')); ?>" rel="external nofollow"></a><?php } ?>
            <a class="nav-rss icon-rss" title="订阅本站" href="<?php if (get_option('ini_rss')!="") { echo stripslashes(get_option('ini_rss')); } else { bloginfo('rss2_url'); } ?>" rel="external"></a>
            <a class="nav-search icon-search" href="javascript:;" title="展开搜索" <?php if (get_option('ini_search')=="Display") { echo 'style="display:block;"'; } ?>></a>
        </div>
        <div class="nav-search-bar">
            <form role="search" method="get" action="<?php bloginfo('home'); ?>">
                <input type="search" placeholder="Search…" value="" name="s">
            </form>
        </div>
    </div>
</div>

<div id="container">
<?php if ( is_home() ) { ?>
<div id="metro">
<div id="metro-item">
        <div class="left">
          <div class="featured">
        <ul>
        <?php query_posts('meta_key=top&showposts='.get_option(stripslashes('ini_num')).';&ignore_sticky_posts=1');
            if (have_posts()) :
             while (have_posts()) : the_post();?>
        <li>
          <a href="<?php the_permalink(); ?>" rel="bookmark external">
              <?php $thumb_img = has_post_thumbnail() ? get_the_post_thumbnail( $post->ID, 'full', array('alt' => trim(strip_tags( $post->post_title ))) ) : get_post_img(430,230,1);?>
              <span class="featured-title"><span><?php the_title(); ?></span></span>
              <?php echo $thumb_img;?> 
          </a>
        </li>
            <?php endwhile; ?>
            <?php else: ?>
                <?php query_posts('orderby=rand&ignore_sticky_posts=1&showposts='.get_option(stripslashes('ini_num')).'');
                if (have_posts()) :
                while (have_posts()) : the_post();?>
        <li><a href="<?php the_permalink(); ?>" rel="bookmark external">
                <?php $thumb_img = has_post_thumbnail() ? get_the_post_thumbnail( $post->ID, 'full', array('alt' => trim(strip_tags( $post->post_title ))) ) : get_post_img(430,230,1);?>
              <span class="featured-title"><span>随机推荐：<?php the_title(); ?></span></span>
              <?php echo $thumb_img;?>
          </a>
        </li>
                <?php endwhile;endif; ?>
            <?php endif; ?>
            <?php wp_reset_query(); ?>
          </ul>
          </div>
        </div>
        <div class="center">
        <ul class="center-list">
            <?php query_posts('orderby=rand&ignore_sticky_posts=1&showposts=8');
            if (have_posts()) :
               while (have_posts()) : the_post();?>
        <li class="center-item"><a href="<?php the_permalink(); ?>" rel="bookmark external ">
                <?php $thumb_img = has_post_thumbnail() ? get_the_post_thumbnail( $post->ID, array(110,110), array('alt' => trim(strip_tags( $post->post_title ))) ) : get_post_img(110,110,2);?>
                <span class="center-item-title"><?php the_title(); ?></span>
                <?php echo $thumb_img;?> 
                </a></li>
            <?php endwhile;endif; ?>
            <?php wp_reset_query(); ?>
          </ul>
        </div>
        <div class="right"><?php if (get_option('ini_right')!="") { ?><?php echo stripslashes(get_option('ini_right')); ?><?php } else { ?><div style="height:230px;font-size:18px;color:#ccc;background:#f6f6f6;text-align:center;padding:20px;">请到后台 - 外观 - Initial主题设置 - 自定义代码里添加代码</div><?php } ?>
    </div>
</div>
</div>
<?php } ?>