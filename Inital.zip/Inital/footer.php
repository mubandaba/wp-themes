<div id="footer">
<div id="footer-body">
<div id="footer-content">
<?php if (get_option('ini_footer')!="") { ?><?php echo stripslashes(get_option('ini_footer')); ?><?php } else { ?><div style="font-size:18px;color:#ccc;">请到后台 - 外观 - Initial主题设置 - 自定义代码里添加代码</div><?php } ?>
</div>
<div id="footer-copyright">
Copyright <?php echo comicpress_copyright(); ?><a href="<?php bloginfo('url') ?>"> <?php bloginfo('name') ?></a>. <?php if (get_option('ini_beian')!="") { ?><?php echo stripslashes(get_option('ini_beian'));echo '. '; ?><?php } ?>Theme By <a href="http://icaoye.com"> Cleris</a>, Powered By <a rel="external nofollow" href="http://www.wordpress.org/"> WordPress.</a>
</div>
</div>
<div style="display:none;" id="gotop" class="navbtn btn"></div>
<div style="display:none;" id="cmt" class="navbtn btn"></div>
</div>

<script src="<?php bloginfo('template_directory'); ?>/js/Initial.min.js"></script>
<?php if ( is_singular() ){ ?><script src="<?php bloginfo('template_directory'); ?>/js/comments-ajax.js"></script><?php } if (get_option('ini_fancybox') == 'Display') { ?><script src="<?php bloginfo('template_directory');?>/js/fancybox.js"></script><?php } if (get_option('ini_prettify') == 'Display') { ?><script src="<?php bloginfo('template_directory');?>/js/prettify.js"></script><?php } ?>
<script>
$(document).ready(function() {$("a[rel=img]").fancybox({'transitionIn':'elastic','transitionOut':'elastic','titlePosition':'outside','titleFormat':function(title,currentArray,currentIndex,currentOpts){return 'Image ' + (currentIndex + 1) + ' / ' + currentArray.length + (title.length ? ' &nbsp; ' + title : '');}});$("a[rel=page]").fancybox({'titlePosition':'outside','transitionIn':'elastic','transitionOut':'elastic'});}); //fancybox
jQuery(document).ready(function (a) {var <?php if (is_home()) { echo stripslashes(get_option('ini_roller_home')); } else {echo stripslashes(get_option('ini_roller'));}?>a.browser.msie && 6 == a.browser.version && !a.support.style || (f = a("#sidebar").width(), g = a("#sidebar .widget"), h = g.length, h >= (c > 0) && h >= (d > 0) && a(window).scroll(function () {var b = document.documentElement.scrollTop + document.body.scrollTop;b > g.eq(h - 1).offset().top + g.eq(h - 1).height() ? 0 == a(".roller").length ? (g.parent().append('<div class="roller"></div>'),g.eq(c - 1).clone().appendTo(".roller"),c !== d && g.eq(d - 1).clone().appendTo(".roller"),d !== e && g.eq(e - 1).clone().appendTo(".roller"),a(".roller").css({position: "fixed",top: 50,zIndex: 0,width: 250}), a(".roller").width(f)) : a(".roller").fadeIn(300) : a(".roller").fadeOut(300)}))});
<?php if (get_option('ini_bdtj') == 'Display') { ?>var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%<?php echo stripslashes(get_option('ini_bdtjcode')); ?>' type='text/javascript'%3E%3C/script%3E"));
<?php } if (get_option('ini_ggtj') == 'Display') { ?>(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,'script','//www.google-analytics.com/analytics.js','ga');ga('create', '<?php echo stripslashes(get_option('ini_ggtjcode')); ?>', '<?php echo stripslashes(get_option('ini_ggtjym')); ?>');ga('send', 'pageview');
<?php } if (is_singular()) { if (get_option('ini_bdshare') == 'Display') {?>
function bds_content(){var content=jQuery(".entry-content").html();content = content.replace(/<\/?[^>]*>/g,'');content = content.replace(/&nbsp;/g,'');return content;};var bds_config={'bdText':bds_content(),"snsKey":{'tsina':'4120318029'}};document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000)
<?php } } ?>
</script>
<!--[if lt IE 7]><script src="<?php bloginfo('template_directory'); ?>/js/killie6.js"></script><![endif]-->
<?php wp_footer(); ?>
</div>
</body>
</html>