<?php 
//搜索框插件
class cy_search extends WP_Widget {
    function cy_search() {
        $widget_ops = array('description' => '用于搜索本站内容的工具');
        $this->WP_Widget('cy_search', '草野插件：搜索框', $widget_ops);
    }
    function widget() {?>
        <div class="widget search">
            <form class="search-form" method="get" action="<?php bloginfo('home'); ?>">
                <input type="submit" value="?" class="search-submit btn"/>
                <input type="text" class="s" name="s" value=""/>
            </form>
        </div>
        <?php
    }
}
register_widget('cy_search');
?>