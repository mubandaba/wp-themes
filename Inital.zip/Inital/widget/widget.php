<?php

if (function_exists('register_sidebar')){
register_sidebar(array(
'name'=> '首页侧边栏',
'before_widget'=> '<div class="widget %2$s">',
'after_widget'=> '</div>',
'before_title'=> '<h3><span>',
'after_title'=> '</span></h3>',
));
register_sidebar(array(
'name'=> '其他侧边栏',
'before_widget'=> '<div class="widget %2$s">',
'after_widget'=> '</div>',
'before_title'=> '<h3><span>',
'after_title'=> '</span></h3>',
));
}

include('widget-search.php');
include('widget-tab.php');
include('widget-comment.php');
include('widget-tags.php');
include('widget-readers.php');
include('widget-statistics.php');

function unregister_default_wp_widgets() {
unregister_widget('WP_Widget_Search');
unregister_widget('WP_Widget_Tag_Cloud');
unregister_widget( 'WP_Widget_Recent_Comments' );
}
add_action('widgets_init','unregister_default_wp_widgets');
add_filter( 'pre_option_link_manager_enabled', '__return_true' );
?>