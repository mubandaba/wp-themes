<?php get_header(); ?>
<div id="content">
<div class="main">
<?php include('includes/map.php'); ?>
<?php if (have_posts()) : ?>
	<?php while (have_posts()) : the_post(); ?>
<ul <?php post_class(); ?> id="post-<?php the_ID(); ?>">
<li><?php include('article.php'); ?></li>
</ul>
		<?php endwhile; else: ?>
<div class="article">
<h3 class="center">抱歉，亲，还木有匹配的信息...</h3>
<br>
<h3 class="center">随便看看：</h3>
<ul class="tab_post_links"><?php $myposts = get_posts("numberposts=15&orderby=rand");foreach($myposts as $post) :?>
<li><a rel="bookmark" href="<?php echo get_permalink( $post->ID ); ?>" rel="bookmark external" title="<?php echo $post->post_title; ?>"><?php echo $post->post_title; ?></a></li>
<?php endforeach; ?>
</ul>
</div>
		<?php endif; ?> 
<div class="navigation"><?php pagination($query_string); ?></div>
</div>
</div>
<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>