<address id="map">
<a href="<?php bloginfo('url') ?>" >Home</a>
 &gt; <?php
if( is_single() ){
$categorys = get_the_category();
$category = $categorys[0];
echo is_wp_error( $category_parents = get_category_parents($category->term_id,true,' &gt; ') ) ? '' : $category_parents;echo' 正文';
} elseif ( is_page() ){
the_title();
} elseif ( is_category() ){
single_cat_title();
} elseif ( is_tag() ){
single_tag_title();
} elseif ( is_day() ){
the_time('Y年n月j日');echo"发布的文章";
} elseif ( is_month() ){
the_time('Y年n月');echo"发布的文章";
} elseif ( is_year() ){
the_time('Y年');echo"发布的文章";
} elseif ( is_search() ){
echo '包含词条“'.$s.'”的内容';
}
else
{}
?>
</address>