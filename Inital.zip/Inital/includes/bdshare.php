<span class="entry-content" style="display:none;">【<?php the_title(); ?>】：<?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 180,"...");if (get_option('ini_uid')!=="") { echo stripslashes(get_option('ini_uid'));} else { echo '来自 ';bloginfo('name');}?>：</span>
<div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare">
<a class="bds_tsina"></a>
<a class="bds_tqq"></a>
<a class="bds_qzone"></a>
<a class="bds_renren"></a>
<a class="bds_fbook"></a>
<a class="bds_twi"></a>
<span class="bds_more"></span>
<a class="shareCount"></a>
</div>
<div style="display:none;" id="share" class="navbtn btn"></div>
<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=1013580" ></script>
<script type="text/javascript" id="bdshell_js"></script>