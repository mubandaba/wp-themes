<div class="related-post">
<?php
  $post_num = stripslashes(get_option('ini_postnum')); 
  global $post;
  $tmp_post = $post;
  $tags = ''; $i = 0;
  if ( get_the_tags( $post->ID ) ) {
  foreach ( get_the_tags( $post->ID ) as $tag ) $tags .= $tag->name . ',';
  $tags = strtr(rtrim($tags, ','), ' ', '-');
  $myposts = get_posts('numberposts='.$post_num.'&tag='.$tags.'&exclude='.$post->ID);
  foreach($myposts as $post) {
  setup_postdata($post);
  ?>
      <a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="external">
      <?php $thumb_img = has_post_thumbnail() ? get_the_post_thumbnail( $post->ID, array(110,110), array('alt' => trim(strip_tags( $post->post_title ))) ) : get_post_img( 110, 110, 2);?>
<?php echo $thumb_img;?>
      <h2><?php the_title();?></h2>
      </a>
<?php
  $i += 1;
  }
  }
  if ( $i < $post_num ) {
  $post = $tmp_post; setup_postdata($post);
  $cats = ''; $post_num -= $i;
  foreach ( get_the_category( $post->ID ) as $cat ) $cats .= $cat->cat_ID . ',';
  $cats = strtr(rtrim($cats, ','), ' ', '-');
  $myposts = get_posts('numberposts='.$post_num.'&category='.$cats.'&exclude='.$post->ID);
  foreach($myposts as $post) {
  setup_postdata($post);
  ?>
      <a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="external">
      <?php $thumb_img = has_post_thumbnail() ? get_the_post_thumbnail( $post->ID, array(110,110), array('alt' => trim(strip_tags( $post->post_title ))) ) : get_post_img( 110, 110, 2);?>
<?php echo $thumb_img;?>
      <h2><?php the_title();?></h2>
      </a>
  <?php
  }
  }
  $post = $tmp_post; setup_postdata($post);
  ?>
<div class="clear"></div>
</div>