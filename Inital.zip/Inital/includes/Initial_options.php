<?php

$themename = "Initial";
$shortname = "ini";

//Stylesheets Reader
$alt_stylesheet_path = TEMPLATEPATH . '/css/';
$alt_stylesheets = array();
$alt_stylesheets[] = '';

if ( is_dir($alt_stylesheet_path) ) {
	if ($alt_stylesheet_dir = opendir($alt_stylesheet_path) ) { 
		while ( ($alt_stylesheet_file = readdir($alt_stylesheet_dir)) !== false ) {
		if(stristr($alt_stylesheet_file, ".css") !== false) {
			$alt_stylesheets[] = $alt_stylesheet_file;
		}
		}	
	}
}

$options = array (
	array( "name" => $themename." Options","type" => "title"),

//SEO设置
	array( "name" => "网站SEO设置（必填）","type" => "section"),

	array(	"name" => "描述（Description）",
		"desc" => "",
		"id" => $shortname."_description",
		"type" => "textarea",
		"std" => "输入您的网站描述，一般不超过200个字符"),

	array(	"name" => "关键词（KeyWords）",
		"desc" => "",
		"id" => $shortname."_keywords",
		"type" => "textarea",
		"std" => "输入您的网站关键字，一般不超过100个字符"),
	array( "type" => "close"),

//站点信息设置
	array( "name" => "站点信息设置","type" => "section"),

	array(	"name" => "订阅地址",
		"desc" => "设置导航栏里的订阅按钮，留空则使用RSS2订阅",
		"id" => $shortname."_rss",
		"type" => "text"),

	array( "name" => "新浪微博",
		"desc" => "设置导航栏里的新浪微博地址，留空则不显示微博图标",
		"id" => $shortname."_weibo",
		"type" => "text"),

	array( "name" => "邮箱地址",
		"desc" => "设置导航栏里的收件邮箱，默认使用管理员邮箱",
		"id" => $shortname."_mail",
		"type" => "text"),

	array( "name" => "Google+ ID",
		"desc" => "用于显示主站谷歌搜索结果中的作者信息，可到 <a href='https://www.google.com.hk/webmasters/tools/richsnippets' target='_blank'>这里</a> 测试，其他作者请到 <a href='".get_bloginfo(url)."/wp-admin/profile.php' target='_blank'>个人资料</a> 填写信息",
		"id" => $shortname."_ggplus",
		"type" => "text"),

	array( "name" => "您的备案号",
		"desc" => "如有备案号，直接输入即可在footer中显示，留空则不显示",
		"id" => $shortname."_beian",
		"type" => "text"),

	array( "name" => "评论提示",
		"desc" => "评论为空时的提示语",
		"id" => $shortname."_cmtinfo",
		"type" => "text",
		"std" => "沙发空闲中，快来抢！",),
	array( "type" => "close"),

//功能模块设置
	array( "name" => "功能模块设置","type" => "section"),

	array( "name" => "搜索按钮",
		"desc" => "设置导航栏里的搜索按钮，<span style='color:red'>默认隐藏侧边栏时自动显示</span>，如需一直显示可开启此功能",
		"id" => $shortname."_search",
		"type" => "select",
		"options" => array("Hide", "Display")),

	array( "name" => "评论头像",
		"desc" => "评论中是否显示头像 | <span style='color:red'>默认显示</span>",
		"id" => $shortname."_type",
		"type" => "select",
		"options" => array("Display", "Hide")),

	array( "name" => "头像缓存",
		"desc" => "评论头像本地缓存，需要在根目录建立avatar文件夹，并且还要有默认头像default.jpg | <span style='color:red'>默认关闭</span>",
		"id" => $shortname."_avatar",
		"type" => "select",
		"options" => array("Hide", "Display")),

	array( "name" => "评论表情",
		"desc" => "是否开启评论表情 | <span style='color:red'>默认开启</span>",
		"id" => $shortname."_smiley",
		"type" => "select",
		"options" => array("Display", "Hide")),

	array( "name" => "百度分享按钮",
		"desc" => "开启百度分享按钮，显示在文章下方，同时页面右侧出现导航按钮 | <span style='color:red'>默认关闭</span>",
		"id" => $shortname."_bdshare",
		"type" => "select",
		"options" => array("Hide", "Display")),

	array( "name" => "微博昵称",
		"desc" => "读者分享文章时@的对象，如：<strong>@柳飘清枫</strong>，留空则显示：<strong>来自 ".get_bloginfo(name)."</strong> | <span style='color:red'>需要开启百度分享</span>",
		"id" => $shortname."_uid",
		"type" => "text",
		"std" => ""),

	array( "name" => "作者信息",
		"desc" => "在文章页面显示作者信息，请到 <a href='".get_bloginfo(url)."/wp-admin/profile.php' target='_blank'>个人资料</a> 填写，个人说明简短为好 | <span style='color:red'>默认不显示</span>",
		"id" => $shortname."_author",
		"type" => "select",
		"options" => array("Hide", "Display")),

	array( "name" => "Fancybox",
		"desc" => "使用Fancybox预览图片 | <span style='color:red'>默认关闭</span>",
		"id" => $shortname."_fancybox",
		"type" => "select",
		"options" => array("Hide", "Display")),

	array( "name" => "代码高亮",
		"desc" => "使用prettify代码高亮 | <span style='color:red'>默认关闭</span>",
		"id" => $shortname."_prettify",
		"type" => "select",
		"options" => array("Hide", "Display")),

	array( "name" => "首页幻灯片",
		"desc" => "首页幻灯片显示文章的数量，不要超过10篇，建议6篇",
		"id" => $shortname."_num",
		"type" => "text",
		"std" => "6",),

	array( "name" => "相关文章",
		"desc" => "相关文章的数量，建议7或14",
		"id" => $shortname."_postnum",
		"type" => "text",
		"std" => "7",),

	array( "name" => "首页侧边栏滑动模块",
		"desc" => "设置首页侧边栏跟随滑动的小工具，当侧边栏滚动结束时跟随滑动，更改小工具序号（数字）即可，最多设置三个 | <span style='color:red'>默认显示前两个</span>",
		"id" => $shortname."_roller_home",
		"type" => "text",
		"std" => "c = 1 ,d = 2 ,e = 999 ;"),

	array( "name" => "侧边栏滑动模块",
		"desc" => "其他页面跟随滑动的小工具，更改小工具序号（数字）即可，最多设置三个 | <span style='color:red'>默认显示前两个</span>",
		"id" => $shortname."_roller",
		"type" => "text",
		"std" => "c = 1 ,d = 2 ,e = 999 ;"),
	array( "type" => "close"),

//网站统计
	array( "name" => "网站统计设置","type" => "section"),

	array( "name" => "百度统计",
		"desc" => "启用百度统计来分析网站数据，需要输入您的跟踪ID才能正确安装 | <span style='color:red'>默认关闭</span>",
		"id" => $shortname."_bdtj",
		"type" => "select",
		"options" => array("Hide", "Display")),

	array( "name" => "百度统计代码",
		"desc" => "",
		"id" => $shortname."_bdtjcode",
		"type" => "text",
		"std" => "example: 6F368b998d5fc627c7dd92063108cf49ee"),

	array( "name" => "谷歌统计",
		"desc" => "启用谷歌统计来分析网站数据，需要输入您的跟踪ID以及域名才能正确安装 | <span style='color:red'>默认关闭</span>",
		"id" => $shortname."_ggtj",
		"type" => "select",
		"options" => array("Hide", "Display")),

	array( "name" => "谷歌统计代码",
		"desc" => "",
		"id" => $shortname."_ggtjcode",
		"type" => "text",
		"std" => "example: UA-69986668-1"),

	array( "name" => "网站域名",
		"desc" => "",
		"id" => $shortname."_ggtjym",
		"type" => "text",
		"std" => "icaoye.com"),
	array( "type" => "close"),

//自定义代码
	array( "name" => "自定义代码","type" => "section"),

	array( "name" => "介绍",
		"desc" => "以下内容需要一定的代码知识，您可以在这里自由的发挥，输入任何想要分享的内容，如站内公告、广告、友情链接等等，也可以是一些日常琐碎，总之，相信您一定会利用好这里的各个模块。",
		"id" => $shortname."_introduction",
		"type" => "introduction"),

	array(	"name" => "首页顶部模块",
		"desc" => "首页顶部右侧显示的内容，该模块宽度自适应，最大宽度360px，最小宽度240px，高度230px",
		"id" => $shortname."_right",
		"type" => "textarea"),

	array(	"name" => "页面底部信息",
		"desc" => "页面footer一栏显示的内容",
		"id" => $shortname."_footer",
		"type" => "textarea"),
	array( "type" => "close"),

//SMTP邮箱设置
	array( "name" => "SMTP邮箱设置","type" => "section"),

	array( "name" => "发件人地址：",
		"desc" => "",
		"id" => $shortname."_smtp_from",
		"type" => "text"),

	array( "name" => "发件人昵称：",
		"desc" => "",
		"id" => $shortname."_smtp_fromname",
		"type" => "text"),

	array( "name" => "SMTP服务器地址：",
		"desc" => "",
		"id" => $shortname."_smtp_host",
		"type" => "text",
		"std" => ""),

	array( "name" => "SMTP端口：",
		"desc" => "SMTP邮件发送端口，常用端口有：25、465、587（后两个为ssl安全连接端口）",
		"id" => $shortname."_smtp_port",
		"type" => "text",
		"std" => ""),

	array( "name" => "SMTP加密方式：",
		"desc" => "SSL/TLS，不明白此处设置别选，以免设置错误，无法正常发送邮件",
		"id" => $shortname."_smtp_secure",
		"type" => "select",
		"options" => array(" ","SSL","TLS")),

	array( "name" => "邮箱帐号：",
		"desc" => "",
		"id" => $shortname."_smtp_username",
		"type" => "text",
		"std" => ""),

	array( "name" => "邮箱密码：",
		"desc" => "",
		"id" => $shortname."_smtp_password",
		"type" => "password",
		"std" => ""),

array( "type" => "close"),
);

function mytheme_add_admin() {
global $themename, $shortname, $options;
if ( $_GET['page'] == basename(__FILE__) ) {
	if ( 'save' == $_REQUEST['action'] ) {
		foreach ($options as $value) {
	update_option( $value['id'], $_REQUEST[ $value['id'] ] ); }
foreach ($options as $value) {
	if( isset( $_REQUEST[ $value['id'] ] ) ) { update_option( $value['id'], $_REQUEST[ $value['id'] ] ); } else { delete_option( $value['id'] ); } }
	header("Location: admin.php?page=Initial_options.php&saved=true");
die;
}
else if( 'reset' == $_REQUEST['action'] ) {
	foreach ($options as $value) {
		delete_option( $value['id'] ); }
	header("Location: admin.php?page=Initial_options.php&reset=true");
die;
}
}
add_theme_page($themename." Options", "Initial主题设置", 'edit_themes', basename(__FILE__), 'mytheme_admin');
}

function mytheme_admin() {
global $themename, $shortname, $options;
$i=0;
if ( $_REQUEST['saved'] ) echo '<div id="message" class="updated fade"><p>'.$themename.' 主题设置已保存</p></div>';
if ( $_REQUEST['reset'] ) echo '<div id="message" class="updated fade"><p>'.$themename.' 主题已重新设置</p></div>';
?>

<div class="wrap Initial_wrap">
<link rel="stylesheet" href="<?php bloginfo('template_url') ?>/includes/Initial_options.css"/>
<script>
jQuery(document).ready(function(){
	jQuery('.Initial_options').slideUp();
	jQuery('.Initial_section h3').click(function(){
		if(jQuery(this).parent().next('.Initial_options').css('display')=='none')
			{	jQuery(this).removeClass('inactive');
				jQuery(this).addClass('active');
				jQuery(this).children('span').removeClass('inactive');
				jQuery(this).children('span').addClass('active');
			}
		else
			{	jQuery(this).removeClass('active');
				jQuery(this).addClass('inactive');
				jQuery(this).children('span').removeClass('active');
				jQuery(this).children('span').addClass('inactive');
			}
		jQuery(this).parent().next('.Initial_options').slideToggle('slow');
	});
});
</script>
<h2><?php echo $themename; ?> 设置页面</h2>
<br>
<div class="header">
<span style="font-size:14px;">主题：Initial 0.8<span style="margin-left:60px;">作者：<a href="http://icaoye.com" rel="external">柳飘清枫</a></span><br>
</span>
<p class="Initial_introduction">
亲，欢迎您使用 Initial 主题，您可以根据自己的需要设置以下项目。<br>
Display = 显示/开启　　Hide = 不显示/关闭<br>
<span style="color:red">如果设置出错可以点击“恢复默认”按钮，将所有设置恢复至初始状态，不到不得已千万别点击这个按钮哦！</span>
<form method="post">
<input name="reset" type="submit" value="恢复默认" class="button" title="您真的想好了吗？" /></p>
<input type="hidden" name="action" value="reset" />
</form>
</div>
<br>
<div class="Initial_opts">
<form method="post" name="form">
<?php foreach ($options as $value) {
switch ( $value['type'] ) {
case "open":
?>
<?php break;
case "close":
?>
</div>
</div>
<br>
<?php break;
case "title":
?>
<?php break;
case "introduction":
?>
<div class="Initial_input Initial_introduction" >
<?php echo $value['desc']; ?><div class="clear"></div>
 </div>
<?php break;
case 'text':
?>
<div class="Initial_input Initial_text">
	<label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
	<input name="<?php echo $value['id']; ?>" type="text" value="<?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id']) ); } else { echo $value['std']; } ?>" />
 <small><?php echo $value['desc']; ?></small><div class="clear"></div>
 </div>
 <?php break;
case 'password':
?>
<div class="Initial_input Initial_password">
	<label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
	<span id=box><input name="<?php echo $value['id']; ?>" type="password" value="<?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id']) ); } else { echo $value['std']; } ?>" /></span>
 <small><?php echo $value['desc']; ?></small><div class="clear"></div>
 </div>
<?php break;
case 'textarea':
?>
<div class="Initial_input Initial_textarea">
	<label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
	<textarea name="<?php echo $value['id']; ?>" type="textarea" cols="" rows="" onclick="if(this.value == '<?php echo $value['std']; ?>'){this.value = '';}" onblur="if(this.value == ''){this.value = '<?php echo $value['std']; ?>';}"><?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id']) ); } else { echo $value['std']; } ?></textarea>
 <small><?php echo $value['desc']; ?></small><div class="clear"></div>
 </div>
<?php
break;
case 'select':
?>
<div class="Initial_input Initial_select">
	<label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
	<select name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>">
<?php foreach ($value['options'] as $option) { ?>
		<option value="<?php echo $option;?>" <?php if (get_settings( $value['id'] ) == $option) { echo 'selected="selected"'; } ?>>
		<?php
		if ((empty($option) || $option == '' ) && isset($value['default_option_value'])) {
		echo $value['default_option_value'];
		} else {
		echo $option; 
		}?>
		
		</option><?php } ?>
</select>
	<small><?php echo $value['desc']; ?></small><div class="clear"></div>
</div>
<?php
break;
case "checkbox":
?>
<div class="Initial_input Initial_checkbox">
	<label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
<?php if(get_option($value['id'])){ $checked = "checked=\"checked\""; }else{ $checked = "";} ?>
<input type="checkbox" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" value="true" <?php echo $checked; ?> />
	<small><?php echo $value['desc']; ?></small><div class="clear"></div>
 </div>
<?php break; 
case "section":
$i++;
?>
<div class="Initial_section">
<div class="Initial_title"><h3><span class="inactive" alt=""></span><?php echo $value['name']; ?></h3><span class="submit"><input name="save<?php echo $i; ?>" type="submit" value="保存设置" class="button" />
</span><div class="clear"></div>
</div>
<div class="Initial_options">
<?php break;
}
}
?>
<input type="hidden" name="action" value="save" />
</form>
</div>
<?php }
add_action('admin_menu', 'mytheme_add_admin');
?>