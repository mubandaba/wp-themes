<?php
$t1=$post->post_date;
$t2=$post->post_modified;
$t3=date("Y-m-d H:i:s");
$diff=(strtotime($t3)-strtotime($t1))/10800;
$diff2=(strtotime($t3)-strtotime($t2))/10800;
if($diff<24){
    echo '<span class="webkit"><span class="new"></span></span>';
}
else {
    if((get_the_modified_time('Y')*365+get_the_modified_time('z')) > (get_the_time('Y')*365+get_the_time('z'))) {
        if($diff2<24){echo '<span class="webkit"><span class="update"></span></span>';}
    }
}
?>