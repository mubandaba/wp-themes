<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8" />
<title>I'M 404 | <?php bloginfo('name');?></title>
<style>
html{background:#f6f6f6;}
body{font:14px/18px "open sans","sans-serif";}
h2{font-size:32px;line-height:48px;font-weight:normal;background:-webkit-gradient(linear,0% 0%,0% 100%,from(rgba(120,120,120,.6)),to(rgba(0, 0, 0, 1)));-webkit-text-fill-color:transparent;-webkit-background-clip:text;}
#content{width:50%;height:60%;min-width:400px;min-height:240px;_width:420px;_height:240px;margin:10% auto;background:#f2f2f2;border:1px solid #e6e6e6;border-radius:6px;}
#ShowDiv{width:100%;height:30px;line-height:30px;font-size:24px;text-align:center;position:relative;margin-top:60px;background:-webkit-gradient(linear,0% 0%,0% 100%,from(rgba(120,120,120,.6)),to(rgba(0, 0, 0, 1)));-webkit-text-fill-color:transparent;-webkit-background-clip:text;}
</style>
<script>
var secs=9;
var URL;
function Load(url){
URL=url;
for(var i=secs;i>=0;i--){window.setTimeout('doUpdate('+i+')',(secs-i)*1000);}
}
function doUpdate(num){
document.getElementById('ShowDiv').innerHTML='Page will jump in '+num+' s';
if(num == 0){window.location=URL;}
}
Load("<?php bloginfo('url');?>");
</script>
</head>
<body>
<div id="content">
<h2 align="center">Stay Hungry,Stay Foolish!</h2>
<div id="ShowDiv"></div>
</div>
</body>
</html>