<?php get_header(); ?>
<div id="content">
<div class="main">
<?php include('includes/map.php'); ?>
<?php if (have_posts()) : ?>
	<?php while (have_posts()) : the_post(); ?>
<ul <?php post_class(); ?> id="post-<?php the_ID(); ?>">
<li><?php include('article.php'); ?></li>
</ul>
<?php endwhile; ?>
<?php endif; ?>
<div class="navigation"><?php pagination($query_string); ?></div>
</div>
</div>
<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>