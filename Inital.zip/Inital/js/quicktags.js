// 五对引号，分别是按钮ID、显示名、点一下输入内容、再点一下关闭内容、提示文字，\n表示换行
QTags.addButton( 'code', 'code', '[code lang="" start="" highlight=""]', '[/code]','','代码高亮' );
QTags.addButton( 'bright', 'bright', '<span class="bright">', '</span>','','高亮文字' );
QTags.addButton( 'download', 'dl', '<span class="download"><a title="" href="">', '</a></span>','','下载按钮' );
QTags.addButton( 'u-download', 'u-dl', '<span class="u-download"><a title="" rel="external nofollow" href="">', '</a></span>','','外链下载按钮' );
QTags.addButton( 'nextpage', 'next', '<!--nextpage-->\n', '','','添加分页' );
QTags.addButton( 'center', 'center', '<p style="text-align:center;">', '</p>','','居中' );
QTags.addButton( 'h3', 'h3', '<h3>', '</h3>' );
QTags.addButton( 'h4', 'h4', '<h4>', '</h4>' );
QTags.addButton( 'h5', 'h5', '<h5>', '</h5>' );
QTags.addButton( 'h6', 'h6', '<h6>', '</h6>' );