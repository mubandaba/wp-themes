<?php /*Template Name:Guestbook*/ ?>
<?php get_header(); ?>
<div id="content">
<div class="main">
<?php if (have_posts()) :while (have_posts()) :the_post(); ?>
<style>
.v_comment ul{padding-top:14px;}
.v_comment ul li{list-style-type:none;display:inline;}
.v_comment img{height:50px;width:50px;float:left;padding:0px;margin:0px;margin:6px;padding:3px;background:#EEE;border:1px solid #E6E6E6;}
.v_comment img:hover{margin:2px 6px 10px;box-shadow:0 3px 9px 1px #F90;}
</style>
<div class="article">
<h2 class="title entry-title" property="v:title" style="text-align:center;font-size:1.5rem;font-weight:800;"><?php the_title(); ?></h2>
<div class="context" property="v:description">
<p style="text-align:center;"><img src="<?php bloginfo('template_directory'); ?>/images/water.jpg" width="600" height="240" />
</p>
<?php the_content(); ?>
</div>
<div class="clear" style="height:30px;"></div>
<div class="v_comment"><ul>
<?php
$query="SELECT COUNT(comment_ID) AS cnt, comment_author, comment_author_url, comment_author_email FROM (SELECT * FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->posts.ID=$wpdb->comments.comment_post_ID) WHERE comment_date > date_sub( NOW(), INTERVAL 1 MONTH ) AND user_id='0' AND comment_author_email != '' AND post_password='' AND comment_approved='1' AND comment_type='') AS tempcmt GROUP BY comment_author_email ORDER BY cnt DESC LIMIT 60";
$wall = $wpdb->get_results($query);
foreach ($wall as $comment)
{
if( $comment->comment_author_url )
$url = $comment->comment_author_url;
else $url="#";
$r="rel='external nofollow'";
$tmp = "<a class='add-title' href='".$url."' ".$r." title='".$comment->comment_author." (留下".$comment->cnt."个脚印)'>".get_avatar( $comment->comment_author_email, 40, get_bloginfo('template_directory'). '/images/avatar.jpg' )."</a>";
$output .= $tmp;
}
echo $output ;?></ul></div> 
<div class="clear"></div>
</div>
<div id="comments"><?php comments_template(); ?></div>
<?php endwhile; else:?>
<?php endif; ?>
</div>
</div>
<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>