<?php get_header(); ?>
<div id="content">
<div class="main">
<?php include('includes/map.php'); ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
<h2 class="title entry-title" property="v:title">
<a  rel="me" href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
</h2>

<meta property="v:url" content="<?php the_permalink() ?>" />
<meta property="v:type" content="article" />

<div class="article-info">
<i class="icon-copyright"></i>
<span class="vcard author">
<?php $custom_fields = get_post_custom_keys($post_id);  if (!in_array ('copyright', $custom_fields)) : if (get_the_author_meta('ggplus')!="") : ?><a href="https://plus.google.com/<?php the_author_meta('ggplus'); ?>?rel=author"></a><?php endif ?>
<a class="fn" href="<?php bloginfo('url') ?>"><?php the_author('nickname'); ?></a>
<?php else: ?>
<?php $custom = get_post_custom($post_id);$custom_url=$custom['copyrighturl'] ;$custom_value = $custom['copyright']; ?>
<a class="fn" rel="nofollow external" href="<?php echo $custom_url[0] ?>" ><?php echo $custom_value[0] ?></a>
<?php endif; ?>
</span>
<i class="icon-time"></i>
<?php if ((get_the_modified_time('Y')*365+get_the_modified_time('z')) > (get_the_time('Y')*365+get_the_time('z'))) { ?>
<span class="date updated" style="display:none;"><?php the_modified_time('Y-m-d  H:i') ?></span>
<span>
<?php } else { ?>
<span class="date updated"><?php } ?>
<time property="v:datePublished" datetime="<?php the_modified_time('Y-m-d') ?>">
<abbr title="最后更新: <?php the_modified_time('n月, j日, Y年  H:i, l') ?>" style="cursor:help" ><?php the_time('Y-m-d') ?></abbr>
</time>
</span>
<i class="icon-category"></i>
<span><?php the_category(', ') ?></span>
<i class="icon-view"></i>
<span><?php get_post_views($post -> ID) ?> 次浏览</span>
<i class="icon-comment"></i>
<span><?php comments_popup_link ('0条评论','1条评论','%条评论'); ?></span>
</div>
<div class="clear"></div>

<div class="context" property="v:description">
<?php the_content(); ?>
</div>
<?php single_fenye();?>
<div class="single-tags"><?php getColorTags(); ?></div>
<?php if (get_option('ini_bdshare') == 'Display') { include('includes/bdshare.php'); }?>
<div class="clear"></div>

<div class="post-nav">
<div class="post-prev">
<?php $prev_post = get_previous_post(); if (get_previous_post()) {?>
  上一篇：<a title="<?php echo $prev_post->post_title; ?>" href="<?php echo get_permalink( $prev_post->ID ); ?>"><?php echo $prev_post->post_title; ?></a><?} else { echo " ";} ?>
</div>
<div class="post-next">
<?php $next_post = get_next_post(); if (get_next_post()) {?>
  下一篇：<a title="<?php echo $next_post->post_title; ?>" href="<?php echo get_permalink( $next_post->ID ); ?>"><?php echo $next_post->post_title; ?></a><?} else { echo "如果给等待加一个期限，你希望是多久...";} ?>
</div>
</div>

<?php echo feed_copyright();?>
<? if (get_option('ini_author') == ('Display')) { ?>
<div class="post-info"><span class="avatar"><?php echo get_avatar( get_the_author_email(), '70' ); ?></span>
<div>
<a class="post-author-name" title="查看他/她的专栏" href="<?php echo get_author_posts_url( $authordata->ID ); ?>" rel="external"><?php the_author('nickname'); ?></a><br>
<div class="post-author-desc"><?php  echo the_author_meta( 'description' ); ?></div>
<div class="post-author-links">
<a href="<?php echo get_author_posts_url( $authordata->ID ); ?>" rel="external">查看他/她的专栏</a><?php if (get_the_author_meta('weibo_sina')!=""){ ?><a href="<?php the_author_meta('weibo_sina');?>" rel="external"> | 新浪微博</a><?php } ?><?php if (get_the_author_meta('weibo_tx')!=""){ ?><a href="<?php the_author_meta('weibo_tx');?>" rel="external"> | 腾讯微博</a><?php } ?><?php if (get_the_author_meta('renren')!=""){ ?><a href="<?php the_author_meta('renren');?>" rel="external"> | 人人网</a><?php } ?>
</div>
<div class="post-info-title">本文小编</div>
</div>
</div>
<?php } ?>
</div>
<?php include('includes/related-post.php'); ?>
<div id="comments"><?php comments_template(); ?></div>
<?php endwhile; else: ?>
<?php endif; ?>
</div>
</div>
<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>