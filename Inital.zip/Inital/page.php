<?php get_header(); ?>
<div id="content">
<div class="main">
<?php include('includes/map.php'); ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<h2 class="title entry-title" property="v:title">
<a  rel="me" href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
</h2>

<meta property="v:url" content="<?php the_permalink() ?>" />
<meta property="v:type" content="article" />

<div class="context" property="v:description">
<span class="entry-content" style="display:none;">【<?php the_title(); ?>】：<?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 180,"..."); ?></span>
<?php the_content(); ?>
</div>
<?php if (get_option('ini_bdshare') == 'Display') { include('includes/bdshare.php'); }?>
<div class="clear"></div>
<div id="comments"><?php comments_template(); ?></div>
<?php endwhile; else: ?>
<?php endif; ?>
</div>
</div>
<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>