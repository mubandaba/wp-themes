<?php get_header(); ?>
<?php if (get_the_author_meta('ggplus',1)!=""){ ?>
<a href="https://plus.google.com/<?php the_author_meta('ggplus',1); ?>?rel=author"></a>
<?php } ?>
<div id="content">
<div class="main">
<?php include('includes/map.php'); ?>
<?php if (have_posts()) : ?>
	<?php while (have_posts()) : the_post(); ?>
<ul <?php post_class(); ?> id="post-<?php the_ID(); ?>">
<li><?php include('article.php'); ?></li>
</ul>
<?php endwhile; ?>
<?php endif; ?>
<div class="navigation"><?php pagination($query_string); ?></div>
</div>
</div>
<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>