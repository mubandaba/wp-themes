</div>
<div class="clear"></div>

<div id="footer">
<div class="cred">Design: <a href="http://www.2zzt.com/">2ZZT</a> | <?php 
/* This theme is powered by wptheme.net, please do NOT remove the comment or anything below. */
			wp_theme_GPL_credits();
/* This theme is powered by wptheme.net, please do NOT remove the comment or anything below. */ ?><br/>
Copyright &copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?> &ndash; <?php bloginfo('description'); ?></div>
<div class='clear'></div>	
</div>
<div class="clear"></div>
</div>

<!-- 返回顶部 -->
<div style="display: none;" id="gotop"></div>
<script type='text/javascript'>
    backTop=function (btnId){
        var btn=document.getElementById(btnId);
        var d=document.documentElement;
        var b=document.body;
        window.onscroll=set;
        btn.onclick=function (){
            btn.style.display="none";
            window.onscroll=null;
            this.timer=setInterval(function(){
                d.scrollTop-=Math.ceil((d.scrollTop+b.scrollTop)*0.1);
                b.scrollTop-=Math.ceil((d.scrollTop+b.scrollTop)*0.1);
                if((d.scrollTop+b.scrollTop)==0) clearInterval(btn.timer,window.onscroll=set);
            },10);
        };
        function set(){btn.style.display=(d.scrollTop+b.scrollTop>100)?'block':"none"}
    };
    backTop('gotop');
</script>
<!-- 返回顶部END -->

<?php wp_footer(); ?>
</body>
</html>