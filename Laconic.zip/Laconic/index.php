<?php wp_get_header(); ?>


<div id="content">
<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>

<div <?php post_class('post rounded') ?> id="post-<?php the_ID(); ?>">
<div class="posts"></div>
<div class="title">

	<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="点击阅读《<?php the_title(); ?>》"><?php the_title(); ?></a></h2>
	<div class="entry-comment-number">
		<span class="number"><?php comments_popup_link ('0','1','%'); ?></span>
		<span class="corner"></span>
	</div>
	<div class="postmeta">
		<div class="metablock"><?php the_author(); ?> |</div> 
		<div class="metablock"><?php the_category(', '); ?> |</div>
		<div class="metablock"><?php the_time('Y-m-j H:i'); ?></div>
	</div>	
<div class="clear"></div>

</div>

<div class="entry">

<?php the_content('阅读全文'); ?>

<div class="clear"></div>
<?php wp_link_pages(array('before' => '<p><strong>Pages: </strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
</div>

	<div class="meta">
		<span class="meat_span"><i class="postll"></i><span><?php if(function_exists('custom_the_views') ) custom_the_views($post->ID); ?></span>人围观</span>
		<span class="meat_span"><i class="postpl"></i><?php comments_popup_link('前去评论', '1条评论', '%条评论'); ?></a></span>
		<span class="meat_span meat_max"><i class="posttag"></i><?php the_tags('标签: ', ', ', '<br />'); ?></span>
	</div>

<div class='clear'></div>



</div>

<?php endwhile; ?>

<div class="clear"></div>

<div class="page_navi"><?php par_pagenavi(9); ?></div>  

<?php else : ?>
		<h1 class="title">Not Found</h1>
		<p>Sorry, but you are looking for something that isn't here.</p>
<?php endif; ?>

</div>
<?php get_sidebar(); ?>
<?php wp_get_footer(); ?>