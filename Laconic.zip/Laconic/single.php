<?php wp_get_header(); ?>

<div id="content">

<?php if (have_posts()) : ?>

<?php while (have_posts()) : the_post(); ?>

<div <?php post_class('post rounded') ?> id="post-<?php the_ID(); ?>">
<div class="posts"></div>
	<div class="title">
		<h2><?php the_title(); ?></h2>
		<div class="entry-comment-number">
			<span class="number"><?php comments_popup_link ('0','1','%'); ?></span>
			<span class="corner"></span>
		</div>
	<div class="postmeta">
		<div class="metablock">作者: <?php the_author(); ?></div> 
		<div class="metablock">分类: <?php the_category(', '); ?></div>
		<div class="metablock">发布时间: <?php the_time('Y-m-j H:i'); ?></div>
		<div class="metablock"><?php if(function_exists('custom_the_views') ) custom_the_views($post->ID); ?>人围观</div>
	</div>
	<div class="clear"></div>	
</div>

<div class="entry">
	<?php the_content('Read the rest of this entry &raquo;'); ?>
	<div class="clear"></div>
	<?php wp_link_pages(array('before' => '<p><strong>Pages: </strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
</div>

<div class="postmeta">
	<div class="metablock"><?php the_tags('标签: ', ', ', '<br />'); ?> </div>
</div>


<div class="like">
<div class="likebox">  
<h4>或许你会感兴趣的文章</h4> 
<!-- Baidu Button BEGIN -->
<div id="bdfx">
<div id="bdshare" class="bdshare_b" style="line-height: 12px;">
<img src="http://bdimg.share.baidu.com/static/images/type-button-1.jpg?cdnversion=20120831" />
<a class="shareCount"></a>
</div>
<script type="text/javascript" id="bdshare_js" data="type=button&amp;uid=741155" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000);
</script>
</div>
<div class="clear"></div>
</div>
<!-- Baidu Button END -->
<ul> 
<?php
$cats = wp_get_post_categories($post->ID);
if ($cats) {
$cat = get_category( $cats[0] );
$first_cat = $cat->cat_ID;
$args = array(
'category__in' => array($first_cat),
'post__not_in' => array($post->ID),
'showposts' => 6,
'orderby' => rand,
'caller_get_posts' => 1);
query_posts($args);
if (have_posts()) :
while (have_posts()) : the_post(); update_post_caches($posts); ?>
<li><span><?php the_time('Y-m-j H:i'); ?></span><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute();
?>"><?php the_title(); ?></a></li>
<?php endwhile; else : ?>
<li>暂无相关文章</li>
<?php endif; wp_reset_query(); } ?>
</ul> 
</div>

<div id="postnavi"> 
	<span class="prev">&laquo; <?php previous_post_link('%link'); ?></span> 
	<span class="next"><?php next_post_link('%link'); ?> &raquo;</span> 
	<div class="clear"></div> 
</div>

</div>

<?php comments_template(); ?>
<?php endwhile; else: ?>

		<h1 class="title">Not Found</h1>
		<p>I'm Sorry,  you are looking for something that is not here. Try a different search.</p>

<?php endif; ?>

</div>

<?php get_sidebar(); ?>
<?php wp_get_footer(); ?>