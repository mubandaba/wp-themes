
<div id="search">
	<form method="get" id="searchform" action="<?php echo home_url() ; ?>" >
	<input id="s" class="" type="text" name="s" onfocus="if(this.value=='search site'){this.value=''};" onblur="if(this.value==''){this.value='search site'};" value="<?php echo esc_html($s, 1); ?>" />

	</form>
</div>
