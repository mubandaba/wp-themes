<?php wp_get_header(); ?>


<div id="content" >
<div class="shead">
<div id="searchpage">
	<form method="get" id="searchpageform" action="<?php echo home_url(); ?>" >
	<input id="sform" class="rounded" type="text" name="s" onfocus="if(this.value=='search site'){this.value=''};" onblur="if(this.value==''){this.value='search site'};" value="<?php echo esc_html($s, 1); ?>" />
	<input id="formsubmit" type="submit" value="Search" />
	</form>
</div>
<p style="margin-top:5px;color: #999;">
<?php
$mySearch =& new WP_Query("s=$s & showposts=-1");
$num = $mySearch->post_count;
echo  $num.'条结果';?>（用时<?php  get_num_queries(); ?> <?php timer_stop(1); ?>秒）
</p>
</div>
<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>
		
<div class="post sbox rounded" id="post-<?php the_ID(); ?>">

<h2 class="stitle"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h2>
<div class="stitlea"><?php the_permalink(); ?></div>

<div class="list"><?php echo mb_strimwidth(strip_tags($post->post_content),0,140,'...');?></div>
<div class="clear"></div>
<span class="searchmeta"> 内容来自： <?php the_author(); ?> 时间： <?php the_time('Y-m-j H:i'); ?> | <?php comments_popup_link('前来评论', '1条评论', '%条评论'); ?></span>	

</div>

	<?php endwhile; ?>

<div class="page_navi"><?php par_pagenavi(9); ?></div> 

	<?php else : ?>
<div class="post">
<div class="entry">
<b>您搜索的词条[<?php the_search_query();?>]没有找到匹配内容</b>

<p>您确定？</p>
<ul>
   <li>  词条是否正确？</li>
   <li>  尝试其他关键词进行搜索？</li>
   <li>  或者返回首页浏览更多内容吧！</li>
</ul>
</div>				
</div>
<?php endif; ?>
</div>
<?php get_sidebar(); ?>
<?php wp_get_footer(); ?>

