<?php wp_get_header(); ?>
<div id="content" >

<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>
		
<div class="post rounded" id="post-<?php the_ID(); ?>">
<div class="posts"></div>
<div class="title">

	<h2><?php the_title(); ?></h2>
	<div class="entry-comment-number">
		<span class="number"><?php comments_popup_link ('0','1','%'); ?></span>
		<span class="corner"></span>
	</div>
	<div class="postmeta">
		<div class="metablock">作者: <?php the_author(); ?></div> 
		<div class="metablock">分类: <?php the_category(', '); ?></div>
		<div class="metablock">发布时间: <?php the_time('Y-m-j H:i'); ?></div>
		<div class="metablock"><?php if(function_exists('custom_the_views') ) custom_the_views($post->ID); ?>人围观</div>
	</div>
<div class="clear"></div>	
</div>


<div class="entry">
<?php the_content('Read the rest of this entry &raquo;'); ?>
		<div class="clear"></div>
 <?php wp_link_pages(array('before' => '<p><strong>Pages: </strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
</div>


</div>
 <?php
      if(comments_open()) {
			  comments_template();
			}
			?>

<?php endwhile; endif; ?>
</div>		

<?php get_sidebar(); ?>
<?php wp_get_footer(); ?>