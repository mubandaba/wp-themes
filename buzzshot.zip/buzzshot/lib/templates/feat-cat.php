<?php
$feat_cat_one = get_theme_option('feat_cat_one');
$feat_cat_two = get_theme_option('feat_cat_two');
$feat_cat_three = get_theme_option('feat_cat_three');
$num = '4';
$eleght = '25';
?>


<?php if( ($feat_cat_one == '' && $feat_cat_two == '' && $feat_cat_three == '' && $feat_cat_four == '' && $feat_cat_five == '') || ($feat_cat_one == 'Choose a category' && $feat_cat_two == 'Choose a category' && $feat_cat_three == 'Choose a category' && $feat_cat_four == 'Choose a category' && $feat_cat_five == 'Choose a category') ): ?>

<?php else: ?>


<div id="homefeat"><div class="innerwrap">



<?php if($feat_cat_one != '' && $feat_cat_one != 'Choose a category') {
$cat_name = get_cat_name($feat_cat_one);
$cat_id = get_cat_ID($cat_name);
?>
<div class="featblk-content">
<div class="homefeatbox blkfeat<?php echo $cat_id; ?>">
<h3><a href="<?php echo get_category_link( $feat_cat_one ); ?>"><?php echo get_cat_name($feat_cat_one); ?></a></h3>

<?php //$catdesc = category_description( $cat_id ); if($catdesc) { echo '<span class="homefeat-desc">'.category_description( $cat_id ).'</span>'; } ?>

<?php
$oddpost = 'alt-post';$postcount = 0;
$query = new WP_Query( "cat=".$feat_cat_one."&posts_per_page=". $num. "&orderby=date" );
while ( $query->have_posts() ) : $query->the_post();
$thepostlink = '<a href="'. get_permalink() . '" title="' . the_title_attribute('echo=0') . '">';
?>
<!-- POST START -->
<article <?php post_class('homefeat-post'); ?> id="post-<?php the_ID(); ?>">
<?php echo get_featured_post_image("<div class='post-thumb'>".$thepostlink, "</a></div>", 300, 300, "alignnone", 'medium', mp_get_image_alt_text(),the_title_attribute('echo=0'), false); ?>
<h2 class="post-title entry-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
</article>
<!-- POST END -->
<?php endwhile; wp_reset_query(); ?>
</div>
</div>
<?php } ?>


<?php do_action('mp_after_featcat_one'); ?>





<?php if($feat_cat_two != '' && $feat_cat_two != 'Choose a category') {
$cat_name = get_cat_name($feat_cat_two);
$cat_id = get_cat_ID($cat_name);
?>
<div class="featblk-content middle-feat-content">
<div class="homefeatbox blkfeat<?php echo $cat_id; ?>">
<h3><a href="<?php echo get_category_link( $feat_cat_two ); ?>"><?php echo get_cat_name($feat_cat_two); ?></a></h3>

<?php //$catdesc = category_description( $cat_id ); if($catdesc) { echo '<span class="homefeat-desc">'.category_description( $cat_id ).'</span>'; } ?>

<?php
$oddpost = 'alt-post';$postcount = 0;
$query = new WP_Query( "cat=".$feat_cat_two."&posts_per_page=". $num. "&orderby=date" );
while ( $query->have_posts() ) : $query->the_post();
$thepostlink = '<a href="'. get_permalink() . '" title="' . the_title_attribute('echo=0') . '">';
?>
<!-- POST START -->
<article <?php post_class('homefeat-post'); ?> id="post-<?php the_ID(); ?>">
<?php echo get_featured_post_image("<div class='post-thumb'>".$thepostlink, "</a></div>", 300, 300, "alignnone", 'medium', mp_get_image_alt_text(),the_title_attribute('echo=0'), false); ?>
<h2 class="post-title entry-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
</article>
<!-- POST END -->
<?php endwhile; wp_reset_query(); ?>
</div></div>
<?php } ?>

<?php do_action('mp_after_featcat_two'); ?>






<?php if($feat_cat_three != '' && $feat_cat_three != 'Choose a category') {
$cat_name = get_cat_name($feat_cat_three);
$cat_id = get_cat_ID($cat_name);
?>
<div class="featblk-content">
<div class="homefeatbox blkfeat<?php echo $cat_id; ?>">
<h3><a href="<?php echo get_category_link( $feat_cat_three ); ?>"><?php echo get_cat_name($feat_cat_three); ?></a></h3>

<?php //$catdesc = category_description( $cat_id ); if($catdesc) { echo '<span class="homefeat-desc">'.category_description( $cat_id ).'</span>'; } ?>

<?php
$oddpost = 'alt-post';$postcount = 0;
$query = new WP_Query( "cat=".$feat_cat_three."&posts_per_page=". $num. "&orderby=date" );
while ( $query->have_posts() ) : $query->the_post();
$thepostlink = '<a href="'. get_permalink() . '" title="' . the_title_attribute('echo=0') . '">';
?>
<!-- POST START -->
<article <?php post_class('homefeat-post'); ?> id="post-<?php the_ID(); ?>">
<?php echo get_featured_post_image("<div class='post-thumb'>".$thepostlink, "</a></div>", 300, 300, "alignnone", 'medium', mp_get_image_alt_text(),the_title_attribute('echo=0'), false); ?>
<h2 class="post-title entry-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
</article>
<!-- POST END -->
<?php endwhile; wp_reset_query(); ?>
</div></div>
<?php } ?>

<?php do_action('mp_after_featcat_three'); ?>



</div> </div>
<?php endif; ?>