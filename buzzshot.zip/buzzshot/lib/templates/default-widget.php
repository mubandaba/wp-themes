<?php $get_right_ads_code = get_theme_option('ads_right_sidebar'); if($get_right_ads_code != '') { ?>
<aside class="widget">
<div class="textwidget adswidget"><?php echo stripcslashes(do_shortcode($get_right_ads_code)); ?></div>
</aside>
<?php } ?>
<?php if( get_theme_option('twitter_widget_id') ) { ?>
<aside class="widget" id="twitter-blk">
<h3 class="widget-title"><span><?php _e('Recent Tweets', TEMPLATE_DOMAIN); ?></span></h3>
<div class="textwidget" id="twitter-news"></div>
</aside>
<?php } ?>


<aside class="widget">
<h3 class="widget-title"><span><?php _e('Topics', TEMPLATE_DOMAIN); ?></span></h3>
<ul><?php wp_list_categories('orderby=name&show_count=1&title_li='); ?></ul>
</aside>

<aside class="widget">
<h3 class="widget-title"><span><?php _e('Archives', TEMPLATE_DOMAIN); ?></span></h3>
<ul><?php wp_get_archives('type=monthly&limit=12&show_post_count=1'); ?></ul>
</aside>