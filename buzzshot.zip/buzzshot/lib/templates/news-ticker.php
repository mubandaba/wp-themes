<?php
$ticker_on = get_theme_option('ticker_on');
if($ticker_on == 'enable') {
$ticker_featured_post = get_theme_option('ticker_feat_post');
$allposttype = mp_get_all_posttype();
echo '<div id="js-news"><ul>';
query_posts( array( 'post__in' => explode(',', $ticker_featured_post), 'post_type'=> $allposttype, 'posts_per_page' => 100, 'ignore_sticky_posts' => 1, 'orderby' => 'post__in', 'order' => '' ) );
while ( have_posts() ) : the_post();
echo '<li><a href="'. get_permalink() . '" title="'. the_title_attribute('echo=0') . '">'. get_the_title() . '</a></li>';
endwhile; wp_reset_query();
echo '</ul></div>';
}
?>