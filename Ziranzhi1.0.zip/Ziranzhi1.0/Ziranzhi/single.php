<?php 
if (in_category(array(34,36,37,38,39,40,41))) {
include(TEMPLATEPATH . '/single-baike.php');
} elseif (in_category(array(217))) {
include(TEMPLATEPATH . '/single-mei.php');
} else {
include(TEMPLATEPATH . '/single-zixun.php');
}
?>