</body>
<script type="text/javascript">
/* <![CDATA[ */
(new GoTop()).init({
	pageWidth		:960,
	nodeId			:'go-top',
	nodeWidth		:50,
	distanceToPage :20,
	distanceToBottom	:125,
	hideRegionHeight	:130,
	text			:'Top'
});
/* ]]> */
</script>
</html>