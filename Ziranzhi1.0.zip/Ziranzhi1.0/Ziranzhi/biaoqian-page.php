<?php 
/**
 * Template Name: biaoqian
**/
get_header(); ?>
<?php include_once("sidebar-left.php"); ?>
	<div id="content" class="page">
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<div class="post" id="post-<?php the_ID(); ?>">
			<div class="entry">
			<h1 itemprop="name"><?php the_title(); ?></h1>
<p style="color:#888;font-size:11px;margin-bottom:10px;"><?php the_author(); ?> - <span><meta itemprop="dateModified" content="<?php the_modified_time('Y-m-d'); ?>"/> </span><span><?php the_modified_time('Y-m-d'); ?></span> - <?php if(function_exists('the_views')) { the_views(); } ?> 次浏览</p>
				<?php wp_tag_cloud('number=100&smallest=12&largest=50&unit=px'); ?>
			</div>
		</div>
		<?php endwhile; endif; ?>

	<?php get_footer(); ?>
	</div>

<?php include_once("sidebar-right.php"); ?>