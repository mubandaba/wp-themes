	<div id="sidebar-left">
		<div id="logo">
			<a href="<?php echo get_option('home'); ?>/"><img src="http://lemolee-video.b0.upaiyun.com/logo.png" alt="自然志"/></a>
		</div>
		<ul>
		<?php if (is_home()) { ?>
		<div class="sidebar-title"><h1>自然志</h1></div>
		<?php } else { ?>
		<div class="sidebar-title">自然志</div>
		<?php } ?>
		<?php wp_list_categories('include=3,33,74&show_count=1&title_li='); ?>	
		<div class="sidebar-title">动物百科</div>
		<?php wp_list_categories('include=34,36,37,38,39,40,41&show_count=1&title_li='); ?>
		<div class="sidebar-title">自然基础知识</div>
		<ul>
		<li>
		<a href="http://ziranzhi.com/ziranjichuzhishi/1743.html">地球生命</a>
		</li>
		<li>
		<a href="http://ziranzhi.com/ziranjichuzhishi/1754.html">生物地理的分界</a>
		</li>
		</ul>
		</ul>
	</div>

