<?php get_header(); ?>

<?php include_once("sidebar-left.php"); ?>
	<div id="content" class="page">

		<div class="post" id="post-<?php the_ID(); ?>">
			<div class="entry">
			<h2 class="center">Error 404 - Not Found</h2>
			</div>
		</div>

	<?php get_footer(); ?>
	</div>

<?php include_once("sidebar-right.php"); ?>