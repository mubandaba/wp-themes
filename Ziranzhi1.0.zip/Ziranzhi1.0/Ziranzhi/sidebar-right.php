<div id="sidebar-right">
	<div class="sidebar-right-info">
		<ul class="rss clearfix">
			<li><a href="http://ziranzhi.com/feed"><img src="<?php bloginfo('template_directory'); ?>/images/rss.png" alt="订阅" /></a></li>
			<li><a rel="nofollow" href="http://www.douban.com/people/72246758"><img src="<?php bloginfo('template_directory'); ?>/images/dou.png" alt="豆瓣" /></a></li>
			<li><a rel="nofollow" href="http://t.qq.com/ziranzhi_com"><img src="<?php bloginfo('template_directory'); ?>/images/qq.png" alt="QQ微博" /></a></li>
			<li><a rel="nofollow" href="http://weibo.com/u/3434523442"><img src="<?php bloginfo('template_directory'); ?>/images/sina.png" alt="新浪微博" /></a></li>
			<li style="margin:0"><a rel="nofollow" href="http://ziranzhi.diandian.com"><img src="<?php bloginfo('template_directory'); ?>/images/diandian.png" alt="点点" /></a></li>
		</ul>
		<ul class="miaoshu"><li><span style="color:#ccc">用</span><span style="color:#2b2b2b">影像</span><span style="color:#ccc">和</span><span style="color:#2b2b2b">文字</span><span style="color:#ccc">记录</span><span style="color:#0072BC">自然的脉动</span></li></ul>
		<ul class="sidebar-right-info-a clearfix">
			<li><a href="http://ziranzhi.com/about">关于本站</a></li><li><a href="http://ziranzhi.com/about-author">关于作者</a></li><li style="margin:0"><a href="http://ziranzhi.com/feedback">意见反馈</a></li>
		</ul>
	</div>
	<div class="sidebar-right-b">
		<div class="tougao"><a href="http://ziranzhi.com/tougao">关注自然，我要投稿</a></div>
		<div class="banquan">
		<p><b>关于自然志：</b></p>
		<p>相信你看出来了，我们着迷于自然，那么我们的任务就是给你介绍这个星球上最奇特、最稀有、最酷的自然事物。<a href="http://ziranzhi.com/about" rel="nofollow" style="color:#0063A2">了解更多..</a></p>
		</div>
		<div class="sidebar-right-title-re">热门文章</div>
		<ul>
				<?php function mostweek($where = '') {
    //posts in the last 7 days
    $where .= " AND post_date > '" . date('Y-m-d', strtotime('-7 days')) . "'";
    return $where;
  }
add_filter('posts_where', 'mostweek'); ?>
<?php query_posts("v_sortby=views&caller_get_posts=1&orderby=date&v_orderby=desc&showposts=5") ?>
  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
      <li><a href="<?php the_permalink() ?>" title="<?php the_title() ?>"><?php the_title() ?></a></li>
  <?php endwhile; ?>
<?php endif; ?>		
		</ul>
		<div class="sidebar-right-title-re">最新评论</div>
		<ul>
			<?php recent_comments('5', '35'); ?>
		</ul>
				<div class="banquan">
		<p><b>注意：</b></p>
		<p>自然志中的图片，多数来源网络，图片的版权归原作者所有。</p>
        <p>如果触犯了您的权利，请联系，我们将尽快修正。<a href="http://ziranzhi.com/contact" rel="nofollow" style="color:#0063A2">联系我们</a> </p>
		</div>
	</div>
</div>
</div>
		<?php wp_footer(); ?>
<script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F35003554391b53948a450f359916799c' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
/* <![CDATA[ */
(new GoTop()).init({
	pageWidth		:960,
	nodeId			:'go-top',
	nodeWidth		:50,
	distanceToPage :20,
	distanceToBottom	:125,
	hideRegionHeight	:130,
	text			:'Top'
});
/* ]]> */
</script>	
</body>
</html>