<?php get_header(); ?>
<?php include_once("sidebar-left.php"); ?>
	<div id="content">

<?php include(TEMPLATEPATH . '/jquery-side.php'); ?>
<div class="lun">
<div class="index-title clearfix"><p style="float:left;">百科</p><a href="http://ziranzhi.com/baike" style="display:block;float:right;color:#D65229">更多..</a></div>
<div class="lun-ul">
   <?php $posts = get_posts( "cat=34,36,37,38,39,40,41,287,291,293&numberposts=4" ); ?>
   <?php if( $posts ) : ?>
   <?php foreach( $posts as $post ) : setup_postdata( $post ); ?>
         <div class="youth-page">
		<div class="youth-page-title" style="display:none">
				<div style="padding:3px 10px"><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></div>
			</div>
			<a href="<?php the_permalink() ?>"><img src="http://img.ziranzhi.com/<?php $values = get_post_custom_values("indexcenter"); echo $values[0]; ?>!lun" alt="<?php the_title(); ?>" /></a>
					</div>
	 <?php endforeach; ?>   
   <?php endif; ?>
   </div>
    </div>
		<div class="clearfix">
		<div class="post-2-n"> 
			<ul class="clearfix index">
<?php
$page = (get_query_var('paged')) ? get_query_var('paged') : 1; query_posts("showposts=10&cat=3,33&paged=$page");
?>
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				<li>
					<div class="post-2-n-li clearfix">
						<h2><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
						<div class="meta clearfix"><div class="meta-left clearfix"><div class="time"><?php the_time( get_option('date_format') ); ?></div><div class="view-likes"><a class="view" href="<?php the_permalink(); ?>" rel="nofollow"><?php if(function_exists('the_views')) { the_views(); } ?></a><?php if( function_exists('zilla_likes') ) zilla_likes(); ?></div></div><div class="home-category">[<?php the_category(', ') ?>]</div></div>
						<a href="<?php the_permalink(); ?>"><img src="http://img.ziranzhi.com/<?php $values = get_post_custom_values("indexcenter"); echo $values[0]; ?>!indexinfo" alt="<?php the_title(); ?>" /></a>
						<div class="entry-home"><?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 88,"..."); ?>
						</div>
					</div>	
				</li>
				<?php endwhile; endif; ?>
			</ul>
		</div>
		</div>
		<div class="postnav clearfix">
		<div class="shang"><?php previous_posts_link('上一页'); ?></div>
		<div class="xia"><?php next_posts_link('下一页'); ?> </div>
		</div>
		<?php include(TEMPLATEPATH . '/footer2.php'); ?>
	</div>
<?php include_once("sidebar-right.php"); ?>


