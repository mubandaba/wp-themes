<?php 
/**
 * Template Name: yijian
**/
get_header(); ?>
<?php include_once("sidebar-left.php"); ?>
	<div id="content" class="page">
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<div class="post" id="post-<?php the_ID(); ?>">
			<div class="entry">
			<img src="http://lemolee-video.b0.upaiyun.com/feedback.png" alt="意见反馈"/>
			<h1 itemprop="name"><?php the_title(); ?></h1>
<p style="color:#888;font-size:11px;margin-bottom:10px;"><?php the_author(); ?> - <span><meta itemprop="dateModified" content="<?php the_modified_time('Y-m-d'); ?>"/> </span><span><?php the_modified_time('Y-m-d'); ?></span> - <?php if(function_exists('the_views')) { the_views(); } ?> 次浏览</p>
				<?php the_content('<p class="serif">Read the rest of this page &raquo;</p>'); ?>

				<?php wp_link_pages(array('before' => '<p><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>

			</div>
		</div>
		<?php endwhile; endif; ?>
	<?php comments_template(); ?>
	<?php get_footer(); ?>
	</div>

<?php include_once("sidebar-right.php"); ?>