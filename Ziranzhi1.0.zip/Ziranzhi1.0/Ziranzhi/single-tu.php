<?php get_header(); ?>
<?php include_once("sidebar-left.php"); ?>
	<div id="content" class="single tu">
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	<?php if (get_post_meta($post->ID, 'video', true)) : ?>
	    	<?php $values = get_post_custom_values("video"); echo $values[0]; ?>
	<?php  else : ?>
		<img src="http://img.ziranzhi.com/<?php $values = get_post_custom_values("indexcenter"); echo $values[0]; ?>!huandeng" alt="<?php the_title(); ?>" />
		<?php endif ; ?>
		<div class="post" id="post-<?php the_ID(); ?>">
			<h1><?php the_title(); ?></h1>

			<div class="entry">

				<?php the_content('<p class="serif">Read the rest of this entry &raquo;</p>'); ?>

				<?php wp_link_pages(array('before' => '<p><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
				<?php the_tags( '<p id="tags">Tags: ', ', ', '</p>'); ?><span>文章来源：<a href="<?php $values = get_post_custom_values("laiyuanurl"); echo $values[0]; ?>"><?php $values = get_post_custom_values("laiyuan"); echo $values[0]; ?></a></span>
<p class="postmetadata alt">
		说明：因为作者的知识有限，不能保证本文的百科知识完全正确，如果您觉得这篇文章有错误，或者不妥，请在下面留言告诉我们，我们会第一时间更正。
				</p>
			</div>
		</div>
		<div class="navigation">
			<div class="alignleft"><?php previous_post_link('&laquo; %link') ?></div>
			<div class="alignright"><?php next_post_link('%link &raquo;') ?></div>
		</div>

	<?php comments_template(); ?>

	<?php endwhile; else: ?>

		<p>Sorry, no posts matched your criteria.</p>

<?php endif; ?>
<?php get_footer(); ?>
	</div>
	</div>
		
</body>
</html>



