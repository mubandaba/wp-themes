<?php 
/**
 * Template Name: baike
**/
get_header(); ?>
<?php include_once("sidebar-left.php"); ?>
	<div id="content" class="archive">
	<div id="popular-tags">
	<span class="clearfix"><p style="float:left;">一周热门标签</p><a href="http://ziranzhi.com/tags" style="display:block;float:right;color:#ff0000">所有标签</a></span>
<ul class="wp-tag-cloud"> <?php global $wpdb; $term_ids = $wpdb->get_col(" SELECT DISTINCT term_taxonomy_id FROM $wpdb->term_relationships INNER JOIN $wpdb->posts ON $wpdb->posts.ID = object_id WHERE DATE_SUB(CURDATE(), INTERVAL 7 DAY) <= $wpdb->posts.post_date"); if($term_ids > 0){ $tags = get_tags(array( 'orderby' => 'count', 'order' => 'DESC', 'number' => 15, 'include' => $term_ids, )); foreach ( (array) $tags as $tag ) { echo '<li><a href="' . get_tag_link ($tag->term_id) . '" rel="tag">' . $tag->name . '</a></li>'; } } ?> </ul>	
</div>
<?php
$limit = get_option('posts_per_page');
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
query_posts('cat=34,36,37,39,40,41,287,291,293&showposts=' . $limit=10 . '&paged=' . $paged);
$wp_query->is_archive = true; $wp_query->is_home = false;
?>
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<div class="post" id="post-<?php the_ID(); ?>">
				<a href="<?php the_permalink(); ?>" rel="nofollow"><img src="http://img.ziranzhi.com/<?php $values = get_post_custom_values("indexcenter"); echo $values[0]; ?>!indexinfo" /></a>
				<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
				<div class="entry">
					<?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 100,"..."); ?>
							</div>
							</div>
	 	<?php endwhile; endif; ?>

		<div class="navigation">
			<div class="alignleft"><?php next_posts_link('下一页') ?></div>
			<div class="alignright"><?php previous_posts_link('上一页') ?></div>
		</div>

<?php get_footer(); ?>
	</div>
<?php include_once("sidebar-right.php"); ?>


