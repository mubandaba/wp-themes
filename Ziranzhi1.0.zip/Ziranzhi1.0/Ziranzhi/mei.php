<?php 
/**
 * Template Name: mei
**/
get_header(); ?>
<?php include_once("sidebar-left-mei.php"); ?>
	<div id="content-mei">
		<div id="popular-tags" class="clearfix">
	<?php include (TEMPLATEPATH . "/content_top.php"); ?>
	</div>
	<?php $qry[1] = 5;$qry[2] = 5;$qry[3] = 5; $qry['total'] = array_sum($qry); $paged = (get_query_var('paged')) ? get_query_var('paged') : 1; ?>
	<div class="mei clearfix">
	<div class="post-2-n left"> 
			<ul class="index">
				<?php $off = ($paged > 1) ? ($qry['total'] * ($paged - 1)) : 0; ?>
			<?php query_posts("cat=217&posts_per_page=$qry[total]&paged=$paged&showposts=$qry[1]&offset=$off"); ?>
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				<li class="clearfix">
					<div class="post-2-n-li clearfix">
						<div class="mei-title" style="display:none"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></div>
						<a href="<?php the_permalink(); ?>"><img src="http://yubuzhi.b0.upaiyun.com/<?php $values = get_post_custom_values("indexcenter"); echo $values[0]; ?>!mei2" alt="<?php the_title(); ?>" /></a>
						</div>
				</li>
						<?php endwhile; endif; ?>
			</ul>
	</div>
	<div class="post-2-n center"> 
			<ul class="clearfix index">

		<?php $a = ($qry['total'] * ($paged - 1)); ?>
			<?php $off = $qry[1] + (($paged > 1) ? $a : 0); ?>
				<?php query_posts("cat=217&posts_per_page=$qry[total]&offset=$off&showposts=$qry[2]"); ?>
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				<li class="clearfix">
					<div class="post-2-n-li clearfix">
						<div class="mei-title" style="display:none"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></div>
						<a href="<?php the_permalink(); ?>"><img src="http://yubuzhi.b0.upaiyun.com/<?php $values = get_post_custom_values("indexcenter"); echo $values[0]; ?>!mei2" alt="<?php the_title(); ?>" /></a>
						</div>	
				</li>
						<?php endwhile; endif; ?>
			</ul>
	</div>
	<div class="post-2-n right"> 
			<ul class="clearfix index">
				<?php $a = ($qry['total'] * ($paged - 1)); ?>
			<?php $off = ($qry[1] + $qry[2]) + (($paged > 1) ? $a : 0); ?>
				<?php query_posts("cat=217&posts_per_page=$qry[total]&offset=$off&showposts=$qry[3]"); ?>
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				<li class="clearfix">
					<div class="post-2-n-li clearfix">
						<div class="mei-title" style="display:none"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></div>
						<a href="<?php the_permalink(); ?>"><img src="http://yubuzhi.b0.upaiyun.com/<?php $values = get_post_custom_values("indexcenter"); echo $values[0]; ?>!mei2" alt="<?php the_title(); ?>" /></a>
						</div>	
				</li>
						<?php endwhile; endif; ?>
			</ul>
	</div>
	</div>
		<div class="postnav clearfix">
		<div class="shang"><?php previous_posts_link('上一页'); ?></div>
		<div class="xia"><?php next_posts_link('下一页'); ?> </div>
		</div>
	</div>
		<?php include (TEMPLATEPATH . "/footer3.php"); ?>


