<div class="clearfix"></div>
<div id="footer">
<div class="other-info clearfix">
<ul class="clearfix">
<li>
<a href="http://ziranzhi.com/terms-of-service">服务条款</a> - 
</li>
<li>
<a href="http://ziranzhi.com/contact">联系我们</a> -
</li>
<li>
<a href="http://ziranzhi.com/archives">存档</a> - 
</li>
<li>
<a href="http://ziranzhi.com/sitemap.xml">Site Map</a>  
</li>
</ul>
</div>
		<div style="float:left;width:480px"><p>&copy; 2013-<?php echo date( Y ); ?> <?php bloginfo('name'); ?> 基于 <a href="http://wordpress.org/">WordPress</a>，主题 ZIRANZHI 由 如春 制作。</p>
		<p>本站通过 <a rel="external nofollow" href="http://validator.w3.org/check?uri=referer">HTML 5</a> 和 <a href="http://jigsaw.w3.org/css-validator/check/referer?profile=css3">CSS 3</a> 验证。备案信息：<a href="http://www.miibeian.gov.cn/" rel="nofollow">粤ICP备12044466号</a></p>
	    <p>本站采用<a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/3.0/deed.zh">《知识共享署名-非商业性使用-相同方式共享 3.0 未本地化版本许可协议》</a></p>
		</div>
		<div style="float:right"><img src="http://ziranzhi.com/wp-content/themes/ziranzhi/images/footer-logo.png" alt="自然志"/></div>
		</div>
		</div>
		<?php wp_footer(); ?>
		<script type="text/javascript">
/* <![CDATA[ */
(new GoTop()).init({
	pageWidth		:960,
	nodeId			:'go-top',
	nodeWidth		:50,
	distanceToPage :20,
	distanceToBottom	:125,
	hideRegionHeight	:130,
	text			:'Top'
});
/* ]]> */
</script>
</body>

</html>