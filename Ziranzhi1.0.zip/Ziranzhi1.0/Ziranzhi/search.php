<?php get_header(); ?>
<?php include_once("sidebar-left.php"); ?>
	<div id="content" class="archive">
	<div id="popular-tags" class="clearfix">
	<?php include (TEMPLATEPATH . "/content_top.php"); ?>
	</div>
	<?php if (have_posts()) : ?>

		<?php while (have_posts()) : the_post(); ?>

			<div class="post" id="post-<?php the_ID(); ?>">
				<a href="<?php the_permalink(); ?>"><img src="http://yubuzhi.b0.upaiyun.com/<?php $values = get_post_custom_values("indexcenter"); echo $values[0]; ?>!indexinfo" /></a>
				<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
				<div class="entry">
					<?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 100,"..."); ?>
							</div>
							</div>
		<?php endwhile; ?>

		<div class="navigation">
			<div class="alignleft"><?php next_posts_link('&laquo; Older Entries') ?></div>
			<div class="alignright"><?php previous_posts_link('Newer Entries &raquo;') ?></div>
		</div>

	<?php else : ?>

		<h2 class="center">没有找到</h2>
		<p class="center">对不起，没有找到你要的内容，请更换关键词，从新搜索。</p>
		<?php include (TEMPLATEPATH . "/searchform.php"); ?>

	<?php endif; ?>
<?php get_footer(); ?>
	</div>
<?php include_once("sidebar-right.php"); ?>