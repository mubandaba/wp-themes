<div class="nav-search">	
<form action="<?php bloginfo('url'); ?>" id="search" method="get">
	<button title="Search" class="submit iconfont" id="J_Submit" type="submit"></button>
	<input type="text" placeholder="" class="input sprites bg-anim" id="J_Input" title="Type Keyword" name="s" maxlength="30">
</form>			
</div>