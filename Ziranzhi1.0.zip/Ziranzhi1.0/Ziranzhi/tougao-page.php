<?php 
/**
 * Template Name: tougao
**/
get_header(); ?>
<?php include_once("sidebar-left.php"); ?>
	<div id="content" class="page">
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<div class="post" id="post-<?php the_ID(); ?>">
			<div class="entry">
			<img src="http://lemolee-video.b0.upaiyun.com/tougao-page.png" alt="关注自然，我要投稿"/>
				<p class="postmetadata alt">
                 <span style="color:#D65229">尊重作者：</span>自然故事欢迎您来投稿，我们尊重您的劳动成果，不会对投稿的文字、图片、链接等信息擅自更改，如果需要微调我们会首先征求你的意见。<span style="color:#D65229">文章的一切权利归作者所有</span>。
				</p>
				<h1 itemprop="name"><?php the_title(); ?></h1>
<p style="color:#888;font-size:11px;margin-bottom:10px;"><?php the_author(); ?> - <span><meta itemprop="dateModified" content="<?php the_modified_time('Y-m-d'); ?>"/> </span><span><?php the_modified_time('Y-m-d'); ?></span> - <?php if(function_exists('the_views')) { the_views(); } ?> 次浏览</p>
				<?php the_content('<p class="serif">Read the rest of this page &raquo;</p>'); ?>
				<?php wp_link_pages(array('before' => '<p><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>

			</div>
		</div>
		<?php endwhile; endif; ?>
<?php comments_template(); ?>
	<?php get_footer(); ?>
	</div>

<?php include_once("sidebar-right.php"); ?>