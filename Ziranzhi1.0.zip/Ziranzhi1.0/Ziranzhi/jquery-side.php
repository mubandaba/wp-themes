 <div id="flashbox">
  <div class="effectContainer clearfix" style="overflow:hidden">
    <?php $posts = get_posts( "cat=43,48,74&numberposts=5" ); ?>
    <?php if( $posts ) : ?>
    <?php foreach( $posts as $post ) : setup_postdata( $post ); ?>
	<div class="slide">
	<a href="<?php the_permalink(); ?>"><img src="http://img.ziranzhi.com/<?php $values = get_post_custom_values("indexcenter"); echo $values[0]; ?>!huandeng" title="<?php the_title(); ?>" alt="<?php the_title(); ?>" />
	<span class="slide-title"><?php the_title(); ?></span>
	</a>
	</div>
	<?php endforeach; ?>  
    <?php endif; ?>
	  </div>	  
    </div>

