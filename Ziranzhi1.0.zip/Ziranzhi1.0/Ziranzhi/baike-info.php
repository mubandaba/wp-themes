	  <?php if (is_category("34")) { ?>
    <p class="postmetadata alt" style="margin-bottom:10px;">
	鱼类（Fish）终生都生活在水中：少部份鱼能短时间待在陆地上。靠鳍运动，呼吸主要依靠鳃。对于鱼，中国人有很多误区，把生活在水中像鱼的生物都叫做鱼，比如鲸鱼（哺乳动物）、娃娃鱼（两栖动物）、鳄鱼（爬行动物）、鲍鱼（无脊椎动物）。
	 <span><a rel="nofollow" href="http://baike.baidu.cn/view/27863.htm">鱼类 - 百度百科</a> | <a rel="nofollow" href="http://zh.wikipedia.org/wiki/%E9%B1%BC">鱼类 - 维基百科</a></span>
   	 </p>
	 	<?php } elseif (is_category("36")) { ?>
	<p class="postmetadata alt" style="margin-bottom:10px;">
	无脊椎动物（Invertebrate）是动物的原始形式，一般身体柔软，无内骨骼，但常有坚硬的外骨骼，其种类数占动物总种类数的95%。最小的有单细胞的原生动物如草履虫，最大的如大王酸浆鱿有20米长，所有昆虫都是无脊椎动物动物，而且会飞的无脊椎动物动物只有昆虫。
	 <span><a rel="nofollow" href="http://baike.baidu.com/view/3868.htm">无脊椎动物 - 百度百科</a> | <a rel="nofollow" href="http://zh.wikipedia.org/zh-cn/%E6%97%A0%E8%84%8A%E6%A4%8E%E5%8A%A8%E7%89%A9">无脊椎动物 - 维基百科</a></span>
	 </p>
	 <?php } elseif (is_category("37")) { ?>
	 <p class="postmetadata alt" style="margin-bottom:10px;">
	 哺乳动物（Mammal）最显著的特征是能够通过乳腺分泌乳汁给幼体哺乳。按照《世界哺乳动物物种》2005年的数据，哺乳动物约占地球所有物种的0.4%，水下、地下、地面、空中都可以找到它们的踪影。人类是哺乳动物的一种。
	<span><a rel="nofollow" href="http://baike.baidu.com/view/30264.htm">哺乳动物 - 百度百科</a> | <a rel="nofollow" href="http://zh.wikipedia.org/wiki/%E5%93%BA%E4%B9%B3%E5%8A%A8%E7%89%A9">哺乳动物 - 维基百科</a></span>
	 </p>		
	 <?php } elseif (is_category("38")) { ?>
	 <p class="postmetadata alt" style="margin-bottom:10px;">
	 哺乳动物（Mammal）体表覆盖着角质的鳞片或甲，用肺呼吸，卵生，有羊膜卵，骨骼也具有一系列适应陆地生活的特征。我们常常看到的爬行动物是鳄鱼、龟鳖、蛇、蜥蜴等。
	<span><a rel="nofollow" href="http://baike.baidu.com/view/7568.htm">哺乳动物 - 百度百科</a> | <a rel="nofollow" href="http://zh.wikipedia.org/wiki/%E7%88%AC%E8%A1%8C%E5%8A%A8%E7%89%A9">哺乳动物 - 维基百科</a></span>
	 </p>		 
	 <?php } elseif (is_category("39")) { ?>
	  <p class="postmetadata alt" style="margin-bottom:10px;">
	 两栖动物（Amphibians）最显著的特征是拥有裸露光滑的皮肤，没有毛发和鳞片等覆盖物，但是可以分泌粘液保持身体湿润。卵生而没有卵壳。现在最大的两栖动物有1米五长，最小的不到1厘米。青蛙是典型的两栖动物，国宝娃娃鱼也是两栖动物。
	<span><a rel="nofollow" href="http://baike.baidu.cn/view/15259.htm">两栖动物 - 百度百科</a> | <a rel="nofollow" href="http://zh.wikipedia.org/wiki/%E4%B8%A4%E6%A0%96%E5%8A%A8%E7%89%A9">两栖动物 - 维基百科</a></span>
	</p>	
 <?php } elseif (is_category("40")) { ?>
 	 <p class="postmetadata alt" style="margin-bottom:10px;">
	 鸟类（Birds）是两足、恒温、卵生的脊椎动物，身披羽毛，前肢演化成翅膀，有坚硬的喙。人类已知的鸟有9000多种，人类的活动对鸟造成了极大的影响，大部分鸟都面临着生存问题。
	 <span><a rel="nofollow" href="http://baike.baidu.cn/view/13702.htm">鸟类 - 百度百科</a> | <a rel="nofollow" href="http://zh.wikipedia.org/wiki/%E9%B8%9F">鸟类 - 维基百科</a></span>
	</p>
	<?php } ?>
