<?php get_header(); ?>
<?php include_once("sidebar-left.php"); ?>
	<div id="content" class="single">
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	<?php if (get_post_meta($post->ID, 'video', true)) : ?>
	    	<?php $values = get_post_custom_values("video"); echo $values[0]; ?>
	<?php  else : ?>
		<img src="http://img.ziranzhi.com/<?php $values = get_post_custom_values("indexcenter"); echo $values[0]; ?>!huandeng" alt="<?php the_title(); ?>" />
		<?php endif ; ?>
		<div class="breadcrumb" itemprop="breadcrumb">
<?php
        if(function_exists('bcn_display')) {
                bcn_display();
        }
?>
</div>
		<div class="post" id="post-<?php the_ID(); ?>" itemscope itemtype="http://schema.org/Article">
			<h1 itemprop="name"><?php the_title(); ?></h1>
<p style="color:#888;font-size:11px;margin-bottom:10px;float:left"><?php the_author(); ?> 于 <span><meta itemprop="dateModified" content="<?php the_modified_time('Y-m-d'); ?>"/> </span><span><?php the_time('Y'); ?></span> 发表在 <span class="category"><span class="icon"></span><?php the_category(', '); ?></span> 分类 - <?php if(function_exists('the_views')) { the_views(); } ?> 次浏览
分享到：<div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare">
<a class="bds_tsina"></a>
<a class="bds_qzone"></a>
<a class="bds_tqq"></a>
<a class="bds_renren"></a>
<a class="bds_t163"></a>
<a class="bds_diandian"></a>
<a class="bds_douban"></a>
</div>
</p>
<div class="clearfix"></div>
			<div class="entry" itemprop="articleBody">

				<?php the_content('<p class="serif">Read the rest of this entry &raquo;</p>'); ?>

				<?php wp_link_pages(array('before' => '<p><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
				
<p class="postmetadata alt">
		<span style="color:#D65229"><b>说明</b></span>：因为作者的知识有限，不能保证文中观点完全正确，如果您觉得这篇文章有错误，或者不妥，请在下面<span style="color:#D65229">留言告诉我们</span>，我们会第一时间更正。
				</p>
			</div>
		</div>
		<div class="navigation clearfix">
<?php
$categories = get_the_category();
        $categoryIDS = array();
        foreach ($categories as $category) {
            array_push($categoryIDS, $category->term_id);
        }
        $categoryIDS = implode(",", $categoryIDS);
?>
<div class="alignleft"><?php if (get_previous_post($categoryIDS)) { previous_post_link('%link','%title',true);} else { echo "已是最后文章";} ?></div>
<div class="alignright"><?php if (get_next_post($categoryIDS)) { next_post_link('%link','%title',true);} else { echo "已是最新文章";} ?></div>
		</div>
<div class="xiangguan">
<ul id="tags_related" class="clearfix">
	<div class="l">
	<h4>与 <?php the_tags( ' ', ', ' ,' '); ?> 相关的文章</h4>
	<ul>
     <?php
      $post_num = 5; // 设置相关文章数量.
      global $post;
      $tmp_post = $post;
      $tags = ''; $i = 0; // 先取 tags 文章.
      if ( get_the_tags( $post->ID ) ) {
      foreach ( get_the_tags( $post->ID ) as $tag ) $tags .= $tag->name . ',';
      $tags = strtr(rtrim($tags, ','), ' ', '-');
      $myposts = get_posts('numberposts='.$post_num.'&tag='.$tags.'&exclude='.$post->ID);
foreach($myposts as $post) {
setup_postdata($post);
?>
<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
<?php
$i += 1;
}
}
if ( $i < $post_num ) { // tags 文章数量不足, 再取 category 补足.
$post = $tmp_post; setup_postdata($post);
$cats = ''; $post_num -= $i;
foreach ( get_the_category( $post->ID ) as $cat ) $cats .= $cat->cat_ID . ',';
$cats = strtr(rtrim($cats, ','), ' ', '-');
$myposts = get_posts('numberposts='.$post_num.'&category='.$cats.'&exclude='.$post->ID);
foreach($myposts as $post) {
setup_postdata($post);
?>
<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
<?php
}
}
$post = $tmp_post; setup_postdata($post);
?>
</ul>
	</div>
</div>
	<?php comments_template(); ?>

	<?php endwhile; else: ?>

		<p>Sorry, no posts matched your criteria.</p>

<?php endif; ?>
<?php get_footer(); ?>
	</div>
	
<?php include_once("sidebar-right-single.php"); ?>



