<?php get_header(); ?>
<?php include_once("sidebar-left.php"); ?>
	<div id="content" class="archive">
	<?php include_once("baike-info.php"); ?>
	<div id="popular-tags" class="clearfix">
	<?php include (TEMPLATEPATH . "/content_top.php"); ?>
	</div>
	<?php if (have_posts()) : ?>

		<?php while (have_posts()) : the_post(); ?>

			<div class="post" id="post-<?php the_ID(); ?>">
				<a href="<?php the_permalink(); ?>" rel="nofollow"><img src="http://img.ziranzhi.com/<?php $values = get_post_custom_values("indexcenter"); echo $values[0]; ?>!indexinfo" /></a>
				<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
				<div class="entry">
					<?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 100,"..."); ?>
							</div>
							</div>
		<?php endwhile; ?>

		<div class="navigation">
			<div class="alignleft"><?php next_posts_link('下一页') ?></div>
			<div class="alignright"><?php previous_posts_link('上一页') ?></div>
		</div>

	<?php else : ?>

		<h2 class="center">Not Found</h2>
		<p class="center">Sorry, but you are looking for something that isn't here.</p>
		<?php include (TEMPLATEPATH . "/searchform.php"); ?>

	<?php endif; ?>
<?php get_footer(); ?>
	</div>
<?php include_once("sidebar-right.php"); ?>


