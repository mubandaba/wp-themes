<?php
//顶部标题
function csubstr($string, $beginIndex, $length){
if(strlen($string) < $length){
return substr($string, $beginIndex);
}
$char = ord($string[$beginIndex + $length - 1]);
if($char >= 224 && $char <= 239){
$str = substr($string, $beginIndex, $length - 1);
return $str;
}
$char = ord($string[$beginIndex + $length - 2]);
if($char >= 224 && $char <= 239){
$str = substr($string, $beginIndex, $length - 2);
return $str;
}
return substr($string, $beginIndex, $length);
}
add_filter( 'the_category', 'add_nofollow_cat' );  function add_nofollow_cat( $text ) { $text = str_replace('rel="category tag"', "", $text); return $text; }
?>
<?php
//缩略图
    function show_image() {
      global $post, $posts;
      $first_img = '';
      ob_start();
      ob_end_clean();
      $output = preg_match_all('/<IMG.+SRC=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
      $first_img = $matches [1] [0];
      if(empty($first_img)){
        $first_img = "/images/default.png"; 
      }
      return $first_img;
    }
?>
<?php
//替换默认调用jquery
 if( !is_admin()){
   wp_deregister_script('jquery');
   wp_register_script('jquery', ("http://upcdn.b0.upaiyun.com/libs/jquery/jquery-1.7.2.min.js"), false, '');
   wp_enqueue_script('jquery');
}
?>
<?php
add_filter('gallery_style',
    create_function(
        '$css',
        'return preg_replace("#<style type=\'text/css\'>(.*?)</style>#s", "", $css);'
        )
    );
	?>
<?php
//时间显示times ago
function themeblvd_time_ago() {
	global $post;
 	$date = get_post_time('G', true, $post ,$comment);
	$chunks = array(
		array( 60 * 60 * 24 * 365 , __( '年', 'themeblvd' ), __( '年', 'themeblvd' ) ),
		array( 60 * 60 * 24 * 30 , __( '个月', 'themeblvd' ), __( '个月', 'themeblvd' ) ),
		array( 60 * 60 * 24 * 7, __( '周', 'themeblvd' ), __( '周', 'themeblvd' ) ),
		array( 60 * 60 * 24 , __( '天', 'themeblvd' ), __( '天', 'themeblvd' ) ),
		array( 60 * 60 , __( '小时', 'themeblvd' ), __( '小时', 'themeblvd' ) ),
		array( 60 , __( '分钟', 'themeblvd' ), __( '分钟', 'themeblvd' ) ),
		array( 1, __( '秒', 'themeblvd' ), __( '秒', 'themeblvd' ) )
	);
 	if ( !is_numeric( $date ) ) {
		$time_chunks = explode( ':', str_replace( ' ', ':', $date ) );
		$date_chunks = explode( '-', str_replace( ' ', '-', $date ) );
		$date = gmmktime( (int)$time_chunks[1], (int)$time_chunks[2], (int)$time_chunks[3], (int)$date_chunks[1], (int)$date_chunks[2], (int)$date_chunks[0] );
	}
 	$current_time = current_time( 'mysql', $gmt = 0 );
	$newer_date = strtotime( $current_time );
	$since = $newer_date - $date;
	if ( 0 > $since )
		return __( 'sometime', 'themeblvd' );
	for ( $i = 0, $j = count($chunks); $i < $j; $i++) {
		$seconds = $chunks[$i][0];
		if ( ( $count = floor($since / $seconds) ) != 0 )
			break;
	}
	$output = ( 1 == $count ) ? '1 '. $chunks[$i][1] : $count . ' ' . $chunks[$i][2];
  	if ( !(int)trim($output) ){
		$output = '0 ' . __( 'seconds', 'themeblvd' );
	}
 	$output .= __('前', 'themeblvd');
 	return $output;
}
add_filter('the_time', 'themeblvd_time_ago');
?>
<?php
function recent_comments( $posts = 5 ) {
global $wpdb;
$sql = "SELECT DISTINCT ID, post_title, post_password, comment_ID,
comment_post_ID, comment_author, comment_date_gmt, comment_approved,
comment_type,comment_author_url,
SUBSTRING(comment_content,1,300) AS com_excerpt
FROM $wpdb->comments
LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID =
$wpdb->posts.ID)
WHERE comment_approved = '1' AND comment_type = '' AND
post_password = ''
ORDER BY comment_date_gmt DESC LIMIT ".$posts;
$comments = $wpdb->get_results($sql);
foreach ($comments as $comment) {
?>
<li class="clearfix">
<div class="info">
<a href="<?php echo get_permalink($comment->ID); ?>#comment-<?php echo $comment->comment_ID; ?>" title="<?php echo $comment->post_title; ?>" rel="nofollow">
<b style="color:#000"><?php echo strip_tags($comment->comment_author); ?>:</b> <?php echo strip_tags($comment->com_excerpt); ?>
</a>
</div>
</li>
<?php
}
}
?>
<?php function to_reply() { ?>
[<a onclick='to_reply("<?php comment_ID() ?>", "<?php comment_author();?>")' href="#respond" style="cursor:pointer;"/>回复</a>]
<?php } ?>
<?php
function wp_smilies() {
    global $wpsmiliestrans;
    if ( !get_option('use_smilies') or (empty($wpsmiliestrans))) return;
    $smilies = array_unique($wpsmiliestrans);
    $link='';
    foreach ($smilies as $key => $smile) {
        $file = get_bloginfo('wpurl').'/wp-includes/images/smilies/'.$smile;
        $value = " ".$key." ";
        $img = "<img src=\"{$file}\" alt=\"{$smile}\" />";
        $imglink = htmlspecialchars($img);
        $link .= "<a href=\"#commentform\" title=\"{$smile}\" onclick=\"document.getElementById('comment').value += '{$value}'\">{$img}</a>&nbsp;";
    }
    echo '<div class="wp_smilies">'.$link.'</div>';
}
?>
<?php
/**
 * Load javascripts used by the theme
 */
function custom_theme_js() {
    wp_register_script('infinite_scroll', get_stylesheet_directory_uri() . '/js/jquery.infinitescroll.min.js', array('jquery'), null, true);
    if (!is_singular()) {
        wp_enqueue_script('infinite_scroll');
    }
}
add_action('wp_enqueue_scripts', 'custom_theme_js');
?>
