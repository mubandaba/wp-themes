<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<title><?php
	global $page, $paged;
	wp_title( '-', true, 'right' );
	bloginfo( 'name' );
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $paged >= 2 || $page >= 2 )
		echo ' - ' . sprintf( __( 'Page %s' ), max( $paged, $page ) );
	?></title>
	<?php if (is_home()){
		$keywords = "自然百科,自然新网,自然资讯,生物百科,生物资讯,奇特动物,国家地理,地理图片,鸟类,两栖动物,无脊椎动物,哺乳动物,爬行动物,鱼类,昆虫";
		$description = "自然志是一个科普网站，用影像和文字记录自然的脉动，推动人们对自然的认识。";
		} elseif (is_single()){
			if ($post->post_excerpt) {
				$description = $post->post_excerpt;
				} else {
					$str = csubstr(strip_tags($post->post_content),0,220);
					$str = trim($str);
                                        $str = strip_tags($str,"");
                                        $str = ereg_replace("\t","",$str);
                                        $str = ereg_replace("\r\n","",$str);
                                        $str = ereg_replace("\r","",$str);
                                        $str = ereg_replace("\n","",$str);
                                        $str = ereg_replace(" "," ",$str);
					$description = trim($str);
					}
					$keywords = "";
					$tags = wp_get_post_tags($post->ID);
					foreach ($tags as $tag ) {
						$keywords = $keywords . $tag->name . ", ";
						}
					}
	?>
<meta name="keywords" content="<?=$keywords?>" />
<meta name="description" content="<?=$description?>" />
<!--[if lte IE 9]>
    <script type="text/javascript" src="http://lemolee-video.b0.upaiyun.com/html5.js"></script>
<![endif]-->
<link rel="shortcut icon" href="<?php bloginfo('template_directory'); ?>/images/favicon.png" />
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<?php wp_head(); ?>
<script type="text/javascript" src="http://lemolee-video.b0.upaiyun.com/js/go-top.js"></script>
<?php if (is_home() || is_page()) { ?>
<script type="text/javascript" src="http://lemolee-video.b0.upaiyun.com/js/ziranzhi.js"></script>
<script type="text/javascript">
    (function($) {
        function init() {
          $("#flashbox .effectContainer").fadeTransition({pauseTime: 3000,
                                                 transitionTime: 1000,
                                                 ignore: "#introslide",
                                                 delayStart: 2000,
                                                 pauseOnMouseOver: true,
                                                 createNavButtons: true});
        }
        $(document).ready(init);
      })(jQuery);
	  </script>
<?php } ?>
<?php if (is_singular()) { ?>
<script type="text/javascript" src="http://lemolee-video.b0.upaiyun.com/js/jquery.imagePreview.1.0.js"></script>
<script type="text/javascript">
$(function(){
	$(".gallery-icon a").preview();	  
});
</script>
<?php } ?>
</head>

<body itemscope itemtype="http://schema.org/WebPage">
<div id="page" class="clearfix">