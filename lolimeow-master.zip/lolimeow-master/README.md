WordPress主题:Lolimeow

最近版本1.6
详细参考
https://www.boxmoe.com/222.html

主题安装后需要再主题设置上点击下保存设置才生效

有带会员中心,需要配合erphpdown插件https://www.boxmoe.com/87.html


0512更新
增加文章随机缩略图自定义数量
修改文章列表动态效果


0501
调整全屏搜索UI

3.24更新

1.修复会员中心头像显示问题
2.修复头像加速服务器选择
3.增加禁止纯英文 日语评论内容 开关设置
