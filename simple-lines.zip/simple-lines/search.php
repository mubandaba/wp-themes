<?php get_header(); ?>

<div id="postlist">
<div id="post-title-page">
<h1><span><?php _e('Search Results'); ?></span></h1>
</div>
<ul class="cate">
<?php $posts = query_posts($query_string . '&orderby=date&showposts=30'); ?>
<?php if(have_posts()) : while (have_posts()) : the_post(); ?>
	<li><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><span><?php the_time('Y-m-d'); ?>&nbsp;|&nbsp;<?php _e('Comments');?>: <?php comments_number('0','1','%'); ?></span>《<?php the_title(); ?>》</a></li>
			
		<?php endwhile; else: ?>
		<?php endif; ?>
</ul>
	<div class="navigation clearfix">
		<div class="alignleft"><?php next_posts_link(__('&laquo; Newer Posts')) ?></div>
		<div class="alignright"><?php previous_posts_link(__('Older Posts &raquo;')) ?></div>
	</div>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>