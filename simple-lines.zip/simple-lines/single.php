<?php get_header(); ?>

<div id="left-content-single">
		<?php if (have_posts()) : ?><?php while (have_posts()) : the_post(); ?>

<div class="post-home">
<div class="post-title-single"><h1><?php the_title(); ?></h1><span><a href="<?php bloginfo('url'); ?>/author/<?php the_author_login(); ?>"><?php echo get_avatar( get_the_author_email(), 35); ?></a></span></div>

<div class="post-content"><?php the_content() ?><?php wp_link_pages(); ?></div>
<div class="post-messages">
	<div class="post-messages-1"><?php the_time('Y.m.d'); ?></div><div class="post-messages-2"><?php _e('Tags');?>:<?php the_tags(' ',',', ' '); ?></div><div class="post-messages-2"><?php _e('Category');?>:<?php the_category(',', ' ') ?></div><span class="more-link"><?php edit_post_link('Edit post >>'); ?></span>
	</div>
</div>

<div class="navigation clearfix">
	<div class="alignleft"><?php next_post_link('%link') ?></div>
	<div class="alignright"><?php previous_post_link('%link')  ?></div>
</div>
		<?php endwhile; else: ?>
		<?php endif; ?>
<div id="comments">
<?php comments_template('', true); ?>
</div>
</div>
<?php get_sidebar() ?>
<?php get_footer(); ?>