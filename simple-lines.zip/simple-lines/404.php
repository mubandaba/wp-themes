<?php get_header(); ?>
<div id="left-content-single">
<div id="post-home">
<div id="post-content">
<div id="post-title-page"><h1><span>404 Error - <?php _e('Not found');?></span></h1></div>
<div id="border-all">Sorry, but you are searching for something that is not here.</div>
</div>
</div>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>