</div>
<div id="foot">
<a href="<?php bloginfo('url'); ?>/wp-admin"><?php bloginfo('name'); ?></a>

<a class="footr" href="http://immmmm.com/wordpress-theme-simple-lines-live.html">Simple-Lines</a>
</div>

<?php wp_footer(); ?>
</div>
</body>
</html>