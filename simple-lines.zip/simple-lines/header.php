<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php $the_title = wp_title(' - ', false); if ($the_title != '') : ?>
    <title><?php echo wp_title('',false); ?> | <?php bloginfo('name'); ?></title>
<?php else : ?>
    <title><?php bloginfo('name'); ?></title>
<?php endif; ?>
<?php if (is_single() || is_page() || is_home() ) : ?>
<meta name="robots" content="index,follow" /><?php else : ?><meta name="robots" content="noindex,follow" />
<?php endif; ?>
<?php if(is_single()){?>
<link rel="canonical" href="<?php echo get_permalink($post->ID);?>" />
<?php } ?>
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/style.css" type="text/css" media="screen" />
<link title="RSS 2.0" type="application/rss+xml" href="<?php bloginfo('rss2_url'); ?>" rel="alternate" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?> 
<?php wp_head(); ?>
</head>

<body>
<div id="container">

<div id="header-title">
	<div id="logo"><a href="<?php echo get_settings('home') ?>/"><?php bloginfo('name'); ?></a></div>
	<div id="description"><?php bloginfo('description'); ?></div>
</div>

<div id="menu">
<ul class="nav">
	<li<?php if ( is_home() ) { echo ' class="current_page_item"'; }?>><a title="<?php _e('Home', 'default'); ?>" href="<?php echo get_settings('home'); ?>/"><?php _e('Home', 'default'); ?></a></li>
	<?php wp_list_pages('title_li=&depth=-1'); ?>
</ul>
</div>

<div id="content" class="clearfix">