<?php get_header(); ?>
<div id="left-content-single">
  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div id="post-home">
<div id="post-title-page"><h1><span><?php the_title(); ?></span></h1></div>
<div id="post-content" style="border: 1px solid #ccf;padding:10px;;margin-bottom:1.5em;"><?php the_content(); ?></div>
</div>

<div id="comments">
	<?php comments_template('', true); ?>
</div>

<?php endwhile; endif; ?>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>