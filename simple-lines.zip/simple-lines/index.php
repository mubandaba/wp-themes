<?php get_header(); ?>
<div id="postlist">

<?php if(have_posts()) : while (have_posts()) : the_post(); ?>
	<div id="post-<?php the_ID(); ?>" class="post-home">
		<div class="post-title"><h2><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2></div>
		<div class="post-content">
		<?php the_content(__('More &gt;&gt;')); ?>
		</div>
		<div class="post-messages">
		<div class="post-messages-1"><?php the_time('Y.m.d'); ?></div><div class="post-messages-2"><?php _e('Tags');?>:<?php the_tags(' ',',', ' '); ?></div><div class="post-messages-2"><?php _e('Category');?>:<?php the_category(',', ' ') ?></div><div class="post-messages-3"><?php comments_popup_link('No Comments ', '1 Comment ', '% Comments '); ?></div>
		</div>
	</div>
<?php endwhile; else: ?>
<?php endif; ?>
	<div class="navigation clearfix">
		<div class="alignleft"><?php next_posts_link(__('&laquo; Newer Posts')) ?></div>
		<div class="alignright"><?php previous_posts_link(__('Older Posts &raquo;')) ?></div>
	</div>

</div>

<?php get_sidebar() ?>
<?php get_footer(); ?>