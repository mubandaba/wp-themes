<div id="sidebar">
	<?php 	/* Widgetized sidebar, if you have the plugin installed. */	if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar(1) ) : ?>
<div class="widget_search">
	<?php include(TEMPLATEPATH . '/searchform.php'); ?>
</div>
		<?php if ( is_page() ) {
			?>
		<div class="widget_pages">
				<h3><span><?php _e('Pages');?></span></h3>
				<ul>
						<?php wp_list_pages('title_li='); ?>
				</ul>
		</div>
		<?php } ?>
		<?php if (is_home()) { ?>
		<div class="widget_categories">
				<h3><span><?php _e('Categories');?></span></h3>
				<ul>
						<?php wp_list_categories('title_li='); ?>
				</ul>
		</div>
		<div class="widget_archive">
				<h3><span><?php _e('Archives');?></span></h3>
				<ul>
						<?php wp_get_archives('type=monthly'); ?>
				</ul>
		</div>
		<div class="widget_tag_cloud">
				<h3><span><?php _e('Tag Cloud');?></span></h3>
						<div><?php wp_tag_cloud('smallest=9&largest=16'); ?></div>
		</div>
		<div class="widget_links">
				<h3><span><?php _e('Links');?></span></h3>
				<ul>
						<?php wp_list_bookmarks('title_li=&categorize=0&orderby=rand'); ?>
				</ul>
		</div>
		<div class="widget_meta">
				<h3><span><?php _e('Meta');?></span></h3>
				<ul>
						<?php wp_register(); ?>
						<li><?php wp_loginout(); ?></li>
						<li><a href="<?php bloginfo('rss2_url'); ?>" title="<?php _e('Syndicate this site using RSS'); ?>"><?php _e('<abbr title="Really Simple Syndication">RSS</abbr>'); ?></a></li>
						<li><a href="<?php bloginfo('comments_rss2_url'); ?>" title="<?php _e('The latest comments to all posts in RSS'); ?>"><?php _e('Comments <abbr title="Really Simple Syndication">RSS</abbr>'); ?></a></li>
						<li><a href="http://wordpress.org/" title="Powered by WordPress, state-of-the-art semantic personal publishing platform.">WordPress</a></li>
						<?php wp_meta(); ?>
				</ul>
		</div>
		<?php } ?>
		<?php if ( is_single() || is_404() || is_category() || is_search() || is_page() || is_tag() || is_date() || is_year() ) {
			?>
		<div class="widget_recent_entries">
				<h3><span><?php _e('Random Posts');?></span></h3>
				<ul>
						<?php
						$rand_posts = get_posts('numberposts=6&orderby=rand');
						foreach( $rand_posts as $post ) :
						?>
						<!--defining Loop-->
						<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
						<?php endforeach; ?>
				</ul>
		</div>
		<div class="widget_recent_entries">
				<h3><span><?php _e('Recent Posts');?></span></h3>
				<ul>
						<?php
						$myposts = get_posts('numberposts=6&offset=0&category=0');
						foreach($myposts as $post) :
						setup_postdata($post);
						?>
						<li>
								<a href="<?php the_permalink(); ?>"><?php the_title(); ?> - <?php the_time('Y/m/d'); ?></a>
								
						</li>
						<?php endforeach; ?>
				</ul>	
		</div>
		<div class="widget_tag_cloud">
				<h3><span><?php _e('Tag Cloud');?></span></h3>
				<div><?php wp_tag_cloud('smallest=9&largest=16'); ?></div>
		</div>
		<div class="widget_categories">
				<h3><span><?php _e('Categories');?></span></h3>
				<ul>
						<?php wp_list_categories('title_li='); ?>
				</ul>
		</div>
		<?php } ?>
	<?php endif; ?>

</div>