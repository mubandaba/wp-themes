<?php
if ( function_exists('register_sidebar') ){
    register_sidebar(array(
        'before_widget' => '<div class="%2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3><span>',
        'after_title' => '</span></h3>',
    ));
	}

function mytheme_comment($comment, $args, $depth) {
   $GLOBALS['comment'] = $comment; ?>
   <li <?php comment_class('clearfix'); ?> id="comment-<?php comment_ID() ?>" >
   <div id="div-comment-<?php comment_ID(); ?>" class="c">
   <div class="commentmeta"><?php echo get_avatar( $comment, $size = '35'); ?></div>
   <div class="comments">
         <?php if ($comment->comment_approved == '0') : ?>
         <em><?php _e('Your comment is awaiting moderation.') ?></em>
         <br />
   <?php endif; ?>
<div class="commentmetadata"> &nbsp;-&nbsp;<?php printf(__('%1$s at %2$s'), get_comment_date(),  get_comment_time()) ?></div><div class="reply"><?php comment_reply_link(array_merge( $args, array('add_below' => 'div-comment', 'depth' => $depth, 'max_depth' => $args['max_depth']))) ?></div>
<div class="fn"><?php printf(__('%s'), get_comment_author_link()) ?></div>
<?php comment_text() ?>
</div>
</div>
<?php
}

?>