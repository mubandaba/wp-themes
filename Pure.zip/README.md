# Pure

A pure theme for WordPress.

[![Verson](https://img.shields.io/badge/Release-1.4.0-orange.svg)](https://github.com/izhaoo/pure)
[![PHP](https://img.shields.io/badge/PHP-7.2-blue.svg)](http://www.php.net/ChangeLog-7.php)
[![License](https://img.shields.io/badge/License-MIT-red.svg)](https://mit-license.org/)
[![Github Releases](https://img.shields.io/badge/downloads-184KB-brightgreen.svg)](https://github.com/izhaoo/pure/releases)

* [Demo](https://pure.izhaoo.com)
* [Logs](https://pure.izhaoo.com/development-log.html)

## Introduce

Just 4 write.

## Use It

Download the zip package and upload it to your WordPress.