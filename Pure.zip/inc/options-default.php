<?php
    $default_options = array(
        "description" => "Just 4 Write",
        "keywords" => "WordPress,主题,Pure,极简,响应式,自适应,Ajax,Pjax,zhaoo",
        "copyright" => "Copyright© 2018-2018 | <a href='https://www.izhaoo.com'>zhaoo</a> .AllRightsReserved",
        "ajax" => "1",
        "pjax" => "1",
        "back-to-top" => "1",
        "article-footer" => "1",
        "html" => "",
        "css" => "",
        "js" => "",
        "php" => "",
    );
?>