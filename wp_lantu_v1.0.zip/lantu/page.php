<?php get_header();?>
<div class="inner container">
	<main class="l_box f_l">
		<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
		<article class="blogs post" id="post-<?php the_ID(); ?>">
			<h1 class="title"><?php the_title();?></h1>			
			<div class="entry">
				<?php the_content();?>
			</div>			
			<?php comments_template('',true); ?>
		</article>
		<?php endwhile; ?>
		<?php else : ?>	
		<div class="post">
			<h3>你要找的页面已删除或不存在</h3>
		</div>
		<?php endif;?>
	</main>
	<?php get_sidebar();?>
  <!--r_box end --> 
</div>
<?php get_footer();?>