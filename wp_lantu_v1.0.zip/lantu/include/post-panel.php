<?php
    ini_set( 'error_reporting', E_ALL ^ E_NOTICE );
    ini_set( 'display_errors', '0' );
    $new_meta_boxes =
    array( 				"keywords" => array(            "name" => "keywords",            "std" => "",             "title" => "自定义文章Keywords关键词",            "type"=>"text"),		"description" => array(            "name" => "description",            "std" => "",             "title" => "自定义文章Description描述",            "type"=>"textarea"),	    
    );
    function new_meta_boxes() {
        global $post, $new_meta_boxes;
        foreach($new_meta_boxes as $meta_box) {
            //获取保存的是
            $meta_box_value = get_post_meta($post->ID, $meta_box['name'], true);
            if($meta_box_value != "")
                $meta_box['std'] = $meta_box_value;//将默认值替换为以保存的值 
            echo'<input type="hidden" name="'.$meta_box['name'].'_noncename" id="'.$meta_box['name'].'_noncename" value="'.wp_create_nonce( plugin_basename(__FILE__) ).'" />';
            //通过选择类型输出不同的html代码 
            switch ( $meta_box['type'] ){ 
                case 'title':
                    echo'<h4>'.$meta_box['title'].'</h4>';
                    break; 
                case 'text':
                    echo'<h4 style="margin-top:10px;">'.$meta_box['title'].'</h4>'; 
                    echo '<input style="margin:10px; width:99%; height:32px; line-height:32px;" type="text" size="40" name="'.$meta_box['name'].'" value="'.$meta_box['std'].'" /><br />';
                    break;
                case 'textarea':
                    echo'<h4>'.$meta_box['title'].'</h4>'; 
                    echo '<textarea cols="60" style="margin:10px; width:99%;" rows="3" name="'.$meta_box['name'].'">'.$meta_box['std'].'</textarea><br />';
                    break;				
                case 'dropdown':
                    echo'<h4>'.$meta_box['title'].'</h4>'; 
                    if($meta_box['subtype'] == 'cat'){
                        $select = 'Select category';
                        $entries = get_categories('title_li=&orderby=name&hide_empty=0');//获取分类
                    }
                    echo '<p><select name="'.$meta_box['name'].'"> ';
                    echo '<option value="">'.$select .'</option>  ';
                    foreach ($entries as $key => $entry){
                        $id = $entry->term_id;
                        $title = $entry->name;
                        if ( $meta_box['std'] == $id ){
                            $selected = "selected='selected'";
                        }else{
                            $selected = ""; 
                        } 
                        echo "<option $selected value='". $id."'>". $title."</option>";
                    } 
                    echo '</select><br />';
                    break;
                case 'radio':
                    echo'<h4>'.$meta_box['title'].'</h4>';
                    $counter = 1;
                    foreach( $meta_box['buttons'] as $radiobutton ) {
                        $checked ="";
                        if(isset($meta_box['std']) && $meta_box['std'] == $counter) {
                            $checked = 'checked = "checked"';
                        }
                        echo '<input '.$checked.' type="radio" class="kcheck" value="'.$counter.'" name="'.$meta_box['name'].'"/>'.$radiobutton; 
                        $counter++; 
                    }
                    break;
                case 'checkbox':
                    echo'<h4>'.$meta_box['title'].'</h4>'; 
                    if( isset($meta_box['std']) && $meta_box['std'] == 'true' )
                        $checked = 'checked = "checked"';
                    else
                        $checked  = '';
                    echo '<input type="checkbox" name="'.$meta_box['name'].'" value="true"  '.$checked.' />'; 
                    break;
                //编辑器 
                case 'editor': 
                    echo'<h4>'.$meta_box['title'].'</h4>';
                  /* wp_editor( $meta_box['std'], $meta_box['name'] );*/
                    //带配置参数                    					wp_editor($meta_box['std'],$meta_box['name'],$settings = array('media_buttons'=> false,'teeny'=>false,'quicktags'=>0,'textarea_rows'=>7,'tinymce'=>array('plugins'=>'') ) );
                break;
            }
        } 
    }
    function create_meta_box() {
        global $theme_name;
        if ( function_exists('add_meta_box') ) {
            add_meta_box( 'new-meta-boxes', 'SEO设置', 'new_meta_boxes', 'post', 'normal', 'high' );
			add_meta_box( 'new-meta-boxes', 'SEO设置', 'new_meta_boxes', 'page', 'normal', 'high' );
        }
    } 
    function save_postdata( $post_id ) {
        global $post, $new_meta_boxes;
        foreach($new_meta_boxes as $meta_box) { 
            if ( !wp_verify_nonce( $_POST[$meta_box['name'].'_noncename'], plugin_basename(__FILE__) ))  {
                return $post_id; 
            }
            if ( 'page' == $_POST['post_type'] ) {
                if ( !current_user_can( 'edit_page', $post_id ))
                    return $post_id;
            } 
            else {
                if ( !current_user_can( 'edit_post', $post_id ))
                    return $post_id; 
            } 
            $data = $_POST[$meta_box['name']];
            if(get_post_meta($post_id, $meta_box['name']) == "")
                add_post_meta($post_id, $meta_box['name'], $data, true);
            elseif($data != get_post_meta($post_id, $meta_box['name'], true)) 
                update_post_meta($post_id, $meta_box['name'], $data);
            elseif($data == "") 
                delete_post_meta($post_id, $meta_box['name'], get_post_meta($post_id, $meta_box['name'], true)); 
        }
    }
    add_action('admin_menu', 'create_meta_box');
    add_action('save_post', 'save_postdata');
?>