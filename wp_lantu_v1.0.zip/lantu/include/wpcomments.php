<?php 
function boke8_comment($comment, $args, $depth){
   $GLOBALS['comment'] = $comment; ?>
	<li id="comment-<?php comment_ID(); ?>">				<?php if (function_exists('get_avatar') && get_option('show_avatars')) { ?>
		<div class="gravatar resetimg">
			<?php echo get_avatar($comment, 45);?>
		</div>		<?php } ?>
		<div class="cmt-info">			<p class="time"><?php echo get_comment_time('Y-m-d'); ?></p>			<p class="author"><span><a rel="nofollow" href="<?php comment_author_url() ?>" target="_blank"><?php comment_author() ?></a></span> 说：</p>
		</div>		<div class="cmt-cont">
			<?php if($comment->comment_approved =='0') : ?>
			<em>你的评论正在审核，稍后会显示出来！</em>
			<?php endif;?>	
			<?php comment_text(); ?>		</div>
		<div class="resply">
			<?php comment_reply_link(array_merge( $args, array('reply_text' => '回复','depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
		</div>
<?php } ?>