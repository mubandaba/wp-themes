<?php get_header();?>
<div class="inner container">
	<main class="l_box f_l">
		<div class="main-ad">
			<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- 自适应广告 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-9642311778195731"
     data-ad-slot="6411638153"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
      
		</div>
		<!-- banner代码 结束 -->
		<div class="topnews">
			<h2><span><?php get_breadcrumbs();?></span>最新文章</h2>
		</div>
		<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
		<article class="blogs">
			<figure><?php if((function_exists('has_post_thumbnail')) && (has_post_thumbnail())){the_post_thumbnail('other-thumbnail');}else {?><img src="<?php echo catch_that_image();?>"/><?php } ?></figure>
			<ul>
				<h3><a href="<?php the_permalink() ?>" target="_blank" title="<?php the_title();?>"><?php the_title();?></a></h3>
				<p><?php echo wp_trim_words(get_the_content(),150,'...');?></p>
				<p class="autor"><span class="lm f_l"><?php the_category(' &bull; '); ?></span><span class="dtime f_l"><?php the_time('Y-n-j'); ?></span><?php if(function_exists('the_views')) {?><span class="viewnum f_r">浏览（<a href="<?php the_permalink() ?>" target="_blank" title="<?php the_title();?>"><?php the_views(); ?></a>）</span><?php } ?><span class="pingl f_r">评论（<a href="<?php the_permalink() ?>#comments"><?php comments_number('0','1','%'); ?></a>）</span></p>
			</ul>
		</article>
		<?php endwhile;?>
		<div class="pagenavi">
			<?php boke8_net_pagenavi(6);?>
		</div>
		<?php else : ?>
		<div class="post">
		你要找的页面已删除或不存在
		</div>
		<?php endif;?>
	</main>
	<?php get_sidebar();?>
  <!--r_box end --> 
</div>
<?php get_footer();?>