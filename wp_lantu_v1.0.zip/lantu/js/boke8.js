$(document).ready(function(){
	$('#gotop').click(function(){
		$('html,body').animate({scrollTop:0},500);
	});
	$('#nav .menu ul li').hover(function(){
		$(this).children('a').addClass('on');
		$(this).children('ul').show();
	},function(){
		$(this).find('ul').hide().end().find('a').removeClass('on');
	});
});
window.onload = function (){
	var oLi = document.getElementById("tab").getElementsByTagName("li");
	var oUl = document.getElementById("ms-main").getElementsByTagName("div");	
	for(var i = 0; i < oLi.length; i++)	{
		oLi[i].index = i;
		oLi[i].onmouseover = function (){
			for(var n = 0; n < oLi.length; n++) oLi[n].className="";
			this.className = "cur";
			for(var n = 0; n < oUl.length; n++) oUl[n].style.display = "none";
			oUl[this.index].style.display = "block"
		}	
	}
}
function AddFavorite(title, url) {
	try {
		window.external.addFavorite( url,title);
	}
	catch (e) {
		try {
			window.sidebar.addPanel(title, url, "");
		}
		catch (e) {
			alert("抱歉，您所使用的浏览器无法完成此操作。\n\n加入收藏失败，请使用Ctrl+D进行添加");
		}
	}
}