<aside class="r_box f_r">
    <div class="tit01">
		<h3>关注我</h3>
		<div class="gzwm">
			<ul>
				<?php if($boke8_option["boke8"]["_weibo"]) { ?>
				<li><a rel="nofollow" class="xlwb" href="<?php echo $boke8_option["boke8"]["_weibo"];?>" target="_blank">新浪微博</a></li>
				<?php } ?>
				<?php if($boke8_option["boke8"]["_tencent"]) { ?>
				<li><a rel="nofollow" class="txwb" href="<?php echo $boke8_option["boke8"]["_tencent"];?>" target="_blank">腾讯微博</a></li>
				<?php } ?>
				<li><a class="rss" href="<?php bloginfo("rss2_url");?>" target="_blank">RSS</a></li>
				<?php if($boke8_option["boke8"]["_email"]) { ?>
				<li><a rel="nofollow" class="wx" href="mailto:<?php echo $boke8_option["boke8"]["_email"];?>">邮箱</a></li>
				<?php } ?>
			</ul>
		</div>
    </div>
    <!--tit01 end-->
    <div class="ad300x100"> 
		<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
		<!-- 300x250, 创建于 10-1-6 -->
		<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:250px"
     data-ad-client="ca-pub-9642311778195731"
     data-ad-slot="7322768119"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
	</div>
    <div class="moreSelect" id="lp_right_select">
		<div class="ms-top">
			<ul class="hd" id="tab">
				<li class="cur"><a href="javascript:void(0);">点击排行</a></li>
				<li><a href="javascript:void(0);">最新文章</a></li>
				<li><a href="javascript:void(0);">站长推荐</a></li>
			</ul>
		</div>
		<div class="ms-main" id="ms-main">
			<div style="display: block;" class="bd bd-news" >
				<ul>
				<?php 
					if (function_exists('get_most_viewed')){
					get_most_viewed('post',6);
					}
				?>					
				</ul>
			</div>
			<div  class="bd bd-news">
				<?php query_posts('showposts=6');?>
				<ul>
					<?php while (have_posts()) : the_post(); ?>
					<li><a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title();?>"><?php the_title();?></a></li>
					<?php endwhile;?>
				</ul>
				<?php wp_reset_query(); ?>
			</div>
			<div class="bd bd-news">
			<?php
			if(get_option('sticky_posts')){
			$sticky = get_option('sticky_posts');
			rsort( $sticky );			
			query_posts( array( 'post__in' => $sticky, 'ignore_sticky_posts' => 1,'showposts'=>'6' ) );
			if (have_posts()) :
			?>
				<ul>
					<?php while (have_posts()) : the_post();?>
					<li><a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title(); ?>"><?php the_title(); ?></a></li> 
					<?php endwhile; ?>
				</ul>
			<?php endif; wp_reset_query();}else{?>
			<ul>
			<p>暂无置顶推荐</p>
			</ul>
			<?php }?>
			</div>
		</div>
		<!--ms-main end --> 
    </div>
    <!--切换卡 moreSelect end -->
    
    <div class="cloud">
		<h3>标签云</h3>
		<ul>
			<?php wp_tag_cloud('smallest=9&largest=9&number=15&orderby=count&order=DESC'); ?>     
		</ul>
    </div>
    <div class="tuwen">
		<h3>图文推荐</h3>
		<?php query_posts('showposts=6&cat=1');?>
		<ul>
			<?php while (have_posts()) : the_post();?>
			<li>
				<a href="<?php the_permalink() ?>" target="_blank" title="<?php the_title();?>">
					<?php if((function_exists('has_post_thumbnail')) && (has_post_thumbnail())){the_post_thumbnail('other-thumbnail');}else {?><img src="<?php echo catch_that_image();?>"/><?php } ?>
					<b><?php the_title();?></b>
				</a>
				<p><span class="tutime"><?php the_time('Y-n-j'); ?></span></p>
			</li> 
			<?php endwhile; ?>
		</ul>
		<?php wp_reset_query();?>
    </div>
    <?php if(is_home()){?>
    <div class="links">
		<h3><span>[<a href="<?php bloginfo('url');?>/links">申请友情链接</a>]</span>友情链接</h3>
		<ul>
			<?php wp_list_bookmarks('show_description=0&show_images=0&title_li=&categorize=0'); ?>  
		</ul>
    </div>
	<?php } ?>
</aside>