<?php 
if(isset($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
	die('please do not load this page directly. Thanks!');
	if ( post_password_required() ) {
?>
<div id="comments" class="commentlist">
	<h3>网友评论</h3>
	<ol>
		<li>
			<p>请输入密码再查看评论内容.</p>
		</li>
	</ol>
</div>
<?php return;} ?>
<?php if ( have_comments() ) { ?>
<div id="comments" class="commentlist">
	<h3>网友评论</h3>
	<ol>
		<?php wp_list_comments('type=comment&callback=boke8_comment');?>
		<?php
			if (get_option('page_comments')) {
				$comment_pages = paginate_comments_links('echo=0');
				if ($comment_pages) {
					echo '<li class="pagenavi">';
					echo $comment_pages;
					echo '</li>';
				}
			}
		?>
	</ol>
</div>
<?php }else {} ?>
<?php if (comments_open() ) : ?>
<div id="comment">
	<h3>我要评论</h3>	
	<div id="respond" class="comment-form">
	<?php if (get_option('comment_registration') && !is_user_logged_in()) :	?>
	<p>你必须 <a href="<?php echo wp_login_url( get_permalink() ); ?>">登录</a> 才能发表评论.</p>
	<?php else : ?>
		<form id="commentform" name="commentform" action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post">
			<?php if(is_user_logged_in()) :?>
			<p>您已登录:<a href="<?php echo get_option('siteurl'); ?>/wp-admin/profile.php"><?php echo $user_identity; ?></a>. <a href="<?php echo wp_logout_url(get_permalink()); ?>" title="退出登录">退出 &raquo;</a></p>
			<?php else : ?>
			<p>
				<input type="text" class="text" name="author" id="author" value="<?php echo $comment_author; ?>" tabindex="1"/><label>昵称（必填）</label>
			</p>
			<p>
				<input type="text" class="text" name="email" id="email" value="<?php echo $comment_author_email; ?>" tabindex="2"/><label>邮箱（必填）</label>
			</p>
			<p>
				<input type="text" class="text" name="url" id="url" value="<?php echo $comment_author_url; ?>" tabindex="3"/><label>个人主页</label>
			</p>
			<?php endif; ?>	
			<p>
				<textarea name="comment" id="comment" class="textarea" tabindex="4"></textarea>
			</p>
			<p>
				<input type="submit" name="submit" id="submit" class="submit" tabindex="5" value="提交"/>
			</p>
			<?php cancel_comment_reply_link(); ?>
			<?php comment_id_fields(); ?>
			<?php do_action('comment_form',$post->ID);?>
		</form>
	<?php endif; ?>	
	</div>
</div>
<?php endif;?>