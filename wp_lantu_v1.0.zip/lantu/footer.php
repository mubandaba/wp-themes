<?php global $boke8_option;?>
<footer class="footer">
	<div class="inner">	
		<p class="ft-copyright"><?php copyrightDate();?>  <?php bloginfo('name');?>. Design by DanceSmile. Theme By <a href="http://www.boke8.net" target="_blank">博客吧</a> </p>
		<p><?php if($boke8_option["boke8"]["_statistics"]){ echo stripslashes($boke8_option["boke8"]["_statistics"]);}?> <?php if($leonhere_option["leonhere"]["_icp"]){ echo '<a class="ipc" href="http://www.miitbeian.gov.cn/">'.$leonhere_option["leonhere"]["_icp"].'</a>';}?></p>
	</div>
</footer>
<div id="tbox">
	<a id="gotop" href="javascript:void(0)"></a>
</div>
<?php wp_footer();?>
</body>
</html>