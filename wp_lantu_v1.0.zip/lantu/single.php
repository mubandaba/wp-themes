<?php get_header();?>
<div class="inner container">
	<main class="l_box f_l">
		<div class="main-ad">
			<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- 自适应广告 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-9642311778195731"
     data-ad-slot="6411638153"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
		</div>	
		<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
		<article class="blogs post" id="post-<?php the_ID(); ?>">
			<h1 class="title"><?php the_title();?></h1>
			<div class="postmeta">
				<p class="autor">
					<span class="lm f_l"><?php the_category(' &bull; '); ?></span>
					<span class="dtime f_l"><?php the_time('Y-n-j'); ?></span>
					<?php if(function_exists('the_views')) {?><span class="viewnum f_r">浏览（<?php the_views(); ?>）</span><?php } ?>
					<span class="pingl f_r">评论（<?php comments_number('0','1','%'); ?>）</span>
				</p>
			</div>
			<div class="entry">
				<?php the_content();?>
			</div>			
			<?php 
			$tags = wp_get_post_tags($post->ID);
			if ($tags) {
				$first_tag = $tags[0]->term_id;
				$args=array('tag__in' => array($first_tag),'post__not_in' => array($post->ID),'showposts'=>8,'caller_get_posts'=>1);
				$my_query = new WP_Query($args);
				if( $my_query->have_posts() ) {
			?>
			<div class="related">
				<h3>相关推荐</h3>
				<ul>
					<li><span><?php the_time('Y-n-j');?></span><a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title();?>"><?php the_title();?></a></li>					
				</ul>
			</div>
			<?php } } wp_reset_query();?>
			<?php comments_template('',true); ?>
		</article>
		<?php endwhile; ?>
		<?php else : ?>	
		<div class="post">
			<h3>你要找的页面已删除或不存在</h3>
		</div>
		<?php endif;?>
	</main>
	<?php get_sidebar();?>
  <!--r_box end --> 
</div>
<?php get_footer();?>