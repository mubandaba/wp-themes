<?php  
$shortname = "boke8"; 
$pageinfo = array(
	'full_name' => '', 
	'optionname'=>'boke8', 
	'child'=>false, 
	'filename' => basename(__FILE__)
);
$cats_array = get_categories('hide_empty=0');
$pages_array = get_pages('hide_empty=0');
$site_pages = array();
$site_cats = array();
foreach ($pages_array as $pagg) {
	$site_pages[$pagg->ID] = $pagg->post_title;
}
foreach ($cats_array as $categs) {
	$site_cats[$categs->cat_ID] = $categs->cat_name;
}
$options = array();                  
$options[] = array( "type" => "open","desc"=>"SEO基础设置");
$options[] = array("name"=>"首页Title标题","id"=>"_title","std"=>"","desc"=>"这里是首页title标题设置","size"=>"60","type"=>"text"); 
$options[] = array("name"=>"网站关键词","id"=>"_keywords","std"=>"","desc"=>"这里是网站关键词设置","size"=>"60","type"=>"text");			
$options[] = array("name"=>"网站描述","id"=>"_description","std"=>"","desc"=>"这里是网站描述，建议不超过150字符","size"=>"60","type"=>"textarea"); 
$options[] = array("name"=>"内页Title标题分隔符","id"=>"_separator","std"=>"","desc"=>"这里是网页标题Title分隔符设置，输入“ | ”、“ _ ”、“ - ”或其它符号，默认是下划线，除非有必要，否则不要修改","size"=>"60","type"=>"text");
$options[] = array( "type" => "close","desc"=>"");
$options[] = array( "type" => "open","desc"=>"LOGO设置"); 
$options[] = array("name" => "LOGO上传","desc" => "上传网站LOGO图片，点击“插件入图片”，选择电脑本地图片，上传后点击“插入到文件”","std"=>"","id" => "_logo","type" => "upload");
$options[] = array( "type" => "close","desc"=>"");
$options[] = array( "type" => "open","desc"=>"其它设置");
$options[] = array("name"=>"新浪微博","id"=>"_weibo","std"=>"","desc"=>"输入新浪微博地址","size"=>"60","type"=>"text");
$options[] = array("name"=>"腾讯微博","id"=>"_tencent","std"=>"","desc"=>"输入腾讯微博地址","size"=>"60","type"=>"text");
$options[] = array("name"=>"邮箱地址","id"=>"_email","std"=>"","desc"=>"输入邮箱地址","size"=>"60","type"=>"text");
$options[] = array("name"=>"统计代码","id"=>"_statistics","std"=>"","desc"=>"第三方统计代码，如百度统计、cnzz统计或者谷歌统计,支持HTML代码","size"=>"60","type"=>"textarea");
$options[] = array("name"=>"ICP备案号","id"=>"_icp","std"=>"","desc"=>"输入ICP备案号","size"=>"60","type"=>"text"); 
$options[] = array( "type" => "close","desc"=>"更多wordpress主题请访问 <a href='http://www.boke8.net'>博客吧</a> ！"); 
$options_page = new ashu_option_class($options, $pageinfo);   
?>