<?php
function remove_open_sans() {
	wp_deregister_style( 'open-sans' );
	wp_register_style( 'open-sans', false );
	wp_enqueue_style('open-sans','');
}
add_action( 'init', 'remove_open_sans' );
include_once('include/wpcomments.php');
include_once('optionsclass/optionclass.php');
include_once('optionsclass/option.php');
include_once('include/post-panel.php');
include_once('include/more.php');
remove_action('pre_post_update', 'wp_save_post_revision' ); 
function hide_admin_bar($flag) {return false;}
add_filter('show_admin_bar','hide_admin_bar');
add_filter( 'pre_option_link_manager_enabled', '__return_true' );
remove_action('wp_head', 'wp_shortlink_wp_head', 10, 0 );
remove_action( 'wp_head', 'feed_links_extra', 3 ); 
remove_action('wp_head', 'wlwmanifest_link');
remove_action( 'wp_head', 'index_rel_link' ); 
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wp_generator');
add_theme_support( 'post-thumbnails', array( 'post', 'page' ) );
add_image_size( 'single-thumbnail', 180, 9999 );
add_image_size( 'other-thumbnail', 105, 120 );
function add_editor_buttons($buttons) {
	$buttons[] = 'fontselect';	
	$buttons[] = 'fontsizeselect';
	$buttons[] = 'cleanup';
	$buttons[] = 'styleselect';
	$buttons[] = 'hr';
	$buttons[] = 'del';
	$buttons[] = 'sub';
	$buttons[] = 'sup';
	$buttons[] = 'copy';
	$buttons[] = 'paste';
	$buttons[] = 'cut';
	$buttons[] = 'undo';
	$buttons[] = 'image';
	$buttons[] = 'anchor';
	$buttons[] = 'backcolor';
	$buttons[] = 'wp_page';
	$buttons[] = 'charmap';
	return $buttons;
}
add_filter("mce_buttons_3", "add_editor_buttons");
register_nav_menus(array('header-menu' => __( '顶部导航菜单' ),	));
function get_category_root_id($cat){
	$this_category = get_category($cat);
	while($this_category->category_parent){
		$this_category = get_category($this_category->category_parent);
	}
	return $this_category->term_id;
}
function post_is_in_descendant_category( $cats,$_post = null ){
	foreach ( (array) $cats as $cat ) {
		$descendants = get_term_children( (int) $cat,'category');
		if ( $descendants &&in_category( $descendants,$_post ) )
			return true;
		}
	return false;
}
function get_breadcrumbs(){
    global $wp_query; 
	if(is_home()) {
		echo '<a href="'. get_option('home') .'">'. get_bloginfo('name') .'首页</a>';		
	}
    if ( !is_home() ){ 
        // Start the UL        
        // Add the Home link
        echo '<a href="'. get_option('home') .'">'. get_bloginfo('name') .'</a>';
        if ( is_category() )
        {
            $catTitle = single_cat_title( "", false );
            $cat = get_cat_ID( $catTitle );
            echo " / ". get_category_parents( $cat, TRUE, "" );
        }
        elseif ( is_archive() && !is_category() )
        {
            echo " / Archives";
        }
        elseif ( is_search() ) { 
            echo " / 搜索结果";
        }
        elseif ( is_404() )
        {
            echo " / 404 Not Found";
        }
        elseif ( is_single() )
        {
            $category = get_the_category();
            $category_id = get_cat_ID( $category[0]->cat_name );
            echo ' / '. get_category_parents( $category_id, TRUE, " &raquo; " );
            echo the_title('','', FALSE);
        }
        elseif ( is_page() )
        {
            $post = $wp_query->get_queried_object();
            if ( $post->post_parent == 0 ){
                echo " / ".the_title('','', FALSE);
            } else {
                $title = the_title('','', FALSE);
                $ancestors = array_reverse( get_post_ancestors( $post->ID ) );
                array_push($ancestors, $post->ID); 
                foreach ( $ancestors as $ancestor ){
                    if( $ancestor != end($ancestors) ){
                        echo ' / <a href="'. get_permalink($ancestor) .'">'. strip_tags( apply_filters( 'single_post_title', get_the_title( $ancestor ) ) ) .'</a>';
                    } else {
                        echo ' / '. strip_tags( apply_filters( 'single_post_title', get_the_title( $ancestor ) ) );
                    }
                }
            }
        } 
        // End the UL
    }
}
function tagtext(){
	global $post;
	$gettags = get_the_tags($post->ID);
	if ($gettags) {
		foreach ($gettags as $tag) {
		$posttag[] = $tag->name;
	}
	$tags = implode( ',', $posttag );
		echo $tags;
	}
}
function boke8_net_pagenavi($range = 9){
	global $paged, $wp_query, $max_page;
	if ( !$max_page ) {$max_page = $wp_query->max_num_pages;}
	if($max_page > 1){if(!$paged){$paged = 1;}
	if($paged != 1){echo "<a href='" . get_pagenum_link(1) . "' class='extend' title='跳转到首页'> 首页 </a>";}
	previous_posts_link(' 上一页 ');
    if($max_page > $range){
		if($paged < $range){for($i = 1; $i <= ($range + 1); $i++){echo "<a href='" . get_pagenum_link($i) ."'";
		if($i==$paged)echo " class='oncurrent'";echo ">$i</a>";}}
    elseif($paged >= ($max_page - ceil(($range/2)))){
		for($i = $max_page - $range; $i <= $max_page; $i++){echo "<a href='" . get_pagenum_link($i) ."'";
		if($i==$paged)echo " class='oncurrent'";echo ">$i</a>";}}
	elseif($paged >= $range && $paged < ($max_page - ceil(($range/2)))){
		for($i = ($paged - ceil($range/2)); $i <= ($paged + ceil(($range/2))); $i++){echo "<a href='" . get_pagenum_link($i) ."'";if($i==$paged) echo " class='oncurrent'";echo ">$i</a>";}}}
    else{for($i = 1; $i <= $max_page; $i++){echo "<a href='" . get_pagenum_link($i) ."'";
    if($i==$paged)echo " class='oncurrent'";echo ">$i</a>";}}
	next_posts_link(' 下一页 ');
    if($paged != $max_page){echo "<a href='" . get_pagenum_link($max_page) . "' class='extend' title='跳转到最后一页'> 末页 </a>";}}
}
function catch_that_image() {
	global $post, $posts;
	$first_img = '';
	ob_start();
	ob_end_clean();
	$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
	if(isset($matches[1][0])){
		$first_img = $matches[1][0];
	}else{		
        $first_img = get_bloginfo('template_directory')."/images/no-image.jpg";
	}
	return $first_img;
}
function copyrightDate() {
	global $wpdb;
	$copyright_dates = $wpdb->get_results("
		SELECT
			YEAR(min(post_date_gmt)) AS firstdate,
			YEAR(max(post_date_gmt)) AS lastdate
		FROM
			$wpdb->posts
		WHERE post_status = 'publish'
	");
	if($copyright_dates) {
		$date = date('Y-m-d');
		$date = explode('-', $date);
		$copyright = "Copyright &copy; " . $copyright_dates[0]->firstdate;
		if($copyright_dates[0]->firstdate != $date[0]) {
			$copyright .= '-' . $date[0];
		}
		echo $copyright;
	}
}
global $texonomy_slug_keywords;
$texonomy_slug_keywords='category';
add_action($texonomy_slug_keywords.'_add_form_fields','categorykeywords');
function categorykeywords($taxonomy){ ?>
    <div>
    <label for="tag-keywords">分类关键词</label>
    <input type="text" name="tag-keywords" id="tag-keywords" value="" /><br /><span>请在此输入分类关键词。</span>    
</div>
<?php }
add_action($texonomy_slug_keywords.'_edit_form_fields','categorykeywordsedit');
function categorykeywordsedit($taxonomy){ ?>
<tr class="form-field">
    <th scope="row" valign="top"><label for="tag-keywords">关键词</label></th>
    <td><input type="text" name="tag-keywords" id="tag-keywords" value="<?php echo get_option('_category_keywords'.$taxonomy->term_id); ?>" /><br /><span class="description">请在此输入分类关键词。</span></td>
</tr>              
<?php  }
add_action('edit_term','categorykeywordssave');
add_action('create_term','categorykeywordssave');
function categorykeywordssave($term_id){
    if(isset($_POST['tag-keywords'])){
        if(isset($_POST['tag-keywords']))
            update_option('_category_keywords'.$term_id,$_POST['tag-keywords'] );
    }
}
?>