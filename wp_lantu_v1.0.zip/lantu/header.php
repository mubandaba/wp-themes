<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
<?php global $boke8_option;?>
<title><?php if ( $paged > 1 ) {echo ('第'); echo ($paged); echo '页'; if($boke8_option["boke8"]["_separator"]){ echo $boke8_option["boke8"]["_separator"];	}else {	echo '_';}}?><?php if (is_home () ) {if($boke8_option["boke8"]["_title"]){echo $boke8_option["boke8"]["_title"];}else {bloginfo('name'); if($boke8_option["boke8"]["_separator"]){echo $boke8_option["boke8"]["_separator"];}else {echo '_';} bloginfo('description');}	} elseif ( is_category() ) {single_cat_title(); if($boke8_option["boke8"]["_separator"]){ echo $boke8_option["boke8"]["_separator"];}else {echo '_';} bloginfo('name'); } elseif (is_single() || is_page() ) {single_post_title(); if($boke8_option["boke8"]["_separator"]){ echo $boke8_option["boke8"]["_separator"];	}else {echo '_';}bloginfo('name'); } elseif (is_search() ) {echo "全站搜索结果:"; echo esc_html($s); } else { wp_title('',true); if($boke8_option["boke8"]["_separator"]){ echo $boke8_option["boke8"]["_separator"];}else {	echo '_';} bloginfo('name'); } ?></title>
<?php 
if(is_home()){ 
	if($boke8_option["boke8"]["_keywords"]) { 
		$keywords = $boke8_option["boke8"]["_keywords"]; 
	} else { 
		$keywords = get_bloginfo('name');
	}
?>
	<meta name="keywords" content="<?php echo $keywords;?>"/>
<?php 
	if($boke8_option["boke8"]["_description"]) { 
		$description = $boke8_option["boke8"]["_description"]; 
	} else { 
		$description = get_bloginfo('description');
	} 
?>
	<meta name="description" content="<?php echo $description;?>"/>
<?php }else if(is_category()){
	global $wp_query;
	$cat_ID = get_query_var('cat');
	$cat_des = strip_tags(category_description());
	$cat_des = str_replace("\n","",$cat_des);
	$cat_keywords = get_option('_category_keywords'.$cat_ID);
?>	
	<meta name="keywords" content="<?php echo $cat_keywords;?>"/>
	<meta name="description" content="<?php echo $cat_des;?>"/>
<?php } else if(is_single()) {
	if(get_post_meta($post->ID, "description", true)){
		$description = get_post_meta($post->ID, "description", true);
	}else{
		$description = wp_trim_words(get_the_content(),110);
		$description=str_replace("\n","",$description);
	}
	if(get_post_meta($post->ID, "keywords", true)){
		$keywords = get_post_meta($post->ID, "keywords", true);
?>
	<meta name="keywords" content="<?php echo $keywords; ?>"/>
<?php }else{ ?>
	<meta name="keywords" content="<?php tagtext();?>"/>
<?php } ?>
	<meta name="description" content="<?php echo $description;?>"/>
<?php }else if(is_page()){
	if(get_post_meta($post->ID, "description", true)){
		$description = get_post_meta($post->ID, "description", true);
	}else{
		$description = wp_trim_words(get_the_content(),110);
		$description=str_replace("\n","",$description);
	}if(get_post_meta($post->ID, "keywords", true)){
		$keywords = get_post_meta($post->ID, "keywords", true);
?>
	<meta name="keywords" content="<?php echo $keywords; ?>"/>
<?php }?>
	<meta name="description" content="<?php echo $description; ?>"/>
<?php } ?>
<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_url'); ?>" media="screen" />
<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/jquery.min.js"></script>
<!--[if lt IE 9]>
<script src="<?php bloginfo('template_url');?>/js/modernizr.js"></script>
<![endif]-->
<!-- 返回顶部调用 begin -->
<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/boke8.js"></script>
<!-- 返回顶部调用 end-->
<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
<?php wp_head();?>
</head>
<body>
<div class="top-bar">
	<div class="inner">
		<div class="google-ad">
		<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
		<!-- 468x15, 创建于 09-8-19 -->
		<ins class="adsbygoogle"
			style="display:inline-block;width:468px;height:15px"
			data-ad-client="ca-pub-9642311778195731"
			data-ad-slot="1079685849"></ins>
		<script>
		(adsbygoogle = window.adsbygoogle || []).push({});
		</script>
		</div>
		<a href="javascript:void(0);" onclick="AddFavorite('<?php bloginfo('name');?>','<?php bloginfo('url');?>')">收藏本站</a>
	</div>
</div>
<header>
	<div class="logo f_l"> 
	<?php
		if($boke8_option["boke8"]["_logo"]) {
			$logo = $boke8_option["boke8"]["_logo"];
		}else{
			$logo = get_bloginfo('template_url')."/images/logo.png";
		}
		?>
		<a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>"><img src="<?php echo $logo;?>" alt="<?php bloginfo('name'); ?>"/></a>
	</div>
	<div id="search-form" class="f_r">
		<form id="searchform" method="get" action="<?php bloginfo('url'); ?>/" >
			<input type="text" name="s" class="s" value="" placeholder="输入关键词搜索"/>
			<input type="submit" name="submit" class="submit" value="搜索"/>
		</form>
	</div>
</header>
<nav id="nav">
	<?php if(function_exists('wp_nav_menu')){
	wp_nav_menu( array('theme_location' =>'header-menu','container' => 'div','container_class' => 'inner menu','menu_class' => 'inner menu','depth' => 0,'items_wrap' => '<ul>%3$s</ul>'));}?>	
</nav>