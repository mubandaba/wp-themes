<?php get_header(); ?>
<div id="content">
<div class="main">
<?php if (get_option('creekoo_ad-single-top') == 'Display') { ?>
<div id="ad-single-top">
<?php echo stripslashes(get_option('creekoo_ad-single-topcode')); ?></div>
<?php } else {echo ''; } ?> 


<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
  
<?php include('includes/article_right.php'); ?>

<div class="article" style="width:620px;float:left">
<div id="map">
<div class="site">当前位置：<a title="返回首页" href="<?php echo get_settings('Home'); ?>/">首页</a> &gt; <?php the_category('、') ?> &gt; <h1><?php the_title();?></h1></div>
</div>
 <div class="context">
        <?php the_content(); ?>

      </div>
  </div>
<?php include('includes/single_related.php'); ?>

<div class="comments-main">
<?php comments_template(); ?>
</div>
<?php if (get_option('creekoo_ad-single-bottom') == 'Display') { ?>
<div id="ad-single-bottom">
<?php echo stripslashes(get_option('creekoo_ad-single-bottomcode')); ?></div>
<?php } else {echo ''; } ?> 
</div>
  <?php endwhile; else: ?>
  <?php endif; ?>

<?php get_sidebar(); ?>
<?php get_footer(); ?>