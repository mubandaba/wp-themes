<?php get_header(); ?>
<div id="content">
<div class="main" style="width:830px">
<div id="map" style="width:820px">
<div class="site">当前位置： <a title="返回首页" href="<?php echo get_settings('Home'); ?>/">首页</a> &gt; <?php the_title(); ?></div></div>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="article" style="margin-right:0px">

<h2 style="padding:7px 0 0px 10px;font-size:15px"><?php the_title(); ?></h2>

<div class="context"><?php the_content('Read more...'); ?></div>
</div>
<div class="comments-main" style="width:830px">
<?php comments_template(); ?>
</div>
	<?php endwhile; else: ?>
	<?php endif; ?>
</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>