<?php get_header(); ?>
<div id="roll"><div title="回到顶部" id="roll_top"></div></div>
<div id="content">
<div class="main">
  <div class="article">
<span class="error">
<p style="padding-top:20px">抱歉，您打开的页面未能找到。</p>
<p>您可以使用本站的搜索框搜索您想要的内容，如有不便深感抱歉！</p>
<p><a href="<?php bloginfo('home'); ?>">返回首页</a></p>
<p><a href="javascript:history.back();">返回前一页</a></p>
<p><a href="/guestbook" target="_blank">留言将该错误链接提交给站长</a></p>
<p style="padding-bottom:20px">您还可以使用本站搜索功能找到你要的文章哦</p></span>
</div>

</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
