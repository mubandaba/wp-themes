<div class="clear"></div>
<div id="footer">
	<div id="footermain">
		<a id="footerlogo" href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>"></a>
	<?php echo stripslashes(get_option('creekoo_footerlinkcode')); ?></br><?php do_action( 'creekoo_footerinfo' ); ?>
	</div>
 </div>
<?php wp_enqueue_script('jquery'); ?>
<?php wp_footer(); ?>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/comments-ajax.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/creekoo.min.js?v1.1"></script>
</body>
</html>