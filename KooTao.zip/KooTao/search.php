<?php get_header(); ?>
<div id="content">
<div class="main">
  <div id="map_2">
    <div class="site">当前位置：<a title="返回首页" href="<?php echo get_settings('Home'); ?>/">首页</a> &gt; 搜索结果</div>
  </div>
  <?php if (have_posts()) : ?>
  <?php while (have_posts()) : the_post(); ?>
       <div class="shopbox">
        <?php include('includes/articlepic.php'); ?>
        <h2><a href="<?php the_permalink() ?>" rel="bookmark" title="详细阅读：<?php the_title_attribute(); ?>"><?php the_title();?></a></h2>
        <div class="price">¥<?php echo get_post_meta($post->ID,"price_value",true);?></div>
        <a href="<?php echo get_post_meta($post->ID,"taobao_value",true);?>" rel="bookmark" title="淘宝购买<?php the_title_attribute(); ?>" target="_blank"><span class="buy">淘宝购买</span></a><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><span class="read">查看详情</span></a>
        <div class="clear"></div>
      </div>
  <?php endwhile; else: ?>
  <div style="background:#fff;width:830px">
  <h3 style="padding: 15px;">非常抱歉，无法搜索到与之相匹配的信息。</h3>
</div>
  <?php endif; ?>
  <div class="navigation">
    <?php pagination($query_string); ?>
  </div>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>