  <div class="article_right">
    <div id="shopbox-info_sideroll">
      <div class="shopbox-info">
          <a href="<?php echo get_post_meta($post->ID,"taobao_value",true);?>" rel="bookmark" title="淘宝购买：<?php the_title(); ?>">
          <?php if (has_post_thumbnail()) { the_post_thumbnail('thumbnail'); }
          else { ?>
          <img class="home-thumb" src="<?php echo catch_first_image() ?>" width="180px" height="180px" alt="<?php the_title(); ?>"/>
          <?php } ?>
          </a>
        
        <a href="<?php echo get_post_meta($post->ID,"taobao_value",true);?>" rel="bookmark" title="淘宝购买：<?php the_title(); ?>" target="_blank"><span class="buy">淘宝购买</a></span>
        <span class="price">特价：¥<?php echo get_post_meta($post->ID,"price_value",true);?></span>
        <div class="clear"></div>
      </div>
      <?php include('baidushare.php'); ?>
    </div>

   </div>