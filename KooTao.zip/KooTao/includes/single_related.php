<div style="width:630px">
  <?php
  $post_num = 9; 
  global $post;
  $tmp_post = $post;
  $tags = ''; $i = 0;
  if ( get_the_tags( $post->ID ) ) {
  foreach ( get_the_tags( $post->ID ) as $tag ) $tags .= $tag->name . ',';
  $tags = strtr(rtrim($tags, ','), ' ', '-');
  $myposts = get_posts('numberposts='.$post_num.'&tag='.$tags.'&exclude='.$post->ID);
  foreach($myposts as $post) {
  setup_postdata($post);
  ?>
      <div class="shopbox">
        <?php include('articlepic.php'); ?>
        <h2><a href="<?php the_permalink() ?>" rel="bookmark" title="详细阅读：<?php the_title_attribute(); ?>"><?php the_title();?></a></h2>
        <div class="price">¥<?php echo get_post_meta($post->ID,"price_value",true);?></div>
        <a href="<?php echo get_post_meta($post->ID,"taobao_value",true);?>" rel="bookmark" title="淘宝购买<?php the_title_attribute(); ?>" target="_blank"><span class="buy">淘宝购买</span></a><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><span class="read">查看详情</span></a>
      </div>
<?php
  $i += 1;
  }
  }
  if ( $i < $post_num ) {
  $post = $tmp_post; setup_postdata($post);
  $cats = ''; $post_num -= $i;
  foreach ( get_the_category( $post->ID ) as $cat ) $cats .= $cat->cat_ID . ',';
  $cats = strtr(rtrim($cats, ','), ' ', '-');
  $myposts = get_posts('numberposts='.$post_num.'&category='.$cats.'&exclude='.$post->ID);
  foreach($myposts as $post) {
  setup_postdata($post);
  ?>
       <div class="shopbox">
        <?php include('articlepic.php'); ?>
        <h2><a href="<?php the_permalink() ?>" rel="bookmark" title="详细阅读：<?php the_title_attribute(); ?>"><?php the_title();?></a></h2>
        <div class="price">¥<?php echo get_post_meta($post->ID,"price_value",true);?></div>
        <a href="<?php echo get_post_meta($post->ID,"taobao_value",true);?>" rel="bookmark" title="淘宝购买<?php the_title_attribute(); ?>" target="_blank"><span class="buy">淘宝购买</span></a><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><span class="read">查看详情</span></a>
      </div>
  <?php
  }
  }
  $post = $tmp_post; setup_postdata($post);
  ?>
</div>
<div class="clear"></div>