<div style="background:#fff;margin-top:10px;padding:5px 9px 4px 6px;float:left">
<div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare">
<a class="bds_tsina" style="margin-right:0"></a>
<a class="bds_qzone" style="margin-right:0"></a>
<a class="bds_tqq" style="margin-right:0"></a>
<a class="bds_sqq" style="margin-right:0"></a>
<span class="bds_more"></span>
</div>
<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=0" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000)
</script>
</div>