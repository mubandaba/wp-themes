<div class="widget">
<div class="tags">
<h3>标签云集</h3>
<div style="margin-top:5px">
<?php wp_tag_cloud('smallest=12&largest=12&unit=px&number=50&orderby=id&order=DESC');?></div>

</div><div class="clear"></div>
</div>