<?php get_header(); ?>
<div id="content">
<div class="main">
  <div id="map_2">
    <div class="site">当前位置：<a title="返回首页" href="<?php echo get_settings('Home'); ?>/">首页</a> &gt;
      <?php if (have_posts()) : ?>
      <?php $post = $posts[0]; ?>
      <?php if (is_category()) { ?>
      <?php single_cat_title(); ?>
      <?php } elseif( is_tag() ) { ?>
      <?php single_tag_title(); ?>
      <?php } elseif (is_day()) { ?>
      <?php the_time('Y年n月j日'); ?>
      发布的所有日志
      <?php } elseif (is_month()) { ?>
      <?php the_time('Y年n月'); ?>
      发布的所有日志
      <?php } elseif (is_year()) { ?>
      <?php the_time('Y年'); ?>
      发布的所有日志
      <?php } elseif (is_author()) { ?>
      <?php wp_title( '');?>
      发布的所有日志
      <?php } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
        <h1>Blog Archives</h1>
        <?php } ?>
      <?php endif; ?>
    </div>
  </div>
<?php if (have_posts()) : ?><?php while (have_posts()) : the_post(); ?>
<div class="shopbox">
        <?php include('includes/articlepic.php'); ?>
        <h2><a href="<?php the_permalink() ?>" rel="bookmark" title="详细阅读：<?php the_title_attribute(); ?>"><?php the_title();?></a></h2>
        <div class="price">¥<?php echo get_post_meta($post->ID,"price_value",true);?></div>
        <a href="<?php echo get_post_meta($post->ID,"taobao_value",true);?>" rel="bookmark" title="淘宝购买<?php the_title_attribute(); ?>" target="_blank"><span class="buy">淘宝购买</span></a><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><span class="read">查看详情</span></a>
        <div class="clear"></div>
      </div>
  <?php endwhile; ?>
  <?php endif; ?>
  <div class="navigation">
    <?php pagination($query_string); ?>
  </div>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
