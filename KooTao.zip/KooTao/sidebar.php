<div id="sidebar">

<div id="sideroll">

<?php include('includes/r_tags.php'); ?>

<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('小工具一') ) : ?>
<?php endif; ?>

<?php if (get_option('creekoo_ad-right') == 'Display') { ?>
<div id="ad-right">
<?php echo stripslashes(get_option('creekoo_ad-rightcode')); ?></div>
<?php } else {echo ''; } ?> 
</div>

<div class="sidebarhot">
	<h3>随机推荐</h3>
  <?php
  query_posts(array('orderby' => 'rand', 'showposts' => 8, 'caller_get_posts' => 8));
  if (have_posts()) :
  while (have_posts()) : the_post();?>
<div class="hotshopbox">
		<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
		<?php if (has_post_thumbnail()) { the_post_thumbnail('thumbnail'); }
		else { ?>
		<img class="home-thumb" src="<?php echo catch_first_image() ?>" width="121px" height="121px" alt="<?php the_title(); ?>"/>
		<?php } ?>
		</a></div>
  <?php endwhile;endif; ?>
  <?php wp_reset_query();?>

<div class="clear"></div>
</div>

<?php include('includes/r_comment.php'); ?>

<?php if (get_option('creekoo_r_links') == 'Display') { ?>
<?php include(TEMPLATEPATH . '/includes/r_links.php'); ?>
<?php } else {echo ''; } ?>

<div id="rollstart"></div>
</div></div>