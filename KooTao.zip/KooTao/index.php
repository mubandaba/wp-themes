<?php get_header(); ?>
<div id="content">
<div class="main">
  <?php if (have_posts()) : ?><?php while (have_posts()) : the_post(); ?>
 
      <div class="shopbox">
        <?php include('includes/articlepic.php'); ?>
        <h2><a href="<?php the_permalink() ?>" rel="bookmark" title="详细阅读：<?php the_title_attribute(); ?>"><?php the_title();?></a></h2>
        <div class="price">¥<?php echo get_post_meta($post->ID,"price_value",true);?></div>
        <a href="<?php echo get_post_meta($post->ID,"taobao_value",true);?>" rel="bookmark" title="淘宝购买<?php the_title_attribute(); ?>" target="_blank"><span class="buy">淘宝购买</span></a><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><span class="read">查看详情</span></a>
        <div class="clear"></div>
      </div>
  <?php endwhile; ?>
  <?php endif; ?>
  <div class="clear"></div>
  <div class="navigation">
    <?php pagination($query_string); ?>
  </div>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>