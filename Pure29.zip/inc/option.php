<?php
/*
	警告:切勿改动版本号信息,否则将导致主题保存内容被清空.
 */
$var = '0.0.1';
if(get_option('pure_setting_ver') != $var){
	update_option('pure_scoial','');
	update_option('pure_setting','');
	update_option('pure_setting_ver',$var);
	echo "<script>alert('提示：主题数据库表格格式发生不可逆变化,已经清理所有的旧内容!');</script>";
}

$pure_option = get_option('pure_setting');//获取选项   
if( $pure_option == '' ){
    $pure_option = '<::><::>转载请注出处:%web_title% » %post_title%<::>WordPress Theme designed by <a href="http://www.hoyt99.com">Hoyt99</a><::>Proudly published with <a href="https://wordpress.org">WordPress</a><::>0<::>1<::>0<::>0';
    $pure_scoial = '<::><::>';
    $pure_tools = '1<::>1<::>1<::>1';
    update_option('pure_tools', $pure_tools);
    update_option('pure_scoial',$pure_scoial);   
    update_option('pure_setting', $pure_option);//更新选项 
}

if(isset($_POST['option_save'])){   
    //处理数据
    $KeyWords = stripslashes($_POST['pure_kw']);
    $Description  =	stripslashes($_POST['pure_de']);
    $SiteCopy = stripslashes($_POST['pure_postcopy']);
    $footer1 = stripslashes($_POST['pure_footer1']);
    $footer2 = stripslashes($_POST['pure_footer2']);
    if($_POST['pure_thumbnail'] == 'show'){
    	$postimg = '1';
    }else{
    	$postimg = '0';
    }
    if($_POST['pure_related'] == 'show'){
    	$postrelated = '1';
    }else{
    	$postrelated = '0';
    }
    if($_POST['pure_textshow'] == 'show'){
    	$postshow = '1';
    }else{
    	$postshow = '0';
    }
    if($_POST['pure_modules'] == 'show'){
    	$mod = '1';
    }else{
    	$mod = '0';
    }

    if($_POST['pure_tool_hotpost'] == 'show'){
    	$tools .= '1<::>';
    }else{
    	$tools .= '0<::>';
    }
    if($_POST['pure_tool_hottags'] == 'show'){
    	$tools .= '1<::>';
    }else{
    	$tools .= '0<::>';
    }
    if($_POST['pure_tool_newcmd'] == 'show'){
    	$tools .= '1<::>';
    }else{
    	$tools .= '0<::>';
    }
    if($_POST['pure_tool_links'] == 'show'){
    	$tools .= '1';
    }else{
    	$tools .= '0';
    }
    $weibo = stripslashes($_POST['pure_weibo']);
    $qqt = stripslashes($_POST['pure_qqt']);
    $weixin = stripslashes($_POST['pure_weixin']);


    $option = $KeyWords.'<::>'.$Description.'<::>'.$SiteCopy.'<::>'.$footer1.'<::>'.$footer2.'<::>'.$postimg.'<::>'.$postrelated.'<::>'.$postshow.'<::>'.$mod;
    $scoial = $weibo.'<::>'.$qqt.'<::>'.$weixin;
    update_option('pure_tools', $tools);
    update_option('pure_scoial', $scoial);
    update_option('pure_setting', $option);//更新选项   
}   
?>
<?php
function pure_option(){
    add_menu_page( 'Pure主题设置', '主题设置', 'edit_themes', 'pure_setting','pure_page','',64);
}   
  
function pure_page(){
	$pure_option = get_option('pure_setting');
	$pure_arr = explode('<::>',$pure_option);
	$pure_scoial = get_option('pure_scoial');
	$pure_arr_scoial = explode('<::>',$pure_scoial);
	$pure_tools = get_option('pure_tools');
	$pure_arr_tools = explode('<::>',$pure_tools);
?>
	<style type="text/css">
		input{
			display: block;
			margin: 10px 0;
			max-width:800px;
			width: 99%;
		}
		label span{
			color: #999;
		}
		label{
			display: block;
			padding-bottom: 10px;
		}
	</style>
	<h1>欢迎您使用Pure主题</h1><span>该主题属于收费主题,正版用户有任何问题欢迎<a target="_blank" href="http://weibo.com/hoythan"/> @快叫我韩大人 </a>获取帮助</span><hr>

	<form method="post" name="pure_page_form" id="pure_page_form">   
		<h2>》站点优化</h2>
		<p>
		<label>网站关键词(KeyWords)：<span>关键词请使用英文逗号分隔，并应不超过100个字符长度.</span><input name="pure_kw" size="40" value="<?php echo $pure_arr[0]; ?>"/></label>
		<label>网站描述(Description)： <span>用一句话描述你的站点，最多不要超过200字符.</span><input name="pure_de" size="40" value="<?php echo $pure_arr[1]; ?>"/></label>
		<hr>
		</p>

		<h2>》网站模式</h2><p></p>
		<p>
		<label><input name="pure_modules" type="checkbox" size="40" value="show" <?php if($pure_arr[8] == '1'){echo 'checked';} ?>/>  是否启用博客2模式<span>不勾选[ 首页和分类页采用博客1模式 ]，勾选[ 采用模式2 ]</span></label>
		<hr>
		</p>

		<h2>》小工具选择<p>如果都不选择,文章页将采用无工具栏的宽屏模式</p></h2>
		<p>
		<label><input name="pure_tool_hotpost" type="checkbox" size="40" value="show" <?php if($pure_arr_tools[0] == '1'){echo 'checked';} ?>/>  是否显示热门文章</label>
		<label><input name="pure_tool_hottags" type="checkbox" size="40" value="show" <?php if($pure_arr_tools[1] == '1'){echo 'checked';} ?>/>  是否显示常用标签</label>
		<label><input name="pure_tool_newcmd" type="checkbox" size="40" value="show" <?php if($pure_arr_tools[2] == '1'){echo 'checked';} ?>/>  是否显示最新评论</label>
		<label><input name="pure_tool_links" type="checkbox" size="40" value="show" <?php if($pure_arr_tools[3] == '1'){echo 'checked';} ?>/>  是否显示友情链接</label>
		<hr>
		</p>

		<h2>》网站美化</h2>
		<p>
		<label><input name="pure_thumbnail" type="checkbox" size="40" value="show" <?php if($pure_arr[5] == '1'){echo 'checked';} ?>/>  是否从文章中获取缩略图<span>不勾选[ 如果文章没设置特色图像，分类页使用纯文字形式 ]，勾选[ 如果文章无特色图像，则取文章第一张图片作为缩略图 ]</span></label>
		<label><input name="pure_related" type="checkbox" size="40" value="show" <?php if($pure_arr[6] == '1'){echo 'checked';} ?>/>  是否显示相关文章<span>不勾选[ 隐藏文章底部相关文章 ]，勾选[ 显示文章底部相关文章 ]</span></label>
		<label><input name="pure_textshow" type="checkbox" size="40" value="show" <?php if($pure_arr[7] == '1'){echo 'checked';} ?>/>  是否显示分类页/首页特色图像下文字<span>不勾选[ 隐藏特色图像下的灰色阴影条和文字 ]，勾选[ 显示隐藏特色图像下的灰色阴影条和文字 ]</span></label>
		<hr>
		</p>

		<h2>》网站版权</h2>
		<p>
		<label>文章版权提示：<span>您可以在此处定义您的版权格式，你可以用到[ 网站名称 %web_title% / 文章标题 %post_title% ] 默认格式 [转载请注出处:%web_title% » %post_title%].</span><input name="pure_postcopy" size="40" value="<?php echo $pure_arr[2]; ?>"/></label>
		<hr>
		</p>

		<h2>》页脚信息</h2>
		<p>
		<h3>社交信息</h3>
		<label>新浪微博：<span>键入新浪微博的地址</span><input name='pure_weibo' size='40' value='<?php echo $pure_arr_scoial[0]; ?>'/></label>
		<label>腾讯微博：<span>键入腾讯微博的地址</span><input name='pure_qqt' size='40' value='<?php echo $pure_arr_scoial[1] ?>'/></label>
		<label>QQ微信：<span>键入微信的二维码图片地址(请先前往多媒体上传图片，并拷贝文件地址到此处.分辨率200px以上效果最佳)</span><input name='pure_weixin' size='40' value='<?php echo $pure_arr_scoial[2]; ?>'/></label>
		<h3>页脚内容</h3>
		<label>页脚第一行：<input name='pure_footer1' size='40' value='<?php echo $pure_arr[3]; ?>'/></label>
		<label>页脚第二行：<input name='pure_footer2' size='40' value='<?php echo $pure_arr[4]; ?>'/></label>
		<hr>
		</p>

		<p class="submit">   
        	<input class="sub" type="submit" name="option_save" value="保存设置" />   
    	</p>    
	</form>
<?php }
	add_action('admin_menu', 'pure_option'); 
?>