// console.log
//获取浏览器的可视区域高度 $(window).height();
//$("html,body").animate({scrollTop:winheight}, 1000); 
//当窗口载入的时候
$(window).ready(function(){
//隐藏点赞
	$('.archive .zan').hide();
//关于INFO的鼠标事件
	$('.archive .thumbnail .info').hide();
	var no_img = $('.archive .thumbnail');
	for (var i = 0; i < no_img.length; i++) {
		if($(no_img[i]).hasClass('no_img')){
			$(no_img[i]).children('.info').show();
		}
	};
	$('.archive .thumbnail').hover(function(){
		if(!$(this).hasClass('no_img')){
			$(this).children('.info').show();
		}
	},function(){
		if(!$(this).hasClass('no_img')){
			$(this).children('.info').hide();
		}
	});
//关于MIN_INFO的鼠标事件
	$('.archive .min_info .a').hide();
	$('.archive .min_info').hover(function(){
		$(this).children('.a').show();
		$(this).children('.b').hide();
	},function(){
		$(this).children('.b').show();
		$(this).children('.a').hide();
	});

});