// console.log
//菜单
$(window).ready(function Menus(){
	$('#leftbar').css('left',-$('#leftbar').width());
	$('#leftbar .min_nav').html($('#header .nav').html());
	$('#leftbar .min_nav .search').remove();
	$('#leftbar .min_nav .searchform').remove();
});
//菜单
var defaultScroll = 0,
	percentage = 0;
jQuery(window).scroll(function() {
    var windowH = $(window).height(),
    docHeight = (jQuery(document).height() - windowH),
    $windowObj = jQuery(this),
    st = $windowObj.scrollTop(),
    percentage = 0;
    if (st < defaultScroll && st > 200) {
    	$('#main').addClass('menus_height');
        $('#header').addClass('menus_up');
    } else {
        $('#header').removeClass('menus_up');
        $('#main').removeClass('menus_height');
    }
    defaultScroll = $windowObj.scrollTop();
    percentage = parseInt((defaultScroll / docHeight) * 6);
})
//滚动条滚动
var currTop = 0,
    sTop = 0;
	sTop = $(document).height() - $(window).height();
$(window).scroll(function(){
    currTop = $(window).scrollTop();
    if(currTop < $(window).height()*0.2){
    	$('.stop').css('right','-45px');
    }else{
		$('.stop').css('right','0px');
	}

    if(currTop < sTop * 0.2){
    	$('.stop a').html('<i class="fa fa-bicycle"></i>');
    }else if(currTop < sTop * 0.4){
    	$('.stop a').html('<i class="fa fa-car"></i>');
    }else if(currTop < sTop * 0.6){
    	$('.stop a').html('<i class="fa fa-train"></i>');
    }else if(currTop < sTop * 0.8){
    	$('.stop a').html('<i class="fa fa-fighter-jet"></i>');
    }else{
    	$('.stop a').html('<i class="fa fa-rocket"></i>');
	}
});
//点赞
$.fn.postLike = function() {
	if ($(this).parent('.zan').hasClass('likes')) {
		alert('您已经赞过啦,来试试评论下把?');
		return false;
	} else {
		$(this).parent('.zan').addClass('likes');
		$(this).children('span').html(parseInt($(this).children('span').html())+1+'+');
		var id = $(this).data("id"),
		action = $(this).data('action'),
		rateHolder = $(this).children('.count');
		var ajax_data = {
			action: "bigfa_like",
			um_id: id,
			um_action: action
		};
		$.post("/wp-admin/admin-ajax.php", ajax_data,
		function(data) {
			$(rateHolder).html(data);
		});
		return false;
	}
};
jQuery(document).on("click", ".favorite",function() {
	$(this).postLike();
});
//搜索框searchform
jQuery(document).on("click","#header .nav .search",function(){
	if($(this).next('.searchform').css('display') == 'none'){
		$(this).next('.searchform').css('display','block');
		$(this).next('.searchform').animate({top:64},200);
	}else{
		$(this).next('.searchform').css('display','none');
		$(this).next('.searchform').css('top','-64px');
	}
});
//图片切换点击
jQuery(document).on("click","#main .img_blog .switch a",function(){
	if($(this).children('i').hasClass('fa-toggle-off')){
		$(this).children('i').addClass('fa-toggle-on');
		$(this).children('i').removeClass('fa-toggle-off');
		//开关被打开
		$(this).parents('.thumbnail').children('.info').show();
		$(this).parents('.thumbnail').children('.info').css('opacity','1');
		$(this).parents('.thumbnail').children('.info').css('top','0');
		//信息块
		$(this).parents('.card').children('.min_info').children('.a').css('opacity','1');
		$(this).parents('.card').children('.min_info').children('.b').css('opacity','0');
	}else{
		$(this).children('i').addClass('fa-toggle-off');
		$(this).children('i').removeClass('fa-toggle-on');
		$(this).parents('.thumbnail').children('.info').hide();
		$(this).parents('.thumbnail').children('.info').css('opacity','');
		$(this).parents('.thumbnail').children('.info').css('top','');
		//信息块
		$(this).parents('.card').children('.min_info').children('.a').css('opacity','0');
		$(this).parents('.card').children('.min_info').children('.b').css('opacity','1');
	}
});
//文章页二维码点击
jQuery(document).on("click",".single .min_qrcode",function(){
	$('.single .qrcode').animate({right:0,top:0,opacity:1},200);
});
jQuery(document).on("click",".single .qrcode",function(){
	$('.single .qrcode').animate({right:-400,top:-400,opacity:0},100);
});

//表情
jQuery(document).on("click", ".add-smily",
function() {
        var myField;
        tag = ' ' + jQuery(this).data("smilies") + ' ';
        if (document.getElementById('comment') && document.getElementById('comment').type == 'textarea') {
            myField = document.getElementById('comment');
        } else {
            return false;
        }
        if (document.selection) {
            myField.focus();
            sel = document.selection.createRange();
            sel.text = tag;
            myField.focus();
        }
        else if (myField.selectionStart || myField.selectionStart == '0') {
            var startPos = myField.selectionStart;
            var endPos = myField.selectionEnd;
            var cursorPos = endPos;
            myField.value = myField.value.substring(0, startPos)
                          + tag
                          + myField.value.substring(endPos, myField.value.length);
            cursorPos += tag.length;
            myField.focus();
            myField.selectionStart = cursorPos;
            myField.selectionEnd = cursorPos;
        }
        else {
            myField.value += tag;
            myField.focus();
        }
    return false;
});

jQuery(document).on("click", ".leftbar_bg a",function() {
	delbar();
});

jQuery(document).on("click", ".menubtn a",function() {
	showbar();
});
function delbar(){
	$('#leftbar').animate({left:-$('#leftbar').width()},300);
	$('.leftbar_bg').css('display','none');
}
function showbar(){
	$('#leftbar').css('display','block');
	$('#leftbar').animate({left:0},300);
	$('.leftbar_bg').css('display','block');
}
//返回顶部按钮经过
$('.stop').hover(function(){
	$('.stop a').html('<i class="fa fa-chevron-up"></i>');
},function(){
    if(currTop < sTop * 0.2){
    	$('.stop a').html('<i class="fa fa-bicycle"></i>');
    }else if(currTop < sTop * 0.4){
    	$('.stop a').html('<i class="fa fa-car"></i>');
    }else if(currTop < sTop * 0.6){
    	$('.stop a').html('<i class="fa fa-train"></i>');
    }else if(currTop < sTop * 0.8){
    	$('.stop a').html('<i class="fa fa-fighter-jet"></i>');
    }else{
    	$('.stop a').html('<i class="fa fa-rocket"></i>');
    }
});
//返回顶部按钮点击
jQuery(document).on('click','.stop',function(){
	$('html, body').animate({scrollTop:0},500);
});
//评论框
jQuery(document).on('click', '#comment', function() {
	if($('.cmd_box')){
		$('.cmd_box').css('height','auto');
	}else{
		return false;
	}
});