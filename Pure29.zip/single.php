<?php get_header(); ?>
<div id="main" class="wth <?php echo showbar(); ?>">
<?php if(function_exists('breadcrumbs')) breadcrumbs();?>
  <div class="single wl boxbs">
	<div class="pad">
<?php while (have_posts()) : the_post(); ?>
<div class="qrcode"><img alt="本文二维码"src="http://qr.liantu.com/api.php?text=<?php echo get_the_permalink(); ?>"> </div>
<div class="min_qrcode"><img alt="扫一扫使用手机访问" src="<?php bloginfo('template_url'); ?>/images/qr.png" title="扫一扫使用手机访问"></div>
    <div class="title tit postbox"><h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1></div>
    <div class="post_meta postbox">
		<span class="time">发布于：<?php echo timeago( get_gmt_from_date(get_the_time('Y-m-d G:i:s')) ) ?></span>
		<span class="cat">所属分类：<a href="<?php $cat = get_the_category($post_id); echo get_category_link(get_cat_id($cat[0]->cat_name)); ?>"><?php $cat = get_the_category($post_id); echo $cat[0]->cat_name;?></a></span>
		<span class="cmd"><?php if ( comments_open() ) echo '<i class="fa fa-comments-o"></i> <a href="'.get_comments_link().'">'.get_comments_number('0', '1', '%').' 条评论</a>'; ?></span>
		<span class="like">
			<i class="fa fa-thumbs-o-up"></i>
			<div class="zan <?php if(isset($_COOKIE['bigfa_ding_'.$post->ID])) echo ' likes';?>">
				<a data-action="ding" data-id="<?php the_ID(); ?>" class="favorite" href="javascript:;" ><span><?php $like = get_post_meta($post->ID,'bigfa_ding',true);if($like >0){echo $like.' 人点赞';}else{echo '0';} ?></span></a>
			</div>
		</span>
		<span class="edit"><?php edit_post_link('[编辑文章]'); ?></span>
    </div>
<div class="post postbox">
<?php the_content(); ?>
<div class="copy">
<?php echo get_pure_setting('postcopy') ?>
</div>
</div>
<?php
if(get_the_tags('', ' , ' , '')) { ?>
<div class="foot_tool tags">
<i class="fa fa-tags"></i>
<?php the_tags('', ' , ' , ''); ?>
</div>
<?php } ?>
<?php endwhile; ?>
</div>
<!-- 信息块 -->
<div class="pad">
<!-- 
<div class="ctit"><span><i class="fa fa-share"></i>分享</span></div>
<div class="share">
</div>
-->
<?php if(get_pure_setting('related') == '1'){ ?>
<div class="ctit"><span><i class="fa fa-code-fork"></i>相关文章</span></div>
<div class="related">
	<ul class="related_img">
	<?php
	$post_num = 5;
	$exclude_id = $post->ID;
	$posttags = get_the_tags(); $i = 0;
	if ( $posttags ) {
		$tags = ''; foreach ( $posttags as $tag ) $tags .= $tag->term_id . ',';
		$args = array(
			'post_status' => 'publish',
			'tag__in' => explode(',', $tags),
			'post__not_in' => explode(',', $exclude_id),
			'caller_get_posts' => 1,
			'orderby' => 'comment_date',
			'posts_per_page' => $post_num
		);
		query_posts($args);
		while( have_posts() ) { the_post();?>
			<li class="related_box box<?php echo $i; ?>"  >
			<div class="r_pic">
			<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" target="_blank">
			<img src="<?php echo get_thumbnail_src(); ?>" alt="<?php the_title(); ?>" class="thumbnail" />
			</a>
			</div>
			<div class="r_title ashow"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" target="_blank" rel="bookmark"><?php the_title(); ?></a></div>
			</li>
		<?php
			$exclude_id .= ',' . $post->ID; $i ++;
		} wp_reset_query();
	}
	if ( $i < $post_num ) {
		$cats = ''; foreach ( get_the_category() as $cat ) $cats .= $cat->cat_ID . ',';
		$args = array(
			'category__in' => explode(',', $cats),
			'post__not_in' => explode(',', $exclude_id),
			'caller_get_posts' => 1,
			'orderby' => 'comment_date',
			'posts_per_page' => $post_num - $i
		);
		query_posts($args);
		while( have_posts() ) { the_post(); ?>
		<li class="related_box"  >
			<div class="r_pic">
			<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" target="_blank">
			<img src="<?php echo get_thumbnail_src(); ?>" alt="<?php the_title(); ?>" class="thumbnail" />
			</a>
			</div>
			<div class="r_title"><a href="<?php echo the_permalink(); ?>" title="<?php the_title(); ?>" target="_blank" rel="bookmark"><?php the_title(); ?></a></div>
		</li>
		<?php $i++;
		} wp_reset_query();
	}
	if ( $i  == 0 )  echo '<div class="r_title">没有相关文章!</div>';
	?>
	</ul>
</div>
<?php } ?>
<div class="comments">
  <?php comments_template(); ?>
</div>
</div>
<!-- 结束 -->
  </div>
 <?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>