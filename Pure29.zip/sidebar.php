<div class="sidebar wr">
<?php if(get_pure_setting('hotpost')) {?>
<div class="newpost boxbs ashow pad">
	<div class="title"><span><i class="fa fa-heartbeat"></i>热门文章</span></div>
	<div class="list">
		<ul>
<?php
$arr = hotpost();
for ($i=0; $i < count($arr)-1 ; $i++) { 
    $siteurl = get_site_url();
    $a = $i+1;
    echo'<li><div class="topnum timer"><span>'.$a.'</span></div><div class="postinfo"><h4><a href="'.$siteurl.'?p='.$arr[$i].'">'.get_post($arr[$i])->post_title.'</a></h4><p>'.get_post($arr[$i])->comment_count.' 条评论<i class="fa fa-angle-right"></i>'.get_post_meta($arr[$i],'bigfa_ding',true).'个赞<i class="fa fa-angle-right"></i>'.get_post_meta($arr[$i],'views',true).'次阅读</p></div></li>';
}
?>
		</ul>
	</div>
</div>
<?php }if(get_pure_setting('tags')){?>
<div class="tags boxbs pad">
	<div class="title"><span><i class="fa fa-tags"></i>常用标签</span></div>
	<div class="list">
	<?php wp_tag_cloud('smallest=12&largest=12&unit=px&number=20&orderby=count&order=DESC');?>
	</div>
</div>
<?php }if(get_pure_setting('cmd')){?>
<div class="commend boxbs pad">
	<div class="title"><span><i class="fa fa-heartbeat"></i>最新评论</span></div>
		<div class="list">
		<?php get_recent_comments(); ?>
		</div>
	</div>
<?php }if(get_pure_setting('links')){?>
<div class="link boxbs pad">
	<div class="title"><span><i class="fa fa-link"></i>友情链接</span></div>
	<div class="list">
		<?php wp_list_bookmarks('title_li=&categorize=0&before=<li class="ashow">'); ?>
	</div>
	<div class="clear"></div>
</div>
<?php }?>
</div>
