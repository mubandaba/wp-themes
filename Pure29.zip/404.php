<?php get_header(); ?>
<div id="main" class="wth pages">
<?php if(function_exists('breadcrumbs')) breadcrumbs();?>
  <div class="single wth boxbs">
	<div class="pad">
	<div class="nopage">
		<p>诶，找不到你要的东西呢。</p>
	</div>
	</div>
<div class="comments pad">
  <?php comments_template(); ?>
</div>
  </div>
</div>
<?php get_footer(); ?>