<?php   
    if (isset($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME']))   
        die ('Please do not load this page directly. Thanks!');   
?>
<style type="text/css">

</style>
   <div class="ctit"><span><i class="fa fa-comment-o"></i>文章评论 [<?php echo get_comments_number(); ?> 条]</span></div> 
   <ol class="commentlist">   
    <?php    
   if (!empty($post->post_password) && $_COOKIE['wp-postpass_' . COOKIEHASH] != $post->post_password) {    
       // if there's a password   
       // and it doesn't match the cookie   
   ?>   
   <li class="decmt-box">   
       <p><a href="#comment">请输入密码再查看评论内容.</a></p>   
   </li>   
   <?php    
       } else if ( !comments_open() ) {   
   ?>   
   <li class="decmt-box">   
       <p><a href="#comment">评论功能已经关闭!</a></p>   
   </li>   
   <?php    
       } else if ( !have_comments() ) {    
   ?>   
   <li class="decmt-box">   
       <p><a href="#comment">还没有任何评论，你来说两句吧</a></p>   
   </li>   
   <?php    
       } else {   
           wp_list_comments('type=comment&callback=aurelius_comment');   
       }   
   ?>  
   </ol>
<?php if ( 'open' == $post->comment_status ) : ?>

<div id="respond">

<div class="ctit"><span><i class="fa fa-pencil-square-o"></i>发布评论</span></div>

<?php cancel_comment_reply_link(); ?>

<?php if ( get_option( 'comment_registration' ) && !$user_ID ) : ?>

<p>You must be <a href="<?php echo wp_login_url( get_permalink() ); ?>">logged in</a> to post a comment.</p>

<?php else : ?>

<form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform">

<?php if ( $user_ID ) : ?>

<p>Hello , <a href="<?php echo get_option( 'siteurl' ); ?>/wp-admin/profile.php"><?php echo $user_identity; ?></a> 欢迎评论 . <a href="<?php echo wp_logout_url( get_permalink() ); ?>" title="Log out of this account">注销登录</a></p>

<?php else : ?>
<div class="cmd_box"><p>
<input placeholder="Name*" type="text" name="author" id="author" value="<?php echo $comment_author; ?>" size="22" tabindex="1" <?php if ($req) echo "aria-required='true'"; ?> />
<label for="author"><?php if(is_ie8_page()){echo '昵称（必填）';} ?></label>
</p>
<p>
<input placeholder="E-mail*" type="text" name="email" id="email" value="<?php echo $comment_author_email; ?>" size="22" tabindex="2" <?php if ($req) echo "aria-required='true'"; ?> />
<label for="email"><?php if(is_ie8_page()){ echo '邮箱（必填）';}?></label>
</p>
<p>
<input placeholder="Site Url" type="text" name="url" id="url" value="<?php echo $comment_author_url; ?>" size="22" tabindex="3" />
<label for="url"><?php if(is_ie8_page()){ echo '站点';}?></label>
</p></div>
<?php endif; ?>
<p><textarea name="comment" id="comment" cols="100%" rows="10" tabindex="4"></textarea></p>
<?php echo fa_get_wpsmiliestrans();?>

<p><input class="sub" name="submit" type="submit" id="submit" tabindex="5" value="发表评论" /></p>
<?php do_action( 'comment_form', $post->ID ); comment_id_fields(); ?>

</form>

<?php endif; // If registration required and not logged in ?>
</div>

<?php endif; // If comments are open: delete this and the sky will fall on your head ?>