<?php get_header(); ?>
<div id="main" class="wth">
	<div class="img_blog">
		<ul>
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		    <li>
		      <?php
		      if(get_pure_setting('blog2')){
		      	include 'modules/blog2.php';
		      }else{
		      	include 'modules/blog.php';
		      }
		      ?>
		    </li>
		<?php endwhile; ?>
		<?php endif; ?> 
		</ul>
	</div>
</div>
<?php portfolio_paging_nav(); get_footer(); ?>