<!doctype html>
<html class="no-js">
<head>
  <meta charset="utf-8">
  <meta property="wb:webmaster" content="aa7c88303e74b8e2" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="description" content="<?php echo get_pure_setting('de') ?>">
  <meta name="keywords" content="<?php echo get_pure_setting('kw') ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  <title>
  <?php
  if ( is_home() ) {
  bloginfo('name'); echo " | "; bloginfo('description');
  }elseif ( is_category() ) {
    single_cat_title(); echo " | "; bloginfo('name');
  }elseif (is_single() || is_page() ) {
    single_post_title();echo " - "; echotag();echo " | ";bloginfo('name');
  }elseif (is_search() ) {
    echo "搜索结果"; echo " | "; bloginfo('name');
  }elseif (is_404() ) {
    echo '页面未找到!';
  }else{
    wp_title('',true);
  }
  ?>
  </title>
  <!-- 360内核浏览器访问 -->
  <meta name="renderer" content="webkit">
  <!-- 拒绝百度手机转码 -->
  <meta http-equiv="Cache-Control" content="no-siteapp"/>
  <!-- 加载CSS样式 -->
  <link rel="apple-touch-icon" href="<?php bloginfo('template_url'); ?>/images/favicon.ico">
  <link rel="icon" href="<?php bloginfo('template_url'); ?>/images/favicon.ico"  type="image/x-icon" />
  <link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_url'); ?>">
  <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/css/font-awesome.min.css">
  <?php echo is_ie8(); ?>
  <?php wp_head(); ?>
</head>
<body <?php if(wp_is_mobile()){echo 'class="moblie"';}else{echo 'class="pc"';}?> >
<div id="header">
  <div class="wth">
    <div class="logo <?php if(is_home() || is_page()){echo 'nosp';} ?>">
      <a href="<?php bloginfo('url'); ?>"><img src="<?php bloginfo('template_url'); ?>/images/logo.jpg"></a>
    </div>
    <div class="menubtn"><a href="javascript:;"><i class="fa fa-bars"></i></a></div>
    <div class="nav">
      <ul>
        <?php wp_nav_menu( array('container' => false, 'items_wrap' => '%3$s', 'theme_location' => 'Menus') ); ?>
        <!-- 搜索 -->
        <li class="search">
          <i class="fa fa-search"></i>
        </li>
        <div class="searchform">
          <form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
              <div>
                  <input value="输入内容并按回车键" type="text" value="" name="s" id="s" onblur="if(this.value=='')this.value='输入内容并按回车键';" onfocus="if(this.value=='输入内容并按回车键')this.value='';" x-webkit-speech="" />
              </div>
          </form>         
        </div>
      </ul>
    </div>
  </div>
</div>
<!-- 侧边栏内容 -->
<div id="leftbar">
  <div class="min_nav">

  </div>
</div>
<div class="leftbar_bg"><a href="javascript:;"></a></div>