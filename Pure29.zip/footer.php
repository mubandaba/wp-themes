<div id="footer">
  <div class="wth">
    <div class="ico">
<?php
$weibo = get_pure_setting('weibo');
$qqt = get_pure_setting('qqt');
$weixin = get_pure_setting('weixin');
if($weibo)echo '<a href="'.$weibo.'"  target="_blank"><i class="fa fa-weibo"></i></i></a>';
if($qqt)echo '<a href="'.$qqt.'"  target="_blank"><i class="fa fa-tencent-weibo"></i></a>';
if($weixin)echo '<a class="weixin" herf="javascript:;"><i class="fa fa-weixin"></i><div class="weixin_qrcode"><img src="'.$weixin.'" class="qrcode" width="200" height="200" alt="weixin_qrcode"></div></a>';
?>
    </div>
    <p><?php echo get_pure_setting('footer1'); ?></p>
    <p><?php echo get_pure_setting('footer2'); ?></p>
  </div>
</div>
<div class="stop"><a href="javascript:;"><i class="fa fa-chevron-up"></i></a></div>
 <!-- JavaSrcipt-->
 <script src="<?php bloginfo('template_url'); ?>/js/jquery.min.js"></script>
 <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/main.js"></script>
<?php wp_footer(); ?>
</body>
</html>