<div class="row <?php if(post_thumbnail_src() =='no_img'){ echo 'no_img';}?>">
    <div class="postimg" style="background-image: url('<?php echo get_bloginfo("template_url") ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=478&w=720&q=90&zc=1&ct=1');">
		<div class="zan <?php if(isset($_COOKIE['bigfa_ding_'.$post->ID])) echo ' likes';?>">
			<a data-action="ding" data-id="<?php the_ID(); ?>" class="favorite" href="javascript:;" ><i class="fa fa-thumbs-o-up"></i><span><?php $like = get_post_meta($post->ID,'bigfa_ding',true);if($like >0){echo $like.' 人点赞';}else{echo '0';} ?></span></a>
			<span class="tip">( 已赞 )</span>
		</div>
		<div class="black"></div>

    </div>
	<div class="post">
	<div class="show">
	<a target="_blank" href="<?php the_permalink() ?>">
		<h1><?php the_title(); ?></h1>
	</a>
		<p><?php $post_describe = get_post_meta($post->ID,'post_describe',true);if(!$post_describe){echo strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 80, '...');}else{echo $post_describe;} ?></p>
	</div>
	</div>
	<div class="info">
		<div class="left ashow"><span><a href="<?php $cat = get_the_category($post_id); echo get_category_link(get_cat_id($cat[0]->cat_name)); ?>"><?php $cat = get_the_category($post_id); echo $cat[0]->cat_name;?></a></span></div>
		<div class="right"><span><i class="fa fa-eye"></i><?php if(function_exists('the_views')) { the_views(); } ?> 次浏览<i class="fa fa-comment-o"></i><?php echo get_comments_number(); ?> 条评论</span></div>
	</div>
</div>