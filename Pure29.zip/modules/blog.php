<a class="btn" target="_blank" href="<?php the_permalink() ?>"></a>
<div class="card">
    <?php if(post_thumbnail_src()!='no_img'){?>
    <div class="thumbnail" style="background-image: url('<?php echo get_bloginfo("template_url") ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=478&w=720&q=90&zc=1&ct=1');">
    <?php if(get_pure_setting('textshow') == '1'){ ?>
    <div class="titleshow"><?php the_title(); ?></div>
    <?php }?>
    <?php }else{?>
    <div class="thumbnail no_img">
    <?php } ?>
    <?php if(wp_is_mobile()){echo'<div class="switch"><a href="javascript:;"><i class="fa fa-toggle-off"></i></a></div>';} ?>
    <div class="info lrtb">
    <a target="_blank" href="<?php the_permalink() ?>">
      <h2><?php the_title(); ?></h2>
      <p><?php $post_describe = get_post_meta($post->ID,'post_describe',true);if(!$post_describe){echo strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 80, '...');}else{echo $post_describe;} ?></p>
    </a>
    <div class="zan <?php if(isset($_COOKIE['bigfa_ding_'.$post->ID])) echo ' likes';?>">
      <a data-action="ding" data-id="<?php the_ID(); ?>" class="favorite" href="javascript:;" ><span><?php $like = get_post_meta($post->ID,'bigfa_ding',true);if($like >0){echo $like.'+';}else{echo '0';} ?></span><i class="fa fa-thumbs-o-up"></i></a></div>
    </div>
  </div>
  <div class="min_info lrtb">
    <div class="a"><span><i class="fa fa-eye"></i><?php if(function_exists('the_views')) { the_views(); } ?> 次浏览<i class="fa fa-comment-o"></i><?php echo get_comments_number(); ?> 条评论</span></div>
    <div class="b"><span><i class="fa fa-folder-open-o"></i><?php $cat = get_the_category($post_id); echo $cat[0]->cat_name;?></span><i class="fa fa-clock-o"></i><?php echo timeago( get_gmt_from_date(get_the_time('Y-m-d G:i:s')) ) ?></div>
  </div>
</div>