<?php
/* Template Name: 普通页面 */
get_header(); ?>
<div id="main" class="wth pages">
<?php if(function_exists('breadcrumbs')) breadcrumbs();?>
  <div class="single wth boxbs">
	<div class="pad">
<?php while (have_posts()) : the_post(); ?>
<div class="qrcode"><img alt="本文二维码"src="http://qr.liantu.com/api.php?text=<?php echo get_the_permalink(); ?>"> </div>
<div class="min_qrcode"><img alt="扫一扫使用手机访问" src="<?php bloginfo('template_url'); ?>/images/qr.png" title="扫一扫使用手机访问"></div>
    <div class="title tit postbox"><h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1></div>
    <div class="post_meta postbox">
      <span class="time">发布于：<?php echo timeago( get_gmt_from_date(get_the_time('Y-m-d G:i:s')) ) ?></span>
    </div>
<div class="post postbox">
<?php the_content(); ?>
</div>
<?php
if(get_the_tags('', ' , ' , '')) { ?>
<div class="tags">
<i class="fa fa-tags"></i>
<?php the_tags('', ' , ' , ''); ?>
</div>
<?php } ?>

<?php endwhile; ?>
	</div>
<div class="comments pad">
  <?php comments_template(); ?>
</div>
  </div>
</div>
<?php get_footer(); ?>