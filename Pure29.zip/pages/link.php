<?php
/* Template Name: 友情链接 */
get_header(); ?>
<div id="main" class="wth pages">
<?php if(function_exists('breadcrumbs')) breadcrumbs();?>
  <div class="single wth boxbs">
	<div class="pad">
<?php echo get_link_items(); ?>
	</div>
<div class="comments pad">
  <?php comments_template(); ?>
</div>
  </div>
</div>
<?php get_footer(); ?>