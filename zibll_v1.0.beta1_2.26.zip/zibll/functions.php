<?php
// Require theme functions
require get_stylesheet_directory() . '/functions-theme.php';

// 在下方加入您的自定义functions
// 升级主题请自行备份以下内容
