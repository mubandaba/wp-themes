<?php
if ( 'POST' != $_SERVER['REQUEST_METHOD'] ) {
	header('Allow: POST');
	header('HTTP/1.1 405 Method Not Allowed');
    header('Content-Type: text/plain');
    echo '错误请求';
	exit;
}

require( dirname(__FILE__).'/../../../../wp-load.php' );

function err($ErrMsg) {
    header('HTTP/1.1 405 Method Not Allowed');
    echo $ErrMsg;
    exit;
}

$comment = wp_handle_comment_submission( wp_unslash( $_POST ) );
        if ( is_wp_error( $comment ) ) {
            $data = $comment->get_error_data();
            if ( ! empty( $data ) ) {
            	err($comment->get_error_message());
            } else {
                exit;
            }
        }
$user = wp_get_current_user();
do_action('set_comment_cookies', $comment, $user);

zib_get_comments_list($comment);

exit;
?>
