
//文章Ajax加载
(Number(_win.ajaxpager) > 0 && $(".ajaxpager .posts-item").length && $(".ajaxpager .next-page").length ) && post_ias();

function post_ias() {
    spinner = '.ajax-loading';
    item = ".ajax-item";
    next = ".next-page a";
    pagination = '.pagination';
    over = '<div class="muted-3-color">-----------  已加载全部内容  -----------</div>';

tbquire([ "ias" ], function() {
    var index_ias = new InfiniteAjaxScroll('.ajaxpager', {
        item: item,
        next: next,
        spinner: spinner,
        loadOnScroll: false,
        pagination:pagination,
      });
      index_ias.on('appended', () => {
        show_svg();
      });
      index_ias.on('last', () => {
        $(spinner).html(over).css('opacity',1);
      });
      $(next).on('click', () => {
        return index_ias.next(),!1;
      });
});

}
