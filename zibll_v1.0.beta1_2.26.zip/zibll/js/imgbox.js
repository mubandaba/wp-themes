$("link#swiper").length || $("head").append('<link type="text/css" id="swiper" rel="stylesheet" href="' + _win.uri + '/css/swiper.css">');
close = '';
/*	close +='<i class="icon-close"><i class="fa fa-play-circle-o" aria-hidden="true"></i></i>';
	close +='<i class="icon-close"><i class="fa fa-search-minus" aria-hidden="true"></i></i>';
	close +='<i class="icon-close"><i class="fa fa-search" aria-hidden="true"></i></i>';  */
close += '<i class="icon-close"><i data-svg="close" data-class="ic-close" data-viewbox="0 0 1024 1024"></i></i>';

beijin = '<div class="modal-backdrop imgbox-bg"></div>';
anniu = '<div class="imgbox-an">' + close + '</div>';
imgbox = '<div class="imgbox">' + beijin + anniu + '</div>';

_win.bd.append(imgbox);

var _i = $(".imgbox"),
	_img = _i.find(".swiper-slide img");
$('.imgbox-bg,.imgbox-an .icon-close').on('click', function () {
	imgbox_close()
});

function imgbox_close() {
	$("html,body").css("overflow", ""), _i.removeClass("show"), _img.css({
		transform: ""
	});
	$('.swiper-imgbox.comt-imgbox').remove();
}

function imgbox_touch() {
	var _igb = _i.find(".swiper-close");
	_igb.on("touchstart", function (n) {
		startX = n.originalEvent.changedTouches[0].pageX, startY = n.originalEvent.changedTouches[0].pageY;
	}).on("touchmove", function (n) {
		endX = n.originalEvent.changedTouches[0].pageX, endY = n.originalEvent.changedTouches[0].pageY,
			distanceX = endX - startX, distanceY = endY - startY, angle = 180 * Math.atan2(distanceY, distanceX) / Math.PI,
			scale = 1.1 - distanceY / 600,
			translateY = "translateY(" + distanceY + "px) scale(" + (scale < 1 ? scale : '1') + ")", opacity = 1.4 - distanceY / 150,
			angle > 60 && angle < 120 && $(this).css({
				transition: "none",
				"-webkit-transition": "none",
				"-o-transition": "none",
				opacity: opacity,
				transform: translateY
			});
	}).on("touchend", function (n) {
		distanceY && (distanceY > 100 && imgbox_close(), $(this).css({
			transition: "",
			"-webkit-transition": "",
			"-o-transition": "",
			opacity: "",
			transform: ""
		})), distanceX = 0;
	});
	return false;
}

function imgbox_open(e, b, c) {
	tbquire(['swiper'], function () {
		var _a = $(e),
			length = _a.length,
			index = 0,
			b = b || 'swiper-imgbox',
			tupian = '';

		_a.each(function () {
			link = $(this).attr("href") || $(this).attr("src");
			src = $(this).find('img').attr("src");
			link2 = link;
			src == link && (link2 = link.replace(/(.*\/)(.*)(-\d+x\d+)(.*)/g, "$1$2$4"));
			index += 1;
			$(this).attr("imgbox-index", index);
			tupian += '<div class="swiper-slide"><div class="swiper-close"><div class="swiper-zoom-container"><img data-src="' + link2 + '" class="swiper-lazy"><div class="swiper-lazy-preloader"></div></div></div></div>';
		});

		wrapper = '<div class="swiper-wrapper">' + tupian + '</div>';
		swiper = '<div class="' + b + '">' + wrapper + '<div class="swiper-pagination"></div><div class="swiper-button-prev"></div><div class="swiper-button-next"></div></div>';
		_i.append(swiper);

		var imgbox_S = new Swiper("." + b, {
			grabCursor: !0,
			init: !1,
			lazy: {
				loadPrevNext: !0
			},
			navigation: {
				nextEl: ".swiper-button-next",
				prevEl: ".swiper-button-prev"
			},
			pagination: {
				el: ".swiper-pagination",
				clickable: !0
			},
			zoom: {
				maxRatio: 2,
			},
			keyboard: {
				enabled: !0,
				onlyInViewport: !1
			},
			spaceBetween: 20,
			on: {
				zoomChange: function (i, e, n) {
					i > 1 ? _i.addClass("scale") : _i.removeClass("scale");
				}
			}
		});

		_a.on("click", function () {
			$('.swiper-imgbox').css('display', '');
			return inx = $(this).attr("imgbox-index"), $("html,body").css("overflow", "hidden"),
				$(".modal").modal("hide"), imgbox_S.init(), imgbox_S.slideToLoop(inx - 1, 10), _i.addClass("show"),
				startY = endX = endY = distanceY = 0, !1,
				imgbox_touch();
		});

		$('.imgbox-an .icon-play').click(function () {
			imgbox_S.autoplay.start()
		});
		_i.on('touchmove', function (e) {
			e.preventDefault()
		});
	})
}

function click_imgbox(e) {
	$('body').on('click', e, function () {
		$('.swiper-imgbox').css('display', 'none');
		link = $(this).attr("href") || $(this).attr("src");
		tupian = '<div class="swiper-slide"><div class="swiper-close"><div class="swiper-zoom-container"><img src="' + link + '"></div></div></div>';
		wrapper = '<div class="swiper-wrapper">' + tupian + '</div>';
		swiper = '<div class="swiper-imgbox comt-imgbox">' + wrapper + '</div>';
		_i.append(swiper).addClass("show");
		imgbox_touch();
		startY = endX = endY = distanceY = 0, !1;
		$("html,body").css("overflow", "hidden");
		return !1;
	});
}
imgbox_open('a[data-imgbox="imgbox"]', 'swiper-imgbox');
click_imgbox('.comt-main .box-img');
click_imgbox('.article-content img');
auto_fun();