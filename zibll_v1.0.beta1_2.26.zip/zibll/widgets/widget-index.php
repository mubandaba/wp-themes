<?php
add_action('widgets_init', 'unregister_d_widget');

function unregister_d_widget()
{
	unregister_widget('WP_Widget_Search');
	unregister_widget('WP_Widget_Recent_Comments');
}

$widgets = array(
	'more',
);

foreach ($widgets as $widget) {
	include 'widget-' . $widget . '.php';
}

// 注册小工具
if (function_exists('register_sidebar')) {
	$sidebars = array();
	$pags = array(
		'home' => '首页',
		'single' => '文章页',
		'cat' => '分类页',
		'tag' => '标签页',
		'search' => '搜索页',
		'author' => '用户页',
	);

	$poss = array(
		'top_fluid' => '顶部全宽度',
		'top_content' => '主内容上面',
		'bottom_content' => '主内容下面',
		'bottom_fluid' => '底部全宽度',
		'sidebar' => '侧边栏',
	);

	foreach ($pags as $key => $value) {
		foreach ($poss as $poss_key => $poss_value) {

			$sidebars[] = array(
				'name'          => $value . '-' . $poss_value,
				'id'            => $key . '_' . $poss_key,
				'description'   => '显示在 ' . $value . ' 的 ' . $poss_value . ' 位置，由于位置较多，建议使用实时预览管理！',
			);
		}
	}

	$sidebars[] = array(
		'name'          => '页面最底部页脚区域',
		'id'            => 'all_footer',
		'description'   => '显示最底部页脚区域内部，由于位置较多，建议使用实时预览管理！',
	);
	$sidebars[] = array(
		'name'          => '所有页面-侧边栏-顶部位置',
		'id'            => 'all_sidebar_top',
		'description'   => '显示在所有侧边栏的最上面位置，由于位置较多，建议使用实时预览管理！',
	);

	$sidebars[] = array(
		'name'          => '所有页面-侧边栏-底部位置',
		'id'            => 'all_sidebar_bottom',
		'description'   => '显示在所有侧边栏的最下面，由于位置较多，建议使用实时预览管理！',
	);

	$sidebars[] = array(
		'name'          => '页面最底部页脚区域',
		'id'            => 'all_footer',
		'description'   => '显示最底部页脚区域内部，由于位置较多，建议使用实时预览管理！',
	);

	foreach ($sidebars as $value) {
		register_sidebar(array(
			'name' => $value['name'],
			'id' => $value['id'],
			'description' => $value['description'],
			'before_widget' => '<div class="zib-widget %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h3>',
			'after_title' => '</h3>'
		));
	};
}
