<?php

add_action( 'widgets_init', 'widget_register' );
function widget_register() {
	register_widget( 'widget_ui_yiyan' );
	register_widget( 'widget_ui_mian_posts' );
	register_widget( 'widget_ui_tab_posts' );
	register_widget( 'widget_ui_avatar' );
	register_widget( 'widget_ui_posts_navs' );
	register_widget( 'widget_ui_user' );
	register_widget( 'widget_ui_mini_posts' );
}










class widget_ui_mini_posts extends WP_Widget
{
	function __construct()
	{
		$widget   = array(
			'w_id'     =>  'widget_ui_mini_posts',
			'w_name'     =>  _name('mini文章板块'),
			'classname'     => '',
			'description'       => '尺寸更小的文章列表，推荐设置在侧边栏，如果要设置在非侧边栏位置，请打开显示缩略图',
		);
		parent::__construct($widget['w_id'],$widget['w_name'], $widget);
	}
	function widget($args, $instance)
	{
		extract($args);

		$defaults = array(
			'title' => '',
			'mini_title' => '',
			'limit' => 6,
			'cat' => '',
			'orderby' => 'views'
		);

		$instance = wp_parse_args((array) $instance, $defaults);
		$orderby = $instance['orderby'];

		$mini_title = $instance['mini_title'];
		if($mini_title){
			$mini_title = '<small class="ml10">'.$mini_title.'</small>';
		}
		$title = $instance['title'];
		$class = '';

		if($title){
			$title = '<div class="box-body notop'.$class.'"><div class="title-theme">'.$title.$mini_title.'</div></div>';
		}

		echo '<div class="theme-box">';
		echo $title;
	//	echo '<pre>'.json_encode($instance).'</pre>';

		$args = array(
			'cat' => $instance['cat'],
			'order' => 'DESC',
			'showposts' => $instance['limit'],
			'ignore_sticky_posts' => 1
		);

		if ($orderby !== 'views') {
			$args['orderby'] = $orderby;
		} else {
			$args['orderby'] = 'meta_value_num';
			$args['meta_query'] = array(
				array(
					'key' => 'views',
					'order' => 'DESC'
				)
			);
		}
		$list_args = array(
			'show_thumb' => isset($instance['show_thumb']) ? true : false,
		);
		echo '<div class="box-body posts-mini-lists zib-widget">';
		$the_query = new WP_Query( $args );
		zib_posts_mini_list($list_args,$the_query);
		echo '</div>';
		echo '</div>';
	}
	function form($instance)
	{
		$defaults = array(
			'title' => '',
			'mini_title' => '',
			'show_thumb' => true,
			'limit' => 6,
			'cat' => '',
			'orderby' => 'views'
		);
		$instance = wp_parse_args((array) $instance, $defaults);
		?>
		<p>
			<label>
				标题：
			<input style="width:100%;" id="<?php echo $this->get_field_id('title');
				?>" name="<?php echo $this->get_field_name('title');
				?>" type="text" value="<?php echo $instance['title'];
				?>" />
			</label>
		</p>
		<p>
			<label>
				副标题：
			<input style="width:100%;" id="<?php echo $this->get_field_id('mini_title');
				?>" name="<?php echo $this->get_field_name('mini_title');
				?>" type="text" value="<?php echo $instance['mini_title'];
				?>" />
			</label>
		</p>
		<p>
			<label>
				<input style="vertical-align:-3px;margin-right:4px;" class="checkbox" type="checkbox" <?php checked( $instance['show_thumb'], 'on' ); ?> id="<?php echo $this->get_field_id('show_thumb'); ?>" name="<?php echo $this->get_field_name('show_thumb'); ?>">显示缩略图
			</label>
		</p>
		<p>
			<label>
				分类限制：
				<a style="font-weight:bold;color:#f60;text-decoration:none;" href="javascript:;" title="格式：1,2&nbsp;表限制ID为1,2分类的文章&#13;格式：-1,-2 &nbsp;表排除分类ID为1,2的文章&#13;也可直接写1或者-1；注意逗号须是英文的">？</a>
				<input style="width:100%;" id="<?php echo $this->get_field_id('cat');
				?>" name="<?php echo $this->get_field_name('cat');
				?>" type="text" value="<?php echo $instance['cat'];
				?>" size="24" />
			</label>
		</p>
		<p>
			<label>
				显示数目：
				<input style="width:100%;" id="<?php echo $this->get_field_id('limit');
				?>" name="<?php echo $this->get_field_name('limit');
				?>" type="number" value="<?php echo $instance['limit'];
				?>" size="24" />
			</label>
		</p>
		<p>
			<label>
				排序：
				<select style="width:100%;" id="<?php echo $this->get_field_id('orderby');
					?>" name="<?php echo $this->get_field_name('orderby');
					?>">
					<option value="comment_count" <?php selected('comment_count', $instance['orderby']);
						?>>评论数</option>
					<option value="views" <?php selected('views', $instance['orderby']);
						?>>浏览量</option>
					<option value="date" <?php selected('date', $instance['orderby']);
						?>>发布时间</option>
					<option value="modified" <?php selected('modified', $instance['orderby']);
						?>>更新时间</option>
					<option value="rand" <?php selected('rand', $instance['orderby']);
						?>>随机排序</option>
				</select>
			</label>
		</p>
			<?php
	}
}






/////用户信息---//用户信息---//用户信息---//用户信息---//用户信息------

class widget_ui_user extends WP_Widget
{
	function __construct()
	{
		$widget   = array(
			'w_id'     =>  'widget_ui_user',
			'w_name'     =>  _name('个人信息模块'),
			'classname'     => '',
			'description'       => '未登录时候显示登录注册按钮，登录后显示用户的个人信息',
		);
		parent::__construct($widget['w_id'],$widget['w_name'], $widget);
	}
	function widget($args, $instance)
	{
		extract($args);

		$defaults = array(
			'title' => '',
			'mini_title' => '',
			'loged_title' => 'Hi！请登录',
		);

		$instance = wp_parse_args((array) $instance, $defaults);

		$mini_title = $instance['mini_title'];
		if($mini_title){
			$mini_title = '<small class="ml10">'.$mini_title.'</small>';
		}
		$title = $instance['title'];

		if($title){
			$title = '<div class="box-body notop"><div class="title-theme">'.$title.$mini_title.'</div></div>';
		}

		echo '<div class="theme-box">';
		echo $title;
		zib_posts_user_box($instance['loged_title']);
		echo '</div>';
	}

	function form($instance)
	{
		$defaults = array(
			'title' => '',
			'mini_title' => '',
			'loged_title' => 'HI！请登录',
		);

		$instance = wp_parse_args((array) $instance, $defaults);
		?>
		<p>
		<i style="width:100%;color:#f60;">此模块与作者信息模块较为相似，如果站点开启了个人中心功能建议优先添加此模块到所有侧边栏顶部</i>
		</p>

		<p>
			<label>
				标题：
			<input style="width:100%;" id="<?php echo $this->get_field_id('title');
				?>" name="<?php echo $this->get_field_name('title');
				?>" type="text" value="<?php echo $instance['title'];
				?>" />
			</label>
		</p>
		<p>
			<label>
				副标题：
			<input style="width:100%;" id="<?php echo $this->get_field_id('mini_title');
				?>" name="<?php echo $this->get_field_name('mini_title');
				?>" type="text" value="<?php echo $instance['mini_title'];
				?>" />
			</label>
		</p>
		<p>
			<label>
				登录文案：
			<input style="width:100%;" id="<?php echo $this->get_field_id('loged_title');
				?>" name="<?php echo $this->get_field_name('loged_title');
				?>" type="text" value="<?php echo $instance['loged_title'];
				?>" />
			</label>
		</p>
		<?php
	}
}


class widget_ui_posts_navs extends WP_Widget
{
	function __construct()
	{
		$widget   = array(
			'w_id'     =>  'widget_ui_posts_navs',
			'w_name'     =>  _name('文章目录树'),
			'classname'     => '',
			'description'       => '显示文章的目录树，非文章页则不显示内容',
		);
		parent::__construct($widget['w_id'],$widget['w_name'], $widget);
	}

	function widget($args, $instance)
	{
		extract($args);
		$defaults = array(
			'title' => '',
			'mini_title' => '',
		);
		$instance = wp_parse_args((array) $instance, $defaults);
		$mini_title = $instance['mini_title'];
		if($mini_title){
			$mini_title = '<small class="ml10">'.$mini_title.'</small>';
		}
		$title = esc_html( $instance['title'] ).esc_html($mini_title);
		if($title){
			$title = ' data-title="'.$title.'"';
		}

		echo '<div class="posts-nav-box"'.$title.'></div>';
	}

	function form($instance)
	{
		$defaults = array(
			'title' => '文章目录',
			'mini_title' => '',
		);
		$instance = wp_parse_args((array) $instance, $defaults);

		?>
		<p>
			<label>
				<i style="width:100%;color:#f80;">显示文章的目录，添加在非文章页则不会显示任何内容。在实时预览添加此模块时，请注意查看是否在文章页</i>
			</label>
		</p>
		<p>
			<label>
				标题：
			<input style="width:100%;" id="<?php echo $this->get_field_id('title');
				?>" name="<?php echo $this->get_field_name('title');
				?>" type="text" value="<?php echo $instance['title'];
				?>" />
			</label>
		</p>
		<p>
			<label>
				副标题：
			<input style="width:100%;" id="<?php echo $this->get_field_id('mini_title');
				?>" name="<?php echo $this->get_field_name('mini_title');
				?>" type="text" value="<?php echo $instance['mini_title'];
				?>" />
			</label>
		</p>
	<?php
		}
}


/////----- //一言//------ //一言//------ //一言//------ //一言//------ //一言//----
/////----- //一言//------ //一言//------ //一言//------ //一言//------ //一言//----
/////----- //一言//------ //一言//------ //一言//------ //一言//------ //一言//----
/////----- //一言//------ //一言//------ //一言//------ //一言//------ //一言//----
class widget_ui_yiyan extends WP_Widget
{
	function __construct()
	{
		$widget   = array(
			'w_id'     =>  'widget_ui_yiyan',
			'w_name'     =>  _name('一言'),
			'classname'     => 'yiyan-box main-bg theme-box text-center box-body radius8 main-shadow',
			'description'       => '这是一个显示一言的小工具，每次页面刷新或者每隔30秒会自动更新内容',
		);
		parent::__construct($widget['w_id'],$widget['w_name'], $widget);
	}

	function widget($args, $instance)
	{
		extract($args);
		$defaults = array(
			'title' => '',
			'mini_title' => '',
		);

		$instance = wp_parse_args((array) $instance, $defaults);
		$mini_title = $instance['mini_title'];
		if($mini_title){
			$mini_title = '<small class="ml10">'.$mini_title.'</small>';
		}
		$title = $instance['title'];
		if($title){
			$title = '<div class="box-body notop"><div class="title-theme">'.$title.$mini_title.'</div></div>';
		}

		echo '<div class="theme-box">';
		echo $title;
		echo '<div class="yiyan-box main-bg text-center box-body radius8 main-shadow">';
		echo '<div class="yiyan"></div>';
		echo '</div>';
		echo '</div>';
	}
	function form($instance)
	{
		$defaults = array(
			'title' => '',
			'mini_title' => '',
		);
		$instance = wp_parse_args((array) $instance, $defaults);

		?>
		<p>
			<label>
				标题：
			<input style="width:100%;" id="<?php echo $this->get_field_id('title');
				?>" name="<?php echo $this->get_field_name('title');
				?>" type="text" value="<?php echo $instance['title'];
				?>" />
			</label>
		</p>
		<p>
			<label>
				副标题：
			<input style="width:100%;" id="<?php echo $this->get_field_id('mini_title');
				?>" name="<?php echo $this->get_field_name('mini_title');
				?>" type="text" value="<?php echo $instance['mini_title'];
				?>" />
			</label>
		</p>
	<?php
		}
}

class widget_ui_mian_posts extends WP_Widget
{
	function __construct()
	{
		$widget   = array(
			'w_id'     =>  'widget_ui_mian_posts',
			'w_name'     =>  _name('文章板块'),
			'classname'     => '',
			'description'       => '用于显示文章列表的板块，不能添加在侧边栏',
		);
		parent::__construct($widget['w_id'],$widget['w_name'], $widget);
	}
	function widget($args, $instance)
	{
		extract($args);

		$defaults = array(
			'title' => '',
			'mini_title' => '',
			'type' => 'auto',
			'limit' => 6,
			'cat' => '',
			'orderby' => 'views'
		);

		$instance = wp_parse_args((array) $instance, $defaults);
		$orderby = $instance['orderby'];

		$mini_title = $instance['mini_title'];
		if($mini_title){
			$mini_title = '<small class="ml10">'.$mini_title.'</small>';
		}
		$title = $instance['title'];
		$class = ' nobottom';
		if($instance['type'] == 'card'){
			$class = '';
		}
		if($title){
			$title = '<div class="box-body notop'.$class.'"><div class="title-theme">'.$title.$mini_title.'</div></div>';
		}

		echo '<div class="theme-box">';
		echo $title;
	//	echo '<pre>'.json_encode($instance).'</pre>';

		$args = array(
			'cat' => $instance['cat'],
			'order' => 'DESC',
			'showposts' => $instance['limit'],
			'ignore_sticky_posts' => 1
		);

		if ($orderby !== 'views') {
			$args['orderby'] = $orderby;
		} else {
			$args['orderby'] = 'meta_value_num';
			$args['meta_query'] = array(
				array(
					'key' => 'views',
					'order' => 'DESC'
				)
			);
		}
		$list_args = array(
			'type' => $instance['type'],
		);

		$the_query = new WP_Query( $args );
		zib_posts_list($list_args,$the_query);
		echo '</div>';
	}
	function form($instance)
	{
		$defaults = array(
			'title' => '',
			'mini_title' => '',
			'limit' => 6,
			'type' => 'auto',
			'cat' => '',
			'orderby' => 'views'
		);
		$instance = wp_parse_args((array) $instance, $defaults);
		?>
		<p>
			<label>
				<i style="width:100%;color:#f60;">! 核心的文章列表功能，不能设置在侧边栏</i>
			</label>
		</p>
		<p>
			<label>
				标题：
			<input style="width:100%;" id="<?php echo $this->get_field_id('title');
				?>" name="<?php echo $this->get_field_name('title');
				?>" type="text" value="<?php echo $instance['title'];
				?>" />
			</label>
		</p>
		<p>
			<label>
				副标题：
			<input style="width:100%;" id="<?php echo $this->get_field_id('mini_title');
				?>" name="<?php echo $this->get_field_name('mini_title');
				?>" type="text" value="<?php echo $instance['mini_title'];
				?>" />
			</label>
		</p>
		<p>
			<label>
				分类限制：
				<a style="font-weight:bold;color:#f60;text-decoration:none;" href="javascript:;" title="格式：1,2&nbsp;表限制ID为1,2分类的文章&#13;格式：-1,-2 &nbsp;表排除分类ID为1,2的文章&#13;也可直接写1或者-1；注意逗号须是英文的">？</a>
				<input style="width:100%;" id="<?php echo $this->get_field_id('cat');
				?>" name="<?php echo $this->get_field_name('cat');
				?>" type="text" value="<?php echo $instance['cat'];
				?>" size="24" />
			</label>
		</p>
		<p>
			<label>
				显示数目：
				<input style="width:100%;" id="<?php echo $this->get_field_id('limit');
				?>" name="<?php echo $this->get_field_name('limit');
				?>" type="number" value="<?php echo $instance['limit'];
				?>" size="24" />
			</label>
		</p>
		<p>
			<label>
				列表显示模式：
				<select style="width:100%;" id="<?php echo $this->get_field_id('type');
					?>" name="<?php echo $this->get_field_name('type');
					?>">
					<option value="comment_count" <?php selected('auto', $instance['type']);
						?>>默认（自动跟随主题设置)</option>
					<option value="card" <?php selected('card', $instance['type']);
						?>>卡片模式</option>
					<option value="no_thumb" <?php selected('no_thumb', $instance['type']);
						?>>无缩略图列表</option>
					<option value="mult_thumb" <?php selected('mult_thumb', $instance['type']);
						?>>多图模式</option>
				</select>
			</label>
		</p>
		<p>
			<label>
				排序：
				<select style="width:100%;" id="<?php echo $this->get_field_id('orderby');
					?>" name="<?php echo $this->get_field_name('orderby');
					?>">
					<option value="comment_count" <?php selected('comment_count', $instance['orderby']);
						?>>评论数</option>
					<option value="views" <?php selected('views', $instance['orderby']);
						?>>浏览量</option>
					<option value="date" <?php selected('date', $instance['orderby']);
						?>>发布时间</option>
					<option value="modified" <?php selected('modified', $instance['orderby']);
						?>>更新时间</option>
					<option value="rand" <?php selected('rand', $instance['orderby']);
						?>>随机排序</option>
				</select>
			</label>
		</p>
			<?php
	}
}


///////单行滚动文章板块------//单行滚动文章板块------//单行滚动文章板块------//单行滚动文章板块------
///////单行滚动文章板块------//单行滚动文章板块------//单行滚动文章板块------//单行滚动文章板块------
///////单行滚动文章板块------//单行滚动文章板块------//单行滚动文章板块------//单行滚动文章板块------
///////单行滚动文章板块------//单行滚动文章板块------//单行滚动文章板块------//单行滚动文章板块------
///////单行滚动文章板块------//单行滚动文章板块------//单行滚动文章板块------//单行滚动文章板块------

class widget_ui_tab_posts extends WP_Widget
{
	function __construct()
	{
		$widget   = array(
			'w_id'     =>  'widget_ui_tab_posts',
			'w_name'     =>  _name('单行滚动文章板块'),
			'classname'     => '',
			'description'       => '显示文章列表，只显示一行，自动横向滚动',
		);
		parent::__construct($widget['w_id'],$widget['w_name'], $widget);
	}
	function widget($args, $instance)
	{
		extract($args);

		$defaults = array(
			'title' => '',
			'mini_title' => '',
			'type' => 'auto',
			'limit' => 6,
			'cat' => '',
			'orderby' => 'views'
		);

		$instance = wp_parse_args((array) $instance, $defaults);
		$orderby = $instance['orderby'];

		$mini_title = $instance['mini_title'];
		if($mini_title){
			$mini_title = '<small class="ml10">'.$mini_title.'</small>';
		}
		$title = $instance['title'];

		if($title){
			$title = '<div class="box-body notop"><div class="title-theme">'.$title.$mini_title.'</div></div>';
		}

		echo '<div class="theme-box">';
		echo $title;
	//	echo '<pre>'.json_encode($instance).'</pre>';

		$args = array(
			'cat' => $instance['cat'],
			'order' => 'DESC',
			'showposts' => $instance['limit'],
			'ignore_sticky_posts' => 1
		);

		if ($orderby !== 'views') {
			$args['orderby'] = $orderby;
		} else {
			$args['orderby'] = 'meta_value_num';
			$args['meta_query'] = array(
				array(
					'key' => 'views',
					'order' => 'DESC'
				)
			);
		}
		$list_args = array(
			'type' => 'card',
		);

		echo '<div data-scroll="x" class="relative"><div class="scroll-x mini-scrollbar">';
		$the_query = new WP_Query( $args );
		zib_posts_list($list_args,$the_query);
		echo '</div>';
		echo '</div></div>';
	}

	function form($instance)
	{
		$defaults = array(
			'title' => '热门文章',
			'mini_title' => '',
			'limit' => 6,
			'type' => 'auto',
			'cat' => '',
			'orderby' => 'views'
		);
		$instance = wp_parse_args((array) $instance, $defaults);
		?>
		<p>
			<label>
				标题：
			<input style="width:100%;" id="<?php echo $this->get_field_id('title');
				?>" name="<?php echo $this->get_field_name('title');
				?>" type="text" value="<?php echo $instance['title'];
				?>" />
			</label>
		</p>
		<p>
			<label>
				副标题：
			<input style="width:100%;" id="<?php echo $this->get_field_id('mini_title');
				?>" name="<?php echo $this->get_field_name('mini_title');
				?>" type="text" value="<?php echo $instance['mini_title'];
				?>" />
			</label>
		</p>
		<p>
			<label>
				分类限制：
				<a style="font-weight:bold;color:#f60;text-decoration:none;" href="javascript:;" title="格式：1,2&nbsp;表限制ID为1,2分类的文章&#13;格式：-1,-2 &nbsp;表排除分类ID为1,2的文章&#13;也可直接写1或者-1；注意逗号须是英文的">？</a>
				<input style="width:100%;" id="<?php echo $this->get_field_id('cat');
				?>" name="<?php echo $this->get_field_name('cat');
				?>" type="text" value="<?php echo $instance['cat'];
				?>" size="24" />
			</label>
		</p>
		<p>
			<label>
				显示数目：
				<input style="width:100%;" id="<?php echo $this->get_field_id('limit');
				?>" name="<?php echo $this->get_field_name('limit');
				?>" type="number" value="<?php echo $instance['limit'];
				?>" size="24" />
			</label>
		</p>

		<p>
			<label>
				排序方式：
				<select style="width:100%;" id="<?php echo $this->get_field_id('orderby');
					?>" name="<?php echo $this->get_field_name('orderby');
					?>">
					<option value="comment_count" <?php selected('comment_count', $instance['orderby']);
						?>>评论数</option>
					<option value="views" <?php selected('views', $instance['orderby']);
						?>>浏览量</option>
					<option value="date" <?php selected('date', $instance['orderby']);
						?>>发布时间</option>
					<option value="modified" <?php selected('modified', $instance['orderby']);
						?>>更新时间</option>
					<option value="rand" <?php selected('rand', $instance['orderby']);
						?>>随机排序</option>
				</select>
			</label>
		</p>
			<?php
	}
}

/////文章作者信息----///文章作者信息----///文章作者信息----///文章作者信息----///文章作者信息------
/////文章作者信息----///文章作者信息----///文章作者信息----///文章作者信息----///文章作者信息------
/////文章作者信息----///文章作者信息----///文章作者信息----///文章作者信息----///文章作者信息------
/////文章作者信息----///文章作者信息----///文章作者信息----///文章作者信息----///文章作者信息------
/////文章作者信息----///文章作者信息----///文章作者信息----///文章作者信息----///文章作者信息------

class widget_ui_avatar extends WP_Widget
{
	function __construct()
	{
		$widget   = array(
			'w_id'     =>  'widget_ui_avatar',
			'w_name'     =>  _name('文章作者信息'),
			'classname'     => '',
			'description'       => '显示当前文章的作者信息，如添加在其他页面则显示最后一篇文章的作者信息(建议只添加在文章页面)',
		);
		parent::__construct($widget['w_id'],$widget['w_name'], $widget);
	}
	function widget($args, $instance)
	{
		extract($args);

		$defaults = array(
			'title' => '',
			'mini_title' => '',
			'show_info' => '',
			'show_posts' => '',
			'show_img_bg' => true,
			'show_img' => '',
			'limit' => 6,
			'orderby' => 'views'
		);

		$instance = wp_parse_args((array) $instance, $defaults);

		$args = array(
			'show_info' => $instance['show_info'],
			'show_posts' => $instance['show_posts'],
			'show_img_bg' => $instance['show_img_bg'],
			'show_img' => $instance['show_img'],
			'limit' => $instance['limit'],
			'orderby' => $instance['orderby'],
		);

		$mini_title = $instance['mini_title'];
		if($mini_title){
			$mini_title = '<small class="ml10">'.$mini_title.'</small>';
		}
		$title = $instance['title'];

		if($title){
			$title = '<div class="box-body notop"><div class="title-theme">'.$title.$mini_title.'</div></div>';
		}

		echo '<div class="theme-box">';
		echo $title;
		// echo '<pre>'.json_encode($instance).'</pre>';

		zib_posts_avatar_box($args);
		echo '</div>';
	}

	function form($instance)
	{
		$defaults = array(
			'title' => '',
			'mini_title' => '',
			'show_info' => true,
			'show_posts' => true,
			'show_img_bg' => true,
			'show_img' => true,
			'limit' => 6,
			'orderby' => 'views'
		);

		$instance = wp_parse_args((array) $instance, $defaults);
		?>
		<p>
		<i style="width:100%;color:#f60;">此模块与个人信息模块较为相似，且文章页文章内容下方也有作者信息模块可选择显示，建议不优先添加此模块</i>
		</p>
		<p>
			<label>
				标题：
			<input style="width:100%;" id="<?php echo $this->get_field_id('title');
				?>" name="<?php echo $this->get_field_name('title');
				?>" type="text" value="<?php echo $instance['title'];
				?>" />
			</label>
		</p>
		<p>
			<label>
				副标题：
			<input style="width:100%;" id="<?php echo $this->get_field_id('mini_title');
				?>" name="<?php echo $this->get_field_name('mini_title');
				?>" type="text" value="<?php echo $instance['mini_title'];
				?>" />
			</label>
		</p>
		<p>
			<label>
				<input style="vertical-align:-3px;margin-right:4px;" class="checkbox" type="checkbox" <?php checked($instance['show_posts'], 'on');
				?> id="<?php echo $this->get_field_id('show_posts');
				?>" name="<?php echo $this->get_field_name('show_posts');
				?>">显示文章
			</label>
		</p>

		<p>
			<label>
				<input style="vertical-align:-3px;margin-right:4px;" class="checkbox" type="checkbox" <?php checked($instance['show_img'], 'on');
				?> id="<?php echo $this->get_field_id('show_img');
				?>" name="<?php echo $this->get_field_name('show_img');
				?>">文章显示为图片模式
			</label>
		</p>

		<p>
			<label>
				显示数目：
				<input style="width:100%;" id="<?php echo $this->get_field_id('limit');
				?>" name="<?php echo $this->get_field_name('limit');
				?>" type="number" value="<?php echo $instance['limit'];
				?>" size="24" />
			</label>
		</p>
		<p>
			<label>
				排序方式：
				<select style="width:100%;" id="<?php echo $this->get_field_id('orderby');
					?>" name="<?php echo $this->get_field_name('orderby');
					?>">
					<option value="comment_count" <?php selected('comment_count', $instance['orderby']);
						?>>评论数</option>
					<option value="views" <?php selected('views', $instance['orderby']);
						?>>浏览量</option>
					<option value="date" <?php selected('date', $instance['orderby']);
						?>>发布时间</option>
					<option value="modified" <?php selected('modified', $instance['orderby']);
						?>>更新时间</option>
					<option value="rand" <?php selected('rand', $instance['orderby']);
						?>>随机排序</option>
				</select>
			</label>
		</p>

		<?php
	}
}

