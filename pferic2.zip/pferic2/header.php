<?php
/*-----------------------------------------------------------------------------------

	Theme Name: pferic
	Theme URI: http://www.seacozz.com/
	Description: A free theme. More features are added into this theme.
	Author: Eric
	Author URI: http://seacozz.com/
	Version: 1.0.1
	License: GNU General Public License v2 or later
	License URI: http://www.gnu.org/licenses/gpl-2.0.html
	This theme, like Pinterest, is licensed under the GPL.
	Use it to make something cool, have fun, and share what you've learned with others.

-----------------------------------------------------------------------------------*/
?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;" />
	<meta name="baidu-site-verification" content="CPb1awJANb" />
	<meta name="Keywords" content="个人博客,wordpress,似水流年,flash" />
	<meta name="description" content="采用wordpress的个人博客似水流年" />
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<!--[if lt IE 9]>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/html5.js"></script>
	<![endif]-->
	<script>(function(){document.documentElement.className='js'})();</script>
	<script type="text/javascript" src="<?php echo get_bloginfo('template_directory').'/js/jquery.js'; ?>"></script>
	<link rel="stylesheet" href="<?php echo get_bloginfo('template_directory').'/css/bootstrap.min.css'; ?>">
	<link rel="stylesheet" href="<?php echo get_bloginfo('template_directory').'/css/eric.css'; ?>" />
	<link rel="stylesheet" href="<?php echo get_bloginfo('template_directory').'/css/respond.css'; ?>" />
	<?php
	wp_enqueue_script( 'main', get_bloginfo('template_directory').'/js/bootstrap.min.js', array(), '1.0.0', 0 ); // 重新定义 script,同时加载
	wp_enqueue_script( 'audio', get_bloginfo('template_directory').'/js/audio.min.js', array(), '1.0.0', 0 ); // 重新定义 script,同时加载
	if (is_home()){
		wp_enqueue_script( 'type', get_bloginfo('template_directory').'/js/typed.js', array('jquery'), '1.0.0', 0 ); // 重新定义 script,同时加载
	    wp_enqueue_script( 'home', get_bloginfo('template_directory').'/js/home.js', array(), '1.0.0', 0 ); // 重新定义 script,同时加载
	}
	wp_enqueue_script( 'eric', get_bloginfo('template_directory').'/js/eric.js', array(), '1.0.0', 0 ); // 重新定义 script,同时加载


		/**
     * 判断是否为手机浏览器
     * @return bool
     */
    function is_mobile() {
        static $is_mobile;
 
        if ( isset($is_mobile) )
            return $is_mobile;
 
        if ( empty($_SERVER['HTTP_USER_AGENT']) ) {
            $is_mobile = false;
        }elseif(stristr($_SERVER['HTTP_VIA'],"wap")){// 先检查是否为wap代理，准确度高
            $is_mobile = true;
        }elseif(strpos(strtoupper($_SERVER['HTTP_ACCEPT']),"VND.WAP.WML") > 0){// 检查浏览器是否接受 WML.
            $is_mobile = true;
        }elseif(preg_match('/(blackberry|configuration\/cldc|hp |hp-|htc |htc_|htc-|iemobile|kindle|midp|mmp|motorola|mobile|nokia|opera mini|opera |Googlebot-Mobile|YahooSeeker\/M1A1-R2D2|android|iphone|ipod|mobi|palm|palmos|pocket|portalmmm|ppc;|smartphone|sonyericsson|sqh|spv|symbian|treo|up.browser|up.link|vodafone|windows ce|xda |xda_)/i', $_SERVER['HTTP_USER_AGENT'])){//检查USER_AGENT
            $is_mobile = true;
        }elseif ( strpos($_SERVER['HTTP_USER_AGENT'], 'Mobile') !== false // many mobile devices (all iPhone, iPad, etc.)
            || strpos($_SERVER['HTTP_USER_AGENT'], 'Android') !== false
            || strpos($_SERVER['HTTP_USER_AGENT'], 'Silk/') !== false
            || strpos($_SERVER['HTTP_USER_AGENT'], 'Kindle') !== false
            || strpos($_SERVER['HTTP_USER_AGENT'], 'BlackBerry') !== false
            || strpos($_SERVER['HTTP_USER_AGENT'], 'Opera Mini') !== false
            || strpos($_SERVER['HTTP_USER_AGENT'], 'Opera Mobi') !== false ) {
            $is_mobile = true;
        } else {
            $is_mobile = false;
        }
        return $is_mobile;
    }
	?>


	<?php wp_head(); ?>

</head>


<body <?php body_class(); ?>>
<div id="bg_div" style = "background-image:url(<?php echo get_stylesheet_directory_uri();?>/images/bg.jpg);"></div>
<div id="page" class="hfeed site">


	<div class="navbar navbar-inverse navbar-fixed-top">
		    <div class="container">
		        
		        <div class="navbar-header">
		            
		          <button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target=".navbar-collapse">
		            <span class="sr-only">Toggle navigation</span>
		            <span class="icon-bar"></span>
		            <span class="icon-bar"></span>
		            <span class="icon-bar"></span>
		          </button>
		          <a class="navbar-brand hidden-sm" href="#">似水·流年</a>
		          <a style="display:none;" class="navbar-brand hidden-sm" href="http://seacozz.com/blog_bak/flash3/" style="font-size: 12px;padding-top: 18px; ">旧版1</a>
		          <a style="display:none;" class="navbar-brand hidden-sm" href="http://seacozz.com/blog_bak/flash2/" style="font-size: 12px;padding-top: 18px; ">旧版2</a>
		          	<?php if(!is_mobile()): ?><div class="audioMp3"><audio src="http://tsmusic128.tc.qq.com/101824078.mp3" preload="auto"  /></div><?php endif ?>
		          
		        </div>
		        <?php wp_nav_menu( array('container_class' => 'navbar-collapse collapse','menu_class'=>'nav navbar-nav'));?>
		        
		    </div>

		</div>


