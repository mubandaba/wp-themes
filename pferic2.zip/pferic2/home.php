<?php get_header(); ?>
  <div id="content" class="h100" style="">

    <div id="page" style="overflow: hidden;left:0px;top:0px;width:100%;height:100%;display:block;padding-bottom: 0px;">
      <div class="hm-nw-bnr-vid h100" style="overflow: hidden;">
         <div class="hm-nw-bnr-bk " style="height:0px">
         <?php if(!is_mobile()): ?>
         <video autoplay loop preload="auto" style="" id="video">
             <source src="<?php bloginfo('template_directory'); ?>/videos/pops.webm">
             <!--[if LT IE 9]>
             <object type="application/x-shockwave-flash" data="http://flashfox.googlecode.com/svn/trunk/flashfox.swf" width="100%" height="770">
               <param name="movie" value="http://flashfox.googlecode.com/svn/trunk/flashfox.swf">
               <param name="allowFullScreen" value="true">
               <param name="wmode" value="transparent">
               <param name="flashVars" value="autoplay=true&controls=false&loop=true&poster=http%3A%2F%2Fwww.cloudways.com%2Ftemplate%2Fdefault%2Fimg%2Fimg-new%2Fhome_bg.jpg&src=http%3A%2F%2Fs3.amazonaws.com%2Fcloudways-website-videos%2FHome.mp4">
             </object>
             <![endif]-->
        </video>
        <?php endif ?>
        </div>
        <div class="home_div w100">
          <div class="home_title_div w100 p100"> 
             
           
            <div class="home_title">
              <div class="home_title1">
                <span id="home_tile_type1"></span>
              </div>
              <div class="home_title2">
                <span>似水·流年</span>
              </div>
              <div class="home_title3">
                <span>从远处来到远处去，相遇又相离。徘徊的我们，来不及伤感，却已是别一个盛夏...</span>
              </div>
              <div class="home_title_btn">
                <a href="http://seacozz.com/?cat=2" id="getIns">GetIn</a>
              </div>
            </div>
          </div>

          <div class="home_page_div w100 p100">
            <div class="home_span_div1">
              <a href="http://seacozz.com/?cat=2">
              <span class="home_span1">
                做另一个自己
              </span>
              <span class="home_span2">
                <br>
                ★★★★学习★★★★<br>……<br>
                ★★★★生活★★★★<br>……<br>
                ★★★★锻炼★★★★<br>……<br>
                ★★★★阅读★★★★<br>……<br>
                ★★★★心愿★★★★<br>……<br>
              </span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">

</script>

  <div class="footer-main" style="z-index: 99;">©<a href="<?php bloginfo('url'); ?>">
    <?php bloginfo('name'); ?>
    </a> | <a href="http://seacozz.com/">Seaco</a> | <a href="http://seacozz.com/" target="_blank">pferic</a></div>


<div id="dto-top" class="m-goTopArea"><a href="javascript:;" class="goTop" title="回到顶部">回到顶部</a></div>

