/*-----------------------------------------------------------------------------------

	Theme Name: pferic
	Theme URI: http://www.seacozz.com/
	Description: A free theme. More features are added into this theme.
	Author: Eric
	Author URI: http://seacozz.com/
	Version: 1.0.1
	License: GNU General Public License v2 or later
	License URI: http://www.gnu.org/licenses/gpl-2.0.html
	This theme, like Pinterest, is licensed under the GPL.
	Use it to make something cool, have fun, and share what you've learned with others.

-----------------------------------------------------------------------------------*/  


  audiojs.events.ready(function() {
    var as = audiojs.createAll();
    $('.audiojs .play-pause').click();
  });


