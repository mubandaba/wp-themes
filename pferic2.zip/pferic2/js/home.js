
function resizeVideo(){
    $('.p100').height($('body').height()) 
    $('#page').height($('body').height()) 
    console.log("bodyW:"+ $('body').width() + "   bodyH:"+$('body').height() )
    var wH = $('body').width()/1920*1080
    if (wH < $('body').height()){
      wH = $('body').height()
    }
    console.log(wH)
    $('#video').height(wH)

}
  $(window).resize(function(){
   //process here
   resizeVideo()
  });

$(function(){
    resizeVideo()
    //a.click
    $('#getIn').click(function(){
      //$(".home_div").animate({top:0 - $('body').height() + "px"},900);
      //$("#dto-top").fadeIn(500);
    })

    $('#dto-top').click(function(){
      $(".home_div").animate({top:0 + "px"},900);
      $("#dto-top").fadeOut(300);
    })

    jQuery("#home_tile_type1").typed({
      strings: ["^800你见，或者不见我","我就在那里","不悲不喜","你念，或者不念我","情就在那里","不来不去","你爱或者不爱我","爱就在那里","不增不减","你跟，或者不跟我","我的手就在你的手里","不舍不弃","来我怀里","或者","让我住进你的心里","默然 相爱","寂静 喜欢^2000"],
      typeSpeed: 140,
      backSpeed:70,
      backDelay:1000,
      loop:true
    });
  });