<?php
/**
 * The default template for displaying content
 *
 * Used for both single and index/archive/search.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
?>

<div class="post-wrap pferic-post">
		<div class="m-post">
			<?php
				$format = get_post_format();
				if( false === $format ) { $format = 'standard'; }
			?>
			<a class="typeicon standard <?php  echo get_post_format(); ?>" href="<?php the_permalink(); ?>"></a>
			<div class="content content_<?php  echo get_post_format(); ?>">
				<h2 class="title"><a href="<?php the_permalink(); ?>" title="<?php echo esc_attr( sprintf( __( 'Permalink to %s', 'presence' ), the_title_attribute( 'echo=0' ) ) ); 
				?>" rel="bookmark"><?php the_title(); 

					$format = get_post_format();
					if( 'image' == $format ) { 
						echo '<span style="font-size:12px;margin-left: 10px;">--点击查看<span>';
					}

				?></a></h2>
				<div class="text">
					<?php the_content(); ?>
				</div>
				<?php edit_post_link( '编辑', '<span class="edit-link">', '</span>' ); ?>
			</div>
		</div>
		<div class="m-infoarea clearfix">
			<a class="time" href="<?php the_permalink(); ?>"><?php echo get_the_date(); ?></a>
			<?php if(function_exists('post_views')) { ?>
			<a href="<?php the_permalink(); ?>" class="like"><?php echo post_views('', '');?></a>
			<?php } ?>
			<?php comments_popup_link( '0', '1', '%', 'comment' ); ?>
			<span class="sep">/</span>
			<div class="from"><span class="reblog"><?php the_category('&nbsp;'); ?></span></div>
			<span class="sep">/</span>
			<div class="tagarea clearfix">
				<span class="taglb"><?php _e( 'Tag:&nbsp;', 'presence' ); ?></span>
				<?php 
					$taglist = get_the_tag_list( '', '' );
					if ( $taglist ) {
						echo $taglist;
					} else {
						echo __( 'No Tags', 'presence' );
					}
				?>
			</div>
		</div>
	</div>