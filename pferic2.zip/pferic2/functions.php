<?php
/**
 * Twenty Fifteen functions and definitions
 *
 * Set up the theme and provides some helper functions, which are used in the
 * theme as custom template tags. Others are attached to action and filter
 * hooks in WordPress to change core functionality.
 *
 * When using a child theme you can override certain functions (those wrapped
 * in a function_exists() call) by defining them first in your child theme's
 * functions.php file. The child theme's functions.php file is included before
 * the parent theme's file, so the child theme functions would be used.
 *
 * @link http://www.seacozz.com/
 * @link http://www.seacozz.com/
 *
 * Functions that are not pluggable (not wrapped in function_exists()) are
 * instead attached to a filter or action hook.
 *
 * For more information on hooks, actions, and filters,
 *
 * @package WordPress
 * @subpackage pferic
 * @since pferic 2.0
 */

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 *
 * @since pferic 2.0
 */

function pferc_setup() {

	// Load our main stylesheet.
	wp_enqueue_style( 'pferic-style', get_stylesheet_uri() );


	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on twentyfifteen, use a find and replace
	 * to change 'twentyfifteen' to the name of your theme in all the template files
	 */
	load_theme_textdomain( 'pferic', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	//add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * See: https://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	 */
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 825, 510, true );

	// This theme uses wp_nav_menu() in two locations.
	register_nav_menus( array(
		'primary' => __( 'Primary Menu',      'pferic' ),
		'social'  => __( 'Social Links Menu', 'pferic' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form', 'comment-form', 'comment-list', 'gallery', 'caption'
	) );

	/*
	 * Enable support for Post Formats.
	 *
	 * See: https://codex.wordpress.org/Post_Formats
	 */
	add_theme_support( 'post-formats', array(
		'aside', 'image', 'video', 'quote', 'link', 'gallery', 'status', 'audio', 'chat'
	) );

	// Setup the WordPress core custom background feature.
	//add_theme_support( 'custom-background');

	/**
	*WordPress 不同自定义文章类型使用不同的模板文件
	*http://www.endskin.com/custom-post-type-template.html
*/



}
add_action( 'after_setup_theme', 'pferc_setup' );

if (!is_admin()) {
	function zfunc_scripts_method() {
		wp_enqueue_script('jquery');
		if (is_singular()) {
			wp_enqueue_script('comments_ajax_js', (get_template_directory_uri()."/comments-ajax.js"), false, '1.3', true);
		}
	}
	add_action('wp_enqueue_scripts', 'zfunc_scripts_method');
}



	/**
	 * Replace avatar URL
	 * @author bigfa
	 * @return string 
	 */
	function get_ssl_avatar($avatar) {
   		$avatar = preg_replace('/.*\/avatar\/(.*)\?s=([\d]+)&.*/','<img src="http://cn.gravatar.com/avatar/$1?s=$2" class="avatar avatar-$2" height="$2" width="$2">',$avatar);
  		return $avatar;
	}
	add_filter('get_avatar', 'get_ssl_avatar');


	/**
	 * Get Post Thumb img
	 * @author M.J
	 * @return string 
	 */
	function get_post_thumb( $return_src = 'true' ){
		global $post, $posts;
		$content = $post->post_content;
		$pattern = '/<img.+src=[\'"]([^\'"]+)[\'"].*>/i';
		$result = preg_match_all( $pattern, $content, $matches );
		if ( $return_src == 'true' ){
			if ( !empty( $result ) ){
				$imgResult = '<img src="'.get_bloginfo("template_url").'/timthumb.php?src='.$matches[1][0].'&amp;q=100&amp;w=210" alt="" />';
			}
		} else {
			$imgResult = $matches[1][0];
		}
		return $imgResult;
	}
	
	
	//New window opens Comment Link
	function hu_popuplinks($text) {
		$text = preg_replace('/<a (.+?)>/i', "<a $1 target='_blank'>", $text);
		return $text;
	}
	add_filter('get_comment_author_link', 'hu_popuplinks', 6);

	//To anti in English comment spam
	function scp_comment_post( $incoming_comment ) {
		$pattern = '/[一-龥]/u';
		if(!preg_match($pattern, $incoming_comment['comment_content'])) {
			err( __('You should type some Chinese word (like "Hello") in your comment to pass the spam-check, thanks for your patience! Your comment must contain Chinese characters!', 'pferic') );
		}
		return( $incoming_comment );
	}
	add_filter('preprocess_comment', 'scp_comment_post');
	
	//Add Math For Comment
	function mathCode_comment_post(){
		$num1 = ( isset( $_POST['num1'] ) ) ? trim( intval( strip_tags( $_POST['num1'] ) ) ) : null;
		$num2 = ( isset( $_POST['num1'] ) ) ? trim( intval( strip_tags( $_POST['num2'] ) ) ) : null;
		$math = ( isset( $_POST['num1'] ) ) ? trim( intval( strip_tags( $_POST['math'] ) ) ) : null;
		if ( !num1 || !num2 || !math ){
			err( '验证码错误' );
		} else {
			if ( ( $num1+$num2 ) != $math ){
				err( '验证码错误' );
			}
		}
	}
	add_action( 'pre_comment_on_post', 'mathCode_comment_post');


	/* 邮件通知 by Qiqiboy */
	 function comment_mail_notify($comment_id) {

		$comment = get_comment($comment_id);//根据id获取这条评论相关数据
	     $content=$comment->comment_content;
	     //对评论内容进行匹配
	     $match_count=preg_match_all('/<a href="#comment-([0-9]+)?" rel="nofollow">/si',$content,$matchs);
	     if($match_count>0){//如果匹配到了
	         foreach($matchs[1] as $parent_id){//对每个子匹配都进行邮件发送操作
	         	SimPaled_send_email($parent_id,$comment);
	         }
	     }elseif($comment->comment_parent!='0'){//以防万一，有人故意删了@回复，还可以通过查找父级评论id来确定邮件发送对象
	     	$parent_id=$comment->comment_parent;

	         SimPaled_send_email($parent_id,$comment);
	     }else return;
	 }
	 add_action('comment_post', 'comment_mail_notify');
	 function SimPaled_send_email($parent_id,$comment){//发送邮件的函数 by Qiqiboy.com
	 	 $admin_email = get_bloginfo ('admin_email');//管理员邮箱
	     $parent_comment=get_comment($parent_id);//获取被回复人（或叫父级评论）相关信息
	     $author_email=$comment->comment_author_email;//评论人邮箱
	     $to = trim($parent_comment->comment_author_email);//被回复人邮箱
	     $spam_confirmed = $comment->comment_approved;
	     if ($spam_confirmed != 'spam' && $to != $admin_email && $to != $author_email) {
	     	 $wp_email = '84089842@qq.com' . preg_replace('#^www\.#', '', strtolower($_SERVER['SERVER_NAME'])); // e-mail 發出點, no-reply 可改為可用的 e-mail.
	         
	         //$subject = '您在 [' . get_option("blogname") . '] 的留言有了回复';
	         $subject = '您在 [似水 流年] 的留言有了回复';
	         $message = '<div style="background-color:#eef2fa;border:1px solid #d8e3e8;color:#111;padding:0 15px;-moz-border-radius:5px;-webkit-border-radius:5px;-khtml-border-radius:5px;">
	             <p>' . trim(get_comment($parent_id)->comment_author) . ', 您好!</p>
	             <p>您曾在《' . get_the_title($comment->comment_post_ID) . '》的留言:<br />'
	             . trim(get_comment($parent_id)->comment_content) . '</p>
	             <p>' . trim($comment->comment_author) . ' 给你的回复:<br />'
	             . trim($comment->comment_content) . '<br /></p>
	             <p>您可以点击 <a href="' . htmlspecialchars(get_comment_link($parent_id,array("type" => "all"))) . '">查看回复的完整內容</a></p>
	             <p>欢迎再度光临 <a href="' . get_option('home') . '">' . get_option('blogname') . '</a></p>
	             <p>(此邮件有系统自动发出, 请勿回复.)</p></div>';
	         $from = "From: \"" . get_option('blogname') . "\" <$wp_email>";
	         $headers = "Content-Type: text/html; charset=" . get_option('blog_charset') . "\n";
	         //wp_mail($to, 'you have a new comment', $message, $headers); 
	         $newSub = iconv("UTF-8", "gb2312", $subject);
	         wp_mail($to, $newSub , $message, $headers); 
	     }
	 }
	
	/**
	 * when comment check the comment_author comment_author_email
	 * @param unknown_type $comment_author
	 * @param unknown_type $comment_author_email
	 * @return unknown_type
	 * Prevent visitors posing bloggers comment 
	 */
	function CheckEmailAndName(){
		global $wpdb;
		$comment_author       = ( isset($_POST['author']) )  ? trim(strip_tags($_POST['author'])) : null;
		$comment_author_email = ( isset($_POST['email']) )   ? trim($_POST['email']) : null;
		if(!$comment_author || !$comment_author_email){
			return;
		}
		$result_set = $wpdb->get_results("SELECT display_name, user_email FROM $wpdb->users WHERE display_name = '" . $comment_author . "' OR user_email = '" . $comment_author_email . "'");
		if ($result_set) {
			if ($result_set[0]->display_name == $comment_author){
				err( __( 'Warning: You can not use this nickname, because this is the nickname of the bloggers!', 'pferic' ) );
			}else{
				err( __( 'Warning: You can not use the mailbox, because this is the mailbox of the bloggers!', 'pferic') );
			}
			fail($errorMessage);
		}
	}
	add_action('pre_comment_on_post', 'CheckEmailAndName');
	




	/**
	 * Template for comments and pingbacks.
	 *
	 * To override this walker in a child theme without modifying the comments template
	 * simply create your own pferic_comment(), and that function will be used instead.
	 */
	function pferic_comment($comment, $args, $depth) {
		$GLOBALS['comment'] = $comment; 
	?>
		<li <?php comment_class(); ?> id="li-comment-<?php comment_ID() ?>">
		<div class="comment-body clearfix" id="comment-<?php comment_ID(); ?>">
			<?php echo get_avatar( $comment, $size='35' ); ?>
			<div class="comment-wrap">
				<div class="comment-author">
					<span class="reply-container">
						<?php comment_reply_link(array_merge( $args, array('reply_text' => '回复', 'depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
						<?php edit_comment_link(__(' Edit ', 'pferic'),'  ','') ?>
						<span class="comment-meta commentmetadata"><?php echo(get_comment_date()) ?></span>
					</span>
					<span id="reviewer-<?php echo comment_ID(); ?>"><?php printf('%s', get_comment_author_link()) ?></span>
				</div>
				<div class="comment-content"><?php comment_text() ?></div>
			</div>
		</div>

	<?php

	}



	/**
	 * infinite scroll
	 *
	 */

function infinitescroll_js() {
    wp_register_script('infinite_scroll', get_stylesheet_directory_uri() . '/js/jquery.infinitescroll.min.js', array('jquery'), null, true);
    if (!is_singular()) {
        wp_enqueue_script('infinite_scroll');
    }
}
add_action('wp_enqueue_scripts', 'infinitescroll_js');
/*
初始化infinite scroll插件配置参数
*/
function infinite_scroll_js() {
    if (!is_singular() ) {
        ?>
        <script type="text/javascript">
        jQuery(document).ready(function(){            
            var infinite_scroll = {
                loading: {
                    img: "<?php echo get_stylesheet_directory_uri(); ?>/images/ajax-loader_dark.gif",
                    msgText: "加载中...",
                    finishedMsg: "已加载所有..."
                },
                nextSelector:".navigation a:first",
                navSelector:".navigation",
                itemSelector:".pferic-post",
                contentSelector:".pferic-content",                
            };
            jQuery( infinite_scroll.contentSelector ).infinitescroll( infinite_scroll );
        });
        </script>
        <?php
    }
}
add_action('wp_footer', 'infinite_scroll_js', 100);

function record_visitors()
{
	if (is_singular())
	{
	  global $post;
	  $post_ID = $post->ID;
	  if($post_ID)
	  {
		  $post_views = (int)get_post_meta($post_ID, 'views', true);
		  if(!update_post_meta($post_ID, 'views', ($post_views+1)))
		  {
			add_post_meta($post_ID, 'views', 1, true);
		  }
	  }
	}
}
add_action('wp_head', 'record_visitors');
 
/// 函数名称：post_views
/// 函数作用：取得文章的阅读次数
function post_views($before = '(浏览 ', $after = ' 次)', $echo = 1)
{
  global $post;
  $post_ID = $post->ID;
  $views = (int)get_post_meta($post_ID, 'views', true);
  if ($echo) echo $before, number_format($views), $after;
  else return $views;
}





/* if the host doesn't support the mb_ functions, we have to define them. From Yskin's wp-CJK-excerpt, thanks to Yskin. */
if ( !function_exists('mb_strlen') ) {
	function mb_strlen ($text, $encode) {
		if ($encode=='UTF-8') {
			return preg_match_all('%(?:
					  [\x09\x0A\x0D\x20-\x7E]           # ASCII
					| [\xC2-\xDF][\x80-\xBF]            # non-overlong 2-byte
					|  \xE0[\xA0-\xBF][\x80-\xBF]       # excluding overlongs
					| [\xE1-\xEC\xEE\xEF][\x80-\xBF]{2} # straight 3-byte
					|  \xED[\x80-\x9F][\x80-\xBF]       # excluding surrogates
					|  \xF0[\x90-\xBF][\x80-\xBF]{2}    # planes 1-3
					| [\xF1-\xF3][\x80-\xBF]{3}         # planes 4-15
					|  \xF4[\x80-\x8F][\x80-\xBF]{2}    # plane 16
					)%xs',$text,$out);
		}else{
			return strlen($text);
		}
	}
}

/* from Internet, author unknown */
if (!function_exists('mb_substr')) {
    function mb_substr($str, $start, $len = '', $encoding="UTF-8"){
        $limit = strlen($str);
 
        for ($s = 0; $start > 0;--$start) {// found the real start
            if ($s >= $limit)
                break;
 
            if ($str[$s] <= "\x7F")
                ++$s;
            else {
                ++$s; // skip length
 
                while ($str[$s] >= "\x80" && $str[$s] <= "\xBF")
                    ++$s;
            }
        }
 
        if ($len == '')
            return substr($str, $s);
        else
            for ($e = $s; $len > 0; --$len) {//found the real end
                if ($e >= $limit)
                    break;
 
                if ($str[$e] <= "\x7F")
                    ++$e;
                else {
                    ++$e;//skip length
 
                    while ($str[$e] >= "\x80" && $str[$e] <= "\xBF" && $e < $limit)
                        ++$e;
                }
            }
 
        return substr($str, $s, $e - $s);
    }
}


/* default option values */
define ('HOME_EXCERPT_LENGTH', 300);
define ('ARCHIVE_EXCERPT_LENGTH', 150);
define ('ALLOWD_TAG', '<a><b><blockquote><br><cite><code><dd><del><div><dl><dt><em><h1><h2><h3><h4><h5><h6><i><img><li><ol><p><pre><span><strong><ul>');
define ('READ_MORE_LINK', __( 'Read more', 'pferic') );


/* the core excerpt function */
if (!function_exists('utf8_excerpt')) {
	function utf8_excerpt ($text, $type) {
		
		
		//get the full post content
		global $post;

		//whether it is hooked to the_excerpt or the_content
		switch ($type) {
			case 'content':
				//in this case, the passed parameter $text is the full content
				
				//get the manual excerpt

				$manual_excerpt = $post->post_excerpt;

				break;
			
			case 'excerpt':
				//in this case, the passed parameter $text is the manual excerpt
				$manual_excerpt = $text;
				
				//get and trim the full post content
				$text = $post->post_content;
				$text = str_replace(']]>', ']]&gt;', $text);
				$text = trim($text);
				break;
			
			default:
				break;
		}
		
		

		//only show excerpt on home and archive pages. search result page should be considered archive page.
		if ( !is_page() && !is_archive() && !is_search() ) {
			return $text;
		}
		
		//if there is manual excerpt, show the manual  excerpt
		if ( '' !==  $manual_excerpt ) {
			$text = $manual_excerpt;
			$text = utf8_excerpt_readmore ($text);
			return $text;
		}
		
		//if there is a <!--more--> tag, return stuff before that
		switch ($type) {
			case 'content':
				//in this case, the_content passes formatted content, which has turned <!--more--> tag into a link, which is in turn turned to special mark by me
		 		$more_position = stripos ($text, 'UTF8_EXCERPT_HAS_MORE');
				if ($more_position !== false) {
					//remove UTF8_EXCERPT_HAS_MORE at the end, which has 21 characters
					$text = substr ($text, 0, -21);
					$text = utf8_excerpt_readmore ($text);
					return $text;
				}
				break;
			
			case 'excerpt':
				//in this case, I get the raw content with the <!--more--> tag
		 		$more_position = stripos ($text, "<!--more-->");
				if ($more_position !== false) {
					$text = substr ($text, 0, $more_position);
					$text = utf8_excerpt_readmore ($text);
				    	return $text;
				}
				break;
			
			default:
				break;
		}
		
		
		//get the options
		$home_excerpt_length = HOME_EXCERPT_LENGTH;
		$archive_excerpt_length = ARCHIVE_EXCERPT_LENGTH;
		$allowd_tag =  ALLOWD_TAG;
		if ( is_home()) {
			$length = $home_excerpt_length;
		} elseif ( is_archive() || is_search() || is_page()) {
			$length = $archive_excerpt_length;
		}
		
		//will make this an option for the user to decide
		$strip_short_post = true;
		
		 //if the post is already short and the user wants to strip tags
		if(($length > mb_strlen(strip_tags($text), 'utf-8')) && ($strip_short_post === true) ) {
			$text = strip_tags($text, $allowd_tag); 		
			$text = trim($text);
			//$text = utf8_excerpt_readmore ($text);
			return $text;
		}
		
		//other cases
		$text = strip_tags($text, $allowd_tag); 		
		$text = trim($text);
		//check if the character is worth counting (ie. not part of an HTML tag). From Bas van Doren's Advanced Excerpt, thanks to Bas van Doren.
		$num = 0;
		$in_tag = false;
		for ($i=0; $num<$length || $in_tag; $i++) {
			if(mb_substr($text, $i, 1) == '<')
				$in_tag = true;
			elseif(mb_substr($text, $i, 1) == '>')
				$in_tag = false;
			elseif(!$in_tag)
				$num++;
		}
		$text = mb_substr ($text,0,$i, 'utf-8');    
		
		$text = trim($text);
		$text = utf8_excerpt_readmore ($text);
		return $text;
	}
}


//check if the post has a <!--more--> tag
//the_content passes formatted content, which has turned <!--more--> tag into a link, so I have to leave a special mark
function utf8_excerpt_has_more( $more )
{
	if ( '' !== $more) {
		return 'UTF8_EXCERPT_HAS_MORE';
	} 
}
add_filter( 'the_content_more_link', 'utf8_excerpt_has_more' );


// add a "read more" link
if (!function_exists('utf8_excerpt_readmore')) {
	function utf8_excerpt_readmore ($text) {
		//get options
		$read_more_link = READ_MORE_LINK;
		
		//add read_more_link
		$text .= "[......]";
		$text = force_balance_tags($text);
		$text .= "<p class='read-more'><a href='".get_permalink()."'>".$read_more_link."</a></p>";
		return $text;
	}
}


//hook on the_excerpt hook
if (!function_exists('utf8_excerpt_for_excerpt')) {
	function utf8_excerpt_for_excerpt ($text) {
		return utf8_excerpt($text, 'excerpt');
	}
}
add_filter('get_the_excerpt', 'utf8_excerpt_for_excerpt', 9);

//hook on the_content hook
if (!function_exists('utf8_excerpt_for_content')) {
	function utf8_excerpt_for_content ($text) {
		return utf8_excerpt($text, 'content');
	}
}
add_filter('the_content', 'utf8_excerpt_for_content', 9);






/**
* Enqueues scripts and styles for loop
*/
require("framework/loop.php");





//修复4.2表情bug
function disable_emoji9s_tinymce($plugins) {
    if (is_array($plugins)) {
        return array_diff($plugins, array(
            'wpemoji'
        ));
    } else {
        return array();
    }
}
//取当前主题下img\smilies\下表情图片路径
function custom_gitsmilie_src($old, $img) {
    return get_stylesheet_directory_uri() . '/images/smilies/' . $img;
}
function init_gitsmilie() {
    global $wpsmiliestrans;
    //默认表情文本与表情图片的对应关系(可自定义修改)
    $wpsmiliestrans = array(
        ':mrgreen:' => 'icon_mrgreen.gif',
        ':neutral:' => 'icon_neutral.gif',
        ':twisted:' => 'icon_twisted.gif',
        ':arrow:' => 'icon_arrow.gif',
        ':shock:' => 'icon_eek.gif',
        ':smile:' => 'icon_smile.gif',
        ':???:' => 'icon_confused.gif',
        ':cool:' => 'icon_cool.gif',
        ':evil:' => 'icon_evil.gif',
        ':grin:' => 'icon_biggrin.gif',
        ':idea:' => 'icon_idea.gif',
        ':oops:' => 'icon_redface.gif',
        ':razz:' => 'icon_razz.gif',
        ':roll:' => 'icon_rolleyes.gif',
        ':wink:' => 'icon_wink.gif',
        ':cry:' => 'icon_cry.gif',
        ':eek:' => 'icon_surprised.gif',
        ':lol:' => 'icon_lol.gif',
        ':mad:' => 'icon_mad.gif',
        ':sad:' => 'icon_sad.gif',
        '8-)' => 'icon_cool.gif',
        '8-O' => 'icon_eek.gif',
        ':-(' => 'icon_sad.gif',
        ':-)' => 'icon_smile.gif',
        ':-?' => 'icon_confused.gif',
        ':-D' => 'icon_biggrin.gif',
        ':-P' => 'icon_razz.gif',
        ':-o' => 'icon_surprised.gif',
        ':-x' => 'icon_mad.gif',
        ':-|' => 'icon_neutral.gif',
        ';-)' => 'icon_wink.gif',
        '8O' => 'icon_eek.gif',
        ':(' => 'icon_sad.gif',
        ':)' => 'icon_smile.gif',
        ':?' => 'icon_confused.gif',
        ':D' => 'icon_biggrin.gif',
        ':P' => 'icon_razz.gif',
        ':o' => 'icon_surprised.gif',
        ':x' => 'icon_mad.gif',
        ':|' => 'icon_neutral.gif',
        ';)' => 'icon_wink.gif',
        ':!:' => 'icon_exclaim.gif',
        ':?:' => 'icon_question.gif',
    );
    //移除WordPress4.2版本更新所带来的Emoji钩子同时挂上主题自带的表情路径
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('admin_print_scripts', 'print_emoji_detection_script');
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_action('admin_print_styles', 'print_emoji_styles');
    remove_filter('the_content_feed', 'wp_staticize_emoji');
    remove_filter('comment_text_rss', 'wp_staticize_emoji');
    remove_filter('wp_mail', 'wp_staticize_emoji_for_email');
    add_filter('tiny_mce_plugins', 'disable_emoji9s_tinymce');
    add_filter('smilies_src', 'custom_gitsmilie_src', 10, 2);
}
add_action('init', 'init_gitsmilie', 5); 




?>