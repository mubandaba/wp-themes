<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the "site-content" div and all content after.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
?>

	</div><!-- .site-content -->

	<footer id="colophon" class="site-footer" role="contentinfo">
		<div class="site-info">
			<?php
				/**
				 * Fires before the Twenty Fifteen footer text for footer customization.
				 *
				 * @since Twenty Fifteen 1.0
				 */
				do_action( 'twentyfifteen_credits' );
			?>
			<a style="display:none;"> href="<?php echo esc_url( __( 'https://wordpress.org/', 'twentyfifteen' ) ); ?>"><?php printf( __( 'Proudly powered by %s', 'pferic' ), 'Seaco' ); ?></a>
		</div><!-- .site-info -->
	</footer><!-- .site-footer -->

</div><!-- .site -->


<script>
	jQuery(function () {
			jQuery(window).scroll(function () {
				if ($(window).scrollTop() >= $(window).height()) {
					jQuery("#gtotop").fadeIn(600)
				} else {
					jQuery("#gtotop").fadeOut(600)
				}
			});
			jQuery("#gtotop").click(function () {
				jQuery('body,html').animate({
					scrollTop : 0
				}, 600);
				return false
			});
		})

<?php 
if(is_mobile() ){
?>

jQuery(function () {
	$('.single-format-image .slideshow-imgprev').attr('style', 'opacity:0.5 !important;');
	$('.slideshow-imgprev').one('click', function(event) {
		$('.slideshow-imgprev').removeAttr('style');
	});
	$('.single-format-image .slideshow-imgnext').attr('style', 'opacity:0.5 !important;');
	$('.slideshow-imgnext').one('click', function(event) {
		$('.slideshow-imgnext').removeAttr('style');

	});

	//$('body').bind("touchmove",function(e){
	  //e.preventDefault();
	//});
})
<?php
}
?>


</script>
<div class="footer-main" style="z-index: 99;">©<a href="http://seacozz.com">
    似水·流年    </a> | <a href="http://seacozz.com/">Seaco</a> | <a href="http://seacozz.com/" target="_blank">pferic</a></div>

<?php wp_footer(); ?>

</body>
</html>
