<?php get_header(); ?>	
	<section id="content">
		<article id="post-0" class="post error404 not-found" >
			<hgroup>
				<h1 class="entry-title" style="text-align:center;">报告长官，您走错地方了！</h1>
			</hgroup>
			<div class="entry-content">
				 <p><?php _e( 'Apologies, but we were unable to find what you were looking for. Perhaps searching will help.', 'your-theme' ); ?></p>
			</div>					
		</article>	
	</section>			
<?php get_sidebar(); ?>	
<?php get_footer(); ?>