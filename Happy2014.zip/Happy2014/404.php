<?php get_header(); ?>

<div class="container global">
	<div class="row">
		<div class="col-md-9">
			<div class="error404">
				<h1>404 Not Found</h1>
			</div>
		</div>
		<div class="col-md-3 hiidden-xs">
			<?php get_sidebar(); ?>
		</div>
	</div>
</div>



<?php get_footer(); ?>