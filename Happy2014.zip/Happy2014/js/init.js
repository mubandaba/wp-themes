$(document).ready(function() {
	$('.thumb img').adipoli({
    'startEffect' : 'normal',
    'hoverEffect' : 'popout'
	});
	$('.weixin img').adipoli({
    'startEffect' : 'grayscale',
    'hoverEffect' : 'normal'
	});

 $(".article img").addClass("carousel-inner img-responsive img-rounded");

});