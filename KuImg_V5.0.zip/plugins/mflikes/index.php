<?php

require_once(dirname(__FILE__) . '/../../../wp-load.php');		// includes wordpress loads for using wordpress vars
require_once(dirname(__FILE__) . '/class.mflikes.php');		// includes mflikes class to process likes and unlikes
global $wpdb;

function sortArray($array){
	$values = array_values($array);
	$ch= max;
	do{
		$val = $ch($values);
		$key = array_search($val,$values);
		$result[$key] = $val;
		unset($values[$key]);
	}while (count($values)>0);
	return $result;
}

$post_id = $_POST['post_id'];
$user_id = $_POST['user_id'];
$mflikes = new mflikes($post_id, $user_id);	// new mflikes class

$mflikes->like_post();

$user = get_userdata($user_id);

$post = get_post($post_id);



$user_likes = $user->likes ? unserialize($user->likes) : array();
$mflikes_uid = $post->mflikes_uid  ? unserialize($post->mflikes_uid) : array();

if( !in_array($post_id, $user_likes) ) array_push( $user_likes, $post_id );

if( !in_array($user_id, $mflikes_uid) ) array_push( $mflikes_uid, $user_id );

$user_likes = sortArray($user_likes);
// updates user meta with new like count
update_user_meta($user_id, 'likes', serialize($user_likes) );


// updates posts table with new like count
$wpdb->update($wpdb->posts, 
			array('mflikes_uid' => serialize($mflikes_uid )),
			array('ID' => $post_id, 'post_status' => 'publish'),
			array('%s'),
			array('%d', '%s'));

// count likes
$mflikes->likes_count();

echo $mflikes->likes_count;

?>