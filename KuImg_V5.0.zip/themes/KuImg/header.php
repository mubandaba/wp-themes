<!DOCTYPE html>
<html lang="zh-CN">
 <head>
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 <meta name="applicable-device" content="pc">
 <meta http-equiv="content-language" lang="zh-CN" />
 <meta http-equiv="Cache-Control" content="no-transform" /> 
 <meta http-equiv="Cache-Control" content="no-siteapp" />
 <?php header('X-Frame-Options:Deny'); ?>
 <?php mfthemes_meta();?>
 <?php head_script(); ?>
 <?php wp_head(); ?>
 <?php headcode(); ?> 
 </head>
 <body>
  <div class="pic_index_headc"> 
   <div class="secondaryHeader">
   <?php $options = get_option('mfthemes_options'); $logo =  $options['logo'] ? $options['logo'] : get_bloginfo('template_url')."/style/images/logo.png" ;?>
    <div class="logo" style="cursor:pointer;background: url(<?php echo $logo;?>) no-repeat;">
    <a href="/" alt="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a>
    </div>
    <div class="menu-wrapp">
	 <div class="menucat-1">
      <?php echo str_replace("</ul></div>", "", preg_replace("#<div[^>]*><ul[^>]*>#", "", wp_nav_menu(array('theme_location' => 'menu_top','echo' => false)) ));?>
	 </div>
	</div>
	<div class="search_start">
	<!--login-->
     <div class="search_cont" style="width: 90px;">
      <form name="topSearchForm" action="/" method="get">
       <input type="text" name="s" class="in_search" autocomplete="off" value="搜索">
       <input type="submit" class="in_submit">
       <i class="icon-search icon iconfont">&#xe638;</i>
      </form>
     </div>
    </div> 
   </div> 
  </div>
<?php video_script(); ?>