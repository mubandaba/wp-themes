<?php get_template_part( 'header', get_post_format() ); ?>
<?php $options = get_option('mfthemes_options');
	  if( $options['cat_01']){?>
<div class="ggtoptow">
      <div class="ggtleft">
        <?php ad_cat_01();?>
	  </div>
      <div class="ggtright">
        <div class="banner">
          <div class="tophotsp"></div>
          <ul class="banList">
		  <?php $rand_post = get_posts('numberposts=5&orderby=rand');  foreach( $rand_post as $post ) : ?>
            <li class="active">
              <a href="<?php the_permalink(); ?>">
                <img src="<?php attachment_timthumb_src(113,90);?>" title="<?php the_title(); ?>" alt="<?php the_title(); ?>"/></a>
            </li>
          <?php endforeach; ?>
          </ul>
          <div class="fomW">
            <div class="jsNav">
              <a href="javascript:;" class="trigger current"></a>
              <a href="javascript:;" class="trigger"></a>
              <a href="javascript:;" class="trigger"></a>
              <a href="javascript:;" class="trigger"></a>
              <a href="javascript:;" class="trigger"></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script type="text/javascript">$(function() {$(".banner").swBanner();});</script>
<?php }?>
<div class="index_listc" id="load-img">
<div class="longTop"><i class="iconfont" style="margin-right: 5px;">&#xe625;</i>当前位置&#65306;<a href="/">首页</a> &gt; <span style="color: #d54d3f;"><?php single_cat_title(); ?></span></div>
	<div class="pos__1 camWholeBox borderTop">
		<ul class="picpos__1 layout camWholeBoxUl-h">
<?php 
  global $query_string;
  query_posts($query_string.'&showposts=24&caller_get_posts=1'); ?>
    <?php if(have_posts()) : ?>
	<?php while(have_posts()) : the_post(); ?>
          <div class="he_border1 b-w"> 
        <img class="he_border1_img" src="<?php attachment_timthumb_src(291,164);?>" width="291" height="164" alt="<?php the_title(); ?>"> 
        <div class="he_border1_caption">
         <p class="he_border1_caption_p"><?php the_title(); ?></p> 
         <a class="he_border1_caption_a" href="<?php the_permalink(); ?>" target="_blank"></a> 
        </div> 
      </div>
		  <?php endwhile; ?>
	<?php endif; ?>		
		</ul>
	</div>
	<div class="bigpages">
		<div class="piclist__1_1566457851" id="pageNum">
		<span><?php pagenavi();?></span></div>
	</div>
</div>
<?php ad_cat_02();?>
<?php get_template_part( 'footer', get_post_format() ); ?>
