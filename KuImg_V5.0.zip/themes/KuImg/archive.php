<?php 
if ( has_post_format( 'gallery' ) ) {
	get_template_part('cat_gallery' );
} elseif ( has_post_format( 'image' ) ) {
	get_template_part('cat_image' );
} elseif ( has_post_format( 'video' ) ) {
	get_template_part('cat_video' );
} else {
	get_template_part('cat_standard' );
}
?>