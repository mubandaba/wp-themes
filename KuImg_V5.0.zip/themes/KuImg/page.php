<?php get_template_part( 'header', get_post_format() ); ?>
<?php $options = get_option('mfthemes_options');
	  if( $options['cat_01']){?>
<div class="ggtoptow">
      <div class="ggtleft">
        <?php ad_cat_01();?>
	  </div>
      <div class="ggtright">
        <div class="banner">
          <div class="tophotsp"></div>
          <ul class="banList">
		  <?php $rand_post = get_posts('numberposts=5&orderby=rand');  foreach( $rand_post as $post ) : ?>
            <li class="active">
              <a href="<?php the_permalink(); ?>">
                <img src="<?php timthumb_src(113,90);?>" title="<?php the_title(); ?>" alt="<?php the_title(); ?>"/></a>
            </li>
          <?php endforeach; ?>
          </ul>
          <div class="fomW">
            <div class="jsNav">
              <a href="javascript:;" class="trigger current"></a>
              <a href="javascript:;" class="trigger"></a>
              <a href="javascript:;" class="trigger"></a>
              <a href="javascript:;" class="trigger"></a>
              <a href="javascript:;" class="trigger"></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script type="text/javascript">$(function() {$(".banner").swBanner();});</script>
<?php }?>
	  <div class="page-main">
	  <div class="l">
	  <div class="page-left">
	<div class="page-title"><h1><?php wp_title(); ?></h1></div>
	<div class="borderTop">
	<div class="page_meta">
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	发布时间：<?php the_time('Y-m-d H:i:s'); ?><i class="icon iconfont fontico" style="margin-left: 10px;">&#xe622;</i><?php if(function_exists('the_views')) the_views();?>
	</div>
		<div class="page-content">
        <?php the_content('Read more...'); ?>
        <?php endwhile;endif; ?>
		<div class="interact"><?php if(function_exists('mflikes')) mflikes('button');  ?></div>
		</div>
		<div class="xian_790">
		<ul class="related_img">
		<?php $rand_post = get_posts('numberposts=4&orderby=rand');  foreach( $rand_post as $post ) : ?>
		<li class="related_box">
		<div class="r_pic">
		<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" target="_blank">
		<img src="<?php attachment_timthumb_src(205,135);?>" alt="<?php the_title(); ?>">
		</a>
		</div>
		<div class="r_title"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" target="_blank" rel="bookmark"><?php the_title(); ?></a></div>
		</li>
		<?php endforeach; ?>
		</ul>
		</div>
	</div>
</div>
<?php $options = get_option('mfthemes_options');
	  if( $options['changyan_appid']){?>
<div class="comment">
<div class="comment-m">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div id="SOHUCS" sid="<?php the_ID();?>" ></div> 
<script type="text/javascript"> 
(function(){ 
var appid = '<?php echo $options['changyan_appid'];?>'; 
var conf = '<?php echo $options['changyan_appkey'];?>'; 
var width = window.innerWidth || document.documentElement.clientWidth; 
if (width < 960) { 
window.document.write('<script id="changyan_mobile_js" charset="utf-8" type="text/javascript" src="//changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=' + appid + '&conf=' + conf + '"><\/script>'); } else { var loadJs=function(d,a){var c=document.getElementsByTagName("head")[0]||document.head||document.documentElement;var b=document.createElement("script");b.setAttribute("type","text/javascript");b.setAttribute("charset","UTF-8");b.setAttribute("src",d);if(typeof a==="function"){if(window.attachEvent){b.onreadystatechange=function(){var e=b.readyState;if(e==="loaded"||e==="complete"){b.onreadystatechange=null;a()}}}else{b.onload=a}}c.appendChild(b)};loadJs("//changyan.sohu.com/upload/changyan.js",function(){window.changyan.api.config({appid:appid,conf:conf})}); } })(); </script>
<?php endwhile;endif; ?>
</div>
</div>
<?php }?>
</div>
<div class="r">
<div class="page-right">
<div class="page-right-p">
	   <div class="page-right-title"><span class="page-icon"></span>热门推荐</div></div>
	   <div class="page-right-list">
	              <div class="ul-content">
	                <ul class="fade">
					<?php most_viewed_sidebar('post',10); ?>
					</ul>
		          </div>		  
		</div>	
</div>
<?php ad_page_01();?>	
</div>		
</div>
<?php ad_cat_02();?>
<?php get_template_part( 'footer', get_post_format() ); ?>
