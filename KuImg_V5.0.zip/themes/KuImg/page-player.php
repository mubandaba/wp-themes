<?php
/*
Template Name: 隐藏视频地址模板
*/
?>
<?php videourl();?>