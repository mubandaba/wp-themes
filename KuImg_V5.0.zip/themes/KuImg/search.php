<?php get_template_part( 'header', get_post_format() ); ?>
<?php $options = get_option('mfthemes_options');
	  if( $options['cat_01']){?>
<div class="ggtoptow">
      <div class="ggtleft">
        <?php ad_index_01();?>
	  </div>
      <div class="ggtright">
        <div class="banner">
          <div class="tophotsp"></div>
          <ul class="banList">
		  <?php $rand_post = get_posts('numberposts=5&orderby=rand');  foreach( $rand_post as $post ) : ?>
            <li class="active">
              <a href="<?php the_permalink(); ?>">
                <img src="<?php attachment_timthumb_src(113,90);?>" title="<?php the_title(); ?>" alt="<?php the_title(); ?>"/></a>
            </li>
          <?php endforeach; ?>
          </ul>
          <div class="fomW">
            <div class="jsNav">
              <a href="javascript:;" class="trigger current"></a>
              <a href="javascript:;" class="trigger"></a>
              <a href="javascript:;" class="trigger"></a>
              <a href="javascript:;" class="trigger"></a>
              <a href="javascript:;" class="trigger"></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script type="text/javascript">$(function() {$(".banner").swBanner();});</script>
<?php }?>   
<div class="index_listc" id="load-img">
		<div class="longTop b-1-f4f4f4">您现在的位置 &gt; <a href="/">首页</a> &gt; 搜索<?php echo $_GET['s'];?></div>
		<div class="search_nav">
		<div class="search_navcon">
			<form action="/" method="get">
				<div class="search_navleft">
				<input type="text" name="s" autocomplete="off" value="<?php echo $_GET['s'];?>">
				</div>
				<div class="search_navright"><input type="submit" value="搜 索"></div>
			</form>
		</div>
	</div>
	<div class="wtn">
		<div class="search_pu_list">
			<span>排序:</span>
			<ul class="cl">
				<li class="on"><a href="/?s=<?php echo $_GET['s'];?>">最新发布</a></li>
				<li><a href="/?s=<?php echo $_GET['s'];?>&orderby=rand ">随机排序</a></li>
			</ul>
		</div>
		<?php
  $allsearch = new WP_Query("s=$s&showposts=-1");
  $key = wp_specialchars($s, 1);
  $count = $allsearch->post_count;
  wp_reset_query(); ?>
		<div class="search_Position">
			<span class="seartitle">搜索 /</span>
			<p class="searjiguo"><?php echo $_GET['s'];?></p>
			<div class="Position_info_r">
				<p>共找到<span><?php echo $count; ?></span>条相关内容</p>
			</div>
		</div>
		<!-- list -->
	<div class="pos__1 camWholeBox borderTop">
		<ul class="picpos__1 layout camWholeBoxUl">
		<?php 
  global $query_string;
  query_posts($query_string.'&showposts=24&caller_get_posts=1'); ?>
    <?php if(have_posts()) : ?>
    <?php while(have_posts()) : the_post(); ?>
						<li class="min-h-imgall">
				<a href="<?php the_permalink(); ?>" class="itemimg" title="<?php the_title(); ?>" target="_blank">
					<img src="<?php attachment_timthumb_src(196,265);?>" width="196" height="265" alt="<?php the_title(); ?>">
					<?php post_format_vip();?>
					<div class="itemset-num">
                  <span class="text"><?php post_format(); ?></span></div>
				</a>
				<div class="camLiCon">
					<div class="camLiTitleC hot">
						<p><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" target="_blank"><?php the_title(); ?></a></p>
					</div>
					<div class="camLiDes">
						<span class="mr3"><i class="icon iconfont fontico">&#xe673;</i><?php the_time('y/m/d'); ?></span>
						<span class="mr3"><i class="icon iconfont fontico">&#xe622;</i><?php if(function_exists('the_views')) the_views();?></span>
						<span><i class="icon iconfont fontico">&#xe602;</i><?php if(function_exists('mflikes')) mflikes('button1');  ?></span>
					</div>
				</div>
			</li>
			<?php endwhile; ?>
    <?php endif; ?>
					</ul>
	</div>	
<?php if(!have_posts()):?>
<div style="margin-bottom: -100px;width:100%; height:200px; background:url(<?php bloginfo('template_url'); ?>/style/images/null.jpg) no-repeat center;"></div>
<?php endif; ?>
	<div class="bigpages">
		<div class="piclist__1_1566457851" id="pageNum">
		<span><?php pagenavi();?></span></div>
	</div>
</div>
</div>
<?php ad_index_04();?>
<?php get_template_part( 'footer', get_post_format() ); ?>
