<?php get_template_part( 'header', get_post_format() ); ?>
<div class="container mt20">
	<div class="longConWhite">
    	<div class="show_8_1_862 show-topmbx"><i class="iconfont" style="margin-right: 5px;">&#xe625;</i>当前位置&#65306;<a href="/">首页</a> &gt; <?php the_category(' '); ?> > <span style="color: #d54d3f;"><?php the_title(); ?></span></div>
		<?php ad_archive_01();?>
		<div class="swp-tit layout" slide-type="title"><h1><?php the_title(); ?>(<?php echo pic_count(); ?>P)</h1></a></div>
		<?php $i = 1; $w = 1; $q = 1; $e = 1; $r = 1; $t=1;  ?>
		<?php 
		$login_in = get_post_meta($post->ID,"login_in",true);
		if($current_user->roles[0] == 'administrator' || $current_user->roles[0] == 'contributor'||is_user_logged_in() ) {
			$attachments = get_posts(array(
                       'post_parent' => $post->ID,
                       'post_type' => 'attachment',
                       'post_mime_type' => 'image',
                       'orderby' => 'date',
                       'posts_per_page' => -1,
                       'order' => 'ASC'
                       ));
		}
		elseif($login_in =='open'){
			$attachments = get_posts(array(
                       'post_parent' => $post->ID,
                       'post_type' => 'attachment',
                       'post_mime_type' => 'image',
                       'orderby' => 'date',
                       'posts_per_page' => 5,
                       'order' => 'ASC'
                       ));
					   echo "<script> if(confirm( '本图集游客可浏览5张，登录后浏览完整套图！(点击“确定”登录，点击“取消”继续浏览当前图集) '))  location.href='/wp-login.php';</script>";
					   }
		else {
			$attachments = get_posts(array(
                       'post_parent' => $post->ID,
                       'post_type' => 'attachment',
                       'post_mime_type' => 'image',
                       'orderby' => 'date',
                       'posts_per_page' => -1,
                       'order' => 'ASC'
                       ));
		}
        $post_title = get_the_title();
           if ( $attachments ) {
                $output = array();
                foreach ( $attachments as $attachment ) {
                    $imgurl_big = wp_get_attachment_url( $attachment->ID, '' );
		            /*$imgexcerpt = $attachment->post_excerpt;//图片说明*/
		            $imgdescription = $attachment->post_content;
					$desc = get_post_meta($post->ID,"desc",true);
					$options = get_option('mfthemes_options');
					if ( $options['cloud'] =="1" ) {
                    $imgurl_big = $imgurl_big;
                    }
				    elseif ( $options['cloud'] =="2" ) {
                    $imgurl_big = ''.$imgurl_big.'';
                    }
	                else {
		            $imgurl_big = $imgurl_big;
				    }
					if ( empty( $imgdescription ) ) {
                    $desc = $desc;
                    }
				    else {
					$desc = $imgdescription;
				    }
                    array_push($output,'
					{
						"picPos": '.$i++.',
						"bigPic": "'.$imgurl_big.'"},
						');
                }
                $thumb_m = array();
                foreach ( $attachments as $attachment ) {
                    $imgurl = wp_get_attachment_url( $attachment->ID, '' );
					$options = get_option('mfthemes_options');
	            if ( $options['cloud'] =="1" ) {
                    $imgurl_thumb = ''.$imgurl.'?imageView2/1/w/80/q/90/interlace/1';
                }
				elseif ( $options['cloud'] =="2" ) {
                    $imgurl_thumb = ''.$imgurl.'!pximg/fw/80';
                }
	            else {
		            $imgurl_thumb = ''.get_bloginfo('template_directory').'/timthumb.php?src='.$imgurl.'&w=80&s=1';
				}
					array_push($thumb_m,'<li id="tu_'.$r++.'"><span></span>
                                   <a href="javascript:void(0);"><img src="'.$imgurl_thumb.'" alt="'.$post_title.'('.$t++.')"/></a>
					</li>');
                }
				$small = array();
                foreach ( $attachments as $attachment ) {
                    $imgurl = wp_get_attachment_url( $attachment->ID, '' );
	            if ( $options['cloud'] =="1" ) {
                    $thumb = ''.$imgurl.'?imageView2/1/h/160/q/90/interlace/1';
                }
				elseif ( $options['cloud'] =="2" ) {
                    $thumb = ''.$imgurl.'!pximg/fh/160';
                }
	            else {
		            $thumb = ''.get_bloginfo('template_directory').'/timthumb.php?src='.$imgurl.'&h=160&s=1';
				}
                array_push($small,'<li class="swl-item current">
                                   <a href="'.get_permalink().'#!p='.$e++.'" target="_blank"><div class="swi-hd"><img src="'.$thumb.'" alt="'.$post_title.'('.$w++.')"></div></a>
                                   <div class="swi-bd"><h3>第'.$q++.'张</h3></div>
                                   </li>');
                }
            }
        ?>
		<div class="workContentWrapper">
			<div class="swp-tool">
				<div class="swpt-extra">
				<span class="swpt-tip">支持<i></i>键翻阅图片</span>
				<span class="swpt-mode-wrap"><a href="javascript:;" id="showlists" class="swpt-mode swpt-mode-list"><i></i>列表模式</a></span>
				</div>
				<em class="swpt-time" id="time">更新：<?php the_time('Y-m-d'); ?>&nbsp;&nbsp;&nbsp;&nbsp;编辑：<a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a>&nbsp;&nbsp;&nbsp;&nbsp;点击：<span id="hits"><?php if(function_exists('the_views')) the_views();?></span></em>
			</div>
			<div class="show_8_1_862 workShow">
			<div class="indexBody">
  <div class="demo w990">
    <div class="maxPic-box">
    <div class="indexbody-left"></div>
    <div class="indexbody-right"></div>
  <a class="maxBtn-l" href="javascript:void(0);"></a>
  <a class="maxBtn-r" href="javascript:void(0);"></a>
      <div class="maxPic">
        <div class="maxPicBox"><img id="mainPic" src="<?php gallery_first_src(0,0);?>" alt="<?php the_title(); ?>"/></div>
      </div>
    </div>
    <div class="Pic-pageln">
        <span class="lp">可用“←”或“→”方向键快速翻页</span>
        <span class="pic-r-span rp">
            <a href="javascript:void(0);"  class="ico01" id="stop-on"><i class="ins1"></i>已暂停</a>
        </span>
    </div>    
    <div id="tplist" class="w-width clearfix">
      <div class="Up-tuzu">
	    <?php
                    $prev_post = get_previous_post();
                    if (!empty( $prev_post )): ?>
          <a class="outpic" href="<?php echo get_permalink( $prev_post->ID ); ?>" id="prevUrl"><span></span><img src="<?php echo prev_thumbnail_url(100,120); ?>" /></a>
          <a class="inpic" href="<?php echo get_permalink( $prev_post->ID ); ?>">上一组</a><span class="prevspan"></span>
		<?php endif; ?>
      </div>
      
      <div class="bottom-lists l">
        <div class="PicBtn-a PicBtn-a-l"><a class="PicBtn-left" href="javascript:void(0);"></a></div>
        <div class="minPic l">
          <ul class="gallery_demo_unstyled">
            <?php
    foreach($thumb_m as $pic1)
    echo $pic1;
?>
          </ul>
        </div>
        <div class="PicBtn-a PicBtn-a-r"><a class="PicBtn-right" href="javascript:void(0);"></a></div>
      </div>
      
      <div class="Next-tuzu">
	    <?php
                    $next_post = get_next_post();
                    if (!empty( $next_post )): ?>
          <a class="outpic" href="<?php echo get_permalink( $next_post->ID ); ?>" id="nextUrl"><span></span><img src="<?php echo next_thumbnail_url(100,120); ?>"></a>
          <a class="inpic" href="<?php echo get_permalink( $next_post->ID ); ?>">下一组</a>
          <span class="nextspan"></span>
		  <?php endif; ?>
       </div>
    </div>
			<?php 
				$desc = get_post_meta($post->ID,"desc",true);
				if(!empty($desc)) {
			?>
			<div style="border: 1px dotted #dbdbdb;margin:5px;padding: 5px 0;text-align: left;"><h3 style="margin: 0 5px;font-weight: normal;"><b>图集介绍：</b><?php echo get_post_meta($post->ID,"desc",true); ?></h3></div>
			<?php } ?>
			<?php 
				$desc = get_post_meta($post->ID,"desc",true);
				if( empty($desc)) {
			?>
			<div style="border: 1px dotted #dbdbdb;margin:5px;padding: 5px 0;text-align: left;"><h3 style="margin: 0 5px;font-weight: normal;"><b>图集介绍：</b><?php the_title(); ?>推荐，<?php bloginfo('name'); ?>-<?php bloginfo('url'); ?>为你搜集整理提供的最新<?php the_category(' '); ?>，关注更多<?php the_tags('', ' ', '');?>相关图集。</h3></div>
			<?php } ?>
  </div>
</div>
			</div>
		</div>
		<div class="showlists hide">
			<div class="swp-tool b-1-f4f4f4">
				<span class="swpt-mode-wrap showlist_mode"><a href="javascript:;" id="showphotos" class="swpt-mode swpt-mode-hp"><i></i>大图模式</a></span>
				<em class="swpt-time" id="time2"></em>
			</div>
			<ul class="clearfix gallery">				
		<?php
        foreach($small as $pic){
			echo $pic;
        }
        ?>
							</ul>
		</div>
		<div class="workNav layout">
			<div class="workNavRight"><span>图片人气</span><br>
				<b id="biggup"><?php if(function_exists('mflikes')) mflikes('button1');  ?></b>
				<div class="workNavRightPop">
					<table>
						<tbody>
							<tr>
								<td><span class="c999">浏览：</span><span id="hits2"><?php if(function_exists('the_views')) the_views();?></span>次</td>
								<td><span class="c999">点赞：</span><?php if(function_exists('mflikes')) mflikes('button1');  ?>次</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
			<ul class="workNavUl layout">
				<li>
					<a class="tlist" href="javascript:;" onclick="myFavoriteFunc(0,3,1930851)">
						<i class="iconfont download-icon">&#xe60f;</i>
						<span class="rightWn"><b>分享图片</b><br><span>SHARE PHOTOS</span></span>
					</a>
				</li>
				<li class="tags">
					<a class="tlist" href="javascript:;">
						<i class="iconfont download-icon">&#xe626;</i>
						<span class="rightWn"><b>关键字</b><br><span>TAGS</span></span>
					</a>
					<span class="tags-list">
					<?php the_tags('', ' ', '');?></span>
				</li>
				<li class="tags">
					<?php if(function_exists('mflikes')) mflikes('button4');  ?>
				</li>
			</ul>
		</div>
	</div>
</div>
<div class="wrapper1083 show_box_01" id="load-img">
    <?php
		global $post;
		$post_tags = wp_get_post_tags($post->ID);
		if ($post_tags) {
 		   foreach ($post_tags as $tag) {
 		       $tag_list[].= $tag->term_id;
 		   }
  		  $post_tag = $tag_list[mt_rand(0, count($tag_list) - 1) ];
  		  $args = array(
   		     'tag__in' => array($post_tag) ,
  		     'category__not_in' => array(NULL) ,
 		     'post__not_in' => array($post->ID) ,
   		     'showposts' => 6,
   		     'caller_get_posts' => 1
 			  );
  		  query_posts($args);?>
	<div class="lm_name"><i></i><h2>相关推荐</h2></div>
	<div class="show_box_1083"> 
		<div class="box">
			<ul class="showbox">
			<?php if (have_posts()) {while (have_posts()) {the_post();update_post_caches($posts); ?>
			<li class=""><a href="<?php the_permalink(); ?>" target="_blank"><img src="<?php attachment_timthumb_src(190,290);?>" alt="<?php the_title(); ?>"></a><em class="bg"></em>
			<h3 class="txt"><a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a></h3>
			</li>
	        <?php } }?>
			</ul>
		</div>
	</div>
	<?php wp_reset_query(); } else {?>
	<div class="lm_name"><i></i><h2>随机精彩</h2></div>
	<div class="show_box_1083"> 
		<div class="box">
			<ul class="showbox">
			<?php $rand_post = get_posts('numberposts=6&orderby=rand');  foreach( $rand_post as $post ) : ?>
				<li class=""><a href="<?php the_permalink(); ?>" target="_blank"><img src="<?php attachment_timthumb_src(190,290);?>" alt="<?php the_title(); ?>"></a><em class="bg"></em>
				<h3 class="txt"><a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a></h3>
				</li>
			<?php endforeach; ?>
			</ul>
		</div>
	</div>
	<?php } ?>	
</div>
<script type="text/javascript">
$(function(){
	var prevDiv = $(".Up-tuzu");
	var nextDiv = $(".Next-tuzu");
	if(prevDiv.find("a").length<1){
		 prevDiv.html("<p style='line-height:120px;color:#666;'><a href='' id='prevUrl'>没有了</a></p>");
		}
	if(nextDiv.find("a").length<1){
	 nextDiv.html("<p style='line-height:120px;color:#666;'><a href='' id='nextUrl'>没有了</a></p>");
	}
});

var selectKey = "1";
var picList = [
<?php
    foreach($output as $pic)
    echo $pic;
?>
];
</script> 
<?php get_template_part( 'footer', get_post_format() ); ?>