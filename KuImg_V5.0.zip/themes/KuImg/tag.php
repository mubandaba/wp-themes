<?php get_template_part( 'header', get_post_format() ); ?>
<div class="mod-movie-wrap">
    <?php $tag_ids = get_term_meta( $tag_id, '_id_upload',true );
	if(!empty($tag_ids)) {
	?>
	<div class="movie-poster-img" style="background:url('<?php echo $tag_ids; ?>') no-repeat right top;"></div>
	<?php } else{?>
	<div class="movie-poster-img" style="background:url('//img.majidou.com/2017/11/26e86040b5f405b.jpg') no-repeat right top;"></div>
	<?php } ?>
	<div class="movie-mask"></div>
	<div class="mod-movie">
		<h1 class="title-tag">
			<div class="lemmaTitleH1"><span style="vertical-align:middle;font-size:34px;line-height:120%;"><?php echo single_tag_title(); ?></span></div>
		</h1>
		<p class="intro-summary-p"><?php echo get_term_meta( $tag_id, '_id_tinymce',true ); ?></p>
		<p class="intro-p intro-card-p">
			<label>专题编辑</label>
			<span><?php bloginfo('name'); ?></span><span class="text-sep">|</span><span><?php bloginfo('url'); ?></span>
		</p>
		<p class="intro-p intro-card-p">
			<label>更新时间</label>
			<span><?php the_time('Y-m-d'); ?></span>
		</p>
		<p class="intro-p intro-card-p">
			<label>收录内容</label>
			<span><?php echo get_tag_post_count_by_id( $tag_id );?>篇</span>
		</p>
	</div>
</div>
<?php $options = get_option('mfthemes_options');
	  if( $options['index_01']){?>
<div class="ggtoptow">
      <div class="ggtleft">
        <?php ad_cat_01();?>
	  </div>
      <div class="ggtright">
        <div class="banner">
          <div class="tophotsp"></div>
          <ul class="banList">
		  <?php $rand_post = get_posts('numberposts=5&orderby=rand');  foreach( $rand_post as $post ) : ?>
            <li class="active">
              <a href="<?php the_permalink(); ?>">
                <img src="<?php attachment_timthumb_src(113,90);?>" title="<?php the_title(); ?>" alt="<?php the_title(); ?>"/></a>
            </li>
          <?php endforeach; ?>
          </ul>
          <div class="fomW">
            <div class="jsNav">
              <a href="javascript:;" class="trigger current"></a>
              <a href="javascript:;" class="trigger"></a>
              <a href="javascript:;" class="trigger"></a>
              <a href="javascript:;" class="trigger"></a>
              <a href="javascript:;" class="trigger"></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script type="text/javascript">$(function() {$(".banner").swBanner();});</script>
<?php }?> 
<div class="poster-nav"><span class="homes">相关推荐</span><?php wp_tag_cloud('unit=px&smallest=12&largest=12&number=10&order=RAND'); ?></div>
<div class="index_listc" id="load-img">
	<div class="pos__1 camWholeBox borderTop">
		<ul class="picpos__1 layout camWholeBoxUl">
		<?php 
  global $query_string;
  query_posts($query_string.'&showposts=24&caller_get_posts=1'); ?>
    <?php if(have_posts()) : ?>
    <?php while(have_posts()) : the_post(); ?>
						<li class="min-h-imgall">
				<a href="<?php the_permalink(); ?>" class="itemimg" title="<?php the_title(); ?>" target="_blank">
					<img src="<?php attachment_timthumb_src(196,265);?>" width="196" height="265" alt="<?php the_title(); ?>">
					<?php post_format_vip();?>
					<div class="itemset-num">
		            <span class="text"><?php post_format(); ?></span></div>
				  </a>
				<div class="camLiCon">
					<div class="camLiTitleC hot">
						<p><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" target="_blank"><?php the_title(); ?></a></p>
					</div>
					<div class="camLiDes">
						<span class="mr3"><i class="icon iconfont fontico">&#xe673;</i><?php the_time('y/m/d'); ?></span>
						<span class="mr3"><i class="icon iconfont fontico">&#xe622;</i><?php if(function_exists('the_views')) the_views();?></span>
						<span><i class="icon iconfont fontico">&#xe602;</i><?php if(function_exists('mflikes')) mflikes('button1');  ?></span>
					</div>
				</div>
			</li>
			<?php endwhile; ?>
    <?php endif; ?>
					</ul>
	</div>
	<div class="bigpages">
		<div class="piclist__1_1566457851" id="pageNum">
		<span><?php pagenavi();?></span></div>
	</div>
</div>
<?php ad_index_04();?>
<?php get_template_part( 'footer', get_post_format() ); ?>
