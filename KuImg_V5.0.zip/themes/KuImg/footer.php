  <div class="footer">
   <p><a href="/copr" target="_blank" style="margin: 0px 5px;">版权声明</a>|<a href="/about" target="_blank" style="margin: 0px 5px;">关于我们</a>|<a href="/contact" target="_blank" style="margin: 0px 5px;">联系我们</a></p>
   <?php footer();?></div>
  <div id="cbbfixed" style="bottom: 216px;_bottom: 0px;">
   <div class="dingyue"><?php $options = get_option('mfthemes_options');if( $options['email_url']){?><a href="<?php echo $options['email_url'];?>" target="_blank"></a><?php }?> 
    <div class="qqdingyue">RSS订阅</div>
   </div>
    <a id="mweb" href="javascript:void(0);"><span></span><div style="display: none;"></div></a>
    <div class="jianyi"><?php $options = get_option('mfthemes_options');if( $options['email_feed']){?> 
     <a href="//mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=<?php echo $options['email_feed'];?>" target="_blank"></a><?php }?> 
    </div>
  </div>
  <div id="back-to-top" class="back-to-top">
   <a target="_self" href="javascript:void(0);" id="back-to-top-btn">&nbsp;</a>
  </div>
<?php ad_footer_01();?>
<?php wp_footer(); ?>
<?php $options = get_option('mfthemes_options');if( $options['analysis']){?>
  <div style="display: none;">
<?php echo $options['analysis'];?>
  </div><?php }?> 
<?php footercode(); ?>
<?php footer_script(); ?>
 </body>
</html>