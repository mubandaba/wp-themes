<?php get_template_part( 'header', get_post_format() ); ?>
<div class="bg">
	<div class="cont">
		<div class="c1"><img src="<?php bloginfo('template_url'); ?>/style/images/404.jpg" style="margin-top: 30px;margin-left: -20px;"></div>
		<h2>啊哦！页面好像出了点问题，稍后回来。</h2>
		<div class="c2"><a href="/" class="re">返回首页</a><a href="/meinv" class="home">美女图片</a><a href="/" class="sr">查看更多相关信息</a></div>
		<div class="c3">小编提醒您 - 您可能输入了错误的网址，或者该网页已经被删除或者移动。</div>
	</div>
</div>
<?php get_template_part( 'footer', get_post_format() ); ?>
