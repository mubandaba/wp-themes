<?php get_header(); ?>
<?php $options = get_option('mfthemes_options');
	  if( $options['cat_01']){?>
<div class="ggtoptow">
      <div class="ggtleft">
        <?php ad_cat_01();?>
	  </div>
      <div class="ggtright">
        <div class="banner">
          <div class="tophotsp"></div>
          <ul class="banList">
		  <?php $rand_post = get_posts('numberposts=5&orderby=rand');  foreach( $rand_post as $post ) : ?>
            <li class="active">
              <a href="<?php the_permalink(); ?>">
                <img src="<?php attachment_timthumb_src(113,90);?>" title="<?php the_title(); ?>" alt="<?php the_title(); ?>"/></a>
            </li>
          <?php endforeach; ?>
          </ul>
          <div class="fomW">
            <div class="jsNav">
              <a href="javascript:;" class="trigger current"></a>
              <a href="javascript:;" class="trigger"></a>
              <a href="javascript:;" class="trigger"></a>
              <a href="javascript:;" class="trigger"></a>
              <a href="javascript:;" class="trigger"></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script type="text/javascript">$(function() {$(".banner").swBanner();});</script>
<?php }?>
	  <div class="page-main">
	  <div class="l">
	  <div class="page-left">
	  <div class="cat-body">
	  <h3 class="title"><strong>当前分类：<?php single_cat_title(); ?></strong></h3>
	<div class="content-c">
	<?php 
  global $query_string;
  query_posts($query_string.'&showposts=24&caller_get_posts=1'); ?>
    <?php if(have_posts()) : ?>
    <?php while(have_posts()) : the_post(); ?>
<article class="excerpt">
<div class="c-l">
            <a target="_blank" href="<?php the_permalink(); ?>">
			<img src="<?php attachment_timthumb_src(180,130);?>" width="180" height="130" alt="<?php the_title(); ?>" class="thumb"></a>
            </a>
			</div>
			<div class="c-r">
			<h2><a target="_blank" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
            <p><?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 220,"[...]"); ?> </p>
            <footer>
            <time class="new"><i class="icon iconfont fontico">&#xe673;</i><?php the_time('Y-m-d'); ?></span></time>
            <span class="post-views"><i class="icon iconfont fontico">&#xe622;</i><?php if(function_exists('the_views')) the_views();?></span>
             </footer>
			</div>	
            </article>
<?php endwhile; ?>
    <?php endif; ?>
	</div>
	</div>
<div class="bigpages">
		<div class="piclist__1_1566457851" id="pageNum">
		<span><?php pagenavi();?></span></div>
	</div>
</div>	
</div>
<div class="r">
<div class="page-right">
<div class="page-right-p">
	   <div class="page-right-title"><span class="page-icon"></span>热门推荐</div></div>
	   <div class="page-right-list">
	              <div class="ul-content">
	                <ul class="fade">
					<?php most_viewed_sidebar('post',10); ?>
					</ul>
		          </div>		  
		</div>	
</div>
<?php ad_page_01();?>	
</div>		
</div>
<?php ad_cat_02();?>
<?php get_footer(); ?>
