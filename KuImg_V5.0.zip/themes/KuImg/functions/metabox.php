<?php          
$options = array();      
$boxinfo = array('title' => '扩展选项', 'id'=>'ashubox', 'page'=>array('post'), 'context'=>'normal', 'priority'=>'high', 'callback'=>'');         
$options[] = array(      
            "name" => "视频海报（也可直接输入图片链接）",      
            "desc" => "",      
            "id" => "video_poster", 
            "size"=>"34",			
            "std" => "",      
            "button_label"=>'上传图片',      
            "type" => "media"     
            );  			
$options[] = array(      
            "name" => "登录可见",      
            "desc" => "",      
            "id" => "login_in", 			
            "std" => "close",
            "buttons" => array(
            "open"  => "开启",
            "close" => "不开启"),        
            "type" => "radio"     
            ); 			
$options[] = array(      
            "name" => "视频地址",      
            "desc" => "",      
            "id" => "video_url", 
            "size"=>"60",			
            "std" => "",          
            "type" => "text"     
            );    			
$options[] = array(      
            "name" => "图集/视频简介",      
            "desc" => "",      
            "id" => "desc", 
            "media" => 1,      
            "std" => "",      
            "type" => "tinymce"     
            );    	
$new_box = new meta_box($options, $boxinfo);  

//*******独立页面SEO优化开始*****//
$boxinfo = array('title' => 'SEO选项', 'id'=>'taomdbox', 'page'=>array('page'), 'context'=>'normal', 'priority'=>'core', 'callback'=>'');          
$topic[] = array(      
            "name" => "页面关键词:",      
            "desc" => "英文逗号隔开",      
            "id" => "keywords", 
            "size"=>"60",			
            "std" => "",          
            "type" => "text"     
            );			
$topic[] = array(      
            "name" => "页面描述:",      
            "desc" => "",      
            "id" => "description", 
            "size"=>"40",			
            "std" => "",          
            "type" => "textarea"     
            );   			
$new_box = new meta_box($topic, $boxinfo);  
?>