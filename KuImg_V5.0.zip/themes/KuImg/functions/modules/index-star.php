<div class="index-box2" id="load-img">
      <div class="box2 layout">
        <div class="indexTitle t-1-f4f4f4 b-1-f4f4f4 mb10">
          <span class="indexTitleT f20 yh c666">
            <a href="javascript:void(0);" target="_blank">明星模特</a></span>
          <div class="itMore title-tab">
            <a href="javascript:void(0);" class="title_rbt" target="_blank">查看全部</a></div>
        </div>
        <div class="tab-box2">
          <div class="tab-box2-nr layout" style="display:block;">
            <ul class="fn-clear news-list">
              <li>
                <a href="/topic/zhaoliying/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/star/zly.jpg" alt="赵丽颖" />
                  <span class="h2">赵丽颖</span></a>
              </li>
              <li>
                <a href="/topic/tongliya/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/star/tly.jpg" alt="佟丽娅" />
                  <span class="h2">佟丽娅</span></a>
              </li>
              <li>
                <a href="/topic/zhangyou/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/star/zy.jpg" alt="张优" />
                  <span class="h2">张优</span></a>
              </li>
              <li>
                <a href="/topic/zhangmeng/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/star/zm.jpg" alt="张檬" />
                  <span class="h2">张檬</span></a>
              </li>
              <li>
                <a href="/topic/dlrb/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/star/dlrb.jpg" alt="迪丽热巴" />
                  <span class="h2">迪丽热巴</span></a>
              </li>
              <li>
                <a href="/topic/guxinyi/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/star/gxy.jpg" alt="顾欣怡" />
                  <span class="h2">顾欣怡</span></a>
              </li>
              <li>
                <a href="/topic/muyuqian/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/star/myq.jpg" alt="慕羽茜" />
                  <span class="h2">慕羽茜</span></a>
              </li>
              <li>
                <a href="/topic/yuanshanshan/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/star/yss.jpg" alt="袁姗姗" />
                  <span class="h2">袁姗姗</span></a>
              </li>
              <li>
                <a href="/topic/mqmy/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/star/mqmy.jpg" alt="母其弥雅" />
                  <span class="h2">母其弥雅</span></a>
              </li>
              <li>
                <a href="/topic/liuyihan/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/star/lyh.jpg" alt="刘一含" />
                  <span class="h2">刘一含</span></a>
              </li>
              <li>
                <a href="/topic/jiaqing/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/star/jq.jpg" alt="贾青" />
                  <span class="h2">贾青</span></a>
              </li>
              <li>
                <a href="/topic/ambxed/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/star/amb.jpg" alt="艾梅柏·希尔德" />
                  <span class="h2">艾梅柏·希尔德</span></a>
              </li>
              <li>
                <a href="/topic/liuyouqi/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/star/lyq.jpg" alt="柳侑绮" />
                  <span class="h2">柳侑绮</span></a>
              </li>
              <li>
                <a href="/topic/wangruier/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/star/wre.jpg" alt="王瑞儿" />
                  <span class="h2">王瑞儿</span></a>
              </li>
              <li>
                <a href="/topic/chenyiman/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/star/cym.jpg" alt="陈怡曼" />
                  <span class="h2">陈怡曼</span></a>
              </li>
              <li>
                <a href="/topic/ganlu/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/star/gl.jpg" alt="甘露" />
                  <span class="h2">甘露</span></a>
              </li>
              <li>
                <a href="/topic/yuji/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/star/yj.jpg" alt="于姬una" />
                  <span class="h2">于姬una</span></a>
              </li>
              <li>
                <a href="/topic/liufeier/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/star/lfe.jpg" alt="刘飞儿" />
                  <span class="h2">刘飞儿</span></a>
              </li>
              <li>
                <a href="/topic/chenrouxi/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/star/crx.jpg" alt="陈柔希" />
                  <span class="h2">陈柔希</span></a>
              </li>
              <li>
                <a href="/topic/daixinni/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/star/dxl.jpg" alt="黛欣霓" />
                  <span class="h2">黛欣霓</span></a>
              </li>
              <li>
                <a href="/topic/liushishi/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/star/lss.jpg" alt="刘诗诗" />
                  <span class="h2">刘诗诗</span></a>
              </li>
              <li>
                <a href="/topic/yangmi/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/star/ym.jpg" alt="杨幂" />
                  <span class="h2">杨幂</span></a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>