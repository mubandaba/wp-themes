<div class="index-box2" id="JS-news">
      <div class="box2 layout">
        <div class="indexTitle b-1-f4f4f4 mb20" data-unuse="1">
          <span class="indexTitleT f20 yh c666">
            <a href="javascript:void(0);" target="_blank">美女专辑</a></span>
          <div class="itMore title-tab" data-unuse="1">
            <a href="javascript:;" class="title_rbt" target="_blank">美女大类</a>
            <a href="javascript:;" class="title_rbt" target="_blank">地域分布</a>
            <a href="javascript:;" class="title_rbt" target="_blank">身材体征</a>
            <a href="javascript:;" class="title_rbt" target="_blank">着装类型</a>
            <a href="javascript:;" class="title_rbt" target="_blank">特定场景</a>
            <a href="javascript:;" class="title_rbt" target="_blank">类型&机构</a></div>
        </div>
        <div class="tab-box2">
          <div class="tab-box2-nr news1 layout" style="display:block;">
            <ul class="fn-clear news-list" id="list1">
              <li>
                <a href="/topic/xiaoqingxinmeinv/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/xqx.jpg" alt="小清新美女" />
                  <span class="h2">小清新美女</span></a>
              </li>
              <li>
                <a href="/topic/feizhuliumeinv/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/fzl.jpg" alt="非主流美女" />
                  <span class="h2">非主流美女</span></a>
              </li>
              <li>
                <a href="/topic/mingxing/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/mx.jpg" alt="明星" />
                  <span class="h2">明星</span></a>
              </li>
              <li>
                <a href="/topic/mengmeizitu/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/mmz.jpg" alt="萌妹子图" />
                  <span class="h2">萌妹子图</span></a>
              </li>
              <li>
                <a href="/topic/siwameinv/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/sw.jpg" alt="丝袜美女" />
                  <span class="h2">丝袜美女</span></a>
              </li>
              <li>
                <a href="/topic/meinvchemo/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/cm.jpg" alt="美女车模" />
                  <span class="h2">美女车模</span></a>
              </li>
              <li>
                <a href="/topic/zhifumeinv/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/zf.jpg" alt="制服美女" />
                  <span class="h2">制服美女</span></a>
              </li>
              <li>
                <a href="/topic/qingchunmeinv/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/qc.jpg" alt="清纯美女" />
                  <span class="h2">清纯美女</span></a>
              </li>
              <li>
                <a href="/topic/youwu/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/yw.jpg" alt="尤物" />
                  <span class="h2">尤物</span></a>
              </li>
              <li>
                <a href="/topic/gaoqingmeinv/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/gq.jpg" alt="高清美女" />
                  <span class="h2">高清美女</span></a>
              </li>
              <li>
                <a href="/topic/xingganmeinv/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/xg.jpg" alt="性感美女" />
                  <span class="h2">性感美女</span></a>
              </li>
            </ul>
          </div>
          <div class="tab-box2-nr news2 layout" style="">
            <ul class="fn-clear news-list" id="list2">
              <li>
                <a href="/topic/eluosimeinv/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/els.jpg" alt="俄罗斯美女" />
                  <span class="h2">俄罗斯美女</span></a>
              </li>
              <li>
                <a href="/topic/hunxuemeinv/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/hx.jpg" alt="混血美女" />
                  <span class="h2">混血美女</span></a>
              </li>
              <li>
                <a href="/topic/taiguomeinv/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/tg.jpg" alt="泰国美女" />
                  <span class="h2">泰国美女</span></a>
              </li>
              <li>
                <a href="/topic/taiwanmei/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/tw.jpg" alt="台湾妹" />
                  <span class="h2">台湾妹</span></a>
              </li>
              <li>
                <a href="/topic/oumeimeinv/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/om.jpg" alt="欧美美女" />
                  <span class="h2">欧美美女</span></a>
              </li>
              <li>
                <a href="/topic/hanguomeinv/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/hg.jpg" alt="韩国美女" />
                  <span class="h2">韩国美女</span></a>
              </li>
              <li>
                <a href="/topic/xiaohua/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/xh.jpg" alt="校花" />
                  <span class="h2">校花</span></a>
              </li>
              <li>
                <a href="/topic/ribenmeinv/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/rb.jpg" alt="日本美女" />
                  <span class="h2">日本美女</span></a>
              </li>
            </ul>
          </div>
          <div class="tab-box2-nr news3 layout" style="">
            <ul class="fn-clear news-list" id="list3">
              <li>
                <a href="/topic/dapigu/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/dpg.jpg" alt="大屁股" />
                  <span class="h2">大屁股</span></a>
              </li>
              <li>
                <a href="/topic/rugou/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/rg.jpg" alt="乳沟" />
                  <span class="h2">乳沟</span></a>
              </li>
              <li>
                <a href="/topic/changfa/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/cf.jpg" alt="长发" />
                  <span class="h2">长发</span></a>
              </li>
              <li>
                <a href="/topic/meitun/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/mt.jpg" alt="美臀" />
                  <span class="h2">美臀</span></a>
              </li>
              <li>
                <a href="/topic/duanfa/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/df.jpg" alt="短发" />
                  <span class="h2">短发</span></a>
              </li>
              <li>
                <a href="/topic/qiaotun/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/qt.jpg" alt="翘臀" />
                  <span class="h2">翘臀</span></a>
              </li>
              <li>
                <a href="/topic/meixiong/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/meix.jpg" alt="美胸" />
                  <span class="h2">美胸</span></a>
              </li>
              <li>
                <a href="/topic/gugan/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/gg.jpg" alt="骨感" />
                  <span class="h2">骨感</span></a>
              </li>
              <li>
                <a href="/topic/changtui/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/ct.jpg" alt="长腿" />
                  <span class="h2">长腿</span></a>
              </li>
              <li>
                <a href="/topic/meitui/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/meit.jpg" alt="美腿" />
                  <span class="h2">美腿</span></a>
              </li>
            </ul>
          </div>
          <div class="tab-box2-nr news4 layout" style="">
            <ul class="fn-clear news-list" id="list4">
              <li>
                <a href="/topic/shuiyi/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/sy.jpg" alt="睡衣" />
                  <span class="h2">睡衣</span></a>
              </li>
              <li>
                <a href="/topic/duanku/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/dk.jpg" alt="短裤" />
                  <span class="h2">短裤</span></a>
              </li>
              <li>
                <a href="/topic/dingziku/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/dzk.jpg" alt="丁字裤" />
                  <span class="h2">丁字裤</span></a>
              </li>
              <li>
                <a href="/topic/qingqu/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/qq.jpg" alt="情趣" />
                  <span class="h2">情趣</span></a>
              </li>
              <li>
                <a href="/topic/niuzaiku/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/nzk.jpg" alt="牛仔裤" />
                  <span class="h2">牛仔裤</span></a>
              </li>
              <li>
                <a href="/topic/jinshen/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/js.jpg" alt="紧身" />
                  <span class="h2">紧身</span></a>
              </li>
              <li>
                <a href="/topic/duanqun/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/dq.jpg" alt="短裙" />
                  <span class="h2">短裙</span></a>
              </li>
              <li>
                <a href="/topic/neiyi/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/ny.jpg" alt="内衣" />
                  <span class="h2">内衣</span></a>
              </li>
              <li>
                <a href="/topic/gaogen/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/gaog.jpg" alt="高跟" />
                  <span class="h2">高跟</span></a>
              </li>
              <li>
                <a href="/topic/changqun/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/lyq.jpg" alt="长裙" />
                  <span class="h2">长裙</span></a>
              </li>
              <li>
                <a href="/topic/bijini/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/bjn.jpg" alt="比基尼" />
                  <span class="h2">比基尼</span></a>
              </li>
            </ul>
          </div>
          <div class="tab-box2-nr news5 layout" style="">
            <ul class="fn-clear news-list" id="list5">
              <li>
                <a href="/topic/huwai/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/hw.jpg" alt="户外" />
                  <span class="h2">户外</span></a>
              </li>
              <li>
                <a href="/topic/haibian/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/hb.jpg" alt="海边" />
                  <span class="h2">海边</span></a>
              </li>
              <li>
                <a href="/topic/zipai/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/zp.jpg" alt="自拍" />
                  <span class="h2">自拍</span></a>
              </li>
              <li>
                <a href="/topic/shenghuozhao/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/shz.jpg" alt="生活照" />
                  <span class="h2">生活照</span></a>
              </li>
              <li>
                <a href="/topic/yushi/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/ys.jpg" alt="浴室" />
                  <span class="h2">浴室</span></a>
              </li>
              <li>
                <a href="/topic/yongchi/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/yc.jpg" alt="泳池" />
                  <span class="h2">泳池</span></a>
              </li>
              <li>
                <a href="/topic/shatan/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/st.jpg" alt="沙滩" />
                  <span class="h2">沙滩</span></a>
              </li>
              <li>
                <a href="/topic/sifangzhao/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/sfz.jpg" alt="私房照" />
                  <span class="h2">私房照</span></a>
              </li>
              <li>
                <a href="/topic/jiepai/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/jp.jpg" alt="街拍" />
                  <span class="h2">街拍</span></a>
              </li>
            </ul>
          </div>
          <div class="tab-box2-nr news6 layout" style="">
            <ul class="fn-clear news-list" id="list6">
              <li>
                <a href="/topic/shaofu/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/sf.jpg" alt="少妇" />
                  <span class="h2">少妇</span></a>
              </li>
              <li>
                <a href="/topic/xueshengmei/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/xsm.jpg" alt="学生妹" />
                  <span class="h2">学生妹</span></a>
              </li>
              <li>
                <a href="/topic/heibai/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/heib.jpg" alt="黑白" />
                  <span class="h2">黑白</span></a>
              </li>
              <li>
                <a href="/topic/cosplay/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/cos.jpg" alt="cosplay" />
                  <span class="h2">cosplay</span></a>
              </li>
              <li>
                <a href="/topic/shishen/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/ss.jpg" alt="湿身" />
                  <span class="h2">湿身</span></a>
              </li>
              <li>
                <a href="/topic/meishaonv/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/msn.jpg" alt="美少女" />
                  <span class="h2">美少女</span></a>
              </li>
              <li>
                <a href="/topic/nvshen/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/ns.jpg" alt="女神" />
                  <span class="h2">女神</span></a>
              </li>
              <li>
                <a href="/topic/nenmo/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/nm.jpg" alt="嫩模" />
                  <span class="h2">嫩模</span></a>
              </li>
              <li>
                <a href="/topic/dmmn/" class="imgitem">
                  <img src="<?php bloginfo('template_url'); ?>/style/ico/topic/ecy.jpg" alt="二次元美女" />
                  <span class="h2">二次元美女</span></a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>