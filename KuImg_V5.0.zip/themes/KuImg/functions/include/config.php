<?php
$ashu_feild = array();
$taxonomy_cof = array('category','post_tag');

$ashu_feild[] = array(
  'name'        => '标签封面',
  'id'          => '_id_upload',
  'desc'        => '上传/填写图片地址，用于在标签页面显示的封面图片（1250x420）。',
  'std'         => '',
  'button_text' => '上传',
  'edit_only'   => true,
  'type'        => 'upload'
);

$ashu_feild[] = array(
  'name'  => '标签描述',
  'id'    => '_id_tinymce',
  'desc'  => '',
  'std'   => '',
  'media' => 1,
  'type'  => 'tinymce'
);
$ashuwp_termmeta_feild = new ashuwp_termmeta_feild($ashu_feild, $taxonomy_cof);
?>