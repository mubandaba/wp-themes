<?php
/**
 * KuImg core theme functions
 *
 *
 * @package KuImg
 * @author MctDs
 * @url //www.dz9.net
 */
 
//新建预制页面
add_action( 'after_setup_theme', 'themes_init' ); 
function themes_init(){
	$array = array('new','rand','player');
	foreach($array as $value){
		// A new page
		$newpage_template = 'page-'.$value.'.php';
		$newpage_check = get_page_by_title($value);
		$newpage_page = array(
			'post_type' => 'page',
			'post_title' => $value,
			'post_status' => 'publish',
			'post_author' => 1,
		);
		if(!isset($newpage_check->ID)){
			$newpage_id = wp_insert_post($newpage_page);
			update_post_meta($newpage_id, '_wp_page_template', $newpage_template);
		}
	}
}

//首页960X90广告
function ad_index_01(){
	$options = get_option('mfthemes_options');
	if( $options['index_01']){?>
			<?php echo $options['index_01'];?>
	<?php }
}

//首页1083x90广告
function ad_index_02(){
	$options = get_option('mfthemes_options');
	if( $options['index_02']){?>
	<div style="width:1083px; height:90px; margin:10px auto 0;">
			<?php echo $options['index_02'];?></div>
	<?php }
}

//首页中部1083x90广告（左右双拼）
function ad_index_03(){
	$options = get_option('mfthemes_options');
	if( $options['index_03']){?>
    <div class="ggbottow">
      <div class="left">
        <?php echo $options['index_03'];?></div>
      <div class="right">
        <?php echo $options['index_04'];?></div>
    </div>
	<?php }
}

//首页底部1083x90广告（左右双拼）
function ad_index_04(){
	$options = get_option('mfthemes_options');
	if( $options['index_05']){?>
    <div class="ggbottow">
      <div class="left">
        <?php echo $options['index_05'];?></div>
      <div class="right">
        <?php echo $options['index_06'];?></div>
    </div>
	<?php }
}

//分类页960x90广告
function ad_cat_01(){
	$options = get_option('mfthemes_options');
	if( $options['cat_01']){?>
    <?php echo $options['cat_01'];?>
	<?php }
}

//分类页1083x90广告（左右双拼）
function ad_cat_02(){
	$options = get_option('mfthemes_options');
	if( $options['cat_02']){?>
    <div class="ggbottow">
      <div class="left">
        <?php echo $options['cat_02'];?></div>
      <div class="right">
        <?php echo $options['cat_03'];?></div>
    </div>
	<?php }
}

//默认单页250x250广告
function ad_page_01(){
	$options = get_option('mfthemes_options');
	if( $options['page_01']){?>
	<div class="page-right">
    <div class="page-right-p">
    <?php echo $options['page_01'];?>
	</div>
	</div>
	<?php }
}

//内容页960x90广告
function ad_archive_01(){
	$options = get_option('mfthemes_options');
	if( $options['archive_01']){?>
    <div style="width:960px; height:90px; margin:30px auto 0;"><?php echo $options['archive_01'];?></div>
	<?php }
}

//底部广告
function ad_footer_01(){
	$options = get_option('mfthemes_options');
	if( $options['footer_01']){?>
    <?php echo $options['footer_01'];?>
	<?php }
}

//页头代码
function headcode(){
	$options = get_option('mfthemes_options');
	if( $options['headcode']){?>
<?php echo $options['headcode'];?>
<?php }
}

//页脚代码
function footercode(){
	$options = get_option('mfthemes_options');
	if( $options['footercode']){?>
<?php echo $options['footercode'];?>
<?php }
}

//首页幻灯片
function slider_content() { 
	$options = get_option('mfthemes_options');
	$filmstrip = $options['filmstrip'];
	$cnt = count($filmstrip['src']);
	if( $cnt>0){
		$film = '';
		for($i=0;$i<$cnt;$i++){
			//var_dump($src);
			$src = $filmstrip["src"][$i];
			$t = $filmstrip["title"][$i];
			$href = $filmstrip["href"][$i];
			if($src!=""){
				$film .= "<li class=\"txt_top\"><a href=\"$href\"><img src=\"$src\" width=\"1083\" height=\"400\" alt=\"$t\"/><div class=\"txtshow\">$t</div></a></li>";
			}
		}
		
	?>
            <?php echo $film;?>
	<?php }
}

//视频内容判断用户角色
function vid_player() {
	$options = get_option('mfthemes_options');
	if ( $options['videoad'] =="pre" ) {
         $video_ads = 'pre';
                }
	elseif ( $options['videoad'] =="post" ) {
         $video_ads = 'post';
                }	
	elseif ( $options['videoad'] =="mid" ) {
         $video_ads = $options['adtime'];
                }	
    $video_xml = $options['video_xml'];				
	global $current_user, $post, $posts;
	$playlist = get_post_meta($post->ID,"playlist",true);
	$id = get_the_ID();
	$file = '/player?id='.$id.'';
	$image = get_post_meta($post->ID,"video_poster",true);
	$login_in = get_post_meta($post->ID,"login_in",true);
	if( $current_user->roles[0] == 'administrator' || $current_user->roles[0] == 'contributor') {	
	    $player .= "<div class='playArea' id='myElement'><script type='text/javascript'>jwplayer('myElement').setup({playlist:'".$playlist."',file:'".$file."',image:'".$image."',})</script></div>";
    }
	elseif( is_user_logged_in() ) {
		$player .= "<div class='playArea' id='myElement'><script type='text/javascript'>jwplayer('myElement').setup({playlist:'".$playlist."',file:'".$file."',image:'".$image."',advertising:{client: 'vast',schedule: {'myAds':{'offset':'".$video_ads."','tag':'".$video_xml."'}}}})</script></div>";
		}
	elseif($login_in =='open'){
		$player .= '<div class="playArea" id="myElement">
		            <script type="text/javascript">
		            var temp = 1;
		            $(function() {
		            var playerInstance = jwplayer("myElement");
		            playerInstance.setup({
		            file:"'.$file.'",
		            image:"'.$image.'",
		            });
		            playerInstance.on("time",function(obj){
		            var time = obj.position;
		            var v1 = parseFloat(time.toFixed(0));
		            if(v1 > 10 && temp ==1){
		            playerInstance.seek(10);
		            }
		            var v2 = parseFloat("10");
		            if(v1 == v2){
		            if(temp == 1){
		            playerInstance.pause();
		            $("#myModal").addClass("is-visible")
		            $(".cd-user-modal").find("#cd-login").addClass("is-selected");
		            $(".cd-user-modal").find("#cd-signup").removeClass("is-selected");
		            $(".cd-switcher").children("li").eq(0).children("a").addClass("selected");
		            $(".cd-switcher").children("li").eq(1).children("a").removeClass("selected");
		            }
		            }
		            });
		            playerInstance.on("playAttempt",function(){
		            //alert("非登录用户可预览5秒，点击确定开始播放.");
		            });
		            });
		            </script>
					</div>';
		}
	else {
		$player .= "<div class='playArea' id='myElement'><script type='text/javascript'>jwplayer('myElement').setup({playlist:'".$playlist."',file:'".$file."',image:'".$image."',advertising: {client:'vast',schedule: {'myAds':{'offset':'".$video_ads."','tag':'".$video_xml."'}}}})</script></div>";
		}
	/*else {
		$player .='你当前没有权限观看！请先<a href="/wp-login.php" target="_blank"><font color="red">登录</font></a>/<a href="/wp-login.php?action=register" target="_blank"><font color="red">注册</font></a>';
	}*/
	echo $player;
}

//文章类型
function post_format() { 
    if ( has_post_format( 'image' ) ) {
	$pic_text = 单图;
	}
    elseif ( has_post_format( 'gallery' ) ) {
    $pic_text = 图集;
    }
	elseif ( has_post_format( 'video' ) ) {
	$pic_text = 视频;
	}
	else {
	$pic_text = 资讯;
    }
	echo $pic_text;
}

//VIP角标
function post_format_vip() { 
    global $current_user, $post, $posts;
    $login_in = get_post_meta($post->ID,"login_in",true);
    if($login_in =='open'){
	$pic_vip = 'VIP';
	$output .='<div class="itemset-num-vip">
                <span class="text">'.$pic_vip.'</span>
				</div>';
	}
	
    echo $output;
}

//缩略图
function timthumb_src($w='',$h=''){
  global $post, $posts;
  $first_img = '';
  ob_start();
  ob_end_clean();
  $dir_url = get_bloginfo('template_url');
  $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
  $first_img = $matches [1] [0];
  if(empty($first_img)){ 
  $first_img = "$dir_url/style/images/default.jpg";
  }
  $video_poster = get_post_meta($post->ID,"video_poster",true);
				if ( empty( $video_poster ) ) {
                    $video_poster = $first_img;
                }
	$options = get_option('mfthemes_options');
	if ( $options['cloud'] =="1" ) {
         $thumb = ''.$video_poster.'?imageView2/1/w/'.$w.'/h/'.$h.'/q/90/format/jpg/interlace/1';
                }
	elseif ( $options['cloud'] =="2" ) {
         $thumb = ''.$video_poster.'!pximg/both/'.$w.'x'.$h.'';
                }			
	else {
		 $thumb = ''.$dir_url.'/timthumb.php?src='.$video_poster.'&w='.$w.'&h='.$h.'&s=1';
				}
	echo $thumb;
}

//附件缩略图
function attachment_timthumb_src($w='',$h=''){
global $post, $posts;
ob_start();
ob_end_clean();
$attachments = get_posts(array(
                       'post_parent' => $post->ID,
                       'post_type' => 'attachment',
                       'post_mime_type' => 'image',
                       'orderby' => 'date',
                       'posts_per_page' => 1,
                       'order' => 'ASC'
                       ));
foreach ( $attachments as $attachment ) {
                    $imgurl_big = wp_get_attachment_url( $attachment->ID, '' );
                }
  $dir_url = get_bloginfo('template_url');
  $first_img = $imgurl_big;
  if(empty($first_img)){ 
  $first_img = "$dir_url/style/images/default.jpg";
  }
  $video_poster = get_post_meta($post->ID,"video_poster",true);
				if ( empty( $video_poster ) ) {
                    $video_poster = $first_img;
                }
	$options = get_option('mfthemes_options');
	if ( $options['cloud'] =="1" ) {
         $thumb = ''.$video_poster.'?imageView2/1/w/'.$w.'/h/'.$h.'/q/90/format/jpg/interlace/1';
                }
	elseif ( $options['cloud'] =="2" ) {
         $thumb = ''.$video_poster.'!pximg/both/'.$w.'x'.$h.'';
                }			
	else {
		 $thumb = ''.$dir_url.'/timthumb.php?src='.$video_poster.'&w='.$w.'&h='.$h.'&s=1';
				}
	echo $thumb;
}

//瀑布流自适应缩略图
function index_timthumb_src($h=''){
global $post, $posts;
ob_start();
ob_end_clean();
$attachments = get_posts(array(
                       'post_parent' => $post->ID,
                       'post_type' => 'attachment',
                       'post_mime_type' => 'image',
                       'orderby' => 'date',
                       'posts_per_page' => 1,
                       'order' => 'ASC'
                       ));
foreach ( $attachments as $attachment ) {
                    $imgurl_big = wp_get_attachment_url( $attachment->ID, '' );
                }
  $dir_url = get_bloginfo('template_url');
  $first_img = $imgurl_big;
  $title = get_the_title();
  $permalink = get_the_permalink();
  if(empty($first_img)){ 
  $first_img = "$dir_url/style/images/default.jpg";
  }
  $video_poster = get_post_meta($post->ID,"video_poster",true);
				if ( empty( $video_poster ) ) {
                    $video_poster = $first_img;
                }
	$options = get_option('mfthemes_options');
	if ( $options['cloud'] =="1" ) {
         $thumb = ''.$video_poster.'?imageView2/1/w/'.$w.'/h/'.$h.'/q/90/format/jpg/interlace/1';
                }
	elseif ( $options['cloud'] =="2" ) {
         $thumb = ''.$video_poster.'!pximg/fh/'.$h.'';
                }			
	else {
		 $thumb = ''.$dir_url.'/timthumb.php?src='.$video_poster.'&h='.$h.'&s=1';
				}			
	list($width,$height) = getimagesize($thumb);
	$thumb_index .= ' <div class="he_border1 item" data-w="'.$width.'" data-h="'.$height.'">
      <img class="he_border1_img" src="'.$thumb.'" alt="'.$title.'"> 
      <div class="he_border1_caption"> 
       <p class="he_border1_caption_p">'.$title.'</p> 
       <a class="he_border1_caption_a" href="'.$permalink.'" target="_blank"></a> 
      </div> 
     </div>';
	echo $thumb_index;
} 

//图集首图
function gallery_first_src($w='',$h=''){
global $post, $posts;
ob_start();
ob_end_clean();
$attachments = get_posts(array(
                       'post_parent' => $post->ID,
                       'post_type' => 'attachment',
                       'post_mime_type' => 'image',
                       'orderby' => 'date',
                       'posts_per_page' => 1,
                       'order' => 'ASC'
                       ));
foreach ( $attachments as $attachment ) {
                    $imgurl_big = wp_get_attachment_url( $attachment->ID, '' );
                }
echo $imgurl_big;
}

//隐藏视频地址
function videourl() {
global $page, $post, $posts;
$id = intval($_REQUEST['id']);	
$url = get_post_meta($id,"video_url",true);
$arr_tit = array(
    $id => $url,
    );
$ids = intval($_REQUEST['id']);	
Header( "Location: $arr_tit[$ids]" );
exit();
}
?>