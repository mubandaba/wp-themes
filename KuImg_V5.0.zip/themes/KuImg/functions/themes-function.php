﻿<?php
/*********************/
/*                   */
/*  Version : 5.1.0  */
/*  Author  : RM     */
/*  Comment : 071223 */
/*                   */
/*********************/

define( "THEME_NAME", "KuImg" );
add_theme_support( "post-formats", array('gallery','video','image') );
get_template_part( "functions/themes-plugin" );
get_template_part( "functions/themes-script" );
get_template_part( "functions/themes-meta" );
get_template_part( "functions/themes-pagenavi" );
if ( !is_admin( ) )
{
		get_template_part( "functions/themes-login" );
		get_template_part( "functions/forms/login/login-form" );
		get_template_part( "functions/forms/login/login-process" );
		get_template_part( "functions/forms/register/register-form" );
		get_template_part( "functions/forms/register/register-process" );
		get_template_part( "functions/forms/forgot-password/forgot-password-form" );
}
else
{
		get_template_part( "functions/themes-admin" );
}
add_custom_background( );
add_theme_support( "automatic-feed-links" );
if ( function_exists( "register_nav_menus" ) )
{
		register_nav_menus( array( "menu_top" => "菜单" ) );
}
add_filter( "wp_nav_menu_objects", KuImg_menu );

function KuImg_menu( $items )
{
		foreach ( $items as $item )
		{
				if ( hassub( $item->ID, $items ) )
				{
						$item->classes[] = "menu-parent-item";
				}
		}
		return $items;
}

function hasSub( $menu_item_id, $items )
{
		foreach ( $items as $item )
		{
				if ( !$item->menu_item_parent && !( $item->menu_item_parent == $menu_item_id ) )
				{
						continue;
				}
				return TRUE;
		}
		return FALSE;
}

/**
 * 发布文章前提示选择分类
 */
add_action('admin_footer-post.php', 'choose_a_category_before_publish');
add_action('admin_footer-post-new.php', 'choose_a_category_before_publish');
function choose_a_category_before_publish(){
	global $post_type;
	if($post_type=='post'){
		echo "<script>
jQuery(function($){
	$('#publish, #save-post').click(function(e){
		if($('#taxonomy-category input:checked').length==0){
			alert('你还没有选择分类哦，请先选择一个分类！');
			e.stopImmediatePropagation();
			return false;
		}else{
			return true;
		}
	});
	var publish_click_events = $('#publish').data('events').click;
	if(publish_click_events){
		if(publish_click_events.length>1){
			publish_click_events.unshift(publish_click_events.pop());
		}
	}
	if($('#save-post').data('events') != null){
		var save_click_events = $('#save-post').data('events').click;
		if(save_click_events){
		  if(save_click_events.length>1){
			  save_click_events.unshift(save_click_events.pop());
		  }
		}
	}
});
</script>";
	}
}

function footer(){
$options = get_option('mfthemes_options');
if( $options['footer']){?>
<p><?php echo $options['footer'];?>. <?php echo $options['beian_id'];?>. Theme By <a href="//www.dz9.net/" title="多姿-关注互联网">多姿</a></p><?php }else{?>
<p>Copyright &copy; 2016-<?php echo date("Y");?> <a href="<?php bloginfo('url'); ?>" target="_blank" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a> All Rights Reserved. <?php echo $options['beian_id'];?>.Theme By <a href="//www.dz9.net/" target="_blank" title="多姿-关注互联网">多姿</a></br>声明：部分资源来自互联网，图片版权归原作者所有，若有侵权/违规请将链接发送至邮箱 <?php echo $options['email_feed'];?>，我们会在24小时内删除！</p><?php }
}