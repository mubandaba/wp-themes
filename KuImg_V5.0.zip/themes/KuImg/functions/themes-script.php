<?php
//页头脚本
function head_script(){
$options = get_option('mfthemes_options');
$template_url = get_bloginfo('template_url');
if( $options['cloud_url']){
	$script_url = $options['cloud_url'];
} else {
	$script_url = $template_url;
}
{ ?>
<link rel="stylesheet" type="text/css" href="<?php echo $script_url; ?>/style/css/main.css"/>
 <link rel="stylesheet" type="text/css" href="<?php echo $script_url; ?>/style/css/iconfont.css">
 <script type="text/javascript" src="<?php echo $script_url; ?>/style/js/jquery.min.js"></script>
 <script type="text/javascript" src="<?php echo $script_url; ?>/style/js/superslide.2.1.js"></script>
<?php } if ( has_post_format( 'gallery' ) || has_post_format( 'image' ) && is_single() ) { ?>
 <link rel="stylesheet" type="text/css" href="<?php echo $script_url; ?>/style/css/picture.css">
<?php }
}	

//视频模板脚本
function video_script(){
$options = get_option('mfthemes_options');
$template_url = get_bloginfo('template_url');
if( $options['cloud_url']){
	$script_url = $options['cloud_url'];
} else {
	$script_url = $template_url;
}
if ( is_single() && has_post_format( 'video' ) ) { ?>
<script>window.pluginPath="<?php echo $script_url; ?>/player/jwplayer";</script>
<script type="text/javascript" src="<?php echo $script_url; ?>/player/player.js"></script>
<script>jwplayer.key="3j4EQ9zmS/iPdjdjraidj+bLZjnilvVo05wngw==";</script>
<?php  if (is_user_logged_in()){ ?>
<?php } else{?>
<link rel="stylesheet" type="text/css" href="<?php echo $script_url; ?>/style/login/style.css" />
<script src="<?php echo $script_url; ?>/style/login/main.js"></script>
<div class="cd-user-modal" id="myModal" tabindex="-1" role="dialog"> 
		<div class="cd-user-modal-container">
			<ul class="cd-switcher">
				<li><a href="#0">用户登录</a></li>
				<li><a href="#0">注册新用户</a></li>
			</ul>
			<div id="cd-login">
			<p style="color:red;padding: 10px 0 0 30px;font-size: 16px;">本视频游客可试看10秒，登陆后观看完整版~！</p>
				<form class="cd-form" action="<?php echo get_option('home'); ?>/wp-login.php" method="post">
					<p class="fieldset">
						<label class="image-replace cd-username" for="log">用户名</label>
						<input class="full-width has-padding has-border" name="log" id="log" value="<?php echo wp_specialchars(stripslashes($user_login), 1) ?>" type="text" placeholder="输入用户名">
					</p>

					<p class="fieldset">
						<label class="image-replace cd-password" for="pwd">密码</label>
						<input class="full-width has-padding has-border" name="pwd" id="pwd" type="password"  placeholder="输入密码">
					</p>

					<p class="fieldset">
						<input type="checkbox" name="rememberme" id="rememberme" value="forever" checked="checked" />
						<label for="remember-me">记住登录状态</label>
					</p>

					<p class="fieldset">
						<input class="full-width2" type="submit" name="submit" value="登 录">
					</p>
					<input type="hidden" name="redirect_to" value="<?php echo $_SERVER['REQUEST_URI']; ?>" />
				</form>
			</div>

			<div id="cd-signup">
				<form class="cd-form" action="<?php echo get_option('home'); ?>/wp-login.php?action=register" method="post">
					<p class="fieldset">
						<label class="image-replace cd-username" for="your_username">用户名</label>
						<input class="full-width has-padding has-border" name="your_username" id="your_username" tabindex="1" value="<?php if (isset($posted['your_username'])) echo $posted['your_username']; ?>" type="text" placeholder="输入用户名">
					</p>

					<p class="fieldset">
						<label class="image-replace cd-email" for="your_email">邮箱</label>
						<input class="full-width has-padding has-border" name="your_email" id="your_email" tabindex="2" value="<?php if (isset($posted['your_email'])) echo $posted['your_email']; ?>" type="email" placeholder="输入mail">
					</p>

					<p class="fieldset">
						<label class="image-replace cd-password" for="your_password">密码</label>
						<input class="full-width has-padding has-border" name="your_password" id="your_password" tabindex="3" value="" type="password"  placeholder="密码长度至少8位">
					</p>
					<p class="fieldset">
						<label class="image-replace cd-password" for="your_password_2"></label>
						<input class="full-width has-padding has-border" name="your_password_2" id="your_password_2" tabindex="4" value="" type="password"  placeholder="再次输入密码">
					</p>
					<p class="fieldset">
					    <img id="captcha_img" src="<?php echo get_template_directory_uri();?>/functions/forms/register/captcha/captcha.php" title="看不清楚？ 点击更换" alt="看不清楚？ 点击更换" onclick="document.getElementById('captcha_img').src='<?php echo get_template_directory_uri();?>/functions/forms/register/captcha/captcha.php?'+Math.random();document.getElementById('CAPTCHA').focus();return false;" />
					<a href="javascript:void(0)" onclick="document.getElementById('captcha_img').src='<?php echo get_template_directory_uri();?>/functions/forms/register/captcha/captcha.php?'+Math.random();document.getElementById('captcha').focus();return false;"><span>点击更换</span></a>
					<label for="captcha"></label>
					<input id="captcha" class="captcha" type="text" tabindex="5" value="" name="captcha_code" placeholder="输入验证码"/>
					</p>

					<p class="fieldset">
						<input class="full-width2" type="submit" name="register" value="注册新用户">
					</p>
				</form>
			</div>
		</div>
	</div> 
	<?php } ?>
	<?php }
}

//页脚脚本
function footer_script(){
$options = get_option('mfthemes_options');
$template_url = get_bloginfo('template_url');
if( $options['cloud_url']){
	$script_url = $options['cloud_url'];
} else {
	$script_url = $template_url;
}
{ ?>
  <script type="text/javascript" src="<?php echo $script_url; ?>/style/js/IE6Top.js"></script>
  <script type="text/javascript" src="<?php echo $script_url; ?>/style/js/picbase.js"></script>
<?php } if ( has_post_format( 'gallery' ) || has_post_format( 'image' ) && is_single() ) { ?>
  <script type="text/javascript" src="<?php echo $script_url; ?>/style/js/picture.js"></script> 
<?php }
}	
?>