<?php
require get_template_directory() . '/functions/include/wp_framework_core.php'; //必须 加载核心类
require get_template_directory() . '/functions/include/wp_options_feild.php'; //可选 设置页面
require get_template_directory() . '/functions/include/wp_termmeta_feild.php'; //可选 分类字段
require get_template_directory() . '/functions/include/wp_postmeta_feild.php'; //可选 文字字段
require get_template_directory() . '/functions/include/config.php'; //配置文件-按需配置
?>