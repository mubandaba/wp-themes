<?php

function mfthemes_login_form( $action = '', $redirect = '' ) {

	global $posted;
	
	if (!$action) $action = site_url('wp-login.php');
	if (!$redirect) $redirect =  get_admin_url();
	?>
	<div style="margin-top:5px; margin-left:auto; margin-right:auto; width:900px;">
	<form action="<?php echo $action; ?>" method="post" class="account_form">
				<div class="item">
					<label class="wx" for="login_username">用户名&#58;</label>
					<input type="text" class="text" name="log" id="login_username" tabindex="1" value="<?php if (isset($_POST['log'])) echo $_POST['log']; ?>" />
				</div>
				<div class="item">
					<label class="wx" for="login_password">密码&#58;</label>
					<input type="password" class="text" name="pwd" id="login_password" tabindex="2" value="" />
				</div>
				
				<?php if( $_SESSION["trytimes"] > 3) {?>
					<div class="item">
						<div class="captcha clx">
						<label>验证码&#58;</label>
						
						<img id="captcha_img" src="<?php echo get_template_directory_uri();?>/functions/forms/register/captcha/captcha.php" title="看不清楚？ 点击更换" alt="看不清楚？ 点击更换" onclick="document.getElementById('captcha_img').src='<?php echo get_template_directory_uri();?>/functions/forms/register/captcha/captcha.php?'+Math.random();document.getElementById('CAPTCHA').focus();return false;" style="border: #cdcdcd 1px solid;padding-left: 5px; " />
						<a href="javascript:void(0)" onclick="document.getElementById('captcha_img').src='<?php echo get_template_directory_uri();?>/functions/forms/register/captcha/captcha.php?'+Math.random();document.getElementById('captcha').focus();return false;"><span>点击更换</span></a>
						</div><label for="captcha"></label><input id="captcha" class="text" type="text" tabindex="5" value="" name="captcha_code" />
					</div>
				<?php }?>
				<div class="item">
					<input type="submit" class="btn" name="login" value="登录" />
					<a href="<?php echo site_url('wp-login.php?action=lostpassword', 'login') ?>">忘记密码？</a>
					<?php if ( get_option('users_can_register') ) : ; ?>
					<a href="<?php echo site_url('wp-login.php?action=register', 'register') ?>">立即注册</a>
					<?php endif; ?>
				</div>
				<input type="hidden" name="redirect_to" value="<?php echo $redirect; ?>" />
	</form>
</div>
<?php
}
?>