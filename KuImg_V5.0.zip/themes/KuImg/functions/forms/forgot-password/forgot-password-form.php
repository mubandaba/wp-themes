<?php
/**
 * JobRoller Forgot Password Form
 * Function outputs the forgotten password form
 *
 *
 * @version 1.0
 * @author AppThemes
 * @package JobRoller
 * @copyright 2010 all rights reserved
 *
 */

function mfthemes_forgot_password_form() {
	?>
	<div style="margin-top:5px; margin-left:auto; margin-right:auto; width:900px;">
    <p>请输入用户名或者邮箱, 一个新的密码将会发送到你的邮箱。</p>
    <form action="<?php echo site_url('wp-login.php?action=lostpassword', 'login_post') ?>" method="post" class="main_form">
		<div class="item">
			<label for="your_username">用户名/邮箱</label>
			<input type="text" class="text" name="user_login" id="login_username" />
		</div>
		<div class="item">
			<label></label>
			<?php do_action('lostpassword_form'); ?><input type="submit" class="btn" name="login" value="获取新密码" />
		</div>
    </form>
	</div>
	<?php
}