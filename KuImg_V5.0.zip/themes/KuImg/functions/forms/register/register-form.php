<?php
/**
 * JobRoller Registration Form
 * Function outputs the registration form
 *
 *
 * @version 1.0
 * @author AppThemes
 * @package JobRoller
 * @copyright 2010 all rights reserved
 *
 */

function mfthemes_register_form( $action = '', $role = 'job_lister' ) {
	
    global $posted;

    if ( get_option('users_can_register') ) :

        if (!$action) $action = site_url('wp-login.php?action=register');
    ?>
<div style="margin-top:5px; margin-left:auto; margin-right:auto; width:900px;">
            <form action="<?php echo $action; ?>" method="post" class="account_form">
				
				<div class="item">
					<label for="your_username">*用户名&#58;</label>
					<input type="text" class="text" name="your_username" id="your_username" tabindex="1" value="<?php if (isset($posted['your_username'])) echo $posted['your_username']; ?>" /><br /><span>登录用户名，只能由数字和字母组成</span>
				</div>
				<div class="item">
					<label for="your_email">*Email&#58;</label>
					<input type="email" class="text" name="your_email" id="your_email" tabindex="2" value="<?php if (isset($posted['your_email'])) echo $posted['your_email']; ?>" />
				</div>
				<?php if(function_exists('ashuwp_invitation_code_form')) ashuwp_invitation_code_form();?>
				<div class="item">
					<label for="your_password">*密码&#58;</label>
					<input type="password" class="text" name="your_password" id="your_password" tabindex="3" value="" /><br /><span>密码长度至少8位</span>
				</div>
				<div class="item">
					<label for="your_password_2"></label>
					<input type="password" class="text" name="your_password_2" id="your_password_2" tabindex="4" value="" /><br /><span>再次输入密码</span>
				</div>
				<div class="item">
					<div class="captcha clx">
					<label>*验证码&#58;</label>
					
					<img id="captcha_img" src="<?php echo get_template_directory_uri();?>/functions/forms/register/captcha/captcha.php" title="看不清楚？ 点击更换" alt="看不清楚？ 点击更换" onclick="document.getElementById('captcha_img').src='<?php echo get_template_directory_uri();?>/functions/forms/register/captcha/captcha.php?'+Math.random();document.getElementById('CAPTCHA').focus();return false;" style="border: #cdcdcd 1px solid; padding-left: 5px;" />
					<a href="javascript:void(0)" onclick="document.getElementById('captcha_img').src='<?php echo get_template_directory_uri();?>/functions/forms/register/captcha/captcha.php?'+Math.random();document.getElementById('captcha').focus();return false;"><span>点击更换</span></a>
					</div><label for="captcha"></label><input id="captcha" class="text" type="text" tabindex="5" value="" name="captcha_code" />
				</div>
				<div class="item">
					<input type="submit" class="btn" tabindex="6" name="register" value="注册" />
					<a href="<?php echo site_url('wp-login.php?action=login', 'login') ?>">立即登录</a>
				</div>

            </form>
			</div>
<?php endif; ?>

<?php } ?>