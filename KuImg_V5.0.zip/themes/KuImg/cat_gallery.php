<?php get_template_part( 'header', get_post_format() ); ?>
<?php $options = get_option('mfthemes_options');
	  if( $options['cat_01']){?>
<div class="ggtoptow">
      <div class="ggtleft">
        <?php ad_cat_01();?>
	  </div>
      <div class="ggtright">
        <div class="banner">
          <div class="tophotsp"></div>
          <ul class="banList">
		  <?php $rand_post = get_posts('numberposts=5&orderby=rand');  foreach( $rand_post as $post ) : ?>
            <li class="active">
              <a href="<?php the_permalink(); ?>">
                <img src="<?php attachment_timthumb_src(113,90);?>" title="<?php the_title(); ?>" alt="<?php the_title(); ?>"/></a>
            </li>
          <?php endforeach; ?>
          </ul>
          <div class="fomW">
            <div class="jsNav">
              <a href="javascript:;" class="trigger current"></a>
              <a href="javascript:;" class="trigger"></a>
              <a href="javascript:;" class="trigger"></a>
              <a href="javascript:;" class="trigger"></a>
              <a href="javascript:;" class="trigger"></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script type="text/javascript">$(function() {$(".banner").swBanner();});</script>
<?php }?>
<div class="index_listc" id="load-img">
<div class="longTop"><i class="iconfont" style="margin-right: 5px;">&#xe625;</i>当前位置&#65306;<a href="/">首页</a> &gt; <span style="color: #d54d3f;"><?php single_cat_title(); ?></span></div>
	<div class="pos__1 camWholeBox borderTop">
		<ul class="picpos__1 layout camWholeBoxUl">		
<?php 
  global $query_string;
  query_posts($query_string.'&showposts=24&caller_get_posts=1'); ?>
    <?php if(have_posts()) : ?>
    <?php while(have_posts()) : the_post(); ?>
						<li class="min-h-imgall">
				<a href="<?php the_permalink(); ?>" class="itemimg" title="<?php the_title(); ?>" target="_blank">
					<img src="<?php attachment_timthumb_src(181,265);?>" width="181" height="265" alt="<?php the_title(); ?>">
					<?php post_format_vip();?><div class="itemset-num"><span class="num"><?php echo pic_count(); ?></span><span class="text">张</span></div></a>
				<div class="camLiCon">
					<div class="camLiTitleC hot">
						<p><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" target="_blank"><?php the_title(); ?></a></p>
					</div>
					<div class="camLiDes">
						<span class="mr3"><i class="icon iconfont fontico">&#xe673;</i><?php the_time('y/m/d'); ?></span>
						<span class="mr3"><i class="icon iconfont fontico">&#xe622;</i><?php if(function_exists('the_views')) the_views();?></span>
						<span><i class="icon iconfont fontico">&#xe602;</i><?php if(function_exists('mflikes')) mflikes('button1');  ?></span>
					</div>
				</div>
			</li>
			<?php endwhile; ?>
    <?php endif; ?>
					</ul>
	</div>
	<div class="bigpages">
		<div class="piclist__1_1566457851" id="pageNum">
		<span><?php pagenavi();?></span></div>
	</div>
</div>
<?php ad_cat_02();?>
<?php get_template_part( 'footer', get_post_format() ); ?>
