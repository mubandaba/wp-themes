<?php 
if ( has_post_format( 'gallery' ) ) {
	get_template_part('single_gallery' );
} elseif ( has_post_format( 'image' ) ) {
	get_template_part('single_image' );
} elseif ( has_post_format( 'video' ) ) {
	get_template_part('single_video' );
} else {
	get_template_part('single_standard' );
}
?>