<?php get_template_part( 'header', get_post_format() ); ?>
<div class="container mt20">
	<div class="longConWhite">
    	<div class="show_8_1_862 show-topmbx"><i class="iconfont" style="margin-right: 5px;">&#xe625;</i>当前位置&#65306;<a href="/">首页</a> &gt; <?php the_category(' '); ?> > <span style="color: #d54d3f;"><?php the_title(); ?></span></div>
		<div class="swp-tit layout" slide-type="title"><h1><?php the_title(); ?></h1></a></div>
		<div class="workContentWrapper">
			<div class="swp-tool">
				<em class="swpt-time" id="time">更新：<?php the_time('Y-m-d'); ?>&nbsp;&nbsp;&nbsp;&nbsp;编辑：<a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a>&nbsp;&nbsp;&nbsp;&nbsp;点击：<span id="hits"><?php if(function_exists('the_views')) the_views();?></span></em>
			</div>
			<div class="show_8_1_862">
			<div class="play">
			<div class="play1" id="bglink"></div>
			<div class="play2">
			<?php $video_embed = get_post_meta($post->ID,"video_url",true);
			if(!empty($video_embed)) {
			?>
			<?php vid_player();?>
			<?php } else{?>
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<div class="playArea" id="myElement">
			<?php the_content('Read more...'); ?>
			</div>
			<?php endwhile;endif; ?>
			<?php } ?>
			</div>
	        </div>
			</div>
		</div>
		<div class="workNav layout">
			<div class="workNavRight"><span>视频人气</span><br>
				<b id="biggup"><?php if(function_exists('mflikes')) mflikes('button1');  ?></b>
				<div class="workNavRightPop">
					<table>
						<tbody>
							<tr>
								<td><span class="c999">浏览：</span><span id="hits2"><?php if(function_exists('the_views')) the_views();?></span>次</td>
								<td><span class="c999">点赞：</span><?php if(function_exists('mflikes')) mflikes('button1');  ?>次</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
			<ul class="workNavUl layout">
				<li>
					<a class="tlist" href="javascript:;" onclick="myFavoriteFunc(0,3,1930851)">
						<i class="iconfont download-icon">&#xe60f;</i>
						<span class="rightWn"><b>分享视频</b><br><span>SHARE VIDEOS</span></span>
					</a>
				</li>
				<li class="tags">
					<a class="tlist" href="javascript:;" onclick="feedBackWindow(1930851,3)">
						<i class="iconfont download-icon">&#xe626;</i>
						<span class="rightWn"><b>关键字</b><br><span>TAGS</span></span>
					</a>
					<span class="tags-list">
					<?php the_tags('', ' ', '');?></span>
				</li>
				<li class="tags">
					<?php if(function_exists('mflikes')) mflikes('button4');  ?>
				</li>
			</ul>
		</div>
	</div>
</div>
<script type="text/javascript">
$(document).ready(function() {
	jQuery.jqtab = function(tabtit,tab_conbox,shijian) {
		$(tab_conbox).find("li").hide();
		$(tabtit).find("li:first").addClass("thistab").show(); 
		$(tab_conbox).find("li:first").show();
	
		$(tabtit).find("li").bind(shijian,function(){
		  $(this).addClass("thistab").siblings("li").removeClass("thistab"); 
			var activeindex = $(tabtit).find("li").index(this);
			$(tab_conbox).children().eq(activeindex).show().siblings().hide();
			return false;
		});
	
	};
	$.jqtab("#tabs","#tab_conbox","click");
	$.jqtab("#tabs2","#tab_conbox2","mouseenter");
	
});
</script>
<div id="tabbox">
    <ul class="tabs" id="tabs2">
       <li><a href="javascript:void(0);">正在热播</a></li>
       <li><a href="javascript:void(0);">视频信息</a></li>
    </ul>
    <ul class="tab_conbox" id="tab_conbox2">
        <li class="tab_con">
         <div class="F">
<a target="_blank" href="javascript:void(0)" title="<?php the_title(); ?>">
<img src="<?php attachment_timthumb_src(156,100);?>" width="156px" height="100px" border="0" alt="<?php the_title(); ?>" style="display: inline;">
<div class="mt6">
          <?php the_title(); ?></div>
</a>
<span class="ico-playing"></span>
</div>
<div class="FT">
相关视频
</div>
<div class="L">
<?php $category = get_the_category();
$cat = $category[0]->cat_ID; 
?>
<?php $rand_post = get_posts("numberposts=6&orderby=rand&cat={$cat}");  foreach( $rand_post as $post ) : ?>
  <a target="_blank" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
  <img src="<?php attachment_timthumb_src(153,100);?>" width="153px" height="100px" border="0" alt="<?php the_title(); ?>" style="display: inline;">
  <div class="mt7">
          <?php the_title(); ?></div>
  </a>
<?php endforeach; ?>
</div>
        </li> 
        <li class="tab_con">		
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	    <?php 
			$desc = get_post_meta($post->ID,"desc",true);
			if(!empty($desc)) {
			?>
        	<p><?php echo get_post_meta($post->ID,"desc",true); ?></p>
        </li>
		<?php } ?>
	    <?php endwhile;endif; ?>
    </ul>    
</div>
<div class="wrapper1083 show_box_01" id="load-img">
	<div class="lm_name"><i></i><h2>随机精彩</h2></div>
	<div class="show_box_1083"> 
		<div class="box">
			<ul class="showbox">
			<?php $rand_post = get_posts('numberposts=6&orderby=rand');  foreach( $rand_post as $post ) : ?>
				<li class=""><a href="<?php the_permalink(); ?>" target="_blank"><img src="<?php attachment_timthumb_src(190,290);?>" alt="<?php the_title(); ?>"></a><em class="bg"></em>
				<h3 class="txt"><a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a></h3>
				</li>
				<?php endforeach; ?>
									</ul>
		</div>
	</div>
</div>
<?php get_template_part( 'footer', get_post_format() ); ?>