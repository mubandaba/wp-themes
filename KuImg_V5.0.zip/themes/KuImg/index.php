<?php get_template_part( 'header', get_post_format() ); ?>
<?php $options = get_option('mfthemes_options');?>
<?php if( $options['index_bg']){?>
  <div class="w100 TopBgHD re" style="background-image:url(<?php echo $options['index_bg'];?>)">
<?php } else {?>
  <div class="w100 TopBgHD re" style="background-image:url(https://img.pximg.com/static/style/images/bg.jpg)">
<?php } ?>
   <div class="TopBgHD_SearchBox">
	<form action="/">
	 <input type="text" name="s" autocomplete="off" class="searchTxt" placeholder="搜索你喜欢的">
	 <input type="submit" class="searchBtn" value="搜索">
	</form>
   </div>
  </div>
<?php list($one, $two, $three, $four) = explode(',', $options['cat_id']);?>
  <div class="tags_listc">
   <div class="clearfix">
    <div class="mod-channel">
     <div class="channel-ctn">
      <div class="left">
	   <div class="xxmt-left">
        <ul class="clearfix">
		<?php wp_tag_cloud('unit=px&smallest=12&largest=12&number=20&order=RAND'); ?> 
		</ul>
       </div>
	  </div>
	  <div class="middle pic">
      <div class="mod-rep-img-cat" style="width:215px;height:306px;top:0;left:0;">
       <a href="<?php echo $options['index_tag']['href'][0];?>" target="_blank" class="cover"><img class="img" src="<?php echo $options['index_tag']['src'][0];?>" width="215" height="306"><span class="desc"><span class="title_tag"><?php echo $options['index_tag']['title'][0];?></span></span></a>
      </div>
      <div class="mod-rep-img-cat" style="width:142px;height:142px;top:0;left:220px;">
	   <a href="<?php echo $options['index_tag']['href'][1];?>" target="_blank" class="cover"><img class="img" src="<?php echo $options['index_tag']['src'][1];?>" width="142" height="142"><span class="desc"><span class="title_tag"><?php echo $options['index_tag']['title'][1];?></span></span></a>
      </div>
      <div class="mod-rep-img-cat" style="width:142px;height:142px;top:0;left:367px;">
       <a href="<?php echo $options['index_tag']['href'][2];?>" target="_blank" class="cover"><img class="img" src="<?php echo $options['index_tag']['src'][2];?>" width="142" height="142"><span class="desc"><span class="title_tag"><?php echo $options['index_tag']['title'][2];?></span></span></a>
      </div>
      <div class="mod-rep-img-cat" style="width:142px;height:142px;top:0;left:514px;">
       <a href="<?php echo $options['index_tag']['href'][3];?>" target="_blank" class="cover"><img class="img" src="<?php echo $options['index_tag']['src'][3];?>" width="142" height="142"><span class="desc"><span class="title_tag"><?php echo $options['index_tag']['title'][3];?></span></span></a>
      </div>
      <div class="mod-rep-img-cat" style="width:142px;height:159px;top:147px;left:220px;">
       <a href="<?php echo $options['index_tag']['href'][4];?>" target="_blank" class="cover"><img class="img" src="<?php echo $options['index_tag']['src'][4];?>" width="142" height="159"><span class="desc"><span class="title_tag"><?php echo $options['index_tag']['title'][4];?></span></span></a>
      </div>
      <div class="mod-rep-img-cat" style="width:289px;height:159px;top:147px;left:367px;">
       <a href="<?php echo $options['index_tag']['href'][5];?>" target="_blank" class="cover"><img class="img" src="<?php echo $options['index_tag']['src'][5];?>"  width="289" height="159"><span class="desc"><span class="title_tag"><?php echo $options['index_tag']['title'][5];?></span></span></a>
      </div>
      </div>
	  </div>
    </div>
    <div class="sut_lbtC_rnowc box_div">
     <div style="overflow:hidden; border-bottom:1px solid #eee;">
       <div class="sut_mxbt_L sut_btimg1">
	    <a href="/new" target="_blank">最新更新</a>
	   </div>
     </div>
     <dl class="sliderbox" id="slider2"><?php $rand_post = get_posts('numberposts=9');  foreach( $rand_post as $post ) : ?> 
      <dt class="open">
       <span class="title"><a target="_blank" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></span>
	   <span class="date"><?php the_time('m-d'); ?></span>
      </dt><?php endforeach; ?> 
     </dl>
    </div>
   </div>
  </div><?php $posts = query_posts($query_string . "&cat={$one}" ); ?> 
  <div class="index_listc" id="<?php echo $one; ?>">
   <div class="indexTitle" data-unuse="1">
    <span class="indexTitleT f20 yh c666"><a href="<?php echo get_category_link($one); ?>" target="_blank"><?php single_cat_title(); ?></a></span>
	<div class="itMore" data-unuse="1">
	 <a href="<?php echo get_category_link($one); ?>" class="imgitem" target="_blank">MORE+</a>
	</div>
   </div>
   <ul class="layout camWholeBoxUl"><?php $q = 1; ?><?php $posts = query_posts($query_string . "&cat={$one}&orderby=date&showposts=7" ); ?> 
    <div class="ts-i-l"><?php while(have_posts()) : the_post(); ?><?php if($q < 2) { ?> 
     <p id="<?php echo($q++); ?>"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" target="_blank"><?php the_title(); ?></a></p><?php } else { ?> 
      <li id="<?php echo($q++); ?>"><span></span><a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a></li><?php } ?><?php endwhile;?> 
	</div><?php $w = 1; ?><?php $posts = query_posts($query_string . "&cat={$one}&orderby=date&showposts=7&offset=7" ); ?> 
    <div class="ts-i-r"><?php while(have_posts()) : the_post(); ?><?php if($w < 2) { ?> 
     <dl style="width: 230px;height: 326px;" id="<?php echo($w++); ?>">
      <dd>
	   <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" target="_blank"><img src="<?php echo attachment_timthumb_src(230,322);?>" alt="<?php the_title(); ?>" style="width: 230px;height: 322px;"></a></dd>
      <dt>
       <a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a>
      </dt>
     </dl><?php } else { ?> 
     <dl id="<?php echo($w++); ?>">
      <dd><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" target="_blank"><img src="<?php echo attachment_timthumb_src(205,158);?>" alt="<?php the_title(); ?>"></a></dd>
      <dt>
       <a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a>
      </dt>
     </dl><?php } ?><?php endwhile;?> 
    </div>
   </ul>
  </div><?php $posts = query_posts($query_string . "&cat={$two}&orderby=date&showposts=8" ); ?> 
  <div class="index-box2" id="<?php echo $two; ?>">
   <div class="box2 layout">
    <div class="indexTitle t-1-f4f4f4">
     <span class="indexTitleT f20 yh c666">
      <a href="<?php echo get_category_link($two); ?>" target="_blank"><?php single_cat_title(); ?></a></span>
     <div class="itMore title-tab">
      <a href="<?php echo get_category_link($two); ?>" class="title_rbt" target="_blank">MORE+</a>
	 </div>
    </div>
    <div class="camWholeBox-h borderTop">
     <ul class="layout camWholeBoxUl-h"><?php while(have_posts()) : the_post(); ?> 
      <li><a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title(); ?>"><span class="img"><img src="<?php attachment_timthumb_src(291,164);?>" alt="<?php the_title(); ?>"><span class="video-ico-index iconfont">&#xe618;</span><?php post_format_vip();?><span class="bg"></span></span></a></li><?php endwhile; ?> 
     </ul>
    </div>
   </div>
  </div><?php $posts = query_posts($query_string . "&cat={$three}&orderby=date&showposts=12" ); ?> 
  <div class="index-box2" id="<?php echo $three; ?>">
   <div class="box2 layout">
    <div class="indexTitle t-1-f4f4f4">
     <span class="indexTitleT f20 yh c666"><a href="<?php echo get_category_link($three); ?>" target="_blank"><?php single_cat_title(); ?></a></span>
     <div class="itMore title-tab">
      <a href="<?php echo get_category_link($three); ?>" class="title_rbt" target="_blank">MORE+</a>
	 </div>
    </div>
    <div class="camWholeBox borderTop">
     <ul class="layout camWholeBoxUl"><?php while(have_posts()) : the_post(); ?> 
      <li><a href="<?php the_permalink(); ?>" class="itemimg" title="<?php the_title(); ?>" target="_blank"><img src="<?php attachment_timthumb_src(181,265);?>" width="181" height="265" alt="<?php the_title(); ?>"><?php post_format_vip();?> 
       <div class="itemset-num">
        <span class="num"><?php echo pic_count(); ?></span><span class="text">张</span>
	   </div></a>
       <div class="camLiCon">
        <div class="camLiTitleC hot">
         <p><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" target="_blank"><?php the_title(); ?></a></p>
        </div>
        <div class="camLiDes">
         <span class="mr3"><i class="icon iconfont fontico">&#xe673;</i><?php the_time('y/m/d'); ?></span>
         <span class="mr3"><i class="icon iconfont fontico">&#xe622;</i><?php if(function_exists('the_views')) the_views();?></span>
         <span><i class="icon iconfont fontico">&#xe602;</i><?php if(function_exists('mflikes')) mflikes('button1');  ?></span>
        </div>
       </div></li><?php endwhile; ?> 
     </ul>
    </div>
   </div>
  </div><?php ad_index_03();?><?php $posts = query_posts($query_string . "cat={$four}&orderby=date&showposts=8" ); ?> 
  <div class="index-box2" id="<?php echo $four; ?>">
   <div class="box2 layout">
    <div class="indexTitle t-1-f4f4f4">
     <span class="indexTitleT f20 yh c666">
      <a href="<?php echo get_category_link($four); ?>" target="_blank"><?php single_cat_title(); ?></a></span>
     <div class="itMore title-tab">
      <a href="<?php echo get_category_link($four); ?>" class="title_rbt" target="_blank">MORE+</a>
	 </div>
    </div>
    <div class="camWholeBox-h borderTop">
     <ul class="layout camWholeBoxUl-h"><?php while(have_posts()) : the_post(); ?> 
      <div class="he_border1 b-w"> 
        <img class="he_border1_img" src="<?php attachment_timthumb_src(291,164);?>" width="291" height="164" alt="<?php the_title(); ?>"> 
        <div class="he_border1_caption">
         <p class="he_border1_caption_p"><?php the_title(); ?></p> 
         <a class="he_border1_caption_a" href="<?php the_permalink(); ?>" target="_blank"></a> 
        </div> 
      </div><?php endwhile; ?> 
     </ul>
    </div>
   </div>
  </div>
  <div class="wrapper1083 ofHidden cm_block05" id="load-img">
   <div class="indexTitle bottbox" data-unuse="1">
	<span class="indexTitleT f20 yh c666" style="border-bottom:none">月度排行榜</span>
	<div class="itMore" data-unuse="1">
	 <a href="" class="c000 imgitem" target="_blank">查看全部</a>
	</div>
   </div>
   <div class="box">
    <dl style="border-right: 1px dashed #ccc;">
	 <dt><?php echo get_cat_name($one); ?>排行榜</dt>
	 <?php most_viewed_30(array($one), 'post', 10 ,0,30); ?></dl>
	<dl style="border-right: 1px dashed #ccc;">			  
	 <dt><?php echo get_cat_name($two); ?>排行榜</dt>
	 <?php most_viewed_30(array($two), 'post', 10 ,0,30); ?></dl>
	<dl style="border-right: 1px dashed #ccc;">
	 <dt><?php echo get_cat_name($three); ?>排行榜</dt>
	 <?php most_viewed_30(array($three), 'post', 10 ,0,30); ?></dl>
	<dl>
	 <dt><?php echo get_cat_name($four); ?>排行榜</dt>
	 <?php most_viewed_30(array($four), 'post', 10 ,0,30); ?></dl>
   </div>
  </div>
<?php ad_index_04();?>
  <div class="wrapper1083 back_fff ofHidden">
   <div class="indexTitle b-1-f4f4f4 t-1-f4f4f4">
    <span class="indexTitleT f20 yh c666">合作伙伴</span><?php if( $options['email']){?>
   <div style="" class="itMore" data-unuse="1">相关合作请联系邮箱：<?php echo $options['email'];?> </div><?php }?> 
   </div>
   <div class="links layout">
	<?php wp_list_bookmarks('orderby=link_id&categorize=0&title_li='); ?>
   </div>
  </div>
<?php get_template_part( 'footer', get_post_format() ); ?>