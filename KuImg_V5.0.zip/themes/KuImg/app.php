<?php
/*
Template Name: APP下载
*/
?>
<?php get_header(); ?>
<div class="section1">
		<div class="section1-con posr">
			<a href="javascript:;" class="ios-download iepng posa" rel="nofollow"></a>
			<a href="//www.pximg.com/wp-content/uploads/2016/11/pximg_V1.0.apk" title="Android" class="android-download download sprite iepng posa" rel="nofollow"></a>
		</div>
	</div>
<?php get_footer(); ?>
