<?php
/*
Template Name: 最新发布
*/
?>
<?php get_template_part( 'header', get_post_format() ); ?>
<div class="position">
    <div class="wrapper">
    <div class="palce"><i class="iconfont">&#xe6cd;</i>
    <a href="/">首页</a>/<a href="/new">最新发布</a>
    </div>
    </div>
</div>
<div class="body pos">
	<ul class="list-cat cl">
	<?php
        $limit = get_option('posts_per_page');
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
        query_posts('post_type=post&ignore_sticky_posts=1&post_status=publish&showposts=' . $limit = 24 . '&paged=' . $paged);
        if (have_posts()): while (have_posts()): the_post(); ?>
		<li><a href="<?php the_permalink(); ?>"><?php post_format_vip();?><img lazysrc="<?php attachment_timthumb_src(205,277);?>" alt="<?php the_title(); ?>"><span><strong><?php the_title(); ?></strong>
        <p>DATE：<?php the_time('Y-m-d'); ?></p>
      </span></a></li>
	<?php endwhile;endif ?>
	</ul>
	<div class="page cl"><?php pagenavi();?></div>
	</div>
<?php get_template_part( 'footer', get_post_format() ); ?>