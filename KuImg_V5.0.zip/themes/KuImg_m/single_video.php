<?php get_template_part( 'header', get_post_format() ); ?>
<div class="position">
    <div class="wrapper">
    <div class="palce"><i class="iconfont">&#xe6cd;</i>
    <a href="/">首页</a>/<?php the_category(' '); ?>
    </div>
    </div>
  </div>
<h1 class="p-title"><?php the_title(); ?></h1>
	<?php ad_mb_single_01();?>
	<?php $video_embed = get_post_meta($post->ID,"video_url",true);
			if(!empty($video_embed)) {
			?>
			<?php vid_player();?>
			<?php } else{?>
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<div class="playArea" id="myElement">
			<?php the_content('Read more...'); ?>
			</div>
			<?php endwhile;endif; ?>
			<?php } ?>
	<?php ad_mb_single_02();?>
	<div style="padding: 5px;">
	<?php 
				$desc = get_post_meta($post->ID,"desc",true);
				if(!empty($desc)) {
			?>
			<div style="border: 1px dotted #dbdbdb;"><h3 style="margin: 0 5px;font-weight: normal;"><b>视频描述：</b><?php echo get_post_meta($post->ID,"desc",true); ?></h3></div>
			<?php } ?>
			<?php 
				$desc = get_post_meta($post->ID,"desc",true);
				if( empty($desc)) {
			?>
			<div style="border: 1px dotted #dbdbdb;"><h3 style="margin: 0 5px;font-weight: normal;"><b>视频描述：</b><?php the_title(); ?>推荐，<?php bloginfo('name'); ?>-<?php bloginfo('url'); ?>为你搜集整理提供的最新<?php the_category(' '); ?>，关注更多<?php the_tags('', ' ', '');?>相关视频。</h3></div>
			<?php } ?>
	</div>
<div class="btnline">
	<?php if(function_exists('mflikes')) mflikes('button3');  ?>
    <div class="clear"></div>
</div>
<div class="zu autosize" >
<?php
                    $prev_post = get_previous_post();
                    if (!empty( $prev_post )): ?>

<a href='<?php echo get_permalink( $prev_post->ID ); ?>' class='uppage'>上一篇</a>
<?php endif; ?>
<?php
                    $next_post = get_next_post();
                    if (!empty( $next_post )): ?>
<a href='<?php echo get_permalink( $next_post->ID ); ?>' class='dowpage'>下一篇</a>
<?php endif; ?>
</div>
<div class="clear"></div>
<div class="blank10"></div>
<?php ad_mb_single_03();?>
<?php $options = get_option('mfthemes_options');
	  if( $options['changyan_appid']){?>
<div class="comment">
<div class="comment-m">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div id="SOHUCS" sid="<?php the_ID();?>" ></div> 
<script type="text/javascript"> 
(function(){ 
var appid = '<?php echo $options['changyan_appid'];?>'; 
var conf = '<?php echo $options['changyan_appkey'];?>'; 
var width = window.innerWidth || document.documentElement.clientWidth; 
if (width < 960) { 
window.document.write('<script id="changyan_mobile_js" charset="utf-8" type="text/javascript" src="//changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=' + appid + '&conf=' + conf + '"><\/script>'); } else { var loadJs=function(d,a){var c=document.getElementsByTagName("head")[0]||document.head||document.documentElement;var b=document.createElement("script");b.setAttribute("type","text/javascript");b.setAttribute("charset","UTF-8");b.setAttribute("src",d);if(typeof a==="function"){if(window.attachEvent){b.onreadystatechange=function(){var e=b.readyState;if(e==="loaded"||e==="complete"){b.onreadystatechange=null;a()}}}else{b.onload=a}}c.appendChild(b)};loadJs("//changyan.sohu.com/upload/changyan.js",function(){window.changyan.api.config({appid:appid,conf:conf})}); } })(); </script>
<?php endwhile;endif; ?>
</div>
</div>
<?php }?>
<div class="line-10"></div>
	<div class="more">
			<?php
			global $post;
			$post_tags = wp_get_post_tags($post->ID);
			if ($post_tags) {
 			   foreach ($post_tags as $tag) {
 			       $tag_list[].= $tag->term_id;
 			   }
  			  $post_tag = $tag_list[mt_rand(0, count($tag_list) - 1) ];
  			  $args = array(
   			     'tag__in' => array($post_tag) ,
  			     'category__not_in' => array(NULL) ,
 			     'post__not_in' => array($post->ID) ,
   			     'showposts' => 9,
   			     'caller_get_posts' => 1
 			   );
  			  query_posts($args);?>
		    <h2 class="ymw-title-lev2 mt8"><span>相关推荐</span></h2>
		    <div class="cl">
  			<?php if (have_posts()) {while (have_posts()) {the_post();update_post_caches($posts); ?>
			<a href="<?php the_permalink(); ?>"><?php post_format_vip();?><img src="<?php attachment_timthumb_src(228,315);?>" alt="<?php the_title(); ?>" width="228" height="315">
			<div class="itemset-num"><span class="text"><?php post_format(); ?></span></div></a>
			<?php } }?>
			</div>
			<?php wp_reset_query(); } else {?>
		    <h2 class="ymw-title-lev2 mt8"><span>相关推荐</span></h2>
			<div class="cl">
			<?php $rand_post = get_posts('numberposts=6&orderby=rand');  foreach( $rand_post as $post ) : ?>
 			<a href="<?php the_permalink(); ?>"><?php post_format_vip();?><img src="<?php attachment_timthumb_src(228,315);?>" alt="<?php the_title(); ?>" width="228" height="315">
			<div class="itemset-num"><span class="text"><?php post_format(); ?></span></div></a>
			<?php endforeach; ?>
			</div>
			<?php } ?>	
	</div>
</div>
<?php get_template_part( 'footer', get_post_format() ); ?>