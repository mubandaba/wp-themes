<div class="footer">
	<?php footer();?>
</div>
<div class="side">
<div class="slide-logo">
               <div class="slide-title"><img src="<?php bloginfo('template_url'); ?>/style-m/images/logo_m.png"></div>
            </div>
			 <a class="ho" href="/" class="login-button selected"><span>首页</span></a>
	<ul class="main-nav cl">
		<?php
          echo str_replace("</ul></div>", "", preg_replace("#<div[^>]*><ul[^>]*>#", "", wp_nav_menu(array(
 		      'theme_location' => 'mobilemenu',
 		      'echo' => false
		  )) ));
 		  ?>
	</ul>
</div>
<i class="iconfont" id="goTopBtn">&#xe636;</i>
<script type="text/javascript">
 $(window).scroll(function(){
   var sc=$(window).scrollTop();
   var rwidth=$(window).width()
   if(sc>0){
    $("#goTopBtn").css("display","block");
    $("#goTopBtn").css("left",(rwidth-50)+"px")
   }else{
   $("#goTopBtn").css("display","none");
   }
 })
 $("#goTopBtn").click(function(){
   var sc=$(window).scrollTop();
   $('body,html').animate({scrollTop:0},500);
 })
</script>
<?php $options = get_option('mfthemes_options');
			if( $options['analysis']){?>
	<div style="display: none;"><?php echo $options['analysis'];?></div>
<?php }?>
<?php ad_mb_footer_xf();?>
</body>
</html>