<?php get_template_part( 'header', get_post_format() ); ?>
<div class="bg">
	<div class="cont">
		<div class="c1"><img src="<?php bloginfo('template_url'); ?>/style-m/images/404.jpg" style="margin-top: 20px;"></div>
		<h2>啊哦！页面好像出了点问题，稍后回来。</h2>
		<div class="c3">小编提醒您 - 您可能输入了错误的网址，或者该网页已经被删除或者移动。</div>
	</div>
</div>
<?php get_template_part( 'footer', get_post_format() ); ?>
