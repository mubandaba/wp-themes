<?php get_template_part( 'header', get_post_format() ); ?>
<div class="neirong">
<h1><div class="title"><?php the_title(); ?></div></h1>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="other">
<u>发布时间：</u><time><?php the_time('Y-m-d'); ?></time>&nbsp;&nbsp;&nbsp;分类：<?php the_category(' '); ?>
</div>
<div class="neirong-box">
<article>
<?php the_content('Read more...'); ?>
</article>
</div>
<?php endwhile;endif; ?>
<div class="interact"><?php if(function_exists('mflikes')) mflikes('button');  ?></div>
<script>	
$(".iconfont").click(function () {
$(this).toggleClass("iconfont-i");
var classname=$(this).attr("class");
var zan_num=parseInt($('>span',this).text());
if(classname == "iconfont iconfont-i"){
zan_num +=1;
$('>span',this).text(zan_num);
}else if(classname== "iconfont"){
zan_num -=1;
$('>span',this).text(zan_num);
}
})
 </script>
 <div class="zu autosize" >
<?php
                    $prev_post = get_previous_post();
                    if (!empty( $prev_post )): ?>

<a href='<?php echo get_permalink( $prev_post->ID ); ?>' class='uppage'>上一篇</a>
<?php endif; ?>
<?php
                    $next_post = get_next_post();
                    if (!empty( $next_post )): ?>
<a href='<?php echo get_permalink( $next_post->ID ); ?>' class='dowpage'>下一篇</a>
<?php endif; ?>
</div>
</div>
<?php $options = get_option('mfthemes_options');
	  if( $options['changyan_appid']){?>
<div class="comment">
<div class="comment-m">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div id="SOHUCS" sid="<?php the_ID();?>" ></div> 
<script type="text/javascript"> 
(function(){ 
var appid = '<?php echo $options['changyan_appid'];?>'; 
var conf = '<?php echo $options['changyan_appkey'];?>'; 
var width = window.innerWidth || document.documentElement.clientWidth; 
if (width < 960) { 
window.document.write('<script id="changyan_mobile_js" charset="utf-8" type="text/javascript" src="//changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=' + appid + '&conf=' + conf + '"><\/script>'); } else { var loadJs=function(d,a){var c=document.getElementsByTagName("head")[0]||document.head||document.documentElement;var b=document.createElement("script");b.setAttribute("type","text/javascript");b.setAttribute("charset","UTF-8");b.setAttribute("src",d);if(typeof a==="function"){if(window.attachEvent){b.onreadystatechange=function(){var e=b.readyState;if(e==="loaded"||e==="complete"){b.onreadystatechange=null;a()}}}else{b.onload=a}}c.appendChild(b)};loadJs("//changyan.sohu.com/upload/changyan.js",function(){window.changyan.api.config({appid:appid,conf:conf})}); } })(); </script>
<?php endwhile;endif; ?>
</div>
</div>
<?php }?>
<script>
    $('article').readmore({moreLink: '<div class="show_article">加载全文<i class="iconfont">&#xe623;</i></div>',lessLink: '',collapsedHeight: 800,speed: 500});
  </script>
<?php get_template_part( 'footer', get_post_format() ); ?>