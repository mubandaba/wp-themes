﻿<?php
/*********************/
/*                   */
/*  Version : 5.1.0  */
/*  Author  : RM     */
/*  Comment : 071223 */
/*                   */
/*********************/

define( "THEME_NAME", "KuImg_m" );
get_template_part( "functions/themes-plugin" );
get_template_part( "functions/themes-script" );
get_template_part( "functions/themes-meta" );
get_template_part( "functions/themes-pagenavi" );

function footer(){
	$options = get_option('mfthemes_options');
			if( $options['footer']){?>	
    <p>
    <?php echo $options['footer'];?>. <?php echo $options['beian_id'];?> Theme By <a href="//www.dz9.net/" title="多姿-关注互联网">多姿</a>.</p>
    <?php }else{?>
    <p>Copyright &copy; 2016-<?php echo date("Y");?> <a href="<?php bloginfo('url'); ?>" target="_blank" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a> All Rights Reserved.<br>一秒记住我们：<?php bloginfo('url'); ?></p>
	<?php }
}