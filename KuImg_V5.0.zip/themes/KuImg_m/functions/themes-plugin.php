<?php
/**
 * KuImg core theme functions
 *
 *
 * @package KuImg
 * @author MctDs
 * @url //www.dz9.net
 */

//首页幻灯片
function slider_content_m() { 
	$options = get_option('mfthemes_options');
	$filmstrip = $options['filmstrip'];
	$cnt = count($filmstrip['src']);
	if( $cnt>0){
		$film = '';
		for($i=0;$i<$cnt;$i++){
			//var_dump($src);
			$src = $filmstrip["src"][$i];
			$t = $filmstrip["title"][$i];
			$href = $filmstrip["href"][$i];
			if($src!=""){
				$film .= "<li><a href=\"$href\"><img src=\"$src\" alt=\"$t\"/></a></li>";
			}
		}
		
	?>
            <?php echo $film;?>
	<?php }
}

/**
 *  无线端内容页标题下方广告
 */
function ad_mb_single_01(){
	$options = get_option('mfthemes_options');
	if( $options['mb_single_01']){?>
    <?php echo $options['mb_single_01'];?>
	<?php }
}

/**
 *  无线端内容页内容下方广告
 */
function ad_mb_single_02(){
	$options = get_option('mfthemes_options');
	if( $options['mb_single_02']){?>
    <?php echo $options['mb_single_02'];?>
	<?php }
}

/**
 *  无线端内容页推荐上方广告
 */
function ad_mb_single_03(){
	$options = get_option('mfthemes_options');
	if( $options['mb_single_03']){?>
    <?php echo $options['mb_single_03'];?>
	<?php }
}

/**
 *  全站底部悬浮广告
 */
function ad_mb_footer_xf(){
	$options = get_option('mfthemes_options');
	if( $options['mb_footer_xf']){?>
    <?php echo $options['mb_footer_xf'];?>
	<?php }
}

//文章类型
function post_format() { 
	if ( has_post_format( 'image' ) ) {
	$pic_text = 单图;
	}
    elseif ( has_post_format( 'gallery' ) ) {
    $pic_text = 图集;
    }
	elseif ( has_post_format( 'video' ) ) {
	$pic_text = 视频;
	}
	else {
	$pic_text = 资讯;
    }
	echo $pic_text;
}

//VIP角标
function post_format_vip() { 
    global $current_user, $post, $posts;
    $login_in = get_post_meta($post->ID,"login_in",true);
    if($login_in =='open'){
	$pic_vip = 'VIP';
	$output .='<div class="itemset-num-vip">
                <span class="text">'.$pic_vip.'</span>
				</div>';
	}
	
    echo $output;
}

//视频内容判断用户角色
function vid_player() {
	$options = get_option('mfthemes_options');
	if ( $options['videoad'] =="pre" ) {
         $video_ads = 'pre';
                }
	elseif ( $options['videoad'] =="post" ) {
         $video_ads = 'post';
                }	
	elseif ( $options['videoad'] =="mid" ) {
         $video_ads = $options['adtime'];
                }	
    $video_xml = $options['video_xml'];				
	global $current_user, $post, $posts;
	$playlist = get_post_meta($post->ID,"playlist",true);
	$id = get_the_ID();
	$file = '/player?id='.$id.'';
	$image = get_post_meta($post->ID,"video_poster",true);
	$login_in = get_post_meta($post->ID,"login_in",true);
	$width = '%s';
	if( $current_user->roles[0] == 'administrator' ) {	
	    $player .= "<div class='cont' id='myElement'><script type='text/javascript'>jwplayer('myElement').setup({playlist:'".$playlist."',file:'".$file."',image:'".$image."'})</script></div>";
    }
	elseif( $current_user->roles[0] == 'contributor' ) {	
	    $player .= "<div class='cont' id='myElement'><script type='text/javascript'>jwplayer('myElement').setup({playlist:'".$playlist."',file:'".$file."',image:'".$image."'})</script></div>";
    }
	elseif( is_user_logged_in() ) {
		$player .= "<div class='cont' id='myElement'><script type='text/javascript'>jwplayer('myElement').setup({playlist:'".$playlist."',file:'".$file."',image:'".$image."',advertising:{client: 'vast',schedule: {'myAds':{'offset':'".$video_ads."','tag':'".$video_xml."'}}}})</script></div>";
		}
	elseif($login_in =='open'){
		$player .= '<div class="cont" id="myElement">
		            <script type="text/javascript">
		            var temp = 1;
		            $(function() {
		            var playerInstance = jwplayer("myElement");
		            playerInstance.setup({
		            file:"'.$file.'",
		            image:"'.$image.'",
					width: "100%",
					aspectratio:"10:6",
		            });
		            playerInstance.on("time",function(obj){
		            var time = obj.position;
		            var v1 = parseFloat(time.toFixed(0));
		            if(v1 > 10 && temp ==1){
		            playerInstance.seek(10);
		            }
		            var v2 = parseFloat("10");
		            if(v1 == v2){
		            if(temp == 1){
		            playerInstance.pause();
		            $("#myModal").addClass("is-visible")
		            $(".cd-user-modal").find("#cd-login").addClass("is-selected");
		            $(".cd-user-modal").find("#cd-signup").removeClass("is-selected");
		            $(".cd-switcher").children("li").eq(0).children("a").addClass("selected");
		            $(".cd-switcher").children("li").eq(1).children("a").removeClass("selected");
		            }
		            }
		            });
		            playerInstance.on("playAttempt",function(){
		            //alert("非登录用户可预览5秒，点击确定开始播放.");
		            });
		            });
		            </script>
					</div>';
		}
	else {
		$player .= "<div class='cont' id='myElement'><script type='text/javascript'>jwplayer('myElement').setup({playlist:'".$playlist."',file:'".$file."',image:'".$image."',advertising: {client:'vast',schedule: {'myAds':{'offset':'".$video_ads."','tag':'".$video_xml."'}}}})</script></div>";
		}
	/*else {
		$player .='你当前没有权限观看！请先<a href="/wp-login.php" target="_blank"><font color="red">登录</font></a>/<a href="/wp-login.php?action=register" target="_blank"><font color="red">注册</font></a>';
	}*/
	echo $player;
}

/**
 *  缩略图
 */
function timthumb_src($w='',$h=''){
  global $post, $posts;
  $first_img = '';
  ob_start();
  ob_end_clean();
  $dir_url = get_bloginfo('template_url');
  $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
  $first_img = $matches [1] [0];
  if(empty($first_img)){ 
  $first_img = "$dir_url/style/images/default.jpg";
  }
  $video_poster = get_post_meta($post->ID,"video_poster",true);
				if ( empty( $video_poster ) ) {
                    $video_poster = $first_img;
                }
	$options = get_option('mfthemes_options');
	if ( $options['cloud'] =="1" ) {
         $thumb = ''.$video_poster.'?imageView2/1/w/'.$w.'/h/'.$h.'/q/90/format/jpg/interlace/1';
                }
	elseif ( $options['cloud'] =="2" ) {
         $thumb = ''.$video_poster.'!pximg/both/'.$w.'x'.$h.'';
                }			
	else {
		 $thumb = ''.get_bloginfo('template_directory').'/timthumb.php?src='.$video_poster.'&w='.$w.'&h='.$h.'&s=1';
				}
	echo $thumb;
}

//附件缩略图
function attachment_timthumb_src($w='',$h=''){
global $post, $posts;
ob_start();
ob_end_clean();
$attachments = get_posts(array(
                       'post_parent' => $post->ID,
                       'post_type' => 'attachment',
                       'post_mime_type' => 'image',
                       'orderby' => 'date',
                       'posts_per_page' => 1,
                       'order' => 'ASC'
                       ));
foreach ( $attachments as $attachment ) {
                    $imgurl_big = wp_get_attachment_url( $attachment->ID, '' );
                }
  $dir_url = get_bloginfo('template_url');
  $first_img = $imgurl_big;
  if(empty($first_img)){ 
  $first_img = "$dir_url/style/images/default.jpg";
  }
  $video_poster = get_post_meta($post->ID,"video_poster",true);
				if ( empty( $video_poster ) ) {
                    $video_poster = $first_img;
                }
	$options = get_option('mfthemes_options');
	if ( $options['cloud'] =="1" ) {
         $thumb = ''.$video_poster.'?imageView2/1/w/'.$w.'/h/'.$h.'/q/90/format/jpg/interlace/1';
                }
	elseif ( $options['cloud'] =="2" ) {
         $thumb = ''.$video_poster.'!pximg/both/'.$w.'x'.$h.'';
                }			
	else {
		 $thumb = ''.get_bloginfo('template_directory').'/timthumb.php?src='.$video_poster.'&w='.$w.'&h='.$h.'&s=1';
				}
	echo $thumb;
}

//隐藏视频地址
function videourl() {
global $page, $post, $posts;
$id = intval($_REQUEST['id']);	
$url = get_post_meta($id,"video_url",true);
$arr_tit = array(
    $id => $url,
    );
$ids = intval($_REQUEST['id']);	
Header( "Location: $arr_tit[$ids]" );
exit();
}
?>