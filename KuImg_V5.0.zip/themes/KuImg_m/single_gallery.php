<?php get_header(); ?>
<div class="position">
    <div class="wrapper">
    <div class="palce"><i class="iconfont">&#xe6cd;</i>
    <a href="/">首页</a>/<?php the_category(' '); ?>
    </div>
    </div>
  </div>
<h1 class="p-title"><?php the_title(); ?></h1>
	<?php ad_mb_single_01();?>
	<p style="padding:5px; color:#aaa; text-align:center;">Tips:点击图片查看下一张</p>
	<?php $i = 1; $w = 1; $q = 1; $e = 1; $r = 1; $t=1;  ?>
		<?php 
		$login_in = get_post_meta($post->ID,"login_in",true);
		if($current_user->roles[0] == 'administrator' || $current_user->roles[0] == 'contributor'||is_user_logged_in() ) {
			$attachments = get_posts(array(
                       'post_parent' => $post->ID,
                       'post_type' => 'attachment',
                       'post_mime_type' => 'image',
                       'orderby' => 'date',
                       'posts_per_page' => -1,
                       'order' => 'ASC'
                       ));
		}
		elseif($login_in =='open'){
			$attachments = get_posts(array(
                       'post_parent' => $post->ID,
                       'post_type' => 'attachment',
                       'post_mime_type' => 'image',
                       'orderby' => 'date',
                       'posts_per_page' => 5,
                       'order' => 'ASC'
                       ));
					   echo "<script> if(confirm( '本图集游客可浏览5张，登录后浏览完整套图！(点击“确定”登录，点击“取消”继续浏览当前图集) '))  location.href='/wp-login.php';</script>";
					   }
		else {
			$attachments = get_posts(array(
                       'post_parent' => $post->ID,
                       'post_type' => 'attachment',
                       'post_mime_type' => 'image',
                       'orderby' => 'date',
                       'posts_per_page' => -1,
                       'order' => 'ASC'
                       ));
		}
		$post_title = get_the_title();
           if ( $attachments ) {
                $output = array();
                foreach ( $attachments as $attachment ) {
                    $imgurl_big = wp_get_attachment_url( $attachment->ID, '' );
		            /*$imgexcerpt = $attachment->post_excerpt;//图片说明*/
		            $imgdescription = $attachment->post_content;
					$desc = get_post_meta($post->ID,"desc",true);
					$options = get_option('mfthemes_options');
					if ( $options['cloud'] =="1" ) {
                    $imgurl_big = $imgurl_big;
                    }
				    elseif ( $options['cloud'] =="2" ) {
                    $imgurl_big = ''.$imgurl_big.'!/format/webp';
                    }
	                else {
		            $imgurl_big = $imgurl_big;
				    }
					if ( empty( $imgdescription ) ) {
                    $desc = $desc;
                }
				    else {
					$desc = $imgdescription;
				}
                    array_push($output,'
					{
						"picPos": '.$i++.',
						"bigPic": "'.$imgurl_big.'"},
						');
                }
            }
        ?>
	<div class="demo w990">
	<div class="maxPic-box">
    <div class="indexbody-left"></div>
    <div class="indexbody-right"></div>
  <a class="maxBtn-l" href="javascript:void(0);"></a>
  <a class="maxBtn-r" href="javascript:void(0);"></a>
      <div class="maxPic">
	  <?php if ( in_category(array( 3 )) ) { ?>
		  <div class="maxPicBox"><img id="mainPic" src="<?php echo $imgurl_big;?>" alt="<?php the_title(); ?>"/></div>
	  <?php } else{ ?>
        <div class="maxPicBox"><img id="mainPic" src="<?php attachment_timthumb_src(0,0);?>" alt="<?php the_title(); ?>"/></div>
	  <?php } ?>
      </div>
    </div>
	</div>
	<?php ad_mb_single_02();?>
<div class="infoline autosize">			
            <?php 
				$desc = get_post_meta($post->ID,"desc",true);
				if(!empty($desc)) {
			?>
			<div style="border: 1px dotted #dbdbdb;"><h3 style="margin: 0 5px;font-weight: normal;"><b>图集介绍：</b><?php echo get_post_meta($post->ID,"desc",true); ?></h3></div>
			<?php } ?>
			<?php 
				$desc = get_post_meta($post->ID,"desc",true);
				if( empty($desc)) {
			?>
			<div style="border: 1px dotted #dbdbdb;"><h3 style="margin: 0 5px;font-weight: normal;"><b>图集介绍：</b><?php the_title(); ?>推荐，<?php bloginfo('name'); ?>-<?php bloginfo('url'); ?>为你搜集整理提供的最新<?php the_category(' '); ?>，关注更多<?php the_tags('', ' ', '');?>相关图集。</h3></div>
			<?php } ?></div>
<div class="btnline">	
	<?php if(function_exists('mflikes')) mflikes('button3');  ?>
<script>	
$(".iconfont").click(function () {
$(this).toggleClass("iconfont-i");
var classname=$(this).attr("class");
var zan_num=parseInt($('>span',this).text());
if(classname == "iconfont iconfont-i"){
zan_num +=1;
$('>span',this).text(zan_num);
}else if(classname== "iconfont"){
zan_num -=1;
$('>span',this).text(zan_num);
}
})
 </script>
    <div class="clear"></div>
</div>
<div class="zu autosize" >
<?php
                    $prev_post = get_previous_post();
                    if (!empty( $prev_post )): ?>
<div class='Up-tuzu uppage'></div>
<?php endif; ?>
<?php
                    $next_post = get_next_post();
                    if (!empty( $next_post )): ?>
<div class='Next-tuzu dowpage'></div>
<?php endif; ?>
</div>
<script type="text/javascript">
$(function(){
	var prevDiv = $(".Up-tuzu");
	var nextDiv = $(".Next-tuzu");
	if(prevDiv.find("a").length<1){
		 prevDiv.html("<a href='<?php echo get_permalink( $prev_post->ID ); ?>' id='prevUrl'>上一组</a>");
		}
	if(nextDiv.find("a").length<1){
	 nextDiv.html("<a href='<?php echo get_permalink( $next_post->ID ); ?>' id='nextUrl'>下一组</a>");
	}
});

var selectKey = "1";
var picList = [
<?php
    foreach($output as $pic)
    echo $pic;
?>
];
</script> 
<?php single_pic_script(); ?>
<div class="clear"></div>
<div class="blank10"></div>
<?php ad_mb_single_03();?>
<?php $options = get_option('mfthemes_options');
	  if( $options['changyan_appid']){?>
<div class="comment">
<div class="comment-m">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div id="SOHUCS" sid="<?php the_ID();?>" ></div> 
<script type="text/javascript"> 
(function(){ 
var appid = '<?php echo $options['changyan_appid'];?>'; 
var conf = '<?php echo $options['changyan_appkey'];?>'; 
var width = window.innerWidth || document.documentElement.clientWidth; 
if (width < 960) { 
window.document.write('<script id="changyan_mobile_js" charset="utf-8" type="text/javascript" src="//changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=' + appid + '&conf=' + conf + '"><\/script>'); } else { var loadJs=function(d,a){var c=document.getElementsByTagName("head")[0]||document.head||document.documentElement;var b=document.createElement("script");b.setAttribute("type","text/javascript");b.setAttribute("charset","UTF-8");b.setAttribute("src",d);if(typeof a==="function"){if(window.attachEvent){b.onreadystatechange=function(){var e=b.readyState;if(e==="loaded"||e==="complete"){b.onreadystatechange=null;a()}}}else{b.onload=a}}c.appendChild(b)};loadJs("//changyan.sohu.com/upload/changyan.js",function(){window.changyan.api.config({appid:appid,conf:conf})}); } })(); </script>
<?php endwhile;endif; ?>
</div>
</div>
<?php }?>
<div class="line-10"></div>
	<div class="more">
			<?php
			global $post;
			$post_tags = wp_get_post_tags($post->ID);
			if ($post_tags) {
 			   foreach ($post_tags as $tag) {
 			       $tag_list[].= $tag->term_id;
 			   }
  			  $post_tag = $tag_list[mt_rand(0, count($tag_list) - 1) ];
  			  $args = array(
   			     'tag__in' => array($post_tag) ,
  			     'category__not_in' => array(NULL) ,
 			     'post__not_in' => array($post->ID) ,
   			     'showposts' => 9,
   			     'caller_get_posts' => 1
 			   );
  			  query_posts($args);?>
		    <h2 class="ymw-title-lev2 mt8"><span>相关推荐</span></h2>
		    <div class="cl">
  			<?php if (have_posts()) {while (have_posts()) {the_post();update_post_caches($posts); ?>
			<a href="<?php the_permalink(); ?>"><?php post_format_vip();?><img src="<?php attachment_timthumb_src(228,315);?>" alt="<?php the_title(); ?>" width="228" height="315">
			<div class="itemset-num"><span class="text"><?php post_format(); ?></span></div></a>
			<?php } }?>
			</div>
			<?php wp_reset_query(); } else {?>
		    <h2 class="ymw-title-lev2 mt8"><span>随机推荐</span></h2>
			<div class="cl">
			<?php $rand_post = get_posts('numberposts=6&orderby=rand');  foreach( $rand_post as $post ) : ?>
 			<a href="<?php the_permalink(); ?>"><?php post_format_vip();?><img src="<?php attachment_timthumb_src(228,315);?>" alt="<?php the_title(); ?>" width="228" height="315">
			<div class="itemset-num"><span class="text"><?php post_format(); ?></span></div></a>
			<?php endforeach; ?>
			</div>
			<?php } ?>	
	</div>
</div>
<?php get_footer(); ?>  