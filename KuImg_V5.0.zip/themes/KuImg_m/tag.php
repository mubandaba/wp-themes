<?php get_template_part( 'header', get_post_format() ); ?>
 <?php $tag_ids = get_term_meta( $tag_id, '_id_upload',true );
	if(!empty($tag_ids)) {
	?>
	<div class="cl"><img src="<?php echo get_term_meta( $tag_id, '_id_upload',true ); ?>" style="width:100%;"></div>
	<?php } else{?>
	<div class="cl"><img src="//img.majidou.com/2017/11/26e86040b5f405b.jpg" style="width:100%;"></div>
	<?php } ?>
<div class="keywordtopsmw">
<div class="txtcont"><?php echo get_term_meta( $tag_id, '_id_tinymce',true ); ?></div>
</div>
<div class="body line">
	<ul class="works-nav">
		<li class="pos"><a href="javascript:;" id="tag"><span>共<?php echo get_tag_post_count_by_id( $tag_id );?>组</span></a></li>
		<li class="pos"><a href="javascript:;" id="cation"><span>相关推荐</span><i class="icon-down"></i></a></li>
		<li class="pos"><a href="javascript:;" id="attribute"><span><?php the_time('Y-m-d'); ?></span></a></li>
	</ul>
</div>
<div class="body pos">
	<ul class="list cl">
	<?php 
     global $query_string;
     query_posts($query_string.'&showposts=24&caller_get_posts=1'); ?>
    <?php if(have_posts()) : ?>
    <?php while(have_posts()) : the_post(); ?>
		<li><a href="<?php the_permalink(); ?>"><?php post_format_vip(); ?><img lazysrc="<?php attachment_timthumb_src(196,265);?>" title="<?php the_title(); ?>" width="196" height="265"><div class="itemset-num"><span class="text"><?php post_format(); ?></span></div><div class="txtbts"><?php the_title(); ?></div></a></li>
	<?php endwhile;endif; ?>
	</ul>
	<div class="page cl"><?php pagenavi();?></div>
</div>
<div class="works-li" style="display:none; " id="sub-list">
	<div class="header"><h1>相关专辑推荐</h1><i class="icon-close"></i></div>
	<div class="body">
	<ul class="works-subnav">
    <?php wp_tag_cloud('unit=px&smallest=14&largest=14&number=14&order=RAND&format=list'); ?></ul>
	</div>
</div>
<script>
	$(function(){
		$('#cation').click(function(){
			$('#tag-list').hide();
			$('#cate-list').hide();
			$('#sub-list').show();
			$('html').css('overflow','hidden');
		});
		$('.icon-close').click(function(){
			$('.works-li').hide();
			$('html').css('overflow','auto');
		});
	});
</script>
<?php get_template_part( 'footer', get_post_format() ); ?>
