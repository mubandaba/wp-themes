<?php get_template_part( 'header', get_post_format() ); ?>
<div class="position">
    <div class="wrapper">
    <div class="palce"><i class="iconfont">&#xe6cd;</i>
    <a href="/">首页</a>/<a href="<?php get_category_link( $category_id ) ?>"><?php single_cat_title(); ?></a>
    </div>
    </div>
</div>
<div class="body pos">
	<ul class="list-v cl">
	<?php 
     global $query_string;
     query_posts($query_string.'&showposts=24&caller_get_posts=1'); ?>
    <?php if(have_posts()) : ?>
    <?php while(have_posts()) : the_post(); ?>
		<li><a href="<?php the_permalink(); ?>"><?php post_format_vip();?><img src="<?php attachment_timthumb_src(275,180);?>" alt="<?php the_title(); ?>" width="275" height="180"/>
		<span class="iconfont video-ico">&#xe618;</span>
		<div class="txtbts"><?php the_title(); ?></div></a></li>
	<?php endwhile; ?>
    <?php endif; ?>
	</ul>
	<div class="page cl"><?php pagenavi();?></div>
	</div>
<?php get_template_part( 'footer', get_post_format() ); ?>
