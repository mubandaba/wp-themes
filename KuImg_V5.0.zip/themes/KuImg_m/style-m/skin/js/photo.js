
//分享按键
function showfx(){
		$('.waifxbox').css('display','-webkit-box');
	}
	function closefx(){
		$('.waifxbox').css('display','none');
}	
//分享链接	
function tofxURL(name){
	var shareico = {
			"tsina"		:"//v.t.sina.com.cn/share/share.php?title={title}&url={url}&appkey=2992571369",
			"tqq"		:"//v.t.qq.com/share/share.php?title={title}&url={url}&appkey=118cd1d635c44eab9a4840b2fbf8b0fb",
			"renren"	:"//widget.renren.com/dialog/share?resourceUrl={url}&srcUrl={url}&title={title}",
			"cqq"		:"//connect.qq.com/widget/shareqq/index.html?url={url}&title={title}",
			
			"qzone"		:"//sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url={url}&title={title}"
		};
	var shareiconame = {
			"tsina"		:"新浪微博",
			"tqq"		:"腾讯微博",
			"renren"	:"人人网",
			"cqq"		:"QQ好友",
			
			"qzone"		:"QQ空间"
		};
	var $title = encodeURI($('#fxtitle').text());
	var $url = encodeURI($('#fxurl').text());
	$href = shareico[name].replace("{title}",$title).replace("{url}",$url);  
	window.location.href=$href;
	
}