$(function() {
$(".iconfont").click(function () {
$(this).toggleClass("iconfont-i");
var classname=$(this).attr("class");
var zan_num=parseInt($('>span',this).text());
if(classname == "iconfont iconfont-i"){
zan_num +=1;
$('>span',this).text(zan_num);
}else if(classname== "iconfont"){
zan_num -=1;
$('>span',this).text(zan_num);
}
})
});