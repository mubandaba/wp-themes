<?php get_template_part( 'header', get_post_format() ); ?>
<?php $options = get_option('mfthemes_options');?>
<?php list($one, $two, $three,$four) = explode(',','1,3,5,246');?><!--这里数字替换为需要在首页展示的分类ID（固定样式）-->
<div class="swipe">
	<ul id="slider">
	<?php slider_content_m();?>
	</ul>
	<div id="pagenavi"><a href="javascript:;" class="active"></a><a href="javascript:;"></a><a href="javascript:;"></a><a href="javascript:;"></a><a href="javascript:;"></a><a href="javascript:;"></a></div>
</div>
<script>
	console=window.console || {dir:new Function(),log:new Function()};
	var active=0,
	as=document.getElementById('pagenavi').getElementsByTagName('a');
	for(var i=0;i<as.length;i++){
		(function(){
			var j=i;
			as[i].onclick=function(){
				t4.slide(j);
				return false;
			}
		})();
	}

	var t4=new TouchSlider({id:'slider', speed:600, timeout:6000, before:function(index){
		as[active].className='';
		active=index;
		as[active].className='active';
	}});
</script>
<div class="line-10"></div>
<?php $sticky = get_option('sticky_posts'); rsort( $sticky );
$sticky = array_slice( $sticky, 0, 2);query_posts( array( 'post__in' => $sticky, 'caller_get_posts' => 1 ) );
?>
 <div class="m-gs cf">
  <div class="mark">头条<i>&nbsp;</i></div>
   <div class="m-gs-list">
	<ul>
<?php if (have_posts()) :while (have_posts()) : the_post(); ?>
	 <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
<?php endwhile; endif; ?>
	</ul>
   </div>
 </div>
	<?php $posts = query_posts($query_string . "&cat={$one}" ); ?> 
	<div class="line-10"></div>
	<h2 class="ymw-title-lev2 mt8"><span><?php single_cat_title(); ?></span></h2>
	</div>
	<ul class="list cl">
	<?php $posts = query_posts($query_string . "&cat={$one}&orderby=date&showposts=6" ); ?>
	<?php while(have_posts()) : the_post(); ?>
		<li><a href="<?php the_permalink(); ?>"><?php post_format_vip();?><img src="<?php attachment_timthumb_src(205,277);?>" alt="<?php the_title(); ?>" width="205" height="277"/>
				<div class="txtbts"><?php the_title(); ?></div></a></li>
	<?php endwhile;?>
	<a href="<?php echo get_category_link($one); ?>" class="ymw-more ymw-more-bg"><i class="iconfont">&#xe70b;</i><span>点击欣赏更多福利</span></a>
	</ul>
  <div class="line-10"></div>
  <?php $loop_cate_id=explode(',', $two);$num=6;?>  
	<?php foreach($loop_cate_id as $key=>$two){ ?> 
	<?php $posts = query_posts($query_string . "&cat={$two}&orderby=date&showposts=15" ); ?>
  <h2 class="ymw-title-lev2 mt8"><span><?php single_cat_title(); ?></span><a href="<?php echo get_category_link($two); ?>">+MORE</a></h2>
  <div class="swiper-container">
    <div class="swiper-wrapper">
                <?php while(have_posts()) : the_post(); ?>
                <div class="swiper-slide">
                    <a href="<?php the_permalink(); ?>"><img src="<?php attachment_timthumb_src(190,270);?>" alt="<?php the_title(); ?>">
                    <h5><?php the_title(); ?></h5>
                    <p><i class="iconfont" style="margin-right: 5px;color: #e6232a;">&#xe754;</i><?php if(function_exists('the_views')) the_views();?>°</p>
                    </a>
                </div>
                <?php endwhile; ?>
    </div>
    <div class="swiper-pagination"></div>
  </div>
<?php }?>
  <script>
    var swiper = new Swiper('.swiper-container', {
      slidesPerView: 3.5,
      spaceBetween: 10,
      freeMode: true,
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
    });
  </script>
  
    <?php $posts = query_posts($query_string . "&cat={$three} &orderby=date&showposts=6"); ?> 
	<div class="line-10"></div>
	<h2 class="ymw-title-lev2 mt8"><span><?php single_cat_title(); ?></span><a href="<?php echo get_category_link($three); ?>">+MORE</a></h2>
	</div>
	<ul class="list-v cl">
	<?php while(have_posts()) : the_post(); ?>
		<li><a href="<?php the_permalink(); ?>"><?php post_format_vip();?><img src="<?php attachment_timthumb_src(275,180);?>" alt="<?php the_title(); ?>" width="275" height="180"/>
		<span class="iconfont video-ico">&#xe618;</span>
				<div class="txtbts"><?php the_title(); ?></div></a></li>
	<?php endwhile; ?>
	</ul>
	
    <?php $loop_cate_id=explode(',', $options['cat_id_m']);$num=6;?>  
	<?php foreach($loop_cate_id as $key=>$value){ ?> 
	<?php $posts = query_posts($query_string . "&cat={$value}&orderby=date&showposts=6" ); ?>
	<div class="line-10"></div>
	<h2 class="ymw-title-lev2 mt8"><span><?php single_cat_title(); ?></span><a href="<?php echo get_category_link($value); ?>">+MORE</a></h2>
	</div>
	<ul class="list cl">
	<?php while(have_posts()) : the_post(); ?>
		<li><a href="<?php the_permalink(); ?>"><?php post_format_vip();?><img src="<?php attachment_timthumb_src(205,277);?>" alt="<?php the_title(); ?>" width="205" height="277"/>
				<div class="txtbts"><?php the_title(); ?></div></a></li>
	<?php endwhile; ?>
	</ul>
	<?php }?>
	<div class="line-10"></div>
	<?php $loop_cate_id=explode(',', $four);$num=5;?>  
	<?php foreach($loop_cate_id as $key=>$four){ ?> 
	<?php $posts = query_posts($query_string . "&cat={$four}&orderby=date&showposts=5" ); ?>
	<h2 class="ymw-title-lev2 mt8"><span><?php single_cat_title(); ?></span></h2>
	<ul class="ymw-list-tp1 mb8 ymwListMore">
	<?php while(have_posts()) : the_post(); ?>
        <li>
            <img src="<?php attachment_timthumb_src(120,70);?>" alt="<?php the_title(); ?>">
            <h5 class=""><?php the_title(); ?></h5>
            <p><time><i class="iconfont" style="margin-right: 5px;">&#xe673;</i><?php the_time('m-d'); ?></time><span class="pls cy_comment"><i class="iconfont" style="margin-right: 5px;">&#xe622;</i><?php if(function_exists('the_views')) the_views();?></span></p>
            <a href="<?php the_permalink(); ?>"></a>
        </li>
		<?php endwhile; ?>
        <a href="<?php echo get_category_link($four); ?>" class="ymw-more ymwListMoreBtn"><i class="iconfont">&#xe70b;</i><span>点击查看更多资讯</span></a>
    </ul>
	<?php }?>
	<div class="line-10"></div>
	<h2 class="ymw-title-lev2 mt8"><span>标签云</span></h2>
	<div class="arc-tags pic-list mt2"><?php wp_tag_cloud('unit=px&smallest=12&largest=12&number=20&order=RAND'); ?></div>
<?php get_template_part( 'footer', get_post_format() ); ?>