<?php get_header(); ?>
<div class="position">
    <div class="wrapper">
    <div class="palce"><i class="iconfont">&#xe6cd;</i>
    <a href="/">首页</a>/<a href="<?php get_category_link( $category_id ) ?>"><?php single_cat_title(); ?></a>
    </div>
    </div>
</div>
<div class="neirong" style="margin-top: -20px;">
<?php 
  global $query_string;
  query_posts($query_string.'&showposts=24&caller_get_posts=1'); ?>
    <?php if(have_posts()) : ?>
    <?php while(have_posts()) : the_post(); ?>
	<div class="ui-mod-picsummary ui-border-bottom-gray">
                <a href="<?php the_permalink(); ?>">
                    <img class="ui-pic" src="<?php attachment_timthumb_src(120,80);?>" width="120" height="80" alt="<?php the_title(); ?>">
					<h3 class="ui-title"><?php the_title(); ?></h3>
                    <div class="ui-summary"><?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 60,"..."); ?>
					<div class="ui-comment-count"><?php the_time('Y-m-d'); ?></div>
                    </div>
                </a>
            </div>
	<?php endwhile; ?>
    <?php endif; ?>
<div class="page cl"><?php pagenavi();?></div>	
</div>
<?php get_footer(); ?>