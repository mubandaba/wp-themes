<?php get_template_part( 'header', get_post_format() ); ?>
<div class="position">
    <div class="wrapper">
    <div class="palce"><i class="iconfont">&#xe6cd;</i>
    <a href="/">首页</a>/ 搜索 "<?php echo $_GET['s'];?>"
    </div>
    </div>
</div>
<div class="cl" style="margin:10px 0 10px 10px;color:#2b2b2b;font-size: 14px;">你现在的位置 &gt; 搜索<?php echo $_GET['s'];?></div>
<div class="body pos">
<div class="search_nav">
<div class="search_navcon">
			<form action="/" method="get">
				<div class="search_navleft">
				<input type="text" name="s" autocomplete="off" value="<?php echo $_GET['s'];?>">
				</div>
				<div class="search_navright"><input type="submit" value="搜 索"></div>
			</form>
		</div>
</div>
<?php
  $allsearch = new WP_Query("s=$s&showposts=-1");
  $key = wp_specialchars($s, 1);
  $count = $allsearch->post_count;
  wp_reset_query(); ?>
		<div class="search_Position">
			<span class="seartitle">搜索 /</span>
			<p class="searjiguo"><?php echo $_GET['s'];?></p>
			<div class="Position_info_r">
				<p>共找到<span><?php echo $count; ?></span>条相关内容</p>
			</div>
		</div>	
	<ul class="list cl">
	<?php 
  global $query_string;
  query_posts($query_string.'&showposts=24&caller_get_posts=1'); ?>
    <?php if(have_posts()) : ?>
    <?php while(have_posts()) : the_post(); ?>
		<li><a href="<?php the_permalink(); ?>"><?php post_format_vip(); ?><img lazysrc="<?php attachment_timthumb_src(205,277);?>" alt="<?php the_title(); ?>">
		<div class="itemset-num"><span class="text"><?php post_format(); ?></span></div>
				<div class="txtbts"><?php the_title(); ?></div></a></li>
	<?php endwhile; ?>
    <?php endif; ?>
	</ul>
	<?php if(!have_posts()):?>
<div style="width:100%; height:200px; background:url(<?php bloginfo('template_url'); ?>/style/images/null.jpg) no-repeat center;"></div>
<?php endif; ?>
	<div class="page cl"><?php pagenavi();?></div>
	</div>	
<?php get_template_part( 'footer', get_post_format() ); ?>
