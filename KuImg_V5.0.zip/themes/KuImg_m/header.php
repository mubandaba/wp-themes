<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta name="applicable-device" content="mobile">
<meta http-equiv="content-language" lang="zh-CN" />
<meta http-equiv="Cache-Control" content="no-transform" />
<meta http-equiv="Cache-Control" content="no-siteapp">
<?php mfthemes_meta();?>
<?php wp_head(); ?>
<?php head_script(); ?>
</head>
<body>
<?php if ( is_single() ) { ?>
<div id="wx_pic" style="margin:0 auto;display:none;"><img src="<?php attachment_timthumb_src(0,0);?>" /></div>
<?php } ?>
<div class="header">
<i id="panelSwitch" class="icon-nav iconfont">&#xe60b;</i>
<h1 style="color: #fff;">
<?php if ( is_home() ) { ?><?php bloginfo('name'); ?>-首页<?php } ?>
<?php if ( is_search() ) { ?><?php _e('搜索&#34;','KuImg');echo $_GET['s'];echo "&#34;";?><?php $paged = get_query_var('paged'); if ( $paged > 1 ) printf(' （第 %s 页） ',$paged); ?><?php } ?>
<?php if ( is_single() ) { ?><a href="/" style="color: #fff;"><< 返回首页</a><?php } ?>
<?php if ( is_archive() ) { ?><?php single_cat_title(); ?><?php $paged = get_query_var('paged'); if ( $paged > 1 ) printf(' （第 %s 页） ',$paged); ?><?php } ?>
<?php if ( is_page() ) { ?>
<?php if( is_page('rand') ){ ?>
<?php _e('随便看看','KuImg'); ?><?php $paged = get_query_var('paged'); if ( $paged > 1 ) printf(' （第 %s 页） ',$paged); ?>
<?php }elseif( is_page('new') ){ ?>
<?php _e('最新更新','KuImg'); ?><?php $paged = get_query_var('paged'); if ( $paged > 1 ) printf(' （第 %s 页） ',$paged); ?>
<?php }else{ ?>
<?php echo wp_trim_words( get_the_title(), 12 ); ?>
<?php }?>
<?php } ?>
<?php if ( is_404() ) { ?>
404-页面未找到
<?php } ?>
</h1>
<a class="avatar" href="/?s"><i class="iconfont">&#xe638;</i></a>
</div>
<?php video_script(); ?>
