<?php
/*
Template Name: APP下载
*/
?>
<?php get_header(); ?>
<div class="bg">
	<div class="cont">
		<div class="c1"><img src="<?php bloginfo('template_url'); ?>/style/images/pximg-app.jpg" style="margin-top: 20px;"></div>
		<div class="dow"><a href="//www.pximg.com/wp-content/uploads/2016/11/pximg_V1.0.apk">Android下载</a></div>
	</div>
</div>
<?php get_footer(); ?>
