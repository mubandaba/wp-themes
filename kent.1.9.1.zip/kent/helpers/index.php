<?php
/**
 * Include theme helpers that improve the theming experience.
 *
 * @package kent
 */

if ( is_admin() ) {

    require_once( 'getting-started/index.php' );

}
