<!--sidebar begin-->
<div class="sidebar">
  <!--s1 begin-->
  <div class="s1">
    <div class="stitle"><p>精彩推荐</p></div>
    <div class="project">
      <div class="thumb ">
        <a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/thumb.jpg" alt="缩略图" class="img-rounded"></a>
      </div>
      <div class="ftitle">
        <span class="label label-success">精华</span> <span><a href="">蘑菇街淘宝客整站网站模板</a></span>
      </div>
    </div>  
  </div>
  <!--s1 end-->
  <!--s2 begin-->
  <div class="s2">
    <div class="stitle"><p>热门文章排行</p></div>
    <div class="sidebar-article">
      <?php cnsecer_get_most_viewed();  ?>

    </div>            
  </div>
  <!--s2 end-->
  <!--s3 begin-->
  <div class="s3">
    <div class="stitle"><p>精彩推荐</p></div>
    <div class="project">
      <div class="thumb ">
        <a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/thumb.jpg" alt="缩略图" class="img-rounded"></a>
      </div>
      <div class="ftitle">
        <span class="label label-success">精华</span> <span><a href="">蘑菇街淘宝客整站网站模板</a></span>
      </div>
    </div>
  </div>
  <!--s3 end-->
</div>
<!--sidebar end-->