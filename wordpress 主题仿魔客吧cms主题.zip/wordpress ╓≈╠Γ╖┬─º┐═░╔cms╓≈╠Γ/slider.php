<div class="slider">
    <div id="carousel-example-captions" class="carousel slide" data-ride="carousel">
      <div class="carousel-inner">
        <div class="item ">
		<img  alt="900x500" src="<?php bloginfo('template_directory');echo '/images/slider/a.jpg'?>"/>	
        </div>
        <div class="item">
		<img  alt="900x500" src="<?php bloginfo('template_directory');echo '/images/slider/b.jpg'; ?>"/>
        </div>
        <div class="item active">
		<img  alt="900x500" src="<?php bloginfo('template_directory');echo '/images/slider/c.jpg' ?>"/>
        </div>
      </div>
       <a class="left carousel-control" href="#carousel-example-captions" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left"></span>
       </a>
      <a class="right carousel-control" href="#carousel-example-captions" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right"></span>
      </a>
    </div>
</div>