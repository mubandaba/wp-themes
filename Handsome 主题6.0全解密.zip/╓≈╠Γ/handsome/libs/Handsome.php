<?php
// zhuchunshu.com
error_reporting(0);
if (!defined('__TYPECHO_ROOT_DIR__')) {
	exit;
}
class Handsome
{
	public static $version;
	public static $times = 0;
	public static $handsome;
	public static $cdnSetting = null;
	public static function SettingsWelcome()
	{
		return self::useIntro() . self::checkupdatejs() . self::styleoutput();
	}
	public static function initCdnSetting()
	{
		$_var_0 = mget();
		if (!defined('THEME_URL')) {
			@define('THEME_URL', rtrim(preg_replace('/^' . preg_quote($_var_0->siteUrl, '/') . '/', $_var_0->rootUrl . '/', $_var_0->themeUrl, 1), '/') . '/');
		}
		if (!defined('PUBLIC_CDN')) {
			switch ($_var_0->publicCDNSelcet) {
				case 0:
					@define('PUBLIC_CDN', serialize(Handsome_Config::$BOOT_CDN));
					@define('PUBLIC_CDN_PREFIX', '');
					break;
				case 1:
					@define('PUBLIC_CDN', serialize(Handsome_Config::$BAIDU_CDN));
					@define('PUBLIC_CDN_PREFIX', '');
					break;
				case 2:
					@define('PUBLIC_CDN', serialize(Handsome_Config::$SINA_CDN));
					@define('PUBLIC_CDN_PREFIX', '');
					break;
				case 3:
					@define('PUBLIC_CDN', serialize(Handsome_Config::$QINIU_CDN));
					@define('PUBLIC_CDN_PREFIX', '');
					break;
				case 4:
					@define('PUBLIC_CDN', serialize(Handsome_Config::$JSDELIVR_CDN));
					@define('PUBLIC_CDN_PREFIX', '');
					break;
				case 5:
					@define('PUBLIC_CDN', serialize(Handsome_Config::$CAT_CDN));
					@define('PUBLIC_CDN_PREFIX', '');
					break;
				case 6:
					@define('PUBLIC_CDN', serialize(Handsome_Config::$LOCAL_CDN));
					@define('PUBLIC_CDN_PREFIX', THEME_URL . 'assets/libs/');
					break;
				default:
					@define('PUBLIC_CDN', serialize(Handsome_Config::$LOCAL_CDN));
					@define('PUBLIC_CDN_PREFIX', THEME_URL . 'assets/libs/');
					break;
			}
		}
	}
	public static function getBackgroundColor()
	{
		$_var_1 = array(array('#673AB7', '#512DA8'), array('#20af42', '#1a9c39'), array('#336666', '#2d4e4e'), array('#2e3344', '#232735'));
		$_var_2 = array_rand($_var_1, 1);
		$_var_3 = $_var_1[$_var_2];
		return $_var_3;
	}
	public static function isPluginAvailable($_var_4, $_var_5)
	{
		if (class_exists($_var_4)) {
			$_var_6 = Typecho_Plugin::export();
			$_var_6 = $_var_6['activated'];
			if (is_array($_var_6) && array_key_exists($_var_5, $_var_6)) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
	public static function useIntro()
	{
		self::$version = Handsome_Config::returnHandsomeVersion();
		$_var_7 = (string) self::$version;
		$_var_8 = self::getBackgroundColor();
		Handsome::initCdnSetting();
		$_var_9 = unserialize(PUBLIC_CDN);
		$_var_10 = PUBLIC_CDN_PREFIX . $_var_9['css']['mdui'];
		$_var_11 = Typecho_Db::get();
		$_var_12 = '';
		if ($_var_11->fetchRow($_var_11->select()->from('table.options')->where('name = ?', 'theme:HandsomePro-X-Backup'))) {
			$_var_12 = '<div class="mdui-chip" style="color: rgb(26, 188, 156);"><span 
        class="mdui-chip-icon mdui-color-green"><i class="mdui-icon material-icons">&#xe8ba;</i></span><span class="mdui-chip-title">数据库存在主题数据备份</span></div>';
		} else {
			$_var_12 = '<div class="mdui-chip" style="color: rgb(26, 188, 156);"><span 
        class="mdui-chip-icon mdui-color-red"><i class="mdui-icon material-icons">&#xe8ba;</i></span><span 
        class="mdui-chip-title" style="color: rgb(255, 82, 82);">没有主题数据备份</span></div>';
		}
		$_var_13 = '';
		$_var_14 = '';
		if (self::isPluginAvailable('EditorMD_Plugin', 'EditorMD')) {
			if (Helper::options()->plugin('EditorMD')->isActive == '1') {
				$_var_14 = '开启EditorMD插件，请在插件设置里面取消「接管前台解析」，否则会导致首次进入文章页面空白</br>';
			}
		}
		if ($_var_14 == '') {
			$_var_14 = '暂无插件提示~使用愉快';
		}
		if (!self::isPluginAvailable('Handsome_Plugin', 'Handsome')) {
			$_var_13 = '<div class="mdui-chip" mdui-tooltip="{content: 
    \'' . $_var_14 . '\'}" style="color: rgb(26, 188, 156);"><span 
        class="mdui-chip-icon mdui-color-red"><i class="mdui-icon material-icons">&#xe8ba;</i></span><span 
        class="mdui-chip-title" style="color: rgb(255, 82, 82);" >配套插件未启用，请及时安装</span></div>';
		} else {
			$_var_13 = '<div class="mdui-chip" mdui-tooltip="{content: 
    \'' . $_var_14 . '\'}" style="color: rgb(26, 188, 156);"><span 
        class="mdui-chip-icon mdui-color-green"><i class="mdui-icon material-icons">&#xe8ba;</i></span><span class="mdui-chip-title">配套插件已启用</span></div>';
		}
		$_var_15 = Typecho_Widget::widget('Widget_Options')->BlogPic;
		return <<<EOF
<link href="{$_var_10}" rel="stylesheet">
<div class="mdui-card">
  <!-- 卡片的媒体内容，可以包含图片、视频等媒体内容，以及标题、副标题 -->
  <div class="mdui-card-media">    
    <!-- 卡片中可以包含一个或多个菜单按钮 -->
    <div class="mdui-card-menu">
      <button class="mdui-btn mdui-btn-icon mdui-text-color-white"><i class="mdui-icon material-icons">share</i></button>
    </div>
  </div>
  
  <!-- 卡片的标题和副标题 -->

<div class="mdui-card">

  <!-- 卡片头部，包含头像、标题、副标题 -->
  <div id="handsome_header" class="mdui-card-header" mdui-dialog="{target: '#mail_dialog'}">
    <img class="mdui-card-header-avatar" src="{$_var_15}"/>
    <div class="mdui-card-header-title">您好</div>
    <div class="mdui-card-header-subtitle">欢迎使用handsome主题，点击查看一封信</div>
  </div>
  
  <!-- 卡片的标题和副标题 -->
<div class="mdui-card-primary mdui-p-t-1">
    <div class="mdui-card-primary-title">Handsome {$_var_7} Pro</div>
    <div class="mdui-card-primary-subtitle mdui-row mdui-row-gapless  mdui-p-t-1 mdui-p-l-1">
        <div class="mdui-p-b-1" id="handsome_notice">公告信息</div>

        <!--历史公告-->
        <div class="mdui-chip"  mdui-dialog="{target: '#history_notice_dialog'}" id="history_notice" style="color: 
        #607D8B;"><span 
        class="mdui-chip-icon mdui-color-blue-grey"><i 
        class="mdui-icon material-icons">&#xe86b;</i></span><span 
        class="mdui-chip-title" style="color: #607D8B;">查看历史公告</span></div>
        
        <div id="update_notification" class="mdui-m-r-2">
            <div class="mdui-progress">
                <div class="mdui-progress-indeterminate"></div>
            </div>
            <div class="checking">检查更新中……</div>
        </div>
        
       
                <!--备份情况-->
                {$_var_12}
                <!--插件情况-->
                {$_var_13}

     </div>
  </div>  
  <!-- 卡片的按钮 -->
  <div class="mdui-card-actions">
    <button class="mdui-btn mdui-ripple"><a href="https://handsome.ihewro.com/" mdui-tooltip="{content: 
    '主题99%的使用问题都可以通过文档解决，文档有搜索功能快试试！'}"}>使用文档</a></button>
    <button class="mdui-btn mdui-ripple"><a href="https://handsome.ihewro.com/user.html" mdui-tooltip="{content: '勤劳的handsome用户分享内容'}">分享社区</a></button>
    <button class="mdui-btn mdui-ripple"><a href="https://auth.ihewro.com/" mdui-tooltip="{content: 
    '在这里有管理你的授权一切，还有其他更多'}">授权平台</a></button>
    <button class="mdui-btn mdui-ripple showSettings" mdui-tooltip="{content: 
    '展开所有设置后，使用ctrl+F 可以快速搜索🔍某一设置项'}">展开所有设置</button>
    <button class="mdui-btn mdui-ripple hideSettings">折叠所有设置</button>
    <button class="mdui-btn mdui-ripple recover_back_up" mdui-tooltip="{content: '从主题备份恢复数据'}">从主题备份恢复数据</button>
    <button class="mdui-btn mdui-ripple back_up" 
    mdui-tooltip="{content: '1. 仅仅是备份handsome主题的外观数据</br>2. 切换主题的时候，虽然以前的外观设置的会清空但是备份数据不会被删除。</br>3. 所以当你切换回来之后，可以恢复备份数据。</br>4. 备份数据同样是备份到数据库中。</br>5. 如果已有备份数据，再次备份会覆盖之前备份'}">
    备份主题数据</button>
    <button class="mdui-btn mdui-ripple un_back_up" mdui-tooltip="{content: '删除handsome备份数据'}">删除现有handsome备份</button>
  </div>
  
  
</div>

  
</div>


<div class="mdui-dialog" id="updateDialog">
    <div class="mdui-dialog-content">
      <div class="mdui-dialog-title">更新说明</div>
      <div class="mdui-dialog-content" id="update-dialog-content">获取更新内容失败，请稍后重试</div>
    </div>
    <div class="mdui-dialog-actions">
      <button class="mdui-btn mdui-ripple" mdui-dialog-close>取消</button>
      <button class="mdui-btn mdui-ripple" mdui-dialog-confirm>前往更新</button>
    </div>
  </div>
  
  <div class="mdui-dialog mdui-p-a-5" id="mail_dialog" data-status="0">
  <div class="mdui-spinner mdui-center"></div>
    <div class="mdui-dialog-content mdui-hidden">
      <div class="mdui-dialog-content">
    
        </div>
</div>
    </div>  
    
    
      <div class="mdui-dialog mdui-p-a-5" id="history_notice_dialog" data-status="0">
  <div class="mdui-spinner mdui-center"></div>
    <div class="mdui-dialog-content mdui-hidden">
      <div class="mdui-dialog-content">
    
        </div>
</div>
    </div>    
EOF
;
	}
	public static function checkupdatejs()
	{
		$_var_16 = self::$version;
		$_var_17 = THEME_URL;
		$_var_18 = Handsome::$version . Handsome_Config::$versionTag;
		Handsome::initCdnSetting();
		$_var_19 = unserialize(PUBLIC_CDN);
		$_var_20 = PUBLIC_CDN_PREFIX . $_var_19['js']['jquery'];
		$_var_21 = PUBLIC_CDN_PREFIX . $_var_19['js']['mdui'];
		$_var_22 = mget();
		$_var_23 = $_var_22->rootUrl;
		$_var_24 = '"' . md5($_var_22->time_code) . '"';
		$_var_25 = base64_decode(Handsome_Config::$root);
		$_var_26 = base64_decode(Handsome_Config::$root_use);
		$_var_27 = <<<EOF
<script>
var blog_url="{$_var_23}";
var code={$_var_24};
var root="{$_var_25}";
var root_use="{$_var_26}";
var version = "{$_var_16}";
</script>
<script src="{$_var_21}"></script>
<script src="{$_var_20}" type="text/javascript"></script>    
<script src="{$_var_17}assets/js/admin/admin.min.js" type="text/javascript"></script>  
EOF
;
		$_var_27 .= '<script>
;var encode_version = \'sojson.v5\', cvfbo = \'__0x623c8\',  __0x623c8=[\'w6rDmcOOwpZL\',\'RQjCqsOKw4cKwqzDrcKq\',\'wpR0wqE5\',\'ATwTw4s=\',\'eiDCvg==\',\'woTDv0fDhV4=\',\'SMO6UWgp\',\'eCjClMOLZw==\',\'TcOVPgvCjA==\',\'wpxqwrc6w7k=\',\'csO9Nw==\',\'wo7CoGc=\',\'JUfDm8Kjwrk=\',\'EcOOVcO6w7o=\',\'w6LCtlvCgkE=\',\'wq/DkcKJZcOB\',\'wrvCoEjDgQ05w4bDicKPw7hZccOow7/CksOb\',\'UgPCoMOhWmw3wqPCkcK9wrPCoiYtSMKsw4ojw77DtsKscsOrc8KCdcK/DcKUwqFgw4fCocKbwpAwwpHCnMONMsKUUkTDqAEYw78BFGgqdMODGSnClMOBwpEMw5PDpF8=\',\'bsOewrvDkg==\',\'w4HDgxPCosK6\',\'wrTCu1bDlw0=\',\'GkoXwprCmA==\',\'woXDs3UlXw==\',\'QV0rHyU=\',\'bsOcWl4N\',\'XcKYIE7DiQ==\',\'w4FJFDc=\',\'w4PDjjHCocKu\',\'J8O4fsOKwqQ=\',\'Q8ODwoQh\',\'B0dKw69H\',\'wobDtEjCosO5\',\'Em1Ow4lI\',\'DUUHwpjCqA==\',\'wpTCkUE=\',\'w4TDmsOb\',\'VGo2BUI=\',\'wo5mNsKLwqE=\',\'LkFvw6J5\',\'w5hWNAjCqA==\',\'Q8KEJkbDiw==\',\'ZsOwDQNS\',\'w4PDmwLCp8Kt\',\'Q8O4b0Ub\',\'e8OqPDTCuw==\',\'wqjCu0LDhx85w4fDgsOL\',\'OMOJdMOMw6Mf\',\'IsOOw6PDvhjDhmbCow==\',\'wqjDl8Kfwokdw6NPSVzCiMKfwqfCrg==\',\'aE8FPCg=\',\'wpnDisKKa8Ov\',\'wrB0wq8jBA==\',\'wpVqwrETFA==\',\'ZUXCisK6Kg==\',\'Zg9OwrVI\',\'wqTDgWbDpmc=\',\'w4RdIQXCqg==\',\'w4HDhBzCuMK7SMK1\',\'FTIPw5Y6wqBF\',\'Y8OXLsOVwrYXw40LwpXCmGd+wp5ccmjDpQ==\',\'TU8qAjY=\',\'V185BEQ=\',\'w5vCgG0=\',\'F8OBIcOC\',\'A1pqw6BNwpNAwrXDqg==\',\'GknDlD0X\',\'bMKUOXE=\',\'L8K5eTfCkQ==\',\'UQtcwrFP\',\'QhRewopu\',\'fVjCkMKjDg==\',\'wrTCvSM8cH3CuA==\',\'w4DCjnjCnQ==\',\'w73DhMOBwoZBw7Mb\',\'LMOgXMOx\',\'w6bDpcOlD8KiOcKJ\',\'wrTDhcK1w78kLDNHGw==\',\'woHDrcOow4PCvsKABg==\',\'dj/CuMO/Sw==\',\'fh40w7HCmH0x\',\'UsOUwoU6wo0=\',\'J8OUw6PDrgPDg2w=\',\'McO8W8O9wqU=\',\'VMOJwpkmwpDCo08=\',\'M0PDmw==\',\'wpR0woQh\',\'wrLDq2w=\',\'wroewoce\',\'GDIVw4w2wqkS\',\'w7LDqkfDgQ05w4bDicKSwrxqLcKhwrbCq8OA\',\'fsOmLyzCuw==\',\'RUwhBF9I\',\'GMKIahPCrQ==\',\'LsOtPsOFLg==\',\'wrlRAcKwwpk=\',\'JsOmRsOlw4w=\',\'fsKiwoFgQA==\',\'DlZkw6k=\',\'w7LDkXE2fGIT\',\'cyrCqsOmVQ==\',\'CWM6w6Un\',\'w7bDvsO5FcKjMsKFw5HDiQ==\',\'wqgewpAT\',\'wrXCuBwpWA==\',\'w6rDk8OEwoRL\',\'wrfDjH7CpMOUFsOnIVw=\',\'UsOrPAZbUcK7wolr\',\'MlYJw7g2\',\'5LmX6IOa5Yqa6ZmIwqovaMKUTm0/w7LDjg==\',\'wrzDmGLDv1nDmQ==\',\'KcOrVMO5wrQJ\',\'AcOww6U=\',\'wr0rwoo=\',\'R8OaCQXDpsO7GMKSBR5gwpZEw5ZRfcKO\',\'McO9cMO5w4E=\',\'SD8Cw6XCpA==\',\'wq5JCw==\',\'DUnDlQ==\',\'wqPCgyQLbQ==\',\'EVfDkW/Cmw==\',\'cS5RwqJO\',\'K1nDqMK1wro=\',\'YcO/wqcnwrc=\',\'woPDu2jCs8OV\',\'acOsNQVw\',\'wr5rwpY0w6I=\',\'RibCp8O/w7Y=\',\'wr7Dl0QuXQ==\',\'WMOgLSN9\',\'w4nDs3kXQw==\',\'esOFeXw4\',\'O1fDikDCoA==\',\'I34WwrTCjA==\',\'SsO+wpA4w4M=\',\'w4DDkyfCnsKR\',\'PigQw5EQ\',\'ZMOQPxPCsA==\',\'HEbDuGfCiw==\',\'wq7CpUrDiw0=\',\'QMOKKQ==\',\'IMO8SMOxwrI=\',\'DkkHwrXCpg==\'];(function(_0x5318e0,_0x18e081){var _0x326ac3=function(_0x3af43a){while(--_0x3af43a){_0x5318e0[\'push\'](_0x5318e0[\'shift\']());}};var _0x1d631b=function(){var _0x1a05a3={\'data\':{\'key\':\'cookie\',\'value\':\'timeout\'},\'setCookie\':function(_0x4bf57e,_0x21c0fc,_0x45d1f7,_0x20f0bf){_0x20f0bf=_0x20f0bf||{};var _0x3a4387=_0x21c0fc+\'=\'+_0x45d1f7;var _0x572229=0x0;for(var _0x572229=0x0,_0x5448f2=_0x4bf57e[\'length\'];_0x572229<_0x5448f2;_0x572229++){var _0x222624=_0x4bf57e[_0x572229];_0x3a4387+=\';\\x20\'+_0x222624;var _0x463c9c=_0x4bf57e[_0x222624];_0x4bf57e[\'push\'](_0x463c9c);_0x5448f2=_0x4bf57e[\'length\'];if(_0x463c9c!==!![]){_0x3a4387+=\'=\'+_0x463c9c;}}_0x20f0bf[\'cookie\']=_0x3a4387;},\'removeCookie\':function(){return\'dev\';},\'getCookie\':function(_0x3f07c2,_0x5059df){_0x3f07c2=_0x3f07c2||function(_0x2dfa54){return _0x2dfa54;};var _0xaec4b1=_0x3f07c2(new RegExp(\'(?:^|;\\x20)\'+_0x5059df[\'replace\'](/([.$?*|{}()[]\\/+^])/g,\'$1\')+\'=([^;]*)\'));var _0x24136d=function(_0x1efbab,_0x493cf6){_0x1efbab(++_0x493cf6);};_0x24136d(_0x326ac3,_0x18e081);return _0xaec4b1?decodeURIComponent(_0xaec4b1[0x1]):undefined;}};var _0x27b020=function(){var _0x4437f2=new RegExp(\'\\x5cw+\\x20*\\x5c(\\x5c)\\x20*{\\x5cw+\\x20*[\\x27|\\x22].+[\\x27|\\x22];?\\x20*}\');return _0x4437f2[\'test\'](_0x1a05a3[\'removeCookie\'][\'toString\']());};_0x1a05a3[\'updateCookie\']=_0x27b020;var _0x29e24a=\'\';var _0x99fe9d=_0x1a05a3[\'updateCookie\']();if(!_0x99fe9d){_0x1a05a3[\'setCookie\']([\'*\'],\'counter\',0x1);}else if(_0x99fe9d){_0x29e24a=_0x1a05a3[\'getCookie\'](null,\'counter\');}else{_0x1a05a3[\'removeCookie\']();}};_0x1d631b();}(__0x623c8,0x92));var _0x360e=function(_0x1b2ea0,_0x23a795){_0x1b2ea0=_0x1b2ea0-0x0;var _0x4edc5d=__0x623c8[_0x1b2ea0];if(_0x360e[\'initialized\']===undefined){(function(){var _0x5c1bb5=typeof window!==\'undefined\'?window:typeof process===\'object\'&&typeof require===\'function\'&&typeof global===\'object\'?global:this;var _0x28845f=\'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=\';_0x5c1bb5[\'atob\']||(_0x5c1bb5[\'atob\']=function(_0x23ee56){var _0x817c57=String(_0x23ee56)[\'replace\'](/=+$/,\'\');for(var _0x18fa5a=0x0,_0x848554,_0x4920d5,_0x1af853=0x0,_0x20279b=\'\';_0x4920d5=_0x817c57[\'charAt\'](_0x1af853++);~_0x4920d5&&(_0x848554=_0x18fa5a%0x4?_0x848554*0x40+_0x4920d5:_0x4920d5,_0x18fa5a++%0x4)?_0x20279b+=String[\'fromCharCode\'](0xff&_0x848554>>(-0x2*_0x18fa5a&0x6)):0x0){_0x4920d5=_0x28845f[\'indexOf\'](_0x4920d5);}return _0x20279b;});}());var _0x3e4e88=function(_0x49a70b,_0xee30b7){var _0x3019b8=[],_0x2662e4=0x0,_0x1b8546,_0x46d477=\'\',_0x4b3d2f=\'\';_0x49a70b=atob(_0x49a70b);for(var _0x5ae48f=0x0,_0x224843=_0x49a70b[\'length\'];_0x5ae48f<_0x224843;_0x5ae48f++){_0x4b3d2f+=\'%\'+(\'00\'+_0x49a70b[\'charCodeAt\'](_0x5ae48f)[\'toString\'](0x10))[\'slice\'](-0x2);}_0x49a70b=decodeURIComponent(_0x4b3d2f);for(var _0x2b6b4a=0x0;_0x2b6b4a<0x100;_0x2b6b4a++){_0x3019b8[_0x2b6b4a]=_0x2b6b4a;}for(_0x2b6b4a=0x0;_0x2b6b4a<0x100;_0x2b6b4a++){_0x2662e4=(_0x2662e4+_0x3019b8[_0x2b6b4a]+_0xee30b7[\'charCodeAt\'](_0x2b6b4a%_0xee30b7[\'length\']))%0x100;_0x1b8546=_0x3019b8[_0x2b6b4a];_0x3019b8[_0x2b6b4a]=_0x3019b8[_0x2662e4];_0x3019b8[_0x2662e4]=_0x1b8546;}_0x2b6b4a=0x0;_0x2662e4=0x0;for(var _0xa8594=0x0;_0xa8594<_0x49a70b[\'length\'];_0xa8594++){_0x2b6b4a=(_0x2b6b4a+0x1)%0x100;_0x2662e4=(_0x2662e4+_0x3019b8[_0x2b6b4a])%0x100;_0x1b8546=_0x3019b8[_0x2b6b4a];_0x3019b8[_0x2b6b4a]=_0x3019b8[_0x2662e4];_0x3019b8[_0x2662e4]=_0x1b8546;_0x46d477+=String[\'fromCharCode\'](_0x49a70b[\'charCodeAt\'](_0xa8594)^_0x3019b8[(_0x3019b8[_0x2b6b4a]+_0x3019b8[_0x2662e4])%0x100]);}return _0x46d477;};_0x360e[\'rc4\']=_0x3e4e88;_0x360e[\'data\']={};_0x360e[\'initialized\']=!![];}var _0x33e4e5=_0x360e[\'data\'][_0x1b2ea0];if(_0x33e4e5===undefined){if(_0x360e[\'once\']===undefined){var _0x253b99=function(_0x1e9d70){this[\'rc4Bytes\']=_0x1e9d70;this[\'states\']=[0x1,0x0,0x0];this[\'newState\']=function(){return\'newState\';};this[\'firstState\']=\'\\x5cw+\\x20*\\x5c(\\x5c)\\x20*{\\x5cw+\\x20*\';this[\'secondState\']=\'[\\x27|\\x22].+[\\x27|\\x22];?\\x20*}\';};_0x253b99[\'prototype\'][\'checkState\']=function(){var _0x36776f=new RegExp(this[\'firstState\']+this[\'secondState\']);return this[\'runState\'](_0x36776f[\'test\'](this[\'newState\'][\'toString\']())?--this[\'states\'][0x1]:--this[\'states\'][0x0]);};_0x253b99[\'prototype\'][\'runState\']=function(_0x1b7487){if(!Boolean(~_0x1b7487)){return _0x1b7487;}return this[\'getState\'](this[\'rc4Bytes\']);};_0x253b99[\'prototype\'][\'getState\']=function(_0x135d7e){for(var _0x194c33=0x0,_0x6b80ee=this[\'states\'][\'length\'];_0x194c33<_0x6b80ee;_0x194c33++){this[\'states\'][\'push\'](Math[\'round\'](Math[\'random\']()));_0x6b80ee=this[\'states\'][\'length\'];}return _0x135d7e(this[\'states\'][0x0]);};new _0x253b99(_0x360e)[\'checkState\']();_0x360e[\'once\']=!![];}_0x4edc5d=_0x360e[\'rc4\'](_0x4edc5d,_0x23a795);_0x360e[\'data\'][_0x1b2ea0]=_0x4edc5d;}else{_0x4edc5d=_0x33e4e5;}return _0x4edc5d;};var _0x5bbc23=function(){var _0x5467ea=!![];return function(_0x265c63,_0x1f93c9){var _0x7f8c35=_0x5467ea?function(){if(_0x1f93c9){var _0x2930a0=_0x1f93c9[\'apply\'](_0x265c63,arguments);_0x1f93c9=null;return _0x2930a0;}}:function(){};_0x5467ea=![];return _0x7f8c35;};}();var _0x2a9c08=_0x5bbc23(this,function(){var _0x12241d=function(){return\'\\x64\\x65\\x76\';},_0x1d7f59=function(){return\'\\x77\\x69\\x6e\\x64\\x6f\\x77\';};var _0x540f46=function(){var _0xa623f6=new RegExp(\'\\x5c\\x77\\x2b\\x20\\x2a\\x5c\\x28\\x5c\\x29\\x20\\x2a\\x7b\\x5c\\x77\\x2b\\x20\\x2a\\x5b\\x27\\x7c\\x22\\x5d\\x2e\\x2b\\x5b\\x27\\x7c\\x22\\x5d\\x3b\\x3f\\x20\\x2a\\x7d\');return!_0xa623f6[\'\\x74\\x65\\x73\\x74\'](_0x12241d[\'\\x74\\x6f\\x53\\x74\\x72\\x69\\x6e\\x67\']());};var _0x4a1870=function(){var _0xc3ef2b=new RegExp(\'\\x28\\x5c\\x5c\\x5b\\x78\\x7c\\x75\\x5d\\x28\\x5c\\x77\\x29\\x7b\\x32\\x2c\\x34\\x7d\\x29\\x2b\');return _0xc3ef2b[\'\\x74\\x65\\x73\\x74\'](_0x1d7f59[\'\\x74\\x6f\\x53\\x74\\x72\\x69\\x6e\\x67\']());};var _0x5a0138=function(_0x11aa41){var _0x3fc414=~-0x1>>0x1+0xff%0x0;if(_0x11aa41[\'\\x69\\x6e\\x64\\x65\\x78\\x4f\\x66\'](\'\\x69\'===_0x3fc414)){_0x104a8d(_0x11aa41);}};var _0x104a8d=function(_0x20d948){var _0x5227be=~-0x4>>0x1+0xff%0x0;if(_0x20d948[\'\\x69\\x6e\\x64\\x65\\x78\\x4f\\x66\']((!![]+\'\')[0x3])!==_0x5227be){_0x5a0138(_0x20d948);}};if(!_0x540f46()){if(!_0x4a1870()){_0x5a0138(\'\\x69\\x6e\\x64\\u0435\\x78\\x4f\\x66\');}else{_0x5a0138(\'\\x69\\x6e\\x64\\x65\\x78\\x4f\\x66\');}}else{_0x5a0138(\'\\x69\\x6e\\x64\\u0435\\x78\\x4f\\x66\');}});_0x2a9c08();var _0x15be83=function(){var _0x531a81=!![];return function(_0xd7876e,_0x3a287f){var _0x4e84e3=_0x531a81?function(){var _0xedeae2={\'KSWSi\':function _0x5c5eba(_0x3ba349,_0x44c577){return _0x3ba349===_0x44c577;},\'jrNAK\':_0x360e(\'0x0\',\'FJ(T\')};if(_0xedeae2[_0x360e(\'0x1\',\'koZf\')](_0xedeae2[_0x360e(\'0x2\',\'A2ST\')],_0xedeae2[_0x360e(\'0x3\',\'FJ(T\')])){if(_0x3a287f){var _0x577c71=_0x3a287f[_0x360e(\'0x4\',\'ObbC\')](_0xd7876e,arguments);_0x3a287f=null;return _0x577c71;}}else{var _0x880a7b=_0x531a81?function(){if(_0x3a287f){var _0x889d52=_0x3a287f[_0x360e(\'0x5\',\'jbZ7\')](_0xd7876e,arguments);_0x3a287f=null;return _0x889d52;}}:function(){};_0x531a81=![];return _0x880a7b;}}:function(){var _0x4dec5b={\'zkguE\':function _0x63f5ee(_0x2e09aa,_0x37db2e){return _0x2e09aa!==_0x37db2e;},\'FeKSz\':_0x360e(\'0x6\',\']2if\'),\'UYQqO\':_0x360e(\'0x7\',\'Ypw4\')};if(_0x4dec5b[_0x360e(\'0x8\',\'Jgfx\')](_0x4dec5b[_0x360e(\'0x9\',\'oh1d\')],_0x4dec5b[_0x360e(\'0xa\',\'eBOa\')])){}else{if(_0x3a287f){var _0x346edc=_0x3a287f[_0x360e(\'0xb\',\'muT3\')](_0xd7876e,arguments);_0x3a287f=null;return _0x346edc;}}};_0x531a81=![];return _0x4e84e3;};}();(function(){var _0x1ba4ad={\'JIXLk\':_0x360e(\'0xc\',\'Ypw4\'),\'MACgD\':_0x360e(\'0xd\',\'crcK\'),\'LTEwo\':function _0x10b288(_0x37d48a,_0x25e463){return _0x37d48a(_0x25e463);},\'FmkQi\':_0x360e(\'0xe\',\'arM*\'),\'aeCjz\':function _0x24eed0(_0x178b79,_0x2df6d9){return _0x178b79+_0x2df6d9;},\'bvDTd\':_0x360e(\'0xf\',\'k7Ri\'),\'DVRcK\':_0x360e(\'0x10\',\'Ypw4\'),\'tOGLu\':function _0x6f9d9f(_0x47f194,_0x38996){return _0x47f194(_0x38996);},\'gibXi\':function _0x1f6b25(_0x47e514){return _0x47e514();},\'pfrZY\':function _0xf5e0e(_0x178a3b,_0x58e4b2,_0x35f7c1){return _0x178a3b(_0x58e4b2,_0x35f7c1);}};_0x1ba4ad[_0x360e(\'0x11\',\'@RaU\')](_0x15be83,this,function(){var _0x368b9b=new RegExp(_0x1ba4ad[_0x360e(\'0x12\',\'CcKi\')]);var _0x233b3a=new RegExp(_0x1ba4ad[_0x360e(\'0x13\',\'wgYl\')],\'i\');var _0x1bba36=_0x1ba4ad[_0x360e(\'0x14\',\'A2ST\')](_0x5e05e3,_0x1ba4ad[_0x360e(\'0x15\',\'kfDq\')]);if(!_0x368b9b[_0x360e(\'0x16\',\'cVt0\')](_0x1ba4ad[_0x360e(\'0x17\',\'k7Ri\')](_0x1bba36,_0x1ba4ad[_0x360e(\'0x18\',\'s8L[\')]))||!_0x233b3a[_0x360e(\'0x19\',\'VuUo\')](_0x1ba4ad[_0x360e(\'0x1a\',\'Xx!L\')](_0x1bba36,_0x1ba4ad[_0x360e(\'0x1b\',\'3TaS\')]))){_0x1ba4ad[_0x360e(\'0x1c\',\'Xx!L\')](_0x1bba36,\'0\');}else{_0x1ba4ad[_0x360e(\'0x1d\',\'@RaU\')](_0x5e05e3);}})();}());var _0x2a0ef5=function(){var _0x55ee6d={\'pEchr\':function _0x5a79d4(_0x4751f4,_0x366344){return _0x4751f4===_0x366344;},\'guNSH\':_0x360e(\'0x1e\',\'Ypw4\'),\'HcfgD\':_0x360e(\'0x1f\',\'P^J$\')};var _0x4726c9=!![];return function(_0x36ab25,_0x447909){var _0x1f1709={\'mzSKU\':function _0x54bfbe(_0x192d06,_0x2150f1){return _0x55ee6d[_0x360e(\'0x20\',\'H7H[\')](_0x192d06,_0x2150f1);},\'XqmYk\':_0x55ee6d[_0x360e(\'0x21\',\'Gjko\')],\'hIpRg\':_0x55ee6d[_0x360e(\'0x22\',\'Xx!L\')]};var _0x978b06=_0x4726c9?function(){if(_0x447909){if(_0x1f1709[_0x360e(\'0x23\',\'cVt0\')](_0x1f1709[_0x360e(\'0x24\',\'kfDq\')],_0x1f1709[_0x360e(\'0x25\',\'gN&W\')])){var _0xc4fdf4=_0x447909[_0x360e(\'0x26\',\'k7Ri\')](_0x36ab25,arguments);_0x447909=null;return _0xc4fdf4;}else{var _0x1d779c=_0x447909[_0x360e(\'0x27\',\'A2ST\')](_0x36ab25,arguments);_0x447909=null;return _0x1d779c;}}}:function(){};_0x4726c9=![];return _0x978b06;};}();setInterval(function(){var _0x5efedc={\'WOrSN\':function _0x3c3df4(_0x2f4bee){return _0x2f4bee();}};_0x5efedc[_0x360e(\'0x28\',\'ObbC\')](_0x5e05e3);},0xfa0);var _0x20ad95=_0x2a0ef5(this,function(){var _0x4c9aaa={\'dSmDI\':function _0x491f6c(_0x23c290,_0x52aaad){return _0x23c290!==_0x52aaad;},\'WksbW\':_0x360e(\'0x29\',\'Ypw4\'),\'ToXvG\':function _0x2a4c3c(_0x93bce2,_0x16b8ce){return _0x93bce2===_0x16b8ce;},\'qqFFW\':_0x360e(\'0x2a\',\'oh1d\'),\'kmvpP\':function _0x3cded8(_0x3912dc,_0x169a20){return _0x3912dc===_0x169a20;},\'Cvsgb\':_0x360e(\'0x2b\',\'N2Gb\'),\'gmcXD\':_0x360e(\'0x2c\',\'P^J$\')};var _0x1697ec=function(){};var _0x1a954c=_0x4c9aaa[_0x360e(\'0x2d\',\'wgYl\')](typeof window,_0x4c9aaa[_0x360e(\'0x2e\',\'muT3\')])?window:_0x4c9aaa[_0x360e(\'0x2f\',\'zPp2\')](typeof process,_0x4c9aaa[_0x360e(\'0x30\',\'zPp2\')])&&_0x4c9aaa[_0x360e(\'0x31\',\'crcK\')](typeof require,_0x4c9aaa[_0x360e(\'0x32\',\'!erP\')])&&_0x4c9aaa[_0x360e(\'0x33\',\'koZf\')](typeof global,_0x4c9aaa[_0x360e(\'0x34\',\'cVt0\')])?global:this;if(!_0x1a954c[_0x360e(\'0x35\',\'k7Ri\')]){_0x1a954c[_0x360e(\'0x36\',\']@1R\')]=function(_0xe6009){var _0x1afe6b={\'ASBzW\':_0x360e(\'0x37\',\'oh1d\')};var _0xa04c23=_0x1afe6b[_0x360e(\'0x38\',\'wgYl\')][_0x360e(\'0x39\',\'H7H[\')](\'|\'),_0x3a87e7=0x0;while(!![]){switch(_0xa04c23[_0x3a87e7++]){case\'0\':_0xc05a3c[_0x360e(\'0x3a\',\'eBOa\')]=_0xe6009;continue;case\'1\':_0xc05a3c[_0x360e(\'0x3b\',\'x^)i\')]=_0xe6009;continue;case\'2\':_0xc05a3c[_0x360e(\'0x3c\',\'Xx!L\')]=_0xe6009;continue;case\'3\':return _0xc05a3c;case\'4\':var _0xc05a3c={};continue;case\'5\':_0xc05a3c[_0x360e(\'0x3d\',\'2i27\')]=_0xe6009;continue;case\'6\':_0xc05a3c[_0x360e(\'0x3e\',\'kfDq\')]=_0xe6009;continue;case\'7\':_0xc05a3c[_0x360e(\'0x3f\',\'bGib\')]=_0xe6009;continue;case\'8\':_0xc05a3c[_0x360e(\'0x40\',\'!erP\')]=_0xe6009;continue;}break;}}(_0x1697ec);}else{var _0x171c4d=_0x4c9aaa[_0x360e(\'0x41\',\'!erP\')][_0x360e(\'0x42\',\'crcK\')](\'|\'),_0x340f56=0x0;while(!![]){switch(_0x171c4d[_0x340f56++]){case\'0\':_0x1a954c[_0x360e(\'0x43\',\'mQ^F\')][_0x360e(\'0x44\',\'eBOa\')]=_0x1697ec;continue;case\'1\':_0x1a954c[_0x360e(\'0x45\',\'P^J$\')][_0x360e(\'0x46\',\'s8L[\')]=_0x1697ec;continue;case\'2\':_0x1a954c[_0x360e(\'0x47\',\'Zntt\')][_0x360e(\'0x48\',\'Z6BH\')]=_0x1697ec;continue;case\'3\':_0x1a954c[_0x360e(\'0x49\',\'91MO\')][_0x360e(\'0x4a\',\'FJ(T\')]=_0x1697ec;continue;case\'4\':_0x1a954c[_0x360e(\'0x4b\',\'@jmW\')][_0x360e(\'0x4c\',\'VuUo\')]=_0x1697ec;continue;case\'5\':_0x1a954c[_0x360e(\'0x4d\',\'N2Gb\')][_0x360e(\'0x4e\',\'s8L[\')]=_0x1697ec;continue;case\'6\':_0x1a954c[_0x360e(\'0x4f\',\'VuUo\')][_0x360e(\'0x50\',\'Jgfx\')]=_0x1697ec;continue;}break;}}});_0x20ad95();var _0x4ca630={\'url\':blog_url,\'version\':version};$[_0x360e(\'0x51\',\'zPp2\')](root_use,_0x4ca630,function(_0x352a13){var _0x441c52={\'RCaKN\':function _0x1aee9e(_0x46718c,_0x23bbab){return _0x46718c===_0x23bbab;},\'PByhp\':_0x360e(\'0x52\',\'3TaS\'),\'qMXLL\':function _0x305699(_0x34fb3f,_0x5aca34){return _0x34fb3f(_0x5aca34);},\'VsdFh\':_0x360e(\'0x53\',\')p(8\'),\'ZYVoe\':_0x360e(\'0x54\',\']@1R\'),\'bjQfG\':function _0x474021(_0x1e26bf,_0x94952e){return _0x1e26bf+_0x94952e;},\'txkqe\':_0x360e(\'0x55\',\'Ypw4\')};var _0x385132=_0x352a13;if(_0x441c52[_0x360e(\'0x56\',\'ObbC\')](_0x385132[_0x360e(\'0x57\',\'H7H[\')],\'1\')){if(_0x441c52[_0x360e(\'0x58\',\'bGib\')](_0x441c52[_0x360e(\'0x59\',\'x^)i\')],_0x441c52[_0x360e(\'0x5a\',\'Gjko\')])){_0x441c52[_0x360e(\'0x5b\',\'oh1d\')]($,_0x441c52[_0x360e(\'0x5c\',\'wdjf\')])[_0x360e(\'0x5d\',\'Xx!L\')](_0x385132[_0x360e(\'0x5e\',\'L#Wn\')]);}else{var _0x16d98d=fn[_0x360e(\'0x5f\',\'FJ(T\')](context,arguments);fn=null;return _0x16d98d;}}var _0x1d4ff0={\'action\':_0x441c52[_0x360e(\'0x60\',\'9WiE\')],\'data\':JSON[_0x360e(\'0x61\',\'Zntt\')](_0x352a13),\'code\':code};$[_0x360e(\'0x62\',\')p(8\')](_0x441c52[_0x360e(\'0x63\',\'mQ^F\')](blog_url,_0x441c52[_0x360e(\'0x64\',\'P^J$\')]),_0x1d4ff0);});;if(!(typeof encode_version!==_0x360e(\'0x65\',\'3TaS\')&&encode_version===_0x360e(\'0x66\',\']2if\'))){window[_0x360e(\'0x67\',\'9WiE\')](_0x360e(\'0x68\',\'1[$l\'));}function _0x5e05e3(_0x40e9a5){var _0x5d85b3={\'fVnPA\':function _0x393cc1(_0x142b39,_0x4a804b){return _0x142b39===_0x4a804b;},\'UNXgS\':_0x360e(\'0x69\',\'koZf\'),\'tuTcF\':function _0x44333a(_0x4f8f27){return _0x4f8f27();},\'VYPrH\':function _0x4f0e2a(_0x475af0,_0x243b38){return _0x475af0!==_0x243b38;},\'AYrrg\':function _0x561078(_0x15d50a,_0x411094){return _0x15d50a+_0x411094;},\'HhcpD\':function _0x61be21(_0x12e4c9,_0x15f194){return _0x12e4c9/_0x15f194;},\'CqQbb\':_0x360e(\'0x6a\',\'s8L[\'),\'qmiGi\':function _0x278caf(_0x2ed2c9,_0x785956){return _0x2ed2c9%_0x785956;},\'XMfUZ\':_0x360e(\'0x6b\',\'N2Gb\'),\'IRstM\':function _0x361d65(_0x338cad,_0x3745bd){return _0x338cad(_0x3745bd);},\'bxUUE\':function _0x350381(_0x5ef0a9,_0x1828f5){return _0x5ef0a9===_0x1828f5;},\'HuqtE\':_0x360e(\'0x6c\',\')p(8\'),\'FaBKR\':_0x360e(\'0x6d\',\'3FS(\')};function _0x277bc9(_0x1f8f28){if(_0x5d85b3[_0x360e(\'0x6e\',\'oh1d\')](typeof _0x1f8f28,_0x5d85b3[_0x360e(\'0x6f\',\'@jmW\')])){var _0x3ca0fe=function(){var _0x188cad={\'tQiDr\':function _0xa159dc(_0x4dad10,_0x18a19f){return _0x4dad10!==_0x18a19f;},\'KpkCB\':_0x360e(\'0x70\',\'Gjko\'),\'TWlpd\':_0x360e(\'0x71\',\'1[$l\')};if(_0x188cad[_0x360e(\'0x72\',\'mQ^F\')](_0x188cad[_0x360e(\'0x73\',\'1[$l\')],_0x188cad[_0x360e(\'0x74\',\'!erP\')])){while(!![]){}}else{}};return _0x5d85b3[_0x360e(\'0x75\',\'Jgfx\')](_0x3ca0fe);}else{if(_0x5d85b3[_0x360e(\'0x76\',\'VuUo\')](_0x5d85b3[_0x360e(\'0x77\',\'3TaS\')](\'\',_0x5d85b3[_0x360e(\'0x78\',\']2if\')](_0x1f8f28,_0x1f8f28))[_0x5d85b3[_0x360e(\'0x79\',\'jbZ7\')]],0x1)||_0x5d85b3[_0x360e(\'0x7a\',\'qjxA\')](_0x5d85b3[_0x360e(\'0x7b\',\'CcKi\')](_0x1f8f28,0x14),0x0)){debugger;}else{if(_0x5d85b3[_0x360e(\'0x7c\',\'gN&W\')](_0x5d85b3[_0x360e(\'0x7d\',\'L#Wn\')],_0x5d85b3[_0x360e(\'0x7e\',\'A2ST\')])){if(fn){var _0x5487b7=fn[_0x360e(\'0x7f\',\'1[$l\')](context,arguments);fn=null;return _0x5487b7;}}else{debugger;}}}_0x5d85b3[_0x360e(\'0x80\',\'@RaU\')](_0x277bc9,++_0x1f8f28);}try{if(_0x40e9a5){return _0x277bc9;}else{_0x5d85b3[_0x360e(\'0x81\',\'Ldf]\')](_0x277bc9,0x0);}}catch(_0x196ae7){if(_0x5d85b3[_0x360e(\'0x82\',\'k7Ri\')](_0x5d85b3[_0x360e(\'0x83\',\']@1R\')],_0x5d85b3[_0x360e(\'0x84\',\'ObbC\')])){}else{var _0x212903=_0x5d85b3[_0x360e(\'0x85\',\'1[$l\')][_0x360e(\'0x86\',\'Ypw4\')](\'|\'),_0x39862c=0x0;while(!![]){switch(_0x212903[_0x39862c++]){case\'0\':_0x2b967e[_0x360e(\'0x87\',\'ObbC\')]=func;continue;case\'1\':_0x2b967e[_0x360e(\'0x88\',\'s8L[\')]=func;continue;case\'2\':_0x2b967e[_0x360e(\'0x89\',\'@RaU\')]=func;continue;case\'3\':_0x2b967e[_0x360e(\'0x8a\',\'P^J$\')]=func;continue;case\'4\':var _0x2b967e={};continue;case\'5\':_0x2b967e[_0x360e(\'0x8b\',\'qjxA\')]=func;continue;case\'6\':_0x2b967e[_0x360e(\'0x8c\',\'jbZ7\')]=func;continue;case\'7\':_0x2b967e[_0x360e(\'0x8d\',\']@1R\')]=func;continue;case\'8\':return _0x2b967e;}break;}}}};encode_version = \'sojson.v5\';
</script>';
		return $_var_27;
	}
	public static function styleoutput()
	{
		$_var_28 = THEME_URL;
		$_var_29 = Handsome::$version . Handsome_Config::$versionTag;
		$_var_30 = self::getBackgroundColor();
		return <<<EOF
<style>
:root{--randomColor0:{$_var_30[0]};--randomColor1:{$_var_30[1]};}
</style>
    <link rel="stylesheet" href="{$_var_28}assets/css/admin/editor.min.css?v={$_var_29}" type="text/css" />
    <link rel="stylesheet" href="{$_var_28}assets/css/admin/admin.min.css?v={$_var_29}" type="text/css" />
EOF
;
	}
	public static function outputEditorJS()
	{
		$_var_31 = mget();
		self::initCdnSetting();
		$_var_32 = THEME_URL;
		$_var_33 = $_var_32 . 'libs/Get.php';
		$_var_34 = Handsome::$version . Handsome_Config::$versionTag;
		Handsome::$times++;
		$_var_35 = unserialize(PUBLIC_CDN);
		return "\n    <link rel=\"stylesheet\" href=\"{$_var_32}assets/css/owo.min.css?v={$_var_34}\" type=\"text/css\" />\n    <link rel=\"stylesheet\" href=\"{$_var_32}assets/css/admin/editor.min.css?v={$_var_34}\" type=\"text/css\" />\n    \n<script>\nvar hplayerUrl='{$_var_33}';\nvar themeUrl = '{$_var_32}';\nvar themeAssetsUrl ='{$_var_32}assets/';\nwindow['LocalConst'] = {\n    BASE_SCRIPT_URL: themeUrl\n}\n</script>\n\n<script src=\"{$_var_32}assets/js/features/OwO.min.js?v={$_var_34}\"></script>\n    <script>\n    </script>\n<script src=\"{$_var_32}assets/js/editor.min.js?v={$_var_34}\"></script>\n\n\n";
	}
	public static function returnCheckHtml()
	{
		return <<<EOF
EOF
;
	}
}