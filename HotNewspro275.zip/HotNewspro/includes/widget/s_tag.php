<div class="box_top">
	<i class="rt"></i>
	<i class="lt"></i>
</div>
<div class="categories">
	<div class="tag_c"><?php wp_tag_cloud('smallest=12&largest=16&unit=px&number=25');?></div>
</div>
<div class="clear"></div>
<div class="box-bottom">
	<i class="lb"></i>
	<i class="rb"></i>
</div>