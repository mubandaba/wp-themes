<div class="entry_b">
	<?php include('related.php'); ?>
	<?php include('related_img.php'); ?>
	<div class="clear"></div>
		<i class="lt"></i>
		<i class="rt"></i>
</div>
<div class="entry_sb">
	<i class="lb"></i>
	<i class="rb"></i>
</div>