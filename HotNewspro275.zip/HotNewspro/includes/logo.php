<div class="logo_box">
	<a href="<?php bloginfo('siteurl'); ?>" title="<?php bloginfo('name'); ?>"><h1 class="logo"><?php bloginfo('name'); ?></h1><?php include('weibo.php'); ?></a>
</div>