eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('(5(a){4(1t 1l!=="1h"&&1l.2z){1l([],a)}X{4(1t 1y!=="1h"&&1y.1G){1y.1G=a()}X{13.1O=a()}}})(5(){3 c=5(){11 13.23||(Z.18&&Z.18.1X)||Z.1k.1X};3 G={};3 V=24;3 k=[];3 E="25";3 B="26";3 z="28";3 o="2i";3 l="2j";3 w="2l";3 n="2m";3 p=[E,B,z,o,l,w,n];3 F={7:0,6:0};3 y=5(){11 13.22||Z.18.1L};3 a=5(){11 2o.2q(Z.1k.1I,Z.18.1I,Z.1k.1w,Z.18.1w,Z.18.1L)};G.15=1d;G.1b=1d;G.1a=1d;G.1A=y();3 v;3 s;3 b;5 t(){G.15=c();G.1b=G.15+G.1A;G.1a=a();4(G.1a!==v){b=k.Y;1i(b--){k[b].1j()}v=G.1a}}5 r(){G.1A=y();t();q()}3 d;5 u(){2r(d);d=2y(r,2B)}3 h;5 q(){h=k.Y;1i(h--){k[h].19()}h=k.Y;1i(h--){k[h].1D()}}5 m(P,I){3 S=2;2.9=P;4(!I){2.16=F}X{4(I===+I){2.16={7:I,6:I}}X{2.16={7:I.7||F.7,6:I.6||F.6}}}2.8={};1c(3 N=0,M=p.Y;N<M;N++){S.8[p[N]]=[]}2.1e=1o;3 L;3 Q;3 R;3 O;3 H;3 e;5 K(i){4(i.Y===0){11}H=i.Y;1i(H--){e=i[H];e.1q.1p(S,s);4(e.1E){i.1m(H,1)}}}2.1D=5 J(){4(2.W&&!L){K(2.8[B])}4(2.14&&!Q){K(2.8[z])}4(2.12!==R&&2.17!==O){K(2.8[E]);4(!Q&&!2.14){K(2.8[z]);K(2.8[l])}4(!L&&!2.W){K(2.8[B]);K(2.8[o])}}4(!2.14&&Q){K(2.8[l])}4(!2.W&&L){K(2.8[o])}4(2.W!==L){K(2.8[E])}1K(1g){10 L!==2.W:10 Q!==2.14:10 R!==2.12:10 O!==2.17:K(2.8[n])}L=2.W;Q=2.14;R=2.12;O=2.17};2.1j=5(){4(2.1e){11}3 U=2.7;3 T=2.6;4(2.9.2k){3 j=2.9.1z.1x;4(j==="1Q"){2.9.1z.1x=""}3 i=2.9.27();2.7=i.7+G.15;2.6=i.6+G.15;4(j==="1Q"){2.9.1z.1x=j}}X{4(2.9===+2.9){4(2.9>0){2.7=2.6=2.9}X{2.7=2.6=G.1a-2.9}}X{2.7=2.9.7;2.6=2.9.6}}2.7-=2.16.7;2.6+=2.16.6;2.1u=2.6-2.7;4((U!==1h||T!==1h)&&(2.7!==U||2.6!==T)){K(2.8[w])}};2.1j();2.19();L=2.W;Q=2.14;R=2.12;O=2.17}m.1S={1s:5(e,j,i){1K(1g){10 e===E&&!2.W&&2.12:10 e===B&&2.W:10 e===z&&2.14:10 e===o&&2.12&&!2.W:10 e===l&&2.12:j.1p(2,s);4(i){11}}4(2.8[e]){2.8[e].1U({1q:j,1E:i||1o})}X{1n 1f 1B("1Y 1Z 2n a 1v 21 20 1W 1V "+e+". 1T 1C 1R: "+p.1P(", "))}},29:5(H,I){4(2.8[H]){1c(3 e=0,j;j=2.8[H][e];e++){4(j.1q===I){2.8[H].1m(e,1);2a}}}X{1n 1f 1B("1Y 1Z 2b a 1v 21 20 1W 1V "+H+". 1T 1C 1R: "+p.1P(", "))}},2c:5(e,i){2.1s(e,i,1g)},2d:5(){2.1u=2.9.1w+2.16.7+2.16.6;2.6=2.7+2.1u},19:5(){2.12=2.7<G.15;2.17=2.6>G.1b;2.W=(2.7<=G.1b&&2.6>=G.15);2.14=(2.7>=G.15&&2.6<=G.1b)||(2.12&&2.17)},2e:5(){3 I=k.2f(2),e=2;k.1m(I,1);1c(3 J=0,H=p.Y;J<H;J++){e.8[p[J]].Y=0}},2g:5(){2.1e=1g},2h:5(){2.1e=1o}};3 g=5(e){11 5(j,i){2.1s.1p(2,e,j,i)}};1c(3 C=0,A=p.Y;C<A;C++){3 f=p[C];m.1S[f]=g(f)}1N{t()}1M(D){1N{13.$(t)}1M(D){1n 1f 1B("2p 1J 1H 2s 1O 2t 2u <2v>, 1J 1H 2w 2x.")}}5 x(e){s=e;t();q()}4(13.1r){13.1r("1v",x);13.1r("2A",u)}X{13.1F("2C",x);13.1F("2D",u)}G.2E=G.2F=5(i,j){4(1t i==="2G"){i=Z.2H(i)}X{4(i&&i.Y>0){i=i[0]}}3 e=1f m(i,j);k.1U(e);e.19();11 e};G.19=5(){s=1d;t();q()};G.2I=5(){G.1a=0;G.19()};11 G});',62,169,'||this|var|if|function|bottom|top|callbacks|watchItem|||||||||||||||||||||||||||||||||||||||||||||||||isInViewport|else|length|document|case|return|isAboveViewport|window|isFullyInViewport|viewportTop|offsets|isBelowViewport|documentElement|update|documentHeight|viewportBottom|for|null|locked|new|true|undefined|while|recalculateLocation|body|define|splice|throw|false|call|callback|addEventListener|on|typeof|height|scroll|offsetHeight|display|module|style|viewportHeight|Error|options|triggerCallbacks|isOne|attachEvent|exports|must|scrollHeight|you|switch|clientHeight|catch|try|scrollMonitor|join|none|are|prototype|Your|push|type|of|scrollTop|Tried|to|listener|monitor|innerHeight|pageYOffset|747|visibilityChange|enterViewport|getBoundingClientRect|fullyEnterViewport|off|break|remove|one|recalculateSize|destroy|indexOf|lock|unlock|exitViewport|partiallyExitViewport|nodeName|locationChange|stateChange|add|Math|If|max|clearTimeout|put|in|the|head|use|jQuery|setTimeout|amd|resize|100|onscroll|onresize|beget|create|string|querySelector|recalculateLocations'.split('|'),0,{}))
	
$(document).ready(function() {
	// 菜单
	var $account = $('#fix-header');
	var $header = $('#menu-box');
	var $minisb = $('#content');
	var $footer = $('#footer');

	var accountWatcher = scrollMonitor.create($account);
	var headerWatcher = scrollMonitor.create($header);

	var footerWatcherTop = $minisb.height() + $header.height();
	var footerWatcher = scrollMonitor.create($footer, {
		top: footerWatcherTop
	});

	accountWatcher.lock();
	headerWatcher.lock();

	accountWatcher.visibilityChange(function() {
		$header.toggleClass('shadow', !accountWatcher.isInViewport);
	});
	headerWatcher.visibilityChange(function() {
		$minisb.toggleClass('shadow', !headerWatcher.isInViewport);
	});

	footerWatcher.fullyEnterViewport(function() {
		if (footerWatcher.isAboveViewport) {
			$minisb.removeClass('shadow').addClass('hug-footer')
		}
	});
	footerWatcher.partiallyExitViewport(function() {
		if (!footerWatcher.isAboveViewport) {
			$minisb.addClass('fixed').removeClass('hug-footer')
		}
	});
});

$(document).ready(function() {
// 跟随
    var $account = $('#sidebar');
    var $header = $('.sidebar-roll');
    var $minisb = $('#content');
    var $footer = $('#footer');

    var accountWatcher = scrollMonitor.create($account);
    var headerWatcher = scrollMonitor.create($header);

    var footerWatcherTop = $minisb.height() + $header.height();

    accountWatcher.lock();
    headerWatcher.lock();

    accountWatcher.visibilityChange(function() {
        $header.toggleClass('follow', !accountWatcher.isInViewport);
    });
});

// 登录
$(document).ready(function(){
	$('#login-main').leanModal({
		top: 130,
		overlay: 0.8,
		closeButton: '.close'
	});
});

// 折叠字体
$(document).ready(function(){
		//Toggle Content
	$('.toggle-click-btn').click(function(){
		$(this).next('.toggle-content').slideToggle('slow');
        if($(this).hasClass('yes')){
            $(this).removeClass('yes');
            $(this).addClass('no');
        }else{
            $(this).removeClass('no');
            $(this).addClass('yes');
        }
	});
		
});

$(document).ready(function() {
// 搜索
	$(".nav-search").click(function() {
		$("#search-main").fadeToggle(300);
	});
	
// 滚屏
	$('.scroll-top').click(function() {
		$('html,body').animate({
			scrollTop: '0px'
		},
		800);
	});

	$('.scroll-bottom').click(function() {
		$('html,body').animate({
			scrollTop: $('#footer').offset().top
		},
		800);
	});	
	
// 分享
if(/iphone|ipod|ipad|ipad|mobile/i.test(navigator.userAgent.toLowerCase())){	
	$('.share-sd').click(function() {
		$('#share').animate({
			opacity: 'toggle',
			top: '-80px'
		},
			500).animate({
			top: '-60px'
		},
		'fast');
		return false;
	});
} else {
	$(".share-sd").mouseover(function() {
		$(this).children("#share").show();
	});
	$(".share-sd").mouseout(function() {
		$(this).children("#share").hide();
	});
}

// 去边线
	$(".message-widget li:last, .message-page li:last, .hot_commend li:last, .search-page li:last, .my-comment li:last").css("border","none");

// 表情
	$('.smiley').click(function () {
		$('.smiley-box').animate({
			opacity: 'toggle',
			left: '50px'
		}, 1000).animate({
			left: '10px'
		}, 'fast');
		return false;
	});

});

// 公告文字滚动
(function($){$.fn.textSlider=function(settings){settings=jQuery.extend({speed:"normal",line:2,timer:1000},settings);return this.each(function(){$.fn.textSlider.scllor($(this),settings)})};$.fn.textSlider.scllor=function($this,settings){var ul=$("ul:eq(0)",$this);var timerID;var li=ul.children();var _btnUp=$(".up:eq(0)",$this);var _btnDown=$(".down:eq(0)",$this);var liHight=$(li[0]).height();var upHeight=0-settings.line*liHight;var scrollUp=function(){_btnUp.unbind("click",scrollUp);ul.animate({marginTop:upHeight},settings.speed,function(){for(i=0;i<settings.line;i++){ul.find("li:first").appendTo(ul)}ul.css({marginTop:0});_btnUp.bind("click",scrollUp)})};var scrollDown=function(){_btnDown.unbind("click",scrollDown);ul.css({marginTop:upHeight});for(i=0;i<settings.line;i++){ul.find("li:last").prependTo(ul)}ul.animate({marginTop:0},settings.speed,function(){_btnDown.bind("click",scrollDown)})};var autoPlay=function(){timerID=window.setInterval(scrollUp,settings.timer)};var autoStop=function(){window.clearInterval(timerID)};ul.hover(autoStop,autoPlay).mouseout();_btnUp.css("cursor","pointer").click(scrollUp);_btnUp.hover(autoStop,autoPlay);_btnDown.css("cursor","pointer").click(scrollDown);_btnDown.hover(autoStop,autoPlay)}})(jQuery);


// 评论贴图
function embedImage() {
  var URL = prompt('请输入图片 URL 地址:', 'http://');
  if (URL) {
    document.getElementById('comment').value = document.getElementById('comment').value + '[img]' + URL + '[/img]';
  }
};

// 表情
function grin(tag) {
	var myField;
	tag = ' ' + tag + ' ';
    if (document.getElementById('comment') && document.getElementById('comment').type == 'textarea') {
		myField = document.getElementById('comment');
	} else {
		return false;
	}
	if (document.selection) {
		myField.focus();
		sel = document.selection.createRange();
		sel.text = tag;
		myField.focus();
	}
	else if (myField.selectionStart || myField.selectionStart == '0') {
		var startPos = myField.selectionStart;
		var endPos = myField.selectionEnd;
		var cursorPos = endPos;
		myField.value = myField.value.substring(0, startPos)
					  + tag
					  + myField.value.substring(endPos, myField.value.length);
		cursorPos += tag.length;
		myField.focus();
		myField.selectionStart = cursorPos;
		myField.selectionEnd = cursorPos;
	} else {
		myField.value += tag;
		myField.focus();
	}
};

// 点赞
$.fn.postLike = function() {
	if ($(this).hasClass('done')) {
		alert('您已赞过该文章');
		return false;
	} else {
		$(this).addClass('done');
		var id = $(this).data("id"),
		action = $(this).data('action'),
		rateHolder = $(this).children('.count');
		var ajax_data = {
			action: "md_like",
			um_id: id,
			um_action: action
		};
		$.post("/wp-admin/admin-ajax.php", ajax_data,
		function(data) {
			$(rateHolder).html(data);
		});
		return false;
	}
};
$(document).on("click", ".md_like",
	function() {
		$(this).postLike();
});

// 文章归档
$(document).ready(function(){
    (function(){
		var $a = $('#archives'),
			$m = $('.mon', $a),
			$l = $('.post_list', $a),
			$l_f = $('.post_list:first', $a);
		$l.hide();
		$l_f.show();
		$m.css('cursor', 's-resize').on('click', function(){
			$(this).next().slideToggle(400);
		});
		var animate = function(index, status, s) {
			if (index > $l.length) {
				return;
			}
			if (status == 'up') {
				$l.eq(index).slideUp(s, function() {
					animate(index+1, status, (s-10<1)?0:s-10);
				});
			} else {
				$l.eq(index).slideDown(s, function() {
					animate(index+1, status, (s-10<1)?0:s-10);
				});
			}
		};
		$('#expand_collapse').on('click', function(e){
			e.preventDefault();
			if ( $(this).data('s') ) {
				$(this).data('s', '');
				animate(0, 'up', 100);
			} else {
				$(this).data('s', 1);
				animate(0, 'down', 100);
			}
		});
    })();
 });
