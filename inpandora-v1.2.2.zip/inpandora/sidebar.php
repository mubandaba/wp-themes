<?php
/**
 * The template for the sidebar containing the main widget area
 *
 * @package WordPress
 * @subpackage Inpandora
 * @since Wbolt 1.0
 */
?>

<div class="sidebar">
	<div class="sb-inner">
		<?php dynamic_sidebar( 'sidebar-def' ); ?>

        <div class="widget widget-tags">
            <h3 class="widgettitle">标签</h3>
            <div class="hot-tags">
				<?php the_tags('','',''); ?>
            </div>
        </div>

		<?php echo wb_hot_items(); ?>

		<?php echo wb_get_links(); ?>

        <?php dynamic_sidebar( 'sidebar-bottom' ); ?>
		<?php echo wb_insert_ad_block('sidebar'); ?>
    </div>
</div>
