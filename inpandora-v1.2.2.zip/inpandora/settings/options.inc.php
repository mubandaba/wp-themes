<?php
/**
 * Author: wbolt team
 * Author URI: https://www.wbolt.com
 */

class WBOptions
{
	public static $option_name = 'wb_theme_cnf';

	public static $cnf_fields = array(
		'ads' => array(
			'index_block' => array(
				'id'=>'index_block',
				'name' => '首页通栏广告位',
				'type' => 0,
				'code'=>'',
				'img'=>'',
				'url'=>'',
				'code_desc' => '',
				'img_desc' => ''
			),
			'list_block' => array(
				'id'=>'list_block',
				'name' => '搜索页和分类页通栏广告位',
				'type' => 0,
				'code'=>'',
				'img'=>'',
				'url'=>'',
				'code_desc' => '',
				'img_desc' => ''
			),
			'detail_under_title' => array(
				'id'=>'detail_under_title',
				'name' => '详情页开头广告位',
				'type' => 0,
				'code'=>'',
				'img'=>'',
				'url'=>'',
				'code_desc' => '',
				'img_desc' => ''
			),
			'detail_content_btm' => array(
				'id'=>'detail_content_btm',
				'name' => '详情页底部广告位',
				'type' => 0,
				'code'=>'',
				'img'=>'',
				'url'=>'',
				'code_desc' => '',
				'img_desc' => ''
			),
			'sidebar' => array(
				'id'=>'sidebar',
				'name' => '侧栏底部广告位',
				'type' => 0,
				'code'=>'',
				'img'=>'',
				'url'=>'',
				'code_desc' => '',
				'img_desc' => ''
			)
		),
		'thumbnail_rate'=> array('16:9','16:10','4:3','3:2') //默认'1:1',
	);


	public function __construct()
	{

	}

	public static function init(){
		if(is_admin()){
			add_action('admin_menu', array(__CLASS__, 'options_page_menu'));
			add_action('admin_init',array(__CLASS__,'admin_init'),1);
			add_action('wp_ajax_wb_setting_ajax', array(__CLASS__,'ajaxHandle'));
		}

		add_filter('wb_custom_footer_code', array(__CLASS__,'wb_custom_footer_code_handler'));
		add_filter('wb_js_conf', array(__CLASS__,'wb_custom_script_opt_handler'));
		add_filter('wb_custom_header_code', array(__CLASS__,'wb_custom_header_code_handler'));
	}

	public static function admin_init(){
		add_action('admin_enqueue_scripts',function($hook) {
			global $wb_settings_page_hook_theme;
			if ( $wb_settings_page_hook_theme != $hook ) {
				return;
			}

			wp_enqueue_style('wbs-style', get_template_directory_uri() . '/settings/assets/wb_setting.css', array(),WB_ASSETS_VER);
		},1);

		self::load();
	}


	public static function options_page_menu()
	{
		global $wb_settings_page_hook_theme;
		$wb_settings_page_hook_theme = add_menu_page(
			'主题设置',
			'主题设置',
			'manage_options',
			'options-wbthemes',
			array(__CLASS__,'optionsPage'),
			get_template_directory_uri() . '/settings/assets/wbolt_ico.svg'
		);
	}

	public static function optionsPage()
	{
		if (!current_user_can('manage_options')) {
			wp_die(__('You do not have sufficient permissions to access this page.'));
		}
		$_ajax_nonce = wp_create_nonce('wp_ajax_wb_admin');


		//引入基础设置
		require_once 'options_config.php';

		wp_enqueue_media();

		if(defined('WB_CORE_ASSETS_LOAD') && class_exists('WB_Core_Asset_Load')){

			WB_Core_Asset_Load::load('setting-20');

		}else{
			wp_enqueue_script('wbs-js', WB_THEME_URI . '/settings/assets/wb_setting.js', array(),WB_ASSETS_VER);
		}

		$inline_script = '';
		$inline_script .= 'var _admin_url =" '.admin_url().'", _wb_ajax_nonce ="'.$_ajax_nonce.'",  _wp_cf = {ajax_url: "' . admin_url('/admin-ajax.php') . '"};' . "\n";

		$ret = self::get_theme_setting();

		$inline_script .= 'var wbs_cnf ='. json_encode(self::$cnf_fields) . ';';
		$inline_script .= 'var _opt ='. json_encode($ret['data']) . ';';
		$inline_script .= 'var cate_list ='. json_encode($ret['cate_list']) . ';';
		$inline_script .= 'var root_cat_ids ='. json_encode($ret['root_cat_ids']) . ';';

		wp_add_inline_script('wbs-js', $inline_script,'before');

		include WB_THEME_DIR. '/settings/options.php';
	}


	public static function def_opt($type=null){

		$cnf = array(
			/*基本设置*/
			'logo_url'=>'',
			'favicon'=>'',
			'def_img_url'=>'',
			'theme_color'=>'',
			'gutenberg_switch'=>1,
			'autoload_switch'=>0,
			'mxpage'=> '',
			'flID'=> '',

			/*页脚设置*/
			'copyright_footer'=>'',
			'footer'=>array(
				'pwb'=>1,
				'miit_id'=>'',
				'copyright'=>''
			),


			/*自定义代码*/
			'usr_css'=>'',
			'hd_code'=> '',
			'ft_code'=> '',
			'stats_code'=> '',

			/*特色图比例*/
			'thumbnail_rate'=>'',

			/*友情链接*/
			'links'=>array()

		);

		return $cnf;
	}

	/**
	 * 扩展属性
	 * @param $cnf array 当前属性
	 * @param $conf array 扩展属性
	 */
	public static function extend_conf(&$cnf,$conf){
		if(is_array($conf))foreach($conf as  $k=>$v){
			if(!isset($cnf[$k])){
				$cnf[$k] = $v;
			}else if(is_array($v)){
				if(!is_array($cnf[$k])){
					$cnf[$k] = array();
				}
				self::extend_conf($cnf[$k],$v);
			}
		}
	}

	/**
	 * 合并属性
	 * @param $old array 原属性
	 * @param $new array 新属性
	 */
	public static function combine_conf(&$old,$new){
		if(is_array($new))foreach($new as  $k=>$v){
			if(!isset($old[$k])){
				$old[$k] = $v;
			}else if(is_array($v)){
				self::combine_conf($old[$k],$v);
			}else{
				$old[$k] = $v;
			}
		}
	}

	//配置值
	public static function opt($name='', $default = false)
	{
		static $options = null;

		if (null == $options){
			$options = get_option(self::$option_name,array());
			$is_new = false;
			if(!$options){
				$is_new = true;
			}
			//unset($options['dl']['dl_type']);

			self::extend_conf($options,self::def_opt());
			if($is_new){
				$new_default = array(

				);
				foreach ($new_default as $k=>$v){
					if(is_array($v)){
						$options[$k] = array_merge($options[$k],$v);
					}else{
						$options[$k] = $v;
					}
				}
			}
		}

		$return = null;
		do{

			if(!$name){
				$return = $options;
				break;
			}

			$ret = $options;
			$ak = explode('.', $name);

			foreach ($ak as $sk) {
				if (isset($ret[$sk])) {
					$ret = $ret[$sk];
				} else {
					$ret = $default;
					break;
				}
			}

			$return = $ret;


		}while(0);


		return apply_filters('wb_theme_get_conf',$return,$name,$default);

	}

	public static function ajaxHandle(){
		global $wpdb;

		if( !is_user_logged_in()) {
			echo 'fail';
			exit();
		}
		if(!current_user_can('manage_options')){
			exit();
		}
		//if(!user_can())
		switch ($_POST['do']){
            case 'chk_ver':
                $http = wp_remote_get('https://www.wbolt.com/wb-api/v1/themes/checkver?code='.WB_THEMES_CODE.'&ver='.WB_THEMES_VER.'&chk=1');

                if(wp_remote_retrieve_response_code($http) == 200){
                    echo wp_remote_retrieve_body($http);
                    exit();
                }

                break;

			case 'get_theme_setting':
				self::get_theme_setting();
				break;

			case 'set_theme_setting':

				$opt_data = $_POST['opt'];

				self::set_theme_setting($opt_data);

				$ret = array('code'=>0,'desc'=>'success');

				header('content-type:text/json;charset=utf-8');
				echo json_encode($ret);
				break;
		}
		exit();
	}

	public static function set_theme_setting( $data ) {

		$opt = self::opt();

		foreach($data as $key => $value){
			$opt[$key] = self::stripslashes_deep($value);
		}

		return update_option( self::$option_name, $opt );
	}

	public static function stripslashes_deep($value)
	{
		if(is_array($value)){
			foreach($value as $k => $v){
				$value[$k] = self::stripslashes_deep($v);
			}
		}else{
			$value = stripslashes($value);
		}
		return $value;
	}

	public static function get_theme_setting(){

		$ret = array();

		$cat_data = wb_get_root_category();
		$cat_list = array();
		foreach($cat_data as $k => $cat){
			$cat_list[$cat['term_id']] = $cat;
		}

		$ret['cate_list'] = $cat_list;
		$ret['root_cat_ids'] = wb_get_root_category_id();

		$ret['data'] = self::opt();

		//$ret['data']);
		return $ret;
	}


	public static function wb_custom_footer_code_handler(){
		if(self::opt('ft_code')){
			echo self::opt('ft_code')."\n";
		}

		if(self::opt('stats_code')){
			echo '<div style="display:none;">'. self::opt('stats_code')  . '</div>'."\n";
		}
	}

	public static function wb_custom_header_code_handler($echo=true){
		//主题颜色
		$theme_color_var = self::opt('theme_color');
		$custom_thumb_rate = self::opt('thumbnail_rate');


		//自定义样式
		$custom_css = self::opt('usr_css','');

		if($custom_thumb_rate){
			$custom_css = ":root{--thumbRate:" . get_thumb_rate() * 100 ."%;}".$custom_css;
		}

		if($theme_color_var){
			$custom_css = ":root{--mainColor:" . $theme_color_var.";--mainColorHover:" . $theme_color_var.";}\n".$custom_css;
		}

		if($custom_css && $echo){
			echo sprintf("<style>\n%s\n</style>\n",$custom_css);
		}

		//自定义代码
		$hd_code = self::opt('hd_code');
		if($hd_code && $echo){
			echo $hd_code."\n";
		}

		return $custom_css."\n".$hd_code."\n";
	}

	public static function wb_custom_script_opt_handler(){
		$opt_js_cont = '';

		//列表自动加载
		if(self::opt('autoload_switch')){
			$mxpage = self::opt('mxpage') ? self::opt('mxpage') : '3';
			$opt_js_cont .= ' var autoLoadMaxPage = '.$mxpage . ';';
		}
		//默认图片
		if(self::opt('def_img_url')) {
			$opt_js_cont .= ' var _def_pic_url = "'.self::opt('def_img_url') . '";';
		}

		return $opt_js_cont;
	}

	public static function load(){

		add_action( 'load-themes.php', array(__CLASS__,'check_version'),100 );
		add_action( 'load-update.php', array(__CLASS__,'check_version'),100 );
		add_action( 'load-update-core.php', array(__CLASS__,'check_version'),100 );
		add_action( 'wp_update_themes', array(__CLASS__,'check_version'),100 );

	}

	public static function check_version(){
		global $wp_version;

		$update_themes = get_site_transient( 'update_themes' );

		if ( ! is_object( $update_themes ) ) {
			return;
		}

		$theme = wp_get_theme();
		$tpl = $theme->get_template();

		if(isset($update_themes->response[$tpl])){
			return;
		}


		$doing_cron = wp_doing_cron();

		// Check for update on a different schedule, depending on the page.
		switch ( current_filter() ) {
			case 'upgrader_process_complete':
				$timeout = 0;
				break;
			case 'load-update-core.php':
				$timeout = MINUTE_IN_SECONDS;
				break;
			case 'load-themes.php':
			case 'load-update.php':
				$timeout = HOUR_IN_SECONDS;
				break;
			default:
				if ( $doing_cron ) {
					$timeout = 2 * HOUR_IN_SECONDS;
				} else {
					$timeout = 12 * HOUR_IN_SECONDS;
				}
		}

		$time_not_changed = isset( $update_themes->wb_checked ) && $timeout > ( time() - $update_themes->wb_checked );
		if($time_not_changed){
			return;
		}

		$update_themes->wb_checked = time();
		set_site_transient( 'update_themes', $update_themes );

		if ( $doing_cron ) {
			$timeout = 30;
		} else {
			$timeout = 3 ;
		}

		$options = array(
			'timeout'    => $timeout,
			'user-agent' => 'Wbolt WordPress/' . $wp_version . '; ' . home_url( '/' ),
		);


		$url      = 'https://www.wbolt.com/wb-api/v1/themes/checkver?chk=1&code='.WB_THEMES_CODE.'&ver='.WB_THEMES_VER;


		$raw_response = wp_remote_get( $url, $options );

		if ( is_wp_error( $raw_response ) || 200 != wp_remote_retrieve_response_code( $raw_response ) ) {
			return;
		}

		$new_version = trim(wp_remote_retrieve_body( $raw_response ));
		if(!$new_version || !preg_match('#^\d[0-9\.]+#',$new_version)){
			return;
		}

		$update_themes->response[$tpl] = array(
			'theme'=>$tpl,
			'new_version'=>$new_version,
			'url'=>'https://www.wbolt.com/themes/'.WB_THEMES_CODE.'/',
			'package'=>'https://www.wbolt.com/wb-api/v1/themes/upgrade?p='.WB_THEMES_CODE.'&v=free',
			'requires'=>'4.9.6',
			'requires_php'=>'5.3.5',
		);

		set_site_transient( 'update_themes', $update_themes );

	}


	/**
	 * 插入广告位
	 */
	static function insertAdBlock($ad_name = '', $box_class = 'adbanner-block'){
		if(!$ad_name) return;

		$ads = self::opt('ads.'.$ad_name);

		if($ads['type'] == 0) return;

		$adHTML = '<div class="'. $box_class .'">';

		if($ads['type'] == 1){
			$adHTML .= $ads['code'];
		}elseif($ads['type'] == 2){
			$adHTML .= '<a href="' . $ads['url'] . '" target="_blank" rel="nofollow"><img class="adbn-img" src="' . $ads['img'] . '"></a>';
		}else{
			return;
		}
		$adHTML .= '</div>';

		return $adHTML;
	}

	/**
	 * 友链输出
	 */
	static function wb_get_links(){
		$links_items = self::opt('links');
		if(empty($links_items))return '';

		$tpl = '<section class="widget widget-links">
                <h3 class="widgettitle">友情链接</h3>
                <div class="links-items">';

		foreach ($links_items as $item) :
			$img_url = isset($item['img']) && $item['img'] ? $item['img'] : get_template_directory_uri(). '/images/link_def.png';
			$target = isset($item['target']) && $item['target'] ? ' target="_blank"' : '';
			$nofollow = isset($item['nofollow']) && $item['nofollow'] ? ' rel=" nofollow"' : '';

			$tpl .= '<a href="'. $item['url'] . '"'. $target . $nofollow .' >';
			$tpl .= '<img src="'. $img_url . '" alt="">';
			$tpl .= '<span>'.$item['name'].'</span>';
			$tpl .= '</a>';
		endforeach;

		$tpl .= '</div></section>';

		return $tpl;
	}
}

