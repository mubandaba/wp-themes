<?php /**
 * WBolt 友链
 **/
?>
<template id="wbs_tpl_links">
<div>
    <div class="sc-header">
        <strong>友情链接</strong>
        <span>设置您的友情链接</span>
    </div>

    <div class="sc-body">
        <table class="wbs-info-table links-items-table">
            <tbody>
            <tr v-for="(v, idx) in links">
                <th class="row w6em">友链 {{idx + 1}}
                    <p class="ctrl-def-hide"><a @click="delItem(idx)">[删除]</a></p>
                </th>
                <td>
                    <div class="social-item">
                        <div class="mb">
                            <input class="wbs-input" type="text" placeholder="网站名称 *" v-model="v.name" required>
                        </div>
                        <div class="mb">
                            <input class="wbs-input" type="text" placeholder="网站URL (如:https://www.wbolt.com) *" v-model="v.url" required>
                        </div>
                        <div class="social-item section-upload">
                            <wbs-upload-box v-bind:url="v.img" v-on:get-file="v.img = $event"></wbs-upload-box>
                        </div>
                        <div class="selector-bar">
                            <label>
                                <input class="wbs-checkbox" type="checkbox" v-model="v.target">
                                <span>新窗口打开</span>
                            </label>
                            <label class="ml">
                                <input class="wbs-checkbox" type="checkbox" v-model="v.nofollow">
                                <span>设置nofollow</span>
                            </label>
                        </div>
                    </div>
                </td>
            </tr>
            </tbody>
            <tfoot>
            <tr>
                <th></th>
                <td>
                    <a class="wb-btn btn-ctrl" @click="addItem()">
						<?php echo wbolt_svg_icon('sico-plus'); ?>
                        <span>添加</span>
                    </a>
                </td>
            </tr>
            </tfoot>

        </table>
    </div>
</div>
</template>
