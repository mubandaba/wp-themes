<div class="wbs-header">
    <svg class="wb-icon sico-wb-logo"><use xlink:href="#sico-wb-logo"></use></svg>
    <span>WBOLT</span>
    <strong><?php echo isset($page_title) ? $page_title : '主题设置'; ?></strong>

    <div class="links">
        <a class="wb-btn wb-btn-pro" href="<?php echo $pd_index_url . '-pro'; ?>" data-wba-campaign="upgrade-btn" target="_blank">
            <svg class="wb-icon wbsico-pro"><use xlink:href="#wbsico-pro"></use></svg>
            <span>升级PRO版</span>
        </a>
        <a class="wb-btn" href="<?php echo $pd_index_url; ?>" data-wba-campaign="title-bar" target="_blank">
            <svg class="wb-icon sico-plugins"><use xlink:href="#sico-plugins"></use></svg>
            <span>主题主页</span>
        </a>
        <a class="wb-btn" href="<?php echo $pd_doc_url; ?>" data-wba-campaign="title-bar" target="_blank">
            <svg class="wb-icon sico-doc"><use xlink:href="#sico-doc"></use></svg>
            <span>说明文档</span>
        </a>
    </div>
</div>