<?php /**
 * WBolt 推荐资源
 * <script type="text/javascript" src="https://www.wbolt.com/wb-api/v1/news/newest"></script>

 **/
?>
<more-wb-info v-bind:utm-source="'<?php echo $pd_name; ?>'"></more-wb-info>