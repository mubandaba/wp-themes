<?php
/**
 * 设置通用组件
 */
?>


<?php
/**
 * 推荐产品
 */
?>
<template id="wbs_tpl_more_products">
    <div class="more-wb-info">
        <div class="sc-header">
            <strong>精品主题</strong>
            <span></span>
        </div>

        <div class="sc-body wbolt-products">
            <ul class="pd-items-b">
                <li class="pd-item" v-for="item in wbMoreData.themes">
                    <div class="item-inner">
                        <a class="post-thumbnail thumbnail-themes" :href="withCampaign(item.url)" data-wba-campaign="recommend" target="_blank">
                            <img :src="item.thumb[0]">
                        </a>
                        <div class="pd-info">
                            <a class="pd-name" :href="withCampaign(item.url)" data-wba-campaign="recommend" target="_blank"><em v-if="item.status_tag" class="state-tag" :class="item.status_tag">{{item.status_tag}}</em><span>{{item.post_title}}</span></a>
                            <div class="pd-desc">{{item.excerpt}}</div>
                            <p><a class="btn-sm" :href="withCampaign(item.url)" data-wba-campaign="recommend" target="_blank">查看详情</a></p>                        </div>

                        <div class="item-ft">
                            <span><svg class="wb-icon wbsico-views"><use xlink:href="#wbsico-views"></use></svg> <em>{{item.view_count}}</em></span>
                            <span><svg class="wb-icon wbsico-time"><use xlink:href="#wbsico-time"></use></svg> <em>{{item.post_date | displayDate}}</em></span>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
        <div class="sc-header">
            <strong>精品插件</strong>
            <span></span>
        </div>

        <div class="sc-body wbolt-products">
            <ul class="pd-items-b">
                <li class="pd-item" v-for="item in wbMoreData.plugins">
                    <div class="item-inner">
                        <a class="post-thumbnail thumbnail-plugins" :href="withCampaign(item.url)" data-wba-campaign="recommend" target="_blank">
                            <img :src="item.thumb[0]">
                        </a>
                        <div class="pd-info">
                            <a class="pd-name" :href="withCampaign(item.url)" data-wba-campaign="recommend" target="_blank"><em v-if="item.status_tag" class="state-tag" :class="item.status_tag">{{item.status_tag}}</em><span>{{item.post_title}}</span></a>
                            <div class="pd-desc">{{item.excerpt}}</div>
                            <p><a class="btn-sm" :href="withCampaign(item.url)" data-wba-campaign="recommend" target="_blank">查看详情</a></p>                        </div>

                        <div class="item-ft">
                            <span><svg class="wb-icon wbsico-views"><use xlink:href="#wbsico-views"></use></svg> <em>{{item.view_count}}</em></span>
                            <span><svg class="wb-icon wbsico-time"><use xlink:href="#wbsico-time"></use></svg> <em>{{item.post_date | displayDate}}</em></span>
                        </div>
                    </div>
                </li>
            </ul>
        </div>

        <div class="sc-header">
            <strong>WP教程</strong>
            <span></span>
        </div>
        <div class="sc-body">
            <ul class="list-blog wbolt-products">
                <li class="list-item" v-for="item in wbMoreData.blog">
                    <div class="item-inner">
                        <a class="media-pic" :href="withCampaign(item.url)" data-wba-campaign="recommend" target="_blank">
                            <img :src="item.thumb[0]">
                        </a>
                        <div class="media-body">
                            <a class="post-title" :href="withCampaign(item.url)" data-wba-campaign="recommend" target="_blank">{{item.post_title}}</a>
                            <div class="summary">{{item.excerpt}}</div>
                            <div class="post-metas">
                                <span class="meta-item primary">
                                    <svg class="wb-icon wbsico-time"><use xlink:href="#wbsico-time"></use></svg>
                                    <em>{{item.post_date | displayDate}}</em>
                                </span>
                                <span class="meta-item">
                                    <svg class="wb-icon wbsico-views"><use xlink:href="#wbsico-views"></use></svg>
                                    <em>{{item.view_count}}</em>
                                </span>
                                <a class="meta-item" href="withCampaign(item.url)">
                                <svg class="wb-icon wbsico-comment"><use xlink:href="#wbsico-comment"></use></svg>
                                <em>{{item.comment_count}}</em>
                                </a>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</template>


<?php
/**
 * 推荐产品
 */
?>
<template id="wbs_tpl_upload">
    <div class="wbs-upload-box"><input class="wbs-input upload-input" type="text" :value="url" v-on:change="$emit('get-file', $event.target.value)">
        <button type="button" class="wbs-btn" v-on:click="uploadFiles()">
            <svg class="wb-icon sico-upload "><use xlink:href="#sico-upload"></use></svg>
            <span>选择图片</span>
        </button>
    </div>
</template>

<?php
/**
 * 设置封面图显示比例
 */
?>
<template id="wbs_tpl_str">
    <div>
        <div class="selector-bar">
            <label>
                <input type="radio" value="" v-model="thumbnail_rate" @change="$emit('set-value', $event.target.value)" :checked="opt.thumbnail_rate == ''">
                <span>1:1</span>
            </label>
            <label v-for="item in cnf">
                <input type="radio" :value="item" v-model="thumbnail_rate" @change="$emit('set-value', $event.target.value)">
                <span>{{item}}</span>
            </label>
            <label>
                <input class="wbs-input w8em" v-model="thumbnail_rate" @change="$emit('set-value', $event.target.value)">
                <span>* 可输入自定义 宽:高</span>
            </label>
        </div>
        <div class="description mt">
            * 其他尺寸特色图比例参考：电影海报27:40.5，16开杂志21:28.5或18.5:26 ，32开图书13.6:21
        </div>
        <div class="mt">
            <a class="link" @click="swichDemo">预览 ></a>
            <div class="img-rate-demo" v-if="demo">
                <ul>
                    <li v-for="i in [1,2,3,4,5,6,7,8]">
                        <div class="cover" :style="'padding-top:' + imgRate"><i>{{thumbnail_rate}}</i></div>
                        <span></span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</template>
