<?php /**
 * WBolt 主题基本设置
 **/
 ?>

<div class="sc-header">
    <strong>基本设置</strong>
    <span>网站基本设置</span>
</div>

<div class="sc-body">
    <table class="wbs-form-table">
        <tbody>
        <tr>
            <th class="w8em row">Logo</th>
            <td>
                <div id="section-logo_src" class="section section-upload">
                    <wbs-upload-box :url="opt.logo_url" v-on:get-file="opt.logo_url = $event"></wbs-upload-box>

                    <p class="description">建议Logo图片高度至少68像素（包括上下留白）及不大于204像素，宽度随高度等比例显示。</p>
                </div>
            </td>
        </tr>

        <tr>
            <th class="row">Favicon</th>
            <td>
                <div id="section-favicon_src" class="section section-upload">
                    <wbs-upload-box :url="opt.favicon" v-on:get-file="opt.favicon = $event"></wbs-upload-box>
                </div>
				<div class="description mt">查看<a a href="https://www.wbolt.com/favicon-generator.html"  target="_blank">在线快速生成网址图标favicon</a>教程。</div>
            </td>
        </tr>

        <tr>
            <th class="row">默认图</th>
            <td>
                <div id="section-defimg_src" class="section section-upload">
                    <wbs-upload-box :url="opt.def_img_url" v-on:get-file="opt.def_img_url = $event"></wbs-upload-box>
                </div>
            </td>
        </tr>

        <tr>
            <th class="row">特色图宽高比</th>
            <td>
                <set-thumb-rate :opt="opt.thumbnail_rate" :cnf="wbs_cnf.thumbnail_rate" v-on:set-value="opt.thumbnail_rate = $event"></set-thumb-rate>
            </td>
        </tr>

        <tr>
            <th class="row">主题主色调</th>
            <td>
                <div class="themes-color-items">
                    <input type="radio" value="" style="background-color:#152256" v-model="opt.theme_color" :checked="opt.theme_color == ''">
                    <input type="radio" value="#A02533" style="background-color:#A02533" v-model="opt.theme_color">
                    <input type="radio" value="#CA891E" style="background-color:#CA891E" v-model="opt.theme_color">
                    <input type="radio" value="#6BB020" style="background-color:#6BB020" v-model="opt.theme_color">
                    <input type="radio" value="#8B572A" style="background-color:#8B572A" v-model="opt.theme_color">
                    <input type="radio" value="#000000" style="background-color:#000000" v-model="opt.theme_color">
                    <input type="radio" value="#666666" style="background-color:#666666" v-model="opt.theme_color">

                    <label>
                        <input class="wbs-input w8em" v-model="opt.theme_color" :style="'border-color:' + opt.theme_color">
                        <span>* 可输入自定义颜色值，格式：#XXXXXX</span>
                    </label>
                </div>
            </td>
        </tr>

        <tr>
            <th class="row">文章编辑器</th>
            <td>
                <input class="wb-switch" type="checkbox" v-model="opt.gutenberg_switch" true-value="1" false-value="0"> <span class="description">默认激活选项使用传统编辑器关闭古腾堡。</span>
            </td>
        </tr>

        <tr>
            <th class="row">自动加载分页数</th>
            <td>
                <input class="wb-switch" type="checkbox" data-target="#J_rangeAutoLoadSetting" v-model="opt.autoload_switch" true-value="1" false-value="0"> <span class="description">列表下拉自动加载，默认关闭</span>

                <div class="default-hidden-box mt" :class="{active: opt.autoload_switch != '0'}" id="J_rangeAutoLoadSetting">
                    <input class="wbs-input w6em" v-model="opt.mxpage" placeholder="输入数字" type="number" maxlength="2" min="0" />
                    <span class="description">设定浏览时自动加载暂停的页数，若启动，建议设定3-5页</span>
                </div>
            </td>
        </tr>

       <tr>
            <th class="row">列表文章数量</th>
            <td>
                <div class="info">
                    你可以通过<b>仪表盘-设置-阅读</b>来设置博客页面至多显示文章数量，<a href="<?php echo admin_url('options-reading.php'); ?>" target="_blank">现在设置</a>
                </div>
            </td>
        </tr>	
		
        <tr>
            <th class="row">首页展示分类</th>
            <td>

                <div class="cate-list" id="cat_list">

                    <div v-for="(cat, idx) in cate_list" class="cl-item">
                        <label><input class="set-cate" type="checkbox" name="floor" v-model="floor" :value="cat.term_id">{{cat.name}}</label>
                    </div>
                </div>
                <p class="description">勾选在首页展示的分类</p>

                <ul class="selected-items-wp sortable" id="J_selectedCateWp">
                    <li v-for="(fl_id, idx) in floor" :id="fl_id">
                        {{fl_id | flName}}
                    </li>
                </ul>
                <p class="description">拖动以设定分类展示顺序</p>
            </td>
        </tr>
        </tbody>
    </table>
</div>

<div class="sc-header">
    <strong>页脚设置</strong>
</div>
<div class="sc-body" v-if="opt.footer">
    <table class="wbs-form-table">
        <tbody>
		<tr>
            <th class="w8em row">页面菜单</th>
            <td>
                <div class="info">
                    你可以通过<b>仪表盘-外观-菜单</b>来设置页脚需要展示的菜单内容。创建保存一个菜单，编辑菜单添加菜单项保存后，并管理该菜单位置为页脚链接。<a href="<?php echo admin_url('nav-menus.php'); ?>" target="_blank">现在设置</a>
                </div>
            </td>
        </tr>	
        <tr>
            <th class="row">
                版权信息
            </th>
            <td>
                <input class="wbs-input" v-model.trim="opt.footer.copyright" placeholder="网站名称版权所有">
            </td>
        </tr>
        <tr>
            <th class="row">
                备案号
            </th>
            <td>
                <input class="wbs-input" v-model.trim="opt.footer.miit_id" placeholder="备案号">
            </td>
        </tr>
        </tbody>
    </table>
</div>
