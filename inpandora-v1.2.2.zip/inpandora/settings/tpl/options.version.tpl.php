<?php /**
 * WBolt 版本信息
 **/
?>

<div class="sc-header"><h3><strong>环境参数</strong></h3></div>
<div class="sc-body">
    <textarea id="sys_info_textarea" style="width: 80%; min-height: 300px; padding:10px; margin-bottom: 10px; display: none;"></textarea>
    <div><button type="button" onclick="create_sys_info()" class="button">生成系统报告</button></div>
	<div class="description mt">复制粘贴生成的系统报告至工单，以帮助技术人员快速定位解决问题。</div>
</div>

<div class="sc-body sc-version">
    <h3 class="data-sc-title"><span>主题版本</span></h3>
    <table class="wbs-data-table">
        <tbody>
        <tr>
            <th class="w8em">主题名称</th>
            <td><?php echo $pd_name; ?></td>
        </tr>
        <tr>
            <th>当前版本</th>
            <td><?php echo WB_THEMES_VER; ?></td>
        </tr>
        <tr>
            <th>最新版本</th>

            <td>
                <span v-if="!new_ver"><?php echo WB_THEMES_VER; ?></span>
                <span v-if="new_ver">{{new_ver}}</span>
            </td>
        </tr>
        </tbody>
    </table>
</div>

<div class="sc-body sc-version">
    <h3 class="data-sc-title"><span>WordPress环境</span></h3>
    <table class="wbs-data-table">
        <tbody>
        <tr>
            <th class="w8em">网站首页</th>
            <td><?php echo home_url('/'); ?></td>
        </tr>
        <tr>
            <th>WP内容路径</th>
            <td><?php echo defined( 'WP_CONTENT_DIR' ) ? esc_html( WP_CONTENT_DIR ) : 'N/A';?></td>
        </tr>
        <tr>
            <th>WP安装路径</th>
            <td><?php echo defined( 'ABSPATH' ) ? esc_html( ABSPATH ) : 'N/A';?></td>
        </tr>
        <tr>
            <th>WP版本信息</th>
            <td><?php bloginfo( 'version' );?></td>
        </tr>
        <tr>
            <th>PHP内存限制</th>
            <td><?php
                $memory = ini_get( 'memory_limit' );
                // If we can't get it, fallback to WP_MEMORY_LIMIT.
                if ( ! $memory || -1 === $memory ) {
                    $memory = wp_convert_hr_to_bytes( WP_MEMORY_LIMIT );
                }
                // Make sure the value is properly formatted in bytes.
                if ( ! is_numeric( $memory ) ) {
                    $memory = wp_convert_hr_to_bytes( $memory );
                }
                echo esc_attr( size_format( $memory ) );

                ?></td>
        </tr>
        <tr>
            <th>WP调试模式</th>
            <td><?php
                if ( defined( 'WP_DEBUG' ) && WP_DEBUG ){
                    echo '开启';
                }else{
                    echo '关闭';
                }?></td>
        </tr>
        <tr>
            <th>语言版本</th>
            <td><?php echo esc_attr( get_locale() ); ?></td>
        </tr>
        </tbody>
    </table>
</div>

<div class="sc-body sc-version">
    <h3 class="data-sc-title"><span>服务器环境</span></h3>
    <table class="wbs-data-table">
        <tbody>
        <tr>
            <th class="w8em">服务器信息</th>
            <td><?php echo isset( $_SERVER['SERVER_SOFTWARE'] ) ? esc_attr( sanitize_text_field( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) ) ) : 'Unknown'; ?></td>
        </tr>
        <tr>
            <th>PHP版本</th>
            <td><?php
                $php_version = null;
                if ( defined( 'PHP_VERSION' ) ) {
                    $php_version = PHP_VERSION;
                } elseif ( function_exists( 'phpversion' ) ) {
                    $php_version = phpversion();
                }
                echo $php_version?$php_version:'Unknown';
                ?></td>
        </tr>
        <tr>
            <th>PHP Post Max Size</th>
            <td><?php echo esc_attr( size_format( wp_convert_hr_to_bytes( ini_get( 'post_max_size' ) ) ) );;?></td>
        </tr>
        <tr>
            <th>PHP Time Limit</th>
            <td><?php $time_limit = ini_get( 'max_execution_time' );
                echo esc_attr( $time_limit );?>s</td>
        </tr>
        <tr>
            <th>PHP Max Input Vars</th>
            <td><?php $max_input_vars      = ini_get( 'max_input_vars' );
                echo esc_attr( $max_input_vars );
                ?></td>
        </tr>
        <tr>
            <th>ZipArchive</th>
            <td><?php echo class_exists( 'ZipArchive' ) ? '启用':'未启用';?></td>
        </tr>
        <tr>
            <th>MySQL Version</th>
            <td><?php global $wpdb; ?>
                <?php echo esc_attr( $wpdb->db_version() ); ?></td>
        </tr>
        <tr>
            <th>Max Upload Size</th>
            <td><?php echo esc_attr( size_format( wp_max_upload_size() ) ); ?></td>
        </tr>
        <tr>
            <th>DOMDocument</th>
            <td><?php echo class_exists( 'DOMDocument' ) ? '启用':'未启用';?></td>
        </tr>
        <tr>
            <th>WP Remote Get</th>
            <td><?php $response = wp_remote_get(
                    'https://www.wbolt.com',
                    array(
                        'user-agent' => 'wbolt-remote-get-test',
                    )
                );
                echo (wp_remote_retrieve_response_code($response)==200) ? '成功':'失败';
                ?></td>
        </tr>
        <tr>
            <th>WP Remote Post</th>
            <td><?php $response = wp_remote_post(
                    'https://www.wbolt.com',
                    array(
                        'user-agent' => 'wbolt-remote-post-test',
                    )
                );
                echo (wp_remote_retrieve_response_code($response)==200) ? '成功':'失败';
                ?></td>
        </tr>
        <tr>
            <th>GD Library</th>
            <td><?php
                $info = '未安装';
                if ( extension_loaded( 'gd' ) && function_exists( 'gd_info' ) ) {
                    $info    = '已安装';
                    $gd_info = gd_info();
                    if ( isset( $gd_info['GD Version'] ) ) {
                        $info = $gd_info['GD Version'];
                    }
                }
                echo esc_attr( $info );

                ?></td>
        </tr>
        </tbody>
    </table>
</div>

<div class="sc-body sc-version">
    <h3 class="data-sc-title"><span>激活插件</span></h3>
    <table class="wbs-data-table">
        <tbody>
        <?php
        $active_plugins = (array) get_option( 'active_plugins', array() );
        $plugins      = get_plugins();

        foreach($active_plugins as $plug){
            $row = $plugins[$plug];

            ?>
            <tr>
                <th class="w8em"><?php echo $row['Name'];?></th>
                <td>Develop by <?php echo $row['Author']; ?></td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>