<?php /**
 * WBolt 主题广告设置
 * array('id'=>'', 'name' => '', 'type' => 0, 'code'=>'', 'img'=>'', 'url'=>'', 'code_desc' => '', 'img_desc' => '')
 **/
?>
<template id="wbs_tpl_ads">
    <div>
        <div class="sc-header">
            <strong>现有广告位</strong>
        </div>
        <div class="sc-body">
            <table class="table wbs-table table-thead">
                <thead>
                <tr>
                    <th>名称</th>
                    <th>类型</th>
                    <th>操作</th>
                </tr>
                </thead>
                <tbody>
                <tr v-for="(v,k) in cnf">
                    <td>{{v.name}}</td>
                    <td>{{ad_type(k)}}</td>
                    <td>
                        <a class="ctrl-item" @click="ads_edit_active=2;ads_editing=opt[k]" title="修改"><svg class="wb-icon sico-edit"><use xlink:href="#sico-edit"></use></svg></a>
                    </td>
                </tr>
                </tbody>
            </table>
        </div>


        <div id="wbui999" class="wbui wbui-dialog wbui-wbs-panel" index="999" v-if="ads_edit_active > 0">
            <div class="wbui-mask" @click="closeAdDialog"></div>
            <div class="wbui-main">
                <div class="wbui-section">
                    <div class="wbui-child  wbui-anim-def">
                        <h3 class="wbui-title">{{ads_edit_active > 1 ? '修改' : '新增'}}广告位</h3>
                        <div class="wbui-cont">

                            <div class="sc-body">
                                <table class="wbs-form-table wb-data-table">
                                    <tbody>
                                    <tr>
                                        <th class="w6em">广告类型：</th>
                                        <td>
                                            <div class="selector-bar">
                                                <label><input class="wbs-radio" type="radio" value="0" v-model="ads_editing.type"> 关闭</label>
                                                <label><input class="wbs-radio" type="radio" value="1" v-model="ads_editing.type"> 代码广告</label>
                                                <label><input class="wbs-radio" type="radio" value="2" v-model="ads_editing.type"> 图片广告</label>
                                            </div>

                                            <div class="wbs-ad-item" v-show="ads_editing.type == 1">
                                                <textarea class="large-text code wbs-input" rows="5" cols="42" placeholder="广告代码" v-model="ads_editing.code"></textarea>
                                                <p class="description"> </p>
                                            </div>

                                            <div class="wbs-ad-item" v-show="ads_editing.type == 2">
                                                <wbs-upload-box v-bind:url="ads_editing.img" v-on:get-file="ads_editing.img = $event"></wbs-upload-box>

                                                <div class="mt">
                                                    <input class="wbs-input" type="text" v-model="ads_editing.url" placeholder="请输入广告链接 http(s)://xxx"/>
                                                </div>

                                                <div class="selector-bar mt">
                                                    <label>
                                                        <input type="checkbox" v-model="ads_editing.nofollow" true-value="1"><span>设置nofollow</span>
                                                    </label>
                                                    <label>
                                                        <input type="checkbox" v-model="ads_editing.target" true-value="1"><span>新窗口打开</span>
                                                    </label>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <td>
                                            <div class="wbs-btns">
                                                <button type="button" class="button button-cancel" @click="closeAdDialog">取消</button>
                                                <button type="button" class="button button-primary" @click="closeAdDialog">确认</button>
                                            </div>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                        <a class="wbui-close" @click="closeAdDialog"><i></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>