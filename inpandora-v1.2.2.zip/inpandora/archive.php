<?php
/**
 * The template for displaying archive pages
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * If you'd like to further customize these archive views, you may create a
 * new template file for each one. For example, tag.php (Tag archives),
 * category.php (Category archives), author.php (Author archives), etc.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Inpandora
 * @since Wbolt 1.0
 */
$GLOBALS['container-custom'] = 'container-list';
get_header();

$have_posts = have_posts();
?>

<div class="header-list">
    <div class="title-list">
		<?php
		global $wp_query;
		$item_count = number_format($wp_query->found_posts);
		$item_count = $item_count > 0 ? $item_count . '个' : '';
		?>
        <h1>共<?php echo $item_count . single_cat_title( '', false ); ?>相关</h1>
		<?php if ( category_description() ) : ?>
            <div class="description"><?php echo category_description(); ?></div>
		<?php endif; ?>
    </div>
</div>

<?php if ( $have_posts ) : ?>
	<?php echo wb_insert_ad_block('list_block','adbanner-block under-list-title'); ?>

    <div class="articles-list<?php echo wp_is_mobile() ? ' list-mode-b':' list-mode-a'; ?>" id="J_postList">
		<?php

		while ( have_posts() ) : the_post();
			get_template_part( 'template-parts/content', get_post_format() );

		endwhile;
		?>
    </div>
    <div class="loading-bar"></div>
	<?php
	wbolt_the_posts_pagination();
	?>

<?php else :
	get_template_part( 'template-parts/content-none', 'none' );

endif;
?>

<?php get_footer(); ?>
