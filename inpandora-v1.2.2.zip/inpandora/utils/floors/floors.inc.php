<?php

/**
 *
 *
 */

class WBFloors
{
    function __construct()
    {

    }

	function sort_index_catid($catids){
		global $wpdb;
		if(!$catids)return '';
		$sql = "SELECT a.term_taxonomy_id FROM ".$wpdb->term_relationships." a,".$wpdb->posts." b 
            WHERE a.object_id=b.ID AND b.post_status='publish' AND a.term_taxonomy_id in($catids) order by b.post_date DESC";

		$r = $wpdb->get_col($sql);
		$r = array_unique($r);
		if(is_array($r))return implode(',',$r);
		return '';
	}
}

new WBFloors();