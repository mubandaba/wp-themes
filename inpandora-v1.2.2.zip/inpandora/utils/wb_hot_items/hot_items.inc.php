<?php
/**
 * same_cate 排序按所属分类或是全部同类型post, 默认是按全部 （值为0)
 * borderby 排序依据是浏览数或是下载数, 默认是按浏览数 （值为0)
 * max 展示最大记录数，默认值是 5
 * section_name 模块标题，默认为 相关推荐
 */

class WB_Hot_Items
{

	public function __construct()
	{
		add_shortcode( 'wb_hot_items', array(__CLASS__,'get_hot_items'));
	}

	public static function get_hot_items($atts=array()){
		$post = get_queried_object();

//		if(!is_single())return '';

		$defaults = array(
			'same_cate' => 0,
			'orderby' => 1,
            'max' => 5,
			'name' => __('热门', 'wbolt')
		);
		$atts = wp_parse_args( $atts, $defaults );

		$svgHTML = $atts['orderby'] ? wbolt_svg_icon('wbsico-download') : wbolt_svg_icon('wbsico-views');
		$meta_key = $atts['orderby'] ? 'post_downs' : 'post_views_count';

		$post_ids = isset($atts['ids']) && $atts['ids'] != '' ? explode(',',$atts['ids']) : self::get_related_posts_id($post, $atts);

		$content =  '<section class="widget widget-hot">
			<h3 class="widgettitle">'.$atts['name'].'</h3>';

		$content .= '<ul class="post-list'. (get_thumb_rate() != 1 ? ' with-custom-cover':'') . '">';

		foreach ($post_ids as $id){
			$thumb = get_the_post_thumbnail( $id, 'post-thumbnail' );
			if(!$thumb){
				$img = wbolt_catch_first_image($id);

				if($img && isset($img['src'])){
					$thumb = '<img class="auto-cover'.(isset($img['spc_class'])?$img['spc_class']:'').'" src="'. wb_opt('def_img_url', 'data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==') .'" data-src="'.$img['src'].'" alt="">';
				}
				if(!$thumb){
					$thumb = wb_opt('def_img_url') ? '<img src="'. wb_opt('def_img_url') .'" alt="">' : '<img src="'. WB_THEME_URI .'/images/wbolt_def_cover.png" alt="">';
				}
			}
			$url = esc_url( apply_filters( 'the_permalink', get_permalink( $id ) ) );

			$content .=  '<li class="post">
							<div class="media-pic"><a href="' . $url . '">' . $thumb . '</a></div>
							<div class="media-body">
								<a class="title" href="'. $url .'">' . get_the_title( $id ) . '</a>
								<p class="post-metas">' . $svgHTML . '<em class="meta-dl">' . get_post_meta($id,$meta_key,true) . '</em></p>
							</div>
						</li>';
		}


		$content .= '</ul></section>';

		return $content;
	}

	function  post_cats($post_id){
		$cat = get_the_category( $post_id );
		return wp_list_pluck( $cat, 'term_id' );
	}

	static function get_related_posts_id( $post,$opt,$not_in = array() ) {
		$num_posts = $opt['max'];
		$order_by = $opt['orderby'] ? 'post_downs' : 'post_views_count';
		$not_in[] = $post->ID;

		$args = array(
			'post_type' => $post->post_type,
			'post_status' => 'publish',
//			'date_query'=>array('after'=>date('Y-m-d',strtotime('-1 year'))),
			'order'=>'DESC',
			'meta_key'=> $order_by,
			'orderby' => 'meta_value_num',
			'post__not_in' => $not_in,
			'numberposts' => $num_posts,
			'post_count' => $num_posts
		);
		// auto posts by tags 根据post ID获取所属分类ID数组
		if( $opt['same_cate'] ){
			$cat = get_the_category( $post->ID );
			$cat_ids = wp_list_pluck( $cat, 'term_id' );
			$args['category'] = implode( ',', $cat_ids );
		}

		// auto posts query
		$relative_query = get_posts( $args );
		$rel_id = array(); // set empty
		// we found posts ?
		if ( ! empty( $relative_query ) ) {
			$rel_id = wp_list_pluck( $relative_query, 'ID' );
		}

		return $rel_id;
	}

}
new WB_Hot_Items();


