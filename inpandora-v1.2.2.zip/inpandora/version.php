<?php
define('WB_THEMES_VER','1.2.2');
define('WB_ASSETS_VER','202009');
define('WB_THEMES_NAME','Inpandora');
define('WB_THEMES_CODE','inpandora');