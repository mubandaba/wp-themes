<?php  
include('widget-postlist.php');//文章
?>