<?php
/* options css */
$header_image = get_header_image();
$bg_image = get_background_image();
$bg_color = get_background_color();
?>

<?php if($bg_color) { ?>
#post-entry article,#right-sidebar .widget-area aside {border: 1px solid <?php echo dehex($bg_color,-5); ?>;box-shadow: 0 0 5px <?php echo dehex($bg_color,-40); ?>;  }
.ad-loop-post, .adsense-post {border-bottom: 1px solid <?php echo dehex($bg_color,10); ?>;border-top: 1px solid <?php echo dehex($bg_color,10); ?>;}
<?php } ?>


<?php
if( get_theme_option('body_font') == 'Choose a font' || get_theme_option('body_font') == '') { ?>
body, .post-meta { font-family:'Open sans',arial,sans-serif;font-weight:400;}
<?php } else { ?>
body, .post-meta { font-family: <?php echo get_theme_option('body_font'); ?> !important; font-weight: <?php echo get_theme_option('body_font_weight'); ?> !important; }
<?php } ?>

<?php
if( get_theme_option('headline_font') == 'Choose a font' || get_theme_option('headline_font') == '') { ?>
h1,h2,h3,h4,h5,h6,#siteinfo h1, #siteinfo div,ul.tabbernav li a,#post-entry div.post-thumb span.post-category a,#post-entry .post-meta,.fbottom,#textpad  {font-family:'Oswald',arial,sans-serif;font-weight:400;}
<?php } else { ?>
h1,h2,h3,h4,h5,h6,#siteinfo h1, #siteinfo div,ul.tabbernav li a,#post-entry div.post-thumb span.post-category a,#post-entry .post-meta,.fbottom,#textpad  {
font-family:  <?php echo get_theme_option('headline_font'); ?> !important; font-weight: <?php echo get_theme_option('headline_font_weight'); ?> !important;}
<?php } ?>

<?php
if( get_theme_option('navigation_font') == 'Choose a font' || get_theme_option('navigation_font') == '') { ?>
#main-navigation, .sf-menu li a,.share_box .continue-reading { font-family:'Oswald',arial,sans-serif;font-weight:300;}
<?php } else { ?>
#main-navigation, .sf-menu li a,.share_box .continue-reading { font-family:  <?php echo get_theme_option('navigation_font'); ?> !important; font-weight: <?php echo get_theme_option('navigation_font_weight'); ?> !important;}
<?php } ?>

<?php
$header_color = get_theme_option('header_color');
if( $header_color ) { ?>

#header {
background: <?php echo $header_color; ?>;
background: -moz-linear-gradient(top, <?php echo dehex($header_color,-25); ?> 0%, <?php echo $header_color; ?> 54%, <?php echo dehex($header_color,-15); ?> 94%);
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,<?php echo dehex($header_color,-25); ?>), color-stop(54%,<?php echo $header_color; ?>), color-stop(94%,<?php echo dehex($header_color,-15); ?>));
	background: -webkit-linear-gradient(top, <?php echo dehex($header_color,-25); ?> 0%, <?php echo $header_color; ?> 54%, <?php echo dehex($header_color,-15); ?> 94%);
	background: -o-linear-gradient(top, <?php echo dehex($header_color,-25); ?> 0%, <?php echo $header_color; ?> 54%, <?php echo dehex($header_color,-15); ?> 94%);
	background: -ms-linear-gradient(top, <?php echo dehex($header_color,-25); ?> 0%, <?php echo $header_color; ?> 54%, <?php echo dehex($header_color,-15); ?> 94%);
	background: linear-gradient(to bottom, <?php echo dehex($header_color,-25); ?> 0%, <?php echo $header_color; ?> 54%, <?php echo dehex($header_color,-15); ?> 94%);
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='<?php echo dehex($header_color,-25); ?>', endColorstr='<?php echo dehex($header_color,-15); ?>',GradientType=0 );
	border-bottom: 10px solid <?php echo dehex($header_color,-25); ?>;
}
.sf-menu ul {background: <?php echo dehex($header_color,-25); ?> none;}
.sf-menu ul li a:hover {background: <?php echo dehex($header_color,-40); ?> none;}
<?php } ?>


<?php
$footer_color = get_theme_option('footer_color');
if( $footer_color ) { ?>

.footer-top {
background: <?php echo $footer_color; ?>;
background: -moz-linear-gradient(top, <?php echo dehex($footer_color,-25); ?> 0%, <?php echo $footer_color; ?> 54%, <?php echo dehex($footer_color,-15); ?> 94%);
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,<?php echo dehex($footer_color,-25); ?>), color-stop(54%,<?php echo $footer_color; ?>), color-stop(94%,<?php echo dehex($footer_color,-15); ?>));
	background: -webkit-linear-gradient(top, <?php echo dehex($footer_color,-25); ?> 0%, <?php echo $footer_color; ?> 54%, <?php echo dehex($footer_color,-15); ?> 94%);
	background: -o-linear-gradient(top, <?php echo dehex($footer_color,-25); ?> 0%, <?php echo $footer_color; ?> 54%, <?php echo dehex($footer_color,-15); ?> 94%);
	background: -ms-linear-gradient(top, <?php echo dehex($footer_color,-25); ?> 0%, <?php echo $footer_color; ?> 54%, <?php echo dehex($footer_color,-15); ?> 94%);
	background: linear-gradient(to bottom, <?php echo dehex($footer_color,-25); ?> 0%, <?php echo $footer_color; ?> 54%, <?php echo dehex($footer_color,-15); ?> 94%);
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='<?php echo dehex($footer_color,-25); ?>', endColorstr='<?php echo dehex($footer_color,-15); ?>',GradientType=0 );
	border-top: 10px solid <?php echo dehex($footer_color,-25); ?>;
}

footer .widget li {border-bottom: 1px solid <?php echo dehex($footer_color,-20); ?>;}

.footer-bottom {
  background: <?php echo dehex($footer_color,-25); ?>;
  border-top: 1px solid <?php echo dehex($footer_color,5); ?>;
}

<?php } ?>


<?php
$links_color = get_theme_option('links_color');
if( $links_color ) { ?>
#right-sidebar aside .textwidget a {color: <?php echo $links_color; ?>;}
#right-sidebar aside.widget a:hover,.content a,#post-related h2 a:hover, #post-related p a:hover, #post-related-inline h2 a:hover {color: <?php echo $links_color; ?>;}
#container .content a:hover {color:<?php echo dehex($links_color,20); ?> !important;}
<?php } ?>