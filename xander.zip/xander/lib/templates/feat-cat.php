<?php
$feat_cat_one = get_theme_option('feat_cat_one');
$feat_cat_two = get_theme_option('feat_cat_two');
$feat_cat_three = get_theme_option('feat_cat_three');
$feat_cat_four = get_theme_option('feat_cat_four');
$feat_cat_five = get_theme_option('feat_cat_five');
$num = '5';
?>


<?php if( ($feat_cat_one == '' && $feat_cat_two == '' && $feat_cat_three == '' && $feat_cat_four == '' && $feat_cat_five == '') || ($feat_cat_one == 'Choose a category' && $feat_cat_two == 'Choose a category' && $feat_cat_three == 'Choose a category' && $feat_cat_four == 'Choose a category' && $feat_cat_five == 'Choose a category') ): ?>

<?php else: ?>

<div id="homefeat">

<?php if($feat_cat_one != '' && $feat_cat_one != 'Choose a category') { ?>
<div class="homefeatbox">
<h3><a href="<?php echo get_category_link( $feat_cat_one ); ?>"><?php echo get_cat_name($feat_cat_one); ?></a></h3>
<ul>
<?php
$oddpost = 'alt-post';$postcount = 0;
$query = new WP_Query( "cat=".$feat_cat_one."&posts_per_page=". $num. "&orderby=date" );
while ( $query->have_posts() ) : $query->the_post();
$thepostlink = '<a href="'. get_permalink() . '" title="' . the_title_attribute('echo=0') . '">';
if($postcount > '0') {  $thumb = 'thumbnail'; $wx = '150'; $hx = '150';} else { $thumb = 'medium'; $wx = '320'; $hx = '240'; }
?>
<li class="post-<?php echo $postcount; ?> <?php echo $oddpost; ?>">
<div class="post-content">
<?php if($postcount == 0) {
echo get_featured_post_image("<div class='homefeatthumb'>".$thepostlink, "</a></div>", $wx, $hx, "alignleft", $thumb, the_title_attribute('echo=0') ,the_title_attribute('echo=0'), false); ?>
<div class="homefeat-title-wrapper"><h2><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2><p><?php echo get_custom_the_excerpt(40); ?></p><?php get_template_part( 'lib/templates/share-box' ); ?> </div>
<?php } else {
echo get_featured_post_image("<div class='homefeatthumbsmall'>".$thepostlink, "</a></div>", $wx, $hx, "alignleft", $thumb, the_title_attribute('echo=0') ,the_title_attribute('echo=0'), false); ?>
<div class="homefeat-title-wrapper"><h2><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2><p><?php echo get_custom_the_excerpt(15); ?></p><?php get_template_part( 'lib/templates/share-box' ); ?> </div>
<?php } ?>
     </div>
</li>
<?php ($oddpost == "alt-post") ? $oddpost="" : $oddpost="alt-post"; $postcount++; ?>
<?php endwhile; wp_reset_query(); ?>
</ul>
</div>
<?php } ?>

<?php do_action('mp_after_featcat_one'); ?>

<?php if($feat_cat_two != '' && $feat_cat_two != 'Choose a category') { ?>
<div class="homefeatbox">
<h3><a href="<?php echo get_category_link( $feat_cat_two ); ?>"><?php echo get_cat_name($feat_cat_two); ?></a></h3>
<ul>
<?php
$oddpost = 'alt-post';$postcount = 0;
$query = new WP_Query( "cat=".$feat_cat_two."&posts_per_page=". $num. "&orderby=date" );
while ( $query->have_posts() ) : $query->the_post();
$thepostlink = '<a href="'. get_permalink() . '" title="' . the_title_attribute('echo=0') . '">';
if($postcount > '0') {  $thumb = 'thumbnail'; $wx = '150'; $hx = '150';} else { $thumb = 'medium'; $wx = '320'; $hx = '240'; }
?>
<li class="post-<?php echo $postcount; ?> <?php echo $oddpost; ?>">
<div class="post-content">
<?php if($postcount == 0) {
echo get_featured_post_image("<div class='homefeatthumb'>".$thepostlink, "</a></div>", $wx, $hx, "alignleft", $thumb, the_title_attribute('echo=0') ,the_title_attribute('echo=0'), false); ?>
<div class="homefeat-title-wrapper"><h2><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2><p><?php echo get_custom_the_excerpt(40); ?></p><?php get_template_part( 'lib/templates/share-box' ); ?> </div>
<?php } else {
echo get_featured_post_image("<div class='homefeatthumbsmall'>".$thepostlink, "</a></div>", $wx, $hx, "alignleft", $thumb, the_title_attribute('echo=0') ,the_title_attribute('echo=0'), false); ?>
<div class="homefeat-title-wrapper"><h2><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2><p><?php echo get_custom_the_excerpt(15); ?></p><?php get_template_part( 'lib/templates/share-box' ); ?> </div>
<?php } ?>
</div>
</li>
<?php ($oddpost == "alt-post") ? $oddpost="" : $oddpost="alt-post"; $postcount++; ?>
<?php endwhile; wp_reset_query(); ?>
</ul>
</div>
<?php } ?>

<?php do_action('mp_after_featcat_two'); ?>

<?php if($feat_cat_three != '' && $feat_cat_three != 'Choose a category') { ?>
<div class="homefeatbox">
<h3><a href="<?php echo get_category_link( $feat_cat_three ); ?>"><?php echo get_cat_name($feat_cat_three); ?></a></h3>
<ul>
<?php
$oddpost = 'alt-post';$postcount = 0;
$query = new WP_Query( "cat=".$feat_cat_three."&posts_per_page=". $num. "&orderby=date" );
while ( $query->have_posts() ) : $query->the_post();
$thepostlink = '<a href="'. get_permalink() . '" title="' . the_title_attribute('echo=0') . '">';
if($postcount > '0') {  $thumb = 'thumbnail'; $wx = '150'; $hx = '150';} else { $thumb = 'medium'; $wx = '320'; $hx = '240'; }
?>
<li class="post-<?php echo $postcount; ?> <?php echo $oddpost; ?>">
<div class="post-content">
<?php if($postcount == 0) {
echo get_featured_post_image("<div class='homefeatthumb'>".$thepostlink, "</a></div>", $wx, $hx, "alignleft", $thumb, the_title_attribute('echo=0') ,the_title_attribute('echo=0'), false); ?>
<div class="homefeat-title-wrapper"><h2><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2><p><?php echo get_custom_the_excerpt(40); ?></p><?php get_template_part( 'lib/templates/share-box' ); ?> </div>
<?php } else {
echo get_featured_post_image("<div class='homefeatthumbsmall'>".$thepostlink, "</a></div>", $wx, $hx, "alignleft", $thumb, the_title_attribute('echo=0') ,the_title_attribute('echo=0'), false); ?>
<div class="homefeat-title-wrapper"><h2><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2><p><?php echo get_custom_the_excerpt(15); ?></p><?php get_template_part( 'lib/templates/share-box' ); ?> </div>
<?php } ?>
</div>
</li>
<?php ($oddpost == "alt-post") ? $oddpost="" : $oddpost="alt-post"; $postcount++; ?>
<?php endwhile; wp_reset_query(); ?>
</ul>
</div>
<?php } ?>

<?php do_action('mp_after_featcat_three'); ?>

<?php if($feat_cat_four != '' && $feat_cat_four != 'Choose a category') { ?>
<div class="homefeatbox">
<h3><a href="<?php echo get_category_link( $feat_cat_four ); ?>"><?php echo get_cat_name($feat_cat_four); ?></a></h3>
<ul>
<?php
$oddpost = 'alt-post';$postcount = 0;
$query = new WP_Query( "cat=".$feat_cat_four."&posts_per_page=". $num. "&orderby=date" );
while ( $query->have_posts() ) : $query->the_post();
$thepostlink = '<a href="'. get_permalink() . '" title="' . the_title_attribute('echo=0') . '">';
if($postcount > '0') {  $thumb = 'thumbnail'; $wx = '150'; $hx = '150';} else { $thumb = 'medium'; $wx = '320'; $hx = '240'; }
?>
<li class="post-<?php echo $postcount; ?> <?php echo $oddpost; ?>">
<div class="post-content">
<?php if($postcount == 0) {
echo get_featured_post_image("<div class='homefeatthumb'>".$thepostlink, "</a></div>", $wx, $hx, "alignleft", $thumb, the_title_attribute('echo=0') ,the_title_attribute('echo=0'), false); ?>
<div class="homefeat-title-wrapper"><h2><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2><p><?php echo get_custom_the_excerpt(40); ?></p><?php get_template_part( 'lib/templates/share-box' ); ?> </div>
<?php } else {
echo get_featured_post_image("<div class='homefeatthumbsmall'>".$thepostlink, "</a></div>", $wx, $hx, "alignleft", $thumb, the_title_attribute('echo=0') ,the_title_attribute('echo=0'), false); ?>
<div class="homefeat-title-wrapper"><h2><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2><p><?php echo get_custom_the_excerpt(15); ?></p><?php get_template_part( 'lib/templates/share-box' ); ?> </div>
<?php } ?>
</div>
</li>
<?php ($oddpost == "alt-post") ? $oddpost="" : $oddpost="alt-post"; $postcount++; ?>
<?php endwhile; wp_reset_query(); ?>
</ul>
</div>
<?php } ?>

<?php do_action('mp_after_featcat_four'); ?>

<?php if($feat_cat_five != '' && $feat_cat_five != 'Choose a category') { ?>
<div class="homefeatbox">
<h3><a href="<?php echo get_category_link( $feat_cat_five ); ?>"><?php echo get_cat_name($feat_cat_five); ?></a></h3>
<ul>
<?php
$oddpost = 'alt-post';$postcount = 0;
$query = new WP_Query( "cat=".$feat_cat_five."&posts_per_page=". $num. "&orderby=date" );
while ( $query->have_posts() ) : $query->the_post();
$thepostlink = '<a href="'. get_permalink() . '" title="' . the_title_attribute('echo=0') . '">';
if($postcount > '0') {  $thumb = 'thumbnail'; $wx = '150'; $hx = '150';} else { $thumb = 'medium'; $wx = '320'; $hx = '240'; }
?>
<li class="post-<?php echo $postcount; ?> <?php echo $oddpost; ?>">
<div class="post-content">
<?php if($postcount == 0) {
echo get_featured_post_image("<div class='homefeatthumb'>".$thepostlink, "</a></div>", $wx, $hx, "alignleft", $thumb, the_title_attribute('echo=0') ,the_title_attribute('echo=0'), false); ?>
<div class="homefeat-title-wrapper"><h2><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2><p><?php echo get_custom_the_excerpt(40); ?></p><?php get_template_part( 'lib/templates/share-box' ); ?> </div>
<?php } else {
echo get_featured_post_image("<div class='homefeatthumbsmall'>".$thepostlink, "</a></div>", $wx, $hx, "alignleft", $thumb, the_title_attribute('echo=0') ,the_title_attribute('echo=0'), false); ?>
<div class="homefeat-title-wrapper"><h2><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2><p><?php echo get_custom_the_excerpt(15); ?></p><?php get_template_part( 'lib/templates/share-box' ); ?> </div>
<?php } ?>
</div>
</li>
<?php ($oddpost == "alt-post") ? $oddpost="" : $oddpost="alt-post"; $postcount++; ?>
<?php endwhile; wp_reset_query(); ?>
</ul>
</div>
<?php } ?>

<?php do_action('mp_after_featcat_five'); ?>

</div>
<?php endif; ?>