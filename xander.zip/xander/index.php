<?php get_header(); ?>

<?php do_action( 'bp_before_content' ) ?>

<!-- CONTENT START -->
<div class="content">

<div class="content-inner">

<?php do_action( 'bp_before_blog_home' ) ?>

<!-- POST ENTRY START -->
<div id="post-entry">

<?php do_action( 'bp_before_blog_entry' ) ?>

<section class="post-entry-inner">

<?php
$postcount = 1;
$oddpost = '';


$feat_size = get_theme_option('feat_img_size');
if($feat_size == ''){ $feat_size = 'thumbnail'; }
$thumb_w = get_option($feat_size.'_size_w');
$thumb_h = get_option($feat_size.'_size_h');

if (have_posts()) : while ( have_posts() ) : the_post();
$thepostlink =  '<a href="'. get_permalink() . '" title="' . the_title_attribute('echo=0') . '">';
$cat_name = get_singular_cat_name();
$cat_id = get_cat_ID($cat_name);
?>
<?php do_action( 'bp_before_blog_post' ) ?>

<!-- POST START -->
<article <?php post_class($oddpost . ' post-feat-'. $feat_size . ' cat_' . $cat_id); ?> id="post-<?php the_ID(); ?>">

<?php get_template_part( 'lib/templates/post-meta' ); ?>

<h2 class="post-title entry-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>

<div class="post-content">

<?php echo get_featured_post_image("<div class='feat-". $feat_size . " post-thumb'>".$thepostlink, "</a></div>", $thumb_w, $thumb_h, "alignnone", $feat_size, mp_get_image_alt_text(),the_title_attribute('echo=0'), false); ?>

<div class="entry-content">
<?php
if (post_password_required()) {
the_content();
} else {
echo get_custom_the_excerpt(50);
}
?>
</div>

</div>

<?php get_template_part( 'lib/templates/share-box' ); ?>

</article>
<!-- POST END -->

<?php do_action( 'bp_after_blog_post' ); ?>

<?php ($oddpost == "alt-post") ? $oddpost="" : $oddpost="alt-post"; $postcount++; ?>

<?php endwhile; ?>

<?php endif; ?>

<?php get_template_part( 'lib/templates/paginate' ); ?>

</section>

<?php do_action( 'bp_after_blog_entry' ) ?>
</div>
<!-- POST ENTRY END -->

<?php do_action( 'bp_after_blog_home' ) ?>

</div><!-- CONTENT INNER END -->
</div><!-- CONTENT END -->

<?php do_action( 'bp_after_content' ) ?>

<?php get_sidebar(); ?>

<?php get_footer(); ?>