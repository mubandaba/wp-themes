<?php
$nc_option = get_option('nc_option');
$others_seo = $nc_option['others_seo'];

if ($others_seo['noindex_author_page']) {
    if (!function_exists('nc_no_index_author_page')):
        function nc_no_index_author_page() {
            if (is_author()) wp_no_robots();
        }
        add_action( 'wp_head', 'nc_no_index_author_page' );
    endif;
}

if ($others_seo['sitemap_xml']) {
    if (!function_exists('nc_create_sitemap')):
        add_action("publish_post", "nc_create_sitemap");
        add_action("publish_page", "nc_create_sitemap");
        add_action( "save_post", "nc_create_sitemap" );
        function nc_create_sitemap() {
            if ( str_replace( '-', '', get_option( 'gmt_offset' ) ) < 10 ) {
                $tempo = '-0' . str_replace( '-', '', get_option( 'gmt_offset' ) );
            } else {
                $tempo = get_option( 'gmt_offset' );
            }
            if( strlen( $tempo ) == 3 ) { $tempo = $tempo . ':00'; }
            $postsForSitemap = get_posts( array(
                'numberposts' => -1,
                'orderby'     => 'modified',
                'post_type'   => array('post'),
                'order'       => 'DESC',
            ) );
            $sitemap .= '<?xml version="1.0" encoding="UTF-8"?>';
            $sitemap .= "\n" . '<urlset xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd" xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
            $sitemap .= "\t" . '<url>' . "\n" .
                "\t\t" . '<loc>' . esc_url( home_url( '/' ) ) . '</loc>' .
                "\n\t\t" . '<lastmod>' . date( "Y-m-d\TH:i:s", current_time( 'timestamp', 0 ) ) . $tempo . '</lastmod>' .
                "\n\t\t" . '<changefreq>daily</changefreq>' .
                "\n\t\t" . '<priority>1.0</priority>' .
                "\n\t" . '</url>' . "\n";
            foreach( $postsForSitemap as $post ) {
                setup_postdata( $post);
                $postdate = explode( " ", $post->post_modified );
                $sitemap .= "\t" . '<url>' . "\n" .
                    "\t\t" . '<loc>' . get_permalink( $post->ID ) . '</loc>' .
                    "\n\t\t" . '<lastmod>' . $postdate[0] . 'T' . $postdate[1] . $tempo . '</lastmod>' .
                    "\n\t\t" . '<changefreq>Weekly</changefreq>' .
                    "\n\t\t" . '<priority>0.5</priority>' .
                    "\n\t" . '</url>' . "\n";
            }
            $sitemap .= '</urlset>';
            $fp = fopen( ABSPATH . "sitemap.xml", 'w' );
            fwrite( $fp, $sitemap );
            fclose( $fp );
        }
    endif;
}

if ($others_seo['auto_nofollow']) {
    if (!function_exists('nc_nofollow')):
        add_filter('the_content', 'nc_nofollow');
        add_filter('the_excerpt', 'nc_nofollow');
        
        function nc_nofollow($content) {
            return preg_replace_callback('/<a[^>]+/', 'nc_nofollow_callback', $content);
        }
        
        function nc_nofollow_callback($matches) {
            $link = $matches[0];
            $site_link = get_bloginfo('url');
        
            if (strpos($link, 'rel') === false) {
                $link = preg_replace("%(href=\S(?!$site_link))%i", 'rel="nofollow" $1', $link);
            } elseif (preg_match("%href=\S(?!$site_link)%i", $link)) {
                $link = preg_replace('/rel=\S(?!nofollow)\S*/i', 'rel="nofollow"', $link);
            }
            return $link;
        }
    endif;
}

if ($others_seo['auto_tag_link_switcher']) {
    if (!function_exists('nc_tag_link')):
        add_filter('the_content','nc_tag_link', 1);
        // 按长度排序
        function nc_tag_sort($a, $b){
            if ( $a->name == $b->name ) return 0;
            return ( strlen($a->name) > strlen($b->name) ) ? -1 : 1;
        }
        // 为符合条件的标签添加链接
        function nc_tag_link($content) {
            $link_section = $others_seo['auto_tag_link_section'];
            $match_num_from = $link_section['min'];  // 一个标签在文章中出现少于多少次不添加链接
            $match_num_to = $link_section['max']; // 一篇文章中同一个标签添加几次链接
            $posttags = get_the_tags();
            $ex_word = '';
            $case = '';
            if ($posttags) {
                usort($posttags, "nc_tag_sort");
                foreach($posttags as $tag) {
                    $link = get_tag_link($tag->term_id);
                    $keyword = $tag->name;
                    //链接的代码
                    $cleankeyword = stripslashes($keyword);
                    $url = "<a href=\"$link\" title=\"".str_replace('%s',addcslashes($cleankeyword, '$'),__('View all posts in %s'))."\"";
                    $url .= ' target="_blank"';
                    $url .= ">".addcslashes($cleankeyword, '$')."</a>";
                    $limit = rand($match_num_from,$match_num_to);
                    //不链接的代码
                    $content = preg_replace( '|(<a[^>]+>)(.*)('.$ex_word.')(.*)(</a[^>]*>)|U'.$case, '$1$2%&&&&&%$4$5', $content);
                    $content = preg_replace( '|(<img)(.*?)('.$ex_word.')(.*?)(>)|U'.$case, '$1$2%&&&&&%$4$5', $content);
                    $cleankeyword = preg_quote($cleankeyword,'\'');
                    $regEx = '\'(?!((<.*?)|(<a.*?)))('. $cleankeyword . ')(?!(([^<>]*?)>)|([^>]*?</a>))\'s' . $case;
                    $content = preg_replace($regEx,$url,$content,$limit);
                    $content = str_replace( '%&&&&&%', stripslashes($ex_word), $content);
                }
            }
            return $content;
        }
    endif;
}
if ($general_options['improve_robots_txt']) {
    if (!function_exists('nc_robots_txt')):
        add_filter('robots_txt', 'nc_robots_txt', 10, 2);

        function nc_robots_txt($robotext) {
            $robotext = "
    User-agent: *
    Disallow: /wp-admin/
    Disallow: /wp-content/plugins/
    Disallow: /wp-includes/
    Disallow: /*/trackback
    Disallow: /feed
    Disallow: /*/feed
    Disallow: /attachment/
    Disallow: /wp-content/themes/";
            return $robotext;
        }
    endif;
}

if (isset( $others_seo['baidu_submit'] ) && $others_seo['baidu_submit']) {
    add_action('post_updated', 'nc_baidu_submit');
    function nc_baidu_submit($post_ID){
        global $post;
        $bd_submit_site = get_bloginfo('url');
        $bd_submit_token = $others_seo['baidu_submit_key'];
        if( empty($post_ID) || empty($bd_submit_site) || empty($bd_submit_token) ) return;
        $api = 'http://data.zz.baidu.com/urls?site='.$bd_submit_site.'&token='.$bd_submit_token;
        $status = $post->post_status;
        if($status != '' && $status != 'publish'){
            $url = get_permalink($post_ID);
            $ch = curl_init();
            $options =  array(
                CURLOPT_URL => $api,
                CURLOPT_POST => true,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POSTFIELDS => $url,
                CURLOPT_HTTPHEADER => array('Content-Type: text/plain')
            );
            curl_setopt_array($ch, $options);
        }
    }
    add_action('wp_footer', 'nc_baidu_auto_code', 500);
    function nc_baidu_auto_code() {
        echo '<script>
                (function(){
                    var bp = document.createElement(\'script\');
                    var curProtocol = window.location.protocol.split(\':\')[0];
                    if (curProtocol === \'https\') {
                        bp.src = \'https://zz.bdstatic.com/linksubmit/push.js\';
                    }
                    else {
                        bp.src = \'http://push.zhanzhang.baidu.com/push.js\';
                    }
                    var s = document.getElementsByTagName("script")[0];
                    s.parentNode.insertBefore(bp, s);
                })();
            </script>';
    }
}