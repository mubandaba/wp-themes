
if (typeof jQuery != 'undefined') {
	var $ = jQuery.noConflict();
}

$(document).on('ready', function() {
	var ajax_url = nicetheme.ajax_url
	retrieve_database_items_count()

	function acf_site_tips(type, msg) {
		var c = type ? 'updated' : 'error';
		var html = '<div class="nicetheme-notice notice '+ c +'">'
					+ '<p>' + msg + '</p>'
					+ '</div>'
		$('.acf-settings-wrap h1').append(html);
	
		var tipsDOM = $('.nicetheme-notice');
	
		window.setTimeout(function(){
			tipsDOM.remove();
		}, 3000);
	}
	
	function acf_fire(data, successCallback = function() {}, failCallback = function() {}) {
		$.ajax({
			url: ajax_url,
			type: 'POST',
			dataType: 'html',
			data: data,
		})
		.done(function(data) {
			data = JSON.parse(data)
			if (data.s == 200) {
				acf_site_tips(1, data.m)
				successCallback()
			} else {
				acf_site_tips(0, data.m)
				failCallback()
			}
		})
		.fail(function() {
			acf_site_tips(0, '网络错误，请稍后再试！')
			failCallback()
		});
	}

	// 显示数据库优化内容
	function retrieve_database_items_count() {
		$.ajax({
			url: ajax_url,
			type: 'POST',
			dataType: 'html',
			data: { action: 'nc_database_clean_up_count' },
		})
		.done(function(data) {
			counts = JSON.parse(data).counts
			var cleanupForm = $('.acf-database-cleanup-form')
			var cleanupFormKeys = Object.keys(counts)
			cleanupFormKeys.forEach(function (item) {
				cleanupForm.find('.' + item).text(counts[item])
				counts[item] == 0 && cleanupForm.find('input[data-action_type="' + item + '"]').prop('disabled', 'disabled')
			})
		})
		.fail(function() {
			acf_site_tips(0, '网络错误，请刷新页面重试！')
		});
	}

	$(document).on('click', 'input[data-action=nc_test_email]', function(event) {
		event.preventDefault();
		var data = $(this).data();
		acf_fire(data)
	});

	$(document).on('click', 'input[data-action=nc_database_optimize]', function(event) {
		event.preventDefault();
		var data = $(this).data();
		acf_fire(data)
	});

	$(document).on('click', 'input[data-action_type]', function(event) {
		event.preventDefault();
		var data = $(this).data();
		acf_fire(data, function() {
			retrieve_database_items_count()
		}, function() {
			retrieve_database_items_count()
		})
	});
})

