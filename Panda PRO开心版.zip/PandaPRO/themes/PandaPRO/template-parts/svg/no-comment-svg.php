<svg id="Artwork" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="100%" height="auto" viewBox="0 0 269.93 210">
  <defs>
    <clipPath id="clip-path">
      <path id="Clip_6" data-name="Clip 6" d="M226.521,0V89.668H0V0Z" transform="translate(0.408 0.332)" fill="none"/>
    </clipPath>
    <linearGradient id="linear-gradient" x1="1" x2="0" y2="1" gradientUnits="objectBoundingBox">
      <stop offset="0" stop-color="#2c63ff"/>
      <stop offset="1" stop-color="#2c63ff"/>
    </linearGradient>
  </defs>
  <path id="Fill_1" data-name="Fill 1" d="M121.135,0A104.2,104.2,0,0,0,55.852,22.872H26.9a6.861,6.861,0,0,0,0,13.723H45.952A6.855,6.855,0,0,1,50.78,48.3a6.8,6.8,0,0,1-4.828,2.017H6.839a6.861,6.861,0,0,0,0,13.723H24.6a105.19,105.19,0,0,0-8.333,41.169,106.7,106.7,0,0,0,1.144,15.6q.472,3.191,1.135,6.322c12.9-1.981,26.59-3.573,40.879-4.734l1.076.983,1.012-1.148c17.166-1.34,35.184-2.054,53.768-2.054,39.484,0,76.433,3.22,108.024,8.819a105.487,105.487,0,0,0,2.426-16.317q.267-3.705.264-7.474C226,47.1,179.053,0,121.135,0" transform="translate(25)" fill="#f1f2f7"/>
  <path id="Fill_3" data-name="Fill 3" d="M11.072,0H6.928a7,7,0,0,0,0,14h4.145a7,7,0,0,0,0-14" transform="translate(0 50)" fill="#f1f2f7"/>
  <g id="Group_7" data-name="Group 7" transform="translate(43 120)">
    <path id="Clip_6-2" data-name="Clip 6" d="M226.521,0V89.668H0V0Z" transform="translate(0.408 0.332)" fill="none"/>
    <g id="Group_7-2" data-name="Group 7" clip-path="url(#clip-path)">
      <path id="Fill_5" data-name="Fill 5" d="M226.521,34.668a6.848,6.848,0,0,1-6.837,6.818H176.011a6.818,6.818,0,1,0,0,13.636h8.114a6.818,6.818,0,1,1,0,13.636H165.468A104.577,104.577,0,0,1,102.56,89.668,104.808,104.808,0,0,1,0,6.909c12.9-1.968,26.584-3.55,40.869-4.7l1.075.977,1.012-1.141C60.118.709,78.133,0,96.712,0c39.474,0,76.414,3.2,108,8.764a103.321,103.321,0,0,1-6.44,19.086h21.415a6.854,6.854,0,0,1,6.837,6.818" transform="translate(0.408 0.332)" fill="#e8ebf2"/>
    </g>
  </g>
  <path id="Fill_8" data-name="Fill 8" d="M164,4.372A109.544,109.544,0,0,1,161.578,21c-31.55-5.706-68.449-8.987-107.881-8.987-18.559,0-36.554.727-53.7,2.093L11.889.331,30.383,12.4,55.418,5.487l43.068,6.526,18.7-6.526,4.735,6.526,11.3-8.386L143.774,13.3,160.426,0Z" transform="translate(86 108)" fill="#e0e2ee"/>
  <path id="Fill_10" data-name="Fill 10" d="M88.62,67.4A41.183,41.183,0,0,0,96,43.616C95.805,19.316,74.158-.21,47.649,0S-.193,20.085,0,44.384,21.843,88.21,48.351,88a50.986,50.986,0,0,0,25.685-7.063L93.842,85.6Z" transform="translate(100 51)" fill="#d8dbea"/>
  <path id="Fill_12" data-name="Fill 12" d="M10,4.96A5,5,0,1,1,4.96,0,5,5,0,0,1,10,4.96" transform="translate(124 89)" fill="#bec0d6"/>
  <path id="Fill_14" data-name="Fill 14" d="M10,4.96A5,5,0,1,1,4.96,0,5,5,0,0,1,10,4.96" transform="translate(142 89)" fill="#bec0d6"/>
  <path id="Fill_16" data-name="Fill 16" d="M10,4.96A5,5,0,1,1,4.96,0,5,5,0,0,1,10,4.96" transform="translate(160 89)" fill="#bec0d6"/>
  <path id="Fill_18" data-name="Fill 18" d="M2,0,1.03,1,0,.143C.663.092,1.332.044,2,0" transform="translate(84 122)" fill="#f1f2f7"/>
  <path id="Fill_20" data-name="Fill 20" d="M0,16a14.941,14.941,0,0,0,2.761,8.62L.909,31.26l7.212-1.755A18.624,18.624,0,0,0,17.5,32C27.165,32,35,24.837,35,16S27.165,0,17.5,0,0,7.163,0,16Z" transform="translate(95 113)" fill="url(#linear-gradient)"/>
  <path id="Fill_22" data-name="Fill 22" d="M0,2A2,2,0,1,0,2,0,2,2,0,0,0,0,2" transform="translate(117 127)" fill="#fff"/>
  <path id="Fill_24" data-name="Fill 24" d="M0,2A2,2,0,1,0,2,0,2,2,0,0,0,0,2" transform="translate(111 127)" fill="#fff"/>
  <path id="Fill_26" data-name="Fill 26" d="M0,2A2,2,0,1,0,2,0,2,2,0,0,0,0,2" transform="translate(104 127)" fill="#fff"/>
  <path id="Fill_28" data-name="Fill 28" d="M42,18.258C27.716,19.422,14.033,21.016,1.135,23Q.472,19.866,0,16.668L22.109,0Z" transform="translate(42 104)" fill="#e0e2ee"/>
  <path id="Fill_30" data-name="Fill 30" d="M78,3.5C78,5.433,60.539,7,39,7S0,5.433,0,3.5,17.461,0,39,0,78,1.568,78,3.5" transform="translate(106 153)" fill="#d8dbea"/>
  <path id="Fill_32" data-name="Fill 32" d="M7,14H7a7,7,0,1,1,7-7,7.021,7.021,0,0,1-7,7" transform="translate(241 175)" fill="#e1e3ef"/>
</svg>
