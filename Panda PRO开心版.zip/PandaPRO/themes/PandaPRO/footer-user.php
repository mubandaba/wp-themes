<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @package Panda PRO
 */

?>
<div class="mobile-overlay"></div>
<?php wp_footer(); ?>
</body>
</html>