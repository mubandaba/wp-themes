<?php
/*
Template Name: 友情链接
*/
?>
<?php get_header();?>
<div id="content" class="site-content">	
<div class="clear"></div>
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
<?php while ( have_posts() ) : the_post(); ?>
			
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<header class="entry-header">
		<h1 class="entry-title"><?php the_title(); ?></h1>	
		<div class="single_info">
					<span class="date"><?php the_time( 'Y-m-d H:i' ) ?></span>
					<span class="views"><?php if( function_exists( 'the_views' ) ) { the_views(); print '人阅读 '; } ?></span>			
					<span class="edit"><?php edit_post_link('编辑', '  ', '  '); ?></span>
				</div>			
	</header><!-- .entry-header -->

	<div class="entry-content">
					<div class="single-content">									
	<?php the_content(); ?>
	<h2>友情链接</h2>
	<article class="link-page">
<ul id="linkdh">
	<li class="linkcat">		
	<ul class="xoxo blogroll">
	<div class="clear"></div>
		<?php 
		$dh_id = get_option('ygj_link_id'); 
$bookmarks = get_bookmarks('title_li=&categorize=0&orderby=link_id&order=DESC&category='.$dh_id.''); 
        if ( !empty($bookmarks) ) {
            foreach ($bookmarks as $bookmark) {?>
            <span class="cx7"><span class="link-all"><a href="<?php echo $bookmark->link_url?>" title="<?php echo $bookmark->link_description;?>" target="_blank" rel="nofollow" ><?php echo $bookmark->link_name;?></a></span></span>
			<?php 
            }
        }
        ?>			
</ul>
	</li>
</ul>
</article>	
<h2>页内链接</h2>
	<article class="link-page">
<ul id="linkdh">
	<li class="linkcat">		
	<ul class="xoxo blogroll">
	<div class="clear"></div>
		<?php 
		$dh_id = get_post_meta($post->ID, 'dhid', true); 
$bookmarks = get_bookmarks('title_li=&categorize=0&orderby=link_id&order=DESC&exclude_category='.$dh_id.''); 
        if ( !empty($bookmarks) ) {
            foreach ($bookmarks as $bookmark) {?>
            <span class="cx7"><span class="link-all"><a href="<?php echo $bookmark->link_url?>" title="<?php echo $bookmark->link_description;?>" target="_blank" rel="nofollow" ><?php echo $bookmark->link_name;?></a></span></span>
			<?php 
            }
        }
        ?>			
</ul>
	</li>
</ul>
</article>
			</div>
<div class="clear"></div>
<?php get_template_part( 'inc/social' ); ?>
			
<?php include('inc/file.php'); ?>
				<div class="clear"></div>
	</div><!-- .entry-content -->

	</article><!-- #post -->															
		<?php if (get_option('ygj_g_full') == '关闭') { ?>
	<?php } else { ?>
		<?php get_template_part( 'inc/ad/ad_full' ); ?>
	<?php } ?>	
	<?php comments_template( '', true ); ?>			
			<?php endwhile; ?>
		</main><!-- .site-main -->
	</div><!-- .content-area -->
<div class="clear"></div>
</div><!-- .site-content -->
<?php get_footer();?>