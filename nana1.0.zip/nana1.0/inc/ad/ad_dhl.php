	<div id="ad-dhl" class="ad-pc ad-site">
		<?php echo stripslashes(get_option('ygj_addd_c')); ?>
	</div>	