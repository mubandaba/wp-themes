<?php
/**
 * The Header template for our theme
 *
 * Displays all of the <head> section and everything up till <div id="main">
 *
 */
?><!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) | !(IE 8)  ]><!-->
<?php
 	$agent = $_SERVER["HTTP_USER_AGENT"];
	if(strpos($agent,"MSIE 8.0"))
	$classes =  "IE8";
	else if(strpos($agent,"MSIE 7.0"))
	$classes =  "IE7";
	else if(strpos($agent,"MSIE 6.0"))
	$classes =  "IE6";
	else if(strpos($agent,"Firefox/3"))
	$classes =  "firefox_3";
	else if(strpos($agent,"Firefox/2"))
	$classes =  "firefox_2";
	else if(strpos($agent,"Chrome"))
	$classes =  "chrome";
	else if(strpos($agent,"Safari"))
	$classes =  "safari";
	else if(strpos($agent,"Opera"))
	$classes = "opera";
?>
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">

<!--  Mobile viewport scale | Disable user zooming as the layout is optimised -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<title><?php wp_title( '|', true, 'right' ); ?></title>
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<link href="<?php bloginfo('url');?>/favicon.ico" rel="icon" type="image/x-icon">  
<link href="<?php bloginfo('url');?>/favicon.ico" rel="shortcut icon" type="image/x-icon">  
<meta name="keywords" content="<?php echo get_option('mytheme_keywords'); ?>" /> 
<meta name="description" content="<?php echo get_option('mytheme_description'); ?>" />
<!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame -->
<!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" /><![endif]-->

<?php wp_head(); ?>
<script type='text/javascript'>
	var $ = jQuery.noConflict();
</script>
<!--[if lt IE 9]>
<script src="<?php echo get_template_directory_uri(); ?>/js/html5.js"></script>
<![endif]-->

</head>

<body <?php body_class($classes); ?>>
	<div id="page" class="hfeed site wrapper">
		<div class="inner-wrapper" id="inner-wrapper">

			<header id="header" class="site-header" role="banner">
				<div class="header-wrapper col-full">
					<span class="nav-toggle col-left"><a href="#navigation"><span></span></a></span>
					<div class="logo col-left">
						<a class="home-link" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home">
							<img id="logo" src="<?php bloginfo('template_url');?>/images/logo.png" alt=""/>
						</a>
					</div>
				</div>
				<div class="nav-wrapper col-full">	
                   	<div  id="nav">
					<nav id="navigation" role="navigation">
						<section class="menus">
						<a href="<?php echo $base_url ;?>" class="nav-home"><span>Home</span></a>
						<h3>Primary Menu</h3>
						<?php wp_nav_menu( array( 'depth' => 6, 'sort_column' => 'menu_order', 'container' => 'ul', 'menu_id' => 'main-nav', 'menu_class' => 'nav', 'theme_location' => 'primary' ) );?>
						</section>
						<a href="#top" class="nav-close"><span>Return to Content</span></a>
						<div class="clear"></div>
					</nav><!-- #site-navigation -->
					</div><!-- #navbar -->
					
					<div class="connect">
						<ul class="social-media">
						<li><a class="login" href="<?php echo get_option('mytheme_sign_in'); ?>" target="_blank"></a></li>
						<li><a class="qq" href="<?php echo get_option('mytheme_qq'); ?>" target="_blank"></a></li>
						<li><a class="xinlang" href="<?php echo get_option('mytheme_xinlang_weibo'); ?>" target="_blank"></a></li>
						<li><a class="tengxun" href="<?php echo get_option('mytheme_qq_weibo'); ?>" target="_blank"></a></li>
				             </ul>
					  </div><!-- .connect -->
				<div class="clear"></div>
				<?php wp_reset_query();?>
				</div>
			</header><!-- #masthead -->

			<div class="clear"></div>
			<div id="main" class="site-main">