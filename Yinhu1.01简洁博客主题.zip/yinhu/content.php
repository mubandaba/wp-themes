<?php
/**
 * The default template for displaying content
 *
 * Used for both single and index/archive/search.
 */
?>
<?php if ( is_single() ) : ?>
<div class="breadcrumbs">
<?php if(function_exists('bcn_display'))
{
    bcn_display();
}?>
</div>
<?php endif; // is_single() ?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<header class="entry-header">
		<?php if ( is_single() ) : ?>
		<h3 class="entry-title"><?php the_title(); ?></h3>
		<?php	$categories = get_the_category();
		$separator = ' ';
		$output = '';
		if($categories){
			foreach($categories as $category) {
				$output .= '<a class="detail-back-btn"  href="'.get_category_link( $category->term_id ).'" title="' . esc_attr( sprintf( __( "返回 %s 分类" ), $category->name ) ) . '"></a>'.$separator;
			}
			echo trim($output, $separator);
		}?>
		<?php else : ?>
		<h3 class="entry-title">
			<a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a>
		</h3>
		<a class="art-detail-btn" href="<?php the_permalink(); ?>" rel="bookmark" target="_blank" title="点击查看详情"></a>
		<?php endif; // is_single() ?>


	</header><!-- .entry-header -->

	<?php if ( is_single()) : // Only display Excerpts for Search ?>
	<div class="entry-content">
		<?php the_content(); ?>
		<!-- Baidu Button BEGIN -->
		<div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare">
		<a class="bds_tsina"></a>
		<a class="bds_qzone"></a>
		<a class="bds_tqq"></a>
		<a class="bds_renren"></a>
		<span class="bds_more"></span>
		<a class="shareCount"></a>
		</div>
		<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=6666081" ></script>
		<script type="text/javascript" id="bdshell_js"></script>
		<script type="text/javascript">
		document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000)
		</script>
		<!-- Baidu Button END -->
		<?php wp_link_pages( array( 'before' => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'twentythirteen' ) . '</span>', 'after' => '</div>', 'link_before' => '<span>', 'link_after' => '</span>' ) ); ?>
	</div><!-- .entry-content -->

	<?php else : ?>
	
	<div class="entry-summary">
		<span class="art-main">
			<?php if ( has_post_thumbnail() && ! post_password_required() ) : ?>
			<div class="entry-thumbnail">
				<?php the_post_thumbnail(); ?>
			</div>
			<?php endif; ?>
			<?php $excerpt = strip_tags(get_the_excerpt());
    			    echo $excerpt; ?>
		</span>
	</div><!-- .entry-summary -->
	<?php endif; ?>
	<footer class="entry-meta">
		<div class="entry-meta">
			<?php 	if ( 'post' == get_post_type() ) {
					printf( '<span class="author vcard"><a class="url fn n" href="%1$s" title="%2$s" rel="author">%3$s</a></span>',
						esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
						esc_attr( sprintf( __( 'View all posts by %s', 'twentythirteen' ), get_the_author() ) ),
						get_the_author()
					);
				}
				// Translators: used between list items, there is a space after the comma.
				$categories_list = get_the_category_list( __( ', ', 'twentythirteen' ) );
				if ( $categories_list ) {
					echo '<span class="categories-links">' . $categories_list . '</span>';
				}

				// Translators: used between list items, there is a space after the comma.
				$tag_list = get_the_tag_list( '', __( ', ', 'twentythirteen' ) );
				if ( $tag_list ) {
					echo '<span class="tags-links">' . $tag_list . '</span>';
				}
			?>
			<span  class="date"><?php echo human_time_diff( get_the_time('U'), current_time('timestamp') ) . ' 前'; ?></span>
			<?php edit_post_link( __( 'Edit', 'twentythirteen' ), '<span class="edit-link">', '</span>' ); ?>
		</div><!-- .entry-meta -->

		<?php if ( comments_open() && ! is_single() ) : ?>
			<div class="comments-link">
				<?php comments_popup_link( '<span class="leave-reply">' . __( '0', 'twentythirteen' ) . '</span>', __( '1', 'twentythirteen' ), __( '%', 'twentythirteen' ) ); ?>
			</div><!-- .comments-link -->
		<?php endif; // comments_open() ?>
		<div class="clear"></div>

	</footer><!-- .entry-meta -->
</article><!-- #post -->
