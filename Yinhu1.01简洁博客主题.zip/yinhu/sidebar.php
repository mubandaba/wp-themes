<?php
/**
 * The sidebar containing the secondary widget area
 *
 * Displays on posts and pages.
 *
 * If no active widgets are in this sidebar, hide it completely.
 *
 */ 
 ?>

<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>

	<div id="tertiary" class="sidebar-container" role="complementary">
		<div class="sidebar-inner">
			<div class="widget-area">
				<!--调用公告板-->
				<?php if(get_option('mytheme_announcement')!="") :?>
				<aside id="announcement" class="widget widget_announcement">
						<h3 class="widget-title">公告</h3>	
						<div class="announcement-content">
							<p><?php echo get_option('mytheme_announcement'); ?></p>
						</div>
				</aside>
				<?php endif;?>
		
				<?php dynamic_sidebar( 'sidebar-1' ); ?>
			</div><!-- .widget-area -->
		</div><!-- .sidebar-inner -->
	</div><!-- #tertiary -->

<?php endif; ?>