<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$includes = array(
				'includes/theme-options.php', 		// Options panel settings and custom settings
				'includes/theme-script-style.php', 	// Custom theme javascript and style
				'includes/theme-functions.php', 		// Custom theme functions
				'includes/posttype-init.php', 			// Initialize custom posttype
				'includes/sidebar-init.php', 			// Initialize widgetized areas
				'includes/theme-widgets.php'			// Theme widgets
				);

foreach ( $includes as $i ) {
	locate_template( $i, true );
}
