<?php
/**
 * The default template for displaying content
 *
 * Used for both single and index/archive/search.
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<h3 class="entry-title">
			<a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a>
		</h3>
		<a class="art-detail-btn" href="<?php the_permalink(); ?>" rel="bookmark" target="_blank"  title="新窗口查看详情"></a>
	</header><!-- .entry-header -->

	<div class="entry-summary">

		<span class="art-main">
		<?php if ( has_post_thumbnail() && ! post_password_required() ) : ?>
		<div class="entry-thumbnail">
			<?php the_post_thumbnail(); ?>
		</div>
		<?php endif; ?>
		
	<?php $excerpt = strip_tags(get_the_excerpt());
    			    echo $excerpt; ?>
		
		</span>
		
	</div><!-- .entry-summary -->
	<div class="clear"></div>
	<footer class="entry-meta">
		<div class="entry-meta">
			<?php 	if ( 'post' == get_post_type() ) {
				printf( '<span class="author vcard"><a class="url fn n" href="%1$s" title="%2$s" rel="author">%3$s</a></span>',
					esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
					esc_attr( sprintf( __( 'View all posts by %s', 'twentythirteen' ), get_the_author() ) ),
					get_the_author()
				);
			}?>
			<span  class="date"><?php echo human_time_diff( get_the_time('U'), current_time('timestamp') ) . ' 前'; ?></span>
			<?php edit_post_link( __( 'Edit', 'twentythirteen' ), '<span class="edit-link">', '</span>' ); ?>
		</div><!-- .entry-meta -->

		<?php if ( comments_open() && ! is_single() ) : ?>
			<div class="comments-link">
				<?php comments_popup_link( '<span class="leave-reply">' . __( '0', 'twentythirteen' ) . '</span>', __( '1', 'twentythirteen' ), __( '%', 'twentythirteen' ) ); ?>
			</div><!-- .comments-link -->
		<?php endif; // comments_open() ?>
		<div class="clear"></div>

	</footer><!-- .entry-meta -->
</article><!-- #post -->
