<?php
/**
 * The template for displaying the footer
 *
 * Contains footer content and the closing of the #main and #page div elements.
 *
 */
?>

		</div><!-- #main -->
		<div class="clear"></div>

		<?php if(!is_home()){?>
		<footer id="colophon" class="site-footer" role="contentinfo">
			<div class="footer-inner-wrapper  col-full  full-width">
				<?php get_sidebar( 'footer' ); ?>
	   		    <div id="footer-nav">
					<nav id="footer-navigation" class="navigation footer-navigation col-full" role="navigation">
						<?php wp_nav_menu( array( 'theme_location' => 'footer', 'menu_class' => 'footer-menu' , 'depth' => 1,) ); ?>
					</nav><!-- #site-navigation -->
					
				<div class="clear"></div>
				</div><!-- #navbar -->
					
					<div class="connect">
						<ul class="social-media">
						<li><a class="login" href="<?php echo get_option('mytheme_sign_in'); ?>" target="_blank"></a></li>
						<li><a class="qq" href="<?php echo get_option('mytheme_qq'); ?>" target="_blank"></a></li>
						<li><a class="xinlang" href="<?php echo get_option('mytheme_xinlang_weibo'); ?>" target="_blank"></a></li>
						<li><a class="tengxun" href="<?php echo get_option('mytheme_qq_weibo'); ?>" target="_blank"></a></li>
				             </ul>
					  </div><!-- .connect -->
						
			
			</div><!-- .footer-inner-wrapper -->
	
            <div class="clear"></div>
		</footer><!-- #colophon -->
		<?php }?>
			<?php wp_reset_query();if ( is_home()){ ?>
		<div id="footer-links" class="links">
			<div class="col-full full-width">
				
				    	<div class="flink">
						<strong>友情链接:</strong>
				             <?php partner_links("txt",24) ?>
						<a target="_blank" title="点击此处申请链接" href="<?php bloginfo('url');?>/links" class="curflink">申请链接</a>
				      </div>
				
			</div>
		</div>
		<?php } ?>
		<div class="clear"></div>
		<div class="site-info ">
			<div class=" full-width col-full">
			<span class="col-left" >&copy; <a href="<?php bloginfo('url');?>"><?php bloginfo('name');?></a>. 2014. All rights reserved.</span>
			<span>
				<!--调用统计代码-->
				<?php if (get_option('mytheme_analytics')!="") {?> 
				<div id="analytics"><?php echo stripslashes(get_option('mytheme_analytics')); ?></div> 
				<?php }?>
			</span>
			<img class="col-right" src="<?php bloginfo('template_url');?>/images/footer_logo.png" alt="footer-logo"/></div>
			<div class="clear"></div>
			</div><!-- .site-info -->
		</div><!-- .inner-wrapper -->
	</div><!-- #page -->
	<?php wp_footer(); ?>
</body>
</html>