<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/*-----------------------------------------------------------------------------------*/
/* Post Type: Featured Slider  */
/*-----------------------------------------------------------------------------------*/

if ( ! function_exists( 'yinhu_featured_slider_post_type' ) ) {
function yinhu_featured_slider_post_type () {
	$labels = array(
		'name' => _x( '幻灯片', 'post type general name', 'yinhuthemes' ),
		'singular_name' => _x( '幻灯片', 'post type singular name', 'yinhuthemes' ),
		'add_new' => _x( 'Add New', 'slide', 'yinhuthemes' ),
		'add_new_item' => 'Add New Slide',
		'edit_item' => 'Edit Slide',
		'new_item' => 'New Slide',
		'view_item' => 'View Slide',
		'search_items' => 'Search Slides',
		'not_found' =>  'No slides found',
		'not_found_in_trash' => 'No slides found in Trash',
		'parent_item_colon' => 'Parent slide:'
	);
	$args = array(
		'labels' => $labels,
		'public' => false,
		'publicly_queryable' => false,
		'show_ui' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_icon' => esc_url( get_template_directory_uri() . '/images/icon/slides.png' ),
		'menu_position' => 5,
		'supports' => array('title','editor','thumbnail','page-attributes' , /*'author','thumbnail','excerpt','comments'*/)
	);

	register_post_type( 'slide', $args );
} // End yinhu_featured_slider_post_type()
}
add_action( 'init', 'yinhu_featured_slider_post_type' );

if ( ! function_exists( 'yinhu_features_post_type' ) ) {
function yinhu_features_post_type () {
	$labels = array(
		'name' => _x( '专区', 'post type general name', 'yinhuthemes' ),
		'singular_name' => _x( '专区', 'post type singular name', 'yinhuthemes' ),
		'add_new' => _x( 'Add New', 'feature', 'yinhuthemes' ),
		'add_new_item' => 'Add New Feature',
		'edit_item' => 'Edit Feature',
		'new_item' => 'New Feature',
		'view_item' => 'View Feature',
		'search_items' => 'Search Features',
		'not_found' =>  'No features found',
		'not_found_in_trash' => 'No features found in Trash',
		'parent_item_colon' => 'Parent feature:'
	);
	$args = array(
		'labels' => $labels,
		'public' => false,
		'publicly_queryable' => false,
		'show_ui' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_icon' => esc_url( get_template_directory_uri() . '/images/icon/features-icon.png' ),
		'menu_position' => 6,
		'supports' => array('title','editor','thumbnail','excerpt','page-attributes' ,/*'author','thumbnail','excerpt','comments'*/)
	);

	register_post_type( 'feature', $args );
} // End yinhu_features_post_type()
}
add_action( 'init', 'yinhu_features_post_type' );

