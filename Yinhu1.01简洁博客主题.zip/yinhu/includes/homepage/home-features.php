<section class="home-columns features_wrapper">
	<div class="features">
			<div class="full-width">
				<div class="features_columns" >
				<?php
				 $args =  array(
				 'post_type' => 'feature',
				 'orderby' => 'menu_order',
				 'order' => 'ASC',
				);
				query_posts( $args );
				if ( have_posts() ) { $count = 0;
					while ( have_posts() ) { the_post(); $count++;
						$css_class = 'feature-number-' . esc_attr( $count );
							$url='#';
					?>
						<article class="feature-box <?php echo $css_class?>">
							<div class="feature-thumbnail">
								<?php if ( function_exists("has_post_thumbnail") && has_post_thumbnail() ) { ?>
									<div class="single-post-thumb">
										<a href="<?php echo $url ?>" ><?php the_post_thumbnail(); ?></a>
									</div>
								<?php } ?>
							</div>
							<header class="<?php echo $post->post_name;?>">
								<h1 class="feature-title"><a href="<?php echo $url ?>" ><?php the_title();?></a></h1>
							</header>
							<div class="feature-content">
								<?php the_excerpt();?>
							</div>
							<div class="clear"></div>
						</article>
					<?php } ?>
				<?php } ?>
				
			<div class="clear"></div>
			</div><!--/.col-full -->
		</div><!-- /.section-wrapper-->
	</div><!-- /.features-->
</section><!-- /.home-columns-->