<section class="home-slider  col-full">
<link rel="stylesheet" href="<?php bloginfo('template_url');?>/css/flexslider.css" type="text/css" media="screen" />
<div id="featured-slider" class="flexslider carousel">
	<?php
	 $args =  array(
	 'post_type' => 'slide',
	'orderby' =>'menu_order',
	'order'=>'ASC',
	);?>
	<ul class="slides">
	<?php
	query_posts( $args );

	if ( have_posts() ) : $count = 0;
	while ( have_posts() ) { the_post(); $count++;
		$css_class = 'slide-number-' . esc_attr( $count );
		$image_bg = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
		$style = '';
		if ( '' != $image_bg ) {
			$style = ' style="background-size: cover; background-image: url(' . $image_bg . ');"';
		}
?>
		<li class="slide <?php echo esc_attr( $css_class ); ?>"<?php echo $style; ?>>
			<div class="slide-content">
					<div class="entry"><div class="slider-img"><?php the_content(); ?></div></div><!--/.entry-->
			</div><!--/.slide-content-->
		</li>
	<?php }
	endif;?>

	</ul>
</div><!--/#featured-slider-->
<?php wp_reset_query(); ?>

<script src="<?php bloginfo('template_url');?>/js/jquery.flexslider-min.js"></script>
<script type="text/javascript">

    (function() {

      // store the slider in a local variable
      var $window = $(window),
          flexslider;
      // tiny helper function to add breakpoints
      function getGridSize() {
        return (window.innerWidth < 600) ? 2 :
               (window.innerWidth < 1000) ? 2 : 3;
      }

      $window.load(function() {
        $('.flexslider').flexslider({
          animation: "slide",
          animationSpeed: 400,
          animationLoop: true,
          itemWidth: 246,
          itemMargin: 45,
          prevText: "",
      	  nextText: "",
      	  move: 1,
      	  minItems: 1,
   		  maxItems: 2,      
          minItems: getGridSize(), // use function to pull in initial value
          maxItems: getGridSize(), // use function to pull in initial value
          start: function(slider){
            $('body').removeClass('loading');
            flexslider = slider;
          }
        });
      });

      // check grid size on resize event
    }());
</script>
</section>