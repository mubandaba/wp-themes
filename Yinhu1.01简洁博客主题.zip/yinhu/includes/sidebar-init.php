<?php
if ( ! defined( 'ABSPATH' ) ) exit;


/**
 * Register widget areas.
 *
 */
function yinhu_widgets_init() {
	register_sidebar( array(
		'name'          =>  'Main Widget Area',
		'id'            => 'sidebar-1',
		'description'   => 'Appears on posts and pages in the sidebar.',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => 'Footer Widget Area',
		'id'            => 'sidebar-2',
		'description'   => 'Appears in the footer section of the site.',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
}
add_action( 'widgets_init', 'yinhu_widgets_init' );