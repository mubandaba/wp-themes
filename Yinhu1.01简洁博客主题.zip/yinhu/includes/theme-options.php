<?php
function mytheme_page (){
 
    if ( count($_POST) > 0 && isset($_POST['mytheme_settings']) ){
 
        $options = array ('keywords','description','analytics','announcement','sign_in','qq','xinlang_weibo','qq_weibo');
 
        foreach ( $options as $opt ){
 
            delete_option ( 'mytheme_'.$opt, $_POST[$opt] );
 
            add_option ( 'mytheme_'.$opt, $_POST[$opt] );    
 
        }
 
    }
 
    add_theme_page(__('主题选项'), __('主题选项'), 'edit_themes', basename(__FILE__), 'mytheme_settings');
 
}
 
function mytheme_settings(){?>
 
<style>
 
    .wrap,textarea,em{font-family:'Century Gothic','Microsoft YaHei',Verdana;}
    .wrap{margin: 10px 15px 0 20px;max-width: 600px;}
 
    fieldset{width:100%;border:1px solid #aaa;padding-bottom:20px;margin-top:20px;-webkit-box-shadow:rgba(0,0,0,.2) 0px 0px 5px;-moz-box-shadow:rgba(0,0,0,.2) 0px 0px 5px;box-shadow:rgba(0,0,0,.2) 0px 0px 5px;}
 
    legend{margin-left:5px;padding:0 5px;color:#2481C6;background:#F9F9F9;cursor:pointer;}
 
    textarea{width:100%;font-size:11px;border:1px solid #aaa;background:none;-webkit-box-shadow:rgba(0,0,0,.2) 1px 1px 2px inset;-moz-box-shadow:rgba(0,0,0,.2) 1px 1px 2px inset;box-shadow:rgba(0,0,0,.2) 1px 1px 2px inset;-webkit-transition:all .4s ease-out;-moz-transition:all .4s ease-out;}
 
    textarea:focus{-webkit-box-shadow:rgba(0,0,0,.2) 0px 0px 8px;-moz-box-shadow:rgba(0,0,0,.2) 0px 0px 8px;box-shadow:rgba(0,0,0,.2) 0px 0px 8px;outline:none;}
 
</style>
 
<div class="wrap">
 
<h2>主题选项</h2>
 
<form method="post" action="">
 
    <fieldset>
 
    <legend><strong>SEO 代码添加</strong></legend>
 
        <table class="form-table">
 
            <tr><td>
 
                <textarea name="keywords" id="keywords" rows="1" cols="70"><?php echo get_option('mytheme_keywords'); ?></textarea><br />
 
                <em>网站关键词（Meta Keywords），中间用半角逗号隔开。</em>
 
            </td></tr>
 
            <tr><td>
 
                <textarea name="description" id="description" rows="3" cols="70"><?php echo get_option('mytheme_description'); ?></textarea>
 
                <em>网站描述（Meta Description），针对搜索引擎设置的网页描述。</em>
 
            </td></tr>
 
        </table>
 
    </fieldset>
 
 
 
    <fieldset>
 
    <legend><strong>统计代码添加</strong></legend>
 
        <table class="form-table">
 
            <tr><td>
 
                <textarea name="analytics" id="analytics" rows="2" cols="70"><?php echo stripslashes(get_option('mytheme_analytics')); ?></textarea>
 
            </td></tr>
 
        </table>
 
    </fieldset>
 
     <fieldset>
 
    <legend><strong>公告板设置</strong></legend>
 
        <table class="form-table">
 
            <tr><td>
 
                <textarea name="announcement" id="announcement" rows="5" cols="70"><?php echo get_option('mytheme_announcement'); ?></textarea>
 
            </td></tr>
 
        </table>
 
    </fieldset>
 
     <fieldset>
    <legend><strong>导航右侧社会化联系设置</strong></legend>
 
        <table class="form-table">
 
            <tr><td>
 
                <textarea name="sign_in" id="sign_in" rows="1" cols="70"><?php echo get_option('mytheme_sign_in'); ?></textarea><br />
 
                <em>“注册” 或 “登陆” 或 “个人信息” 链接</em>
 
            </td></tr>
 
            <tr><td>
 
                <textarea name="qq" id="qq" rows="1" cols="70"><?php echo get_option('mytheme_qq'); ?></textarea>
 
                <em>在线QQ代码</em>
 
            </td></tr>
 
             <tr><td>
 
                <textarea name="xinlang_weibo" id="xinlang_weibo" rows="1" cols="70"><?php echo get_option('mytheme_xinlang_weibo'); ?></textarea>
 
                <em>新浪微博地址</em>
 
            </td></tr>

            <tr><td>
 
                <textarea name="qq_weibo" id="qq_weibo" rows="1" cols="70"><?php echo get_option('mytheme_qq_weibo'); ?></textarea>
 
                <em>腾讯微博地址</em>
 
            </td></tr>

        </table>
 
    </fieldset>

 
    <p class="submit">
 
        <input type="submit" name="Submit" class="button-primary" value="保存设置" />
 
        <input type="hidden" name="mytheme_settings" value="save" style="display:none;" />
 
    </p>
 
 
 
</form>
 
</div>
 
<?php }
 
add_action('admin_menu', 'mytheme_page');