<?php
if ( ! defined( 'ABSPATH' ) ) exit;


/**
 * Set the content width based on the theme's design and stylesheet.
 */
if ( ! isset( $content_width ) ) $content_width = 640;




/**
 * Sets up theme defaults and registers the various WordPress features 
 *
 * @uses add_editor_style() To add Visual Editor stylesheets.
 * @uses add_theme_support() To add support for automatic feed links, post
 * formats, and post thumbnails.
 * @uses register_nav_menu() To add support for a navigation menu.
 * @uses set_post_thumbnail_size() To set a custom post thumbnail size.
 *
 * @return void
 */
function yinhu_setup() {

	/*
	 * This theme styles the visual editor to resemble the theme style,
	 * specifically font, colors, icons, and column width.
	 */
	add_editor_style( array( 'css/editor-style.css', 'fonts/genericons.css', yinhu_fonts_url() ) );

	// Adds RSS feed links to <head> for posts and comments.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Switches default core markup for search form, comment form,
	 * and comments to output valid HTML5.
	 */
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );

	/*
	 * This theme supports all available post formats by default.
	 * See http://codex.wordpress.org/Post_Formats
	add_theme_support( 'post-formats', array(
		'aside', 'audio', 'chat', 'gallery', 'image', 'link', 'quote', 'status', 'video'
	) );
	 */

	// This theme uses wp_nav_menu() in one location.
	register_nav_menu( 'primary', __( 'Navigation Menu', 'twentythirteen' ) );
	register_nav_menu( 'footer', __( 'Footer Menu', 'twentythirteen' ) );
	/*
	 * This theme uses a custom image size for featured images, displayed on
	 * "standard" posts and pages.
	 */
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 604, 270, true );

	// This theme uses its own gallery styles.
	add_filter( 'use_default_gallery_style', '__return_false' );
}
add_action( 'after_setup_theme', 'yinhu_setup' );


/**
 * Return the Google font stylesheet URL, if available.
 *
 * @return string Font stylesheet or empty string if disabled.
 */
function yinhu_fonts_url() {
	$fonts_url = '';

	$source_sans_pro = "on";
	$bitter = "on";
	
	if ( 'off' !== $source_sans_pro || 'off' !== $bitter ) {
		$font_families = array();

		if ( 'off' !== $source_sans_pro )
			$font_families[] = 'Source Sans Pro:300,400,700,300italic,400italic,700italic';

		if ( 'off' !== $bitter )
			$font_families[] = 'Bitter:400,700';

		$query_args = array(
			'family' => urlencode( implode( '|', $font_families ) ),
			'subset' => urlencode( 'latin,latin-ext' ),
		);
		$fonts_url = add_query_arg( $query_args, "//fonts.googleapis.com/css" );
	}

	return $fonts_url;
}



/**
 * Enqueue scripts and styles for the front end.
 *
 * @return void
 */
function yinhu_scripts_styles() {
	/*
	 * Adds JavaScript to pages with the comment form to support
	 * sites with threaded comments (when in use).
	 */
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) )
		wp_enqueue_script( 'comment-reply' );

	// Adds Masonry to handle vertical alignment of footer widgets.
	if ( is_active_sidebar( 'sidebar-2' ) )
		wp_enqueue_script( 'jquery-masonry' );

	// Loads JavaScript file with functionality specific to Twenty Thirteen.
	wp_enqueue_script( 'yinhu-script', get_template_directory_uri() . '/js/functions.js', array( 'jquery' ), '', true );

	wp_enqueue_script( 'respond-script', get_template_directory_uri() . '/js/respond.js', array( 'jquery' ), '', true );

	wp_enqueue_script( 'fitvids-script', get_template_directory_uri() . '/js/fitvids.js', array( 'jquery' ), '', true );

	wp_enqueue_script( 'doubleTapToGo-script', get_template_directory_uri() . '/js/jquery.doubleTapToGo.js', array( 'jquery' ), '', true );

	wp_enqueue_script( 'modernizr-script', get_template_directory_uri() . '/js/modernizr.min.js', array( 'jquery' ), '', true );

	wp_enqueue_script( 'general-script', get_template_directory_uri() . '/js/general.js', array( 'jquery' ), '', true );

	// Add Source Sans Pro and Bitter fonts, used in the main stylesheet.
	wp_enqueue_style( 'yinhu-fonts', yinhu_fonts_url(), array(), null );

	// Add Genericons font, used in the main stylesheet.
	wp_enqueue_style( 'genericons', get_template_directory_uri() . '/fonts/genericons.css', array(), '2.09' );

	// Loads our main stylesheet.
	wp_enqueue_style( 'main-style', get_stylesheet_uri(), array(), '' );

	// Loads the Internet Explorer specific stylesheet.
	wp_enqueue_style( 'yinhu-ie', get_template_directory_uri() . '/css/ie.css', array( 'main-style' ), '' );
	wp_style_add_data( 'yinhu-ie', 'conditional', 'lt IE 9' );

	wp_enqueue_style( 'yinhu-layout', get_template_directory_uri() . '/css/layout.css', array(), '' );

	wp_enqueue_style( 'custom-layout', get_template_directory_uri() . '/custom.css', array(), '' );

}
add_action( 'wp_enqueue_scripts', 'yinhu_scripts_styles' );


/**
 * Extend the default WordPress body classes.
 *
 * Adds body classes to denote:
 * 1. Active widgets in the sidebar to change the layout and spacing.
 *
 * @param array $classes A list of existing body class values.
 * @return array The filtered body class list.
 */
function yinhu_body_class( $classes ) {

	if ( is_active_sidebar( 'sidebar-1' ) && ! is_attachment() && ! is_404() )
		$classes[] = 'sidebar';

	return $classes;
}
add_filter( 'body_class', 'yinhu_body_class' );