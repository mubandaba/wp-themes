<?php			$banner_url = "";
				$banner_parent_css = "";
			
				$page_id = get_the_ID();
				    $image_project = wp_get_attachment_image_src( get_post_thumbnail_id($page_id), 'single-post-thumbnail' );
				 if ($image_project ){
					$banner_url = $image_project[0]; 
					$banner_parent_css = "parent-banner";
				}else{
					$banner_url = get_template_directory_uri().'/images/headers/banner_default.jpg';
				}

				if(0){ //image
			?>
		<div class="page-banner <?php echo $banner_parent_css; ?> full-width" >
			<img src="<?php echo $banner_url; ?>" />
		</div>
<?php } else { //background 
?>
		<style type="text/css">
		div.header_banner {
			max-width: 1000px;
			margin:0 auto;
		}
		figure.page-banner-bg {
			padding-top: 10%;  /* slope */
			height: 150px;  /* start height */
			background-image: url(<?php echo $banner_url ?>);
			background-size: cover;
			-moz-background-size: cover;  /* Firefox 3.6 */
			background-position: center;  /* Internet Explorer 7/8 */
			border-radius:  3px;
			box-shadow: 0px 1px 1px #ddd;
		}
		</style>
		
		<div class="header_banner">
			<figure class="page-banner-bg"></figure>
		</div>

<?php
}?>