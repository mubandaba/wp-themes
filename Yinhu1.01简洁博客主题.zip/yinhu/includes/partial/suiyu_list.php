<!--简说列表-->

<div class="art_img_box clearfix">
	<div class="fr box_content">
		<div class="art_title clearfix">
			<span class="face_img"><?php echo get_avatar( get_the_author_email(), '50' ); ?></span>
			<p class="intro">
				<span>小Z:</span>
				<?php 
					 $excerpt = strip_tags(get_the_excerpt());
		    			 echo $excerpt; 
				?>
			</p>
			<div class="info">
				<span>发布日期：<?php the_time('Y年m月d日') ?></span>                        
				<span><?php edit_post_link( __('[编辑]')); ?></span>
			</div>
		</div>
	</div>
</div>

<!--blog列表结束 -->