# Pure

Pure - a simple WordPress theme

* Homepage: [http://www.icodechef.com](http://www.icodechef.com)