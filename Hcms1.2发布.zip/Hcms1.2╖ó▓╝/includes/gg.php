<div class="gg">
<p>------======<strong> 本站公告 </strong>======------<br/>
<?php echo stripslashes(get_option('swt_ggao')); ?></p>
			<div class="clear"></div>
</div>