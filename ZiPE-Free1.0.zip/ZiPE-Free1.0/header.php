<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<title><?php
	global $page, $paged;
	wp_title( '|', true, 'right' );
	bloginfo( 'name' );
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) )
		echo " | $site_description";
	if ( $paged >= 2 || $page >= 2 )
		echo ' | ' . sprintf( '第%s页', max( $paged, $page ) );
	?></title>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
<link rel="shortcut icon" href="<?php echo home_url( '/' ); ?>favicon.ico" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<?php if(stripos($_SERVER["HTTP_USER_AGENT"],"MSIE")) { ?>
<!--[if lt IE 9]><script type="text/javascript">(function(){if(!/*@cc_on!@*/0)return;var e = "article,aside,footer,hgroup,header,nav,section,time".split(','),i=0,length=e.length;while(i<length){document.createElement(e[i++])}})();</script><![endif]-->
<?php } ?>
<?php
	if ( is_singular() && get_option( 'thread_comments' ) )
		wp_enqueue_script( 'comment-reply' );
	wp_head();
?>
</head>

<body <?php body_class(); ?>>
<header id="branding" role="banner">

	<?php $headingtag = ( is_singular() ) ? 'h4' : 'h1'; ?>
	<hgroup id="logo">
		<<?php echo $headingtag; ?> id="site-title"><a href="<?php echo home_url(); ?>" title="<?php bloginfo( 'name' ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></<?php echo $headingtag; ?>>
		<h5 id="site-description"><?php bloginfo( 'description' ); ?></h5>
	</hgroup>

	<nav id="access" role="navigation">
		<?php wp_nav_menu( array( 'container' => 'false', 'theme_location' => 'primary' ) ); ?>
	</nav><!-- #access -->
	
	<form method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
		<input type="text" name="s" id="s" placeholder="搜索..." required>
		<input type="submit" class="submit" name="submit" id="searchsubmit" value="搜索">
	</form>
	<a id="rss" href="<?php echo get_bloginfo('rss2_url'); ?>">RSS订阅<i title="RSS订阅"></i></a>

</header><!-- #branding -->
<div class="split"></div>
<section id="main">
<?php if( stripos($_SERVER["HTTP_USER_AGENT"],"MSIE") ) { ?>
<!--[if lt IE 7]><div style="text-align:center;margin-bottom:20px"><a href="http://windows.microsoft.com/zh-CN/internet-explorer/downloads/ie?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.cn/img/banner/upgrade.jpg" alt="您正在使用的Internet Explorer浏览器版本过旧，我们希望您能够体验流畅、兼容、安全的互联网。立即升级吧！" /></a></div><![endif]-->
<?php } ?>