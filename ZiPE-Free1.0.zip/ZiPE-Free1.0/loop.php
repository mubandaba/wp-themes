<?php while ( have_posts() ) : the_post(); ?>
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<header class="entry-header">
				<h3 class="entry-title"><a href="<?php the_permalink(); ?>" title="链向 <?php the_title(); ?> 的固定链接" rel="bookmark"><?php the_title(); ?></a></h3>

				<div class="entry-meta">
					<time class="entry-date" datetime="<?php the_time('c'); ?>" pubdate><?php the_date('Y-m-d'); ?></time> / 
					<?php the_category(', '); ?> / 
					<?php the_tags('', ', ', ' / '); ?>
					<?php if(function_exists('the_views')) { the_views(); } ?>
				</div><!-- .entry-meta -->
	
				<?php if ( comments_open() && ! post_password_required() ) : ?>
				<div class="comments-link">
					<?php comments_popup_link('0', '1', '%'); ?>
				</div>
				<?php endif; ?>
			</header><!-- .entry-header -->
			<div class="entry-content clearfix">
	<?php if ( is_search() ) : ?>
				<?php the_excerpt(); ?>
	<?php else : ?>
				<?php the_content('阅读全文...'); ?>
	<?php endif; ?>
			</div>
		</article>
<?php endwhile; ?>

<?php if ( $wp_query->max_num_pages > 1 ) : ?>
	<?php if(function_exists('wp_pagenavi')){ wp_pagenavi(); } else { ?>
		<nav id="nav-below">
			<div class="nav-previous"><?php previous_posts_link('&laquo; 上一页'); ?></div>
			<div class="nav-next"><?php next_posts_link('下一页 &raquo;'); ?></div>
		</nav>
	<?php } ?>
<?php endif; ?>