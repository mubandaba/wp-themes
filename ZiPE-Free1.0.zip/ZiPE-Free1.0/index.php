<?php get_header(); ?>

	<div id="content" role="main">
		<?php get_template_part( 'loop' ); ?>
	</div><!-- #content -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>