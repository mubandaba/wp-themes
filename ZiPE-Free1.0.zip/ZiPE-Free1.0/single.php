<?php get_header(); ?>

	<div id="content" role="main">
<?php while ( have_posts() ) : the_post(); ?>
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<header class="entry-header">
				<h1 class="entry-title"><a href="<?php the_permalink(); ?>" title="链向 <?php the_title(); ?> 的固定链接" rel="bookmark"><?php the_title(); ?></a></h1>

				<div class="entry-meta">
					<time class="entry-date" datetime="<?php the_time('c'); ?>" pubdate><?php the_date('Y-m-d'); ?></time> / 
					<?php the_category(', '); ?> / 
					<?php the_tags('', ', ', ' / '); ?>
					<?php if(function_exists('the_views')) { the_views(); } ?>
				</div><!-- .entry-meta -->
	
				<?php if ( comments_open() && ! post_password_required() ) : ?>
				<div class="comments-link">
					<?php comments_popup_link('0', '1', '%'); ?>
				</div>
				<?php endif; ?>
			</header><!-- .entry-header -->

			<div class="entry-content">
				<?php the_content(); ?>
				<?php wp_link_pages(); ?>
			</div>
		</article>
		<nav id="nav-single">
			<span class="nav-previous"><?php previous_post_link( '&laquo; 上一篇 %link' ); ?></span>
			<span class="nav-next"><?php next_post_link( '%link 下一篇 &raquo;' ); ?></span>
		</nav><!-- #nav-single -->
		<?php comments_template( '', true ); ?>
<?php endwhile; // end of the loop. ?>
	</div><!-- #content -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>