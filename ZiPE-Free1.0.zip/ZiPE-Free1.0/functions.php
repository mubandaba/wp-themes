<?php
function zipe_setup() {
	add_theme_support( 'automatic-feed-links' );
	register_nav_menu( 'primary', '导航栏' );
	register_sidebar( array(
		'name' => 'Sidebar',
		'id' => 'sidebar',
		'before_widget' => '<aside id="%1$s" class="widget clearfix %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );
}
add_action( 'after_setup_theme', 'zipe_setup' );

if ( ! function_exists( 'zipe_comment' ) ) :
function zipe_comment( $comment, $args, $depth ) {
	$GLOBALS['comment'] = $comment;
	switch ( $comment->comment_type ) :
		case 'pingback' :
		case 'trackback' :
	?>
	<li class="post pingback">
		<p>Pingback 引用通告：<?php comment_author_link(); ?></p>
	<?php
			break;
		default :
	?>
	<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
		<div id="comment-<?php comment_ID(); ?>" class="comment-wrapper">
			<div class="comment-meta">
				<div class="comment-author vcard">
					<?php echo get_avatar( $comment, 36 ); ?>
					<?php comment_author_link(); ?><span class="says"> 说：</span>
					<?php if ( $comment->comment_approved == '0' ) : ?>
						<em class="comment-awaiting-moderation" title="<?php comment_time('Y-n-j H:i') ?>">初次评论需要等待审核。</em>
					<?php else : ?>
						<time pubdate datetime="<?php comment_date() ?>"><?php echo comment_time('Y-n-j H:i'); ?></time>
					<?php endif; ?>
				</div><!-- .comment-author .vcard -->
			</div>

			<div class="comment-content"><?php comment_text(); ?></div>

			<?php if ( $comment->comment_approved != '0' && $args != null&&$depth != null) : ?>
			<div class="reply">
				<?php comment_reply_link( array_merge( $args, array( 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
				<?php if(function_exists('mailtocommenter_button')) mailtocommenter_button();?>
			</div><!-- .reply -->
			<?php endif; ?>
		</div><!-- #comment-## -->

	<?php
			break;
	endswitch;
}
endif;