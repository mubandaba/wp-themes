<?php get_header(); ?>

	<div id="post-0" class="post error404 not-found clearfix">
		<img src="<?php bloginfo('template_url'); ?>/images/404.gif" alt="404 - NOT FOUND" />
		<h1>有点尴尬诶。</h1>
		<h3>我们可能无法找到您需要的内容。</h3>
		<p>
			<a href="<?php echo home_url( '/' ); ?>">&raquo; 回到首页</a>
			<br />
			<a href="javascript:history.go(-1);">&raquo; 返回上页</a>
		</p>
	</div><!-- #post-0 -->

<?php get_footer(); ?>