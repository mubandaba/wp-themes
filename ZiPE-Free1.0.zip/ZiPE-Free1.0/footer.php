</section><!-- #main -->

<footer id="colophon" role="contentinfo">
		&copy; <?php echo date('Y'); ?> <a href="<?php echo home_url( '/' ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a><span class="sep"></span>Powered by <a href="http://wordpress.org/" target="_blank" rel="generator">WordPress</a><span class="sep"></span>Designed by <a href="http://c7sky.com/" target="_blank">Cople</a>
</footer><!-- #colophon -->

<div id="sticky-nav">
	<a href="#top" class="gotop" onclick="window.scrollTo(0,0);return false;"><span>返回顶部</span></a>
	<?php if ( is_singular() && comments_open() ) { ?>
	<a href="#respond" class="gocom" onclick="document.getElementById('comment').focus();return false;"><span>发表评论</span></a>
	<?php if ( !is_user_logged_in() ) : ?><script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/show-gravatar.js"></script><?php endif; ?>
	<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/comment-plus.js"></script>
	<?php } ?>
	<a href="#colophon" class="gobtm" onclick="window.scrollTo(0,document.body.scrollHeight);return false;"><span>前往底部</span></a>
</div>

<?php wp_footer(); ?>
</body>
</html>