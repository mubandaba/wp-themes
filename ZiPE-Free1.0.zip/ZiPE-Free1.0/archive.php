<?php get_header(); ?>

	<div id="content" role="main">
<?php if ( have_posts() ) : ?>
		<h1 class="page-title">
			<?php if ( is_category() ) {
				echo '分类归档：' . single_cat_title('', false);
			} elseif ( is_tag() ) {
				echo '标签归档：' . single_tag_title('', false);
			} elseif ( is_day() ) {
				echo '日度归档：' . get_the_date('Y年n月j日');
			} elseif ( is_month() ) {
				echo '月度归档：' . get_the_date('Y年n月');
			} elseif ( is_year() ) {
				echo '年度归档：' . get_the_date('Y年');
			} elseif ( is_author() ) {
				if ( have_posts() ) {
					the_post();
					echo '作者归档：' . get_the_author();
					rewind_posts();
				}
			} else {
				echo '文章归档';
			}
			?>
		</h1>
		<?php get_template_part( 'loop' ); ?>
<?php else : ?>
		<h1 class="page-title">未找到</h1>
		<article id="post-0" class="post no-results not-found">
			<div class="entry-content">
				<p>抱歉，您访问的归档页面未找到。也许搜索能帮到您。</p>
			</div>
		</article>
<?php endif; ?>
	</div><!-- #content -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>