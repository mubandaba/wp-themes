<article class="postitem" >
	<header>
		<h3 class="title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h3>
		<div class="muted">
			<span class="time"><?php echo timeago( get_gmt_from_date(get_the_time('Y-m-d G:i:s')) ); ?></span> | 
			<span class="views"><?php the_view(); ?> VIEWS</span> | 
			<span class="comment"><?php comments_popup_link('0 COMMENTS', '1 COMMENTS', '% COMMENTS', '', '评论已关闭' ); ?></span>
		</div>
	</header>
	<div class="format">
		<?php if (has_excerpt()) { // 如果设置了摘要则显示摘要 ?>
			<div class="thumbnail">
				<?php
					if(has_post_thumbnail() || get_dopt('Rcloud_imgpost_b')){
						the_thumbnail(740,300,1);
					}; 
				?>
			</div>
		<?php
			the_excerpt();
			// 否则显示内容
			}else{
				the_content('Read More →');
			}
		?>
	</div>
	<footer>
		<?php the_author_link(); ?> | 
		<span class="category"><?php the_category(" "); ?></span> | 
		<span class="tags"><?php the_tags("", " "); ?></span>
	</footer>
</article>