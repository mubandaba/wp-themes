<?php if(is_home() && is_sticky()): ?>
<!-- 置顶推荐 -->
<div class="m-stickpost" id="stickpost">
	<?php
		// 获取置顶文章代码
		$sticky = get_option( 'sticky_posts' ); //获得所有置顶文章的id
		$args = array(
			
			'post__in'  => $sticky
		);
		$sticky_posts = new WP_Query($args);
		$post_page = 1;
		//循环输出置顶文章
		if($post_page <= 4): while ( $sticky_posts -> have_posts() ) : $sticky_posts -> the_post();
	?>
		<dl class="item-<?php echo $post_page; ?>"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
			<dd class="img"><?php the_thumbnail('230','140','1'); ?><span class="info"><?php the_excerpt(); ?></span></dd>
			<dt><?php the_title(); ?></dt>
		</a></dl>
	<?php $post_page++; endwhile; endif; wp_reset_query();?>
</div>
<?php endif; ?>