<?php
/*
Template Name: 文章归档
*/
?>
<?php get_header(); ?>
<section class="container m-page">
	<?php
		while(have_posts()):the_post();
	?>
		<header><h1><?php the_title(); ?></h1></header>
		<footer class="muted">
			<span class="time"><?php echo timeago( get_gmt_from_date(get_the_time('Y-m-d G:i:s')) ); ?></span> | 
			<span class="comment"><?php comments_popup_link('0 COMMENTS', '1 COMMENTS', '% COMMENTS', '', '评论已关闭' ); ?></span>
		</footer>
		<article class="format"><?php the_content(); ?><?php Rcloud_archives_list(); ?></article>
		<?php comments_template(); ?>
	<?php endwhile; ?>

<?php get_footer(); ?>
<script>
	$(function(){
         $('#al_expand_collapse,#archives span.al_mon').css({cursor:"s-resize"});
         $('#archives span.al_mon').each(function(){
             var num=$(this).next().children('li').size();
             var text=$(this).text();
             $(this).html(text+'<em> ( '+num+' 篇文章 )</em>');
         });
         var $al_post_list=$('#archives ul.al_post_list'),
             $al_post_list_f=$('#archives ul.al_post_list:first');
         $al_post_list.hide(1,function(){
             $al_post_list_f.show();
         });
         $('#archives span.al_mon').click(function(){
             $(this).next().slideToggle(400);
             return false;
         });
         $('#al_expand_collapse').toggle(function(){
             $al_post_list.show();
         },function(){
             $al_post_list.hide();
         });
 	});
</script>