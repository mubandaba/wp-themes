$(function(){
	//导航切换
	$('.d_mainbox:eq(0)').show();
	$('.d_tab a').each(function(i) {
		$(this).click(function(){
			$(this).addClass('d_tab_on').siblings().removeClass('d_tab_on');
			$($('.d_mainbox')[i]).show().siblings('.d_mainbox').hide();
		})
	});
})