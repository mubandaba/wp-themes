<?php
$themename = wp_get_theme();
include_once 'theme_con.php';
function mytheme_add_admin() {
	global $themename, $options;
	if ( $_GET['page'] == basename(__FILE__) ) {
		if ( 'save' == $_REQUEST['action'] ) {
			foreach ($options as $value) {
				update_option( $value['id'], $_REQUEST[ $value['id'] ] ); 
			}
			header("Location: admin.php?page=setThemes.php&saved=true");
			die;
		}
		else if( 'reset' == $_REQUEST['action'] ) {
			foreach ($options as $value) {delete_option( $value['id'] ); }
			header("Location: admin.php?page=setThemes.php&reset=true");
			die;
		}
	}
	add_theme_page($themename."设置", $themename."设置", 'edit_themes', basename(__FILE__), 'mytheme_admin');
}

function mytheme_admin() {
	global $themename, $options, $themeSet_tagname;
	$i=0;
	if ( $_REQUEST['saved'] ) echo '<div class="d_message">'.$themename.'修改已保存</div>';
	if ( $_REQUEST['reset'] ) echo '<div class="d_message">'.$themename.'已恢复设置</div>';
?>

<div class="wrap d_wrap">
	<link rel="stylesheet" href="<?php bloginfo('template_url') ?>/admin/theme.css"/>
	<?php
		$my_theme = wp_get_theme();
	?>
	<div class="d_header">
		<h2><?php echo $themename; ?></h2>
		<p><?php echo $my_theme->get('Description'); ?></p>
		<div class="d_dsc">
			<p><span>当前版本：<?php echo $my_theme->get('Version'); ?>&nbsp;&nbsp; 主题作者：<a href="<?php echo $my_theme->get('AuthorURI'); ?>" title="生要能尽欢，死要能无憾" target="_blank">热血洒红尘</a>&nbsp;&nbsp; 主题使用教程和效果演示：<a href="<?php echo $my_theme->get('ThemeURI'); ?>" title="主题演示站点，主题使用教程" target="_blank"><?php echo $my_theme->get('Name'); ?></a></span></p>
			<?php if(function_exists(show_category)){ echo '<p class="d_catinfo">分类：'; show_category(); echo '</p>'; } ?></p>
		</div>
	</div>
	<form method="post">
		<div class="d_tab"><?php echo "$themeSet_tagname"; ?></div>
		<?php foreach ($options as $value) { switch ( $value['type'] ) { case "": ?>
			<?php break; case "tit": ?>
			
			</li><li class="d_li">
			<h4><?php echo $value['name']; ?>：</h4>
			
			<?php break; case 'text': ?>
			<?php if ( $value['desc'] != "") { ?><label class="d_the_desc"><?php echo $value['desc']; ?></label><?php } ?><input class="d_inp <?php echo $value['class']; ?>" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" value="<?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id'])  ); }; ?>" placeholder="<?php echo $value['std']; ?>" />
			
			<?php break; case 'textarea': ?>
			<textarea class="d_tarea" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" cols="" rows="" placeholder="<?php echo $value['std']; ?>"><?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id']) ); } ?></textarea>
			
			<?php break; case 'select': ?>
			<?php if ( $value['desc'] != "") { ?><span class="d_the_desc" id="<?php echo $value['id']; ?>_desc"><?php echo $value['desc']; ?></span><?php } ?><select class="d_sel" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>">
				<?php foreach ($value['options'] as $option) { ?>
				<option <?php if (get_settings( $value['id'] ) == $option) { echo 'selected="selected" class="d_sel_opt"'; } ?>><?php echo $option; ?></option>
				<?php } ?>
			</select>
			
			<?php break; case "checkbox": ?>
			<?php if(get_settings($value['id']) != ""){ $checked = "checked=\"checked\""; }else{ $checked = "";} ?>
			<label class="d_check"><input type="checkbox" id="<?php echo $value['id']; ?>" name="<?php echo $value['id']; ?>" <?php echo $checked; ?> />开启</label>
			
			<!-- 新增 -->
			<?php break; case "z_c": ?>
			<?php if(get_settings($value['id']) != ""){ $checked = "checked=\"checked\""; }else{ $checked = "";} ?>
			<label class="d_check z_c"><input type="checkbox" id="<?php echo $value['id']; ?>" name="<?php echo $value['id']; ?>" <?php echo $checked; ?> />开启</label>
			
			<?php break; case 'z_text': ?>
			<?php if ( $value['desc'] != "") { ?><label class="d_the_desc"><?php echo $value['desc']; ?></label><?php } ?><input class="d_inp <?php echo $value['class']; ?> z_text" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" type="text" value="<?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id'])  ); } ?>"  placeholder="<?php echo $value['std']; ?>" />
			
			<?php break; case 'z_textarea': ?>
			<?php if ( $value['desc'] != "") { ?><label class="d_the_desc"><?php echo $value['desc']; ?></label><?php } ?><input class="d_inp <?php echo $value['class']; ?> z_textarea" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" type="text" value="<?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id'])  ); } ?>"  placeholder="<?php echo $value['std']; ?>" />
			
			<?php break; case 'z_info': ?>
			<?php if ( $value['desc'] != "") { ?><label class="d_the_desc"><?php echo $value['desc']; ?></label><?php } ?><div class="d_inp <?php echo $value['class']; ?> z_info" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>"><?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id'])  ); } else { echo $value['std']; } ?></div>
			
			
			<?php break; case "section": $i++; ?>
			<div class="d_mainbox" id="d_mainbox_<?php echo $i; ?>">
				<div class="d_desc"><input class="button-primary" name="save<?php echo $i; ?>" type="submit" value="保存设置" /><?php echo $value['desc']; ?></div>
				<ul class="d_inner">
					<?php break; case "endtag": ?>
				</ul>
			<div class="d_desc d_desc_b"><input class="button-primary" name="save<?php echo $i; ?>" type="submit" value="保存设置" /></div>
			</div>
			
		<?php break; }} ?>
		
		
		<!-- 使用教程 -->
		<div class="d_mainbox">
			<div class="d_desc">Rclean主题使用教程</div>
			<div class="d_inner m-help"><?php include_once 'help.php'; ?></div>
			<div class="d_desc d_desc_b">本主题是商业主题，版权归<a href="http://rxshc.com" target="_blank">热血洒红尘</a>所有，未经许可请不要传播复制，二次修改售卖。</div>
		</div>	
		<!-- 使用教程结束 -->	
		<input type="hidden" name="action" value="save" />
		
	</form>
<script src="http://libs.baidu.com/jquery/2.0.0/jquery.min.js"></script>
<script src="<?php bloginfo('template_url') ?>/admin/theme.js"></script>
</div>
<?php } ?>

<?php add_action('admin_menu', 'mytheme_add_admin');?>

<?php 

	function dopt($e){
		echo get_dopt($e);
	}
	
	function get_dopt($e){
		return stripslashes(get_option($e));
	}
?>