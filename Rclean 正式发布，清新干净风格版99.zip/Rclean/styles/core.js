/**
 * 置顶幻灯片模块
 */
function stick_start(){
	var $stick = $('#stickpost dl');
	var $info = $('#stickpost .info');
	$stick.hover(function(){
		$(this).find('.info').css({left:'0'});
	},function(){
		$(this).find('.info').css({left:'100%'});
	});
};

// 菜单导航效果
function sub_menu_init(){
	$("#nav li").hover(function() {
		$(this).children('.sub-menu').fadeIn(200);
	}, function() {
		$(this).children('.sub-menu').fadeOut(200);
	});
}

// 评论处JS效果
function comment_entry_init(){
	$('#comments .children li').hover(function() {
		$(this).find('.comment-entry').show();
	}, function() {
		$(this).find('.comment-entry').hide();
	});
}

// 菜单边缘滑出
function modie_menu(){
	var body = $("#body");
	var menu = $("#Menu_controller");
	var header = $("#blogTitle");
	var status = 'false';
	//ontouchstart // ontouchmove
	menu.on('click',function(e){
		if(status == 'false'){
			status = 'true';
			body.css('left',190);
		}else{
			status = 'false';
			body.css('left',0);
		}
	});
}


$(function(){
	// 启动幻灯片模块
	stick_start();
	// 启动slimbox图片展示效果
	$('.format a[href$=".jpg"],.format a[href$=".png"],.format a[href$=".gif"]').slimbox();
	// 启动菜单导航效果
	sub_menu_init();
	// 启动评论回复JS效果
	comment_entry_init();
	
	modie_menu();
});