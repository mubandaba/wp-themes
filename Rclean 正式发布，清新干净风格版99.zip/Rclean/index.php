<?php get_header(); ?>
<section class="container">
	<?php if(!wp_is_mobile()): ?>
		<?php include 'modules/stick.php'; //导入置顶推荐文件 ?>
	<?php endif; ?>
	<!-- 内容 -->
	<div class="g-post">
		<!-- 文章列表 -->
		<div class="m-postlist" id="postlist">
			<?php if( is_category()){ ?>
				<header class="archive-header">
					<h1>分类：<?php single_cat_title(); ?></h1>
					<?php echo category_description(); ?>
				</header>
			<?php }elseif( is_tag() ){ ?>
				<header class="archive-header">
					<h1>标签：<b><?php single_cat_title(); ?></b></h1>
				</header>
			<?php }elseif( is_search() ){ global $s; ?>
				<header class="archive-header"> 
					<h1>搜索“<b><?php echo $s; ?></b>”的结果</h1>
				</header>
			<?php }; ?>
			<?php
				$postnun = 1;
				global $query_string;
				query_posts( $query_string.'&caller_get_posts=1' );
				if(have_posts()):while(have_posts()):the_post();
			?>
				<?php
					//广告
					if($postnun == 2 && get_dopt('Rcloud_list_ad_c')){
						echo '<article class="postitem">'.get_dopt('Rcloud_list_ad').'</article>';
					}
				?>
				<?php get_template_part( 'modules/content', get_post_format() ); ?>
			<?php $postnun++; endwhile;else: ?>
				<h1 class="nopost">这里什么都没有哦，去<a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>">首页</a>看看别的吧</h1>
			<?php endif; wp_reset_query(); ?>
			<?php 
				// 检测是否安装wp_pagenavi插件
				if(function_exists('wp_pagenavi')){ 
					wp_pagenavi(); 
				}else{ 
			?>
				<div class="wp-pagenavi"><?php posts_nav_link(" ","«上一页","下一页»"); ?></div>
			<?php }; ?>
		</div>
	</div>
	<?php get_sidebar(); //导入侧边文件 ?>

<?php get_footer(); ?>