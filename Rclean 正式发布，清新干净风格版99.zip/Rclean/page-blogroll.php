<?php
/*
Template Name: 友情链接
*/
?>
<?php get_header(); ?>
<section class="container m-page">
	<?php
		while(have_posts()):the_post();
	?>
		<header><h1><?php the_title(); ?></h1></header>
		<footer class="muted">
			<span class="time"><?php echo timeago( get_gmt_from_date(get_the_time('Y-m-d G:i:s')) ); ?></span> | 
			<span class="comment"><?php comments_popup_link('0 COMMENTS', '1 COMMENTS', '% COMMENTS', '', '评论已关闭' ); ?></span>
		</footer>
		<article class="format"><?php the_content(); ?><div id="m-pagelinks" class="m-pagelinks"><?php dynamic_sidebar('links'); ?></div><?php wp_nav_menu(array('theme_location' => 'link_page','container_id' => 'link_page','fallback_cb' =>'Rcloud_noMenu')); ?></article>
		<?php comments_template(); ?>
	<?php endwhile; ?>

<?php get_footer(); ?>
<script>
	$(function(){
    	$('#link_page').find('.menu-item-has-children > a').attr('href','javascript:void(0);');
    	$('#link_page').find('.sub-menu li').each(function(){
    		var title = $(this).find('a').attr('title');
    		if(title){
    			$(this).append('<p>'+title+'</p>');
    		}
    	});
 	});
</script>