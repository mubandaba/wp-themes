<!-- 侧边 -->
<aside class="m-sidebar">
	<?php
		if(is_single() || is_page()){
			dynamic_sidebar('内页侧边'); 
		}else{
			dynamic_sidebar('侧边栏');
		}
	?>
</aside>