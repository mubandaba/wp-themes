<?php

// 导入后台设置文件
include_once 'admin/setThemes.php';

// 导入初始化文件
include 'functions/init.php';

// 自定义评论结构
include 'functions/mytheme_comment.php';
 
// 获取文章相关图片地址
include 'functions/post_thumbnail_src.php';

// 获取&输出缩略图
include 'functions/the_thumbnail.php';

// 显示时间为XX前
include 'functions/timeago.php';

// 显示分类名字，ID
include 'functions/show_category.php';

// 导入小工具
include 'functions/widget.php';

// 文章浏览量
include 'functions/postviews.php';

// 文章存档
include 'functions/archives_list.php';

// 自动播放链接
include 'functions/auto_player_urls.php';

// 面包屑
include 'functions/breadcrumb.php';

?>