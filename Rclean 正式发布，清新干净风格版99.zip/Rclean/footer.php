
		<footer class="m-footer cc">
            版权所有，保留一切权利！ © 2014 <a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?> | <?php bloginfo('description'); ?>"><?php bloginfo('name'); ?></a> Theme By <a href="http://rxshc.com" target="_blank">Rclean</a>
			<div class="links"><?php wp_nav_menu(array('theme_location' => 'footer_nav','fallback_cb' =>'Rcloud_noMenu','depth' => '1')); ?></div>
			<?php
				// 如果开启了统计则显示统计代码
				if(get_dopt('Rcloud_track_b')){
					dopt('Rcloud_track');
				}

				// 如果开启了备案则显示备案信息
				if(get_dopt('Rcloud_beian_b')){
					dopt('Rcloud_beian');
				}
			?>
		</footer>
	</section>
</div>	
<script src="http://libs.baidu.com/jquery/1.8.0/jquery.min.js"></script>
<script src="<?php bloginfo('template_url') ?>/styles/prettify.js"></script>
<script src="<?php bloginfo('template_url') ?>/styles/slimbox2.js"></script>
<script src="<?php bloginfo('template_url') ?>/styles/core.js"></script>
	<?php if(is_singular()): ?>
		<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/comments-ajax.js"></script>
	<?php endif; ?>
<?php wp_footer(); ?>
<?php if(get_dopt('Rcloud_js_c')): ?>
	<!-- 自定义js -->
	<script><?php dopt('Rcloud_js'); ?></script>
<?php endif; ?>
</body>
</html>