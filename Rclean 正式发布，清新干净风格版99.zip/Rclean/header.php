<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=10,IE=9,IE=8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<?php include 'modules/key.php'; ?>
<link rel="shortcut icon" type="image/x-icon" href="<?php bloginfo( 'template_url' ); ?>/img/favicon.ico" />
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/styles/global.css" media="screen">
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/style.css" media="screen">
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/styles/prettify.css" media="screen">
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/styles/slimbox2.css" media="screen">
<!--[if IE]>
	<script src="<?php bloginfo('template_url') ?>/styles/html5.js"></script>
<![endif]-->

<?php if(get_dopt('Rcloud_css_c')): ?>
	<!-- 自定义CSS -->
	<style><?php dopt('Rcloud_css'); ?></style>
<?php endif; ?>

<?php wp_head(); ?>
</head>
<body <?php body_class(); ?> id="body">
<div class="g-wrap">
	<!-- 头部 -->
	<header id="header" class="m-header">
		<?php if(!is_singular() && ! is_category()){ ?>
			<h1 class="blog-title" id="blogTitle"><a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('title'); ?>"><?php bloginfo('name'); ?></a><span id="Menu_controller">Menu</span></h1>
		<?php }else{ ?>
			<h2 class="blog-title" id="blogTitle"><a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('title'); ?>"><?php bloginfo('name'); ?></a><span id="Menu_controller">Menu</span></h2>
		<?php }; ?>
		<div class="blog-notice"><?php dopt('Rcloud_notice'); ?></div>
		
		<div class="sns">
			<?php if(get_dopt('Rcloud_feed_c')){; ?><a target="_blank" rel="nofollow" class="sns_feed" href="<?php dopt('Rcloud_feed'); ?>" title="订阅我吧"></a><?php }; ?>
			<?php if(get_dopt('Rcloud_weibo_c')){; ?><a target="_blank" rel="nofollow" class="sns_weibo" href="<?php dopt('Rcloud_weibo'); ?>" title="新浪微博"></a><?php }; ?>
			<?php if(get_dopt('Rcloud_qweibo_c')){; ?><a target="_blank" rel="nofollow" class="sns_qweibo" href="<?php dopt('Rcloud_qweibo'); ?>" title="腾讯微博"></a><?php }; ?>
			<?php if(get_dopt('Rcloud_douban_c')){; ?><a target="_blank" rel="nofollow" class="sns_douban" href="<?php dopt('Rcloud_douban'); ?>" title="我的豆瓣"></a><?php }; ?>
			<?php if(get_dopt('Rcloud_qq_c')){; ?><a target="_blank" rel="nofollow" class="sns_qq" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo dopt('Rcloud_qq'); ?>&site=qq&menu=yes" title="联系QQ"></a><?php }; ?>
		</div>
	</header>	
	<!-- 导航 -->
	<?php if(!wp_is_mobile()){ ?>
	<nav id="nav" class="m-nav">
		<?php wp_nav_menu(array('theme_location' => 'nav','fallback_cb' =>'Rcloud_noMenu')); ?>
		<div class="m-search"><form method="get" class="dropdown search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>" >
			<input class="search-input" name="s" type="text" placeholder="要来点什么？"<?php if( is_search() ){ echo ' value="'.$s.'"'; } ?> autofocus="" x-webkit-speech="">
			<input class="btn" type="submit" value="搜索">
		</form></div>
		<div class="cc"></div>
	</nav>
	<?php }else{ ?>
		<nav id="nav" class="m-mnav">
			<?php wp_nav_menu(array('theme_location' => 'mnav','depth' => '1','fallback_cb' =>'Rcloud_noMenu')); ?>
		</nav>
	<?php }; ?>