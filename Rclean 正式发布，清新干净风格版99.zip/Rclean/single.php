<?php get_header(); ?>

<section class="container">
	<!-- 内容 -->
	<div class="g-post">
		<!-- 文章列表 -->
		<?php while(have_posts()):the_post(); ?>
			<article class="m-single" >
				<!-- 文章标题 -->
				<header class="header">
					<h1 class="title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h1>
					<div class="muted">
						<span class="time"><?php echo timeago( get_gmt_from_date(get_the_time('Y-m-d G:i:s')) ); ?></span> | 
						<span class="views"><?php the_view(); ?> VIEWS</span> | 
						<span class="comment"><?php comments_popup_link('0 COMMENTS', '1 COMMENTS', '% COMMENTS', '', '评论已关闭' ); ?></span>
					</div>
				</header>
				<!-- 文章内容 -->
				<div class="format" id="single_con">
					<?php
						if (has_excerpt()) {
							echo "<blockquote>";
							the_excerpt();
							echo "</blockquote>";
						}
					?>
					<?php
						//广告
						if(get_dopt('Rcloud_signleTop_ad_c')){
							echo '<div class="m-ad">'.get_dopt('Rcloud_signleTop_ad').'</div>';
						}
					?>
					
					<?php the_content(); ?>
					
					<?php
						//广告
						if(get_dopt('Rcloud_signleBot_ad_c')){
							echo '<div class="m-ad">'.get_dopt('Rcloud_signleBot_ad').'</div>';
						}
					?>
				</div>
				<!-- 文章相关信息 -->
				<footer>
					<?php the_author_link(); ?> | 
					<span class="category"><?php the_category(" "); ?></span> | 
					<span class="tags"><?php the_tags("", " "); ?></span>
				</footer>
			</article>
			<!-- 上下篇 -->
			<ul class="m-other">
				<li><?php next_post_link('下一篇 %link','%title',false); ?></li>
				<li><?php previous_post_link('上一篇 %link','%title',false); ?></li>
			</ul>
			<!-- 版权声明 -->
			<div class="m-copyright">
				<p class="link">
					转载请注明：
					<a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a> » 
					<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a>
				</p>
				<ul class="post-shareul">
					<li><a href="http://service.weibo.com/share/share.php?title=<?php the_title(); ?>&amp;url=<?php the_permalink(); ?>" class="post-sharea psa-weibo" target="_blank" rel="nofollow" title="分享到新浪微博">新浪微博</a></li>
					<li><a href="http://v.t.qq.com/share/share.php?title=<?php the_title(); ?>&amp;url=<?php the_permalink(); ?>&amp;site=<?php bloginfo('url'); ?>" class="post-sharea psa-qqweibo" target="_blank" rel="nofollow" title="分享到腾讯微博">腾讯微博</a></li>
					<li><a href="http://www.douban.com/recommend/?url=<?php the_permalink(); ?>&amp;title=<?php the_title(); ?>" class="post-sharea psa-douban" target="_blank" rel="nofollow" title="分享到豆瓣">豆瓣网</a></li>
					<li><a href="http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=<?php the_permalink(); ?>&amp;title=<?php the_title(); ?>" class="post-sharea psa-qzone" target="_blank" rel="nofollow" title="分享到QQ空间">QQ空间</a></li>
					<li><a href="http://share.renren.com/share/buttonshare?link=<?php the_permalink(); ?>&amp;title=<?php the_title(); ?>" class="post-sharea psa-renren" target="_blank" rel="nofollow" title="分享到人人网">人人网</a></li>
				</ul>
				<div class="cc"></div>
			</div>
			<?php include 'modules/relevance.php'; //导入相关推荐文件 ?>
			<?php comments_template(); ?>
		<?php endwhile; ?>
	</div>
	
	<?php get_sidebar(); //导入侧边文件 ?>

<?php get_footer(); ?>