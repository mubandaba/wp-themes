<?php 
//去除头部冗余代码
remove_action( 'wp_head',   'feed_links_extra', 3 ); 
remove_action( 'wp_head',   'rsd_link' ); 
remove_action( 'wp_head',   'wlwmanifest_link' ); 
remove_action( 'wp_head',   'index_rel_link' ); 
remove_action( 'wp_head',   'start_post_rel_link', 10, 0 ); 
remove_action( 'wp_head',   'wp_generator' ); 

//隐藏admin Bar
function hide_admin_bar($flag) {
	return false;
}
add_filter('show_admin_bar','hide_admin_bar');

//阻止站内PingBack
add_action('pre_ping','theme_noself_ping');

//定义菜单
if (function_exists('register_nav_menu')){
	register_nav_menu('nav','网站头部导航');
	register_nav_menu('footer_nav','网站底部友情链接');
	register_nav_menu('link_page','内页友情链接');
	register_nav_menu('mnav','移动端导航');
}

// 定义侧边栏
if (function_exists('register_sidebar')){
	register_sidebar(array(
		'name'          => '侧边栏',
		'before_widget' => '<div class="widget %2$s">', //%2$s  为小工具模块的类型class
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="widget_title">',
		'after_title'   => '</h3>'
	));

	register_sidebar(array(
		'name'          => '内页侧边',
		'before_widget' => '<div class="widget %2$s">', //%2$s  为小工具模块的类型class
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="widget_title">',
		'after_title'   => '</h3>'
	));
	
	register_sidebar(array(
		'name'          => 'links',
		'before_widget' => '<div class="widget %2$s">', //%2$s  为小工具模块的类型class
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="widget_title">',
		'after_title'   => '</h3>'
	));
}

// 开启特色图像
 add_theme_support( 'post-thumbnails' );

// 文章形式
//add_theme_support( 'post-formats', array('status','image','quote','video','audio','aside','link') );

// 更换谷歌字体为360CDN
function devework_replace_open_sans() {
	wp_deregister_style('open-sans');
	wp_register_style( 'open-sans', '//fonts.useso.com/css?family=Open+Sans:300italic,400italic,600italic,300,400,600' );
	wp_enqueue_style( 'open-sans');
}
add_action( 'init', 'devework_replace_open_sans' );

// 没有设置菜单时候的回调函数
function Rcloud_noMenu(){
	echo '请在后台 -> 外观 -> 菜单 中设置此处要显示的菜单';
}
?>