<?php

/**
 * 描述 : 自定义缩略图函数
 * $w : 宽度
 * $h : 高度
 * $z : 缩放方式
 */
function get_the_thumbnail($w,$h,$z){
	// 如果开启缩略图则输出缩略图
	if(get_dopt('Rcloud_timthumb_b')){
		return get_bloginfo('template_url').'/timthumb.php?src='.post_thumbnail_src().'&w='.$w.'&h='.$h.'&zc='.$z;
	}else{
		// 如果未开启则输出原始图片
		return post_thumbnail_src();
	}
}

// 输出缩略图
function the_thumbnail($w,$h,$z){
	echo '<img src="'.get_the_thumbnail($w,$h,$z).'" alt="'.get_the_title().'">';
}

?>