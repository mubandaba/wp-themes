<?php

/*------------------------------------*\
	描述：浏览量模块
	用法如下
	the_view() // 如果是列表页则只输出浏览量，如果是内页则增加一次浏览量
\*------------------------------------*/

// 获取文章当前浏览量
function getPostViews($postID){
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return "0";
    }
    return $count;
}
// 添加一次浏览量
function setPostViews($postID) {
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
       $count++;
        update_post_meta($postID, $count_key, $count);
    }
}

// 输出文章浏览量，如果是内容页则增加一次浏览量
function the_view(){
	echo getPostViews(get_the_ID());
	if(is_single()){	
		setPostViews(get_the_ID());
	}
}

?>