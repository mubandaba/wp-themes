<?php
// 链接自动识别播放
function auto_player_urls($c) {
    $s = array('/^(http:\/\/.*\.mp3)$/m' => '<embed class="mp3_player" src="'.get_bloginfo("template_url").'/mp3_player.swf?audio_file=$1&amp;color=ffffff" width="207" height="30" type="application/x-shockwave-flash"></embed></p>',
    '/^(http:\/\/www.xiami.com.*\.swf)$/m' => '<p><embed class="swf_player" src="$1" width="258" height="33" type="application/x-shockwave-flash" wmode="transparent"></embed></p>',
	'/^(http:\/\/box.baidu.com.*)$/m' => '<p><embed class="swf_player" src="$1" width="500" height="80" type="application/x-shockwave-flash" wmode="transparent"></embed></p>',
	'/^(http:\/\/.*\.swf)$/m' => '<p><embed class="swf_player" src="$1" width="640" height="480" type="application/x-shockwave-flash" wmode="transparent"></embed></p>');
    foreach($s as $p => $r){
        $c = preg_replace($p,$r,$c);
    }
    return $c;
}
add_filter( 'the_content', 'auto_player_urls' );

?>