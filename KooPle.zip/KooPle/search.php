<?php get_header(); ?>

<div id="roll">
  <div title="回到顶部" id="roll_top"></div>
  <div title="转到底部" id="fall"></div>
</div>
<div id="content">
<div class="main">
  <div id="map">
    <div class="site">当前位置：<a title="返回首页" href="<?php echo get_settings('Home'); ?>/">首页</a> &gt; 搜索结果</div>
  </div>
  <?php if (have_posts()) : ?>
  <?php while (have_posts()) : the_post(); ?>
  <ul <?php post_class(); ?> id="post-<?php the_ID(); ?>">
    <li>
      <div class="article">
       
        <?php if (get_option('creekoo_thumbnail') == 'Display') { ?>
        <?php if (get_option('creekoo_articlepic') == 'Display') { ?>
        <?php include('includes/articlepic.php'); ?>
        <?php { echo ''; } ?>
        <?php } else { include(TEMPLATEPATH . '/includes/thumbnail.php'); } ?>
        <?php { echo ''; } ?>
        <?php } else { } ?>
        
        <div class="entry-content">
        <h2><?php if(is_sticky()) : ?><span class="sticky">置顶</span><?php else : ?><?php endif; ?><a href="<?php the_permalink() ?>" rel="bookmark" title="详细阅读：<?php the_title_attribute(); ?>"><?php the_title();?></a><span class="new"><?php include('includes/new.php'); ?></span></h2>
        <?php
        if(is_singular()){the_content();}else{
        $pc=$post->post_content;
        $st=strip_tags(apply_filters('the_content',$pc));
        if(has_excerpt())
        the_excerpt();
        elseif(preg_match('/<!--more.*?-->/',$pc) || mb_strwidth($st)<150)
        the_content('');
        elseif(function_exists('mb_strimwidth'))
        echo'<p>'
        .mb_strimwidth($st,0,150,' ...')
        .'</p>';
        else the_content();
        }?>
        </div>
        <div class="info"><span class="comm">发布：<?php the_time('Y-m-d') ?></span><span class="comm">分类：<?php the_category('、') ?></span><span class="comm">阅读：<?php post_views('','次'); ?></span><span class="comm">评论：<?php comments_popup_link ('无评论','1条评论','%条评论'); ?></span><a href="<?php the_permalink() ?>" rel="bookmark" title="详细阅读：<?php the_title_attribute(); ?>"><span class="readmore">阅读全文</a></span></div>
        <div class="clear"></div>
      </div>
    </li>
  </ul><div class="clear"></div>
  <?php endwhile; else: ?>
  <ul><li>
  <div class="article">
<h3 style="padding: 15px;">非常抱歉，无法搜索到与之相匹配的信息。</h3>
</div>
  </li>
		</ul>
  <?php endif; ?>
  <div class="navigation">
    <?php pagination($query_string); ?>
  </div>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
