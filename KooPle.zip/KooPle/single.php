<?php get_header(); ?>
<div id="roll"><div title="回到顶部" id="roll_top"></div><div title="查看评论" id="ct"></div><div title="转到底部" id="fall"></div></div>
<div id="content">
<div class="main">
<div id="map">
<div class="site">当前位置：<a title="返回首页" href="<?php echo get_settings('Home'); ?>/">首页</a> &gt; <?php the_category('、') ?> &gt; 正文</div>
</div>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="article">
<div class="article_head">
<div class="author_pic"><img src="<?php bloginfo('template_directory'); ?>/images/author_pic.png" /></div>
<h1><?php the_title(); ?></h1>
<div class="article_info">
    <span class="comm">作者：<?php the_author() ?></span><span class="comm">发布：<?php the_time('Y-m-d H:i') ?></span><span class="comm">分类：<?php the_category(', ') ?></span><span class="comm">阅读：<?php post_views('','次'); ?></span><span class="comm">评论：<?php comments_popup_link ('无评论','1条评论','%条评论'); ?></span><span><?php edit_post_link('编辑'); ?></span>
</div>
</div>
<div class="clear"></div>
 <div class="context entry-content">
        <?php the_content(); ?>
        <div class="article_info_bottom">本文固定链接： <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_permalink() ?></a></div>
           <div class="article_info_bottom2"><?php the_tags('标签： ', ' ', ''); ?></div>
      <?php include('includes/baidushare.php'); ?>
      <div class="pre_nex">
      <ul>
      <li style="margin-right:15px"><?php previous_post_link('上一篇：%link') ?></li>
      <li><?php next_post_link('下一篇：%link') ?></li>
      </ul></div>
      </div>
  </div>

<?php include('includes/single_related.php'); ?>

<?php comments_template(); ?>
</div>
  <?php endwhile; else: ?>
  <?php endif; ?>

<?php get_sidebar(); ?>
<?php get_footer(); ?>