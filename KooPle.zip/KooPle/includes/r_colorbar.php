		<div id="colorbar">
			<ul>
				<?php echo stripslashes(get_option('creekoo_colorbarcode')); ?>
			</ul>
		</div>