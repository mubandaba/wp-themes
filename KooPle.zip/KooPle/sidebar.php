<div id="sidebar">
<div id="sideroll">
<?php if (get_option('creekoo_colorbar') == 'Display') { ?>
<?php include(TEMPLATEPATH . '/includes/r_colorbar.php'); ?>
<?php } else {echo ''; } ?>
<?php if (get_option('creekoo_notice') == 'Display') { ?>
<div class="widget">
<h3>公告</h3>
<div class="textwidget">
<?php echo stripslashes(get_option('creekoo_notice_code')); ?>
</div></div>
<?php } else {echo ''; } ?>
</div>
<?php include('includes/r_tab.php'); ?>
<?php if (get_option('creekoo_ad_sidebar') == 'Display') { ?>
<div id="ad_sidebar"><?php echo stripslashes(get_option('creekoo_ad_sidebar_code')); ?></div>
<?php } else {echo ''; } ?> 
<?php if (get_option('creekoo_wallreaders') == 'Display') { ?>
<?php include(TEMPLATEPATH . '/includes/r_wallreaders.php'); ?>
<?php } else {echo ''; } ?>
<?php include('includes/r_comment.php'); ?>
<?php include('includes/r_tags.php'); ?>
<?php if (get_option('creekoo_r_statistics') == 'Display') { ?>
<?php include(TEMPLATEPATH . '/includes/r_statistics.php'); ?>
<?php } else {echo ''; } ?>
<?php if (get_option('creekoo_r_links') == 'Display') { ?>
<?php include(TEMPLATEPATH . '/includes/r_links.php'); ?>
<?php } else {echo ''; } ?>
<div id="rollstart"></div>
</div></div>