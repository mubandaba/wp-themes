<div class="clear"></div>
<div id="footer">
	<div id="footermain">
		<a class="footerlogo" href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>"></a>
		<?php echo stripslashes(get_option('creekoo_footerlinkcode')); ?></br><span class="comm1"><?php echo comicpress_copyright(); ?> <a href="<?php echo home_url( '/' ) ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home" target="_blank"><?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?></a></span>-<span class="comm">网站核心源自<a href="http://www.wordpress.org/" target="_blank" title="网站核心源自WordPress">WordPress</a></span>-<span class="comm">主题源自<a href="http://www.creekoo.com/" target="_blank" title="主题源自CreeKoo">CreeKoo</a></span><?php if (get_option('creekoo_beian') == 'Display') { ?>-<span class="comm"><?php echo stripslashes(get_option('creekoo_beianhao')); ?><?php } else { } ?></span><?php if (get_option('creekoo_tj') == 'Display') { ?><span class="comm"><?php echo stripslashes(get_option('creekoo_tjcode')); ?><?php } else { } ?></span>
	</div>
 </div>
<?php wp_enqueue_script('jquery'); ?>
<?php wp_footer(); ?>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/comments-ajax.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/creekoo.min.js?v1.06"></script>
</body>
</html>