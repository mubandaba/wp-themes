<div class="header_right">
                    <?php echo stripslashes(get_option('swt_ad_b')); ?>
                 </div>