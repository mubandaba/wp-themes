

<div class="widget hot_box" id="tuijian">	
	<h3>最新评论</h3>
		<div class="r_comments">
			<ul>
			<?php r_comments($outer=get_option('swt_outer')); ?>
			</ul>
		</div>

</div>