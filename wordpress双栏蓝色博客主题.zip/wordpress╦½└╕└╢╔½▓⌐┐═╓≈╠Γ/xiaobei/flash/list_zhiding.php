﻿
<div class="sticky_list">
			<ul>
			
		   			
		
			<li>
			<h2><marquee scrollamount="3" behavior="alternate" onMouseOut="this.start()" onMouseOver="this.stop()"><a href="http://www.kanhulian.com/" title="看互联网">你好，游客，小北博客欢迎你的光临！</a></marquee></h2>
			</li>

			</ul> 
			</div>