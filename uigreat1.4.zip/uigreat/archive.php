<?php get_header(); ?>

<main class="main">
	<div class="uk-container">
		<section class="card uk-margin-medium-top uk-margin-medium-bottom">
			<h3 class="uk-text-bolder"><?php single_cat_title(); ?></h3>
			<div uk-grid>
				<?php while (have_posts()) : the_post(); ?>	

				<div class="uk-width-1-1@s uk-width-1-4@m uk-width-1-4@l uk-width-1-4@xl">
					<?php include(TEMPLATEPATH . '/extends/sitenav/loop/card.php'); ?>
				</div>
				<?php endwhile; ?> 

			</div>
		</section>
	</div>
</main>
<?php get_footer(); ?>
