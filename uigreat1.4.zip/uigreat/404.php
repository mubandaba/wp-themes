<?php get_header();?>

<section class="uk-flex uk-flex-middle">
	<div class="uk-container">
		<div class=" uk-text-center uk-padding">

			<h1 class="uk-text-bolder">404</h1>
			<p class="uk-text-muted uk-h4 uk-margin-bottom uk-margin-remove-top">Sorry，页面丢失了，要不返回首页吧？</p>
			<p class="uk-light uk-margin-large-bottom">
				<a href="<?php bloginfo('url'); ?>" target="_blank" class="btn b-r-4 uk-display-inline-block"> 返回首页<i class="iconfont icon-resonserate-fill"></i></a>
			</p>
		</div>

	</div>
</section>

<?php get_footer(); ?>