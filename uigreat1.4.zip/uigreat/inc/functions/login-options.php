<?php

/*
 * ------------------------------------------------------------------------------
 * 登录成功后跳转到首页
 * ------------------------------------------------------------------------------
 */
function login_redirect( $redirect_to, $request, $user ){
	global $user;
	if ( isset( $user->roles ) && is_array( $user->roles ) ) {
		//如果登录用户是订阅者 或 投稿者 或 作者 的身份
		if ( in_array( 'subscriber', $user->roles ) || in_array( 'contributor', $user->roles ) || in_array( 'author', $user->roles ) ) {
			return home_url(); //指向首页
		} else {
			return admin_url(); //指向后台管理
		}
	}
	return;;
}
add_filter( 'login_redirect', 'login_redirect', 10, 3 );


/*
 * ------------------------------------------------------------------------------
 * 退出登录返回首页
 * ------------------------------------------------------------------------------
 */

function logout_page() {
  $login_page  = home_url( '/' );
  wp_redirect( $login_page . "?login=false" );
  exit;
}
add_action('wp_logout','logout_page');
