<?php 
get_header();
$home_gg = _ug('home_gg'); 
?>
<main class="uk-position-relative uk-position-z-index">
	<?php 
	get_template_part( 'template-parts/home', 'slide' );
	get_template_part( 'template-parts/home', 'list' );
    get_template_part( 'template-parts/home', 'new' );
	get_template_part( 'template-parts/home', 'card' );
	?>
	
	<?php 
	if (is_array($home_gg) ) : 
	if( $home_gg['show'] != 0){
	?>
	
	<section class="uk-container uk-margin-medium-top uk-margin-medium-bottom">
		<a href="<?php echo $home_gg['url'];?>" target="_blank" >
			<img src="<?php echo $home_gg['img'];?>" />	
		</a>
	</section>
	<?php } endif; ?>
	
</main>
<?php get_footer();?>