<?php if( _ug('show_list') == true ) { ?>
<section class="uk-container uk-margin-medium-bottom">
	<div uk-grid>
		<div class="uk-width-1-1@s uk-width-1-2@m uk-width-1-2@l uk-width-1-2@xl">
			<div class="index-list uk-background-default uk-padding-small">
				<?php 
				$list_01 = _ug('list_01');
				if (is_array($list_01)):
				?>
				<div class="title b-b uk-flex uk-flex-middle">
					<div class="uk-flex uk-margin-small-right">
						<div class="dotted1"></div>
						<div class="dotted2"></div>
					</div>
					<div class="uk-flex-1">
						<span class="uk-text-bolder"><?php echo $list_01['title']; ?></span>
					</div>
					<a href="" target="_blank" class="uk-text-small uk-text-muted">更多+</a>
				</div>
				<ul class="uk-list">
					<?php query_posts('cat='.$list_01['cat_id'].'&showposts='.$list_01['num']); ?>
					<?php while (have_posts()) : the_post(); ?>
					<li class="uk-flex uk-flex-middle">
						<div class="uk-flex-1 uk-flex uk-flex-middle">
							<span class="uk-display-inline-block uk-margin-small-right uk-text-muted">[<?php the_time('n-j'); ?>]</span>
							<a href="<?php the_permalink(); ?>" target="_blank" class="uk-display-inline-block uk-text-truncate"><?php the_title(); ?></a>
						</div>
						<span class="uk-text-small"><?php $category = get_the_category();echo $category[0]->cat_name;?></span>
					</li>
					<?php endwhile; wp_reset_query(); ?>
				</ul>
				<?php endif; ?>
				
			</div>
		</div>
		<div class="uk-width-1-1@s uk-width-1-2@m uk-width-1-2@l uk-width-1-2@xl">
			<div class="index-list uk-background-default uk-padding-small">
				<?php 
				$list_02 = _ug('list_02');
				if (is_array($list_02)):
				?>
				<div class="title b-b uk-flex uk-flex-middle">
					<div class="uk-flex uk-margin-small-right">
						<div class="dotted1"></div>
						<div class="dotted2"></div>
					</div>
					<div class="uk-flex-1">
						<span class="uk-text-bolder"><?php echo $list_02['title']; ?></span>
					</div>
					<a href="" target="_blank" class="uk-text-small uk-text-muted">更多+</a>
				</div>
				<ul class="uk-list">
					<?php query_posts('cat='.$list_02['cat_id'].'&showposts='.$list_02['num']); ?>
					<?php while (have_posts()) : the_post(); ?>
					<li class="uk-flex uk-flex-middle">
						<div class="uk-flex-1 uk-flex uk-flex-middle">
							<span class="uk-display-inline-block uk-margin-small-right uk-text-muted">[<?php the_time('n-j'); ?>]</span>
							<a href="<?php the_permalink(); ?>" target="_blank" class="uk-display-inline-block uk-text-truncate"><?php the_title(); ?></a>
						</div>
						<span class="uk-text-small"><?php $category = get_the_category();echo $category[0]->cat_name;?></span>
					</li>
					<?php endwhile; wp_reset_query(); ?>
				</ul>
				<?php endif; ?>
				
			</div>
		</div>
	</div>
</section>
<?php }else {} ?>