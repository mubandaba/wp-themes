<?php
/**
 * 主题激活时，默认创建文章或页面
 *
 * 传入一个二维数组, 可插入多个页面:
 * $new_pages = array( array('title'=>'页面标题','slug'=>'页面url名称','page_template'=>'读取模板文件名','content'=>'预设内容') )
 *参数$title 字符串 页面标题
 *参数$slug  字符串 页面别名
 *参数$page_template 字符串  模板名
 *无返回值
 **/

class WBDefPage
{

	private $new_pages;

    public function __construct($new_pages = array( array('title'=>'WBolt 示例页面','slug'=>'wb_def_page','page_template'=>'','content'=>'感谢使用闪电博产品！') ))
    {
	    $this->new_pages = $new_pages;

	    $this->wb_active_pages();
    }

	private function wb_active_pages() {
		add_action( 'load-themes.php', array($this,'theme_init') );
	}

	public function theme_init(){
        global $pagenow;

        if ( 'themes.php' == $pagenow && isset( $_GET['activated'] ) && isset($this->new_pages)){
            foreach ( $this->new_pages as $new_page ) {
                $this->wb_add_page($new_page['title'], $new_page['slug'], $new_page['page_template'], $new_page['content']);
            }
        }
    }

	private function wb_add_page($title, $slug, $template='', $content=''){
		$allPages = get_pages();
		$exists = false;

		foreach( $allPages as $page ){
			if( strtolower( $page->post_name ) == strtolower( $slug ) ){
				$exists = true;
			}
		}

		if( $exists == false ) {
			$new_page_id = wp_insert_post(
				array(
					'post_title' => $title,
					'post_type'     => 'page',
					'post_name'  => $slug,
					'comment_status' => 'closed',
					'ping_status' => 'closed',
					'post_content' => $content,
					'post_status' => 'publish',
					'post_author' => 1,
					'menu_order' => 0
				)
			);

			if($new_page_id && $template!=''){
				update_post_meta($new_page_id, '_wp_page_template',  $template);
			}
		}
	}

}

$def_add_pages = array(
	array(
		'title' => __('newest','wbolt'),
		'slug' => 'allposts',
		'page_template' => 'page_allposts.php',
		'content' => 'WBolt自定义 最新更新列表页，详情内容将会由主题模板页定义'
	)
);

new WBDefPage($def_add_pages);


