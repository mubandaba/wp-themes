WB.WBGallery = {
    galleryWithThumbs: function() {
        var $gt = $('#gallery-thumbs'),
            $gti = $gt.find('.gt-item'),
            $lgImg = $('#J_pdPic'),
            navH = $gti.height() + 10,
            itemTotal = $gt.length,
            // itl = parseInt(itemTotal / 5), //分组数量
            curScrollIndex = 0,
            anmt = 300;

        //初始化
        $gti.eq(0).hasClass('portrait') && $('#J_pdPicWp').addClass('portrait');
        $lgImg.attr('src', $gti.eq(0).find('img').attr('data-large-src'));
        $lgImg.attr('srcset', $gti.eq(0).find('img').attr('srcset'));

        $gti.on('click', function () {
            var lgSrc = $(this).find('img').attr('data-large-src'),
                lgDataSrc = $(this).find('img').attr('srcset'),
                $pdImgWp = $('#J_pdPicWp'),
                _portrait = $(this).hasClass('portrait'),
                _thisIndex = $(this).index();

            // $pdImgWp.html('');
            // $pdImgWp.addClass('loading-img').append($lgImg.clone());

            $gti.removeClass('current');
            $(this).addClass('current');

            $lgImg.attr('src', lgSrc);
            $lgImg.attr('srcset', lgDataSrc);

            $pdImgWp[ _portrait ? 'addClass' : 'removeClass']('portrait');

            // $lgImg.load(function () {
            //     $pdImgWp.removeClass('loading-img');
            //     $pdImgWp.html('');
            // });


            curScrollIndex = WB.WBGallery.getScrollIndex($gt,navH);
            // console.log('curScrollIndex: ' + curScrollIndex);
            // console.log('_thisIndex: ' + _thisIndex);
            if(curScrollIndex + 4 <= _thisIndex){
                curScrollIndex ++;
                $gt.animate({scrollTop:(navH * curScrollIndex)}, anmt);
            }

            if(curScrollIndex > 0 && (_thisIndex == curScrollIndex)){
                curScrollIndex --;
                $gt.animate({scrollTop:(navH * curScrollIndex)}, anmt);
            }

        });

        $gt.on('scroll',function () {
            WB.lazyLoad($('[data-src]'));
            curScrollIndex = WB.WBGallery.getScrollIndex($gt,navH);
        });

    },

    getScrollIndex: function ($obj,wph) {
        var scroll = $obj.scrollTop();
        return parseInt(scroll / wph);
    },

    galleryViewDetail: function(obj){
        var $obj = obj || $('#J_pdPic'),
            $lgImg = $('#J_pvImg');

        $('.zoom-badge').on('click',function () {
            var imgSrc = $obj.attr('src'),
                _portrait = $('#J_pdPicWp').hasClass('portrait');
            // imgSrcSet = $obj.attr('srcset');

            $lgImg.attr('src',imgSrc);
            // $lgImg.attr('srcset',imgSrcSet);
            $('#J_pvGalleryThumbs').append($('#gallery-thumbs').html());
            $lgImg[ _portrait ? 'addClass' : 'removeClass']('portrait');

            $('#J_photoViewer').show();
        });

        $('body').on('click','#J_pvGalleryThumbs .gt-item',function () {
            var lgSrc = $(this).find('img').attr('data-large-src'),
                lgSrcSet = $(this).find('img').attr('srcset'),
                _portrait = $(this).hasClass('portrait');

            $(this).addClass('current').siblings().removeClass('current');

            $lgImg.attr('src',lgSrc);
            // $lgImg.attr('srcset',lgSrcSet);
            $lgImg[ _portrait ? 'addClass' : 'removeClass']('portrait');
        });

        $('body').on('click','#J_pvCloseBtn,#J_pvMask',function () {
            $('#J_photoViewer').hide();
            $('#J_pvGalleryThumbs').html('');
        });

        var lastClientX,
            lastClientY,
            pushed = 0;

        $('#J_pvGalleryThumbs').on('mousedown','.gallery-wrapper-thumbs', function () {
            pushed = 1;
            lastClientX = e.clientX;
            lastClientY = e.clientY;

            e.preventDefault();
            e.stopPropagation();
        });

        $('#J_pvGalleryThumbs').on('mousemove','.gallery-wrapper-thumbs', function () {
            if (pushed) {
                obj.scrollLeft -=
                    (- lastClientX + (lastClientX=e.clientX));
                obj.scrollTop -=
                    (- lastClientY + (lastClientY=e.clientY));
            }
        });

        $('#J_pvGalleryThumbs').on('mouseup','.gallery-wrapper-thumbs', function () {
            pushed = 0;

        });
    }
};

jQuery(function ($) {
    WB.WBGallery.galleryWithThumbs();

    $('#gallery-main').length && WB.WBGallery.galleryViewDetail();
});