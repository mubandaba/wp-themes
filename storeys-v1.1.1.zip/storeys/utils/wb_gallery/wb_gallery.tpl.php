<?php
if($image_ids){

	$photos = '[gallery size="full" ids="'.implode(',',$image_ids).'"]';
	?>
    <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" overflow="hidden" style="position:absolute;width:0;height:0">
        <defs>
            <symbol id="wbsico-zoom" viewBox="0 0 16 16">
                <path d="M12.66 11.24a6.81 6.81 0 0 0 1.4-4.18A7 7 0 0 0 7.1 0a7.06 7.06 0 1 0 0 14.12 6.57 6.57 0 0 0 4.17-1.4l2.99 2.99a.96.96 0 0 0 1.39 0 .96.96 0 0 0 0-1.4zm-5.56.8a5.01 5.01 0 0 1-5.08-4.98 5.07 5.07 0 0 1 10.15 0 5.01 5.01 0 0 1-5.07 4.98z" fill-rule="evenodd"/>
            </symbol>
            <symbol id="wbsico-loading" viewBox="0 0 200 200" preserveAspectRatio="xMinYMin meet">
                <defs>
                    <linearGradient id="spinner" x1="0%" y1="0%" x2="65%" y2="0%">
                        <stop offset="0%" stop-color="#fff"></stop>
                        <stop offset="100%" stop-opacity="0" stop-color="#fff"></stop>
                    </linearGradient>
                </defs>
                <circle cx="100" cy="100" r="90" fill="transparent" stroke="url(#spinner)" stroke-width="20"></circle>
            </symbol>
        </defs>
    </svg>
	<div class="gallery-panel" id="gallery-main">
        <div class="gallery-wrapper">
            <div class="wb-loading">
				<?php echo wbolt_svg_icon('wbsico-loading'); ?>
            </div>
            <figure class="swiper-slide">
                <img class="j-pdpic" src="<?php echo get_template_directory_uri() . '/images/wbolt_def_cover.png'; ?>" sizes="(max-width: 768px) calc(100vw - 40px), (max-width: 1200px) 488px, (max-width: 1366px) 670px, 768px" alt="">
            </figure>
            <a class="zoom-badge"><?php echo wbolt_svg_icon('wbsico-zoom'); ?></a>
        </div>

		<?php
		echo do_shortcode( $photos );
		?>
	</div>
	<div class="photo-viewer" id="J_photoViewer" style="display: none;">
		<a class="pv-close" id="J_pvCloseBtn"><svg class="sico"><use xlink:href="#wbsico-close"></use></svg></a>
		<div class="pv-gallery-thumbs" id="J_pvGalleryThumbs"></div>

		<img class="pv-img" id="J_pvImg" sizes="90%">

		<div class="pv-mask" id="J_pvMask"></div>

        <div class="wb-loading">
			<?php echo wbolt_svg_icon('wbsico-loading'); ?>
        </div>
	</div>
<?php } ?>