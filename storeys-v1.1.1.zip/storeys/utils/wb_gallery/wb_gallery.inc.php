<?php
/**
 * 自定义相册 - 抽离文章详情内的所有图片整合成相册
 *
 **/

class WBGallery
{

    public function __construct()
    {
	    add_shortcode('gallery', array($this,'wb_gallery_shortcode'));
	    add_shortcode( 'wb_gallery', array($this,'wb_gallery'));
    }

    public function wb_gallery(){
	    add_filter('the_content', array($this,'wb_gallery_content'));
    }

	public function wb_gallery_content(){
		global $post;

		if(!is_single())return '';

		$image_ids = array();
		$content = $post->post_content;
		$img_length = 0;

		$content_org = $content = wpautop( $content );

		if(preg_match_all('#<img[^>]+>#is',$post->post_content,$match)){

			foreach ($match[0] as $img){
				preg_match('#width="(\w+)#',$img,$n);

				if(isset($n[1]) && $n[1] > 400 && preg_match('#wp-image-(\w+)#',$img,$m)){
					$image_ids[] = $m[1];
					$content = str_replace($img,'',$content);

					$img_length++;
				}
			}
		}
		if($img_length < 2) return $content_org;

		$image_ids = array_unique($image_ids);

		ob_start();
		include 'wb_gallery.tpl.php';
		$html = ob_get_clean();

		$content = $html . $content;
		return $content;
	}

	public function wb_gallery_shortcode( $attr ) {
		$post = get_post();

		static $instance = 0;
		$instance++;

		if ( ! empty( $attr['ids'] ) ) {
			// 'ids' is explicitly ordered, unless you specify otherwise.
			if ( empty( $attr['orderby'] ) ) {
				$attr['orderby'] = 'post__in';
			}
			$attr['include'] = $attr['ids'];
		}

		/**
		 * Filters the default gallery shortcode output.
		 *
		 * If the filtered output isn't empty, it will be used instead of generating
		 * the default gallery template.
		 *
		 * @since 2.5.0
		 * @since 4.2.0 The `$instance` parameter was added.
		 *
		 * @see gallery_shortcode()
		 *
		 * @param string $output   The gallery output. Default empty.
		 * @param array  $attr     Attributes of the gallery shortcode.
		 * @param int    $instance Unique numeric ID of this gallery shortcode instance.
		 */
		$output = apply_filters( 'post_gallery', '', $attr, $instance );
		if ( $output != '' ) {
			return $output;
		}

		$html5 = current_theme_supports( 'html5', 'gallery' );
		$atts = shortcode_atts( array(
			'order'      => 'ASC',
			'orderby'    => 'menu_order ID',
			'id'         => $post ? $post->ID : 0,
			'itemtag'    => $html5 ? 'figure'     : 'dl',
			'icontag'    => $html5 ? 'div'        : 'dt',
			'captiontag' => $html5 ? 'figcaption' : 'dd',
			'columns'    => 3,
			'size'       => 'thumbnail',
			'include'    => '',
			'exclude'    => '',
			'link'       => ''
		), $attr, 'gallery' );

		$id = intval( $atts['id'] );

		if ( ! empty( $atts['include'] ) ) {
			$_attachments = get_posts( array( 'include' => $atts['include'], 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $atts['order'], 'orderby' => $atts['orderby'] ) );

			$attachments = array();
			foreach ( $_attachments as $key => $val ) {
				$attachments[$val->ID] = $_attachments[$key];
			}
		} elseif ( ! empty( $atts['exclude'] ) ) {
			$attachments = get_children( array( 'post_parent' => $id, 'exclude' => $atts['exclude'], 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $atts['order'], 'orderby' => $atts['orderby'] ) );
		} else {
			$attachments = get_children( array( 'post_parent' => $id, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $atts['order'], 'orderby' => $atts['orderby'] ) );
		}

		$gallery_thumbs = "<div class='gallery-thumbs' id='gallery-thumbs'><div class='gallery-wrapper-thumbs'>";

		$output .= $gallery_thumbs;

		$j = 0;

		$baseHPC = round((2/3),4);

		foreach ( $attachments as $id => $attachment ) {

//		$attr = ( trim( $attachment->post_excerpt ) ) ? array( 'aria-describedby' => "$selector-$id" ) : '';
//			$image_data_srcset = wp_get_attachment_image_srcset( $id, $atts['full']);
			$atts_full = isset($atts['full']) ? $atts['full'] : '';
			$image_data_src = wp_get_attachment_image_url( $id, $atts_full );

//			$attr ='data-large-srcset=' . $image_data_srcset ;
			$attr ='data-large-src=' . $image_data_src;
			$image_output = wp_get_attachment_image( $id, $size = 'thumbnail', false, $attr );
			$image_meta  = wp_get_attachment_metadata( $id, $atts_full );

			$orientation = '';
			if ( isset( $image_meta['height'], $image_meta['width'] ) ) {
				$orientation = ( round(($image_meta['height'] / $image_meta['width']),4) > $baseHPC ) ? 'portrait' : '';
			}
			$output .= "<figure class='gt-item ". $orientation . ($j==0 ? ' current':'')."'>";
			$output .= "
				$image_output
        </figure>";

			$j++;
		}


		$output .= "
	        </div>\n
	    </div>\n";

		return $output;
	}
}

new WBGallery();


