<?php

/**
 *
 *
 */

class WBTDP
{
    function __construct()
    {
	    function wb_query_posts_id($arg){
		    global $wpdb;

		    $pid_list = get_option('_category_childs',array());
		    //print_r($pid_list);
		    $sql = "SELECT DISTINCT p.ID FROM $wpdb->posts p";
		    $where = array();
		    $group = array();
		    if($arg['cat']){
			    if(!is_array($arg['cat']))$arg['cat'] = explode(',',$arg['cat']);
			    $cids = array();
			    foreach($arg['cat'] as $cid){
				    $cids[] = $cid;
				    if(isset($pid_list[$cid]) && $pid_list[$cid]){
					    $cids = array_merge($cids,$pid_list[$cid]);
				    }
			    }
			    $sql .= ",$wpdb->term_relationships r";

			    $where[] = "p.ID=r.object_id";
			    $where[] = " r.term_taxonomy_id IN(".implode(',',$cids).")";
			    $group[] = "p.ID";
		    }

		    if($arg['meta_key']){
			    $sql .= ",$wpdb->postmeta m";
			    $where[] = "p.ID=m.post_id";
			    $where[] = $wpdb->prepare("m.meta_key=%s",$arg['meta_key']);
		    }

		    $query = $sql.' WHERE 1=1 AND '.implode(' AND ',$where);

		    if($arg['orderby']){
			    switch ($arg['orderby']){
				    case 'hot_rand':
					    //$query .= ' ORDER BY '
					    $query = "SELECT * FROM ($query ORDER BY m.meta_value+0 DESC LIMIT 200) tmp ORDER  BY RAND()";
					    break;
			    }
		    }
		    if($arg['num']){
			    $query .= ' LIMIT  '.$arg['num'];
		    }
		    //echo $query;
		    return $wpdb->get_col($query);
	    }
    }


}

new WBTDP();