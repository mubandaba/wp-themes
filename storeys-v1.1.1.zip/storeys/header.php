<?php
/**
 * The template for displaying the header
 *
 * @package WordPress
 * @subpackage Storeys
 * @since Wbolt 1.0
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php endif; ?>
	<?php wp_head(); ?>

    <?php if(wb_opt('favicon')): ?>
<link rel="shortcut icon" href="<?php echo wb_opt('favicon'); ?>" />
    <?php endif; ?>

    <script>
		<?php
		echo wbolt_js_config();
		echo do_shortcode('[wb_opt_value]');
		?>
    </script>
	<?php echo do_shortcode('[wb_custom_header_code]'); ?>
</head>

<body <?php body_class()?>>
<header class="header<?php if(isset($GLOBALS['custom-header']) && $GLOBALS['custom-header']) echo ' '.$GLOBALS['custom-header']; ?>">
    <div class="inner pw">
        <?php echo (is_front_page() && is_home()) ? '<h1 ' : '<div '; echo 'class="logo">'; ?>
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                    <?php if(wb_opt('logo_url')):
                        $logo_2 = wb_opt('logo_url_2') ? ' data-logo="' .wb_opt('logo_url_2') . '"' : '';
                        echo '<img src="'. wb_opt('logo_url'). '"' . $logo_2 .' alt="'.get_bloginfo( 'name' ).'"/>';
                    else:
	                    echo '<strong>'.get_bloginfo( 'name' ).'</strong>';
                    endif; ?>
                </a>
        <?php echo (is_front_page() && is_home()) ? '</h1>' : '</div>'; ?>

        <?php if(wp_is_mobile()): ?>
            <nav class="nav-top-m" id="J_navBar">
	            <?php get_search_form(); ?>
                <?php
                if ( has_nav_menu( 'primary' ) ){
	                wp_nav_menu( array(
		                'theme_location' => 'primary',
		                'menu_class'     => 'nav-m',
		                'menu_id'     => 'J_topNavMb',
		                'container'     => '',
		                'walker' => new Wbolt_Walker_Nav_Menu_m()
	                ) );
                }
                ?>

                <a class="btn-close" id="J_closeNav"><?php echo wbolt_svg_icon('wbsico-close'); ?></a>
            </nav>
            <a class="btn-search-m" id="J_btnSearchMb"><?php echo wbolt_svg_icon('wbsico-search'); ?></a>
            <a class="btn-nav" id="J_btnNavMb"><i><?php _e( 'Menu Explicit/Hidden', 'wbolt' ); ?></i></a>

        <?php elseif ( has_nav_menu( 'primary' ) ) : ?>
            <nav class="nav-top cf" id="J_navBar">
                <?php
                wp_nav_menu( array(
                    'theme_location' => 'primary',
                    'menu_class'     => 'nav',
                    'menu_id'     => 'J_topNav',
                    'container'     => '',
                    'walker' => new Wbolt_Walker_Nav_Menu()
                ) );

                ?>
            </nav>
        <?php endif; ?>

        <div class="top-links">
            <a class="link link-search" id="J_topSearchBtn"><?php echo wbolt_svg_icon('wbsico-search'); ?></a>
	    <?php if(!is_user_logged_in()): ?>
            <a class="link link-login user-login" data-sign="0" id="user-login" href="<?php echo wp_login_url($_SERVER['REQUEST_URI']);?>"><?php _e( 'Sign in', 'wbolt' ); ?></a>
            <a class="link link-reg" id="user-reg" href="<?php echo wp_registration_url();?>"><?php _e( 'Register', 'wbolt' ); ?></a>
	    <?php else: ?>
            <span class="user-cover" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php global $current_user; echo get_avatar( $current_user->user_email, 32);?></span>
            <span class="user-name">Hi <?php echo $current_user->display_name; ?></span>
        <?php endif; ?>
        </div>
    </div>

    <div class="search-top-bar" id="J_topSearchBar">
        <form class="search-form" id="J_searchformTop" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">
            <button type="button" class="btn-search" id="J_searchsubmitTop"><?php echo wbolt_svg_icon('wbsico-search'); ?></button>
            <input type="text" class="form-control" name="s" id="J_sTop" placeholder="<?php esc_attr_e( 'Search…', 'wbolt' ); ?>" />
        </form>
    </div>
</header>

<div class="container<?php if(isset($GLOBALS['container-custom']) && $GLOBALS['container-custom']) echo ' '.$GLOBALS['container-custom']; ?>">