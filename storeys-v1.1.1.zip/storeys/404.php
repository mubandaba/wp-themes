<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package WordPress
 * @subpackage Storeys
 * @since Wbolt 1.0
 */
$GLOBALS['container-custom'] = 'container-nodata';

get_header(); ?>

<div class="main">
    <div class="content-empty">
        <div class="content-inner">
            <p class="sico-404">
                <svg xmlns="http://www.w3.org/2000/svg" width="62" height="62"><path fill="#E1CD64" fill-rule="evenodd" d="M43 28a5 5 0 1 1 .01-10.01A5 5 0 0 1 43 28m0 12h-3v5a5 5 0 0 1-10 0v-5H19a1 1 0 1 1 0-2h24a1 1 0 1 1 0 2M14 23a5 5 0 1 1 10.01.01A5 5 0 0 1 14 23M31 0C13.9 0 0 13.9 0 31s13.9 31 31 31 31-13.9 31-31S48.1 0 31 0"/></svg></p>
            </p>
            <p class="cont-code">404</p>
            <p><?php _e('Sorry, We can\'t find the page you\'re looking for.','wbolt'); ?></p>
            <form class="search-form" id="searchform-b" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">
                <button type="button" class="btn-search" id="searchsubmit-b"><?php echo wbolt_svg_icon('wbsico-search'); ?></button>
                <input type="text" class="form-control" name="s" id="s" placeholder="<?php esc_attr_e( 'Search', 'wbolt' ); ?>" />
            </form>
        </div>
    </div>
</div>
<?php get_footer(); ?>

