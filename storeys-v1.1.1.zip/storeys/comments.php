<?php
/**
 * The template for displaying comments
 *
 * The area of the page that contains both current comments
 * and the comment form.
 *
 * @package WordPress
 * @subpackage Storeys
 * @since Wbolt 1.0
 */

if ( post_password_required() ) {
	return;
}
?>

<section class="panel-inner sc-comments pw">
    <h3 class="sc-title"><?php _e('Comments','wbolt'); ?></h3>
	<?php
	// If comments are closed and there are comments, let's leave a little note, shall we?
	if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) :
		?>
        <p class="no-comments"><?php _e( 'Comments are closed.', 'wbolt' ); ?></p>
	<?php endif; ?>

    <div id="comments">
	<?php
	$commenter = wp_get_current_commenter();
	$req = get_option( 'require_name_email' );
	$aria_req = ( $req ? " aria-required='true'" : '' );
	$post_id = get_the_ID();
	$fields =  array(
		'author' => '<label class="form-item">
                <input class="form-control" id="author" name="author" value="" size="30"' . $aria_req . ' placeholder="'.__( 'Name', 'wbolt').' *" />
        </label> ' ,
		'email' => '<label class="form-item">
                <input class="form-control" id="email" name="email" type="email" value="" size="30"' . $req . ' placeholder="'.__( 'Email', 'wbolt').' *" />
        </label> ',
		'url' => '<label class="form-item">
                <input class="form-control" id="url" name="url" type="email" value="" size="30"' . ' placeholder="'.__( 'Website', 'wbolt').'" />
        </label> '
	);

	$comments_args = array(
		'fields' =>  $fields,
		'comment_field' => '<textarea
                                class="textarea-comments"
                                id="comment" name="comment"
                                aria-required="true"
                                required="required"
                                placeholder="'.__( 'Comment', 'wbolt' ) .' *"></textarea>',
		'title_reply' => null,
		'comment_notes_before' => null,
		'submit_button'        => '<button class="wb-btn btn-primary" id="%2$s" name="%1$s" type="submit" />' . __('Submit','wbolt') . '</button>',
		'submit_field'         => '<p class="form-item btn-bar">%1$s %2$s</p>',
		'must_log_in'          => '<p class="must-log-in">' . sprintf(
			/* translators: %s: login URL */
				__( 'You must be <a href="%s">logged in</a> to post a comment.' ),
				wp_login_url( apply_filters( 'the_permalink', get_permalink( $post_id ), $post_id ) )
			) . '</p>',
		'logged_in_as'=> '<p class="logged-in-as">' . sprintf(
			/* translators: 1: edit user link, 2: accessibility text, 3: user name, 4: logout URL */
				__( '<a href="%1$s" aria-label="%2$s">Logged in as %3$s</a>. <a href="%4$s">Log out?</a>'),
				get_edit_user_link(),
				esc_attr( sprintf( __( 'Logged in as %s. Edit your profile.' ), $user_identity ) ),
				$user_identity,
				wp_logout_url( apply_filters( 'the_permalink', get_permalink( $post_id ), $post_id ) )
			) . '</p>',

	);

	comment_form($comments_args);
	?>
    </div>

	<?php if(get_comments_number() != '0'): ?>
        <h4 class="title-comments"><?php _e('Comment List','wbolt'); ?>(<?php echo get_comments_number(); ?>)</h4>
        <ul class="list-comments">
			<?php function wbolt_comment($comment, $args, $depth){
			$GLOBALS['comment'] = $comment; ?>
            <li class="comment-item" id="li-comment-<?php comment_ID(); ?>">
	            <?php if (function_exists('get_avatar') && get_option('show_avatars')) { echo '<div class="media-pic">' .get_avatar($comment, 48) . '</div>'; } ?>
                <div class="media-body" id="comment-<?php comment_ID(); ?>">
                    <div class="comment-txt">
                        <div class="hd">
                            <p class="name"><?php printf(__('<cite class="fn">%s</cite>','wbolt'), get_comment_author_link()); ?></p>
                            <p class="date"><?php echo get_comment_time('Y.n.j H:m'); ?></p>
                        </div>

                        <div class="bd">
							<?php if ($comment->comment_approved == '0') : ?>
                                <span><?php _e( 'Comment is being reviewed.', 'wbolt' ); ?></span><br />
							<?php else : ?>
								<?php comment_text(); ?>
							<?php endif; ?>

							<?php comment_reply_link(array_merge( $args, array('reply_text' => __( 'Reply', 'wbolt' ),'depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
                        </div>
                    </div>
                </div>
				<?php } ?>
				<?php
				wp_list_comments( array(
					'type'       => 'comment',
					'reverse_top_level' => true,
					'callback'  => 'wbolt_comment',
					'max_depth' => 2
				) );
				?>
        </ul>

		<?php the_comments_navigation(); ?>
	<?php endif; ?>
</section>