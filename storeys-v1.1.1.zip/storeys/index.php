<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Storeys
 * @since Wbolt 1.0
 */

$GLOBALS['container-custom'] = 'container-index';
if(!wp_is_mobile()) $GLOBALS['custom-header'] = 'header-b';
$showposts = wp_is_mobile() ? 4 : 12;

add_action('wp_footer', 'insert_footer');

function insert_footer()
{
	wp_enqueue_script('index-js', get_template_directory_uri() . '/js/index.js', array('jquery'));
}

get_header(); ?>
<?php
$custom_banner = wb_opt('banner_url');
$is_video_banner = $custom_banner && preg_match('/.mp4$/',$custom_banner);

?>
<div class="banner-panel">
    <div class="swiper-wrapper">
        <div class="item search-box"
	        <?php if($custom_banner && !$is_video_banner){
	            echo ' style="background-image: url(' . $custom_banner .'); background-size:cover; "';
	        }
            elseif( $is_video_banner ){
	            echo ' style="background-image:none;"';
	        }else{
	            echo ' style="background-color:#9dc2f9;"';
            }
	        ?>
        >
            <div class="inner">
	            <?php get_search_form(); ?>
            </div>

	        <?php
	        if($is_video_banner):
		        ?>
                <video src="<?php echo $custom_banner; ?>" preload="auto" loop="loop" autoplay="autoplay" muted></video>
	        <?php endif; ?>
        </div>
    </div>
</div>

<div class="tab-navs" id="J_indexTabNav">
    <a class="tab-nav" data-index="0"><?php _ex('Featured', 'index tabs', 'wbolt'); ?></a>
    <a class="tab-nav current" data-index="1"><?php _e('Latest','wbolt'); ?></a>
    <a class="tab-nav" data-index="2"><?php _e('Popular','wbolt'); ?></a>
</div>

<div class="index-main pw">
	<?php echo WBOptions::insertAdBlock('index_block','adbanner-block under-list-title'); ?>

    <div class="tab-conts" id="J_indexTabCont">
        <div class="tab-cont">
            <div class="articles-list">
				<?php
				$arg = array(
					'ignore_sticky_posts'=>true,
					'showposts'=>$showposts,
					'date_query'=>array('after'=>date('Y-m-d',strtotime('-1 month'))),
					'orderby'=>'meta_value_num',
					'meta_key'=>'post_views_count',
					'order'=>'DESC'
				);

				query_posts($arg);
				?>

				<?php while (have_posts()) : the_post();
					get_template_part( 'template-parts/content', get_post_format() );
				endwhile; ?>
            </div>

            <a class="btn-load-more" href="/allposts?type=featured"><span><?php _e('More','wbolt'); ?></span><i></i></a>
        </div>

        <div class="tab-cont current">
            <div class="articles-list">
				<?php
				$arg = array('ignore_sticky_posts'=>true, 'showposts'=>$showposts,'post_type'=>'post', 'orderby'=>'post_date');//'category__not_in'=>explode(',',$homeFlID),
				query_posts($arg);

				$GLOBALS['ref'] = '';
				?>

				<?php while (have_posts()) : the_post();
					get_template_part( 'template-parts/content', get_post_format() );
				endwhile; ?>
            </div>

            <a class="btn-load-more" href="/allposts?type=latest"><span><?php _e('More','wbolt'); ?></span><i></i></a>
        </div>

        <div class="tab-cont">
            <div class="articles-list">
				<?php
				$arg = array(
					'ignore_sticky_posts'=>true,
					'showposts'=>$showposts,
					'date_query'=>array('after'=>date('Y-m-d',strtotime('-1 year'))),
					'orderby'=>'meta_value_num',
					'meta_key'=>'post_views_count',
					'order'=>'DESC'
				);

				query_posts($arg); ?>

				<?php while (have_posts()) : the_post();
					get_template_part( 'template-parts/content', get_post_format() );
				endwhile;

				?>
            </div>
            <a class="btn-load-more" href="/allposts?type=popular"><span><?php _e('More','wbolt'); ?></span><i></i></a>
        </div>
    </div>

	<?php
	$homeFlID = wb_opt('flID')?wb_opt('flID'):'';

	if( $homeFlID != ''):
        function index_terms_clauses($c,$o,$a){
            if($a['orderby'] && $a['orderby']!='none' && preg_match('#\d+,#',$a['orderby'])){
                $c['orderby'] = " ORDER BY FIELD( t.term_id, ".$a['orderby']." )";
                $c['order']  = ' ASC ';
            }
            return $c;
        }
        add_filter('terms_clauses','index_terms_clauses',10,3);


        $categories = get_categories(array(
                'child_of' => 0,
                'orderby' => $homeFlID,
                'order' => 'ASC',
                'hide_empty' => true,
                'include_last_update_time' => true,
                'hierarchical' => 1,
                'include' => $homeFlID,
                'number' => '',
                'pad_counts' => false)
        );

        $sticky_posts = get_option('sticky_posts');
        if(!$sticky_posts)$sticky_posts = array();
        foreach ($categories as $cat) {
            $catid = $cat->cat_ID;
            //$arg = array();
            ?>
            <div class="title-floor">
                <h3><?php echo $cat->name; ?></h3>
            </div>

            <div class="articles-list">
                <?php

                $i=0;
                if($sticky_posts){
                    query_posts(array('showposts'=>$showposts,'post__in'=>$sticky_posts,'post_type'=>'post','cat'=> $catid,'orderby'=>'post_date'));
                    while (have_posts()) : the_post();
                        $i++;
                        get_template_part( 'template-parts/content', get_post_format() );
                    endwhile;
                }

                if($i<$showposts){
                    query_posts(array('showposts'=>$showposts-$i,'post__not_in'=>$sticky_posts,'post_type'=>'post','cat'=> $catid,'orderby'=>'post_date'));
                    while (have_posts()) : the_post();
                        get_template_part( 'template-parts/content', get_post_format() );
                    endwhile;
                }
                ?>
            </div>

            <a class="btn-load-more" href="<?php echo get_category_link($catid);?>"><span><?php _e('More','wbolt'); ?></span><i></i></a>
        <?php } ?>

    <?php endif; ?>
</div>

<?php get_footer(); ?>