<?php
/**
 * The template for displaying archive pages
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * If you'd like to further customize these archive views, you may create a
 * new template file for each one. For example, tag.php (Tag archives),
 * category.php (Category archives), author.php (Author archives), etc.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Storeys
 * @since Wbolt 1.0
 */
if(!wp_is_mobile()) $GLOBALS['custom-header'] = 'header-b';
add_action('wp_footer', 'insert_footer');

function insert_footer()
{
	wp_enqueue_script('index-js', get_template_directory_uri() . '/js/list.js', array('jquery'));
}

get_header();

$have_posts = have_posts();

$custom_banner = wb_opt('banner_url');
$is_video_banner = $custom_banner && preg_match('/.mp4$/',$custom_banner);

?>

<div class="title-list"<?php if($custom_banner && !$is_video_banner) echo ' style="background-image: url(' . $custom_banner .'); background-size:cover; "';  ?>>
    <h1><?php echo single_cat_title( '', false ); ?></h1>
	<?php if ( category_description() ) : ?>
        <div class="description"><?php echo category_description(); ?></div>
	<?php endif; ?>
</div>

<div class="list-main pw">
<?php if ( $have_posts ) : ?>
	<?php echo WBOptions::insertAdBlock('list_block','adbanner-block under-list-title'); ?>

    <div class="articles-list" id="J_postList">
		<?php

		while ( have_posts() ) : the_post();
			get_template_part( 'template-parts/content', get_post_format() );

		endwhile;
		?>
    </div>
    <div class="loading-bar"></div>
	<?php
	wbolt_the_posts_pagination();
	?>

<?php else :
	get_template_part( 'template-parts/content-none', 'none' );

endif;
?>
</div>

<?php get_footer(); ?>
