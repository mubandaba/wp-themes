<?php
/**
 * The template part for displaying single posts
 *
 * @package WordPress
 * @subpackage Storeys
 * @since Wbolt 1.0
 */
?>

<article class="main main-detail">
    <header class="article-header">
		<?php the_title( '<h1 class="title-detail">', '</h1>' ); ?>

        <div class="post-metas">
            <a href="<?php echo get_category_link( get_article_category_ID() ); ?>" class="meta-item post-cate">
                    <?php echo wbolt_svg_icon('wbsico-circle'); ?>
                    <?php $cate = get_the_category();
                    echo '<em class="cate-tag tag-' . get_article_category_ID() . '">' . $cate[0]->cat_name . '</em>' ?>
            </a>
            <span class="meta-item meta-views">
                <?php echo wbolt_svg_icon('wbsico-views'); ?>
                <em class="meta-views"><?php echo getPostViews(get_the_ID()); ?></em>
            </span>
            <span class="meta-item meta-date">
                <?php echo wbolt_svg_icon('wbsico-time'); ?>
                <em><?php the_time('M d, Y') ?></em>
            </span>
            <span class="meta-item meta-comments primary">
                <?php echo wbolt_svg_icon('wbsico-comment'); ?>
                <em><?php comments_number( '0', '1', '%' ); ?></a></em>
            </span>

            <span class="meta-item meta-author">
                <?php echo wbolt_svg_icon('wbsico-author'); ?>
                <em><?php the_author(); ?></em>
            </span>
        </div>
    </header>

    <div class="article-detail content">
	    <?php echo WBOptions::insertAdBlock('detail_under_title'); ?>

	    <?php
	        if( wb_opt('gallery_switch') == null ) echo do_shortcode( '[wb_gallery]' );
	    ?>

		<?php
		the_content();
		?>

	    <?php echo WBOptions::insertAdBlock('detail_content_btm'); ?>
    </div>

	<?php wp_link_pages(); ?>
</article>