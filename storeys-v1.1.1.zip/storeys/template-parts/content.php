<?php
/**
 * The template part for displaying content
 *
 * @package WordPress
 * @subpackage Storeys
 * @since Wbolt 1.0
 */
?>
<?php
$baseHPC = round((2/3),4);
$img = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()),'post-thumbnail');
$hpc = $img ? round(($img[2] / $img[1]),4) : $baseHPC;
$sp_class = $hpc < $baseHPC ? ' spc' : '';
?>

<article class="post<?php echo $sp_class; ?>">
    <div class="inner">
        <a class="media-pic" href="<?php the_permalink(); ?>" target="_blank">
			<?php wbolt_post_thumbnail(); ?>
        </a>
        <div class="media-body">
            <a class="post-title" href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a>
            <div class="post-metas">
                <div class="meta-item primary post-cate">
	                <?php echo wbolt_svg_icon('wbsico-circle','sico-sm'); ?>

		            <?php
		            $cate = get_the_category();
		            foreach($cate as $key => $cateItem){
			            if($key < 4) { ?>
                            <a class="cate-tag" href="<?php echo get_category_link($cateItem->cat_ID); ?>"><?php echo $cateItem->cat_name; ?></a>
				            <?php
			            }
		            }
		            ?>
                </div>
                <span class="meta-item">
                    <?php echo wbolt_svg_icon('wbsico-time','sico-sm'); ?>
                    <em><?php postTime('Y.n.j') ?></em>
                </span>
            </div>
        </div>
    </div>
</article>
