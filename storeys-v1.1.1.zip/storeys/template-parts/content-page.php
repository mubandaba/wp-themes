<?php
/**
 * The template used for displaying page content
 *
 * @package WordPress
 * @subpackage Storeys
 * @since Wbolt 1.0
 */
?>

<article>


    <div class="article-detail">
		<?php
		the_content();
		?>
    </div>
</article>
