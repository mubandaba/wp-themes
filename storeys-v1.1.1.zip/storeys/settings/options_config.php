<?php

$pd_title = '主题设置';
$pd_name = WB_THEMES_CODE;
$pd_version = WB_THEMES_VER;
$pd_code = WB_THEMES_CODE . '-setting';
$pd_index_url = 'https://www.wbolt.com/themes/' . WB_THEMES_CODE;
$pd_doc_url = 'https://www.wbolt.com/'.WB_THEMES_CODE.'-theme-documentation.html';

?>
