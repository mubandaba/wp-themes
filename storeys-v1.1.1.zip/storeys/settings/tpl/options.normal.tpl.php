<?php /**
 * WBolt 主题基本设置
 **/
 ?>

<div class="sc-header">
    <strong>基本设置</strong>
    <span>网站基本设置</span>
</div>

<div class="sc-body">
    <table class="wbs-form-table">
        <tbody>
        <tr>
            <th class="w8em row">Logo图片</th>
            <td>
                <div id="section-logo_src" class="section section-upload">
                    <div class="wbs-upload-box">
                        <input class="wbs-input upload-input" type="text" name="<?php echo $opt_name; ?>[logo_url]" id="logo" value="<?php _opt('logo_url');?>"/>
                        <button type="button" class="wbs-btn wbs-upload-btn">
			                <?php echo wbolt_svg_icon('sico-upload'); ?>
                            <span>上传</span>
                        </button>
                    </div>

                    <p class="description">建议Logo图片高度至少68像素（包括上下留白）及不大于204像素，宽度随高度等比例显示</p>
                </div>
            </td>
        </tr>
        <tr>
            <th class="w8em row">反白Logo</th>
            <td>
                <div id="section-logo2_src" class="section section-upload">
                    <div class="wbs-upload-box">
                        <input class="wbs-input upload-input" type="text" name="<?php echo $opt_name; ?>[logo_url_2]" id="logo" value="<?php _opt('logo_url_2');?>"/>
                        <button type="button" class="wbs-btn wbs-upload-btn">
							<?php echo wbolt_svg_icon('sico-upload'); ?>
                            <span>上传</span>
                        </button>
                    </div>

                    <p class="description">选填，适用于叠加在有底色或图片banner上（如首页及列表页），建议是白色logo, 大小和"Logo图片"一致</p>
                </div>
            </td>
        </tr>

        <tr>
            <th class="row">Favicon</th>
            <td>
                <div id="section-favicon_src" class="section section-upload">
                    <div class="wbs-upload-box">
                        <input class="wbs-input upload-input" type="text" name="<?php echo $opt_name; ?>[favicon]" id="favicon" value="<?php _opt('favicon');?>"/>
                        <button type="button" class="wbs-btn wbs-upload-btn">
			                <?php echo wbolt_svg_icon('sico-upload'); ?>
                            <span>上传</span>
                        </button>
                    </div>
                </div>
            </td>
        </tr>

        <tr>
            <th class="row">默认图</th>
            <td>
                <div id="section-defimg_src" class="section section-upload">
                    <div class="wbs-upload-box">
                        <input class="wbs-input upload-input" type="text" name="<?php echo $opt_name; ?>[def_img_url]" id="defImg" value="<?php _opt('def_img_url');?>"/>
                        <button type="button" class="wbs-btn wbs-upload-btn">
			                <?php echo wbolt_svg_icon('sico-upload'); ?>
                            <span>上传</span>
                        </button>
                    </div>
                </div>
            </td>
        </tr>

        <tr>
            <th class="row">Banner背影图</th>
            <td>
                <div id="section-defimg_src" class="section section-upload">
                    <div class="wbs-upload-box">
                        <input class="wbs-input upload-input" type="text" name="<?php echo $opt_name; ?>[banner_url]" id="bannerImg" value="<?php _opt('banner_url');?>"/>
                        <button type="button" class="wbs-btn wbs-upload-btn">
							<?php echo wbolt_svg_icon('sico-upload'); ?>
                            <span>上传</span>
                        </button>
                    </div>
                </div>
            </td>
        </tr>

        <tr>
            <th class="row">主题主色调</th>
            <td>
                <input id="themeColor" class="of-input j-color-picker" name="<?php echo $opt_name; ?>[theme_color]" type="text" value="<?php _opt('theme_color'); ?>">
                <p class="description">设定主题配色</p>
            </td>
        </tr>

        <tr>
            <th class="row">文章编辑器</th>
            <td>
                <input class="wb-switch" type="checkbox" name="<?php echo $opt_name; ?>[gutenberg_switch]" <?php if(wb_opt('gutenberg_switch')) echo ' checked="checked"'; ?> data-value="<?php _opt('gutenberg_switch'); ?>"> <span class="description">默认跟WP版本。激活选项则关闭古腾堡，使用传统编辑器</span>
            </td>
        </tr>

        <?php
        $gallery_switch = wb_opt('gallery_switch') != null ? 'checked' : '';
        ?>
        <tr>
            <th class="row">关闭智能相册</th>
            <td>
                <input class="wb-switch" type="checkbox" name="<?php echo $opt_name; ?>[gallery_switch]" <?php echo $gallery_switch; ?> data-value="<?php _opt('gallery_switch'); ?>"> <span class="description">默认将文章详情页图片自动组成相册，若激活将停用该功能。</span>
            </td>
        </tr>

        <tr>
            <th class="row">自动加载分页数</th>
            <td>
                <input class="wb-switch" type="checkbox" name="<?php echo $opt_name; ?>[autoload]" data-target="#J_rangeAutoLoadSetting" <?php if(wb_opt('autoload')) echo ' checked="checked"'; ?> data-value="<?php _opt('autoload'); ?>"> <span class="description">列表下拉自动加载，默认关闭</span>

                <div class="default-hidden-box<?php echo wb_opt('autoload') ? ' active':''; ?> mt" id="J_rangeAutoLoadSetting">
                    <div class="input-range">
                        <input class="field-range" id="J_rangeAutoLoadRange" name="<?php echo $opt_name; ?>[mxpage]" type="hidden" value="<?php _opt('mxpage'); ?>" />
                    </div>
                    <p class="description">设定自动加载页数<p>
                </div>
            </td>
        </tr>

        <tr>
            <th class="row">首页展示分类</th>
            <td>
                <input id="flID" class="wbs-input" name="<?php echo $opt_name;?>[flID]" type="hidden" value="<?php _opt('flID'); ?>" placeholder="以英文逗号分隔">

                <div class="cate-list" id="cat_list">

			        <?php foreach ($cate_list[0] as $cat){
				        ?>
                        <div  class="cl-item">
                            <label><input class="set-cate" type="checkbox" name="sec_cat" title="<?php echo $cat['name'];?>" value="<?php echo $cat['term_id'];?>"><?php echo $cat['name'];?></label>
                        </div>
			        <?php } ?>
                </div>
                <p class="description">勾选在首页展示的分类</p>

                <ul class="selected-items-wp sortable" id="J_selectedCateWp"></ul>
                <p class="description">拖动以设定分类展示顺序</p>
            </td>
        </tr>
        </tbody>
    </table>
</div>

<div class="sc-header">
    <strong>页脚版权信息设置</strong>
</div>
<div class="sc-body">
    <table class="wbs-form-table">
        <tbody>
        <tr>
            <th class="row w8em">
                <div class="pt-l">页脚版权信息</div>
            </th>
            <td>
				<?php
				wp_editor( wb_opt('copyright_footer'), 'editor_copyright_footer', array(
						'teeny' => true,
						'textarea_rows' => 5,
						'media_buttons' => false,
						'textarea_name' => $opt_name.'[copyright_footer]')
				);
				?>
            </td>
        </tr>


        <tr>
            <th class="row"></th>
            <td></td>
        </tr>

        </tbody>
    </table>
</div>
