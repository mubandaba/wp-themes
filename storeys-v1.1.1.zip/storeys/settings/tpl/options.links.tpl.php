<?php /**
 * WBolt 友链
 **/
?>
<script type="application/javascript" src="<?php echo get_template_directory_uri()  ;?>/settings/assets/angular.js"></script>

<div class="sc-header">
    <strong>友情链接</strong>
    <span>设置您的友情链接</span>
</div>

<?php
$links_items = isset($opt['links']) ? $opt['links'] : array();
$item_name = $opt_name . '[links]';

?>
<div class="sc-body" ng-app="xk-app" ng-controller="mainController" ng-cloak>
    <table class="wbs-info-table links-items-table">
        <tbody>
            <tr ng-repeat="(idx,v) in links">
                <th class="row w6em">友链 {{idx + 1}}
                    <p class="ctrl-def-hide"><a ng-click="delOne(idx)">[删除]</a></p>
                </th>
                <td>
                    <div class="social-item">
                        <div class="mb">
                            <input class="wbs-input" type="text" placeholder="网站名称 *" name="<?php echo $item_name;?>[{{idx}}][name]" value="{{v.name}}" required>
                        </div>
                        <div class="mb">
                            <input class="wbs-input" type="text" placeholder="网站URL (如:https://www.wbolt.com) *" name="<?php echo $item_name;?>[{{idx}}][url]" value="{{v.url}}" required>
                        </div>
                        <div class="social-item section-upload">
                            <div class="wbs-upload-box">
                                <input class="wbs-input upload-input" id="J_links_{{idx}}"  type="text" placeholder="站点图标" name="<?php echo $item_name;?>[{{idx}}][img]" value="{{v.img}}"/>
                                <button type="button" class="wbs-btn wbs-upload-btn">
                                    <?php echo wbolt_svg_icon('sico-upload'); ?>
                                    <span>上传</span>
                                </button>
                            </div>
                        </div>
                        <div class="selector-bar">
                            <label>
                                <input class="wbs-checkbox" type="checkbox" name="<?php echo $item_name;?>[{{idx}}][target]" ng-checked="v.target">
                                <input type="hidden" ng-model="v.target">
                                <span>新窗口打开</span>
                            </label>
                            <label class="ml">
                                <input class="wbs-checkbox" type="checkbox" name="<?php echo $item_name;?>[{{idx}}][nofollow]" ng-checked="v.nofollow">
                                <input type="hidden" ng-model="v.nofollow">
                                <span>设置nofollow</span>
                            </label>
                        </div>
                    </div>
                </td>
            </tr>
        </tbody>
        <tfoot>
            <tr>
                <th></th>
                <td>
                    <a class="wb-btn btn-ctrl" id="J_addBtn" ng-click="addOne()">
	                    <?php echo wbolt_svg_icon('sico-plus'); ?>
                        <span>添加</span>
                    </a>
                </td>
            </tr>
        </tfoot>

    </table>
</div>

<script>
    angular.
    module('xk-app',[

    ])
        .controller('mainController', function($scope) {

                $scope.links = [];

                $scope.links = <?php echo $links_items ? json_encode($links_items) : '[]'; ?>;
                // console.log($scope.links);

                $scope.addOne = function () {
                    var o = $scope.links;
                    o.push({'name':'','url':'','img':'','target':'1','nofollow':'1'});
                };

                $scope.delOne = function (idx) {
                    if (confirm("确认删除？")){
                        $scope.links.splice(idx,1);
                    }
                };
            }
        );
</script>