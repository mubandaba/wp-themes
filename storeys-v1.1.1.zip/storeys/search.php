<?php
/**
 * The template for displaying search results pages
 *
 * @package WordPress
 * @subpackage Storeys
 * @since Wbolt 1.0
 */
if(!wp_is_mobile()) $GLOBALS['custom-header'] = 'header-b';
add_action('wp_footer', 'insert_footer');

function insert_footer()
{
	wp_enqueue_script('index-js', get_template_directory_uri() . '/js/list.js', array('jquery'));
}

get_header();
$have_posts = have_posts();

$custom_banner = wb_opt('banner_url');
$is_video_banner = $custom_banner && preg_match('/.mp4$/',$custom_banner);

?>

    <div class="title-list"<?php if($custom_banner && !$is_video_banner) echo ' style="background-image: url(' . $custom_banner .'); background-size:cover; "';  ?>>
		<?php
		global $wp_query;
		$item_count = number_format($wp_query->found_posts);
		$item_count = $item_count > 0 ? $item_count . _n(' item', ' items', $item_count, 'wbolt') : '';
		?>
        <h1><?php printf( __( 'Search Results for: %s', 'wbolt' ), '<span>' . get_search_query() . '</span>' ); ?></h1>
        <div class="description"><?php echo $item_count; ?></div>
    </div>

    <div class="list-main pw">
		<?php if ( $have_posts ) : ?>
	    <?php echo WBOptions::insertAdBlock('list_block','adbanner-block under-list-title'); ?>

        <div class="articles-list" id="J_postList">
			<?php
			// Start the loop.
			$postIndex = 0;
			$adIndex = rand(3,8);
			$hasListAD = wb_opt('ads.list.type');

			while ( have_posts() ) : the_post();
				get_template_part( 'template-parts/content', get_post_format() );

				if($hasListAD && $postIndex == $adIndex){
					get_template_part( 'template-parts/content', 'list-ad' );
				}
				$postIndex++;

			endwhile;
			?>
        </div>
        <div class="loading-bar"></div>
        <?php
        wbolt_the_posts_pagination();
        ?>

        <?php else :
            get_template_part( 'template-parts/content-none', 'none' );

        endif;
        ?>
    </div>

<?php get_footer(); ?>