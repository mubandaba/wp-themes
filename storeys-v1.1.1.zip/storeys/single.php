<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Storeys
 * @since Wbolt 1.0
 */
$GLOBALS['container-custom'] = 'container-single';

if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
	wp_enqueue_script( 'comment-reply' );
}

the_post();

get_header();

setPostViews(get_the_ID());

?>


<?php if (function_exists('wb_breadcrumbs')) wb_breadcrumbs(); ?>
<div <?php post_class('post-single pw'); ?> id="J_postCont">
	<?php
	get_template_part( 'template-parts/content', 'single' );
	?>

	<?php get_sidebar(); ?>
</div>

<div class="related-box">
	<div class="rb-inner pw">
		<?php
        if(wp_is_mobile()){ echo do_shortcode( '[wb_related_posts max="5" name="'.__('Similar items','wbolt').'"]' ); }
		else{ echo do_shortcode( '[wb_related_posts mode="with-img" max="4" name="'.__('Similar items','wbolt').'"]' ); }
		?>
    </div>
</div>

<?php
// If comments are open or we have at least one comment, load up the comment template.
if ( comments_open() || get_comments_number() ) {

	comments_template();
}
?>

<?php get_footer(); ?>
