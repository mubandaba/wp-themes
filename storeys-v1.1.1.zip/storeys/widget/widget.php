<?php
/**
*
*/

class Wb_Widget
{
    function __construct()
    {
        add_action('widgets_init',array(__CLASS__,'widgets_init'));
    }

    public static function widgets_init(){
        //注册装载小工具的区域
        register_sidebar( array(
            'name'          => __( 'Head of Sidebar', 'wbolt' ),
            'id'            => 'sidebar-def',
            'description'   => __( 'Drag the gadgets here to the sidebar', 'wbolt' ),
            'before_widget' => '<section id="%1$s" class="spmg-bottom widget %2$s">',
            'after_widget'  => '</section>'
        ) );
        register_sidebar( array(
            'name'          => __( 'Footer of Sidebar', 'wbolt' ),
            'id'            => 'sidebar-bottom',
            'description'   => __( 'Drag the gadgets here to the footer of sidebar', 'wbolt' ),
            'before_widget' => '<section id="%1$s" class="spmg-bottom widget %2$s">',
            'after_widget'  => '</section>'
        ) );
        register_sidebar( array(
            'name'          => __( 'Bottom of post', 'wbolt' ),
            'id'            => 'sidebar-content-bottom',
            'description'   => __( 'Drag the gadgets here to the footer of post', 'wbolt' ),
            'before_widget' => '<section id="%1$s" class="wbolt-plugin-area %2$s">',
            'after_widget'  => '</section>'
        ) );

        wp_register_sidebar_widget('wbolt-related-posts', __('#Related#','wbolt'), array(__CLASS__,'wb_related_posts'),array('description'=>__('List recommended posts, show at the bottom of post','wbolt')));

//	            unregister_widget( 'WP_Widget_Archives' );
//	            unregister_widget( 'WP_Widget_Calendar' );
//	            unregister_widget( 'WP_Widget_Categories' );
//	            unregister_widget( 'WP_Widget_Links' );
//	            unregister_widget( 'WP_Widget_Meta' );
//	            unregister_widget( 'WP_Widget_Pages' );
//	            unregister_widget( 'WP_Widget_Recent_Comments' );
//	            unregister_widget( 'WP_Widget_Recent_Posts' );
//	            unregister_widget( 'WP_Widget_RSS' );
//	            unregister_widget( 'WP_Widget_Search' );
//	            unregister_widget( 'WP_Widget_Tag_Cloud' );
//	            unregister_widget( 'WP_Widget_Text' );
//	            unregister_widget( 'WP_Widget_Custom_HTML' );
//	            unregister_widget( 'WP_Widget_Media_Image' );
//	            unregister_widget( 'WP_Widget_Media_Video' );
//	            unregister_widget( 'WP_Widget_Media_Audio' );
//	            unregister_widget( 'WP_Nav_Menu_Widget' );
    }

    public static  function wb_related_posts(){
        echo do_shortcode( '[wb_related_posts]' );
    }
}
new Wb_Widget();