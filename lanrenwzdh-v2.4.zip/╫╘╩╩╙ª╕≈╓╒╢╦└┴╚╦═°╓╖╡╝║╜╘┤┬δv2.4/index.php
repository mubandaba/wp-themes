<?php
	$index = 'active';
	require ('./header.php');
?><div class="card">
	<div class="wzgg">
<a href="#" target="_blank" rel="nofollow">文字广告火爆招租</a> 
<a href="#" target="_blank" rel="nofollow">文字广告火爆招租</a> 
<a href="#" target="_blank" rel="nofollow">文字广告火爆招租</a> 
<a href="#" target="_blank" rel="nofollow">文字广告火爆招租</a> 
	</div></div>
        <div id="置顶站点" class="card">
            <div class="top-grid">
			<?php
				mysql_query("set names utf8");
				$results = mysql_query("SELECT * FROM zzdh_list where tui = '1' order by lid asc limit 12");
				while($rows = mysql_fetch_array($results))
				{
		    ?>
                            <a href="<?php if(empty($rows['alias'])){echo "../site_{$rows['id']}.html";}else{echo "../{$rows['alias']}.html";};?>" class="item" title="<?php echo $rows['name'];?>" data-id="<?php echo $rows['id'];?>">
                <span class="icon"><img class="lazy-load" src="assets/images/loading.gif" data-src="<?php echo $rows['img'];?>"></span>
                <span class="name"><?php echo $rows['name'];?></span>
            </a><?php }?>
                        </div>
        </div>
                    <div class="card">
                <a class="ad" target="blank" href="http://www.9zwz.com">
                    <img src="/assets/images/2.gif">
                </a>
            </div>
            <div class="card">
                <div class="card-head">
                    <i class="fa fa-link fa-fw"></i>最新点入：友链后在贵站点击即排本站首位!<a href="apply.html" class="more"><i class="fa fa-plus-square" aria-hidden="true"></i>申请收录</a>
                </div>
                <div class="card-body">
			<?php
				mysql_query("set names utf8");
				$results = mysql_query("SELECT * FROM zzdh_list order by drtime desc limit 14");
				while($rows = mysql_fetch_array($results))
				{ ?><a href="<?php echo "../site_{$rows['id']}.html";?>" target="_blank" class="item" title="<?php echo $rows['name'];?>" data-id="<?php echo $rrows['id'];?>">
                            <span class="icon"><img class="lazy-load" src="assets/images/loading.gif" data-src="<?php echo $rows['img'];?>"></span>
                            <span class="name"><?php echo $rows['name'];?></span>
                        </a><?php }?>
                 </div>
            </div>
	<?php
		mysql_query("set names utf8");
		$result = mysql_query("SELECT * FROM zzdh_sort order by sid asc");
		while($row = mysql_fetch_array($result))
		{
	?>
	<a id="<?php echo $row['sortname'];?>"></a>
                                <div id="<?php echo $row['sortname'];?>" class="card">
                <div class="card-head">
                    <i class="fa <?php echo $row['icon'];?> fa-fw"></i><?php echo $row['sortname'];?>                    <a href="<?php if(empty($row['alias'])){echo "../sort{$row['id']}.html";}else{echo "../sort{$row['alias']}.html";};?>" class="more"><i class="fa fa-ellipsis-h fa-fw"></i></a>
                </div>
                <div class="card-body">
			<?php
				mysql_query("set names utf8");
				$results = mysql_query("SELECT * FROM zzdh_list where sortname = '".$row['sortname']."' order by lid asc limit 14");
				while($rows = mysql_fetch_array($results))
				{
		    ?>
                                            <a href="<?php if(empty($rows['alias'])){echo "../site_{$rows['id']}.html";}else{echo "../{$rows['alias']}.html";};?>" target="_blank" class="item" title="<?php echo $rows['name'];?>" data-id="<?php echo $rrows['id'];?>">
                            <span class="icon"><img class="lazy-load" src="assets/images/loading.gif" data-src="<?php echo $rows['img'];?>"></span>
                            <span class="name"><?php echo $rows['name'];?></span>
                        </a><?php }?>
                                    </div>
            </div><?php }?>
                                <div class="card">
                <a class="ad" target="blank" href="https://wpa.qq.com/msgrd?v=3&uin=1308484422&site=qq&menu=yes" title="点击对话" rel="nofollow">
                    <img src="/assets/images/1.gif">
                </a>
            </div>
                </div>
    <div class="side">
        <div class="card">
            <div class="card-head"><i class="fa fa-line-chart fa-fw"></i>总浏览TOP10</div>
            <div class="card-body">
                <div class="view-list">
<?php $result=mysql_query("select * from zzdh_list order by view desc limit 10");
$pai=0;
while($rs=mysql_fetch_array($result)) {
$pai=$pai+1;
?>
                <a href="<?php if(empty($rs['alias'])){echo "/site_{$rs['id']}.html";}else{echo "/{$rs['alias']}.html";};?>" data-id="<?php echo $rs['id'];?>">
                <span class="rank"><?php echo $pai;?></span>
                <span class="icon"><img class="lazy-load" src="assets/images/loading.gif" data-src="<?php echo $rs['img'];?>"></span>
                <span class="name"><?php echo $rs['name'];?></span>
                <span class="view"><?php echo $rs['view'];?></span>
            </a><?php }?>
                            </div>
            </div>
        </div>
        <div class="card">
            <div class="card-head"><i class="fa fa-coffee fa-fw"></i>最新收录</div>
            <div class="card-body">
                <div class="side-latest oz-timeline">
<?php $result=mysql_query("select * from zzdh_list order by time desc limit 10");
while($rs=mysql_fetch_array($result)) {
?>
                <a href="<?php if(empty($rs['alias'])){echo "/site_{$rs['id']}.html";}else{echo "/{$rs['alias']}.html";};?>" data-id="<?php echo $rs['id'];?>" data-id="<?php echo $rs['id'];?>" class="oz-timeline-item">
                <div class="oz-timeline-time"><?php echo $rs['time'];?></div>
                <div class="oz-timeline-main">
                    <span class="icon"><img class="lazy-load" src="assets/images/loading.gif" data-src="<?php echo $rs['img'];?>"></span>
                    <span class="name"><?php echo $rs['name'];?></span>
                </div>
            </a><?php }?>
                            </div>
            </div>
        </div>
                            <div class="card">
                <a class="ad" target="blank" href="http://www.9zwz.com">
                    <img src="/assets/images/3.gif">
                </a>
            </div>
        <div class="card">
            <div class="card-head"><i class="fa fa-pie-chart fa-fw"></i>本站统计</div>
            <div class="card-body">
                <div class="side-common">
				<p>已开设分类：<b><?php echo $cntsort?></b> 个</p>
				<p>已收录站点：<b><?php echo $cntlist?></b> 个</p>
				<p>最高日览站：<a href="<?php echo "../site_{$rows_cntlistrhits['id']}.html";?>" target="_blank"><?php echo $rows_cntlistrhits['name'];?></a></p>
				<p>最高月览站：<a href="<?php echo "../site_{$rows_cntlisthits['id']}.html";?>" target="_blank"><?php echo $rows_cntlisthits['name'];?></a></p>
				<p>最高总览站：<a href="<?php echo "../site_{$rows_cntlistview['id']}.html";?>" target="_blank"><?php echo $rows_cntlistview['name'];?></a></p>
	            <p>正申请站点：<b><?php echo $cntapply?></b> 个</p>
				<p>已发布公告：<b><?php echo $cntnotice;?></b> 条</p>
				<p>已交换友链：<b><?php echo $cntlink;?></b> 个</p>
				<p>本站已稳定运行了 <b><script language="JavaScript" type="text/javascript">var urodz = new Date("<?php echo $conf['time'];?>");var now = new Date();var ile = now.getTime() - urodz.getTime();var dni = Math.floor(ile / (1000 * 60 * 60 * 24));document.write( + dni)</script></b> 天。</p>
		</div>
            </div>
        </div>

                </div>
    <div class="card links">
        <div class="card-head"><i class="fa fa-link fa-fw"></i>友情链接</div>
        <div class="card-body">
			<?php
				mysql_query("set names utf8");
				$results = mysql_query("SELECT * FROM zzdh_link order by id asc limit 36");
				while($rows = mysql_fetch_array($results))
				{
		    ?>
                                <a href="<?php echo $rows['url'];?>" target="_blank"><?php echo $rows['name'];?></a>
<?php }?>
                        </div>
    </div>
</div>
<div style="display:none;"><script type="text/javascript" src="https://s95.cnzz.com/z_stat.php?id=147429&web_id=147429"></script></div>
<?php
	require ('./footer.php');
?>
