<?php
    require ('../inc/lang.php');
?>

<div class="footer">
	<?php echo $lang->admin->footer;?>
</div>

<script type="text/javascript" src="./style/js/mdui.min.js"></script>
<div style="display:none;"><script type="text/javascript" src="https://s95.cnzz.com/z_stat.php?id=147429&web_id=147429"></script></div>﻿
</footer>
</body>
</html>