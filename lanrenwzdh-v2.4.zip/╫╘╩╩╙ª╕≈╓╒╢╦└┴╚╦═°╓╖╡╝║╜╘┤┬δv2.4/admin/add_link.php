<?php
	$title='添加友链';
    require ('./header.php');
?>

<div class="mdui-container" style="margin-top: 4%;">
	<div class="panel panel-default">
		<div class="panel-heading"><b><?php echo $lang->admin->add_nav;?></b></div>
		<div class="panel-body">
			<form action="./submit.php" method="post">
				<input type="text" value="link" name="from" style="display: none;">
				<div class="input-group">
					<span class="input-group-addon" id="basic-addon1">名称</span>
					<input type="text" class="form-control" placeholder="请输入友链名称[必填]" aria-describedby="basic-addon1" name="name" required>
				</div>
				<br>
				<div class="input-group">
					<span class="input-group-addon" id="basic-addon1">链接</span>
					<input type="url" class="form-control" placeholder="请输入友链链接[必填]" aria-describedby="basic-addon1" name="url" required>
				</div>
				<br>
			    <div style="text-align: center;">
					<input type="submit" class="btn btn-info" style="width: 80%;" value="添加">
			    </div>
			</form>
		</div>
	</div>
</div>
  
<?php
    require ('./footer.php');
?>