</div><!--wrapper-->
<div id="footer">
			<div class="left">&copy; <?php echo date("Y"); ?> <?php bloginfo('name'); ?>. Theme "zDark" designed by <a href="http://zww.me">zwwooooo</a>. Valid <a href="http://validator.w3.org/check/referer" title="This page validates as XHTML 1.0 Transitional"><abbr title="eXtensible HyperText Markup Language">XHTML</abbr></a> and <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS 2.1</a>.</div>
			<div class="right">
					<a href="#top" rel="nofollow">Back to Top</a> / <a href="<?php echo get_settings('home'); ?>" rel="nofollow">Home</a>
			</div>
</div><!--footer-->
</div><!--container-->
<?php wp_footer(); ?>
</body>
</html>