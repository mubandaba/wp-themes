﻿﻿<?php get_header();?>







<?php if (have_posts()) : ?>



<?php while (have_posts()) : the_post(); ?>



<div align="center" class="margin"><a href="<?php echo get_option('home'); ?>" class="dbdtx"><?php if (function_exists('get_avatar')) { echo get_avatar( get_the_author_email(), '50' ); }?></a></div>



<div class="wrap s_clear sjzsy">



<div class="yi_blog">

<?php     
if (function_exists('get_breadcrumbs')){   
    get_breadcrumbs();  
}   
?>
<br>

<hr size=1 style="color:#DDD;border-style:dashed ;width:100%">
<div style="height:10px"></div>
<p style="margin-left:6px;float:left;color:#999;">
<h1 align="center"><?php the_title_attribute(); ?></h1>
</p>
<div style="height:10px"></div>
<hr size=1 style="color:#DDD;border-style:dashed ;width:100%">



<div style="height:5px"></div>

<div class="bi lazy ">

<div class="hentai_post"><p style="margin-left:6px;float:left;color:#999;"><a><?php the_content("Read More..."); ?></a></p></div>

</div>



<div style="height:20px"></div>



<div class="hentai_time">



<a style="float:left;">&nbsp;<i class="fa fa-user fa-lg"></i>&nbsp;<?php the_author(); ?>&nbsp;&nbsp;&nbsp;<i class="fa fa-clock-o fa-lg"></i>&nbsp;<?php the_date_xml()?></a>

<a style="float:right;"><i class="fa fa-users fa-lg"></i>&nbsp;<?php comments_number('No Comment', '1 Comment', '% Comments' );?></a>



<div style="height:20px"></div>



</div>



</div>



</div>



<?php endwhile; ?>



<div class="wrap s_clear sjzsy">



<div class="yi_blog">



<?php comments_template(); ?>



</div>



</div>



<?php else : ?>



<?php endif; ?>







<?php get_footer();?>