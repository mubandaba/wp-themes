<?php

//读者墙
//读者墙
function bymt_mostactive($limit_num,$time) {
	if(!$mostactive = get_option('mostactive_'.$limit_num)){
		global $wpdb;
		$noneurl = esc_url(home_url('/'));
		$my_email = "'" . get_bloginfo ('admin_email') . "'"; //排除管理员评论
		$counts = $wpdb->get_results("
			SELECT COUNT(comment_author) AS cnt, comment_author, comment_author_url, comment_author_email
			FROM (SELECT * FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts
			ON ($wpdb->posts.ID=$wpdb->comments.comment_post_ID)
			WHERE comment_date > date_sub( NOW(), INTERVAL $time )
			AND comment_author_email != $my_email
			AND post_password=''
			AND comment_approved='1'
			AND comment_type='') AS tempcmt GROUP BY comment_author_email
			ORDER BY cnt DESC LIMIT $limit_num
		");
		$mostactive = '';
		if(empty($counts)) {
			$mostactive = '<a style="text-align: center;">暂时还没有</a>';
		} else {
			foreach ($counts as $count) {
				$c_url = $count->comment_author_url;
				if ($c_url == '') $c_url = $noneurl;
				$title_alt = $count->comment_author . ' ('. $count->cnt. ' 条评论)';
				if($limit_num=='1'){
					$mostactive = '<a href="'. $c_url . '" rel="external nofollow" title="' .$title_alt
				. '">'.$count->comment_author.'</a>';
				}else{
					$mostactive .= '<li><a href="'. $c_url . '" rel="external nofollow" title="' .$title_alt
                                        . '">'.my_avatar($avatar).'<em>'.$count->comment_author.'</em><strong>+'.$count->cnt.'</strong></a></li>';
				}
			}
		}
		update_option('mostactive_'.$limit_num, $mostactive);
	}
	if($limit_num!='1') $mostactive = "<ul class=\"readers-list\">".$mostactive."</ul>";
	echo $mostactive;
}
function clear_mostactive() {
  update_option('mostactive_1', ''); 
  update_option('mostactive_36', ''); // 清空 mostactive
  update_option('mostactive_40', '');
}
add_action('comment_post', 'clear_mostactive'); // 新评论发生时
add_action('edit_comment', 'clear_mostactive'); // 评论被编辑过


//面包屑
if(get_option('ashu_copy_mianbx') == '是')
{ 
function get_breadcrumbs()   
{   
global $wp_query;   
if ( !is_home() ){   
echo '<ul>';   
echo '<a href="'. get_settings('home') .'">'. 首页 .'</a>';   
if ( is_category() )   
{   
$catTitle = single_cat_title( "", false );   
$cat = get_cat_ID( $catTitle );   
echo " &raquo; ". get_category_parents( $cat, TRUE, " &raquo; " ) ;   
}   
elseif ( is_archive() && !is_category() )   
{   
echo "&raquo; Archives";   
}   
elseif ( is_search() ) {   
echo "&raquo; Search Results";   
}   
elseif ( is_404() )   
{   
echo "&raquo; 404 Not Found";   
}   
elseif ( is_single() )   
{   
$category = get_the_category();   
$category_id = get_cat_ID( $category[0]->cat_name );   
echo '&raquo; '. get_category_parents( $category_id, TRUE, " &raquo; " );   
echo the_title('','', FALSE);   
}   
elseif ( is_page() )   
{   
$post = $wp_query->get_queried_object();   
if ( $post->post_parent == 0 ){   
echo "<li> &raquo; ".the_title('','', FALSE)."</li>";   
} else {   
$title = the_title('','', FALSE);   
$ancestors = array_reverse( get_post_ancestors( $post->ID ) );   
array_push($ancestors, $post->ID);   
foreach ( $ancestors as $ancestor ){   
if( $ancestor != end($ancestors) ){   
echo '<li> &raquo; <a href="'. get_permalink($ancestor) .'">'. strip_tags( apply_filters( 'single_post_title', get_the_title( $ancestor ) ) ) .'</a></li>';   
} else {   
echo '<li> &raquo; '. strip_tags( apply_filters( 'single_post_title', get_the_title( $ancestor ) ) ) .'</li>';   
}   
}   
}   
}   
echo "</ul>";
}   
}
}


//WordPress第一次评论禁止全英文/屏蔽日语垃圾评论
if(get_option('ashu_copy_lajipl') == '是')
{ 
function v7v3_en($comment) {
    $pattern = '/[一-龥]/u';  
    $cau=$comment['comment_author'] ;
    $cem=$comment['comment_author_email'] ; 
    global $wpdb;
    $ok_to_comment = $wpdb->get_var("SELECT comment_approved FROM $wpdb->comments WHERE comment_author = '$cau' AND comment_author_email = '$cem' and comment_approved = '1' LIMIT 1");
    if( is_user_logged_in() || 1 == $ok_to_comment ){ return $comment; } 
    elseif ( !preg_match_all($pattern, $ccontent, $match) ) {
        exit('
<head><meta http-equiv="Content-Type" content="text/html; charset=utf8"/></head>
初次评论不允许纯英文哦~<a href="javascript:history.go(-1);">向上一页</a>');
    } 
} 
add_filter('preprocess_comment', 'v7v3_en'); 
function v7v3_comment_post( $incoming_comment ) {
$http = '/[<|KTV|ッ|の|ン|優|業|グ|貿|]/u';
if(preg_match($http, $incoming_comment['comment_content'])) {
wp_die( "
<head><meta http-equiv='Content-Type' content='text/html; charset=utf8'/></head>
您的评论包含敏感关键词，被系统判断为垃圾评论！<a href='javascript:history.go(-1);'>向上一页</a>" );
}
return( $incoming_comment );
}
add_filter('preprocess_comment', 'v7v3_comment_post');
}


//缓冲头像
if(get_option('ashu_copy_touxhc') == '是')
{ 
function my_avatar($avatar) {
     $tmp = strpos($avatar, 'http');
     $g = substr($avatar, $tmp, strpos($avatar, "'", $tmp) - $tmp);
     $tmp = strpos($g, 'avatar/') + 7;
     $f = substr($g, $tmp, strpos($g, "?", $tmp) - $tmp);
     $w = home_url(); // $w = get_bloginfo('url');
     $e = preg_replace('/wordpress\//', '', ABSPATH) .'avatar/'. $f .'.jpg';
     $t = 604800;
     if ( empty($default) ) $default = $w. '/avatar/default.jpg';
     if ( !is_file($e) || (time() - filemtime($e)) > $t ) 
         copy(htmlspecialchars_decode($g), $e);
     else
         $avatar = strtr($avatar, array($g => $w.'/avatar/'.$f.'.jpg'));
     if (filesize($e) < 500) copy($default, $e);
     return $avatar;
 }
 add_filter('get_avatar', 'my_avatar');
 }


//点赞
add_action('wp_ajax_nopriv_bigfa_like', 'bigfa_like');
add_action('wp_ajax_bigfa_like', 'bigfa_like');
function bigfa_like(){
    global $wpdb,$post;
    $id = $_POST["um_id"];
    $action = $_POST["um_action"];
    if ( $action == 'ding'){
    $bigfa_raters = get_post_meta($id,'bigfa_ding',true);
    $expire = time() + 99999999;
    $domain = ($_SERVER['HTTP_HOST'] != 'localhost') ? $_SERVER['HTTP_HOST'] : false; // make cookies work with localhost
    setcookie('bigfa_ding_'.$id,$id,$expire,'/',$domain,false);
    if (!$bigfa_raters || !is_numeric($bigfa_raters)) {
        update_post_meta($id, 'bigfa_ding', 1);
    } 
    else {
            update_post_meta($id, 'bigfa_ding', ($bigfa_raters + 1));
        }
   
    echo get_post_meta($id,'bigfa_ding',true);
    
    } 
    
    die;
}


//自定义登录页面
if(get_option('ashu_copy_htmh') == '是')
{ 
function custom_login_logo() { echo '<link rel="stylesheet" id="wp-admin-css" href="'.get_bloginfo('template_directory').'/css/admstyle.css" type="text/css" />';}
add_action('login_head', 'custom_login_logo');
	
}

//评论表情
function wp_smilies() {
	global $wpsmiliestrans;
	if ( !get_option('use_smilies') or (empty($wpsmiliestrans))) return;
	$smilies = array_unique($wpsmiliestrans);
	$link='';
	foreach ($smilies as $key => $smile) {
		$file = get_bloginfo('wpurl').'/wp-includes/images/smilies/'.$smile;
		$value = " ".$key." ";
		$img = "<img src=\"{$file}\" alt=\"{$smile}\" />";
		$imglink = htmlspecialchars($img);
		$link .= "<a href=\"#commentform\" title=\"{$smile}\" onclick=\"document.getElementById('comment').value += '{$value}'\">{$img}</a>&nbsp;";
	}
	echo '<div class="wp_smilies">'.$link.'</div>';
}

//自定义评论结构
function mytheme_comment($comment, $args, $depth) {
   $GLOBALS['comment'] = $comment;
   global $commentcount;
   if(!$commentcount) {
	   $page = ( !empty($in_comment_loop) ) ? get_query_var('cpage')-1 : get_page_of_comment( $comment->comment_ID, $args )-1;
	   $cpp=get_option('comments_per_page');
	   $commentcount = $cpp * $page;
	}
?>
<?php 
if (current_time('timestamp') - get_comment_time('U') < 518400 )//六天
{$cmt_time = human_time_diff( get_comment_time('U') , current_time('timestamp') ) . '前';}
else{$cmt_time = get_comment_date( 'Y/n/j' );};
 ;?>
<li class="comments" <?php if( $depth > 2){ echo ' style="margin-left:-40px;"';} ?> id="li-comment-<?php comment_ID() ?>">
		<div id="comment-<?php comment_ID(); ?>" class="comment-body">
			<div class="touxiang">
		<?php echo get_avatar( $comment, $size = '52'); ?>
			</div>
				<span class="name"><?php printf(__('%s'), get_comment_author_link()) ?>
				<?php if(user_can($comment->user_id, 1)){echo "<span class='owner'>我是主人</span>";}; ?>
				<?php if($comment->comment_parent){// 如果存在父级评论
          $comment_parent_href = get_comment_ID( $comment->comment_parent );
          $comment_parent = get_comment($comment->comment_parent);
          ?>
    回复 <a href="#comment-<?php echo $comment_parent_href;?>"><?php echo $comment_parent->comment_author;?></a>
    <?php }?>
				</span>:<?php comment_text() ?>
				<div class="date"> <?php echo $cmt_time ;?></div>
				<div class="floor"><?php if(!$parent_id = $comment->comment_parent) {printf('#%1$s', ++$commentcount);} ?></div>

<?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth'], 'reply_text' => "@Ta"))) ?>
   	</div> 
<?php
}
function bymt_r($name,$val,$e=''){
    $bymt_r = get_option('bymt_options');
	if($e=='e'){
		if($bymt_r[$name]==""){
			esc_attr_e($val);
		}else{

			esc_attr_e($bymt_r[$name]);

		}

	}elseif($e=='u'){

		if($bymt_r[$name]==""){

			echo esc_url($val);

		}else{

			echo esc_url($bymt_r[$name]);

		}

	}elseif($e=='s'){

		if($bymt_r[$name]==""){

			echo esc_attr(strip_tags($val));

		}else{

			echo esc_attr(strip_tags($bymt_r[$name]));

		}

	}else{

		if($bymt_r[$name]==""){

			echo $val;

		}else{

			echo $bymt_r[$name];

		}

	}

}



register_nav_menus();



function par_pagenavi($range = 9){

	global $paged, $wp_query;

	if ( !$max_page ) {$max_page = $wp_query->max_num_pages;}

	if($max_page > 1){if(!$paged){$paged = 1;}

	if($paged != 1){echo "<a href='" . get_pagenum_link(1) . "' class='extend' title='跳转到首页'> 返回首页 </a>";}

	previous_posts_link(' 上一页 ');

    if($max_page > $range){

		if($paged < $range){for($i = 1; $i <= ($range + 1); $i++){echo "<a href='" . get_pagenum_link($i) ."'";

		if($i==$paged)echo " class='current'";echo ">$i</a>";}}

    elseif($paged >= ($max_page - ceil(($range/2)))){

		for($i = $max_page - $range; $i <= $max_page; $i++){echo "<a href='" . get_pagenum_link($i) ."'";

		if($i==$paged)echo " class='current'";echo ">$i</a>";}}

	elseif($paged >= $range && $paged < ($max_page - ceil(($range/2)))){

		for($i = ($paged - ceil($range/2)); $i <= ($paged + ceil(($range/2))); $i++){echo "<a href='" . get_pagenum_link($i) ."'";if($i==$paged) echo " class='current'";echo ">$i</a>";}}}

    else{for($i = 1; $i <= $max_page; $i++){echo "<a href='" . get_pagenum_link($i) ."'";

    if($i==$paged)echo " class='current'";echo ">$i</a>";}}

	next_posts_link(' 下一页 ');

    if($paged != $max_page){echo "<a href='" . get_pagenum_link($max_page) . "' class='extend' title='跳转到最后一页'> 最后一页 </a>";}}

}

add_filter('the_content', 'fancybox');
function fancybox ($content)
{ global $post;
$pattern = "/<a(.*?)href=('|\")([^>]*).(bmp|gif|jpeg|jpg|png|swf)('|\")(.*?)>(.*?)<\/a>/i";
$replacement = '<a$1href=$2$3.$4$5 rel="box" class="fancybox"$6>$7</a>';
$content = preg_replace($pattern, $replacement, $content);
return $content;
}


//Check see if the customisetheme_setup exists
if ( !function_exists('customisetheme_setup') ):
    //Any theme customisations contained in this function
    function customisetheme_setup() {
        //Define default header image
        define( 'HEADER_IMAGE', '%s/images/default.jpg' );
 
        //Define the width and height of our header image
        define( 'HEADER_IMAGE_WIDTH', apply_filters( 'customisetheme_header_image_width',100 ) );
        define( 'HEADER_IMAGE_HEIGHT', apply_filters( 'customisetheme_header_image_height',100 ) );
 
        //Turn off text inside the header image
        define( 'NO_HEADER_TEXT', true );
 
        //Don't forget this, it adds the functionality to the admin menu
        add_custom_image_header( '', 'customisetheme_admin_header_style' );
 
        //Set some custom header images, add as many as you like
        //%s is a placeholder for your theme directory
        $customHeaders = array (
                //Image 1
                'perfectbeach' => array (
                'url' => '%s/images/default.jpg',
                'thumbnail_url' => '%s/images/pb-thumbnail.jpg',
                'description' => __( 'Perfect Beach', 'customisetheme' )
            ),

        );
        //Register the images with WordPress
        register_default_headers($customHeaders);
    }
endif;
 
if ( ! function_exists( 'customisetheme_admin_header_style' ) ) :
    //Function fired and inline styles added to the admin panel
    //Customise as required
    function customisetheme_admin_header_style() {
    ?>
        <style type="text/css">
            #wpbody-content #headimg {
                height: <?php echo header_image_height; ?>px;
                width: <?php echo header_image_width; ?>px;
                border: 1px solid #333;
            }
        </style>
    <?php
    }
endif;
 
//Execute our custom theme functionality
add_action( 'after_setup_theme', 'customisetheme_setup' );

include_once('myfunctions.php');

?>