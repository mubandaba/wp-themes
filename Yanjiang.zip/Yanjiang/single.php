<?php get_header();?>

<?php if (have_posts()) : ?>

<?php while (have_posts()) : the_post(); ?>

<div align="center" class="margin"><a href="<?php echo get_option('home'); ?>" class="dbdtx"><?php if (function_exists('get_avatar')) { echo get_avatar( get_the_author_email(), '50' ); }?></a></div>

<div class="wrap s_clear sjzsy">
<div class="yi_blog">

<?php     
if (function_exists('get_breadcrumbs')){   
    get_breadcrumbs();  
}   
?>
<br>
<hr size=1 style="color:#DDD;border-style:dashed ;width:100%">
<div style="height:10px"></div>
<p style="margin-left:6px;float:left;color:#999;">
<h1 align="center"><?php the_title_attribute(); ?></h1>
</p>
<div style="height:10px"></div>
<hr size=1 style="color:#DDD;border-style:dashed ;width:100%">


<div style="height:5px"></div>

<div class="bi lazy ">

<div class="hentai_post"><p style="margin-left:6px;float:left;color:#999;"><a><?php the_content("Read More...");?></a></p></div>

</div>

<?php
if(get_option('ashu_copy_dianz') != '是')
{
 $xihuan='xihuanxs';
}
?>
 <div class="post-like <?php echo $xihuan; ?>">
         <a href="javascript:;" data-action="ding" data-id="<?php the_ID(); ?>" class="favorite<?php if(isset($_COOKIE['bigfa_ding_'.$post->ID])) echo ' done';?>  $xihuan">喜欢 <span class="count">
            <?php if( get_post_meta($post->ID,'bigfa_ding',true) ){            
                    echo get_post_meta($post->ID,'bigfa_ding',true);
                 } else {
                    echo '0';
                 }?></span>
        </a>
 </div>

<div style="height:30px"></div>

<div class="hentai_time">



<a style="float:left;">&nbsp;<i class="fa fa-user fa-lg"></i>&nbsp;<?php the_author(); ?>&nbsp;&nbsp;&nbsp;<i class="fa fa-clock-o fa-lg"></i>&nbsp;<?php the_date_xml()?></a>

<div class="qaq2 cdlyc2" style="float:right;">
		<a class="cd2">&nbsp;&nbsp;&nbsp;<i class="fa fa-share fa-lg"></i>分享到</a>
  <div class="dropdown2">

          <input class="fxbjk" value="<?php the_permalink() ?>" style="width:160px;">
<div style="height:10px"></div>
	  <div class="bshare-custom"><a title="分享到新浪微博" class="bshare-sinaminiblog"></a><a title="分享到腾讯微博" class="bshare-qqmb"></a><a title="分享到网易微博" class="bshare-neteasemb"></a><a title="分享到人人网" class="bshare-renren"></a><a title="分享到QQ好友" class="bshare-qqim"></a><a title="分享到QQ空间" class="bshare-qzone"></a><a title="更多平台" class="bshare-more bshare-more-icon more-style-addthis"></a></div><script type="text/javascript" charset="utf-8" src="http://static.bshare.cn/b/buttonLite.js#style=-1&amp;uuid=&amp;pophcol=2&amp;lang=zh"></script><script type="text/javascript" charset="utf-8" src="http://static.bshare.cn/b/bshareC0.js"></script>

	  </div>
</div>

<a style="float:right;"><i class="fa fa-users fa-lg"></i>&nbsp;<?php comments_number('No Comment', '1 Comment', '% Comments' );?></a>

<div style="height:20px"></div>

</div>

</div>

</div>


<?php endwhile; ?>


<?php if(get_option('ashu_copy_wzbqsm') == '是') { ?> <?php get_template_part('wzbqsma'); ?> <?php } ?>


<div class="wrap s_clear sjzsy">

<div class="yi_blog" style="height:none;">



<?php comments_template(); ?>



</div>



</div>



<?php else : ?>



<?php endif; ?>







<?php get_footer();?>