<div class="wrap s_clear sjzsy">
<div class="yi_blog" style="height:none;">
<?php $custom_fields = get_post_custom_keys($post_id);
if (!in_array ('copyright', $custom_fields)) : ?>
<p><strong> 原创文章转载请注明出处: </strong>: <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_permalink() ?> | <?php bloginfo('name');?></a></p>
<?php else: ?>
<?php $custom = get_post_custom($post_id);
$custom_value = $custom['copyright']; ?>
<p><strong> 声明: </strong> 本文参考自 <a rel="nofollow" target="_blank" href="/go.php?url=<?php echo $custom_value[0] ?>"><?php echo $custom_value[0] ?></a> ，由(<a href="<?php bloginfo('home'); ?>"> <?php the_author(); ?> </a>) 整编。</p>
<p>本文固定链接: <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_permalink() ?> | <?php bloginfo('name');?></a></p>
<?php endif; ?>
</div>
</div>