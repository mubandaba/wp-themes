<?php
/*****
Template Name: Reader(读者墙)
Version: Yanjiang 1.2
Author: 编谈  http://biantan.org
*****/
?>
<?php get_header();?>

<div class="wrap s_clear sjzsy">
<div class="yi_blog" align="center">

<hr size=1 style="color:#DDD;border-style:dashed ;width:100%">
<div style="height:10px"></div>
<p style="margin-left:6px;float:left;color:#999;">
<h1 align="center"><?php the_title_attribute(); ?></h1>
</p>
<div style="height:10px"></div>
<hr size=1 style="color:#DDD;border-style:dashed ;width:100%">

<?php if(function_exists('bymt_mostactive')) bymt_mostactive('40', '12 MONTH'); ?>

</div>
</div>

<div class="wrap s_clear sjzsy">
<div class="yi_blog" style="height:none;">

<?php comments_template(); ?>

</div>
</div>

<?php get_footer();?>