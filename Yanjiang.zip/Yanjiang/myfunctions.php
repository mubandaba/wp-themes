<?php   
$option = get_option('ashu_copy_right');   
if( $option == '' ){     
    $option = '博客';   
    update_option('ashu_copy_right', $option);   
}   
if(isset($_POST['option_save'])){      
    $option = stripslashes($_POST['ashu_copy_right']);   
    update_option('ashu_copy_right', $option);   
}   
  
?>   

<?php   
$option2 = get_option('ashu_copy_Description');   
if( $option2 == '' ){     
    $option2 = '博客';   
    update_option('ashu_copy_Description', $option2);   
}   
if(isset($_POST['option_save2'])){      
    $option2 = stripslashes($_POST['ashu_copy_Description']);   
    update_option('ashu_copy_Description', $option2);   
}   
  
?>

<?php   
$option3 = get_option('ashu_copy_beianxx');   
if( $option3 == '' ){     
    $option3 = '';   
    update_option('ashu_copy_beianxx', $option3);   
}   
if(isset($_POST['option_save3'])){      
    $option3 = stripslashes($_POST['ashu_copy_beianxx']);   
    update_option('ashu_copy_beianxx', $option3);   
}   
  
?>

<?php   
$option4 = get_option('ashu_copy_sousuo');   
if( $option4 == '' ){     
    $option4 = '站内搜索';   
    update_option('ashu_copy_sousuo', $option4);   
}   
if(isset($_POST['option_save4'])){      
    $option4 = stripslashes($_POST['ashu_copy_sousuo']);   
    update_option('ashu_copy_sousuo', $option4);   
}   
  
?>

<?php   
$option5 = get_option('ashu_copy_tongji');   
if( $option5 == '' ){     
    $option5 = '';   
    update_option('ashu_copy_tongji', $option5);   
}   
if(isset($_POST['option_save5'])){      
    $option5 = stripslashes($_POST['ashu_copy_tongji']);   
    update_option('ashu_copy_tongji', $option5);   
}   
  
?>

<?php   
$option6 = get_option('ashu_copy_tubiao');   
if( $option6 == '' ){     
    $option6 = '';   
    update_option('ashu_copy_tubiao', $option6);   
}   
if(isset($_POST['option_save6'])){      
    $option6 = stripslashes($_POST['ashu_copy_tubiao']);   
    update_option('ashu_copy_tubiao', $option6);   
}   
  
?>

<?php   
$option7 = get_option('ashu_copy_zsjcdwz');   
if( $option7 == '' ){     
    $option7 = '博';   
    update_option('ashu_copy_zsjcdwz', $option7);   
}   
if(isset($_POST['option_save7'])){      
    $option7 = stripslashes($_POST['ashu_copy_zsjcdwz']);   
    update_option('ashu_copy_zsjcdwz', $option7);   
}   
  
?>

<?php   
$option8 = get_option('ashu_copy_wzbjtp');   
if( $option8 == '' ){     
    $option8 = '';   
    update_option('ashu_copy_wzbjtp', $option8);   
}   
if(isset($_POST['option_save8'])){      
    $option8 = stripslashes($_POST['ashu_copy_wzbjtp']);   
    update_option('ashu_copy_wzbjtp', $option8);   
}   
  
?>

<?php   
$option9 = get_option('ashu_copy_htmh');   
if( $option9 == '' ){     
    $option9 = '';   
    update_option('ashu_copy_htmh', $option9);   
}   
if(isset($_POST['option_save9'])){      
    $option9 = stripslashes($_POST['ashu_copy_htmh']);   
    update_option('ashu_copy_htmh', $option9);   
}   
  
?>

<?php   
$option10 = get_option('ashu_copy_dianz');   
if( $option10 == '' ){     
    $option10 = '';   
    update_option('ashu_copy_dianz', $option10);   
}   
if(isset($_POST['option_save10'])){      
    $option10 = stripslashes($_POST['ashu_copy_dianz']);   
    update_option('ashu_copy_dianz', $option10);   
}   
  
?>

<?php   
$option11 = get_option('ashu_copy_mianbx');   
if( $option11 == '' ){     
    $option11 = '';   
    update_option('ashu_copy_mianbx', $option11);   
}   
if(isset($_POST['option_save11'])){      
    $option11 = stripslashes($_POST['ashu_copy_mianbx']);   
    update_option('ashu_copy_mianbx', $option11);   
}   
  
?>

<?php   
$option12 = get_option('ashu_copy_lajipl');   
if( $option12 == '' ){     
    $option12 = '';   
    update_option('ashu_copy_lajipl', $option12);   
}   
if(isset($_POST['option_save12'])){      
    $option12 = stripslashes($_POST['ashu_copy_lajipl']);   
    update_option('ashu_copy_lajipl', $option12);   
}   
  
?>

<?php   
$option13 = get_option('ashu_copy_touxhc');   
if( $option13 == '' ){     
    $option13 = '';   
    update_option('ashu_copy_touxhc', $option13);   
}   
if(isset($_POST['option_save13'])){      
    $option13 = stripslashes($_POST['ashu_copy_touxhc']);   
    update_option('ashu_copy_touxhc', $option13);   
}   
  
?>

<?php   
$option14 = get_option('ashu_copy_wzbqsm');   
if( $option14 == '' ){     
    $option14 = '';   
    update_option('ashu_copy_wzbqsm', $option14);   
}   
if(isset($_POST['option_save14'])){      
    $option14 = stripslashes($_POST['ashu_copy_wzbqsm']);   
    update_option('ashu_copy_wzbqsm', $option14);   
}   
  
?>
  





<?php      
function test_function(){   
    add_menu_page( '主题设置—编谈制作', '主题设置', 'administrator', 'btzt_yanjiang','display_function',get_stylesheet_directory_uri().'/images/sztb.png',52); 
}    
  add_action('admin_menu', 'test_function');

wp_enqueue_script('my-upload', get_bloginfo( 'stylesheet_directory' ) . '/js/upload.js');      
wp_enqueue_script('thickbox');   
wp_enqueue_style('thickbox'); 

function display_function(){ ?>   
    
    <form method="post" name="ashu_form" id="ashu_form">   
    <h1>Yanjiang主题设置</h1>  
    <h2><a href="http://biantan.org/?page_id=764">点这里可以捐助我哦~</a></h2>
    <p>   
    <label>   
    <input name="ashu_copy_right" size="40" value="<?php echo get_option('ashu_copy_right'); ?>"/>   
    请输入网站关键词   
    </label>   
    </p>   
    <p class="submit">   
        <input type="submit" name="option_save" value="<?php _e('保存设置'); ?>" />   
    </p>    
    </form>  

    <form method="post" name="ashu_form" id="ashu_form">   
    <p>   
    <label>   
    <input name="ashu_copy_Description" size="40" value="<?php echo get_option('ashu_copy_Description'); ?>"/>   
    请输入网站描述  
    </label>   
    </p>   
    <p class="submit">   
        <input type="submit" name="option_save2" value="<?php _e('保存设置'); ?>" />   
    </p>    
    </form> 

    <form method="post" name="ashu_form" id="ashu_form">   
    <p>   
    <label>   
    <input name="ashu_copy_beianxx" size="40" value="<?php echo get_option('ashu_copy_beianxx'); ?>"/>   
    这里输入网站备案信息，无请留空。  
    </label>   
    </p>   
    <p class="submit">   
        <input type="submit" name="option_save3" value="<?php _e('保存设置'); ?>" />   
    </p>    
    </form> 

    <form method="post" name="ashu_form" id="ashu_form">   
    <p>   
    <label>   
    <input name="ashu_copy_sousuo" size="40" value="<?php echo get_option('ashu_copy_sousuo'); ?>"/>   
    这里输入搜索框默认显示的文字
    </label>   
    </p>   
    <p class="submit">   
        <input type="submit" name="option_save4" value="<?php _e('保存设置'); ?>" />   
    </p>    
    </form> 

    <form method="post" name="ashu_form" id="ashu_form">   
    <p>   
    <label>   
    <input name="ashu_copy_tongji" size="40" value="<?php echo get_option('ashu_copy_tongji'); ?>"/>   
    这里输入网站统计代码，没有请留空
    </label>   
    </p>   
    <p class="submit">   
        <input type="submit" name="option_save5" value="<?php _e('保存设置'); ?>" />   
    </p>    
    </form> 

    <form method="post" name="ashu_form" id="ashu_form">   
    <p>   
    <label>   
    <input name="ashu_copy_tubiao" size="40" value="<?php echo get_option('ashu_copy_tubiao'); ?>"/>   
    这里输入网站favicon图标url
    </label>   
    </p>   
    <p class="submit">   
        <input type="submit" name="option_save6" value="<?php _e('保存设置'); ?>" />   
    </p>    
    </form> 

    <form method="post" name="ashu_form" id="ashu_form">   
    <p>   
    <label>   
    <input name="ashu_copy_zsjcdwz" size="40" value="<?php echo get_option('ashu_copy_zsjcdwz'); ?>"/>   
    这里输入左上角菜单显示的文字，请设置一个字
    </label>   
    </p>   
    <p class="submit">   
        <input type="submit" name="option_save7" value="<?php _e('保存设置'); ?>" />   
    </p>    
    </form> 

    <form method="post" name="ashu_form" id="ashu_form">   
    <p>   
    <label>   
    <input name="ashu_copy_wzbjtp" size="40" value="<?php echo get_option('ashu_copy_wzbjtp'); ?>"/>   
    这里输入网站背景图片的url
    </label>   
    </p>   
    <p class="submit">   
        <input type="submit" name="option_save8" value="<?php _e('保存设置'); ?>" />   
    </p>    
    </form> 

    <form method="post" name="ashu_form" id="ashu_form">   
    <p>   
    <label>   
    <input name="ashu_copy_htmh" size="40" value="<?php echo get_option('ashu_copy_htmh'); ?>"/>   
    这里输入 是 ，后台登入界面美化开启，留空或其他则不开启
    </label>   
    </p>   
    <p class="submit">   
        <input type="submit" name="option_save9" value="<?php _e('保存设置'); ?>" />   
    </p>    
    </form> 

    <form method="post" name="ashu_form" id="ashu_form">   
    <p>   
    <label>   
    <input name="ashu_copy_dianz" size="40" value="<?php echo get_option('ashu_copy_dianz'); ?>"/>   
    这里输入 是 ，会开启文章点赞功能，留空或其他则不开启
    </label>   
    </p>   
    <p class="submit">   
        <input type="submit" name="option_save10" value="<?php _e('保存设置'); ?>" />   
    </p>    
    </form> 

    <form method="post" name="ashu_form" id="ashu_form">   
    <p>   
    <label>   
    <input name="ashu_copy_mianbx" size="40" value="<?php echo get_option('ashu_copy_mianbx'); ?>"/>   
    这里输入 是 ，会开启文章面包屑功能，留空或其他则不开启
    </label>   
    </p>   
    <p class="submit">   
        <input type="submit" name="option_save11" value="<?php _e('保存设置'); ?>" />   
    </p>    
    </form>

    <form method="post" name="ashu_form" id="ashu_form">   
    <p>   
    <label>   
    <input name="ashu_copy_lajipl" size="40" value="<?php echo get_option('ashu_copy_lajipl'); ?>"/>   
    这里输入 是 ，会开启WordPress第一次评论禁止全英文/屏蔽日语垃圾评论功能，留空或其他则不开启
    </label>   
    </p>   
    <p class="submit">   
        <input type="submit" name="option_save12" value="<?php _e('保存设置'); ?>" />   
    </p>    
    </form>

    <form method="post" name="ashu_form" id="ashu_form">   
    <p>   
    <label>   
    <input name="ashu_copy_touxhc" size="40" value="<?php echo get_option('ashu_copy_touxhc'); ?>"/>   
    这里输入 是 ，会开启头像缓冲功能，留空或其他则不开启（ps：开启此功能需要在博客根目录下新建一个名为 avatar 的文件夹，权限设置为777，在此文件夹内放入default.jpg作为没有头像时默认的显示图片，尺寸为50*50。）
    </label>   
    </p>   
    <p class="submit">   
        <input type="submit" name="option_save13" value="<?php _e('保存设置'); ?>" />   
    </p>    
    </form>

    <form method="post" name="ashu_form" id="ashu_form">   
    <p>   
    <label>   
    <input name="ashu_copy_wzbqsm" size="40" value="<?php echo get_option('ashu_copy_wzbqsm'); ?>"/>   
    这里输入 是 ，会开启文章显示版权功能，留空或其他则不开启（ps：当发表转载的文章的时候，添加自定义栏目（需要点击编辑文章页面右上角的“显示选项”—选中自定义栏目，就可以开始设置了），点击添加新栏目名称为copyright，值设置为转载文章的原链接即）
    </label>   
    </p>   
    <p class="submit">   
        <input type="submit" name="option_save14" value="<?php _e('保存设置'); ?>" />   
    </p>    
    </form>
 



<?php } ?>  