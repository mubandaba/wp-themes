<?php

/*****

Template Name: Links(友情链接)

Version: Yanjiang 1.2

Author: 编谈  http://biantan.org

*****/

?>

<?php get_header(); ?>

<div class="wrap s_clear sjzsy" align="center">

<div class="yi_blog">
<?php     
if (function_exists('get_breadcrumbs')){   
    get_breadcrumbs();  
}   
?>
<br>
		<?php if (have_posts()) : ?>

		<?php while (have_posts()) : the_post(); ?>
<hr size=1 style="color:#DDD;border-style:dashed ;width:100%">
<div style="height:10px"></div>
<p style="margin-left:6px;float:left;color:#999;">
<h1 align="center"><?php the_title_attribute(); ?></h1>
</p>
<div style="height:10px"></div>
<hr size=1 style="color:#DDD;border-style:dashed ;width:100%">
				<?php the_content('Read more...'); ?>

<div class="Mylinks">

					<ul>

						<?php wp_list_bookmarks('orderby=id&category_orderby=id&title_before=<h3>&title_after=</h3>'); ?>

					</ul>

</div>

</div>

</div>

<div class="wrap s_clear sjzsy">

<div class="yi_blog">

		<?php comments_template(); ?>

</div>

</div>

		<?php endwhile; endif; ?>

<?php get_footer(); ?>