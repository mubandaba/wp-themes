<div id="footerlink" class="container">
	<ul>
		<li><i class="icon-link-1 sjzsy"></i> <strong><?php bymt_r('footerlink_word','友情链接', 'e'); ?></strong></li>

		<?php wp_list_bookmarks('orderby=id&categorize=0&title_li=&limit=20');?>
	</ul>
</div>
<div style="height:10px"></div>
<div align="center">
<a><span>博客由<a href="http://cn.wordpress.org/" target="_blank">Wordpress</a><a>驱动.| 主题由</a><a href="http://biantan.org/" target="_blank">编谈</a><a>制作.（感谢言酱~）</a>
<?php
if(get_option('ashu_copy_beianxx') != '')
{        
    echo '| 备案：<a href="http://www.miitbeian.gov.cn/" target="_blank">';
}
?>
<?php echo get_option('ashu_copy_beianxx'); ?>
<?php
if(get_option('ashu_copy_beianxx') != '')
{        
	echo '</a>';
}
?>
</span></a>
<?php echo get_option('ashu_copy_tongji'); ?>
</div>
<div style="height:30px"></div>

<!-- 加载 Fancybox CSS文件 -->
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/fancybox/fancybox.css" />
<!-- 加载 Fancybox JS文件 -->
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/fancybox/fancybox.js"></script>

<script type="text/javascript">
	$(document).ready(function() {
		$(".fancybox").fancybox();
	});
</script>

</body>
</html>