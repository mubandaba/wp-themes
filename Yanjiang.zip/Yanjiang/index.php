﻿﻿<?php get_header();?>



<?php if (have_posts()) : ?>

<?php while (have_posts()) : the_post(); ?>

<div class="wrap s_clear sjzsy" align="center">

<div class="yi_blog">

<div class="hentai_title"><p style="margin-left:6px;float:left;color:#999;"><a href="<?php the_permalink() ?>"><?php the_title_attribute(); ?></a></p></div>

<div class="hentai">

<a href="<?php the_permalink() ?>"><img src="<?php bloginfo('template_directory'); ?>/images/wzt.jpg" class="img-rounded" style="width:auto;height:auto"></a>

<div style="height:5px"></div>

<div class="hentai_post"><p style="margin-left:6px;float:left;color:#999;"><a><?php the_excerpt("Read More..."); ?></a></p></div>

<div style="height:20px"></div>

<div class="hentai_time">

<a style="float:left;">&nbsp;<i class="fa fa-user fa-lg"></i>&nbsp;<?php the_author(); ?>&nbsp;&nbsp;&nbsp;<i class="fa fa-clock-o fa-lg"></i>&nbsp;<?php the_date_xml()?></a>

<a style="float:right;"><i class="fa fa-users fa-lg"></i>&nbsp;<?php comments_number('No Comment', '1 Comment', '% Comments' );?></a>

<?php  
if (is_sticky()) echo '<h3><span style="color: #00ccff;float:right;" class="zdsjxs"><strong>置顶文章&nbsp;&nbsp;&nbsp;</strong></span></h3>';  
?> 

<div style="height:20px"></div>

</div>

</div>

</div>

</div>



<?php endwhile; ?>

<?php else : ?>

<?php endif; ?>

<div style="height:20px"></div>

<div class="page_navi container"><?php par_pagenavi(9); ?></div>

<?php get_footer();?>