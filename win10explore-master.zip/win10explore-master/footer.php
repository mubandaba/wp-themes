<footer>
    <p>Copyright © 2019 <a href="//<?php echo $_SERVER['SERVER_NAME']; ?>"><?php echo bloginfo('name')?> </a>.
        Theme  made by <a href="http://www.lovestu.com/Win10explorer">Win10explorer</a></p>
</footer>
<?php
