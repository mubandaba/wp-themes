<?php
/**
 * The template part for displaying content
 *
 * @since Shaan 2.0
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

    <header class="entry-header">

		<?php
		if ( is_sticky() && is_home() && ! is_paged() ) {
			printf( '<span class="sticky-post">%s</span>', _x( 'Featured', 'post', 'shaan' ) );
		}
		?>
		<?php the_title( sprintf('<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>


        <div class="entry-info">
            <?php shaan_entry_meta(); ?>
        </div>
    </header>

    <div class="entry-content">

	    <?php shaan_post_thumbnail_index(); ?>

        <?php shaan_excerpt(); ?>

    </div><!-- .entry-content -->

	<?php shaan_entry_footer(); ?>

</article>
