<?php

if( ! is_active_sidebar( 'sidebar-header' ) ) {
	return;
}
?>

<aside id="header-sidebar" class="header-sidebar" role="complementary">
	<?php dynamic_sidebar( 'sidebar-header' ); ?>
</aside><!-- .sidebar .widget-area -->
