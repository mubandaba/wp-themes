<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @since Shaan 2.0
 */

get_header();

/**
 * Shaan Layout Options
 */
$shaan_site_layout    =   get_theme_mod( 'shaan_site_layout' );
$shaan_layout_class   =   'col-lg-8 col-md-12';

if( $shaan_site_layout == 'left-sidebar' && is_active_sidebar( 'sidebar-primary' ) ) :
	$shaan_layout_class = 'col-lg-8 col-md-12 order-md-2';
elseif( $shaan_site_layout == 'no-sidebar' || !is_active_sidebar( 'sidebar-primary' ) ) :
	$shaan_layout_class = 'col-lg-12 col-md-12';
endif;

?>


	<div id="primary" class="content-area row row-eq-height">
		<main id="main" class="site-main <?php echo esc_attr($shaan_layout_class); ?>" role="main">

			<section class="error-404 not-found">
				<header class="page-header">
					<h1 class="page-title"><?php esc_attr_e( 'Oops! That page can&rsquo;t be found.', 'shaan' ); ?></h1>
				</header><!-- .page-header -->

				<div class="page-content">
					<p><?php esc_attr_e( 'It looks like nothing was found at this location. Maybe try a search?', 'shaan' ); ?></p>
				</div>

				<?php get_search_form(); ?>
			</section>

		</main><!-- .site-main -->
		<?php get_sidebar(); ?>
	</div><!-- content-area -->

<?php get_footer(); ?>