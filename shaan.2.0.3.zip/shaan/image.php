<?php

/**
 * The template for displaying image attachments
 *
 * @since Shaan 2.0
 */

get_header(); ?>

<?php
/**
 * Shaan Layout Options
 */
$shaan_site_layout    =   get_theme_mod( 'shaan_site_layout' );
$shaan_layout_class   =   'col-lg-8 col-md-12';

if( $shaan_site_layout == 'left-sidebar' && is_active_sidebar( 'sidebar-primary' ) ) :
	$shaan_layout_class = 'col-lg-8 col-md-12 order-md-2';
elseif( $shaan_site_layout == 'no-sidebar' || !is_active_sidebar( 'sidebar-primary' ) ) :
	$shaan_layout_class = 'col-lg-12 col-md-12';
endif;

?>

	<div id="primary" class="content-area row row-eq-height">
		<main id="main" class="site-main <?php echo esc_attr($shaan_layout_class); ?>" role="main">

			<?php
			// Start the loop
			while( have_posts() ) : the_post();
			?>

				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>


					<div id="image-navigation" class="navigation image-navigation">
						<div class="nav-links">
							<div class="nav-previous"><?php previous_image_link( false, __( 'Previous Image', 'shaan' ) ); ?></div>
							<div class="nav-next"><?php next_image_link( false, __( 'Next Image', 'shaan' ) ); ?></div>
						</div><!-- .nav-links -->
					</div><!-- .image-navigation -->

					<header class="entry-header">
						<?php the_title( '<h1 class="entry-title">','</h1>' ); ?>
					</header><!-- .entry-header -->

					<div class="entry-content">
						<div class="entry-attachment">
							<?php
							/**
							 * Filter the default shaan image attachment size.
							 *
							 * @since Shaan 2.0
							 *
							 * @param string $image_size Image size. Default 'large'.
							 */
							$image_size =   apply_filters( 'shaan_attachment_size', 'large' );

							echo wp_get_attachment_image( get_the_ID(), $image_size );

							shaan_excerpt( 'entry-caption' );
							?>


						</div><!-- .entry-attachment -->

						<?php
						the_content();
						wp_link_pages( array(
							'before'        =>  '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'shaan' ) . '</span>',
							'after'         =>  '</div>',
							'link_before'   =>  '<span>',
							'link_after'    =>  '</span>',
							'pagelink'      => '<span class="screen-reader-text">' . __( 'Page', 'shaan' ) . ' </span>%',
							'separator'     => '<span class="screen-reader-text">, </span>',
						) );
						?>
					</div><!-- .entry-content -->

					<footer class="entry-footer">
						<?php
						// Retrieve attachment metadata.
						$metadata   =   wp_get_attachment_metadata();
						if( $metadata ) {
							printf( '<span class="full-size-link">%1$s<a href="%2$s">%3$s &times; %4$s</a></span>',
								esc_html__( 'Full Size: ', 'shaan' ),
								esc_url( wp_get_attachment_url() ),
								absint( $metadata['width'] ),
								absint( $metadata['height'] )
							);
						}
						?>

						<?php
						edit_post_link(
							sprintf(
							/* translators: %s: Name of current post */
								__( 'Edit<span class="screen-reader-text"> "%s"', 'shaan' ),
								get_the_title()
							),
							'<span class="edit-link">',
							'</span>'
						);
						?>
					</footer>
				</article>


				<?php

				the_post_navigation( array(
					'prev_text'     =>  _x( '<span class="meta-nav">Published in</span><span class="post-title">%title</span>', 'Parent Post Link', 'shaan' ),
				) );

				// If comments are open or we have at least one comment, load up the comment template.
				if( comments_open() || get_comments_number() ) {
					comments_template();
				}

				// End the loop.
			endwhile;
			?>

		</main><!-- .site-main -->
		<?php get_sidebar(); ?>
	</div><!-- content-area -->

<?php get_footer(); ?>