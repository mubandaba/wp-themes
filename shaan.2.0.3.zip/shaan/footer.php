        </div><!-- .site-content -->

    </div><!-- site-inner -->
        
        <?php
            /**
             * In case you want to disable the footer.
             */
            $shaan_footer = apply_filters( 'shaan_display_footer', true );

            if( $shaan_footer ) :
        ?>
        <footer id="colophon" class="container site-footer" role="contentinfo">


         <nav id="footer-navigation" class="footer-navigation" role="navigation" aria-label="<?php esc_attr_e( 'Footer Menu', 'shaan' ); ?>">
	            <?php
	            wp_nav_menu( array(
		            'theme_location' => 'footer-menu',
		            'menu_class'     => 'footer-menu',
		            'depth'          => 1,
		            'fallback_cb'    =>  false
	            ) );
	            ?>
         </nav><!-- .main-navigation -->

            <div class="site-info">

			<?php $blog_info_name = get_bloginfo( 'name' ); ?>
			<?php $blog_info_description = get_bloginfo( 'description' ); ?>

			<p class="site-credit">
			<?php if ( ! empty( $blog_info_name ) || ! empty( $blog_info_description ) ) : ?>
				<?php if ( ! empty( $blog_info_name ) ) : ?>
					<?php echo date('Y'); ?> &copy; <a class="site-name" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
				<?php endif; ?>
				<?php if ( ! empty( $blog_info_description ) ) : ?>
					<span class="siteinfo-sep"></span><?php bloginfo( 'description' ); ?>
				<?php endif; ?>
				<span class="siteinfo-sep"></span>
			<?php endif; ?>


                <?php echo esc_html__( 'Proudly powered by', 'shaan' ); ?>
                <a href="<?php echo esc_url( esc_attr__( 'https://wordpress.org/', 'shaan' ) ) ?>"><?php echo esc_html__( 'WordPress', 'shaan' ); ?></a> <span class="theme-sep"></span>

		    <?php if( is_front_page() || is_home() ) { $rel = ' rel="designer"'; } else { $rel = ' rel="nofollow"'; } ?>

			<?php
				$themeinfo = wp_get_theme();
				echo '<a'. $rel .' href="' . esc_url($themeinfo->get( 'ThemeURI' ) ) . '">';
				echo esc_attr($themeinfo->get( 'Name' ));
				echo '</a>';
			?>

			</p>
            </div>
        </footer>
        <?php 
            endif; 
        ?>
</div><!-- site -->

<div class="search-popup">
	<?php get_search_form(); ?>
     <span class="search-popup-close"><i class="fa fa-times"></i></span>
</div><!-- .search-popup -->

<?php wp_footer(); ?>
</body>
</html>