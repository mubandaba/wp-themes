<?php get_header(); ?>

<?php
/**
 * Shaan Layout Options
 */
$shaan_site_layout    =   get_theme_mod( 'shaan_site_layout' );
$shaan_layout_class   =   'col-lg-8 col-md-12';

if( $shaan_site_layout == 'left-sidebar' && is_active_sidebar( 'sidebar-primary' ) ) :
	$shaan_layout_class = 'col-lg-8 col-md-12 order-md-2';
elseif( $shaan_site_layout == 'no-sidebar' || !is_active_sidebar( 'sidebar-primary' ) ) :
	$shaan_layout_class = 'col-lg-12 col-md-12';
endif;

?>

<div id="primary" class="content-area row row-eq-height">
    <main id="main" class="site-main <?php echo esc_attr($shaan_layout_class); ?>" role="main">

	    <?php
        if( have_posts() ) : ?>

		    <?php if( is_home() && ! is_front_page() ) : ?>
                <header class="page-header">
                    <h1 class="page-title screen-reader-text">
                        <?php single_post_title(); ?>
                    </h1>
                </header>
		    <?php endif; ?>

            <?php
            // Start the loop
            while( have_posts() ) : the_post();

            get_template_part( 'template-parts/content', get_post_format() );

            // End the loop
            endwhile;

		  shaan_page_navigation();

        else :
	        get_template_part( 'template-parts/content', 'none' );
            ?>
        <?php endif; ?><!-- have_post() -->

    </main><!-- .site-main -->
    <?php get_sidebar(); ?>
</div><!-- content-area -->

<?php get_footer(); ?>