<?php

function shaan_social_icons( $wp_customize ) {

	/**
	 * Social Settings Section
	 */
	$wp_customize->add_section( 'shaan_social_section', array(
		'title'                 =>  esc_html__( 'Social Settings', 'shaan' ),
		'panel'                 =>  'shaan_panel'
	) );

	/**
	 * Facebook Social Handle Setting
	 */
	$wp_customize->add_setting( 'shaan_facebook_handle', array(
		'default'               =>  '',
		'transport'             =>  'refresh',
        array(
	        'sanitize_callback'     =>  'esc_url_raw',
        )
	) );

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'shaan_facebook_social_input',
			array(
				'label'         =>  esc_html__( 'Facebook', 'shaan' ),
				'section'       =>  'shaan_social_section',
				'settings'      =>  'shaan_facebook_handle',
				'type'          =>  'url'
			)
		)
	);

	/**
	 * Twitter Social Handle Setting
	 */
	$wp_customize->add_setting( 'shaan_twitter_handle', array(
		'default'               =>  '',
		'transport'             =>  'refresh',
		array(
			'sanitize_callback'     =>  'esc_url_raw',
		)
	) );

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'shaan_twitter_social_input',
			array(
				'label'         =>  esc_html__( 'Twitter', 'shaan' ),
				'section'       =>  'shaan_social_section',
				'settings'      =>  'shaan_twitter_handle',
				'type'          =>  'url'
			)
		)
	);

	/**
	 * Linkedin Social Handle Setting
	 */
	$wp_customize->add_setting( 'shaan_linkedin_handle', array(
		'default'               =>  '',
		'transport'             =>  'refresh',
		array(
			'sanitize_callback'     =>  'esc_url_raw',
		)
	) );

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'shaan_linkedin_social_input',
			array(
				'label'         =>  esc_html__( 'Linkedin', 'shaan' ),
				'section'       =>  'shaan_social_section',
				'settings'      =>  'shaan_linkedin_handle',
				'type'          =>  'url'
			)
		)
	);

	/**
	 * Instagram Social Handle Setting
	 */
	$wp_customize->add_setting( 'shaan_instagram_handle', array(
		'default'               =>  '',
		'transport'             =>  'refresh',
		array(
			'sanitize_callback'     =>  'esc_url_raw',
		)
	) );

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'shaan_instagram_social_input',
			array(
				'label'         =>  esc_html__( 'Instagram', 'shaan' ),
				'section'       =>  'shaan_social_section',
				'settings'      =>  'shaan_instagram_handle',
				'type'          =>  'url'
			)
		)
	);


	/**
	 * Pinterest Social Handle Setting
	 */
	$wp_customize->add_setting( 'shaan_pinterest_handle', array(
		'default'               =>  '',
		'transport'             =>  'refresh',
		array(
			'sanitize_callback'     =>  'esc_url_raw',
		)
	) );

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'shaan_pinterest_social_input',
			array(
				'label'         =>  esc_html__( 'Pinterest', 'shaan' ),
				'section'       =>  'shaan_social_section',
				'settings'      =>  'shaan_pinterest_handle',
				'type'          =>  'url'
			)
		)
	);

	/**
	 * Email Social Handle Setting
	 */
	$wp_customize->add_setting( 'shaan_email_handle', array(
		'default'               =>  '',
		'transport'             =>  'refresh',
		array(
			'sanitize_callback' => 'sanitize_email'
		)
	) );

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'shaan_email_social_input',
			array(
				'label'         =>  esc_html__( 'Email', 'shaan' ),
				'section'       =>  'shaan_social_section',
				'settings'      =>  'shaan_email_handle',
				'type'          =>  'email'
			)
		)
	);

}

function shaan_social_icons_output() {
	$shaan_facebook_handle       =   get_theme_mod( 'shaan_facebook_handle' );
	$shaan_twitter_handle        =   get_theme_mod( 'shaan_twitter_handle' );
	$shaan_linkedin_handle       =   get_theme_mod( 'shaan_linkedin_handle' );
	$shaan_instagram_handle      =   get_theme_mod( 'shaan_instagram_handle' );
	$shaan_pinterest_handle      =   get_theme_mod( 'shaan_pinterest_handle' );
	$shaan_email_handle          =   get_theme_mod( 'shaan_email_handle' );

	if( $shaan_facebook_handle || $shaan_twitter_handle || $shaan_linkedin_handle || $shaan_instagram_handle || $shaan_pinterest_handle || $shaan_email_handle ) : ?>
		<div class="social-links">
			<?php if( $shaan_facebook_handle ) : ?>
				<a href="<?php echo esc_url( $shaan_facebook_handle ); ?>" target="_blank"><span class="fa fa-facebook"></span></a>
			<?php endif; ?>

			<?php if( $shaan_twitter_handle ) : ?>
				<a href="<?php echo esc_url( $shaan_twitter_handle ); ?>" target="_blank"><span class="fa fa-twitter"></span></a>
			<?php endif; ?>

			<?php if( $shaan_linkedin_handle ) : ?>
				<a href="<?php echo esc_url( $shaan_linkedin_handle ); ?>" target="_blank"><span class="fa fa-linkedin"></span></a>
			<?php endif; ?>

			<?php if( $shaan_instagram_handle ) : ?>
				<a href="<?php echo esc_url( $shaan_instagram_handle ); ?>" target="_blank"><span class="fa fa-instagram"></span></a>
			<?php endif; ?>

			<?php if( $shaan_pinterest_handle ) : ?>
				<a href="<?php echo esc_url( $shaan_pinterest_handle ); ?>" target="_blank"><span class="fa fa-pinterest"></span></a>
			<?php endif; ?>

			<?php if( $shaan_email_handle ) : ?>
				<a href="mailto:<?php echo sanitize_email($shaan_email_handle); ?>" title="<?php echo esc_attr($shaan_email_handle); ?>"><span class="fa fa-envelope"></span></a>
			<?php endif; ?>
		</div>
	<?php
    else :
	    return null;
	endif;
}