<?php

function shaan_misc_options( $wp_customize ) {

	/**
	 * Shaan Misc Options Section
	 */
	$wp_customize->add_section( 'shaan_misc_section', array(
		'title'                 =>  esc_html__( 'Misc Settings', 'shaan' ),
		'panel'                 =>  'shaan_panel'
	) );

	/**
	 * Show Author Bio
	 */
	$wp_customize->add_setting( 'shaan_author_bio', array(
		'default'               =>  1,
		'sanitize_callback'     =>  'shaan_checkbox_sanitize',
		'transport'             =>  'refresh'
	) );
	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'shaan_author_bio_input',
			array(
				'label'         =>  esc_html__( 'Show Author Description in Posts', 'shaan' ),
				'section'       =>  'shaan_misc_section',
				'settings'      =>  'shaan_author_bio',
				'type'          =>  'checkbox'
			)
		)
	);

}

function shaan_social_search_check() {
	$shaan_facebook_handle       =   get_theme_mod( 'shaan_facebook_handle' );
	$shaan_twitter_handle        =   get_theme_mod( 'shaan_twitter_handle' );
	$shaan_google_plus_handle    =   get_theme_mod( 'shaan_google_plus_handle' );
	$shaan_linkedin_handle       =   get_theme_mod( 'shaan_linkedin_handle' );
	$shaan_instagram_handle      =   get_theme_mod( 'shaan_instagram_handle' );
	$shaan_pinterest_handle      =   get_theme_mod( 'shaan_pinterest_handle' );
	$shaan_email_handle          =   get_theme_mod( 'shaan_email_handle' );

	if( $shaan_facebook_handle || $shaan_twitter_handle || $shaan_google_plus_handle || $shaan_linkedin_handle || $shaan_instagram_handle || $shaan_pinterest_handle || $shaan_email_handle ) :
		return 1;
	else :
		return 0;
	endif;

}