<?php

if( ! function_exists( 'shaan_layout_option_sanitize' ) ) :
function shaan_layout_option_sanitize( $value ) {

	if( ! in_array( $value, array( 'right-sidebar', 'left-sidebar', 'no-sidebar' ) ) ) {
		$layout = 'right-sidebar';
	}

	return $value;
}
endif;

if( ! function_exists( 'shaan_layout_header_sanitize' ) ) :
function shaan_layout_header_sanitize( $value ) {

	if( ! in_array( $value, array( 'default', 'center' ) ) ) {
		$layout = 'default';
	}

	return $value;
}
endif;

if( ! function_exists( 'shaan_checkbox_sanitize' ) ) :
function shaan_checkbox_sanitize( $value ) {

	if( ! in_array( $value, array( 0, 1 ) ) ) {
		$value = 1;
	}

	return $value;
}
endif;