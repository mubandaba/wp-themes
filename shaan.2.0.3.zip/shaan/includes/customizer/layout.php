<?php

function shaan_layout_options( $wp_customize ) {

	$wp_customize->add_section( 'shaan_layout_section', array(
		'title'                 =>  esc_html__( 'Layout Settings', 'shaan' ),
		'panel'                 =>  'shaan_panel'
	) );

	$wp_customize->add_setting( 'shaan_site_layout', array(
		'default'               =>  'right-sidebar',
		'sanitize_callback'     =>  'shaan_layout_option_sanitize',
		'transport'             =>  'refresh'
	) );

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'layout_options_input',
			array(
				'label'         =>  esc_html__( 'Site Layout', 'shaan' ),
				'section'       =>  'shaan_layout_section',
				'settings'      =>  'shaan_site_layout',
				'type'          =>  'radio',
				'choices'       =>  array(
					'left-sidebar'      =>  esc_html__( 'Sidebar Left', 'shaan' ),
					'right-sidebar'     =>  esc_html__( 'Sidebar Right', 'shaan' ),
					'no-sidebar'        =>  esc_html__( 'No Sidebar', 'shaan' )
				)
			)
		)
	);

	$wp_customize->add_setting( 'shaan_header_layout', array(
		'default'               =>  'default',
		'sanitize_callback'     =>  'shaan_layout_header_sanitize',
		'transport'             =>  'refresh'
	) );

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'layout_header_input',
			array(
				'label'         =>  esc_html__( 'Header Layout', 'shaan' ),
				'section'       =>  'shaan_layout_section',
				'settings'      =>  'shaan_header_layout',
				'type'          =>  'radio',
				'choices'       =>  array(
					'default'      =>  esc_html__( 'Default Left', 'shaan' ),
					'center'       =>  esc_html__( 'Center Align', 'shaan' ),
				)
			)
		)
	);

	/**
	 * Show Header Image
	 */
	$wp_customize->add_setting( 'shaan_header_image', array(
		'default'               =>  0,
		'sanitize_callback'     =>  'shaan_checkbox_sanitize',
		'transport'             =>  'refresh'
	) );
	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'shaan_header_image_input',
			array(
				'label'         =>  esc_html__( 'Show Header Image Site Wide', 'shaan' ),
				'section'       =>  'shaan_layout_section',
				'settings'      =>  'shaan_header_image',
				'type'          =>  'checkbox'
			)
		)
	);


}