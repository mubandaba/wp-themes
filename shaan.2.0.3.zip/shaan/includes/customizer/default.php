<?php

function shaan_customizer_default_settings( $wp_customize ) {

	$wp_customize->get_setting( 'blogname' )->transport         =   'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  =   'postMessage';

	if( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial(
			'blogname', array(
			'selector'              =>  '.site-title a',
			'_inclusive'   =>  false,
			'render_callback'       =>  'shaan_customize_partial_blogname'
		)   );
		$wp_customize->selective_refresh->add_partial(
			'blogdescription', array(
			'selector'              =>  '.site-description',
			'_inclusive'   =>  false,
			'render_callback'       =>  'shaan_customize_partial_blogdescription'
		)   );
	}

}

/**
 * Render the site title for the selective refresh partial.
 *
 * @since Shaan 2.0
 * @see shaan_customize_register()
 *
 * @return void
 */
function shaan_customize_partial_blogname() {
	bloginfo( 'name' );
}

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @since Shaan 2.0
 * @see shaan_customize_register()
 *
 * @return void
 */
function shaan_customize_partial_blogdescription() {
	bloginfo( 'description' );
}

function shaan_header_style() {

	// If the header text option is untouched, let's bail.
	if ( display_header_text() ) {
		return;
	}

	// If the header text has been hidden.
	?>
	<style type="text/css" id="header-css">
		.site-branding .site-title,
		.site-description {
			clip: rect(1px, 1px, 1px, 1px);
			position: absolute;
		}
	</style>
	<?php
}