<?php

function shaan_theme_setup() {

	add_theme_support( 'title-tag' );

	/*
	 * Enable support for custom logo.
	 *
	 *  @since Shaan 2.0
	 */
	add_theme_support( 'custom-logo', array(
		'height'      => 120,
		'width'       => 360,
		'flex-width' => true,
		'flex-height' => true,
	) );

	/**
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link http://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	 */
	add_theme_support( 'post-thumbnails' );

	add_theme_support( 'custom-header', apply_filters( 'custom_header_args', array(
		'default-text-color'     => '#121212',
		'width'                  => 1800,
		'height'                 => 450,
		'flex-height'            => true,
		'wp-head-callback'       => 'shaan_header_style',
	) ) );

	$defaults = array(
		'default-color'          => '#22609E',
		'default-repeat'         => 'no-repeat',
		'default-position-x'     => 'center',
		'wp-head-callback'       => '_custom_background_cb',
	);

	add_theme_support( 'custom-background', $defaults );

	add_theme_support( 'screen-reader-text' );

	add_theme_support( 'automatic-feed-links' );

	add_theme_support( 'html5', array( 'comment-list', 'comment-form', 'gallery', 'caption' ) );

	// Add support for Block Styles.
	add_theme_support( 'wp-block-styles' );

	// Add support for editor styles.
	add_theme_support( 'editor-styles' );
	add_editor_style( get_template_directory_uri() . '/assets/css/editor-style.css' );

	// Load Text Domain
	load_theme_textdomain( 'shaan', get_template_directory() . '/languages' );

	/**
	 * Post Formats
	 */
	add_theme_support( 'post-formats', array( 'gallery', 'video', 'audio' ) );


	register_nav_menus( array(
            'primary-menu' => __( 'Primary Menu', 'shaan' ),
            'footer-menu'  => __( 'Footer Menu', 'shaan' ),
        ) );
        


	if ( ! isset( $content_width ) ) $content_width = 1080;
}

function shaan_body_classes( $classes ) {
	// Adds "custom-background-image" class when custom background image present
	if ( get_background_image() ) {
		$classes[] = 'custom-background-image';
	}
	// Adds color class when custom color scheme chosen from theme settings
	if ( get_theme_mod( 'shaan_layout_color_setting', 'default') !== 'default') {
		$classes[] = get_theme_mod( 'shaan_layout_color_setting', 'default');
	}

	return $classes;
}
add_filter( 'body_class', 'shaan_body_classes' );


/**
 * Handles JavaScript detection.
 *
 * Adds a `js` class to the root `<html>` element when JavaScript is detected.
 *
 * @since Shaan 2.0
 */
function shaan_javascript_detection() {
	echo "<script>(function(html){html.className = html.className.replace(/\bno-js\b/,'js')})(document.documentElement);</script>\n";
}
add_action( 'wp_head', 'shaan_javascript_detection', 0 );