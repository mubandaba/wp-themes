<?php

function shaan_theme_enqueue() {

	wp_register_style(
		'shaan-google-fonts',
		'//fonts.googleapis.com/css?family=Noto+Sans:400,400i,700&subset=devanagari'
	);
	wp_register_style(
		'bootstrap',
		get_template_directory_uri() . '/assets/css/bootstrap.min.css',
		false,
		'4.1.3'
	);
	wp_register_style(
		'font-awesome',
		get_template_directory_uri() . '/assets/css/fontawesome.min.css',
		false,
		'4.7.0'
	);
	wp_register_style(
		'shaan-style',
		get_stylesheet_uri()
	);

	wp_enqueue_style( 'shaan-google-fonts' );
	wp_enqueue_style( 'bootstrap' );
	wp_enqueue_style( 'font-awesome' );
	wp_enqueue_style( 'shaan-style' );

	wp_register_script(
		'skip-link-focus-fix',
		get_template_directory_uri() . '/assets/js/skip-link-focus-fix.js',
		array(), '1.0', true
	);

	wp_register_script(
		'jquery-bootstrap',
		get_template_directory_uri() . '/assets/js/bootstrap.min.js',
		array( 'jquery' ),
		'3.3.7', true
	);

	wp_register_script(
		'shaan-main-js',
		get_template_directory_uri() . '/assets/js/main.js',
		array( 'jquery' ),
		'1.0', true
	);

	wp_localize_script( 'shaan-main-js', 'shaan_screenReaderText', array(
		'expand'   => __( 'expand child menu', 'shaan' ),
		'collapse' => __( 'collapse child menu', 'shaan' ),
	) );

	wp_enqueue_script( 'skip-link-focus-fix' );
	wp_enqueue_script( 'jquery-bootstrap' );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	wp_enqueue_script( 'shaan-main-js' );
}