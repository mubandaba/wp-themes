<?php

function shaan_customize_register( $wp_customize ) {

	/**
	 * Shaan Default Customizer Settings
	 */
	shaan_customizer_default_settings( $wp_customize );

	/**
	 * Shaan Layout Options
	 */
	shaan_layout_options( $wp_customize );

	/**
	 * Shaan Social Options
	 */
	shaan_social_icons( $wp_customize );

	/**
	 * Shaan Social Options
	 */
	shaan_misc_options( $wp_customize );

    $wp_customize->remove_control('header_textcolor');
    $wp_customize->remove_control('background_color');

	/**
     * Shaan Theme Options Panel
     */
	$wp_customize->add_panel( 'shaan_panel', array(
        'title'         =>  esc_html__( 'Theme Options', 'shaan' ),
        'priority'      =>  40
    ) );

}

