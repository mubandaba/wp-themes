<?php

/**
 * Displays an optional post thumbnail.
 *
 * @since Shaan 2.0
 */
function shaan_post_thumbnail() {
	if( post_password_required() || is_attachment() || ! has_post_thumbnail() ) {
		return;
	}

	$featuredimage_id = get_post_thumbnail_id( get_the_id() ); 
	$featuredimage = wp_get_attachment_image_src( $featuredimage_id, 'large' );

	// Check Featured Image Width
	if ( $featuredimage[1] < 780 ) return;

	if( is_singular() ) :?>

		<div class="entry-thumbnail">
			<?php the_post_thumbnail('large'); ?>
		</div><!-- .post-thumbnail -->

	<?php else : ?>

		<a class="entry-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true">
			<?php the_post_thumbnail( 'large', array(
				'alt'       =>  the_title_attribute( 'echo=0' )
			) ); ?>
		</a>

	<?php endif; // End is_singular()
}

/**
 * Displays an optional post thumbnail.
 *
 * @since Shaan 2.0
 */
function shaan_post_thumbnail_index() {
	if( post_password_required() || is_attachment() || ! has_post_thumbnail() ) {
		return;
	}

	$featuredimage_id = get_post_thumbnail_id( get_the_id() ); 
	$featuredimage = wp_get_attachment_image_src( $featuredimage_id, 'large' );

	// Check Featured Image Width
	if ( $featuredimage[1] < 779 ) :
	
		$thumbsize = 'thumbnail';
		$alignment = ' thumbnail alignleft';
	
	else:
	
		$thumbsize = 'large';
		$alignment = ' alignnone';
	
	endif;	

	if( ! is_singular() ) :?>

		<a class="entry-thumbnail <?php echo $alignment; ?>" href="<?php the_permalink(); ?>" aria-hidden="true">
			<?php the_post_thumbnail( $thumbsize, array(
				'alt'       =>  the_title_attribute( 'echo=0' )
			) ); ?>
		</a>

	<?php endif; // End is_singular()
}

/**
 * Displays the optional excerpt.
 *
 * @since Shaan 2.0
 */
function shaan_excerpt( $class = 'entry-summary' ) {
    $class = esc_attr( $class );

    if( ! is_single() ) : ?>
        <div class="<?php echo $class; ?>">
            <?php the_excerpt(); ?>
        </div>
    <?php endif;
}

/**
 * Prints HTML with meta information
 *
 * @since Shaan 2.0
 */
function shaan_entry_meta() {

    shaan_entry_author();
    shaan_entry_date();

    edit_post_link(
	    sprintf(
	    /* translators: %s: Name of current post */
		    __( 'Edit<span class="screen-reader-text"> "%s"', 'shaan' ),
		    get_the_title()
	    ),
	    ' <span class="edit-link"><i class="fa fa-edit"></i> ',
	    '</span>'
    );


}

function shaan_entry_author() {

    $author_id  =   get_the_author_meta( 'ID' );
    $author_url =   get_author_posts_url( $author_id );

	printf( 
		'<span class="author-info"><i class="fa fa-user"></i> <a href="%1$s">%2$s</a></span>', 
		esc_url( $author_url ), 
		esc_html( get_the_author_meta( 'display_name', $author_id ) ) 
	);

}


function shaan_entry_date() {
	$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';

	if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
		$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
	}

	$time_string = sprintf( $time_string,
		esc_attr( get_the_date( 'c' ) ),
		get_the_date(),
		esc_attr( get_the_modified_date( 'c' ) ),
		get_the_modified_date()
	);

	printf( '<span class="posted-on"><i class="fa fa-calendar"></i> %1$s</span>',
		$time_string
	);
}

function shaan_page_navigation() {

    if ( paginate_links() ):

		$linkargs = array(
			'prev_next'          => true,
			'prev_text'          => __('Previous', 'shaan'),
			'next_text'          => __('Next', 'shaan'),
			'type'               => 'list',
		);

		?>
		
	   <div class="pagination">
	   <?php echo paginate_links($linkargs); ?>
        </div>
	   
    <?php
    elseif( get_next_posts_link() || get_previous_posts_link() ) :
    ?>

        <div class="pagination">
            <span class="nav-next pull-left"><?php previous_posts_link( '&larr; ' . esc_attr__( 'Newer posts', 'shaan' ) ); ?></span>
            <span class="nav-previous pull-right"><?php next_posts_link( esc_attr__( 'Older posts', 'shaan' ) . ' &rarr;' ); ?></span>
        </div>

<?php
    endif;
}

function shaan_entry_footer() {

	/* translators: used between list items, there is a space after the comma */
	$separate_meta = __( ', ', 'shaan' );

	// Get Categories for posts.
    $categories_list = get_the_category_list( $separate_meta );

	// Get Tags for posts.
    $tags_list = get_the_tag_list( '', $separate_meta );

	// We don't want to output .entry-footer if it will be empty, so make sure its not.
    if( ( $categories_list || $tags_list ) || get_edit_post_link() ) :

        echo '<footer class="entry-footer clearfix">';

        if( 'post' === get_post_type() && is_singular() ) {

            if( $categories_list || $tags_list ) {

                    echo '<span class="cat-tags-links">';

	                // Make sure there's more than one category before displaying.
                    if( $categories_list ) {
                        echo '<span class="cat-links">' . '<span class="cat-icon"><i class="fa fa-folder-open"></i></span>' . '<span class="screen-reader-text">' . esc_attr__( 'Categories', 'shaan' ) . '</span>' . $categories_list . '</span>';
                    }

		          if ( $tags_list ) {
			          echo '<span class="tags-links">' . '<span class="tags-icon"><i class="fa fa-hashtag" aria-hidden="true"></i></span>' . '<span class="screen-reader-text">' . esc_attr__( 'Tags', 'shaan' ) . '</span>' . $tags_list . '</span>';
		          }

                    echo '</span>';

                }

        }

        if( 'post' === get_post_type() && !is_singular() ) {
			   echo '<p class="read-more pull-right btn btn-sm"><a href="'. get_the_permalink() .'">' . esc_attr__( 'Read more', 'shaan' ) .' <i class="fa fa-chevron-right"></i></a></p>';
        	   
        }
        	
        echo '</footer>';

    endif;
}

function shaan_custom_excerpt_more( $more ) {
	return '...';
}
add_filter( 'excerpt_more', 'shaan_custom_excerpt_more' );