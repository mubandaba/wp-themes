<!doctype html>
<html <?php language_attributes(); ?>>
<head class="no-js">
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="profile" href="http://gmpg.org/xfn/11">
	<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
        <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php endif; ?>
    <?php wp_head(); ?>

</head>
<?php 
/**
 * Shaan Theme Option
 */
$shaan_header_layout    =   get_theme_mod( 'shaan_header_layout', 'default');
$shaan_header_image    =   get_theme_mod( 'shaan_header_image', 0);
?>
<body <?php body_class(); ?>>
<div id="page" class="site">

     <a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'shaan' ); ?></a>

     <?php if ( has_nav_menu( 'primary-menu' ) && ( shaan_social_search_check() == 1 )) : ?>
	<div id="topnav" class="menu-wrapper">
		<div class="container">
		<div class="row">

		<div id="site-header-menu" class="site-header-menu col-12 col-lg-8 order-2 order-lg-2">

                   <nav id="site-navigation" class="main-navigation" role="navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'shaan' ); ?>">
			            <?php
			            wp_nav_menu( array(
				            'theme_location' => 'primary-menu',
				            'menu_class'     => 'primary-menu',
				            'fallback_cb'    =>  false
			            ) );
			            ?>
                   </nav><!-- .main-navigation -->
          </div><!-- .site-header-menu -->

		<div class="col-12 col-lg-4 order-1 order-lg-2">

                <button id="menu-toggle" class="menu-toggle toggled-on" aria-expanded="true" aria-controls="site-navigation"><span class="screen-reader-text"><?php esc_html_e( 'Menu', 'shaan' ) ?></span></button>

			<?php shaan_social_icons_output(); ?>
			<span class="btn-search fa fa-search icon-button-search"></span>

		</div>

		</div>
		</div>
	</div><!-- .menu-wrapper -->

	<?php elseif( has_nav_menu( 'primary-menu' ) ): ?>

       <div id="topnav" class="menu-wrapper">
		<div class="container">
		<div class="row">

  		<div class="col-10 d-lg-none align-self-center order-2 order-lg-1">
                <button id="menu-toggle" class="menu-toggle toggled-on" aria-expanded="true" aria-controls="site-navigation"><span class="screen-reader-text"><?php esc_html_e( 'Menu', 'shaan' ) ?></span></button>
                
  		</div>

           <div id="site-header-menu" class="site-header-menu col-12 col-lg-11 order-3 order-lg-2">

                   <nav id="site-navigation" class="main-navigation" role="navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'shaan' ); ?>">
			            <?php
			            wp_nav_menu( array(
				            'theme_location' => 'primary-menu',
				            'menu_class'     => 'primary-menu',
				            'fallback_cb'    =>  false
			            ) );
			            ?>
                   </nav><!-- .main-navigation -->
           </div><!-- .site-header-menu -->

		<div class="col-2 col-lg-1 order-1 order-lg-3">

			<?php shaan_social_icons_output(); ?>
			<span class="btn-search fa fa-search icon-button-search"></span>

		</div>

		</div>
		</div>
       </div><!-- .menu-wrapper -->
       <?php endif; ?>

        <header id="masthead" class="site-header <?php echo $shaan_header_layout; ?>" role="banner">

        <?php if( ( function_exists( 'the_custom_logo' )  &&  has_custom_logo() ) || ( display_header_text() && (get_bloginfo( 'name' ) != '') ) ): ?> 
        <div class="site-header-main container">


            <div class="site-branding">
            
	                <?php if( function_exists( 'the_custom_logo' ) ) : ?> 
					<?php if ( has_custom_logo() ) : 
						?>
						<div class="site-logo"><?php the_custom_logo(); ?></div>
					<?php endif; ?>
				<?php endif; ?>

				<?php	
	                if( is_front_page() && is_home() ) : ?>
	                    <h1 class="site-title">
	                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
	                            <?php bloginfo( 'name' ); ?>
	                        </a>
	                    </h1>
	                <?php else : ?>
	                    <p class="site-title">
	                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
	                            <?php bloginfo( 'name' ); ?>
	                        </a>
	                    </p>
	                <?php endif; ?>
	                <?php
	                $description = get_bloginfo( 'description', 'display' );
	                if( $description || is_customize_preview() ) :
	                ?>
	                    <p class="site-description align-self-center"><?php echo esc_html( $description ); ?></p>
	                <?php endif; ?>

            </div><!-- .site-branding -->

        </div><!-- .site-header-main -->
		<?php endif; ?>

	    <?php 
	    if( has_custom_header() && ($shaan_header_image == 0) && is_front_page() && is_home() ) : ?>
	        <!-- Header Image -->
	        <div class="header-image">
                   <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
				<img src="<?php header_image() ?>">
				</a>
	        </div>
	    <?php elseif( has_custom_header() && ($shaan_header_image == 1) ) : ?>
	        <!-- Header Image -->
	        <div class="header-image">
                   <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
				<img src="<?php header_image() ?>">
				</a>
	        </div>
	    <?php endif; ?>
			
	</header>

	<?php if( is_active_sidebar( 'sidebar-header' )): ?>
  		<div class="header-widget-wraper container">
			<?php get_sidebar('header'); ?>
  		</div>
	<?php endif; ?>

    <div class="site-inner container">

     <div id="content" class="site-content">