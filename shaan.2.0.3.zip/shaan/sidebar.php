<?php

if( ! is_active_sidebar( 'sidebar-primary' ) ) {
	return;
}

/**
 * Shaan Layout Options
 */
$shaan_site_layout    =   get_theme_mod( 'shaan_site_layout' );

if( $shaan_site_layout == 'no-sidebar' ) {
	return;
}elseif( $shaan_site_layout == 'left-sidebar' ) {
	$order = ' order-md-1';
}else {
	$order = '';
}

?>

<aside id="secondary" class="sidebar widget-area col-lg-4 col-md-12<?php echo $order; ?>" role="complementary">
	<?php dynamic_sidebar( 'sidebar-primary' ); ?>
</aside><!-- .sidebar .widget-area -->
