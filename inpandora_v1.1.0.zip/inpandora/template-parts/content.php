<?php
/**
 * The template part for displaying content
 *
 * @package WordPress
 * @subpackage Inpandora
 * @since Wbolt 1.0
 */

?>
<article class="post">
    <div class="inner">
        <a class="media-pic<?php echo $sp_class; ?>" href="<?php echo get_permalink(); ?>">
            <?php wbolt_post_thumbnail(); ?>
        </a>

        <div class="media-body">
            <div class="post-cate">
                <a class="cate-tag" href="<?php echo get_category_link( get_article_category_ID() ); ?>" target="_blank"><?php $cate = get_the_category(); echo $cate[0]->cat_name;  ?></a>
            </div>
            <?php the_title( sprintf( '<a class="post-title" href="%s">', esc_url( get_permalink() ) ), '</a>' );
            ?>
            <div class="post-metas">
                <span class="meta-item primary">
                    <?php echo wbolt_svg_icon('wbsico-time'); ?>
                    <em><?php the_time('M d, Y') ?></em>
                </span>
                <span class="meta-item">
                    <?php echo wbolt_svg_icon('wbsico-download'); ?>
                    <em><?php echo getPostMataVal('post_downs'); ?></em>
                </span>
            </div>
        </div>
    </div>
</article>
