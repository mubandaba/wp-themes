<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Inpandora
 * @since Wbolt 1.1.0
 */

get_header(); ?>

<div class="main">
	<?php echo WBOptions::insertAdBlock('index_block','adbanner-block under-list-title'); ?>

    <!--最新更新 S-->
    <div class="title-floor">
        <h3>最新更新</h3>
        <p class="tf-ft">
            <a class="view-more" href="<?php  echo get_permalink(get_page_by_path('newest')) ;?>">更多 &gt;</a>
        </p>
    </div>

    <div class="articles-list<?php if(wp_is_mobile()) echo ' with-list-mode list-mode-b'; ?>">
		<?php
		/*add_action('pre_get_posts',function($query){
			$query->is_home = true;
		});*/

		$homeFlID = WBOptions::opt('flID')?WBOptions::opt('flID'):'';
		$arg = array('showposts'=>12,'post_type'=>'post', 'orderby'=>'post_date');//'category__not_in'=>explode(',',$homeFlID),
		query_posts($arg); ?>

		<?php while (have_posts()) : the_post();
			get_template_part( 'template-parts/content', get_post_format() );
		endwhile; ?>
    </div>
    <!--最新更新 E-->

	<?php
	$homeFlID = WBOptions::opt('flID')?WBOptions::opt('flID'):'';

	if( $homeFlID != ''):
        function index_terms_clauses($c,$o,$a){
            if($a['orderby'] && $a['orderby']!='none' && preg_match('#\d+,#',$a['orderby'])){
                $c['orderby'] = " ORDER BY FIELD( t.term_id, ".$a['orderby']." )";
                $c['order']  = ' ASC ';
            }
            return $c;
        }
        add_filter('terms_clauses','index_terms_clauses',10,3);


        $categories = get_categories(array(
                'child_of' => 0,
                'orderby' => $homeFlID,
                'order' => 'ASC',
                'hide_empty' => true,
                'include_last_update_time' => true,
                'hierarchical' => 1,
                'include' => $homeFlID,
                'number' => '',
                'pad_counts' => false)
        );

        $sticky_posts = get_option('sticky_posts');
        if(!$sticky_posts)$sticky_posts = array();
        foreach ($categories as $cat) {
            $catid = $cat->cat_ID;
            //$arg = array();
            ?>
            <div class="title-floor">
                <h3><?php echo $cat->name; ?></h3>
                <p class="tf-ft">
                    <a class="view-more" href="<?php echo get_category_link($catid);?>">更多 &gt;</a>
                </p>
            </div>

            <div class="articles-list<?php if(wp_is_mobile()) echo ' with-list-mode list-mode-b'; ?>">
                <?php

                $i=0;
                if($sticky_posts){
                    query_posts(array('showposts'=>12,'post__in'=>$sticky_posts,'post_type'=>'post','cat'=> $catid,'orderby'=>'post_date'));
                    while (have_posts()) : the_post();
                        $i++;
                        get_template_part( 'template-parts/content', get_post_format() );
                    endwhile;
                }

                if($i<12){
                    query_posts(array('showposts'=>12-$i,'post__not_in'=>$sticky_posts,'post_type'=>'post','cat'=> $catid,'orderby'=>'post_date'));
                    while (have_posts()) : the_post();
                        get_template_part( 'template-parts/content', get_post_format() );
                    endwhile;
                }
                ?>
            </div>
        <?php } ?>

    <?php endif; ?>
</div>

<?php get_footer(); ?>