<?php
/**
 * WBolt functions and definitions
 *
 * Set up the theme and provides some helper functions, which are used in the
 * theme as custom template tags. Others are attached to action and filter
 * hooks in WordPress to change core functionality.
 *
 * When using a child theme you can override certain functions (those wrapped
 * in a function_exists() call) by defining them first in your child theme's
 * functions.php file. The child theme's functions.php file is included before
 * the parent theme's file, so the child theme functions would be used.
 *
 * @link https://codex.wordpress.org/Theme_Development
 * @link https://codex.wordpress.org/Child_Themes
 *
 * Functions that are not pluggable (not wrapped in function_exists()) are
 * instead attached to a filter or action hook.
 *
 * For more information on hooks, actions, and filters,
 * {@link https://codex.wordpress.org/Plugin_API}
 *
 * @package WordPress
 * @subpackage Inpandora
 * @since WBolt 1.0
 */

/**
 * Inpandora only works in WordPress 4.4 or later.
 */
if ( version_compare( $GLOBALS['wp_version'], '4.4-alpha', '<' ) ) {
	require get_template_directory() . '/utils/back-compat.php';
}

require_once get_template_directory().'/version.php';

if ( ! function_exists( 'wbolt_setup' ) ) :

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 *
 * Create your own wbolt_setup() function to override in a child theme.
 *
 * @since WBolt 1.0
 */
function wbolt_setup() {
	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link http://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	 */
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 640, 640, true );

	// This theme uses wp_nav_menu() in two locations.
	register_nav_menus( array(
		'primary' => __( '主导航菜单', 'wbolt' ),
		'social'  => __( '页脚友链展示', 'wbolt' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	/*
	 * This theme styles the visual editor to resemble the theme style,
	 * specifically font, colors, icons, and column width.
	 */
	//add_editor_style( array( 'css/editor-style.css', wbolt_fonts_url() ) );

	//移除 dns-prefetch for 's.w.org'
	remove_action( 'wp_head', 'wp_resource_hints', 2 );


	//禁用REST API
    add_filter('rest_enabled', '__return_false');
    add_filter('rest_jsonp_enabled', '__return_false');

    remove_action( 'wp_head', 'rest_output_link_wp_head', 10 );
    remove_action( 'wp_head', 'wp_oembed_add_discovery_links', 10 );

    /**
     * Disable the emoji's
     */
    function disable_emojis() {
        remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
        remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
        remove_action( 'wp_print_styles', 'print_emoji_styles' );
        remove_action( 'admin_print_styles', 'print_emoji_styles' );
        remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
        remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
        remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
        add_filter( 'tiny_mce_plugins', 'disable_emojis_tinymce' );
    }
    add_action( 'init', 'disable_emojis' );
    /**
     * Filter function used to remove the tinymce emoji plugin.
     */
    function disable_emojis_tinymce( $plugins ) {
        return array_diff( $plugins, array( 'wpemoji' ) );
    }
}
endif; // wbolt_setup
add_action( 'after_setup_theme', 'wbolt_setup' ); //初始化


/**
 * Enqueues scripts and styles at head.
 *
 * @since WBolt 1.0
 */
function wbolt_header() {

	// Theme stylesheet.
	wp_enqueue_style( 'wbolt-style', get_template_directory_uri() . '/css/style_wbolt.css', false);

    // Load the html5 shiv.
    if(WBOptions::opt('slb')){
        wp_enqueue_script( 'wbolt-html5', get_template_directory_uri() . '/module/html5shiv/html5.js', array() );
        wp_script_add_data( 'wbolt-html5', 'conditional', 'lt IE 9' );
    }
	wp_enqueue_script( 'lab-jq', get_template_directory_uri() . '/js/jquery.min.js', array() );
}
add_action( 'wp_enqueue_scripts', 'wbolt_header' );

/**
 * Enqueues scripts and css on the footer
 */
function wbolt_footer(){
//    wp_enqueue_script( 'wbolt-wb', get_template_directory_uri() . '/js/wbolt.js', array() );
    wp_enqueue_script( 'wbolt-base', get_template_directory_uri() . '/js/base.js', array(),'20190407b' );
}
add_action( 'wp_footer', 'wbolt_footer' );


function wbolt_the_posts_pagination( $args = array() ) {
    echo wbolt_get_the_posts_pagination( $args );
}

function wbolt_get_the_posts_pagination( $args = array() ) {
    $navigation = '';

    // Don't print empty markup if there's only one page.
    if ( $GLOBALS['wp_query']->max_num_pages > 1 ) {
        $args = wp_parse_args( $args, array(
            'mid_size'           => 5,
            'prev_text'          => _x( '上一页', 'previous post','wbolt' ),
            'next_text'          => _x( '下一页', 'next post','wbolt' ),
            'screen_reader_text' => __( 'Posts navigation' ),
        ) );

        // Make sure we get a string back. Plain is the next best thing.
        if ( isset( $args['type'] ) && 'array' == $args['type'] ) {
            $args['type'] = 'plain';
        }

        // Set up paginated links.
        $links = paginate_links( $args );

        if ( $links ) {
            $navigation = wbolt_navigation_markup( $links, 'pagination', $args['screen_reader_text'] );
        }
    }

    return $navigation;
}


function wbolt_navigation_markup( $links, $class = 'posts-navigation', $screen_reader_text = '' ) {
    if ( empty( $screen_reader_text ) ) {
        $screen_reader_text = __( 'Posts navigation' );
    }

    $template = '
    <a class="btn btn-load-more" id="J_loadMoreBtn">加载更多</a>
    <div class="wb-navigation %1$s" role="navigation">
        %3$s
    </div>';

    //Add this line
    $template = apply_filters('navigation_markup_template', $template);

    return sprintf( $template, sanitize_html_class( $class ), esc_html( $screen_reader_text ), $links );
}


//处理评论区头象烂图问题
function get_ssl_avatar($avatar)
{
    $avatar = preg_replace('/.*\/avatar\/(.*)\?s=([\d]+)&.*/', '<img src="https://secure.gravatar.com/avatar/$1?s=$2" class="avatar avatar-$2" height="$2" width="$2">', $avatar);
    return $avatar;
}
add_filter('get_avatar', 'get_ssl_avatar');


//自定义菜单
class Wbolt_Walker_Nav_Menu extends Walker_Nav_Menu
{
    function start_lvl( &$output, $depth = 0, $args = array() ) {
        $indent = str_repeat("\t", $depth);
        $output .= "\n$indent<div class=\"sub-menu lv-$depth\">\n<ul>";
    }

    function end_lvl( &$output, $depth = 0, $args = array() ) {
        $indent = str_repeat("\t", $depth);
        $output .= "$indent</ul>\n</div>";
    }
}

//自定义菜单
class Wbolt_Walker_Nav_Menu_m extends Walker_Nav_Menu
{
    function start_lvl( &$output, $depth = 0, $args = array() ) {
        $indent = str_repeat("\t", $depth);
        $output .= "\n$indent".($depth == 0 ? '<i class="nav-arrow"></i>':'')."<div class=\"sub-menu-m lv-$depth\"><ul>";
    }

    function end_lvl( &$output, $depth = 0, $args = array() ) {
        $indent = str_repeat("\t", $depth);
        $output .= "$indent</ul>\n</div>";
    }
}

//移除菜单的多余CSS选择器
add_filter('nav_menu_css_class', 'my_css_attributes_filter', 100, 1);
add_filter('nav_menu_item_id', 'my_css_attributes_filter', 100, 1);
add_filter('page_css_class', 'my_css_attributes_filter', 100, 1);
function my_css_attributes_filter($var) {
	return is_array($var) ? array_intersect($var, array('menu-item-has-children')) : '';
}

//面包屑
function dimox_breadcrumbs()
{
	/*error_reporting(E_ALL);
	ini_set('display_errors',true);*/
	$delimiter = '<i>&gt;</i>';
	$name = '首页'; //text for the 'Home' link
	$currentBefore = '<strong>';
	$currentAfter = '</strong>';

	if (!is_home() && !is_front_page() || is_paged()) {

		echo '<div class="bread-crumbs"><div class="inner pw"><span>当前位置：</span>';

		global $post;
		$home = get_bloginfo('url');
		echo '<a href="' . $home . '">' . $name . '</a> ' . $delimiter . ' ';

		if (is_category()) {
			global $wp_query;
			$cat_obj = $wp_query->get_queried_object();
			$thisCat = $cat_obj->term_id;
			$thisCat = get_category($thisCat);
			$parentCat = get_category($thisCat->parent);
			if ($thisCat->parent != 0) echo(get_category_parents($parentCat, TRUE, ' ' . $delimiter . ' '));
			echo $currentBefore . '<strong>';
			single_cat_title();
			echo '</strong>' . $currentAfter;

		} elseif (is_day()) {
			echo '' . get_the_time('Y') . ' ' . $delimiter . ' ';
			echo '' . get_the_time('F') . ' ' . $delimiter . ' ';
			echo $currentBefore . get_the_time('d') . $currentAfter;

		} elseif (is_month()) {
			echo '' . get_the_time('Y') . ' ' . $delimiter . ' ';
			echo $currentBefore . get_the_time('F') . $currentAfter;

		} elseif (is_year()) {
			echo $currentBefore . get_the_time('Y') . $currentAfter;

		} elseif (is_single()) {
			$cat = get_the_category();

			$cat_parent = $cat[0] -> category_parent;
			$cet_ret = get_category_parents($cat_parent, TRUE, ' ' . $delimiter . ' ');
			if(!is_wp_error($cet_ret))echo $cet_ret;

			foreach ($cat as $key => $cats){
				if($key > 0) echo ' | ';
				echo '<a href='.get_category_link($cats -> term_id) . '>' . $cats -> name . '</a>';
			}

			echo ' ' . $delimiter . ' ';

			echo $currentBefore;
			the_title();
			echo $currentAfter;

		} elseif (is_page() && !$post->post_parent) {
			echo $currentBefore;
			the_title();
			echo $currentAfter;

		} elseif (is_page() && $post->post_parent) {
			$parent_id = $post->post_parent;
			$breadcrumbs = array();
			while ($parent_id) {
				$page = get_page($parent_id);
				$breadcrumbs[] = '' . get_the_title($page->ID) . '';
				$parent_id = $page->post_parent;
			}
			$breadcrumbs = array_reverse($breadcrumbs);
			foreach ($breadcrumbs as $crumb) echo $crumb . ' ' . $delimiter . ' ';
			echo $currentBefore;
			the_title();
			echo $currentAfter;

		} elseif (is_search()) {
			echo $currentBefore . '探索结果 &#39;' . get_search_query() . '&#39;' . $currentAfter;

		} elseif (is_tag()) {
			echo $currentBefore . '<strong>';
			single_tag_title();
			echo '</strong>' . $currentAfter;

		} elseif (is_author()) {
			global $author;
			$userdata = get_userdata($author);
			echo $currentBefore . '文章 ' . $userdata->display_name . $currentAfter;

		} elseif (is_404()) {
			echo $currentBefore . 'Error 404' . $currentAfter;
		}

		if (get_query_var('paged')) {
			if (is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author()) echo ' (';
			echo __('Page') . ' ' . get_query_var('paged');
			if (is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author()) echo ')';
		}

		echo '</div></div>';

	}
}

//详情通用变量
function getPostMataVal($key,$default=0){
	$postId = get_the_ID();
	if(!$postId)return $default;
	$val = get_post_meta($postId,$key,true);
	return $val?$val:$default;
}

//浏览数
/* Postviews start */
function getPostViews($postID){
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return '0';
    }
    return $count;
}

function setPostViews($postID) {
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
            $count = 0;
            delete_post_meta($postID, $count_key);
            add_post_meta($postID, $count_key, '0');
    }else{
            $count++;
            update_post_meta($postID, $count_key, $count);
        }
}
/* Postviews start end*/


//获取一级分类菜单ID
function get_category_root_id($cat)
{
    $this_category = get_category($cat);
    while($this_category->category_parent)
    {
        $this_category = get_category($this_category->category_parent);
    }
    return $this_category->term_id;
}
function get_article_category_ID()
{
    $category = get_the_category();
    return $category[0]->cat_ID;
}

//投稿者上传图片权限
if ( current_user_can('contributor') && !current_user_can('upload_files') )
  add_action('admin_init', 'allow_contributor_uploads');

function allow_contributor_uploads() {
  $contributor = get_role('contributor');
  $contributor->add_cap('upload_files');
}

//缩略图
/**
 * Display an optional post thumbnail.
 */
function wbolt_post_thumbnail() {
	if ( post_password_required() || is_attachment()) {
		return;
	}

	if(has_post_thumbnail()){
		the_post_thumbnail( 'post-thumbnail', array( 'alt' => get_the_title() ) );
		return;
	}

	//无设定默认图尝试获取文章第一张图
	if(! has_post_thumbnail() && $img = catch_that_image()){
		if($img['src']){

            echo '<img src="'.$img['src'].'" alt="">';
			return;
        }
	}

	//主题设置默认占位图
	if( WBOptions::opt('def_img_url') ){
		echo  '<img src="'. WBOptions::opt('def_img_url') .'" alt="">';
		return;
	}

	//都没有，读取主题默认图
	echo '<img src="'. get_template_directory_uri() .'/images/wbolt_def_cover.png" alt="">';
}

//抽取文章第一张图
function catch_that_image() {
	global $post, $posts;
	$first_img = '';
	$output_src = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches_src);

	if(!$matches_src){
	    return array();
    }


	$output_height = preg_match_all('/<img.+height=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches_height);
	$output_width = preg_match_all('/<img.+width=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches_width);
	$first_img = Array('src'=>$matches_src[1][0],'width'=>$matches_width[1][0],'height'=>$matches_height[1][0]);
	return $first_img;
}


function wbolt_content_image_sizes_attr($sizes, $size)
{
	$width = $size[0];

	880 <= $width && $sizes = '(max-width: 768px) calc(100vw - 40px), (max-width: 1200px) 550px, (max-width: 1400px) 730px, 880px';

	return $sizes;
}

add_filter('wp_calculate_image_sizes', 'wbolt_content_image_sizes_attr', 10, 2);

/**
 * Add custom image sizes attribute to enhance responsive image functionality
 * for post thumbnails
 *
 * @since WBolt Wowrk 1.0
 *
 * @param array $attr Attributes for the image markup.
 * @param int $attachment Image attachment ID.
 * @param array $size Registered image size or flat array of height and width dimensions.
 * @return string A source size value for use in a post thumbnail 'sizes' attribute.
 * (max-width: 768px) calc(50vw - 20px) 指小于768时，图片占屏宽50%再减20px
 * (max-width: 1280px) 225px 小于1280显示225, 否则显示288
 */
function wbolt_post_thumbnail_sizes_attr($attr, $attachment, $size)
{
	if(is_admin()) return $attr;

	$attr['data-src'] = $attr['src'];

	$attr['src'] = WBOptions::opt('def_img_url') ? WBOptions::opt('def_img_url') : get_template_directory_uri() . '/images/wbolt_def_cover.png';

	$attr['data-srcset'] = $attr['srcset'];
	$attr['srcset'] = '';

	if ('post-thumbnail' === $size) {
		$attr['sizes'] = '(max-width: 1200) 300px, (max-width: 1400) 250px, 300px';
	}

	return $attr;
}

add_filter('wp_get_attachment_image_attributes', 'wbolt_post_thumbnail_sizes_attr', 10, 3);


/***
 * 列表文章概要字数重置
 */


function wb_excerpt_length($length){

}
add_filter('excerpt_length', 'wb_excerpt_length');
function wb_excerpt_more(){
    return  '...';
}
add_filter('excerpt_more','wb_excerpt_more');


/**
 * 插入svg icon
 * e.g. wbolt_svg_icon('icon-time');
 */
function wbolt_svg_icon($name){
	return '<svg class="wb-icon '.$name.'"><use xlink:href="#'.$name.'"></use></svg>';
}

add_action('wp_ajax_nopriv_post_down', 'wp_ajax_post_down');
add_action('wp_ajax_post_down','wp_ajax_post_down' );
function wp_ajax_post_down(){
        $post_id = intval($_POST['post_id']);
        if(!$post_id)exit();
        $val = get_post_meta($post_id,'post_downs',true);
        $val = abs($val) + 1;
        update_post_meta($post_id,'post_downs',$val);
}


//load setting
require_once 'settings/options.inc.php';


if( WBOptions::opt('dl.switch')) {
    require_once 'utils/download/downinfo.inc.php';
}
if( WBOptions::opt('donate.switch')) {
    require_once 'utils/donate/donate.inc.php';
}
//百度主动推送
require_once 'utils/baidu_push/baidu_push.inc.php';

require_once 'widget/widget.php';
require_once 'utils/related_post/related_post.inc.php';

//主题激活时默认创建page
require_once 'utils/wb_default_page/def_page.inc.php';

