<?php
/**
 * The template for displaying comments
 *
 * The area of the page that contains both current comments
 * and the comment form.
 *
 * @package WordPress
 * @subpackage Inpandora
 * @since Wbolt 1.0
 */

if ( post_password_required() ) {
	return;
}
?>

<section class="panel-inner sc-comments">
    <h3 class="sc-title">发表评论</h3>
	<?php
	// If comments are closed and there are comments, let's leave a little note, shall we?
	if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) :
		?>
        <p class="no-comments"><?php _e( 'Comments are closed.', 'wbolt' ); ?></p>
	<?php endif; ?>

    <div id="comments">
	<?php
	$commenter = wp_get_current_commenter();
	$req = get_option( 'require_name_email' );//检测数据库必填字段
	$aria_req = ( $req ? " aria-required='true'" : '' ); //提示必须的文案
	$fields =  array(
		'author' => '<label class="form-item">
                <input class="form-control" id="author" name="author" value="" size="30"' . $aria_req . ' placeholder="名字 *" />
        </label> ' ,
		'email' => '<label class="form-item">
                <input class="form-control" id="email" name="email" type="email" value="" size="30"' . $req . ' placeholder="邮箱 *" />
        </label> ',
		'url' => '<label class="form-item">
                <input class="form-control" id="url" name="url" type="email" value="" size="30"' . ' placeholder="网站" />
        </label> '
	);

	$comments_args = array(
		'fields' =>  $fields,
		'comment_field' => '<textarea
                                class="textarea-comments"
                                id="comment" name="comment"
                                aria-required="true"
                                required="required"
                                placeholder="评论内容 *"></textarea>',
		'title_reply' => null,
		'comment_notes_before' => null,
		'submit_button'        => '<button class="wb-btn btn-primary" id="%2$s" name="%1$s" type="submit" />%4$s</button>',
		'submit_field'         => '<p class="form-item btn-bar">%1$s %2$s</p>',
		'must_log_in' => '<p class="must-log-in">要发表评论，您必须先<a class="link-login user-login" href="javascript:;">登录</a>。</p>',

		'logged_in_as'=> sprintf('<p class="logged-in-as"><a href="'.esc_url( home_url( '/member' )).'" aria-label="已登入为%s。编辑您的个人资料。">已登入为%s</a>。<a class="user-logout" href="'.wp_logout_url().'">登出？</a></p>',$user_identity,$user_identity),

	);

	comment_form($comments_args);
	?>
    </div>

	<?php if(get_comments_number() != '0'): ?>
        <h4 class="title-comments">评论列表(<?php echo get_comments_number(); ?>)</h4>
        <ul class="list-comments">
			<?php function wbolt_comment($comment, $args, $depth){
			$GLOBALS['comment'] = $comment; ?>
            <li class="comment-item" id="li-comment-<?php comment_ID(); ?>">
                <div class="media-pic">
					<?php if (function_exists('get_avatar') && get_option('show_avatars')) { echo get_avatar($comment, 48); } ?>
                </div>
                <div class="media-body" id="comment-<?php comment_ID(); ?>">
                    <div class="comment-txt">
                        <div class="hd">
                            <p class="name"><?php printf(__('<cite class="fn">%s</cite>'), get_comment_author_link()); ?></p>
                            <p class="date"><?php echo get_comment_time('Y.n.j H:m'); ?></p>
                        </div>

                        <div class="bd">
							<?php if ($comment->comment_approved == '0') : ?>
                                <span>你的评论正在审核，稍后会显示出来！</span><br />
							<?php else : ?>
								<?php comment_text(); ?>
							<?php endif; ?>

							<?php comment_reply_link(array_merge( $args, array('reply_text' => '回复','depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
							<?php //edit_comment_link('修改'); ?>
                        </div>
                    </div>
                </div>
				<?php } ?>
				<?php
				wp_list_comments( array(
					'type'       => 'comment',
					'reverse_top_level' => true,
					'callback'  => 'wbolt_comment',
					'max_depth' => 2
				) );
				?>
        </ul>

		<?php the_comments_navigation(); ?>
	<?php endif; ?>
</section>