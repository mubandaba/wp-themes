<?php


define('WB_THEMES_VER','1.1.0');
define('WB_THEMES_CODE','inpandora');