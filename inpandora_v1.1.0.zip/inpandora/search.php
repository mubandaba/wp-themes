<?php
/**
 * The template for displaying search results pages
 *
 * @package WordPress
 * @subpackage Inpandora
 * @since Wbolt 1.0
 */

get_header();
$have_posts = have_posts();
?>

    <div class="main">
        <div class="header-list">
            <div class="title-list">
	            <?php
	            global $wp_query;
	            $item_count = number_format($wp_query->found_posts);
	            $item_count = $item_count > 0 ? $item_count . '个' : '';
	            ?>
                <h1>搜索关键词：<?php echo esc_html( get_search_query() ) ; ?></h1>
                <div class="description">共查询匹配到<?php echo $item_count; ?>结果</div>
            </div>
        </div>

		<?php if ( $have_posts ) : ?>
	    <?php echo WBOptions::insertAdBlock('list_block','adbanner-block under-list-title'); ?>

        <div class="articles-list <?php if($list_display_mode < 2) echo ' with-list-mode'; if($list_display_mode == 1) echo ' list-mode-b'; ?>" id="J_postList">
			<?php
			// Start the loop.
			$postIndex = 0;
			$adIndex = rand(3,8);
			$hasListAD = WBOptions::opt('ads.list.type');

			while ( have_posts() ) : the_post();
				get_template_part( 'template-parts/content', get_post_format() );

				if($hasListAD && $postIndex == $adIndex){
					get_template_part( 'template-parts/content', 'list-ad' );
				}
				$postIndex++;

			endwhile;
			?>
        </div>
        <div class="loading-bar"></div>
        <?php
        wbolt_the_posts_pagination();
        ?>

        <?php else :
            get_template_part( 'template-parts/content-none', 'none' );

        endif;
        ?>
    </div>

<?php get_footer(); ?>