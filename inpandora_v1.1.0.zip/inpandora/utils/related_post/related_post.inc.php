<?php
/**
 * mode 展示模式，默认只是标题： text-only, 图片模式为 with-img
 * max 展示最大记录数，默认值是 5
 * section_name 模块标题，默认为 相关推荐
 */

class WB_Related_Post
{

	public function __construct()
	{
		add_shortcode( 'manual_related_posts',array($this,'relatedPostShortCode'));

	}

	public  function relatedPostShortCode($atts){
		global $post;

		if(!is_single())return '';

		$mode =isset( $atts['mode'] ) ?  $atts['mode'] : 'text-only';
		$max =isset( $atts['max'] ) ?  $atts['max'] : 5;
		$section_name =isset( $atts['name'] ) ?  $atts['name'] : '相关推荐';
//                print_r($mode);

		$post_ids = $this->get_related_posts_id($post,$max);

		$content = '<section class="related-posts panel-inner"><h3 class="sc-title">'.$section_name.'</h3>';

		switch ($mode) {
			case 'text-only' :
				$content .= '<ul class="list-ul">';
				foreach ($post_ids as $id){
					$content .=  '<li class="text-item">
									<a href="' . esc_url( apply_filters( 'the_permalink', get_permalink( $id ) ) ) . '">' . get_the_title( $id ) . '</a>
								</li>';
				}
				break;
			default :
				$content .= '<ul class="articles-list">';

				foreach ($post_ids as $id){
					$thumb = has_post_thumbnail( $id ) ? get_the_post_thumbnail( $id, 'post-thumbnail' ) : '<img alt="" src="" height="300" width="200" />';
					$url = esc_url( apply_filters( 'the_permalink', get_permalink( $id ) ) );
					$content .=  '<li class="post ">
										<div class="inner">
											<a class="media-pic" href="' . $url . '">' . $thumb . '</a>
											<div class="media-body">
												<a class="post-title" href="'. $url .'">' . get_the_title( $id ) . '</a>
											</div>
										</div>
									</li>';
				}
				break;
		}


		$content .= '</ul></section>';

		return $content;
	}

	function  post_cats($post_id){
		$cat = get_the_category( $post_id );
		return wp_list_pluck( $cat, 'term_id' );
	}
	function get_related_posts_id( $post,$num_posts,$not_in = array() ) {
		$transient_name = 'related_post_id_'. $post->ID.'_'.$num_posts;
		$rel_id = get_transient( $transient_name );
		if($rel_id)return explode(',',$rel_id);
		$not_in[] = $post->ID;
		$args = array(
			'post_type' => $post->post_type,
			'post_status' => 'publish',
			'post__not_in' => $not_in,
			'numberposts' => $num_posts,
			'post_count' => $num_posts,
			'order' => 'RAND'
		);
		// auto posts by tags
		$cat = get_the_category( $post->ID );
		$cat_ids = wp_list_pluck( $cat, 'term_id' );
		$args['category'] = implode( ',', $cat_ids );


		// auto posts query
		$relative_query = get_posts( $args );
		$rel_id = array(); // set empty
		// we found posts ?
		if ( ! empty( $relative_query ) ) {
			$rel_id = wp_list_pluck( $relative_query, 'ID' );
		}


		// return not empty
		$rel_id = wp_parse_id_list( $rel_id );

		if ( ! empty( $rel_id ) ) {
			set_transient( $transient_name, implode(',',$rel_id) ,2592000  );
		}
		return $rel_id;
	}

}
new WB_Related_Post();



