<?php

/**
 *
 *
 */

class WBDonate
{
	function __construct()
	{
		add_shortcode( 'wbolt_donate',array(__CLASS__,'donateShortCode'));



        add_action('wp_ajax_dwqr_ajax',array($this,'dwqr_ajax'));
        add_action('wp_ajax_nopriv_dwqr_ajax',array($this,'dwqr_ajax'));
	}

	public function dwqr_ajax(){

		//print_r($_GET);exit();
		if($_REQUEST['do']=='like'){

			do{
				$post_id = intval($_REQUEST['post_id']);

				if(!$post_id){
					break;
				}
				$like = get_post_meta($post_id,'dwqr_like',true);
				if($like){
					$like = intval($like);
				}else{
					$like = 0;
				}
				$like++;

				update_post_meta($post_id,'dwqr_like',$like);
				echo $like;
				exit();

			}while(false);


		}


	}

	public static function donateShortCode($attr){
		$opt_data = WBOptions::opt('donate');
		if(!$opt_data['switch']) return '';

		$items = $opt_data['items'];
		$share_switch = $opt_data['display_group'];

		$ajax_url = admin_url('admin-ajax.php');

		$style = '<style>
			.item-weixin::before {background-image: url("data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%2216%22 height=%2214%22%3E%3Cpath fill=%22%2300D000%22 fill-rule=%22nonzero%22 d=%22M7 9.2a.5.5 0 0 1-.6-.3L3.6 5c0-.2.1-.3.3-.3H4l3 1.9c.3 0 .5.1.8 0l6.7-4A8.8 8.8 0 0 0 8 0C3.6 0 0 2.8 0 6.3c0 1.9 1 3.6 2.8 4.8l.2.4v.1L2.6 13v.2c0 .1 0 .2.2.2H3l1.7-1a.9.9 0 0 1 .7 0c.8.2 1.7.3 2.6.3 4.4 0 8-2.8 8-6.3 0-1-.3-2-1-3L7.3 9.2h-.3z%22/%3E%3C/svg%3E");}
			.item-alipay::before {background-image: url("data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%2216%22 height=%2216%22%3E%3Cg fill=%22%2304A7ED%22 fill-rule=%22nonzero%22%3E%3Cpath d=%22M13.4 0H2.6A2.6 2.6 0 0 0 0 2.6v10.8C0 14.8 1.2 16 2.6 16h10.8c1.4 0 2.6-1.2 2.6-2.6v-.1l-6.3-2.7a6.8 6.8 0 0 1-5 2.7c-3.3 0-4.3-2.7-2.8-4.6.3-.4.9-.7 1.7-1 1.4-.3 3.6.2 5.6.9l.9-2.2H3.8v-.6H7V4.7H3.1V4h4V2.4s0-.3.2-.3H9V4h3.9v.6h-4v1.2h3.3C11.7 7 11.3 8 10.7 9l2.5 1c2.3.7 2.8.7 2.8.7V2.6C16 1.2 14.8 0 13.4 0z%22/%3E%3Cpath d=%22M4 8.7c-.5 0-1.2.2-1.7.5-1.2 1.1-.5 3 2 3 1.5 0 2.9-.8 4-2.3C6.8 9 5.4 8.5 4 8.7z%22/%3E%3C/g%3E%3C/svg%3E");}
			</style>';
		echo $style;

		$tab_html ='';
		$cont_html ='';

		$index = 0;
		foreach ($items as $k => $v){
			if(empty($v['img']))continue;
			$tab_html .= '<div class="tab-nav-item item-'.$k. ($index==0 ? ' current':'') .'"><span>'.$v['name'].'</span></div>';
			$cont_html .= '<div class="tab-cont'.($index==0 ? ' current':'') .'"><div class="pic"><img src="'.$v['img'].'" alt="'.$v['name'].'二维码图片"></div><p>用<span class="hl">'.$v['name'].'</span>扫描二维码打赏</p></div>';
			$index ++;
		}

		//只有一个item时不显示
		if($index == 1) $tab_html ='';

		$post_id = get_the_ID();

		$like = get_post_meta($post_id,'dwqr_like',true);
		if($like){
			$like = intval($like);
		}else{
			$like = 0;
		}

		$tpl = '<div class="ctrl-item">
						<a class="wb-btn btn-ctrl btn-outlined" id="J_ppoDonateBtn" data-ppo-name="#J_ppoDonate"><svg class="wb-icon wbsico-donate"><use xlink:href="#wbsico-donate"></use></svg><span>打赏</span></a>
						<a class="wb-btn btn-ctrl btn-outlined btn-like" id="J_btnLike" data-api="'.$ajax_url.'" data-post_id="'.$post_id.'"><svg class="wb-icon wbsico-like"><use xlink:href="#wbsico-like"></use></svg><span>赞('.$like.')</span></a>';

		if(isset($share_switch) && $share_switch){
			$tpl.= '<div class="btn-share">
							<div class="bdsharebuttonbox" data-tag="share_1"><a class="popup_more" data-cmd="more"></a></div>
							<a class="wb-btn"><svg class="wb-icon wbsico-share"><use xlink:href="#wbsico-share"></use></svg><span>分享</span></a>
						</div>
				        <script>
				            window._bd_share_config = {
				                share : [{
				                    "bdSize" : 32
				                }],
				                "url" : _wp_theme_uri + "/module/"
				            };
				            
				            with(document)0[(getElementsByTagName("head")[0]||body).appendChild(createElement("script")).src= _wp_theme_uri + "/module/static/api/js/share.js?cdnversion="+~(-new Date()/36e5)];
				        </script>';
		}

		$tpl .= '<div class="com-popover pst-c xk-dialog-df ppo-donate" id="J_ppoDonate">
			    <div class="bd" id="J_tabBox">
			    	<div class="tab-navs">
			    		'.$tab_html.'
					</div>
					<div class="tab-conts">
						'.$cont_html.'
					</div>
			    </div>
			    <a class="wb-ppo-close">'. wbolt_svg_icon('wbsico-close') .'</a>
			    </div>';

		$tpl .= '</div>'; //ctrl-item

		echo $tpl;
	}
}

new WBDonate();