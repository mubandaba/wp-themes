WB.WBPostool ={
    like: function (obj) {
        var $btn = obj || $('#J_btnLike');

        if($btn.length){

            $btn.on('click',function(){

                var btn = $(this);
                if(btn.hasClass('active')){
                    return;
                }
                var api = btn.data('api');
                if(!api) api = '/wp-admin/admin-ajax.php';
                var post_id = btn.data('post_id');
                if(!post_id){
                    return;
                }
                //console.log($);
                $.post(api,{'action':'dwqr_ajax','do':'like','post_id':post_id},function(ret){
                    if(ret){
                        btn.find('span').eq(0).html('赞('+ret+')');
                        // btn.attr('data-like',1);
                        btn.addClass('active');
                    }
                })

            });
        }
    }
};

jQuery(function () {
    WB.WBPostool.like();
});