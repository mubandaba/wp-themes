<?php
/**
 * This was contained in an addon until version 1.0.0 when it was rolled into
 * core.
 *
 * @package    WBOLT
 * @author     WBOLT
 * @since      1.1.0
 * @license    GPL-2.0+
 * @copyright  Copyright (c) 2019, WBOLT
 */

?>

<div style=" display:none;">
    <svg aria-hidden="true" style="position: absolute; width: 0; height: 0; overflow: hidden;" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
        <defs>
            <symbol id="sico-upload" viewBox="0 0 16 13">
                <path d="M9 8v3H7V8H4l4-4 4 4H9zm4-2.9V5a5 5 0 0 0-5-5 4.9 4.9 0 0 0-4.9 4.3A4.4 4.4 0 0 0 0 8.5C0 11 2 13 4.5 13H12a4 4 0 0 0 1-7.9z" fill="#666" fill-rule="evenodd"/>
            </symbol>
        </defs>
    </svg>
</div>

<div class="wb-post-sitting-panel">
    <div class="wbsp-aside selector-bar">
        <label class="tab-item"><input class="wbs-radio" type="radio" name="wb_dl_type"<?php echo !$type?' checked="checked"':'';?> value="0"> 关闭</label>
        <label class="tab-item"><input class="wbs-radio" type="radio" name="wb_dl_type"<?php echo $type=='1'?' checked="checked"':'';?> value="1"> 本地附件上传</label>
        <label class="tab-item"><input class="wbs-radio" type="radio" name="wb_dl_type"<?php echo $type=='2'?' checked="checked"':'';?> value="2"> 共享网盘分享</label>
    </div>
    <div class="wbsp-main">
        <div class="wbsp-cont current">
            <div class="wbs-upload-box"></div>
        </div>
        <div class="wbsp-cont section-upload ">
            <div class="wbs-upload-box">
                <input class="wbs-input upload-input" type="text" placeholder="点击右侧上传按钮或者直接贴入下载链接" name="wb_down_local_url" id="wb_down_local_url" value="<?php echo $meta_value['wb_down_url'];?>">
                <button type="button" class="wbs-btn wbs-upload-btn">
                    <svg class="wb-icon sico-upload"><use xlink:href="#sico-upload"></use></svg><span>上传</span>
                </button>
            </div></div>
        <div class="wbsp-cont">
			<?php foreach($baidu_down as $field=>$r):?>
                <div class="wb-post-sitting-item">
                    <label for="<?php echo $field;?>"><?php echo $r['title'];?></label>
                    <input class="wbs-input" type="text" name="<?php echo $field;?>" placeholder="<?php echo $r['tips'];?>" id="<?php echo $field;?>" <?php echo $r['js'];?> value="<?php echo $meta_value[$field];?>">
                </div>
				<?php if($r['help']){ echo '<div class="wb-tip-txt">'.$r['help'].'</div>';}?>
			<?php endforeach;?>
        </div>
    </div>
</div>
<script>

    function autofillvalue(obj){
        var rule=/链接:?：?\s*([^\s]+)\s*.+?码:?：?\s*([a-zA-Z0-9]+)/i;
        if(obj.value && rule.test(obj.value)){
            var ret = obj.value.match(rule);
            if(ret[1])jQuery("#wb_down_url").val(ret[1]);
            if(ret[2])jQuery("#wb_down_pwd").val(ret[2]);
        }
    };
</script>
