WB.WBDownload = {
    downloadPanel: function (obj) {
        var btn = $(obj),
            _url = btn.data('dl-url'),
            _psw = btn.data('clipboard-text');

        // console.log(_url + ' / ' + _psw);
        if(_psw) new Clipboard('[data-clipboard-text]');
        WB.WBDownload.popoverDownloadPanel(btn,_url,_psw);
    },

    popoverDownloadPanel: function(btn,url,psw,targetObj){
        var $popover = targetObj || $('#J_ppoDownload');

        $popover.find('.dl-psw').text(psw);
        $popover.find('.wb-btn').attr('href',url);

        WB.popover(btn);
    }
};

jQuery(function ($) {
    WB.WBDownload.downloadPanel('[data-dl-url]');

    $(window).on('scroll', function(e) {
        var st = $(window).scrollTop();

        //详情页下载bar
        if($('#J_downloadBar').length) $('#J_downloadBar')[(st > 200 ? 'add' : 'remove') + 'Class']('sb-active');
    });
});
