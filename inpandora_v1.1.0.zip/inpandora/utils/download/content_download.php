<?php





?>


    <?php if($need_login && !$is_login){//if login ?>
    <a class="wb-btn btn-download"" href="<?php echo wp_login_url(get_permalink());?>"><svg class="wb-icon wbsico-dlsm"><use xlink:href="#wbsico-dlsm"></use></svg> <span>登录下载</span></a>

    <?php }else{//else if login ?>

        <?php
        if($meta_value['wb_dl_type']=='1'){ //if local file?>
        <a class="wb-btn btn-download" href="<?php echo $meta_value['wb_down_url'];?>" target="_blank"><svg class="wb-icon wbsico-dlsm"><use xlink:href="#wbsico-dlsm"></use></svg> <span>点击下载</span></a>

        <?php }else{ //else baidu file?>
        <a class="wb-btn btn-download" data-ppo-name="#J_ppoDownload" data-ppo-mask="1"  data-dl-url="<?php echo $meta_value['wb_down_url'];?>" data-down="<?php echo $meta_value['wb_down_title'];?>" data-clipboard-text="<?php echo $meta_value['wb_down_pwd'];?>" href="javascript:;"><svg class="wb-icon wbsico-dlsm"><use xlink:href="#wbsico-dlsm"></use></svg> <span>点击下载</span></a>


        <?php }//end if baidu file ?>

    <?php } //end if login ?>

