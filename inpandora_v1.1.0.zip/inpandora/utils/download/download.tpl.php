<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage SG
 * @since Wbolt 1.0
 *
 */

if(!wp_is_mobile()) add_action('wp_footer', 'appreciate_footer');


add_filter('document_title_parts','wb_document_title_parts',10,1);
function wb_document_title_parts($parts){
    $parts['title'] = 'Download '.get_the_title().' for free';
    $parts['tagline'] = get_bloginfo( 'description', 'display' );
    $parts['site'] = get_bloginfo( 'name', 'display' );
    return $parts;
}
function wbopt_seo_title($title){
    $title = wp_get_document_title();
    return $title;
}
add_filter('wbopt_seo_title','wbopt_seo_title');


function appreciate_footer()
{
    wp_enqueue_script('list-js', get_template_directory_uri() . '/js/list.js', array());
}

// = null;
$post_id = intval($_GET['goto']);
$post = get_post($post_id);
if(empty($post) || !$post->ID || $post->post_status!='publish'){
    wp_redirect(home_url().'/404');
    exit();
}
$GLOBALS['post'] = $post;

$downinfo = apply_filters('wb_download_meta',$post_id);

get_header();
?>
    <div class="main main-download">
        <div class="content">
            <div class="top-part pw">
                <div class="post-info txtl">
                    <a class="media-pic">
                        <?php wbolt_post_thumbnail(); ?>
                    </a>
                    <div class="media-body">
                        <p>你要下载的文件是:</p>
                        <h2><?php the_title(); ?></h2>
                    </div>
                </div>

	            <?php echo WBOptions::insertAdBlock('dl_top'); ?>
            </div>

            <div class="download-info pw">
                <?php
                if($downinfo['wb_down_url']): ?>

                    <p>
                        <a class="btn btn-dl" href="<?php echo $downinfo['wb_down_url'] ?>" target="_blank">
                            <strong>去下载</strong>
                        </a>
                    </p>
                    <?php if($downinfo['wb_down_pwd']):  ?><p class="psw">下载密码： <?php echo $downinfo['wb_down_pwd'] ?></p><?php endif; ?>
                <?php

                    else: ?>
                    <p>噢噢! 下载链接似乎出问题了...</p>
                <?php endif; ?>

	            <?php echo WBOptions::insertAdBlock('dl_text'); ?>
            </div>

            <div class="more-posts">

                <h3>其他推荐</h3>

                <div class="pw">
                    <?php
                    $arg =array(
                        'post_type' => $post->post_type,
                        'post_status' => 'publish',
                        'post__not_in' => array( $post->ID ),

                        'order' => 'RAND'
                    );
                    if(isset($_GET['paged'])){
                        $arg['paged'] = $_GET['paged'];
                    }

                    query_posts($arg);

                    if ( have_posts() ) :
                    ?>

                    <div class="articles-list" id="J_postList">
                        <?php
                        // Start the loop.
                        $postIndex = 0;
                        $adIndex = rand(3,8);
                        $hasListAD = WBOptions::opt('ads.list.type');

                        while ( have_posts() ) : the_post();

                            /*
                             * Include the Post-Format-specific template for the content.
                             * If you want to override this in a child theme, then include a file
                             * called content-___.php (where ___ is the Post Format name) and that will be used instead.
                             */
                            get_template_part( 'template-parts/content',get_post_format());
                            if($hasListAD && $postIndex == $adIndex){
                                get_template_part( 'template-parts/content', 'list-ad' );
                            }
                            $postIndex++;

                            // End the loop.
                        endwhile;

                        // If no content, include the "No posts found" template.
                        else :
                            get_template_part( 'template-parts/content-none', 'none' );

                        endif;
                        ?>
                    </div>
                    <div class="loading-bar"></div>
                    <?php
                    // Previous/next page navigation.
                    wbolt_the_posts_pagination();
                    ?>
                </div>
            </div>
        </div>
    </div>

<?php get_footer(); ?>