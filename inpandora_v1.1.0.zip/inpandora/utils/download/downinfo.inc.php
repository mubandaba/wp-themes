<?php

/**
 *
 *
 * User: zhiqun
 * Date: 2018/08/19
 */

class WBDowninfo
{

	private static  $meta_keys = array(
		'wb_dl_type'=>array('name'=>'下载方式','tip'=>''),
        'wb_down_title'=>array('type'=>'text','title'=>'文件名称','tips'=>'可以为空','help'=>'','js'=>''),
        'wb_down_url'=>array('type'=>'text','title'=>'网盘链接','tips'=>'请填完整url','js'=>'onblur="autofillvalue(this)"','help'=>'填入百度网盘客户端或者网页端分享链接及提取码，可自动识别链接和提取码填入哦。'),
        'wb_down_pwd'=>array('type'=>'text','title'=>'提取码（密码）','tips'=>'','help'=>'','js'=>''),

	);

	function __construct()
	{

		if(is_admin()){
			//输入表单
			add_action( 'add_meta_boxes', array($this,'addMetaBox'));

			//保存表单
			add_action( 'save_post', array($this,'saveMeta') );
		}

		if(!is_admin()){
			//样式、js
			add_filter('wp_footer',array($this,'wp_footer'),1);

			//详情输出
			//add_filter('the_content',array($this,'the_content'));

			//short code
			add_shortcode( 'wb_download_info',
				array(__CLASS__,'downloadShortCode')
			);
		}
	}


	public function wp_footer(){
		if(is_single()) {
			wp_enqueue_script( 'js-clipboards', get_template_directory_uri() . '/module/clipboard/clipboard.min.js', array('lab-jq') );
		}
	}

	public static function metaInfo($post_id){

		$meta_value = array();
		foreach(self::$meta_keys as $field=>$field_config){
			$meta_value[$field] = get_post_meta($post_id,$field,true);
		}
		return $meta_value;
	}

	public function addMetaBox(){
		$screens = array( 'post');//, 'page'
		foreach ($screens as $screen) {
			wp_enqueue_style( 'wb-admin-style', get_stylesheet_directory_uri() . '/settings/assets/wb_admin.css' );

			add_meta_box(
				'wbolt_meta_box_download_info',
				'下载设置',
				array($this,'renderMetaBox'),
				$screen
			);
		}
	}
	public function renderMetaBox($post){

		$meta_value = self::metaInfo($post->ID);
		$fields = self::$meta_keys;
		unset($fields['wb_dl_type']);

		//百度
		$baidu_down = array(
			'wb_down_title'=>array('type'=>'text','title'=>'文件名称','tips'=>'可以为空','help'=>'','js'=>''),
			'wb_down_url'=>array('type'=>'text','title'=>'网盘链接','tips'=>'请填完整url','js'=>'onblur="autofillvalue(this)"','help'=>'填入百度网盘客户端或者网页端分享链接及提取码，可自动识别链接和提取码填入哦。'),
			'wb_down_pwd'=>array('type'=>'text','title'=>'提取码（密码）','tips'=>'','help'=>'','js'=>''),
		);
        $type = $meta_value['wb_dl_type'];
		include dirname(__FILE__).'/meta_box.php';

	}

	public function saveMeta($post_id){
		if ( ! current_user_can( 'edit_post', $post_id ) )
			return;

		if($_POST['wb_dl_type']=='1'){
			$_POST['wb_down_url'] = trim($_POST['wb_down_url_upload']);
		}

		foreach(self::$meta_keys as $field=>$field_config){
			if(!isset($_POST[$field]))continue;

			$_POST[$field] = trim($_POST[$field]);

			if(strlen($_POST[$field])==0)continue;

			$value = sanitize_text_field( $_POST[$field] );
			update_post_meta($post_id, $field, $value);
		}
	}



	public static function downloadShortCode($atts){
		echo self::downHtml($atts);
	}


	private static function downHtml($atts){

		$post_id = get_the_ID();
		$html = '';
		do{
			if(!$post_id){
				break;
			}
			$meta_value = self::metaInfo($post_id);

			//关闭资源
			if(!$meta_value['wb_dl_type']){
				break;
			}

			$need_login = WBOptions::opt('dl.need_login');
			$is_login = is_user_logged_in();

			ob_start();
			include dirname(__FILE__).'/content_download.php';
			$html = ob_get_clean();



		}while(false);

		return $html;


	}


}

new WBDowninfo();