<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Inpandora
 * @since Wbolt 1.0
 */
$GLOBALS['container-custom'] = 'container-single';

if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
	wp_enqueue_script( 'comment-reply' );
}

the_post();

get_header();

//统计views
setPostViews(get_the_ID());

?>
<div class="main main-detail">
	<?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>

    <header class="article-header">
		<?php the_title( '<h1 class="title-detail">', '</h1>' ); ?>

        <div class="post-metas">
            <span class="meta-item meta-author">
                <?php echo wbolt_svg_icon('wbsico-author'); ?>
                <em><?php the_author(); ?></em>
            </span>
            <span class="meta-item meta-date">
                <?php echo wbolt_svg_icon('wbsico-time'); ?>
                <em><?php the_time('M d, Y') ?></em>
            </span>
            <span class="meta-item meta-date">
                <?php echo wbolt_svg_icon('wbsico-download'); ?>
                <em><?php echo getPostMataVal('post_downs'); ?></em>
            </span>
        </div>
    </header>

    <div class="content pw-dt">
		<?php
			get_template_part( 'template-parts/content', 'single' );
		?>

		<?php get_sidebar(); ?>
    </div>


	<?php
	if ( comments_open() || get_comments_number() ) {
		comments_template();
	}
	?>

	<?php if( WBOptions::opt('dl.switch') ): ?>
        <div class="sticky-bar" id="J_downloadBar">
            <div class="inner pw">
                <div class="sb-title">
					<?php the_title( '<div class="title-sb">', '</div>' ); ?>
                    <div class="post-metas">
                        <span class="meta-item meta-author">
                            <?php echo wbolt_svg_icon('wbsico-author'); ?>
                            <em><?php the_author(); ?></em>
                        </span>
                        <span class="meta-item meta-date">
                            <?php echo wbolt_svg_icon('wbsico-time'); ?>
                            <em><?php the_time('M d, Y') ?></em>
                        </span>
                        <span class="meta-item meta-date">
                            <?php echo wbolt_svg_icon('wbsico-download'); ?>
                            <em><?php echo getPostMataVal('post_downs'); ?></em>
                        </span>
                    </div>
                </div>

                <div class="ctrl-box">
		            <?php echo do_shortcode( '[wb_download_info]' ); ?>
                </div>
            </div>
        </div>

	<?php
	//下载信息 ?>
    <div class="com-popover pst-fixed xk-dialog-df ppo-dl" id="J_ppoDownload">
        <div class="bd">
            <p class="dl-info">
                <?php echo wbolt_svg_icon('wbsico-confirm'); ?>
                <span>密码</span>
                <b class="dl-psw"></b>
                <span>已复制</span>
            </p>
            <a class="wb-btn btn-outlined" href="" target="_blank" rel="nofollow">
                <?php echo wbolt_svg_icon('wbsico-dlsm'); ?>
                <span>前往下载页面</span>
            </a>
        </div>
        <div class="info-for-sp">
            <p>低版本浏览器需手动复制密码再前往下载页面下载，谢谢</p>
        </div>

        <a class="wb-ppo-close"> <?php echo wbolt_svg_icon('wbsico-close'); ?></a>
    </div>

        <script>
            $('.btn-download').on('click',function(){
                $.post('<?php echo admin_url('admin-ajax.php');?>',{action:'post_down',post_id:<?php echo get_the_ID();?>},function () { })
            });
        </script>
	<?php endif; ?>
</div>

<?php get_footer(); ?>
