<?php
/**
 * The template for displaying the header
 *
 * @package WordPress
 * @subpackage Inpandora
 * @since Wbolt 1.0
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php endif; ?>
	<?php wp_head(); ?>
    <?php /*读取设置favicon图标*/ ?>
    <?php if(WBOptions::opt('favicon')): ?>
<link rel="shortcut icon" href="<?php echo WBOptions::opt('favicon'); ?>" />
    <?php endif; ?>

    <script>
        var _wp_base = '<?php echo home_url();?>';
        var _wp_theme_uri = '<?php echo get_template_directory_uri();?>';
        <?php /*自动加载参数*/
            if(WBOptions::opt('autoload')):
        ?>
        var autoLoadMaxPage = <?php if(WBOptions::opt('mxpage')){echo WBOptions::opt('mxpage');}else{ echo '0'; } ?>;
        <?php endif; ?>
        <?php /*默认图片url*/
            if(WBOptions::opt('def_img_url')):
        ?>
        var _def_pic_url = "<?php echo WBOptions::opt('def_img_url'); ?>";
	    <?php endif; ?>
    </script>

	<?php /*自定义主题色*/ ?>
	<?php if(WBOptions::opt('theme_color')) echo '<style>:root{ --mainColor: ' . WBOptions::opt('theme_color') . ';}</style>'; ?>
    <?php /*自定义样式*/ ?>
    <?php if(WBOptions::opt('usr_css')) echo '<style>' . WBOptions::opt('usr_css') . '</style>'; ?>
    <?php /*自定义头部代码*/ ?>
    <?php if(WBOptions::opt('hd_code')) echo WBOptions::opt('hd_code'); ?>
    <?php /*引入谷歌广告*/ ?>
    <?php if(WBOptions::opt('ads.ggad')): ?>
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <?php endif; ?>
</head>

<body <?php body_class()?>>
<?php #icons
include( '_svg_icons.php' );
?>
<header class="header">
    <div class="inner pw">
        <?php echo (is_front_page() && is_home()) ? '<h1 ' : '<div '; echo 'class="logo">'; ?>
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                    <?php if(WBOptions::opt('logo_url')):
                        echo '<img src="'. WBOptions::opt('logo_url'). '" alt="'.get_bloginfo( 'name' ).'"/>';
                    else:
	                    echo '<img src="'. get_template_directory_uri(). '/images/logo_wb.png" alt="'.get_bloginfo( 'name' ).'"/>';
                    endif; ?>
                </a>
        <?php echo (is_front_page() && is_home()) ? '</h1>' : '</div>'; ?>

        <?php if(wp_is_mobile()): ?>
            <nav class="nav-top-m" id="J_navBar">
	            <?php get_search_form(); ?>
                <?php
                wp_nav_menu( array(
                    'theme_location' => 'primary',
                    'menu_class'     => 'nav-m',
                    'menu_id'     => 'J_topNavMb',
                    'container'     => '',
                    'walker' => new Wbolt_Walker_Nav_Menu_m()
                ) );
                ?>

                <a class="btn-close" id="J_closeNav"><?php echo wbolt_svg_icon('wbsico-close'); ?></a>
            </nav>
            <a class="btn-search-m" id="J_btnSearchMb"><?php echo wbolt_svg_icon('wbsico-search'); ?></a>
            <a class="btn-nav" id="J_btnNavMb"><i><?php _e( '显/隐菜单', 'wbolt' ); ?></i></a>

        <?php elseif ( has_nav_menu( 'primary' ) ) : ?>
            <nav class="nav-top cf" id="J_navBar">
                <?php
                wp_nav_menu( array(
                    'theme_location' => 'primary',
                    'menu_class'     => 'nav',
                    'menu_id'     => 'J_topNav',
                    'container'     => '',
                    'walker' => new Wbolt_Walker_Nav_Menu()
                ) );

                ?>
            </nav>
	        <?php get_search_form(); ?>
        <?php endif; ?>


    </div>
</header>

<div class="container pw<?php if($GLOBALS['container-custom']) echo ' '.$GLOBALS['container-custom']; ?>">