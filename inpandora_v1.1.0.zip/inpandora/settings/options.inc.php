<?php

/**
 * Created by zhiqun.
 * User: zhiqun
 * Date: 2016/10/27
 * Time: 23:10
 * @subpackage themes
 * @since WBolt 1.0
 */
class WB_Images_Seo {


    private $active_title = 0;
    private $active_alt = 0;
    public function __construct(){

        $this->active_title = WBOptions::opt('seo.img_seo.title');
        $this->active_alt = WBOptions::opt('seo.img_seo.alt');


        if($this->active_title || $this->active_alt){

            add_filter( 'the_content', array( $this, 'handel_images' ), 500 );
            add_filter( 'post_thumbnail_html', array( $this, 'handel_images_featured' ), 500 );
        }

    }

    function handel_images( $content ) {
        //if(is_single()){

        $post_title = get_the_title();
        if(preg_match_all('#<img([^>]+)>#is',$content,$match)){

            foreach($match[0] as $k=>$img){
                $src_img = $img;
                $img = str_replace(array('alt=""',"alt=''",'title=""',"title=''"),'',$img);

                $add_html = '';

                if($this->active_title && !preg_match('#\s+title=.+?#is',$img)){

                    if($this->active_title=='2'){
                        if(preg_match('#/.+?\.(jpg|jpeg|gif|webp|png|bmp)#is',$img,$name_match)){
                            $add_html .= ' title="'.esc_attr($name_match[0]).'插图'.($k?'('.$k.')':'').'"';
                        }
                    }else if($post_title){

                        $add_html .= ' title="'.esc_attr($post_title).'插图'.($k?'('.$k.')':'').'"';
                    }
                }
                if($this->active_alt && !preg_match('#\s+alt=.+?#is',$img)){

                    if($this->active_alt == '2'){
                        if(preg_match('#/.+?\.(jpg|jpeg|gif|webp|png|bmp)#is',$img,$name_match)){
                            $add_html .= ' alt="'.esc_attr($name_match[0]).'插图'.($k?'('.$k.')':'').'"';
                        }
                    }else if($post_title){
                        $add_html .= ' alt="'.esc_attr($post_title).'插图'.($k?'('.$k.')':'').'"';
                    }
                }
                if(!$add_html){
                    continue;
                }

                $new_img = '<img'.$add_html.' '.$match[1][$k].'>';
                $content = str_replace($src_img,$new_img,$content);
            }//end foreach match

        }//end preg_match image
        //}//end if is_single
        return $content;
    }

    function handel_images_featured( $html ) {


        if(preg_match('#<img([^>]+)>#i',$html,$match)){

            $img = $match[0];

            $add_html = '';
            $post_title = get_the_title();
            $img = str_replace(array('alt=""',"alt=''",'title=""',"title=''"),'',$img);

            if($this->active_title && !preg_match('#\s+title=.+?#is',$img)){

                if($this->active_title=='2'){
                    if(preg_match('#/.+?\.(jpg|jpeg|gif|webp|png|bmp)#is',$img,$name_match)){
                        $add_html .= ' title="'.esc_attr($name_match[0]).'插图"';
                    }
                }else if($post_title){

                    $add_html .= ' title="'.esc_attr($post_title).'插图"';
                }
            }
            if($this->active_alt && !preg_match('#\s+alt=.+?#is',$img)){

                if($this->active_alt == '2'){
                    if(preg_match('#/.+?\.(jpg|jpeg|gif|webp|png|bmp)#is',$img,$name_match)){
                        $add_html .= ' alt="'.esc_attr($name_match[0]).'插图"';
                    }
                }else if($post_title){
                    $add_html .= ' alt="'.esc_attr($post_title).'插图"';
                }
            }
            if($add_html){

                $html = '<img'.$add_html.' '.$match[1].'>';
            }

        }//end if preg_match image

        return $html;

    }

}

class WBOptions
{
    function __construct()
    {

        //添加菜单
        add_action('admin_menu', array($this, 'options_page_menu'));


        //============SEO================
        //seo配置
        $seo_opt = $this->opt('seo');
        if (isset($seo_opt['active']) && $seo_opt['active']) {
            //去掉默认标题处理
            remove_action('wp_head', '_wp_render_title_tag', 1);
            //添加seo处理
            add_action('wp_head',array($this,'seoTitle') , 1);
        }
        if($seo_opt['img_seo']['active']){
            new WB_Images_Seo();
        }


        add_action('admin_init',array($this,'admin_init'),1);
    }
function admin_enqueue_scripts($hook) {
		    global $wb_settings_page_hook_theme;
		    if ( $wb_settings_page_hook_theme != $hook ) {
			    return;
		    }

		    wp_enqueue_style('wbs-style', get_template_directory_uri() . '/settings/assets/wb_setting.css', array(),'20190409');
	    }
    public function admin_init(){
	    add_action('admin_enqueue_scripts',array($this,'admin_enqueue_scripts'),1);

        wp_enqueue_script('wbs-nmjs', get_template_directory_uri() . '/settings/assets/wb_admin.js', array(),'20190403', true);

        //setting
        register_setting($this->cnf('opt_key'), $this->cnf('opt'));
    }

    //主题常量配置
    static function cnf($key, $default = null)
    {
        $cnf = array(
            'name' => 'WB',
            'opt' => 'wb_theme_cnf',
            'opt_key' => 'options_xk_themes'
        );
        if (isset($cnf[$key])) return $cnf[$key];
        return $default;
    }


	function options_page_menu()
	{
		global $wb_settings_page_hook_theme;
		$wb_settings_page_hook_theme = add_menu_page(
			'主题设置',
			'主题设置',
			'edit_theme_options',
			'options-wbthemes',
			array($this,'optionsPage'),
			get_template_directory_uri() . '/settings/assets/wbolt_ico.svg'
		);
	}

    //配置页面get_template_directory() . '/settings/wbolt_ico.png'
    function optionsPage()
    {
	    global $wpdb;
        $opt = $this->opt('');//get_option($this->cnf('opt'));
        $opt_name = $this->cnf('opt');
        $opt_key = $this->cnf('opt_key') ;
        $name = $this->cnf('name');

	    $index_term_id = $opt['flID'];

	    $tm_1 = $wpdb->terms;
	    $tm_2 = $wpdb->term_taxonomy;
	    $sql = "SELECT b.name,b.slug,a.parent,a.term_id FROM $tm_2 a,$tm_1 b WHERE a.term_id=b.term_id AND a.taxonomy='category' order by a.parent";

	    $term_name = array();

	    $term_list = $wpdb->get_results($sql,ARRAY_A);
	    $cate_list = array();
	    $term_list2 = array();
	    foreach($term_list as $term){
		    if(!isset($cate_list[$term['parent']])){
			    $cate_list[$term['parent']] = array();
		    }
		    $cate_list[$term['parent']][] = $term;
		    $term_list2[$term['term_id']] = $term;
	    }
	    if($index_term_id){
		    $index_term_id = explode(',',$index_term_id);
		    foreach ($index_term_id as $term_id) {
			    $term_name[] = $term_list2[$term_id]['name'];
		    }
	    }
//        print_r($opt);

        include get_template_directory() . '/settings/options.php';
    }

    //配置值
    static function opt($name, $default = false)
    {
        //配置的name
        $option_name = self::cnf('opt');
        static $options = null;
        // Get option settings from database
        if (null == $options) $options = get_option($option_name);

        if(!$name)return $options;

        $ret = $options;
        $ak = explode('.', $name);
        foreach ($ak as $sk) {
            if (isset($ret[$sk])) {
                $ret = $ret[$sk];
            } else {
                return $default;
            }
        }
        return $ret;
    }


    //seo title, keywords, description
    function seoTitle()
    {
        $title = wp_get_document_title();
        $kw = $desc = '';
        $tpls = array('<title>%s</title>', '%s', '%s');
        $seo = $this->opt('seo');
        if (is_home()) {
            if (isset($seo['index'])) {
                $mata = $seo['index'];
                if (isset($mata[0]) && $mata[0]) {
                    $title = $this->formatTitle($mata[0]);
                }
                if (isset($mata[1]) && $mata[1]) {
                    $tpls[1] = '<meta name="keywords" content="%s" />';
                    $kw = $mata[1];
                }
                if (isset($mata[2]) && $mata[2]) {
                    $tpls[2] = '<meta name="description" content="%s" />';
                    $desc = $mata[2];
                }
            }


        } else if(is_author()){

            /* 标题: “{作者名称}”作者主页 - 站点名称
             关键词: 读取该作者所有结果Top5关键词
               描述: {作者名称}主页，包括作者所有结果Top5关键词（以顿号分割）等内容。

             */

            global $authordata,$wpdb;

            $sep = apply_filters('document_title_separator', '-');
            $title = implode($sep, array('”'.get_the_author().'”作者主页', get_bloginfo('name', 'display')));
            //$title = self::formatTitle($title);

            if(is_object($authordata)){

                $top_words = get_user_meta($authordata->ID,'seo_top_keywords',true);
                $time = current_time('timestamp');
                if(!$top_words || $top_words['time']<$time){

                    $sql = "SELECT c.`term_taxonomy_id`,c.term_id,COUNT(1) num FROM $wpdb->posts a,$wpdb->term_relationships r,$wpdb->term_taxonomy c ";
                    $sql .= " WHERE a.post_author=%d AND a.post_status='publish' AND a.post_type='post' AND a.ID=r.object_id AND r.term_taxonomy_id=c.term_taxonomy_id AND c.taxonomy='post_tag'";
                    $sql .= " GROUP BY c.`term_taxonomy_id` ORDER by num DESC LIMIT 5";

                    $sql = "SELECT t.name from $wpdb->terms t,($sql) tt WHERE t.term_id=tt.term_id";

                    $sql = $wpdb->prepare($sql,$authordata->ID);

                    $col = $wpdb->get_col($sql);

                    $top_words = array('time'=>$time + WEEK_IN_SECONDS,'keywords'=>$col);
                    update_user_meta($authordata->ID,'seo_top_keywords',$top_words);
                }

                if($top_words['keywords']){
                    $tpls[1] = '<meta name="keywords" content="%s" />';
                    $kw = implode(',',$top_words['keywords']);
                    $tpls[2] = '<meta name="description" content="%s" />';
                    $desc = '”'.get_the_author().'”作者主页，包括'.implode('、',$top_words['keywords']).'等内容。';
                }

            }




        } else if(is_search()){

            //$q = get_queried_object();
            //print_r($q);
            global $wp_query,$wpdb;
            /*
            标题: 与“{搜索词}”匹配搜索结果 - 站点名称
            关键词: {搜索词}, {搜索词}相关, {搜索词}内容及搜索结果文章Top5关键词
            描述: 当前页面展示所有与“{搜索词}”相关的匹配结果，热门内容包括搜索结果文章Top5关键词（以顿号分割）等内容。
            注：{搜索词}指访客输入关键词内容
            */
            $sep = apply_filters('document_title_separator', '-');
            $q_kw = get_search_query(false);
            $title = implode($sep, array('与”'.$q_kw.'”匹配的搜索结果', get_bloginfo('name', 'display')));
            //$title = self::formatTitle($title);

            $kws = array($q_kw,$q_kw.'相关',$q_kw.'内容');//array_merge(,$top_words['keywords']);
            $tpls[1] = '<meta name="keywords" content="%s" />';
            $kw = implode(',',$kws);
            $tpls[2] = '<meta name="description" content="%s" />';
            $desc = '当前页面展示所有与”'.$q_kw.'”相关的匹配结果';//.implode('、',$top_words['keywords']);

            if($wp_query->found_posts){
                $post_ids = array();
                foreach ($wp_query->posts as $p){
                    $post_ids[] = $p->ID;
                }
                //print_r($wp_query);

                $post_ids = implode(',',$post_ids);

                $sql = "SELECT tt.term_id,tt.term_taxonomy_id,count(1) num FROM $wpdb->term_relationships r , $wpdb->term_taxonomy tt,$wpdb->terms t where r.object_id IN($post_ids) AND r.term_taxonomy_id=tt.term_taxonomy_id AND tt.taxonomy<>'category' group by tt.term_taxonomy_id order by num DESC LIMIT 5";

                $sql = "SELECT t.name FROM $wpdb->terms t ,($sql) tmp where  tmp.term_id=t.term_id ";


                //echo $sql;
                $col = $wpdb->get_col($sql);
                if($col){

                    $kw .= ','.implode(',',$col);
                    $desc .= ',热门内容包括'.implode('、',$col).'等内容。';
                }

            }




        } else if(is_tag()){

            $tag = get_queried_object();

            global $wpdb;
            //print_r($tag);
            /* 标题: “{标签}”相关内容 - 站点名称
             关键词: {标签}, {标签}相关, {标签}内容及标签结果文章Top5关键词
             描述: 关于“{标签}”相关内容全站索引列表，包括标签列表页所有结果Top5关键词（以顿号分割）。
             注：{标签}指文章编辑时输入的标签词语*/


            $sep = apply_filters('document_title_separator', '-');
            $title = implode($sep, array('”'.$tag->name.'”相关内容', get_bloginfo('name', 'display')));
            //$title = self::formatTitle($title);

            $top_words = get_term_meta($tag->term_id,'seo_top_keywords',true);
            $time = current_time('timestamp');
            if(!$top_words || $top_words['time']<$time){


                //tag 下的所有文章
                $sql = "SELECT p.ID  FROM $wpdb->term_relationships r ,$wpdb->posts p WHERE r.term_taxonomy_id = %d and  r.object_id=p.ID AND p.post_status='publish'";

                //所有文章下的tag，取数量前五
                $sql = "SELECT tt.term_taxonomy_id,tt.term_id,COUNT(1) FROM $wpdb->term_taxonomy tt ,$wpdb->term_relationships rr ,$wpdb->posts pp WHERE tt.term_taxonomy_id=rr.term_taxonomy_id  AND tt.taxonomy<>'category' AND rr.object_id=pp.ID AND pp.ID IN($sql)";
                $sql .= " GROUP BY tt.term_taxonomy_id ORDER BY tt.count DESC LIMIT 5";


                $sql = "SELECT t.name FROM $wpdb->terms t,($sql) tmp WHERE t.term_id=tmp.term_id";

                $sql = $wpdb->prepare($sql,$tag->term_taxonomy_id);

                //echo $sql;exit();
                $col = $wpdb->get_col($sql);

                $top_words = array('time'=>$time + WEEK_IN_SECONDS,'keywords'=>$col);
                update_term_meta($tag->term_id,'seo_top_keywords',$top_words);
            }

            if($top_words['keywords']){
                $kws = array_merge(array($tag->name,$tag->name.'相关',$tag->name.'内容'),$top_words['keywords']);
                $tpls[1] = '<meta name="keywords" content="%s" />';
                $kw = implode(',',$kws);
                $tpls[2] = '<meta name="description" content="%s" />';
                $desc = '关于“'.$tag->name.'”相关内容全站索引列表，包括'.implode('、',$top_words['keywords']).'。';
            }
        } else if (is_category()) {
            $term = get_queried_object();
            $cid = $term->term_id;
            if (isset($seo[$cid])) {
                $mata = $seo[$cid];
                if (isset($mata[0]) && $mata[0]) {
                    $sep = apply_filters('document_title_separator', '-');
                    $title = implode($sep, array($mata[0], get_bloginfo('name', 'display')));
                    $title = $this->formatTitle($title);
                }
                if (isset($mata[1]) && $mata[1]) {
                    $tpls[1] = '<meta name="keywords" content="%s" />';
                    $kw = $mata[1];
                }
                if (isset($mata[2]) && $mata[2]) {
                    $tpls[2] = '<meta name="description" content="%s" />';
                    $desc = $mata[2];
                }
            }
        }else if(is_post_type_archive()){

            $q_obj = get_queried_object();
            //$q_obj->name;
            if(isset($seo['post_type_'.$q_obj->name])){
                $mata = $seo['post_type_'.$q_obj->name];
                if (isset($mata[0]) && $mata[0]) {
                    $sep = apply_filters('document_title_separator', '-');
                    $title = implode($sep, array($mata[0], get_bloginfo('name', 'display')));
                    $title = $this->formatTitle($title);
                }
                if (isset($mata[1]) && $mata[1]) {
                    $tpls[1] = '<meta name="keywords" content="%s" />';
                    $kw = $mata[1];
                }
                if (isset($mata[2]) && $mata[2]) {
                    $tpls[2] = '<meta name="description" content="%s" />';
                    $desc = $mata[2];
                }
            }
        } else if (is_single()) {

            //kw
            $posttags = get_the_tags();

            if ($posttags) {
                $tags = array();
                foreach ($posttags as $tag) {
                    $tags[] = $tag->name;
                }
                $stags = implode(',', $tags);
                $kw = $stags;
                $tpls[1] = '<meta name="keywords" content="%s" />';
            }
            //desc
            $excerpt = $this->excerpt();

            if ($excerpt) {
                $desc = $excerpt;
                $tpls[2] = '<meta name="description" content="%s" />';
            }

        }
        echo sprintf(implode('', $tpls), $title, $kw, $desc);
    }

    //格式化标题
    function formatTitle($title)
    {
        $title = wptexturize($title);
        $title = convert_chars($title);
        $title = esc_html($title);
        $title = capital_P_dangit($title);
        return $title;
    }

    //文章摘要
    function excerpt()
    {
        $post = get_post();
        if (empty($post)) {
            return '';
        }
        $excerpt = $post->post_excerpt ? $post->post_excerpt : $this->trimContent($post->post_content);
        if (!$excerpt) return $excerpt;
        return apply_filters('get_the_excerpt', $excerpt);
    }

    //格式化文章内容
    function trimContent($text)
    {
        $text = strip_shortcodes($text);

        $text = str_replace(']]>', ']]&gt;', $text);

        $excerpt_length = apply_filters('excerpt_length', 120);

        $excerpt_more = apply_filters('excerpt_more', ' ' . '[&hellip;]');
        $text = wp_trim_words($text, $excerpt_length, $excerpt_more);

        return $text;
    }

    //插入广告位
	static function insertAdBlock($ad_name = '', $box_class = 'adbanner-block'){
    	if(!$ad_name) return;

		$ads = self::opt('ads.'.$ad_name);

		if($ads['type'] == 0) return;

		$adHTML = '<div class="'. $box_class .'">';

		if($ads['type'] == 1){
			$adHTML .= $ads['code'];
		}elseif($ads['type'] == 2){
			$adHTML .= '<a href="' . $ads['url'] . '" target="_blank" rel="nofollow"><img class="adbn-img" src="' . $ads['img'] . '"></a>';
		}else{
			return;
		}
		$adHTML .= '</div>';

		return $adHTML;
    }

}

new WBOptions();