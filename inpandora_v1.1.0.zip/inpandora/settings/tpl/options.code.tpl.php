<?php /**
 * WBolt 自定义代码设置
 **/
 ?>
<div class="sc-header">
    <strong>自定义代码</strong>
    <span>自定义网站常用代码</span>
</div>

<div class="sc-body">
    <section class="sc-block">
        <div class="scb-hd">自定义CSS样式</div>
        <div class="scb-main">
            <textarea class="large-text code wbs-input" id="usr_css" name="<?php echo $opt_name;?>[usr_css]" rows="5" cols="42"><?php _opt('usr_css');?></textarea>
        </div>
    </section>

    <section class="sc-block">
        <div class="scb-hd">自定义头部代码</div>
        <div class="scb-main">
            <textarea class="large-text code wbs-input" id="hd_code" name="<?php echo $opt_name;?>[hd_code]" rows="5" cols="42"><?php _opt('hd_code');?></textarea>
        </div>
    </section>

    <section class="sc-block">
        <div class="scb-hd">自定义底部代码</div>
        <div class="scb-main">
            <textarea class="large-text code wbs-input" id="ft_code" name="<?php echo $opt_name;?>[ft_code]" rows="5" cols="42"><?php _opt('ft_code');?></textarea>
        </div>
    </section>

    <section class="sc-block">
        <div class="scb-hd">统计代码</div>
        <div class="scb-main">
            <textarea class="large-text code wbs-input" id="stats_code" name="<?php echo $opt_name;?>[stats_code]" rows="5" cols="42"><?php _opt('stats_code');?></textarea>
        </div>
    </section>
</div>