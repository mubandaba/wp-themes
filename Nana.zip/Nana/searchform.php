<div id="searchbar">
	<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
		<input type="text" value="" name="s" id="s" placeholder="输入搜索内容" required="">
		<button type="submit" id="searchsubmit">搜索</button>
	</form>
</div>
	