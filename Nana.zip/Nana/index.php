<?php if (get_option('ygj_home') == '杂志布局') { ?>
<?php include('cms.php'); ?>
<?php } else { include(TEMPLATEPATH . '/blog.php'); } ?>