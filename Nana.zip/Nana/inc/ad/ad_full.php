	<div class="ad-pc ad-site">
		<?php echo stripslashes(get_option('ygj_ad_fc')); ?>
	</div>	