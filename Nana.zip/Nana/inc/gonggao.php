	<div id="scrolldiv"><div class="bull">
	</div>
		<div class="scrolltext">
			<ul style="margin-top: 0px;">
				<?php echo stripslashes(get_option('ygj_ggl_nr')); ?>
			</ul>
		</div>
	</div> 
	<script type="text/javascript">$(document).ready(function() {$("#scrolldiv").textSlider({line: 1, speed: 1000, timer: 3000});})</script>