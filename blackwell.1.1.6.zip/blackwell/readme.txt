"BlackWell is a One Page Business WordPress Theme" By InkThemes.

Get Your Website Ready in Just 1 Click.

Thank you for trying the BlackWell WordPress Theme. If you have any questions that are beyond the scope of this readme file, please feel free to ask questions at InkThemes Support Forum. Follow the link given below:
http://www.inkthemes.com/community/

License and resources links for images:
http://pixabay.com/en/hot-air-balloon-balloon-floating-241642/

 == All other images in images folder are created by InkThemes and distributed under GPL V.3  ==

License and resources links for scripts and css  
---------------------------------------
1. Animate.css - http://daneden.me/animate
Licensed under the MIT license

2. Font Awesome 4.1.0 by @davegandy - http://fontawesome.io - @fontawesome
License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)

3.  bigSlide.js
/*! bigSlide - v0.4.3 - 2014-01-25
* http://ascott1.github.io/bigSlide.js/
* Copyright (c) 2014 Adam D. Scott; Licensed MIT */
	
4.  jquery.singlePageNav.min.js	
Version: 1.5.2 
Plugin URI: http://manos.malihu.gr/page-scroll-to-id/
Author: malihu
Author URI: http://manos.malihu.gr
License: MIT License (MIT)

5  superfish.js
 * Superfish v1.4.8 - jQuery menu widget
 * Copyright (c) 2008 Joel Birch
 *
 * Dual licensed under the MIT and GPL licenses:
 * 	http://www.opensource.org/licenses/mit-license.php
 * 	http://www.gnu.org/licenses/gpl.html
 
 == All other js and css files are created by InkThemes and distributed under GPL V.3  ==

