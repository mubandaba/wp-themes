<?php
/*
Template Name: 文章归档
*/
?>
<?php get_header(); ?>
		
<div id="roll"><div title="回到顶部" id="roll_top"></div><div title="转到底部" id="fall"></div></div>
<div id="content">
<div class="main">
<!--div id="map">
<div class="site">当前位置：<a title="返回首页" href="<?php echo get_settings('Home'); ?>/">首页</a> &gt; 归档</div>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
</div-->
<div class="article">

<h2>文章归档</h2>
<div class="archives">
		<?php
        $previous_year = $year = 0;
        $previous_month = $month = 0;
        $ul_open = false;
         
        $myposts = get_posts('numberposts=-1&orderby=post_date&order=DESC');
        
        foreach($myposts as $post) :
            setup_postdata($post);
         
            $year = mysql2date('Y', $post->post_date);
            $month = mysql2date('n', $post->post_date);
            $day = mysql2date('j', $post->post_date);
            
            if($year != $previous_year || $month != $previous_month) :
                if($ul_open == true) : 
                    echo '</table>';
                endif;
         
                echo '<h2>'; echo the_time('F Y'); echo '</h2>';
                echo '<table>';
                $ul_open = true;
         
            endif;
         
            $previous_year = $year; $previous_month = $month;
        ?>
            <tr>
                <td width="50"><?php the_time('j'); ?>日</td>
                <td width=""><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></td>
                <td width="80"><a href="<?php comments_link(); ?>" title="查看 <?php the_title(); ?> 的评论"><?php comments_number('0', '1', '%'); ?>人评论</a></td>
                <td width="100" style="text-align:right;"><span><?php post_views('','次'); ?>浏览</span></td>
            </tr>
        <?php endforeach; ?>
        </table>
    </div>
		
<div class="clear"></div>	

</div>
<?php endwhile; else: ?>
	<?php endif; ?>

</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>