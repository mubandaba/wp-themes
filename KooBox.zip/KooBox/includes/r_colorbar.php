		<div id="colorbar">
		<div class="r_side-top"> 
			<ul>
				<?php echo stripslashes(get_option('swt_colorbarcode')); ?>
			</ul>
		</div>
		</div>
		