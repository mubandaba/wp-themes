<div class="notice">
<h3>本站公告</h3>
<p><?php echo stripslashes(get_option('swt_notice_con')); ?></p>
</div>