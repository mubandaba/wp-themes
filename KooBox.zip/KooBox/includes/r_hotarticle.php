<?php if ( is_single() ) { ?>
<div id="rollstart"></div>
<div class="hotarticle" >
<div class="widget">
<h3>热门日志</h3>
<?php
$numberposts = 10; 
$most_viewd_posts = new WP_Query(); 
$most_viewd_posts->query('showposts='.$numberposts.'&orderby=meta_value&meta_key=views');
?>
<ul>
<?php while ($most_viewd_posts->have_posts()): $most_viewd_posts->the_post();?>
<li><a href="<?php echo the_permalink(); ?>"  rel="bookmark" title="详细阅读：<?php the_title(); ?>">
• <?php the_title(); ?>
</a></li>
<?php endwhile; ?>
</ul>
</div>
</div>
<?php } ?>