<?php
/*
Template Name: 友情链接
*/
?>
<?php get_header(); ?>
<div id="roll"><div title="回到顶部" id="roll_top"></div><div title="查看评论" id="ct"></div><div title="转到底部" id="fall"></div></div>
  <div id="content">
    <!--div class="main">
      <div id="map">
      <div class="site">当前位置：<a title="返回首页" href="<?php echo get_settings('Home'); ?>/">首页</a> &gt; 链接</div>
</div-->

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<!--script type="text/javascript">
jQuery(document).ready(function($){
$(".creeklink a").each(function(e){
	$(this).prepend("<img src=http://www.google.com/s2/favicons?domain="+this.href.replace(/^(http:\/\/[^\/]+).*$/, '$1').replace( 'http://', '' )+" style=float:left;padding:5px;>");
}); 
});
</script-->
<div class="article">
<div class="creeklink"><ul>
<?php wp_list_bookmarks('orderby=id&category_orderby=id'); ?></ul>
</div>
<div class="clear"></div>
<div class="linkstandard">
<h2 style="color:#FF0000">申请友情连接前请看：</h2><ul>
<li>一、在您申请本站友情链接之前请先做好本站链接，否则不会通过，谢谢！</li>
<li>二、<span style="color:#FF0066">谢绝第一次来我博客就申请友情链接</span>，在此之前我希望的是博客之间的交流，而不是一上来就是交换链接。</li>
<li>三、如果您的站还未被baidu或google收录，申请链接暂不予受理！</li>
<li>四、如果您的站原创内容少之又少，申请连接不予受理！</li>
<li>五、其他暂且保留，有想到的再添加。</li></ul>
</div>
</div>

<div class="article">
<?php comments_template(); ?>
</div>

	<?php endwhile; else: ?>
	<?php endif; ?>
</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>