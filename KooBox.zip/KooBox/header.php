<!DOCTYPE html>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<?php include('includes/seo.php'); ?>
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/style.css" />
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name'); ?> Atom Feed" href="<?php bloginfo('atom_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<link rel="shortcut icon" href="<?php bloginfo('template_directory'); ?>/images/favicon.ico" type="image/x-icon" />
<?php wp_enqueue_script('jquery'); ?>
<?php wp_head(); ?>
<?php if ( is_singular() ){ ?>
<?php } ?>
</head>
<body>
<div id="page">
  <div id="head">
    <div id="topmenu">
    <div class="subpage">
      <div class="toppage">
        <ul><?php wp_list_pages('depth=2&title_li='); ?>
        </ul>
      </div>
      <div id="rss">
        <ul>
        <li class="rssfeed"><a href="<?php bloginfo('rss2_url'); ?>" target="_blank" class="icon1" title="欢迎订阅<?php bloginfo('name'); ?>"></a></li>
        <?php if (get_option('swt_tqq') == 'Display') { ?>
        <li class="tqq"><a href="<?php echo stripslashes(get_option('swt_tqqurl')); ?>" target="_blank" class="icon2" title="我的腾讯微博"></a></li>
        <?php } else {echo ''; } ?>
        <?php if (get_option('swt_tsina') == 'Display') { ?>
        <li class="tsina"><a href="<?php echo stripslashes(get_option('swt_tsinaurl')); ?>" target="_blank" class="icon3" title="我的新浪微博"></a></li>
        <?php } else {echo ''; } ?>
        <?php if (get_option('swt_mailqq') == 'Display') { ?>
        <li class="rssmail"><a href="http://mail.qq.com/cgi-bin/feed?u=<?php bloginfo('rss2_url'); ?>" target="_blank" class="icon4" title="用QQ邮箱订阅我的博客"></a></li>
        <?php } else {echo ''; } ?>
        </ul>
      </div>
    </div>
      <div class="clear"></div>
    </div>
    <div id="header">
      <div id="blogname">
        <h1><a href="<?php echo get_option('home'); ?>/">
          <?php bloginfo('name'); ?>
          </a></h1>
        <div id="blogtitle">
          <h2>
            <?php bloginfo('description'); ?>
          </h2>
        </div>
      </div>
    <div class="clear"></div>
    <!-- end of header --> 
  </div>
  <!-- end of head --> 
</div>
<div class="mainmenus">
<div class="mainmenu">
  <div class="topnav">
     
         <?php
if(function_exists('wp_nav_menu')) {
    wp_nav_menu(array('theme_location'=>'primary','menu_id'=>'nav','container'=>'ul'));
}
?>
      
  </div>
  <div class="search">
    <div class="search_site addapted" style="overflow: hidden; width: 150px;">
      <form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
        <fieldset id="search">
        
          <input value="Search" onclick="this.value='';" name="s" id="s" type="text" />
          <input name="searchsubmit" value="" id="searchsubmit" class="button" type="submit" />
          
        </fieldset>
      </form>
    </div>
  </div>
  <div class="clear"></div>
</div>
</div>