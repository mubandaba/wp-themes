<div id="sidebar">
<!-- 公告 -->
<?php if (get_option('swt_notice') == 'Hide') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/r_notice.php'); } ?>
<!-- colorbar-->
<?php if (get_option('swt_colorbar') == 'Display') { ?>
<?php include(TEMPLATEPATH . '/includes/r_colorbar.php'); ?>
<?php } else {echo ''; } ?>
<!-- 日志TAB -->
<?php include('includes/r_tab.php'); ?>
<!-- 广告位 -->
<?php if (get_option('swt_ada') == 'Display') { ?>
<div id="ada">
<?php echo stripslashes(get_option('swt_adacode')); ?></div>
<?php } else {echo ''; } ?> 
<!-- 读者墙 -->
<?php if (get_option('swt_wallreaders') == 'Hide') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/r_wallreaders.php'); } ?>
<!-- 最新评论 -->
<?php include('includes/r_comment.php'); ?>
<!-- 标签 -->
<?php include('includes/r_tags.php'); ?>
<!-- 博客统计-->
<?php if (get_option('swt_r_statistics') == 'Hide') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/r_statistics.php'); } ?>
<!-- 友情链接 -->
<?php if (get_option('swt_r_links') == 'Hide') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/r_links.php'); } ?>
<!-- 热门日志 -->
<?php include('includes/r_hotarticle.php'); ?>
</div></div>