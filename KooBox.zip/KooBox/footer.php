<div class="clear"></div>
<div id="footer"><span class="comm"><?php echo comicpress_copyright(); ?> <a href="<?php echo home_url( '/' ) ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home" target="_blank"><?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?></a></span>-<span class="comm">Powered by <a href="http://www.wordpress.org/" target="_blank" title="WordPress">WordPress</a></span>-<span class="comm">Theme <a href="http://www.creekoo.com/" target="_blank" title="Koo-Box">Koo-Box</a></span><span class="comm"><?php if (get_option('swt_beian') == 'Display') { ?><?php echo stripslashes(get_option('swt_beianhao')); ?><?php } else { } ?></span><span class="comm"><?php if (get_option('swt_tj') == 'Display') { ?><?php echo stripslashes(get_option('swt_tjcode')); ?><?php } else { } ?></span>
 </div>
<?php wp_footer(); ?>
</body>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/comments-ajax.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/realgravatar.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/creekoo.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/lazyload.js"></script>
</html>