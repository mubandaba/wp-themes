<div id="sidebar">
        <ul class="widgets">
<?php // 如果没有使用 Widget 才显示以下内容, 否则会显示 Widget 定义的内容
if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) :
?>
        <!-- widget 1 -->
        <h2>文章分类</h2>
        <ul>
        <?php wp_list_cats('sort_column=name&optioncount=1&hierarchical=1'); ?>
        </ul>
        <!-- widget 2 -->
		<h2>页面</h2>
		<ul>
		<?php wp_list_pages('title_li=&depth=1'); ?>
		</ul>
		<!-- widget 3 -->
		<h2>搜搜</h2>
		<ul>
		<?php include (TEMPLATEPATH . '/searchform.php'); ?>
		</ul>
		<!-- widget 4 -->
		<h2>月份存档</h2>
		<ul>
		<?php wp_get_archives('type=monthly&show_post_count=0'); ?>
		</ul>
		<!-- widget 5 -->
		<h2>Links</h2>
		<ul>
		<?php get_links('-1', '<li>', '</li>', '<br>', FALSE, 'id', FALSE, FALSE, -1, FALSE); ?>
		</ul>
		<!-- widget 6 -->
		<h2>Meta</h2>
		<ul>
		<?php wp_register(); ?>
		<?php wp_meta(); ?>
		</ul>

<?php endif; ?>
        </ul>
</div>
<div class="clear"></div>

