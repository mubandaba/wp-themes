		<div id="footer">
            <span id="icp" class="fleft gray-link">© 2008－2011 肖建锋的博客, all rights reserved
        
            </span>
            <span class="fright">

            </span>
        </div>


</div>



<?php wp_footer(); ?>

</body>

</html>

