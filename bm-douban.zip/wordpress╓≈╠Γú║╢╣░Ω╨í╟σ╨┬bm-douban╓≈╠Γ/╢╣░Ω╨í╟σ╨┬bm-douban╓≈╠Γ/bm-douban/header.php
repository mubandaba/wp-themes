<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="zh-CN" xml:lang="zh-CN">
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php 
if(is_category()){
	$description = category_description($cat);	
	$keywords =get_cat_name($cat);
}elseif (is_single()){
	if ($post->post_excerpt) {
		$description     = $post->post_excerpt;
	} else {
		$description = utf8Substr(strip_tags(do_shortcode($post->post_content)),0,250);
	}
	$keywords = "";
	$tags = wp_get_post_tags($post->ID);
	foreach ($tags as $tag ) {
		$keywords = $keywords . $tag->name . ",";
	}
}
if($description=="")	$description = "肖建锋，人称肖大侠，是一个会在网络媒体从业、正在学习融合媒体的本科学生，正在学习和研究web2.0、数字化出版、网络视频等。爱好动画、设计、编程等。为研究各种网络平台，学习过多种计算机及网络技术(平面设计、影视动画制作、网页设计、SEO、数字报、wap网站、电子杂志、AIR、flash和编程等)，也在关注文化创意行业的发展";
if($keywords=="")	$keywords = "肖建锋,肖建锋的博客,建锋,wp高手,网站策划师,草根播报,IT技能,wordpress,长江新闻与传播学院学生";	
?>
<meta name="keywords" content="<?php echo $keywords;?>" />
<meta name="description" content="<?php echo $description; ?>" />
<title><?php seotitles(); ?></title>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/jquery-1.3.1.min.js"></script>
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<?php wp_head(); ?>
</head>
<body>
<div class="top-nav">
  <div class="bd">
	<div class="top-nav-items">
		<?php if ( $user_ID ) : ?>
			<a href="<?php echo wp_logout_url(get_permalink()); ?>" title="Log out of this account">登出</a>
		<?php else : ?>
			<a href="http://jfxiao.bammoo.com/wp-content/plugins/bee-sina-connect/sina-start.php" title="用你的新浪微博登录">登录</a>
		<?php endif; ?>
		<a target="_blank" href="http://t.sina.com.cn/jfxiao" title="肖建锋的微博">肖建锋的微博</a>
		<a href="http://feed.feedsky.com/jfxiao"  title="邮箱订阅肖建锋写的文章">RSS</a>
		<a href="http://www.feedsky.com/msub_wr.html?burl=jfxiao" title="邮寄给你最新的文章">邮寄</a>
	</div>
    <div class="site-desc"><?php bloginfo('description'); ?></div>
  </div>
</div>

<div id="wrapper">
	<div id="header">

		<h1><a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a></h1>

		<div class="nav">

			<div class="nav-items">
				<?php wp_nav_menu( array('theme_location' => 'primary') ); ?>
			</div>

			<div class="nav-search-form">
				<form name="ssform" method="get" action="<?php bloginfo('url'); ?>/">
					<div class="inp">
						<span><input name="s" type="text" title="" size="22" maxlength="60" value="<?php the_search_query(); ?>"></span>
						<span><input class="bn-search" type="submit" value="搜索"></span>
					</div>
				</form>
			</div>

		</div>

</div>