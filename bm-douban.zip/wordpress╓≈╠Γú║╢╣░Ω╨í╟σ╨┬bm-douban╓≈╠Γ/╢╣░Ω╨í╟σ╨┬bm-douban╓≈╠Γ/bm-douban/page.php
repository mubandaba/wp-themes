<?php get_header(); ?>

	<div id="content" class="narrowcolumn">

    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<div class="post" id="post-<?php the_ID(); ?>">
		<h2><?php the_title(); ?></h2>
<small class="postdata_small"><?php the_author_nickname(); ?> 於 <?php the_time('Y-m-d g:i a') ?> 发表</small>
			<div class="entrytext">
				<?php the_content('<p class="serif">Read the rest of this page &raquo;</p>'); ?>
	
				<?php link_pages('<div class="center_pages"><strong>Pages:</strong> ', '</div>', 'number'); ?>
	<?php edit_post_link('编辑', '<p>', '</p>'); ?>
<script type="text/javascript" src="http://9.douban.com/js/button_widget.js"></script>
			</div>
		</div>
<?php comments_template(); ?>
	  <?php endwhile; endif; ?>

	</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
