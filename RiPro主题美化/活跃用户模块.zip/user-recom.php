<?php 
    $user_ID = ['1','2','3','4','5','6','7','8'];  //调用用户ID
?>
<div class="recomUser">
    <div class="container">
        <div class="post-modules-top">
                <h3 class="section-title">活跃用户</h2>
        </div>
        <ul>
            <?php 
            foreach ($user_ID as $user) {
                $user_nickname = get_the_author_meta('nickname',$user);
                $user_description = get_the_author_meta('description',$user);
            ?>
            <li>
                <div class="item box b2-radius">
					<article class="warp">
						<div class="ava">
							<img class="avatar" src="<?php echo _get_user_avatar_url('user',$user)?>">
						</div>
						<div class="info">
						    <div class="name">
								<a href="/" target="_blank"><?php echo $user_nickname; ?></a>
							</div>
							<div class="desc">
							    <?php 
							    if (!$user_description) {
                                        echo '很个性，没签名！';
                                    }else {
                                        echo $user_description;
                                    }
							    ?>
							</div>
							<div class="count">
								<span>文章：<b><?php echo count_user_posts($user, 'post', false); ?></b></span>
								<span>评论：<b><?php echo get_comments('count=true&user_id='.$user); ?></b></span>
							</div>
						</div>
					</article>
				</div>
			</li>
            <?php } ?>
        </ul>
    </div>
</div>
<style>

/*
 * RiPro活跃用户模块美化
 * 主题君 www.ztjun.com
 */
.recomUser {
    margin-top: 30px;
}
.recomUser ul {
    display: flex;
    flex-wrap: wrap;
    margin-left: -15px;
    list-style: none;
    padding: 0;
}
.recomUser ul li {
    width: 25%;
    padding-left: 15px;
    margin-bottom: 15px;
}
.recomUser ul .item {
    display: block;
    transition: all .3s;
    background: #fff;
}
.recomUser ul .item:hover {
    -webkit-box-shadow: 0 0 10px rgba(0,0,0,.05);
    box-shadow: 0 0 10px rgba(0,0,0,.05);
    -webkit-transform: translateY(-3px);
    -ms-transform: translateY(-3px);
    transform: translateY(-3px);
}
.recomUser ul .item .warp {
    padding: 15px;
    display: flex;
}
.recomUser ul .item .warp .ava {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    overflow: hidden;
}
.recomUser ul .item .warp .ava img {
    width: 100%;
    height: 100%;
}
.recomUser ul .item .warp .info {
    flex: 1;
    margin-left: 15px;
}
.recomUser ul .item .warp .info .name {
    display: flex;
}
.recomUser ul .item .warp .info .name a {
    
}
.recomUser ul .item .warp .info .name em {
    transform: scale(.8);
    border-radius: 3px;
    display: inline-block;
    background: linear-gradient(180.03deg, #393F68 0%, #24263C 100%);
    padding: 3px 6px;
    font-size: 11px;
    line-height: 15px;
    color: #fff;
    font-style: normal;
}
.recomUser ul .item .warp .info .desc {
    display: inline-flex;
    font-size: 12px;
    background: #f3f3f3;
    padding: 5px 6px;
    margin: 10px 0;
    color: #606266;
}
.recomUser ul .item .warp .info .desc i {
    position: unset;
    margin-right: 5px;
}
.recomUser ul .item .warp .info .count {
    font-size: 12px;
    display: flex;
}
.recomUser ul .item .warp .info .count span {
    color: #909399;
    display: inline-block;
    margin-right: 10px;
    padding-right: 10px;
    position: relative;
}
.recomUser ul .item .warp .info .count span:after {
    content: '';
    position: absolute;
    top: 3px;
    right: 0;
    height: 11px;
    width: 1px;
    background: #e3e4e5;
}
.recomUser ul .item .warp .info .count span:last-child:after {
    display: none;
    margin: 0;
    padding: 0;
}
@media screen and (max-width: 768px) {
    .recomUser ul li {
        width: 100%;
    }
}
</style>