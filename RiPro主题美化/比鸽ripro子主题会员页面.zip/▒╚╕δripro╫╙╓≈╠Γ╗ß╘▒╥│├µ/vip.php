<?php
/*
Template Name: vip介绍
*/
get_header();
?>

<?php
// 开通会员
global $current_user;
$CaoUser = new CaoUser($current_user->ID);
$post_id = cao_get_page_by_slug('user');
$create_nonce = wp_create_nonce('caopay-' . $post_id);
?>
<style>
    .term-bar {
        display: none;
    }
    .site-content {
        padding: 0;
    }
    .site-header {
        box-shadow: none;
    }
</style>
<div class="bige-vip">
    <div class="container">
    	<form>
    	    <?php 
    	        if (_cao('is_userpage_vip_head')) {
    			    get_template_part( 'pages/user/header-card');
    		    }
    		?>
            <div class="payvip-box">
            	<?php
            	$vip_pay_setting = _cao('vip-pay-setting');
            	$site_title = get_bloginfo('name');
            	$site_url   = get_bloginfo('url');
            	foreach ($vip_pay_setting as $key => $item) {
            		echo '<div class="vip-info" data-id="'.$key.'" data-price="'.$item['price'].'" >';
            		echo '<div class="vip-tr"><i class="fa fa-diamond"></i><span>'.$site_title.' VIPS</span></div>';
            		if ($item['daynum'] == 9999) {
            			echo '<div class="vip-time"><i class="fa fa-diamond"></i><span>永久会员</span>';
            		}else{
            			if ($item['daynum']==30) {
            				$daynum_str = '30<b>天</b>';
            			}elseif ($item['daynum']==60) {
            				$daynum_str = '60<b>天</b>';
            			}elseif ($item['daynum']==90) {
            				$daynum_str = '90<b>天</b>';
            			}elseif ($item['daynum']==180) {
            				$daynum_str = '180<b>天</b>';
            			}elseif ($item['daynum']==365) {
            				$daynum_str = '365<b>天</b>';
            			}else{
            				$daynum_str = $item['daynum'].'天';
            			}
            			echo '<div class="vip-time"><span>'.$daynum_str.'</span>';
            		}
            		echo '<p class="price" style="background: '.$item['color'].';">'.$item['price']._cao('site_money_ua').'</p>';
            		echo '</div>';
                    echo '<div class="site-url">'.$site_url.'</div>';      		
            		echo '<div class="vip-bg" style="background-image: url('.get_stylesheet_directory_uri().'/assets/images/vip-logo.png);"></div></div>';
            	}
                ?>
            </div>
           <?php if ( is_user_logged_in() ) { ?>
            <div class="bige-vip-pay">
            	<input type="hidden" name="pay_id" value="">
            	<?php echo '<button type="button" class="click-pay click-payvip btn btn--danger" data-postid="' . $post_id . '" data-postvid="0" data-nonce="' . $create_nonce . '" data-price="0">立即开通</button>';?>
            </div>
            <?php } else { ?>
            <div class="bige-vip-pay">
                <button type="button" class="btn vip-pay login-btn" >立即开通</button>
            </div>
            <?php } ?>
            <div class="bige-vip-text">
                <span><i class="fa fa-diamond"></i> <?php echo $CaoUser->vip_name().'用户 · 特权到期时间：'.$CaoUser->vip_end_time() ?> · 选择套餐购买或续费</span>
            </div>
        </form>
    </div>
    <div class="bige-vip-bg-01 bige-vip-bg" style="background-image: url(<?php echo get_stylesheet_directory_uri(); ?>/assets/images/bg-vip-01.png);"></div>
    <div class="bige-vip-bg-02 bige-vip-bg" style="background-image: url(<?php echo get_stylesheet_directory_uri(); ?>/assets/images/bg-vip-02.png);"></div>
</div>
<style>
    .bige-vip {
        width: 100%;
        height: 600px;
        background-color: var(--pm-c);
        display: flex;
        align-items: center;
        position: relative;
    }
    .bige-vip .container {
        position: relative;
        z-index: 10;
    }
    .bige-vip .payvip-box {
        display: flex;
        justify-content: center;
    }
    .bige-vip .payvip-box .vip-info {
        opacity: 1;
        margin: 0 10px;
        padding: 30px;
        min-width: 360px;
        height: 210px;
        border: 0;
        position: relative;
        transition: all .3s;
    }
    .bige-vip .payvip-box .active {
        transform: translateY(-10px);
    }
    .bige-vip .payvip-box .vip-info {
        background: linear-gradient(180.03deg, #393F68 0%, #24263C 100%);
    }
    .bige-vip .payvip-box .vip-info:nth-child(3) .price {
        color: #ddd;
    }
    .bige-vip .payvip-box .vip-info .vip-tr {
        color: #fff;
        font-size: 13px;
        position: absolute;
        top: 0;
        margin: 15px;
        left: 0;
        opacity: .65;
    }
    .bige-vip .payvip-box .vip-info .vip-tr i {
        display: inline-block;
        margin-right: 3px;
    }
    .bige-vip .payvip-box .vip-info .vip-time {
        font-size: 18px;
        position: absolute;
        z-index: 5;
        right: 0;
        top: 50%;
        transform: translateY(-50%);
        margin-right: 40px;
        line-height: normal;
        text-align: right;
    }
    
    .bige-vip .payvip-box .vip-info .vip-time span {
        color: #ffffff;
        font-size: 65px;
        display: flex;
        align-items: baseline;
        
    }
    .bige-vip .payvip-box .vip-info .vip-time span b {
        margin-left: 5px;
        font-size: 13px;
        
    }
    .bige-vip .payvip-box .vip-info .price {
        font-size: 13px;
        text-align: right;
        display: inline-block;
        padding: 2px 8px;
        border-radius: 2px;
    }
    .bige-vip .payvip-box .vip-info .site-url {
        position: absolute;
        bottom: 0;
        left: 0;
        margin: 20px;
        color: #fff;
        opacity: .2;
        font-size: 13px;
        line-height: 0;
    }
    .bige-vip .bige-vip-pay {
        text-align: center;
    }
    .bige-vip .bige-vip-pay .click-pay {
        padding: 6px 30px;
        font-size: 15px;
        font-weight: normal;
        margin: 40px 0;
        letter-spacing: 1px;
    }
    .bige-vip .bige-vip-pay .vip-pay {
        padding: 6px 30px;
        font-size: 15px;
        font-weight: normal;
        margin: 40px 0;
        letter-spacing: 1px;
        color: #ffffff;
        background: #61be33;
        background: -webkit-gradient(linear,left top,right top,from(#61be33),to(#8fce44));
        background: -webkit-linear-gradient(left,#61be33,#8fce44);
        background: linear-gradient(90deg,#61be33,#8fce44);
        -webkit-box-shadow: 0 3px 5px rgba(104,195,59,.5);
        box-shadow: 0 3px 5px rgba(104,195,59,.5);
    }
    
    .bige-vip .bige-vip-text {
        text-align: center;
    }
    .bige-vip .bige-vip-text span {
        border-radius: 4px;
        background: rgba(255, 255, 255, 0.3);
        color: #fff;
        padding: 6px 10px;
        display: inline-block;
        font-size: 14px;
        letter-spacing: .5px;
    }
    .bige-vip .payvip-box .vip-info .vip-bg {
        width: 100%;
        height: 100%;
        position: absolute;
        bottom: 0;
        right: 0;
        text-align: right;
        background-repeat: no-repeat;
        background-position: bottom right;
        opacity: .1;
    }
    .bige-vip-bg {
        position: absolute;
        width: 100%;
        height: 100%;
        background-repeat: no-repeat;
    }
    .bige-vip-bg-01 {
        bottom: 0;
        left: 0;
        background-position: bottom left;
    }
    .bige-vip-bg-02 {
        top: 0;
        right: 0;
        background-position: top right;
    }
    
    
</style>


<?php get_footer(); ?>
