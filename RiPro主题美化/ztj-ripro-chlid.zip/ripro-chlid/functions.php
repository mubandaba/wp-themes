<?php

/**
 * 子主题函数
 * RiPro是一个优秀的主题，首页拖拽布局，高级筛选，自带会员生态系统，超全支付接口，你喜欢的样子我都有！
 * 正版唯一购买地址，全自动授权下载使用：https://vip.ylit.cc/
 * 作者唯一QQ：200933220 （油条）
 * 承蒙您对本主题的喜爱，我们愿向小三一样，做大哥的女人，做大哥网站中最想日的一个。
 * 能理解使用盗版的人，但是不能接受传播盗版，本身主题没几个钱，主题自有支付体系和会员体系，盗版风险太高，鬼知道那些人乱动什么代码，无利不起早。
 * 开发者不易，感谢支持，更好的更用心的等你来调教
 */

//加载style.css 子主题样式
function ripro_chlid_style() {
    if (!is_admin()) {
    	//挂在父主题优先最前
        wp_register_style('ripro_chlid_style', get_stylesheet_directory_uri() . '/diy.css',  array('app'), '', 'all');
        wp_enqueue_style('ripro_chlid_style');
        wp_enqueue_script( 'ripro_chlid_style_jquery', get_stylesheet_directory_uri(). '/assets/js/index.js', array(), '' , true );
        wp_enqueue_script( 'ripro_chlid_js', get_stylesheet_directory_uri(). '/child.js', array(), '' , true );
    }
}
add_action('init', 'ripro_chlid_style', 0 );

/*
 * ------------------------------------------------------------------------------
 * 加载比鸽RiPro子主题
 * ------------------------------------------------------------------------------
 */
require_once get_template_directory() . '/inc/codestar-framework/codestar-framework.php';

/*
 * ------------------------------------------------------------------------------
 * WordPress分类描述删除p标签
 * ------------------------------------------------------------------------------
 */

function deletehtml($description) {
	$description = trim($description);
	$description = strip_tags($description,'');
	return ($description);
}
add_filter('category_description', 'deletehtml');

//WordPress 文章关键词自动内链

function tag_sort($a, $b){
	if ( $a->name == $b->name ) return 0;
	return ( strlen($a->name) > strlen($b->name) ) ? -1 : 1;
}
function tag_link($content){
	$match_num_from = 1;	//一个标签少于几次不链接
	$match_num_to = 1;	//一个标签最多链接几次
	$posttags = get_the_tags();
	if ($posttags) {
		usort($posttags, "tag_sort");
		foreach($posttags as $tag) {
			$link = get_tag_link($tag->term_id);
			$keyword = $tag->name;
			//链接代码
			$cleankeyword = stripslashes($keyword);
			$url = "<a href=\"$link\" title=\"".str_replace('%s',addcslashes($cleankeyword, '$'),__('更多关于 %s 的文章'))."\"";
			$url .= ' target="_blank"';
			$url .= ">".addcslashes($cleankeyword, '$')."</a>";
			$limit = rand($match_num_from,$match_num_to);
			//不链接代码
			$content = preg_replace( '|(<a[^>]+>)(.*)<pre.*?>('.$ex_word.')(.*)<\/pre>(</a[^>]*>)|U'.$case, '$1$2%&&&&&%$4$5', $content);
			$content = preg_replace( '|(<img)(.*?)('.$ex_word.')(.*?)(>)|U'.$case, '$1$2%&&&&&%$4$5', $content);
			$cleankeyword = preg_quote($cleankeyword,'\'');
			$regEx = '\'(?!((<.*?)|(<a.*?)))('. $cleankeyword . ')(?!(([^<>]*?)>)|([^>]*?</a>))\'s' . $case;
			$content = preg_replace($regEx,$url,$content,$limit);
			$content = str_replace( '%&&&&&%', stripslashes($ex_word), $content);
		}
	}
	return $content;
}
add_filter('the_content','tag_link',1);


/*
 * WordPress整站文章访问计数
 * 暖岛整理 www.nuandao.cn
 */

function nd_get_all_view(){
	global $wpdb;
	$count=0;
	$views= $wpdb->get_results("SELECT * FROM $wpdb->postmeta WHERE meta_key='views'");
	foreach($views as $key=>$value){
		$meta_value=$value->meta_value;
		if($meta_value!=' '){
			$count+=(int)$meta_value;
		}
	}return $count;
}

/*
 * WordPress获取今日发布文章数量
 * 暖岛整理 www.nuandao.cn
 */
function nd_get_24h_post_count(){
	$today = getdate();
	$query = new WP_Query( 'year=' . $today["year"] . '&monthnum=' . $today["mon"] . '&day=' . $today["mday"]);
	$postsNumber = $query->found_posts;
	return $postsNumber;
}
/*
 * WordPress获取一周发布文章数量
 * 暖岛整理 www.nuandao.cn
 */
function nd_get_week_post_count(){
    $date_query = array(
        array(
        'after'=>'1 week ago'
        )
    );
    $args = array(
        'post_type' => 'post',
        'post_status'=>'publish',
        'date_query' => $date_query,
        'no_found_rows' => true,
        'suppress_filters' => true,
        'fields'=>'ids',
        'posts_per_page'=>-1
    );
    $query = new WP_Query( $args );
    return $query->post_count;
}



/*
 * 暖岛B2子主题 网址导航功能 
 * www.nuandao.cn
 */
 
// 注册自定义文章形式 暖岛网整理
add_action( 'init', 'nuandao_post_type_site' );
function nuandao_post_type_site() {
	$labels = array(
		'name'                      => '网址', 'post type general name', 'your-plugin-textdomain',
		'singular_name'             => '网址', 'post type singular name', 'your-plugin-textdomain',
		'menu_name'                 => '网址', 'admin menu', 'your-plugin-textdomain',
		'name_admin_bar'            => '网址', 'add new on admin bar', 'your-plugin-textdomain',
		'add_new'                   => '添加网址', 'site', 'your-plugin-textdomain',
		'add_new_item'              => '添加新网址', 'your-plugin-textdomain',
		'new_item'                  => '新网址', 'your-plugin-textdomain',
		'edit_item'                 => '编辑网址', 'your-plugin-textdomain',
		'view_item'                 => '查看网址', 'your-plugin-textdomain',
		'all_items'                 => '所有网址', 'your-plugin-textdomain',
		'search_items'              => '搜索网址', 'your-plugin-textdomain',
		'parent_item_colon'         => 'Parent 网址:', 'your-plugin-textdomain',
		'not_found'                 => '你还没有发布网址。', 'your-plugin-textdomain',
		'not_found_in_trash'        => '回收站中没有网址。', 'your-plugin-textdomain'
	);
	$args = array(
		'labels'                    => $labels,
		'description'               => '暖岛网网址导航',
		'public'                    => true,
		'publicly_queryable'        => true,
		'show_ui'                   => true,
		'show_in_menu'              => true,
		'query_var'                 => true,
		'rewrite'                   => true,
		'capability_type'           => 'post',
		'menu_icon'                 => 'dashicons-admin-site',
		'has_archive'               => true,
		'hierarchical'              => false,
		'show_in_rest'              => true, // 启用古腾堡编辑器
		'menu_position'             => 10,
		'supports'                  => array( 'title', 'author', 'editor', 'comments', 'custom-fields' ,'thumbnail')
	);
	register_post_type( 'site', $args );
}

// 注册网址导航自定义分类法 暖岛网整理
$labels = array(
    'name'                          => '',
    'singular_name'                 => '网址分类',
    'search_items'                  =>  '搜索网址' ,
    'all_items'                     => '所有网址' ,
    'parent_item'                   => null,
    'parent_item_colon'             => null,
    'edit_item'                     => '编辑网址' ,
    'update_item'                   => '更新网址' ,
    'add_new_item'                  => '添加网址' ,
    'new_item_name'                 => '新网址',
    'separate_items_with_commas'    => '按逗号分开' ,
    'add_or_remove_items'           => '添加或删除',
    'choose_from_most_used'         => '从经常使用的类型中选择',
    'menu_name'                     => '分类目录',
);
register_taxonomy(
    'sitecat',
    array(
        'site'
        ),
    array(
        'hierarchical'              => true,
        'labels'                    => $labels,
        'show_ui'                   => true,
        'query_var'                 => true,
    )
);



// 设置自定义文章类型的固定链接结构为 ID.html 暖岛网整理
add_filter('post_type_link', 'custom_site_link', 1, 3);
function custom_site_link( $link, $post = 0 ){
    if ( $post->post_type == 'site' ){
        return home_url( 'site/' . $post->ID .'.html' );
    } else {
        return $link;
    }
}
add_action( 'init', 'nuandao_site_rewrites_init' );
function nuandao_site_rewrites_init(){
    add_rewrite_rule(
        'site/([0-9]+)?.html$',
        'index.php?post_type=site&p=$matches[1]',
		'top' 
	);
    add_rewrite_rule(
        'site/([0-9]+)?.html/comment-page-([0-9]{1,})$',
        'index.php?post_type=site&p=$matches[1]&cpage=$matches[2]',
        'top'
    );
}




// 添加自定义字段

$new_meta_sites_boxes =
array(
	"sites_link" => array(
		"name" => "_sites_link",
		"std" => "",
		"title" => "输入网址链接，需包含 http(s)://",
		"type"=>"text"
	),
);

// 面板内容
function new_meta_sites_boxes() {
	global $post, $new_meta_sites_boxes;
	//获取保存
	foreach ($new_meta_sites_boxes as $meta_box) {
		$meta_box_value = get_post_meta($post->ID, $meta_box['name'] , true);
		if ($meta_box_value != "")
		//将默认值替换为已保存的值
		$meta_box['std'] = $meta_box_value;
		echo '<input type="hidden" name="' . $meta_box['name'] . '_noncename" id="' . $meta_box['name'] . '_noncename" value="' . wp_create_nonce(plugin_basename(__FILE__)) . '" />';
		//选择类型输出不同的html代码
		switch ($meta_box['type']) {
			case 'title':
				echo '<div>' . $meta_box['title'] . '</div>';
			break;
			case 'text':
				echo '<div style="margin-bottom: 5px;">' . $meta_box['title'] . '</div>';
				echo '<div class="form-field" style="margin-bottom: 15px"><input type="text" size="40" name="' . $meta_box['name'] . '" value="' . $meta_box['std'] . '" /></div>';
			break;
			case 'textarea':
				echo '<div style="margin-bottom: 5px;">' . $meta_box['title'] . '</div>';
				echo '<textarea id="seo-excerpt" cols="40" rows="2" name="' . $meta_box['name'] . '">' . $meta_box['std'] . '</textarea><br />';
			break;
			case 'radio':
				echo '<div style="margin-bottom: 5px;">' . $meta_box['title'] . '</div>';
				$counter = 1;
				foreach ($meta_box['buttons'] as $radiobutton) {
					$checked = "";
					if (isset($meta_box['std']) && $meta_box['std'] == $counter) {
						$checked = 'checked = "checked"';
					}
					echo '<input ' . $checked . ' type="radio" class="kcheck" value="' . $counter . '" name="' . $meta_box['name'] . '_value"/>' . $radiobutton;
					$counter++;
				}
			break;
			case 'checkbox':
				if (isset($meta_box['std']) && $meta_box['std'] == 'true') $checked = 'checked = "checked"';
				else $checked = '';
				echo '<br /><label><input type="checkbox" name="' . $meta_box['name'] . '" value="true"  ' . $checked . ' />';
				echo '' . $meta_box['title'] . '</label><br /><br />';
			break;
			case 'upload':
				$button_text = (isset($meta_box['button_text'])) ? $meta_box['button_text'] : 'Upload';
				echo '<div style="margin-bottom: 5px;">' . $meta_box['title'] . '</div>';
				echo '<input class="damiwp_url_input" style="width: 95%;margin-bottom: 10px;" type="text" id="'.$meta_box['name'].'_input" size="'.$meta_box['size'].'" value="'.$meta_box['std'].'" name="'.$meta_box['name'].'"/><br><a href="#" id="'.$meta_box['name'].'" class="dami_upload_button button">'.$button_text.'</a>';
			break;
			}
		}
}
function create_meta_sites_box() {
	global $theme_name;
	if (function_exists('add_meta_box')) {
		add_meta_box('new-meta-boxes', '网站属性', 'new_meta_sites_boxes', 'site', 'normal', 'high');
	}
}
function save_sites_postdata($post_id) {
	global $post, $new_meta_sites_boxes;
	foreach ($new_meta_sites_boxes as $meta_box) {
		if (!wp_verify_nonce((@$_POST[$meta_box['name'] . '_noncename']), plugin_basename(__FILE__))) {
			return $post_id;
		}
		if ('page' == $_POST['post_type']) {
			if (!current_user_can('edit_page', $post_id)) return $post_id;
		} else {
			if (!current_user_can('edit_post', $post_id)) return $post_id;
		}
		$data = $_POST[$meta_box['name'] ];
		if (get_post_meta($post_id, $meta_box['name'] ) == "") add_post_meta($post_id, $meta_box['name'] , $data, true);
		elseif ($data != get_post_meta($post_id, $meta_box['name'] , true)) update_post_meta($post_id, $meta_box['name'] , $data);
		elseif ($data == "") delete_post_meta($post_id, $meta_box['name'] , get_post_meta($post_id, $meta_box['name'] , true));
	}
}
add_action('admin_menu', 'create_meta_sites_box');
add_action('save_post', 'save_sites_postdata');









// 添加网址导航菜单
register_nav_menus(
	array(
		'site-nav' => __( '导航菜单' ),
	)
); 
function nuandao_menu($location){
    if ( function_exists( 'wp_nav_menu' ) && has_nav_menu($location) ) {
        wp_nav_menu( array( 'container' => false, 'items_wrap' => '%3$s', 'theme_location' => $location, 'depth'=>2 ) );
    } else {
        echo '<li><a href="'.get_bloginfo('url').'/wp-admin/nav-menus.php">请到[后台->外观->菜单]中设置菜单。</a></li>';
    }

}


// 网址导航添加特色缩略图支持 暖岛网整理

if ( function_exists('add_theme_support') )add_theme_support('post-thumbnails');
//输出缩略图地址
function nd_site_thumbnail_src(){
	$default_thumb = 'https://www.nuandao.cn/images/ndnav/default-thumb.png';
	global $post;
	if( $values = get_post_custom_values("thumbnail") ) { //输出自定义域图片地址
		$values = get_post_custom_values("thumbnail");
		$post_thumbnail_src = $values [0];
	} elseif( has_post_thumbnail() ){ //如果有特色缩略图，则输出缩略图地址
		$thumbnail_src = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
		$post_thumbnail_src = $thumbnail_src [0];
	} else {
		$post_thumbnail_src = '';
		ob_start();
		ob_end_clean();
		$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
		$post_thumbnail_src = $matches [1] [0]; //获取该图片 src
		if(empty($post_thumbnail_src)){
		    $post_thumbnail_src = $default_thumb; //如果日志中没有图片，则显示默认图片
		}
	};
	echo $post_thumbnail_src;
}

/*
 * ------------------------------------------------------------------------------
 * WordPress文章访问计数（勿删、必须）
 * ------------------------------------------------------------------------------
 */

function record_visitors(){
	if (is_singular()) {
		global $post;
		$post_ID = $post->ID;
		if($post_ID){
			$post_views = (int)get_post_meta($post_ID, 'views', true);
			if(!update_post_meta($post_ID, 'views', ($post_views+1))) 
			{
				add_post_meta($post_ID, 'views', 1, true);
			}
		}
	}
}
add_action('wp_head', 'record_visitors');  
function post_views($before = '(点击 ', $after = ' 次)', $echo = 1)
{
	global $post;
	$post_ID = $post->ID;
	$views = (int)get_post_meta($post_ID, 'views', true);
	if ($echo) echo $before, number_format($views), $after;
	else return $views;
};
