<div class="footer-widget">
    <div class="row">
        <div class="col-xs-12 col-sm-6 col-md-3 widget--about">
            <div class="widget--content">
                <div class="footer--logo">
                    <img class="tap-logo" src="<?php echo esc_url( _cao( 'site_footer_logo') ); ?>" data-dark="<?php echo esc_url(_cao( 'site_footer_logo')); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
                </div>
                <p class="mb-10"><?php echo _cao('site_footer_desc');?></p>
            </div>
        </div>
        <!-- .col-md-2 end -->
        <div class="col-xs-12 col-sm-6 col-md-9 col-md-offset-1 widget--links">
            <div class="widget--content">
                <ul class="list-unstyled mb-0">
                    <?php 
                    $foot_link = _cao('foot_link');
                    if (!empty($foot_link)) {
                        foreach ($foot_link as $key => $v) {
                    ?>
                    <li><a href="<?php echo $v['link']; ?>" target="_blank"><?php echo $v['text']; ?></a></li>
                    <?php }} ?>
                </ul>
            </div>
        </div>
    </div>
</div>