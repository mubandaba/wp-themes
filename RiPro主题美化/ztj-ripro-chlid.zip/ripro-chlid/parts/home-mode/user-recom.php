<?php 
    $recomUser_id = _cao('recomUser_id');
    $user_ID = explode(",",$recomUser_id);
?>
<div class="recomUser">
    <div class="container">
        <div class="post-modules-top">
            <h3 class="section-title">活跃用户</h2>
        </div>
        <ul>
            <?php 
            foreach ($user_ID as $user) {
                $user_nickname = get_the_author_meta('nickname',$user);
                $user_description = get_the_author_meta('description',$user);
                $CaoUser = new CaoUser($user);
            ?>
            <li>
                <div class="item box b2-radius">
					<article class="warp">
						<div class="ava">
							<img class="avatar" src="<?php echo _get_user_avatar_url('user',$user)?>">
						</div>
						<div class="info">
						    <div class="name">
								<a><?php echo $user_nickname; ?></a>
								<!--<em class="vip"><?php 
                                   // echo $CaoUser->vip_name();
								?></em>-->
							</div>
							<div class="desc">
							    <?php 
							    if (!$user_description) {
                                        echo '很个性，没签名！';
                                    }else {
                                        echo $user_description;
                                    }
							    ?>
							</div>
							<div class="count">
								<span>文章：<b><?php echo count_user_posts($user, 'post', false); ?></b></span>
								<span>评论：<b><?php echo get_comments('count=true&user_id='.$user); ?></b></span>
							</div>
						</div>
					</article>
				</div>
			</li>
            <?php } ?>
        </ul>
    </div>
</div>