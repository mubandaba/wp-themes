<section class="siteCount" style="background-image: url(<?php echo _cao('siteCount_bg'); ?>);">
    <div class="cover"></div>
    <div class="container">
	    <ul>
	        <li>
	            <span><?php $users = $wpdb->get_var("SELECT COUNT(ID) FROM $wpdb->users"); echo $users; ?></span>
	            <b>用户总数</b>
	        </li>
	        <li>
	            <span><?php $count_posts = wp_count_posts(); echo $published_posts =$count_posts->publish;?></span>
	            <b>文章总数</b>
	        </li>
	        <li>
	            <span><?php echo nd_get_all_view(); ?></span>
	            <b>浏览总数</b>
	        </li>
	        <li>
	            <span><?php echo nd_get_24h_post_count(); ?></span>
	            <span><?php // echo nd_get_week_post_count(); ?></span>
	            <b>今日发布</b>
	        </li>
	        <li>
	            <span><?php echo floor((time()-strtotime("2020-3-21"))/86400); ?></span>
	            <b>稳定运行</b>
	        </li>
	    </ul>
	    <div class="join-vip">
	        <a class="b-r-4" href="<?php echo _cao('siteCount_btn_url'); ?>" target="_blank"><?php echo _cao('siteCount_btn'); ?></a>
	        <p><?php echo _cao('siteCount_text'); ?></p>
	    </div>
    </div>
</section>