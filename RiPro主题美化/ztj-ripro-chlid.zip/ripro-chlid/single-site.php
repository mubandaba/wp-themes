<?php get_header(); ?>
<div class="sites container" style="margin-top: 30px">
    <div class="row">
        <div class="content-area col-9">
            <main class="site-main">
                <div class="box">
                    <?php while ( have_posts() ) : the_post(); ?>
                    <div class="site-head">
                        <h1><?php the_title(); ?></h1>
                        <div class="info">
                            <span><?php the_time('Y-m-d') ?> 收录</span>
                            <span><?php post_views('', ''); ?> 访问</span>
                        </div>
                    </div>
                    <div class="entry-content site-single">
                        <div class="site-row">
                            <div class="site-icon">
                                <img class="bg" src="<?php echo nd_site_thumbnail_src(); ?>" />
                	            <i>
                                    <img src="<?php echo nd_site_thumbnail_src(); ?>" />
                                </i>
                            </div>
                            <div class="site-main">
                                <div class="site-list-cat">
                                    <?php 
                                        $terms = get_the_terms( get_the_ID(), 'sitecat' );
                                        if( !empty( $terms ) ){
                                        	foreach( $terms as $term ){
                                                $name = $term->name;
                                                $link = esc_url( get_term_link( $term, 'res_category' ) );
                                                echo "<a href='$link' target='_blan'>".$name."</a>";
                                            }
                                        }  
                                    ?>
                                </div>
                                <div class="site-desc">
                                    <?php the_content(); ?>
                                </div>
                                <div class="site-go">
                        		    <a href="<?php echo get_post_meta($post->ID,'_site_link',true);?>" target="_blank" rel="nofollow" uk-tooltip="访问网站">访问网站<i class="iconfont icon-go uk-margin-small-left"></i></a>
                        		</div>
                            </div>
            	        </div>
                    </div>
            		<?php endwhile; ?>
        		</div>
        		<div class="site-other">
        		    <div class="site-box">
                		<div class="site-box-title" id="site<?php echo $category->term_id; ?>" >
                    		<h3>相关站点</h3>
                		</div>
                		<div class="site-box-warp">
                            <?php 
                				$posts = get_posts(
                					array(							
                						'numberposts' => '9', //输出的文章数量
                						'post_type' => 'site',	//自定义文章类型名称		
                						'tax_query'=>array(
                							array(
                								'taxonomy'=>'sitecat', //自定义分类法名称
                								'terms'=>'sitecat'
                							)
                						),
                					)
                				);
                				?>
                				<?php if($posts): foreach($posts as $post): 
                				include get_stylesheet_directory() . '/expand/sitenav/loop/loop-card.php'; 
                				wp_reset_postdata(); endforeach; endif;
                			?>
                		</div>
            		</div>
        		</div>
            </main>
        </div>
        <div class="col-3">
            <?php get_sidebar(); ?>
        </div>
    </div>
</div>
<?php get_footer(); ?>
