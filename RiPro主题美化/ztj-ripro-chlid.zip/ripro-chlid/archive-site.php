<?php get_header();?>
<?php require_once get_stylesheet_directory() . '/expand/sitenav/home/site-search.php'; ?>
<div class="site-main container">
    <div class="site-row">
        <?php require_once get_stylesheet_directory() . '/expand/sitenav/home/site-menu.php'; ?>
        <?php require_once get_stylesheet_directory() . '/expand/sitenav/home/site-list.php'; ?>
    </div>
</div>
<?php get_footer(); ?>