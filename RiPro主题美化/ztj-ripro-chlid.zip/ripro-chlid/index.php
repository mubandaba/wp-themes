<?php
/**
 * RiPro是一个优秀的主题，首页拖拽布局，高级筛选，自带会员生态系统，超全支付接口，你喜欢的样子我都有！
 * 正版唯一购买地址，全自动授权下载使用：https://ritheme.com/
 * 作者唯一QQ：200933220 （油条）
 * 承蒙您对本主题的喜爱，我们愿向小三一样，做大哥的女人，做大哥网站中最想日的一个。
 * 能理解使用盗版的人，但是不能接受传播盗版，本身主题没几个钱，主题自有支付体系和会员体系，盗版风险太高，鬼知道那些人乱动什么代码，无利不起早。
 * 开发者不易，感谢支持，更好的更用心的等你来调教
 */
get_header();
?>
<div class="content-area">
	<main class="site-main">
	    <section class="ztj-style">
	        <div class="ztj-bg" style="background-image: url(<?php echo _cao('ztj_home_bg'); ?>)"></div>
	        <div class="container">
	            <div class="title">
	                <h2><a href="<?php bloginfo('url'); ?>" target="_blank"><?php echo _cao('ztj_home_h1'); ?></a></h2>
	                <span class="b-r-4"><?php echo _cao('ztj_home_p'); ?></span>
	            </div>
	            <div class="ztj-warp b-r-4">
	                <?php
	                    $ztj_search = _cao('ztj_search');
	                ?>
	                <div class="ztj-menu">
	                    <ul>
	                        <li class="all">
                                <a href="<?php echo $ztj_search['all_link']; ?>" target="_blank">
                                    <svg class="icon" aria-hidden="true">
                                        <use xlink:href="#icon-faxian"></use>
                                    </svg>
                                    <span><?php echo $ztj_search['all_text']; ?></span>
                                </a>
	                        </li>
	                        <?php
	                            $search_links = $ztj_search['link_item'];
	                            if(!empty($search_links)){
                                foreach ($search_links as $links){
                            ?>
                            <li>
	                            <a href="<?php echo $links['link'] ?>" target="_blank"><?php echo $links['text'] ?></a>
	                        </li> 
                            <?php }} ?>
	                    </ul>
	                    <ul style="justify-content: flex-end;">
	                        <li>
                                <a class="vip" href="" target="_blank">
                                    <svg class="icon" aria-hidden="true">
                                        <use xlink:href="#icon-VIP"></use>
                                    </svg>
                                    <span>开通VIP</span>
                                </a>
	                        </li>
	                    </ul>
	                </div>
	                <div class="ztj-search">
	                    <form method="get" class="b-r-4 search-form inline" action="<?php bloginfo('url'); ?>">
                          <input type="search" class="search-field inline-field" placeholder="<?php echo $ztj_search['search_input_text']; ?>" autocomplete="off" value="" name="s" required="required">
                          <button type="submit"><i class="mdi mdi-magnify"></i>搜索</button>
                        </form>
	                </div>
	                <div class="ztj-tags">
	                    <ul>
	                        <li><a class="all b-r-4" href="/tags" target="_blank">全部标签 +</a></li>
    	                    <?php 
                        		$tags_list = get_tags('orderby=count&order=DESC&number=19');
                        		if($tags_list) {
                        			foreach($tags_list as $tag) {
                        				echo '<li><a class="b-r-4" target="_blank" href="'.get_tag_link($tag).'">'. $tag->name .'</a></li>'; 
                        			} 
                        		} 
                        	?>
                    	</ul>
	                </div>
	            </div>
	        </div>
	    </section>
        <script type='text/javascript' src='https://at.alicdn.com/t/font_2221976_hfz1pv3sil.js'></script>
    	<?php $module_home = _cao('home_mode');
    		if (!$module_home) {
    		    echo '<h2 style=" text-align: center; margin: 0 auto; padding: 60px; ">请前往后台-主题设置-设置首页模块！</h2>';
    		}
    		// var_dump($module_home['enabled']);
    		if ($module_home) {
    		    foreach ($module_home['enabled'] as $key => $value) {
    		        @get_template_part('parts/home-mode/'.$key);
    		    }
    		}
    		get_template_part('parts/home-mode/banner')
    	?>
    	<?php 
    	    get_template_part('parts/home-mode/user-recom'); //用户推荐
    	    if( _cao('show_siteCount') == false ) {
    	        get_template_part('parts/home-mode/site-count'); //网址底部统计
    	    }
    	?>
	</main>
</div>
<?php get_footer(); ?>
