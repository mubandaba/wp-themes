<link rel='stylesheet' href='//at.alicdn.com/t/font_1764854_wj83ofdifhs.css' type='text/css' media='all' />
<div class="site-menu">
    <div class="sidebar-innter">
        <ul class="box b2-radius">
            <li class="title">
                <i class="b2font b2-shixindiqiu"></i><span>网址导航</span>
            </li>
            <li class="all">
                <a href="/site/">全部网址</a>
            </li>
            <?php
			$args=array(
			'taxonomy' => 'sitecat',
			'hide_empty'=>'0',
			'hierarchical'=>1,
			'parent'=>'0',
			);
			$categories=get_categories($args);
			foreach($categories as $category){
			$cat_id = $category->term_id;
			?>
			<li class="uk-display-inline-block"><a href="<?php echo get_category_link( $category->term_id )?>" class="uk-display-block" uk-scroll><?php echo $category->name;?></a></li>
			<?php }?>	
        </ul>
    </div>
</div>