<section class="site-warp">
    <div class="container">
        <div class="site-search">
            <h3>以最快的速度获取想要的资源</h3>
            <ul class="search-tmenu">
                <li class="active"><span>常用</span></li>
                <li><span>工具</span></li>
                <li><span>社区</span></li>
                <li><span>灵感</span></li>
            </ul>
            <form id="searchForm" class="shadow b2-radius" action="https://www.baidu.com/s?wd=" method="get" target="_blank">
                <input id="searchinput" class="" type="text" placeholder="百度一下"  autocomplete="off">
                <button id="searc-submit" class="uk-text-bold" type="submit"><i class="fa fa-search"></i></button>
            </form>
            <div class="subnav">
                <div class="subnav-item active">
                	<ul class="search-bmenu uk-padding-remove">
                		<li class="search-item on" url="https://www.baidu.com/s?wd=">百度</li>
                		<li class="search-item" url="https://www.google.com/search?q=">Google</li>
                		<li class="search-item" url="https://www.so.com/s?q=">360</li>
                		<li class="search-item" url="https://www.sogou.com/web?query=">搜狗</li>
                		<li class="search-item" url="https://cn.bing.com/search?q=">必应</li>
                		<li class="search-item" url="https://yz.m.sm.cn/s?q=">神马</li>
                	</ul>
                </div>
                <div class="subnav-item">
                	<ul class="search-bmenu uk-padding-remove">
                		<li class="search-item on" url="http://rank.chinaz.com/all/">权重查询</li>
                		<li class="search-item" url="http://link.chinaz.com/">友链检测</li>
                		<li class="search-item" url="https://icp.aizhan.com/">备案查询</li>
                		<li class="search-item" url="http://ping.chinaz.com/">PING检测</li>
                		<li class="search-item" url="http://tool.chinaz.com/Links/?DAddress=">死链检测</li>
                	</ul>
                </div>
                <div class="subnav-item">
                	<ul class="search-bmenu uk-padding-remove">
                		<li class="search-item on" url="https://www.zhihu.com/search?type=content&q=">知乎</li>
                		<li class="search-item" url="http://weixin.sogou.com/weixin?type=2&query=">微信</li>
                		<li class="search-item" url="http://s.weibo.com/weibo/">微博</li>
                		<li class="search-item" url="https://www.douban.com/search?q=">豆瓣</li>
                	</ul>
                </div>
                <div class="subnav-item">
                	<ul class="search-bmenu uk-padding-remove">
                		<li class="search-item on" url="https://www.huaban.com/search/?q=">花瓣</li>
                		<li class="search-item" url="https://dribbble.com/search/">dribbble</li>
                		<li class="search-item" url="https://www.behance.net/search?search=">behance</li>
                		<li class="search-item" url="http://www.zcool.com.cn/search/content?&word=">站酷</li>
                	</ul>
                </div>
            </div>
        </div>
    </div>
</section>
<style>
    .term-bar {
        display: none;
    }
    .site-content {
        padding-top: 0;
    }
</style>