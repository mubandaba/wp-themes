<?php 
   //$cat_id = ['40','39','38','37','36','35','34','33','32','31']; 
    $site_num = '8'; //每个分类显示网址数量
?>
<div class="site-list">
    <div class="site-item">
		<?php
		$args=array(
			'taxonomy' => 'sitecat',
			'hide_empty'=>'0',
			'hierarchical'=>1,
			'parent'=>'0',
			//'include'       => $cat_id,
		);
		$categories=get_categories($args);
		foreach($categories as $category){
			$cat_id = $category->term_id;
		?>
    	<div class="site-box">
    		<div class="site-box-title" id="site<?php echo $category->term_id; ?>" >
        		<h3><?php echo $category->name;?></h3>
        		<a class="more" href="<?php echo get_category_link( $category->term_id )?>" target="_blank">查看更多<i class="iconfont icon-angle-right"></i></a>
    		</div>
    		<div class="site-box-warp">
    			<?php
    				$salong_posts = new WP_Query(
    					array(
    						'post_type' => 'site',//自定义文章类型，这里为video
    						'ignore_sticky_posts' => 1,//忽略置顶文章
    						'posts_per_page' => $site_num,//显示的文章数量
    						'meta_key' => 'views', //访问量
    						'orderby' => 'meta_value_num', //访问量排序
    						'tax_query' => array(
    							array(
    								'taxonomy' => 'sitecat',//分类法名称
    								'field'    => 'id',//根据分类法条款的什么字段查询，这里设置为ID
    								'terms'    => $cat_id,//分类法条款，输入分类的ID，多个ID使用数组：array(1,2)
    							)
    						),
    					)
    				);
    				if ($salong_posts->have_posts()): while ($salong_posts->have_posts()): $salong_posts->the_post(); 
    			    include get_stylesheet_directory() . '/expand/sitenav/loop/loop-card.php'; 
    			    endwhile; endif;
                ?>
    		</div>
    	</div>
        <?php }?>
    </div>	
</div>