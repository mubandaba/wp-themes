<div class="site-card">
    <div class="item box">
    	<a href="<?php the_permalink(); ?>" target="_blank">
    		<i class="icon" style="background-image: url(<?php echo nd_site_thumbnail_src() ?>);"></i>
    		<div class="content">
    			<span><?php the_title(); ?></span>
    			<div class="desc"><?php echo wp_trim_words( the_excerpt(), 66 ); ?></div>
    		</div>
    	</a>
		<div class="info">
			<span><i class="fa fa-eye"></i> <?php post_views('', ''); ?></span>
			<span class="uk-float-right"><a href="<?php echo get_post_meta($post->ID,'_site_link',true);?>" target="_blank" rel="nofollow" title="点击直达"><i class="fa fa-paper-plane"></i></a></span>
		</div>
	</div>
</div>