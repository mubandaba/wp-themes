$(function() {
	//首页右侧悬浮导航
	$(window).scroll(function(){
		var scroll_top = $(window).scrollTop();
		if(scroll_top>=50){
			$(".site-header").addClass('inNav');
		}else{
			$(".site-header").removeClass('inNav');
		}
	})
	
	
});