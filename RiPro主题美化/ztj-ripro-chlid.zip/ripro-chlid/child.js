$(document).ready(function(){
    
    //首页搜索条
    var jsonData = ["百度一下","权重查询(不带http/https)","知乎","花瓣"]
    var jsonDataUrl = ["https://www.baidu.com/s?wd=","http://rank.chinaz.com/all/","https://www.zhihu.com/search?type=content&q=","https://www.huaban.com/search"]
    $('.search-tmenu li').click(function(){
        var _index = $(this).index();
        $(this).addClass("active").siblings().removeClass("active");
        $('.subnav').each(function(){
    		$(this).find('div').eq(_index).addClass("active").siblings().removeClass("active");
    	})
        console.log(_index)
    })
    
    
    $(".subnav-item").on("shown",function(){
    	$("#searchForm").attr("action",jsonDataUrl[$(this).index()]);
    	$("#searchinput").attr("placeholder",jsonData[$(this).index()]);
    })
    $(".search-item").on("click",function(){
    	$("#searchForm").attr("action",$(this).attr("url"));
    	$("#searchinput").attr("placeholder",$(this).html());
    	$(this).addClass("on").siblings().removeClass("on");
    })
    
    $("#searc-submit").click(function(){
    	window.open($("#searchForm").attr("action")+$("#searchinput").val())
    })
    
    $('#searchForm').keydown(function(e) {
    	if (e.keyCode == 13) {
      		window.open($("#searchForm").attr("action")+$("#searchinput").val())
      		return false;
    	}
    });
    
    
    
});