<?php
	$sidebar = cao_sidebar();
	$column_classes = cao_column_classes( $sidebar );
	global $post;
    $post_id = $post->ID;
    $user_id = is_user_logged_in() ? wp_get_current_user()->ID : 0;
	get_header();
	//var_dump(get_post_meta($post_id));
?>

<div class="container">
	<div class="breadcrumbs">
	<?php echo dimox_breadcrumbs(); ?>
	</div>
    <?php 
        if (_get_post_shop_status()) {
        $cao_info   = get_post_meta($post_id, 'cao_info', true); //信息属性
        $author_id = get_post_field( 'post_author', $post_id );//用户ID
        $cao_demourl = get_post_meta($post_id, 'cao_demourl', true); //信息属性
    ?>
    <style>.cao_entry_header{display: none;}.article-content .container {padding:0}</style>
    <section class="single-down b-r-4">
        <div class="down-box">
            <div class="down-thumb">
                <img class="lazyload" data-src="<?php echo esc_url(_get_post_timthumb_src()); ?>" alt="<?php echo get_the_title(); ?>">  
            </div>
            <div class="down-data">
                <h2><?php echo get_the_title(); ?></h2>
                <div class="entry-meta">
                    <div class="meta-author">
                        <?php
                            echo get_avatar( get_the_author_meta( 'email', $author_id ), '40', null, get_the_author_meta( 'display_name', $author_id ) );?>
                        <span><?php echo get_the_author_meta( 'display_name', $author_id ); ?></span>
                    </div>
                    <span><i class="fa fa-clock-o"></i> <?php echo _get_post_time(); ?></span>
                    <span><i class="fa fa-eye"></i>  <?php echo _get_post_views(); ?></span>
                </div>
                <ul>
                    <?php 
                        if ($cao_info) {
                            foreach ($cao_info as $key => $value) {
                                echo '<li><div>' . $value['title'] . '</div><span>' . $value['desc'] . '</span></li>';
                            } 
                    ?>
                    <?php }else {?>
                        <li><div>主题类型</div><span><?php the_category('、','li'); ?></span></li>
                        <li><div>主题作者</div><span>未知</span></li>
                        <li><div>主题特色</div><span>博主太懒了，没填写</span></li>
                    <?php } ?>
                </ul>
                <div class="down-foot">
                    <div class="down-btn">
                        <button class="theme-down" id="themeDown">立即下载</button>
                        <a class="demo-url" href="<?php echo $cao_demourl; ?>" target="_blank" rel="nofollow">查看演示</a>
                    </div>
                    <div class="xshare">
                        <span class="xshare-title">分享到：</span>
                        <?php if (_cao('is_nav_myfav') && is_site_shop_open()): ?>
                        <a href="javascript:;" title="收藏文章" etap="star" data-postid="<?php the_ID(); ?>" class="ripro-star<?php echo $is_post_favcss;?>"><i class="fa fa-star-o"></i></a>
                        <?php endif; ?>
                        <a href="" etap="share" data-share="qq" class="share-qq"><i class="fa fa-qq"></i></a>
                        <a href="" etap="share" data-share="weibo" class="share-weibo"><i class="fa fa-weibo"></i></a>
                        <?php if( _cao('poster_share_open') ){ ?>
                        <a href="javascript:;" class="btn-bigger-cover share-weixin" data-nonce="<?php echo wp_create_nonce('mi-create-bigger-image-'.$post->ID );?>" data-id="<?php echo $post->ID; ?>" data-action="create-bigger-image" id="bigger-cover"><i class="fa fa-paper-plane"></i></a>
                        <?php } ?>
                  </div>
                </div>
            </div>
        </div>
    </section>
    <?php } ?>
	<div class="row">
		<div class="<?php echo esc_attr( $column_classes[0] ); ?>">
			<div class="content-area">
				<main class="site-main">
					<?php while ( have_posts() ) : the_post();
						get_template_part( 'parts/template-parts/content', 'single' );
					endwhile; ?>
				</main>
			</div>
		</div>
		<?php if ( $sidebar != 'none' ) : ?>
			<div class="<?php echo esc_attr( $column_classes[1] ); ?>">
				<?php get_sidebar(); ?>
			</div>
		<?php endif; ?>
	</div>
</div>

<?php if (_cao('disable_related_posts','1') && _cao('related_posts_style','grid')=='fullgrid') {
	get_template_part( 'parts/related-posts' );
}?>
<div class="down-pop">
    <div class="down-box">
        <i class="down-pop-close fa fa-times"></i>
        <h3>主题下载</h3>
        <div class="down-main">
            <img src="/wp-content/uploads/2020/12/1607257791-c019e20ced2dfd6.png" />
            <div class="desc">
                <p>使用<b>QQ</b>扫描二维码即可下载！</p>
                <p>或查找QQ群：772774006</p>
            </div>
        </div>
        <a class="on-btn" href="https://jq.qq.com/?_wv=1027&k=5klO8DdF" target="_blank" rel="nofollow">直接下载</a>
    </div>
</div>
<script>
    $('.theme-down').click(function(){
		$('.down-pop').fadeIn();	
	})
	$('.down-pop-close').click(function(){
		$('.down-pop').fadeOut();	
	})
</script>
<?php get_footer(); ?>