<?php get_header();?>
<?php require_once get_stylesheet_directory() . '/expand/sitenav/home/site-search.php';?>
<div class="site-main container">
    <div class="site-row">
        <?php require_once get_stylesheet_directory() . '/expand/sitenav/home/site-menu.php'; ?>
        <div class="site-list">
            <div class="site-box">
                <div class="site-box-title" id="site455">
            		<h3><?php single_cat_title(); ?></h3>
        		</div>
                <div class="site-item">
                	<div class="site-box">
                		<div class="site-box-warp">
                		    <?php if(have_posts()) : while (have_posts()) : the_post(); ?>
            			    <?php include get_stylesheet_directory() . '/expand/sitenav/loop/loop-card.php'; ?>
            			    <?php endwhile; else: ?>
            			    <p>暂无内容！</p>
            			    <?php endif; ?>
                		</div>
                	</div>
                </div>	
            </div>
        </div>
    </div>
</div>
<?php get_footer(); ?>