<?php get_header(); ?>
<h1 style="text-indent:-99999px;height:0;"><?php the_field('keywords');?></h1>
<?php the_crumbs(); ?>
<section id="main" class="p40">
<div class="container">
<div class="row">
<div class="col-md-9 col-sm-8 col-xs-12">
<div class="content">
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<article>
<div class="entry-meta">
<h1 class="mb20"><?php the_title();?></h1>
</div>
<div class="entry-content">
<?php the_content();?> 
</div>
</article>
<?php endwhile;  endif;?>
</div>
</div>
<div class="col-md-3 col-sm-4 hidden-xs">
<?php get_template_part( 'template/sidebar' ); ?>
</div>
</div>
</section>
<?php get_footer(); ?>