<?php get_header(); ?>
<?php the_crumbs(); ?>
<section id="content" class="f5 p30">
<div class="container">
<div class="row">
<div class="col-md-9 col-sm-9 col-xs-12 wow fadeInLeft delay300">
<div class="content">
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<div class="single-header">
<h1><?php the_title(); ?></h1>
<div class="single-meta">
<span class="time"><?php _e('时间','xs')?>：<?php the_time('Y-n-j'); ?></span>
<span class="author pull-right"><?php _e('作者','xs')?>：<?php the_author(); ?></span>
</div>
</div>
<div class="entry-content">
<?php the_content();?> 
</div>
</article>
<?php endwhile;  endif;?>
<div class="post-link-share clearfix">
<div class="bdsharebuttonbox">
<span class="share-hmj">分享到：</span>
<a title="分享到新浪微博" class="bds_tsina fa fa-weibo" href="#" data-cmd="tsina"></a>
<a title="分享到QQ空间" class="bds_qzone fa fa-star" href="#" data-cmd="qzone"></a>
<a title="分享到QQ好友" class="qq fa fa-qq" href="#" data-cmd="sqq" ></a>
<a title="分享到微信" class="bds_weixin fa fa-weixin" href="#" data-cmd="weixin"></a>
<a class="bds_more fa fa-ellipsis-h" href="#" data-cmd="more"></a>
</div>
</div>
<div class="post-tags mt20 mb30"><?php the_tags()?></div>
<div class="single-info mb40">
声明：本文内容由互联网用户自发贡献自行上传，本网站不拥有所有权，未作人工编辑处理，也不承担相关法律责任。如果您发现有涉嫌版权的内容，欢迎发送邮件至：<?php bloginfo('admin_email');?> 进行举报，并提供相关证据，工作人员会在5个工作日内联系你，一经查实，本站将立刻删除涉嫌侵权内容。
</div>

<div class="single-xg mb40">
<div class="con-title">
<h3>今日推荐</h3>
</div>
<div class="sticky mb40">
<?php 
$sticky = get_option('sticky_posts');
$args = array(
'posts_per_page' => 1,
'post__in' => $sticky,
'post__not_in' => array( $post->ID ),
'ignore_sticky_posts' => 1  ,
);
query_posts($args);
?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<h2 class="mb20"><a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
<p><?php the_excerpt();?></p>
<?php endwhile;endif;wp_reset_query(); ?>
</div>
<ul class="new-list">
<div class="row">
<?php 
global $post;
$cats = wp_get_post_categories($post->ID);
    $args = array(
		  'category__in' => array( $cats[0] ),
		  'post__not_in' => array( $post->ID ),
		  'showposts' => 10,
		  'caller_get_posts' => 1
	  );
  query_posts($args);
?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<li class="col-md-6 col-sm-6 col-xs-6"><a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title(); ?>"><?php the_title(); ?></a>
</li>
<?php endwhile;endif;wp_reset_query(); ?>
</div>
</ul>
</div>
<nav id="nav-single" class="clearfix">
<div class="nav-previous"><?php if (get_previous_post()) { previous_post_link('上一篇: %link');} else {echo "没有了，已经是最后文章";} ?></div>
<div class="nav-next"><?php if (get_next_post()) { next_post_link('下一篇: %link');} else {echo "没有了，已经是最新文章";} ?></div>
</nav>
</div>
</div>
<div class="col-md-3 col-sm-3 hidden-xs wow fadeInRight delay300">
<div class="sidebar">
<?php get_sidebar();?>
</div>
</div>
</div>
</div>
</section>
<?php get_footer(); ?>