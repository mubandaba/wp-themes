<div class="content">
<div class="con-top mb60">
<div class="con-title">
<h3>今日推荐</h3>
</div>
<div class="sticky mb40">
<?php 
$sticky = get_option('sticky_posts');
$args = array(
'posts_per_page' => 1,
'post__in' => $sticky,
'ignore_sticky_posts' => 1  ,
);
query_posts($args);
?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<h2 class="mb20"><a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
<p><?php the_excerpt();?></p>
<?php endwhile;endif;wp_reset_query(); ?>
</div>

<ul class="new-list">
<?php 
$args = array(
'posts_per_page' => 5,
'ignore_sticky_posts' => 1  ,
'orderby' => date,
);
query_posts($args);
?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<li><a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title(); ?>"><?php the_title(); ?></a>
</li>
<?php endwhile;endif;wp_reset_query(); ?>
</ul>
</div>
<div class="con-btm">
<div class="row">
<?php 
$ncat = get_field('news-cat','option');
if( $ncat ): ?><?php foreach( $ncat as $term ):?>
<div class="col-md-6 col-sm-6 col-xs-12">
<div class="news-box mb10">
<div class="con-title">
<h3><a href="<?php echo get_term_link( $term ); ?>" title="<?php echo $term->name; ?>"><?php echo $term->name; ?></a></h3>
<a class="more" href="<?php echo get_term_link( $term ); ?>">更多</a>
</div>

<ul class="new-list mb50">
<?php 
$newsnum = get_field('news-num');
$args = array(
'posts_per_page' => $newsnum,      // 显示多少条
'orderby' => 'date',         // 时间排序
'order' => 'desc',           // 降序（递减，由大到小）    
'ignore_sticky_posts' => 1,
'category__in' => $term->term_id,
);
query_posts($args); while (have_posts()) : the_post();?>
<li><a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title(); ?>"><?php the_title(); ?></a>
</li>
<?php endwhile;wp_reset_query(); ?>
</ul>
</div>
</div>
<?php endforeach; ?>
<?php endif; ?>
</div>
</div>
</div>