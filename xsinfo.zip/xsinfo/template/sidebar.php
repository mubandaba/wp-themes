<div class="sidebar">
<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
<?php dynamic_sidebar( 'sidebar-1' ); ?>
<?php else: ?>	 
<?php endif; ?>
</div>