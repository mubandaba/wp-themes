<?php get_header(); ?>
<section id="main" class="p40">
<div class="container">
<div class="col-md-9 col-sm-8 col-xs-12">
<?php get_template_part( 'template/content' ); ?>
</div>
<div class="col-md-3 col-sm-4 hidden-xs">
<?php get_template_part( 'template/sidebar' ); ?>
</div>
</div>
</section>
<?php get_footer();?>