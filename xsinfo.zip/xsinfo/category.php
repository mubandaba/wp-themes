<?php get_header(); ?>
<h1 style="text-indent:-99999px;height:0;overflow:hidden;"><?php $page_id = get_queried_object();  the_field('keywords',$page_id); ?></h1>
<section id="main" class="p40">
<div class="container">
<div class="row">
<div class="col-md-9 col-sm-9 col-xs-12 wow fadeInLeft delay300">
<div class="content">
<div class="con-title mb40">
<h3>分类：<?php single_cat_title(); ?></h3>
</div>
<ul class="content-list">
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<li>
<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
<div class="single-meta">
<span class="time"><?php _e('时间','xs')?>：<?php the_time('Y-n-j'); ?></span>
<span class="author pull-right"><?php _e('作者','xs')?>：<?php the_author(); ?></span>
</div>
<p><?php the_excerpt();?></p>
<div class="post-tags mt20"><?php the_tags()?></div>
</li>
<?php endwhile; endif;?>
</ul>
<?php the_posts_pagination( array( 'prev_text' => __( '上一页', 'xs' ), 'next_text' => __( '下一页', 'xs' ) ) );?>
</div>

</div>
<div class="col-md-3 col-sm-3 hidden-xs wow fadeInRight delay300">
<div class="sidebar">
<?php get_sidebar();?>
</div>
</div>
</div>
</div>
</div>
</section>
<?php get_footer(); ?>