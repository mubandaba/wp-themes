<?php
require get_template_directory() . '/inc/hooks/posts.php';
require get_template_directory() . '/inc/hooks/tgm.php';
require get_template_directory() . '/inc/hooks/breadcrumb.php';
require get_template_directory() . '/inc/hooks/pagination.php';
require get_template_directory() . '/inc/hooks/inner-header.php';



