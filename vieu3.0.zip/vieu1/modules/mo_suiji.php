<?php if ($paged <= 1) {
    echo '<div class="focusmo"><ul> ';
    for ($i = 1;$i <= 5;$i++) {
        $args = array('numberposts' => 1, 'orderby' => 'rand', 'post_status' => 'publish');
        $rand_posts = get_posts($args);
        foreach ($rand_posts as $post):
            if ($i == 1) {
                echo '<li class="large">';
            } else {
                echo '<li>';
            }
            echo '<a href="' . get_permalink() . '">' . _get_post_thumbnail() . '<h4>' . get_the_title() . '</h4></a>';
            echo '</li> ';
        endforeach;
    }
    echo '</ul>
 </div>  ';
}
?>