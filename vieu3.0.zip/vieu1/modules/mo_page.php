<div class="comment-posts">
  <?php echo'<div class="mo-suiji">
           <h3>'._hui('index_suiji_h3').'</h3>
              <ul>';
                    $a=1;$x=1;
				           $args = array('numberposts' => _hui('index_suiji_item') , 'orderby' => 'rand', 'post_status' => 'publish');
                            $rand_posts = get_posts($args);
                            foreach ($rand_posts as $post): 
							
							echo'<li class="item-'.$x++.'"><span class="label label-'.$a++.'">'._hui('index_suiji_text').'</span><span class="date">['.get_the_time('m-d').']</span>
                     <a href="'.get_permalink().'">';echo get_the_title();echo'</a></li>';
     					  endforeach; 
			echo'</ul>
			</div>';?>
	<?php echo'<div class="mo-hots">	
              <h3>'._hui('index_rem_h3').'</h3>	
			<ul>';
          if(function_exists('most_comm_posts')) most_comm_posts( _hui('index_rem_date'), _hui('index_rem_item')); 
     echo'</ul>
             </div>'; ?>
			</div>