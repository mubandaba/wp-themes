<ul class="countdown">
  
  
  <li> <span id="vi-hour" class="hours">00</span>
    <p class="hours_ref">hours</p>
  </li>
  <li class="seperator">:</li>
  <li> <span id="vi-minute" class="minutes">00</span>
    <p class="minutes_ref">minutes</p>
  </li>
  <li class="seperator">:</li>
  <li> <span id="vi-second" class="seconds">00</span>
    <p class="seconds_ref">seconds</p>
  </li>
  </ul>