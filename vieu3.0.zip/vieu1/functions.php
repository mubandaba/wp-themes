<?php
// Require theme functions
require get_stylesheet_directory() . '/functions-theme.php';

//vieugonnengjiazai
require get_stylesheet_directory() . '/fn-theme.php';
require get_template_directory() . '/action/avatars.php';