		<div id="sidebar">
<div class="widget">
	<h3>欢迎光临 <span class="title">Welcome To My Blog!</span></h3>
<div class="siderbar-ad">
				<a href="http://3zi.me/wordpress-theme-newgavin2-3.html">
				<img src="<?php bloginfo('stylesheet_directory'); ?>/screenshot.png" title="newgavin2.3下载" alt="newgavin2.3" width="250px" height="213px">
				</a>
				
					</div>
					<div class="clr"></div> 
<p>
免責：<br>
本站文章內容為原創,主題美化為網絡傳播
如有侵權請通知修改,將不負任何法律責任
</p>
</div><div class="clr"></div>
<div class="widget">
	<?php include('includes/r_tab.php'); ?>
</div><div class="clr"></div> 
<div class="widget">
	<?php include('includes/r_link.php'); ?>
</div><div class="clr"></div> 
			  <div class="widget">
		<h3>博客统计</h3>
<?php include('includes/r_statistics.php'); ?>  
          
</div> <div class="clr"></div> 
<div class="widget" id="float">
				<h3>与我相关</h3>
				<ul class="contact">
					
					<li><a href="http://weibo.com/ah3zi" target="_blank">新浪微博</a>|<a href="http://t.qq.com/wcglove" target="_blank">腾讯微博</a>|<a href="http://3zi.me/feed" target="_blank">RSS 订阅</a></li>
					<li><a href="<?php echo get_settings('Home'); ?>/link" target="_blank">申请友链</a></li>
					<li><?php if (get_option('swt_sm') == 'Display') { ?><a href="<?php echo stripslashes(get_option('swt_sitemap')); ?>">网站地图</a><?php { echo ''; } ?><?php } else { } ?><?php if (get_option('swt_tj') == 'Display') { ?>|<?php echo stripslashes(get_option('swt_tjcode')); ?><?php { echo ''; } ?><?php } else { } ?> </li>
					
					
				</ul> 
         	</div>
			<div class="widget" id="float">
				<h3>主机推荐</h3>
				<ul class="contact">
					
					<li>PHP主机推荐：<a href="http://zhuji.gd/" target="_blank">格调主机</a></li>
					<li>小提示：<br/>本博客在<a href="http://www.google.com/chrome " target="_blank">谷歌浏览器</a>上能显示最佳效果！</li>
				</ul> 
         	</div>

			
			
			

          <div class="clr"></div> 



		</div>

