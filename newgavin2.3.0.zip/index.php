<?php get_header(); ?>
	<div id="content">
        <div class="post-content">
				<?php include('includes/format.php'); ?>
				
		<div id="postnavigation">   
   			<div class="page_navi"> <?php par_pagenavi(5); ?> </div>  
        </div>
		</div>
<?php get_sidebar(); ?>

<?php get_footer(); ?>