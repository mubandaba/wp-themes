<h3>友情链接</h3>
<div class="r_link">
<?php wp_list_bookmarks('orderby=id&categorize=0&show_images=0&title_li='); ?>


</div><div class="clr"></div>