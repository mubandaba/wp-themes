var panel_title = $('.panel-title');
var pannel_array_html = new Array();
var pannel_array_text = new Array();
var li_dom = new Array();
var i = 0;
while(i < panel_title.size()){
    li_dom[0]='<ul class="nav-tags mCustomScrollbar">';
    pannel_array_html[i]=$.trim(panel_title[i].innerHTML);
    pannel_array_text[i]=$.trim(panel_title[i].innerText);
    li_dom[i+1]='<li><a href="#'+pannel_array_text[i]+'">'+ pannel_array_html[i] +'</li>';
    li_dom[panel_title.size()+1]='</ul>';
    i++
}
ul_dom=li_dom.join('');
$(ul_dom).insertAfter('.active');
console.log(ul_dom);