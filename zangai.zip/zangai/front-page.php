﻿<?php get_header();?>
    <!-- index -->

    <div class="main-wrap">
        <div class="main">



            <?php
            $site_query = new WP_Query(array(
                'post_type'     =>  'site',
                'p'     =>  joy('select_site_index'),
            ));
            if($site_query->have_posts()):  while($site_query->have_posts()):$site_query->the_post();
                $meta_data = get_post_meta(get_the_ID(), 'site_options', true);
                $add_link = $meta_data['add_link'];
                ?>
                <div class="board selected-nav">

                    <div class="nav-left">
                        <?php $icon = $meta_data['icon'];
                        joy_if_empty($icon,"<i class=\"","\"></i>");
                        ?>
                        <span class="selected-nav-cn"><?php the_title()?></span>
                    </div>

                    <div class="navigator">
                        <a href="#" class="up">
                            <i class="czs-arrow-up-l"></i>
                        </a>
                        <a href="#" class="down">
                            <i class="czs-arrow-down-l"></i>
                        </a>
                    </div>
                    <div class="selected-nav-link-wrapper">

                        <?php if(joy('add_notice')): foreach(joy('add_notice') as $notice):?>
                            <div class="selected-nav-link-item">
                                <span class="selected-nav-description">
                                    <?php echo $notice['notice_content'];?>
                                </span>
                                    <span class="selected-nav-linkname">
                                    <a target="_blank" href="<?php echo $notice['notice_link'];?>">了解详情</a>
                                </span>
                            </div>
                        <?php endforeach;endif;?>
                    </div>

                </div>
                <div class="panel">

                    <div class="panel-body">
                        <div class="row">
                            <?php if($add_link): foreach ($add_link as $link) :?>
                                <div class="sm-6 md-4 lg-3">
                                    <div class="card">
                                        <a class="card-heading link-tooltip" title="<?php echo $link['link']?>" href="<?php joy_go($link['link']);?>" target="_blank">
                                <span class="card-icon">
                                    <img src="<?php joy_meta_img($link['logo'])?>">
                                </span>
                                            <span class="card-title">
                                    <?php echo $link['name']?>
                                </span>
                                        </a>
                                        <div class="card-body">
                                            <?php echo $link['desc']?>
                                        </div>
                                        <div class="card-footer">
                                            <table>
                                                <tr>
                                                    <td class="btn-view" >

                                                    </td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach;endif;?>
                        </div>
                    </div>
                </div>

            <?php endwhile; endif?>


            <?php if(joy('ad_switcher')):?>
                <div class="footer-at row">
                    <?php if(joy('add_ad')): foreach (joy('add_ad') as $ad):?>
                        <div class="xs-12 sm-12 md-6" style="margin-bottom: 10px;">

                            <a target="_blank" href="<?php $ad['ad_link']?>" title="<?php $ad['ad_title']?>">
                                <img src="<?php joy_meta_img($ad['ad_link'])?>" alt="<?php $ad['ad_title']?>">
                            </a>

                        </div>
                    <?php endforeach;endif?>

                </div>
            <?php endif;?>


        </div>
    </div>

<?php get_footer();?>