


<footer class="footer">

    <div class="footer-top-border"></div>
    <?php the_time('Y'); bloginfo('name');joy_icp();
    if(joy('friend_options')):
        ?>
        <span class="footer-link">
                    <?php foreach (joy('friend_options') as $fl):?>
                        <a href="<?php $fl['friend_link']?>"><?php $fl['friend_title']?></a>
                    <?php endforeach;?>
         </span>
    <?php endif?>
</footer>

<?php wp_footer()?>
</body>
</html>