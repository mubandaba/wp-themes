<?php

# 常量定义[Constants]
# ------------------------------------------------------------------------------
define( 'JOY_THEME_NAME'      , '葬爱导航'                                                  );
define( 'JOY_THEME_AUTHOR'    , '魏星'                                                    );
define( 'JOY_THEME_VERSION'   , '1.0.0.0'                                                 );
define( 'JOY_SRC_PATH'        , get_template_directory_uri()."/static/"                   );
define( 'JOY_CSS_PATH'        , get_template_directory_uri()."/static/css/"               );
define( 'JOY_JS_PATH'         , get_template_directory_uri()."/static/js/"                );
define( 'JOY_DEFAULT_IMG_PATH', get_template_directory_uri()."/static/images/"            );
define( 'JOY_FUNCTIONS_PATH'  , get_template_directory_uri()."/inc/wordpress/"            );


# 引用cs框架 [Include the cs framework ]
# ------------------------------------------------------------------------------
require_once( dirname( __FILE__ ) . '/inc/setting/cs-framework.php'              );


# 引用JS/CSS [enqueue]
# ------------------------------------------------------------------------------
require_once( dirname( __FILE__ ) . '/inc/enqueue/enqueue-css.php'               );
require_once( dirname( __FILE__ ) . '/inc/enqueue/enqueue-js.php'                );
require_once( dirname( __FILE__ ) . '/inc/enqueue/enqueue-other.php'             );


# WORDPRESS设置和自定义 [WordPress Settings and Customizations]
# ------------------------------------------------------------------------------
require_once( dirname( __FILE__ ) .'/inc/function/wp-branding.php'              );
require_once( dirname( __FILE__ ) .'/inc/function/wp-regMenu.php'               );
require_once( dirname( __FILE__ ) .'/inc/function/wp-regPostType.php'           );
require_once( dirname( __FILE__ ) .'/inc/function/wp-remove.php'                );
require_once( dirname( __FILE__ ) .'/inc/function/wp-seo.php'                   );
require_once( dirname( __FILE__ ) .'/inc/function/wp-joy.php'                   );
require_once( dirname( __FILE__ ) .'/inc/updater/theme-updater.php'             );


# 去除wordpress前台顶部工具条
# ------------------------------------------------------------------------------
show_admin_bar(false);





