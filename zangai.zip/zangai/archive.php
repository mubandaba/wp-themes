<?php get_header();?>
<?php
$queried_object = get_queried_object();
$term_id = $queried_object->term_id;
$term_meta = get_term_meta( $term_id, 'sites_options', true );
?>

    <!-- index -->

    <div class="main-wrap">
        <div class="main">



            <div class="board selected-nav">
                <div class="nav-left">
                    <i class="<?php echo $term_meta['icon'];?>"></i>
                    <span class="selected-nav-cn"><?php echo $queried_object->name; ?></span>
                    <span class="selected-nav-en"><?php echo $queried_object->slug; ?></span>
                </div>
                <div class="navigator">
                    <a href="#" class="up">
                        <i class="czs-arrow-up-l"></i>
                    </a>
                    <a href="#" class="down">
                        <i class="czs-arrow-down-l"></i>
                    </a>
                </div>
                <div class="selected-nav-link-wrapper">
                <?php
                if($term_meta):
                $add_notice=$term_meta['add_notice'];
                if(is_array($add_notice)): foreach($add_notice as $notice):?>
                    <div class="selected-nav-link-item">
                        <span class="selected-nav-description">
                            <?php echo $notice['notice_content'];?>
                        </span>
                        <span class="selected-nav-linkname">
                            <a target="_blank" href="<?php echo $notice['notice_link'];?>">
                                了解详情
                            </a>
                        </span>
                    </div>
                    <?php endforeach;endif;endif?>
                </div>

            </div>

            <?php
            if(have_posts()):  while(have_posts()):the_post();
                $meta_data = get_post_meta(get_the_ID(), 'site_options', true);
                $add_link = $meta_data['add_link'];
                ?>

                <a id="<?php the_title()?>" class="relink"></a>
                <div class="panel">


                    <div class="panel-title card"><?php $icon = $meta_data['icon'];
                        joy_if_empty($icon,"<i class=\"","\"></i>")
                        ?><?php the_title()?></div>


                    <div class="panel-body">
                        <div class="row">
                            <?php if(is_array($add_link)): foreach ($add_link as $link) :?>
                                <div class="sm-6 md-4 lg-3">
                                    <div class="card">
                                        <a class="card-heading link-tooltip" title="<?php echo $link['link']?>" href="<?php joy_go($link['link']);?>" target="_blank">
                                <span class="card-icon">
                                    <img src="<?php joy_meta_img($link['logo'])?>">
                                </span>
                                            <span class="card-title">
                                    <?php echo $link['name']?>
                                </span>
                                        </a>
                                        <div class="card-body">
                                            <?php echo $link['desc']?>
                                        </div>
                                        <div class="card-footer">
                                            <table>
                                                <tr>
                                                    <td class="btn-view" >

                                                    </td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach;endif?>
                        </div>
                    </div>
                </div>

            <?php endwhile; endif?>


            <?php if(joy('ad_switcher')):?>
                <div class="footer-at row">
                    <?php if(joy('add_ad')) :foreach (joy('add_ad') as $ad):?>
                        <div class="xs-12 sm-12 md-6" style="margin-bottom: 10px;">

                            <a target="_blank" href="<?php $ad['ad_link']?>" title="<?php $ad['ad_title']?>">
                                <img src="<?php joy_meta_img($ad['ad_link'])?>" alt="<?php $ad['ad_title']?>">
                            </a>

                        </div>
                    <?php endforeach;endif;?>

                </div>
            <?php endif;?>


        </div>
    </div>

<?php get_footer();?>