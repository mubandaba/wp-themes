<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta http-equiv="X-UA-COMPATIBLE" content="IE=edge">
    <?php wp_head();?>
</head>
<body>

<header class="mobile-header-wrap">

    <a class="mobile-logo" href="/">
        <img src="<?php joy_img("m_logo")?>">
    </a>
</header>
<div class="btn-mobile-sidenav">
    <div class="nav-bar">
        <span></span>
        <span></span>
        <span></span>
    </div>
</div>
<!-- sidenav -->
<div class="sidenav">
    <a class="logo" href="/">
        <img src="<?php joy_img("logo")?>" alt="<?php bloginfo("name")?>">
    </a>
    <div class="site-description">
        <?php bloginfo("description")?>
    </div>
    <?php wp_menu('main_menu');?>

    <!-- tool -->

    <a class="copyright" href="<?php bloginfo("url")?>">&#169; <?php bloginfo("name")?></a>
</div>