<?php get_header();if( have_posts() ) : while( have_posts() ) : the_post();?>
<div class="main-wrap">

    <div class="main">

        <div class="board selected-nav">

            <i class="czs-chuangzaoshi"></i>

            <span class="selected-nav-cn"><?php the_title();?></span>

            <span class="selected-nav-en"></span>

            <span style="font-size:12px;color:#bbb;margin-top:4px;float:right;">
                为创意工作者而设计
            </span>
        </div>

        <div class="page">
            <?php the_content();?>
        </div>




<?php endwhile;endif;get_footer();?>