<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// TAXONOMY OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options     = array();


$options[]   = array(
    'id'       => 'sites_options',
    'taxonomy' => 'site_category',
    'fields'   => array(

        array(
            'id'    => 'icon', // this is must be unique
            'type'  => 'text',
            'title' => '图标',
        ),

        array(
            'id'              => 'add_notice',
            'type'            => 'group',
            'title'           => '添加公告',
            'button_title'    => '添加',
            'accordion_title' => '添加公告',
            'fields'          => array(

                array(
                    'id'      => 'notice_content',
                    'type'    => 'text',
                    'title'   => '公告内容',
                ),
                array(
                    'id'      => 'notice_link',
                    'type'    => 'text',
                    'title'   => '公告链接',
                    'desc'    => '需要带上http://(或者https://)',
                ),

            )
        ),



        array(
            'id'    => 'seo_switcher', // this is must be unique
            'type'  => 'switcher',
            'title' => '是否启用自定义SEO',
        ),
        array(
            'id'    => 'seo_custom_title', // this is must be unique
            'type'  => 'text',
            'title' => '自定义标题',
            'dependency' => array('seo_switcher', '==', true),
            'help'  => '留空则调用默认全局SEO设置'

        ),
        array(
            'id'    => 'seo_custom_keywords', // this is must be unique
            'type'  => 'textarea',
            'title' => '自定义关键词',
            'dependency' => array('seo_switcher', '==', true),

            'help'  => '留空则调用默认全局SEO设置'

        ),
        array(
            'id'    => 'seo_custom_desc', // this is must be unique
            'type'  => 'textarea',
            'title' => '自定义描述',
            'dependency' => array('seo_switcher', '==', true),

            'help'  => '留空则调用默认全局SEO设置'
        ),






    ),
);



// -----------------------------------------
// Taxonomy Options                        -
// -----------------------------------------

CSFramework_Taxonomy::instance( $options );
