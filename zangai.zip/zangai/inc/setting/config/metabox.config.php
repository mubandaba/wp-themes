<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// METABOX OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options[]    = array(
    'id'        => 'site_options',
    'title'     => '详细信息',
    'post_type' => 'site',
    'context'   => 'normal',
    'priority'  => 'high',
    'sections'  => array(
        array(
            'name'   => 'site_options_1',
            'fields' => array(
                array(
                    'id'      => 'icon',
                    'type'    => 'text',
                    'title'   => '对应图标',
                ),
                array(
                    'id'              => 'add_link',
                    'type'            => 'group',
                    'title'           => '添加网站',
                    'button_title'    => '添加',
                    'accordion_title' => '添加网站',
                    'fields'          => array(
                        array(
                            'id'      => 'name',
                            'type'    => 'text',
                            'title'   => '网站名称',
                        ),
                        array(
                            'id'      => 'logo',
                            'type'    => 'image',
                            'title'   => '网站LOGO',
                        ),
                        array(
                            'id'      => 'link',
                            'type'    => 'text',
                            'title'   => '网站链接',
                            'desc'    => '需要带上http://<br>(或者https://)',
                        ),
                        array(
                            'id'      => 'desc',
                            'type'    => 'text',
                            'title'   => '网站简介',
                        ),


                    )
                ),
            ),
        ),
    ),
);



CSFramework_Metabox::instance( $options );
