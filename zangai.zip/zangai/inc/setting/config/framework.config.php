<?php if (!defined('ABSPATH')) {
    die;
} // 不能直接访问网页.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// 主题框架设置
// -----------------------------------------------------------------------------------------------
// ===============================================================================================

$settings = array(
    'menu_title' => '主题设置',
    'menu_type' => 'menu',
    'menu_slug' => 'joytheme' . '-' . wp_get_theme()->display('Name'),
    'menu_position' => 10000,
    'ajax_save' => true,
    'show_reset_all' => false,
    'menu_icon' => 'dashicons-hammer',
    'framework_title' => wp_get_theme()->display('Name') . '<small class="oldVer" data-vs="' . JOY_THEME_VERSION . '" style="color:#979797;margin-left:10px">Release ' . JOY_THEME_VERSION . '</small>',
);

// ---------------------------------------
// 常规  --------------------------------
// ---------------------------------------
$options[] = array(
    'name' => 'overwiew',
    'title' => '常规设置',
    'icon' => 'fa fa-list',
    'fields' => array(

        array(
            'id' => 'logo',
            'type' => 'image',
            'title' => '上传 Logo',
            'help' => '上传您的站点logo <br>（推荐尺寸为:150*150 px）',
            'add_title' => '上传',
        ),

        array(
            'id' => 'm_logo',
            'type' => 'image',
            'title' => '上传移动端Logo',
            'help' => '上传您的站点logo <br>（推荐尺寸为:150*150 px）',
            'add_title' => '上传',
        ),
        array(
            'id' => 'favicon',
            'type' => 'image',
            'title' => '上传 Favicon',
            'help' => '上传您的站点logo <br>（尺寸为：60*60 px）',
            'add_title' => '上传',
        ),
//        array(
//            'id' => 'cp_switcher',
//            'type' => 'switcher',
//            'title' => '是否隐藏主题作者版权',
//        ),
        array(
            'id'    => 'icp_num',
            'type'  => 'text',
            'title' => '备案号',
        ),


),
);



// ----------------------------------------
// 首页设置--------------------------------
// ----------------------------------------
$options[] = array(
    'name'        => 'index_links',
    'title'       => '首页设置',
    'icon'        => 'fa fa-external-link-square',
    'fields'      => array(
        array(
            'id'             => 'select_site_index',
            'type'           => 'select',
            'title'          => '首页展示的站点集',
            'options'        => 'posts',
            'query_args'     => array(
                'post_type'    => 'site',
                'orderby'      => 'post_date',
                'order'        => 'DESC',
            ),
            'default_option' => '选择站点集',
        ),
        array(
            'id'              => 'add_notice',
            'type'            => 'group',
            'title'           => '添加公告（仅首页）',
            'button_title'    => '添加',
            'accordion_title' => '添加公告',
            'fields'          => array(

                array(
                    'id'      => 'notice_content',
                    'type'    => 'text',
                    'title'   => '公告内容',
                ),
                array(
                    'id'      => 'notice_link',
                    'type'    => 'text',
                    'title'   => '公告链接',
                    'desc'    => '需要带上http://(或者https://)',
                ),

            )
        ),


    ),
);
// ----------------------------------------
// 友情链接--------------------------------
// ----------------------------------------
$options[] = array(
    'name'        => 'friend_links',
    'title'       => '友情链接',
    'icon'        => 'fa fa-external-link-square',
    'fields'      => array(

        array(
            'id'              => 'friend_options',
            'type'            => 'group',
            'title'           => '添加友情链接',
            'button_title'    => '添加',
            'accordion_title' => '添加友情链接',
            'fields'          => array(
                array(
                    'id'      => 'friend_title',
                    'type'    => 'text',
                    'title'   => '友链名称',
                ),
                array(
                    'id'      => 'friend_link',
                    'type'    => 'text',
                    'title'   => '跳转链接',
                    'desc'    => '需要带上http://(或者https://)',
                ),
            )
        ),
    ),
);
// ----------------------------------------
// 广告--------------------------------
// ----------------------------------------
$options[] = array(
    'name' => 'ad',
    'title' => '广告',
    'icon' => 'fa fa-black-tie',
    'fields' => array(
        array(
            'type' => 'switcher',
            'content' => '广告开关',
            'id'    => 'ad_switcher',

        ),
        array(
            'id'              => 'add_ad',
            'type'            => 'group',
            'title'           => '添加广告',
            'button_title'    => '添加',
            'accordion_title' => '添加广告',
            'dependency' => array('ad_switcher', '==', true),
            'fields'          => array(
                array(
                    'id'      => 'ad_title',
                    'type'    => 'text',
                    'title'   => '友链名称',
                ),
                array(
                    'id'      => 'ad_link',
                    'type'    => 'text',
                    'title'   => '跳转链接',
                    'desc'    => '需要带上http://(或者https://)',
                ),
                array(
                    'id'      => 'img',
                    'type'    => 'image',
                    'title'   => '广告图片',
                    'desc'    => '推荐尺寸为（）',
                ),
            )
        ),



    ),
);
// ----------------------------------------
// 社交媒体--------------------------------
// ----------------------------------------
//$options[] = array(
//    'name' => 'follow',
//    'title' => '社交媒体',
//    'icon' => 'fa fa-wechat',
//    'fields' => array(
//        array(
//            'type' => 'notice',
//            'content' => '社交媒体设置',
//            'class' => 'info',
//        ),
//        array(
//            'id' => 'mail',
//            'type' => 'text',
//            'title' => '邮箱',
//        ),
//        array(
//            'id' => 'facebook',
//            'type' => 'text',
//            'title' => 'facebook',
//        ),
//        array(
//            'id' => 'QQ',
//            'type' => 'text',
//            'title' => 'QQ',
//        ),
//        array(
//            'id' => 'weibo',
//            'type' => 'text',
//            'title' => '微博',
//        ),
//        array(
//            'id' => 'twitter',
//            'type' => 'text',
//            'title' => 'twitter',
//        ),
//    ),
//);
// ----------------------------------------
// SEO-------------------------------------
// ----------------------------------------
$options[] = array(
    'name' => 'speed',
    'title' => 'SEO设置',
    'icon' => 'fa fa-server',
    'fields' => array(
        array(
            'type' => 'notice',
            'class' => 'info',
            'content' => 'SEO',
        ),
        array(
            'id' => 'site_seo_switch',
            'type' => 'switcher',
            'title' => '主题自带SEO',
            'help' => '开启后将使用主题自带SEO设置',
            'default' => true
        ),

        array(
            'type' => 'notice',
            'class' => 'info',
            'content' => '全局SEO功能设定',
        ),
        array(
            'id' => 'seo_auto_des',
            'type' => 'switcher',
            'title' => '文章页描述',
            'help' => '开启后将自动截取文章内容作为文章description标签',
            'default' => true
        ),

        array(
            'id' => 'seo_auto_des_num', // this is must be unique
            'type' => 'text',
            'title' => '自动截取字节数',
            'default' => '120',
            'dependency' => array('seo_auto_des', '==', true),
        ),

        array(
            'id' => 'seo_sep', // this is must be unique
            'type' => 'text',
            'title' => 'Title后缀分隔符',
            'default' => ' - ',
        ),

        array(
            'type' => 'notice',
            'class' => 'info',
            'content' => '首页SEO设置',
        ),
        array(
            'id' => 'seo_home_title', // this is must be unique
            'type' => 'text',
            'title' => '首页标题',
            'help' => '关键词使用英文逗号隔开',
        ),

        array(
            'id' => 'seo_home_keywords', // this is must be unique
            'type' => 'text',
            'title' => '首页关键词',
        ),

        array(
            'id' => 'seo_home_desc', // this is must be unique
            'type' => 'textarea',
            'title' => '首页描述',
        ),


    ),
);
// ----------------------------------------
// 自定义代码------------------------------
// ----------------------------------------
$options[] = array(
    'name' => 'code',
    'title' => '代码添加',
    'icon' => 'fa fa-code',
    'fields' => array(

        array(
            'class' => 'info',
            'type' => 'notice',
            'content' => '自定义代码',
        ),
        array(
            'id' => 'code_footer',
            'type' => 'textarea',
            'title' => 'footer自定义代码',
            'desc' => '显示在网站版权之前'
        ),
        array(
            'id' => 'code_css',
            'type' => 'textarea',
            'title' => '自定义样式css代码',
            'desc' => '不要添加< style &gt;标签',
        ),
    )
);
// ----------------------------------------
// 备份------------------------------------
// ----------------------------------------
$options[] = array(
    'name' => 'advanced',
    'title' => '备份',
    'icon' => 'fa fa-shield',
    'fields' => array(

        array(
            'type' => 'notice',
            'class' => 'danger',
            'content' => '您可以保存当前的选项，下载一个备份和导入.（此操作会清除网站数据，请谨慎操作）',
        ),

        // 备份
        array(
            'type' => 'backup',
        ),

    )
);

CSFramework::instance($settings, $options);


