<?php
//注册菜单
register_nav_menus(array(
    'main_menu' => '主菜单',
));


class description_walker extends Walker_Nav_Menu{
    function start_el(&$output="",$item="",$depth = 0, $args = Array(),$id = 0){
        global $wp_query;
        $indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';
        $class_names = '';
        $classes = empty( $item->classes ) ? array() : (array) $item->classes;
        if ( in_array( 'current-menu-item', $classes, true ) || in_array( 'current-menu-parent', $classes, true ) ) {
            $classes[] = 'active';
        }
        $classes[] = 'nav-item';
        $class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item ) );
        $class_names = ' class="'. esc_attr( $class_names ) . '"';
        $output.= $indent . '
<li ' . $class_names .'>';
        $icon = ! empty( $item->attr_title ) ? esc_attr( $item->attr_title ) : '';
        $attributes = ! empty( $item->target )        ? ' target="' . esc_attr( $item->target     ) .'"' : '';    //链接目标
        $attributes.= ! empty( $item->xfn )           ? ' rel="'    . esc_attr( $item->xfn        ) .'"' : '';    //链接关系网 也就是rel属性
        $attributes.= ! empty( $item->url )           ? ' href="'   . esc_attr( $item->url        ) .'"' : '';    //链接
        $description  = ! empty( $item->description ) ? '<span>'.esc_attr( $item->description ).'</span>' : '';   //图像描述
        //  if($depth != 0) $description = "";    //只在一级菜单输出图像描述，如果全部输出请注释本行
        $item_output = $args->before;
        $item_output.= '<a '. $attributes .'><i class="csz '. $icon .'"></i>';
        $item_output.= $args->link_before . apply_filters( 'the_title', $item->title, $item->ID ) . $description;
        $item_output.= '</a>';
        $item_output.= $args->after;
        $output.= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
    }
}


function wp_menu($location){
    if ( function_exists( 'wp_nav_menu' ) && has_nav_menu($location) ) {
        wp_nav_menu( array( 'container' => false, 'items_wrap' => '%3$s', 'theme_location' => $location,'walker' => new description_walker() , 'depth'=>1 ) );
    } else {
        echo '<li><a href="'.get_bloginfo('url').'/wp-admin/nav-menus.php">请到[后台->外观->菜单]中设置菜单。</a></li>';
    }

}

