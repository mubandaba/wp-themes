<?php


add_action('init','create_site');
add_action('init', 'create_site_tax');

add_action('admin_head-nav-menus.php', 'joy_add_metabox_menu_posttype_archive');

/**
 * 站点集
 */
function create_site(){
    $site_name=joy('site_name','站点集');
    $labels = array(
        'name' =>$site_name,
        'singular_name' =>$site_name,
        'add_new' => '添加'.$site_name,
        'add_new_item' => '撰写新'.$site_name,
        'edit_item' => '编辑'.$site_name,
        'new_item' => '添加'.$site_name,
        'view_item' => '查看'.$site_name,
        'search_items' => '搜索'.$site_name,
        'not_found' => '未找到'.$site_name,
        'not_found_in_trash' => '回收站中没有'.$site_name,
        'parent_item_colon' => '',
        'all_items' => '所有'.$site_name,
        'archives' => $site_name.'存档',
        'insert_into_item' => '插入至'.$site_name,
        'uploaded_to_this_item' => '上传到本'.$site_name.'的',
        'featured_image' =>$site_name.'图片',
        'set_featured_image' => '设为'.$site_name.'图像',
        'remove_featured_image' => '移除'.$site_name.'图片',
        'use_featured_image' => '作为'.$site_name.'图像',
        'filter_items_list' => '过滤列表',
        'items_list_navigation' => '列表导航',
        'items_list' =>$site_name. '列表',
        'menu_name' => $site_name,
        'name_admin_bar' =>$site_name,
    );

    $args = array(
        'labels'               => $labels,
        'description'          => '',
        'public'               => true,
        'hierarchical'         => true,
        'exclude_from_search'  => false,
        'publicly_queryable'   => true,
        'show_ui'              => true,
        'show_in_menu'         => true,
        'show_in_nav_menus'    => true,
        'show_in_admin_bar'    => true,
        'menu_position'        => true,
        'menu_icon'            => 'dashicons-screenoptions',
        'menu_position'        => 8,
        'capability_type'      => 'post',
        'capabilities'         => array(),
        'map_meta_cap'         => null,
        'supports'             => array( 'title'),
        'register_meta_box_cb' => null,
        'taxonomies'           => array(),
        'has_archive'          => true,
        'rewrite'              => false,
        'query_var'            => true,
        'can_export'           => true,
        'delete_with_user'     => null
    );

    register_post_type('site', $args);
}
function create_site_tax(){
    $site_name=joy('site_name','站点集');

    $labels = array(
        'name' => $site_name.'分类',
        'singular_name' => $site_name.'分类',
        'search_items' => '搜索'.$site_name.'分类',
        'popular_items' => '',
        'all_items' => '所有'.$site_name.'分类',
        'parent_item' => '父级'.$site_name.'分类',
        'parent_item_colon' => '父级'.$site_name.'分类：',
        'edit_item' => '编辑'.$site_name.'分类',
        'view_item' => '查看'.$site_name.'分类',
        'update_item' => '更新'.$site_name,
        'add_new_item' => '添加新'.$site_name.'分类',
        'new_item_name' => '新'.$site_name.'分类名',
        'separate_items_with_commas' => '',
        'add_or_remove_items' => '',
        'choose_from_most_used' => '',
        'not_found' => '未找到分类。',
        'no_terms' => '没有'.$site_name.'分类',
        'items_list_navigation' => '分类列表导航',
        'items_list' => '分类列表',
        'menu_name' => $site_name.'分类',
        'name_admin_bar' => 'category'
    );


    $args = array(
        'labels'                => $labels,
        'description'           => '',
        'public'                => true,
        'publicly_queryable'    => true,
        'hierarchical'          => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'show_in_nav_menus'     => true,
        'show_tagcloud'         => true,
        'show_in_quick_edit'    => true,
        'show_admin_column'     => true,
        'meta_box_cb'           => null,
        'capabilities'          => array(),
        'rewrite'               => true,
        'query_var'             => true,
        'update_count_callback' => '',
    );
    register_taxonomy('site_category', 'site', $args);
}

//添加到菜单
function joy_add_metabox_menu_posttype_archive() {
    add_meta_box('joy-metabox-nav-menu-posttype', '自定义类型', 'joy_metabox_menu_posttype_archive', 'nav-menus', 'side', 'default');
}
function joy_metabox_menu_posttype_archive() {
    $post_types = get_post_types(array('show_in_nav_menus' => true, 'has_archive' => true), 'object');

    if ($post_types) :
        $items = array();
        $loop_index = 999999;

        foreach ($post_types as $post_type) {
            $item = new stdClass();
            $loop_index++;

            $item->object_id = $loop_index;
            $item->db_id = 0;
            $item->object = 'post_type_' . $post_type->query_var;
            $item->menu_item_parent = 0;
            $item->type = 'custom';
            $item->title = $post_type->labels->name;
            $item->url = get_post_type_archive_link($post_type->query_var);
            $item->target = '';
            $item->attr_title = '';
            $item->classes = array();
            $item->xfn = '';

            $items[] = $item;
        }

        $walker = new Walker_Nav_Menu_Checklist(array());

        echo '<div id="posttype-archive" class="posttypediv">';
        echo '<div id="tabs-panel-posttype-archive" class="tabs-panel tabs-panel-active">';
        echo '<ul id="posttype-archive-checklist" class="categorychecklist form-no-clear">';
        echo walk_nav_menu_tree(array_map('wp_setup_nav_menu_item', $items), 0, (object) array('walker' => $walker));
        echo '</ul>';
        echo '</div>';
        echo '</div>';

        echo '<p class="button-controls">';
        echo '<span class="add-to-menu">';
        echo '<input type="submit"' . disabled(1, 0) . ' class="button-secondary submit-add-to-menu right" value="' . __('添加到菜单', 'andromedamedia') . '" name="add-posttype-archive-menu-item" id="submit-posttype-archive" />';
        echo '<span class="spinner"></span>';
        echo '</span>';
        echo '</p>';

    endif;
}
