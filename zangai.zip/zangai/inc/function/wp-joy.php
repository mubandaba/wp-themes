<?php


/**
 *
 * Get option
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
function get_joy_go($url){
    return  get_bloginfo('template_url').'/go?url=' .base64_encode($url);
}
function joy_go($url){
    echo get_joy_go($url);
}
function joy_icp(){
    $icp_num = joy('icp_num');
    if($icp_num){
        echo "<a href=\"http://www.miitbeian.gov.cn/\" style=\"color:#bbb;text-decoration: none;\">".$icp_num."</a>";
    }
}
if ( ! function_exists( 'joy' ) ) {
    function joy( $option_name = '', $default = '' ) {

        $options = apply_filters( 'joy', get_option( CS_OPTION ), $option_name, $default );

        if( ! empty( $option_name ) && ! empty( $options[$option_name] ) ) {
            return $options[$option_name];
        } else {
            return ( ! empty( $default ) ) ? $default : null;
        }

    }
}
/*获取框架image图片地址*/


function joy_img($id){
   echo get_joy_img ($id);
}
function joy_meta_img($id){
    echo get_joy_meta_img ($id);
}



function get_joy_img ($id){
    $cs_id= joy($id);
    if (!empty($cs_id )){
        $id_url= wp_get_attachment_image_src( $cs_id, 'full' );
        return $id_url[0];
    }

}
function get_joy_meta_img($meta_id){
    if (!empty($meta_id )){
        $id_url= wp_get_attachment_image_src( $meta_id, 'full' );
        return $id_url[0];
    }
}

function joy_if_empty($var_name,$before='',$after=''){

    if(!empty($var_name)){
        echo $before.$var_name.$after;
    }

}
function joy_thumb(){
    global $post;
    $thumbnail_default=joy_img("thumbnail_default");
    if( has_post_thumbnail() ){    //如果有特色缩略图，则输出缩略图地址
        $thumbnail_src = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
        $post_thumbnail_src = $thumbnail_src [0];
    } elseif($thumbnail_default) {
        $post_thumbnail_src = $thumbnail_default;
    }
   // else{
   //    $num=mt_rand(1, 7);
   //    $name=$num.".jpeg";
   //    $post_thumbnail_src = JOY_DEFAULT_IMG_PATH.$name;
   // }
    echo $post_thumbnail_src;
}
//文章所属分类名称
function joy_cat_nicename(){
    $category = get_the_category();
    $length =count($category);
    for($i=0;$i<$length;$i++){
        echo " ".$category[$i]->category_nicename;
    }}

function joy_cat_name(){
    $category = get_the_category();
    $length =count($category);
    for($i=0;$i<$length;$i++){
        echo "<span class=\"line\">/</span>".$category[$i]->cat_name;
    }
}
function custom_taxonomies_terms_links(){
    //根据当前文章ID获取文章信息
    $post = get_post( $post->ID );

    //获取当前文章的文章类型
    $post_type = $post->post_type;

    //获取文章所在的自定义分类法
    $taxonomies = get_object_taxonomies( $post_type, 'objects' );

    $out = array();
    foreach ( $taxonomies as $taxonomy_slug => $taxonomy ){
        $term_list = wp_get_post_terms($post->ID, $taxonomy_slug, array("fields" => "all"));
        echo $term_list[0]->name; //显示文章所处的分类中的第一个
    }

    return implode('', $out );
}


function joy_add_js2admin() {
    global $wp_customize;
    if ( ! isset( $wp_customize ) ) {
        wp_enqueue_script( 'dashboard-js', get_template_directory_uri() . '/static/js/admin.js', array('jquery','jquery-ui-datepicker','jquery-ui-sortable','jquery-ui-sortable', 'jquery-ui-draggable','jquery-ui-droppable','admin-widgets' ) );
    }
}
add_action( 'admin_enqueue_scripts', 'joy_add_js2admin' );
