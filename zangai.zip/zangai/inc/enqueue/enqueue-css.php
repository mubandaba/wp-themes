<?php

# 加载CSS到<head>中  [Enqueue css]
function JOY_enqueue_styles()
{
    wp_enqueue_style('icon', JOY_CSS_PATH ."icon.css",   array(), JOY_THEME_VERSION, 'all');
    wp_enqueue_style('style', JOY_CSS_PATH ."style.css",   array(), JOY_THEME_VERSION, 'all');
}

# Add CSS to the theme
add_action('wp_enqueue_scripts', 'JOY_enqueue_styles', 3);


