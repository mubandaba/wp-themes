<?php
# 加载JavaScript到footer [Add JavaScript to footer]
function JOY_enqueue_scripts() {
    wp_deregister_script('jquery');
    wp_enqueue_script( 'jquery' ,  JOY_JS_PATH . "jquery.min.js",                    array() , false , true );
    wp_enqueue_script( 'jweixin' ,  JOY_JS_PATH . "jweixin.js",                    array() , false , false );
    wp_enqueue_script( 'main' ,  JOY_JS_PATH . "main.js",                    array() , false , true );
    wp_enqueue_script( 'addsubmenu' ,  JOY_JS_PATH . "addsubmenu.js",                    array() , false , true );
}
# Add JS to the theme
add_action( 'wp_enqueue_scripts' , 'JOY_enqueue_scripts' , 4);
