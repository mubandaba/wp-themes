<?php
/*
Template Name:所有关键词
*/

get_header(); ?>
<div class="pagebox mb15">
<div class="pagebox_hd"></div>
<div class="pagebox_bd">
<div class="place"><?php if (function_exists('wp_bac_breadcrumb')) {wp_bac_breadcrumb();}?></div>
</div>            
<div class="pagebox_ft"></div>
</div>

<div class="mainbox w960 clearfix">
<div class="article_info keywordinfo clearfix">
<div class="click_buy">
<div class="like_keyword">
<span>所有关键词：</span>
<?php
$querystr = "
SELECT $wpdb->posts.*
FROM $wpdb->posts, $wpdb->postmeta
WHERE $wpdb->posts.ID != ".$post->ID."
AND $wpdb->posts.ID = $wpdb->postmeta.post_id
AND $wpdb->postmeta.meta_key = 'haikuo_keyword'
AND $wpdb->postmeta.meta_value != ''
AND $wpdb->posts.post_status = 'publish'
AND $wpdb->posts.post_type = 'post'
AND $wpdb->posts.post_date < NOW()
ORDER BY $wpdb->posts.post_date DESC
";

$pageposts = $wpdb->get_results($querystr, OBJECT);
?>
<?php
if ($pageposts) {
    global $post;
    foreach ($pageposts as $post){
        setup_postdata($post);
            //main loop...
			echo '<a href="'.get_permalink().'">'.get_post_meta($post->ID,"haikuo_keyword",true).'</a>';
    }
} else {
   echo '没有相关文章';
}
wp_reset_query();
?>
</div>
<div class="page">
<?php pagenavi();?>
</div>
<!--<h5>宝贝详情：</h5>-->
<div class="article_body" style="padding-top:0;">
<?php the_content(); ?>
</div>

</div>
</div>
<br class="clear" />


</div>
<?php get_footer(); ?>