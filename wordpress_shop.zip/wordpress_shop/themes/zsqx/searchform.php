<form method="get" id="searchform" class="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>" role="search">
<input type="text" class="input_txt" name="s" value="请输入关键字" id="s" placeholder="请输入关键字" onfocus="if(this.value=='请输入关键字') this.value=''" onblur="if(this.value=='')this.value='请输入关键字'" />
<input type="submit" class="input_btn" id="searchsubmit" value="" />
</form>
