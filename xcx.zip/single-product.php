<?php get_header();?>
<div class="page-main">
      <div class="content-row">
        <div class="content-row-left">
          <div class="minapp-intro clearfix">
            <dl>
              <dt><img src="<?php echo get_post_meta($post->ID, "product_pic", true);?>"></dt>
              <dd>
                <h3 class="minapp-name"><?php the_title();?></h3>
                <p class="minapp-author">更新时间：<?php the_time('Y年n月j日')?>&nbsp;&nbsp;&nbsp;&nbsp;阅读量：<?php post_views(' ', ' '); ?></p>
                <ul class="clearfix minapp-tags"><?php echo posts_tags(10);?></ul>
              </dd>
            </dl>
          </div>
          <div class="minapp-detail-conts-info">
            <span class="emphasize-bar"></span>
            <span class="minapp-detail-conts-inner-intro-des"><?php the_title();?> 简介</span>
            <div class="minapp-detail-conts-sidebar-info-inner">
              <ul>
                <li><span>开发者</span><label><?php echo get_post_meta($post->ID, "product_zuozhe", true);?></label></li>              	
                <li><span>描述</span><label><?php echo get_post_meta($post->ID, "single_description", true);?></label></li>
                <?php $shuomi = get_post_meta($post->ID, "product_sm", true);if($shuomi){?>
                <li><span>说明</span><label><?php echo $shuomi;?></label></li>
                <?php }?>
              </ul>
            </div>
          </div>         
          <div class="minapp-detail-conts-info clearfix">
            <span class="emphasize-bar"></span>
            <span class="minapp-detail-conts-inner-intro-des"><?php the_title();?> 应用快照</span>
            <?php $pics = get_post_meta($post->ID, "product_img", true);?>
            <div class="minapp-detail-screenshots imgs-grid imgs-grid-5">
            <?php foreach($pics as $key => $pic){?>	
              <div class="imgs-grid-image">
                  <?php echo wp_get_attachment_link( $pic,array(auto,auto),false );?>
              </div>
            <?php }?>  
            </div>
          </div>
          <div class="minapp-detail-conts-info clearfix">
            <span class="emphasize-bar"></span>
            <span class="minapp-detail-conts-inner-intro-des">注意</span>
            <div class="minapp-detail-conts-sidebar-info-inner"><p class="minapp-copyright">本站所有小程序均为互联网采集或网友自行上传，仅供大家方便体验，本站不拥最终所属权且不含任何商业行为。<br></p></div>
          </div>  
        </div>
        <div class="content-row-right">
          <div class="minapp-qrcode-wrapper">
            <img src="<?php echo get_post_meta($post->ID, "product_ewm", true);?>">
            <p class="mod-use-tips">打开微信扫一扫</p></div>
          <div class="minapp-detail-conts-info related-minapps">
            <span class="emphasize-bar"></span>
            <span class="minapp-detail-conts-inner-intro-des">你可能还喜欢</span>
            <div class="minapp-detail-conts-sidebar-minapp-rows minapp-rows clearfix">
						<?php
						global $post, $wpdb;
						$cats = wp_get_post_categories($post->ID);
						if ($cats) {
						  $related = $wpdb->get_results("
						  SELECT post_title, ID
						  FROM {$wpdb->prefix}posts, {$wpdb->prefix}term_relationships, {$wpdb->prefix}term_taxonomy
						  WHERE {$wpdb->prefix}posts.ID = {$wpdb->prefix}term_relationships.object_id
						  AND {$wpdb->prefix}term_taxonomy.taxonomy = 'category'
						  AND {$wpdb->prefix}term_taxonomy.term_taxonomy_id = {$wpdb->prefix}term_relationships.term_taxonomy_id
						  AND {$wpdb->prefix}posts.post_status = 'publish'
						  AND {$wpdb->prefix}posts.post_type = 'product'
						  AND {$wpdb->prefix}term_taxonomy.term_id = '" . $cats[0] . "'
						  AND {$wpdb->prefix}posts.ID != '" . $post->ID . "'
						  ORDER BY RAND( )
						  LIMIT 5");
						
						  if ( $related ) {
							  foreach ($related as $related_post) {
						?>
			              <dl class="minapp-grid clearfix">
			                <dt>
			                  <a class="minapp-link" href="<?php echo get_permalink($related_post->ID); ?>"><img class="minapp-icon" src="<?php echo get_post_meta($related_post->ID, "product_pic", true);?>" width="100"></a>
			                </dt>
			                <dd>
			                  <h3 class="minapp-name">
			                    <a class="minapp-link" href="<?php echo get_permalink($related_post->ID); ?>"><?php echo $related_post->post_title; ?></a></h3>
			                  <p class="created-author"><i class="iconfont icon-user"></i><?php echo get_post_meta($related_post->ID, "product_zuozhe", true);?></p>
			                </dd>
			              </dl>			
						<?php
						    } 
						  }
						}
						?>
           	</div>
          </div>
        </div>
      </div>
</div>
</div>
<?php get_footer();?>