<?php
	/**
	 * COMMENTS TEMPLATE
	 */
	if('comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
		die('Please do not load this page directly.');
	if(post_password_required()){
		return;
	}
?>
<?php if(comments_open() != false): ?>
	<div id="comments">
	<div class="respond">
		<p class="commentp"><i class="iconfont icon-write"></i>添加新评论</p>
			<?php
				if( get_option('comment_registration') && !$user_ID ){
					echo '<p class="must-log-in">要发表评论，您必须先<a href="'.get_page_link(av('ucdenglu')).'">登录</a>。</p>';
				}elseif(comments_open()){
					$args = array(
						'id_form' => 'comment-form',
						'class_form' => 'ui-form',
						'id_submit' => 'submit',
						'class_submit' => 'submit btn',
						'title_reply' => '',
						'title_reply_to' => '<div class="notification"><i class="fa fa-comments-o"></i>' . esc_html__('Leave a Reply to', 'wpdie') . ' %s' . '</div>',
						'cancel_reply_link' => esc_html__('取消回复', 'wpdie'),
						'label_submit' => esc_html__('评论', 'wpdie'),
						'comment_notes_after' => '',
						'comment_notes_before' => '',
						'fields' => apply_filters( 'comment_form_default_fields', array(
							'author' =>'<div class="form-infos"><p><input class="text form-control" type="text" placeholder="' . esc_attr__('昵称', 'wpdie') . ' ' . ( $req ?  '(' . esc_attr__('必填', 'wpdie') . ')' : '') . '" name="author" id="author" value="' . esc_attr($comment_author) . '" size="22" tabindex="1" ' . ($req ? "aria-required='true'" : '' ). ' /></p>',
							'email' =>'<p><input class="text form-control" type="text" placeholder="' . esc_attr__('邮箱', 'wpdie') . ' ' . ( $req ? '(' . esc_attr__('必填', 'wpdie') . ')' : '') . '" name="email" id="email" value="' . esc_attr($comment_author_email) . '" size="22" tabindex="1" ' . ($req ? "aria-required='true'" : '' ). ' /></p>',
							'url' =>'<p class="url-control"><input class="text form-control" type="text" placeholder="' . esc_attr__('个人主页', 'wpdie') . '" name="url" id="url" value="' . esc_attr($comment_author_url) . '" size="22" tabindex="1" /></p></div>'
							)
						),
						'comment_field' =>  '<p><textarea placeholder="' . esc_attr__('说点什么吧', 'wpdie') . '..." name="comment" class="commentbody textarea form-control" id="comment" rows="5" tabindex="4"></textarea></p>',

					);
					comment_form($args);
				}
			?>
	</div>
			<?php if(have_comments()): ?>
		<p class="commentp"><i class="iconfont icon-comment"></i> 已有 <?php comments_number('0', '1', '%'); ?> 条评论</p>	
		<ol class="comment-list">
			<?php wp_list_comments('type=comment&callback=wd_comment_format'); ?>				
		</ol>
		<p class="posts-nav" style="float: right;display: inline-block;">
		<?php paginate_comments_links('prev_text=<i class="iconfont icon-left_b"></i>&next_text=<i class="iconfont icon-right_b"></i>'); ?>
		</p>
		<?php endif; ?>
	</div>
<?php endif; ?>



