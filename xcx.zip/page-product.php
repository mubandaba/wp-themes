<?php 
/*
Template Name: 小程序列表
*/ 
get_header();?>
<div class="page-main">
  <div class="container">
    <div class="main-content">
      <div class="content-row">
        <?php if (av('slion','0')==1) {include(locate_template('includes/slider.php'));}?>
        <div class="minapp-rows clearfix">
          <div class="minapps-tag-wrapper">            
            <?php 
            	$catss = av('cate_porductcat');
            	$categories = explode(',', $catss); //获取到后台设置里的分类id  
        			foreach ($categories as $category){
        			$assrgs = array(
        					'post_type'=>'product',
						  		'post_status'=>'publish',
								  'showposts'=> 8,
								  'cat'=> $category,
								  'ignore_sticky_posts' => 1,
							);
						  $ssposts = new WP_Query($assrgs);	 
        			if($ssposts->have_posts() ) : ?>
	            <div class="titlebar minapp-detail-conts-info clearfix">
	              <span class="emphasize-bar"></span>
	              <a href="<?php echo get_category_link($category);?>"><span class="minapp-detail-conts-inner-intro-des"><?php echo get_the_category_by_ID($category);?></span></a>
	              <ul class="minapp-tags-nav clearfix">
	                <li><a href="<?php echo get_category_link($category);?>" target="_blank">查看全部</a></li>
	              </ul>
	            </div>        			
						<?php $count = 1;while($ssposts->have_posts()) : $ssposts->the_post();?>          		
						<?php if(($count-1)%4 == 0){?>             	
            <dl class="minapp-grid first-item">
						<?php }elseif( $count%4 == 0){?>									
            <dl class="minapp-grid last-item">									
						<?php }else{?>
            <dl class="minapp-grid ">
						<?php }?>            	
	            <dt>
	              <a class="minapp-link" href="<?php the_permalink(); ?>"><img class="minapp-icon" src="<?php echo get_post_meta($post->ID, "product_pic", true);?>" width="100"></a>
	            </dt>
	            <dd>
	              <a class="mod-qrcode" href="javascript:;">扫码</a>
	              <div class="mod-qrcode-modal">
	                <img src="<?php echo get_post_meta($post->ID, "product_ewm", true);?>">
	                <p>打开微信扫一扫</p>
	              </div>
	              <h3 class="minapp-name"><a class="minapp-link" href="<?php the_permalink(); ?>"><?php the_title();print($count%4) ;?></a></h3>
	              <div class="minapp-infos clearfix"><p class="created-author"><?php echo get_post_meta($post->ID, "product_zuozhe", true);?></p></div>
	            </dd>
	            <dd class="bottom-desc"><a class="minapp-link" href="<?php the_permalink(); ?>"><?php echo get_post_meta($post->ID, "single_description", true);?></a></dd>
	          </dl>
            <?php $count++;endwhile; endif;wp_reset_query();?>
            <?php }?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<?php get_footer();?>
