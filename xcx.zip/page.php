<?php get_header();?>
<div class="page-main page-post-main">
  <div class="container">
    <div class="doc_container">
	  <div class="jiathis_style bdsharebuttonbox">
		<a class="jiathis_button_qzone iconfont icon-qqkongjian"></a>
		<a class="jiathis_button_tsina iconfont icon-weibo"></a>
		<a class="jiathis_button_cqq iconfont icon-qq"></a>
		<a class="jiathis_button_weixin iconfont icon-weixin"></a>
		<a class="jiathis_button_copy iconfont icon-fuzhihuihua"></a>
	  </div>
	  <?php while( have_posts() ): the_post();?>
      <div class="doc_header">
        <h1><?php the_title(); ?></h1>
        <div>作者：<?php the_author(); ?>&nbsp;&nbsp;&nbsp;&nbsp;发布于<?php echo timeago( get_gmt_from_date(get_the_time('Y-m-d G:i:s')) ); ?>&nbsp;&nbsp;&nbsp;&nbsp;阅读：&nbsp;<?php post_views(' ', ' '); ?>&nbsp;次<br></div>
      </div>
      <div class="doc_content">
		<?php the_content(); ?>
		<?php endwhile; ?>
      </div>
      <div class="doc_comments">
        <?php comments_template('', true); ?>
      </div>
    </div>
  </div>
</div>
</div>
<script "text/javascript"> 
var jiathis_config = { 
	url: "<?php the_permalink(); ?>", 
	title: "推荐一篇文章『<?php the_title(); ?>』看完蛮有收获的！", 
	pic:"<?php echo wd_thumb();?>"
} 
</script> 
<?php get_footer();?>
	