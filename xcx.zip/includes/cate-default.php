<?php get_header();?>
<div class="page-main">
  <div class="container">
    <div class="main-content">
      <div class="content-row"></div>
      <h1 class="h2 m-t-0">
        <div class="titlebar minapp-detail-conts-info">
          <span class="emphasize-bar"></span>
          <span class="minapp-detail-conts-inner-intro-des">分类『<?php echo get_category($cat)->name;?>』下的文章</span></div>
      </h1>
      <div class="row row-table-md article-rows clearfix d_category">
		<?php if( have_posts() ) : $count = 1;?>
		<?php while( have_posts() ): the_post(); ?>
		<?php if(($count-1)%3 == 0){?>             	
	    <div class="article-grid grid-item first-item">
		<?php }elseif( $count%3 == 0){?>									
	    <div class="article-grid grid-item last-item">
		<?php }else{?>
	    <div class="article-grid grid-item ">
		<?php }$count++;?>	
          <div class="panel panel-block docs-panel-block">
            <a href="<?php the_permalink(); ?>" class="mind-thumb-image"><img class="wd-lazy" data-src="<?php echo wd_thumb();?>"></a>
            <div class="placeholder-title">
              <h3 class="panel-title h2"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
            </div>
            <div class="panel-body">
              <div class="panel-intro"><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 60, "…");?></div>
              <div class="profile-reply">
                <div class="mind-vote p-r-10">
                  <div class="text-center user-vote">
                    <section class="arrow-vote">
											<span class="vote-hover"><i class="iconfont icon-eye"></i></span>
											<span class="vote-total"><?php post_views(' ', ' '); ?></span>
	                    <a href="<?php the_permalink(); ?>" class="read-more" target="_blank">阅读更多</a>
                    </section>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
		<?php endwhile; ?>
		<?php else : ?>
		<?php endif; ?>
      </div>
      <div class="row row-table-md article-rows clearfix">
      <?php if( wt_get_category_count($cat) > get_option('posts_per_page') ){ ?>
        <nav class="post-navigation navigation pagination" role="navigation">
          <div class="nav-links clearfix">
            <a href="javascript:;" class="dsloading ajax_load next" data-cat="<?php echo $cat;?>" data-action="d_category" data-page="2">加载更多</a>
          </div>
        </nav>
      <?php } ?>       	
      </div>
    </div>
  </div>
</div>
</div>
<?php get_footer();?>	