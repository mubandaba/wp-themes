<div id="homeslider">
  <div class="mod-slider container">
    <div class="mod-slider-inner slide" style="display: block;">
      <div class="content-main-visual">
        <?php for($i = 1; $i <= 3; $i++){?><a class="pc current" href="<?php echo av('sliherf'.$i);?>" target="_blank" ><img class="wd-lazy" data-src="<?php echo av('sliimg'.$i);?>"></a><?php }?>
      </div>
      <div class="content-main-feature"><?php for($i = 1; $i <= 3; $i++){?>	
        <div class="feature">
          <a href="javascript:;" class="">
            <img class="wd-lazy" data-src="<?php echo av('sliimg'.$i);?>">
            <div class="gallery-desc">
              <strong><?php echo av('slitit'.$i);?></strong>
              <p><?php echo av('slides'.$i);?></p>
            </div>
            <div class="timerLine" ></div>
          </a>
        </div>
				<?php }?>
      </div>
    </div>
  </div>
</div>