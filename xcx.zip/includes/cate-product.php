<?php get_header();?>
<div class="page-main minapps-wrapper">
  <div class="container">
    <div class="main-content">
      <div class="content-row">
        <ul class="minapp-tags-nav">
			 		<?php 
						$cateporductcat = av('cate_porductcat');
						$cateporductcat =explode(',',$cateporductcat);
						foreach($cateporductcat as $catcat){
					?>
	          <li class="<?php if($cat == $catcat){ echo 'current';}?>">
	            <a href="<?php echo get_category_link($catcat);?>"><?php echo get_the_category_by_ID($catcat);?><i class="minapps-count"><?php echo wt_get_category_count($catcat); ?></i></a>
	          </li>
					<?php }?>
	        </ul>
	        <div class="minapp-rows minapps-inner clearfix d_product">
			 		<?php 
			 			$catenumb = av('cate_porductnumb','10');
						$args = array( 
						  'post_type'=>'product',
						  'post_status'=>'publish',
						  'cat'=>$cat,
						  'posts_per_page'=>$catenumb,
						  'paged'=>1,
						); 
						$pdposts = new WP_Query($args);
						if ($pdposts->have_posts() ) : $count = 1;
						while($pdposts->have_posts()) : $pdposts->the_post();
					?>         	
					<?php if(($count-1)%3 == 0){?>             	
	          <dl class="minapp-grid first-item">
					<?php }elseif( $count%3 == 0){?>									
	          <dl class="minapp-grid last-item">									
					<?php }else{?>
	          <dl class="minapp-grid ">
					<?php }$count++;?>
            <dt>
              <a class="minapp-link" href="<?php the_permalink(); ?>"><img class="minapp-icon" src="<?php echo get_post_meta($post->ID, "product_pic", true);?>" width="100"></a>
            </dt>
            <dd>
              <a class="mod-qrcode" href="javascript:;">扫码</a>
              <div class="mod-qrcode-modal">
                <img src="<?php echo get_post_meta($post->ID, "product_ewm", true);?>">
                <p>打开微信扫一扫</p>
              </div>
              <h3 class="minapp-name"><a class="minapp-link" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
              <div class="minapp-infos clearfix"><p class="created-author"><?php echo get_post_meta($post->ID, "product_zuozhe", true);?></p></div>
            </dd>
            <dd class="bottom-desc"><a class="minapp-link" href="<?php the_permalink(); ?>"><?php echo get_post_meta($post->ID, "single_description", true);?></a></dd>
          </dl>
		<?php endwhile; endif;wp_reset_query();?>
		</div>
		<div class="minapp-rows minapps-inner clearfix">	
      <?php if( wt_get_category_count($cat) > $catenumb ){ ?>
        <nav class="post-navigation navigation pagination" role="navigation">
          <div class="nav-links clearfix">
            <a href="javascript:;" class="dsloading ajax_load next" data-cat="<?php echo $cat;?>" data-action="d_product" data-page="2">加载更多</a>
          </div>
        </nav>
      <?php } ?> 
    </div>	 
    </div>
  </div>
</div>
</div>
</div>
<?php get_footer();?>