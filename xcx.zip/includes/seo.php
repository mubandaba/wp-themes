<?php
if(av('nocategory','0') == 1){
//去除分类标志代码
add_action( 'load-themes.php',  'no_category_base_refresh_rules');
add_action('created_category', 'no_category_base_refresh_rules');
add_action('edited_category', 'no_category_base_refresh_rules');
add_action('delete_category', 'no_category_base_refresh_rules');
function no_category_base_refresh_rules() {
	global $wp_rewrite;
	$wp_rewrite -> flush_rules();
}
// Remove category base
add_action('init', 'no_category_base_permastruct');
function no_category_base_permastruct() {
	global $wp_rewrite, $wp_version;
	if (version_compare($wp_version, '3.4', '<')) {
		// For pre-3.4 support
		$wp_rewrite -> extra_permastructs['category'][0] = '%category%';
	} else {
		$wp_rewrite -> extra_permastructs['category']['struct'] = '%category%';
	}
}
// Add our custom category rewrite rules
add_filter('category_rewrite_rules', 'no_category_base_rewrite_rules');
function no_category_base_rewrite_rules($category_rewrite) {
	//var_dump($category_rewrite); // For Debugging
	$category_rewrite = array();
	$categories = get_categories(array('hide_empty' => false));
	foreach ($categories as $category) {
		$category_nicename = $category -> slug;
		if ($category -> parent == $category -> cat_ID)// recursive recursion
			$category -> parent = 0;
		elseif ($category -> parent != 0)
			$category_nicename = get_category_parents($category -> parent, false, '/', true) . $category_nicename;
		$category_rewrite['(' . $category_nicename . ')/(?:feed/)?(feed|rdf|rss|rss2|atom)/?$'] = 'index.php?category_name=$matches[1]&feed=$matches[2]';
		$category_rewrite['(' . $category_nicename . ')/page/?([0-9]{1,})/?$'] = 'index.php?category_name=$matches[1]&paged=$matches[2]';
		$category_rewrite['(' . $category_nicename . ')/?$'] = 'index.php?category_name=$matches[1]';
	}
	// Redirect support from Old Category Base
	global $wp_rewrite;
	$old_category_base = get_option('category_base') ? get_option('category_base') : 'category';
	$old_category_base = trim($old_category_base, '/');
	$category_rewrite[$old_category_base . '/(.*)$'] = 'index.php?category_redirect=$matches[1]';
	//var_dump($category_rewrite); // For Debugging
	return $category_rewrite;
}
// Add 'category_redirect' query variable
add_filter('query_vars', 'no_category_base_query_vars');
function no_category_base_query_vars($public_query_vars) {
	$public_query_vars[] = 'category_redirect';
	return $public_query_vars;
}
// Redirect if 'category_redirect' is set
add_filter('request', 'no_category_base_request');
function no_category_base_request($query_vars) {
	//print_r($query_vars); // For Debugging
	if (isset($query_vars['category_redirect'])) {
		$catlink = trailingslashit(get_option('home')) . user_trailingslashit($query_vars['category_redirect'], 'category');
		status_header(301);
		header("Location: $catlink");
		exit();
	}
	return $query_vars;
}
}
//压缩html代码 
if(av('yasuohtml','0') == 1){ 
function wp_compress_html()  
{  
function wp_compress_html_main ($buffer)  
{  
    $initial=strlen($buffer);  
    $buffer=explode("<!--wp-compress-html-->", $buffer);  
    $count=count ($buffer);  
    for ($i = 0; $i <= $count; $i++)  
    {  
        if (stristr($buffer[$i], '<!--wp-compress-html no compression-->'))  
        {  
            $buffer[$i]=(str_replace("<!--wp-compress-html no compression-->", " ", $buffer[$i]));  
        }  
        else  
        {  
            $buffer[$i]=(str_replace("\t", " ", $buffer[$i]));  
            $buffer[$i]=(str_replace("\n\n", "\n", $buffer[$i]));  
            $buffer[$i]=(str_replace("\n", "", $buffer[$i]));  
            $buffer[$i]=(str_replace("\r", "", $buffer[$i]));  
            while (stristr($buffer[$i], '  '))  
            {  
            $buffer[$i]=(str_replace("  ", " ", $buffer[$i]));  
            }  
        }  
        $buffer_out.=$buffer[$i];  
    }  
    $final=strlen($buffer_out);  
    $savings=($initial-$final)/$initial*100;  
    $savings=round($savings, 2);  
    $buffer_out.="\n<!--压缩前的大小: $initial bytes; 压缩后的大小: $final bytes; 节约：$savings% -->";  
    return $buffer_out;  
}  
ob_start("wp_compress_html_main");  
}  
add_action('get_header', 'wp_compress_html'); 
}
function um_phpmailer( $mail ) {
	$smtp_switch = av('smtp_switch','0');
	if($smtp_switch == '1'){
		$mail->IsSMTP();
		$mail->SMTPAuth = true; 
		$mail->isHTML(true);
		$mail->From = sanitize_text_field(av('smtp_account'));
		$mail->Sender = $mail->From;
		$mail->Host = sanitize_text_field(av('smtp_host'));
		$mail->Port = intval(av('smtp_port'));
		$mail->Username = sanitize_text_field(av('smtp_account'));
		$mail->Password = sanitize_text_field(av('smtp_pass'));
		if(av('smtp_ssl','0') == '1') $mail->SMTPSecure = 'ssl';
		$mail->FromName = sanitize_text_field(av('smtp_name'));
	}
}
add_action( 'phpmailer_init', 'um_phpmailer' );
//外链nofollow
if(av('nofollow','0')==1){
add_filter( 'the_content', 'die_seo_wl');
function die_seo_wl( $content ){
    $regexp = "<a\s[^>]*href=(\"??)([^\" >]*?)\\1[^>]*>";
    if(preg_match_all("/$regexp/siU", $content, $matches, PREG_SET_ORDER)) {
        if( !empty($matches) ) {
   
            $srcUrl = get_option('siteurl');
            for ($i=0; $i < count($matches); $i++)
            {
   
                $tag = $matches[$i][0];
                $tag2 = $matches[$i][0];
                $url = $matches[$i][0];
   
                $noFollow = '';
                $pattern = '/target\s*=\s*"\s*_blank\s*"/';
                preg_match($pattern, $tag2, $match, PREG_OFFSET_CAPTURE);
                if( count($match) < 1 )
                    $noFollow .= ' target="_blank" ';
   
                $pattern = '/rel\s*=\s*"\s*[n|d]ofollow\s*"/';
                preg_match($pattern, $tag2, $match, PREG_OFFSET_CAPTURE);
                if( count($match) < 1 )
                    $noFollow .= ' rel="nofollow" ';
   
                $pos = strpos($url,$srcUrl);
                if ($pos === false) {
                    $tag = rtrim ($tag,'>');
                    $tag .= $noFollow.'>';
                    $content = str_replace($tag2,$tag,$content);
                }
            }
        }
    }
   
    $content = str_replace(']]>', ']]>', $content);
    return $content;
}
}
//给文章图片自动添加alt和title信息
if(av('postalt','0') == 1){
add_filter('the_content', 'imagesalt');
function imagesalt($content) {
       global $post;
       $pattern ="/<a(.*?)href=('|\")(.*?).(bmp|gif|jpeg|jpg|png)('|\")(.*?)>/i";
       $replacement = '<a$1href=$2$3.$4$5 alt="'.$post->post_title.'" title="'.$post->post_title.'"$6>';
       $content = preg_replace($pattern, $replacement, $content);
       return $content;
}
function image_alt_tag($content){
    global $post;preg_match_all('/<img (.*?)\/>/', $content, $images);
    if(!is_null($images)) {foreach($images[1] as $index => $value)
    {
        $new_img = str_replace('<img', '<img alt="'.get_the_title().'-'.get_option('blogname').'"', $images[0][$index]);
        $content = str_replace($images[0][$index], $new_img, $content);}}
    return $content;
}
add_filter('the_content', 'image_alt_tag', 99999);
}