<title><?php 
if (is_search() || is_404() || is_author()) {
    wp_title('', true);
    echo ' ' . page_sign() . ' ';
} elseif (is_single() || is_page()) {
    $newtitle1 = get_post_meta($post->ID, "single_newtitles", true);
    $newtitle2 = get_the_title();
    echo $newtitle1 ? $newtitle1 : $newtitle2;
    echo ' ' . page_sign() . ' ';
	if(av('sseott','0')==1){
	$cat = get_the_category(); $cat = $cat[0];
	$cats = get_category_parents($cat, false, ' ' . page_sign() . ' ');
	echo $cats;		
	}
} elseif (is_archive() || is_category()) {
    global $wp_query;
    $cat_id = $wp_query->get_queried_object_id();
    $category = get_category($cat_id);
    $cattitle1 = get_term_meta($cat_id, 'category_newtitles', true);
    $cattitle2 = $category->name;
    echo $cattitle1 ? $cattitle1 : $cattitle2;
    echo ' ' . page_sign() . ' ';
}
bloginfo('name');
if (is_home()) {
    echo ' ' . page_sign() . ' ';
    bloginfo('description');
}
if (is_paged()) {
    ?> - <?php 
    printf(__('Page %1$s of %2$s', ''), intval(get_query_var('paged')), $wp_query->max_num_pages);
}
?></title>
<?php 
if (is_home() || is_search() || is_author()) {
    $description = av('home_description');
    $keywords = av('home_keywords');
} elseif (is_single() || is_page()) {
    $description1 = get_post_meta($post->ID, "single_description", true);
    $description2 = mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 200, "…");
    $description = $description1 ? $description1 : $description2;
    $keywords = get_post_meta($post->ID, "single_keywords", true);
    if ($keywords == '') {
        $tags = wp_get_post_tags($post->ID);
        foreach ($tags as $tag) {
            $keywords = $keywords . $tag->name . ", ";
        }
        $keywords = rtrim($keywords, ', ');
    }
} elseif (is_category()) {
    $description = get_term_meta($cat, 'category_description', true);
    $keywords = get_term_meta($cat, 'category_keywords', true);
} elseif (is_tag()) {
    $description = tag_description();
    $keywords = single_tag_title('', false);
} elseif (is_404()) {
    $description = '网页找不到了！';
    $keywords = '';
}
$description = trim(strip_tags($description));
$keywords = trim(strip_tags($keywords));
?>
<meta name="description" content="<?php echo $description;?>" />
<meta name="keywords" content="<?php echo $keywords;?>" />