<?php get_header();?>
<?php 
	$tagname = single_tag_title('', false);
	$productid = av('cate_porductcat');
	$pronotid = explode(',', $productid);
	$fuid = '';
	foreach($pronotid as $cat){
		$fuid .= '-'.$cat.',';
	}
?>	
<div class="page-main">
  <div class="container">
    <div class="main-content">
      <div class="content-row">
				<?php 
				$args = array( 
					'post_type'=>'product',
					'cat' => $productid ,
					'tag' => $tagname,
					'paged'=>1,
					'ignore_sticky_posts' => 1,
				); 
				$pdposts = new WP_Query($args);
				$prnumb = $pdposts->found_posts;
				if ($pdposts->have_posts() ) : $count = 1;?>
        <h1 class="h2 m-t-0">
          <div class="titlebar minapp-detail-conts-info">
            <span class="emphasize-bar"></span>
            <span class="minapp-detail-conts-inner-intro-des">关于『<?php echo $tagname;?>』的小程序</span></div>
        </h1>
        <div class="home-minapp-rows minapp-rows clearfix d_ts_product">				
				<?php while($pdposts->have_posts()) : $pdposts->the_post();?>         	
				<?php if(($count-1)%4 == 0){?>             	
			      <dl class="minapp-grid first-item">
				<?php }elseif( $count%4 == 0){?>									
			      <dl class="minapp-grid last-item">									
				<?php }else{?>
			      <dl class="minapp-grid ">
				<?php }$count++;?>
                  <dt>
                    <a class="minapp-link" href="<?php the_permalink(); ?>">
                      <img class="minapp-icon" src="<?php echo get_post_meta($post->ID, "product_pic", true);?>" width="100"></a>
                  </dt>
                  <dd>
                    <a class="mod-qrcode" href="javascript:;">扫码</a>
                    <div class="mod-qrcode-modal">
                      <img src="<?php echo get_post_meta($post->ID, "product_ewm", true);?>">
                      <p>打开微信扫一扫</p>
                    </div>
                    <h3 class="minapp-name">
                      <a class="minapp-link" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <div class="minapp-infos clearfix">
                      <ul class="minapp-tags clearfix"><?php echo posts_tags(3)?></ul>
                    </div>
                  </dd>
                </dl>
				<?php endwhile;?>
				</div>
	      <div class="home-minapp-rows minapp-rows clearfix">	
	      <?php if( $prnumb > get_option('posts_per_page') ){ ?>
	        <nav class="post-navigation navigation pagination" role="navigation">
	          <div class="nav-links clearfix">
	            <a href="javascript:;" class="dsloading ajax_load next" data-cat="<?php echo $productid;?>" data-tag="<?php echo $tagname;?>" data-action="d_ts_product" data-page="2">加载更多</a>
	          </div>
	        </nav>
	      <?php } ?>       	
	      </div>				
				<?php endif;wp_reset_postdata();?>
		 		<?php 
		 		$asrgs = array( 
					'post_type'=>'post',
					'cat' => $fuid,
					'tag' => $tagname,
					'ignore_sticky_posts' => 1,
				); 
				$pposts = new WP_Query($asrgs);
				$ppnumb = $pposts->found_posts;
		 		if( $pposts->have_posts() ) : $count = 1;?>        
        <h1 class="h2 m-t-0">
          <div class="titlebar minapp-detail-conts-info">
            <span class="emphasize-bar"></span>
            <span class="minapp-detail-conts-inner-intro-des">关于『<?php echo $tagname;?>』的文章</span></div>
        </h1>
        <div class="row row-table-md article-rows clearfix d_ts_post">
				<?php while( $pposts->have_posts() ): $pposts->the_post(); ?>
				<?php if(($count-1)%3 == 0){?>             	
			    <div class="article-grid grid-item first-item">
				<?php }elseif( $count%3 == 0){?>									
			    <div class="article-grid grid-item last-item">
				<?php }else{?>
			    <div class="article-grid grid-item ">
				<?php }$count++;?>	         	  	
		          <div class="panel panel-block docs-panel-block">
		            <a href="<?php the_permalink(); ?>" class="mind-thumb-image"><img class="wd-lazy" data-src="<?php echo wd_thumb();?>"></a>
		            <div class="placeholder-title">
		              <h3 class="panel-title h2"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
		            </div>
		            <div class="panel-body">
		              <div class="panel-intro"><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 60, "…");?></div>
		              <div class="profile-reply">
		                <div class="mind-vote p-r-10">
		                  <div class="text-center user-vote">
		                    <section class="arrow-vote">
													<span class="vote-hover"><i class="iconfont icon-eye"></i></span>
													<span class="vote-total"><?php post_views(' ', ' '); ?></span>
			                    <a href="<?php the_permalink(); ?>" class="read-more" target="_blank">阅读更多</a>
		                    </section>
		                  </div>
		                </div>
		              </div>
		            </div>
		          </div>
		       	</div>
				<?php endwhile; ?>
				</div>	
				<div class="home-minapp-rows minapp-rows clearfix">	
	      <?php if( $ppnumb > get_option('posts_per_page') ){ ?>
	        <nav class="post-navigation navigation pagination" role="navigation">
	          <div class="nav-links clearfix">
	            <a href="javascript:;" class="dsloading ajax_load next" data-cat="<?php echo $fuid;?>" data-tag="<?php echo $tagname;?>" data-action="d_ts_post" data-page="2">加载更多</a>
	          </div>
	        </nav>
	      <?php } ?>       	
	      </div>
		<?php endif;wp_reset_postdata();?>
      </div>
    </div>
  </div>
</div>
</div>
<?php get_footer();?>		