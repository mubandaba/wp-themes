<?php get_header();?>
<div class="block_message me404" style="margin-top: 50px;">
  <div class="container">
    <div class="base_message error_message custom_message">
      <i class="iconfont icon-icon-tutorial"></i>
      <h3>404 Error</h3>
      <p>『你查看的页面』跑到火星去了，我很快会抓回来:-D
        <br>
        <a href="<?php bloginfo('url');?>">返回首页看看</a></p>
    </div>
  </div>
</div>
</div>
<?php get_footer();?>
	