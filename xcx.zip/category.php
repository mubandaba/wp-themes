<?php 
$cat_f1 = av('cate_porductcat');
$idarr_f1 =explode(',',$cat_f1);
$post = $wp_query -> post;
if(is_category($idarr_f1)){
	include( TEMPLATEPATH.'/includes/cate-product.php');
}else {
	include( TEMPLATEPATH.'/includes/cate-default.php');
}
?>