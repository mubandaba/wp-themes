<?php
require get_template_directory() . '/settings/option.php';
require get_template_directory() . '/includes/seo.php';
add_filter('admin_footer_text', 'remove_footer_admin');
add_filter('show_admin_bar', '__return_false');
add_filter('nav_menu_css_class', 'my_css_attributes_filter', 100, 1);
add_filter('nav_menu_item_id', 'my_css_attributes_filter', 100, 1);
add_filter('page_css_class', 'my_css_attributes_filter', 100, 1);
add_action('wp_enqueue_scripts', 'wd_add_scripts');
add_action('wp_head', 'av_head_css');
add_filter( 'style_loader_src', 'wd_remove_cssjs_ver', 999 );
add_filter( 'script_loader_src', 'wd_remove_cssjs_ver', 999 );
add_action( 'load-themes.php', 'Init_theme' );
add_action( 'welcome_panel', 'rc_my_welcome_panel' );
add_action('wp_dashboard_setup', 'example_remove_dashboard_widgets' );
remove_action('welcome_panel', 'wp_welcome_panel');
add_action( 'admin_init', 'remove_dashboard_meta' );
add_action('wp_head', 'record_visitors');
add_action( 'wp_ajax_d_product' , 'd_product' );
add_action( 'wp_ajax_nopriv_d_product' , 'd_product' );
add_action( 'wp_ajax_d_ts_product' , 'd_ts_product' );
add_action( 'wp_ajax_nopriv_d_ts_product' , 'd_ts_product' );
add_action( 'wp_ajax_d_ts_post' , 'd_ts_post' );
add_action( 'wp_ajax_nopriv_d_ts_post' , 'd_ts_post' );
add_action( 'wp_ajax_d_category' , 'd_category' );
add_action( 'wp_ajax_nopriv_d_category' , 'd_category' );
add_filter('pre_get_posts', 'searchAll' );
add_filter( 'posts_search', 'wd_search_by_title_only', 500, 2 );
add_action('login_head', 'uazoh_custom_login_page');
add_filter('retrieve_password_message', 'reset_password_message', null, 2);
add_filter( 'pre_option_link_manager_enabled', '__return_true' );
function remove_footer_admin(){
echo '<p>7号技师WP作品，交流QQ群：281907514。<a href="https://ztmao.com/cmszhuti/2753.html" target="_blank" title="问题反馈">问题反馈</a></p>';
}
function my_css_attributes_filter($var) {
	return is_array($var) ? array_intersect($var, array('current-menu-item','current-post-ancestor','current-menu-ancestor','current-menu-parent')) : '';
}
function wd_add_scripts(){
	wp_enqueue_style('style', get_template_directory_uri() . '/style.css');	
	wp_enqueue_style('fonts', 'http://at.alicdn.com/t/font_ormjd9900ctbj4i.css');	
	$jq = get_template_directory_uri() . '/includes/js/jquery.min.js';
	wp_deregister_script( 'jquery' ); 
	wp_deregister_script( 'wp-embed' ); 
	wp_register_script( 'jquery', $jq ); 
	wp_enqueue_script( 'jquery' );
	wp_register_script( 'commons', get_template_directory_uri() . '/includes/js/common.js', array('jquery'), '' );
	wp_enqueue_script( 'commons',false,array(),'',true  );
	wp_register_script( 'slider', get_template_directory_uri() . '/includes/js/slider.js', array('jquery'), '' );
	wp_enqueue_script( 'slider',false,array(),'',true  );
	wp_localize_script( 'commons', 'admin_url', 
        array(
             "url_ajax" => admin_url("admin-ajax.php"),
        ) 
    );	
	if(is_single()){
	wp_enqueue_script('comment-reply');
	wp_register_script( 'jiathis', 'http://v2.jiathis.com/code/jia.js', array('jquery'), '' );
	wp_enqueue_script( 'jiathis',false,array(),'',true  );
	}
}
register_nav_menu('header', __( '主菜单', 'header' ) );
function av_head_css(){
	$xz_var_2 = '';
	if (av('net_gray')==1) {
		$xz_var_2.= 'html{overflow-y:scroll;filter:progid:DXImageTransform.Microsoft.BasicImage(grayscale=1);-webkit-filter: grayscale(100%);}body{background-color:#9aa6b9;}';
	}else{
		$bjcssz = av('bjcssz','#9aa6b9');
		$bjjbsz = av('bjjbsz','#9aa6b9');
		$xz_var_2.= 'body{filter:progid: DXImageTransform.Microsoft.gradient(gradientType=1, startColorstr="'.$bjcssz.'", endColorstr="'.$bjjbsz.'");background-size:100%;background-image:-webkit-gradient(linear,0 0,100% 100%,color-stop(0,'.$bjcssz.'),color-stop(100%,'.$bjjbsz.'));background-image:-webkit-linear-gradient(135deg,'.$bjcssz.','.$bjjbsz.');background-image:-moz-linear-gradient(45deg,'.$bjcssz.','.$bjjbsz.');background-image:-ms-linear-gradient(45deg,'.$bjcssz.' 0,'.$bjjbsz.' 100%);background-image:-o-linear-gradient(45deg,'.$bjcssz.','.$bjjbsz.');background-image:linear-gradient(135deg,'.$bjcssz.','.$bjjbsz.');}';
		$excssz = av('excssz','#9aa6b9');
		$exjbsz = av('exjbsz','#9aa6b9');	
		$xz_var_2.= '#page-sidebar-left #logo {background-color: '.$excssz.';background: -moz-linear-gradient(left,'.$excssz.','.$exjbsz.');background: -webkit-linear-gradient(left top,'.$excssz.','.$exjbsz.');background: -o-linear-gradient(left,'.$excssz.','.$exjbsz.');}';
		$xz_var_2.= '.mod-slider .mod-slider-inner .timerLine {background-color: '.$excssz.';background: -moz-linear-gradient(left,'.$excssz.','.$exjbsz.');background: -webkit-linear-gradient(left top,'.$excssz.','.$exjbsz.');background: -o-linear-gradient(left,'.$excssz.','.$exjbsz.');}';
		$xz_var_2.= '.posts-nav .page-numbers:not(.dots):hover,.btn:hover {background-color: '.$excssz.';background: -moz-linear-gradient(left,'.$excssz.','.$exjbsz.');background: -webkit-linear-gradient(left top,'.$excssz.','.$exjbsz.');background: -o-linear-gradient(left,'.$excssz.','.$exjbsz.');}';
	}
	if ($xz_var_2) echo '<style>' . $xz_var_2 . '</style>';
}
function wd_remove_cssjs_ver( $src ){
	if( strpos( $src, 'ver=' ) )
		$src = remove_query_arg( 'ver', $src );
	return $src;
}
function Init_theme(){
  global $pagenow;
  if ( 'themes.php' == $pagenow && isset( $_GET['activated'] ) ) {
    wp_redirect( admin_url( '/index.php' ) );
    exit;
  }
}
function rc_my_welcome_panel() { ?>
<script type="text/javascript">
	jQuery(document).ready( function($) 
	{
		$('div.welcome-panel-content').hide();
	});
</script>
<div class="ybpjc">
	<h2>Crzd 1st </h2>
	<p>首先，感谢您使用主题猫WP建站的作品！以下为主题教程：</p>
	<hr>
	<h3>基础主题教程</h3>
	<ol class="jcbox">
		<li>教程都是承上启下的，教程都有顺序，请从上到下按顺序进行设置，教程内蓝色字是可以直接点击的，切勿跳跃操作！</li>
		<li>主题安装后，会在后台的外观上部增加【<a href="/wp-admin/admin.php?page=generalpage" target="_blank">网站设置</a>】选项，这是主题的核心设置，请知悉！</li>
		<li>主题安装好第一件事不是去设置主题选项，而是创建好网站里的【<a href="/wp-admin/edit-tags.php?taxonomy=category" target="_blank">分类</a>】和【<a href="/wp-admin/edit.php?post_type=page" target="_blank">页面</a>】！（已有内容的老站除外）切记，只有有了分类和页面，才有操作下面的依据！</li>
		<li>分类目录想不同模板展示该如何设置？一般如果主题支持多分类模板，这个功能一般会在【<a href="/wp-admin/admin.php?page=generalpage" target="_blank">主题选项</a>】的文章判定中体现。只需勾选分类就可以设置不同分类模板。</li>
		<li>文章想不同模板展示？一般多文章模板是和多分类模板是想关联的。即设置好分类模板后，文章模板会自行跟随分类模板而不同。而如果没有多模板设置，则将单独体现多文章模板设置选项。</li>		
		<li>导航菜单如何添加？通过【<a href="/wp-admin/nav-menus.php" target="_blank">菜单</a>】的【<a href="/wp-admin/nav-menus.php?action=edit&menu=0" target="_blank">创建</a>】功能可以创建出很多的菜单组，设置好菜单组的菜单内容，选择好菜单所要显示的位置！！！听好了吗？一个菜单组有三个信息，菜单组的名字，菜单组的内容，和菜单组的位置！当然，我们可以自由创建出N个菜单组来给每个位置进行展示！</li>
		<li>以上是主题使用方面最基础的操作，如需要修改主题里某些写死了的文字或链接，可以尝试下外观里的【<a href="/wp-admin/theme-editor.php" target="_blank">编辑</a>】 来对细节文件的修改！而如果你通过FTP来上传下载修改，一定要选择二进制传输模式。</li>
		<li>如果你对wordpress一无所知，建议首先阅读主题猫提供的基础教程，以便您快速熟悉wp的操作！详尽请进【<a href="https://ztmao.com/ksrm/zbgz" target="_blank">GO</a>】</li>
	</ol>
	<h3>交流群</h3>
	<p>QQ群：281907514！该主题仅在主题猫独家发布！官方网址为：ztmao.com ，其它主题来源，主题猫不保证代码的安全性！在主题使用过程中，任何疑问除QQ群交流，还可以通过主题猫个人中心里面的工单系统来提交给我们处理。</p>
	<p>如果你想修改或添加其他主题不包含的功能，也可以在工单系统中提交工单并备注7号技师，会得到最低报价。</p>
</div>
<?php }
function example_remove_dashboard_widgets() {
    global $wp_meta_boxes;
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_quick_press']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_incoming_links']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_plugins']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_recent_comments']);
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_recent_drafts']);
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_primary']);
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_secondary']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_right_now']);
}
function remove_dashboard_meta() {
    remove_meta_box( 'dashboard_activity', 'dashboard', 'normal');
}
function av($name,$default = false ){
	global $ashu_option;
	@$result = $ashu_option['general'][$name];
	
	if(isset($result) && $result!=''){
	return $result;
	}else{
	return $default; 	
	}
}
function show_category(){
    global $wpdb;
    $request = "SELECT $wpdb->terms.term_id, name FROM $wpdb->terms ";
    $request .= " LEFT JOIN $wpdb->term_taxonomy ON $wpdb->term_taxonomy.term_id = $wpdb->terms.term_id ";
    $request .= " WHERE $wpdb->term_taxonomy.taxonomy = 'category' ";
    $request .= " ORDER BY term_id asc";
    $categorys = $wpdb->get_results($request);
    echo '<p>分类ID：';
    foreach ($categorys as $category) { 
        echo  ''.$category->name."（<code>".$category->term_id.'</code>）';
    }
    echo '</p>';
}
function page_sign(){
    $sign = '';
	$pas = av('page_sign','-');
    return $pas;
}
function wd_thumb($post_id=null){
	$post_id = ( $post_id === null ) ? get_the_ID() : $post_id;
    $post=get_post($post_id);
	$thumb = get_post_meta($post_id,'thumb', true);
    if( $thumb ) {
        $post_thumbnail_src = $thumb;
    }else {
        $post_thumbnail_src = '';
        ob_start();
        ob_end_clean();
        $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
        if(!empty($matches[1][0])){
            $post_thumbnail_src = $matches[1][0];
        }else{  
            //如果日志中没有图片，则显示随机图片
            $random = mt_rand(1, 5);
            $post_thumbnail_src = get_template_directory_uri().'/includes/images/random/'.$random.'.jpg';
        }
    }
	return $post_thumbnail_src; 
}
function timeago( $ptime ) {
    $ptime = strtotime($ptime);
    $etime = time() - 28800 - $ptime;
    if($etime < 1) return '刚刚';
    $interval = array (
        12 * 30 * 24 * 60 * 60  =>  '年前 ('.date('Y-m-d', $ptime).')',
        30 * 24 * 60 * 60       =>  '个月前 ('.date('Y-m-d', $ptime).')',
        7 * 24 * 60 * 60        =>  '周前 ('.date('Y-m-d', $ptime).')',
        24 * 60 * 60            =>  '天前',
        60 * 60                 =>  '小时前',
        60                      =>  '分钟前',
        1                       =>  '秒前'
    );
    foreach ($interval as $secs => $str) {
        $d = $etime / $secs;
        if ($d >= 1) {
            $r = round($d);
            return $r . $str;
        }
    }
}

function record_visitors(){
    if (is_singular())
    {
      global $post;
      $post_ID = $post->ID;
      if($post_ID)
      {
          $post_views = (int)get_post_meta($post_ID, 'views', true);
          if(!update_post_meta($post_ID, 'views', ($post_views+1)))
          {
            add_post_meta($post_ID, 'views', 1, true);
          }
      }
    }
}
function post_views($before = '(点击 ', $after = ' 次)', $echo = 1)
{
  global $post;
  $post_ID = $post->ID;
  $views = (int)get_post_meta($post_ID, 'views', true);
  if ($echo) echo $before, number_format($views), $after;
  else return $views;
}
function wd_comment_format($comment, $args, $depth) {
	$GLOBALS['comment'] = $comment;
	?>
	<li <?php comment_class(); ?> id="comment-<?php echo esc_attr(comment_ID()); ?>">
	  <div class="comment-author" >
	    <span itemprop="image">
	    <img class="avatar" src="//0.gravatar.com/avatar/<?php echo esc_attr(md5($comment->comment_author_email)); ?>?s=32" alt="<?php comment_author(); ?>" width="32" height="32">
	    </span>
	    <cite class="fn"><?php comment_author(); ?></cite>
	  </div>
	  <div class="comment-meta"><time datetime="<?php comment_date('Y-m-d'); ?>"><?php comment_date(get_option('date_format')); ?></time></div>
	  <div class="comment-content" >
	    <?php comment_text(); ?>
	  </div>
	  <?php comment_reply_link(array_merge($args, array('depth' => $depth, 'max_depth' => $args['max_depth']))); ?>
	<?php
}
function posts_tags($nmb){
	$tags = get_the_tags();
	$count=0;
	if($tags){
		foreach ($tags as $tag){
		$count++;
			if($count<$nmb){	
			$tag_link = get_tag_link($tag->term_id);
			$html .= '<li><a href="'.$tag_link.'" target="_blank">';
			$html .= "{$tag->name}</a></li>";
			}
		}
	}
	echo $html;
}
function wt_get_category_count($input = '') {
    global $wpdb;

    if($input == '') {
        $category = get_the_category();
        return $category[0]->category_count;
    }
    elseif(is_numeric($input)) {
        $SQL = "SELECT $wpdb->term_taxonomy.count FROM $wpdb->terms, $wpdb->term_taxonomy WHERE $wpdb->terms.term_id=$wpdb->term_taxonomy.term_id AND $wpdb->term_taxonomy.term_id=$input";
        return $wpdb->get_var($SQL);
    }
    else {
        $SQL = "SELECT $wpdb->term_taxonomy.count FROM $wpdb->terms, $wpdb->term_taxonomy WHERE $wpdb->terms.term_id=$wpdb->term_taxonomy.term_id AND $wpdb->terms.slug='$input'";
        return $wpdb->get_var($SQL);
    }
}
function d_product(){
    $page = sanitize_text_field($_POST['data']['page']);
	$cat = sanitize_text_field($_POST['data']['cat']);
 	$catenumb = av('cate_porductnumb','10');
	$args = array( 
		'post_type'=>'product',
		'post_status'=>'publish',
		'cat'=>$cat,
		'posts_per_page'=>$catenumb,
		'paged'=>$page,
		'ignore_sticky_posts' => 1,
	); 
	$pdposts = new WP_Query($args);
	if ($pdposts->have_posts() ) { $count = 1;
	while($pdposts->have_posts()) : $pdposts->the_post();
	$post = get_post();
	?>         	
	<?php if(($count-1)%3 == 0){?>             	
    <dl class="minapp-grid first-item">
	<?php }elseif( $count%3 == 0){?>									
    <dl class="minapp-grid last-item">									
	<?php }else{?>
    <dl class="minapp-grid ">
	<?php }$count++;?>
        <dt>
        <a class="minapp-link" href="<?php the_permalink(); ?>"><img class="minapp-icon" src="<?php echo get_post_meta($post->ID, "product_pic", true);?>" width="100"></a>
        </dt>
        <dd>
            <a class="mod-qrcode" href="javascript:;">扫码</a>
            <div class="mod-qrcode-modal">
              <img src="<?php echo get_post_meta($post->ID, "product_ewm", true);?>">
              <p>打开微信扫一扫</p>
            </div>
            <h3 class="minapp-name"><a class="minapp-link" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
            <div class="minapp-infos clearfix"><p class="created-author"><?php echo get_post_meta($post->ID, "product_zuozhe", true);?></p></div>
        </dd>
        <dd class="bottom-desc"><a class="minapp-link" href="<?php the_permalink(); ?>"><?php echo get_post_meta($post->ID, "single_description", true);?></a></dd>
    </dl>
	<?php 
	unset($post);
	endwhile;
    }else{
        echo 0;
    }
    die();
}
function d_ts_product(){
    $page = sanitize_text_field($_POST['data']['page']);
	$cat = sanitize_text_field($_POST['data']['cat']);
	$tag = sanitize_text_field($_POST['data']['tag']);	
	$args = array( 
		'post_type'=>'product',
		'tag' => $tag,
		'cat'=>$cat,
		'paged'=>$page,
		'ignore_sticky_posts' => 1,
	); 
	$pdposts = new WP_Query($args);
	if ($pdposts->have_posts() ) { $count = 1;
	while($pdposts->have_posts()) : $pdposts->the_post();
	$post = get_post();
	?>         	
	<?php if(($count-1)%4 == 0){?>             	
    <dl class="minapp-grid first-item">
	<?php }elseif( $count%4 == 0){?>									
    <dl class="minapp-grid last-item">									
	<?php }else{?>
    <dl class="minapp-grid ">
	<?php }$count++;?>
                  <dt>
                    <a class="minapp-link" href="<?php the_permalink(); ?>">
                      <img class="minapp-icon" src="<?php echo get_post_meta($post->ID, "product_pic", true);?>" width="100"></a>
                  </dt>
                  <dd>
                    <a class="mod-qrcode" href="javascript:;">扫码</a>
                    <div class="mod-qrcode-modal">
                      <img src="<?php echo get_post_meta($post->ID, "product_ewm", true);?>">
                      <p>打开微信扫一扫</p>
                    </div>
                    <h3 class="minapp-name">
                      <a class="minapp-link" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <div class="minapp-infos clearfix">
                      <ul class="minapp-tags clearfix"><?php echo posts_tags(3)?></ul>
                    </div>
                  </dd>
                </dl>
	<?php 
	unset($post);
	endwhile;
    }else{
        echo 0;
    }
    die();
}
function d_ts_post(){

    $page = sanitize_text_field($_POST['data']['page']);
    $cat = sanitize_text_field($_POST['data']['cat']);
	$tag = sanitize_text_field($_POST['data']['tag']);	
    $args = array(
        'cat'                 => $cat,
        'paged'               => $page,
        'post_type'   => 'post',
		'tag' => $tag,
		'ignore_sticky_posts' => 1,
    );
    $category_posts = new WP_Query( $args );

    if( $category_posts->have_posts() ){ 
        $count = 1;
        while( $category_posts->have_posts() ) : $category_posts->the_post();
            $post = get_post();
		?>
		<?php if(($count-1)%3 == 0){?>             	
	    <div class="article-grid grid-item first-item">
		<?php }elseif( $count%3 == 0){?>									
	    <div class="article-grid grid-item last-item">
		<?php }else{?>
	    <div class="article-grid grid-item ">
		<?php }$count++;?>	
          <div class="panel panel-block docs-panel-block">
            <a href="<?php the_permalink(); ?>" class="mind-thumb-image"><img class="wd-lazy" data-src="<?php echo wd_thumb();?>"></a>
            <div class="placeholder-title">
              <h3 class="panel-title h2"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
            </div>
            <div class="panel-body">
              <div class="panel-intro"><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 60, "…");?></div>
              <div class="profile-reply">
                <div class="mind-vote p-r-10">
                  <div class="text-center user-vote">
                    <section class="arrow-vote">
						<span class="vote-hover"><i class="iconfont icon-eye"></i></span>
						<span class="vote-total"><?php post_views(' ', ' '); ?></span>
	                    <a href="<?php the_permalink(); ?>" class="read-more" target="_blank">阅读更多</a>
                    </section>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>		
		<?php
            unset($post);
            $count++;
        endwhile;
    }else{
        echo 0; 
    }

    die();
}
function d_category(){

    $page = sanitize_text_field($_POST['data']['page']);
    $cat = sanitize_text_field($_POST['data']['cat']);

    $args = array(
        'cat'                 => $cat,
        'paged'               => $page,
        'post_type'   => 'post',
        'post_status' => 'publish',
        'ignore_sticky_posts' => 1,
    );
    $category_posts = new WP_Query( $args );

    if( $category_posts->have_posts() ){ 
        $count = 1;
        while( $category_posts->have_posts() ) : $category_posts->the_post();
            $post = get_post();
		?>
		<?php if(($count-1)%3 == 0){?>             	
	    <div class="article-grid grid-item first-item">
		<?php }elseif( $count%3 == 0){?>									
	    <div class="article-grid grid-item last-item">
		<?php }else{?>
	    <div class="article-grid grid-item ">
		<?php }$count++;?>	
          <div class="panel panel-block docs-panel-block">
            <a href="<?php the_permalink(); ?>" class="mind-thumb-image"><img class="wd-lazy" data-src="<?php echo wd_thumb();?>"></a>
            <div class="placeholder-title">
              <h3 class="panel-title h2"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
            </div>
            <div class="panel-body">
              <div class="panel-intro"><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 60, "…");?></div>
              <div class="profile-reply">
                <div class="mind-vote p-r-10">
                  <div class="text-center user-vote">
                    <section class="arrow-vote">
						<span class="vote-hover"><i class="iconfont icon-eye"></i></span>
						<span class="vote-total"><?php post_views(' ', ' '); ?></span>
	                    <a href="<?php the_permalink(); ?>" class="read-more" target="_blank">阅读更多</a>
                    </section>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>		
		<?php
            unset($post);
            $count++;
        endwhile;
    }else{
        echo 0; 
    }

    die();
}
function searchAll( $query ) {
  if ( $query->is_search ) { $query->set( 'post_type', array( 'post','product' )); } 
  return $query;
}
function wd_search_by_title_only( $search, &$wp_query ){
	global $wpdb;
 
	if ( empty( $search ) )
        return $search; // skip processing - no search term in query
 
    $q = $wp_query->query_vars;    
    $n = ! empty( $q['exact'] ) ? '' : '%';
 
    $search =
    $searchand = '';
 
    foreach ( (array) $q['search_terms'] as $term ) {
    	$term = esc_sql( like_escape( $term ) );
    	$search .= "{$searchand}($wpdb->posts.post_title LIKE '{$n}{$term}{$n}')";
    	$searchand = ' AND ';
    }
 
    if ( ! empty( $search ) ) {
    	$search = " AND ({$search}) ";
    	if ( ! is_user_logged_in() )
    		$search .= " AND ($wpdb->posts.post_password = '') ";
    }
 
    return $search;
}
function uazoh_custom_login_page() {
$excssz = av('excssz','#9aa6b9');
$exjbsz = av('exjbsz','#9aa6b9');
echo'<style type="text/css">#login form {-webkit-box-shadow:0 2px 5px 0 rgba(146,146,146,.1);-moz-box-shadow:0 2px 5px 0 rgba(146,146,146,.1);box-shadow:0 8px 25px 0 rgba(146,146,146,0.21);}#login form .forgetmenot{float:none}
#login form p.submit{padding: 20px 0 0;}#login form p.submit .button-primary{float:none;background-color: #494949;font-weight: bold;color: #fff;width: 100%;height: 40px;border-width: 0;border-color:none;background-color: '.$excssz.';background: -moz-linear-gradient(left,'.$excssz.','.$exjbsz.');background: -webkit-linear-gradient(left top,'.$excssz.','.$exjbsz.');background: -o-linear-gradient(left,'.$excssz.','.$exjbsz.');font-size:16px;letter-spacing: 10px;}#login form input{box-shadow:none!important;outline:none!important}
.login h1 a { background-image:url('.get_template_directory_uri().'/includes/images/login.png); width: 280px; max-height: 100px;margin: 20px auto 15px; background-size: contain;background-repeat: no-repeat;background-position: center center;}
</style>';
}
function reset_password_message( $message, $key ) {
 if ( strpos($_POST['user_login'], '@') ) {
 $user_data = get_user_by('email', trim($_POST['user_login']));
 } else {
 $login = trim($_POST['user_login']);
 $user_data = get_user_by('login', $login);
 }
 $user_login = $user_data->user_login;
 $msg = __('有人要求重设如下帐号的密码：'). "\r\n\r\n";
 $msg .= network_site_url() . "\r\n\r\n";
 $msg .= sprintf(__('用户名：%s'), $user_login) . "\r\n\r\n";
 $msg .= __('若这不是您本人要求的，请忽略本邮件，一切如常。') . "\r\n\r\n";
 $msg .= __('要重置您的密码，请打开下面的链接：'). "\r\n\r\n";
 $msg .= network_site_url("wp-login.php?action=rp&key=$key&login=" . rawurlencode($user_login), 'login') ;
 return $msg;
}
//FQ上传头像
function tizipu_ad( $description ) {
$description = '您可以在<a href="https://cn.gravatar.com/">Gravatar</a>修改您的资料图片。<br>当然这是需要翻墙才可以访问的：<a target="_blank" href="https://www.tizipu.net/aff.php?aff=25">点我购买翻墙加速服务【站长必备】</a>';
return $description; 
};
add_filter( 'user_profile_picture_description', 'tizipu_ad', 10, 1 );
//后台强制css
function custom_logo() {
  echo '<style type="text/css">
    #wp-admin-bar-wp-logo { display: none !important; }
	.form-field td img{width: 200px;}
	*{text-shadow:none!important;}
	.ybpjc{}
	.ybpjc h3{margin-top: -10px;background: #f3f2f2;padding: 2px 10px;}
	.jcbox li{padding-bottom:10px;line-height:26px;}
    </style>';
}
add_action('admin_head', 'custom_logo');
 //
function create_dwb_menu() {
  global $wp_admin_bar;
	$menu_id = 'dwb';
  $content = wp_remote_retrieve_body( wp_remote_get('https://ztmao.com/wp-json/wp/v2/posts?include=2753') );
  $content_obj = json_decode($content); #JSON内容转换为PHP对象
	if($content_obj){
		foreach ($content_obj as $key) {
			$bben = $key->version;
			$downlink = $key->link;
			$my_theme = wp_get_theme();
			$dqbb = $my_theme->get( 'Version' );
			if($dqbb < $bben){
			  $wp_admin_bar->add_menu(array('id' => $menu_id, 'title' => __('<span class="update-plugins count-2" style="display: inline-block;background-color: #d54e21;color: #fff;font-size: 9px;font-weight: 600;border-radius: 10px;z-index: 26;height: 18px;margin-right: 5px;"><span class="update-count" style="display: block;padding: 0 6px;line-height: 17px;">1</span></span>主题有更新，请及时查看！！！'), 'href' => $downlink));	
			}
		} 
	}
}
add_action('admin_bar_menu', 'create_dwb_menu', 2000);