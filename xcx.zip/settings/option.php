<?php
/**
*Author: Ashuwp
*Author url: http://www.ashuwp.com
*Version: 4.2
**/

/**Add the cod into your functions.php**/
require get_template_directory() . '/settings/include/ashuwp_framework_core.php'; //必须 加载核心类
require get_template_directory() . '/settings/include/ashuwp_options_feild.php'; //可选 设置页面
require get_template_directory() . '/settings/include/ashuwp_termmeta_feild.php'; //可选 分类字段
require get_template_directory() . '/settings/include/ashuwp_postmeta_feild.php'; //可选 文字字段
require get_template_directory() . '/settings/include/icons.php'; 
require get_template_directory() . '/settings/include/import_export.php'; //可选 设置选项导入导出
require get_template_directory() . '/settings/include/product.php';
/**
*Author: Ashuwp
*Author url: http://www.ashuwp.com
*Version: 4.4
**/

/**
*
*post meta test
*
**/
/*****Meta Box********/

$tab_meta = array();
$tab_conf = array('title' => '额外选项', 'id'=>'tab_box', 'page'=>array('post'), 'context'=>'normal', 'priority'=>'low', 'tab'=>true);
/**first**/
$tab_meta[] = array(
  'name' => '文章特色选项',
  'id'   => 'tab_one',
  'type' => 'open'
);
$tab_meta[] = array(
  'name'        => '特色图片',
  'id'          => 'thumb',
  'desc'        => '图形大小：448*240。展示优先顺序：特色图片->文章内图片->随机图（或默认图）',
  'std'         => '',
  'button_text' => '上传',
  'edit_only'   => true,
  'type'        => 'upload'
);
$tab_meta[] = array(
  'name' => '浏览量',
  'id'   => 'views',
  'desc' => '文章浏览量，嫌人气不高可以自己修改。',  
  'std'  => '',
  'type' => 'text'
);
$tab_meta[] = array(
  'type' => 'close'
);
$tab_meta[] = array(
  'name' => '文章SEO',
  'id'   => 'tab_two',
  'type' => 'open'
);
$tab_meta[] = array(
  'name' => '文章重写标题',
  'id'   => 'single_newtitles',
  'desc' => '如题，显示在head中的title。',
  'std'  => '',
  'type' => 'text'
);
$tab_meta[] = array(
  'name' => '文章关键词',
  'id'   => 'single_keywords',
  'desc' => '多个关键词用英文逗号隔开。',
  'std'  => '',
  'type' => 'text'
);
$tab_meta[] = array(
  'name' => '文章描述',
  'id'   => 'single_description',
  'desc' => '围绕关键词及标题进行造句。',
  'std'  => '',
  'type' => 'textarea'
);
$tab_meta[] = array(
  'type' => 'close'
);
$tab_box = new ashuwp_postmeta_feild($tab_meta, $tab_conf);
/**
*
*page meta test
*
**/
$tab_meta_page = array();
$tab_conf_page = array('title' => '文章SEO', 'id'=>'tab_box_page', 'page'=>array('page'), 'context'=>'normal', 'priority'=>'low', 'tab'=>false);
$tab_meta_page[] = array(
  'name' => '页面重写标题',
  'id'   => 'single_newtitles',
  'desc' => '如题，显示在head中的title。',
  'std'  => '',
  'type' => 'text'
);
$tab_meta_page[] = array(
  'name' => '页面关键词',
  'id'   => 'single_keywords',
  'desc' => '多个关键词用英文逗号隔开。',
  'std'  => '',
  'type' => 'text'
);
$tab_meta_page[] = array(
  'name' => '页面描述',
  'id'   => 'single_description',
  'desc' => '围绕关键词及标题进行造句。',
  'std'  => '',
  'type' => 'textarea'
);
$tab_box_page = new ashuwp_postmeta_feild($tab_meta_page, $tab_conf_page);
/**
*
*taxonomy feild test
*
**/
/*****taxonomy feild ******/
$ashu_feild = array();
$taxonomy_cof = array('category','post_tag');
$ashu_feild[] = array(
  'name'      => '分类重写标题',
  'id'        => 'category_newtitles',
  'desc'      => '如题重写替换默认title标签。',
  'std'       => '',
  'edit_only' => true,
  "type"      => "text"
);
$ashu_feild[] = array(
  'name'      => '分类关键词',
  'id'        => 'category_keywords',
  'desc'      => '填写分类关键词。',
  'std'       => '',
  'edit_only' => true,
  "type"      => "text"
);
$ashu_feild[] = array(
  'name'      => '分类描述',
  'id'        => 'category_description',
  'desc'      => '围绕关键词以及分类名进行造句即可。',
  'std'       => '',
  'edit_only' => true,
  "type"      => "textarea"
);
$ashuwp_termmeta_feild = new ashuwp_termmeta_feild($ashu_feild, $taxonomy_cof);

/**
*
*Optinos page
*
**/
/**General options**/
$page_info = array(
  'full_name' => '网站设置',
  'optionname'=>'general',
  'child'=>false,
  'filename' => 'generalpage',
  'tab'=>true  //注意加上'tab'=>true
);

$ashu_options = array();

$ashu_options[] = array(
  'name' => '基础设置',
  'id'   => 'option_tab1',
  'type' => 'open',
);

$ashu_options[] = array(
  'name'=>'网站logo',
  'id'=>'logo_url',
  'std'=> '',
  'desc'=>'可以上传，也可以直接填写地址，也可以直接替换本地文件。',
  'button_text' => '上传',
  'type' => 'upload'
);
$ashu_options[] = array(
  'name'=>'Favicon图标',
  'id'=>'favicon_url',
  'std'=> '',
  'desc'=>'可以上传，也可以直接填写地址，也可以直接替换本地文件。',
  'button_text' => '上传',
  'type' => 'upload'
);

$ashu_options[] = array(
  'name' => '网站底部',
  'id'   => 'dibufooter',
  'desc' => '自定义前台底部文字。',
  'std'  => '',
  'type' => 'textarea'
);
$ashu_options[] = array(
  'type' => 'close',
);
$ashu_options[] = array(
  'name' => '幻灯片设置',
  'id'   => 'option_tab2',
  'type' => 'open',
);
$ashu_options[] = array(
  'name'    => '开启幻灯片',
  'id'      => 'slion',
  'desc'    => '默认关闭，若开启，就必须填写下面三个幻灯片哦。',
  'std'     => '0',
  'subtype' => array(
    '1' => '是',
    '0' => '否',
  ),
  'type'    => 'radio'
);
for ($i = 1; $i <= 3; $i++) {
$ashu_options[] = array(
  'name' => '幻灯片'.$i,
  'type' => 'title',
  'desc' => '',
);	
$ashu_options[] = array(
  'name' => '标题'.$i ,
  'id'   => 'slitit'.$i ,
  'type' => 'text'
);
$ashu_options[] = array(
  'name' => '描述'.$i,
  'id'   => 'slides'.$i,
  'type' => 'text'
);
$ashu_options[] = array(
  'name'=>'图片地址'.$i,
  'id'=>'sliimg'.$i,
  'desc'=>'如果你想自己网站好看点，图片大小请裁剪到：687*280',
  'button_text' => '上传',
  'type' => 'upload'
);
$ashu_options[] = array(
  'name' => '跳转链接'.$i ,
  'id'   => 'sliherf'.$i ,
  'type' => 'text'
);
}	

$ashu_options[] = array(
  'type' => 'close',
);
$ashu_options[] = array(
  'name' => '首页/分类展示',
  'id'   => 'option_tab5',
  'type' => 'open',
);
$ashu_options[] = array(
  'name' => '首页展示',
  'type' => 'title',
  'desc' => '以下两项仅控制首页的小程序推荐和最新文章推荐。',
);	

$ashu_options[] = array(
  'name' => '小程序展示分类' ,
  'id'   => 'hm_porductcat' ,
  'desc'    => '首页，直接填写分类id，多个用英文逗号隔开（如填写“1”，则显示分类id“1”下面的所有小程序）。',  
  'type' => 'text'
);
$ashu_options[] = array(
  'name' => '展示小程序数量' ,
  'id'   => 'hm_porductcatnumb' ,
  'desc'    => '默认8。',  
  'type' => 'text'
);

$ashu_options[] = array(
  'name' => '文章展示分类' ,
  'id'   => 'hm_newcat' ,
  'desc'    => '首页，直接填写分类id，多个用英文逗号隔开（如填写“1”，则显示分类id“1”下面的所有文章）。',  
  'type' => 'text'
);
$ashu_options[] = array(
  'name' => '展示文章数量' ,
  'id'   => 'hm_newcatnumb' ,
  'desc'    => '默认8。',  
  'type' => 'text'
);

$ashu_options[] = array(
  'name' => '分类模板选项',
  'type' => 'title',
  'desc' => '如果你有分类id1、2、3,小程序分类填写了1，则2、3的分类模板都属于正常模板。',
);	
$ashu_options[] = array(
  'name' => '小程序分类' ,
  'id'   => 'cate_porductcat' ,
  'desc'    => '这里填写小程序分类id。',  
  'type' => 'text'
);
$ashu_options[] = array(
  'name' => '小程序数量' ,
  'id'   => 'cate_porductnumb' ,
  'desc'    => '这里填写小程序分类页展示数量。',  
  'type' => 'text'
);

$ashu_options[] = array(
  'type' => 'close',
);
$ashu_options[] = array(
  'name' => '功能选项',
  'id'   => 'option_tab11',
  'type' => 'open',
);
/*$ashu_options[] = array(
  'name'    => '开启文章title优化',
  'id'      => 'sseott',
  'desc'    => '在文章页面的title部分加入所属分类。如：标题 - 分类 - 网站名',
  'std'     => '0',
  'subtype' => array(
    '1' => '是',
    '0' => '否',
  ),
  'type'    => 'radio'
);*/
$ashu_options[] = array(
  'name'    => '是否禁止category',
  'id'      => 'nocategory',
  'desc'    => '分类链接里的category字符，开启后需要在固定链接处，点击更新或应用按钮；默认关闭。',
  'std'     => '0',
  'subtype' => array(
    '1' => '是',
    '0' => '否',
  ),
  'type'    => 'radio'
);
$ashu_options[] = array(
  'name'    => '是否压缩前台html',
  'id'      => 'yasuohtml',
  'desc'    => '压缩前台的html代码，默认关闭。仅供高端玩家玩耍。',
  'std'     => '0',
  'subtype' => array(
    '1' => '是',
    '0' => '否',
  ),
  'type'    => 'radio'
);
$ashu_options[] = array(
  'name'    => '是否开启nofollow',
  'id'      => 'nofollow',
  'desc'    => '此项仅针对于文章中的外链。',
  'std'     => '0',
  'subtype' => array(
    '1' => '是',
    '0' => '否',
  ),
  'type'    => 'radio'
);
$ashu_options[] = array(
  'name'    => '是否自动增加alt标签',
  'id'      => 'postalt',
  'desc'    => '此项仅针对于文章中的图像，即IMG标签中增加alt标签。',
  'std'     => '0',
  'subtype' => array(
    '1' => '是',
    '0' => '否',
  ),
  'type'    => 'radio'
);

$ashu_options[] = array(
  'type' => 'close',
);
$ashu_options[] = array(
  'name' => '颜色搭配',
  'id'   => 'option_tab3',
  'type' => 'open',
);
$ashu_options[] = array(
  'name'    => '网站整体变灰',
  'id'      => 'net_gray',
  'desc'    => '使网站变灰。',
  'std'     => '0',
  'subtype' => array(
    '1' => '是',
    '0' => '否',
  ),
  'type'    => 'radio'
);
$ashu_options[] = array(
  'name' => '背景渐变色设置说明',
  'type' => 'title',
  'desc' => '只有网站整体变灰关闭以后，以下色值才会生效。当色值一样时，就没有渐变效果了哈。自己多测试测试，选择自己喜欢的。',
);	
$ashu_options[] = array(
  'name' => '初始色值' ,
  'id'   => 'bjcssz',
  'desc'    => '',
  'type' => 'color'
);
$ashu_options[] = array(
  'name' => '渐变色值' ,
  'id'   => 'bjjbsz',
  'desc'    => '',
  'type' => 'color'
);
$ashu_options[] = array(
  'name' => 'LOGO&进度条渐变色',
  'type' => 'title',
  'desc' => '同背景渐变色说明。',
);	
$ashu_options[] = array(
  'name' => '初始色值' ,
  'id'   => 'excssz',
  'desc'    => '',
  'type' => 'color'
);
$ashu_options[] = array(
  'name' => '渐变色值' ,
  'id'   => 'exjbsz',
  'desc'    => '',
  'type' => 'color'
);

$ashu_options[] = array(
  'type' => 'close',
);
$ashu_options[] = array(
  'name' => '社交选项',
  'id'   => 'option_tab4',
  'type' => 'open',
);
$ashu_options[] = array(
  'name' => '新浪微博' ,
  'id'   => 'sfsina' ,
  'desc'    => '填写你的新浪微博地址',  
  'type' => 'text'
);
$ashu_options[] = array(
  'name'=>'微信二维码',
  'id'=>'sfwx',
  'desc'    => '上传或填写链接或直接替换本地文件',  
  'button_text' => '上传',
  'type' => 'upload'
);
$ashu_options[] = array(
  'name' => 'QQ链接' ,
  'id'   => 'sfqq' ,
  'desc'    => '填写你的QQ地址，不知道怎么找的，可以在shang.qq.com里申请。',  
  'type' => 'text'
);

$ashu_options[] = array(
  'type' => 'close',
);
$ashu_options[] = array(
  'name' => 'SEO设置',
  'id'   => 'option_tab6',
  'type' => 'open',
);
$ashu_options[] = array(
  'name' => '首页关键词',
  'id'   => 'home_keywords',
  'desc' => '多个关键词之间，请用英文逗号隔开。',
  'std'  => '',
  'type' => 'text'
);
$ashu_options[] = array(
  'name' => '首页描述',
  'id'   => 'home_description',
  'desc' => '一般围绕关键词与标题进行造句即可。',
  'std'  => '',
  'type' => 'textarea'
);
$ashu_options[] = array(
  'name' => '网站标题连接符',
  'id'   => 'page_sign',
  'desc' => '默认为 - ，你可以根据自己的喜好来选择，建议初次启用主题后设置，设置后少修改以免影响收录。',
  'std'  => '',
  'type' => 'text'
);

$ashu_options[] = array(
  'type' => 'close',
);
$ashu_options[] = array(
  'name' => 'SMTP设置',
  'id'   => 'option_tab10',
  'type' => 'open',
);
$ashu_options[] = array(
  'name'    => '是否开启SMTP',
  'id'      => 'smtp_switch',
  'desc'    => '如果主机商禁用了PHP Mail()，请使用SMTP发信。推荐使用企业QQ邮箱免费版。不会的话可以在左边搜索smtp。',
  'std'     => '0',
  'subtype' => array(
    '1' => '开启',
    '0' => '关闭',
  ),
  'type'    => 'radio'
);
$ashu_options[] = array(
  'name' => 'SMTP发信服务器',
  'id'   => 'smtp_host',
  'desc' => 'SMTP发信服务器，例如smtp.qq.com。',
  'std'  => '',
  'type' => 'text'
);
$ashu_options[] = array(
  'name' => 'SMTP发信服务器端口',
  'id'   => 'smtp_port',
  'desc' => 'SMTP发信服务器端口，不开启SSL时一般默认25，开启SSL一般为465。',
  'std'  => '',
  'type' => 'text'
);
$ashu_options[] = array(
  'name'    => '是否使用SSL连接',
  'id'      => 'smtp_ssl',
  'desc'    => 'SMTP发信服务器SSL连接，请相应修改端口。',
  'std'     => '0',
  'subtype' => array(
    '1' => '是',
    '0' => '否',
  ),
  'type'    => 'radio'
);
$ashu_options[] = array(
  'name' => 'SMTP发信用户名',
  'id'   => 'smtp_account',
  'desc' => 'SMTP发信用户名，一般为完整邮箱号。',
  'std'  => '',
  'type' => 'text'
);
$ashu_options[] = array(
  'name' => 'SMTP帐号密码',
  'id'   => 'smtp_pass',
  'desc' => '请正确填写密码。',
  'std'  => '',
  'type' => 'text'
);
$ashu_options[] = array(
  'name' => 'SMTP发信人昵称',
  'id'   => 'smtp_name',
  'desc' => '请填写昵称，避免非主流字体及符号。',
  'std'  => '',
  'type' => 'text'
);

$ashu_options[] = array(
  'type' => 'close',
);
$ashu_options[] = array(
  'name' => '添加代码',
  'id'   => 'option_tab8',
  'type' => 'open',
);
$ashu_options[] = array(
  'name' => '网站验证标签',
  'id'   => 'home_meta',
  'desc' => '出现在网站head中，主要用于验证网站。',
  'std'  => '',
  'type' => 'textarea'
);
$ashu_options[] = array(
  'name' => '网站统计',
  'id'   => 'tongji',
  'desc' => '本选项所填统计代码会出现在网站底部body前，如果需要在顶部head中加载，可以直接填写在网站验证标签选项里。',
  'std'  => '',
  'type' => 'textarea'
);


$ashu_options[] = array(
  'type' => 'close',
);
$option_page = new ashuwp_options_feild($ashu_options, $page_info);
/**
*
*import-export page
*
**/
/****import-export*****/
$icons_info = array(
  'full_name' => 'icon图标',
  'child'=>true,
  'parent_slug'=>'generalpage',
  'filename' => 'icons_page'
);
$icons_page = new ashuwp_option_icons_class($icons_info);
/**
*
*import-export page
*
**/
/****import-export*****/
$import_info = array(
  'full_name' => '导入/导出',
  'child'=>true,
  'parent_slug'=>'generalpage',
  'filename' => 'import_page'
);
$import_page = new ashuwp_option_import_class($import_info);
?>