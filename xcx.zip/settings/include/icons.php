<?php
/**
*Author: Ashuwp
*Author url: http://www.ashuwp.com
*Version: 4.2
**/

class ashuwp_option_icons_class {
  var $options;
  function __construct($options) {
    $this->options = $options;
    add_action( 'admin_menu', array(&$this, 'add_admin_menu') ); 
  }
  
  function add_admin_menu(){
    if( $this->options['child'] ){
      $parent_slug = $this->options['parent_slug'];
      add_submenu_page($parent_slug, $this->options['full_name'], $this->options['full_name'], 'edit_themes', $this->options['filename'], array(&$this, 'display'));
    }else{
      add_menu_page($this->options['full_name'], $this->options['full_name'], 'edit_themes', $this->options['filename'], array(&$this, 'display'));
    }
  }
  
  function display(){
  ?>
    <div class="wrap" style="background-color: #fff;padding:20px 50px;margin: 50px;">
      <h2>Icon图标</h2>
      <p>1、使用方法：&lt;i class="iconfont icon-xxx"&gt;&lt;/i&gt;</p>
      <p>2、主要方便您在编辑菜单时使用。【在您编辑菜单时，只需按上面的方法，将代码添加到菜单名字前面就可以了。】</p>
			<ul class="icon_lists clear">
			  <li>
			    <i class="icon iconfont icon-weibo"></i>
			    <div class="fontclass">icon-weibo</div></li>
			  <li>
			    <i class="icon iconfont icon-icon8"></i>
			    <div class="fontclass">icon-icon8</div></li>
			  <li>
			    <i class="icon iconfont icon-sousuo"></i>
			    <div class="fontclass">icon-sousuo</div></li>
			  <li>
			    <i class="icon iconfont icon-weixintubiao"></i>
			    <div class="fontclass">icon-weixintubiao</div></li>
			  <li>
			    <i class="icon iconfont icon-qqkongjian"></i>
			    <div class="fontclass">icon-qqkongjian</div></li>
			  <li>
			    <i class="icon iconfont icon-weixin"></i>
			    <div class="fontclass">icon-weixin</div></li>
			  <li>
			    <i class="icon iconfont icon-qq"></i>
			    <div class="fontclass">icon-qq</div></li>
			  <li>
			    <i class="icon iconfont icon-fuzhihuihua"></i>
			    <div class="fontclass">icon-fuzhihuihua</div></li>
			  <li>
			    <i class="icon iconfont icon-yinxiangbiji"></i>
			    <div class="fontclass">icon-yinxiangbiji</div></li>
			  <li>
			    <i class="icon iconfont icon-tijiao"></i>
			    <div class="fontclass">icon-tijiao</div></li>
			  <li>
			    <i class="icon iconfont icon-icon-test1"></i>
			    <div class="fontclass">icon-icon-test1</div></li>
			  <li>
			    <i class="icon iconfont icon-icon-test16"></i>
			    <div class="fontclass">icon-icon-test16</div></li>
			  <li>
			    <i class="icon iconfont icon-icon-test"></i>
			    <div class="fontclass">icon-icon-test</div></li>
			  <li>
			    <i class="icon iconfont icon-icon-appstore"></i>
			    <div class="fontclass">icon-icon-appstore</div></li>
			  <li>
			    <i class="icon iconfont icon-icon-test2"></i>
			    <div class="fontclass">icon-icon-test2</div></li>
			  <li>
			    <i class="icon iconfont icon-icon-test3"></i>
			    <div class="fontclass">icon-icon-test3</div></li>
			  <li>
			    <i class="icon iconfont icon-icon-test4"></i>
			    <div class="fontclass">icon-icon-test4</div></li>
			  <li>
			    <i class="icon iconfont icon-icon-test5"></i>
			    <div class="fontclass">icon-icon-test5</div></li>			    
			  <li>
			    <i class="icon iconfont icon-icon-test6"></i>
			    <div class="fontclass">icon-icon-test6</div></li>			    
			  <li>
			    <i class="icon iconfont icon-icon-test7"></i>
			    <div class="fontclass">icon-icon-test7</div></li>			    
			  <li>
			    <i class="icon iconfont icon-icon-test8"></i>
			    <div class="fontclass">icon-icon-test8</div></li>			    
			  <li>
			    <i class="icon iconfont icon-icon-test9"></i>
			    <div class="fontclass">icon-icon-test9</div></li>			    
			  <li>
			    <i class="icon iconfont icon-icon-test10"></i>
			    <div class="fontclass">icon-icon-test10</div></li>			    
			  <li>
			    <i class="icon iconfont icon-icon-test11"></i>
			    <div class="fontclass">icon-icon-test11</div></li>			    
			  <li>
			    <i class="icon iconfont icon-icon-test12"></i>
			    <div class="fontclass">icon-icon-test12</div></li>			    
			  <li>
			    <i class="icon iconfont icon-icon-test13"></i>
			    <div class="fontclass">icon-icon-test13</div></li>			    
			  <li>
			    <i class="icon iconfont icon-icon-test29"></i>
			    <div class="fontclass">icon-icon-test29</div></li>			    
			  <li>
			    <i class="icon iconfont icon-icon-test31"></i>
			    <div class="fontclass">icon-icon-test31</div></li>	
			  <li>
			    <i class="icon iconfont icon-icon-home"></i>
			    <div class="fontclass">icon-icon-home</div></li>	
			  <li>
			    <i class="icon iconfont icon-icon-test33"></i>
			    <div class="fontclass">icon-icon-test33</div></li>				    			    
			  <li>
			    <i class="icon iconfont icon-icon-me"></i>
			    <div class="fontclass">icon-icon-me</div></li>					    
			  <li>
			    <i class="icon iconfont icon-icon-hot"></i>
			    <div class="fontclass">icon-icon-hot</div></li>					    
			  <li>
			    <i class="icon iconfont icon-icon-test36"></i>
			    <div class="fontclass">icon-icon-test36</div></li>				    			    
			  <li>
			    <i class="icon iconfont icon-icon-test37"></i>
			    <div class="fontclass">icon-icon-test37</div></li>	
			  <li>
			    <i class="icon iconfont icon-icon-test38"></i>
			    <div class="fontclass">icon-icon-test38</div></li>			    
			  <li>
			    <i class="icon iconfont icon-icon-code"></i>
			    <div class="fontclass">icon-icon-code</div></li>			    
			  <li>
			    <i class="icon iconfont icon-icon-test40"></i>
			    <div class="fontclass">icon-icon-test40</div></li>				    
			  <li>
			    <i class="icon iconfont icon-icon-test41"></i>
			    <div class="fontclass">icon-icon-test41</div></li>				    
			  <li>
			    <i class="icon iconfont icon-icon-test42"></i>
			    <div class="fontclass">icon-icon-test42</div></li>				    
			  <li>
			    <i class="icon iconfont icon-querentijiao"></i>
			    <div class="fontclass">icon-querentijiao</div></li>	
			  <li>
			    <i class="icon iconfont icon-tijiao1"></i>
			    <div class="fontclass">icon-tijiao1</div></li>	
			  <li>
			    <i class="icon iconfont icon-yes"></i>
			    <div class="fontclass">icon-yes</div></li>	
			  <li>
			    <i class="icon iconfont icon-close"></i>
			    <div class="fontclass">icon-close</div></li>	
			  <li>
			    <i class="icon iconfont icon-caution"></i>
			    <div class="fontclass">icon-caution</div></li>	
			  <li>
			    <i class="icon iconfont icon-down"></i>
			    <div class="fontclass">icon-down</div></li>	
			  <li>
			    <i class="icon iconfont icon-up"></i>
			    <div class="fontclass">icon-up</div></li>	
			  <li>
			    <i class="icon iconfont icon-left"></i>
			    <div class="fontclass">icon-left</div></li>	
			  <li>
			    <i class="icon iconfont icon-right"></i>
			    <div class="fontclass">icon-right</div></li>	
			  <li>
			    <i class="icon iconfont icon-add"></i>
			    <div class="fontclass">icon-add</div></li>	
			  <li>
			    <i class="icon iconfont icon-reduce"></i>
			    <div class="fontclass">icon-reduce</div></li>	
			  <li>
			    <i class="icon iconfont icon-thetop"></i>
			    <div class="fontclass">icon-thetop</div></li>	
			  <li>
			    <i class="icon iconfont icon-triangle"></i>
			    <div class="fontclass">icon-triangle</div></li>	
			  <li>
			    <i class="icon iconfont icon-yes_b"></i>
			    <div class="fontclass">icon-yes_b</div></li>	
			  <li>
			    <i class="icon iconfont icon-close_b"></i>
			    <div class="fontclass">icon-close_b</div></li>	
			  <li>
			    <i class="icon iconfont icon-caution_b"></i>
			    <div class="fontclass">icon-caution_b</div></li>	
			  <li>
			    <i class="icon iconfont icon-question_b"></i>
			    <div class="fontclass">icon-question_b</div></li>	
			  <li>
			    <i class="icon iconfont icon-down_b"></i>
			    <div class="fontclass">icon-down_b</div></li>	
			  <li>
			    <i class="icon iconfont icon-up_b"></i>
			    <div class="fontclass">icon-up_b</div></li>	
			  <li>
			    <i class="icon iconfont icon-left_b"></i>
			    <div class="fontclass">icon-left_b</div></li>	
			  <li>
			    <i class="icon iconfont icon-right_b"></i>
			    <div class="fontclass">icon-right_b</div></li>	
			  <li>
			    <i class="icon iconfont icon-play"></i>
			    <div class="fontclass">icon-play</div></li>	
			  <li>
			    <i class="icon iconfont icon-lock"></i>
			    <div class="fontclass">icon-lock</div></li>	
			  <li>
			    <i class="icon iconfont icon-down_b"></i>
			    <div class="fontclass">icon-down_b</div></li>	
			  <li>
			    <i class="icon iconfont icon-phone"></i>
			    <div class="fontclass">icon-phone</div></li>	
			  <li>
			    <i class="icon iconfont icon-code"></i>
			    <div class="fontclass">icon-code</div></li>	
			  <li>
			    <i class="icon iconfont icon-eye"></i>
			    <div class="fontclass">icon-eye</div></li>	
			  <li>
			    <i class="icon iconfont icon-hide"></i>
			    <div class="fontclass">icon-hide</div></li>	
			  <li>
			    <i class="icon iconfont icon-refresh"></i>
			    <div class="fontclass">icon-refresh</div></li>	
			  <li>
			    <i class="icon iconfont icon-mail"></i>
			    <div class="fontclass">icon-mail</div></li>	
			  <li>
			    <i class="icon iconfont icon-home"></i>
			    <div class="fontclass">icon-home</div></li>	
			  <li>
			    <i class="icon iconfont icon-list"></i>
			    <div class="fontclass">icon-list</div></li>	
			  <li>
			    <i class="icon iconfont icon-user"></i>
			    <div class="fontclass">icon-user</div></li>	
			  <li>
			    <i class="icon iconfont icon-people"></i>
			    <div class="fontclass">icon-people</div></li>
			  <li>
			    <i class="icon iconfont icon-female"></i>
			    <div class="fontclass">icon-female</div></li>
			  <li>
			    <i class="icon iconfont icon-male"></i>
			    <div class="fontclass">icon-male</div></li>
			  <li>
			    <i class="icon iconfont icon-search"></i>
			    <div class="fontclass">icon-search</div></li>
			  <li>
			    <i class="icon iconfont icon-star"></i>
			    <div class="fontclass">icon-star</div></li>
			  <li>
			    <i class="icon iconfont icon-comment"></i>
			    <div class="fontclass">icon-comment</div></li>
			  <li>
			    <i class="icon iconfont icon-write"></i>
			    <div class="fontclass">icon-write</div></li>			    
			  <li>
			    <i class="icon iconfont icon-ranking"></i>
			    <div class="fontclass">icon-ranking</div></li>			    
			  <li>
			    <i class="icon iconfont icon-ranking1"></i>
			    <div class="fontclass">icon-ranking1</div></li>			    
			  <li>
			    <i class="icon iconfont icon-calendar"></i>
			    <div class="fontclass">icon-calendar</div></li>			    
			  <li>
			    <i class="icon iconfont icon-praise"></i>
			    <div class="fontclass">icon-praise</div></li>			    
			  <li>
			    <i class="icon iconfont icon-topic"></i>
			    <div class="fontclass">icon-topic</div></li>					    
			  <li>
			    <i class="icon iconfont icon-sofa"></i>
			    <div class="fontclass">icon-sofa</div></li>					    
			  <li>
			    <i class="icon iconfont icon-music"></i>
			    <div class="fontclass">icon-music</div></li>					    
			  <li>
			    <i class="icon iconfont icon-news"></i>
			    <div class="fontclass">icon-news</div></li>					    
			  <li>
			    <i class="icon iconfont icon-heart"></i>
			    <div class="fontclass">icon-heart</div></li>					    
			  <li>
			    <i class="icon iconfont icon-vip"></i>
			    <div class="fontclass">icon-vip</div></li>					    
			  <li>
			    <i class="icon iconfont icon-video"></i>
			    <div class="fontclass">icon-video</div></li>					    
			  <li>
			    <i class="icon iconfont icon-Share"></i>
			    <div class="fontclass">icon-Share</div></li>					    
			  <li>
			    <i class="icon iconfont icon-menu"></i>
			    <div class="fontclass">icon-menu</div></li>				    
			  <li>
			    <i class="icon iconfont icon-camera"></i>
			    <div class="fontclass">icon-camera</div></li>				    
			  <li>
			    <i class="icon iconfont icon-recharge"></i>
			    <div class="fontclass">icon-recharge</div></li>	
			  <li>
			    <i class="icon iconfont icon-dongman"></i>
			    <div class="fontclass">icon-dongman</div></li>				    
			  <li>
			    <i class="icon iconfont icon-icon-tutorial"></i>
			    <div class="fontclass">icon-icon-tutorial</div></li>			    
			</ul>
    </div>
		<link rel="stylesheet" type="text/css" href="http://at.alicdn.com/t/font_ormjd9900ctbj4i.css"/>
		<style type="text/css">
			.icon_lists{
  			width: 100% !important;
  			display: inline-block;
			}
			.icon_lists li{
			  float:left;
			  width: 180px;
			  height:180px;
			  text-align: center;
			  list-style: none !important;
			}
			.icon_lists .icon{
			  font-size: 42px;
			  line-height: 100px;
			  margin: 10px 0;
			  color:#333;
			  -webkit-transition: font-size 0.25s ease-out 0s;
			  -moz-transition: font-size 0.25s ease-out 0s;
			  transition: font-size 0.25s ease-out 0s;
			
			}
		</style>
  <?php
  }
}