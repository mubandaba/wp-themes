<?php get_header();?>
      <div class="page-main">
        <div class="container">
          <div class="main-content">
            <div class="content-row">
							<?php if (av('slion','0')==1) {include(locate_template('includes/slider.php'));}?>
              <div class="titlebar minapp-detail-conts-info">
                <span class="emphasize-bar"></span>
                <span class="minapp-detail-conts-inner-intro-des">新上架小程序</span>
                <ul class="minapp-tags-nav clearfix">
                	<?php $categories = explode(',', av('hm_porductcat','1'));foreach ($categories as $category) { ?>
                  <li><a href="<?php echo get_category_link($category);?>"><?php echo get_cat_name( $category ); ?></a></li>
                  <?php }?>
                </ul>
              </div>
              <div class="home-minapp-rows minapp-rows clearfix">
 								<?php 
								$hmporductcat = av('hm_porductcat','1');
								$hmporductcatnumb = av('hm_porductcatnumb','8');
								$args = array(
								    'post_type' => 'product',
								    'showposts'=> $hmporductcatnumb,
								    'cat'=> $hmporductcat,
								    'ignore_sticky_posts' => 1,
								);
						    $pdposts = new WP_Query($args);
								if ($pdposts->have_posts() ) : $count = 1;
								while($pdposts->have_posts()) : $pdposts->the_post();
								?> 
								<?php if(($count-1)%4 == 0){?>             	
                <dl class="minapp-grid first-item">
								<?php }elseif( $count%4 == 0){?>									
                <dl class="minapp-grid last-item">									
								<?php }else{?>
                <dl class="minapp-grid ">
								<?php }$count++;?>
                  <dt>
                    <a class="minapp-link" href="<?php the_permalink(); ?>">
                      <img class="minapp-icon" src="<?php echo get_post_meta($post->ID, "product_pic", true);?>" width="100"></a>
                  </dt>
                  <dd>
                    <a class="mod-qrcode" href="javascript:;">扫码</a>
                    <div class="mod-qrcode-modal">
                      <img src="<?php echo get_post_meta($post->ID, "product_ewm", true);?>">
                      <p>打开微信扫一扫</p>
                    </div>
                    <h3 class="minapp-name">
                      <a class="minapp-link" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <div class="minapp-infos clearfix">
                      <ul class="minapp-tags clearfix"><?php echo posts_tags(3)?></ul>
                    </div>
                  </dd>
                </dl>
							<?php endwhile; endif;wp_reset_query();?>
              </div>
              <div class="titlebar minapp-detail-conts-info">
                <span class="emphasize-bar"></span>
                <span class="minapp-detail-conts-inner-intro-des">最新文章</span>
                <ul class="minapp-tags-nav minapp-article-nav clearfix">
                	<?php $categories = explode(',', av('hm_newcat','1'));foreach ($categories as $category) { ?>
                  <a href="<?php echo get_category_link($category);?>"><?php echo get_cat_name( $category ); ?></a>
                  <?php }?>
                </ul>
              </div>
              <div class="row row-table-md article-rows">
								<?php 
								$hmnewcat = av('hm_newcat','1');
								$hmnewcatnumb = av('hm_newcatnumb','8');
						    $ncposts = new WP_Query();
						    $ncposts->query("showposts=$hmnewcatnumb&cat=$hmnewcat");
								if ($ncposts->have_posts() ) : $count = 1;
								while($ncposts->have_posts()) : $ncposts->the_post();
								?> 
								<?php if($count == 1){?>
								<div class="article-grid grid-item first-item first-line-first-item">
								<?php $numb = 120;?>	
								<?php }elseif($count == 2){?>
								<div class="article-grid grid-item first-line-last-item">	
								<?php $numb = 120;?>				
								<?php }elseif( $count%3 == 0){?>
								<div class="article-grid grid-item first-item ">
								<?php }elseif(($count-2)%3 == 0){?>
								<div class="article-grid grid-item last-item ">
								<?php }else{?>
								<div class="article-grid grid-item">	
								<?php $numb = 60;?>		
								<?php }$count++;?>
								  <div class="panel panel-block docs-panel-block">
								    <a href="<?php the_permalink(); ?>" class="mind-thumb-image"><img class="wd-lazy" data-src="<?php echo wd_thumb();?>"></a>
								    <div class="placeholder-title">
								      <h3 class="panel-title h2"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
								    </div>
								    <div class="panel-body">
								      <div class="panel-intro"><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, $numb, "…");?></div>
								      <div class="profile-reply">
								        <div class="mind-vote p-r-10">
								          <div class="text-center user-vote">
								            <section class="arrow-vote">
								              <span class="vote-hover"><i class="iconfont icon-eye"></i></span>
								              <span class="vote-total"><?php post_views(' ', ' '); ?></span>
								              <a href="<?php the_permalink(); ?>" class="read-more" target="_blank">阅读更多</a></section>
								          </div>
								        </div>
								      </div>
								    </div>
								  </div>
								</div>
								<?php endwhile; endif;wp_reset_query();?>  
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php get_footer();?>