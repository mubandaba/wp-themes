    <div class="page-footer clearfix">
      <footer id="footer" class="footer-bottom">
        <div class="container">
          <p class="f_bq"><?php echo av('dibufooter');?>
          &nbsp;Theme by <a href="https://ztmao.com" target="_blank" rel="nofollow" class="banquan">WordPress主题</a></p>
          <div class="friendly-links-wrapper">
          	友情链接：<?php wp_list_bookmarks('title_li=&categorize=0&before=&after='); ?>  
          </div>
        </div>
      </footer>
    </div>
	<?php wp_footer();?>
	<!--wp-compress-html--><!--wp-compress-html no compression--> 
	 <?php echo av('tongji');?>
	<!--wp-compress-html no compression--><!--wp-compress-html--> 		
  </body>
</html>