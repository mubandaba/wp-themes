<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh" lang="zh">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo av('favicon_url',get_template_directory_uri().'/includes/images/favicon.ico');?>">
    <?php include(locate_template('includes/title.php'));?>
		<!--[if lt IE 9]>
		<script src="//cdn.bootcss.com/html5shiv/r29/html5.min.js"></script>
		<script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
		<!--wp-compress-html--><!--wp-compress-html no compression--> 
		<?php echo av('home_meta');?>
		<!--wp-compress-html no compression--><!--wp-compress-html-->     
	<?php wp_head();?>
 </head>
  <body>
    <div class="page-wrapper">
      <div id="page-sidebar-left" class="page-sidebar">
        <div class="row">
          <div class="site-name">
            <a id="logo" href="<?php bloginfo('url');?>"><img src="<?php echo av('logo_url',get_template_directory_uri().'/includes/images/logo.png');?>" alt="<?php bloginfo('name');?>"></a>
            <nav id="nav-menu" role="navigation" style="position: relative; margin-top: 0px;">
            <?php wp_nav_menu(array('theme_location'=>'header','container' => false,'menu_id'=>'menu','depth'=>'0','items_wrap' => '%3$s','echo'=>true)); ?>
            </nav>	
          </div>
        </div>
      </div>
      <div class="site-search">
        <form id="search" method="get" action="<?php bloginfo('url');?>" role="search">
          <input type="text" name="s" id="s" class="text" placeholder="搜索...">
          <button type="submit" class="submit">
            <i class="iconfont icon-search" id="lime-search"></i>
          </button>
        </form>
        <div class="submit-minapp">
        	<?php if(is_user_logged_in()){?>
        	<a href="<?php bloginfo('url');?>/wp-admin/" target="_blank" class="submit-minapp-button"> 管理</a>
        	<?php }else{?>
        	<a href="<?php bloginfo('url');?>/wp-login.php" target="_blank" class="submit-minapp-button"> 登陆</a> 
        	<?php }?>
        	
        	 
        </div>
        <div class="socail-follow">
          <a href="javascript:;" class="socail-follow-wechat">
            <i class="iconfont icon-weixin"></i>
            <div class="mod-qrcode-modal" style="display: none;"><img src="<?php echo av('sfewm',get_template_directory_uri().'/includes/images/ewm.png');?>"></div>
          </a>
          <a href="<?php echo av('sfsina');?>" target="_blank" class="socail-follow-weibo"><i class="iconfont icon-weibo"></i></a>
          <a href="<?php echo av('sfqq');?>" target="_blank" class="socail-follow-qq"><i class="iconfont icon-qq"></i></a>
        </div>
      </div>
      

