<?php
// lark setup ------------------>
add_action( 'after_setup_theme', 'lark_setup' );
function lark_setup() 
{
	global $content_width;
	if ( ! isset( $content_width ) ) $content_width = 900;

	load_theme_textdomain( 'lark', get_template_directory() . '/languages' );

	add_theme_support('automatic-feed-links' );
	add_theme_support('title-tag' );
	add_theme_support('post-formats', array( 'aside', 'image', 'video', 'quote', 'link', 'gallery', 'status', 'audio', 'chat' ) );
	
	add_theme_support('html5', array('comment-form', 'comment-list', 'gallery', 'caption'	) );
	add_theme_support('customize-selective-refresh-widgets' );
	add_theme_support('post-thumbnails' );
		set_post_thumbnail_size( 150, 150,true ); 
		add_image_size('lark-post-medium', 400, 250, true );
		add_image_size('lark-post-big', 850,300, true );
		add_image_size('lark-post-single', 800,0, false );
		add_image_size('lark-post-wide', 1200,500, true );

	add_theme_support( 'custom-logo', array());
	add_theme_support( "custom-header", array(
		'width'        => 1600,
		'default-image'  => '',
		'height'        => 600,
		'header-text' => true,
		'video'              => true,
		'video-active-callback' => '',
		'default-text-color' => '#FFFFFF',
	));
	add_theme_support( "custom-background",  array(
		'default-color' => '#FFFFFF',
	) );

	register_nav_menus( array(
		'social'  => __( 'Social Menu','lark' ),
		'footer'  => __( 'Footer Menu','lark' ),
	) );
}

// lark sidebar setup ------------------>
add_action( 'widgets_init', 'lark_widgets_init' );
function  lark_widgets_init() {
	foreach(lark_sidebars() as $sidebar){
		register_sidebar($sidebar);
	}
}

// Theme customizer settings ------------------>
add_action( 'customize_register', 'lark_customize_register', 11 );
function lark_customize_register( $wp_customize ) 
{
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';
	$wp_customize->get_setting( 'background_color' )->transport = 'postMessage';

    if (isset($wp_customize->selective_refresh) ) {
        $wp_customize->selective_refresh->add_partial(
            'blogname', array(
            'selector' => '.site-title a',
            'container_inclusive' => false,
            'render_callback' => 'lark_customize_partial_blogname',
            ) 
        );
        $wp_customize->selective_refresh->add_partial(
            'blogdescription', array(
            'selector' => '.site-description',
            'container_inclusive' => false,
            'render_callback' => 'lark_customize_partial_blogdescription',
            ) 
        );
    }
	$colors_array =array(
			'header_background_color'=>array(
					'title'=>__('Header Background Color', 'lark' ),
					'default'           => '#222',
			),
			'footer_bg_color'=>array(
					'title'=>__('Footer Background Color', 'lark' ),
					'default'  => '#E0E0E0',
			),
			'wt_bg_color'=>array(
					'title'=>__('Widget Title Background Color', 'lark' ),
					'default'  => '#0270A0',
			),
			'bt_bg_color'=>array(
					'title'=>__('Button Background color', 'lark' ),
					'default'  => '#555555',
			),
			'wt_color'=>array(
					'title'=>__('Widget Title Color', 'lark' ),
					'default'  => '#FFFFFF',
			),
			'footer_color'=>array(
					'title'=>__('Footer Text Color', 'lark' ),
					'default'  => '#0270A0',
			),
			/*'bt_color'=>array(
					'title'=>__('Button Text Color', 'lark' ),
					'default'  => '#FFFFFF',
			),*/
			'link_color'=>array(
					'title'=>__('Link color', 'lark' ),
					'default'  => '#0270A0',
			),
		);

	foreach($colors_array as $index=>$color){
		$wp_customize->add_setting( $index, array(
			'default'           => $color['default'],
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage',
		));
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $index, array(
			'label'       => __('Lark', 'lark' ) .' - '.$color['title'],
			'section'     => 'colors',
		)));
	}
	$wp_customize->add_setting( 'footer_text', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_textarea_field',
	));
	$wp_customize->add_control('footer_text', array(
		'label'       => __('Lark - Footer Text ', 'lark' ),
		'section'     => 'title_tagline',
		'type' => 'textarea',
	));
}
add_action( 'customize_preview_init', 'lark_customize_preview_js' );
function lark_customize_preview_js() {
	wp_enqueue_script( 'lark-customize-preview', get_template_directory_uri() . '/assets/js/customize-preview.js', array( 'customize-preview' ), NULL, true );
}

// Adding scripts and CSS to theme ------------------>
add_action( 'wp_enqueue_scripts', 'lark_scripts' );
function lark_scripts() {
	$image=(array)get_custom_header();
	
	wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/assets/css/font-awesome.css', array(), null,'all');
	wp_enqueue_style( 'lark-style', get_stylesheet_uri(), array() ,null,'all');
	wp_enqueue_style( 'lark-responsive', get_template_directory_uri() . '/assets/css/responsive.css', array(), null,'all');

	$custom_css ='';
	if (!display_header_text() ) {
		$custom_css .= '.site-branding, .site-branding .site-title, .site-description {
			clip: rect(1px, 1px, 1px, 1px)!important;
			position: absolute!important;
			margin:0px !important;
		}';
	}

	$custom_css .= '#masthead{';
	if($image['url']){
		$custom_css .= 'background-image:url(\''.esc_url($image['url']).'\') !important;
			background-size:cover;
			background-repeat: no-repeat;
		'."\n";
	}	
	if($background_color=lark_replace_color_hash(get_theme_mod('header_background_color'))){
		$custom_css .= 'background-color:'.esc_attr($background_color).';'."\n";
	}
	$custom_css .= '}';
	
	if($header_textcolor=lark_replace_color_hash(get_header_textcolor())){
		$custom_css .= '#masthead, #masthead a, #masthead .site-header-menu ul li a { color: '.esc_attr($header_textcolor).';}'."\n";
	}
	if($wt_color=lark_replace_color_hash(get_theme_mod('wt_color'))){
		$custom_css .= '#secondary.sidebar .widget .widget-title{ color: '.esc_attr($wt_color).';}'."\n";
	}
	
	if($wt_bg_color=lark_replace_color_hash(get_theme_mod('wt_bg_color'))){
		$custom_css .= '#secondary.sidebar .widget .widget-title { background: '.esc_attr($wt_bg_color).';}
		#secondary.sidebar .widget { border-bottom-color: '.esc_attr($wt_bg_color).';}'."\n";	
	}
	
	$custom_css .= 'button, .button, input[type="submit"],input[type="reset"] {';
	if($bt_bg_color=lark_replace_color_hash(get_theme_mod('bt_bg_color'))){
		$custom_css .= 'background-color:'.esc_attr($bt_bg_color).';'."\n";
	}
	if($bt_color=lark_replace_color_hash(get_theme_mod('bt_color'))){
		$custom_css .= 'color:'.esc_attr($bt_color).';'."\n";
	}
	$custom_css .= '}';
	
	if($link_color=lark_replace_color_hash(get_theme_mod('link_color'))){
		$custom_css .= '#content a{	color:'.esc_attr($link_color).';}'."\n";
	}
	
	if($footer_bg_color=lark_replace_color_hash(get_theme_mod('footer_bg_color'))){
		$custom_css .= '#colophon{ background-color:'.esc_attr($footer_bg_color).';}'."\n";
	}
	
	if($footer_color=lark_replace_color_hash(get_theme_mod('footer_color'))){
		$custom_css .= '#colophon,#colophon a{color:'.esc_attr($footer_color).';}'."\n";
	}
	wp_add_inline_style( 'lark-style', $custom_css );

	if ( is_singular() ) { 
		wp_enqueue_script( "comment-reply" ); 
	}
	wp_enqueue_script( 'html5shiv',get_template_directory_uri().'/assets/js/html5.js', array( 'jquery' ), NULL, false );
	wp_script_add_data( 'html5shiv', 'conditional', 'lt IE 9' );
	wp_enqueue_script( 'lark-script', get_template_directory_uri() . '/assets/js/main.js', array( 'jquery' ), NULL, false );
}


// Handles JavaScript detection.Adds a `js` class to the root `<html>` element when JavaScript is detected.------------------>
add_action( 'wp_head', 'lark_javascript_detection', 0 );
function lark_javascript_detection() {
	echo "<script>(function(html){html.className = html.className.replace(/\bno-js\b/,'js')})(document.documentElement);</script>\n";
}

// Category transient flusher ------------------>
add_action( 'edit_category', 'lark_category_transient_flusher' );
add_action( 'save_post',   'lark_category_transient_flusher' );
function lark_category_transient_flusher() {
	delete_transient( 'lark_categories' );
}

// Linesh.com Latest news on your dashboard ------------------>
add_action('wp_dashboard_setup', 'lark_dashboard_widget' );
function lark_dashboard_widget() {
  wp_add_dashboard_widget('lj_dashboard_widget', 'Linesh.com - Latest Posts', 'linesh_com_rss_dashboard_widget');
}
function linesh_com_rss_dashboard_widget(){
	$rss = @fetch_feed( 'https://linesh.com/feed/' );
	if ( is_wp_error($rss) && ( is_admin() || current_user_can('manage_options') ) ) {
		echo '<div class="rss-widget"><p><strong>'.__('RSS Error','lark').'</strong> '.esc_html($rss->get_error_message()).'</p></div>';
	} elseif ( !$rss->get_item_quantity() ) {
		$rss->__destruct();
		unset($rss);
		return false;
	} else {
		echo '<ul class="lj-rss-widget">';
		$maxitems = $rss->get_item_quantity(10);
		$rss_items = $rss->get_items(0, $maxitems);
		foreach ($rss_items as $item){
			echo ' <li><a class="rsswidget" href="'.$item->get_permalink().'" />'.$item->get_title().'</a></li>';
		}
		//wp_widget_rss_output( $rss );
		echo '</ul>
		<style>
			#lj_dashboard_widget .inside{ 
				padding:0px;
				margin:0px;
			}
			#lj_dashboard_widget .lj-rss-widget{  margin:0px;}
			#lj_dashboard_widget .lj-rss-widget li{
				 padding: 9px 15px;
				 margin: 1px;
			}
			#lj_dashboard_widget .lj-rss-widget li:nth-child(even){
				background:#EEE;
			}
			#lj_dashboard_widget .lj-rss-widget li a{ display:block; font-size:14px;}
		</style>
		';
		$rss->__destruct();
		unset($rss);
	}
}
?>