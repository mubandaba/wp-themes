<?php
// Body class filter ------------------>
add_filter( 'body_class', 'lark_body_classes' );
function lark_body_classes( $classes ) {
	if ( get_background_image() ) { // Adds a class of custom-background-image to sites with a custom background image.
		$classes[] = 'custom-background-image';
	}
	if ( is_multi_author() ) { // Adds a class of group-blog to sites with more than 1 published author.
		$classes[] = 'group-blog';
	}
	if ( ! is_active_sidebar( 'sidebar-1' ) ) {// Adds a class of no-sidebar to sites without active sidebar.
		$classes[] = 'no-sidebar';
	}
	if ( ! is_singular() ) {// Adds a class of hfeed to non-singular pages.
		$classes[] = 'hfeed';
	}
	return $classes;
}

// Excerpt more ------------------>
add_filter( 'excerpt_more', 'lark_excerpt_more' );
function lark_excerpt_more( $more ) {
	if(! is_admin()){
		 /* translators: %s: Name of current post */
		$link = sprintf( '<span class="clear"></span><a href="%1$s" class="more-link read-more" rel="bookmark">%2$s</a>',esc_url( get_permalink( get_the_ID() ) ),sprintf( esc_html__( 'Continue Reading %s', 'lark' ), '<span class="screen-reader-text">'.get_the_title( get_the_ID() ).'</span><i class="fa fa-arrow-right"></i>' ));
		return '&hellip; ' . $link;
	}
}

// Archive title filter ------------------>
add_filter('get_the_archive_title','lark_filter_archive_title');	
function lark_filter_archive_title($title ){
	$rss='';
	if (is_search()){
		$title = '<span>'. esc_html__( 'Searching for:','lark' ).'</span><strong>"'.get_search_query().'"</strong>' ;
		
	}elseif ( is_category() ) {
		$title = '<strong>'.single_cat_title( '', false ).'</strong><span>'. esc_html__( 'Category','lark' ).'</span>' ;
		$rss=get_category_feed_link(get_query_var('cat'));
		
	} elseif ( is_tag() ) {
		$title = '<strong>'.single_tag_title( '', false ).'</strong><span>'. esc_html__( 'Tag Archive','lark' ).'</span>' ;
		$rss=get_tag_feed_link(get_query_var('tag_id')); 
		
	} elseif ( is_author() ) {
		$title = '<strong class="vcard">' . get_the_author() . '</strong><span>'. esc_html__( 'Author','lark' ).'</span>' ;
		$rss= get_author_feed_link(get_the_author_meta('ID'));
		
	} elseif ( is_year() ) {
		$title = '<strong>' .get_the_date( __( 'Y', 'lark' ) )  . '</strong><span>'. esc_html__( 'Yearly Archive','lark' ).'</span>' ;
		
	} elseif ( is_month() ) {
		$title = '<strong>' .get_the_date( __( 'F Y', 'lark' ) )  . '</strong><span>'. esc_html__( 'Monthly Archive ','lark' ).'</span>' ;
		
	} elseif ( is_day() ) {
		$title = '<strong>' .get_the_date( __( 'F j, Y', 'lark' ) )  . '</strong><span>'. esc_html__( 'Daily Archive','lark' ).'</span>' ;
		
	} elseif ( is_post_type_archive() ) {
		$title = '<strong>' .post_type_archive_title( '', false )  . '</strong>' ;
		$rss=get_post_type_archive_feed_link(get_query_var('post_type'));
		
	} elseif ( is_tax() ) {
		$tax = get_taxonomy( get_queried_object()->taxonomy );
		$term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );
		$title = '<strong>'.single_term_title('', false ).'</strong><span>'.$tax->labels->singular_name.'</span>' ;
		$rss=get_term_feed_link($term->term_id, get_query_var( 'taxonomy' ));
		
	 } else {
		$title ='<strong>'.esc_html__( 'All Posts' ,'lark').'</strong> <span>'.esc_html__( 'Blog Archives:' ,'lark').'</span>';
		$rss=get_bloginfo('rss2_url');
	}
	
	if($title && $rss){
		$title=$title.'<a href="'.$rss.'" title="'.esc_attr(__('Subscribe this','lark')).'" class="subscribe" rel="noopener noreferrer" target="_blank"><i class="fa fa-rss"></i><srong class="">'.esc_html__('Subscribe','lark').'</srong></a>	';
	}
	return $title;
}

// Page nvaigation template  ------------------>
add_filter('navigation_markup_template','lark_navigation_template');
function lark_navigation_template(){
	return $template = '
    <nav class="navigation %1$s" role="navigation">
        <h2 class="screen-reader-text">%2$s</h2>
        <div class="nav-links">%3$s
			<div class="clear"></div>
		</div>
    </nav>';
}
?>