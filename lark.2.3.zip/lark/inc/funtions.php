<?php /**
* More Functions file
*
* @category WordPress
* @package  Lark
* @author   Linesh Jose <lineshjos@gmail.com>
* @license  http://www.gnu.org/copyleft/gpl.html GNU General Public License
* @link     https://linesh.com/projects/lark/
*
*/

// Widhet spaces ------------------>
function lark_sidebars(){
	$sidebars=array(
	array(
		'name'          => __( 'Lark Widget Area', 'lark' ),
		'id'            => 'lark_sidebar',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'lark' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
		) 	
	);
	return $sidebars;
}

// checking for active sidebar  ------------------>
function lark_active_sidebars(){
	foreach(lark_sidebars() as $sidebar){
		if ( is_active_sidebar($sidebar['id']) ) {
			return true ;
		}else{
			continue;
		}
	}
	return false;
}

// Customizer settings ------------------>
function lark_customize_partial_blogname() {
	bloginfo( 'name' );
}
function lark_customize_partial_blogdescription() {
	bloginfo( 'description' );
}

// replace and add hash tag from color hexcode 
function lark_replace_color_hash($color_hex){
	if($color_hex=trim($color_hex)){
		return '#'.str_replace('#','',$color_hex);
	}
}

// Post entery metas ------------------>
function lark_entry_meta()
{
	$format = get_post_format();
	$formats_class=array(	
		'aside'=>'file-text',
		'image'=>'image',
		'video'=>'video-camera',
		'quote'=>'quote-left', 
		'link'=>'link',
		'gallery'=>'image',
		'status'=>'thumb-tack', 
		'audio'=>'music',
		'chat'=>'commenting-o',
	);
	$categories_list = get_the_category_list( ', ' );
	$tags_list = get_the_tag_list( '', ', ' );
	
	echo '<ul>';
	if ( is_sticky() && is_home() && ! is_paged() ) {
		echo '<li class="sticky-post"><i class="fa fa-bookmark"></i>'.esc_html__( 'Featured', 'lark' ).'</li>';
	}
	
	if ( current_theme_supports( 'post-formats', $format ) ) {
		echo '<li class="entry-format '.esc_attr($format).'">
			<i class="fa fa-'.esc_attr($formats_class[$format]).'"></i>
			<span class="screen-reader-text">'.esc_html__( 'Format:','lark' ) .'</span>
			<a href="'.esc_url(get_post_format_link($format)).'" title="'.esc_attr($format).' post">'.esc_html(get_post_format_string( $format )).'</a>
		</li>';
	}
	
	echo '<li class="posted-on">
		<i class="fa fa-calendar"></i>
		<span class="screen-reader-text">'.esc_html__( 'Posted on:', 'lark' ).'</span>
		<a href="'.esc_url( get_permalink()).'" rel="bookmark">
			<time class="entry-date published" datetime="'.esc_attr(get_the_date('c')).'">'.get_the_date().'</time>
			<time class="updated screen-reader-text" datetime="'.esc_attr( get_the_modified_date( 'c' ) ).'">'. esc_html(get_the_modified_date()).'</time>
		</a>
	</li>';
	
	echo '<li class="byline author vcard">
		<i class="fa fa-user"></i>
		<span class="screen-reader-text">'. esc_html__( 'Author:', 'lark' ).'</span>
		<a class="url fn n" href="'.esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ).'">'.esc_html(get_the_author()).'</a>
	</li>';
	
	if ( $categories_list && lark_categorized_blog() ) {
		echo '<li class="cat-links">
			<i class="fa fa-folder-open"></i>
			<span class="screen-reader-text">'. esc_html__( 'Categories:', 'lark' ).'</span>
			'.ent2ncr($categories_list).'
		</li>';
	}
	
	if ( $tags_list ) {
		echo '<li class="tag-links">
			<i class="fa fa-tags"></i>
			<span class="screen-reader-text">'. esc_html__( 'Tags:', 'lark' ).'</span>
			'.ent2ncr($tags_list).'
		</li>';
	}

	if ( is_attachment() && wp_attachment_is_image() ) {
		$metadata = wp_get_attachment_metadata();
		echo '<li class="full-size-link">
			<i class="fa fa-link"></i>
			<span class="screen-reader-text">'.esc_html__( 'Full size link:', 'lark' ).'</span>
			<a href="'.esc_url( wp_get_attachment_url() ).'">'.esc_html($metadata['width']).' &times; '.esc_html($metadata['height']).'</a>
		</li>';
	}
	
	if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
		echo '<li class="comment">
			<i class="fa fa-comments"></i>';
			comments_popup_link(esc_html__( 'Leave a comment', 'lark' ).'<span class="screen-reader-text">:&nbsp;'.get_the_title().'</span>');
		echo '</li>';
	}
	
	edit_post_link( esc_html__( 'Edit', 'lark' ), '<li class="edit-link"><i class="fa fa-pencil"></i>', '</li>' ); 
	echo '</ul>';
}

// Determines whether blog/site has more than one category. ------------------>
function lark_categorized_blog(){
	if ( false === ( $all_the_cool_cats = get_transient( 'lark_categories' ) ) ) {
		$all_the_cool_cats = get_categories( array(
			'fields'     => 'ids',
			'hide_empty' => 1,
			'number'     => 2,
		));
		$all_the_cool_cats = count( $all_the_cool_cats );
		set_transient( 'lark_categories', $all_the_cool_cats );
	}
	if ( $all_the_cool_cats > 1 ) {
		return true;
	} else {
		return false;
	}
}


// Post featured image ------------------>
function lark_post_thumbnail( $size='',$id=''){
	if( !($size=trim($size)) ){
		$size='medium';
	}
	if( !($id=trim($id)) ){
		$id=get_the_ID();
	}
	if(has_post_thumbnail($id)){ 
		echo '<div class="entry-thumbnail">
			<a class="" href="'.esc_url(get_the_permalink()).'">'.get_the_post_thumbnail( $id, $size, array( 'alt' => get_the_title() ) ).'</a>
		</div>';
	}
}

// Home page validation ------------------>
function lark_is_home_page(){
	if ( is_home() && is_front_page()) { 
		return true;
	}else{
		return false;	
	}
}


// Displays the optional custom logo ------------------>
function lark_the_custom_logo(){
	if ( function_exists( 'the_custom_logo' )  && has_custom_logo() ) {
		echo ' <div class="site-branding logo-active">';
		the_custom_logo();
	}else{
		echo ' <div class="site-branding">';
		if(lark_is_home_page()){
			echo '<h1 class="site-title"><a href="'.esc_url( home_url( '/' ) ).'" rel="home">'.esc_html(get_bloginfo( 'name' )).'</a></h1>';
		} else{
			echo '<p class="site-title"><a href="'.esc_url( home_url( '/' ) ).'" rel="home">'.esc_html(get_bloginfo( 'name' )).'</a></p>';
		}
	}
	if ( $description = get_bloginfo( 'description', 'display' )){
		/*if( !is_customize_preview()){
		$class="says";
		}*/
		echo '<p class="site-description">'.esc_html($description).'</p>';
	}
	echo '</div>';
}

// Author's meta ------------------>
function lark_author_metas($author_id){
	echo '<div class="author-metas">';
	if($post_count=count_user_posts($author_id)) { 
		echo '<a href='.esc_url(get_author_posts_url($author_id)).' title="'.esc_attr($post_count).' '.esc_attr('Posts', 'lark' ).'" class="posts"><i class="fa fa-thumb-tack"></i><span>'.esc_html($post_count).'</span></a>';
	}
	if($website=esc_url(get_the_author_meta('url',$author_id)) ){
		echo '<a href="'.esc_url($website).'" rel="noopener" target="_blank" class="social web" title="'. esc_attr__( 'Author\'s Website', 'lark' ).'"><i class="fa fa-globe"></i><span>'. esc_html__( 'Website', 'lark' ).'</span></a>';
	}
	echo '<a href="'.esc_url(get_author_feed_link($author_id )).'" rel="noopener"  title="'.esc_attr__( 'Subscribe RSS Feed', 'lark' ).'" target="_blank" class="social rss"><i class="fa fa-rss"></i><span>'.esc_html__( 'RSS Feed', 'lark' ).'</span></a>';
	echo '<div class="clear"></div>
	</div>';
}
?>