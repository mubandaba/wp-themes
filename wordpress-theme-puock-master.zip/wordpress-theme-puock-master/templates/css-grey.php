<?php

if(pk_is_checked('grey')): ?>
<style>
    html {
        filter: grayscale(100%);
        -webkit-filter: grayscale(100%);
        -moz-filter: grayscale(100%);
        -o-filter: grayscale(100%);
    }
</style>
<?php endif;