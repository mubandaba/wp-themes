<?php if(pk_is_checked('ad_g_bottom_c')): ?>
    <div class="puock-text p-block t-md ad-global-bottom">
        <?php echo pk_get_option('ad_g_bottom','') ?>
    </div>
<?php endif; ?>