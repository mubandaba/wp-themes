<?php if(pk_is_checked('ad_page_t_c')): ?>
    <div class="puock-text p-block t-md ad-page-top" style="padding:0">
        <?php echo pk_get_option('ad_page_t','') ?>
    </div>
<?php endif; ?>