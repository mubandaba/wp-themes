<?php
/*
* 本主题由君子不器（Junzibuqi.Com）分享
* 若是在使用该主题的过程中遇到问题，君子不器（Junzibuqi.Com）留言！当然你也可以直接加入君子不器QQ群：479928584和大家一起交流！
* 若是不想看到本段代码，可以按照下面君子不器的注释直接删除，删除后对主题无影响
*/
#删除开始
function junzibuqi_com_bangzhu() {
    add_menu_page('zhutishuom', '主题说明-必看', 'edit_theme_options', __FILE__, 'junzibuqi_com_toplevel_page');
}
function junzibuqi_com_toplevel_page() {
    echo '
    <div class="wrap">
    <h2>本主题由 <a href="http://junzibuqi.com">君子不器（Junzibuqi.Com）</a> 分享!</h2>    <div id="message" class="updated fade"><h3>若是在使用该主题的过程中遇到问题，欢迎前往 <a href="http://junzibuqi.com">君子不器（Junzibuqi.Com）</a> 留言！当然你也可以直接加入君子不器QQ群：479928584和大家一起交流！</h3></div>
    </div>
    ';
}
add_action('admin_menu', 'junzibuqi_com_bangzhu');
#删除结束
$purename = "PureViper";
$pureauthor = "梦月酱";
$purever = "2.2";
$pureweb = "http://www.wysafe.com";
require_once (TEMPLATEPATH . "/purex/purex-phpframework.php");
include (TEMPLATEPATH . "/functions-diy.php");

?>
