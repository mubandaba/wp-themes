﻿=== Friendly Lite ===

Contributors: dinesh1985singh
Requires at least: 4.7.0
Tested up to: 5.3.2
Requires PHP: 7.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: one-column, two-columns, left-sidebar, right-sidebar, custom-header, custom-background, threaded-comments, sticky-post, translation-ready, custom-menu, custom-colors, featured-images, post-formats, full-width-template, theme-options, blog, custom-logo

Friendly Lite is a theme built for variety of purposes from creating a simple blog to a complex news websites.

== Description ==

Friendly Lite is a translation ready responsive theme built on Twitter Bootstrap v3 with a huge customizing options straight from WordPress Customizer that let you build stunning blogs and websites. This theme is made as customizable as possible from the backend and thus makes it perfect for any need without any hard work at the users end. 
Friendly Lite is compatible with latest WordPress versions. 

This theme supports WordPress's core functionalities like:
 - custom logo 
 - custom background
 - custom header
 - custom menu
 - featured images
 
There are primary 2 widget areas:
 - The main widget area is in the blog sidebar.
 - Secondary widget area is at the bottom of the theme inside footer section which is further divided into Left, Right and Middle footer widgetize areas. 
 
There is only one menu location at present in our theme:
- The Primary menu location, is placed at the bottom of the header.

The Customizer options:
This theme doesn't include any options page. Everything is managed through the customizer itself. Friendly lite provide you many different options to manage different aspects of a website additionally to the default customizer options. Go to Appearance > Customize to see all available options.

 - The 'Page Layout' section let you set your Blog page, Post Page, Default page and archive page with left/right sidebar or no sidebar at all.
 - The 'General Settings' section allows you to toggle different features like displaying search form in Navbar, displaying posts in excerpt or full view on listing pages and so on. You can also set your copyright and read more link text from here as well. And most importatly this section also let you choose how many widgetize areas you want to display in footer section.
 - The 'Social Media' section let you disable/enable social icons in top header strip and at the bottom of the footer.
 - From 'Contat Info' section you can set or update email, phone and skype address in the top header strip.
 - The 'Color' section let you set or update background color and Header text color applicable to site title and tagline.

== Licenses & Credits ==

Friendly Lite is distributed under the terms of the GNU GPL v2.0 or later.
Feel free to use and modify this theme as you like.

Unless otherwise specified, all the theme files, scripts and images are created by us and licensed under the same license as the theme is.

= External resources linked to the theme. =
 
Raleway font
	Source: https://fonts.google.com/specimen/Raleway
	License: The SIL Open Font License, Version 1.1 
	License Url: https://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL

Open Sans
	Source: https://fonts.google.com/specimen/Open+Sans 
	License: The Apache License, Version 2.0 
	License Url: http://www.apache.org/licenses/LICENSE-2.0

Ubuntu Mono Font
	Source: https://fonts.google.com/specimen/Ubuntu+Mono
	License: The Ubuntu Font License
	License Url: https://design.ubuntu.com/font/

= Resources packed within the theme. =

Font Awesome 4.7.0
	Source: http://fontawesome.io
	Font license: The SIL OFL 1.1
	Font license Url: http://scripts.sil.org/OFL
	Code license: The MIT License
	Code License Url: https://opensource.org/licenses/mit-license.html

Bootstrap v3.3.7
	Source: http://getbootstrap.com/
	License: The MIT License Copyright (c) 2011-2016 Twitter, Inc.  
	License Url: https://github.com/twbs/bootstrap/blob/master/LICENSE

HTML5 Shiv 3.7.3
	Source: https://github.com/afarkas/html5shiv
	License: The MIT License Copyright (c) 2014 Alexander Farkas (aFarkas).
	License Url: https://github.com/aFarkas/html5shiv/blob/master/MIT%20and%20GPL2%20licenses.md

Respond.js v1.4.2
	Source: https://github.com/scottjehl/Respond
	License: The MIT License Copyright (c) 2012 Scott Jehl
	license Url : https://github.com/scottjehl/Respond/blob/master/LICENSE-MIT

normalize.css v3.0.3
	Source: https://github.com/necolas/normalize.css
	License: The MIT License Copyright (c) Nicolas Gallagher and Jonathan Neal
	license Url: https://github.com/necolas/normalize.css/blob/master/LICENSE.md

skip-link-focus-fix.js
	Source: https://github.com/Automattic/_s/blob/master/js/skip-link-focus-fix.js
	License: The GNU GPL v2.0, Same as Automattic's underscores(_s) theme.
	License Url: https://github.com/Automattic/_s/blob/master/LICENSE


== Images Screenshot ==

Image for theme screenshot
	Source: Self Made
	License: Same as theme

Image used as default header image
	Source: Self Made
	License: Same as theme

Unless otherwise specified, all the theme images are created by us and licensed under the same license as the theme is.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Is the theme Gutenberg ready? =
Well, partially. I am working on it to make it fully gutenberg compatible and it would be available very soon in the next update of the theme. 

= I have uploaded the header hero image, but it not visible to my site? =
Please make sure you have checked the option "Display hero image?" under Appearance > Customize > General Settings. Until you check it, Header Hero image would not be available. 

== Changelog ==

= 1.0.5 ( April 24, 2020 ) =
* Placed the header image back in assests's images directory, to fix the missing image in theme preview.

= 1.0.4 ( April 21, 2020 ) =
* Made the pingback conditional.
* Removed the header images from assests's images directory.

= 1.0.3 ( April 15, 2020 ) =
* Fixed the changelog dates typo except the very first release.
* Updated the var and constants prefixing and escaping.
* Removed bootstrap map files.
* Added original files for minified css/js files.  
* Added a call to wp_body_open().
* Updated the header image.
* Updated the screenshot image.
* Updated the image licenses.
* Removed dummy/default content set for contact info and social links.

= 1.0.2 ( March 28, 2020 ) =
* Updated Licensing formatting.

= 1.0.1 ( March 25, 2020 ) =
* Temporarily removed the theme URI from style.css.
* Updated the Contributer field to match the wordpress.org username.
* Added wp_body_open hook to make it backward compatible.
* Fixed the escaping issues.
* Added translation function for missing untranslated text.
* Fixed the 'Continue Reading' link on front page by removing front page(front-page.php) template.
* Removed the documentation license from readme.txt
* Updated the pot file to include missing unstranslated text. 

= 1.0.0 ( Dec 31, 2019 ) =
* Initial release
