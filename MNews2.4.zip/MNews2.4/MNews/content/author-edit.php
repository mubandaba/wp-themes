<?php global $salong; ?>
<section class="contribute">
    <?php echo salong_edit_post(); ?>
</section>
