<?php
//Chiser丶
//https://www.chiser.cc
require_once( trailingslashit( get_template_directory() ) . 'includes/functions.php' );
require_once( trailingslashit( get_template_directory() ) . 'includes/salong-functions.php' );
require_once( trailingslashit( get_template_directory() ) . 'includes/svg.php' );
