<?php

/**
* 为模板增加缩略图功能
*/
if ( function_exists( 'add_theme_support' ) ) {  
    add_theme_support( 'post-thumbnails' );  
}


/**
* 去掉多余的header代码
*/
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'feed_links_extra', 3 );
remove_action('wp_head', 'feed_links', 2 );
remove_action('wp_head', 'wp_shortlink_wp_head', 10, 0 );
remove_action('wp_head', 'index_rel_link');
remove_action('wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0 );

/**
* 屏蔽前台搜索功能
*/
add_filter('posts_search', 'disable_search_query_like');
function disable_search_query_like($arg){
    if(!is_admin()){
        return '';
    }else{
        return $arg;
    }
}

if(isset($_GET['s'])){
    add_filter('posts_request', 'disable_search_query');
}
function disable_search_query($arg){
    if(!is_admin()){
        return '';
    }else{
        return $arg;
    }
}

/**
* 移除文章图片的宽度和高度属性
*/
add_filter( 'post_thumbnail_html', 'remove_width_attribute', 10 );
add_filter( 'image_send_to_editor', 'remove_width_attribute', 10 );
 
function remove_width_attribute( $html ) {
   $html = preg_replace( '/(width|height)="\d*"\s/', "", $html );
   return $html;
}

?>