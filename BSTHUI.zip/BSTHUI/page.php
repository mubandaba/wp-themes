<?php get_header(); ?>


    <main role="main" class="container">
	
	<img src="http://so2x.com/imgs/banner.png" class="img-fluid" alt=" ">
	
	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
	
      <h1 class="mt-5"><?php the_title(); ?></h1>
	  
	  
      <?php the_content(); ?>
<?php endwhile; else: ?>
<p><?php _e('Sorry, this page does not exist.'); ?></p>
<?php endif; ?>
<?php edit_post_link(); ?>


    </main>
	
	<?php get_footer(); ?>

    