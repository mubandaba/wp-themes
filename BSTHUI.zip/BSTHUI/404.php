<?php get_header(); ?>


    <main role="main" class="container">
	
	
	
  <h1 class="mt-5">404错误！</h1>
	
      
	  
	  
  <p>内容不存在，或者被删除。请通过搜索，或者回到<a href="http://so2x.com" class="alert-link">SO2X首页</a>继续寻找你需要的内容。</p>
	  
	
	  



    </main>
	
	<?php get_footer(); ?>

    