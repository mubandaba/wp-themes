<?php get_header(); ?>


    <main role="main" class="container">


	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
      <div class="jumbotron">
        <h1><a target="_blank" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
        <p class="lead"><?php if (has_excerpt()) {
        echo $description = get_the_excerpt(); //文章编辑中的摘要
    }else {
        echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 170,"……"); //文章编辑中若无摘要，自定截取文章内容字数做为摘要
    } ?> <a target="_blank" href="<?php the_permalink(); ?>">阅读全文。。。</a></p>
        
      </div>
 
<?php  endwhile; endif; wp_reset_query(); ?> 
	  
	  
<?php if ( $wp_query->max_num_pages > 1 ) : ?>
<nav aria-label="Page navigation example">
<ul class="pagination">
<li class="page-item"><?php next_posts_link( __( '下一页', 'twentyten' ) ); ?></li>
<li class="page-item"><?php previous_posts_link( __( '上一页', 'twentyten' ) ); ?></li>
</ul>
</nav>	  
<?php endif; ?>

    </main>
	
	<?php get_footer(); ?>

    