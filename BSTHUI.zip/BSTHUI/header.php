<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
	
	<meta http-equiv="Cache-Control" content="no-transform " />
<meta name="applicable-device" content="pc,mobile">
<meta name="renderer" content="webkit">
	

    <title>
<?php if (function_exists('is_tag') && is_tag()) {
   single_tag_title('Tag Archive for "'); echo '" - ';
 } elseif (is_archive()) {
   wp_title(''); echo ' Archive - ';
 } elseif (is_search()) {
   echo 'Search for "'.wp_specialchars($s).'" - ';
 } elseif (!(is_404()) && (is_single()) || (is_page())) {
   wp_title(''); echo ' - ';
 } elseif (is_404()) {
   echo 'Not Found - ';
 }
if (is_home()) {
   bloginfo('name'); echo ' - '; bloginfo('description');
 } else {
   bloginfo('name');
}
   if ($paged > 1) {
   echo ' - page '. $paged;
 } ?>
</title>
	
    <!-- Bootstrap core CSS -->
    <link href="/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="/css/sticky-footer-navbar.css" rel="stylesheet">
  </head>

  <body>

    <header>
      <!-- Fixed navbar -->
      <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
        <a class="navbar-brand" href="http://so2x.com/">SO2X</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" href="http://so2x.com/">网站首页 <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="http://so2x.com/blog/">小小博客</a>
            </li>
			
			<li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle"  id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          相关资源
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="http://so2x.com/ziyuan/">SEO资源整理</a>
          <a class="dropdown-item" href="http://so2x.com/bsthui/">WP文章模板</a>
		  <a class="dropdown-item" href="http://so2x.com/suanfa/">算法记录</a>
        </div>
      </li>
	  
	  
            <li class="nav-item">
              <a class="nav-link" href="http://so2x.com/about/">联系方式</a>
            </li>
          </ul>
          <form class="form-inline mt-2 mt-md-0">
            <input class="form-control mr-sm-2" type="text" placeholder="站内搜索" aria-label="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">点击搜索</button>
          </form>
        </div>
      </nav>
    </header>