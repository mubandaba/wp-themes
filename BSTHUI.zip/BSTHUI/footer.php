

<footer class="footer">
      <div class="container">
        <span class="text-muted">SO2X © 2017 - 2019 / 自豪地由WordPress驱动 / <script type="text/javascript" src="https://js.users.51.la/19781665.js"></script></span>
		
		<?php if (is_home()) { ?>
<p>友情链接： <a href="http://so2x.com/links/" target="_blank">友链专页</a> / <a href="http://vpsping.com/" target="_blank">vps测评</a> </p>
<?php } else {?>
<?php } ?>

      </div>
    </footer>
	
    <script src="/js/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="/js/jquery-slim.min.js"><\/script>')</script>
    <script src="/js/popper.min.js"></script>
    <script src="/js/bootstrap.min.js"></script>
	
	<?php wp_footer(); ?>
	
	
  </body>
</html>
