<?php

?>

<aside class="aside">

<div class="contentBlock title category weibo">
<div class="title">
<h3 class="icon weibo">
<img src="/imgs/dummy.png" class="sprite">
公众号
</h3>
</div>
</div>
<div class="contentBlock content weibo">
<img width="100%" src="http://www.taishan168.com/wp-content/uploads/2018/02/weixin.jpg" alt="台山168公众号" >
</div>

<div class="contentBlock title category weibo">
<div class="title">
<h3 class="icon weibo">
<img src="/imgs/dummy.png" class="sprite">
微新闻
</h3>
</div>
</div>

<div class="contentBlock content weibo">
<div class="content">
<dl>
<dt>
<a href="http://www.taishan168.com/qita/133/" target="_blank">台山新宁体育馆场地价格表</a>
</dt>
 <dd>台山新宁体育馆场地价格表分为两个时间段，周一到周五、周末节假日...</dd>
 </dl>
 <dl>
 <dt>
 <a href="http://www.taishan168.com/keji/155/" target="_blank">6499元起的iPhone XR还有9天开售</a>
 </dt>
 <dd>iPhone XR采用了6.1英寸Liquid LCD视网膜显示屏，分辨率为1792×828、326PPI，提供白色...</dd>
 </dl>
 <dl>
 <dt>
 <a href="http://www.taishan168.com/zixun/71/" target="_blank">泰利吹向广东来的可能性不大</a>
</dt>
<dd>今年的广东经历了几个大型台风，其中还有直接经过台山的。台风泰利这段时间的生成，牵挂着...</dd>
</dl>
</div>
</div>

<div class="contentBlock title category recent">
<div class="title">
<h3 class="icon recent">
<img src="/imgs/dummy.png" class="sprite">
最新动态
</h3>
</div>
</div>

<div class="contentBlock content recent">
<div class="content">
<dl>
<dt>
<a href="http://www.taishan168.com/dxzf/" target="_blank">台山比较优惠的手机/光纤套餐介绍</a>
</dt>
<dd>
</dd>
</dl>
<dl>
<dt>
<a href="http://www.taishan168.com/keji/51/" target="_blank">市面上1080P屏的双摄手机推荐</a>
</dt>
<dd>
</dd>
</dl>
<dl>
<dt>
<a href="http://www.taishan168.com/zixun/64/" target="_blank">别让“礼让斑马线行人”成为空话</a>
</dt>
<dd>
</dd>
</dl>
</div>
</div>

</aside>