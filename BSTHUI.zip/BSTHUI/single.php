﻿<?php get_header(); ?>


    <main role="main" class="container">
	
	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
	
	 <nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item active" aria-current="page">现在的位置：<a href="/">SO2X首页</a>
 &raquo; 
<?php
if( is_single() ){
$categorys = get_the_category();
$category = $categorys[0];
echo( get_category_parents($category->term_id,true,' &raquo; ') );
} elseif ( is_page() ){
the_title();
} elseif ( is_category() ){
single_cat_title();
} elseif ( is_tag() ){
single_tag_title();
} elseif ( is_day() ){
the_time('Y年Fj日');
} elseif ( is_month() ){
the_time('Y年F');
} elseif ( is_year() ){
the_time('Y年');
} elseif ( is_search() ){
echo $s.' 的搜索结果';
}
?>
<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
</li>
  </ol>
</nav>

<img src="http://so2x.com/imgs/banner.png" class="img-fluid" alt=" ">
  
	
      <h1 class="mt-5"><?php the_title(); ?></h1>
	  
	 
	  
	  
	  
	  <p><span class="badge badge-primary">发布时间：<?php the_time('Y-m-d H:i') ?></span></p>
	  
	  
      <?php the_content(); ?>
<?php endwhile; else: ?>
<p><?php _e('Sorry, this page does not exist.'); ?></p>
<?php endif; ?>
<?php edit_post_link(); ?>


    </main>
	
	<?php get_footer(); ?>

    