<!DOCTYPE html>
<html <?php language_attributes( 'html' ); ?>>
<head>
<?php wp_head();  ?>
<!--[if lte IE 8]><script>window.location.href='http://www.mywpku.com/upgrade-your-browser.html?referrer='+location.href;</script><![endif]-->
<meta name="keywords" content="逆天,nitian,顾天,wordpress博客"><meta name="description" content="就这样我慢慢等待，等待你的身影破雾走来" />
</head>

<body <?php body_class(); ?> <?php omega_attr( 'body' ); ?>>

<?php do_action( 'omega_before' ); ?>

<div class="<?php echo omega_apply_atomic( 'site_container_class', 'site-container' );?>">

	<?php 
	do_action( 'omega_before_header' );
	do_action( 'omega_header' );
	do_action( 'omega_after_header' ); 
	?>

	<div class="site-inner">

		<?php do_action( 'omega_before_main' ); ?>