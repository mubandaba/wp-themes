<?php
?>
		<?php do_action( 'omega_after_main' ); ?>

	</div>
	<?php
	do_action( 'omega_before_footer' ); 
	do_action( 'omega_footer' ); 
	do_action( 'omega_after_footer' ); 
	?>
</div>
<?php do_action( 'omega_after' ); ?>

<?php wp_footer(); ?>
<script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F7ce966acb2667dd57217d7eed0a4df2d' type='text/javascript'%3E%3C/script%3E"));
</script>
</body>
</html>