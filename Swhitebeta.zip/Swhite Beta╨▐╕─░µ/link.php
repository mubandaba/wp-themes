<?php
/*
Template Name: Links
*/
?><?php
get_header(); ?>

	<main  class="<?php echo omega_apply_atomic( 'main_class', 'content' );?>" <?php omega_attr( 'content' ); ?>>
		<?php 
		do_action( 'omega_before_content' ); 

		do_action( 'omega_content' ); 

		do_action( 'omega_after_content' ); 
		?>
		<?php

$bookmarks = get_bookmarks();

if ( !empty($bookmarks) ){
    echo '<ul class="link-content clearfix">';
    foreach ($bookmarks as $bookmark) {
        echo '<li><a href="' . $bookmark->link_url . '" title="' . $bookmark->link_description . '" target="_blank" >'. get_avatar($bookmark->link_notes,64) . '<span class="sitename">'. $bookmark->link_name .'</span></a></li>';
    }
    echo '</ul>';
}

?>
	</main><!-- .content -->

<?php get_footer(); ?>
