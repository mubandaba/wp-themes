<?php
if ( post_password_required() || ( !have_comments() && !comments_open() && !pings_open() ) )
	return;

if ( is_singular( 'page' ) &&  !get_theme_mod( 'page_comment' ) )
	return;

?>

<div id="comments" class="entry-comments">

	<?php get_template_part( 'partials/comments-loop' );  ?>

</div>

<?php comment_form(); ?>
