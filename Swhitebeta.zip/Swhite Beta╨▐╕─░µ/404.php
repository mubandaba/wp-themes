<?php
get_header(); ?>

	<main class="content"  role="main">

			<section class="error-404 not-found">
				<header class="page-header">
					<h1 class="page-title"><?php _e( 'Oops! That page can&rsquo;t be found.', 'omega' ); ?></h1>
				</header>

				<div class="page-content">
					<p><?php echo sprintf( __( 'It looks like nothing was found at this location. Perhaps you can return back to the site\'s <a href="%s">homepage</a> and see if you can find what you are looking for. Or, you can try finding it by using the search form below.', 'omega' ), home_url() ); ?></p>

					<?php get_search_form(); ?>

				</div>
			</section>

	</main>

<?php get_footer(); ?>