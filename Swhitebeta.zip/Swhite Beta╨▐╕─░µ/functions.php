<?php
function cwp_header_clean_up(){
    if (!is_admin()) {
        foreach(array('wp_generator','rsd_link','index_rel_link','start_post_rel_link','wlwmanifest_link') as $clean){remove_action('wp_head',$clean);}
        remove_action( 'wp_head', 'feed_links_extra', 3 );
        remove_action( 'wp_head', 'feed_links', 2 );
        remove_action( 'wp_head', 'parent_post_rel_link', 10, 0 );
        remove_action( 'wp_head', 'start_post_rel_link', 10, 0 );
        remove_action( 'wp_head', 'adjacent_posts_rel_link', 10, 0 );
        foreach(array('single_post_title','bloginfo','wp_title','category_description','list_cats','comment_author','comment_text','the_title','the_content','the_excerpt') as $where){
         remove_filter ($where, 'wptexturize');
        }
        /*remove_filter( 'the_content', 'wpautop' );
        remove_filter( 'the_excerpt', 'wpautop' );*/
        wp_deregister_script( 'l10n' );
    }
}
function cwp_remove_dashboard_widgets() {
    global $wp_meta_boxes;
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_quick_press']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_incoming_links']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_right_now']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_plugins']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_recent_drafts']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_recent_comments']);
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_primary']);
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_secondary']);
}
add_action('wp_dashboard_setup', 'cwp_remove_dashboard_widgets',11 );
/* 加载框架 */
require ( trailingslashit( get_template_directory() ) . 'lib/framework.php' );
new Omega();

function omega_theme_setup() {
//禁用Open Sans
class Disable_Google_Fonts {
        public function __construct() {
                add_filter( 'gettext_with_context', array( $this, 'disable_open_sans'             ), 888, 4 );
        }
        public function disable_open_sans( $translations, $text, $context, $domain ) {
                if ( 'Open Sans font: on or off' == $context && 'on' == $text ) {
                        $translations = 'off';
                }
                return $translations;
        }
}
$disable_google_fonts = new Disable_Google_Fonts;
	/* 加载功能 */
	require get_template_directory() . '/lib/hooks.php';
	
	/* 缩略图 */
	add_theme_support( 'get-the-image' );
	
	/* 脚本 */
	add_theme_support( 
		'omega-scripts', 
		array( 'comment-reply' ) 
	);
	
	add_theme_support( 'omega-theme-settings' );

	add_theme_support( 'omega-content-archives' );

	/* 自定义模板层次 */
	//add_theme_support( 'omega-template-hierarchy' );

	/* 主题布局 (需添加样式表) */
	add_theme_support( 
		'theme-layouts', 
		array(
			'1c'        => __( '居中（去掉小工具）',           'omega' ),
			'2c-l'      => __( '居左', 'omega' ),
			'2c-r'      => __( '居右', 'omega' )
		),
		array( 'default' => is_rtl() ? '2c-r' :'2c-l', 'customize' => true ) 
	);
	
		
	/* 执行编辑样式，以使编辑内容相匹配*/
	add_editor_style();

	/* 分页支持 */
	add_theme_support( 'loop-pagination' );	

	/* 主题标题风格 */
	add_theme_support( 'cleaner-caption' );

	/* 评论 */
	add_theme_support( 'automatic-feed-links' );

	/* 启用包裹 */
	add_theme_support( 'omega-wraps' );

	/* 自定义CSS */
	add_theme_support( 'omega-custom-css' );
	
	/* 自定义头像 */
	add_theme_support( 'omega-custom-logo' );

	/* 页面 */
	add_theme_support( 'omega-child-page' );


	/* 图片大小 */
	omega_set_content_width( 640 );

}
add_action( 'after_setup_theme', 'omega_theme_setup' );	
add_filter( 'pre_option_link_manager_enabled', '__return_true' );