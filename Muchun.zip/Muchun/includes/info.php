<div class="gg">
<p>-----=====<strong> 博主信息 </strong>=====-----<br/>
<?php echo stripslashes(get_option('swt_information')); ?></p>
			<div class="clear"></div>
</div>