<div class="widget hot_box">	
	<h3>评论之星</h3>
		<ul class="readers clearfix">
		
			<?php Muchun_readers($out=get_option('swt_outer'),$timer=get_option('swt_timer'),$limit=get_option('swt_limit')); ?>
		</ul>
</div>
