   <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	<?php if (has_post_format( 'audio' )){ ?> <!--音频类型-->
				<div class="musicbg">
					<div class="musiccover"><img src="http://ceezi.com/img/defaultcover.png"></div>
					<div class="musicsep"></div>
					<div class="musicname"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></div>
					<div class="singer"><?php $key="演唱者"; echo get_post_meta($post->ID, $key, true); ?></div>
					<div class="zhuanji"><?php $key="所属专辑"; echo get_post_meta($post->ID, $key, true); ?></div>
					<div class="stars"><?php $key="歌曲评分"; echo get_post_meta($post->ID, $key, true); ?></div>
					<div class="flash"><embed src="<?php $key="音乐链接"; echo get_post_meta($post->ID, $key, true); ?>" quality='high' width='362' height='35' align='middle' type='application/x-shockwave-flash'  wmode='transparent' ></embed></div>
					<div class="musictimes">Played <?php if (function_exists('the_views')): ?><?php the_views(); ?><?php endif; ?> Times,</div>
					<div class="musiccom"><?php comments_popup_link('还没有乐评', '只有1条乐评', '已有%条乐评'); ?></div>
				</div>
				
				<div class="clear"></div>
				<?php } else if ( has_post_format('status')) { ?>
				<div class="status">
				<div class="statusavatar left">
				<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php echo get_avatar( get_the_author_email(), 56 ); ?></a>
				<div class="statustime"><?php echo past_date(); ?></div>
				</div>
				<div class="statusleft right">
				<div class="statustop"></div>
				<div class="statuscon"><?php the_content();?></div>
				<div class="clear"></div>
				<div class="statusfot"></div>
				</div>
				</div>
				<?php } else if ( has_post_format( 'image' )){ ?> <!--图像类型-->
				<div class="imgpost">
					<a href="<?php the_permalink(); ?> " rel="nofollow"><?php get_the_pic() ?></a>
					<h2 class="imgposth2">
						<a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a>
						
					</h2>
					
				</div>
			<?php } else { ?> <!--默认类型-->
    <h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark">
      <?php the_title(); ?>
      </a></h2>
    <div class="post-meta"> <span>
      <?php the_time('D,g:h A'); ?>
      </span>&nbsp;|&nbsp;<span>
      超过<?php if(function_exists('the_views')) { the_views(); } ?>人围观
      </span>&nbsp;|&nbsp;<span>
      <?php comments_popup_link('还没有评论', '只有1条评论', '已有%条评论'); ?>
      </span> </div>
    <!--.postMeta-->
    <div class="post-content">
      <?php the_content(__('readmore'));?>
    </div>
		<?php } ?>
    <div class="sep"></div>
    <?php endwhile; endif;?>