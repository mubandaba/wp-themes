<?php 
/*
Template Name:Search
*/
get_header(); 
?>
<div id="layout">
	<div id="contentbg">
<div class="content-header"></div>		
		
	    <div id="content">
		<div class="breadcrumbsclear"><div class="breadcrumbs"><li><a href="<?php bloginfo('url'); ?>">Home&nbsp;</a> &gt; <?php the_title(); ?></li></div></div>
			<blockquote>欢迎使用搜索功能</blockquote>
			<div id="search">
        <div class="search_pic">
          <?php get_search_form(); ?>
        </div>
      </div>
			

			
		</div>
		
	</div>

	<?php get_sidebar(); ?>
	<div class="clear"></div>  
	<?php get_footer(); ?>
</div>
<div class="clear"></div> 