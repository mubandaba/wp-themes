<?php


function get_the_pic() {
		global $post;
		$content = $post->post_content;
		preg_match_all('/<img.*?(?: |\\t|\\r|\\n)?src=[\'"]?(.+?)[\'"]?(?:(?: |\\t|\\r|\\n)+.*?)?>/sim', $content, $strResult, PREG_PATTERN_ORDER);
		echo '<a href="'.get_permalink().'"><img src="'.get_option('siteurl').'/wp-content/themes/iLeyar/timthumb.php?w=636&h=250&src='.$strResult[1][0].'" /></a>';
	}
	
function past_date() {global $post;$suffix = '前';$day = '天';$hour = '小时';$minute = '分钟';$second = '秒';$m = 60;$h = 3600;$d = 86400;$post_time = get_post_time('G', true, $post);$past_time = time() - $post_time;if ($past_time < $m) {$past_date = $past_time . $second;} else if ($past_time < $h) {$past_date = $past_time / $m;$past_date = floor($past_date);$past_date .= $minute;} else if ($past_time < $d) {$past_date = $past_time / $h;$past_date = floor($past_date);$past_date .= $hour;} else if ($past_time < $d * 30) {$past_date = $past_time / $d;$past_date = floor($past_date);$past_date .= $day;} else {echo get_post_time('n月j日');return;} echo $past_date . $suffix;}add_filter('past_date', 'past_date');

add_theme_support( 'post-formats', array( 'status', 'video', 'image', 'audio') );


function get_author_class($comment_author_email,$user_id){
    global $wpdb;
    $adminEmail = get_option('admin_email');
    $author_count  =  count($wpdb->get_results(
    "SELECT comment_ID as author_count FROM  $wpdb->comments WHERE comment_author_email = '$comment_author_email' "));
    if($comment_author_email ==$adminEmail) 
        echo '<a class="vp" target="_blank" href="http://ceezi.com" title="亲，这是博主啦。"></a>';
    if($user_id!=0 && $comment_author_email !=$adminEmail) 
        echo '<a class="vip" target="_blank" href="" title="听！我在说认证用户"></a>';
    if($author_count>=0 && $author_count<20 && $comment_author_email !==$adminEmail) 
        echo '<a class="vip1" target="_blank" href="" title="亲，博主才刚刚认识你！"></a>';
    else if($author_count>=20 && $author_count<50 && $comment_author_email !==$adminEmail) 
        echo '<a class="vip2" target="_blank" href="" title="亲，这是热心围观群众！"></a>';
    else if($author_count>=50 && $author_count<100 && $comment_author_email !==$adminEmail)
        echo '<a class="vip3" target="_blank" href="" title="亲，这是资深水王！"></a>';    
    else if($author_count>=100 && $author_count<150 && $comment_author_email !==$adminEmail) 
        echo '<a class="vip4" target="_blank" href="" title="亲，这不是QQ啊！"></a>';    
    else if($author_count>=150 &&$author_count<200 && $comment_author_email !==$adminEmail) 
        echo '<a class="vip5" target="_blank" href="" title="亲，数据库都让你刷爆了"></a>';    
    else if($author_count>=200 && $author_count<300 && $comment_author_email !==$adminEmail) 
        echo '<a class="vip6" target="_blank" href="" title="亲，数据库真的不行了~"></a>';    
    else if($author_count>=300 && $comment_author_email !==$adminEmail) 
        echo '<a class="vip7" target="_blank" href="" title="亲，法律已经无法阻挡你回复了。"></a>';    
}



	// Truncated text
	function cut_str($string, $sublen, $start = 0, $code = 'UTF-8')
	{
	 if($code == 'UTF-8')
	 {
	 $pa = "/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|\xe0[\xa0-\xbf][\x80-\xbf]|[\xe1-\xef][\x80-\xbf][\x80-\xbf]|\xf0[\x90-\xbf][\x80-\xbf][\x80-\xbf]|[\xf1-\xf7][\x80-\xbf][\x80-\xbf][\x80-\xbf]/";
	 preg_match_all($pa, $string, $t_string);
	 if(count($t_string[0]) - $start > $sublen) return join('', array_slice($t_string[0], $start, $sublen))."...";
	 return join('', array_slice($t_string[0], $start, $sublen));
	 }
	 else
	 {
	 $start = $start*2;
	 $sublen = $sublen*2;
	 $strlen = strlen($string);
	 $tmpstr = '';
	 for($i=0; $i<$strlen; $i++)
	 {
	 if($i>=$start && $i<($start+$sublen))
	 {
	 if(ord(substr($string, $i, 1))>129) $tmpstr.= substr($string, $i, 2);
	 else $tmpstr.= substr($string, $i, 1);
	 }
	 if(ord(substr($string, $i, 1))>129) $i++;
	 }
	 if(strlen($tmpstr)<$strlen ) $tmpstr.= "...";
	 return $tmpstr;
	 }
	}
	
	 /* 禁用自动保存 */
	remove_action('pre_post_update','wp_save_post_revision'); 
	add_action('wp_print_scripts','disable_autosave'); 
	function disable_autosave(){  wp_deregister_script('autosave'); }
	 /* Mini Pagenavi v1.0 by Willin Kan. */
	function pagenavi( $p = 2 ) {if ( is_singular() ) return; global $wp_query, $paged;$max_page = $wp_query->max_num_pages;if ( $max_page == 1 ) return; if ( empty( $paged ) ) $paged = 1;echo '<span class="pagescout">Page: ' . $paged . ' of ' . $max_page . ' </span> '; if ( $paged > $p + 1 ) p_link( 1, '第 1 页' );if ( $paged > $p + 2 ) echo '... ';for( $i = $paged - $p; $i <= $paged + $p; $i++ ) { if ( $i > 0 && $i <= $max_page ) $i == $paged ? print "<span class='page-numbers current'>{$i}</span> " : p_link( $i );}if ( $paged < $max_page - $p - 1 ) echo '... ';if ( $paged < $max_page - $p ) p_link( $max_page, '最末页' );}
	function p_link( $i, $title = '' ) { if ( $title == '' ) $title = "第 {$i} 页";echo "<a class='page-numbers' href='", esc_html( get_pagenum_link( $i ) ), "' title='{$title}'>{$i}</a> ";}
	//END 
	// comment_mail_notify v1.0 by willin kan. (所有回覆都發郵件)
	function comment_mail_notify($comment_id) {
	$comment = get_comment($comment_id);
	$parent_id = $comment->comment_parent ? $comment->comment_parent : '';
	$spam_confirmed = $comment->comment_approved;
	if (($parent_id != '') && ($spam_confirmed != 'spam')) {
	$wp_email = 'no-reply@' . preg_replace('#^www\.#', '', strtolower($_SERVER['SERVER_NAME'])); //e-mail 發出點, no-reply 可改為可用的 e-mail.
	$to = trim(get_comment($parent_id)->comment_author_email);
	$subject = '你在 [' . get_option("blogname") . '] 的留言有了新回复';
	$message = '

	<div style="background-color:#eef2fa; border:1px solid #d8e3e8; color:#111; padding:0 15px; -moz-border-radius:5px; -webkit-border-radius:5px; -khtml-border-radius:5px; border-radius:5px;">
	<p><strong>' . trim(get_comment($parent_id)->comment_author) . ', 你好!</strong></p>
	<p><strong>您曾在《' . get_the_title($comment->comment_post_ID) . '》的留言为:</strong><br />'
	. trim(get_comment($parent_id)->comment_content) . '</p>
	<p><strong>' . trim($comment->comment_author) . ' 给你的回复是:</strong><br />'
	. trim($comment->comment_content) . '<br /></p>
	<p>你可以点击此链接 <a href="' . htmlspecialchars(get_comment_link($parent_id)) . '">查看完整内容</a></p><br />
	<p>欢迎再次来访<a href="' . get_option('home') . '">' . get_option('blogname') . '</a></p>
	<p>(此邮件为系统自动发送，请勿直接回复.)</p>
	</div>';

	$from = "From: \"" . get_option('blogname') . "\" <$wp_email>";
	$headers = "$from\nContent-Type: text/html; charset=" . get_option('blog_charset') . "\n";
	wp_mail( $to, $subject, $message, $headers );
	  }
	}
	add_action('comment_post', 'comment_mail_notify');
	
	add_filter('got_rewrite', 'nginx_has_rewrites');
function nginx_has_rewrites() {
    return true;
}


add_filter('the_content', 'hlHighSlide_replace', '99');
add_action('wp_head', 'highslide_head');

    function highslide_head()
    {
    $hlHighslide_wp_url=get_bloginfo('template_url').'/';
    $defaults_javascript =  
    "\n\t<link href='{$hlHighslide_wp_url}highslide.css' rel='stylesheet' type='text/css' />
		<!--[if IE 6]>
		<link href='{$hlHighslide_wp_url}highslide-ie6.css' rel='stylesheet' type='text/css' />
		<![endif]-->
        <script type='text/javascript' src='{$hlHighslide_wp_url}highslide.js'></script>
    <script type='text/javascript'>
	hs.showCredits = false;  
    hs.graphicsDir = '{$hlHighslide_wp_url}graphics/';
	hs.wrapperClassName = 'wide-border';
    hs.align = 'center';
        hs.transitions = ['expand', 'crossfade'];
        hs.fadeInOut = true;
        hs.dimmingOpacity = 0.3;
		//hs.padToMinWidth = true;
        if (hs.addSlideshow) hs.addSlideshow({
            interval: 5000,
            repeat: false,
            useControls: true,
            fixedControls: 'fit',
            overlayOptions: {
                opacity: .6,
                position: 'bottom center',
                hideOnMouseOut: true
            }
        });
        hs.lang={
    loadingText :     '图片加载中...',
    loadingTitle :    '正在加载图片',
        closeText :       '关闭',
    closeTitle :      '关闭 (Esc)',
        moveTitle :       '移动图片',
        moveText :        '移动',
        restoreTitle :    '点击可关闭或拖动',
        fullExpandTitle : '点击查看原图',
        fullExpandText :  '查看原图'
        };
        hs.registerOverlay({
    html: '<div class=\"closebutton\" onclick=\"return hs.close(this)\" title=\"Close\"></div>',
    position: 'top right',
    fade: 2 // fading the semi-transparent overlay looks bad in IE
        });
        hs.Expander.prototype.onMouseOut = function (sender) {
        sender.close();
        };
        hs.Expander.prototype.onAfterExpand = function (sender) {
        if (!sender.mouseIsOver) sender.close();
         }
         </script>";
 echo $defaults_javascript;
 }
//add onclick event 
function add_onclick_replace ($content)
{ 
$pattern = "/<a(.*?)href=('|\")([^>]*).(bmp|gif|jpeg|jpg|png)('|\")(.*?)>(.*?)<\/a>/i";
$replacement = '<a$1href=$2$3.$4$5 class="highslide"  onclick="return hs.expand(this)" $6>$7 </a>';
$content = preg_replace($pattern, $replacement, $content);
return $content;
}
function hlHighSlide_replace($content)
{
        global $post;
        $defaults = array();
        $defaults['quicktags'] = 'y';
        $defaults['alt'] = 'Enter ALT Tag Description';
        $defaults['title'] = 'Enter Caption Text';
        $defaults['thumbid'] = 'thumb1';
        $defaults['show_caption'] = 'y';
        $defaults['show_close'] = 'y';
        $content=add_onclick_replace($content);
        $HSVars = array("SRC", "ALT", "TITLE", "WIDTH", "HEIGHT","THUMBID");
        $HSVals = array($defaults['href'], $defaults['src'], $defaults['alt'], $defaults['title'], $defaults['thumbid']);
        preg_match_all ('!<img([^>]*)[ ]*[/]{1}>!i', $content, $matches);
        $HSStrings = $matches[0];
        $HSAttributes = $matches[1];
        for ($i = 0; $i < count($HSAttributes); $i++)
        { preg_match_all('!(src|alt|title|width|height|class)="([^"]*)"!i',$HSAttributes[$i],$matches);
          $HSSetVars = $HSSetVals = array();
          for ($j = 0; $j < count($matches[1]); $j++)
            { $HSSetVars[$j] = strtoupper($matches[1][$j]);
              $HSSetVals[$j] = $matches[2][$j];}
		}
        $HSClose = <<<EOT
                <a href="#" onclick="hs.close(this);return false;" class="highslide-close"  title="关闭">Close</a>  
EOT;
                $HSCaption = <<<EOT
                <div class='highslide-caption' id='caption-for-%THUMBID%'>
                {$HSPrvNextLinks}           
                {$HSClose}  
                <div style="clear:both">%TITLE%</div>
                </div>
EOT;
            $HSCode = <<<EOT
<img id="%THUMBID%" src="%SRC%" alt="%ALT%" title="%TITLE%" width="%WIDTH%"  height="%HEIGHT%" />{$HSCaption}
EOT;
          $content = str_replace($HSStrings[$i], $HSCode, $content);
        return $content;
    }
	
add_action('media_buttons_context',  'add_my_custom_button');function add_my_custom_button($context) {$img = '<img src="' . get_bloginfo('template_url') . '/images/ddm.png" width="15" height="15" />';$context .='<a href="#" id="ddm-button" title="短代码" class="thickbox">' . $img . '</a>';return $context;}add_action('admin_footer', 'media_upload_for_upyun');function media_upload_for_upyun(){ ?>
<div id="ddm-lay"></div>
<div id="ddm-box">
  <div id="ddm-content" class="cfx">
    <ul id="ddm-cate">
      <li><a href="#" class="current">静态面板短代码</a></li>
      <li><a href="#">新版静态面板短代码</a></li>
      <li><a href="#">按钮短代码</a></li>
      <li><a href="#">音乐</a></li>
      <li><a href="#">视频播放短代码</a></li>
    </ul>
    <ul id="ddm-ddm">
      <li class="cfx current">
        <p>旧版</p>
        <a href="1">下载面板</a><a href="2">警告面板</a><a href="3">介绍面板</a><a href="4">文本面板</a><a href="5">教程面板</a><a href="6">项目面板</a><a href="7">错误面板</a><a href="8">提问面板</a><a href="9">链接面板</a><a href="10">代码面板</a></li>
      <li class="cfx">
        <p>新版</p>
        <a href="11">下载面板</a><a href="12">警告面板</a><a href="13">介绍面板</a><a href="14">文本面板</a><a href="15">教程面板</a><a href="16">项目面板</a><a href="17">错误面板</a><a href="18">提问面板</a><a href="19">链接面板</a><a href="20">代码面板</a></li>
      <li class="cfx"><a href="21">下载按钮</a><a href="22">爱心图标</a><a href="23">文本图标</a><a href="24">盒子图标</a><a href="25">搜索图标</a><a href="26">文档图标</a><a href="27">链接图标</a><a href="28">箭头图标</a><a href="29">音乐图标</a></li>
      <li class="cfx"><a href="30">音乐</a><a href="31">音乐(可自动播放)</a></li>
      <li class="cfx"><a href="33">优酷</a><a href="34">土豆</a><a href="35">酷6</a><a href="36">音悦台</a></li>
    </ul>
    <a id="ddm-close" href="#">X</a></div>
</div>
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/ie7.css" type="text/css" media="all">
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.ddm.js"></script>	
<?php }
include_once('functions/shortcode.php');
include_once('functions/basefunctions.php');
include_once('functions/archives.php');
include_once('functions/themeset.php');
include_once('functions/newerwidget.php');
include_once('functions/commentlists.php');


	




?>