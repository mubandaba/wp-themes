<?php
////////////////ThemeOptions
	class NewerOptions {
	function getOptions() {
		$options = get_option('Newer_options');
		if (!is_array($options)) {
			
			$options['description_content'] = '';
			
			$options['footercode'] = '';
		
			
		
				
		
			/*关于*/			
			$options['about_img'] = '';
			$options['about_content'] = '';
			$options['about_title'] = '';
			
				
			update_option('Newer_options', $options);
		}
		return $options;
	}
	/* -- 初始化 -- */
	function init() {
		if(isset($_POST['Newer_save'])) {
			$options = NewerOptions::getOptions();
			// 数据限制		
			
			$options['description_content'] = stripslashes($_POST['description_content']);
						
			$options['footercode'] = stripslashes($_POST['footercode']);

		
			
			
			
			/*关于*/
				$options['about_img'] = stripslashes($_POST['about_img']);
				$options['about_content'] = stripslashes($_POST['about_content']);
				$options['about_title'] = stripslashes($_POST['about_title']);	
				
			
			
			
			
			
			update_option('Newer_options', $options);
			echo "<div id='message' class='updated fade'><p><strong>设置已保存</strong></p></div>";
		} else {NewerOptions::getOptions();	}
		
		add_theme_page("主题设置", "主题设置", 'edit_themes', basename(__FILE__), array('NewerOptions', 'display'));
	}

	/* -- 标签页 -- */
	function display() {
		$options = NewerOptions::getOptions();
?>



 
 <style type="text/css">
.wrap{padding:10px; font-size:12px; line-height:24px;color:#383838;}
.devetable td{vertical-align:top;text-align: left;border:none ;font-size:12px; }
.top td{vertical-align: middle;text-align: left; border:none;font-size:12px;}
.submit {
    border-color: #DFDFDF;
    margin-left: 15px;
}
table{border:none;font-size:12px;}
pre{white-space: pre;overflow: auto;padding:0px;line-height:19px;font-size:12px;color:#898989;}
strong{ color:#666}
textarea{ width:100%; margin:0 20px 0 0;  overflow:auto}
.none{display:none;}
fieldset{ border:1px solid #ddd;margin:5px 0 10px;padding:10px 10px 20px 10px;-moz-border-radius:5px;-khtml-border-radius:5px;-webkit-border-radius:5px;border-radius:5px;}
fieldset:hover{border-color:#bbb;}
fieldset legend{padding:0 5px;color:#777;font-size:14px;font-weight:700;cursor:pointer}
fieldset .line{border-bottom:1px solid #e5e5e5;padding-bottom:15px;}
fieldset textarea{ padding:5px 5px;line-height:12px;-moz-border-radius:3px;-khtml-border-radius:3px;-webkit-border-radius:3px;border-radius:3px;}
</style>


<script type="text/javascript">
jQuery(document).ready(function($){  
$(".toggle").click(function(){$(this).next().slideToggle('slow')});
});
</script>



<form action="#" method="post" enctype="multipart/form-data" name="Newer_form" id="Newer_form" />

	<div class="wrap">

					<h2>主题设置</h2>
<table width="800" border="1" class="devetable">					
					<br/>		
					<fieldset>
					<legend class="toggle">基本设置</legend>
						<div class="none">
							<strong>网站描述</strong> （用简洁干练的话对你的网站进行描述）<br/><label><textarea name="description_content"  rows="4"  id="description_content" style="width:540px;"  ><?php echo($options['description_content']); ?></textarea></label>
							<br/><br/>						
																	
							<strong>网站统计代码输入</strong>（添加统计代码，为了不影响主题美观，不被显示是正常现象）<br/>
							<label><textarea name="footercode"  rows="5"  id="footercode" style="width:540px;"  ><?php echo($options['footercode']); ?></textarea></label>		
							<br/><br/>											
						</div>
					</fieldset>
					
	  </table>				
					
				
						
			
					
			
				    <fieldset>
						<legend class="toggle">模板页面设置</legend>     
							<div class="none">
							<br/>
							
								<fieldset>
								<legend class="toggle">关于页面设置</legend>
									<div class="none">
										若使用了关于页面模板请在此进行相关设置，提示：关于页面图片的标准尺寸为630 × Y, Y最大值为800<br/><br/>								
										<strong>标题</strong><br/><label><textarea name="about_title"  rows="1"  id="about_title" style="width:350px;" ><?php echo($options['about_title']); ?></textarea></label><br/><br/>
										<strong>简介内容</strong><br/><label><textarea name="about_content"  rows="6"  id="about_content" style="width:700px;" ><?php echo($options['about_content']); ?></textarea></label>	<br/><br/>
										<strong>图片地址</strong><br/><label><textarea name="about_img"  rows="1"  id="about_img" style="width:700px;"><?php echo($options['about_img']); ?></textarea></label>	 																							 
									</div>
								</fieldset>
								
								
								
							</div>
					</fieldset>
					
					
					
		
					
							
								
					
					
					
					
		<!-- submit -->
		<p class="submit">
			<input type="submit" name="Newer_save" value="保存设置" />
		</p>
	</div>
</form>
 
<?php
	}
}
add_action('admin_menu', array('NewerOptions', 'init'));



?>