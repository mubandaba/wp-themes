<?php get_header(); ?>
<?php $options = get_option('Newer_options'); ?>
	<article>        
				
			<div id="content">
			 <div class="bigfa-content">					
				    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>													
				      <div class="breadcrumbsclear"><div class="breadcrumbs"><a href="<?php bloginfo('url'); ?>">Home&nbsp;</a> &gt; Categories &gt; <?php the_category(' &gt; '); ?> &gt; <?php the_title(); ?></div></div>				
				      <?php if (has_post_format( 'audio' )){ ?> <!--音频类型-->
				<div class="musicbg">
					<div class="musiccover"><img src="http://ceezi.com/img/defaultcover.png"></div>
					<div class="musicsep"></div>
					<div class="musicname"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></div>
					<div class="singer"><?php $key="演唱者"; echo get_post_meta($post->ID, $key, true); ?></div>
					<div class="zhuanji"><?php $key="所属专辑"; echo get_post_meta($post->ID, $key, true); ?></div>
					<div class="stars"><?php $key="歌曲评分"; echo get_post_meta($post->ID, $key, true); ?></div>
					<div class="flash"><embed src="<?php $key="音乐链接"; echo get_post_meta($post->ID, $key, true); ?>" quality='high' width='362' height='35' align='middle' type='application/x-shockwave-flash'  wmode='transparent' ></embed></div>
					<div class="musictimes">Played <?php if (function_exists('the_views')): ?><?php the_views(); ?><?php endif; ?> Times,</div>
					<div class="musiccom"><?php comments_popup_link('还没有乐评', '只有1条乐评', '已有%条乐评'); ?></div>
				</div>
				<?php the_content(__('Read More'));?>
				<div class="clear"></div>
			<?php } else { ?> <!--默认类型--> 
				      
					   <h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h2> 	
					  	 <div class="post-meta"> <span>
      <?php the_time('D,g:h A'); ?>
      </span>&nbsp;|&nbsp;<span>
      <?php the_category(', ') ?>
      </span>&nbsp;|&nbsp;<span>
      超过<?php if(function_exists('the_views')) { the_views(); } ?>人围观
      </span>&nbsp;|&nbsp;<span>
      <?php comments_popup_link('还没有评论', '只有1条评论', '已有%条评论'); ?>
      </span> </div>
    <!--.postMeta-->						
				        <div class="post-content">									
					        <?php the_content(__('Read More'));?>
						<a href="http://zhuji.gd" title="主机格调" target="_blank" rel="nofollow" ><img src="http://ceezi.com/wp-content/uploads/2012/11/ad_960x60a.jpg" alt="ad"></a></div>
                        <div class="clear"></div>
						<?php } ?>
                        <div class="postinfo">													
					<div class="nav_previous"><?php  if (get_next_post()) {next_post_link('%link');} else {echo "已是最新文章！";}; ?></div>
						<div class="nav_next"><?php  if (get_previous_post()) {previous_post_link('%link');} else {echo "已是最后一篇文章！";}; ?></div>		
	<div class="relatedposts"><?php include('relatedpost.php'); ?></div>
	
	
							<div class="clear"></div>
								
						</div>
						
					<?php comments_template( '', true ); ?>

					
				
				<?php endwhile; endif;?>    
				
				<div class="clear"></div></div>
			</div>
		
		<script type="text/javascript">
		$("#loadbar").show();
		$("#loadbar div").animate({width:"50%"});
</script>
		
		<?php include('sidebar-single.php'); ?>
		<div class="clear"></div>  
		
	</article>
	  <?php get_footer(); ?>