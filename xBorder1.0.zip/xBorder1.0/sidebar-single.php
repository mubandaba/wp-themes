<aside>
<?php $options = get_option('Newer_options'); ?>





	
							
		
		<div id="sidebarwidgit">
	<?php if ( ! dynamic_sidebar( '单篇文章的Sidebar' )) : ?>
	
	<?php endif; ?>
	</div>
		

</aside>


<script type="text/javascript">
		$("#loadbar").show();
		$("#loadbar div").animate({width:"80%"});
</script>