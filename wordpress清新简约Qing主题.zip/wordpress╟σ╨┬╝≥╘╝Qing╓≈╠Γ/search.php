<?php get_header(); ?>
<div class="content-wrap">
	<div class="content">
		<?php if ( !have_posts() ) : ?>
			<?php hui_404() ?>
		<?php else: ?>
			<h1 class="title"><strong><?php echo $s; ?> 的搜索结果</strong></h1>
			<?php hui_post_excerpt() ?>
			<div class="page_navi"><?php par_pagenavi(8); ?></div>
		<?php endif; ?>
		
	</div>
</div>
<?php 
if ( have_posts() ) {
	get_sidebar(); get_footer();
} 
?>
