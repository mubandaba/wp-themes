<?php if( _hui('layout') == 'ui-c2' ) return false; ?>
<aside class="sidebar">	

<div class="deanwpr">
        <div class="deanwprc deanshadow deanborder deanfff">
            <div class="deanp14">
                <div class="deanqd"><a id="deanpost" onclick="showWindow('nav', this.href, 'get', 0)" href="http://bbs.heirui.cn/forum-2-1.html" target="_blank">发布主题</a></div>
                <div class="clear"></div>
                <div class="deanforumhotr top15">
                    <h2>板块分类</h2>
                    <div class="clear" style="border-bottom: 1px solid #e9e9e9;"></div>	
                    <ul>
					<?php hui_nav_menu(); ?>
                        <div class="clear"></div>
                    </ul>
                </div>
				
				
				<div class="clear"></div>
				<div class="deanactive top25">
                    <h2>专题聚焦</h2>
                    <div class="clear"></div>
                    <ul><div id="deanactive" class="area"><div id="framepnT7bb" class="frame move-span cl frame-1"><div id="framepnT7bb_left" class="column frame-1-c"><div id="framepnT7bb_left_temp" class="move-span temp"></div><div id="portal_block_35" class="block move-span"><div id="portal_block_35_content" class="dxb_bc"><li>
                            <div class="deanactivel"><a href="http://www.heirui.cn/category/share" target="_blank"><img src="http://img.heirui.cn/wp-content/uploads/2014/09/1323915759165_11-150x150.png" width="121" height="92"></a></div>
                            <div class="deanactiver">
                                <h3><a href="http://www.heirui.cn/category/share" target="_blank">迅雷VIP账号</a></h3>
                                <div class="clear"></div>
                                <div class="deanactivesummary">
迅雷VIP，每日免费取！
</div>
                                <div class="clear"></div>
                                <a href="http://bbs.heirui.cn/forum-38-1.html" target="_blank" class="deanattend">立即获取</a>
                            </div>
                            <div class="clear"></div>
                        </li><li>
                            <div class="deanactivel"><a href="http://bbs.heirui.cn/forum-38-1.html" target="_blank"><img src="http://bbs.heirui.cn/static/image/common/a2.jpg" width="121" height="92"></a></div>
                            <div class="deanactiver">
                                <h3><a href="forum.php?mod=viewthread&amp;tid=15" target="_blank">精品商业源码</a></h3>
                                <div class="clear"></div>
                                <div class="deanactivesummary">
各类精品VIP商业源码等尽在黑锐源码社区！
</div>
                                <div class="clear"></div>
                                <a href="forum.php?mod=viewthread&amp;tid=15" target="_blank" class="deanattend">立即查看</a>
                            </div>
                            <div class="clear"></div>
                        </li></div></div></div></div></div><!--[/diy]--></ul>
                </div>
				
				<div class="clear"></div>
				<div class="deantabs top25">
                    <ul class="deantabname">
                        <li class="cur">体验固件</li>
                        <li class="">正式固件</li>
                        <div class="clear"></div>
                    </ul>
                    <div class="clear"></div>
                    <ul class="deantabc top15">
                        <li style="display: block;"><div id="deantabc1" class="area"><div id="framewbBJor" class="frame move-span cl frame-1"><div id="framewbBJor_left" class="column frame-1-c"><div id="framewbBJor_left_temp" class="move-span temp"></div><div id="portal_block_36" class="block move-span"><div id="portal_block_36_content" class="dxb_bc"><div class="portal_block_summary"><h3>MX3/MX2 Flyme OS 3.8.3A 体验固件</h3>
                            <p>固件亮点：新增 Flyme 4 天气等应用</p>
                            <p>变更详情：优化 Smartbar；</p>
                            <div class="clear"></div>
                            <a href="#" target="_blank" class="deanlink">更新日期&gt;</a>
                            <a href="#" target="_blank" class="deanlink">使用反馈&gt;</a>
                            <div class="clear"></div>
                            <a class="deandown" href="#" target="_blank">下载固件</a></div></div></div></div></div></div><!--[/diy]--></li>
                        <li style="display: none;"><div id="deantabc2" class="area"><div id="framepL5TLW" class="frame move-span cl frame-1"><div id="framepL5TLW_left" class="column frame-1-c"><div id="framepL5TLW_left_temp" class="move-span temp"></div><div id="portal_block_37" class="block move-span"><div id="portal_block_37_content" class="dxb_bc"><div class="portal_block_summary"><h3>MX3/MX2 Flyme OS 3.7.3A</h3>
                            <p>发布日期：2014年9月9日</p>
                            <p>变更详情：新增 升级至Android 4.4.4</p>
                            <div class="clear"></div>
                            <a href="#" target="_blank" class="deanlink">更新日期&gt;</a>
                            <a href="#" target="_blank" class="deanlink">使用反馈&gt;</a>
                            <div class="clear"></div>
                            <a class="deandown" href="#" target="_blank">下载固件</a></div></div></div></div></div></div><!--[/diy]--></li>
                    </ul>
                    
                </div>
				<!--
				<div class="clear"></div>
				<div class="deannewdp top25">
                    <h2>新品速递</h2>
                    <div class="clear"></div>
                    <div class="deannewdpc"><div id="deannewdpc" class="area"><div id="framemIIv50" class="frame move-span cl frame-1"><div id="framemIIv50_left" class="column frame-1-c"><div id="framemIIv50_left_temp" class="move-span temp"></div><div id="portal_block_38" class="block move-span"><div id="portal_block_38_content" class="dxb_bc" style="position: relative;"><div class="module cl slidebox" id="0.9094533259049058" style="display: block;">
					<ul class="slideshow" style="list-style:none;margin-left:-40px;"><li style="width: 274px; height: 147px; display: block;"><a href="forum.php?mod=viewthread&amp;tid=9" target="_blank"><img src="data/attachment/block/69/691595a31fc840e344622c12d472a329.jpg" width="274" height="147"></a><span class="title">带魅族去旅行 寄明信片赢好礼</span></li><li style="width: 274px; height: 147px; display: none;"><a href="forum.php?mod=viewthread&amp;tid=15" target="_blank"><img src="data/attachment/block/41/41836f2e923c1f6d71408d83db616230.jpg" width="274" height="147"></a><span class="title">伦敦把废弃电话亭改造为太阳能手机充电站</span></li><li style="width: 274px; height: 147px; display: none;"><a href="forum.php?mod=viewthread&amp;tid=14" target="_blank"><img src="data/attachment/block/05/054a9a1a60cecbb815cc412130d62479.jpg" width="274" height="147"></a><span class="title">网上的谣言为什么比真相跑得更快</span></li></ul>
					</div>
					<script type="text/javascript">
					runslideshow();
					</script><div class="slidebar" style="position: absolute; top: 5px; left: 4px;"><ul><li onmouseover="slideshow.entities[0.9094533259049058].xactive(0); return false;" class="on">1</li><li onmouseover="slideshow.entities[0.9094533259049058].xactive(1); return false;" class="">2</li><li onmouseover="slideshow.entities[0.9094533259049058].xactive(2); return false;" class="">3</li></ul></div></div></div></div></div></div></div>
						</div>
				
				<div class="clear"></div>
				<div class="deannewzd top25">
                    <h2>新人课堂</h2>
                    <div class="clear"></div>
                    <div class="deannewzdc"><div id="deannewzdc" class="area"><div id="frameNjtZfD" class="frame move-span cl frame-1"><div id="frameNjtZfD_left" class="column frame-1-c"><div id="frameNjtZfD_left_temp" class="move-span temp"></div><div id="portal_block_39" class="block move-span"><div id="portal_block_39_content" class="dxb_bc"><div class="portal_block_summary"><a href="#" target="_blank"><img src="./template/dean_meizu_141003/deancss/phone.jpg" width="272" height="147"></a></div></div></div></div></div></div></div>
                    <div class="clear"></div>
                    <ul class="top15" style="margin-left: -40px;"><div id="deannewzdc1" class="area"><div id="framerPcKQi" class="frame move-span cl frame-1"><div id="framerPcKQi_left" class="column frame-1-c"><div id="framerPcKQi_left_temp" class="move-span temp"></div><div id="portal_block_40" class="block move-span"><div id="portal_block_40_content" class="dxb_bc"><div class="portal_block_summary"><li class="linone"><a href="#" target="_blank">系统教程</a></li>
                        <li><a href="#" target="_blank">新人指导</a></li>
                        <li><a href="#" target="_blank">社区版规</a></li>
                        <li class="linone"><a href="#" target="_blank">反馈意见</a></li>
                        <li><a href="#" target="_blank">版务申诉</a></li>
                        <li><a href="#" target="_blank">服务支持</a></li>
                        <div class="clear"></div></div></div></div></div></div></div></ul>
                </div>
				-->
				<div class="clear"></div>
				<div class="deanrank top25">
                    <h2>最新发布</h2>
					
                    <div class="clear"></div>
                    <ul class="deanrankc"><?php $cmntCnw = 1; query_posts( $query_string . '&orderby=date&showposts=10&ignore_sticky_posts=1' );while(have_posts()) : the_post(); ?><li><span class="deanspan"><?php echo ($cmntCnw++); ?>.</span><a href="<?php the_permalink() ?>" target="_blank"><?php the_title(); ?></a></li> <?php endwhile;wp_reset_query() ?></ul>
               </div>
				
                <script type="text/javascript">
                    jq(".deanforumhotr ul li:odd").css("border-left","1px solid #ddd");
                </script>
                <div class="clear"></div>
				
                 <script type="text/javascript">
                    jq(".deantabname li").each(function(s){
                        jq(this).hover(function(){
                            jq(this).addClass("cur").siblings().removeClass("cur");
                            jq(".deantabc li").eq(s).show().siblings().hide();
                        })
                    })
                </script>

            </div>
            
        </div>
    </div>



<?php 
if (function_exists('dynamic_sidebar') && dynamic_sidebar('widget_sitesidebar')) : endif; 

if (is_single()){
	if (function_exists('dynamic_sidebar') && dynamic_sidebar('widget_postsidebar')) : endif; 
}
else if (is_page()){
	if (function_exists('dynamic_sidebar') && dynamic_sidebar('widget_pagesidebar')) : endif; 
}
else if (is_home()){
	if (function_exists('dynamic_sidebar') && dynamic_sidebar('widget_sidebar')) : endif; 
}
else {
	if (function_exists('dynamic_sidebar') && dynamic_sidebar('widget_othersidebar')) : endif; 
}
?>


</aside>