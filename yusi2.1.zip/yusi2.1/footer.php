<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.titleQIPAO.js"></script>
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/fancybox/fancybox.css" />  
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/fancybox/jquery-1.9.0.min.js"></script>  
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/fancybox/fancybox.js"></script>  
  <script type="text/javascript">  
    $(document).ready(function() {  
        $(".fancybox").fancybox();  
    });  
</script> 
</section>
<style type="text/css">
<!--
.STYLE1 {color: #006699}
.footer-inner .copyright.pull-left p {
	color: 2fa2d4;
	font-weight:100;
	font-size:15px;
}
.footer-inner .copyright.pull-left p {
	color: #06945d;
}
.footer-inner .copyright.pull-left p {
	color: #00FFCF;
}
.s {
	color: #000;
}
.a {
	font-weight: bold;
}
-->
</style>

<footer class="footer">
<div class="footer-inner">
        <div class="copyright pull-left">          
          <p>Copyright <span class="s">©</span> 2014-2015  <a><a href="<?php site_url(); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?> </a>  Power By <a href="http://cn.wordpress.org/" target="_blank">WordPress</a> Theme By <a title="wordpress主题yusi修改版免费分享" href="http://tmy123.com/10930.html" target="_blank">Yusi2.0</a>
          响应时间：<?php timer_stop(1); ?>ms<div id="TimeShow">
<p><span class="a">站点统计</span>：共有
<?php $count_posts = wp_count_posts(); echo $published_posts = $count_posts->publish;?>
  篇文章   
  <?php $count_pages = wp_count_posts('page'); echo $page_posts = $count_pages->publish; ?>
  个页面     <?php echo $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->comments");?>条评论  <?php echo $count_tags = wp_count_terms('post_tag'); ?> 个标签 <?php echo $count_categories = wp_count_terms('category'); ?>个分类 最后更新时间：<?php $last = $wpdb->get_results("SELECT MAX(post_modified) AS MAX_m FROM $wpdb->posts WHERE (post_type = 'post' OR post_type = 'page') AND (post_status = 'publish' OR post_status = 'private')");$last = date('Y-n-j', strtotime($last[0]->MAX_m));echo $last; ?> 
</p>
<div></div>
          </div>
</div>
        <div class="trackcode pull-right">
          <?php if( dopt('d_track_b') ) echo dopt('d_track'); ?>
      </div>
    </div>
</footer>

<?php 
wp_footer(); 
global $dHasShare; 
if($dHasShare == true){ 
	echo'<script>with(document)0[(getElementsByTagName("head")[0]||body).appendChild(createElement("script")).src="http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion="+~(-new Date()/36e5)];</script>';
}  
if( dopt('d_footcode_b') ) echo dopt('d_footcode'); 
?>
</body>
</html>