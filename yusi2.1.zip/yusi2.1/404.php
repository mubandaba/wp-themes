<!DOCTYPE HTML>
<html>
<head>
<title>I'M 404 | <?php bloginfo('name');?></title>
<style>
html{background:#f6f6f6;}
body{font:14px/18px 'open sans',sans-serif;color:#333;margin:0;padding:0;}
a,input{transition:all .2s ease-out;-moz-transition:all .2s ease-out;-webkit-transition:all .2s ease-out;}
a{color:#333;text-decoration:none;border-bottom:1px dotted;}
a:hover{color:#06e;text-shadow:0 0 6px #09f;}
h2{font-size:32px;line-height:40px;font-weight:normal;background:-webkit-gradient(linear,0% 20%,0% 100%,from(#fff),to(#000));-webkit-text-fill-color:transparent;-webkit-background-clip:text;margin-top:32px;text-shadow:0 1px 1px rgba(0,0,0,.3);}
#content{width:50%;min-width:450px;_width:450px;_height:240px;padding:10px;margin-top:-360px;margin-left:auto;margin-right:auto;background:#eee;border:1px solid #ddd;border-radius:6px;box-shadow:0 1px #fff,0 6px 12px rgba(0, 0, 0, 0.3);}
p{text-align:center;font-size:16px;margin:15px auto;}
input{width:80%;height:32px;border:3px solid #ddd;display:block;padding:0 10px;margin:20px auto;-webkit-appearance:none;}
input:focus{border-color:#0af;box-shadow:0 0 12px #09f;}
.copyright{text-align:center;}
.copyright a{border:0;}
</style>
<script type='text/javascript' src='http://libs.baidu.com/jquery/1.8.3/jquery.min.js'></script>
<script type='text/javascript'>
$(document).ready(function(){
    $("#content").animate({margin:'10% auto'},800);
});
</script>
</head>
<body>
<div id="content">
<h2 align="center">404, 对不起 您访问的页面不存在!</h2>
<p>The captain was sleeping, but ship needs some guide !</p>
<p><a href="javascript:void(0);" onClick="location.href='javascript:history.go(-1);'">返回</a>&nbsp;&nbsp;or&nbsp;&nbsp;<a href="<?php bloginfo('url'); ?>">进入主页</a></p>
<form method="get" action="<?php bloginfo('url')?>">
<input type="输入内容，回车发起搜索" placeholder="输入内容，回车发起搜索" value="" name="s" x-webkit-speech=""/>
</form>
<div class="copyright"><a href="<?php bloginfo('url')?>" title="搜索"><?php echo $_SERVER['SERVER_NAME']; ?></a>. All rights reserved.</div>
</div>
</body>
</html>