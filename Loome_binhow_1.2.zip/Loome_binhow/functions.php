<?php

include('includes/theme-option.php');
add_theme_support( 'post-formats',array( 'gallery') );
if (function_exists('register_sidebar'))
{
register_sidebar(array(
'name'=>'banner',
'before_widget'=>'<div class="banner">',
'after_widget'=>'</div>',
));
}
{
register_sidebar(array(
'name'=>'小工具1(搜索栏下)',
'before_widget'=>'<div class="widget">',
'after_widget'=>'</div>',
'before_title'=>'<h3>',
'after_title'=>'</h3>',
));
}
{
register_sidebar(array(
'name'=>'小工具2(标签上方)',
'before_widget'=>'<div class="widget">',
'after_widget'=>'</div>',
'before_title'=>'<h3>',
'after_title'=>'</h3>',
));
}
{
register_sidebar(array(
'name'=>'小工具3(跟随滚动)',
'before_widget'=>'<div class="widget">',
'after_widget'=>'</div>',
'before_title'=>'<h3>',
'after_title'=>'</h3>',
));
}
{
register_sidebar(array(
'name'=>'首页inter-top',
'before_widget'=>'<div class="widget">',
'after_widget'=>'</div>',
'before_title'=>'<h3>',
'after_title'=>'</h3>',
));
}
if ( function_exists('register_nav_menus') ) {
register_nav_menus(array(
'primary'=>'导航菜单'
));
}
function wt_get_category_count($input = '') {
global $wpdb;
if($input == '') {
$category = get_the_category();
return $category[0]->category_count;
}
elseif(is_numeric($input)) {
$SQL = "SELECT $wpdb->term_taxonomy.count FROM $wpdb->terms, $wpdb->term_taxonomy WHERE $wpdb->terms.term_id=$wpdb->term_taxonomy.term_id AND $wpdb->term_taxonomy.term_id=$input";
return $wpdb->get_var($SQL);
}
else {
$SQL = "SELECT $wpdb->term_taxonomy.count FROM $wpdb->terms, $wpdb->term_taxonomy WHERE $wpdb->terms.term_id=$wpdb->term_taxonomy.term_id AND $wpdb->terms.slug='$input'";
return $wpdb->get_var($SQL);
}
}
function simple_get_most_viewed($posts_num=10,$days=90){
global $wpdb;
$sql = "SELECT ID , post_title , comment_count
            FROM $wpdb->posts
           WHERE post_type = 'post' AND TO_DAYS(now()) - TO_DAYS(post_date) < $days
		   AND ($wpdb->posts.`post_status` = 'publish' OR $wpdb->posts.`post_status` = 'inherit')
           ORDER BY comment_count DESC LIMIT 0 , $posts_num ";
$posts = $wpdb->get_results($sql);
$output = '';
foreach ($posts as $post){
$output .= "\n<li><a href= \"".get_permalink($post->ID)."\" rel=\"bookmark\" title=\"".$post->post_title.' ('.$post->comment_count."条评论)\" >".mb_strimwidth($post->post_title,0,36).'</a></li>';
}
echo $output;
}
function cut_str($src_str,$cut_length)
{
$return_str='';
$i=0;
$n=0;
$str_length=strlen($src_str);
while (($n<$cut_length) &&($i<=$str_length))
{
$tmp_str=substr($src_str,$i,1);
$ascnum=ord($tmp_str);
if ($ascnum>=224)
{
$return_str=$return_str.substr($src_str,$i,3);
$i=$i+3;
$n=$n+2;
}
elseif ($ascnum>=192)
{
$return_str=$return_str.substr($src_str,$i,2);
$i=$i+2;
$n=$n+2;
}
elseif ($ascnum>=65 &&$ascnum<=90)
{
$return_str=$return_str.substr($src_str,$i,1);
$i=$i+1;
$n=$n+2;
}
else 
{
$return_str=$return_str.substr($src_str,$i,1);
$i=$i+1;
$n=$n+1;
}
}
if ($i<$str_length)
{
$return_str = $return_str .'';
}
if (get_post_status() == 'private')
{
$return_str = $return_str .'（private）';
}
return $return_str;
}
function pagination($query_string){
global $posts_per_page,$paged;
$my_query = new WP_Query($query_string .'&posts_per_page=-1');
$total_posts = $my_query->post_count;
if(empty($paged))$paged = 1;
$prev = $paged -1;
$next = $paged +1;
$range = 5;
$showitems = ($range * 2)+1;
$pages = ceil($total_posts/$posts_per_page);
if(1 != $pages){
echo "<div class='pagination'>";
echo ($paged >2 &&$paged+$range+1 >$pages &&$showitems <$pages)?"<a href='".get_pagenum_link(1)."' class='fir_las'>最前</a>":'';
echo ($paged >1 &&$showitems <$pages)?"<a href='".get_pagenum_link($prev)."' class='page_previous'>« 上一页</a>":'';
for ($i=1;$i <= $pages;$i++){
if (1 != $pages &&( !($i >= $paged+$range+1 ||$i <= $paged-$range-1) ||$pages <= $showitems )){
echo ($paged == $i)?"<span class='current'>".$i.'</span>':"<a href='".get_pagenum_link($i)."' class='inactive' >".$i.'</a>';
}
}
echo ($paged <$pages &&$showitems <$pages) ?"<a href='".get_pagenum_link($next)."' class='page_next'>下一页 »</a>":'';
echo ($paged <$pages-1 &&$paged+$range-1 <$pages &&$showitems <$pages) ?"<a href='".get_pagenum_link($pages)."' class='fir_las'>最后</a>":'';
echo "</div>\n";
}
}
function wp_smilies() {
global $wpsmiliestrans;
if ( !get_option('use_smilies') or (empty($wpsmiliestrans))) return;
$smilies = array_unique($wpsmiliestrans);
$link='';
foreach ($smilies as $key =>$smile) {
$file = get_bloginfo('template_directory').'/images/smilies/'.$smile;
$value = ' '.$key.' ';
$img = "<img src=\"{$file}\" alt=\"{$smile}\" />";
$imglink = htmlspecialchars($img);
$link .= "<a href=\"#commentform\" title=\"{$smile}\" onclick=\"document.getElementById('comment').value += '{$value}'\">{$img}</a>";
}
echo $link;
}
add_filter('smilies_src','custom_smilies_src',1,10);
function custom_smilies_src ($img_src,$img,$siteurl){
return get_bloginfo('template_directory').'/images/smilies/'.$img;
}
class hacklog_archives
{
function GetPosts() 
{
global  $wpdb;
if ( $posts = wp_cache_get( 'posts','ihacklog-clean-archives') )
return $posts;
$query="SELECT DISTINCT ID,post_date,post_date_gmt,comment_count,comment_status,post_password FROM $wpdb->posts WHERE post_type='post' AND post_status = 'publish' AND comment_status = 'open'";
$rawposts =$wpdb->get_results( $query,OBJECT );
foreach( $rawposts as $key =>$post ) {
$posts[mysql2date( 'Y.m',$post->post_date ) ][] = $post;
$rawposts[$key] = null;
}
$rawposts = null;
wp_cache_set( 'posts',$posts,'ihacklog-clean-archives');;
return $posts;
}
function PostList( $atts = array() ) 
{
global $wp_locale;
global $hacklog_clean_archives_config;
$atts = shortcode_atts(array(
'usejs'=>$hacklog_clean_archives_config['usejs'],
'monthorder'=>$hacklog_clean_archives_config['monthorder'],
'postorder'=>$hacklog_clean_archives_config['postorder'],
'postcount'=>'1',
'commentcount'=>'1',
),$atts);
$atts=array_merge(array('usejs'=>1,'monthorder'=>'new','postorder'=>'new'),$atts);
$posts = $this->GetPosts();
( 'new'== $atts['monthorder'] ) ?krsort( $posts ) : ksort( $posts );
foreach( $posts as $key =>$month ) {
$sorter = array();
foreach ( $month as $post )
$sorter[] = $post->post_date_gmt;
$sortorder = ( 'new'== $atts['postorder'] ) ?SORT_DESC : SORT_ASC;
array_multisort( $sorter,$sortorder,$month );
$posts[$key] = $month;
unset($month);
}
$html = '<div class="car-container';
if ( 1 == $atts['usejs'] ) $html .= ' car-collapse';
$html .= '">'."\n";
if ( 1 == $atts['usejs'] ) $html .= '<a href="#" class="car-toggler">展开所有月份'."</a>\n\n";
$html .= '<ul class="car-list">'."\n";
$firstmonth = TRUE;
foreach( $posts as $yearmonth =>$posts ) {
list( $year,$month ) = explode( '.',$yearmonth );
$firstpost = TRUE;
foreach( $posts as $post ) {
if ( TRUE == $firstpost ) {
$spchar = $firstmonth ?'<span class="car-toggle-icon car-minus">-</span>': '<span class="car-toggle-icon car-plus">+</span>';
$html .= '	<li><span class="car-yearmonth" style="cursor:pointer;">'.$spchar.' '.sprintf( __('%1$s %2$d'),$wp_locale->get_month($month),$year );
if ( '0'!= $atts['postcount'] ) 
{
$html .= ' <span title="文章数量">(共'.count($posts) .'篇文章)</span>';
}
if ($firstmonth == FALSE) {
$html .= "</span>\n		<ul class='car-monthlisting' style='display:none;'>\n";
}else {
$html .= "</span>\n		<ul class='car-monthlisting'>\n";
}
$firstpost = FALSE;
$firstmonth = FALSE;
}
$html .= '			<li>'.mysql2date( 'd',$post->post_date ) .'日: <a target="_blank" href="'.get_permalink( $post->ID ) .'">'.get_the_title( $post->ID ) .'</a>';
if ( '0'!= $atts['commentcount'] &&( 0 != $post->comment_count ||'closed'!= $post->comment_status ) &&empty($post->post_password) )
$html .= ' <span title="评论数量">('.$post->comment_count .'条评论)</span>';
$html .= "</li>\n";
}
$html .= "		</ul>\n	</li>\n";
}
$html .= "</ul>\n</div>\n";
return $html;
}
function PostCount() 
{
$num_posts = wp_count_posts( 'post');
return number_format_i18n( $num_posts->publish );
}
}
if(!empty($post->post_content))
{
$all_config=explode(';',$post->post_content);
foreach($all_config as $item)
{
$temp=explode('=',$item);
$hacklog_clean_archives_config[trim($temp[0])]=htmlspecialchars(strip_tags(trim($temp[1])));
}
}
else
{
$hacklog_clean_archives_config=array('usejs'=>1,'monthorder'=>'new','postorder'=>'new');
}
$hacklog_archives=new hacklog_archives();
function password_hint( $c ){
global $post,$user_ID,$user_identity;
if ( empty($post->post_password) )
return $c;
if ( isset($_COOKIE['wp-postpass_'.COOKIEHASH]) &&stripslashes($_COOKIE['wp-postpass_'.COOKIEHASH]) == $post->post_password )
return $c;
if($hint = get_post_meta($post->ID,'password_hint',true)){
$url = get_option('siteurl').'/wp-pass.php';
if($hint)
$hint = '密码提示：'.$hint;
else
$hint = '请输入您的密码';
if($user_ID)
$hint .= sprintf('欢迎进入，您的密码是：',$user_identity,$post->post_password);
$out = "<form method=\"post\" action=\"$url\">
<p>这篇文章是受保护的文章，请输入密码继续阅读：</p>
<div>
<label>$hint<br/>
<input type=\"password\" name=\"post_password\"/></label>
<input type=\"submit\" value=\"输入密码\" name=\"Submit\"/>
</div>
</form>";
return $out;
}else{
return $c;
}
}
add_filter('the_content','password_hint');
if ( function_exists('add_theme_support') )
add_theme_support('post-thumbnails');
function catch_first_image() {
global $post,$posts;
$first_img = '';
ob_start();
ob_end_clean();
$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i',$post->post_content,$matches);
$first_img = $matches [1] [0];
if(empty($first_img)){
$random = mt_rand(1,20);
echo get_bloginfo ( 'stylesheet_directory');
echo '/images/random/tb'.$random.'.jpg';
}
return $first_img;
}
function weisay_comment($comment,$args,$depth) {
$GLOBALS['comment'] = $comment;
global $commentcount,$wpdb,$post;
if(!$commentcount) {
$comments = $wpdb->get_results("SELECT * FROM $wpdb->comments WHERE comment_post_ID = $post->ID AND comment_type = '' AND comment_approved = '1' AND !comment_parent");
$cnt = count($comments);
$page = get_query_var('cpage');
$cpp=get_option('comments_per_page');
if (ceil($cnt / $cpp) == 1 ||($page >1 &&$page  == ceil($cnt / $cpp))) {
$commentcount = $cnt +1;
}else {
$commentcount = $cpp * $page +1;
}
}
;echo '<li ';comment_class();;echo ' id="comment-';comment_ID() ;echo '">
   <div id="div-comment-';comment_ID() ;echo '" class="comment-body">
      ';$add_below = 'div-comment';;echo '		<div class="comment-author vcard">';echo get_avatar( $comment,40 );;echo '					<div class="floor">';
if(!$parent_id = $comment->comment_parent){
switch ($commentcount){
case 2 :echo '沙发';--$commentcount;break;
case 3 :echo '板凳';--$commentcount;break;
case 4 :echo '地板';--$commentcount;break;
default:printf('%1$s楼',--$commentcount);
}
}
;echo '         </div><strong>';comment_author_link() ;echo '</strong>:';edit_comment_link('编辑','&nbsp;&nbsp;','');;echo '</div>
		';if ( $comment->comment_approved == '0') : ;echo '			<span style="color:#C00; font-style:inherit">您的评论正在等待审核中...</span>
			<br />			
		';endif;;echo '		';comment_text() ;echo '        
		<div class="clear"></div><span class="datetime">';comment_date('Y-m-d') ;echo ' ';comment_time() ;echo ' </span> <span class="reply">';comment_reply_link(array_merge( $args,array('reply_text'=>'[回复]','add_below'=>$add_below,'depth'=>$depth,'max_depth'=>$args['max_depth'])));;echo '</span>
  </div>
';
}
function weisay_end_comment() {
echo '</li>';
}
function weisay_get_avatar($email,$size = 48){
return get_avatar($email,$size);
}
function comicpress_copyright() {
global $wpdb;
$copyright_dates = $wpdb->get_results("
    SELECT
    YEAR(min(post_date_gmt)) AS firstdate,
    YEAR(max(post_date_gmt)) AS lastdate
    FROM
    $wpdb->posts
    WHERE
    post_status = 'publish'
    ");
$output = '';
if($copyright_dates) {
$copyright = '&copy; '.$copyright_dates[0]->firstdate;
if($copyright_dates[0]->firstdate != $copyright_dates[0]->lastdate) {
$copyright .= '-'.$copyright_dates[0]->lastdate;
}
$output = $copyright;
}
return $output;
}
function Get_Recent_Comment($limit=15,$cut_length=24){
global $wpdb;
$admin_email = "'".get_bloginfo ('admin_email') ."'";
$rccdb = $wpdb->get_results("
		SELECT ID, post_title, comment_ID, comment_author, comment_author_email, comment_content
		FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts
		ON ($wpdb->comments.comment_post_ID = $wpdb->posts.ID)
		WHERE comment_approved = '1'
		AND comment_type = ''
		AND post_password = ''
		AND comment_author_email != $admin_email
		ORDER BY comment_date_gmt
		DESC LIMIT $limit
	 ");
foreach ($rccdb as $row) {
$rcc .= '<li>'.get_avatar($row,$size='32').'<span>'.$row->comment_author .'：</span>'.'<br />'."<a href='"
.get_permalink($row->ID) .'#comment-'.$row->comment_ID
."' title='查看 ".$row->post_title ."'>".cut_str($row->comment_content,$cut_length).'</a>'.'</li>';
}
$rcc = convert_smilies($rcc);
echo $rcc;
}
function comment_mail_notify($comment_id) {
$admin_email = get_bloginfo ('admin_email');
$comment = get_comment($comment_id);
$comment_author_email = trim($comment->comment_author_email);
$parent_id = $comment->comment_parent ?$comment->comment_parent : '';
$to = $parent_id ?trim(get_comment($parent_id)->comment_author_email) : '';
$spam_confirmed = $comment->comment_approved;
if (($parent_id != '') &&($spam_confirmed != 'spam') &&($to != $admin_email) &&($comment_author_email == $admin_email)) {
$wp_email = 'no-reply@'.preg_replace('#^www\.#','',strtolower($_SERVER['SERVER_NAME']));
$subject = '您在 ['.get_option('blogname') .'] 的评论有新的回复';
$message = '
    <div style="background-color:#eef2fa; border:1px solid #d8e3e8; color:#111; padding:0 15px; -moz-border-radius:5px; -webkit-border-radius:5px; -khtml-border-radius:5px; border-radius:5px;">
      <p>'.trim(get_comment($parent_id)->comment_author) .', 您好!</p>
      <p>您曾在 ['.get_option('blogname') .'] 的文章 《'.get_the_title($comment->comment_post_ID) .'》 上发表评论:<br />'
.nl2br(get_comment($parent_id)->comment_content) .'</p>
      <p>'.trim($comment->comment_author) .' 给您的回复如下:<br />'
.nl2br($comment->comment_content) .'<br /></p>
      <p>您可以点击 <a href="'.htmlspecialchars(get_comment_link($parent_id)) .'">查看回复的完整內容</a></p>
      <p>欢迎再次光临 <a href="'.get_option('home') .'">'.get_option('blogname') .'</a></p>
      <p>(此郵件由系統自動發出, 請勿回覆.)</p>
    </div>';
$message = convert_smilies($message);
$from = "From: \"".get_option('blogname') ."\" <$wp_email>";
$headers = "$from\nContent-Type: text/html; charset=".get_option('blog_charset') ."\n";
wp_mail( $to,$subject,$message,$headers );
}
}
add_action('comment_post','comment_mail_notify');
;echo '';
remove_action( 'wp_head','feed_links_extra',3 );
remove_action( 'wp_head','feed_links',2 );
remove_action( 'wp_head','rsd_link');
remove_action( 'wp_head','wlwmanifest_link');
remove_action( 'wp_head','index_rel_link');
remove_action( 'wp_head','parent_post_rel_link',10,0 );
remove_action( 'wp_head','start_post_rel_link',10,0 );
remove_action( 'wp_head','adjacent_posts_rel_link',10,0 );
remove_action( 'wp_head','wp_generator');
/*显示文章浏览次数*/
function getPostViews($postID){
$count = get_post_meta($postID,'views', true);
if($count==''){
delete_post_meta($postID,'views');
add_post_meta($postID,'views', '0');
return "0";
}
return $count.'';
}
function setPostViews($postID) {
$count = get_post_meta($postID,'views', true);
if($count==''){
$count = 0;
delete_post_meta($postID,'views');
add_post_meta($postID,'views', '0');
}else{
$count++;
update_post_meta($postID,'views', $count);
}
}?>