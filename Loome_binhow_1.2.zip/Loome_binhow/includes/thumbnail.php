<?php echo '<div class="thumbnail_box"><div class="thumbnail">'; if (
get_post_meta($post->
    ID,'thumbnail',true) ) : ;echo ' ';$image = get_post_meta($post->ID,'thumbnail',true);;echo
    '
    <a href="';the_permalink() ;echo '" rel="bookmark" title="';the_title_attribute();;echo '">
        <img src="';echo $image;;echo '" alt="'the_title_attribute();;echo '" title="'the_title_attribute();;echo '"
        />
    </a>
    ';else: ;echo '
    <a href="';the_permalink() ;echo '" rel="bookmark" title="';the_title_attribute();;echo '">
        <img src="';bloginfo('template_directory');;echo '/images/random/tb';echo rand(1,20);echo '.jpg"
        alt="';the_title_attribute();;echo '" title="'the_title_attribute();;echo '" />
    </a>
    ';endif;;echo '
    </div>
    </div>
    '; ?>