<?php

$themename = 'binhow';
function my_function_admin_bar(){
return false;
}
add_filter( 'show_admin_bar','my_function_admin_bar');
function binhow_add_option() {
global $themename;
add_theme_page($themename.' 主题设置',''.$themename.' 主题设置','administrator',basename(__FILE__),'binhow_form');
add_action( 'admin_init','register_mysettings');
}
function register_mysettings() {
register_setting( 'binhow-settings','binhow_announce');
register_setting( 'binhow-settings','binhow_statistics');
register_setting( 'binhow-settings','binhow_tqq');
register_setting( 'binhow-settings','binhow_weibo');
register_setting( 'binhow-settings','binhow_sbaidu');
register_setting( 'binhow-settings','binhow_ditu');
register_setting( 'binhow-settings','binhow_keywords');
register_setting( 'binhow-settings','binhow_links');
register_setting( 'binhow-settings','binhow_description');
register_setting( 'binhow-settings','binhow_sidebar_ad');
register_setting( 'binhow-settings','binhow_single_ad');
register_setting( 'binhow-settings','binhow_top_ad');
register_setting( 'binhow-settings','binhow_share');
register_setting( 'binhow-settings','binhow_start');
register_setting( 'binhow-settings','binhow_date');
register_setting( 'binhow-settings','binhow_Designed');
register_setting( 'binhow-settings','binhow_link');
register_setting( 'binhow-settings','binhow_cat_n');
register_setting( 'binhow-settings','binhow_home');
}
function binhow_form() {
global $themename;
;echo '
<!-- Options Form begin -->
<div class="wrap">
	<div id="icon-options-general" class="icon32"><br/></div>
	<h2>';echo $themename;;echo '设置</h2>
    <ul class="subsubsub" style="margin-top:15px; ">
    	<li><a href="#binhow_base"><strong>基本设置</strong></a> |</li>
        <li><a href="#binhow_seo"><strong>SEO设置</strong></a></li>
     </ul>
	<form method="post" action="options.php">
		';settings_fields('binhow-settings');;echo '		<table class="form-table">
			<tr valign="top">
            	<td><h3 id="binhow_base">基本设置</h3></td>
        	</tr>
            <tr valign="top">
                <th scope="row"><label>网站公告</label></th>
                <td>
                    <textarea style="width:35em; height:5em;" name="binhow_announce">';echo get_option('binhow_announce');;echo '</textarea>
                    <br />
                    <span class="description">将在网站头部显示</span>
                </td>
        	</tr>
			<tr valign="top">
                <th scope="row"><label>站点统计代码【footer.php】</label></th>
                <td>
                    <textarea style="width:35em; height:5em;" name="binhow_start">';echo get_option('binhow_start');;echo '</textarea>
                    <br />
                    <span class="description">写入站点统计代码</span>
                </td>
        	</tr>
            <tr valign="top">
                <th scope="row"><label>网站底部代码【footer.php】</label></th>
                <td>
                    <textarea style="width:35em; height:10em;" name="binhow_statistics">';echo get_option('binhow_statistics');;echo '</textarea>
                    <br />
                    <span class="description">可以写入各种底部信息</span>
                </td>
        	</tr>
			<tr valign="top">
                <th scope="row"><label>建站日期</label></th>
                <td>
                    <textarea style="width:35em; height:2em;" name="binhow_date">';echo get_option('binhow_date');;echo '</textarea>
                    <br />
                    <span class="description">格式：2012-01-01</span>
                </td>
        	</tr>
			<tr valign="top">
                <th scope="row"><label>百度地图地址</label></th>
                <td>
                    <textarea style="width:35em; height:2em;" name="binhow_sbaidu">';echo get_option('binhow_sbaidu');;echo '</textarea>
                    <br />
                    <span class="description">输入百度地图地址</span>
                </td>
        	</tr>
			<tr valign="top">
                <th scope="row"><label>网站地图地址</label></th>
                <td>
                    <textarea style="width:35em; height:2em;" name="binhow_ditu">';echo get_option('binhow_ditu');;echo '</textarea>
                    <br />
                    <span class="description">输入网站地图地址</span>
                </td>
        	</tr>
             <tr valign="top">
                <th scope="row"><label>我的腾讯微博地址</label></th>
                <td>
                    <textarea style="width:35em; height:2em;" name="binhow_tqq">';echo get_option('binhow_tqq');;echo '</textarea>
                    <br />
                    <span class="description">输入腾讯微博地址</span>
                </td>
        	</tr>
            <tr valign="top">
                <th scope="row"><label>我的新浪微博地址</label></th>
                <td>
                    <textarea style="width:35em; height:2em;" name="binhow_weibo">';echo get_option('binhow_weibo');;echo '</textarea>
                    <br />
                    <span class="description">输入微博地址</span>
                </td>
        	</tr>
            <tr valign="top">
            	<td><h3 id="binhow_seo">SEO设置</h3></td>
        	</tr>
            <tr valign="top">
                <th scope="row"><label>网站关键词</label></th>
                <td>
                    <textarea style="width:35em; height:5em;" name="binhow_keywords">';echo get_option('binhow_keywords');;echo '</textarea>
                    <br />
                    <span class="description">输入关键词请使用英文逗号","符号分隔</span>
                </td>
        	</tr>
            <tr valign="top">
                <th scope="row"><label>网站描述</label></th>
                <td>
                    <textarea style="width:35em; height:5em;" name="binhow_description">';echo get_option('binhow_description');;echo '</textarea>
                    <br />
                    <span class="description">输入网站描述信息</span>
                </td>
        	</tr>
		</table>
		<p class="submit">
		<input type="submit" name="save" id="button-primary" class="button-primary" value="';_e('Save Changes') ;echo '" />
		</p>
	</form>
    <style type="text/css"> span.description{ font-style:normal;} .form-table h3{ padding:5px 10px 4px; color:#FFF; background-color:#535353;} a{
		color:#535353;}</style>
		<link rel="stylesheet" href="';bloginfo('template_url');;echo '/highlight.css" />
</div>
<!-- Options Form begin -->
';}
add_action('admin_menu','binhow_add_option');

?>