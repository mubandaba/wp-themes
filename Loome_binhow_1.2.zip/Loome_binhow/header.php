<?php
echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="';bloginfo('html_type');;echo '; charset=';bloginfo('charset');;echo '" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
';include('includes/seo.php');;echo '<link rel="stylesheet" type="text/css" href="';bloginfo('template_directory');;echo '/style.css" />
<link rel="alternate" type="application/rss+xml" title="';bloginfo('name');;echo ' RSS Feed" href="';bloginfo('rss2_url');;echo '" />
<link rel="alternate" type="application/atom+xml" title="';bloginfo('name');;echo ' Atom Feed" href="';bloginfo('atom_url');;echo '" />
<link rel="pingback" href="';bloginfo('pingback_url');;echo '" />
';wp_head();;if ( is_singular() ){;echo '<script type="text/javascript" src="';bloginfo('template_directory');;echo '/comments-ajax.js"></script>
';};if ( is_home() );include('includes/lazyload.php');;echo '<script type="text/javascript" src="';bloginfo('template_url');;echo '/js/jquery.js"></script>
</head>
<body>
<div id="page">
<div id="head">
<div id="header">
<div class="subpage">
<div class="toppage">
<ul>';wp_list_pages('title_li=');;echo '</ul></div>
<div id="rss"><ul>
<li><a href="';bloginfo('rss2_url');;echo '" target="_blank" class="icon1" title="欢迎订阅';bloginfo('name');;echo '"></a></li>
';if(get_option('binhow_sbaidu')!='')
echo '<li><a href="'.get_option('binhow_sbaidu').'" target="_blank" class="icon5" title="百度地图"></a></li>';
;echo '';if(get_option('binhow_tqq')!='')
echo '<li><a href="'.get_option('binhow_tqq').'" target="_blank" class="icon2" title="我的腾讯微博" rel="nofollow"></a></li>';
;echo '';if(get_option('binhow_weibo')!='')
echo '<li><a href="'.get_option('binhow_weibo').'" target="_blank" class="icon3" title="我的新浪微博" rel="nofollow"></a></li>';
;echo '<li><a href="http://mail.qq.com/cgi-bin/feed?u=';bloginfo('rss2_url');;echo '" target="_blank" class="icon4" title="用QQ邮箱阅读空间订阅本站" rel="nofollow"></a></li>
';if(get_option('binhow_ditu')!='')
echo '<li><a href="'.get_option('binhow_ditu').'" target="_blank" class="icon6" title="网站地图"></a></li>';
;echo '</ul></div>
<div class="clear"></div>
</div>
<div class="logo">
	<div id="blogname"><h1><a href="';bloginfo('siteurl');;echo '/">';bloginfo('name');;echo '</a></h1></div>'
;if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('banner') ) :
; endif;
;echo '</div>
<div class="clear"></div>
</div>
</div>
<div class="mainmenus">
<div class="mainmenu">
<div class="topnav">
';
if(function_exists('wp_nav_menu')) {
wp_nav_menu(array('theme_location'=>'primary','menu_id'=>'nav','container'=>'ul'));
}
;echo '</div>
<div class="clear"></div>
</div>
</div>'
?>