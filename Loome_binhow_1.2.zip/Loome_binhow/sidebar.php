<?php
echo '<div class="zhuce">
<div class="search">
<div class="search_site">
<form id="searchform" method="get" action="';bloginfo('home');;echo '">
		<input type="submit" value="" id="searchsubmit" class="button"/>
		<input type="text" id="s" name="s" value="请输入搜索内容" onfocus="if (value ==\'请输入搜索内容\'){value =\'\'}" onblur="if (value ==\'\'){value=\'请输入搜索内容\'}" />
</form></div></div>
</div>
<div id="sidebar">

'
;if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('小工具1(搜索栏下)') ) :
; endif;
;echo'<div class="widgets">
<div id="tab-title"><div class="tab"><ul id="tabnav">
<li>最新文章</li>
<li class="selected">热评文章</li>
<li>随机文章</li>
</ul>
</div><div class="clear"></div>
	<div id="tab-content">
		<ul class="hide">';$myposts = get_posts('numberposts=10&offset=0');foreach($myposts as $post) :;echo '					<li><a href="';the_permalink();;echo '" rel="bookmark" title="详细阅读 ';the_title_attribute();;echo '">';echo cut_str($post->post_title,37);;echo '</a></li>
					';endforeach;;echo '</ul>
		<ul>';simple_get_most_viewed();;echo '</ul>
		<ul class="hide">';$myposts = get_posts('numberposts=10&orderby=rand');foreach($myposts as $post) :;echo '					<li><a href="';the_permalink();;echo '" rel="bookmark" title="详细阅读 ';the_title_attribute();;echo '">';echo cut_str($post->post_title,37);;echo '</a></li>
					';endforeach;;echo '</ul>
					</div></div>
<div class="widget"><h3>最新评论</h3>
<div class="r_comment">
<ul id="scroll_List">
';Get_Recent_Comment();;echo '</ul>
</div></div>'
;if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('小工具2(标签上方)') ) :
; endif;
;echo'<div class="widget"><h3>标签</h3>
<div class="tag">
';wp_tag_cloud('smallest=13&largest=13&unit=px&number=50&orderby=count&order=DESC');;echo '</div><div class="clear"></div></div>
<a name="buttom"></a>
<div class="widget widget1">
<h3>站点统计</h3>
   <ul>
<li>日志总数：<span>';$count_posts = wp_count_posts();echo $published_posts = $count_posts->publish;;echo '</span> 篇</li>
<li>评论总数：<span>';echo $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->comments");;echo '</span> 条</li>
<li>标签数量：<span>';echo $count_tags = wp_count_terms('post_tag');;echo '</span> 个</li>
<li>链接总数：<span>';$link = $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->links WHERE link_visible = 'Y'");echo $link;;echo '</span> 个</li>
<li>建站日期：<span>';echo get_option('binhow_date');;echo '</span></li>
<li>运行天数：<span>';echo floor((time()-strtotime(get_option('binhow_date')))/86400);;echo '</span> 天</li>
<li>最后更新：<span>';$last = $wpdb->get_results("SELECT MAX(post_modified) AS MAX_m FROM $wpdb->posts WHERE (post_type = 'post' OR post_type = 'page') AND (post_status = 'publish' OR post_status = 'private')");$last = date('Y-n-j',strtotime($last[0]->MAX_m));echo $last;;echo '</span></li>
   </ul>
<div class="clear"></div></div>
<div class="widget">
';
global $user_ID,$user_identity,$user_email,$user_login;
get_currentuserinfo();
if (!$user_ID) {
;echo '<form id="loginform" action="';echo get_settings('siteurl');;echo '/wp-login.php" method="post"><h3>用户登录</h3>
<p>
<label>用户名：<input class="login" type="text" name="log" id="log" value="" size="12" /></label>
</p>
<p>
<label>密　码：<input class="login" type="password" name="pwd" id="pwd" value="" size="12" /></label>
</p>
<p>
<input class="denglu" type="submit" name="submit" value="登陆" /> <label>记住我 <input id="comment_mail_notify" type="checkbox" name="rememberme" value="forever" /></label>
</p>
<p>
<input type="hidden" name="redirect_to" value="';echo $_SERVER['REQUEST_URI'];;echo '"/>
</p>
</form>
';}
else {;echo '<h3>用户管理</h3>
<p><div class="v_avatar">';echo weisay_get_avatar($user_email,64);;echo '</div><div class="v_li">
			<li><a href="';bloginfo('url') ;echo '/wp-admin/" target="_blank">控制面板</a></li>
				<li><a href="';bloginfo('url') ;echo '/wp-admin/post-new.php" target="_blank">撰写文章</a></li>
				<li><a href="';bloginfo('url') ;echo '/wp-admin/edit-comments.php" target="_blank">评论管理</a></li>
				<li><a href="';bloginfo('url') ;echo '/wp-login.php?action=logout&amp;redirect_to=';echo urlencode($_SERVER['REQUEST_URI']) ;echo '">注销</a></li></div>
</p>
';};echo '<div class="clear"></div></div><div id="rollstart"></div>
<div class="hotarticle">'
;if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('小工具3(跟随滚动)') ) :
; endif;
;echo '</div></div></div>
</div></div>';
?>