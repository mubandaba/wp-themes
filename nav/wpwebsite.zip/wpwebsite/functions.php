<?php 
add_filter( 'auto_update_core', '__return_false' );
add_filter( 'pre_site_transient_update_core', create_function( '$a', "return null;" ) );
add_filter('pre_site_transient_update_plugins', create_function('$a', "return null;")); // 关闭插件提示
add_filter('pre_site_transient_update_themes',  create_function('$a', "return null;")); // 关闭主题提示
remove_action('admin_init', '_maybe_update_plugins'); // 禁止 WordPress 更新插件
remove_action('admin_init', '_maybe_update_themes');  // 禁止 WordPress 更新主题
/*显示页面查询次数、加载时间和内存占用*/
function performance( $visible = false ) {
	$stat = sprintf(  '%d queries in %.3f seconds, using %.2fMB memory',
		get_num_queries(),
		timer_stop( 0, 3 ),
		memory_get_peak_usage() / 1024 / 1024
	);
	echo $visible ? $stat : "<!-- {$stat} -->" ;
}
//add_action( 'wp_footer', 'performance', 20 );
/*功能加载*/
require get_template_directory() . '/include/leonhere-comments.php';
require get_template_directory() . '/include/postviews.php';
require get_template_directory() . '/include/ashuwp_framework_core.php';
require get_template_directory() . '/include/ashuwp_options_feild.php';
require get_template_directory() . '/include/ashuwp_termmeta_feild.php';
require get_template_directory() . '/include/ashuwp_postmeta_feild.php';
require get_template_directory() . '/include/import_export.php';
require get_template_directory() . '/include/config.php';
require get_template_directory() . '/include/news.php';
require get_template_directory() . '/widget/widget-news.php';
require get_template_directory() . '/widget/widget-new.php';
require get_template_directory() . '/widget/widget-hot.php';
require get_template_directory() . '/widget/widget-cmts.php';
/*速度优化部分*/
//禁止加载s.w.org并移动dns-prefetch
function remove_dns_prefetch( $hints, $relation_type ) {
    if ( 'dns-prefetch' === $relation_type ) {
		return array_diff( wp_dependencies_unique_hosts(), $hints );
    }
    return $hints;
}
add_filter( 'wp_resource_hints', 'remove_dns_prefetch', 10, 2 );
/*修改登陆地址*/
//add_action('login_enqueue_scripts','login_protection');  
function login_protection(){  
    	if($_GET['login'] != 'admin'){
		wp_redirect(get_bloginfo('url'));
	}  
}
/*隐藏前台管理栏*/
function hide_admin_bar($flag) {return false;}
add_filter('show_admin_bar','hide_admin_bar');
/*移除前端XML-RPC相关代码*/
remove_action('wp_head', 'rsd_link');
/*移除Windows Live Writer*/
remove_action('wp_head', 'wlwmanifest_link');
/*移除前端wordpress版本号*/
remove_action('wp_head', 'wp_generator');
/*移除日志相关的 Link*/
remove_action('wp_head', 'start_post_rel_link');
remove_action('wp_head', 'index_rel_link');
remove_action('wp_head', 'adjacent_posts_rel_link');
/*禁止wordpress 3.5+版本的aAuto Embeds*/
remove_filter( 'the_content', array( $GLOBALS['wp_embed'], 'autoembed' ), 8 );
/*禁用 XML-RPC 接口*/
add_filter('xmlrpc_enabled', '__return_false');
/*屏蔽 REST API，文章 Emebed 功能失效*/
add_filter('rest_enabled', '__return_false');
add_filter('rest_jsonp_enabled', '__return_false');
/*移除头部 wp-json 标签和 HTTP header 中的 link*/
remove_action( 'wp_head', 'rest_output_link_wp_head', 10 );
remove_action('template_redirect', 'rest_output_link_header', 11 );
/*禁用文章embeds功能并移除wp-embed.min.js文件*/
function disable_embeds_init() {
    global $wp;
    $wp->public_query_vars = array_diff( $wp->public_query_vars, array(
        'embed',
    ) );
    remove_action( 'rest_api_init', 'wp_oembed_register_route' );
    add_filter( 'embed_oembed_discover', '__return_false' );
    remove_filter( 'oembed_dataparse', 'wp_filter_oembed_result', 10 );
    remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
    remove_action( 'wp_head', 'wp_oembed_add_host_js' );
    add_filter( 'tiny_mce_plugins', 'disable_embeds_tiny_mce_plugin' );
    add_filter( 'rewrite_rules_array', 'disable_embeds_rewrites' );
}
add_action( 'init', 'disable_embeds_init', 9999 );
function disable_embeds_tiny_mce_plugin( $plugins ) {
    return array_diff( $plugins, array( 'wpembed' ) );
}
function disable_embeds_rewrites( $rules ) {
    foreach ( $rules as $rule => $rewrite ) {
        if ( false !== strpos( $rewrite, 'embed=true' ) ) {
            unset( $rules[ $rule ] );
        }
    }
    return $rules;
}
function disable_embeds_remove_rewrite_rules() {
    add_filter( 'rewrite_rules_array', 'disable_embeds_rewrites' );
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'disable_embeds_remove_rewrite_rules' );
function disable_embeds_flush_rewrite_rules() {
    remove_filter( 'rewrite_rules_array', 'disable_embeds_rewrites' );
    flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'disable_embeds_flush_rewrite_rules' );
/*前台不加载语言包*/
add_filter( 'locale', 'language_locale' );
function language_locale($locale) {
    $locale = ( is_admin() ) ? $locale : 'en_US';
    return $locale;
}
/*移除前台短链接*/
remove_action('wp_head', 'wp_shortlink_wp_head', 10, 0 );
/*移除前台feed链接*/
remove_action( 'wp_head', 'feed_links_extra', 3 ); 
/*禁止emoji并移除样式*/
remove_action('wp_head', 'print_emoji_detection_script', 7 );
remove_action('admin_print_scripts','print_emoji_detection_script');
remove_action('wp_print_styles', 'print_emoji_styles');
remove_action('admin_print_styles', 'print_emoji_styles');
/*恢复友情链接*/
add_filter( 'pre_option_link_manager_enabled', '__return_true' );
/*速度优化部分*/
function get_term_parents( $id, $link = false, $separator = '/', $nicename = false, $visited = array() ) {
	$chain = '';
	$parent = get_term( $id, 'topics' );
	if ( is_wp_error( $parent ) )
		return $parent;

	if ( $nicename )
		$name = $parent->slug;
	else
		$name = $parent->name;
	
	if ( $parent->parent && ( $parent->parent != $parent->term_id ) && !in_array( $parent->parent, $visited ) ) {
		$visited[] = $parent->parent;
		$chain .= get_term_parents( $parent->parent, $link, $separator, $nicename, $visited );		
	}

	if ( $link )
		$chain .= '<a href="' . esc_url( get_term_link( $parent->term_id ) ) . '">'.$name.'</a>' . $separator;
	else
		$chain .= $name.$separator;
	return $chain;
}
add_theme_support( 'post-thumbnails', array( 'post', 'page','news' ) );
function add_editor_buttons($buttons) {
	$buttons[] = 'fontselect';	
	$buttons[] = 'fontsizeselect';
	$buttons[] = 'cleanup';
	$buttons[] = 'styleselect';		
	$buttons[] = 'sub';
	$buttons[] = 'sup';
	$buttons[] = 'copy';
	$buttons[] = 'paste';
	$buttons[] = 'cut';
	$buttons[] = 'image';
	$buttons[] = 'anchor';
	$buttons[] = 'backcolor';
	$buttons[] = 'wp_page';	
	return $buttons;
}
add_filter("mce_buttons_3", "add_editor_buttons");
register_nav_menus(array('header-menu' => __( '<strong>顶部导航菜单</strong>' )));
function search_url_rewrite() {
    if ( is_search() && ! empty( $_GET['s'] ) && get_option('permalink_structure') != '') {
        wp_redirect( home_url( "/search/" ) . urlencode( get_query_var( 's' ) ) );
        exit();
    }
}
add_action( 'template_redirect', 'search_url_rewrite');
function exclude_page() {
	global $post;
	if ($post->post_type == 'page') {
		return true;
	} else {
		return false;
	}
}
function get_category_root_id($cat){
	$this_category = get_category($cat);
	while($this_category->category_parent){
		$this_category = get_category($this_category->category_parent);
	}
	return $this_category->term_id;
}
function get_term_root_id($term){
	$this_term = get_term( $term, 'topics' );
	while($this_term->parent){
		$this_term = get_term($this_term->parent,'topics');
	}
	return $this_term->term_id;
}
function rename_filename($filename) {
	$info = pathinfo($filename);
	$ext = empty($info['extension']) ? '' : '.' . $info['extension'];
	$name = basename($filename, $ext);
	return substr(md5($name), 0, 20) . $ext;
}
add_filter('sanitize_file_name', 'rename_filename', 10);
function post_is_in_descendant_category( $cats,$_post = null ){
	foreach ( (array) $cats as $cat ) {
		$descendants = get_term_children( (int) $cat,'category');
		if ( $descendants &&in_category( $descendants,$_post ) )
			return true;
		}
	return false;
}
if( function_exists('register_sidebar') ) {
	register_sidebars(5,array(
		'name' => '侧栏小工具 %d',
		'id' => 'sidebar',
		'description'   => '小工具 1 全站显示；小工具 2 只在首页显示；小工具 3 只在文章内容页显示；小工具 4 只在新闻内容页显示；小工具 5 只在分类页面显示',
		'before_widget' => '<section class="widget">',
		'after_widget' => '</section>',
		'before_title' => '<h3>',
		'after_title' => '</h3>'
	));
}
function get_category_tags($args) {
	global $wpdb;
	$tags = $wpdb->get_results
		("
            SELECT DISTINCT terms2.term_id as tag_id, terms2.name as tag_name
            FROM
                $wpdb->posts as p1
                LEFT JOIN $wpdb->term_relationships as r1 ON p1.ID = r1.object_ID
                LEFT JOIN $wpdb->term_taxonomy as t1 ON r1.term_taxonomy_id = t1.term_taxonomy_id
                LEFT JOIN $wpdb->terms as terms1 ON t1.term_id = terms1.term_id,
                $wpdb->posts as p2
                LEFT JOIN $wpdb->term_relationships as r2 ON p2.ID = r2.object_ID
                LEFT JOIN $wpdb->term_taxonomy as t2 ON r2.term_taxonomy_id = t2.term_taxonomy_id
                LEFT JOIN $wpdb->terms as terms2 ON t2.term_id = terms2.term_id
            WHERE
                t1.taxonomy = 'category' AND p1.post_status = 'publish' AND terms1.term_id IN (".$args['categories'].") AND
                t2.taxonomy = 'post_tag' AND p2.post_status = 'publish'
                AND p1.ID = p2.ID
            ORDER by tag_name
			LIMIT 5
        ");
        $count = 0;
        if($tags) {
			foreach ($tags as $tag) {
				$mytag[$count] = get_term_by('id', $tag->tag_id, 'post_tag');
				$count++;
			}
        }
        else {
			$mytag = NULL;
        }       
        return $mytag;
}
function catch_that_image() {
	global $post, $posts;
	$first_img = '';
	ob_start();
	ob_end_clean();
	$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
	$first_img = $matches [1] [0];
	if(empty($first_img)){
		$site_url = get_bloginfo('template_directory');
        $first_img = $site_url."/images/no-image.jpg";
	}
	return $first_img;
}
function get_breadcrumbs(){
    global $wp_query; 
	if(is_home()) {
		echo '<a href="'. get_option('home') .'" title="'. get_option('blogname').'">网站首页</a>';		
	}
    if ( !is_home() ){
        echo '<a href="'. get_option('home') .'" title="'. get_option('blogname').'">网站首页</a>';
        if ( is_category() ){
            $catTitle = single_cat_title( "", false );
            $cat = get_cat_ID( $catTitle );
            echo " <i>/</i> ". get_category_parents( $cat, TRUE, " <i>/</i> " );
        }elseif(is_tax()){
			$term = get_term_by('slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );
			echo ' <i>/</i> '. get_term_parents( $term->term_id, TRUE, " <i>/</i> " );
		}elseif(is_tag()){
			echo " <i>/</i> ";
			single_tag_title();
		}
        elseif ( is_archive())
        {
            echo " <i>/</i> ";
			wp_title('',true);
        }
        elseif ( is_search() ) { 
            echo " <i>/</i> 搜索结果";
        }
        elseif ( is_404() )
        {
            echo " <i>/</i> 404页面不存在";
        }
        elseif ( is_single() )
        {
			if(get_post_type() == 'news'){				
				$terms = get_the_terms( get_the_ID() , 'topics');
				echo ' <i>/</i> '. get_term_parents( $terms[0]->term_id, TRUE, " <i>/</i> " );
			}else{
				$category = get_the_category();
				$category_id = get_cat_ID( $category[0]->cat_name );
				echo ' <i>/</i> '. get_category_parents( $category_id, TRUE, " <i>/</i> " );   
			}			
        }
        elseif ( is_page() )
        {
            $post = $wp_query->get_queried_object();
            if ( $post->post_parent == 0 ){
                echo " <i>/</i> ".the_title('','', FALSE);
            } else {
                $title = the_title('','', FALSE);
                $ancestors = array_reverse( get_post_ancestors( $post->ID ) );
                array_push($ancestors, $post->ID);
                foreach ( $ancestors as $ancestor ){
                    if( $ancestor != end($ancestors) ){
                        echo ' <i>/</i> <a href="'. get_permalink($ancestor) .'">'. strip_tags( apply_filters( 'single_post_title', get_the_title( $ancestor ) ) ) .'</a>';
                    } else {
                        echo ' <i>/</i> '. strip_tags( apply_filters( 'single_post_title', get_the_title( $ancestor ) ) );
                    }
                }
            }
        }else{
			echo " <i>/</i> ";
			wp_title('',true);
		}       
    }
}
function tagtext(){
	global $post;
	$gettags = get_the_tags($post->ID);
	if ($gettags) {
		foreach ($gettags as $tag) {
		$posttag[] = $tag->name;
	}
	$tags = implode( ',', $posttag );
		return $tags;
	}
}
function leonhere_pagenavi($range = 9){
	global $paged, $wp_query;
	if ( !$max_page ) {$max_page = $wp_query->max_num_pages;}
	if($max_page > 1){if(!$paged){$paged = 1;}
	if($paged != 1){echo "<a href='" . get_pagenum_link(1) . "' class='extend' title='跳转到首页'> 首页 </a>";}
	previous_posts_link(' 上一页 ');
    if($max_page > $range){
		if($paged < $range){for($i = 1; $i <= ($range + 1); $i++){echo "<a href='" . get_pagenum_link($i) ."'";
		if($i==$paged)echo " class='oncurrent'";echo ">$i</a>";}}
    elseif($paged >= ($max_page - ceil(($range/2)))){
		for($i = $max_page - $range; $i <= $max_page; $i++){echo "<a href='" . get_pagenum_link($i) ."'";
		if($i==$paged)echo " class='oncurrent'";echo ">$i</a>";}}
	elseif($paged >= $range && $paged < ($max_page - ceil(($range/2)))){
		for($i = ($paged - ceil($range/2)); $i <= ($paged + ceil(($range/2))); $i++){echo "<a href='" . get_pagenum_link($i) ."'";if($i==$paged) echo " class='oncurrent'";echo ">$i</a>";}}}
    else{for($i = 1; $i <= $max_page; $i++){echo "<a href='" . get_pagenum_link($i) ."'";
    if($i==$paged)echo " class='oncurrent'";echo ">$i</a>";}}
	next_posts_link(' 下一页 ');
    if($paged != $max_page){echo "<a href='" . get_pagenum_link($max_page) . "' class='extend' title='跳转到最后一页'> 末页 </a>";}}
}
function copyrightDate() {
	global $wpdb;
	$copyright_dates = $wpdb->get_results("
		SELECT
			YEAR(min(post_date_gmt)) AS firstdate,
			YEAR(max(post_date_gmt)) AS lastdate
		FROM
			$wpdb->posts
		WHERE post_status = 'publish'
	");
	if($copyright_dates) {
		$date = date('Y-m-d');
		$date = explode('-', $date);
		$copyright = "Copyright &copy; " . $copyright_dates[0]->firstdate;
		if($copyright_dates[0]->firstdate != $date[0]) {
			$copyright .= '-' . $date[0];
		}
		echo $copyright;
	}
}
function redirect(){
	$request = $_SERVER['REQUEST_URI'];
	$goArray = explode('/',$request);
	$goid = array_pop($goArray);
	if(in_array('go',$goArray) && is_numeric($goid)){		
		$url = get_post_meta($goid,'url',true);
		if($url){
			wp_redirect($url,301);
			exit;
		}
	}
}
add_action('init','redirect');
// 说明：获取完整URL
function curPageURL(){
    $pageURL = 'http';
    if (isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] == "on"){
        $pageURL .= "s";
    }
    $pageURL .= "://";
    if ($_SERVER["SERVER_PORT"] != "80")
    {
        $pageURL .= $_SERVER["SERVER_NAME"] . ":" . $_SERVER["SERVER_PORT"] . $_SERVER["REQUEST_URI"];
    }
    else
    {
        $pageURL .= $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"];
    }
    return $pageURL;
}

//联系我们
function spam_protection_math(){
	$num1=rand(0,9);
	$num2=rand(0,9);
	echo "<label for=\"math\">输入结果：<i>*</i></label>\n";
	echo "<input type=\"text\" name=\"sum\" class=\"text\" value=\"\" size=\"25\" tabindex=\"4\">\n";
	echo "<input type=\"hidden\" name=\"num1\" value=\"$num1\">\n";
	echo "<input type=\"hidden\" name=\"num2\" value=\"$num2\">";
	echo "<span>$num1 + $num2 = ? 的计算结果：</span>";
}
add_action('template_redirect', 'submit_site');
function submit_site(){
	$current_url = get_bloginfo('url'); 
	if(is_page()){
		if (!isset($_SESSION)) {
			session_start();
			session_regenerate_id(TRUE);
		}
		if( isset($_POST['submitsite']) && $_POST['submitsite'] == 'send') {
			$num = $_POST['num1']+$_POST['num2'];
			$sum = isset( $_POST['sum'] ) ? trim(htmlspecialchars($_POST['sum'], ENT_QUOTES)) : '';
			if(empty($sum)){
				wp_die('对不起: 请输入计算结果。<a href="javascript:history.back(-1);">点此返回</a>','提交失败');
			}elseif($sum != $num){
				wp_die('对不起: 计算结果错误，请<a href="javascript:history.back(-1);">返回重试</a>。','提交失败');
			}
			global $wpdb;			
			$last_post = $wpdb->get_var("SELECT `post_date` FROM `$wpdb->posts` ORDER BY `post_date` DESC LIMIT 1");
			if ( current_time('timestamp') - strtotime($last_post) < 120 ) {
				wp_die('您已提交过网站，请耐心等等审核。<a href="'.$current_url.'">点此返回首页</a>','提交失败');
			}
			$website = isset( $_POST['website'] ) ? trim(htmlspecialchars($_POST['website'], ENT_QUOTES)) : '';
			$logo =  isset( $_POST['logo'] ) ? trim(htmlspecialchars($_POST['logo'], ENT_QUOTES)) : '';
			$url =  isset( $_POST['url'] ) ? trim(htmlspecialchars($_POST['url'], ENT_QUOTES)) : '';
			$sitecat =  isset( $_POST['cat'] ) ? trim(htmlspecialchars($_POST['cat'], ENT_QUOTES)) : '';			
			$reason =  isset( $_POST['reason'] ) ? trim(htmlspecialchars($_POST['reason'], ENT_QUOTES)) : '';
			if ( empty($website)) {
				wp_die('网站名称必须填写，且长度不得超过15字。<a href="'.$current_url.'">点此返回首页</a>','提交失败');
			}   
			if ( empty($url)) {
				wp_die('网站地址必须填写。<a href="javascript:history.back(-1);">点此返回</a>','提交失败');
			}elseif(!filter_var($url, FILTER_VALIDATE_URL)){
				wp_die('网站地址格式不正确，请重新输入。<a href="javascript:history.back(-1);">点此返回</a>','提交失败');
			}
			if ( empty($reason) || mb_strlen($reason) < 20) {
				wp_die('咨询内容必须填写，且长度不得小于20字。<a href="javascript:history.back(-1);">点此返回</a>','提交失败');
			}
			$submitsite = array(
				'comment_status' => 'closed',
				'ping_status' => 'closed',
				'post_title' => $website,
				'post_status' => 'private',
				'post_type' => 'post',
				'post_category' => array($sitecat),
				'post_content' => $reason,
			);
			$status = wp_insert_post( $submitsite ); 
			if ($status != 0) {
				add_post_meta($status, 'logo', $logo); 
				add_post_meta($status, 'url', $url);
				wp_die('提交成功！审核通过后显示！<a href="'.$current_url.'">点此返回首页</a>', '提交成功');		
			}else {
				wp_die('提交失败！<a href="'.$current_url.'">点此返回首页</a>','提交失败');
			}
		}
	}
}
?>