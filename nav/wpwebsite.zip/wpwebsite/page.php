<?php get_header();?>
<div class="inner content">	
	<aside class="sidebar">
		<nav id="menu">
			<ul>
			<?php 
				$parent_page = $post->ID;
				while($parent_page) {
					$page_query = $wpdb->get_row("SELECT ID, post_title, post_status, post_parent FROM $wpdb->posts WHERE ID = '$parent_page'");
					$parent_page = $page_query->post_parent;
				}
				$parent_id = $page_query->ID;
				$parent_title = $page_query->post_title;
				if ($wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_parent = '$parent_id' AND post_status != 'attachment'")) {
					$subpage = wp_list_pages('depth=1&echo=0&child_of='.$parent_id); 
					if($subpage) { 
						if(get_page_link($parent_id) == curPageURL()){
							$cur = ' class="current_page_item"';
						}else{
							$cur ='';
						}
						echo '<li'.$cur.'><a href="'.get_page_link($parent_id).'" title="'.$parent_title.'">'.$parent_title.'</a></li>';
						wp_list_pages('depth=1&sort_column=menu_order&title_li=&child_of='. $parent_id);
					}else{
						wp_list_pages('depth=1&sort_column=menu_order&title_li=');
					}
				}
			?>
			</ul>
		</nav>
	</aside>
	<main class="main">
	<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>	
		<article class="post">
			<h1 class="post-title"><?php the_title();?></h1>
			<div class="entry">
				<?php the_content();?>
			</div>
			<?php comments_template('',true); ?>
		</article>
		<?php endwhile; ?>
		<?php else : ?>
		<div class="post">
			你要找的页面已删除或不存在
		</div>
		<?php endif;?>
	</main>
</div>
<?php get_footer();?>