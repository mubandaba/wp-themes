<div class="pagenavi">
<?php 
	if(function_exists('wp_pagenavi')) { 
		wp_pagenavi();
	}else{
		leonhere_pagenavi(7);
	}
?>
</div>