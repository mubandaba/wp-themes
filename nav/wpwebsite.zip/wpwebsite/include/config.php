<?php
/**
*Version: 4.3
**/
$categories_array = get_categories('hide_empty=0');
$pages_array = get_pages('hide_empty=0');
$categories = array();
$pages = array();
foreach ($pages_array as $pagg) {
	$pages[$pagg->ID] = $pagg->post_title;
}
foreach ($categories_array as $categs) {
	$categories[$categs->cat_ID] = $categs->cat_name;
}
$bloghost = get_bloginfo('url');
/**
*
*post meta test
*
**/
/*****Meta Box********/
$leonhere_postset = array();
$postset_conf = array('title' => '参数设置', 'id'=>'post_settings', 'page'=>array('post'), 'context'=>'normal', 'priority'=>'low');
$leonhere_postset[] = array(
  'name' => '网站LOGO',
  'id'   => 'logo',
  'desc' => '要导航的网站LOGO图片，建议150px * 150px以上尺寸',
  'std'  => '',
  'button_text' => '上传',
  'type' => 'upload'
);
$leonhere_postset[] = array(
  'name' => '编辑点评',
  'id'   => 'review',
  'desc' => '一句话点评，最好在20个字左右',
  'std'  => '',
  'type' => 'text'
);
$leonhere_postset[] = array(
  'name' => '网站地址',
  'id'   => 'url',
  'desc' => '目标网站地址',
  'std'  => '',
  'type' => 'text'
);
$leonhere_postset[] = array(
  'name' => '是否直接跳转',
  'id'   => 'redirect',
  'desc' => '首页导航点击是否直接跳转到目标网站，默认进入内页',
  'std'  => 'no',
  'buttons' => array(
    'yes'      => '直接跳转',
    'no'    => '进入内页',    
  ),
  'type'    => 'radio'
);
$setting_box = new ashuwp_postmeta_feild($leonhere_postset, $postset_conf);
/*****Meta Box********/
$leonhere_postseo = array();
$postseo_conf = array('title' => 'SEO设置', 'id'=>'post_seo', 'page'=>array('post','page','news'), 'context'=>'normal', 'priority'=>'low');
$leonhere_postseo[] = array(
  'name' => '自定义标题',
  'id'   => 'title',
  'desc' => '自定义页面标题，用于SEO优化',
  'std'  => '',
  'type' => 'text'
);
$leonhere_postseo[] = array(
  'name' => '自定义关键词',
  'id'   => 'keywords',
  'desc' => '自定义页面关键词，用于SEO优化',
  'std'  => '',
  'type' => 'text'
);
$leonhere_postseo[] = array(
  'name' => '自定义描述',
  'id'   => 'description',
  'desc' => '自定义页面描述，用于SEO优化',
  'std'  => '',
  'type' => 'textarea'
);
$new_box = new ashuwp_postmeta_feild($leonhere_postseo, $postseo_conf);
/**
*
*taxonomy feild test
*
**/
/*****taxonomy feild ******/
$leonhere_catfeild = array();
$category_cof = array('category');
$leonhere_catfeild[] = array(
  'name'      => '显示LOGO',
  'id'        => '_sitelogo',
  'desc'      => '该栏目下的站点在首页导航中是否显示LOGO，默认显示',
  'std'     => 'show',
  'buttons' => array(
    'show'      => '显示',
    'hide'    => '不显示',    
  ),
  'type'    => 'radio'
);
$leonhere_catfeild[] = array(
  'name'      => '显示数量',
  'id'        => '_sitenum',
  'desc'      => '该栏目下的站点在首页导航中显示数量，默认显示6个',
  'std'     => '6',  
  'type'    => 'text'
);
$ashuwp_termmeta_feild = new ashuwp_termmeta_feild($leonhere_catfeild, $category_cof);
/*****taxonomy feild ******/
$leonhere_feild = array();
$taxonomy_cof = array('category','post_tag','topics');
$leonhere_feild[] = array(
  'name'      => '栏目标题',
  'id'        => '_category_title',
  'desc'      => '自定义栏目标题，用于SEO优化',
  'std'       => '',
  'edit_only' => false,
  "type"      => "text"
);
$leonhere_feild[] = array(
  'name'      => '栏目关键词',
  'id'        => '_category_keywords',
  'desc'      => '自定义栏目关键词，用于SEO优化',
  'std'       => '',
  'edit_only' => false,
  "type"      => "text"
);
$leonhere_feild[] = array(
  'name'      => '栏目描述',
  'id'        => '_category_description',
  'desc'      => '自定义栏目描述，用于SEO优化',
  'std'       => '',
  'edit_only' => false,
  "type"      => "textarea"
);
$ashuwp_termmeta_feild = new ashuwp_termmeta_feild($leonhere_feild, $taxonomy_cof);
/**
*
*Optinos page
*
**/
/**Child options page width tab style**/
$settings_info = array(
  'full_name' => '主题设置',
  'optionname'=>'leonhere',
  'child'=>false,  
  'filename' => 'theme-settings'
);

$leonhere_option = array();
/**first tab**/
$leonhere_option[] = array(
  'name' => '基础设置',
  'id'   => 'option_tab1',
  'type' => 'open',
);
$leonhere_option[] = array(
  'name' => 'LOGO图片',
  'id'   => '_logo',
  'desc' => 'LOGO图片尺寸：174px × 46px',
  'std'  => get_bloginfo('template_url').'/images/logo.png',
  'button_text' => '上传图片',
  'type' => 'upload'
);
$leonhere_option[] = array(
  'name'      => '摘要字数',
  'id'        => '_intro',
  'desc'      => '列表页面自动摘要显示文字数量，默认120字符，<b>对新闻列表无效</b>',
  'std'       => '120',
  'edit_only' => false,
  "type"      => "text"
);
$leonhere_option[] = array(
  'name'      => '网站备案号',
  'id'        => '_icp',
  'desc'      => '输入网站ICP备案号，没有则留空',
  'std'       => '',
  'edit_only' => false,
  "type"      => "text"
);

$leonhere_option[] = array(
  'type' => 'close',
);
/**second tab**/
$leonhere_option[] = array(
  'name' => '栏目设置',
  'id'   => 'option_tab2',
  'type' => 'open',
);
$leonhere_option[] = array(
  'name'    => '新闻动态',
  'id'      => '_news',
  'desc'    => '网站右上角轮播新闻要调用的栏目，请先在后台——右侧——新闻——新闻分类里创建分类目录',
  'std'     => '',
  'subtype' => 'topics',
  'type'    => 'select'
);
$leonhere_option[] = array(
  'name'    => '导航栏目',
  'id'      => '_website',
  'desc'    => '首页导航栏目录要调用的分类',
  'std'     => '',
  'buttons' => $categories,
  'type'    => 'checkbox'
);
$leonhere_option[] = array(
  'type' => 'close',
);
/**third tab**/
$leonhere_option[] = array(
  'name' => '广告设置',
  'id'   => 'option_tab3',
  'type' => 'open',
);
$leonhere_option[] = array(
  'name'      => '列表中间广告',
  'id'        => '_listAd',
  'desc'      => '首页[品牌推荐]下的横幅广告，支持HTML代码，最大宽度 970px，高度自适应',
  'std'       => '',
  'edit_only' => false,
  "type"      => "textarea"
);
$leonhere_option[] = array(
  'name'      => '导航介绍文章内容广告',
  'id'        => '_siteStart',
  'desc'      => '导般网站介绍的正文开头上边的广告，支持HTML，最大宽度930px，高度自适应。注：只对后台——文章下的内容页面有效',
  'std'       => '',
  'edit_only' => false,
  "type"      => "textarea"
);
$leonhere_option[] = array(
  'name'      => '新闻文章内容广告',
  'id'        => '_articleStart',
  'desc'      => '新闻纯文章内容开头上边广告，支持HTML，最大宽度930px，高度自适应。注：只对后台——新闻下的内容页面有效',
  'std'       => '',
  'edit_only' => false,
  "type"      => "textarea"
);
$leonhere_option[] = array(
  'name'      => '文章评论上方广告',
  'id'        => '_cmtAd',
  'desc'      => '文章评论上边的广告，支持HTML，建议最大宽度930px',
  'std'       => '',
  'edit_only' => false,
  "type"      => "textarea"
);
$leonhere_option[] = array(
  'type' => 'close',
);
/**fourth tab**/
$leonhere_option[] = array(
  'name' => 'SEO设置',
  'id'   => 'option_tab4',
  'type' => 'open',
);
$leonhere_option[] = array(
  'name'    => '主题SEO功能',
  'id'      => '_seo',
  'desc'    => '选择是否关闭主题自带的SEO功能，关闭后，主题自带的首页、分类、文章的自定义标题、关键词、描述设置将不生效，默认开启',
  'std'     => 'start',
  'buttons' => array(
    'close'      => '关闭',
    'start'    => '开启',    
  ),
  'type'    => 'radio'
);
$leonhere_option[] = array(
  'name'      => '自定义标题',
  'id'        => '_title',
  'desc'      => '自定义网站title标题',
  'std'       => '',
  'edit_only' => false,
  "type"      => "text"
);
$leonhere_option[] = array(
  'name'      => '自定义关键词',
  'id'        => '_keywords',
  'desc'      => '自定义网站关键词',
  'std'       => '',
  'edit_only' => false,
  "type"      => "text"
);
$leonhere_option[] = array(
  'name'      => '自定义描述',
  'id'        => '_description',
  'desc'      => '自定义网站描述',
  'std'       => '',
  'edit_only' => false,
  "type"      => "textarea"
);
$leonhere_option[] = array(
  'name'      => '标题间隔符',
  'id'        => '_separator"',
  'desc'      => '自定义网页标题间隔符，默认_',
  'std'       => '_',
  'edit_only' => false,
  "type"      => "text"
);
$leonhere_option[] = array(
  'name'    => '友情链接显示',
  'id'      => '_links',
  'desc'    => '请选择友情链接的显示范围',
  'std'     => 'home',
  'subtype' => array(
    'home'  => '首页',
    'all' => '全站',
    'close' => '关闭',    
  ),
  'type' => 'select'
);
$leonhere_option[] = array(
  'name'      => '网站统计',
  'id'        => '_statistic',
  'desc'      => '输入网站统计代码，如百度统计、cnzz统计等',
  'std'       => '',
  'edit_only' => false,
  "type"      => "textarea"
);
$leonhere_option[] = array(
  'type' => 'close',
);
$child_page = new ashuwp_options_feild($leonhere_option, $settings_info);
/**
*
*import-export page
*
**/
/****import-export*****/
$import_info = array(
  'full_name' => '导入/导出',
  'child'=>true,
  'parent_slug'=>'theme-settings',
  'filename' => 'import_page'
);
$import_page = new ashuwp_option_import_class($import_info);
?>