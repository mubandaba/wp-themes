<?php 
function leonhere_news() {
  $labels = array(
    'name'               => _x( '所有新闻', 'post type 名称' ),
    'singular_name'      => _x( '新闻', 'post type 单个 item 时的名称，因为英文有复数' ),
    'add_new'            => _x( '添加新闻', '添加新内容的链接名称' ),
    'add_new_item'       => __( '添加一个新闻' ),
    'edit_item'          => __( '编辑新闻' ),
    'new_item'           => __( '新的新闻' ),
    'all_items'          => __( '所有新闻' ),
    'view_item'          => __( '查看新闻' ),
    'search_items'       => __( '搜索新闻' ),
    'not_found'          => __( '没有找到有关新闻' ),
    'not_found_in_trash' => __( '回收站里面没有相关新闻' ),
    'parent_item_colon'  => '',
    'menu_name'          => '新闻'
  );
  $args = array(
    'labels'        => $labels,
    'description'   => '我们公司的新闻信息',
    'public'        => true,
    'menu_position' => 5,
    'supports'      => array('title','editor','thumbnail','comments'),
	'taxonomies' => array('post_tag'),	
    'has_archive'   => true
  );
  register_post_type( 'news', $args );
}
add_action( 'init', 'leonhere_news' );
function my_taxonomies_news() {
  $labels = array(
    'name'              => _x( '新闻分类', 'taxonomy 名称' ),
    'singular_name'     => _x( '新闻分类', 'taxonomy 单数名称' ),
    'search_items'      => __( '搜索新闻分类' ),
    'all_items'         => __( '所有新闻分类' ),
    'parent_item'       => __( '该新闻分类的上级分类' ),
    'parent_item_colon' => __( '该新闻分类的上级分类：' ),
    'edit_item'         => __( '编辑新闻分类' ),
    'update_item'       => __( '更新新闻分类' ),
    'add_new_item'      => __( '添加新的新闻分类' ),
    'new_item_name'     => __( '新的新闻分类' ),
    'menu_name'         => __( '新闻分类' ),
  );
  $args = array(
    'labels' => $labels,
    'public'            => true,
        'show_in_nav_menus' => true,
        'hierarchical'      => true,
        'show_ui'           => true,		
        'query_var'         => true,		
        'rewrite'           => true,
        'show_admin_column' => true
  );
  register_taxonomy( 'topics', 'news', $args );
}
add_action( 'init', 'my_taxonomies_news', 0 );

//自定义文章模板
add_filter( 'template_include', 'include_template_function', 1 );
function include_template_function( $template_path ) {
    if ( get_post_type() == 'news' ) {
        if ( is_single() ) {
            if ( $theme_file = locate_template( array ( 'single-news.php' ) ) ) {
                $template_path = $theme_file;
            } else {
                $template_path = locate_template( array ( 'single.php' ) );
            }
        }
    }
    return $template_path;
}
//自定义固定链接
add_filter('post_type_link', 'custom_news_link', 1, 3);
function custom_news_link( $link, $post = 0 ){
    if ( $post->post_type == 'news' ){
        return home_url( 'news/' . $post->ID .'.html' );
    } else {
        return $link;
    }
}
add_action( 'init', 'news_rewrites_init' );
function news_rewrites_init(){
    add_rewrite_rule(
        'news/([0-9]+)?.html$',
        'index.php?post_type=news&p=$matches[1]',
        'top' );
    add_rewrite_rule(
        'news/([0-9]+)?.html/comment-page-([0-9]{1,})$',
        'index.php?post_type=news&p=$matches[1]&cpage=$matches[2]',
        'top'
        );
}
//添加主循环
add_action( 'pre_get_posts', 'add_my_post_types_to_query' );
function add_my_post_types_to_query( $query ) {
  if ( is_tag() && $query->is_main_query() )
    $query->set( 'post_type', array( 'post', 'news' ) );
  return $query;
}
?>