<?php get_header();?>
<div class="inner container">	
	<main class="main">
		<div class="breadcrumb"><?php get_breadcrumbs();?></div>
		<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
		<article class="section">
			<div class="site-logo">
				<a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title();?>"><?php get_template_part('include/thumbnail');?></a>
				<?php if(is_sticky()){?>
				<i>精</i>
				<?php } ?>
			</div>
			<div class="site-intro">
				<h2><a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title();?>"><?php the_title();?></a></h2>
				<div class="excerpt">
				<?php 
					if($leonhere_option["leonhere"]["_intro"]){
						$intro = $leonhere_option["leonhere"]["_intro"];
					}else{
						$intro = '120';
					}
				?>
					<p><?php echo wp_trim_words($post->post_content, $intro, '...');?></p>
				</div>
				<div class="site-more">
					<a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title();?>">查看点评</a>
				</div>
			</div>
			
		</article>
		<?php endwhile;?>		
		<?php get_template_part('include/pagenavi');?>
		<?php else: ?>
		<div class="post">
			<p>很抱歉，该栏目下暂未添加内容，请先浏览网站其它内容！</p>
		</div>
	<?php endif;?>
	</main>
	<?php get_sidebar();?>
</div>
<?php get_footer();?>