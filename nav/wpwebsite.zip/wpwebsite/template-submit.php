<?php 
/*
Template Name:网站提交
*/
get_header();
?>
<main class="inner content">	
<?php if (have_posts()) : ?>
	<?php while (have_posts()) : the_post(); ?>	
	<article class="post">
		<h1 class="post-title"><?php the_title();?></h1>
		<div class="entry">
			<?php the_content();?>
		</div>
		<div class="submit_site">
			<form action="" method="post">
				<div class="submit_input">
					<label>网站名称：<i>*</i></label>
					<input type="text" class="text" name="website" value="<?php if(isset($_POST['website'])) echo $_POST['website'];?>" tabindex="1"/>
					<span>输入提交的网站名称</span>
				</div>
				<div class="submit_input">
					<label>logo图片：</label>
					<input type="text" class="text" name="logo" value="<?php if(isset($_POST['logo'])) echo $_POST['logo'];?>" tabindex="2"/>
					<span>输入LOGO图片绝对URL</span>
				</div>
				<div class="submit_input">
					<label>网站地址：<i>*</i></label>
					<input type="text" class="text" name="url" value="<?php if(isset($_POST['url'])) echo $_POST['url'];?>" tabindex="3"/>
					<span>网站地址以http://或https://开头</span>
				</div>				
				<div class="submit_input">
					<label>提交栏目：<i>*</i></label>
					<?php wp_dropdown_categories('hide_empty=0&id=sitecat&show_count=0&hierarchical=1'); ?>
					<span>审核通过后，将会显示在选择的栏目下</span>
				</div>
				<div class="submit_input">
					<label>推荐理由：<i>*</i></label>
					<textarea name="reason"></textarea>
					<span>为什么提交这个网站？不少于20字</span>
				</div>
				<div class="submit_input submit_verify">
					<?php spam_protection_math();?>
				</div>
				<div class="submit">
					<input type="hidden" value="send" name="submitsite" />
					<input type="submit" value="立即提交"/>
				</div>
			</form>
		</div>
	</article>
	<?php endwhile; ?>
	<?php else : ?>
	<div class="post">
		你要找的页面已删除或不存在
	</div>
<?php endif;?>	
</main>
<?php get_footer();?>