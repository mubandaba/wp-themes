<aside class="sidebar">
<?php 
	if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('sidebar')) : endif;
	if(is_home()){
		if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('sidebar-2')) : 
		endif;
	}elseif(is_category() || is_archive()){
		if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('sidebar-5')) : 
		endif;
	}elseif(is_single()){
		if(get_post_type() == 'news'){
			if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('sidebar-4')) : 
			endif;
		}else{
			if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('sidebar-3')) : 
			endif;
		}		
	}
?>
</aside>