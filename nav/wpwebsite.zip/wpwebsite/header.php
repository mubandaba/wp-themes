<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="UTF-8"/>
<meta http-equiv="Cache-Control" content="no-transform"/>
<meta http-equiv="Cache-Control" content="no-siteapp"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<?php 
	global $leonhere_option;
	if(is_tax()){		
		$term = get_term_by('slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );
		$termid = $term->term_id;
		$cat_title = get_term_meta($termid ,'_category_title',true);		
	}
	if($leonhere_option["leonhere"]["_seo"] == 'start'){	
?>
<title><?php if($paged > 1){echo ('第'); echo ($paged); echo '页'; if($leonhere_option["leonhere"]["_separator"]){ echo $leonhere_option["leonhere"]["_separator"];}else {echo '_';}}?><?php if (is_home()){if($leonhere_option["leonhere"]["_title"]){echo $leonhere_option["leonhere"]["_title"];}else {bloginfo('name'); if($leonhere_option["leonhere"]["_separator"]){echo $leonhere_option["leonhere"]["_separator"];}else {echo '_';} bloginfo('description');}}elseif (is_category()){if(get_term_meta($cat ,'_category_title',true)){echo get_term_meta($cat ,'_category_title',true);} else{single_cat_title(); if($leonhere_option["leonhere"]["_separator"]){ echo $leonhere_option["leonhere"]["_separator"];}else {echo '_';} bloginfo('name');}} elseif(is_tax()){if($cat_title){echo $cat_title;} else{single_cat_title(); if($leonhere_option["leonhere"]["_separator"]){ echo $leonhere_option["leonhere"]["_separator"];}else {echo '_';} bloginfo('name');}}elseif(is_single() || is_page()) {if(get_post_meta($post->ID, "title", true)){echo get_post_meta($post->ID, "title", true); if($leonhere_option["leonhere"]["_separator"]){ echo $leonhere_option["leonhere"]["_separator"];}else {echo '_';} bloginfo('name');}else{single_post_title(); if($leonhere_option["leonhere"]["_separator"]){echo $leonhere_option["leonhere"]["_separator"];}else {echo '_';}bloginfo('name'); }} elseif(is_search()) {echo "全站搜索结果:"; echo wp_specialchars($s);} else{ wp_title('',true); if($leonhere_option["leonhere"]["_separator"]){ echo $leonhere_option["leonhere"]["_separator"];}else {echo '_';} bloginfo('name'); } ?></title>
<?php 
if(is_home()){ 
	if($leonhere_option["leonhere"]["_keywords"]) { 
		$keywords = $leonhere_option["leonhere"]["_keywords"]; 
	} else { 
		$keywords = get_bloginfo('name');
	}
	if($leonhere_option["leonhere"]["_description"]) { 
		$description = $leonhere_option["leonhere"]["_description"]; 
	} else { 
		$description = get_bloginfo('description');
	}
?>
<meta name="keywords" content="<?php echo $keywords;?>"/>
<meta name="description" content="<?php echo $description;?>"/>
<?php }elseif(is_category()){
	$cat_des = get_term_meta($cat ,'_category_description',true);	
	$cat_keywords = get_term_meta($cat ,'_category_keywords',true);
?>
<meta name="keywords" content="<?php echo $cat_keywords;?>"/>
<meta name="description" content="<?php echo $cat_des;?>"/>
<?php }elseif(is_tax()){
	$cat_des = get_term_meta($termid ,'_category_description',true);	
	$cat_keywords = get_term_meta($termid ,'_category_keywords',true);
?>	
<meta name="keywords" content="<?php echo $cat_keywords;?>"/>
<meta name="description" content="<?php echo $cat_des;?>"/>
<?php } elseif(is_single()) {
	if(get_post_meta($post->ID, "description", true)){
		$description = get_post_meta($post->ID, "description", true);		
	}else{
		$description = wp_trim_words($post->post_content, 110, '...');		
		$description = str_replace("\n","",$description);		
	}
	if(get_post_meta($post->ID, "keywords", true)){
		$keywords = get_post_meta($post->ID, "keywords", true);
	}else{
		$keywords = tagtext();
	}
?>
<meta name="keywords" content="<?php echo $keywords; ?>"/>
<meta name="description" content="<?php echo $description;?>"/>
<?php }elseif(is_page()){
	if(get_post_meta($post->ID, "description", true)){
		$description = get_post_meta($post->ID, "description", true);
	}else{
		$description = wp_trim_words($post->post_content,110,'...');
		$description=str_replace("\n","",$description);
	}
?>
<meta name="description" content="<?php echo $description;?>"/>
<?php
	if(get_post_meta($post->ID, "keywords", true)){
		$keywords = get_post_meta($post->ID, "keywords", true);
?>
<meta name="keywords" content="<?php echo $keywords; ?>"/>
<?php } } }else{?>
<title><?php if (is_home()){bloginfo('name'); echo '_'; bloginfo('description');}else{ wp_title('',true); echo '_'; bloginfo('name'); } ?></title>
<?php } ?>
<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_url'); ?>" media="screen" />
<!--[if lt IE 9]>
<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/html5-css3.js"></script>
<![endif]-->
<?php wp_head();?>
</head>
<body <?php body_class(); ?>>
<header class="header">
	<div class="inner">
		<div class="logo">
		<?php 
			if(!empty($leonhere_option["leonhere"]["_logo"])){
				$logo = $leonhere_option["leonhere"]["_logo"];
			}else{
				$logo = get_bloginfo('template_url')."/images/logo.png";
			}
		?>
			<a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>"><img src="<?php echo $logo;?>" alt="<?php bloginfo('name'); ?>"/></a>
		</div>
		<div class="search-form">
			<form method="get" id="searchform" action="<?php bloginfo('url');?>/">
				<input type="text" class="s" name="s" placeholder="输入工具名称，如域名" value=""/>
				<input type="submit" class="submit" name="submit" value="查找"/>
			</form>
		</div>
		<?php 
		if(!empty($leonhere_option["leonhere"]["_news"])){	
			$news = $leonhere_option["leonhere"]["_news"];
			$term = get_term($news,'topics');
			$getposts = get_posts(array(
				'numberposts' => $newsnum,
				'post_type' => 'news',			
				'tax_query'=>array(
					array(
						'taxonomy'=>'topics',
						'terms'=>$news
						)
					),
				)
			);
			if($getposts):
		?>
		<div class="notice">
			<ul class="newsList">
				<?php foreach($getposts as $post):?>
				<li><a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title();?>"><?php the_title();?></a></li>
				<?php wp_reset_postdata(); endforeach;?>
			</ul>
			<ul class="swap"></ul>
		</div>
		<?php endif;  } ?>
		<div class="mobilesch">
			<i class="schbtn"></i>
		</div>
		<div class="mobilenav">
			<div class="navbtn">
				<i></i><i></i><i></i>
			</div>
		</div>
		<div class="clear"></div>
	</div>
</header>
<nav class="nav">
	<?php 
		if(function_exists('wp_nav_menu')){
			wp_nav_menu( array('theme_location' =>'header-menu','container' => 'div','container_class' => 'inner menu','menu_class' => 'inner menu','depth' => 0,'items_wrap' => '<ul class="menus">%3$s</ul>'));
		}
	?>	
</nav>
<div class="blank"></div>