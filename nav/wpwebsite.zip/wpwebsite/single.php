<?php get_header();?>
<?php global $leonhere_option;?>
<div class="inner container">	
	<main class="main">
		<div class="breadcrumb"><?php get_breadcrumbs();?></div>
		<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>	
		<article class="site-post">
			<div class="site-logo">
				<?php get_template_part('include/thumbnail');?>
			</div>
			<div class="site-info">
				<h1><?php the_title();?><?php if(is_sticky()){echo '[荐]'; } ?></h1>
				<ul>
					<li>更新日期：<?php the_time('Y-m-d');?></li>
					<li>查看次数：<?php setPostViews(get_the_ID()); echo getPostViews(get_the_ID()); ?></li>
					<li>点评次数：<?php comments_number('0','1','%'); ?></li>
					<li>编辑寄语：<?php echo get_post_meta($post->ID, "review", true);?></li>
				</ul>
				
			</div>
			<div class="site-go">
				<a rel="nofollow" href="<?php if(get_option('permalink_structure')==''){echo get_post_meta($post->ID, "url", true);}else{bloginfo('url');?>/go/<?php the_ID();}?>" target="_blank">立即前往</a>
			</div>
			<div class="site-content">
				<?php if(!empty($leonhere_option["leonhere"]["_siteStart"])){?>
				<div class="post-ad">
				<?php echo $leonhere_option["leonhere"]["_siteStart"];?>
				</div>
				<?php } ?>
				<div class="site-entry">				
				<h4>网站介绍</h4>
				<?php the_content();?>
				</div>				
				<section class="news-related">
					<h3>相关资讯</h3>
					<ul>
					<?php 
						$tags = wp_get_post_tags($post->ID);
						if ($tags) {
							$first_tag = $tags[0]->term_id;							
							$args=array(
								'post_type'=>'news',
								'tag__in' => array($first_tag),
								'post__not_in' => array($post->ID),
								'showposts'=>'10',
								'caller_get_posts'=>1
							);
							$my_query = new WP_Query($args);
							if( $my_query->have_posts() ) {
								while ($my_query->have_posts()) : $my_query->the_post(); 
					?>
						<li><a title="<?php the_title();?>" href="<?php the_permalink(); ?>" target="_blank"><?php the_title();?></a></li>
					<?php 
								endwhile; 
							} 
						}else{
							echo '“暂无相关资讯”';
						} 
						wp_reset_query();
					?>
					</ul>
				</section>
				
			</div>
			
			<section class="site-related">				
				<ul>
				<?php 
				$categories = get_the_category();				
				$posts = get_posts('numberposts=6&category='. $categories[0]->term_id);
				foreach($posts as $post):
				setup_postdata( $post );
				?>
					<li>
						<div class="site-logo">
							<a title="<?php the_title();?>" href="<?php the_permalink(); ?>" target="_blank"><?php get_template_part('include/thumbnail');?></a>
						</div>
						<p><a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title();?>"><?php the_title();?></a></p>
					</li>
				<?php wp_reset_postdata(); endforeach;?>	
				</ul>
			</section>
			<?php if(!empty($leonhere_option["leonhere"]["_cmtAd"])){?>
			<div class="site-entry post-ad">		
				<?php echo $leonhere_option["leonhere"]["_cmtAd"];?>	
			</div>
			<?php } ?>
			<?php comments_template('',true); ?>
		</article>
		<?php endwhile; ?>
		<?php else : ?>
		<div class="post">
			你要找的页面已删除或不存在
		</div>
		<?php endif;?>
	</main>
	<?php get_sidebar();?>
</div>
<?php get_footer();?>