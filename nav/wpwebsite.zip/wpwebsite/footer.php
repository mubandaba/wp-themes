<?php global $leonhere_option;?>
<footer class="footer">	
	<div class="inner">
		<p><?php copyrightDate();?> <a href="<?php bloginfo('url');?>" title="<?php bloginfo('name');?>"><?php bloginfo('name');?></a>. 主题由 博客吧 制作.</p>
		<p><?php if($leonhere_option["leonhere"]["_icp"]){ echo '<a rel="external nofollow" href="http://www.miitbeian.gov.cn/" target="_blank">'.$leonhere_option["leonhere"]["_icp"].'</a>. ';}?> <?php if($leonhere_option["leonhere"]["_statistic"]){ echo $leonhere_option["leonhere"]["_statistic"];}?></p>
	</div>
	<?php if($leonhere_option["leonhere"]["_links"]=='all'){?>
	<div class="inner friendlinks">
		<ul>
			<li><span>友情链接</span></li>
			<?php wp_list_bookmarks('show_description=0&show_images=0&title_li=&categorize=0');?>
		</ul>	
	</div>
	<?php }else if($leonhere_option["leonhere"]["_links"]=='home' && is_home()){?>
	<div class="inner friendlinks">
		<ul>
			<li><span>友情链接</span></li>
			<?php wp_list_bookmarks('show_description=0&show_images=0&title_li=&categorize=0');?>
		</ul>	
	</div>
	<?php } ?>
</footer>
<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/leonhere.js"></script>
<?php wp_footer();?>
</body>
</html>