<?php
class leonhere_hot_post_list extends WP_Widget {
	function __construct(){
		$widget_des = array('description' => '主题自带调用浏览最多的文章');
		parent::__construct('leonhere_hot_post_list',$name='主题 热门关注',$widget_des);
	}
	function form($instance){
		$instance = wp_parse_args((array)$instance,array('title'=>'热门关注','showPosts'=>'10','exclude'=>''));
		$title = htmlspecialchars($instance['title']);		
		$showPosts = htmlspecialchars($instance['showPosts']);
		$exclude = htmlspecialchars($instance['exclude']);
		echo '<p style="text-align:left;"><label for="'.$this->get_field_name('title').'">中文标题:<input style="width:200px;" id="'.$this->get_field_id('title').'" name="'.$this->get_field_name('title').'" type="text" value="'.$title.'" /></label></p>';
		echo '<p style="text-align:left;"><label for="'.$this->get_field_name('showPosts').'">文章数量:<input style="width:200px;" id="'.$this->get_field_id('showPosts').'" name="'.$this->get_field_name('showPosts').'" type="text" value="'.$showPosts.'" /></label></p>';
		echo '<p style="text-align:left;"><label for="'.$this->get_field_name('exclude').'">排除分类:<input style="width:200px;" id="'.$this->get_field_id('exclude').'" name="'.$this->get_field_name('exclude').'" type="text" value="'.$exclude.'" /></label></p>';
	}
	function update($new_instance,$old_instance){
		$instance = $old_instance;
		$instance['title'] = strip_tags(stripslashes($new_instance['title']));		
		$instance['showPosts'] = strip_tags(stripslashes($new_instance['showPosts']));
		$instance['exclude'] = strip_tags(stripslashes($new_instance['exclude']));
		return $instance;
	}
	function the_hot_posts($args = ''){
		$default = array('meta_key' => 'views','orderby' => 'meta_value_num','order' => 'DESC','showPosts'=>'10');
		$r = wp_parse_args($args,$default);
		extract($r);
		$exclude = explode(',',$exclude);
		$args = array(
			'showposts'=>$showPosts,
			'orderby'=>'meta_value_num',
			'meta_key'=>'views',
			'ignore_sticky_posts'=>1,
			'category__not_in'   => $exclude,			
		);
		query_posts($args);		
		if(have_posts()){
			echo '<ul>';			
			while (have_posts()) {
				the_post();				
				echo '<li><a href="'.get_permalink().'" title="'.get_the_title().'" target="_blank">· '.get_the_title().'</a><span><i>(</i><i class="center">'.getPostViews(get_the_ID()).'</i><i>)</i></span></li>';
			}
			echo '</ul>';
		}
		wp_reset_query();
	}
	function widget($args, $instance){
		extract($args);
		$title = apply_filters('widget_title', empty($instance['title']) ? __('热门关注','leonhere') : $instance['title']);
		$title = $title;		
		$showPosts = empty($instance['showPosts']) ? 10 : $instance['showPosts'];
		$exclude = empty($instance['exclude']) ? '' : $instance['exclude'];
		echo '<section class="widget hot">';
		if( $title ) echo $before_title . $title . $after_title;
		self::the_hot_posts("showPosts=$showPosts&exclude=$exclude");
		echo '</section>';
	}
}
register_widget('leonhere_hot_post_list');
?>