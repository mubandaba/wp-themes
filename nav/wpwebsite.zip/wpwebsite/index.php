<?php get_header();?>
<?php global $leonhere_option;?>
<div class="inner container">	
	<main class="main">
	<?php
		$sticky = get_option('sticky_posts');			
		query_posts( array('showposts'=>'6', 'post__in' => $sticky, 'ignore_sticky_posts' => 1 ) );
		if (have_posts()) :		
	?>
		<section class="box">
			<h3>品牌推荐</h3>			
			<ul>
				<?php while (have_posts()) : the_post();?>
				<li>
					<div class="site-logo">
						<?php if(get_post_meta($post->ID, "redirect", true) == 'yes'){?>
						<a rel="nofollow" href="<?php if(get_option('permalink_structure')==''){echo get_post_meta($post->ID, "url", true);}else{bloginfo('url');?>/go/<?php the_ID();}?>" target="_blank"><?php get_template_part('include/thumbnail');?></a>
						<?php }else{?>
						<a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title();?>"><?php get_template_part('include/thumbnail');?></a>
						<?php } ?>
					</div>
					<p class="site-name">
						<?php if(get_post_meta($post->ID, "redirect", true) == 'yes'){?>
						<a rel="nofollow" href="<?php if(get_option('permalink_structure')==''){echo get_post_meta($post->ID, "url", true);}else{bloginfo('url');?>/go/<?php the_ID();}?>" target="_blank"><?php the_title(); ?></a>
						<?php }else{?>
						<a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a>
						<?php } ?>
					</p>
					<p class="site-intro"><?php echo get_post_meta($post->ID, "review", true);?></p>
				</li>
				<?php endwhile;?>
			</ul>
		</section>
	<?php endif; wp_reset_query();?>
	<?php if(!empty($leonhere_option["leonhere"]["_listAd"])){?>
		<div class="box widget-ad">
			<?php echo $leonhere_option["leonhere"]["_listAd"];?>
		</div>
	<?php } ?>
		<?php 
		if(!empty($leonhere_option["leonhere"]["_website"])){
			$website = $leonhere_option["leonhere"]["_website"];
			sort($website);
			foreach($website as $site){
				$sitenum = get_term_meta($site ,'_sitenum',true);
				query_posts('&cat='.$site.'&showposts='.$sitenum);
		?>
		<section class="box">
			<h3><?php echo get_cat_name($site);?></h3>
			<span class="more"><a href="<?php echo get_category_link($site); ?>" title="<?php echo get_cat_name($site);?>">更多 <i>+</i></a></span>
			<?php if (have_posts()) :?>
			<ul>
				<?php while (have_posts()) : the_post(); ?>
				<li>
				<?php if(get_term_meta($site ,'_sitelogo',true) != 'hide'){?>
					<div class="site-logo">
						<?php if(get_post_meta($post->ID, "redirect", true) == 'yes'){?>
						<a rel="nofollow" href="<?php if(get_option('permalink_structure')==''){echo get_post_meta($post->ID, "url", true);}else{bloginfo('url');?>/go/<?php the_ID();}?>" target="_blank"><?php get_template_part('include/thumbnail');?></a>
						<?php }else{?>
						<a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title();?>"><?php get_template_part('include/thumbnail');?></a>
						<?php } ?>						
						<?php if(is_sticky()){?>
						<i>荐</i>
						<?php } ?>
					</div>
				<?php } ?>
					<p class="site-name">
						<?php if(get_post_meta($post->ID, "redirect", true) == 'yes'){?>
						<a rel="nofollow" href="<?php if(get_option('permalink_structure')==''){echo get_post_meta($post->ID, "url", true);}else{bloginfo('url');?>/go/<?php the_ID();}?>" target="_blank"><?php the_title(); ?></a>
						<?php }else{?>
						<a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a>
						<?php } ?>
					</p>
					<p class="site-intro"><?php echo get_post_meta($post->ID, "review", true);?></p>
				</li>
				<?php endwhile;?>
			</ul>
			<?php endif;?>
		</section>
		<?php wp_reset_query(); } } ?>
	</main>
	<?php get_sidebar();?>
</div>
<?php get_footer();?>