<?php get_header();?>
<div class="inner container">	
	<main class="main">
		<h3 class="title">搜索结果</h3>
		<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
		<article class="section bloglist">
			<h2 class="blog-title"><a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title();?>"><?php the_title();?></a></h2>
			<div class="excerpt">
				<p><?php echo wp_trim_words($post->post_content, 120, '...');?></p>
			</div>			
			<div class="readmore">
				<a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title();?>">阅读全文 &gt;&gt;</a>
			</div>
		</article>
		<?php endwhile;?>
		<?php get_template_part('include/pagenavi');?>
		<?php else: ?>
		<div class="post">
			<p>很抱歉，该栏目下暂未添加内容，请先浏览网站其它内容！</p>
		</div>
		<?php endif;?>
	</main>
	<?php get_sidebar();?>
</div>
<?php get_footer();?>