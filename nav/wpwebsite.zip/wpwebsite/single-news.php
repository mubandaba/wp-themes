<?php get_header();?>
<?php global $leonhere_option;?>
<div class="inner container">	
	<main class="main">
		<div class="breadcrumb"><?php get_breadcrumbs();?></div>
		<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>	
		<article class="site-post post blog-post">
			<h1 class="post-title"><?php the_title();?></h1>
			<div class="postmeta">				
				<span>发布时间：<?php the_time('Y-m-d');?></span>
				<span>浏览次数：<?php setPostViews(get_the_ID()); echo getPostViews(get_the_ID()); ?></span>
				<span>评论次数：<?php comments_number('0','1','%'); ?></span>
			</div>
			<div class="entry">
				<?php if($leonhere_option["leonhere"]["_articleStart"]){?>
				<div class="post-ad">
				<?php echo $leonhere_option["leonhere"]["_articleStart"];?>
				</div>
				<?php } ?>
				<?php the_content();?>
			</div>			
			<section class="news-related">	
				<h3>您可能还会喜欢：</h3>
				<ul>
				<?php 
				$categories = get_the_terms(get_the_ID(),'topics');
				foreach ($categories as $category) {
					$getposts = get_posts(array(
							'numberposts' => 10,
							'post_type' => 'news',
							'exclude'=>get_the_ID(),
							'tax_query'=>array(
								array(
								'taxonomy'=>'topics',
								'terms'=>$category->term_id
								)
								),
							)
						);
					if($getposts){
						foreach($getposts as $post){
							setup_postdata( $post ); 
				?>
					<li><a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title();?>"><?php the_title();?></a></li>
				<?php 
							wp_reset_postdata();
						} 
					}else{
						echo '<p>暂无相关资讯</p>';
					}
				}
				?>	
				</ul>
			</section>
			<?php if($leonhere_option["leonhere"]["_cmtAd"]){?>
			<div class="site-entry post-ad">		
				<?php echo $leonhere_option["leonhere"]["_cmtAd"];?>	
			</div>
			<?php } ?>
			<?php comments_template('',true); ?>
		</article>
		<?php endwhile; ?>
		<?php else : ?>
		<div class="post">
			你要找的页面已删除或不存在
		</div>
		<?php endif;?>
	</main>
	<?php get_sidebar();?>
</div>
<?php get_footer();?>