﻿=== WP SEO TDK ===
Contributors: 否子戈
Donate link: www.tangshuang.net/2324.html
Tags: wordpress seo, title seo, description seo, keywords seo
Requires at least: 3.9.0
Tested up to: 5.2.3
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

为您提供一个通用的网页标题、关键词、描述方案，实现最基本的SEO TDK目的。

== Description ==

简单易懂，可以很快的设置网页的标题、关键词、描述。可以在github上获得源码 http://github.com/tangshuang/wp-seo-tdk ，可以在GitHub上提交issue。我的博客支持页 http://www.tangshuang.net/2324.html

== Installation ==

1、在后台“安装插件”中搜索WP SEO TDK，找到本插件后安装；或者下载后，把插件文件夹上传到/wp-content/plugins/目录<br />
2、在后台插件列表中激活它<br />
3、在“设置-SEO”菜单中进行配置<br />
4、完成后即可

注意，主题中，应该用`<?php wp_title(''); ?>`输出标题，标题依赖于wp_title，关键词描述依赖于wp_head。

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==

= 2.1.1 =
同步最新代码。

= 2.0.2 =
修复了获取父分类串的bug

= 2.0.1 =
2.0版本和1.0版本有巨大的不同，2.0版本要求博主根据后台SEO设置的提示，自己填写标题、关键字、描述的结构，提供了完整的首页、分类、标签、文章、独立页面的TDK项。总之，你应该会喜欢上这个版本。

== Upgrade Notice ==

= 2.0.2 =
修复了获取父分类串的bug

= 2.0.1 =
2.0版本和1.0版本有巨大的不同，2.0版本要求博主根据后台SEO设置的提示，自己填写标题、关键字、描述的结构，提供了完整的首页、分类、标签、文章、独立页面的TDK项。总之，你应该会喜欢上这个版本。
