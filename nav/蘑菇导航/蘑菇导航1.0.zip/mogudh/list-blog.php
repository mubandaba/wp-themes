	<div class="container list-blog clearfix">
		<div class="list-left fl">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<div class="item clearfix">
				<a href="<?php the_permalink(); ?>">
					<div class="item-left fl">
						<?php if ( has_post_thumbnail() ) { ?>
							<img src="<?php echo wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large')[0]; ?>" alt="<?php the_title(); ?>">
						<?php } else {?>
							<img src="<?php bloginfo('template_url'); ?>/images/list-pic.jpg" alt="<?php the_title(); ?>">
						<?php } ?>
					</div>
				</a>
				<div class="item-right fl">
					<a href="<?php the_permalink(); ?>"><h3><?php the_title(); ?></h3></a>
					<span class="item-content ell-3"><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 190, '……'); ?></span>
					<div class="other">
						<span class="item-date"><?php the_time('Y-m-d'); ?></span>
						<span class="reading"><?php get_post_views($post -> ID); ?>次阅读</span>
                      	<span class="item-zan count"><?php if( get_post_meta($post->ID,'bigfa_ding',true) ) { echo get_post_meta($post->ID,'bigfa_ding',true);} else {echo '0';}?>个赞</span>
					</div>
				</div>
			</div>
			<?php endwhile; endif; ?>
            <div class="page-code">
                <?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } ?>
			</div>
		</div>
		<?php get_template_part('sidebar');  ?>
	</div>
