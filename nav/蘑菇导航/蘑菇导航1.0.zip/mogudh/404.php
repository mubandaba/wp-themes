<?php get_header(); ?>
	<div class="img404 container clearfix">
		<div class="imgicon"></div>
		<div class="text">
			<span>咦？世界线变动了，你好像来到了奇怪的地方。看看其他内容吧~</span>
			<a href="<?php echo get_option('home'); ?>">返回首页</a>
		</div>
	</div>
<?php get_footer(); ?>