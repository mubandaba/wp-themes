	<div class="container list-blog clearfix">
		<div class="list-left fl">
			<div class="rec-con">
				<ul class="clearfix">
					<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						<li>
							<a class="rec-link" href="<?php the_permalink(); ?>">
								<img src="<?php the_field('网站图标'); ?>" alt="<?php the_title(); ?>">
								<h3><?php the_title(); ?></h3>
								<p><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 150, '……'); ?></p>
							</a>
                          	<a class="linkDirect" href="<?php the_field('网站链接'); ?>" target="_blank" rel="nofollow" title="直达链接"><i class="iconfont">&#xe618;</i></a>
						</li>
					<?php endwhile; endif; ?>
				</ul>
			</div>
            <div class="page-code">
                <?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } ?>
			</div>
		</div>
		<?php get_template_part('sidebar');  ?>
	</div>
