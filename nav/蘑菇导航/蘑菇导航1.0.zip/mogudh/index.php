<?php get_header(); ?>
	<div class="banner">
		<div class="content container">
			<div class="gif">
				<img src="<?php echo of_get_option( 'home_logo'); ?>">
			</div>
			<div class="search">
				<div class="group" id="group">
					<span>
						<input hidden placeholder="Google 搜索" value="https://www.google.com/search?q=">
						<p>谷歌</p>
					</span>
					<span>
						<input hidden placeholder="最新电影，高清电影" value="http://ifkdy.com/?q=">
						<p>影视</p>
					</span>
					<span>
						<input hidden placeholder="找软件" value="https://www.mpyit.com/?s=wps">
						<p>软件</p>
					</span>
					<span>
						<input hidden placeholder="百度网盘搜索" value="https://www.yunpanjingling.com/search/">
						<p>网盘</p>
					</span>
					<span>
						<input hidden placeholder="看小说" value="https://www.owllook.net/search?wd=">
						<p>小说</p>
					</span>
				</div>
				<input type="text" id="txt" placeholder="百度一下，你就知道" data="https://www.baidu.com/s?wd=">
				<button id="btn"></button>
			</div>
			<div class="m-nav">
				<?php wp_nav_menu( array( 'theme_location' => 'mb_header-menu' )); ?>
				<script>
					$(function() {
						$(".m-nav li").eq(0).find("a").prepend('<img src="<?php echo of_get_option( 'm_menu_1'); ?>">');
						$(".m-nav li").eq(1).find("a").prepend('<img src="<?php echo of_get_option( 'm_menu_2'); ?>">');
						$(".m-nav li").eq(2).find("a").prepend('<img src="<?php echo of_get_option( 'm_menu_3'); ?>">');
						$(".m-nav li").eq(3).find("a").prepend('<img src="<?php echo of_get_option( 'm_menu_4'); ?>">');
						$(".m-nav li").eq(4).find("a").prepend('<img src="<?php echo of_get_option( 'm_menu_5'); ?>">');
					})
				</script>
			</div>
		</div>
	</div>
	<div class="article swiper-container">
		<ul class="swiper-wrapper clearfix">
			<?php $posts = query_posts('cat=' . of_get_option('article') . '&showposts=4&order=DESC&orderby=date' . '&paged=' . get_query_var('paged'));
			if ($posts) : foreach( $posts as $post ) : setup_postdata( $post );{?>
				<li class="swiper-slide"><a href="<?php the_permalink(); ?>">
					<?php if ( has_post_thumbnail() ) { ?>
						<img src="<?php echo wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large')[0]; ?>" alt="<?php the_title(); ?>">
					<?php } else {?>
						<img src="<?php bloginfo('template_url'); ?>/images/list-pic.jpg" alt="<?php the_title(); ?>">
					<?php } ?>
					</a>
				</li>
			<?php } endforeach; endif; wp_reset_query(); ?>
		</ul>
	</div>
	<?php $cids = array(of_get_option('navigation')); $len = count($cids); for ($a=1; $a<=$len; $a++) { $cid = $cids[$a-1]; ?>
	<div class="recommend container">
		<div class="rec-tie">
			<strong><?php echo get_cat_name($cid); ?></strong>
			<span class="fr"><a href="<?php echo get_category_link($cid); ?>">查看更多</a></span>
		</div>
		<div class="rec-con">
			<ul class="clearfix">
				<?php $posts = query_posts('cat=' . $cid . '&showposts=10&order=DESC&orderby=date' . '&paged=' . get_query_var('paged'));
				if ($posts) : foreach( $posts as $post ) : setup_postdata( $post );{?>
					<li>
						<a class="rec-link" href="<?php the_permalink(); ?>" target="_blank">
							<img src="<?php the_field('网站图标'); ?>" alt="<?php the_title(); ?>">
							<h3><?php the_title(); ?></h3>
							<p><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 150, '……'); ?></p>
						</a>
						<a class="linkDirect" href="<?php the_field('网站链接'); ?>" target="_blank" rel="nofollow" title="直达链接"><i class="iconfont">&#xe618;</i></a>
					</li>
				<?php } endforeach; endif; wp_reset_query(); ?>
			</ul>
		</div>
	</div>
	<?php } ?>
	<div class="container">
		<div class="table clearfix">
		<h3 class="fl" id="so-life"><i class="iconfont">&#xe655;</i>生活休闲</h3>
		<ul class="tab-hd clearfix">
			<li class="on">便携生活</li>
            <li>购 物</li>
            <li>直 播</li>
            <li>财经金融</li>
            <li>社 区</li>
            <li>游 戏</li>
            <li>新闻报刊</li>
            <li>IT资讯</li>
            <li>热点排行榜</li>
		</ul>
		<div class="tab-bd">
			<ul class="show clearfix">
				<li class="hot">
					<a href="http://www.mogudh.com/tao" target="_blank">优惠买-大额券</a></li>
				<li>
					<a href="https://www.kuaidi100.com/" target="_blank">快递查询</a></li>
				<li class="hot">
					<a href="http://sswz.spb.gov.cn/" target="_blank">快递申诉</a></li>
				<li>
					<a href="http://www.12306.cn/" target="_blank">12306</a></li>
				<li>
					<a href="https://www.taobao.com/" target="_blank">淘宝网</a></li>
				<li>
					<a href="https://www.tmall.com/" target="_blank">天猫</a></li>
				<li>
					<a href="http://www.todayonhistory.com/" target="_blank">历史上的今天</a></li>
				<li>
					<a href="https://wx.qq.com/" target="_blank">微信网页版</a></li>
				<li>
					<a href="https://www.ipip.net/" target="_blank">ip查询</a></li>
				<li>
					<a href="http://hao.360.cn/rili/" target="_blank">万年历</a></li>
				<li>
					<a href="https://mail.163.com/" target="_blank">163邮箱</a></li>
				<li>
					<a href="https://mail.qq.com/" target="_blank">QQ邮箱</a></li>
				<li>
					<a href="https://accounts.google.com/ServiceLogin?service=mail&continue=https://mail.google.com/mail/&hl=zh-CN#identifier"
					 target="_blank">Gmail</a></li>
				<li>
					<a href="http://mail.sina.com.cn/" target="_blank">新浪邮箱</a></li>
				<li>
					<a href="https://mail.126.com/" target="_blank">126邮箱</a></li>
				<li>
					<a href="https://mail.sohu.com/fe/#/login" target="_blank">搜狐邮箱</a></li>
				<li>
					<a href="https://pan.baidu.com/" target="_blank">百度网盘</a></li>
				<li>
					<a href="http://115.com/" target="_blank">115网盘</a></li>
				<li>
					<a href="https://www.weiyun.com/" target="_blank">微云</a></li>
				<li>
					<a href="https://www.lanzou.com/" target="_blank">蓝奏云</a></li>
				<li>
					<a href="http://pan.stnts.com" target="_blank">盛天云盘</a></li>
				<li>
					<a href="https://map.baidu.com/" target="_blank">百度地图</a></li>
				<li>
					<a href="http://ditu.amap.com/" target="_blank">高德地图</a></li>
				<li>
					<a href="http://hao.360.cn/zgjm.html" target="_blank">周公解梦</a></li>
				<li>
					<a href="http://hao.360.cn/xingzuo.html" target="_blank">星座</a></li>
			</ul>
			<ul class="clearfix">
				<li class="hot">
					<a href="http://lolbaicai.com/" target="_blank">淘宝优惠券</a></li>
				<li class="hot">
					<a href="http://mall.yhm11.com/" target="_blank">优惠买-大额券</a></li>
				<li class="hot">
					<a href="http://jd.lolbaicai.com/" target="_blank">京东优惠券</a></li>
				<li class="hot">
					<a href="http://union-click.jd.com/jdc?e=0&p=AyIHVCtaJQMiQwpDBUoyS0IQWlALHEIYDk5ER1xOGWVbJHJKUX8RQjlVYGYdT38GHBxveSFdVxkyFg5XElgVBhoEZRtaFAMSBlUdXRAyIgdUKxB7AyIBUhlZEgITAVwrWxAKEQJdHV0RChUPUStcJdqGm4GOwMObowZlK2sl&t=W1dCFBBFC1INXAAECUteDA%3D%3D"
					 target="_blank">京东领券中心</a></li>
				<li>
					<a href="https://www.taobao.com/" target="_blank">淘 宝</a></li>
				<li>
					<a href="https://s.click.taobao.com/lfpuJAx" target="_blank">天 猫</a></li>
				<li>
					<a href="http://union-click.jd.com/jdc?e=0&p=AyIPZRprFDJWWA1FBCVbV0IUEEULRFRBSkAOClBMW2UdU0xYT1gqUDhQVk98S0MIUWJ1YwZrVxkyFg5XElgVBhoEZRtaFAMSBlUdXRAyIgdUKxB7AyIAVRtaHAcbD10rWxALEA5SElwdBBIGXStcJdqGm4GOwMObowZlK2sl&t=W1dCFBBFC0RUQUpADgpQTFs%3D"
					 target="_blank">京 东</a></li>
				<li>
					<a href="http://union-click.jd.com/jdc?e=0&p=AyIHVCtaJQMiQwpDBUoyS0IQWlALHEFZC0FETlcNVQtHRSUFeloOWgZWdHJyIxpcHHUaAlZEK1JyHgtlH1IXCxEHURNYJQITBlQbWhUEFAJlK1sUMllpVCtdEQEbA1IYWBEyEgJdG1MTAxIEVRlcFzIVN42Px8GXidHMqlolMiI3&t=W1dCFBBFC1FMWQ8EAEAdQFkJBQ%3D%3D"
					 target="_blank">京东图书</a></li>
				<li>
					<a href="https://click.union.vip.com/redirect.php?code=A6XIDW8" target="_blank">唯品会</a></li>
				<li>
					<a href="http://cps.kaola.com/cps/login?unionId=356454142107&uid=&trackingCode=&targetUrl=http://www.kaola.com/"
					 target="_blank">网易考拉海购</a></li>
				<li>
					<a href="https://www.amazon.cn/?_encoding=UTF8&camp=536&creative=3200&linkCode=ur2&tag=lxdh-23" target="_blank">亚马逊</a></li>
				<li>
					<a href="https://s.click.taobao.com/Qaj8Hlw" target="_blank">聚划算</a></li>
				<li>
					<a href="http://union.dangdang.com/transfer.php?from=P-331152&ad_type=10&sys_id=1&backurl=http%3A%2F%2Fwww.dangdang.com"
					 target="_blank">当 当</a></li>
				<li>
					<a href="http://www.suning.com/" target="_blank">苏宁易购</a></li>
				<li>
					<a href="http://www.gome.com.cn/?cmpid=cps_15497_21667_&sid=15497&wid=21667" target="_blank">国美在线</a></li>
				<li>
					<a href="https://s.click.taobao.com/oTYIg7x" target="_blank">爱淘宝</a></li>
				<li>
					<a href="https://modesens.com/s/3JU/" target="_blank">ModeSens轻奢比价</a></li>
				<li>
					<a href="http://union-click.jd.com/jdc?e=0&p=AyIHVCtaJQMiQwpDBUoyS0IQWlALHE5fBUUZTFINXAAECUteDDccYRphR2xmLH4iD0ASUzMaU2dcdAUlF1clBhsFXBhbEQoRN1UaWhQCEwdTHV4lMhIGZVA1FDIbB1YdXxcDFQJlG14dBxoGUR1dHQQbD2Uca82WjtPAgI2MsxM3ZStr&t=W1dCFBBFC15KVwtZAkUdSVJKSQVJHA%3D%3D"
					 target="_blank">京东秒杀</a></li>
				<li>
					<a href="https://s.click.taobao.com/woxVHlw" target="_blank">淘抢购</a></li>
				<li>
					<a href="http://cps.kaola.com/cps/login?unionId=356454142107&uid=&trackingCode=&targetUrl=http%3A%2F%2Fwww.kaola.com%2Factivity%2FflashSaleIndex%2Fshow.html"
					 target="_blank">考拉限时购</a></li>
				<li>
					<a href="https://www.amazon.cn/gp/goldbox/?ie=UTF8&camp=536&creative=3200&linkCode=ur2&tag=lxdh-23" target="_blank">亚马逊秒杀</a></li>
				<li>
					<a href="https://s.click.taobao.com/ViuLg7x" target="_blank">淘宝特卖</a></li>
				<li>
					<a href="https://s.click.taobao.com/BGR4Hlw" target="_blank">淘宝聚优惠</a></li>
				<li>
					<a href="https://www.dianping.com/" target="_blank">大众点评</a></li>
				<li>
					<a href="https://www.meituan.com/" target="_blank">美 团</a></li>
				<li>
					<a href="https://www.nuomi.com/" target="_blank">百度糯米</a></li>
				<li>
					<a href="http://www.xitie.com/" target="_blank">西 贴</a></li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="http://www.shiting5.com/tv/hunanweishi.html" target="_blank">湖南卫视</a></li>
				<li>
					<a href="http://live.jstv.com/" target="_blank">江苏卫视</a></li>
				<li>
					<a href="http://tv.cztv.com/live1" target="_blank">浙江卫视</a></li>
				<li>
					<a href="http://tv.cctv.com/live/cctv1/" target="_blank">CCTV全直播</a></li>
				<li class="close">
					<a href="http://360kan.wasu.cn/live/ahws/?site=huashu" target="_blank">综合直播</a></li>
				<li>
					<a href="http://www.zdfans.com/5084.html" target="_blank">超级看PC版</a></li>
				<li>
					<a href="https://www.douyu.com/" target="_blank">斗 鱼</a></li>
				<li>
					<a href="http://www.huya.com/" target="_blank">虎 牙</a></li>
				<li class="close">
					<a href="https://www.panda.tv/" target="_blank">熊猫TV</a></li>
				<li>
					<a href="http://www.yy.com/" target="_blank">YY</a></li>
				<li>
					<a href="http://www.zhanqi.tv/" target="_blank">战 旗</a></li>
				<li>
					<a href="http://www.longzhu.com/" target="_blank">龙珠直播</a></li>
				<li class="close">
					<a href="http://www.quanmin.tv/" target="_blank">全民TV</a></li>
				<li>
					<a href="https://chushou.tv/" target="_blank">触手直播</a></li>
				<li>
					<a href="https://www.huomao.com/" target="_blank">火猫直播</a></li>
				<li>
					<a href="http://www.huajiao.com/" target="_blank">花椒直播</a></li>
				<li>
					<a href="http://www.inke.cn/hotlive_list.html" target="_blank">映客直播</a></li>
				<li>
					<a href="http://live.bilibili.com/" target="_blank">bilibili直播</a></li>
				<li>
					<a href="https://www.zhibo8.cc/" target="_blank">直播吧</a></li>
				<li>
					<a href="http://www.zhangyu.tv/" target="_blank">章鱼TV</a></li>
				<li>
					<a href="https://www.tiantianzhibo.com/" target="_blank">天天直播</a></li>
				<li>
					<a href="http://www.jrsnba.com/" target="_blank">jrs直播</a></li>
				<li>
					<a href="http://www.24zbw.com/live/" target="_blank">24直播</a></li>
				<li>
					<a href="https://www.52waha.com/live" target="_blank">哇哈体育</a></li>
				<li>
					<a href="http://www.zhibo.me/" target="_blank">直播迷</a></li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="http://finance.sina.com.cn/" target="_blank">新浪财经</a></li>
				<li>
					<a href="http://finance.qq.com/" target="_blank">腾讯财经</a></li>
				<li>
					<a href="http://www.hexun.com/" target="_blank">和讯网</a></li>
				<li>
					<a href="http://www.eastmoney.com/" target="_blank">东方财富网</a></li>
				<li>
					<a href="http://finance.ifeng.com/" target="_blank">凤凰财经</a></li>
				<li>
					<a href="http://www.jrj.com.cn/" target="_blank">金融界</a></li>
				<li>
					<a href="http://money.163.com/" target="_blank">网易财经</a></li>
				<li>
					<a href="http://business.sohu.com/" target="_blank">搜狐财经</a></li>
				<li>
					<a href="http://www.ce.cn/" target="_blank">中国经济网</a></li>
				<li>
					<a href="http://quote.eastmoney.com/" target="_blank">东方财富行情中心</a></li>
				<li>
					<a href="http://www.10jqka.com.cn/" target="_blank">同花顺财经</a></li>
				<li>
					<a href="http://www.cngold.org/" target="_blank">金投网</a></li>
				<li>
					<a href="http://fund.eastmoney.com/" target="_blank">天天基金网</a></li>
				<li>
					<a href="http://www.stockstar.com/" target="_blank">证券之星</a></li>
				<li>
					<a href="http://southmoney.com/" target="_blank">南方财富网</a></li>
				<li>
					<a href="http://www.caixin.com/" target="_blank">财新网</a></li>
				<li>
					<a href="http://www.caijing.com.cn/" target="_blank">财经网</a></li>
				<li class="close">
					<a href="https://wallstreetcn.com/" target="_blank">华尔街见闻</a></li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="https://www.douban.com/" target="_blank">豆瓣</a></li>
				<li>
					<a href="https://weibo.com/" target="_blank">新浪微博</a></li>
				<li>
					<a href="https://www.zhihu.com/" target="_blank">知乎</a></li>
				<li>
					<a href="https://www.jianshu.com/" target="_blank">简书</a></li>
				<li>
					<a href="https://tieba.baidu.com/" target="_blank">百度贴吧</a></li>
				<li>
					<a href="http://www.tianya.cn/" target="_blank">天涯</a></li>
				<li>
					<a href="http://dzh.mop.com/" target="_blank">猫扑</a></li>
				<li>
					<a href="http://www.lofter.com/" target="_blank">lofter</a></li>
				<li>
					<a href="https://qzone.qq.com/" target="_blank">QQ空间</a></li>
				<li>
					<a href="http://www.renren.com/" target="_blank">人人</a></li>
				<li>
					<a href="https://www.hupu.com/" target="_blank">虎扑</a></li>
				<li>
					<a href="http://www.360doc.com/index.html" target="_blank">360doc个人图书馆</a></li>
				<li>
					<a href="https://www.chiphell.com/portal.php" target="_blank">Chiphell</a></li>
				<li>
					<a href="https://www.v2ex.com/" target="_blank">v2ex</a></li>
				<li>
					<a href="https://www.autohome.com.cn/" target="_blank">汽车之家</a></li>
				<li>
					<a href="https://www.xueqiu.com/" target="_blank">雪球</a></li>
				<li>
					<a href="http://bbs.tiexue.net/" target="_blank">铁血社区</a></li>
				<li class="close">
					<a href="http://zhan.renren.com/" target="_blank">人人小站</a></li>
				<li class="close">
					<a href="https://www.qiushibaike.com/" target="_blank">糗事百科</a></li>
				<li class="close">
					<a href="http://www.u148.net/" target="_blank">有意思吧</a></li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="http://wanga.me/" target="_blank">拼命玩游戏</a></li>
				<li class="close">
					<a href="http://www.u77.com/" target="_blank">U77</a></li>
				<li>
					<a href="http://www.sea187.com/dev/pc/" target="_blank">游戏博物馆</a></li>
				<li>
					<a href="http://www.mhhf.com/" target="_blank">灵动游戏</a></li>
				<li>
					<a href="http://www.chafanhou.com/" target="_blank">茶饭后</a></li>
				<li class="close">
					<a href="http://www.indieace.com/" target="_blank">IndieACE</a></li>
				<li class="close">
					<a href="http://gameflow.cc/" target="_blank">GameFlow</a></li>
				<li>
					<a href="http://www.gamersky.com/" target="_blank">游民星空</a></li>
				<li>
					<a href="http://www.3dmgame.com/" target="_blank">3 D M</a></li>
				<li>
					<a href="http://www.ali213.net/" target="_blank">游侠网</a></li>
				<li>
					<a href="http://www.91danji.com/" target="_blank">91单机</a></li>
				<li>
					<a href="http://www.yxdown.com/" target="_blank">游迅网</a></li>
				<li>
					<a href="http://www.duote.com/game/" target="_blank">多特单机</a></li>
				<li>
					<a href="http://tieba.baidu.com/f?kw=%E5%8D%95%E6%9C%BA%E6%B8%B8%E6%88%8F&ie=utf-8" target="_blank">单机游戏吧</a></li>
				<li>
					<a href="http://www.doyo.cn/" target="_blank">逗 游</a></li>
				<li>
					<a href="http://www.4399.com/" target="_blank">4 3 9 9</a></li>
				<li>
					<a href="http://qqgame.qq.com/" target="_blank">qq游戏</a></li>
				<li>
					<a href="http://www.7k7k.com/" target="_blank">7 k 7 k</a></li>
				<li>
					<a href="http://xiaoyouxi.2345.com/" target="_blank">2345小游戏</a></li>
				<li>
					<a href="http://xyx.hao123.com/" target="_blank">hao123小游戏</a></li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="http://www.xinhuanet.com/" target="_blank">新华网</a></li>
				<li>
					<a href="http://news.ifeng.com/" target="_blank">凤凰资讯</a></li>
				<li>
					<a href="http://www.huanqiu.com/" target="_blank">环球网</a></li>
				<li>
					<a href="http://news.163.com/" target="_blank">网易新闻</a></li>
				<li>
					<a href="https://www.toutiao.com/" target="_blank">今日头条</a></li>
				<li>
					<a href="http://www.thepaper.cn/" target="_blank">澎湃新闻</a></li>
				<li>
					<a href="http://www.jiemian.com/" target="_blank">界面新闻</a></li>
				<li>
					<a href="http://www.tiexue.net/" target="_blank">铁血网</a></li>
				<li>
					<a href="https://news.un.org/zh/" target="_blank">联合国新闻</a></li>
				<li>
					<a href="http://www.takungpao.com/" target="_blank">大公网</a></li>
				<li>
					<a href="http://www.zaobao.com/" target="_blank">联合早报网</a></li>
				<li>
					<a href="http://www.youth.cn/" target="_blank">中国青年网</a></li>
				<li>
					<a href="http://news.sina.com.cn/" target="_blank">新浪新闻</a></li>
				<li>
					<a href="http://news.qq.com/" target="_blank">腾讯新闻</a></li>
				<li>
					<a href="http://www.infzm.com/" target="_blank">南方周末</a></li>
				<li>
					<a href="http://www.qdaily.com/" target="_blank">好奇心日报</a></li>
				<li>
					<a href="http://www.ebrun.com/" target="_blank">亿邦动力网</a></li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="https://www.cnbeta.com/" target="_blank">cnBeta</a></li>
				<li>
					<a href="http://www.ifanr.com/" target="_blank">爱范儿</a></li>
				<li>
					<a href="http://36kr.com/" target="_blank">36 氪</a></li>
				<li>
					<a href="http://www.geekpark.net/" target="_blank">极客公园</a></li>
				<li>
					<a href="https://www.huxiu.com/" target="_blank">虎嗅网</a></li>
				<li>
					<a href="https://www.leiphone.com/" target="_blank">雷锋网</a></li>
				<li>
					<a href="http://tech.sina.com.cn/" target="_blank">新浪科技</a></li>
				<li>
					<a href="http://tech.qq.com/" target="_blank">腾讯科技</a></li>
				<li>
					<a href="http://tech.ifeng.com/" target="_blank">凤凰科技</a></li>
				<li>
					<a href="http://www.zol.com.cn/" target="_blank">中关村在线</a></li>
				<li>
					<a href="http://news.mydrivers.com/" target="_blank">驱动之家</a></li>
				<li>
					<a href="https://www.ithome.com/" target="_blank">IT之家</a></li>
				<li>
					<a href="http://www.tmtpost.com/" target="_blank">钛媒体</a></li>
				<li>
					<a href="http://www.cnetnews.com.cn/" target="_blank">CNET科技资讯</a></li>
				<li>
					<a href="http://www.iheima.com/" target="_blank">i黑马</a></li>
				<li>
					<a href="http://www.pingwest.com/" target="_blank">品玩</a></li>
				<li>
					<a href="https://madbrief.com/" target="_blank">疯狂简报</a></li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="http://s.weibo.com/top/summary?cate=homepage" target="_blank">微博热搜榜</a></li>
				<li>
					<a href="http://www.zhihufans.com/index.php" target="_blank">知乎封神榜</a></li>
				<li>
					<a href="http://www.cbooo.cn/" target="_blank">CBO实时票房榜</a></li>
				<li>
					<a href="http://dig.chouti.com/" target="_blank">抽屉新热榜</a></li>
				<li>
					<a href="http://top.baidu.com/" target="_blank">百度风云榜</a></li>
				<li>
					<a href="https://top.taobao.com/" target="_blank">淘宝排行榜</a></li>
				<li>
					<a href="http://top.sogou.com/" target="_blank">搜狗热搜榜</a></li>
				<li>
					<a href="https://trends.so.com/index" target="_blank">360趋势</a></li>
				<li>
					<a href="http://www.hao123.com/top" target="_blank">hao123风云榜</a></li>
				<li>
					<a href="http://tv.sohu.com/hothdtv/" target="_blank">搜狐视频排行榜</a></li>
				<li>
					<a href="http://index.youku.com/" target="_blank">中国网络视频指数</a></li>
				<li>
					<a href="http://www.gamersky.com/top/" target="_blank">单机游戏排行榜</a></li>
			</ul>
		</div>
	</div>
	</div>
	
	<div class="container">
		<div class="table clearfix">
		<h3 class="fl" id="so-movie"><i class="iconfont">&#xe614;</i>影视欣赏</h3>
		<ul class="tab-hd clearfix">
			<li class="on">最新影视</li>
			<li>高清蓝光</li>
			<li>在线电影</li>
			<li>BT影视</li>
			<li>美 剧</li>
			<li>日韩剧</li>
			<li>动 漫</li>
			<li>纪录片</li>
			<li>字 幕</li>
		</ul>
		<div class="tab-bd">
			<ul class="show clearfix">
				<li class="hot">
					<a href="http://ifkdy.com/" target="_blank">疯狂影视搜索</a></li>
				<li class="hot">
					<a href="http://czjx8.com/" target="_blank">vip视频解析</a></li>
				<li class="close">
					<a href="http://esyy007.com/" target="_blank">二十影院</a></li>
				<li>
					<a href="http://www.mp4ba.cc/" target="_blank">高清MP4吧</a></li>
				<li>
					<a href="https://www.22tu.cc/" target="_blank">迅播影院</a></li>
				<li class="close">
					<a href="http://www.xunyingwang.com/" target="_blank">迅影网</a></li>
				<li>
					<a href="https://neets.cc/" target="_blank">neets</a></li>
				<li>
					<a href="https://www.dygod.net/" target="_blank">电影天堂</a></li>
				<li>
					<a href="https://www.bd-film.cc/" target="_blank">BD影视</a></li>
				<li class="close">
					<a href="http://www.66ys.tv/" target="_blank">66影视</a></li>
				<li>
					<a href="http://www.ck180.net/" target="_blank">CK电影部落</a></li>
				<li>
					<a href="http://qukantv.net/" target="_blank">去看TV网</a></li>
				<li class="close">
					<a href="http://www.lbldy.com/" target="_blank">龙部落</a></li>
				<li>
					<a href="http://www.dygang.net/" target="_blank">电影港</a></li>
				<li>
					<a href="https://www.piaohua.com/" target="_blank">飘花电影</a></li>
				<li>
					<a href="https://www.xiaohx.org/" target="_blank">小浣熊</a></li>
				<li>
					<a href="https://www.yugaopian.cn/" target="_blank">预告片世界</a></li>
			</ul>
			<ul class="clearfix">
				<li class="hot">
					<a href="http://ifkdy.com/" target="_blank">疯狂影视搜索</a></li>
				<li>
					<a href="http://www.mp4ba.cc/" target="_blank">高清MP4吧</a></li>
				<li>
					<a href="http://www.yinfans.com/" target="_blank">音范丝</a></li>
				<li>
					<a href="http://www.gscq.me/" target="_blank">乐赏</a></li>
				<li>
					<a href="http://www.pianhd.com/" target="_blank">PianHD高清片网</a></li>
				<li>
					<a href="https://www.bttwo.com/" target="_blank">两个BT</a></li>
				<li>
					<a href="http://gaoqing.la/" target="_blank">中国高清网</a></li>
				<li>
					<a href="http://www.ck180.net/" target="_blank">CK电影部落</a></li>
				<li>
					<a href="http://www.youzhidy.com/" target="_blank">优质电影网</a></li>
				<li class="close">
					<a href="http://www.ibtbb.com/" target="_blank">思 享</a></li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="http://czjx8.com/" target="_blank">vip视频解析</a></li>
				<li class="close">
					<a href="http://esyy007.com/" target="_blank">二十影院</a></li>
				<li>
					<a href="https://www.kankanwu.com/" target="_blank">看看屋</a></li>
				<li>
					<a href="http://qukantv.net/" target="_blank">去看TV网</a></li>
				<li>
					<a href="http://www.nicotv.me/" target="_blank">妮可影视</a></li>
				<li>
					<a href="https://www.xixixixi.wang/" target="_blank">嘻嘻动漫</a></li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="http://www.pianhd.com/" target="_blank">PianHD高清片网</a></li>
				<li>
					<a href="https://www.bttwo.com/" target="_blank">两个BT</a></li>
				<li>
					<a href="http://www.hhyyk.com/" target="_blank">后花园影库</a></li>
				<li>
					<a href="http://btbta.com/" target="_blank">BT之家</a></li>
				<li>
					<a href="http://www.btba.com.cn/" target="_blank">BT吧</a></li>
				<li>
					<a href="https://bde4.com/" target="_blank">哔嘀影视</a></li>
				<li>
					<a href="https://www.dlkoo.com/" target="_blank">大连生活网</a></li>
				<li>
					<a href="http://pianyuan.net/" target="_blank">片源网</a></li>
				<li>
					<a href="https://moviejie.net/" target="_blank">电影街</a></li>
				<li>
					<a href="http://www.btshoufa.net/forum.php" target="_blank">BT首发论坛</a></li>
				<li>
					<a href="http://www.54new.com/" target="_blank">燕子BT</a></li>
				<li class="close">
					<a href="http://www.btbbt.org/" target="_blank">BT之家种子网</a></li>
				<li class="close">
					<a href="http://www.jpdrama.cn/forum.php" target="_blank">猪猪乐园</a></li>
			</ul>
			<ul class="clearfix">
				<li class="hot">
					<a href="http://www.zimuzu.tv/tv/eschedule" target="_blank">美剧时间表</a></li>
				<li class="close">
					<a href="http://esyy007.com/?m=vod-type-id-15.html" target="_blank">美剧-二十影院</a></li>
				<li>
					<a href="https://neets.cc/category?country=america&type=tv" target="_blank">neets</a></li>
				<li>
					<a href="http://www.zimuzu.tv/" target="_blank">YYeTs字幕组</a></li>
				<li>
					<a href="https://eztv.ag/" target="_blank">EZTV片源</a></li>
				<li class="hot">
					<a href="http://www.ttmeiju.wang/" target="_blank">天天美剧网</a></li>
				<li class="close">
					<a href="http://cn163.net/" target="_blank">天天美剧2</a></li>
				<li>
					<a href="http://mcar.cc/" target="_blank">耐卡影音</a></li>
				<li>
					<a href="http://www.6vhao.tv/mj/" target="_blank">6V美剧</a></li>
				<li>
					<a href="http://www.meijutt.com/" target="_blank">美剧天堂</a></li>
				<li>
					<a href="http://videos.yizhansou.com/" target="_blank">一站搜</a></li>
				<li>
					<a href="https://www.dygod.net/html/tv/oumeitv/index.html" target="_blank">电影天堂-美剧</a></li>
				<li>
					<a href="http://tv.le.com/us/" target="_blank">乐视美剧</a></li>
				<li>
					<a href="http://www.iqiyi.com/dianshiju/oumei.html" target="_blank">爱奇艺美剧</a></li>
				<li>
					<a href="http://tv.sohu.com/drama/us/" target="_blank">搜狐美剧</a></li>
				<li>
					<a href="http://list.youku.com/category/show/c_97_s_1_d_1_a_%E7%BE%8E%E5%9B%BD.html" target="_blank">优酷美剧</a></li>
				<li class="close">
					<a href="http://www.shinybbs.info/forum.php" target="_blank">深影字幕组</a></li>
				<li>
					<a href="http://www.1000fr.net/" target="_blank">謦灵风软</a></li>
				<li>
					<a href="http://bbs.sfile2012.com/" target="_blank">伊甸园</a></li>
				<li>
					<a href="http://dbfansub.com/" target="_blank">电波字幕组</a></li>
			</ul>
			<ul class="clearfix">
				<li class="close">
					<a href="http://esyy007.com/?m=vod-type-id-14.html" target="_blank">韩剧-二十影院</a></li>
				<li>
					<a href="http://www.hanfan.cc/hanju/" target="_blank">韩饭网</a></li>
				<li>
					<a href="http://www.zimuzu.tv/resourcelist?area=%E9%9F%A9%E5%9B%BD" target="_blank">韩剧-字幕组</a></li>
				<li class="close">
					<a href="http://www.y3600.com/hanju/" target="_blank">热播网-韩剧</a></li>
				<li>
					<a href="http://www.hanju.cc/" target="_blank">韩剧网</a></li>
				<li>
					<a href="https://weibo.com/hxly9" target="_blank">幻想乐园字幕组</a></li>
				<li>
					<a href="http://www.hanmi520.com/forum-8-1.html" target="_blank">韩迷字幕组</a></li>
				<li>
					<a href="http://zhuixinfan.com/main.php" target="_blank">追新番</a></li>
				<li>
					<a href="http://www.zimuzu.tv/resourcelist?channel=tv&area=%E6%97%A5%E6%9C%AC" target="_blank">日剧-字幕组</a></li>
				<li>
					<a href="http://www.hideystudio.com/drama/" target="_blank">隐 社</a></li>
				<li class="close">
					<a href="http://www.91riju.com/" target="_blank">91日剧</a></li>
				<li>
					<a href="http://www.mytvbt.net/forumdisplay.php?fid=6&page=1" target="_blank">日菁字幕组</a></li>
				<li class="close">
					<a href="http://www.jpdrama.cn/forum.php?mod=forumdisplay&fid=306" target="_blank">猪猪日剧字幕组</a></li>
				<li>
					<a href="http://www.zimuxia.cn/%E6%88%91%E4%BB%AC%E7%9A%84%E4%BD%9C%E5%93%81" target="_blank">FIX字幕侠</a></li>
				<li class="close">
					<a href="http://pssclub.com/forum.php" target="_blank">光合社大联盟</a></li>
				<li>
					<a href="https://www.tokyonothot.com/" target="_blank">东京不够热</a></li>
				<li class="close">
					<a href="http://forum.6cn.org/forum-105-1.html" target="_blank">第六感</a></li>
			</ul>
			<ul class="clearfix">
				<li class="close">
					<a href="http://esyy007.com/?m=vod-type-id-4.html" target="_blank">动漫-二十影院</a></li>
				<li>
					<a href="http://www.nicotv.me/" target="_blank">妮可影视</a></li>
				<li>
					<a href="http://www.acfun.cn/" target="_blank">AcFun</a></li>
				<li>
					<a href="https://www.bilibili.com/" target="_blank">bilibili</a></li>
				<li>
					<a href="http://www.dilidili.one/" target="_blank">dilidili</a></li>
				<li>
					<a href="https://bgmlist.com/" target="_blank">番组放送</a></li>
				<li>
					<a href="http://pada.18183.com/" target="_blank">啪嗒动漫</a></li>
				<li>
					<a href="http://www.missevan.com/" target="_blank">M站</a></li>
				<li>
					<a href="http://www.iqiyi.com/dongman/" target="_blank">爱奇艺动漫</a></li>
				<li>
					<a href="http://v.qq.com/cartoon/" target="_blank">腾讯动漫</a></li>
				<li>
					<a href="http://comic.le.com/" target="_blank">乐视动漫</a></li>
				<li>
					<a href="http://tv.sohu.com/comic/" target="_blank">搜狐动漫</a></li>
				<li>
					<a href="http://cartoon.pptv.com/" target="_blank">pptv动漫</a></li>
				<li>
					<a href="http://comic.youku.com/" target="_blank">优酷动漫</a></li>
				<li>
					<a href="http://cartoon.tudou.com/" target="_blank">土豆动漫</a></li>
				<li>
					<a href="https://share.dmhy.org/" target="_blank">动漫花园资源网</a></li>
				<li>
					<a href="http://www.kisssub.org/" target="_blank">爱恋BT</a></li>
				<li>
					<a href="http://neets.cc/category?type=animation" target="_blank">neets</a></li>
				<li class="close">
					<a href="http://www.hldm123.cc/" target="_blank">红旅动漫</a></li>
				<li>
					<a href="http://dm1080p.com/" target="_blank">动漫1080p</a></li>
				<li class="close">
					<a href="http://www.dm2046.com/" target="_blank">动漫分享站</a></li>
				<li>
					<a href="http://bt.acg.gg/" target="_blank">ACG狗狗</a></li>
				<li>
					<a href="http://www.moe123.net/" target="_blank">萌导航</a></li>
				<li>
					<a href="http://d.yimoe.cc/" target="_blank">翼萌导航</a></li>
				<li>
					<a href="http://www.moe321.com/" target="_blank">次元导航</a></li>
				<li>
					<a href="http://moe.hao123.com/" target="_blank">萌主页</a></li>
				<li>
					<a href="http://www.dongman.fm/" target="_blank">动漫FM</a></li>
				<li class="close">
					<a href="https://nyaso.com/" target="_blank">喵 搜</a></li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="http://www.jlpzj.net/" target="_blank">纪录片之家</a></li>
				<li>
					<a href="http://www.jlpcn.net/" target="_blank">纪录片天地</a></li>
				<li class="close">
					<a href="https://www.laojilu.com/" target="_blank">老记录</a></li>
				<li>
					<a href="http://jilupian.xzwyu.com/" target="_blank">行者物语</a></li>
				<li>
					<a href="http://www.onehourlife.com/" target="_blank">每天一小时</a></li>
				<li>
					<a href="http://www.opclass.com/" target="_blank">公开课纪录片</a></li>
				<li>
					<a href="http://jishi.cntv.cn/" target="_blank">央视纪实</a></li>
				<li>
					<a href="http://www.iqiyi.com/jilupian/" target="_blank">爱奇艺纪录片</a></li>
				<li>
					<a href="http://jilupian.youku.com/" target="_blank">优酷纪录片</a></li>
				<li>
					<a href="http://jilupian.tudou.com/" target="_blank">土豆纪实</a></li>
				<li>
					<a href="http://tv.sohu.com/documentary/" target="_blank">搜狐纪录片</a></li>
				<li>
					<a href="http://v.qq.com/doco/" target="_blank">腾讯纪录片</a></li>
				<li>
					<a href="http://v.ifeng.com/documentary/" target="_blank">凤凰纪录片</a></li>
				<li>
					<a href="http://jilu.le.com/" target="_blank">乐视纪录片</a></li>
				<li>
					<a href="https://www.bilibili.com/documentary/" target="_blank">bilibili纪录</a></li>
				<li>
					<a href="http://jilupian.kankan.com/" target="_blank">迅雷看看纪录</a></li>
				<li>
					<a href="http://v.163.com/jishi/" target="_blank">网易纪录片</a></li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="http://subhd.com/" target="_blank">SubHD</a></li>
				<li>
					<a href="http://www.zimuku.cn/" target="_blank">字幕库</a></li>
				<li>
					<a href="http://www.zimuzu.tv/fsubtitle" target="_blank">字幕组</a></li>
				<li>
					<a href="http://assrt.net/" target="_blank">伪射手</a></li>
				<li class="close">
					<a href="http://www.shinybbs.info/forum.php" target="_blank">深影字幕组</a></li>
				<li class="close">
					<a href="https://fantopia.club/" target="_blank">翻托邦字幕组</a></li>
				<li>
					<a href="https://weibo.com/xiamoqiuzmz" target="_blank">夏末秋字幕组</a></li>
				<li class="close">
					<a href="http://www.kamigami.org/" target="_blank">诸神字幕组</a></li>
				<li>
					<a href="http://sskzmz.com/" target="_blank">SSK字幕组</a></li>
				<li>
					<a href="https://weibo.com/youzimucom" target="_blank">柚子木字幕组</a></li>
				<li>
					<a href="http://sub.eastgame.org/" target="_blank">TLF字幕组</a></li>
				<li>
					<a href="https://weibo.com/ragbear2007" target="_blank">破烂熊字幕组</a></li>
				<li>
					<a href="http://bbs.sfile2012.com/index.php" target="_blank">伊甸园字幕组</a></li>
				<li>
					<a href="http://www.1000fr.net/" target="_blank">风软字幕组</a></li>
				<li>
					<a href="https://www.opensubtitles.org/zh" target="_blank">opensubtitles</a></li>
				<li>
					<a href="https://subscene.com/" target="_blank">subscene</a></li>
			</ul>
		</div>
	</div>
	</div>
	
	<div class="container">
		<div class="table clearfix">
		<h3 class="fl" id="so-resource"><i class="iconfont">&#xe62a;</i>资源工具</h3>
		<ul class="tab-hd clearfix">
            <li class="on">网盘搜索</li>
            <li>BT搜索</li>
			<li>博客资源</li>
            <li>图片搜索</li>
		</ul>
		<div class="tab-bd">
			<ul class="show clearfix">
				<li class="hot">
					<a href="https://www.yunpanjingling.com/" target="_blank">云盘精灵</a></li>
				<li>
					<a href="http://www.quzhuanpan.com/" target="_blank">去转盘网</a></li>
				<li>
					<a href="https://www.panc.cc/" target="_blank">胖次搜索</a></li>
				<li>
					<a href="http://www.panduoduo.net/" target="_blank">盘多多</a></li>
				<li class="close">
					<a href="https://pan.09l.me/" target="_blank">云盘恶魔</a></li>
				<li class="close">
					<a href="https://so.6hgr.top/" target="_blank">云搜</a></li>
				<li>
					<a href="http://www.xiaobaipan.com/" target="_blank">小白盘</a></li>
				<li>
					<a href="http://www.58wangpan.com/" target="_blank">58网盘搜索</a></li>
				<li class="close">
					<a href="http://tansuo233.com/" target="_blank">探索云盘搜索</a></li>
				<li>
					<a href="https://www.ttyunsou.com/" target="_blank">天天云搜</a></li>
				<li class="close">
					<a href="https://wangpan007.com/" target="_blank">网盘007</a></li>
				<li class="close">
					<a href="http://www.tuoniao.me/" target="_blank">鸵鸟搜索</a></li>
				<li class="close">
					<a href="http://www.wodepan.com/" target="_blank">我的盘</a></li>
				<li>
					<a href="http://www.sobaidupan.com/" target="_blank">搜百度盘</a></li>
			</ul>
			<ul class="clearfix">
				<li class="hot">
					<a href="https://bt.09l.me/" target="_blank">磁力恶魔</a></li>
				<li>
					<a href="http://www.acgsou.com/" target="_blank">ACG搜索</a></li>
				<li class="close">
					<a href="https://www.cilimao.cc/" target="_blank">磁力猫</a></li>
				<li class="close">
					<a href="http://www.acgsou.com/" target="_blank">ACG搜索</a></li>
				<li class="close">
					<a href="http://cnbtkitty.co/" target="_blank">BT kitty</a></li>
				<li>
					<a href="http://oabt007.com/" target="_blank">MAG磁力</a></li>
				<li class="close">
					<a href="https://www.shousibaocai.net/" target="_blank">CiliBaBa</a></li>
				<li class="close">
					<a href="http://btyingtaocili.com/" target="_blank">BT樱桃</a></li>
				<li class="close">
					<a href="http://cililiana.com/" target="_blank">cililian</a></li>
				<li class="close">
					<a href="http://btlibrary.co/" target="_blank">btlibrary</a></li>
				<li class="close">
					<a href="https://btdigg.org/" target="_blank">btdigg</a></li>
				<li class="close">
					<a href="http://www.runbt.xyz/" target="_blank">runbt</a></li>
				<li class="close">
					<a href="http://diggbts.me/" target="_blank">Diggbt</a></li>
			</ul>
			<ul class="clearfix">
				<li class="hot">
					<a href="http://www.mogudh.com/blog" target="_blank">蘑菇导航博客</a></li>
				<li>
					<a href="https://www.runningcheese.com/" target="_blank">奔跑中的奶酪</a></li>
				<li>
					<a href="http://ybmfx.com/" target="_blank">100秒分享</a></li>
				<li>
					<a href="https://www.isharebest.com/" target="_blank">爱上分享</a></li>
				<li class="close">
					<a href="http://www.i5h8m.com/" target="_blank">五花八门</a></li>
				<li>
					<a href="https://weibo.com/cmzyk" target="_blank">传媒老跟班</a></li>
				<li>
					<a href="https://weibo.com/u/2091076344" target="_blank">资源分享库</a></li>
				<li>
					<a href="http://fulibus.net/" target="_blank">福利吧</a></li>
				<li>
					<a href="https://weibo.com/chuangbogongshe" target="_blank">传播公社</a></li>
				<li class="close">
					<a href="http://www.mianfeib.com/" target="_blank">免费吧</a></li>
				<li>
					<a href="https://www.weibo.com/u/5647630462" target="_blank">设定控主页</a></li>
				<li>
					<a href="https://www.weibo.com/bangzhaoziyuan" target="_blank">帮找资源</a></li>
				<li>
					<a href="https://weibo.com/newdsxs" target="_blank">新都市小生</a></li>
				<li class="close">
					<a href="javascript:;">念分享</a></li>
				<li>
					<a href="https://weibo.com/aifusheng" target="_blank">论坛收割者</a></li>
				<li>
					<a href="https://51.ruyo.net/" target="_blank">如有乐享</a></li>
				<li class="close">
					<a href="http://www.vxia.net/" target="_blank">微夏博客</a></li>
				<li>
					<a href="https://wzfou.com/" target="_blank">挖站否</a></li>
				<li>
					<a href="http://www.egouz.com/" target="_blank">国外网站推荐</a></li>
				<li>
					<a href="http://www.vipbuluo.com/" target="_blank">vip部落</a></li>
				<li>
					<a href="http://youquhome.com/" target="_blank">有趣网址之家</a></li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="http://image.chongbuluo.com/" target="_blank">虫部落图搜</a></li>
				<li>
					<a href="http://image.baidu.com/" target="_blank">百度图片</a></li>
				<li>
					<a href="http://cn.bing.com/images" target="_blank">必应图片</a></li>
				<li>
					<a href="http://image.so.com/" target="_blank">好搜图片</a></li>
				<li>
					<a href="http://pic.sogou.com/" target="_blank">搜狗图片</a></li>
				<li>
					<a href="http://images.search.yahoo.com/" target="_blank">YAHOO</a></li>
				<li>
					<a href="http://soogif.com/" target="_blank">GIF搜索</a></li>
				<li>
					<a href="https://www.google.com/imghp" target="_blank">Google识图</a></li>
				<li>
					<a href="http://image.baidu.com/?fr=shitu" target="_blank">百度识图</a></li>
				<li class="close">
					<a href="https://www.tineye.com/" target="_blank">TinEye</a></li>
				<li>
					<a href="http://st.so.com/" target="_blank">好搜识图</a></li>
				<li>
					<a href="http://cn.bing.com/images" target="_blank">必应识图</a></li>
				<li>
					<a href="http://pic.sogou.com/" target="_blank">搜狗识图</a></li>
				<li>
					<a href="http://www.pailitao.com/" target="_blank">拍立淘</a></li>
			</ul>
		</div>
	</div>
	</div>
	
	<div class="container">
		<div class="table clearfix">
		<h3 class="fl" id="so-soft"><i class="iconfont">&#xec2e;</i>软件工具</h3>
		<ul class="tab-hd clearfix">
	        <li class="on">精品软件</li>
			<li>发现APP</li>
            <li>在线工具</li>
		</ul>
		<div class="tab-bd">
			<ul class="show clearfix">
				<li class="hot">
					<a href="http://www.qkweixin.com/" target="_blank">乾坤跳转</a></li>
				<li>
					<a href="http://love.appinn.com/" target="_blank">我最喜欢的软件</a></li>
				<li>
					<a href="https://amazing-apps.gitbooks.io/windows-apps-that-amaze-us/content/zh-CN/" target="_blank">Windows 绝赞应用</a></li>
				<li>
					<a href="http://wangchujiang.com/awesome-mac/index.zh.html" target="_blank">Mac 绝赞应用</a></li>
				<li>
					<a href="https://www.52pojie.cn/" target="_blank">吾爱破解</a></li>
				<li>
					<a href="https://msdn.itellyou.cn/" target="_blank">MSDN我告诉你</a></li>
				<li>
					<a href="https://getitfree.cn/" target="_blank">正版中国</a></li>
				<li>
					<a href="http://blog.sina.com.cn/flyonzone" target="_blank">飞扬时空</a></li>
				<li>
					<a href="http://www.carrotchou.blog/" target="_blank">胡萝卜周</a></li>
				<li>
					<a href="https://www.laomoit.com/" target="_blank">殁漂遥</a></li>
				<li>
					<a href="https://www.appinn.com/" target="_blank">小众软件</a></li>
				<li>
					<a href="http://www.apprcn.com/" target="_blank">反斗软件</a></li>
				<li>
					<a href="http://www.fishlee.net/" target="_blank">鱼·后花园</a></li>
				<li>
					<a href="https://www.iplaysoft.com/" target="_blank">异次元软件</a></li>
				<li>
					<a href="https://www.portablesoft.org/" target="_blank">精品绿色软件</a></li>
				<li>
					<a href="http://www.lrshare.com/" target="_blank">绿软分享吧</a></li>
				<li>
					<a href="https://www.appcgn.com/" target="_blank">软件缘</a></li>
				<li>
					<a href="http://www.th-sjy.com/" target="_blank">th_sjy汉化博客</a></li>
				<li>
					<a href="http://www.dayanzai.me/" target="_blank">大眼仔-旭</a></li>
				<li>
					<a href="http://www.v5pc.com/" target="_blank">V5PC绿软</a></li>
				<li>
					<a href="https://xbeta.info/" target="_blank">善用佳软</a></li>
				<li>
					<a href="https://www.macdo.cn/" target="_blank">Mac毒</a></li>
				<li>
					<a href="https://www.repaik.com/forum.php" target="_blank">睿派克论坛</a></li>
				<li>
					<a href="http://www.bokeboke.net/" target="_blank">爱软客</a></li>
				<li>
					<a href="http://www.xuepojie.com/forum.php?mod=guide&view=newthread" target="_blank">学破解</a></li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="http://www.wandoujia.com/award" target="_blank">豌豆荚设计奖</a></li>
				<li>
					<a href="http://app.mi.com/subjectList" target="_blank">小米专题</a></li>
				<li>
					<a href="http://www.anzhi.com/subjects_1.html" target="_blank">安智专题</a></li>
				<li>
					<a href="http://news.d.cn/special.html" target="_blank">当乐手游专题</a></li>
				<li>
					<a href="http://apk.gfan.com/topics-1.shtml" target="_blank">机锋精选专题</a></li>
				<li>
					<a href="http://www.appchina.com/column_list/1" target="_blank">汇说专栏</a></li>
				<li>
					<a href="http://zuimeia.com/" target="_blank">最美应用</a></li>
				<li>
					<a href="http://bbs.zhiyoo.com/" target="_blank">智友论坛</a></li>
				<li>
					<a href="https://forum.xda-developers.com/" target="_blank">XDA社区</a></li>
				<li>
					<a href="https://sspai.com/" target="_blank">少数派</a></li>
				<li>
					<a href="https://www.appinn.com/" target="_blank">小众软件</a></li>
				<li>
					<a href="http://www.appnz.com/" target="_blank">数字捕手</a></li>
				<li class="close">
					<a href="http://pinapps.in/" target="_blank">Pinapps</a></li>
				<li class="close">
					<a href="http://appdp.com/" target="_blank">APP每日推送</a></li>
				<li>
					<a href="http://www.qdaily.com/tags/1288.html" target="_blank">好奇心日报</a></li>
				<li>
					<a href="http://www.wooaii.com/" target="_blank">我爱玩应用</a></li>
			</ul>
			<ul class="clearfix">
				<li class="hot">
					<a href="http://www.qkweixin.com/" target="_blank">乾坤跳转</a></li>
				<li>
					<a href="http://czjx8.com/" target="_blank">vip视频解析</a></li>
				<li>
					<a href="http://www.taguage.com/" target="_blank">Taguage</a></li>
				<li>
					<a href="http://dwz.wailian.work/" target="_blank">短网址生成</a></li>
				<li>
					<a href="http://tool.mkblog.cn/" target="_blank">孟坤工具箱</a></li>
				<li>
					<a href="http://www.downfi.com/video/" target="_blank">小视频下载</a></li>
				<li class="close">
					<a href="https://uzer.me/" target="_blank">在线云应用uzer</a></li>
				<li>
					<a href="https://convertio.co/zh/" target="_blank">在线文件转换器</a></li>
				<li>
					<a href="https://www.ageeye.cn/" target="_blank">地图制作分享</a></li>
				<li class="site-dretails">
					<a href="javascript:;" style="color:#f00" detailsInfo="giftools">GIF工具</a></li>
				<li class="site-dretails">
					<a href="javascript:;" style="color:#f00" detailsInfo="form">表单工具</a></li>
				<li class="site-dretails">
					<a href="javascript:;" style="color:#f00" detailsInfo="compressjpg">图片工具</a></li>
				<li class="site-dretails">
					<a href="javascript:;" style="color:#f00" detailsInfo="pdftools">PDF工具</a></li>
				<li class="site-dretails">
					<a href="javascript:;" style="color:#f00" detailsInfo="hahaimg">斗图工具</a></li>
				<li>
					<a href="https://www.51240.com/" target="_blank">便民查询网</a></li>
				<li>
					<a href="http://music.ifkdy.com/" target="_blank">疯狂音乐搜索</a></li>
				<li>
					<a href="http://24mail.chacuo.net/" target="_blank">十分钟邮箱</a></li>
				<li>
					<a href="http://tool.lu/" target="_blank">Tool.lu</a></li>
				<li>
					<a href="http://cli.im/" target="_blank">草料二维码</a></li>
				<li>
					<a href="https://www.onlineocr.net/" target="_blank">在线OCR识别文字</a></li>
				<li class="close">
					<a href="http://p.haoii123.com/" target="_blank">在线排版工具</a></li>
				<li>
					<a href="http://www.cnplugins.com/" target="_blank">chrome插件网</a></li>
				<li>
					<a href="https://cn.office-converter.com/" target="_blank">文件转换器</a></li>
				<li>
					<a href="http://www.tietuku.com/upload" target="_blank">贴图库-图片外链</a></li>
				<li class="close">
					<a href="http://deepba.com/" target="_blank">装逼神器</a></li>
				<li>
					<a href="https://www.autodraw.com/" target="_blank">AutoDraw</a></li>
				<li>
					<a href="https://www.99cankao.com/" target="_blank">99参考计算网</a></li>
			</ul>
		</div>
	</div>
	</div>
	
	<div class="container">
		<div class="table clearfix">
		<h3 class="fl" id="so-material"><i class="iconfont">&#xe685;</i>模板素材</h3>
		<ul class="tab-hd clearfix">
            <li class="on">图库</li>
            <li>图标</li>
            <li>PPT模板</li>
            <li>简历模板</li>
            <li>字体音效</li>
		</ul>
		<div class="tab-bd">
			<ul class="show clearfix">
				<li>
					<a href="http://pngimg.com/" target="_blank">PNG透明素材</a></li>
				<li>
					<a href="https://pixabay.com/" target="_blank">pixabay</a></li>
				<li>
					<a href="https://stocksnap.io/" target="_blank">stocksnap</a></li>
				<li>
					<a href="https://500px.com/" target="_blank">500px</a></li>
				<li>
					<a href="https://alpha.wallhaven.cc/" target="_blank">wallhaven</a></li>
				<li class="close">
					<a href="https://www.deviantart.com/" target="_blank">deviantart</a></li>
				<li>
					<a href="https://www.pexels.com/" target="_blank">pexels</a></li>
				<li>
					<a href="https://barnimages.com/" target="_blank">barnimages</a></li>
				<li>
					<a href="https://www.gratisography.com/" target="_blank">Gratisography</a></li>
				<li>
					<a href="http://www.58pic.com/" target="_blank">千图网</a></li>
				<li>
					<a href="http://588ku.com/" target="_blank">千库网</a></li>
				<li>
					<a href="https://foodiesfeed.com/" target="_blank">食物 foodiesfeed</a></li>
				<li>
					<a href="http://www.cutestpaw.com/" target="_blank">宠物 cutestpaw</a></li>
				<li>
					<a href="https://psiupuxa.com/" target="_blank">太空壁纸</a></li>
				<li>
					<a href="https://www.netcarshow.com/" target="_blank">汽车壁纸</a></li>
				<li class="hot">
					<a href="http://hao.uisdc.com/photo/" target="_blank">更多</a></li>
			</ul>
			<ul class="clearfix">
				<li class="hot">
					<a href="https://app.brandmark.io/v2/" target="_blank">Logo设计</a></li>
				<li>
					<a href="http://instantlogosearch.com/" target="_blank">instantlogosearch</a></li>
				<li>
					<a href="https://icons8.com/" target="_blank">icons8</a></li>
				<li>
					<a href="http://www.iconfont.cn/" target="_blank">Iconfont</a></li>
				<li>
					<a href="https://www.iconfinder.com/" target="_blank">iconfinder</a></li>
				<li>
					<a href="http://www.easyicon.net/" target="_blank">easyicon</a></li>
				<li class="close">
					<a href="http://www.iconpng.com/" target="_blank">iconPng</a></li>
				<li>
					<a href="https://www.flaticon.com/" target="_blank">flaticon</a></li>
				<li>
					<a href="https://iconmonstr.com/" target="_blank">iconmonstr</a></li>
				<li>
					<a href="https://thenounproject.com/" target="_blank">Noun Project</a></li>
				<li>
					<a href="https://findicons.com/" target="_blank">FindIcons</a></li>
				<li>
					<a href="https://worldvectorlogo.com/" target="_blank">worldvectorlogo</a></li>
				<li>
					<a href="https://seeklogo.com/" target="_blank">seeklogo</a></li>
				<li>
					<a href="https://www.graphberry.com/category/icons" target="_blank">graphberry</a></li>
				<li>
					<a href="https://logoeps.com/" target="_blank">logoeps</a></li>
				<li>
					<a href="http://www.iconarchive.com/" target="_blank">iconarchive</a></li>
				<li>
					<a href="http://www.veryicon.com/" target="_blank">veryicon</a></li>
				<li>
					<a href="https://iconstore.co/" target="_blank">iconstore</a></li>
				<li>
					<a href="https://fontawesome.com/" target="_blank">fontawesome</a></li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="http://www.officeplus.cn/List.shtml?cat=PPT" target="_blank">OfficePLUS</a></li>
				<li>
					<a href="http://www.hippter.com/" target="_blank">HiPPTer</a></li>
				<li>
					<a href="http://www.tretars.com/" target="_blank">逼格ppt</a></li>
				<li>
					<a href="http://www.1ppt.com/" target="_blank">第1PPT</a></li>
				<li>
					<a href="http://www.ypppt.com/" target="_blank">优品PPT</a></li>
				<li>
					<a href="http://www.pptfans.cn/pptmuban" target="_blank">PPTfans</a></li>
				<li>
					<a href="http://list.docer.com/PPT模板/" target="_blank">稻壳儿</a></li>
				<li>
					<a href="http://www.pptstore.net/ppt_moban/?opt=free" target="_blank">PPTstore</a></li>
				<li>
					<a href="http://www.51pptmoban.com/" target="_blank">51ppt模板</a></li>
				<li class="close">
					<a href="http://www.pptschool.com/" target="_blank">PPT大学</a></li>
				<li>
					<a href="http://www.rapidbbs.cn/" target="_blank">锐普ppt</a></li>
				<li>
					<a href="http://www.51ppt.com.cn/" target="_blank">无忧ppt</a></li>
				<li>
					<a href="http://www.yanj.cn/" target="_blank">演界网</a></li>
				<li class="close">
					<a href="http://iloveppt.cn/" target="_blank">我爱ppt</a></li>
				<li>
					<a href="http://www.pooban.com/" target="_blank">扑奔网</a></li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="http://www.officeplus.cn/List.shtml?cat=WORD&tag=13&order=0" target="_blank">OfficePLUS简历</a></li>
				<li>
					<a href="https://www.hloom.com/resumes/" target="_blank">hloom精品简历</a></li>
				<li>
					<a href="https://www.zhiyeapp.com/" target="_blank">知页简历</a></li>
				<li>
					<a href="http://cv.qiaobutang.com/tpl/" target="_blank">乔布简历</a></li>
				<li>
					<a href="http://list.docer.com/%E5%BA%94%E7%94%A8%E6%96%87%E4%B9%A6/?tags=%E7%AE%80%E5%8E%86%E6%B1%82%E8%81%8C" target="_blank">稻壳儿简历</a></li>
				<li>
					<a href="http://www.500d.me/" target="_blank">五百丁</a></li>
				<li>
					<a href="http://www.ijianli.com/" target="_blank">简历在线</a></li>
			</ul>
			<ul class="clearfix">
				<li class="hot">
					<a href="http://www.qiuziti.com/" target="_blank">求字体</a></li>
				<li class="close">
					<a href="http://www.17ziti.com/" target="_blank">字体之家</a></li>
				<li>
					<a href="http://www.diyiziti.com/" target="_blank">第一字体转换器</a></li>
				<li>
					<a href="http://font.chinaz.com/" target="_blank">站长字体</a></li>
				<li>
					<a href="http://www.sozi.cn/zitidaquan/" target="_blank">搜字网</a></li>
				<li>
					<a href="http://font.knowsky.com/" target="_blank">字体下载大宝库</a></li>
				<li>
					<a href="http://www.hellofont.cn/" target="_blank">字 由</a></li>
				<li>
					<a href="http://www.ziticq.com/" target="_blank">字体传奇</a></li>
				<li>
					<a href="http://www.zhaozi.cn/" target="_blank">找字网</a></li>
				<li>
					<a href="http://www.fontex.org/" target="_blank">fontex</a></li>
				<li>
					<a href="https://www.1001freefonts.com/" target="_blank">1001freefonts</a></li>
				<li class="hot">
					<a href="http://www.aigei.com/sound/" target="_blank">爱给网</a></li>
				<li>
					<a href="http://taira-komori.jpn.org/freesoundcn.html" target="_blank">小森平的音效</a></li>
				<li>
					<a href="http://www.yisell.com/" target="_blank">音笑网</a></li>
				<li>
					<a href="http://www.findsounds.com/typesChinese.html" target="_blank">findsounds</a></li>
				<li>
					<a href="http://sc.chinaz.com/yinxiao/" target="_blank">站长素材音效</a></li>
				<li>
					<a href="https://100audio.com/sound/?ref=5456" target="_blank">100AUDIO音效搜索</a></li>
				<li>
					<a href="https://offers.adobe.com/en/na/audition/offers/audition_dlc/AdobeAuditionDLCSFX.html?cq_ck=1407955238126&wcmmode=disabled"
					 target="_blank">Sound Effects</a></li>
				<li>
					<a href="http://www.luyin.com/" target="_blank">录音网</a></li>
				<li>
					<a href="https://www.soundsnap.com/" target="_blank">soundsnap</a></li>
				<li>
					<a href="http://www.sucaibar.com/yinxiao/" target="_blank">素材吧</a></li>
			</ul>
		</div>
	</div>
	</div>
	
	<div class="container">
		<div class="table clearfix">
		<h3 class="fl" id="so-readding"><i class="iconfont">&#xe67e;</i>读物</h3>
		<ul class="tab-hd clearfix">
	        <li class="on">网络小说</li>
			<li>Kindle</li>
	        <li>漫 画</li>
	        <li>杂 志</li>
	        <li>有声读物</li>
	        <li>PDF与博客</li>
		</ul>
		<div class="tab-bd">
			<ul class="show clearfix">
				<li>
					<a href="http://www.soduso.com/" target="_blank">搜 读</a></li>
				<li>
					<a href="https://www.owllook.net/" target="_blank">小说搜索引擎</a></li>
				<li>
					<a href="http://zuiyidu.com/" target="_blank">最易读</a></li>
				<li>
					<a href="https://www.boyunso.com/" target="_blank">拨云搜索</a></li>
				<li>
					<a href="http://www.biquge5200.com/" target="_blank">笔趣阁1</a></li>
				<li>
					<a href="https://www.qu.la/" target="_blank">笔趣阁2</a></li>
				<li>
					<a href="https://www.x23us.com/" target="_blank">顶点小说</a></li>
				<li>
					<a href="https://www.qidian.com/" target="_blank">起点中文网</a></li>
				<li>
					<a href="http://www.zongheng.com/" target="_blank">纵横中文网</a></li>
				<li>
					<a href="https://www.hongxiu.com/" target="_blank">红袖添香</a></li>
				<li>
					<a href="http://www.xxsy.net/" target="_blank">潇湘书院</a></li>
				<li>
					<a href="http://www.jjwxc.net/" target="_blank">晋江文学网</a></li>
				<li>
					<a href="http://chuangshi.qq.com/" target="_blank">创世中文网</a></li>
				<li>
					<a href="http://www.17k.com/" target="_blank">17K小说网</a></li>
				<li>
					<a href="http://www.zhulang.com/" target="_blank">逐浪小说网</a></li>
				<li>
					<a href="http://hjsm.tom.com/" target="_blank">幻剑书盟</a></li>
				<li>
					<a href="https://www.readnovel.com/" target="_blank">小说阅读网</a></li>
				<li>
					<a href="https://www.qdmm.com/" target="_blank">起点女生网</a></li>
				<li>
					<a href="http://www.motie.com/" target="_blank">磨铁中文网</a></li>
				<li>
					<a href="http://www.jjxsw.com/" target="_blank">久久小说网</a></li>
				<li>
					<a href="https://www.bookbao8.com/" target="_blank">书包网</a></li>
			</ul>
			<ul class="clearfix">
				<li class="hot">
					<a href="https://book.jd.com/"
					 target="_blank">京东图书</a></li>
				<li>
					<a href="https://www.jiumodiary.com/" target="_blank">鸠摩搜书</a></li>
				<li class="close">
					<a href="http://mebook.cc/" target="_blank">我的小书屋</a></li>
				<li>
					<a href="https://bookfere.com/" target="_blank">书 伴</a></li>
				<li>
					<a href="https://kgbook.com/" target="_blank">苦瓜书盘</a></li>
				<li>
					<a href="https://www.amazon.cn/Kindle%E5%85%8D%E8%B4%B9%E7%94%B5%E5%AD%90%E4%B9%A6/b/ref=amb_link_30927692_12?ie=UTF8&node=116175071&pf_rd_m=A1AJ19PSB66TGU&pf_rd_s=left-2&pf_rd_r=019VVFFWQYQAVAHCRP80&pf_rd_t=101&pf_rd_p=81488872&pf_rd_i=116169071"
					 target="_blank">亚马逊免费</a></li>
				<li>
					<a href="http://www.zoudupai.com/" target="_blank">走读派</a></li>
				<li class="close">
					<a href="https://www.cnepub.com/" target="_blank">掌上书苑</a></li>
				<li>
					<a href="https://bbs.feng.com/forum.php?mod=forumdisplay&fid=224" target="_blank">威锋电子书分享</a></li>
				<li class="close">
					<a href="http://idesks.me/" target="_blank">iDesks</a></li>
				<li class="close">
					<a href="http://readfree.me/" target="_blank">readfree.me</a></li>
				<li>
					<a href="http://haodoo.net/" target="_blank">好 读</a></li>
				<li>
					<a href="https://www.yuekanshuwu.com/" target="_blank">悦看书屋</a></li>
				<li class="close">
					<a href="http://www.kindle10000.com/" target="_blank">万读论坛</a></li>
				<li>
					<a href="https://www.mlook.mobi/" target="_blank">mlook精校</a></li>
				<li>
					<a href="http://vol.moe/" target="_blank">kindle漫画</a></li>
				<li class="close">
					<a href="http://forfrigg.com/" target="_blank">kindle专用搜索</a></li>
				<li>
					<a href="http://www.gutenberg.org/" target="_blank">古登堡计划</a></li>
				<li class="hot">
					<a href="https://bookfere.com/ebook" target="_blank">更 多</a></li>
			</ul>
			<ul class="clearfix">
				<li class="close">
					<a href="https://www.manhuagui.com/" target="_blank">漫画柜</a></li>
				<li>
					<a href="https://manhua.dmzj.com/" target="_blank">动漫之家</a></li>
				<li>
					<a href="http://www.dm5.com/" target="_blank">动漫屋DM5</a></li>
				<li>
					<a href="http://www.somanhua.com/" target="_blank">搜漫画</a></li>
				<li>
					<a href="http://www.1kkk.com/" target="_blank">极速漫画</a></li>
				<li>
					<a href="http://comic.kukudm.com/" target="_blank">KuKu动漫</a></li>
				<li>
					<a href="http://www.ishuhui.com/cartoon" target="_blank">鼠绘漫画网</a></li>
				<li>
					<a href="http://www.manben.com/" target="_blank">漫本</a></li>
				<li>
					<a href="http://comic.sfacg.com/" target="_blank">sf在线漫画</a></li>
				<li>
					<a href="http://www.18jdm.com/" target="_blank">18劲动漫</a></li>
				<li>
					<a href="http://www.zymk.cn/" target="_blank">知音漫客</a></li>
				<li>
					<a href="http://www.u17.com/" target="_blank">有妖气</a></li>
				<li>
					<a href="http://www.hao123.com/manhua" target="_blank">hao123漫画</a></li>
				<li>
					<a href="http://www.buka.cn/" target="_blank">布卡漫画</a></li>
				<li>
					<a href="http://www.kuaikanmanhua.com/" target="_blank">快看漫画</a></li>
				<li>
					<a href="http://www.manmanapp.com/" target="_blank">漫漫漫画</a></li>
				<li>
					<a href="http://ac.qq.com/" target="_blank">腾讯漫画</a></li>
				<li>
					<a href="https://manhua.163.com/" target="_blank">网易漫画</a></li>
				<li>
					<a href="http://baozoumanhua.com/" target="_blank">暴走漫画</a></li>
				<li>
					<a href="http://manhua.weibo.com/" target="_blank">微漫画</a></li>
				<li>
					<a href="http://vol.moe/" target="_blank">kindle漫画</a></li>
			</ul>
			<ul class="clearfix">
				<li class="close">
					<a href="http://www.i5h8m.com/" target="_blank">五花八门</a></li>
				<li>
					<a href="http://www.pdfzj.com/" target="_blank">PDF之家</a></li>
				<li class="close">
					<a href="http://www.ed2000.com/FileList.asp?FileCategory=%E8%B5%84%E6%96%99&SubCategory=%E6%9D%82%E5%BF%97%E6%9C%9F%E5%88%8A" target="_blank">ED2000杂志</a></li>
				<li>
					<a href="http://www.verycd.com/sto/datum/magazine/" target="_blank">verycd杂志</a></li>
				<li>
					<a href="https://weibo.com/pcpx" target="_blank">十月的杂物铺</a></li>
				<li>
					<a href="https://weibo.com/magazine8" target="_blank">原版君</a></li>
				<li>
					<a href="http://www.ifblue.net/" target="_blank">若蓝格</a></li>
				<li>
					<a href="http://www.freelian.com/" target="_blank">微微杂志馆</a></li>
				<li>
					<a href="http://www.zoupan.com/category/mianfeizazhi/" target="_blank">走盘网</a></li>
				<li class="close">
					<a href="http://www.52duzhe.com/" target="_blank">读者免费在线</a></li>
				<li>
					<a href="http://www.92yilin.com/" target="_blank">意林免费在线</a></li>
				<li>
					<a href="http://www.92gushi.com/" target="_blank">故事会免费在线</a></li>
				<li>
					<a href="http://pan.baidu.com/s/1dGVfS" target="_blank">度盘-报刊杂志</a></li>
			</ul>
			<ul class="clearfix">
				<li class="close">
					<a href="http://www.mmmppp333.com/" target="_blank">有声读物</a></li>
				<li>
					<a href="http://www.lrts.me/" target="_blank">懒人听书</a></li>
				<li>
					<a href="http://www.ximalaya.com/" target="_blank">喜马拉雅</a></li>
				<li>
					<a href="http://qutingshu.com/" target="_blank">趣听书</a></li>
				<li>
					<a href="http://www.tingbook.com/" target="_blank">天方听书网</a></li>
				<li>
					<a href="http://www.kting.cn/" target="_blank">酷听</a></li>
				<li>
					<a href="http://www.justing.com.cn/" target="_blank">静雅思听</a></li>
				<li class="close">
					<a href="http://yuedu.fm/" target="_blank">悦读FM</a></li>
				<li class="close">
					<a href="http://www.ysts8.com/" target="_blank">有声下吧</a></li>
				<li class="close">
					<a href="http://www.pingshuxiazai.com/" target="_blank">评书下载网</a></li>
				<li>
					<a href="http://www.520tingshu.com/" target="_blank">520听书网</a></li>
				<li class="close">
					<a href="http://pan.baidu.com/share/home?uk=4010064038&view=share#category/type=0" target="_blank">度盘-听故事</a></li>
				<li>
					<a href="http://www.tingchina.com/" target="_blank">听中国</a></li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="https://www.jiumodiary.com/" target="_blank">鸠摩搜书</a></li>
				<li>
					<a href="http://www.9lizhi.com/" target="_blank">浩扬励志网</a></li>
				<li class="close">
					<a href="http://www.ed2000.com/FileList.asp?FileCategory=%E5%9B%BE%E4%B9%A6" target="_blank">ED2000图书</a></li>
				<li>
					<a href="http://www.zreading.cn/" target="_blank">左岸读书</a></li>
				<li>
					<a href="http://www.read.org.cn/" target="_blank">战隼学习探索</a></li>
				<li>
					<a href="http://www.ireadweek.com/" target="_blank">周读</a></li>
				<li>
					<a href="http://ibooks.org.cn/" target="_blank">读书小站</a></li>
				<li class="close">
					<a href="http://www.write.org.cn/" target="_blank">读书笔记分享</a></li>
				<li class="close">
					<a href="http://www.xkreading.com/" target="_blank">醒客读书</a></li>
				<li>
					<a href="http://haoshu100.com/" target="_blank">好书推荐排行榜</a></li>
				<li class="close">
					<a href="http://www.54read.com/" target="_blank">五四阅读</a></li>
				<li>
					<a href="http://www.bookask.com/" target="_blank">书 问</a></li>
				<li class="close">
					<a href="http://www.yuehuzhi.com/" target="_blank">阅乎之</a></li>
			</ul>
			
		</div>
	</div>
	</div>
	
	<div class="container">
		<div class="table clearfix">
		<h3 class="fl" id="so-music"><i class="iconfont">&#xe680;</i>音乐</h3>
		<ul class="tab-hd clearfix">
	        <li class="on">在线音乐</li>
	        <li>高清MV</li>
	        <li>无损音乐</li>
	        <li>音乐博客</li>
	        <li>音乐论坛</li>
		</ul>
		<div class="tab-bd">
			<ul class="show clearfix">
				<li>
					<a href="http://music.ifkdy.com/" target="_blank">疯狂音乐搜索</a></li>
				<li>
					<a href="http://lyplayer.hkjapp.com/" target="_blank">灵音播放器</a></li>
				<li>
					<a href="http://music.163.com/" target="_blank">网易云音乐</a></li>
				<li>
					<a href="http://www.xiami.com/" target="_blank">虾米音乐</a></li>
				<li>
					<a href="http://y.qq.com/" target="_blank">QQ音乐</a></li>
				<li>
					<a href="http://www.app-echo.com/" target="_blank">echo回声</a></li>
				<li>
					<a href="https://douban.fm/" target="_blank">豆瓣FM</a></li>
				<li>
					<a href="http://5sing.kugou.com/" target="_blank">5sing原创</a></li>
				<li>
					<a href="http://www.1ting.com/" target="_blank">一听音乐</a></li>
				<li>
					<a href="http://www.kugou.com/" target="_blank">酷狗音乐</a></li>
				<li>
					<a href="http://music.baidu.com/" target="_blank">百度音乐</a></li>
				<li>
					<a href="http://www.kuwo.cn/" target="_blank">酷我音乐</a></li>
				<li>
					<a href="http://www.9sky.com/" target="_blank">九天音乐</a></li>
				<li>
					<a href="https://luooqi.com/" target="_blank">鱼声音乐</a></li>
				<li>
					<a href="http://www.yinyueke.net/" target="_blank">音乐客</a></li>
				<li>
					<a href="http://www.nofm.cn/" target="_blank">乐鼠无牙</a></li>
				<li>
					<a href="https://www.bandari.net/" target="_blank">班得瑞全球网</a></li>
				<li>
					<a href="http://www.hzou.net/" target="_blank">红嘴鸥电台</a></li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="http://www.yinyuetai.com/" target="_blank">音悦台</a></li>
				<li>
					<a href="http://tool.mkblog.cn/yinyuetai/" target="_blank">音悦台MV解析</a></li>
				<li>
					<a href="http://www.170mv.com/" target="_blank">170MV</a></li>
				<li>
					<a href="http://www.truemv.com/" target="_blank">真乐网</a></li>
				<li>
					<a href="https://www.dlkoo.com/down/6/" target="_blank">大连生活-MV</a></li>
				<li>
					<a href="http://www.zhuyin.com/" target="_blank">主音高清</a></li>
				<li>
					<a href="http://www.xiazaimv.com/forum.php" target="_blank">SQHD</a></li>
				<li class="close">
					<a href="http://www.chdmv.com/" target="_blank">CHD高清音乐影像</a></li>
				<li>
					<a href="http://t.hdjay.com/forum.php" target="_blank">可乐分享</a></li>
				<li>
					<a href="http://www.hdmv.org/" target="_blank">hdmv.org</a></li>
				<li class="close">
					<a href="http://www.7mv.cn/" target="_blank">7mv分享网</a></li>
				<li>
					<a href="http://v.qq.com/music/" target="_blank">腾讯MV</a></li>
				<li>
					<a href="http://music.iqiyi.com/" target="_blank">爱奇艺MV</a></li>
				<li>
					<a href="http://www.kuwo.cn/mv/" target="_blank">酷我MV</a></li>
				<li>
					<a href="http://www.1ting.com/mv/" target="_blank">一听MV</a></li>
				<li>
					<a href="http://www.9ku.com/yinyuetai/" target="_blank">九酷·高清MV</a></li>
				<li>
					<a href="http://www.kugou.com/mvweb/html/" target="_blank">酷狗MV</a></li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="https://sq688.com/" target="_blank">超高无损音乐</a></li>
				<li>
					<a href="http://www.51ape.com/" target="_blank">51Ape</a></li>
				<li>
					<a href="http://tieba.baidu.com/f?kw=%E6%97%A0%E6%8D%9F%E9%9F%B3%E4%B9%90" target="_blank">无损音乐贴吧</a></li>
				<li>
					<a href="http://www.moofeel.com/" target="_blank">磨坊音乐</a></li>
				<li>
					<a href="http://www.88liu.com/" target="_blank">88六音乐</a></li>
				<li class="close">
					<a href="http://www.pt80.net/forum.php?gid=89" target="_blank">捌零音乐</a></li>
				<li>
					<a href="http://www.zasv.net/forum-44-1.html" target="_blank">杂碎后院</a></li>
				<li>
					<a href="http://www.cdbao.net/" target="_blank">CD包音乐网</a></li>
				<li>
					<a href="https://trix360.com/forum.php" target="_blank">trix360</a></li>
				<li>
					<a href="http://www.deepms.net/" target="_blank">深度无损音乐</a></li>
				<li>
					<a href="https://sacdr.net/forum.php" target="_blank">易音音乐</a></li>
				<li>
					<a href="http://wusunyinyue.cn/forum.php" target="_blank">无损音乐网</a></li>
				<li class="close">
					<a href="http://ape8.com/" target="_blank">无损音乐吧</a></li>
				<li class="close">
					<a href="http://www.xicxi.com/" target="_blank">XICXI</a></li>
				<li>
					<a href="http://www.91tingge.com/" target="_blank">91听歌网</a></li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="http://www.luoo.net/" target="_blank">落网</a></li>
				<li>
					<a href="http://www.52qingyin.cn/" target="_blank">清音陋室</a></li>
				<li>
					<a href="http://www.musicsailor.com/" target="_blank">水手音乐</a></li>
				<li>
					<a href="http://indietime.lofter.com/" target="_blank">JustIndie</a></li>
				<li>
					<a href="http://www.iyccd.com/" target="_blank">如果你能静下来</a></li>
				<li class="close">
					<a href="http://summerbreeze2007.blogbus.com/" target="_blank">Summer Breeze</a></li>
				<li>
					<a href="http://www.maninmusic.com/" target="_blank">悦之随</a></li>
				<li>
					<a href="http://www.mologer.cn/" target="_blank">音乐是岸</a></li>
				<li>
					<a href="http://www.ningmeng.name/" target="_blank">私房歌</a></li>
				<li>
					<a href="http://www.ttost.com/" target="_blank">听听原声</a></li>
				<li>
					<a href="http://schwarzwei.lofter.com/" target="_blank">哀 暗</a></li>
				<li>
					<a href="http://tothesky.cn/" target="_blank">Best Music</a></li>
				<li>
					<a href="http://blog.sina.com.cn/mhzhmusic" target="_blank">梦幻之弧</a></li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="http://www.tingyuxuan.net/" target="_blank">听雨轩</a></li>
				<li>
					<a href="http://www.zhiaimusic.com/" target="_blank">至爱音乐论坛</a></li>
				<li>
					<a href="http://wusunyinyue.cn/forum.php" target="_blank">无损音乐网</a></li>
				<li>
					<a href="http://www.zasv.net/" target="_blank">杂碎音乐论坛</a></li>
				<li class="close">
					<a href="http://www.pt80.net/" target="_blank">捌零音乐论坛</a></li>
				<li>
					<a href="http://www.88liu.com/" target="_blank">88六社区</a></li>
				<li>
					<a href="http://bbs.musicool.cn/" target="_blank">炫音音乐论坛</a></li>
				<li class="close">
					<a href="http://bbs.xialala.com/" target="_blank">极乐分享音乐</a></li>
				<li>
					<a href="http://bbs.besgold.com/" target="_blank">百事高音乐论坛</a></li>
				<li>
					<a href="http://www.cdbao.net/" target="_blank">CD包音乐网</a></li>
				<li>
					<a href="http://www.mixrnb.com/" target="_blank">MixRNB</a></li>
				<li>
					<a href="http://www.oppsu.cn/" target="_blank">OppsU</a></li>
				<li>
					<a href="http://www.breezee.org/" target="_blank">清风音乐论坛</a></li>
				<li class="close">
					<a href="http://www.eacdy.com/" target="_blank">音艾论坛</a></li>
				<li>
					<a href="http://micool.xclub.tw/" target="_blank">米酷音乐论坛</a></li>
				<li class="close">
					<a href="http://www.oolove.com/" target="_blank">真爱家园</a></li>
				<li class="close">
					<a href="http://www.hcyy.org/" target="_blank">风云音乐谷</a></li>
			</ul>
			
		</div>
	</div>
	</div>
	
	<div class="container">
		<div class="table clearfix">
		<h3 class="fl" id="so-study"><i class="iconfont">&#xe635;</i>学习天堂</h3>
		<ul class="tab-hd clearfix">
	        <li class="on">在线课程</li>
	        <li>考研</li>
	        <li>英语学习</li>
	        <li>TED</li>
	        <li>文库</li>
		</ul>
		<div class="tab-bd">
			<ul class="show clearfix">
				<li>
					<a href="https://www.imooc.com/" target="_blank">慕课网</a></li>
				<li>
					<a href="http://study.163.com/" target="_blank">网易云课堂</a></li>
				<li>
					<a href="http://www.ycku.com/" target="_blank">瓢城Web俱乐部</a></li>
				<li>
					<a href="http://doyoudo.com" target="_blank">doyoudo</a></li>
				<li>
					<a href="https://www.icourse163.org/" target="_blank">中国大学MOOC</a></li>
				<li>
					<a href="https://www.shiyanlou.com/courses/" target="_blank">实验楼</a></li>
				<li>
					<a href="https://ke.qq.com/" target="_blank">腾讯课堂</a></li>
				<li>
					<a href="http://open.163.com/" target="_blank">网易公开课</a></li>
				<li>
					<a href="https://www.jisuanke.com/" target="_blank">计蒜客</a></li>
				<li>
					<a href="https://mooc.guokr.com/" target="_blank">MOOC学院</a></li>
				<li>
					<a href="http://ok.lanou3g.com/" target="_blank">鸥客学院</a></li>
				<li>
					<a href="http://www.51zxw.net/" target="_blank">我要自学网</a></li>
				<li>
					<a href="http://www.duobei.com/" target="_blank">多贝</a></li>
				<li>
					<a href="https://www.coursera.org/" target="_blank">Coursera</a></li>
				<li>
					<a href="http://www.icourses.cn/home/" target="_blank">爱课程</a></li>
				<li>
					<a href="http://oeasy.org/" target="_blank">Oeasy系列</a></li>
				<li>
					<a href="http://www.ibeifeng.com/" target="_blank">北风网</a></li>
				<li>
					<a href="http://www.howzhi.com/" target="_blank">好知网</a></li>
				<li>
					<a href="https://www.wanmen.org/" target="_blank">万门大学</a></li>
				<li class="close">
					<a href="http://www.haoxue.com/" target="_blank">好学网</a></li>
				<li>
					<a href="http://www.gogoup.com/" target="_blank">高高手</a></li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="https://wuqibazao.com/" target="_blank">咚咚学习网</a></li>
				<li>
					<a href="https://weibo.com/719656790" target="_blank">每日考研笔记</a></li>
				<li>
					<a href="https://weibo.com/media2015" target="_blank">传媒小哥</a></li>
				<li>
					<a href="https://weibo.com/u/2091076344" target="_blank">资源分享库</a></li>
				<li>
					<a href="https://weibo.com/u/5359434969" target="_blank">考虫考研萌酱</a></li>
				<li>
					<a href="https://weibo.com/s1002297748" target="_blank">文艺君考研</a></li>
				<li>
					<a href="https://weibo.com/u/5372911673" target="_blank">找研友吧</a></li>
				<li>
					<a href="https://weibo.com/kyqq" target="_blank">考研资源库</a></li>
				<li>
					<a href="https://weibo.com/Dateservice" target="_blank">资料服务库</a></li>
				<li>
					<a href="http://bbs.kaoshidian.com/resource" target="_blank">考试点</a></li>
				<li class="close">
					<a href="http://www.zhuansoo.com/vbar/c/vc.html?id=19" target="_blank">考研圈</a></li>
				<li>
					<a href="http://bbs.kaoyan.com/" target="_blank">考研论坛</a></li>
				<li class="close">
					<a href="http://download.kaoyan.com/" target="_blank">考研论坛-资料</a></li>
				<li>
					<a href="http://club.topsage.com/forum.php?gid=27" target="_blank">大家论坛</a></li>
				<li class="close">
					<a href="http://www.1zhao.org/" target="_blank">知识宝库</a></li>
				<li>
					<a href="http://muchong.com/bbs/forumdisplay.php?fid=127" target="_blank">小木虫-考研</a></li>
				<li>
					<a href="http://bbs.freekaoyan.com/forum.php" target="_blank">免费考研论坛</a></li>
				<li>
					<a href="http://tieba.baidu.com/f?kw=%E8%80%83%E7%A0%94&ie=utf-8" target="_blank">考研贴吧</a></li>
				<li style="color:#E13F3F;">祝考研顺利！</li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="http://www.hjenglish.com/" target="_blank">沪江英语</a></li>
				<li>
					<a href="http://www.51voa.com/" target="_blank">51voa</a></li>
				<li>
					<a href="http://article.yeeyan.org/" target="_blank">译文学习区</a></li>
				<li>
					<a href="http://www.kekenet.com/" target="_blank">可可英语</a></li>
				<li>
					<a href="http://www.putclub.com/" target="_blank">普特英语听力</a></li>
				<li>
					<a href="http://www.mofunenglish.com/" target="_blank">魔方英语</a></li>
				<li>
					<a href="http://www.1speaking.com/" target="_blank">第一口语网</a></li>
				<li>
					<a href="http://www.bigear.cn/" target="_blank">大耳朵英语</a></li>
				<li>
					<a href="http://www.duolingo.cn/" target="_blank">多邻国</a></li>
				<li>
					<a href="http://lang-8.com/" target="_blank">多国语言学习平台</a></li>
				<li>
					<a href="http://www.qcenglish.com/" target="_blank">七彩英语</a></li>
				<li>
					<a href="https://www.engvid.com/" target="_blank">engvid</a></li>
				<li>
					<a href="https://www.npr.org/" target="_blank">NPR</a></li>
				<li>
					<a href="http://www.bbc.com/news" target="_blank">BBC</a></li>
				<li>
					<a href="http://www.reuters.com/" target="_blank">reuters</a></li>
				<li>
					<a href="https://www.iyyxz.com/" target="_blank">english-lover</a></li>
				<li>
					<a href="https://www.shanbay.com/" target="_blank">扇贝网</a></li>
				<li>
					<a href="http://www.baicizhan.com/" target="_blank">百词斩</a></li>
				<li class="hot">
					<a href="https://www.zhihu.com/question/20183585" target="_blank">英语学习-系列</a></li>
				<li class="hot">
					<a href="http://www.yywz123.com/" target="_blank">英语学习大全</a></li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="https://www.ted.com/" target="_blank">TED官网</a></li>
				<li>
					<a href="http://www.kekenet.com/Article/videolis/tedspeech/" target="_blank">可可英语</a></li>
				<li>
					<a href="http://open.163.com/ted/" target="_blank">网易TED</a></li>
				<li>
					<a href="http://edu.youku.com/ted" target="_blank">优酷TED</a></li>
				<li>
					<a href="http://open.sina.com.cn/school/id_57/" target="_blank">新浪TED</a></li>
				<li>
					<a href="http://v.qq.com/vplus/ted" target="_blank">腾讯TED</a></li>
				<li>
					<a href="http://list.iqiyi.com/www/12/---2127----------4-1----.html" target="_blank">爱奇艺TED</a></li>
				<li>
					<a href="http://www.acfun.cn/a/aa5002167" target="_blank">A站TED</a></li>
				<li>
					<a href="http://www.acfun.cn/a/aa5002167" target="_blank">TED演讲集</a></li>
				<li>
					<a href="http://www.tingvoa.com/TED/" target="_blank">VOA英语网</a></li>
				<li>
					<a href="http://www.ximalaya.com/zhubo/1219164/" target="_blank">喜马拉雅TED</a></li>
			</ul>
			<ul class="clearfix">
				<li class="hot">
					<a href="https://www.lanzous.com/i6y7fah" target="_blank">冰点文库</a></li>
				<li>
					<a href="https://wenku.baidu.com/" target="_blank">百度文库</a></li>
				<li>
					<a href="http://www.docin.com/" target="_blank">豆丁网</a></li>
				<li>
					<a href="http://www.doc88.com/" target="_blank">道客巴巴</a></li>
				<li>
					<a href="http://wenshu.court.gov.cn/" target="_blank">中国裁判文书网</a></li>
				<li>
					<a href="http://doc.mbalib.com/" target="_blank">智库文档</a></li>
				<li>
					<a href="http://www.dajudeng.com/" target="_blank">大桔灯</a></li>
				<li>
					<a href="http://www.360doc.com/index.html" target="_blank">360doc</a></li>
				<li>
					<a href="http://www.cnki.net/" target="_blank">中国知网</a></li>
				<li>
					<a href="http://ishare.iask.sina.com.cn/" target="_blank">爱问共享</a></li>
				<li class="close">
					<a href="http://www.chinadmd.com/" target="_blank">中华文本库</a></li>
				<li>
					<a href="http://wenku.it168.com/" target="_blank">IT168文库</a></li>
				<li>
					<a href="http://www.diyifanwen.com/" target="_blank">第一范文网</a></li>
			</ul>
		</div>
	</div>
	</div>
	
	<div class="container">
		<div class="table clearfix">
		<h3 class="fl" id="so-nav"><i class="iconfont">&#xe651;</i>导航先锋</h3>
		<ul class="tab-hd clearfix">
	        <li class="on">综合</li>
	        <li>影视</li>
	        <li>设计</li>
	        <li>学习</li>
	        <li>博客</li>
		</ul>
		<div class="tab-bd">
			<ul class="show clearfix">
				<li>
					<a href="http://ilxdh.com/" target="_blank">龙轩导航</a></li>
				<li>
					<a href="https://www.chaidu.com/" target="_blank">柴都导航</a></li>
				<li>
					<a href="http://www.gitnavi.com/" target="_blank">GitNavi</a></li>
				<li>
					<a href="http://byr.wiki/" target="_blank">北邮人导航</a></li>
				<li class="close">
					<a href="http://mwlmt.cc/d/" target="_blank">五花八门导航</a></li>
				<li>
					<a href="http://qianshan.co/" target="_blank">千山导航</a></li>
				<li>
					<a href="http://www.xiaolvji.com/" target="_blank">效率集</a></li>
				<li>
					<a href="http://www.miguyu.com/" target="_blank">咪咕鱼导航</a></li>
				<li>
					<a href="http://hao.199it.com/" target="_blank">大数据导航</a></li>
				<li>
					<a href="http://www.haoyonghaowan.com/" target="_blank">好用好玩导航</a></li>
				<li>
					<a href="https://www.24kdh.com/" target="_blank">24k导航</a></li>
				<li>
					<a href="http://oo1.win/" target="_blank">炫 猿</a></li>
				<li>
					<a href="http://www.dajiadaohang.com/" target="_blank">打假导航</a></li>
				<li>
					<a href="http://www.jspoo.com/" target="_blank">聚神铺导航</a></li>
				<li>
					<a href="http://qiachu.com/" target="_blank">洽初导航</a></li>
				<li>
					<a href="http://www.lian81.com/" target="_blank">超链网</a></li>
				<li>
					<a href="http://wxbbx.jh1z.com/" target="_blank">微信百宝箱</a></li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="http://www.allyingshi.com/" target="_blank">人人影视大全</a></li>
				<li>
					<a href="http://www.yingmi123.com/" target="_blank">影迷导航网</a></li>
				<li>
					<a href="http://www.dydh.org/" target="_blank">电影导航.ORG</a></li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="http://hao.uisdc.com/" target="_blank">设计师网址导航1</a></li>
				<li class="close">
					<a href="http://www.userinterface.com.cn/" target="_blank">设计师网址导航2</a></li>
				<li>
					<a href="http://hao.xueui.cn/" target="_blank">ui设计导航</a></li>
				<li>
					<a href="http://hao.shejidaren.com/" target="_blank">设计导航</a></li>
				<li class="close">
					<a href="http://www.niudana.com/" target="_blank">牛大拿设计师导航</a></li>
				<li>
					<a href="http://lackk.com/nav/" target="_blank">兰客导航</a></li>
				<li>
					<a href="http://hao.psefan.com/" target="_blank">饭团导航</a></li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="http://www.1nami.com/" target="_blank">1纳米学习导航</a></li>
				<li class="close">
					<a href="http://kbs.cnki.net/" target="_blank">学术网站大全</a></li>
				<li>
					<a href="http://hao.muchong.com/" target="_blank">木虫学术</a></li>
				<li>
					<a href="http://www.paomianba.com/" target="_blank">泡面吧</a></li>
				<li>
					<a href="http://dh.xdf.cn/" target="_blank">新东方教育导航</a></li>
				<li>
					<a href="http://www.yywz123.com/" target="_blank">英语学习大全</a></li>
			</ul>
			<ul class="clearfix">
				<li>
					<a href="http://www.jetli.com.cn/" target="_blank">博客志</a></li>
				<li>
					<a href="https://boke112.com/" target="_blank">boke112导航</a></li>
			</ul>
		</div>
	</div>
	</div>
	
	<div class="link container">
		<div class="link-tie"><strong>友情链接</strong></div>
		<div class="link-con">
			<ul class="clearfix">
				<?php wp_list_bookmarks('orderby=id&categorize=0&category=' . of_get_option('link') . '&title_li='); ?> 
			</ul>
		</div>
	</div>
	
	<div class="sidebar">
	    <ul>
	        <li id="jump-life">休闲</li>
	        <li id="jump-movie">影视</li>
	        <li id="jump-resource">资源</li>
	        <li id="jump-soft">软件</li>
	        <li id="jump-material">素材</li>
	        <li id="jump-readding">读物</li>
	        <li id="jump-music">音乐</li>
	        <li id="jump-study">学习</li>
	        <li id="jump-nav">导航</li>
	    </ul>
	    <div class="sid-top" title="回到顶部"><img src="<?php bloginfo('template_url'); ?>/images/pic152.png" alt=""></div>
	</div>
<?php get_footer(); ?>