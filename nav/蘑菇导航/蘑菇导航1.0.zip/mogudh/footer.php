	<footer>
		<div class="container clearfix">
			<p class="fl">
				<span>Copyright © 2019 ~ <?php echo date("Y")?></span>
				<span><a href="<?php echo get_option('home'); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a></span>
              	<span><?php echo of_get_option( 'customcode'); ?></span>
				<span><?php echo of_get_option( 'textarea'); ?></span><?php echo of_get_option( 'trackcode'); ?>
			</p>
			<img class="fr" src="<?php echo of_get_option( 'dh_logo'); ?>" alt="<?php bloginfo('name'); ?>" title="<?php bloginfo('name'); ?>">
		</div>
	</footer>
</body>
</html>