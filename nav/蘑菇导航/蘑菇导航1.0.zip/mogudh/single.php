<?php get_header(); ?>
<?php 
	if(in_category(array(of_get_option('singlecolumn')))){
		get_template_part('single-news');
	}elseif(in_category(array(of_get_option('doublecolumn')))){
		get_template_part('single-blog');
	}else{
		get_template_part('single-nav');
	}
?>
<?php get_footer(); ?>