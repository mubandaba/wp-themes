<div id="comments">
    请使用多说插件 → <a href="http://wordpress.org/plugins/duoshuo/" target="_blank">插件下载</a>
</div>