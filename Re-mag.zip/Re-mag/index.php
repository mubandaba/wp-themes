<?php
/*****************************************************************
 _____   _   _____   _____   _   _   _____       ___  ___   _____  
|  _  \ | | |_   _| |_   _| | | | | | ____|     /   |/   | | ____| 
| |_| | | |   | |     | |   | |_| | | |__      / /|   /| | | |__   
|  _  { | |   | |     | |   |  _  | |  __|    / / |__/ | | |  __|  
| |_| | | |   | |     | |   | | | | | |___   / /       | | | |___  
|_____/ |_|   |_|     |_|   |_| |_| |_____| /_/        |_| |_____| 

 HTTPS://WWW.BITTHEME.CN/
 ****************************************************************/
?>
<?php get_header(); ?>
            <!--
            <section class="slider-area bg-color2">
                <div class="container">
                    <div class="slider-container">
                        <div id="carouselIndicators" class="carousel slide wow fadeIn" data-ride="carousel">
                            <ol class="carousel-indicators">
                                <li data-target="#carouselIndicators" data-slide-to="0" class="active"></li>
                                <li data-target="#carouselIndicators" data-slide-to="1"></li>
                                <li data-target="#carouselIndicators" data-slide-to="2"></li>
                            </ol>
                            <div class="carousel-inner">
                                <div class="carousel-item">
                                    <div class="slider-wrapper">
                                        <ul class="slider-meta-data">
                                            <li><i class="fa fa-tag"></i><a href="/tag/travel/">Travel</a></li>
                                            <li><i class="fa fa-calendar"></i>Jun, 04, 2018</li>
                                        </ul>
                                        <a href="/dolores-incidunt-condimentum-voluptates/"><h2>Dolores incidunt condimentum voluptates</h2></a>
                                        <p>
                                            Harum quos sapiente dictumst, ultricies corporis! Inventore, faucibus feugiat dis quis ligula, reiciendis numquam vehicula assumenda, eu, ipsam ducimus eiusmod.
                                        </p>
                                        <ul class="slider-author list-inline d-flex">
                                            <li class="slider-author-img list-inline">
                                                <a href="/author/bibi/">	<div class="author-image-box" style="background-image:url(static/images/admin-img.jpg)"></div>
                                                </a>
                                            </li>
                                            <li class="slider-author-descipt list-inline"><a href="/author/bibi/">bibi</a><span>London, United Kingdom</span></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <div class="slider-wrapper">
                                        <ul class="slider-meta-data">
                                            <li><i class="fa fa-tag"></i><a href="/tag/technology/">Technology</a></li>
                                            <li><i class="fa fa-calendar"></i>Jun, 04, 2018</li>
                                        </ul>
                                        <a href="/nterdum-metus-aenean-vestibulum/"><h2>Nterdum metus aenean vestibulum.</h2></a>
                                        <p>
                                            Morbi nibh consequuntur mollis ullam ante temporibus ipsum nobis, laoreet quos magnam. Lorem, aperiam numquam illo, necessitatibus minim, exercitation voluptatem,
                                        </p>
                                        <ul class="slider-author list-inline d-flex">
                                            <li class="slider-author-img list-inline">
                                                <a href="/author/bibi/">	<div class="author-image-box" style="background-image:url(static/images/admin-img.jpg)"></div>
                                                </a>
                                            </li>
                                            <li class="slider-author-descipt list-inline"><a href="/author/bibi/">bibi</a><span>London, United Kingdom</span></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <div class="slider-wrapper">
                                        <ul class="slider-meta-data">
                                            <li><i class="fa fa-tag"></i><a href="/tag/getting-started/">Getting Started</a></li>
                                            <li><i class="fa fa-calendar"></i>Jun, 04, 2018</li>
                                        </ul>
                                        <a href="/themes-2/"><h2>Setting up your own Ghost theme</h2></a>
                                        <p>
                                            Creating a totally custom design for your publication Ghost comes with a beautiful default theme called Casper, which is designed
                                        </p>
                                        <ul class="slider-author list-inline d-flex">
                                            <li class="slider-author-img list-inline">
                                                <a href="/author/ghost/">	<div class="author-image-box" style="background-image:url(static/images/admin-img.png)"></div>
                                                </a>
                                            </li>
                                            <li class="slider-author-descipt list-inline"><a href="/author/ghost/">Ghost</a><span>Sydney, Austria </span></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            -->
            <div class="post-area section-spacing">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 m-auto">
<?php if (have_posts()) :$ashu_i=0;?>
<?php while (have_posts()) : the_post();$ashu_i++;?>
                            <div class="themeix-post-style wow fadeIn d-md-flex">
<?php
$thumb = get_post_meta(get_the_ID(), 'my_post_options', true);
if ($values = $thumb['thumbnail']) { ?>
                                <div class="post-featured-image" style="background-image:url(<?php bloginfo('template_url');?>/functions/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&w=400&h=400&zc=1);background-size: cover;background-position: center center;"></div>
<?php } else { ?>
<?php } ?>
                                <div class="themeix-post-descript">
                                    <div class="post-big-font"><?php echo $ashu_i ?></div>
                                    <ul class="post-meta-data list-inline">
                                        <li class="list-inline-item"><i class="fa fa-tag"></i> <?php the_category(', '); ?></li>
                                        <li class="list-inline-item"><i class="fa fa-calendar"></i> <?php the_time('Y年n月j日') ?></li>
                                    </ul>
                                    <a href="<?php the_permalink(); ?>"><h3 class="title_heading"><?php the_title(); ?></h3></a>
                                    <p><?php echo mb_strimwidth(strip_tags($post->post_content),0,120,'...'); ?></p>
                                </div>
                            </div>
<?php endwhile; ?>
<?php else : ?>
<?php endif; ?>
                            <div class="themeix-pagination">
                                <nav class="pagination d-flex justify-content-between themeix-highlight">
                                    <li class="page-next page-item themeix-highlight wow bounceInRight col">
                                        <?php previous_posts_link('<i class="fa fa-angle-double-left"></i> 上一页', 0); ?>
                                    </li>
                                    <li class="page-prev page-item themeix-highlight wow bounceInLeft col text-right">
                                        <?php next_posts_link('下一页 <i class="fa fa-angle-double-right"></i>', 0); ?>
                                    </li>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<?php get_footer(); ?>