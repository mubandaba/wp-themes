<?php
/*****************************************************************
 _____   _   _____   _____   _   _   _____       ___  ___   _____  
|  _  \ | | |_   _| |_   _| | | | | | ____|     /   |/   | | ____| 
| |_| | | |   | |     | |   | |_| | | |__      / /|   /| | | |__   
|  _  { | |   | |     | |   |  _  | |  __|    / / |__/ | | |  __|  
| |_| | | |   | |     | |   | | | | | |___   / /       | | | |___  
|_____/ |_|   |_|     |_|   |_| |_| |_____| /_/        |_| |_____| 

 HTTPS://WWW.BITTHEME.CN/
 ****************************************************************/
?>
<?php
//WordPress禁用emoji表情
remove_action ('wp_head','print_emoji_detection_script',7);
remove_action ('wp_print_styles','print_emoji_styles');
add_filter ('emoji_svg_url','__return_false');

//WordPress免插件禁用古腾堡编辑器
add_filter ('use_block_editor_for_post','__return_false');