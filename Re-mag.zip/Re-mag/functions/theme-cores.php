<?php
/*****************************************************************
 _____   _   _____   _____   _   _   _____       ___  ___   _____  
|  _  \ | | |_   _| |_   _| | | | | | ____|     /   |/   | | ____| 
| |_| | | |   | |     | |   | |_| | | |__      / /|   /| | | |__   
|  _  { | |   | |     | |   |  _  | |  __|    / / |__/ | | |  __|  
| |_| | | |   | |     | |   | | | | | |___   / /       | | | |___  
|_____/ |_|   |_|     |_|   |_| |_| |_____| /_/        |_| |_____| 

 HTTPS://WWW.BITTHEME.CN/
 ****************************************************************/
?>
<?php
function bit_add_menu_setup() {
    register_nav_menus([
        'main-menu' => __('主菜单'),
    ]);
}
add_action('after_setup_theme', 'bit_add_menu_setup');

function post_thumbnail_src() {
    $thumb = get_post_meta(get_the_ID(), 'my_post_options', true);
    global $post;
    if ($values = $thumb['thumbnail']) {
        //输出自定义域图片地址
        $values = $thumb['thumbnail'];
        $post_thumbnail_src = $thumb['thumbnail'];
    } elseif (has_post_thumbnail()) {
        //如果有特色缩略图，则输出缩略图地址
        $thumbnail_src = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
        $post_thumbnail_src = $thumbnail_src [0];
    } else {
        $post_thumbnail_src = '';
        ob_start();
        ob_end_clean();
        $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
        $post_thumbnail_src = $matches [1] [0];
        //获取该图片 src
        if (empty($post_thumbnail_src)) {
            $post_thumbnail_src = get_bloginfo('template_url')."/static/images/default-picture.jpg";
        }
    }
    ;
    echo $post_thumbnail_src;
}

function record_visitors() {
    if (is_singular()) {
        global $post;
        $post_ID = $post->ID;
        if ($post_ID) {
            $post_views = (int)get_post_meta($post_ID, 'views', true);
            if (!update_post_meta($post_ID, 'views', ($post_views+1))) {
                add_post_meta($post_ID, 'views', 1, true);
            }
        }
    }
}
add_action('wp_head', 'record_visitors');
function post_views($before = '', $after = '', $echo = 1) {
    global $post;
    $post_ID = $post->ID;
    $views = (int)get_post_meta($post_ID, 'views', true);
    if ($echo) echo $before, number_format($views), $after;
    else return $views;
}

function dotGood() {
    global $wpdb, $post;
    $id = $_POST["um_id"];
    if ($_POST["um_action"] == 'topTop') {
        $specs_raters = get_post_meta($id, 'dotGood', true);
        $expire = time() + 99999999;
        $domain = ($_SERVER['HTTP_HOST'] != 'localhost') ? $_SERVER['HTTP_HOST'] : false;
        // make cookies work with localhost
        setcookie('dotGood_' . $id, $id, $expire, '/', $domain, false);
        if (!$specs_raters || !is_numeric($specs_raters)) update_post_meta($id, 'dotGood', 1);
        else update_post_meta($id, 'dotGood', ($specs_raters + 1));
        echo get_post_meta($id, 'dotGood', true);
    }
    die;
}
add_action('wp_ajax_nopriv_dotGood', 'dotGood');
add_action('wp_ajax_dotGood', 'dotGood');

function copyrightDate() {
    global $wpdb;
    $copyright_dates = $wpdb->get_results("
		SELECT
			YEAR(min(post_date_gmt)) AS firstdate,
			YEAR(max(post_date_gmt)) AS lastdate
		FROM
			$wpdb->posts
		WHERE post_status = 'publish'
	");
    if ($copyright_dates) {
        $date = date('Y-m-d');
        $date = explode('-', $date);
        $copyright = "" . $copyright_dates[0]->firstdate;
        if ($copyright_dates[0]->firstdate != $date[0]) {
            $copyright .= '-' . $date[0];
        }
        echo $copyright;
    }
}