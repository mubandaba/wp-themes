<?php
/*****************************************************************
 _____   _   _____   _____   _   _   _____       ___  ___   _____  
|  _  \ | | |_   _| |_   _| | | | | | ____|     /   |/   | | ____| 
| |_| | | |   | |     | |   | |_| | | |__      / /|   /| | | |__   
|  _  { | |   | |     | |   |  _  | |  __|    / / |__/ | | |  __|  
| |_| | | |   | |     | |   | | | | | |___   / /       | | | |___  
|_____/ |_|   |_|     |_|   |_| |_| |_____| /_/        |_| |_____| 

 HTTPS://WWW.BITTHEME.CN/
 ****************************************************************/
?>
<?php get_header(); ?>
<?php if (have_posts()) : the_post(); update_post_caches($posts); ?>
            <section class="section-well bg-color2">
                <div class="container">
                    <div class="well-wrapper">
                        <h2><?php the_title(); ?></h2>
                    </div>
                </div>
            </section>
            <div class="single-area section-spacing">
                <div class="container">
                    <div class="row">
                        <div class="offset-md-2 col-md-8">
                            <div class="post-area">
                                <div class="post-details">
                                    <div class="kg-card-markdown">
                                        <?php the_content(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="single-share-post d-flex justify-content-between themeix">
                                <ul class="single-share-social list-inline themeix">
                                    <li class="list-inline-item"><button type="button" class="btn btn-outline-success article-qr-code shadow"><a data-toggle="modal" data-target="#article_qr_code"><i class="fa fa-weixin"></i></button></a></li>
                                </ul>
                            </div>
                            <div class="modal fade" id="article_qr_code" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                              <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content text-center">
                                  <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalCenterTitle">微信扫一扫 分享给朋友</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                  </div>
                                  <div class="modal-body">
                                    <div id="qrcode"></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<?php else : ?>
<?php endif; ?>
<?php get_footer(); ?>