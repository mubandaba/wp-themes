<?php
/*****************************************************************
 _____   _   _____   _____   _   _   _____       ___  ___   _____  
|  _  \ | | |_   _| |_   _| | | | | | ____|     /   |/   | | ____| 
| |_| | | |   | |     | |   | |_| | | |__      / /|   /| | | |__   
|  _  { | |   | |     | |   |  _  | |  __|    / / |__/ | | |  __|  
| |_| | | |   | |     | |   | | | | | |___   / /       | | | |___  
|_____/ |_|   |_|     |_|   |_| |_| |_____| /_/        |_| |_____| 

 HTTPS://WWW.BITTHEME.CN/
 ****************************************************************/
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title><?php if ( is_home() ) {
		bloginfo('name'); echo " - "; bloginfo('description');
	} elseif ( is_category() ) {
		single_cat_title(); echo " - "; bloginfo('name');
	} elseif (is_single() || is_page() ) {
		single_post_title();
	} elseif (is_search() ) {
		echo "搜索结果"; echo " - "; bloginfo('name');
	} elseif (is_404() ) {
		echo '页面未找到!';
	} else {
		wp_title('',true);
	} ?></title>
    <link rel="stylesheet" href="https://cdn.bootcss.com/twitter-bootstrap/4.4.1/css/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/static/css/font-awesome.min.css" />
    <link rel="stylesheet" href="static/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="https://cdn.bootcss.com/animate.css/3.7.2/animate.min.css" />
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/static/css/theme.css" />
    <link rel="stylesheet" href="static/css/responsive.css" />
    <meta name="description" content="Thoughts, stories and ideas." />
    </head>
    <body class="home-template">
        <div class="main-area">
            <!--
            <ul class="themeix-fixed-social list-inline">
                <li><a href="https://twitter.com/themeix_ltd">twitter</a></li>
                <li><a href="https://www.facebook.com/themeix">facebook</a></li>
                <li><a href="#">google+</a></li>
            </ul>
            -->
            <header class="header-area">
                <div class="themeix-header-collapse collapse bg-color2" id="navbarHeader">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="themeix-header-nav text-left">
                                    <div class="menu-outer">
                                        <div class="table">
                                            <ul id="horizontal-list">
<?php if(function_exists('wp_nav_menu')) wp_nav_menu(array(
    'container' => false,
    'items_wrap' => '%3$s',
    'theme_location' => 'main-menu'
)); ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="themeix-navbar navbar bg-color">
                    <div class="container d-flex justify-content-between">
                        <a href="<?php echo get_option('home'); ?>" class="themeix-navbar-brand navbar-brand d-flex align-items-center">
                            <!-- <img src="" alt="<?php bloginfo('name'); ?>" /> -->
                            <h1><?php bloginfo('name'); ?></h1>
                        </a>
                        <button class="toggle-nav js-toggle-nav navbar-toggler" data-toggle="collapse" data-target="#navbarHeader">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </button>
                    </div>
                </div>
            </header>