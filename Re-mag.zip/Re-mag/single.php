<?php
/*****************************************************************
 _____   _   _____   _____   _   _   _____       ___  ___   _____  
|  _  \ | | |_   _| |_   _| | | | | | ____|     /   |/   | | ____| 
| |_| | | |   | |     | |   | |_| | | |__      / /|   /| | | |__   
|  _  { | |   | |     | |   |  _  | |  __|    / / |__/ | | |  __|  
| |_| | | |   | |     | |   | | | | | |___   / /       | | | |___  
|_____/ |_|   |_|     |_|   |_| |_| |_____| /_/        |_| |_____| 

 HTTPS://WWW.BITTHEME.CN/
 ****************************************************************/
?>
<?php get_header(); ?>
<?php if (have_posts()) : the_post(); update_post_caches($posts); ?>
            <section class="section-well bg-color2">
                <div class="container">
                    <div class="well-wrapper">
                        <h2><?php the_title(); ?></h2>
                        <ul class="post-meta-data list-inline text-center">
                            <li class="list-inline-item"><i class="fa fa-tag"></i> <?php the_category(', '); ?></li>
                            <li class="list-inline-item"><i class="fa fa-calendar"></i> <?php the_time('Y年n月j日') ?></li>
                        </ul>
                    </div>
                </div>
            </section>
            <div class="single-area section-spacing">
                <div class="container">
                    <div class="row">
                        <div class="offset-md-2 col-md-8">
                            <div class="post-area">
                                <div class="post-details">
                                    <div class="kg-card-markdown">
                                        <?php the_content(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="single-share-post d-flex justify-content-between themeix">
<?php if ( has_tag() ) { ?>
                                <div class="tags-cloud-wrapper">
                                    <span class="mr-2"><i class="fa fa-tag"></i></span>
                                    <div class="tag-list">
                                        <?php the_tags('#', ' #', '') ?>
                                    </div>
                                </div>
<?php } else { ?>
<?php } ?>
                                <ul class="single-share-social list-inline themeix">
                                    <li class="list-inline-item"><button type="button" class="btn btn-outline-success article-qr-code shadow"><a data-toggle="modal" data-target="#article_qr_code"><i class="fa fa-weixin"></i></button></a></li>
                                </ul>
                            </div>
                            <div class="modal fade" id="article_qr_code" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                              <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content text-center">
                                  <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalCenterTitle">微信扫一扫 分享给朋友</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                  </div>
                                  <div class="modal-body">
                                    <div id="qrcode"></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="single-admin wow fadeIn">
                                <div class="single-admin-avatar">
                                    <?php echo get_avatar( get_the_author_meta( 'user_email' ) ); ?>
                                </div>
                                <div class="single-admin-intro">
                                    <?php the_author(); ?>
                                    <ul class="single-share-social list-inline themeix">
<?php
if ($values = get_the_author_meta( 'qq_number' )) { ?>
                                        <li class="list-inline-item"><a href="https://wpa.qq.com/msgrd?v=3&uin=<?php echo get_the_author_meta( 'qq_number' ); ?>&site=qq&menu=yes"><i class="fa fa-qq"></i></a></li>
<?php } else { ?>
<?php } ?>
<?php
if ($values = get_the_author_meta( 'wechat_qr_code' )) { ?>
                                        <li class="list-inline-item"><a data-toggle="modal" data-target="#wechat_qr_code"><i class="fa fa-weixin"></i></a></li>
                                        <div class="modal fade" id="wechat_qr_code" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                          <div class="modal-dialog modal-dialog-centered" role="document">
                                            <div class="modal-content text-center">
                                              <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalCenterTitle">微信扫一扫</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                  <span aria-hidden="true">&times;</span>
                                                </button>
                                              </div>
                                              <div class="modal-body">
                                                <img src="<?php echo get_the_author_meta( 'wechat_qr_code' ); ?>">
                                              </div>
                                            </div>
                                          </div>
                                        </div>
<?php } else { ?>
<?php } ?>
                                        <li class="list-inline-item"><a href=""><i class="fa fa-globe"></i></a></li>
                                    </ul>
                                    <p>
                                        <?php the_author_description(); ?>
                                    </p>
                                </div>
                            </div>
                            <nav class="themeix-pagination single-pagination">
                                <ul class="pagination d-flex justify-content-between themeix-highlight">
                                    <li class="page-next page-item themeix-highlight wow bounceInRight col">
                                        <?php previous_post_link('<i class="fa fa-angle-double-left"></i> %link'); ?>
                                    </li>
                                    <li class="page-prev page-item themeix-highlight wow bounceInLeft col text-right">
                                        <?php next_post_link('%link <i class="fa fa-angle-double-right"></i>'); ?>
                                    </li>
                                </ul>
                            </nav>
                            <!--
                            <div class="recent-posts">
                                <div class="single-title">
                                    <h4>Latest Posts</h4>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="related-post">
                                            <a href="/welcome/">
                                                <div class="related-post-img height-250" style="background-image:url(https://casper.ghost.org/v1.0.0/images/welcome.jpg);">
                                                </div>
                                            </a>
                                            <div class="related-post-content">
                                                <a href="/welcome/">
                                                    <h3>Welcome to Ghost</h3>
                                                </a>
                                                <ul class="related-meta-data list-inline">
                                                    <li class="list-inline-item"><i class="fa fa-tag"></i><a href="/tag/getting-started/"> Getting Started</a></li>
                                                    <li class="list-inline-item"><i class="fa fa-calendar"></i> 4 June 2018</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                -->
                            </div>
                        </div>
                        <!--
                        <div class="comments">
                                <h2>评论</h2>
                        </div>
                        -->
                    </div>
                </div>
            </div>
<?php else : ?>
<?php endif; ?>
<?php get_footer(); ?>