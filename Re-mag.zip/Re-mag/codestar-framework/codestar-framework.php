<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access directly.
require_once plugin_dir_path( __FILE__ ) .'classes/setup.class.php';
require_once plugin_dir_path( __FILE__ ) .'options/profile-options.theme.php';
require_once plugin_dir_path( __FILE__ ) .'options/metabox.theme.php';