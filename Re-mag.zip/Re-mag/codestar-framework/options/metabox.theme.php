<?php if (! defined('ABSPATH')) {
    die;
}
// Cannot access directly.

//
// Metabox of the PAGE
// Set a unique slug-like ID
//
$prefix_page_opts = 'my_post_options';

//
// Create a metabox
//
CSF::createMetabox($prefix_page_opts, array(
    'title' => 'Re-mag主题拓展',
    'post_type' => 'post',
    'data_type' => 'serialize',
    'show_restore' => true,
));

//
// Create a section
//
CSF::createSection($prefix_page_opts, array(
    'title' => '基本设置',
    'fields' => array(
        array(
            'id' => 'thumbnail',
            'type' => 'upload',
            'title' => '主题特色图',
        ),
    )
));