<?php if (! defined('ABSPATH')) {
    die;
}
// Cannot access directly.

//
// Set a unique slug-like ID
//
$prefix = 'my_profile_options';

//
// Create profile options
//
CSF::createProfileOptions($prefix, array(
    'data_type' => 'unserialize'
));

//
// Create a section
//
CSF::createSection($prefix, array(
    'title' => 'Re-mag主题拓展',
    'fields' => array(
        array(
            'id' => 'qq_number',
            'type' => 'text',
            'title' => 'QQ号码',
        ),
        array(
            'id' => 'wechat_qr_code',
            'type' => 'upload',
            'title' => '微信二维码',
        ),
    )
));