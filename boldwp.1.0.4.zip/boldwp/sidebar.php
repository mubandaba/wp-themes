<?php
/**
* The file for displaying the sidebars.
*
* @package BoldWP WordPress Theme
* @copyright Copyright (C) 2020 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/
?>

<div class="boldwp-sidebar-wrapper boldwp-sidebar-widget-areas clearfix" id="boldwp-sidebar-wrapper" itemscope="itemscope" itemtype="http://schema.org/WPSideBar" role="complementary">
<div class="theiaStickySidebar">
<div class="boldwp-sidebar-wrapper-inside clearfix">

<?php boldwp_sidebar_one(); ?>

</div>
</div>
</div><!-- /#boldwp-sidebar-wrapper-->