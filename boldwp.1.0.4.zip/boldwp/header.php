<?php
/**
* The header for BoldWP theme.
*
* @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
*
* @package BoldWP WordPress Theme
* @copyright Copyright (C) 2020 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="profile" href="http://gmpg.org/xfn/11">
<?php wp_head(); ?>
</head>

<body <?php body_class('boldwp-animated boldwp-fadein'); ?> id="boldwp-site-body" itemscope="itemscope" itemtype="http://schema.org/WebPage">
<?php wp_body_open(); ?>
<a class="skip-link screen-reader-text" href="#boldwp-posts-wrapper"><?php esc_html_e( 'Skip to content', 'boldwp' ); ?></a>

<div class="boldwp-site-wrapper">

<?php boldwp_before_header(); ?>

<div class="boldwp-outer-wrapper">
<div class="boldwp-container" id="boldwp-header" itemscope="itemscope" itemtype="http://schema.org/WPHeader" role="banner">
<div class="boldwp-head-content clearfix" id="boldwp-head-content">

<?php if ( !(boldwp_get_option('hide_header_content')) ) { ?>
<div class="boldwp-header-inside clearfix">
<div class="boldwp-header-inside-content clearfix">

<div class="boldwp-logo">
<?php if ( has_custom_logo() ) : ?>
    <div class="site-branding">
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" class="boldwp-logo-img-link">
        <img src="<?php echo esc_url( boldwp_custom_logo() ); ?>" alt="" class="boldwp-logo-img"/>
    </a>
    <div class="boldwp-custom-logo-info"><?php boldwp_site_title(); ?></div>
    </div>
<?php else: ?>
    <div class="site-branding">
      <?php boldwp_site_title(); ?>
    </div>
<?php endif; ?>
</div>

<div class="boldwp-header-ad">
<?php dynamic_sidebar( 'boldwp-header-ad' ); ?>
</div><!--/.boldwp-header-ad -->

</div>
</div>
<?php } else { ?>
<div class="boldwp-no-header-content">
  <?php boldwp_site_title(); ?>
</div>
<?php } ?>

</div><!--/#boldwp-head-content -->
</div><!--/#boldwp-header -->
</div>

<?php boldwp_after_header(); ?>

<?php boldwp_header_image(); ?>

<?php if ( !(boldwp_get_option('disable_primary_menu')) ) { ?>
<div class="boldwp-outer-wrapper">
<div class="boldwp-container boldwp-primary-menu-container clearfix">
<div class="boldwp-primary-menu-container-inside clearfix">

<nav class="boldwp-nav-primary" id="boldwp-primary-navigation" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement" role="navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'boldwp' ); ?>">
<button class="boldwp-primary-responsive-menu-icon" aria-controls="boldwp-menu-primary-navigation" aria-expanded="false"><?php esc_html_e( 'Menu', 'boldwp' ); ?></button>
<?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_id' => 'boldwp-menu-primary-navigation', 'menu_class' => 'boldwp-primary-nav-menu boldwp-menu-primary', 'fallback_cb' => 'boldwp_fallback_menu', 'container' => '', ) ); ?>
<?php if ( !(boldwp_get_option('hide_header_social_buttons')) ) { boldwp_header_social_buttons(); } ?>
</nav>

</div>
</div>
</div>
<?php } ?>

<div id="boldwp-search-overlay-wrap" class="boldwp-search-overlay">
  <div class="boldwp-search-overlay-content">
    <?php get_search_form(); ?>
  </div>
  <button class="boldwp-search-closebtn" aria-label="<?php esc_attr_e( 'Close Search', 'boldwp' ); ?>" title="<?php esc_attr_e('Close Search','boldwp'); ?>">&#xD7;</button>
</div>

<div class="boldwp-outer-wrapper">
<?php boldwp_top_wide_widgets(); ?>
</div>

<div class="boldwp-outer-wrapper" id="boldwp-wrapper-outside">

<div class="boldwp-container clearfix" id="boldwp-wrapper">
<div class="boldwp-content-wrapper clearfix" id="boldwp-content-wrapper">