<?php
/**
* The template for displaying all single posts.
*
* @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
*
* @package BoldWP WordPress Theme
* @copyright Copyright (C) 2020 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

get_header(); ?>

<div class="boldwp-main-wrapper clearfix" id="boldwp-main-wrapper" itemscope="itemscope" itemtype="http://schema.org/Blog" role="main">
<div class="theiaStickySidebar">
<div class="boldwp-main-wrapper-inside clearfix">

<?php boldwp_before_main_content(); ?>

<div class="boldwp-posts-wrapper" id="boldwp-posts-wrapper">

<?php while (have_posts()) : the_post();

    get_template_part( 'template-parts/content', 'single' );

    boldwp_post_navigation();

    boldwp_post_bottom_widgets();

    if ( !(boldwp_get_option('hide_comment_form')) ) {

    // If comments are open or we have at least one comment, load up the comment template
    if ( comments_open() || get_comments_number() ) :
            comments_template();
    endif;

    }

endwhile; ?>

<div class="clear"></div>
</div><!--/#boldwp-posts-wrapper -->

<?php boldwp_after_main_content(); ?>

</div>
</div>
</div><!-- /#boldwp-main-wrapper -->

<?php get_sidebar(); ?>

<?php get_footer(); ?>