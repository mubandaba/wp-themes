<?php
/**
* The template for displaying 404 pages (not found).
*
* @link https://codex.wordpress.org/Creating_an_Error_404_Page
*
* @package BoldWP WordPress Theme
* @copyright Copyright (C) 2020 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

get_header(); ?>

<div class='boldwp-main-wrapper clearfix' id='boldwp-main-wrapper' itemscope='itemscope' itemtype='http://schema.org/Blog' role='main'>
<div class='theiaStickySidebar'>
<div class="boldwp-main-wrapper-inside clearfix">

<div class='boldwp-posts-wrapper' id='boldwp-posts-wrapper'>

<div class='boldwp-posts boldwp-box'>
<div class="boldwp-box-inside">

<div class="boldwp-page-header-outside">
<header class="boldwp-page-header">
<div class="boldwp-page-header-inside">
    <?php if ( boldwp_get_option('error_404_heading') ) : ?>
    <h1 class="page-title"><?php echo esc_html( boldwp_get_option('error_404_heading') ); ?></h1>
    <?php else : ?>
    <h1 class="page-title"><?php esc_html_e( 'Oops! That page can not be found.', 'boldwp' ); ?></h1>
    <?php endif; ?>
</div>
</header><!-- .boldwp-page-header -->
</div>

<div class='boldwp-posts-content'>

    <?php if ( boldwp_get_option('error_404_message') ) : ?>
    <p><?php echo wp_kses_post( force_balance_tags( boldwp_get_option('error_404_message') ) ); ?></p>
    <?php else : ?>
    <p><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'boldwp' ); ?></p>
    <?php endif; ?>

    <?php if ( !(boldwp_get_option('hide_404_search')) ) { ?><?php get_search_form(); ?><?php } ?>

</div>

</div>
</div>

</div><!--/#boldwp-posts-wrapper -->

</div>
</div>
</div><!-- /#boldwp-main-wrapper -->

<?php get_footer(); ?>