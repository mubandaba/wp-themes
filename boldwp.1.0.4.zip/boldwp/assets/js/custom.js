jQuery(document).ready(function($) {
    'use strict';

    if(boldwp_ajax_object.secondary_menu_active){
         if(boldwp_ajax_object.secondary_mobile_menu_active){

            //$(".boldwp-nav-secondary .boldwp-secondary-nav-menu").addClass("boldwp-secondary-responsive-menu").before('<div class="boldwp-secondary-responsive-menu-icon"></div>');
            $(".boldwp-nav-secondary .boldwp-secondary-nav-menu").addClass("boldwp-secondary-responsive-menu");

            $(".boldwp-secondary-responsive-menu-icon").click(function(){
                $(this).next(".boldwp-nav-secondary .boldwp-secondary-nav-menu").slideToggle();
            });

            $(window).resize(function(){
                if(window.innerWidth > 1112) {
                    $(".boldwp-nav-secondary .boldwp-secondary-nav-menu, nav .sub-menu, nav .children").removeAttr("style");
                    $(".boldwp-secondary-responsive-menu > li").removeClass("boldwp-secondary-menu-open");
                }
            });

            $(".boldwp-secondary-responsive-menu > li").click(function(event){
                if (event.target !== this)
                return;
                $(this).find(".sub-menu:first").toggleClass('boldwp-submenu-toggle').parent().toggleClass("boldwp-secondary-menu-open");
                $(this).find(".children:first").toggleClass('boldwp-submenu-toggle').parent().toggleClass("boldwp-secondary-menu-open");
            });

            $("div.boldwp-secondary-responsive-menu > ul > li").click(function(event) {
                if (event.target !== this)
                    return;
                $(this).find("ul:first").toggleClass('boldwp-submenu-toggle').parent().toggleClass("boldwp-secondary-menu-open");
            });

        }
    }

    if(boldwp_ajax_object.primary_menu_active){
        if(boldwp_ajax_object.primary_mobile_menu_active){

            if(boldwp_ajax_object.sticky_menu_active){
            // grab the initial top offset of the navigation 
            var boldwpstickyNavTop = $('.boldwp-primary-menu-container').offset().top;
            
            // our function that decides weather the navigation bar should have "fixed" css position or not.
            var boldwpstickyNav = function(){
                var boldwpscrollTop = $(window).scrollTop(); // our current vertical position from the top
                     
                // if we've scrolled more than the navigation, change its position to fixed to stick to top,
                // otherwise change it back to relative

                if(boldwp_ajax_object.sticky_mobile_menu_active){
                    if (boldwpscrollTop > boldwpstickyNavTop) {
                        $('.boldwp-primary-menu-container').addClass('boldwp-fixed');
                    } else {
                        $('.boldwp-primary-menu-container').removeClass('boldwp-fixed');
                    }
                } else {
                    if(window.innerWidth > 1112) {
                        if (boldwpscrollTop > boldwpstickyNavTop) {
                            $('.boldwp-primary-menu-container').addClass('boldwp-fixed');
                        } else {
                            $('.boldwp-primary-menu-container').removeClass('boldwp-fixed'); 
                        }
                    }
                }
            };

            boldwpstickyNav();
            // and run it again every time you scroll
            $(window).scroll(function() {
                boldwpstickyNav();
            });
            }

            //$(".boldwp-nav-primary .boldwp-primary-nav-menu").addClass("boldwp-primary-responsive-menu").before('<div class="boldwp-primary-responsive-menu-icon"></div>');
            $(".boldwp-nav-primary .boldwp-primary-nav-menu").addClass("boldwp-primary-responsive-menu");

            $(".boldwp-primary-responsive-menu-icon").click(function(){
                $(this).next(".boldwp-nav-primary .boldwp-primary-nav-menu").slideToggle();
            });

            $(window).resize(function(){
                if(window.innerWidth > 1112) {
                    $(".boldwp-nav-primary .boldwp-primary-nav-menu, nav .sub-menu, nav .children").removeAttr("style");
                    $(".boldwp-primary-responsive-menu > li").removeClass("boldwp-primary-menu-open");
                }
            });

            $(".boldwp-primary-responsive-menu > li").click(function(event){
                if (event.target !== this)
                return;
                $(this).find(".sub-menu:first").toggleClass('boldwp-submenu-toggle').parent().toggleClass("boldwp-primary-menu-open");
                $(this).find(".children:first").toggleClass('boldwp-submenu-toggle').parent().toggleClass("boldwp-primary-menu-open");
            });

            $("div.boldwp-primary-responsive-menu > ul > li").click(function(event) {
                if (event.target !== this)
                    return;
                $(this).find("ul:first").toggleClass('boldwp-submenu-toggle').parent().toggleClass("boldwp-primary-menu-open");
            });

        }
    }

    if($(".boldwp-social-icon-search").length){
        $(".boldwp-social-icon-search").on('click', function (e) {
            e.preventDefault();
            document.getElementById("boldwp-search-overlay-wrap").style.display = "block";
            const boldwp_focusableelements = 'button, [href], input';
            const boldwp_search_modal = document.querySelector('#boldwp-search-overlay-wrap');
            const boldwp_firstfocusableelement = boldwp_search_modal.querySelectorAll(boldwp_focusableelements)[0];
            const boldwp_focusablecontent = boldwp_search_modal.querySelectorAll(boldwp_focusableelements);
            const boldwp_lastfocusableelement = boldwp_focusablecontent[boldwp_focusablecontent.length - 1];
            document.addEventListener('keydown', function(e) {
              let isTabPressed = e.key === 'Tab' || e.keyCode === 9;
              if (!isTabPressed) {
                return;
              }
              if (e.shiftKey) {
                if (document.activeElement === boldwp_firstfocusableelement) {
                  boldwp_lastfocusableelement.focus();
                  e.preventDefault();
                }
              } else {
                if (document.activeElement === boldwp_lastfocusableelement) {
                  boldwp_firstfocusableelement.focus();
                  e.preventDefault();
                }
              }
            });
            boldwp_firstfocusableelement.focus();
        });
    }

    if($(".boldwp-search-closebtn").length){
        $(".boldwp-search-closebtn").on('click', function (e) {
            e.preventDefault();
            document.getElementById("boldwp-search-overlay-wrap").style.display = "none";
        });
    }

    $(".post").fitVids();

    if($(".boldwp-scroll-top").length){
        var boldwp_scroll_button = $( '.boldwp-scroll-top' );
        boldwp_scroll_button.hide();

        $( window ).scroll( function () {
            if ( $( window ).scrollTop() < 20 ) {
                $( '.boldwp-scroll-top' ).fadeOut();
            } else {
                $( '.boldwp-scroll-top' ).fadeIn();
            }
        } );

        boldwp_scroll_button.click( function () {
            $( "html, body" ).animate( { scrollTop: 0 }, 300 );
            return false;
        } );
    }

    if(boldwp_ajax_object.sticky_sidebar_active){
    $('.boldwp-main-wrapper, .boldwp-sidebar-wrapper').theiaStickySidebar({
        containerSelector: ".boldwp-content-wrapper",
        additionalMarginTop: 0,
        additionalMarginBottom: 0,
        minWidth: 960,
    });

    $(window).resize(function(){
        $('.boldwp-main-wrapper, .boldwp-sidebar-wrapper').theiaStickySidebar({
            containerSelector: ".boldwp-content-wrapper",
            additionalMarginTop: 0,
            additionalMarginBottom: 0,
            minWidth: 960,
        });
    });
    }

});