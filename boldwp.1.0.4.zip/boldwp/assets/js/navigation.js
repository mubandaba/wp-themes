/**
 * File navigation.js.
 *
 * Handles toggling the navigation menu for small screens and enables TAB key
 * navigation support for dropdown menus.
 */
( function() {
    var boldwp_secondary_container, boldwp_secondary_button, boldwp_secondary_menu, boldwp_secondary_links, boldwp_secondary_i, boldwp_secondary_len;

    boldwp_secondary_container = document.getElementById( 'boldwp-secondary-navigation' );
    if ( ! boldwp_secondary_container ) {
        return;
    }

    boldwp_secondary_button = boldwp_secondary_container.getElementsByTagName( 'button' )[0];
    if ( 'undefined' === typeof boldwp_secondary_button ) {
        return;
    }

    boldwp_secondary_menu = boldwp_secondary_container.getElementsByTagName( 'ul' )[0];

    // Hide menu toggle button if menu is empty and return early.
    if ( 'undefined' === typeof boldwp_secondary_menu ) {
        boldwp_secondary_button.style.display = 'none';
        return;
    }

    boldwp_secondary_menu.setAttribute( 'aria-expanded', 'false' );
    if ( -1 === boldwp_secondary_menu.className.indexOf( 'nav-menu' ) ) {
        boldwp_secondary_menu.className += ' nav-menu';
    }

    boldwp_secondary_button.onclick = function() {
        if ( -1 !== boldwp_secondary_container.className.indexOf( 'boldwp-toggled' ) ) {
            boldwp_secondary_container.className = boldwp_secondary_container.className.replace( ' boldwp-toggled', '' );
            boldwp_secondary_button.setAttribute( 'aria-expanded', 'false' );
            boldwp_secondary_menu.setAttribute( 'aria-expanded', 'false' );
        } else {
            boldwp_secondary_container.className += ' boldwp-toggled';
            boldwp_secondary_button.setAttribute( 'aria-expanded', 'true' );
            boldwp_secondary_menu.setAttribute( 'aria-expanded', 'true' );
        }
    };

    // Get all the link elements within the menu.
    boldwp_secondary_links    = boldwp_secondary_menu.getElementsByTagName( 'a' );

    // Each time a menu link is focused or blurred, toggle focus.
    for ( boldwp_secondary_i = 0, boldwp_secondary_len = boldwp_secondary_links.length; boldwp_secondary_i < boldwp_secondary_len; boldwp_secondary_i++ ) {
        boldwp_secondary_links[boldwp_secondary_i].addEventListener( 'focus', boldwp_secondary_toggleFocus, true );
        boldwp_secondary_links[boldwp_secondary_i].addEventListener( 'blur', boldwp_secondary_toggleFocus, true );
    }

    /**
     * Sets or removes .focus class on an element.
     */
    function boldwp_secondary_toggleFocus() {
        var self = this;

        // Move up through the ancestors of the current link until we hit .nav-menu.
        while ( -1 === self.className.indexOf( 'nav-menu' ) ) {

            // On li elements toggle the class .focus.
            if ( 'li' === self.tagName.toLowerCase() ) {
                if ( -1 !== self.className.indexOf( 'boldwp-focus' ) ) {
                    self.className = self.className.replace( ' boldwp-focus', '' );
                } else {
                    self.className += ' boldwp-focus';
                }
            }

            self = self.parentElement;
        }
    }

    /**
     * Toggles `focus` class to allow submenu access on tablets.
     */
    ( function( boldwp_secondary_container ) {
        var touchStartFn, boldwp_secondary_i,
            parentLink = boldwp_secondary_container.querySelectorAll( '.menu-item-has-children > a, .page_item_has_children > a' );

        if ( 'ontouchstart' in window ) {
            touchStartFn = function( e ) {
                var menuItem = this.parentNode, boldwp_secondary_i;

                if ( ! menuItem.classList.contains( 'boldwp-focus' ) ) {
                    e.preventDefault();
                    for ( boldwp_secondary_i = 0; boldwp_secondary_i < menuItem.parentNode.children.length; ++boldwp_secondary_i ) {
                        if ( menuItem === menuItem.parentNode.children[boldwp_secondary_i] ) {
                            continue;
                        }
                        menuItem.parentNode.children[boldwp_secondary_i].classList.remove( 'boldwp-focus' );
                    }
                    menuItem.classList.add( 'boldwp-focus' );
                } else {
                    menuItem.classList.remove( 'boldwp-focus' );
                }
            };

            for ( boldwp_secondary_i = 0; boldwp_secondary_i < parentLink.length; ++boldwp_secondary_i ) {
                parentLink[boldwp_secondary_i].addEventListener( 'touchstart', touchStartFn, false );
            }
        }
    }( boldwp_secondary_container ) );
} )();


( function() {
    var boldwp_primary_container, boldwp_primary_button, boldwp_primary_menu, boldwp_primary_links, boldwp_primary_i, boldwp_primary_len;

    boldwp_primary_container = document.getElementById( 'boldwp-primary-navigation' );
    if ( ! boldwp_primary_container ) {
        return;
    }

    boldwp_primary_button = boldwp_primary_container.getElementsByTagName( 'button' )[0];
    if ( 'undefined' === typeof boldwp_primary_button ) {
        return;
    }

    boldwp_primary_menu = boldwp_primary_container.getElementsByTagName( 'ul' )[0];

    // Hide menu toggle button if menu is empty and return early.
    if ( 'undefined' === typeof boldwp_primary_menu ) {
        boldwp_primary_button.style.display = 'none';
        return;
    }

    boldwp_primary_menu.setAttribute( 'aria-expanded', 'false' );
    if ( -1 === boldwp_primary_menu.className.indexOf( 'nav-menu' ) ) {
        boldwp_primary_menu.className += ' nav-menu';
    }

    boldwp_primary_button.onclick = function() {
        if ( -1 !== boldwp_primary_container.className.indexOf( 'boldwp-toggled' ) ) {
            boldwp_primary_container.className = boldwp_primary_container.className.replace( ' boldwp-toggled', '' );
            boldwp_primary_button.setAttribute( 'aria-expanded', 'false' );
            boldwp_primary_menu.setAttribute( 'aria-expanded', 'false' );
        } else {
            boldwp_primary_container.className += ' boldwp-toggled';
            boldwp_primary_button.setAttribute( 'aria-expanded', 'true' );
            boldwp_primary_menu.setAttribute( 'aria-expanded', 'true' );
        }
    };

    // Get all the link elements within the menu.
    boldwp_primary_links    = boldwp_primary_menu.getElementsByTagName( 'a' );

    // Each time a menu link is focused or blurred, toggle focus.
    for ( boldwp_primary_i = 0, boldwp_primary_len = boldwp_primary_links.length; boldwp_primary_i < boldwp_primary_len; boldwp_primary_i++ ) {
        boldwp_primary_links[boldwp_primary_i].addEventListener( 'focus', boldwp_primary_toggleFocus, true );
        boldwp_primary_links[boldwp_primary_i].addEventListener( 'blur', boldwp_primary_toggleFocus, true );
    }

    /**
     * Sets or removes .focus class on an element.
     */
    function boldwp_primary_toggleFocus() {
        var self = this;

        // Move up through the ancestors of the current link until we hit .nav-menu.
        while ( -1 === self.className.indexOf( 'nav-menu' ) ) {

            // On li elements toggle the class .focus.
            if ( 'li' === self.tagName.toLowerCase() ) {
                if ( -1 !== self.className.indexOf( 'boldwp-focus' ) ) {
                    self.className = self.className.replace( ' boldwp-focus', '' );
                } else {
                    self.className += ' boldwp-focus';
                }
            }

            self = self.parentElement;
        }
    }

    /**
     * Toggles `focus` class to allow submenu access on tablets.
     */
    ( function( boldwp_primary_container ) {
        var touchStartFn, boldwp_primary_i,
            parentLink = boldwp_primary_container.querySelectorAll( '.menu-item-has-children > a, .page_item_has_children > a' );

        if ( 'ontouchstart' in window ) {
            touchStartFn = function( e ) {
                var menuItem = this.parentNode, boldwp_primary_i;

                if ( ! menuItem.classList.contains( 'boldwp-focus' ) ) {
                    e.preventDefault();
                    for ( boldwp_primary_i = 0; boldwp_primary_i < menuItem.parentNode.children.length; ++boldwp_primary_i ) {
                        if ( menuItem === menuItem.parentNode.children[boldwp_primary_i] ) {
                            continue;
                        }
                        menuItem.parentNode.children[boldwp_primary_i].classList.remove( 'boldwp-focus' );
                    }
                    menuItem.classList.add( 'boldwp-focus' );
                } else {
                    menuItem.classList.remove( 'boldwp-focus' );
                }
            };

            for ( boldwp_primary_i = 0; boldwp_primary_i < parentLink.length; ++boldwp_primary_i ) {
                parentLink[boldwp_primary_i].addEventListener( 'touchstart', touchStartFn, false );
            }
        }
    }( boldwp_primary_container ) );
} )();