<?php
/**
* The main template file.
*
* This is the most generic template file in a WordPress theme
* and one of the two required files for a theme (the other being style.css).
* It is used to display a page when nothing more specific matches a query.
* E.g., it puts together the home page when no home.php file exists.
*
* @link https://developer.wordpress.org/themes/basics/template-hierarchy/
*
* @package BoldWP WordPress Theme
* @copyright Copyright (C) 2020 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

get_header(); ?>

<div class="boldwp-main-wrapper clearfix" id="boldwp-main-wrapper" itemscope="itemscope" itemtype="http://schema.org/Blog" role="main">
<div class="theiaStickySidebar">
<div class="boldwp-main-wrapper-inside clearfix">

<?php boldwp_before_main_content(); ?>

<div class="boldwp-posts-wrapper" id="boldwp-posts-wrapper">
<div class="boldwp-posts">

<?php if ( !(boldwp_get_option('hide_posts_heading')) ) { ?>
<?php if(is_home() && !is_paged()) { ?>
<?php if ( boldwp_get_option('posts_heading') ) : ?>
<div class="boldwp-posts-header"><h2 class="boldwp-posts-heading"><span><?php echo esc_html( boldwp_get_option('posts_heading') ); ?></span></h2></div>
<?php else : ?>
<div class="boldwp-posts-header"><h2 class="boldwp-posts-heading"><span><?php esc_html_e( 'Recent Posts', 'boldwp' ); ?></span></h2></div>
<?php endif; ?>
<?php } ?>
<?php } ?>

<div class="boldwp-posts-content">

<?php if (have_posts()) : ?>

    <div class="boldwp-posts-container <?php echo esc_attr(boldwp_posts_container_class()); ?>">
    <?php $boldwp_total_posts = $wp_query->post_count; ?>
    <?php $boldwp_post_counter=1; while (have_posts()) : the_post(); ?>

        <?php get_template_part( 'template-parts/content', boldwp_post_style() ); ?>

    <?php $boldwp_post_counter++; endwhile; ?>
    </div>
    <div class="clear"></div>

    <?php boldwp_posts_navigation(); ?>

<?php else : ?>

  <?php get_template_part( 'template-parts/content', 'none' ); ?>

<?php endif; ?>

</div>

</div>
</div><!--/#boldwp-posts-wrapper -->

<?php boldwp_after_main_content(); ?>

</div>
</div>
</div><!-- /#boldwp-main-wrapper -->

<?php get_sidebar(); ?>

<?php get_footer(); ?>