<?php
/**
* Template part for displaying posts.
*
* @link https://developer.wordpress.org/themes/basics/template-hierarchy/
*
* @package BoldWP WordPress Theme
* @copyright Copyright (C) 2020 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/
?>

<div id="post-<?php the_ID(); ?>" class="boldwp-fp04-post boldwp-item-post boldwp-box">
<div class="boldwp-box-inside">

    <?php if ( !(boldwp_get_option('hide_thumbnail_home')) ) { ?>
    <?php if ( has_post_thumbnail() ) { ?>
        <div class="boldwp-fp04-post-thumbnail boldwp-fp-post-thumbnail">
            <a href="<?php echo esc_url( get_permalink() ); ?>" title="<?php /* translators: %s: post title. */ echo esc_attr( sprintf( __( 'Permanent Link to %s', 'boldwp' ), the_title_attribute( 'echo=0' ) ) ); ?>" class="boldwp-fp04-post-thumbnail-link boldwp-fp-post-thumbnail-link"><?php the_post_thumbnail('boldwp-480w-360h-image', array('class' => 'boldwp-fp04-post-thumbnail-img boldwp-fp-post-thumbnail-img', 'title' => the_title_attribute('echo=0'))); ?></a>
        </div>
    <?php } else { ?>
        <?php if ( !(boldwp_get_option('hide_default_thumbnail_home')) ) { ?>
        <div class="boldwp-fp04-post-thumbnail boldwp-fp-post-thumbnail">
            <a href="<?php echo esc_url( get_permalink() ); ?>" title="<?php /* translators: %s: post title. */ echo esc_attr( sprintf( __( 'Permanent Link to %s', 'boldwp' ), the_title_attribute( 'echo=0' ) ) ); ?>" class="boldwp-fp04-post-thumbnail-link boldwp-fp-post-thumbnail-link"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/no-image-480-360.jpg' ); ?>" class="boldwp-fp04-post-thumbnail-img boldwp-fp-post-thumbnail-img"/></a>
        </div>
        <?php } ?>
    <?php } ?>
    <?php } ?>

    <div class="boldwp-fp04-post-details">
    <?php if ( !(boldwp_get_option('hide_post_categories_home')) ) { ?><?php boldwp_style_4_cats(); ?><?php } ?>

    <?php if ( !(boldwp_get_option('hide_post_title_home')) ) { ?>
    <?php the_title( sprintf( '<h3 class="boldwp-fp04-post-title boldwp-fp-post-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h3>' ); ?>
    <?php } ?>

    <?php boldwp_style_4_postmeta(); ?>

    <?php if ( !(boldwp_get_option('hide_post_snippet')) ) { ?><div class="boldwp-fp04-post-snippet boldwp-fp-post-snippet boldwp-fp04-post-excerpt boldwp-fp-post-excerpt"><?php the_excerpt(); ?></div><?php } ?>

    <?php if ( !(boldwp_get_option('hide_read_more_button')) ) { ?><div class='boldwp-fp04-post-read-more boldwp-fp-post-read-more'><a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo esc_html( boldwp_read_more_text() ); ?><span class="boldwp-sr-only"> <?php echo wp_kses_post( get_the_title() ); ?></span></a></div><?php } ?>
    </div>

</div>
</div>