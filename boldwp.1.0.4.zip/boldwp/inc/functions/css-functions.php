<?php
/**
* Css Classes Functions
*
* @package BoldWP WordPress Theme
* @copyright Copyright (C) 2020 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

// Category ids in post class
function boldwp_category_id_class($classes) {
    global $post;
    foreach((get_the_category($post->ID)) as $category) {
        $classes [] = 'wpcat-' . $category->cat_ID . '-id';
    }
    return $classes;
}
add_filter('post_class', 'boldwp_category_id_class');


// Adds custom classes to the array of body classes.
function boldwp_body_classes( $classes ) {
    // Adds a class of group-blog to blogs with more than 1 published author.
    if ( is_multi_author() ) {
        $classes[] = 'boldwp-group-blog';
    }

    if ( get_header_image() ) {
        $classes[] = 'boldwp-header-image-active';
    }

    if ( has_custom_logo() ) {
        $classes[] = 'boldwp-custom-logo-active';
    }

    if ( is_page_template( array( 'template-full-width-page.php', 'template-full-width-post.php' ) ) ) {
       $classes[] = 'boldwp-layout-full-width';
    }

    if ( is_404() ) {
        $classes[] = 'boldwp-layout-full-width';
    }

    if ( boldwp_get_option('hide_tagline') ) {
        $classes[] = 'boldwp-tagline-inactive';
    }

    if ( !(boldwp_get_option('disable_primary_menu')) ) {
        $classes[] = 'boldwp-primary-menu-active';
    }
    $classes[] = 'boldwp-primary-mobile-menu-active';

    if ( !(boldwp_get_option('disable_secondary_menu')) ) {
        $classes[] = 'boldwp-secondary-menu-active';
    }
    $classes[] = 'boldwp-secondary-mobile-menu-active';

    $classes[] = 'boldwp-table-css-active';

    return $classes;
}
add_filter( 'body_class', 'boldwp_body_classes' );


/* Posts container class */
function boldwp_posts_container_class() {
    if( 'style-4' == boldwp_post_style() ) {
        $posts_container_class = 'boldwp-fp04-posts-container boldwp-fpw-1-column';
    } elseif( 'style-5' == boldwp_post_style() ) {
        $posts_container_class = 'boldwp-fp05-posts-container boldwp-fpw-2-columns';
    } else {
        $posts_container_class = 'boldwp-default-posts-container';
    }
    return apply_filters( 'boldwp_posts_container_class', $posts_container_class );
}