<?php
/**
* Post meta functions
*
* @package BoldWP WordPress Theme
* @copyright Copyright (C) 2020 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

if ( ! function_exists( 'boldwp_post_tags' ) ) :
/**
 * Prints HTML with meta information for the tags.
 */
function boldwp_post_tags() {
    if ( 'post' == get_post_type() ) {
        /* translators: used between list items, there is a space after the comma */
        $tags_list = get_the_tag_list( '', esc_html_x( ', ', 'list item separator', 'boldwp' ) );
        if ( $tags_list ) {
            /* translators: 1: list of tags. */
            printf( '<span class="boldwp-tags-links"><i class="fas fa-tags" aria-hidden="true"></i> ' . esc_html__( 'Tagged %1$s', 'boldwp' ) . '</span>', $tags_list ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }
    }
}
endif;

if ( ! function_exists( 'boldwp_style_9_cats' ) ) :
function boldwp_style_9_cats() {
    if ( 'post' == get_post_type() ) {
        /* translators: used between list items, there is a space */
        $categories_list = get_the_category_list( esc_html__( '&nbsp;', 'boldwp' ) );
        if ( $categories_list ) {
            /* translators: 1: list of categories. */
            printf( '<div class="boldwp-fp09-post-categories boldwp-fp-post-categories">' . __( '<span class="screen-reader-text">Posted in </span>%1$s', 'boldwp' ) . '</div>', $categories_list ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }
    }
}
endif;

if ( ! function_exists( 'boldwp_style_9_postmeta' ) ) :
function boldwp_style_9_postmeta() { ?>
    <?php if ( !(boldwp_get_option('hide_post_author_home')) || !(boldwp_get_option('hide_posted_date_home')) || !(boldwp_get_option('hide_comments_link_home')) ) { ?>
    <div class="boldwp-fp09-post-footer boldwp-fp-post-footer">
    <?php if ( !(boldwp_get_option('hide_post_author_home')) ) { ?><span class="boldwp-fp09-post-author boldwp-fp-post-author boldwp-fp09-post-meta boldwp-fp-post-meta"><i class="far fa-user-circle" aria-hidden="true"></i>&nbsp;<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><?php echo esc_html( get_the_author() ); ?></a></span><?php } ?>
    <?php if ( !(boldwp_get_option('hide_posted_date_home')) ) { ?><span class="boldwp-fp09-post-date boldwp-fp-post-date boldwp-fp09-post-meta boldwp-fp-post-meta"><i class="far fa-clock" aria-hidden="true"></i>&nbsp;<?php echo esc_html( get_the_date() ); ?></span><?php } ?>
    <?php if ( !(boldwp_get_option('hide_comments_link_home')) ) { ?><?php if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) { ?>
    <span class="boldwp-fp09-post-comment boldwp-fp-post-comment boldwp-fp09-post-meta boldwp-fp-post-meta"><i class="far fa-comments" aria-hidden="true"></i>&nbsp;<?php comments_popup_link( sprintf( wp_kses( /* translators: %s: post title */ __( 'Leave a Comment<span class="screen-reader-text"> on %s</span>', 'boldwp' ), array( 'span' => array( 'class' => array(), ), ) ), wp_kses_post( get_the_title() ) ) ); ?></span>
    <?php } ?><?php } ?>
    </div>
    <?php } ?>
<?php }
endif;

if ( ! function_exists( 'boldwp_style_4_cats' ) ) :
function boldwp_style_4_cats() {
    if ( 'post' == get_post_type() ) {
        /* translators: used between list items, there is a space */
        $categories_list = get_the_category_list( esc_html__( '&nbsp;', 'boldwp' ) );
        if ( $categories_list ) {
            /* translators: 1: list of categories. */
            printf( '<div class="boldwp-fp04-post-categories boldwp-fp-post-categories">' . __( '<span class="screen-reader-text">Posted in </span>%1$s', 'boldwp' ) . '</div>', $categories_list ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }
    }
}
endif;

if ( ! function_exists( 'boldwp_style_4_postmeta' ) ) :
function boldwp_style_4_postmeta() { ?>
    <?php if ( !(boldwp_get_option('hide_post_author_home')) || !(boldwp_get_option('hide_posted_date_home')) || !(boldwp_get_option('hide_comments_link_home')) ) { ?>
    <div class="boldwp-fp04-post-footer boldwp-fp-post-footer">
    <?php if ( !(boldwp_get_option('hide_post_author_home')) ) { ?><span class="boldwp-fp04-post-author boldwp-fp-post-author boldwp-fp04-post-meta boldwp-fp-post-meta"><i class="far fa-user-circle" aria-hidden="true"></i>&nbsp;<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><?php echo esc_html( get_the_author() ); ?></a></span><?php } ?>
    <?php if ( !(boldwp_get_option('hide_posted_date_home')) ) { ?><span class="boldwp-fp04-post-date boldwp-fp-post-date boldwp-fp04-post-meta boldwp-fp-post-meta"><i class="far fa-clock" aria-hidden="true"></i>&nbsp;<?php echo esc_html( get_the_date() ); ?></span><?php } ?>
    <?php if ( !(boldwp_get_option('hide_comments_link_home')) ) { ?><?php if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) { ?>
    <span class="boldwp-fp04-post-comment boldwp-fp-post-comment boldwp-fp04-post-meta boldwp-fp-post-meta"><i class="far fa-comments" aria-hidden="true"></i>&nbsp;<?php comments_popup_link( sprintf( wp_kses( /* translators: %s: post title */ __( 'Leave a Comment<span class="screen-reader-text"> on %s</span>', 'boldwp' ), array( 'span' => array( 'class' => array(), ), ) ), wp_kses_post( get_the_title() ) ) ); ?></span>
    <?php } ?><?php } ?>
    </div>
    <?php } ?>
<?php }
endif;

if ( ! function_exists( 'boldwp_style_5_cats' ) ) :
function boldwp_style_5_cats() {
    if ( 'post' == get_post_type() ) {
        /* translators: used between list items, there is a space */
        $categories_list = get_the_category_list( esc_html__( '&nbsp;', 'boldwp' ) );
        if ( $categories_list ) {
            /* translators: 1: list of categories. */
            printf( '<div class="boldwp-fp05-post-categories boldwp-fp-post-categories">' . __( '<span class="screen-reader-text">Posted in </span>%1$s', 'boldwp' ) . '</div>', $categories_list ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }
    }
}
endif;

if ( ! function_exists( 'boldwp_style_5_postmeta' ) ) :
function boldwp_style_5_postmeta() { ?>
    <?php if ( !(boldwp_get_option('hide_post_author_home')) || !(boldwp_get_option('hide_posted_date_home')) || !(boldwp_get_option('hide_comments_link_home')) ) { ?>
    <div class="boldwp-fp05-post-footer boldwp-fp-post-footer">
    <?php if ( !(boldwp_get_option('hide_post_author_home')) ) { ?><span class="boldwp-fp05-post-author boldwp-fp-post-author boldwp-fp05-post-meta boldwp-fp-post-meta"><i class="far fa-user-circle" aria-hidden="true"></i>&nbsp;<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><?php echo esc_html( get_the_author() ); ?></a></span><?php } ?>
    <?php if ( !(boldwp_get_option('hide_posted_date_home')) ) { ?><span class="boldwp-fp05-post-date boldwp-fp-post-date boldwp-fp05-post-meta boldwp-fp-post-meta"><i class="far fa-clock" aria-hidden="true"></i>&nbsp;<?php echo esc_html( get_the_date() ); ?></span><?php } ?>
    <?php if ( !(boldwp_get_option('hide_comments_link_home')) ) { ?><?php if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) { ?>
    <span class="boldwp-fp05-post-comment boldwp-fp-post-comment boldwp-fp05-post-meta boldwp-fp-post-meta"><i class="far fa-comments" aria-hidden="true"></i>&nbsp;<?php comments_popup_link( sprintf( wp_kses( /* translators: %s: post title */ __( 'Leave a Comment<span class="screen-reader-text"> on %s</span>', 'boldwp' ), array( 'span' => array( 'class' => array(), ), ) ), wp_kses_post( get_the_title() ) ) ); ?></span>
    <?php } ?><?php } ?>
    </div>
    <?php } ?>
<?php }
endif;

if ( ! function_exists( 'boldwp_single_cats' ) ) :
function boldwp_single_cats() {
    if ( 'post' == get_post_type() ) {
        /* translators: used between list items, there is a space */
        $categories_list = get_the_category_list( esc_html__( ', ', 'boldwp' ) );
        if ( $categories_list ) {
            /* translators: 1: list of categories. */
            printf( '<div class="boldwp-entry-meta-single boldwp-entry-meta-single-top"><span class="boldwp-entry-meta-single-cats"><i class="far fa-folder-open" aria-hidden="true"></i>&nbsp;' . __( '<span class="screen-reader-text">Posted in </span>%1$s', 'boldwp' ) . '</span></div>', $categories_list ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }
    }
}
endif;

if ( ! function_exists( 'boldwp_single_postmeta' ) ) :
function boldwp_single_postmeta() { ?>
    <?php if ( !(boldwp_get_option('hide_post_author')) || !(boldwp_get_option('hide_posted_date')) || !(boldwp_get_option('hide_comments_link')) || !(boldwp_get_option('hide_post_likes')) || !(boldwp_get_option('hide_post_views')) || !(boldwp_get_option('hide_post_edit')) ) { ?>
    <div class="boldwp-entry-meta-single">
    <?php if ( !(boldwp_get_option('hide_post_author')) ) { ?><span class="boldwp-entry-meta-single-author"><i class="far fa-user-circle" aria-hidden="true"></i>&nbsp;<span class="author vcard" itemscope="itemscope" itemtype="http://schema.org/Person" itemprop="author"><a class="url fn n" href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><?php echo esc_html( get_the_author() ); ?></a></span></span><?php } ?>
    <?php if ( !(boldwp_get_option('hide_posted_date')) ) { ?><span class="boldwp-entry-meta-single-date"><i class="far fa-clock" aria-hidden="true"></i>&nbsp;<?php echo esc_html( get_the_date() ); ?></span><?php } ?>
    <?php if ( !(boldwp_get_option('hide_comments_link')) ) { ?><?php if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) { ?>
    <span class="boldwp-entry-meta-single-comments"><i class="far fa-comments" aria-hidden="true"></i>&nbsp;<?php comments_popup_link( sprintf( wp_kses( /* translators: %s: post title */ __( 'Leave a Comment<span class="screen-reader-text"> on %s</span>', 'boldwp' ), array( 'span' => array( 'class' => array(), ), ) ), wp_kses_post( get_the_title() ) ) ); ?></span>
    <?php } ?><?php } ?>
    <?php if ( !(boldwp_get_option('hide_post_edit')) ) { ?><?php edit_post_link( sprintf( wp_kses( /* translators: %s: Name of current post. Only visible to screen readers */ __( 'Edit<span class="screen-reader-text"> %s</span>', 'boldwp' ), array( 'span' => array( 'class' => array(), ), ) ), wp_kses_post( get_the_title() ) ), '<span class="edit-link">&nbsp;&nbsp;<i class="far fa-edit" aria-hidden="true"></i> ', '</span>' ); ?><?php } ?>
    </div>
    <?php } ?>
<?php }
endif;

if ( ! function_exists( 'boldwp_page_postmeta' ) ) :
function boldwp_page_postmeta() { ?>
    <?php if ( !(boldwp_get_option('hide_page_author')) || !(boldwp_get_option('hide_page_date')) || !(boldwp_get_option('hide_page_comments')) ) { ?>
    <div class="boldwp-entry-meta-single boldwp-entry-meta-page">
    <?php if ( !(boldwp_get_option('hide_page_author')) ) { ?><span class="boldwp-entry-meta-single-author"><i class="far fa-user-circle" aria-hidden="true"></i>&nbsp;<span class="author vcard" itemscope="itemscope" itemtype="http://schema.org/Person" itemprop="author"><a class="url fn n" href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><?php echo esc_html( get_the_author() ); ?></a></span></span><?php } ?>
    <?php if ( !(boldwp_get_option('hide_page_date')) ) { ?><span class="boldwp-entry-meta-single-date"><i class="far fa-clock" aria-hidden="true"></i>&nbsp;<?php echo esc_html( get_the_date() ); ?></span><?php } ?>
    <?php if ( !(boldwp_get_option('hide_page_comments')) ) { ?><?php if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) { ?>
    <span class="boldwp-entry-meta-single-comments"><i class="far fa-comments" aria-hidden="true"></i>&nbsp;<?php comments_popup_link( sprintf( wp_kses( /* translators: %s: post title */ __( 'Leave a Comment<span class="screen-reader-text"> on %s</span>', 'boldwp' ), array( 'span' => array( 'class' => array(), ), ) ), wp_kses_post( get_the_title() ) ) ); ?></span>
    <?php } ?><?php } ?>
    </div>
    <?php } ?>
<?php }
endif;