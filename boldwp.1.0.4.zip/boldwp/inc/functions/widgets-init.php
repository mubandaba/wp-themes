<?php
/**
* Register widget area.
*
* @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
*
* @package BoldWP WordPress Theme
* @copyright Copyright (C) 2020 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

function boldwp_widgets_init() {

register_sidebar(array(
    'id' => 'boldwp-header-ad',
    'name' => esc_html__( 'Header Right Widgets', 'boldwp' ),
    'description' => esc_html__( 'This widget area is located on the right side of the header of your web page. You can drag and drop a "Custom HTML" widget into this widget area and add your 728x90 banner ad code into that widget.', 'boldwp' ),
    'before_widget' => '<div id="%1$s" class="boldwp-header-widget widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<div class="boldwp-widget-header"><h2 class="boldwp-widget-title"><span class="boldwp-widget-title-inside">',
    'after_title' => '</span></h2></div>'));

register_sidebar(array(
    'id' => 'boldwp-sidebar',
    'name' => esc_html__( 'Sidebar Widgets (Everywhere)', 'boldwp' ),
    'description' => esc_html__( 'This widget area is located on the sidebar of your website. Widgets of this widget area are displayed on every page of your website.', 'boldwp' ),
    'before_widget' => '<div id="%1$s" class="boldwp-side-widget widget boldwp-box %2$s"><div class="boldwp-box-inside">',
    'after_widget' => '</div></div>',
    'before_title' => '<div class="boldwp-widget-header"><h2 class="boldwp-widget-title"><span class="boldwp-widget-title-inside">',
    'after_title' => '</span></h2></div>'));

register_sidebar(array(
    'id' => 'boldwp-home-sidebar',
    'name' => esc_html__( 'Sidebar Widgets (Default HomePage)', 'boldwp' ),
    'description' => esc_html__( 'This widget area is located on the sidebar of your website. Widgets of this widget area are displayed on the default homepage of your website (when you are showing your latest posts on homepage).', 'boldwp' ),
    'before_widget' => '<div id="%1$s" class="boldwp-side-widget widget boldwp-box %2$s"><div class="boldwp-box-inside">',
    'after_widget' => '</div></div>',
    'before_title' => '<div class="boldwp-widget-header"><h2 class="boldwp-widget-title"><span class="boldwp-widget-title-inside">',
    'after_title' => '</span></h2></div>'));


register_sidebar(array(
    'id' => 'boldwp-top-widgets',
    'name' => esc_html__( 'Above Content Widgets (Everywhere)', 'boldwp' ),
    'description' => esc_html__( 'This widget area is located at the top of the main content of your website. Widgets of this widget area are displayed on every page of your website.', 'boldwp' ),
    'before_widget' => '<div id="%1$s" class="boldwp-main-widget widget boldwp-box %2$s"><div class="boldwp-box-inside">',
    'after_widget' => '</div></div>',
    'before_title' => '<div class="boldwp-widget-header"><h2 class="boldwp-widget-title"><span class="boldwp-widget-title-inside">',
    'after_title' => '</span></h2></div>'));

register_sidebar(array(
    'id' => 'boldwp-home-top-widgets',
    'name' => esc_html__( 'Above Content Widgets (Default HomePage)', 'boldwp' ),
    'description' => esc_html__( 'This widget area is located at the top of the main content of your website. Widgets of this widget area are displayed on the default homepage of your website (when you are showing your latest posts on homepage).', 'boldwp' ),
    'before_widget' => '<div id="%1$s" class="boldwp-main-widget widget boldwp-box %2$s"><div class="boldwp-box-inside">',
    'after_widget' => '</div></div>',
    'before_title' => '<div class="boldwp-widget-header"><h2 class="boldwp-widget-title"><span class="boldwp-widget-title-inside">',
    'after_title' => '</span></h2></div>'));


register_sidebar(array(
    'id' => 'boldwp-bottom-widgets',
    'name' => esc_html__( 'Below Content Widgets (Everywhere)', 'boldwp' ),
    'description' => esc_html__( 'This widget area is located at the bottom of the main content of your website. Widgets of this widget area are displayed on every page of your website.', 'boldwp' ),
    'before_widget' => '<div id="%1$s" class="boldwp-main-widget widget boldwp-box %2$s"><div class="boldwp-box-inside">',
    'after_widget' => '</div></div>',
    'before_title' => '<div class="boldwp-widget-header"><h2 class="boldwp-widget-title"><span class="boldwp-widget-title-inside">',
    'after_title' => '</span></h2></div>'));

register_sidebar(array(
    'id' => 'boldwp-home-bottom-widgets',
    'name' => esc_html__( 'Below Content Widgets (Default HomePage)', 'boldwp' ),
    'description' => esc_html__( 'This widget area is located at the bottom of the main content of your website. Widgets of this widget area are displayed on the default homepage of your website (when you are showing your latest posts on homepage).', 'boldwp' ),
    'before_widget' => '<div id="%1$s" class="boldwp-main-widget widget boldwp-box %2$s"><div class="boldwp-box-inside">',
    'after_widget' => '</div></div>',
    'before_title' => '<div class="boldwp-widget-header"><h2 class="boldwp-widget-title"><span class="boldwp-widget-title-inside">',
    'after_title' => '</span></h2></div>'));


register_sidebar(array(
    'id' => 'boldwp-fullwidth-widgets',
    'name' => esc_html__( 'Top Full Width Widgets (Everywhere)', 'boldwp' ),
    'description' => esc_html__( 'This full-width widget area is located after the primary menu of your website. Widgets of this widget area are displayed on every page of your website.', 'boldwp' ),
    'before_widget' => '<div id="%1$s" class="boldwp-main-widget boldwp-top-fullwidth-widget widget %2$s"><div class="boldwp-top-fullwidth-widget-inside">',
    'after_widget' => '</div></div>',
    'before_title' => '<div class="boldwp-widget-header"><h2 class="boldwp-widget-title"><span class="boldwp-widget-title-inside">',
    'after_title' => '</span></h2></div>'));

register_sidebar(array(
    'id' => 'boldwp-home-fullwidth-widgets',
    'name' => esc_html__( 'Top Full Width Widgets (Default HomePage)', 'boldwp' ),
    'description' => esc_html__( 'This full-width widget area is located after the primary menu of your website. Widgets of this widget area are displayed on the default homepage of your website (when you are showing your latest posts on homepage).', 'boldwp' ),
    'before_widget' => '<div id="%1$s" class="boldwp-main-widget boldwp-top-fullwidth-widget widget %2$s"><div class="boldwp-top-fullwidth-widget-inside">',
    'after_widget' => '</div></div>',
    'before_title' => '<div class="boldwp-widget-header"><h2 class="boldwp-widget-title"><span class="boldwp-widget-title-inside">',
    'after_title' => '</span></h2></div>'));


register_sidebar(array(
    'id' => 'boldwp-fullwidth-bottom-widgets',
    'name' => esc_html__( 'Bottom Full Width Widgets (Everywhere)', 'boldwp' ),
    'description' => esc_html__( 'This full-width widget area is located before the footer of your website. Widgets of this widget area are displayed on every page of your website.', 'boldwp' ),
    'before_widget' => '<div id="%1$s" class="boldwp-main-widget boldwp-bottom-fullwidth-widget widget %2$s"><div class="boldwp-bottom-fullwidth-widget-inside">',
    'after_widget' => '</div></div>',
    'before_title' => '<div class="boldwp-widget-header"><h2 class="boldwp-widget-title"><span class="boldwp-widget-title-inside">',
    'after_title' => '</span></h2></div>'));

register_sidebar(array(
    'id' => 'boldwp-home-fullwidth-bottom-widgets',
    'name' => esc_html__( 'Bottom Full Width Widgets (Default HomePage)', 'boldwp' ),
    'description' => esc_html__( 'This full-width widget area is located before the footer of your website. Widgets of this widget area are displayed on the default homepage of your website (when you are showing your latest posts on homepage).', 'boldwp' ),
    'before_widget' => '<div id="%1$s" class="boldwp-main-widget boldwp-bottom-fullwidth-widget widget %2$s"><div class="boldwp-bottom-fullwidth-widget-inside">',
    'after_widget' => '</div></div>',
    'before_title' => '<div class="boldwp-widget-header"><h2 class="boldwp-widget-title"><span class="boldwp-widget-title-inside">',
    'after_title' => '</span></h2></div>'));


register_sidebar(array(
    'id' => 'boldwp-single-post-bottom-widgets',
    'name' => esc_html__( 'Single Post Bottom Widgets', 'boldwp' ),
    'description' => esc_html__( 'This widget area is located at the bottom of single post of any post type (except attachments and pages).', 'boldwp' ),
    'before_widget' => '<div id="%1$s" class="boldwp-main-widget widget boldwp-box %2$s"><div class="boldwp-box-inside">',
    'after_widget' => '</div></div>',
    'before_title' => '<div class="boldwp-widget-header"><h2 class="boldwp-widget-title"><span class="boldwp-widget-title-inside">',
    'after_title' => '</span></h2></div>'));

register_sidebar(array(
    'id' => 'boldwp-top-footer',
    'name' => esc_html__( 'Footer Top', 'boldwp' ),
    'description' => esc_html__( 'This widget area is located on the top of the footer of your website.', 'boldwp' ),
    'before_widget' => '<div id="%1$s" class="boldwp-footer-widget widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="boldwp-widget-title"><span class="boldwp-widget-title-inside">',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'boldwp-footer-1',
    'name' => esc_html__( 'Footer 1', 'boldwp' ),
    'description' => esc_html__( 'This widget area is the column 1 of the footer of your website.', 'boldwp' ),
    'before_widget' => '<div id="%1$s" class="boldwp-footer-widget widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="boldwp-widget-title"><span class="boldwp-widget-title-inside">',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'boldwp-footer-2',
    'name' => esc_html__( 'Footer 2', 'boldwp' ),
    'description' => esc_html__( 'This widget area is the column 2 of the footer of your website.', 'boldwp' ),
    'before_widget' => '<div id="%1$s" class="boldwp-footer-widget widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="boldwp-widget-title"><span class="boldwp-widget-title-inside">',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'boldwp-footer-3',
    'name' => esc_html__( 'Footer 3', 'boldwp' ),
    'description' => esc_html__( 'This widget area is the column 3 of the footer of your website.', 'boldwp' ),
    'before_widget' => '<div id="%1$s" class="boldwp-footer-widget widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="boldwp-widget-title"><span class="boldwp-widget-title-inside">',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'boldwp-footer-4',
    'name' => esc_html__( 'Footer 4', 'boldwp' ),
    'description' => esc_html__( 'This widget area is the column 4 of the footer of your website.', 'boldwp' ),
    'before_widget' => '<div id="%1$s" class="boldwp-footer-widget widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="boldwp-widget-title"><span class="boldwp-widget-title-inside">',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'boldwp-footer-5',
    'name' => esc_html__( 'Footer 5', 'boldwp' ),
    'description' => esc_html__( 'This widget area is the column 5 of the footer of your website.', 'boldwp' ),
    'before_widget' => '<div id="%1$s" class="boldwp-footer-widget widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="boldwp-widget-title"><span class="boldwp-widget-title-inside">',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'boldwp-bottom-footer',
    'name' => esc_html__( 'Footer Bottom', 'boldwp' ),
    'description' => esc_html__( 'This widget area is located on the bottom of the footer of your website.', 'boldwp' ),
    'before_widget' => '<div id="%1$s" class="boldwp-footer-widget widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="boldwp-widget-title"><span class="boldwp-widget-title-inside">',
    'after_title' => '</span></h2>'));

}
add_action( 'widgets_init', 'boldwp_widgets_init' );


function boldwp_sidebar_one_widgets() {
    if ( is_front_page() && is_home() && !is_paged() ) {
    dynamic_sidebar( 'boldwp-home-sidebar' );
    }

    dynamic_sidebar( 'boldwp-sidebar' );
}


function boldwp_top_wide_widgets() { ?>

<?php if ( is_active_sidebar( 'boldwp-home-fullwidth-widgets' ) || is_active_sidebar( 'boldwp-fullwidth-widgets' ) ) : ?>
<div class="boldwp-top-wrapper-outer clearfix">
<div class="boldwp-featured-posts-area boldwp-top-wrapper clearfix">
<?php if ( is_front_page() && is_home() && !is_paged() ) { ?>
<?php dynamic_sidebar( 'boldwp-home-fullwidth-widgets' ); ?>
<?php } ?>

<?php dynamic_sidebar( 'boldwp-fullwidth-widgets' ); ?>
</div>
</div>
<?php endif; ?>

<?php }


function boldwp_top_widgets() { ?>

<?php if ( is_active_sidebar( 'boldwp-home-top-widgets' ) || is_active_sidebar( 'boldwp-top-widgets' ) ) : ?>
<div class="boldwp-featured-posts-area boldwp-featured-posts-area-top clearfix">
<?php if ( is_front_page() && is_home() && !is_paged() ) { ?>
<?php dynamic_sidebar( 'boldwp-home-top-widgets' ); ?>
<?php } ?>

<?php dynamic_sidebar( 'boldwp-top-widgets' ); ?>
</div>
<?php endif; ?>

<?php }


function boldwp_bottom_widgets() { ?>

<?php if ( is_active_sidebar( 'boldwp-home-bottom-widgets' ) || is_active_sidebar( 'boldwp-bottom-widgets' ) ) : ?>
<div class='boldwp-featured-posts-area boldwp-featured-posts-area-bottom clearfix'>
<?php if ( is_front_page() && is_home() && !is_paged() ) { ?>
<?php dynamic_sidebar( 'boldwp-home-bottom-widgets' ); ?>
<?php } ?>

<?php dynamic_sidebar( 'boldwp-bottom-widgets' ); ?>
</div>
<?php endif; ?>

<?php }


function boldwp_bottom_wide_widgets() { ?>

<?php if ( is_active_sidebar( 'boldwp-home-fullwidth-bottom-widgets' ) || is_active_sidebar( 'boldwp-fullwidth-bottom-widgets' ) ) : ?>
<div class="boldwp-bottom-wrapper-outer clearfix">
<div class="boldwp-featured-posts-area boldwp-bottom-wrapper clearfix">
<?php if ( is_front_page() && is_home() && !is_paged() ) { ?>
<?php dynamic_sidebar( 'boldwp-home-fullwidth-bottom-widgets' ); ?>
<?php } ?>

<?php dynamic_sidebar( 'boldwp-fullwidth-bottom-widgets' ); ?>
</div>
</div>
<?php endif; ?>

<?php }


function boldwp_post_bottom_widgets() {
    if ( is_active_sidebar( 'boldwp-single-post-bottom-widgets' ) ) : ?>
        <div class="boldwp-featured-posts-area clearfix">
        <?php dynamic_sidebar( 'boldwp-single-post-bottom-widgets' ); ?>
        </div>
    <?php endif;
}