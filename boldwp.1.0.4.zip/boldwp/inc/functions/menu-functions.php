<?php
/**
* Menu Functions
*
* @package BoldWP WordPress Theme
* @copyright Copyright (C) 2020 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

// Get our wp_nav_menu() fallback, wp_page_menu(), to show a "Home" link as the first item
function boldwp_page_menu_args( $args ) {
    $args['show_home'] = true;
    return $args;
}
add_filter( 'wp_page_menu_args', 'boldwp_page_menu_args' );

function boldwp_top_fallback_menu() {
    wp_page_menu( array(
        'sort_column'  => 'menu_order, post_title',
        'menu_id'      => 'boldwp-menu-secondary-navigation',
        'menu_class'   => 'boldwp-secondary-nav-menu boldwp-menu-secondary',
        'container'    => 'ul',
        'echo'         => true,
        'link_before'  => '',
        'link_after'   => '',
        'before'       => '',
        'after'        => '',
        'item_spacing' => 'discard',
        'walker'       => '',
    ) );
}

function boldwp_fallback_menu() {
    wp_page_menu( array(
        'sort_column'  => 'menu_order, post_title',
        'menu_id'      => 'boldwp-menu-primary-navigation',
        'menu_class'   => 'boldwp-primary-nav-menu boldwp-menu-primary',
        'container'    => 'ul',
        'echo'         => true,
        'link_before'  => '',
        'link_after'   => '',
        'before'       => '',
        'after'        => '',
        'item_spacing' => 'discard',
        'walker'       => '',
    ) );
}

function boldwp_secondary_menu_area() {
if ( !(boldwp_get_option('disable_secondary_menu')) ) { ?>
<div class="boldwp-outer-wrapper">
<div class="boldwp-container boldwp-secondary-menu-container clearfix">
<div class="boldwp-secondary-menu-container-inside clearfix">
<nav class="boldwp-nav-secondary" id="boldwp-secondary-navigation" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement" role="navigation" aria-label="<?php esc_attr_e( 'Secondary Menu', 'boldwp' ); ?>">
<button class="boldwp-secondary-responsive-menu-icon" aria-controls="boldwp-menu-secondary-navigation" aria-expanded="false"><?php esc_html_e( 'Menu', 'boldwp' ); ?></button>
<?php wp_nav_menu( array( 'theme_location' => 'secondary', 'menu_id' => 'boldwp-menu-secondary-navigation', 'menu_class' => 'boldwp-secondary-nav-menu boldwp-menu-secondary', 'fallback_cb' => 'boldwp_top_fallback_menu', 'container' => '', ) ); ?>
<?php if ( !(boldwp_get_option('hide_header_date')) ) { ?><div class="boldwp-header-date"><?php echo esc_html(date_i18n(get_option( 'date_format' ))); ?></div><?php } ?>
</nav>
</div>
</div>
</div>
<?php }
}

add_action('boldwp_before_header', 'boldwp_secondary_menu_area', 10 );