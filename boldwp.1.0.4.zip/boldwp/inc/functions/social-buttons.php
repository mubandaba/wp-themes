<?php
/**
* Social buttons
*
* @package BoldWP WordPress Theme
* @copyright Copyright (C) 2020 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

function boldwp_header_social_buttons() { ?>

<div class="boldwp-top-social-icons clearfix">
    <?php if ( boldwp_get_option('twitterlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('twitterlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-twitter" aria-label="<?php esc_attr_e('Twitter Button','boldwp'); ?>"><i class="fab fa-twitter" aria-hidden="true" title="<?php esc_attr_e('Twitter','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('facebooklink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('facebooklink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-facebook" aria-label="<?php esc_attr_e('Facebook Button','boldwp'); ?>"><i class="fab fa-facebook-f" aria-hidden="true" title="<?php esc_attr_e('Facebook','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('googlelink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('googlelink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-google-plus" aria-label="<?php esc_attr_e('Google Plus Button','boldwp'); ?>"><i class="fab fa-google-plus-g" aria-hidden="true" title="<?php esc_attr_e('Google Plus','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('pinterestlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('pinterestlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-pinterest" aria-label="<?php esc_attr_e('Pinterest Button','boldwp'); ?>"><i class="fab fa-pinterest" aria-hidden="true" title="<?php esc_attr_e('Pinterest','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('linkedinlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('linkedinlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-linkedin" aria-label="<?php esc_attr_e('Linkedin Button','boldwp'); ?>"><i class="fab fa-linkedin-in" aria-hidden="true" title="<?php esc_attr_e('Linkedin','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('instagramlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('instagramlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-instagram" aria-label="<?php esc_attr_e('Instagram Button','boldwp'); ?>"><i class="fab fa-instagram" aria-hidden="true" title="<?php esc_attr_e('Instagram','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('flickrlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('flickrlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-flickr" aria-label="<?php esc_attr_e('Flickr Button','boldwp'); ?>"><i class="fab fa-flickr" aria-hidden="true" title="<?php esc_attr_e('Flickr','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('youtubelink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('youtubelink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-youtube" aria-label="<?php esc_attr_e('Youtube Button','boldwp'); ?>"><i class="fab fa-youtube" aria-hidden="true" title="<?php esc_attr_e('Youtube','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('vimeolink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('vimeolink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-vimeo" aria-label="<?php esc_attr_e('Vimeo Button','boldwp'); ?>"><i class="fab fa-vimeo-v" aria-hidden="true" title="<?php esc_attr_e('Vimeo','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('soundcloudlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('soundcloudlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-soundcloud" aria-label="<?php esc_attr_e('SoundCloud Button','boldwp'); ?>"><i class="fab fa-soundcloud" aria-hidden="true" title="<?php esc_attr_e('SoundCloud','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('messengerlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('messengerlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-messenger" aria-label="<?php esc_attr_e('Messenger Button','boldwp'); ?>"><i class="fab fa-facebook-messenger" aria-hidden="true" title="<?php esc_attr_e('Messenger','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('lastfmlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('lastfmlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-lastfm" aria-label="<?php esc_attr_e('Lastfm Button','boldwp'); ?>"><i class="fab fa-lastfm" aria-hidden="true" title="<?php esc_attr_e('Lastfm','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('mediumlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('mediumlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-medium" aria-label="<?php esc_attr_e('Medium Button','boldwp'); ?>"><i class="fab fa-medium-m" aria-hidden="true" title="<?php esc_attr_e('Medium','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('githublink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('githublink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-github" aria-label="<?php esc_attr_e('Github Button','boldwp'); ?>"><i class="fab fa-github" aria-hidden="true" title="<?php esc_attr_e('Github','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('bitbucketlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('bitbucketlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-bitbucket" aria-label="<?php esc_attr_e('Bitbucket Button','boldwp'); ?>"><i class="fab fa-bitbucket" aria-hidden="true" title="<?php esc_attr_e('Bitbucket','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('tumblrlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('tumblrlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-tumblr" aria-label="<?php esc_attr_e('Tumblr Button','boldwp'); ?>"><i class="fab fa-tumblr" aria-hidden="true" title="<?php esc_attr_e('Tumblr','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('digglink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('digglink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-digg" aria-label="<?php esc_attr_e('Digg Button','boldwp'); ?>"><i class="fab fa-digg" aria-hidden="true" title="<?php esc_attr_e('Digg','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('deliciouslink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('deliciouslink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-delicious" aria-label="<?php esc_attr_e('Delicious Button','boldwp'); ?>"><i class="fab fa-delicious" aria-hidden="true" title="<?php esc_attr_e('Delicious','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('stumblelink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('stumblelink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-stumbleupon" aria-label="<?php esc_attr_e('Stumbleupon Button','boldwp'); ?>"><i class="fab fa-stumbleupon" aria-hidden="true" title="<?php esc_attr_e('Stumbleupon','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('mixlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('mixlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-mix" aria-label="<?php esc_attr_e('Mix Button','boldwp'); ?>"><i class="fab fa-mix" aria-hidden="true" title="<?php esc_attr_e('Mix','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('redditlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('redditlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-reddit" aria-label="<?php esc_attr_e('Reddit Button','boldwp'); ?>"><i class="fab fa-reddit" aria-hidden="true" title="<?php esc_attr_e('Reddit','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('dribbblelink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('dribbblelink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-dribbble" aria-label="<?php esc_attr_e('Dribbble Button','boldwp'); ?>"><i class="fab fa-dribbble" aria-hidden="true" title="<?php esc_attr_e('Dribbble','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('flipboardlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('flipboardlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-flipboard" aria-label="<?php esc_attr_e('Flipboard Button','boldwp'); ?>"><i class="fab fa-flipboard" aria-hidden="true" title="<?php esc_attr_e('Flipboard','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('bloggerlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('bloggerlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-blogger" aria-label="<?php esc_attr_e('Blogger Button','boldwp'); ?>"><i class="fab fa-blogger" aria-hidden="true" title="<?php esc_attr_e('Blogger','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('etsylink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('etsylink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-etsy" aria-label="<?php esc_attr_e('Etsy Button','boldwp'); ?>"><i class="fab fa-etsy" aria-hidden="true" title="<?php esc_attr_e('Etsy','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('behancelink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('behancelink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-behance" aria-label="<?php esc_attr_e('Behance Button','boldwp'); ?>"><i class="fab fa-behance" aria-hidden="true" title="<?php esc_attr_e('Behance','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('amazonlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('amazonlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-amazon" aria-label="<?php esc_attr_e('Amazon Button','boldwp'); ?>"><i class="fab fa-amazon" aria-hidden="true" title="<?php esc_attr_e('Amazon','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('meetuplink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('meetuplink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-meetup" aria-label="<?php esc_attr_e('Meetup Button','boldwp'); ?>"><i class="fab fa-meetup" aria-hidden="true" title="<?php esc_attr_e('Meetup','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('mixcloudlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('mixcloudlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-mixcloud" aria-label="<?php esc_attr_e('Mixcloud Button','boldwp'); ?>"><i class="fab fa-mixcloud" aria-hidden="true" title="<?php esc_attr_e('Mixcloud','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('slacklink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('slacklink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-slack" aria-label="<?php esc_attr_e('Slack Button','boldwp'); ?>"><i class="fab fa-slack" aria-hidden="true" title="<?php esc_attr_e('Slack','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('snapchatlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('snapchatlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-snapchat" aria-label="<?php esc_attr_e('Snapchat Button','boldwp'); ?>"><i class="fab fa-snapchat" aria-hidden="true" title="<?php esc_attr_e('Snapchat','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('spotifylink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('spotifylink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-spotify" aria-label="<?php esc_attr_e('Spotify Button','boldwp'); ?>"><i class="fab fa-spotify" aria-hidden="true" title="<?php esc_attr_e('Spotify','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('yelplink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('yelplink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-yelp" aria-label="<?php esc_attr_e('Yelp Button','boldwp'); ?>"><i class="fab fa-yelp" aria-hidden="true" title="<?php esc_attr_e('Yelp','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('wordpresslink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('wordpresslink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-wordpress" aria-label="<?php esc_attr_e('WordPress Button','boldwp'); ?>"><i class="fab fa-wordpress" aria-hidden="true" title="<?php esc_attr_e('WordPress','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('twitchlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('twitchlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-twitch" aria-label="<?php esc_attr_e('Twitch Button','boldwp'); ?>"><i class="fab fa-twitch" aria-hidden="true" title="<?php esc_attr_e('Twitch','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('telegramlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('telegramlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-telegram" aria-label="<?php esc_attr_e('Telegram Button','boldwp'); ?>"><i class="fab fa-telegram" aria-hidden="true" title="<?php esc_attr_e('Telegram','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('bandcamplink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('bandcamplink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-bandcamp" aria-label="<?php esc_attr_e('Bandcamp Button','boldwp'); ?>"><i class="fab fa-bandcamp" aria-hidden="true" title="<?php esc_attr_e('Bandcamp','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('quoralink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('quoralink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-quora" aria-label="<?php esc_attr_e('Quora Button','boldwp'); ?>"><i class="fab fa-quora" aria-hidden="true" title="<?php esc_attr_e('Quora','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('foursquarelink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('foursquarelink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-foursquare" aria-label="<?php esc_attr_e('Foursquare Button','boldwp'); ?>"><i class="fab fa-foursquare" aria-hidden="true" title="<?php esc_attr_e('Foursquare','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('deviantartlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('deviantartlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-deviantart" aria-label="<?php esc_attr_e('DeviantArt Button','boldwp'); ?>"><i class="fab fa-deviantart" aria-hidden="true" title="<?php esc_attr_e('DeviantArt','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('imdblink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('imdblink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-imdb" aria-label="<?php esc_attr_e('IMDB Button','boldwp'); ?>"><i class="fab fa-imdb" aria-hidden="true" title="<?php esc_attr_e('IMDB','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('vklink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('vklink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-vk" aria-label="<?php esc_attr_e('VK Button','boldwp'); ?>"><i class="fab fa-vk" aria-hidden="true" title="<?php esc_attr_e('VK','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('codepenlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('codepenlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-codepen" aria-label="<?php esc_attr_e('Codepen Button','boldwp'); ?>"><i class="fab fa-codepen" aria-hidden="true" title="<?php esc_attr_e('Codepen','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('jsfiddlelink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('jsfiddlelink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-jsfiddle" aria-label="<?php esc_attr_e('JSFiddle Button','boldwp'); ?>"><i class="fab fa-jsfiddle" aria-hidden="true" title="<?php esc_attr_e('JSFiddle','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('stackoverflowlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('stackoverflowlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-stackoverflow" aria-label="<?php esc_attr_e('Stack Overflow Button','boldwp'); ?>"><i class="fab fa-stack-overflow" aria-hidden="true" title="<?php esc_attr_e('Stack Overflow','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('stackexchangelink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('stackexchangelink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-stackexchange" aria-label="<?php esc_attr_e('Stack Exchange Button','boldwp'); ?>"><i class="fab fa-stack-exchange" aria-hidden="true" title="<?php esc_attr_e('Stack Exchange','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('bsalink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('bsalink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-buysellads" aria-label="<?php esc_attr_e('BuySellAds Button','boldwp'); ?>"><i class="fab fa-buysellads" aria-hidden="true" title="<?php esc_attr_e('BuySellAds','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('web500pxlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('web500pxlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-web500px" aria-label="<?php esc_attr_e('500px Button','boldwp'); ?>"><i class="fab fa-500px" aria-hidden="true" title="<?php esc_attr_e('500px','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('ellolink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('ellolink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-ello" aria-label="<?php esc_attr_e('Ello Button','boldwp'); ?>"><i class="fab fa-ello" aria-hidden="true" title="<?php esc_attr_e('Ello','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('goodreadslink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('goodreadslink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-goodreads" aria-label="<?php esc_attr_e('Goodreads Button','boldwp'); ?>"><i class="fab fa-goodreads" aria-hidden="true" title="<?php esc_attr_e('Goodreads','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('odnoklassnikilink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('odnoklassnikilink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-odnoklassniki" aria-label="<?php esc_attr_e('Odnoklassniki Button','boldwp'); ?>"><i class="fab fa-odnoklassniki" aria-hidden="true" title="<?php esc_attr_e('Odnoklassniki','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('houzzlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('houzzlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-houzz" aria-label="<?php esc_attr_e('Houzz Button','boldwp'); ?>"><i class="fab fa-houzz" aria-hidden="true" title="<?php esc_attr_e('Houzz','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('pocketlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('pocketlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-pocket" aria-label="<?php esc_attr_e('Pocket Button','boldwp'); ?>"><i class="fab fa-get-pocket" aria-hidden="true" title="<?php esc_attr_e('Pocket','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('xinglink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('xinglink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-xing" aria-label="<?php esc_attr_e('XING Button','boldwp'); ?>"><i class="fab fa-xing" aria-hidden="true" title="<?php esc_attr_e('XING','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('googleplaylink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('googleplaylink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-googleplay" aria-label="<?php esc_attr_e('Google Play Button','boldwp'); ?>"><i class="fab fa-google-play" aria-hidden="true" title="<?php esc_attr_e('Google Play','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('slidesharelink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('slidesharelink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-slideshare" aria-label="<?php esc_attr_e('SlideShare Button','boldwp'); ?>"><i class="fab fa-slideshare" aria-hidden="true" title="<?php esc_attr_e('SlideShare','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('dropboxlink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('dropboxlink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-dropbox" aria-label="<?php esc_attr_e('Dropbox Button','boldwp'); ?>"><i class="fab fa-dropbox" aria-hidden="true" title="<?php esc_attr_e('Dropbox','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('paypallink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('paypallink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-paypal" aria-label="<?php esc_attr_e('PayPal Button','boldwp'); ?>"><i class="fab fa-paypal" aria-hidden="true" title="<?php esc_attr_e('PayPal','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('viadeolink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('viadeolink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-viadeo" aria-label="<?php esc_attr_e('Viadeo Button','boldwp'); ?>"><i class="fab fa-viadeo" aria-hidden="true" title="<?php esc_attr_e('Viadeo','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('wikipedialink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('wikipedialink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-wikipedia" aria-label="<?php esc_attr_e('Wikipedia Button','boldwp'); ?>"><i class="fab fa-wikipedia-w" aria-hidden="true" title="<?php esc_attr_e('Wikipedia','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('skypeusername') ) : ?>
            <a href="skype:<?php echo esc_html( boldwp_get_option('skypeusername') ); ?>?chat" class="boldwp-social-icon-skype" aria-label="<?php esc_attr_e('Skype Button','boldwp'); ?>"><i class="fab fa-skype" aria-hidden="true" title="<?php esc_attr_e('Skype','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('emailaddress') ) : ?>
            <a href="mailto:<?php echo esc_html( boldwp_get_option('emailaddress') ); ?>" class="boldwp-social-icon-email" aria-label="<?php esc_attr_e('Email Us Button','boldwp'); ?>"><i class="far fa-envelope" aria-hidden="true" title="<?php esc_attr_e('Email Us','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('rsslink') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('rsslink') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-rss" aria-label="<?php esc_attr_e('RSS Button','boldwp'); ?>"><i class="fas fa-rss" aria-hidden="true" title="<?php esc_attr_e('RSS','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('show_header_login_button') ) { ?><?php if (is_user_logged_in()) : ?><a href="<?php echo esc_url( wp_logout_url( get_permalink() ) ); ?>" class="boldwp-social-icon-login" aria-label="<?php esc_attr_e( 'Logout Button', 'boldwp' ); ?>"><i class="fas fa-sign-out-alt" aria-hidden="true" title="<?php esc_attr_e( 'Logout Button', 'boldwp' ); ?>"></i></a><?php else : ?><a href="<?php echo esc_url( wp_login_url( get_permalink() ) ); ?>" class="boldwp-social-icon-login" aria-label="<?php esc_attr_e( 'Login / Register', 'boldwp' ); ?>"><i class="fas fa-sign-in-alt" aria-hidden="true" title="<?php esc_attr_e( 'Login / Register Button', 'boldwp' ); ?>"></i></a><?php endif;?><?php } ?>
    <?php if ( !(boldwp_get_option('hide_header_search_button')) ) { ?><a href="<?php echo esc_url( '#' ); ?>" class="boldwp-social-icon-search" aria-label="<?php esc_attr_e('Search Button','boldwp'); ?>"><i class="fas fa-search" aria-hidden="true" title="<?php esc_attr_e('Search','boldwp'); ?>"></i></a><?php } ?>
</div>

<?php }

function boldwp_footer_social_buttons() { ?>

<div class="boldwp-bottom-social-icons clearfix">
    <?php if ( boldwp_get_option('twitter_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('twitter_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-twitter" aria-label="<?php esc_attr_e('Twitter Button','boldwp'); ?>"><i class="fab fa-twitter" aria-hidden="true" title="<?php esc_attr_e('Twitter','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('facebook_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('facebook_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-facebook" aria-label="<?php esc_attr_e('Facebook Button','boldwp'); ?>"><i class="fab fa-facebook-f" aria-hidden="true" title="<?php esc_attr_e('Facebook','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('gplus_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('gplus_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-google-plus" aria-label="<?php esc_attr_e('Google Plus Button','boldwp'); ?>"><i class="fab fa-google-plus-g" aria-hidden="true" title="<?php esc_attr_e('Google Plus','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('pinterest_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('pinterest_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-pinterest" aria-label="<?php esc_attr_e('Pinterest Button','boldwp'); ?>"><i class="fab fa-pinterest" aria-hidden="true" title="<?php esc_attr_e('Pinterest','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('linkedin_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('linkedin_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-linkedin" aria-label="<?php esc_attr_e('Linkedin Button','boldwp'); ?>"><i class="fab fa-linkedin-in" aria-hidden="true" title="<?php esc_attr_e('Linkedin','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('instagram_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('instagram_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-instagram" aria-label="<?php esc_attr_e('Instagram Button','boldwp'); ?>"><i class="fab fa-instagram" aria-hidden="true" title="<?php esc_attr_e('Instagram','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('flickr_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('flickr_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-flickr" aria-label="<?php esc_attr_e('Flickr Button','boldwp'); ?>"><i class="fab fa-flickr" aria-hidden="true" title="<?php esc_attr_e('Flickr','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('youtube_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('youtube_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-youtube" aria-label="<?php esc_attr_e('Youtube Button','boldwp'); ?>"><i class="fab fa-youtube" aria-hidden="true" title="<?php esc_attr_e('Youtube','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('vimeo_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('vimeo_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-vimeo" aria-label="<?php esc_attr_e('Vimeo Button','boldwp'); ?>"><i class="fab fa-vimeo-v" aria-hidden="true" title="<?php esc_attr_e('Vimeo','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('soundcloud_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('soundcloud_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-soundcloud" aria-label="<?php esc_attr_e('SoundCloud Button','boldwp'); ?>"><i class="fab fa-soundcloud" aria-hidden="true" title="<?php esc_attr_e('SoundCloud','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('messenger_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('messenger_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-messenger" aria-label="<?php esc_attr_e('Messenger Button','boldwp'); ?>"><i class="fab fa-facebook-messenger" aria-hidden="true" title="<?php esc_attr_e('Messenger','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('lastfm_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('lastfm_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-lastfm" aria-label="<?php esc_attr_e('Lastfm Button','boldwp'); ?>"><i class="fab fa-lastfm" aria-hidden="true" title="<?php esc_attr_e('Lastfm','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('medium_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('medium_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-medium" aria-label="<?php esc_attr_e('Medium Button','boldwp'); ?>"><i class="fab fa-medium-m" aria-hidden="true" title="<?php esc_attr_e('Medium','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('github_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('github_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-github" aria-label="<?php esc_attr_e('Github Button','boldwp'); ?>"><i class="fab fa-github" aria-hidden="true" title="<?php esc_attr_e('Github','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('bitbucket_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('bitbucket_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-bitbucket" aria-label="<?php esc_attr_e('Bitbucket Button','boldwp'); ?>"><i class="fab fa-bitbucket" aria-hidden="true" title="<?php esc_attr_e('Bitbucket','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('tumblr_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('tumblr_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-tumblr" aria-label="<?php esc_attr_e('Tumblr Button','boldwp'); ?>"><i class="fab fa-tumblr" aria-hidden="true" title="<?php esc_attr_e('Tumblr','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('digg_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('digg_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-digg" aria-label="<?php esc_attr_e('Digg Button','boldwp'); ?>"><i class="fab fa-digg" aria-hidden="true" title="<?php esc_attr_e('Digg','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('delicious_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('delicious_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-delicious" aria-label="<?php esc_attr_e('Delicious Button','boldwp'); ?>"><i class="fab fa-delicious" aria-hidden="true" title="<?php esc_attr_e('Delicious','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('stumble_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('stumble_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-stumbleupon" aria-label="<?php esc_attr_e('Stumbleupon Button','boldwp'); ?>"><i class="fab fa-stumbleupon" aria-hidden="true" title="<?php esc_attr_e('Stumbleupon','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('mix_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('mix_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-mix" aria-label="<?php esc_attr_e('Mix Button','boldwp'); ?>"><i class="fab fa-mix" aria-hidden="true" title="<?php esc_attr_e('Mix','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('reddit_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('reddit_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-reddit" aria-label="<?php esc_attr_e('Reddit Button','boldwp'); ?>"><i class="fab fa-reddit" aria-hidden="true" title="<?php esc_attr_e('Reddit','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('dribbble_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('dribbble_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-dribbble" aria-label="<?php esc_attr_e('Dribbble Button','boldwp'); ?>"><i class="fab fa-dribbble" aria-hidden="true" title="<?php esc_attr_e('Dribbble','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('flipboard_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('flipboard_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-flipboard" aria-label="<?php esc_attr_e('Flipboard Button','boldwp'); ?>"><i class="fab fa-flipboard" aria-hidden="true" title="<?php esc_attr_e('Flipboard','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('blogger_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('blogger_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-blogger" aria-label="<?php esc_attr_e('Blogger Button','boldwp'); ?>"><i class="fab fa-blogger" aria-hidden="true" title="<?php esc_attr_e('Blogger','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('etsy_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('etsy_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-etsy" aria-label="<?php esc_attr_e('Etsy Button','boldwp'); ?>"><i class="fab fa-etsy" aria-hidden="true" title="<?php esc_attr_e('Etsy','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('behance_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('behance_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-behance" aria-label="<?php esc_attr_e('Behance Button','boldwp'); ?>"><i class="fab fa-behance" aria-hidden="true" title="<?php esc_attr_e('Behance','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('amazon_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('amazon_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-amazon" aria-label="<?php esc_attr_e('Amazon Button','boldwp'); ?>"><i class="fab fa-amazon" aria-hidden="true" title="<?php esc_attr_e('Amazon','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('meetup_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('meetup_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-meetup" aria-label="<?php esc_attr_e('Meetup Button','boldwp'); ?>"><i class="fab fa-meetup" aria-hidden="true" title="<?php esc_attr_e('Meetup','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('mixcloud_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('mixcloud_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-mixcloud" aria-label="<?php esc_attr_e('Mixcloud Button','boldwp'); ?>"><i class="fab fa-mixcloud" aria-hidden="true" title="<?php esc_attr_e('Mixcloud','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('slack_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('slack_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-slack" aria-label="<?php esc_attr_e('Slack Button','boldwp'); ?>"><i class="fab fa-slack" aria-hidden="true" title="<?php esc_attr_e('Slack','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('snapchat_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('snapchat_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-snapchat" aria-label="<?php esc_attr_e('Snapchat Button','boldwp'); ?>"><i class="fab fa-snapchat" aria-hidden="true" title="<?php esc_attr_e('Snapchat','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('spotify_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('spotify_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-spotify" aria-label="<?php esc_attr_e('Spotify Button','boldwp'); ?>"><i class="fab fa-spotify" aria-hidden="true" title="<?php esc_attr_e('Spotify','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('yelp_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('yelp_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-yelp" aria-label="<?php esc_attr_e('Yelp Button','boldwp'); ?>"><i class="fab fa-yelp" aria-hidden="true" title="<?php esc_attr_e('Yelp','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('wordpress_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('wordpress_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-wordpress" aria-label="<?php esc_attr_e('WordPress Button','boldwp'); ?>"><i class="fab fa-wordpress" aria-hidden="true" title="<?php esc_attr_e('WordPress','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('twitch_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('twitch_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-twitch" aria-label="<?php esc_attr_e('Twitch Button','boldwp'); ?>"><i class="fab fa-twitch" aria-hidden="true" title="<?php esc_attr_e('Twitch','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('telegram_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('telegram_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-telegram" aria-label="<?php esc_attr_e('Telegram Button','boldwp'); ?>"><i class="fab fa-telegram" aria-hidden="true" title="<?php esc_attr_e('Telegram','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('bandcamp_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('bandcamp_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-bandcamp" aria-label="<?php esc_attr_e('Bandcamp Button','boldwp'); ?>"><i class="fab fa-bandcamp" aria-hidden="true" title="<?php esc_attr_e('Bandcamp','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('quora_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('quora_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-quora" aria-label="<?php esc_attr_e('Quora Button','boldwp'); ?>"><i class="fab fa-quora" aria-hidden="true" title="<?php esc_attr_e('Quora','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('foursquare_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('foursquare_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-foursquare" aria-label="<?php esc_attr_e('Foursquare Button','boldwp'); ?>"><i class="fab fa-foursquare" aria-hidden="true" title="<?php esc_attr_e('Foursquare','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('deviantart_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('deviantart_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-deviantart" aria-label="<?php esc_attr_e('DeviantArt Button','boldwp'); ?>"><i class="fab fa-deviantart" aria-hidden="true" title="<?php esc_attr_e('DeviantArt','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('imdb_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('imdb_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-imdb" aria-label="<?php esc_attr_e('IMDB Button','boldwp'); ?>"><i class="fab fa-imdb" aria-hidden="true" title="<?php esc_attr_e('IMDB','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('vk_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('vk_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-vk" aria-label="<?php esc_attr_e('VK Button','boldwp'); ?>"><i class="fab fa-vk" aria-hidden="true" title="<?php esc_attr_e('VK','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('codepen_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('codepen_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-codepen" aria-label="<?php esc_attr_e('Codepen Button','boldwp'); ?>"><i class="fab fa-codepen" aria-hidden="true" title="<?php esc_attr_e('Codepen','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('jsfiddle_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('jsfiddle_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-jsfiddle" aria-label="<?php esc_attr_e('JSFiddle Button','boldwp'); ?>"><i class="fab fa-jsfiddle" aria-hidden="true" title="<?php esc_attr_e('JSFiddle','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('stackoverflow_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('stackoverflow_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-stackoverflow" aria-label="<?php esc_attr_e('Stack Overflow Button','boldwp'); ?>"><i class="fab fa-stack-overflow" aria-hidden="true" title="<?php esc_attr_e('Stack Overflow','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('stackexchange_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('stackexchange_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-stackexchange" aria-label="<?php esc_attr_e('Stack Exchange Button','boldwp'); ?>"><i class="fab fa-stack-exchange" aria-hidden="true" title="<?php esc_attr_e('Stack Exchange','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('bsa_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('bsa_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-buysellads" aria-label="<?php esc_attr_e('BuySellAds Button','boldwp'); ?>"><i class="fab fa-buysellads" aria-hidden="true" title="<?php esc_attr_e('BuySellAds','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('web500px_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('web500px_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-web500px" aria-label="<?php esc_attr_e('500px Button','boldwp'); ?>"><i class="fab fa-500px" aria-hidden="true" title="<?php esc_attr_e('500px','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('ello_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('ello_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-ello" aria-label="<?php esc_attr_e('Ello Button','boldwp'); ?>"><i class="fab fa-ello" aria-hidden="true" title="<?php esc_attr_e('Ello','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('goodreads_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('goodreads_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-goodreads" aria-label="<?php esc_attr_e('Goodreads Button','boldwp'); ?>"><i class="fab fa-goodreads" aria-hidden="true" title="<?php esc_attr_e('Goodreads','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('odnoklassniki_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('odnoklassniki_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-odnoklassniki" aria-label="<?php esc_attr_e('Odnoklassniki Button','boldwp'); ?>"><i class="fab fa-odnoklassniki" aria-hidden="true" title="<?php esc_attr_e('Odnoklassniki','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('houzz_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('houzz_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-houzz" aria-label="<?php esc_attr_e('Houzz Button','boldwp'); ?>"><i class="fab fa-houzz" aria-hidden="true" title="<?php esc_attr_e('Houzz','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('pocket_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('pocket_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-pocket" aria-label="<?php esc_attr_e('Pocket Button','boldwp'); ?>"><i class="fab fa-get-pocket" aria-hidden="true" title="<?php esc_attr_e('Pocket','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('xing_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('xing_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-xing" aria-label="<?php esc_attr_e('XING Button','boldwp'); ?>"><i class="fab fa-xing" aria-hidden="true" title="<?php esc_attr_e('XING','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('googleplay_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('googleplay_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-googleplay" aria-label="<?php esc_attr_e('Google Play Button','boldwp'); ?>"><i class="fab fa-google-play" aria-hidden="true" title="<?php esc_attr_e('Google Play','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('slideshare_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('slideshare_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-slideshare" aria-label="<?php esc_attr_e('SlideShare Button','boldwp'); ?>"><i class="fab fa-slideshare" aria-hidden="true" title="<?php esc_attr_e('SlideShare','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('dropbox_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('dropbox_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-dropbox" aria-label="<?php esc_attr_e('Dropbox Button','boldwp'); ?>"><i class="fab fa-dropbox" aria-hidden="true" title="<?php esc_attr_e('Dropbox','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('paypal_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('paypal_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-paypal" aria-label="<?php esc_attr_e('PayPal Button','boldwp'); ?>"><i class="fab fa-paypal" aria-hidden="true" title="<?php esc_attr_e('PayPal','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('viadeo_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('viadeo_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-viadeo" aria-label="<?php esc_attr_e('Viadeo Button','boldwp'); ?>"><i class="fab fa-viadeo" aria-hidden="true" title="<?php esc_attr_e('Viadeo','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('wikipedia_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('wikipedia_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-wikipedia" aria-label="<?php esc_attr_e('Wikipedia Button','boldwp'); ?>"><i class="fab fa-wikipedia-w" aria-hidden="true" title="<?php esc_attr_e('Wikipedia','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('skype_button') ) : ?>
            <a href="skype:<?php echo esc_html( boldwp_get_option('skype_button') ); ?>?chat" class="boldwp-social-icon-skype" aria-label="<?php esc_attr_e('Skype Button','boldwp'); ?>"><i class="fab fa-skype" aria-hidden="true" title="<?php esc_attr_e('Skype','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('email_button') ) : ?>
            <a href="mailto:<?php echo esc_html( boldwp_get_option('email_button') ); ?>" class="boldwp-social-icon-email" aria-label="<?php esc_attr_e('Email Us Button','boldwp'); ?>"><i class="far fa-envelope" aria-hidden="true" title="<?php esc_attr_e('Email Us','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('rss_button') ) : ?>
            <a href="<?php echo esc_url( boldwp_get_option('rss_button') ); ?>" target="_blank" rel="nofollow" class="boldwp-social-icon-rss" aria-label="<?php esc_attr_e('RSS Button','boldwp'); ?>"><i class="fas fa-rss" aria-hidden="true" title="<?php esc_attr_e('RSS','boldwp'); ?>"></i></a><?php endif; ?>
    <?php if ( boldwp_get_option('show_footer_login_button') ) { ?><?php if (is_user_logged_in()) : ?><a href="<?php echo esc_url( wp_logout_url( get_permalink() ) ); ?>" aria-label="<?php esc_attr_e( 'Logout Button', 'boldwp' ); ?>" class="boldwp-social-icon-login"><i class="fas fa-sign-out-alt" aria-hidden="true" title="<?php esc_attr_e('Logout','boldwp'); ?>"></i></a><?php else : ?><a href="<?php echo esc_url( wp_login_url( get_permalink() ) ); ?>" aria-label="<?php esc_attr_e( 'Login / Register Button', 'boldwp' ); ?>" class="boldwp-social-icon-login"><i class="fas fa-sign-in-alt" aria-hidden="true" title="<?php esc_attr_e('Login / Register','boldwp'); ?>"></i></a><?php endif;?><?php } ?>
    <?php if ( !(boldwp_get_option('hide_footer_search_button')) ) { ?><a href="<?php echo esc_url( '#' ); ?>" aria-label="<?php esc_attr_e('Search Button','boldwp'); ?>" class="boldwp-social-icon-search"><i class="fas fa-search" aria-hidden="true" title="<?php esc_attr_e('Search','boldwp'); ?>"></i></a><?php } ?>
</div>

<?php }