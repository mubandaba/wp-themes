<?php
/**
* Posts navigation functions
*
* @package BoldWP WordPress Theme
* @copyright Copyright (C) 2020 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

if ( ! function_exists( 'boldwp_wp_pagenavi' ) ) :
function boldwp_wp_pagenavi() {
    ?>
    <nav class="navigation posts-navigation clearfix" role="navigation">
        <?php wp_pagenavi(); ?>
    </nav><!-- .navigation -->
    <?php
}
endif;

if ( ! function_exists( 'boldwp_posts_navigation' ) ) :
function boldwp_posts_navigation() {
    if ( !(boldwp_get_option('hide_posts_navigation')) ) {
        if ( function_exists( 'wp_pagenavi' ) ) {
            boldwp_wp_pagenavi();
        } else {
            if ( boldwp_get_option('posts_navigation_type') === 'normalnavi' ) {
                the_posts_navigation(array('prev_text' => esc_html__( 'Older posts', 'boldwp' ), 'next_text' => esc_html__( 'Newer posts', 'boldwp' )));
            } else {
                the_posts_pagination(array('mid_size' => 2, 'prev_text' => esc_html__( '&larr; Newer posts', 'boldwp' ), 'next_text' => esc_html__( 'Older posts &rarr;', 'boldwp' )));
            }
        }
    }
}
endif;

if ( ! function_exists( 'boldwp_post_navigation' ) ) :
function boldwp_post_navigation() {
    if ( !(boldwp_get_option('hide_post_navigation')) ) {
        the_post_navigation(array('prev_text' => esc_html__( '%title &rarr;', 'boldwp' ), 'next_text' => esc_html__( '&larr; %title', 'boldwp' )));
    }
}
endif;