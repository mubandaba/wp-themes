<?php
/**
* Custom Hooks
*
* @package BoldWP WordPress Theme
* @copyright Copyright (C) 2020 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

function boldwp_before_header() {
    do_action('boldwp_before_header');
}

function boldwp_after_header() {
    do_action('boldwp_after_header');
}

function boldwp_before_main_content() {
    do_action('boldwp_before_main_content');
}
add_action('boldwp_before_main_content', 'boldwp_top_widgets', 20 );

function boldwp_after_main_content() {
    do_action('boldwp_after_main_content');
}
add_action('boldwp_after_main_content', 'boldwp_bottom_widgets', 10 );

function boldwp_sidebar_one() {
    do_action('boldwp_sidebar_one');
}
add_action('boldwp_sidebar_one', 'boldwp_sidebar_one_widgets', 10 );

function boldwp_before_single_post() {
    do_action('boldwp_before_single_post');
}

function boldwp_before_single_post_title() {
    do_action('boldwp_before_single_post_title');
}

function boldwp_after_single_post_title() {
    do_action('boldwp_after_single_post_title');
}

function boldwp_after_single_post_content() {
    do_action('boldwp_after_single_post_content');
}

function boldwp_after_single_post() {
    do_action('boldwp_after_single_post');
}

function boldwp_before_single_page() {
    do_action('boldwp_before_single_page');
}

function boldwp_before_single_page_title() {
    do_action('boldwp_before_single_page_title');
}

function boldwp_after_single_page_title() {
    do_action('boldwp_after_single_page_title');
}

function boldwp_after_single_page_content() {
    do_action('boldwp_after_single_page_content');
}

function boldwp_after_single_page() {
    do_action('boldwp_after_single_page');
}

function boldwp_before_comments() {
    do_action('boldwp_before_comments');
}

function boldwp_after_comments() {
    do_action('boldwp_after_comments');
}

function boldwp_before_footer() {
    do_action('boldwp_before_footer');
}

function boldwp_after_footer() {
    do_action('boldwp_after_footer');
}