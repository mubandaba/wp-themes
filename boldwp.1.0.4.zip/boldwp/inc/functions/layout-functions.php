<?php
/**
* Layout Functions
*
* @package BoldWP WordPress Theme
* @copyright Copyright (C) 2020 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

function boldwp_post_style() {
    $post_style = 'style-5';
    if ( boldwp_get_option('post_style') ) {
        $post_style = boldwp_get_option('post_style');
    }
    return apply_filters( 'boldwp_post_style', $post_style );
}

function boldwp_hide_footer_widgets() {
    $hide_footer_widgets = FALSE;
    if ( boldwp_get_option('hide_footer_widgets') ) {
        $hide_footer_widgets = TRUE;
    }
    return apply_filters( 'boldwp_hide_footer_widgets', $hide_footer_widgets );
}