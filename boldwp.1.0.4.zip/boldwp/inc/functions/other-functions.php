<?php
/**
* More Custom Functions
*
* @package BoldWP WordPress Theme
* @copyright Copyright (C) 2020 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

function boldwp_read_more_text() {
    $readmoretext = esc_html__( 'Continue Reading', 'boldwp' );
    if ( boldwp_get_option('read_more_text') ) {
            $readmoretext = boldwp_get_option('read_more_text');
    }
    return $readmoretext;
}

// Change excerpt length
function boldwp_excerpt_length($length) {
    if ( is_admin() ) {
        return $length;
    }
    $read_more_length = 25;
    if ( boldwp_get_option('read_more_length') ) {
        $read_more_length = boldwp_get_option('read_more_length');
    }
    return $read_more_length;
}
add_filter('excerpt_length', 'boldwp_excerpt_length');

// Change excerpt more word
function boldwp_excerpt_more($more) {
    if ( is_admin() ) {
        return $more;
    }
    return '...';
}
add_filter('excerpt_more', 'boldwp_excerpt_more');

if ( ! function_exists( 'wp_body_open' ) ) :
    /**
     * Fire the wp_body_open action.
     *
     * Added for backwards compatibility to support pre 5.2.0 WordPress versions.
     */
    function wp_body_open() { // phpcs:ignore WPThemeReview.CoreFunctionality.PrefixAllGlobals.NonPrefixedFunctionFound
        /**
         * Triggered after the opening <body> tag.
         */
        do_action( 'wp_body_open' ); // phpcs:ignore WPThemeReview.CoreFunctionality.PrefixAllGlobals.NonPrefixedHooknameFound
    }
endif;