<?php
/**
* Menu options
*
* @package BoldWP WordPress Theme
* @copyright Copyright (C) 2020 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

function boldwp_menu_options($wp_customize) {

    $wp_customize->add_section( 'boldwp_section_menu_options', array( 'title' => esc_html__( 'Menu Options', 'boldwp' ), 'panel' => 'boldwp_main_options_panel', 'priority' => 100 ) );

    $wp_customize->add_setting( 'boldwp_options[disable_primary_menu]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_checkbox', ) );

    $wp_customize->add_control( 'boldwp_disable_primary_menu_control', array( 'label' => esc_html__( 'Disable Primary Menu', 'boldwp' ), 'section' => 'boldwp_section_menu_options', 'settings' => 'boldwp_options[disable_primary_menu]', 'type' => 'checkbox', ) );

    $wp_customize->add_setting( 'boldwp_options[enable_sticky_mobile_menu]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_checkbox', ) );

    $wp_customize->add_control( 'boldwp_enable_sticky_mobile_menu_control', array( 'label' => esc_html__( 'Enable Sticky Primary Menu on Small Screen', 'boldwp' ), 'section' => 'boldwp_section_menu_options', 'settings' => 'boldwp_options[enable_sticky_mobile_menu]', 'type' => 'checkbox', ) );

    $wp_customize->add_setting( 'boldwp_options[disable_secondary_menu]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_checkbox', ) );

    $wp_customize->add_control( 'boldwp_disable_secondary_menu_control', array( 'label' => esc_html__( 'Disable Secondary Menu', 'boldwp' ), 'section' => 'boldwp_section_menu_options', 'settings' => 'boldwp_options[disable_secondary_menu]', 'type' => 'checkbox', ) );

}