<?php
/**
* Post Summaries options
*
* @package BoldWP WordPress Theme
* @copyright Copyright (C) 2020 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

function boldwp_post_summaries_options($wp_customize) {

    $wp_customize->add_section( 'boldwp_section_posts_summaries', array( 'title' => esc_html__( 'Post Summaries Options', 'boldwp' ), 'panel' => 'boldwp_main_options_panel', 'priority' => 175 ) );

    $wp_customize->add_setting( 'boldwp_options[hide_posts_heading]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_checkbox', ) );

    $wp_customize->add_control( 'boldwp_hide_posts_heading_control', array( 'label' => esc_html__( 'Hide HomePage Posts Heading', 'boldwp' ), 'section' => 'boldwp_section_posts_summaries', 'settings' => 'boldwp_options[hide_posts_heading]', 'type' => 'checkbox', ) );

    $wp_customize->add_setting( 'boldwp_options[posts_heading]', array( 'default' => esc_html__( 'Recent Posts', 'boldwp' ), 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'sanitize_text_field', ) );

    $wp_customize->add_control( 'boldwp_posts_heading_control', array( 'label' => esc_html__( 'HomePage Posts Heading', 'boldwp' ), 'section' => 'boldwp_section_posts_summaries', 'settings' => 'boldwp_options[posts_heading]', 'type' => 'text', ) );

    $wp_customize->add_setting( 'boldwp_options[post_style]', array( 'default' => 'style-5', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_post_style' ) );

    $wp_customize->add_control( 'boldwp_post_style_control', array( 'label' => esc_html__( 'Posts Style', 'boldwp' ), 'description' => esc_html__('Select the post style you want for home/categories/tags/archive/search-results pages.', 'boldwp'), 'section' => 'boldwp_section_posts_summaries', 'settings' => 'boldwp_options[post_style]', 'type' => 'select', 'choices' => array( 'style-4' => esc_html__('Style 4', 'boldwp'), 'style-5' => esc_html__('Style 5', 'boldwp'), 'style-9' => esc_html__('Style 9', 'boldwp') ) ) );

    $wp_customize->add_setting( 'boldwp_options[read_more_length]', array( 'default' => 25, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_read_more_length' ) );

    $wp_customize->add_control( 'boldwp_read_more_length_control', array( 'label' => esc_html__( 'Auto Post Summary Length', 'boldwp' ), 'description' => esc_html__('Enter the number of words need to display in the post summary. Default is 25 words.', 'boldwp'), 'section' => 'boldwp_section_posts_summaries', 'settings' => 'boldwp_options[read_more_length]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[read_more_text]', array( 'default' => esc_html__( 'Continue Reading', 'boldwp' ), 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'sanitize_text_field', ) );

    $wp_customize->add_control( 'boldwp_read_more_text_control', array( 'label' => esc_html__( 'Read More Text', 'boldwp' ), 'section' => 'boldwp_section_posts_summaries', 'settings' => 'boldwp_options[read_more_text]', 'type' => 'text', ) );

    $wp_customize->add_setting( 'boldwp_options[hide_thumbnail_home]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_checkbox', ) );

    $wp_customize->add_control( 'boldwp_hide_thumbnail_home_control', array( 'label' => esc_html__( 'Hide Featured Images from Main Posts Summaries', 'boldwp' ), 'section' => 'boldwp_section_posts_summaries', 'settings' => 'boldwp_options[hide_thumbnail_home]', 'type' => 'checkbox', ) );

    $wp_customize->add_setting( 'boldwp_options[hide_default_thumbnail_home]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_checkbox', ) );

    $wp_customize->add_control( 'boldwp_hide_default_thumbnail_home_control', array( 'label' => esc_html__( 'Hide Default Images from Posts Summaries', 'boldwp' ), 'section' => 'boldwp_section_posts_summaries', 'settings' => 'boldwp_options[hide_default_thumbnail_home]', 'type' => 'checkbox', ) );

    $wp_customize->add_setting( 'boldwp_options[hide_post_title_home]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_checkbox', ) );

    $wp_customize->add_control( 'boldwp_hide_post_title_home_control', array( 'label' => esc_html__( 'Hide Post Title from Main Posts Summaries', 'boldwp' ), 'section' => 'boldwp_section_posts_summaries', 'settings' => 'boldwp_options[hide_post_title_home]', 'type' => 'checkbox', ) );

    $wp_customize->add_setting( 'boldwp_options[hide_post_author_home]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_checkbox', ) );

    $wp_customize->add_control( 'boldwp_hide_post_author_home_control', array( 'label' => esc_html__( 'Hide Post Authors from Main Posts Summaries', 'boldwp' ), 'section' => 'boldwp_section_posts_summaries', 'settings' => 'boldwp_options[hide_post_author_home]', 'type' => 'checkbox', ) );

    $wp_customize->add_setting( 'boldwp_options[hide_posted_date_home]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_checkbox', ) );

    $wp_customize->add_control( 'boldwp_hide_posted_date_home_control', array( 'label' => esc_html__( 'Hide Posted Dates from Main Posts Summaries', 'boldwp' ), 'section' => 'boldwp_section_posts_summaries', 'settings' => 'boldwp_options[hide_posted_date_home]', 'type' => 'checkbox', ) );

    $wp_customize->add_setting( 'boldwp_options[hide_comments_link_home]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_checkbox', ) );

    $wp_customize->add_control( 'boldwp_hide_comments_link_home_control', array( 'label' => esc_html__( 'Hide Comment Links from Main Posts Summaries', 'boldwp' ), 'section' => 'boldwp_section_posts_summaries', 'settings' => 'boldwp_options[hide_comments_link_home]', 'type' => 'checkbox', ) );

    $wp_customize->add_setting( 'boldwp_options[hide_post_categories_home]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_checkbox', ) );

    $wp_customize->add_control( 'boldwp_hide_post_categories_home_control', array( 'label' => esc_html__( 'Hide Post Categories from Main Posts Summaries', 'boldwp' ), 'section' => 'boldwp_section_posts_summaries', 'settings' => 'boldwp_options[hide_post_categories_home]', 'type' => 'checkbox', ) );

    $wp_customize->add_setting( 'boldwp_options[hide_post_tags_home]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_checkbox', ) );

    $wp_customize->add_control( 'boldwp_hide_post_tags_home_control', array( 'label' => esc_html__( 'Hide Post Tags from Posts Summaries', 'boldwp' ), 'description' => esc_html__('This option is only for these post styles : 9', 'boldwp'), 'section' => 'boldwp_section_posts_summaries', 'settings' => 'boldwp_options[hide_post_tags_home]', 'type' => 'checkbox', ) );

    $wp_customize->add_setting( 'boldwp_options[hide_post_snippet]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_checkbox', ) );

    $wp_customize->add_control( 'boldwp_hide_post_snippet_control', array( 'label' => esc_html__( 'Hide Post Snippets from Main Posts Summaries', 'boldwp' ), 'section' => 'boldwp_section_posts_summaries', 'settings' => 'boldwp_options[hide_post_snippet]', 'type' => 'checkbox', ) );

    $wp_customize->add_setting( 'boldwp_options[hide_read_more_button]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_checkbox', ) );

    $wp_customize->add_control( 'boldwp_hide_read_more_button_control', array( 'label' => esc_html__( 'Hide Read More Buttons from Main Posts Summaries', 'boldwp' ), 'section' => 'boldwp_section_posts_summaries', 'settings' => 'boldwp_options[hide_read_more_button]', 'type' => 'checkbox', ) );

    /* Post Style 9 */
    $wp_customize->add_setting( 'boldwp_options[display_full_post_content]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_checkbox', ) );

    $wp_customize->add_control( 'boldwp_display_full_post_content_control', array( 'label' => esc_html__( 'Display Full Post Content with Posts Style 9', 'boldwp' ), 'section' => 'boldwp_section_posts_summaries', 'settings' => 'boldwp_options[display_full_post_content]', 'type' => 'checkbox', ) );

}