<?php
/**
* Navigation options
*
* @package BoldWP WordPress Theme
* @copyright Copyright (C) 2020 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

function boldwp_navigation_options($wp_customize) {

    $wp_customize->add_section( 'boldwp_section_navigation', array( 'title' => esc_html__( 'Post/Posts Navigation Options', 'boldwp' ), 'panel' => 'boldwp_main_options_panel', 'priority' => 185 ) );

    $wp_customize->add_setting( 'boldwp_options[hide_post_navigation]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_checkbox', ) );

    $wp_customize->add_control( 'boldwp_hide_post_navigation_control', array( 'label' => esc_html__( 'Hide Post Navigation from Full Posts', 'boldwp' ), 'section' => 'boldwp_section_navigation', 'settings' => 'boldwp_options[hide_post_navigation]', 'type' => 'checkbox', ) );

    $wp_customize->add_setting( 'boldwp_options[hide_posts_navigation]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_checkbox', ) );

    $wp_customize->add_control( 'boldwp_hide_posts_navigation_control', array( 'label' => esc_html__( 'Hide Posts Navigation from Home/Archive/Search Pages', 'boldwp' ), 'section' => 'boldwp_section_navigation', 'settings' => 'boldwp_options[hide_posts_navigation]', 'type' => 'checkbox', ) );

    $wp_customize->add_setting( 'boldwp_options[posts_navigation_type]', array( 'default' => 'numberednavi', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_posts_navigation_type' ) );

    $wp_customize->add_control( 'boldwp_posts_navigation_type_control', array( 'label' => esc_html__( 'Posts Navigation Type', 'boldwp' ), 'description' => esc_html__('Select posts navigation type you need. If you activate WP-PageNavi plugin, this navigation will be replaced by WP-PageNavi navigation.', 'boldwp'), 'section' => 'boldwp_section_navigation', 'settings' => 'boldwp_options[posts_navigation_type]', 'type' => 'select', 'choices' => array( 'normalnavi' => esc_html__('Link Navigation', 'boldwp'), 'numberednavi' => esc_html__('Numbered Navigation', 'boldwp') ) ) );

}