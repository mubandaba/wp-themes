<?php
/**
* Social profiles options
*
* @package BoldWP WordPress Theme
* @copyright Copyright (C) 2020 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

function boldwp_header_social_profiles($wp_customize) {

    $wp_customize->add_section( 'boldwp_section_social_header', array( 'title' => esc_html__( 'Header Social Buttons', 'boldwp' ), 'panel' => 'boldwp_main_options_panel', 'priority' => 240, ));

    $wp_customize->add_setting( 'boldwp_options[hide_header_social_buttons]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_checkbox', ) );

    $wp_customize->add_control( 'boldwp_hide_header_social_buttons_control', array( 'label' => esc_html__( 'Hide Header Social + Search + Login/Logout Buttons', 'boldwp' ), 'description' => esc_html__('If you checked this option, all buttons will disappear from header. There is no any effect from "Hide Search Button from Header" and "Show Login/Logout Button from Header" options.', 'boldwp'), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[hide_header_social_buttons]', 'type' => 'checkbox', ) );

    $wp_customize->add_setting( 'boldwp_options[hide_header_search_button]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_checkbox', ) );

    $wp_customize->add_control( 'boldwp_hide_header_search_button_control', array( 'label' => esc_html__( 'Hide Search Button from Header', 'boldwp' ), 'description' => esc_html__('This option has no effect if you checked the option: "Hide Header Social + Search + Login/Logout Buttons"', 'boldwp'), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[hide_header_search_button]', 'type' => 'checkbox', ) );

    $wp_customize->add_setting( 'boldwp_options[show_header_login_button]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_checkbox', ) );

    $wp_customize->add_control( 'boldwp_show_header_login_button_control', array( 'label' => esc_html__( 'Show Login/Logout Button from Header', 'boldwp' ), 'description' => esc_html__('This option has no effect if you checked the option: "Hide Header Social + Search + Login/Logout Buttons"', 'boldwp'), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[show_header_login_button]', 'type' => 'checkbox', ) );

    $wp_customize->add_setting( 'boldwp_options[twitterlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_twitterlink_control', array( 'label' => esc_html__( 'Twitter URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[twitterlink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[facebooklink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_facebooklink_control', array( 'label' => esc_html__( 'Facebook URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[facebooklink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[googlelink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) ); 

    $wp_customize->add_control( 'boldwp_googlelink_control', array( 'label' => esc_html__( 'Google Plus URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[googlelink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[pinterestlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_pinterestlink_control', array( 'label' => esc_html__( 'Pinterest URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[pinterestlink]', 'type' => 'text' ) );
    
    $wp_customize->add_setting( 'boldwp_options[linkedinlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_linkedinlink_control', array( 'label' => esc_html__( 'Linkedin Link', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[linkedinlink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[instagramlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_instagramlink_control', array( 'label' => esc_html__( 'Instagram Link', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[instagramlink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[vklink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_vklink_control', array( 'label' => esc_html__( 'VK Link', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[vklink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[flickrlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_flickrlink_control', array( 'label' => esc_html__( 'Flickr Link', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[flickrlink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[youtubelink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_youtubelink_control', array( 'label' => esc_html__( 'Youtube URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[youtubelink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[vimeolink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_vimeolink_control', array( 'label' => esc_html__( 'Vimeo URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[vimeolink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[soundcloudlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_soundcloudlink_control', array( 'label' => esc_html__( 'Soundcloud URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[soundcloudlink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[messengerlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_messengerlink_control', array( 'label' => esc_html__( 'Messenger URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[messengerlink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[lastfmlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_lastfmlink_control', array( 'label' => esc_html__( 'Lastfm URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[lastfmlink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[mediumlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_mediumlink_control', array( 'label' => esc_html__( 'Medium URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[mediumlink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[githublink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_githublink_control', array( 'label' => esc_html__( 'Github URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[githublink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[bitbucketlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_bitbucketlink_control', array( 'label' => esc_html__( 'Bitbucket URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[bitbucketlink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[tumblrlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_tumblrlink_control', array( 'label' => esc_html__( 'Tumblr URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[tumblrlink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[digglink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_digglink_control', array( 'label' => esc_html__( 'Digg URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[digglink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[deliciouslink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_deliciouslink_control', array( 'label' => esc_html__( 'Delicious URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[deliciouslink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[stumblelink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_stumblelink_control', array( 'label' => esc_html__( 'Stumbleupon URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[stumblelink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[mixlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_mixlink_control', array( 'label' => esc_html__( 'Mix URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[mixlink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[redditlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_redditlink_control', array( 'label' => esc_html__( 'Reddit URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[redditlink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[dribbblelink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_dribbblelink_control', array( 'label' => esc_html__( 'Dribbble URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[dribbblelink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[flipboardlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_flipboardlink_control', array( 'label' => esc_html__( 'Flipboard URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[flipboardlink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[bloggerlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_bloggerlink_control', array( 'label' => esc_html__( 'Blogger URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[bloggerlink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[etsylink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_etsylink_control', array( 'label' => esc_html__( 'Etsy URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[etsylink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[behancelink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_behancelink_control', array( 'label' => esc_html__( 'Behance URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[behancelink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[amazonlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_amazonlink_control', array( 'label' => esc_html__( 'Amazon URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[amazonlink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[meetuplink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_meetuplink_control', array( 'label' => esc_html__( 'Meetup URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[meetuplink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[mixcloudlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_mixcloudlink_control', array( 'label' => esc_html__( 'Mixcloud URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[mixcloudlink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[slacklink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_slacklink_control', array( 'label' => esc_html__( 'Slack URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[slacklink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[snapchatlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_snapchatlink_control', array( 'label' => esc_html__( 'Snapchat URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[snapchatlink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[spotifylink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_spotifylink_control', array( 'label' => esc_html__( 'Spotify URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[spotifylink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[yelplink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_yelplink_control', array( 'label' => esc_html__( 'Yelp URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[yelplink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[wordpresslink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_wordpresslink_control', array( 'label' => esc_html__( 'WordPress URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[wordpresslink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[twitchlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_twitchlink_control', array( 'label' => esc_html__( 'Twitch URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[twitchlink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[telegramlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_telegramlink_control', array( 'label' => esc_html__( 'Telegram URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[telegramlink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[bandcamplink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_bandcamplink_control', array( 'label' => esc_html__( 'Bandcamp URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[bandcamplink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[quoralink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_quoralink_control', array( 'label' => esc_html__( 'Quora URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[quoralink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[foursquarelink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_foursquarelink_control', array( 'label' => esc_html__( 'Foursquare URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[foursquarelink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[deviantartlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_deviantartlink_control', array( 'label' => esc_html__( 'DeviantArt URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[deviantartlink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[imdblink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_imdblink_control', array( 'label' => esc_html__( 'IMDB URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[imdblink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[codepenlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_codepenlink_control', array( 'label' => esc_html__( 'Codepen URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[codepenlink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[jsfiddlelink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_jsfiddlelink_control', array( 'label' => esc_html__( 'JSFiddle URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[jsfiddlelink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[stackoverflowlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_stackoverflowlink_control', array( 'label' => esc_html__( 'Stack Overflow URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[stackoverflowlink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[stackexchangelink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_stackexchangelink_control', array( 'label' => esc_html__( 'Stack Exchange URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[stackexchangelink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[bsalink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_bsalink_control', array( 'label' => esc_html__( 'BuySellAds URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[bsalink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[web500pxlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_web500pxlink_control', array( 'label' => esc_html__( '500px URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[web500pxlink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[ellolink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_ellolink_control', array( 'label' => esc_html__( 'Ello URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[ellolink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[goodreadslink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_goodreadslink_control', array( 'label' => esc_html__( 'Goodreads URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[goodreadslink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[odnoklassnikilink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_odnoklassnikilink_control', array( 'label' => esc_html__( 'Odnoklassniki URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[odnoklassnikilink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[houzzlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_houzzlink_control', array( 'label' => esc_html__( 'Houzz URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[houzzlink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[pocketlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_pocketlink_control', array( 'label' => esc_html__( 'Pocket URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[pocketlink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[xinglink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_xinglink_control', array( 'label' => esc_html__( 'XING URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[xinglink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[googleplaylink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_googleplaylink_control', array( 'label' => esc_html__( 'Google Play URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[googleplaylink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[slidesharelink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_slidesharelink_control', array( 'label' => esc_html__( 'SlideShare URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[slidesharelink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[dropboxlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_dropboxlink_control', array( 'label' => esc_html__( 'Dropbox URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[dropboxlink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[paypallink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_paypallink_control', array( 'label' => esc_html__( 'PayPal URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[paypallink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[viadeolink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_viadeolink_control', array( 'label' => esc_html__( 'Viadeo URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[viadeolink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[wikipedialink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_wikipedialink_control', array( 'label' => esc_html__( 'Wikipedia URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[wikipedialink]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[skypeusername]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'sanitize_text_field' ) );

    $wp_customize->add_control( 'boldwp_skypeusername_control', array( 'label' => esc_html__( 'Skype Username', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[skypeusername]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[emailaddress]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_email' ) );

    $wp_customize->add_control( 'boldwp_emailaddress_control', array( 'label' => esc_html__( 'Email Address', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[emailaddress]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[rsslink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_rsslink_control', array( 'label' => esc_html__( 'RSS Feed URL', 'boldwp' ), 'section' => 'boldwp_section_social_header', 'settings' => 'boldwp_options[rsslink]', 'type' => 'text' ) );

}


function boldwp_footer_social_profiles($wp_customize) {

    $wp_customize->add_section( 'boldwp_section_social_footer', array( 'title' => esc_html__( 'Footer Social Buttons', 'boldwp' ), 'panel' => 'boldwp_main_options_panel', 'priority' => 240, ));

    $wp_customize->add_setting( 'boldwp_options[hide_footer_social_buttons]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_checkbox', ) );

    $wp_customize->add_control( 'boldwp_hide_footer_social_buttons_control', array( 'label' => esc_html__( 'Hide Footer Social + Search + Login/Logout Buttons', 'boldwp' ), 'description' => esc_html__('If you checked this option, all buttons will disappear from footer. There is no any effect from "Hide Search Button from Footer" and "Show Login/Logout Button in Footer" options.', 'boldwp'), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[hide_footer_social_buttons]', 'type' => 'checkbox', ) );

    $wp_customize->add_setting( 'boldwp_options[hide_footer_search_button]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_checkbox', ) );

    $wp_customize->add_control( 'boldwp_hide_footer_search_button_control', array( 'label' => esc_html__( 'Hide Search Button from Footer', 'boldwp' ), 'description' => esc_html__('This option has no effect if you checked the option: "Hide Footer Social + Search + Login/Logout Buttons"', 'boldwp'), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[hide_footer_search_button]', 'type' => 'checkbox', ) );

    $wp_customize->add_setting( 'boldwp_options[show_footer_login_button]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_checkbox', ) );

    $wp_customize->add_control( 'boldwp_show_footer_login_button_control', array( 'label' => esc_html__( 'Show Login/Logout Button in Footer', 'boldwp' ), 'description' => esc_html__('This option has no effect if you checked the option: "Hide Footer Social + Search + Login/Logout Buttons"', 'boldwp'), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[show_footer_login_button]', 'type' => 'checkbox', ) );

    $wp_customize->add_setting( 'boldwp_options[twitter_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_twitter_button_control', array( 'label' => esc_html__( 'Twitter URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[twitter_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[facebook_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_facebook_button_control', array( 'label' => esc_html__( 'Facebook URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[facebook_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[gplus_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) ); 

    $wp_customize->add_control( 'boldwp_gplus_button_control', array( 'label' => esc_html__( 'Google Plus URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[gplus_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[pinterest_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_pinterest_button_control', array( 'label' => esc_html__( 'Pinterest URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[pinterest_button]', 'type' => 'text' ) );
    
    $wp_customize->add_setting( 'boldwp_options[linkedin_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_linkedin_button_control', array( 'label' => esc_html__( 'Linkedin Link', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[linkedin_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[instagram_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_instagram_button_control', array( 'label' => esc_html__( 'Instagram Link', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[instagram_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[vk_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_vk_button_control', array( 'label' => esc_html__( 'VK Link', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[vk_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[flickr_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_flickr_button_control', array( 'label' => esc_html__( 'Flickr Link', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[flickr_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[youtube_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_youtube_button_control', array( 'label' => esc_html__( 'Youtube URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[youtube_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[vimeo_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_vimeo_button_control', array( 'label' => esc_html__( 'Vimeo URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[vimeo_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[soundcloud_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_soundcloud_button_control', array( 'label' => esc_html__( 'Soundcloud URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[soundcloud_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[messenger_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_messenger_button_control', array( 'label' => esc_html__( 'Messenger URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[messenger_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[lastfm_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_lastfm_button_control', array( 'label' => esc_html__( 'Lastfm URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[lastfm_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[medium_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_medium_button_control', array( 'label' => esc_html__( 'Medium URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[medium_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[github_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_github_button_control', array( 'label' => esc_html__( 'Github URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[github_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[bitbucket_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_bitbucket_button_control', array( 'label' => esc_html__( 'Bitbucket URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[bitbucket_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[tumblr_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_tumblr_button_control', array( 'label' => esc_html__( 'Tumblr URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[tumblr_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[digg_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_digg_button_control', array( 'label' => esc_html__( 'Digg URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[digg_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[delicious_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_delicious_button_control', array( 'label' => esc_html__( 'Delicious URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[delicious_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[stumble_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_stumble_button_control', array( 'label' => esc_html__( 'Stumbleupon URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[stumble_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[mix_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_mix_button_control', array( 'label' => esc_html__( 'Mix URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[mix_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[reddit_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_reddit_button_control', array( 'label' => esc_html__( 'Reddit URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[reddit_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[dribbble_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_dribbble_button_control', array( 'label' => esc_html__( 'Dribbble URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[dribbble_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[flipboard_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_flipboard_button_control', array( 'label' => esc_html__( 'Flipboard URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[flipboard_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[blogger_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_blogger_button_control', array( 'label' => esc_html__( 'Blogger URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[blogger_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[etsy_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_etsy_button_control', array( 'label' => esc_html__( 'Etsy URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[etsy_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[behance_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_behance_button_control', array( 'label' => esc_html__( 'Behance URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[behance_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[amazon_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_amazon_button_control', array( 'label' => esc_html__( 'Amazon URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[amazon_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[meetup_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_meetup_button_control', array( 'label' => esc_html__( 'Meetup URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[meetup_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[mixcloud_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_mixcloud_button_control', array( 'label' => esc_html__( 'Mixcloud URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[mixcloud_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[slack_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_slack_button_control', array( 'label' => esc_html__( 'Slack URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[slack_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[snapchat_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_snapchat_button_control', array( 'label' => esc_html__( 'Snapchat URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[snapchat_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[spotify_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_spotify_button_control', array( 'label' => esc_html__( 'Spotify URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[spotify_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[yelp_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_yelp_button_control', array( 'label' => esc_html__( 'Yelp URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[yelp_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[wordpress_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_wordpress_button_control', array( 'label' => esc_html__( 'WordPress URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[wordpress_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[twitch_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_twitch_button_control', array( 'label' => esc_html__( 'Twitch URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[twitch_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[telegram_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_telegram_button_control', array( 'label' => esc_html__( 'Telegram URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[telegram_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[bandcamp_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_bandcamp_button_control', array( 'label' => esc_html__( 'Bandcamp URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[bandcamp_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[quora_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_quora_button_control', array( 'label' => esc_html__( 'Quora URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[quora_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[foursquare_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_foursquare_button_control', array( 'label' => esc_html__( 'Foursquare URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[foursquare_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[deviantart_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_deviantart_button_control', array( 'label' => esc_html__( 'DeviantArt URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[deviantart_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[imdb_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_imdb_button_control', array( 'label' => esc_html__( 'IMDB URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[imdb_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[codepen_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_codepen_button_control', array( 'label' => esc_html__( 'Codepen URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[codepen_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[jsfiddle_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_jsfiddle_button_control', array( 'label' => esc_html__( 'JSFiddle URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[jsfiddle_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[stackoverflow_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_stackoverflow_button_control', array( 'label' => esc_html__( 'Stack Overflow URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[stackoverflow_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[stackexchange_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_stackexchange_button_control', array( 'label' => esc_html__( 'Stack Exchange URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[stackexchange_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[bsa_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_bsa_button_control', array( 'label' => esc_html__( 'BuySellAds URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[bsa_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[web500px_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_web500px_button_control', array( 'label' => esc_html__( '500px URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[web500px_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[ello_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_ello_button_control', array( 'label' => esc_html__( 'Ello URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[ello_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[goodreads_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_goodreads_button_control', array( 'label' => esc_html__( 'Goodreads URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[goodreads_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[odnoklassniki_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_odnoklassniki_button_control', array( 'label' => esc_html__( 'Odnoklassniki URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[odnoklassniki_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[houzz_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_houzz_button_control', array( 'label' => esc_html__( 'Houzz URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[houzz_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[pocket_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_pocket_button_control', array( 'label' => esc_html__( 'Pocket URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[pocket_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[xing_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_xing_button_control', array( 'label' => esc_html__( 'XING URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[xing_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[googleplay_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_googleplay_button_control', array( 'label' => esc_html__( 'Google Play URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[googleplay_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[slideshare_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_slideshare_button_control', array( 'label' => esc_html__( 'SlideShare URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[slideshare_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[dropbox_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_dropbox_button_control', array( 'label' => esc_html__( 'Dropbox URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[dropbox_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[paypal_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_paypal_button_control', array( 'label' => esc_html__( 'PayPal URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[paypal_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[viadeo_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_viadeo_button_control', array( 'label' => esc_html__( 'Viadeo URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[viadeo_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[wikipedia_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_wikipedia_button_control', array( 'label' => esc_html__( 'Wikipedia URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[wikipedia_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[skype_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'sanitize_text_field' ) );

    $wp_customize->add_control( 'boldwp_skype_button_control', array( 'label' => esc_html__( 'Skype Username', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[skype_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[email_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'boldwp_sanitize_email' ) );

    $wp_customize->add_control( 'boldwp_email_button_control', array( 'label' => esc_html__( 'Email Address', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[email_button]', 'type' => 'text' ) );

    $wp_customize->add_setting( 'boldwp_options[rss_button]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

    $wp_customize->add_control( 'boldwp_rss_button_control', array( 'label' => esc_html__( 'RSS Feed URL', 'boldwp' ), 'section' => 'boldwp_section_social_footer', 'settings' => 'boldwp_options[rss_button]', 'type' => 'text' ) );

}