<?php
/**
* The template for displaying tag archive pages.
*
* @link https://developer.wordpress.org/themes/basics/template-hierarchy/
*
* @package BoldWP WordPress Theme
* @copyright Copyright (C) 2020 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

get_header(); ?>

<div class="boldwp-main-wrapper clearfix" id="boldwp-main-wrapper" itemscope="itemscope" itemtype="http://schema.org/Blog" role="main">
<div class="theiaStickySidebar">
<div class="boldwp-main-wrapper-inside clearfix">

<?php boldwp_before_main_content(); ?>

<div class="boldwp-posts-wrapper" id="boldwp-posts-wrapper">
<div class="boldwp-posts">

<?php if ( !(boldwp_get_option('hide_tags_title')) ) { ?>
<div class="boldwp-page-header-outside">
<header class="boldwp-page-header">
<div class="boldwp-page-header-inside">
<?php the_archive_title( '<h1 class="page-title">', '</h1>' ); ?>
<?php if ( !(boldwp_get_option('hide_tags_description')) ) { ?><?php the_archive_description( '<div class="taxonomy-description">', '</div>' ); ?><?php } ?>
</div>
</header>
</div>
<?php } ?>

<div class="boldwp-posts-content">

<?php if (have_posts()) : ?>

    <div class="boldwp-posts-container <?php echo esc_attr(boldwp_posts_container_class()); ?>">
    <?php $boldwp_total_posts = $wp_query->post_count; ?>
    <?php $boldwp_post_counter=1; while (have_posts()) : the_post(); ?>

        <?php get_template_part( 'template-parts/content', boldwp_post_style() ); ?>

    <?php $boldwp_post_counter++; endwhile; ?>
    </div>
    <div class="clear"></div>

    <?php boldwp_posts_navigation(); ?>

<?php else : ?>

  <?php get_template_part( 'template-parts/content', 'none' ); ?>

<?php endif; ?>

</div>

</div>
</div><!--/#boldwp-posts-wrapper -->

<?php boldwp_after_main_content(); ?>

</div>
</div>
</div><!-- /#boldwp-main-wrapper -->

<?php get_sidebar(); ?>

<?php get_footer(); ?>