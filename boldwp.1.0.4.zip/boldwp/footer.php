<?php
/**
* The template for displaying the footer
*
* @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
*
* @package BoldWP WordPress Theme
* @copyright Copyright (C) 2020 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/
?>

</div>

</div><!--/#boldwp-content-wrapper -->
</div><!--/#boldwp-wrapper -->

<div class="boldwp-outer-wrapper">
<?php boldwp_bottom_wide_widgets(); ?>
</div>

<?php boldwp_before_footer(); ?>

<?php if ( !(boldwp_hide_footer_widgets()) ) { ?>
<?php if ( is_active_sidebar( 'boldwp-footer-1' ) || is_active_sidebar( 'boldwp-footer-2' ) || is_active_sidebar( 'boldwp-footer-3' ) || is_active_sidebar( 'boldwp-footer-4' ) || is_active_sidebar( 'boldwp-footer-5' ) || is_active_sidebar( 'boldwp-top-footer' ) || is_active_sidebar( 'boldwp-bottom-footer' ) ) : ?>
<div class="boldwp-outer-wrapper">
<div class='clearfix' id='boldwp-footer-blocks' itemscope='itemscope' itemtype='http://schema.org/WPFooter' role='contentinfo'>
<div class='boldwp-container clearfix'>

<?php if ( is_active_sidebar( 'boldwp-top-footer' ) ) : ?>
<div class='clearfix'>
<div class='boldwp-top-footer-block'>
<?php dynamic_sidebar( 'boldwp-top-footer' ); ?>
</div>
</div>
<?php endif; ?>

<?php if ( is_active_sidebar( 'boldwp-footer-1' ) || is_active_sidebar( 'boldwp-footer-2' ) || is_active_sidebar( 'boldwp-footer-3' ) || is_active_sidebar( 'boldwp-footer-4' ) || is_active_sidebar( 'boldwp-footer-5' ) ) : ?>
<div class='boldwp-footer-block-cols clearfix'>

<div class="boldwp-footer-block-col boldwp-footer-5-col" id="boldwp-footer-block-1">
<?php dynamic_sidebar( 'boldwp-footer-1' ); ?>
</div>

<div class="boldwp-footer-block-col boldwp-footer-5-col" id="boldwp-footer-block-2">
<?php dynamic_sidebar( 'boldwp-footer-2' ); ?>
</div>

<div class="boldwp-footer-block-col boldwp-footer-5-col" id="boldwp-footer-block-3">
<?php dynamic_sidebar( 'boldwp-footer-3' ); ?>
</div>

<div class="boldwp-footer-block-col boldwp-footer-5-col" id="boldwp-footer-block-4">
<?php dynamic_sidebar( 'boldwp-footer-4' ); ?>
</div>

<div class="boldwp-footer-block-col boldwp-footer-5-col" id="boldwp-footer-block-5">
<?php dynamic_sidebar( 'boldwp-footer-5' ); ?>
</div>

</div>
<?php endif; ?>

<?php if ( is_active_sidebar( 'boldwp-bottom-footer' ) ) : ?>
<div class='clearfix'>
<div class='boldwp-bottom-footer-block'>
<?php dynamic_sidebar( 'boldwp-bottom-footer' ); ?>
</div>
</div>
<?php endif; ?>

</div>
</div><!--/#boldwp-footer-blocks-->
</div>
<?php endif; ?>
<?php } ?>

<?php if ( !(boldwp_get_option('hide_footer_social_buttons')) ) { ?>
<div class="boldwp-outer-wrapper">
<div class="boldwp-bottom-social-bar">
<?php boldwp_footer_social_buttons(); ?>
</div>
</div>
<?php } ?>

<div class="boldwp-outer-wrapper">
<div class='clearfix' id='boldwp-footer'>
<div class='boldwp-foot-wrap boldwp-container'>

<?php if ( boldwp_get_option('footer_text') ) : ?>
  <p class='boldwp-copyright'><?php echo esc_html(boldwp_get_option('footer_text')); ?></p>
<?php else : ?>
  <p class='boldwp-copyright'><?php /* translators: %s: Year and site name. */ printf( esc_html__( 'Copyright &copy; %s', 'boldwp' ), esc_html(date_i18n(__('Y','boldwp'))) . ' ' . esc_html(get_bloginfo( 'name' ))  ); ?></p>
<?php endif; ?>
<p class='boldwp-credit'><a href="<?php echo esc_url( 'https://themesdna.com/' ); ?>"><?php /* translators: %s: Theme author. */ printf( esc_html__( 'Design by %s', 'boldwp' ), 'ThemesDNA.com' ); ?></a></p>

</div>
</div><!--/#boldwp-footer -->
</div>

<?php boldwp_after_footer(); ?>

</div>

<button class="boldwp-scroll-top" title="<?php esc_attr_e('Scroll to Top','boldwp'); ?>"><i class="fas fa-arrow-up" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Scroll to Top', 'boldwp'); ?></span></button>

<?php wp_footer(); ?>
</body>
</html>