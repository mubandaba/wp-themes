<?php get_header(); ?>
	<section id="container">
		<div class="row">
			<?php
			Bing_archive_header();
			Bing_posts_list();
			?>
		</div>
	</section>
<?php get_footer(); ?>