<?php 
    get_header(); 
    $user_id        = get_the_author_ID();
    $args = array(
	'post_author' => $user_id 
	);
	$author_comments = get_comments($args);
?>
<div class="uk-grid-small" uk-grid>
    <div class="uk-width-1-1 uk-width-auto@xl">
        <div class="author-card uk-background-default">
        <div class="uk-background-default b-r-4 uk-overflow-hidden">
            <div class="b-b uk-text-center uk-padding">
                <?php echo get_avatar(get_the_author_meta( 'ID' ), 68); ?>
                <div class="uk-margin-top"><?php the_author_nickname(); ?></div>
            </div>
        </div>
        <ul class="uk-list uk-margin-remove uk-visible@s">
            <li><span>UID</span>: <?php the_author_meta( 'ID', $user_id ); ?></li>
            <li><span>帖子</span>: <?php echo count_user_posts($user_id); ?></li>
            <li><span>评论</span>: <?php echo count($author_comments); ?></li>
            <?php if(get_user_meta( $user_id , 'qq' , true )) : ?>
            <li><span>QQ</span>: <?php echo get_user_meta( $user_id , 'qq' , true ); ?></li>
            <?php endif; ?>
            <?php if(get_user_meta( $user_id , 'weixin' , true )) : ?>
            <li><span>微信</span>: <?php echo get_user_meta( $user_id , 'weixin' , true ); ?></li>
            <?php endif; ?>
            <?php if(get_user_meta( $user_id , 'weibo' , true )) : ?>
            <li><span>微博</span>: <?php echo get_user_meta( $user_id , 'weibo' , true ); ?></li>
            <?php endif; ?>
        </ul>
        </div>
    </div>
    <div class="uk-width-1-1 uk-width-expand@xl">
        <div class="uk-background-default">
            <div class="b-b uk-grid-collapse" uk-grid>
    		    <div class="uk-width-expand b-r">
    		        <div class="author-des">
                        <?php 
                            $user_description = get_the_author_meta('user_description', $user_id);
                            if(!$user_description){
                                echo '好久不见';
                            }else {
                                 echo the_author_meta('user_description', $user_id);
                            }
                        ?>
                        <div class="uk-margin-small-top">
                            <span class="time uk-text-small uk-text-muted"></span>
                        </div>
                    </div>
                </div>
                <div class="uk-width-auto uk-visible@s">
                    <div class="author-img">
                        <span class="uk-display-block uk-overflow-hidden">
                            <?php 
                                $userbg = get_user_meta( $user_id , 'userbg' , true );
                                if (!$userbg){
                            ?>
                            <img src="https://img.wmpic.com/wp-content/uploads/2020/05/2020052713441845.png" alt="<?php the_author_meta('nickname',$user_id); ?>">
                            <?php }else { ?> 
                            <img src="<?php echo $userbg; ?>" alt="<?php the_author_meta('nickname',$user_id); ?>">
                            <?php } ?>
                            
                        </span>
                    </div>
                </div>
            </div>
            <ul class="author-menu b-b uk-margin-remove" uk-switcher>
        		<li class="uk-display-inline-block uk-margin-right"><a href="#" class="uk-display-block uk-position-relative uk-padding-small uk-padding-remove-horizontal">动态</a></li>
        	</ul>
        	<div class="author-main uk-switcher">
        		<div class="uk-container">
        			<div class="uk-animation-slide-left-small uk-grid-small" uk-grid="masonry: true">
        				<?php if(have_posts()) : while (have_posts()) : the_post(); ?>
        				<div class="uk-width-1-2 uk-width-1-3@m uk-width-1-3@xl">
        				<?php get_template_part( 'template-parts/loop', 'tp' ); ?>
        				</div>
        				<?php endwhile; else: ?>
        				<p class="uk-padding-small uk-text-center">暂无动态</p>
        				<?php endif; ?>
        			</div>
        			<div class="part-more b-t uk-margin-medium-top uk-padding-remove-horizontal uk-padding-remove-bottom">
            			<div class="fenye">
                        	<?php fenye(); ?>
                        </div>
                    </div>
        		</div>	
	        </div>
        </div>
    </div>
</div>
<?php get_footer(); ?>