<?php get_header();?>
<section>
	<div class="uk-container uk-width-1-1 uk-width-1-2@xl uk-margin-large-top uk-margin-large-bottom">
	    <div class="uk-background-default uk-padding">
	        <div class="b-a uk-padding-small">
	        <h1 class="b-b uk-padding-small uk-padding-remove-horizontal uk-padding-remove-top uk-margin-remove-bottom">404</h1>
	        <div class="uk-text-muted uk-padding-small uk-padding-remove-horizontal">页面走丢了，要不返回首页吧？或者自己搜索下其他内容吧？</div>
	        <div class="search">
            	<form method="get" class="b-a uk-form uk-flex uk-overflow-hidden" action="/">
            		<input type="search" placeholder="输入关键字搜索" autocomplete="off" value="" name="s" required="required" class="uk-input uk-text-small">
            		<button type="submit"><i class="iconfont icon-sousuo"></i></button>
            	</form>
            </div>
            </div>
	    </div>
	</div>
</section>

<?php get_footer(); ?>