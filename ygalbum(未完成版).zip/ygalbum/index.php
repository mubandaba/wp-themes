<?php get_header();?>
<?php get_template_part( 'template-parts/home', 'tx' ); ?>
<?php get_template_part( 'template-parts/home', 'wz' ); ?>
<?php get_template_part( 'template-parts/home', 'tp' ); ?>
<?php if ( is_home() ) { ?>
<?php if(_aye('link_show') == true ): ?>
<div class="link uk-margin-medium-top uk-background-default">
    <div class="link-title b-b uk-flex uk-flex-middle">
        <span class="uk-flex-1">友情链接</span>
        <span class="uk-text-small uk-text-muted">交换友链联系QQ：1098816988</span>
    </div>
    <ul class="uk-margin-remove uk-text-small">
    	<?php wp_list_bookmarks('title_li='); ?>
    </ul>
</div>
<?php endif; ?>
<?php } ?>
<?php get_footer();?>
