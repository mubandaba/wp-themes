$(document).ready(function(){
	
	//文章表格添加样式
	$('.single-content table').addClass('uk-table uk-table-divider uk-text-small');


	//获取日期
	var myDate = new Date;
	var year = myDate.getFullYear(); //获取当前年
	var mon = myDate.getMonth() + 1; //获取当前月
	var date = myDate.getDate(); //获取当前日
	var week = myDate.getDay();
	var weeks = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"];
	$(".time").html(year + "年" + mon + "月" + date + "日 " + weeks[week]);

	
	//添加灯箱
	$('.wp-block-gallery').attr( 'uk-lightbox' ,'animation: fade' );
	$('.wp-block-image').attr( 'uk-lightbox' ,'animation: fade' );
	
	//随机唯美句子
	var arr=[
		"从此以后提及你，也无风无雨也无晴。",
		"生活挺不容易了，相互哄一哄，骗一骗吧。",
		"爱情的道路上，注定会有孤独陪伴。",
		"做一个健康的人，不抽烟不喝酒不熬夜。",
		"生活不是一种刁难，而是一种雕刻。",
		"无论我变得如何强大，你仍然是我的弱点。",
		"人生长路漫漫，往后余生我想与你为伴。",
		"我一生只要两样东西，一个是你，一个是你快乐。",
		"人生总会有雨天和晴天，但总会雨过天晴的。",
		"人来人往，孤独早已司空见惯。",
		"感情一夜就成灰，曾经燃烧的再火热也会落寞。",
		"你所厌恶的现在是未来的你回不去的曾经。",
		"有些时候我会做梦，盼望回过头你在身后。",
		"如果不是曾被爱伤得彻底，谁会把自己关得那么紧。",
		"不后悔遇见谁，只是后悔，怎么成了现在的模样。",
		"我将沿途一路流泪，告别我曾不舍的伤悲。",
		"给时间一点时间，让过去过去，让开始开始。",
		"没有恰到好处的事情，只有恰如其分的心情。",
		"你从不曾理会我出现的昨天，我又何必再想起往日心弦。",
		"理智告诉你多此一举，感情又怂恿你放手一搏。",
		"我走过了江湖百里，却到不了有你的临安。",
		"我给自己砌了一道墙 别人进不来自己也出不去。",
		"漫漫人生路，总有许多想说和想做的。",
		"讨厌酒的味道，却爱极了醉的模样",
		"很多事没有来日方长，很多人只会乍然离场。",
		"一个人的孤独 好过两个人的无趣",
	];
	var rand = Math.floor( Math.random() *arr.length );
	$(".juzi").html(arr[rand])
	
});



console.log('\n' + ' %c Theme Designed by 唯美图片 %c https://www.wmpic.com ' + '\n', 'color: #fff; background: #00d495; padding:5px 0; font-size:12px;', 'padding:5px 0; font-size:12px;');
