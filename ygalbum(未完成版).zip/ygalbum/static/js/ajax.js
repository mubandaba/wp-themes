
// 验证邮箱邮件 重新发送
var t = 60;    
function showTime(item){

    item ? item : item = '#re_send_mail';

    t -= 1;  
    $(item).text('重新发送（'+t+'）');
    $('#re_send_mail').css("pointer-events","none")
    var f = setTimeout("showTime('"+item+"')",1000); 

    if(t==0){
       $(item).text('重新发送');
       $('#re_send_mail').css("pointer-events","auto")
       window.clearTimeout(f);
       t=60;
    } 

}


(function($) {

// 重新发送邮件
$(document).on('click', '#re_send_mail', function(event) {
    event.preventDefault();
    $.ajax({
        url: dahuzi.ajaxurl,
        type: 'POST',
        dataType: 'json',
        data: {action: 're_send_mail'},
    })
    .done(function( data ) {
        if( data.state == 200 ){
            showTime('#re_send_mail');
        }else{
            alert(data.tips)
        }
    })
    .fail(function() {
        alert('网络错误，请稍候再试！');
    });
    

});

// 账号登录
$('#login-form').submit(function(event) {
    event.preventDefault();

    $.ajax({
        url: dahuzi.ajaxurl,
        type: 'POST',
        dataType: 'json',
        data: $('#login-form').serializeArray(),
    })
    .done(function( data ) {
        if( data != 0 ){
            if( data.state == 200 ){
                if( data.url ){
                    window.location.href = data.url;
                }
            }else if( data.state == 201 ){
                $('.dahuzi-tips').removeClass('success').addClass('error').text(data.tips); 
            }
        }else{
            $('.dahuzi-tips').removeClass('success').addClass('error').text('请求错误！');   
        }
    })
    .fail(function() {
        alert('网络错误！');
    });

});

//注册账号
$('#register-form').submit(function(event) {
    event.preventDefault();

    $.ajax({
        url: dahuzi.ajaxurl,
        type: 'POST',
        dataType: 'json',
        data: $('#register-form').serializeArray(),
    })
    .done(function( data ) {
        if( data != 0 ){
            if( data.state == 200 ){
                if( data.url ){
                    window.location.href = data.url;
                }
            }else if( data.state == 201 ){
                $('.dahuzi-tips').removeClass('success').addClass('error').text(data.tips); 
            }
        }else{
            $('.dahuzi-tips').removeClass('success').addClass('error').text('请求错误！');   
        }
    })
    .fail(function() {
        alert('网络错误！');
    });

});

//收藏
jQuery(document).on("click", ".add-collection", function() {

    var post_id = $(this).data("id");
    var $this = $(this);

    jQuery.ajax({
        url: dahuzi.ajaxurl,
        data: {
            action:"do_collection",
            post_id:post_id
        },
        type: 'post',
        dataType: 'json',
        success:function(data){

            if(data.state == 1){
            	UIkit.notification({
					message: '感谢收藏！',
					status: 'success',
				});
                $this.addClass("cancel-collection").removeClass("add-collection").html("<i class='fa fa-star'></i> 已收藏 "+data.num+"");
            }else{

                if( data.state == 300 ){
                    alert(data.tips);
                    window.location.href = data.url;
                } else{
                    alert(data.tips);
                }

            }

        },

    });
    return false;
});

//取消收藏
jQuery(document).on("click", ".cancel-collection", function() {

    var post_id = $(this).data("id");
    var $this = $(this);

    jQuery.ajax({
        url: dahuzi.ajaxurl,
        data: {
            action:"cancel_collection",
            post_id:post_id
        },
        type: 'post',
        dataType: 'json',
        success:function(data){

            if(data.state == 1){
            	UIkit.notification({
					message: '取消收藏！',
					status: 'warning',
				});
                $this.addClass("add-collection").removeClass("cancel-collection").html("<i class='fa fa-star-o'></i> 收藏 "+data.num+"");
            }else{
                alert(data.tips);
            }

        },

    });
    return false;
});

//文章页面，刷新页面后取消收藏
$(document).on('click', '.single-del-collection', function() {

    var post_id = $(this).data('id');
    var $this = $(this);

    jQuery.ajax({
        url: dahuzi.ajaxurl,
        data: {
            action:"cancel_collection",
            post_id:post_id
        },
        type: 'post',
        dataType: 'json',
        success:function(data){

            if(data.state == 1){
                $this.addClass("add-collection").removeClass("single-del-collection").html("<i class='fa fa-star-o'></i> 收藏 "+data.num+"");
            }else{
                alert(data.tips);
            }

        },

    });

});

//用户中心取消收藏文章
$(document).on('click', '.del-collection', function(event) {
    event.preventDefault();
    var id = $(this).data('id');

    jQuery.ajax({
        url: dahuzi.ajaxurl,
        data: {
            action:"cancel_collection",
            post_id:id
        },
        type: 'post',
        dataType: 'json',
        success:function(data){

            if(data.state == 1){
                $('.collection-post-'+id).remove();
            }else{
                alert(data.tips);
            }

        },
    });

});


// 用户中心 我的收藏  移除收藏
(function($){
    var $dp_handle = $('.dropdown-handle');

    $dp_handle.on('click', toggleSettings);

    function toggleSettings() {
        var $this = $(this),
            $dp = $this.siblings('.dropdown');

        if($dp.hasClass('closed')) {
            $dp.removeClass('closed');
            $this.addClass('active');
        } else {
            $dp.addClass('closed');
            $this.removeClass('active');
        }
    }
})(jQuery);

// 修改资料
$('#updata_accounts').submit(function(event) {
    event.preventDefault();

    $.ajax({
        url: dahuzi.ajaxurl,
        type: 'POST',
        dataType: 'json',
        data: $('#updata_accounts').serializeArray(),
    })
    .done(function( data ) {
        alert(data.tips);
        location.reload();
    })
    .fail(function() {
        alert('网络错误！');
    });
    
});


//用户中心修改密码
$(document).on('click', '#change_password_button', function(event) {
    event.preventDefault();

    var oldpwd = $('#oldpassword').val();
    var pwd1 = $('#newpassword').val();
    var pwd2 = $('#newpassword2').val();

    var err = 0;

    if( oldpwd == '' ){
        $('.oldpassword').removeClass('success').addClass('error');
        $('.oldpassword .dahuzi-tips').text('请输入旧密码');
        $('.oldpassword .dahuzi-tips').show();
        err = 1;
    }else{
        $('.oldpassword .dahuzi-tips').hide();
    }

    if( pwd1 == '' ){
        $('.newpassword').removeClass('success').addClass('error');
        $('.newpassword .dahuzi-tips').text('请输入密码');
        $('.newpassword .dahuzi-tips').show();
        err = 1;
    }else{
        $('.newpassword .dahuzi-tips').hide();
    }

    if( pwd2 == '' ){
        $('.newpassword2').removeClass('success').addClass('error');
        $('.newpassword2 .dahuzi-tips').text('请输入密码');
        $('.newpassword2 .dahuzi-tips').show();
        err = 1;
    }else{
        $('.newpassword2 .dahuzi-tips').hide()
    }

    if( pwd1 && pwd2 ){

        if( pwd1 != pwd2 ){
            $('.newpassword2,.newpassword').removeClass('success').addClass('error');
            $('.newpassword2 .dahuzi-tips,.newpassword .dahuzi-tips').text('密码不一致');
            $('.newpassword2 .dahuzi-tips,.newpassword .dahuzi-tips').show();
            err = 1;
        }else if( pwd1.length < 6 ){
            $('.newpassword2,.newpassword').removeClass('success').addClass('error');
            $('.newpassword2 .dahuzi-tips,.newpassword .dahuzi-tips').text('密码不能少于六位');
            $('.newpassword2 .dahuzi-tips,.newpassword .dahuzi-tips').show();
            err = 1;
        }

    }

    if( err != 1 ){

        $.ajax({
            url: dahuzi.ajaxurl,
            type: 'POST',
            dataType: 'json',
            data: $('#change_password').serializeArray(),
        })
        .done(function(data) {

            if( data.state ){
                alert(data.tips);
                window.location.href =  window.location.href;
            }else{
                alert(data.tips);
            }

        })
        .fail(function() {
            alert('网络错误，请稍候再试！');
        });

    }
    
});

//QQ登录
jQuery(document).on("click", ".qq_login_button",
    function() {
        //var w = window.open("","QQ授权登录",["toolbar=0,status=0,resizable=1,width=640,height=560,left=", (screen.width - 640) / 2, ",top=", (screen.height - 560) / 2].join(""));
        jQuery.ajax({
            url: dahuzi.ajaxurl,
            type: "POST",
            data: {action:"ajax_qq"},
            success: function(data) {
                window.location = data;
            }
        });
    return false;  
});

//第三方账号首次登录需绑定本站账号
$('#login_binding').submit(function(event) {
    /* Act on the event */
    event.preventDefault();

        $.ajax({
            url: dahuzi.ajaxurl,
            type: 'POST',
            dataType: 'json',
            data: $('#login_binding').serializeArray(),
        })
        .done(function( data ) {
            if( data != 0 ){
                if( data.state == 200 ){
                    if( data.url ){
                    	//alert(data.tips);
                        window.location.href = data.url;
                    }
                }else if( data.state == 201 ){
                    alert(data.tips);
                }
            }else{
                alert('请求错误！');
            }
        })
        .fail(function() {
            alert('网络错误！');
        });

});

//第三方账号首次登录，没有本站账号的情况下注册新账号并绑定
$('#reg_binding').submit(function(event) {
    event.preventDefault();

        $.ajax({
            url: dahuzi.ajaxurl,
            type: 'POST',
            dataType: 'json',
            data: $('#reg_binding').serializeArray(),
        })
        .done(function( data ) {
            if( data != 0 ){
                if( data.state == 200 ){
                    if( data.url ){
	                    //alert(data.tips);
	                    //window.location.href = data.url;
                        window.location.reload()
                    }
                }else if( data.state == 201 ){
                    alert(data.tips);
                }
            }else{
                alert('请求错误！');  
            }
        })
        .fail(function() {
            alert('网络错误！');
        });

});


//文章点赞
$.prototype.postLike = function () {
	if ($(this).hasClass('done')) {
		UIkit.notification({
			message: '<i class="iconfont icon-icon-test30"></i> 您已经点过赞了！！！',
			status: 'warning',
		});
		return false;
	} else {
		$(this).addClass('done');
		var id = $(this).data("id"),
			action = $(this).data('action'),
			rateHolder = $(this).children('.count');
		var ajax_data = {
			action: "dotGood",
			um_id: id,
			um_action: action
		};
		$.post("/wp-admin/admin-ajax.php", ajax_data,
			   function (data) {
			$(rateHolder).html(data);
		});
		return false;
	}
};
$(".dotGood").click(function () {
	$(this).postLike();
});



//点击加载更多
$('#pagination a').click(function() {
	$this = $(this);
	$this.addClass('loading').text("正在努力加载..."); //给a标签加载一个loading的class属性，可以用来添加一些加载效果
	var href = $this.attr("href"); //获取下一页的链接地址
	if (href != undefined) { //如果地址存在
		$.ajax({ //发起ajax请求
			url: href, //请求的地址就是下一页的链接
			type: "get", //请求类型是get
			error: function(request) {
				//如果发生错误怎么处理
			},
			success: function(data) { //请求成功
				setTimeout(function(){
					$this.removeClass('loading').text("点击查看更多"); //移除loading属性
					var $res = $(data).find(".ajax-item"); //从数据中挑出文章数据，请根据实际情况更改
					$('.ajax-main').append($res.fadeIn(500)); //将数据加载加进posts-loop的标签中。
					var newhref = $(data).find("#pagination a").attr("href"); //找出新的下一页链接
					if (newhref != undefined) {
						$("#pagination a").attr("href", newhref);
					} else {
						$("#pagination").html('我有底线的！'); //如果没有下一页了，隐藏
					}
				},500);
			}
		});
	}
	return false;
});



})(jQuery);