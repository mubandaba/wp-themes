<?php
/*
* ------------------------------------------------------------------------------
* 加载后台框架
* ------------------------------------------------------------------------------
*/
include(TEMPLATEPATH . '/inc/codestar-framework/codestar-framework.php');
include(TEMPLATEPATH . '/inc/options/options.theme.php');
include(TEMPLATEPATH . '/inc/options/taxonomy.theme.php');

if ( ! function_exists( '_aye' ) ) {
  function _aye( $option = '', $default = null ) {
    $options = get_option( 'wmpic' ); // Attention: Set your unique id of the framework
    return ( isset( $options[$option] ) ) ? $options[$option] : $default;
  }
}

/*
* ------------------------------------------------------------------------------
* 加载主题功能
* ------------------------------------------------------------------------------
*/
include TEMPLATEPATH.'/inc/extends/avatar/simple-local-avatars.php';
include TEMPLATEPATH.'/inc/functions/enqueue.php';
include TEMPLATEPATH.'/inc/functions/optimization.php';
include TEMPLATEPATH.'/inc/functions/article.php';
include TEMPLATEPATH.'/inc/functions/category.php';
include TEMPLATEPATH.'/inc/functions/user.php';
include TEMPLATEPATH.'/inc/functions/other.php';
include TEMPLATEPATH.'/inc/functions/comment.php';
