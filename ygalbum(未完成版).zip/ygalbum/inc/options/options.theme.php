<?php if (! defined('ABSPATH')) {
	die;
}
if (class_exists('CSF')) {
	$prefix = 'wmpic';
	CSF::createOptions($prefix, array(
		'menu_title' => '主题设置',
		'menu_slug' => 'my-framework',
		'framework_title'         => 'ygAlbum主题 <small>by ygtheme.com</small>',
	));

	/*
	 * 基本设置
	 * */
	CSF::createSection($prefix, array(
		'id' => 'too_basic',
		'title' => '基本设置',
	));
	CSF::createSection($prefix, array(
		'parent' => 'too_basic',
		'title' => '顶部设置',
		'fields' => array(
			array(
				'id' => 'head_logo',
				'type' => 'upload',
				'title' => '顶部Logo图片',
				'placeholder' => 'http://',
				'button_title' => '上传',
				'remove_title' => '删除',
				'default' => 'https://ygalbum.ygtheme.com/wp-content/uploads/2020/07/2020072012342076.png'
			),
			array(
				'id' => 'favicon',
				'type' => 'upload',
				'title' => '网站favicon.ico图标',
				'placeholder' => 'http://',
				'button_title' => '上传',
				'remove_title' => '删除',
				'default' => 'https://ygalbum.ygtheme.com/wp-content/uploads/2020/07/2020072012342076.png'
			),
		)
	));
	CSF::createSection($prefix, array(
		'parent' => 'too_basic',
		'title' => '底部设置',
		'fields' => array(
			array(
				'id' => 'foot_beian',
				'type' => 'text',
				'title' => '网站备案号码',
				'default' => '鄂ICP备18001037号'
			),
			array(
				'id' => 'foot_text',
				'type' => 'textarea',
				'title' => '网站底部版权文字',
				'desc'  => '可以使用html编辑',
				'default' => 'Copyright 2019-2020'
			),
			array(
				'id' => 'theme_cop',
				'type' => 'switcher',
				'title' => '隐藏/显示主题版权',
				'desc' => '隐藏版权请添加作者网站友情链接',
				'default' => true
			),
			array(
				'id' => 'load_time',
				'type' => 'switcher',
				'title' => '隐藏/显示网站加载时间',
				'default' => true
			),
		)
	));
	/*
	 * SEO设置
	 * */
	CSF::createSection($prefix, array(
		'parent' => 'too_basic',
		'title' => 'SEO设置',
		'fields' => array(
			array(
				'id' => 'website_title',
				'type' => 'text',
				'title' => '网站标题',
			),
			array(
				'id' => 'website_keywords',
				'type' => 'text',
				'title' => '网站关键词',
			),
			array(
				'id' => 'website_description',
				'type' => 'text',
				'title' => '网站描述',
			),
		)
	));

	CSF::createSection($prefix, array(
		'parent' => 'too_basic',
		'title' => '其他设置',
		'fields' => array(
			array(
				'id' => 'link_show',
				'type' => 'switcher',
				'title' => '关闭/开启友情链接',
				'default' => true
			),
			array(
				'id' => 'comments_close',
				'type' => 'switcher',
				'title' => '关闭整站评论',
				'default' => false
			),
		)
	));
	/*
	 * 首页设置
	 * */
	CSF::createSection($prefix, array(
		'id' => 'too_home',
		'title' => '首页设置',
		'fields' => array(
		    array(
				'id' => 'home_title',
				'type' => 'text',
				'title' => '首页标题',
				'default'     => '去成为你想成为的人 什么时候都可以开始'
			),
			array(
				'id' => 'home_title_link',
				'type' => 'text',
				'title' => '首页标题链接',
				'default'     => '/'
			),
			array(
				'id' => 'home_des',
				'type' => 'text',
				'title' => '首页副标题',
				'default'     => 'Be what you want to be, and you can start all the time'
			),
		)
	));


	/*
	 * 分类设置
	 * */
	CSF::createSection($prefix, array(
		'id' => 'too_cat',
		'title' => '分类设置',
	));
	CSF::createSection($prefix, array(
		'parent' => 'too_cat',
		'title' => '分类设置',
		'fields' => array(
			array(
				'id' => 'default_thum',
				'type' => 'upload',
				'title' => '设置文章默认缩略图',
				'placeholder' => 'http://',
				'button_title' => '上传',
				'remove_title' => '删除',
				'default' => 'https://ygalbum.ygtheme.com/wp-content/uploads/2020/07/2020052713441845.png'
			),
		)
	));
	/*
	 * 内页设置
	 * */
	CSF::createSection($prefix, array(
		'id' => 'too_single',
		'title' => '内页设置',
	));
	CSF::createSection($prefix, array(
		'parent' => 'too_single',
		'title' => '内页设置',
		'fields' => array(
			array(
				'id' => 'single_sc_num',
				'type' => 'switcher',
				'title' => '隐藏/显示文章收藏数量',
				'default' => true,
			),
			array(
				'id' => 'single_tag',
				'type' => 'switcher',
				'title' => '隐藏/显示文章标签',
				'default' => true,
			),
			array(
				'id' => 'single_zan',
				'type' => 'switcher',
				'title' => '隐藏/显示文章点赞按钮',
				'default' => true,
			),
			array(
				'id' => 'single_collection',
				'type' => 'switcher',
				'title' => '隐藏/显示文章收藏按钮',
				'default' => true,
			),
			array(
				'id' => 'single_cop',
				'type' => 'switcher',
				'title' => '隐藏/显示底部版权',
				'default' => true,
			),
			array(
				'id' => 'single_cop_text',
				'dependency' => array('single_cop', '==', 'true'),
				'type' => 'textarea',
				'title' => '版权文字',
			),
		)
	));
	CSF::createSection($prefix, array(
		'parent' => 'too_single',
		'title' => '优化设置',
		'fields' => array(
			array(
				'id' => 'auto_add_tags',
				'type' => 'switcher',
				'title' => '自动添加已有关键词 ',
				'default' => false,
			),
			array(
				'id' => 'single_tag_link',
				'type' => 'switcher',
				'title' => 'Tag标签自动内链 ',
				'default' => false,
			),
			array(
				'id' => 'single_nofollow',
				'type' => 'switcher',
				'title' => '文章外链自动添加nofollow',
				'default' => true,
				'subtitle' => '防止导出权重',
			),
			array(
				'id' => 'single_img_alt',
				'type' => 'switcher',
				'title' => '图片自动添加alt',
				'default' => true,
			),
			array(
				'id' => 'single_upload_filter',
				'type' => 'switcher',
				'title' => '上传文件重命名',
				'default' => true,
			),
			array(
				'id' => 'single_delete_post_and_img',
				'type' => 'switcher',
				'title' => '删除文章时删除图片附件',
				'default' => true,
			),

		)
	));

	/*
	 * 优化设置
	 * */
	CSF::createSection($prefix, array(
		'id' => 'too_optimization',
		'title' => '优化设置',
	));
	CSF::createSection($prefix, array(
		'parent' => 'too_optimization',
		'title' => '优化加速',
		'fields' => array(
			array(
				'id' => 'gtb_editor',
				'type' => 'switcher',
				'title' => '禁用古腾堡编辑器',
				'default' => true,
				'subtitle' => '古腾堡用不习惯吗？那就关闭吧！(默认关闭)',
			),
			array(
				'id' => 'diable_revision',
				'type' => 'switcher',
				'title' => '屏蔽文章修订',
				'default' => true,
				'subtitle' => '屏蔽文章修订',
			),
			array(
				'id' => 'googleapis',
				'type' => 'switcher',
				'title' => '后台禁止加载谷歌字体',
				'default' => true,
				'subtitle' => '后台禁止加载谷歌字体，加快后台访问速度',
			),
			array(
				'id' => 'category',
				'type' => 'switcher',
				'title' => '去掉分类目录中的category',
				'default' => true,
				'subtitle' => '去掉分类目录中的category，精简URL，有利于SEO，推荐去掉',
			),
			array(
				'id' => 'emoji',
				'type' => 'switcher',
				'title' => '禁用emoji表情',
				'default' => true,
				'subtitle' => '禁用WordPress的Emoji功能和禁止head区域Emoji css加载',
			),
			array(
				'id' => 'article_revision',
				'type' => 'switcher',
				'title' => '屏蔽文章修订功能',
				'default' => true,
				'subtitle' => '文章多，修订次数的用户建议关闭此功能',
			),
		)
	));
	CSF::createSection($prefix, array(
		'parent' => 'too_optimization',
		'title' => '精简头部',
		'fields' => array(
			array(
				'id' => 'toolbar',
				'type' => 'switcher',
				'title' => '移除顶部工具条',
				'default' => true,
				'subtitle' => '这个大家应该都懂',
			),
			array(
				'id' => 'rest_api',
				'type' => 'switcher',
				'title' => '禁用REST API',
				'default' => false,
				'subtitle' => '不准备打通WordPress小程序的用户建议关闭',
			),
			array(
				'id' => 'wpjson',
				'type' => 'switcher',
				'title' => '移除wp-json链接代码',
				'default' => true,
				'subtitle' => '移除头部区域wp-json链接代码，精简头部区域代码',
			),
			array(
				'id' => 'emoji_script',
				'type' => 'switcher',
				'title' => '移除头部多余Emoji JavaScript代码',
				'default' => true,
				'subtitle' => '移除头部多余Emoji JavaScript代码，精简头部区域代码',
			),
			array(
				'id' => 'wp_generator',
				'type' => 'switcher',
				'title' => '移除头部WordPress版本',
				'default' => true,
				'subtitle' => '移除头部WordPress版本，精简头部区域代码',
			),
			array(
				'id' => 'rsd_link',
				'type' => 'switcher',
				'title' => '移除离线编辑器开放接口',
				'default' => true,
				'subtitle' => '移除WordPress自动添加两行离线编辑器的开放接口，精简头部区域代码',
			),
			array(
				'id' => 'index_rel_link',
				'type' => 'switcher',
				'title' => '清除前后文、第一篇文章、主页meta信息',
				'default' => true,
				'subtitle' => 'WordPress把前后文、第一篇文章和主页链接全放在meta中。我认为于SEO帮助不大，反使得头部信息巨大，建议移出。',
			),
			array(
				'id' => 'feed',
				'type' => 'switcher',
				'title' => '移除文章、分类和评论feed',
				'default' => true,
				'subtitle' => '移除文章、分类和评论feed，精简头部区域代码。',
			),
			array(
				'id' => 'dns_prefetch',
				'type' => 'switcher',
				'title' => '移除头部加载DNS预获取',
				'default' => true,
				'subtitle' => '移出head区域dns-prefetch代码，精简头部区域代码。',
			),

		)
	));

}