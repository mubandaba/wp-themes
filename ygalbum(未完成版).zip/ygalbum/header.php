<!DOCTYPE html>
<html <?php language_attributes(); ?> >
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>" />
		<meta name="applicable-device"content="pc,mobile">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<?php include_once("inc/functions/seo.php"); ?>
		<?php wp_head();?>
<link rel="shortcut icon" href="<?php echo _aye('favicon'); ?>"/>
    <script>
        var _hmt = _hmt || [];
        (function() {
          var hm = document.createElement("script");
          hm.src = "https://hm.baidu.com/hm.js?3a4bb04719ed1fb44f02e06f2c44aeba";
          var s = document.getElementsByTagName("script")[0]; 
          s.parentNode.insertBefore(hm, s);
        })();
    </script>
	</head>
	<body>
		<div class="wmpic">
			<header class="header uk-background-default">
				<div class="navbar uk-container uk-flex uk-flex-middle">
					<a href="<?php bloginfo('url'); ?>" class="logo uk-display-inline-block">
					    <img src="<?php echo _aye('head_logo');?>" alt="<?php bloginfo('name'); ?>"/>
					</a>
					<ul class="nav uk-flex-1 uk-text-center uk-visible@s">
					    <?php yg_menu('head-nav'); ?>
					</ul>
					<div class="uk-margin-left uk-flex uk-position-relative">
					    <div class="search uk-margin uk-margin-remove-bottom">
                        	<form method="get" class="b-a uk-form uk-flex uk-overflow-hidden" action="/">
                        		<input type="search" placeholder="输入关键字搜索" autocomplete="off" value="" name="s" required="required" class="uk-input uk-text-small">
                        		<button type="submit"><i class="iconfont icon-sousuo"></i></button>
                        	</form>
                        </div>
					</div>
				</div>
			</header>
			<!-- 头部 -->
			<main class="uk-container uk-margin-top uk-margin-medium-bottom">