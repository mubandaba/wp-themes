<section class="part uk-background-default uk-margin-bottom">
	<div class="title b-b">
		<span><?php echo _aye('side_art_title'); ?></span>
	</div>
    <div class="hotArt uk-margin uk-margin-remove-bottom">
        <?php
		$side_art_num = _aye('side_art_num');
		$cat = get_the_category();
		foreach($cat as $key=>$category){
			$catid = $category->term_id;
		}
		$args = array(
		    'ignore_sticky_posts' => 1,
			'meta_key' => 'views',
			'orderby' => 'meta_value_num',
		    'showposts' => 5 ,
		    'cat' => $catid 
		);
		$query_posts = new WP_Query();
		$query_posts->query($args);
		while ($query_posts->have_posts()) : $query_posts->the_post();
		?>
        <div class="item b-b uk-margin-bottom">
    		<div class="uk-grid-collapse" uk-grid>
    		    <div class="cover b-a uk-width-auto">
    			<a href="<?php the_permalink(); ?>" target="_blank" class="uk-display-block uk-overflow-hidden"><img src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title();?>"/></a>
    			</div>
    			<div class="uk-width-expand uk-margin-small-left">
    				<a href="<?php the_permalink(); ?>" target="_blank"><?php the_title();?></a>
    				<div class="uk-text-small uk-text-muted">
    					<span class="uk-margin-right"><i class="iconfont icon-yanjing"></i><?php post_views('', ''); ?></span>
    					<span><i class="iconfont icon-xiaoxi"></i><?php echo $post->comment_count; ?></span>
    				</div>
    			</div>
    		</div>
    	</div>
    	<?php endwhile; wp_reset_query(); ?>
    </div>
</section>
<!-- 侧边栏热门文章模块 -->
	