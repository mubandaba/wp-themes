<div class="part uk-background-default uk-margin-bottom">
	<div class="title b-b">
		<span><?php echo _aye('side_search_title'); ?></span>
	</div>
	<div class="search uk-margin uk-margin-remove-bottom">
		<form method="get" class="b-r-4 b-a uk-form uk-flex uk-overflow-hidden" action="/">
			<input type="search" placeholder="输入关键字搜索" autocomplete="off" value="" name="s" required="required" class="uk-input uk-text-small">
			<button type="submit"><i class="iconfont icon-sousuo"></i></button>
		</form>
	</div>
	<?php
	$side_search_tags = _aye('side_search_tags');if($side_search_tags){ ?>
	<div class="tags sideTags uk-margin-top">
	    <?php
    		$side_tag_num =  _aye('side_search_tags_num');
    		$tags_list = get_tags( array('number' => $side_tag_num, 'hide_empty' => false) );
    		$count=0; 
    		if ($tags_list) {
    			foreach($tags_list as $tag) {
    				$count++;
    				echo '<a uk-tooltip="' . $tag->count . '个相关文章" href="'.get_tag_link($tag->term_id).'" target="_blank">'.$tag->name.'</a>';
    				if( $count > $side_tag_num ) break;
    			}
    		}
		?>
	</div>
	<?php } ?>
</div>