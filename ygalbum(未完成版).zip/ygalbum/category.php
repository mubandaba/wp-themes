<?php
    $category = get_the_category();//默认获取当前所属分类
	$category_parent = $category[0]->category_parent;
    if(get_term_meta( $category[0]->cat_ID , 'cat_theme', true ) == 1) {
        get_template_part( 'category/category', 'tx' );
    }elseif(get_term_meta( $category[0]->cat_ID , 'cat_theme', true ) == 3){
        get_template_part( 'category/category', 'wz' );
    }else {
        get_template_part( 'category/category', 'tp' );
    }
?>


