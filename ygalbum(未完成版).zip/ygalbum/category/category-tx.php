<?php get_header(); ?>
<section class="part uk-background-default">
	<?php get_template_part( 'category/category', 'top' ); ?>
	<div class="part-content part-tx">
		<div class="uk-grid-small" uk-grid="masonry: true">
		    <?php if(have_posts()) : while (have_posts()) : the_post(); ?>
		    <div class="uk-width-1-2 uk-width-1-5@m uk-width-1-5@xl">
			<?php get_template_part( 'template-parts/loop', 'tx' ); ?>
			</div>
			<?php endwhile; else: ?>
        	<div class="uk-width-1-1">
        		<div class="uk-alert-primary uk-width-1-2 uk-container" uk-alert>
        			<a class="uk-alert-close" uk-close></a>
        			<p class="uk-padding-small uk-text-center">暂无内容！</p>
        		</div>
        	</div>
        
        	<?php endif; ?>
		</div>
	</div>
	<div class="part-more b-t uk-flex uk-flex-middle">
    	<div class="fenye">
        	<?php fenye(); ?>
        </div>
	</div>
</section>

<?php get_footer(); ?>