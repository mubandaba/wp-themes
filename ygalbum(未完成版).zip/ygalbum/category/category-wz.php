<?php get_header(); ?>
<section class="part uk-background-default">
	<?php get_template_part( 'category/category', 'top' ); ?>
	<div class="part-content">
		<ul class="uk-grid-medium" uk-grid>
		    <?php if(have_posts()) : while (have_posts()) : the_post(); ?>
			<?php get_template_part( 'template-parts/loop', 'wz' ); ?>
			<?php endwhile; else: ?>
        	<div class="uk-width-1-1">
        		<div class="uk-alert-primary uk-width-1-2 uk-container" uk-alert>
        			<a class="uk-alert-close" uk-close></a>
        			<p class="uk-padding-small uk-text-center">暂无内容！</p>
        		</div>
        	</div>
        
        	<?php endif; ?>
		</ul>
	</div>
	<div class="part-more b-t uk-flex uk-flex-middle">
    	<div class="fenye">
        	<?php fenye(); ?>
        </div>
	</div>
	
</section>

<?php get_footer(); ?>