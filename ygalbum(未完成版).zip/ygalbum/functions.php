<?php

include TEMPLATEPATH.'/inc/functions.php';