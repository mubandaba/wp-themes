<?php 
    $cat_ID = 3;
?>
<section class="uk-background-default uk-margin-top">
	<div class="part-head uk-grid-collapse" uk-grid>
		<div class="uk-width-expand">
			<div class="part-head-text">
				<a href="<?php echo _aye('home_title_link'); ?>" target="_blank" class="uk-display-block juzi"><?php echo _aye('home_title'); ?></a>
				<span class="uk-text-small uk-text-muted"><?php echo _aye('home_des');?></span>
			</div>
		</div>
		<div class="uk-width-auto uk-visible@s">
    		<div class="part-head-img uk-text-center">
    		    <a href="/33.html" target="_blank" class="uk-display-inline-block" uk-tooltip="温柔女头／御姐／干净">
    		        <img src="http://www.mcc.pub/wp-content/uploads/2020/06/20200622094810100.jpeg" alt="温柔女头／御姐／干净"/>
    		    </a>
    		    <a href="https://www.wmpic.com/191.html" target="_blank" class="uk-display-inline-block" uk-tooltip="扫码体验「唯美图片」微信小程序">
    		        <img src="https://www.wmpic.com/wp-content/uploads/2020/06/2020061408253244.jpg" class="b-a" alt="扫码体验「唯美图片」微信小程序" style="width:86px;height:86px;padding:5px"/>
    		    </a>
    		    <a href="https://www.wmpic.com/2562.html" target="_blank" class="uk-display-inline-block" uk-tooltip="可爱迷人的小姐姐头像">
    		        <img src="https://img.wmpic.com/wp-content/uploads/2020/06/6f8060717c414cf0b58853717a1db06e400x400.jpeg" alt="唯美女生头像：可爱且迷人的小姐姐头像"/>
    		    </a>
    		</div>
    	</div>
	</div>
	<div class="part-nav b-t b-b uk-grid-collapse" uk-grid>
		<span class="uk-width-auto"><?php echo get_cat_name($cat_ID); ?></span>
		<ul class="uk-width-expand uk-text-right uk-margin-left">
			<?php wp_list_categories('title_li=&hierarchical=1&hide_empty=0&child_of='.$cat_ID); ?>
		</ul>
	</div>
	<div class="part-content part-tx">
		<div class="uk-grid-small" uk-grid>
		    <?php query_posts('cat='.$cat_ID.'&showposts=10' ); ?>
			<?php while (have_posts()) : the_post(); ?>
			<div class="uk-width-1-2 uk-width-1-5@m uk-width-1-5@xl">
			<?php get_template_part( 'template-parts/loop', 'tx' ); ?>
			</div>
			<?php endwhile; wp_reset_query(); ?>
		</div>
	</div>
	<div class="part-more b-t uk-flex uk-flex-middle">
		<a href="<?php echo get_category_link($cat_ID); ?>" target="_blank" class="primary-btn uk-display-inline-block uk-text-small">查看更多<i class="iconfont icon-arrow-right"></i></a>
		<div class="uk-flex-1 uk-text-right uk-text-muted uk-text-small">共 <span class="uk-text-warning"><?php echo get_category($cat_ID)->count;?></span> 个头像帖</div>
	</div>
</section>