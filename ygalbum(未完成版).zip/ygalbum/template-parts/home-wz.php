<?php 
    $cat_ID = 4;
?>
<section class="uk-background-default uk-margin-top">
	<div class="part-nav b-t b-b uk-flex uk-flex-middle">
		<span><?php echo get_cat_name($cat_ID); ?></span>
		<ul class="uk-flex-1 uk-text-right uk-margin-remove">
        	<?php wp_list_categories('title_li=&hierarchical=1&hide_empty=0&child_of=15'); ?>
		</ul>
	</div>
	<div class="part-content" uk-grid>
	    <?php query_posts('cat='.$cat_ID.'&showposts=10' ); ?>
		<?php while (have_posts()) : the_post(); ?>
		<?php get_template_part( 'template-parts/loop', 'wz' ); ?>
		<?php endwhile; wp_reset_query(); ?>
	</div>
	<div class="part-more b-t uk-flex uk-flex-middle">
		<a href="<?php echo get_category_link($cat_ID); ?>" target="_blank" class="primary-btn uk-display-inline-block uk-text-small">查看更多<i class="iconfont icon-arrow-right"></i></a>
		<div class="uk-flex-1 uk-text-right uk-text-muted uk-text-small">共 <span class="uk-text-warning"><?php echo get_category($cat_ID)->count;?></span> 帖子</div>
	</div>
</section>