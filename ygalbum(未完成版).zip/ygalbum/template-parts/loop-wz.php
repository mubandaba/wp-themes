<div class="uk-width-1-1 uk-width-1-2@m uk-width-1-2@xl">
	<div class="blog b-a uk-padding-small">
		<div class="uk-grid-small" uk-grid>
			<div class="uk-width-1-1 uk-width-expand@xl">
				<a href="<?php the_permalink(); ?>" target="_blank" class="title uk-display-block uk-text-truncate"><?php the_title(); ?></a>
				<p class="uk-margin-small uk-text-small uk-text-muted"><?php echo get_the_excerpt(); ?></p>
				<div class="uk-text-small uk-text-muted">
					<span class="author uk-margin-right"><?php the_author_posts_link(); ?></span>
					<span><?php the_time('m-d') ?></span>
				</div>
			</div>
			<div class="uk-width-1-1 uk-width-auto@xl uk-visible@s">
				<a href="<?php the_permalink(); ?>" target="_blank" class="thumb uk-display-block uk-overflow-hidden">
					<img src="<?php echo post_thumbnail_src() ?>" alt="<?php the_title(); ?>" />
				</a>
			</div>
		</div>
	</div>
</div>