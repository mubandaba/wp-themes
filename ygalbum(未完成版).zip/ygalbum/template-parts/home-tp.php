<?php 
    $cat_ID = '1';
?>
<section class="uk-background-default uk-margin-top">
	<div class="part-nav b-t b-b uk-flex uk-flex-middle">
		<span><?php echo get_cat_name($cat_ID); ?></span>
		<ul class="uk-flex-1 uk-text-right uk-margin-remove">
			<?php wp_list_categories('title_li=&hierarchical=1&hide_empty=0&child_of='.$cat_ID); ?>
		</ul>
	</div>
	<div class="part-content part-img">
		<div class="ajax-main uk-grid-small" uk-grid="masonry: true">
		    <?php query_posts('cat='.$cat_ID.'&showposts=30' ); ?>
		    <?php while (have_posts()) : the_post(); ?>
		    <div class="ajax-item uk-width-1-2 uk-width-1-4@m uk-width-1-4@xl">
			<?php get_template_part( 'template-parts/loop', 'tp' ); ?>
			</div>
			<?php endwhile; wp_reset_query(); ?>
		</div>
	</div>
	<div class="part-more b-t uk-flex uk-flex-middle">
	    <a href="<?php echo get_category_link($cat_ID); ?>" target="_blank" class="primary-btn uk-display-inline-block uk-text-small">查看更多<i class="iconfont icon-arrow-right"></i></a>
	    <div class="uk-flex-1 uk-text-right uk-text-muted uk-text-small">共 <span class="uk-text-warning"><?php echo get_category($cat_ID)->count;?></span> 个唯美图片帖</div>
	    <!--<div id="pagination" class="uk-width-1-1 uk-text-center">
		<?php next_posts_link(__('点击查看更多')); ?>
		</div>-->
	</div>
</section>