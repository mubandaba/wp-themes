        </main>
		<footer class="uk-background-default uk-padding-large">
		    <div class="foot uk-container">
				<div class="b-b uk-flex">
			    	<?php 
    					wp_nav_menu( array(
    						'theme_location' => 'foot-nav', //用于在调用导航菜单时指定注册过的某一个导航菜单名，如果没有指定，则显示第一个
    						'container'  => '',  //容器标签
    						'menu_class' => 'db uk-margin-remove uk-flex-1', //ul节点class值
    						'echo'  => true,//是否输出菜单，默认为真
    					) );
    				?>
					<div class="share uk-visible@s">
						<i class="iconfont icon-QQ"></i>
						<i class="iconfont icon-wechat-fill"></i>
						<i class="iconfont icon-weibo1"></i>
					</div>
				</div>
				<div class="uk-text-small uk-text-muted uk-flex uk-padding-small uk-padding-remove-horizontal">
					<div class="cop uk-flex-1">
						<span><a href="http://www.beian.miit.gov.cn/" target="_blank" rel="nofollow"><?php echo _aye('foot_beian'); ?></a></span>
						<span><?php echo _aye('foot_text'); ?></span>
						<?php if(_aye('load_time') == true): ?>
                        <span class="uk-margin-right">共 <?php echo get_num_queries(); ?> 次Sql咨询，耗时 <?php timer_stop(1); ?> 秒</span>
                        <?php endif; ?>
					</div>
					<?php if(_aye('theme_cop') == true): ?>
					<span class="theme uk-visible@s">Theme By <a href="<?php bloginfo('url'); ?>" target="_blank">有个主题(ygtheme.com)</a></span>
					<?php endif; ?>
				</div>
			</div>
			<script>
	             (function(){
                    var bp = document.createElement('script');
                    var curProtocol = window.location.protocol.split(':')[0];
                    if (curProtocol === 'https') {
                        bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
                    }
                    else {
                        bp.src = 'http://push.zhanzhang.baidu.com/push.js';
                    }
                    var s = document.getElementsByTagName("script")[0];
                    s.parentNode.insertBefore(bp, s);
                })();
			</script>
		</footer>
	    <?php wp_footer(); ?>
	</body>

</html>