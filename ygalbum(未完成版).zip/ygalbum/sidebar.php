<div class="sidebar uk-margin-bottom">
	
	<?php 
	$sidebar_layout = _aye('sidebar_layout');
	if (is_array( $sidebar_layout) ):

	if ($sidebar_layout) {
		foreach ($sidebar_layout['enabled'] as $key => $value) {
			get_template_part( 'sidebar/sidebar', $key );
		}
	}
	endif; ?>
	
</div>
