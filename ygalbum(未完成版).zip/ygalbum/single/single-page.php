<?php
	$categories = get_the_category();
	$categoryIDS = array();
	foreach ($categories as $category) {
	array_push($categoryIDS, $category->term_id);
	}
	$categoryIDS = implode(",", $categoryIDS);
?>
<div class="uk-margin" uk-grid>
	<div class="uk-width-1-2 uk-text-truncate">
		<i class="iconfont icon-arrow-lift uk-margin-right"></i>
		<?php if (get_previous_post($categoryIDS)) { previous_post_link('%link','%title',true);} else { echo "已是最后文章";} ?>
	</div>
	<div class="uk-width-1-2 uk-text-truncate uk-text-right">
		<?php if (get_next_post($categoryIDS)) { next_post_link('%link','%title',true);} else { echo "已是最新文章";} ?><i class="iconfont icon-arrow-right uk-margin-left"></i>
	</div>
</div>