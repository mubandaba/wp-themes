<?php get_header(); ?>
<div id="page" class="clearfloat">
<div id="center">

<div class="col">
<div id="newest" class="fr">
<h2><?php bloginfo('name'); ?>最新文章推荐</h2><ul>
<?php while (have_posts()) : the_post(); ?>
<li><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>" target="_blank"><?php the_title(); ?></a>&nbsp;&nbsp;(<?php the_time('m-d') ?>)</li>
<?php endwhile; ?>
</ul></div>
<?php include (TEMPLATEPATH . '/slider.php'); ?>
</div><!--END COL-->

<div class="col">
<div class="col1">
<?php $display_categories = array(1,1); foreach ($display_categories as $category) { ?>
<div class="catlist"><?php query_posts("showposts=5&cat=$category"); $wp_query->is_category = false; $wp_query->is_archive = false; $wp_query->is_home = true; ?>
<h3><a href="<?php echo get_category_link($category);?>" target="_blank"><?php single_cat_title(); ?></a><span><a href="<?php echo get_category_link($category);?>" target="_blank">更多>></a></span></h3><ul>
<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>
<li><a href="<?php the_permalink() ?>" target="_blank"><?php the_title(); ?></a></li>
<?php endwhile; ?><?php else : ?><br />&nbsp;&nbsp;&nbsp;此分类暂无内容
<?php endif; ?></ul></div><?php } ?>
</div><!--END COL LEFT-->
<div class="col2">
<?php $display_categories = array(1,1); foreach ($display_categories as $category) { ?>
<div class="catlist"><?php query_posts("showposts=5&cat=$category"); $wp_query->is_category = false; $wp_query->is_archive = false; $wp_query->is_home = true; ?>
<h3><a href="<?php echo get_category_link($category);?>" target="_blank"><?php single_cat_title(); ?></a><span><a href="<?php echo get_category_link($category);?>" target="_blank">更多>></a></span></h3><ul>
<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>
<li><a href="<?php the_permalink() ?>" target="_blank"><?php the_title(); ?></a></li>
<?php endwhile; ?><?php else : ?><br />&nbsp;&nbsp;&nbsp;此分类暂无内容
<?php endif; ?></ul></div><?php } ?>
</div><!--END COL RIGHT-->
</div><!--END COL-->

<div class="col">
<div class="col1">
<div class="banner"><?php include (TEMPLATEPATH . '/ads300x60x1.php'); ?></div>
<?php $display_categories = array(1,1); foreach ($display_categories as $category) { ?>
<div class="catlist"><?php query_posts("showposts=5&cat=$category"); $wp_query->is_category = false; $wp_query->is_archive = false; $wp_query->is_home = true; ?>
<h3><a href="<?php echo get_category_link($category);?>" target="_blank"><?php single_cat_title(); ?></a><span><a href="<?php echo get_category_link($category);?>" target="_blank">更多>></a></span></h3><ul>
<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>
<li><a href="<?php the_permalink() ?>" target="_blank"><?php the_title(); ?></a></li>
<?php endwhile; ?><?php else : ?><br />&nbsp;&nbsp;&nbsp;此分类暂无内容
<?php endif; ?></ul></div><?php } ?>
</div><!--END COL LEFT-->
<div class="col2">
<div class="banner"><?php include (TEMPLATEPATH . '/ads300x60x2.php'); ?></div>
<?php $display_categories = array(1,1); foreach ($display_categories as $category) { ?>
<div class="catlist"><?php query_posts("showposts=5&cat=$category"); $wp_query->is_category = false; $wp_query->is_archive = false; $wp_query->is_home = true; ?>
<h3><a href="<?php echo get_category_link($category);?>" target="_blank"><?php single_cat_title(); ?></a><span><a href="<?php echo get_category_link($category);?>" target="_blank">更多>></a></span></h3><ul>
<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>
<li><a href="<?php the_permalink() ?>" target="_blank"><?php the_title(); ?></a></li>
<?php endwhile; ?><?php else : ?><br />&nbsp;&nbsp;&nbsp;此分类暂无内容
<?php endif; ?></ul></div><?php } ?>
</div><!--END COL RIGHT-->
</div><!--END COL-->

<div class="col">
<div class="col1">
<div class="banner"><?php include (TEMPLATEPATH . '/ads300x60x3.php'); ?></div>
<?php $display_categories = array(1,1); foreach ($display_categories as $category) { ?>
<div class="catlist"><?php query_posts("showposts=5&cat=$category"); $wp_query->is_category = false; $wp_query->is_archive = false; $wp_query->is_home = true; ?>
<h3><a href="<?php echo get_category_link($category);?>" target="_blank"><?php single_cat_title(); ?></a><span><a href="<?php echo get_category_link($category);?>" target="_blank">更多>></a></span></h3><ul>
<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>
<li><a href="<?php the_permalink() ?>" target="_blank"><?php the_title(); ?></a></li>
<?php endwhile; ?><?php else : ?><br />&nbsp;&nbsp;&nbsp;此分类暂无内容
<?php endif; ?></ul></div><?php } ?>
</div><!--END COL LEFT-->
<div class="col2">
<div class="banner"><?php include (TEMPLATEPATH . '/ads300x60x4.php'); ?></div>
<?php $display_categories = array(1,1); foreach ($display_categories as $category) { ?>
<div class="catlist"><?php query_posts("showposts=5&cat=$category"); $wp_query->is_category = false; $wp_query->is_archive = false; $wp_query->is_home = true; ?>
<h3><a href="<?php echo get_category_link($category);?>" target="_blank"><?php single_cat_title(); ?></a><span><a href="<?php echo get_category_link($category);?>" target="_blank">更多>></a></span></h3><ul>
<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>
<li><a href="<?php the_permalink() ?>" target="_blank"><?php the_title(); ?></a></li>
<?php endwhile; ?><?php else : ?><br />&nbsp;&nbsp;&nbsp;此分类暂无内容
<?php endif; ?></ul></div><?php } ?>
</div><!--END COL RIGHT-->
</div><!--END COL-->

</div><!--END CENTER-->

<div id="left"><!--左侧开始-->
<?php include (TEMPLATEPATH . '/sidebar1.php'); ?>
</div><!--左侧结束-->

<div id="right"><!--右侧开始-->
<?php include (TEMPLATEPATH . '/sidebar2.php'); ?>
</div><!--右侧结束-->

</div><!--END PAGE-->
<?php get_footer(); ?>