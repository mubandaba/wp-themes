<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php if(is_home()) {echo "【"; bloginfo('name'); echo "】"; bloginfo('description');} else {wp_title(' -',true,'right'); echo "【"; bloginfo('name'); echo "】";} ?></title>
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />

<?php if (is_single()){
$description = $post->post_title . ", " . $post->post_excerpt ;
$tags = wp_get_post_tags($post->ID);
foreach ($tags as $tag ){
$keywords = $keywords . $tag->name .", ";}
} else {
$description = get_bloginfo('name') . ", " . get_bloginfo('description');
} $keywords = $keywords . get_bloginfo('name') ;
?>
<meta name="description" content="<?=$description?>" />
<meta name="keywords" content="<?=$keywords?>" />

<?php wp_head(); ?>
</head><body>

<div id="mininav" class="ar clearfloat"></script><script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/language.js"></script></div>

<div id="header" class="clearfloat"><div id="header_l">
<div id="logo" class="fl"><a href="<?php echo get_option('home'); ?>/" title="<?php bloginfo('name'); ?>"><img src="<?php bloginfo('template_directory'); ?>/image/logo.png" alt="<?php bloginfo('name'); ?>" /></a></div>
<div id="siteinfo">
<div id="sitename" style="letter-spacing:5px"><h1><a href="<?php echo get_option('home'); ?>/" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a></h1></div>
<div id="sitedesc" style="letter-spacing:1px"><?php bloginfo('description'); ?></div>
</div></div><div id="header_r">
<a href="javascript:window.external.AddFavorite('<?php echo get_option('home'); ?>', '<?php bloginfo('name'); ?>')">收藏本站</a> | 
<a href="#" onclick="this.style.behavior='url(#default#homepage)';this.sethomepage('<?php echo get_option('home'); ?>');return false;">设为首页</a><br />
<!-- 此处请修改或删除 --><a href="#" target="_blank">邮件订阅</a> | <a href="<?php bloginfo('rss2_url'); ?>" target="_blank">Rss订阅</a>
</div></div>

<div class="nav avt clearfloat">
<li<?php if ( is_home() ) { ?> class="on"<?php } ?>><a href="<?php echo get_option('home'); ?>/">首页</a></li> 
<?php wp_list_categories('orderby=id&hide_empty=0&title_li='); ?>
</div>
