<?php get_header(); ?>
<div id="page" class="clearfloat">

<div id="center">
<div class="col">
<div class="post">
<h2>暂无内容</h2>
<center><br/>抱歉！您所浏览的页面暂无内容。<br/><br/>可能页面正在制作中；<br/><br/>可能已经更名或迁移；<br/><br/>也可能该页并未存在过。<br/><br/><br/>您可<a href="<?php echo get_option('home'); ?>/">返回首页</a>，或试试搜索：<br/><br/>
<?php include (TEMPLATEPATH . '/searchform.php'); ?>
</center></div><!--END POST-->
</div><!--END COL-->
</div><!--END CENTER-->

<div id="left"><!--左侧开始-->
<?php include (TEMPLATEPATH . '/sidebar1.php'); ?>
</div><!--左侧结束-->

<div id="right"><!--右侧开始-->
<?php include (TEMPLATEPATH . '/sidebar2.php'); ?>
</div><!--右侧结束-->

</div><!--END PAGE-->
<?php get_footer(); ?>