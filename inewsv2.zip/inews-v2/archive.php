<?php get_header(); ?>
<div id="page" class="clearfloat">
<div id="center">

<div class="col">
<?php if (have_posts()) : ?>
<?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
<?php /* If this is a category archive */ if (is_category()) { ?>
<h2 class="pagetitle">【<?php single_cat_title(); ?>】分类文章列表</h2>
<?php /* If this is a tag archive */ } elseif( is_tag() ) { ?>
<h2 class="pagetitle">【<?php single_tag_title(); ?>】标签文章列表</h2>
<?php /* If this is a daily archive */ } elseif (is_day()) { ?>
<h2 class="pagetitle">【<?php the_time('Y年m月d日') ?>】当日文章列表</h2>
<?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
<h2 class="pagetitle">【<?php the_time('Y年m月') ?>】当月文章列表</h2>
<?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
<h2 class="pagetitle">【<?php the_time('Y年') ?>】全年文章列表</h2>
<?php /* If this is an author archive */ } elseif (is_author()) { ?>
<h2 class="pagetitle">Author Archive</h2>
<?php /* If this is a paged archive */ } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
<h2 class="pagetitle">Blog Archives</h2>
<?php } ?>

<?php while (have_posts()) : the_post(); ?>
<div class="postlist" id="post-<?php the_ID(); ?>"><h4><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a><span><a href="<?php the_permalink() ?>">阅读全文&raquo;</a></span></h4>
<div class="postcontent"><?php the_excerpt(); ?></div><div class="postmeat al">日期：<?php the_time('Y年m月d日') ?>  | 分类：<?php the_category(', ') ?></div>
</div>
<?php endwhile; ?>

<div class="navigation clearfloat">
<div class="fr"><?php next_posts_link('下一页 &raquo;') ?></div>
<div class="fl"><?php previous_posts_link('&laquo; 上一页') ?></div>
</div>

<?php else : ?>
<div class="post">
<h2>暂无内容</h2>
<center><br/>抱歉！您所浏览的页面暂无内容。<br/><br/>可能页面正在制作中；<br/><br/>可能已经更名或迁移；<br/><br/>也可能该页并未存在过。<br/><br/><br/>您可<a href="<?php echo get_option('home'); ?>/">返回首页</a>，或试试搜索：<br/><br/>
<?php include (TEMPLATEPATH . '/searchform.php'); ?>
</center></div><!--END POST-->

<?php endif; ?>
</div><!--END COL-->
</div><!--END CENTER-->

<div id="left"><!--左侧开始-->
<?php include (TEMPLATEPATH . '/sidebar1.php'); ?>
</div><!--左侧结束-->

<div id="right"><!--右侧开始-->
<?php include (TEMPLATEPATH . '/sidebar2.php'); ?>
</div><!--右侧结束-->

</div><!--END PAGE-->
<?php get_footer(); ?>