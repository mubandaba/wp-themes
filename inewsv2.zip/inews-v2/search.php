<?php get_header(); ?>
<div id="page" class="clearfloat">
<div id="center">

<div class="col">
<?php if (have_posts()) : ?>
<h2 class="pagetitle">搜索到与"<?php the_search_query(); ?>"相关的文章如下：</h2>
<?php while (have_posts()) : the_post(); ?>
<div class="postlist" id="post-<?php the_ID(); ?>"><h4><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a><span><a href="<?php the_permalink() ?>">阅读全文&raquo;</a></span></h4>
<div class="postcontent"><?php the_excerpt(); ?></div><div class="postmeat al">日期：<?php the_time('Y年m月d日') ?>  | 分类：<?php the_category(', ') ?></div>
</div>
<?php endwhile; ?>

<div class="navigation clearfloat">
<div class="fr"><?php next_posts_link('下一页 &raquo;') ?></div>
<div class="fl"><?php previous_posts_link('&laquo; 上一页') ?></div>
</div>

<?php else : ?>
<div class="post">
<h2>什么也没找到</h2>
<center><br/>抱歉！没找到与"<?php the_search_query(); ?>"相关的文章。<br/><br/>是否试试搜索其它关键词？<br/><br/>
<?php include (TEMPLATEPATH . '/searchform.php'); ?>
</center></div><!--END POST-->

<?php endif; ?>
</div><!--END COL-->
</div><!--END CENTER-->

<div id="left"><!--左侧开始-->
<?php include (TEMPLATEPATH . '/sidebar1.php'); ?>
</div><!--左侧结束-->

<div id="right"><!--右侧开始-->
<?php include (TEMPLATEPATH . '/sidebar2.php'); ?>
</div><!--右侧结束-->

</div><!--END PAGE-->
<?php get_footer(); ?>