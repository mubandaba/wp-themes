<div id="sidebar">
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('sidebar') ) : ?><p><?php _e('请到后台设置小工具!');?></p><?php endif; ?>
</div><!-- end #sidebar -->