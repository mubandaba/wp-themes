<?php 
/*
Template Name: 视频 页面
*/
get_header();
?>

<div id="content">
	<div class="video-content">
		<?php the_youku();?>		
	</div>	
</div>
<?php get_footer(); ?>