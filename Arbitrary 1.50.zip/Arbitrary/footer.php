<div id="footer">
	<div class="container">
		<p>©2013<?php bloginfo('name'); ?> <?php bloginfo('description'); ?>。</p>
	</div>
</div><!-- #footer -->
<?php if( IsMobile ){?>
<script type="text/javascript">
	var _id = function(_){
		return document.getElementById(_)
	};
					
	_id("mobile-menu").onclick = function(){
		if( _id("header").className == "selected" ){
			_id("header").className = ""
		}else{
			_id("header").className = "selected"
		}
	};
	
	for(var i=0; i< document.images.length; i++){
		document.images[i].removeAttribute("width");
		document.images[i].removeAttribute("height");
	}
</script>
<?php }?>
<?php wp_footer(); ?>
</body>
</html>