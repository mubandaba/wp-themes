<?php
/**
 * Theme functions file
 *
 *
 * @package Mfthemes
 * @author Mufeng
 */
 
// Theme-specific files
require( dirname(__FILE__) . '/functions/mfthemes-function.php' );
