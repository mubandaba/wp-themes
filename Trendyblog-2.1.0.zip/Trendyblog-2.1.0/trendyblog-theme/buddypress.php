<?php 
	get_header();
	get_template_part(THEME_INCLUDES."page-buddypress");
	get_footer();
?>