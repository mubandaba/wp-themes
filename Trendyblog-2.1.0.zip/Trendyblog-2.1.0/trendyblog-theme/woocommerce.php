<?php 

	get_header();
	get_template_part(THEME_INCLUDES."page","woocommerce");
	get_footer(); 

?>