<?php
	require_once(THEME_WIDGETS_PATH.'widget-ad125x125.php');
	require_once(THEME_WIDGETS_PATH.'widget-ad300x250.php');
	require_once(THEME_WIDGETS_PATH.'widget-'.THEME_NAME.'-reviews.php');
	require_once(THEME_WIDGETS_PATH.'widget-'.THEME_NAME.'-timeline.php');
	require_once(THEME_WIDGETS_PATH.'widget-'.THEME_NAME.'-latest-posts.php');
	require_once(THEME_WIDGETS_PATH.'widget-'.THEME_NAME.'-popular-posts.php');
	require_once(THEME_WIDGETS_PATH.'widget-'.THEME_NAME.'-most-liked.php');
	require_once(THEME_WIDGETS_PATH.'widget-'.THEME_NAME.'-comments.php');


?>