<?php
global $different_themes_managment;
$differentThemes_general_options= array(
 array(
	"type" => "navigation",
	"name" => "常规设置",
	"slug" => "general"
),

array(
	"type" => "tab",
	"slug"=>'general'
),

array(
	"type" => "sub_navigation",
	"subname"=>array(
		array("slug"=>"page", "name"=>esc_html__("常规",'trendyblog-theme')), 
		array("slug"=>"blog", "name"=>esc_html__("博客",'trendyblog-theme')),
		array("slug"=>"gallery", "name"=>esc_html__("图库",'trendyblog-theme')),
		array("slug"=>"contact", "name"=>esc_html__("联系/底部",'trendyblog-theme')),
		array("slug"=>"banner_settings", "name"=>esc_html__("横幅",'trendyblog-theme'))
	)
),

/* ------------------------------------------------------------------------*
 * PAGE SETTINGS
 * ------------------------------------------------------------------------*/

 array(
	"type" => "sub_tab",
	"slug"=>'page'
),
 array(
	"type" => "row"
),

array(
	"type" => "homepage_set_test",
	"title" => "设置您的首页和文章页面！",
	"desc" => "	<p><b>您尚未为首页选择正确的模板页面。</b></p>
	<p>请确保您选择模板通过 \"拖放页面生成器\".</p>
	<br/>
	<ul>
		<li>当前首页： <a href='".esc_url(get_permalink(get_option('page_on_front')))."'>".get_the_title(get_option('page_on_front'))."</a></li>
		<li>当前博客: <a href'".esc_url(get_permalink(get_option('page_for_posts')))."'>".get_the_title(get_option('page_for_posts'))."</a></li>
	</ul>",
	"desc_2" => "<p><b>您尚未启用首页。</b></p>
	<p>要使用自定义首页，您必须先创建两个<a href='".esc_url(home_url())."/wp-admin/post-new.php?post_type=page'>新页面</a>, 其中一个分配给 \"<b>首页</b>\" 模板.给每个页面一个标题，但不要添加任何文本。</p>
	<p>然后在<a href='".esc_url(home_url())."/wp-admin/options-reading.php'>阅读设置中启用首页</a> (请参阅 \"首页显示\" 选项).  从两个下拉列表中选择您之前创建的页面并保存更改。</p>"
),
array(
	"type" => "close"
),


array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("添加logo图片",'trendyblog-theme')
),
   
array(
	"type" => "upload",
	"title" => esc_html__("添加标题logo图片",'trendyblog-theme'),
	"info" => esc_html__("建议的图像大小是467x60px",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_logo",
),      

array(
	"type" => "close"
),
 array(
	"type" => "row"
),
array(
	"type" => "select",
	"title" => "页面名称样式",
	"info" => esc_html__("仅当您将logo图像字段留空时才起作用。",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_subcount",
	"options"=>array(
		array("slug"=>"0", "name"=> esc_html__("主题颜色方案颜色中没有字符",'trendyblog-theme')), 
		array("slug"=>"1", "name"=>esc_html__("在主题配色方案有1个字符颜色",'trendyblog-theme')),
		array("slug"=>"2", "name"=>esc_html__("在主题配色方案有2个字符颜色",'trendyblog-theme')),
		array("slug"=>"3", "name"=>esc_html__("在主题配色方案有3个字符颜色",'trendyblog-theme')),
		array("slug"=>"4", "name"=>esc_html__("在主题配色方案有4个字符颜色",'trendyblog-theme')),
		array("slug"=>"5", "name"=>esc_html__("在主题配色方案有5个字符颜色",'trendyblog-theme')),
		array("slug"=>"6", "name"=>esc_html__("在主题配色方案有6个字符颜色",'trendyblog-theme')),
		array("slug"=>"7", "name"=>esc_html__("在主题配色方案有7个字符颜色",'trendyblog-theme')),
		array("slug"=>"8", "name"=>esc_html__("在主题配色方案有8个字符颜色",'trendyblog-theme')),
		array("slug"=>"9", "name"=>esc_html__("在主题配色方案有9个字符颜色",'trendyblog-theme')),
		array("slug"=>"10", "name"=>esc_html__("在主题配色方案有10个字符颜色",'trendyblog-theme')),
		),
	"std" => "6"
),
array(
	"type" => "close"
),
 array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("导出/导入主题设置",'trendyblog-theme')
),
   
array(
	"type" => "export_content",
	"title" => esc_html__("导出设置",'trendyblog-theme'),
	"section" => "management",
	"id" => $different_themes_managment->themeslug."_export"
),      
   
array(
	"type" => "import_content",
	"title" => esc_html__("导入设置",'trendyblog-theme'),
	"section" => "management",
	"id" => $different_themes_managment->themeslug."_import"
),      

array(
	"type" => "close"
),  
array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => "Favicon图标"
),
   
array(
	"type" => "upload",
	"title" => "Favicon",
	"info" => "Favicons是您在浏览器地址栏中的一些网址旁边看到的小16像素乘16像素的图片。",
	"id" => $different_themes_managment->themeslug."_favicon"
),   

array(
	"type" => "close"
),
array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("单位设置",'trendyblog-theme'),
),

array(
	"type" => "checkbox",
	"title" => esc_html__("在顶部菜单中显示搜索：",'trendyblog-theme'),
	"id"=>$different_themes_managment->themeslug."_search"
),
array(
	"type" => "checkbox",
	"title" => esc_html__("隐藏主页上的重复文章：",'trendyblog-theme'),
	"id"=>$different_themes_managment->themeslug."_duplicate"
),
   

array(
	"type" => "close"
),

array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("天气预报",'trendyblog-theme'),
),

array(
	"type" => "radio",
	"title" => esc_html__("显示天气预报：",'trendyblog-theme'),
	"id"=>$different_themes_managment->themeslug."_weather",
	"radio" => array(
		array("title" => esc_html__("显示天气预报：",'trendyblog-theme'), "value" => "on"),
		array("title" => esc_html__("显示自定义文本/链接：",'trendyblog-theme'), "value" => "link"),
		array("title" => esc_html__("显示日期：",'trendyblog-theme'), "value" => "date"),
		array("title" => esc_html__("关闭：",'trendyblog-theme'), "value" => "off")
	),
),
array(
	"type" => "title",
	"title" => "文本/链接",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_weather", "value" => "link")
	)
),
array(
	"type" => "input",
	"title" => esc_html__("文本",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_weather_text",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_weather", "value" => "link")
	)
),
array(
	"type" => "input",
	"title" => esc_html__("链接",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_weather_url",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_weather", "value" => "link")
	)
),
array(
	"type" => "checkbox",
	"title" => esc_html__("在新窗口中打开/选项卡：",'trendyblog-theme'),
	"id"=>$different_themes_managment->themeslug."_weather_target",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_weather", "value" => "link")
	)
),
array(
	"type" => "title",
	"title" => "温度类型",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_weather", "value" => "on")
	)
),
array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_temperature",
	"radio" => array(
		array("title" => esc_html__("显示温度C：",'trendyblog-theme'), "value" => "C"),
		array("title" => esc_html__("显示温度F：",'trendyblog-theme'), "value" => "F")
	),
	"std" => "C",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_weather", "value" => "on")
	)
),
array(
	"type" => "title",
	"title" => "API类型",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_weather", "value" => "on")
	)
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_weather_api_key_type",
	"radio" => array(
		array("title" => esc_html__("免费API密钥：",'trendyblog-theme'), "value" => "free"),
		array("title" => esc_html__("高级API密钥：",'trendyblog-theme'), "value" => "premium")
	),
	"std" => "free",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_weather", "value" => "on")
	)
),
array(
	"type" => "title",
	"title" => "位置",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_weather", "value" => "on")
	)
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_weather_location_type",
	"radio" => array(
		array("title" => esc_html__("搜索客户位置：",'trendyblog-theme'), "value" => "customer"),
		array("title" => esc_html__("设置自己的自定义位置：",'trendyblog-theme'), "value" => "custom")
	),
	"std" => "customer",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_weather", "value" => "on")
	)
),
array(
	"type" => "input",
	"title" => esc_html__("城市名称，国家",'trendyblog-theme'),
	"info" => esc_html__("示例 - 中国，北京",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_weather_city",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_weather_location_type", "value" => "custom")
	)
),

array(
	"type" => "input",
	"title" => esc_html__("API密钥",'trendyblog-theme'),
	"info" => esc_html__("您可以在此获得的API密钥：",'trendyblog-theme')." <a href='//developer.worldweatheronline.com/signup.aspx' style='color:#fff' target='_blank'>".esc_html__("注册API密钥",'trendyblog-theme')."</a>",
	"id" => $different_themes_managment->themeslug."_weather_api",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_weather", "value" => "on")
	)
),


array(
	"type" => "close"
),
array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("在主菜单中显示购物车",'trendyblog-theme'),
),

array(
	"type" => "checkbox",
	"title" => esc_html__("显示购物车：",'trendyblog-theme'),
	"id"=>$different_themes_managment->themeslug."_cart"
),
array(
	"type" => "close"
),
array(
	"type" => "row"
),
array(
	"type" => "title",
	"title" => esc_html__("显示面包屑导航",'trendyblog-theme'),
),

array(
	"type" => "checkbox",
	"title" => esc_html__("显示面包屑导航：",'trendyblog-theme'),
	"id"=>$different_themes_managment->themeslug."_breadcrumb"
),
array(
	"type" => "close"
),

array(
	"type" => "save",
	"title" => esc_html__("保存设置",'trendyblog-theme'),
),
   
array(
	"type" => "closesubtab"
),

/* ------------------------------------------------------------------------*
 * BLOG SETTINGS
 * ------------------------------------------------------------------------*/   
  
array(
	"type" => "sub_tab",
	"slug"=>'blog'
),

array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("单位设置",'trendyblog-theme'),
),

array(
	"type" => "checkbox",
	"title" => esc_html__("在博客文章列表中显示缩略图：",'trendyblog-theme'),
	"id"=>$different_themes_managment->themeslug."_show_first_thumb",
),

array(
	"type" => "checkbox",
	"title" => esc_html__("当没有缩略图可用时，显示 \"无图片\" 缩略图：",'trendyblog-theme'),
	"id"=>$different_themes_managment->themeslug."_show_no_image_thumb"
),
array(
	"type" => "close"
),
array(
	"type" => "row"
),
array(
	"type" => "title",
	"title" => esc_html__("在打开的文章/页面显示缩略图",'trendyblog-theme')
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_show_single_thumb",
	"radio" => array(
		array("title" => esc_html__("显示：",'trendyblog-theme'), "value" => "show"),
		array("title" => esc_html__("隐藏：",'trendyblog-theme'), "value" => "hide"),
		array("title" => esc_html__("为每篇文章定制：",'trendyblog-theme'), "value" => "custom")
	),
	"std" => "custom"
),

array(
	"type" => "close"
),
array(
	"type" => "row"
),
array(
	"type" => "title",
	"title" => esc_html__("在打开的文章/页面全高中显示缩略图",'trendyblog-theme')
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_single_thumb_size",
	"radio" => array(
		array("title" => esc_html__("饱满：",'trendyblog-theme'), "value" => "show"),
		array("title" => esc_html__("七分：",'trendyblog-theme'), "value" => "hide"),
		array("title" => esc_html__("为每篇文章定制：",'trendyblog-theme'), "value" => "custom")
	),
	"std" => "custom"
),

array(
	"type" => "close"
),
array(
	"type" => "row"
),
array(
	"type" => "title",
	"title" => esc_html__("可点击单文章/页面图像",'trendyblog-theme')
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_imagePopUp",
	"radio" => array(
		array("title" => esc_html__("是:",'trendyblog-theme'), "value" => "show"),
		array("title" => esc_html__("否:",'trendyblog-theme'), "value" => "hide"),
		array("title" => esc_html__("为每篇文章定制：",'trendyblog-theme'), "value" => "custom")
	),
	"std" => "custom"
),

array(
	"type" => "close"
),

array(
	"type" => "row"
),
array(
	"type" => "title",
	"title" => esc_html__("在邮件列表页面上显示缩略图上的图标",'trendyblog-theme')
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_showTumbIcon",
	"radio" => array(
		array("title" => esc_html__("显示:",'trendyblog-theme'), "value" => "show"),
		array("title" => esc_html__("隐藏:",'trendyblog-theme'), "value" => "hide"),
		array("title" => esc_html__("为每篇文章定制：",'trendyblog-theme'), "value" => "custom")
	),
	"std" => "custom"
),

array(
	"type" => "close"
),

array(
	"type" => "row"
),
array(
	"type" => "title",
	"title" => esc_html__("在单个文章/页面中显示文章标题",'trendyblog-theme')
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_show_single_title",
	"radio" => array(
		array("title" => esc_html__("显示:",'trendyblog-theme'), "value" => "show"),
		array("title" => esc_html__("隐藏:",'trendyblog-theme'), "value" => "hide"),
		array("title" => esc_html__("为每篇文章定制：",'trendyblog-theme'), "value" => "custom")
	),
	"std" => "custom"
),

array(
	"type" => "close"
),
array(
	"type" => "row"
),
array(
	"type" => "title",
	"title" => esc_html__("显示文章控件",'trendyblog-theme')
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_postControls",
	"radio" => array(
		array("title" => esc_html__("显示:",'trendyblog-theme'), "value" => "show"),
		array("title" => esc_html__("隐藏:",'trendyblog-theme'), "value" => "hide"),
		array("title" => esc_html__("为每篇文章定制：",'trendyblog-theme'), "value" => "custom")
	),
	"std" => "custom"
),

array(
	"type" => "close"
),
array(
	"type" => "row"
),
array(
	"type" => "title",
	"title" => esc_html__("显示文章作者",'trendyblog-theme')
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_postAuthor",
	"radio" => array(
		array("title" => esc_html__("显示:",'trendyblog-theme'), "value" => "show"),
		array("title" => esc_html__("隐藏:",'trendyblog-theme'), "value" => "hide"),
		array("title" => esc_html__("为每篇文章定制：",'trendyblog-theme'), "value" => "custom")
	),
	"std" => "custom"
),

array(
	"type" => "close"
),


array(
	"type" => "row"
),
array(
	"type" => "title",
	"title" => esc_html__("显示文章日期",'trendyblog-theme')
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_postDate",
	"radio" => array(
		array("title" => esc_html__("显示:",'trendyblog-theme'), "value" => "show"),
		array("title" => esc_html__("隐藏:",'trendyblog-theme'), "value" => "hide"),
		array("title" => esc_html__("为每篇文章定制：",'trendyblog-theme'), "value" => "custom")
	),
	"std" => "custom"
),

array(
	"type" => "close"
),

array(
	"type" => "row"
),
array(
	"type" => "title",
	"title" => esc_html__("显示文章浏览",'trendyblog-theme')
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_postViews",
	"radio" => array(
		array("title" => esc_html__("显示:",'trendyblog-theme'), "value" => "show"),
		array("title" => esc_html__("隐藏:",'trendyblog-theme'), "value" => "hide"),
		array("title" => esc_html__("为每篇文章定制：",'trendyblog-theme'), "value" => "custom")
	),
	"std" => "custom"
),

array(
	"type" => "close"
),
array(
	"type" => "row"
),
array(
	"type" => "title",
	"title" => esc_html__("显示点赞数",'trendyblog-theme')
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_showLikes",
	"radio" => array(
		array("title" => esc_html__("显示:",'trendyblog-theme'), "value" => "show"),
		array("title" => esc_html__("隐藏:",'trendyblog-theme'), "value" => "hide"),
		array("title" => esc_html__("为每篇文章定制：",'trendyblog-theme'), "value" => "custom")
	),
	"std" => "custom"
),

array(
	"type" => "close"
),

array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("显示分类",'trendyblog-theme')
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_postCategory",
	"radio" => array(
		array("title" => esc_html__("显示:",'trendyblog-theme'), "value" => "show"),
		array("title" => esc_html__("隐藏:",'trendyblog-theme'), "value" => "hide"),
		array("title" => esc_html__("为每篇文章定制：",'trendyblog-theme'), "value" => "custom")
	),
	"std" => "custom"
),

array(
	"type" => "close"
),
array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("在单文章中显示标签",'trendyblog-theme')
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_post_tag_single",
	"radio" => array(
		array("title" => esc_html__("显示:",'trendyblog-theme'), "value" => "show"),
		array("title" => esc_html__("隐藏:",'trendyblog-theme'), "value" => "hide"),
		array("title" => esc_html__("为每篇文章定制：",'trendyblog-theme'), "value" => "custom")
	),
	"std" => "custom"
),

array(
	"type" => "close"
),
array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("在单文章显示 \"关于作者\"",'trendyblog-theme')
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_aboutPostAuthor",
	"radio" => array(
		array("title" => esc_html__("显示:",'trendyblog-theme'), "value" => "show"),
		array("title" => esc_html__("隐藏:",'trendyblog-theme'), "value" => "hide"),
		array("title" => esc_html__("为每篇文章定制：",'trendyblog-theme'), "value" => "custom")
	),
	"std" => "custom"
),

array(
	"type" => "close"
),
array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("在单文章显示 \"相关文章\"",'trendyblog-theme')
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_similar_posts",
	"radio" => array(
		array("title" => esc_html__("显示:",'trendyblog-theme'), "value" => "show"),
		array("title" => esc_html__("隐藏:",'trendyblog-theme'), "value" => "hide"),
		array("title" => esc_html__("为每篇文章定制：",'trendyblog-theme'), "value" => "custom")
	),
	"std" => "custom"
),

array(
	"type" => "title",
	"title" => esc_html__("相关文章数量",'trendyblog-theme')
),

array(
	"type" => "scroller",
	"title" => esc_html__("文章数:",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_similar_post_count",
	"max" => '30',
	"std" => "3"
),

array(
	"type" => "title",
	"title" => esc_html__("相关文章摘要",'trendyblog-theme')
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_similar_post_excerpt",
	"radio" => array(
		array("title" => esc_html__("显示:",'trendyblog-theme'), "value" => "on"),
		array("title" => esc_html__("隐藏:",'trendyblog-theme'), "value" => "off"),
	),
	"std" => "on"
),

array(
	"type" => "close"
),



array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("显示分享按钮",'trendyblog-theme')
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_share_buttons",
	"radio" => array(
		array("title" => esc_html__("显示:",'trendyblog-theme'), "value" => "show"),
		array("title" => esc_html__("隐藏:",'trendyblog-theme'), "value" => "hide"),
		array("title" => esc_html__("自定义每篇文章/页面:",'trendyblog-theme'), "value" => "custom")
	),
	"std" => "custom"
),

array(
	"type" => "close"
),

array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("显示文章评论数",'trendyblog-theme')
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_postComments",
	"radio" => array(
		array("title" => esc_html__("显示:",'trendyblog-theme'), "value" => "show"),
		array("title" => esc_html__("隐藏:",'trendyblog-theme'), "value" => "hide"),
		array("title" => esc_html__("为每篇文章定制：",'trendyblog-theme'), "value" => "custom")
	),
	"std" => "custom"
),

array(
	"type" => "close"
),
array(
	"type" => "save",
	"title" => esc_html__("保存设置",'trendyblog-theme')
),

array(
	"type" => "closesubtab"
),


/* ------------------------------------------------------------------------*
 * CONTACT SETTINGS
 * ------------------------------------------------------------------------*/   

array(
	"type" => "sub_tab",
	"slug"=>'contact'
),
/*
array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("Social Account Icons In Header",'trendyblog-theme')
),

array(
	"type" => "checkbox",
	"title" => esc_html__("Enable Icons",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_top_icons",
	"std" => "off"
),

array(
	"type" => "input",
	"title" => esc_html__("Facebook Account Url:",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_facebook",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_top_icons", "value" => "on")
	)
),
array(
	"type" => "input",
	"title" => esc_html__("Twitter Account Url:",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_twitter",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_top_icons", "value" => "on")
	)
),
array(
	"type" => "input",
	"title" => esc_html__("LinkedIn Account Url:",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_linkedin",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_top_icons", "value" => "on")
	)
),
array(
	"type" => "input",
	"title" => esc_html__("Pinterest Account Url:",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_pinterest",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_top_icons", "value" => "on")
	)
),
array(
	"type" => "input",
	"title" => esc_html__("RSS Account Url:",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_rss",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_top_icons", "value" => "on")
	)
),

array(
	"type" => "close"
),
*/
array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("Twitter账户",'trendyblog-theme')
),

array(
	"type" => "input",
	"title" => esc_html__("Twitter用户名:",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_twitter_name"
),

array(
	"type" => "close"
),

array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("底部版权",'trendyblog-theme'),
),

array(
	"type" => "textarea",
	"title" => esc_html__("文本:",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_copyright"
),

array(
	"type" => "close"
),


array(
	"type" => "save",
	"title" => esc_html__("保存设置",'trendyblog-theme'),
),

array(
	"type" => "closesubtab"
),


/* ------------------------------------------------------------------------*
 * GALLERY SETTINGS
 * ------------------------------------------------------------------------*/   
array(
	"type" => "sub_tab",
	"slug"=>'gallery'
),

array(
	"type" => "row"
),

array(
	"type" => "title",
	"title"=> esc_html__('图库设置','trendyblog-theme')
),

array(
	"type" => "input",
	"title" => esc_html__("每个图库的项目页面:",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_gallery_items",
	"number" => "yes",
	"std" => "8"
),

array(
	"type" => "close"
),

array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("在图库页面显示 \"相关文章\"",'trendyblog-theme')
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_similar_posts_gallery",
	"radio" => array(
		array("title" => esc_html__("显示:",'trendyblog-theme'), "value" => "show"),
		array("title" => esc_html__("隐藏:",'trendyblog-theme'), "value" => "hide"),
		array("title" => esc_html__("为每篇文章定制:",'trendyblog-theme'), "value" => "custom")
	),
	"std" => "custom"
),

array(
	"type" => "close"
),

array(
	"type" => "save",
	"title" => esc_html__("保存设置",'trendyblog-theme'),
),

array(
	"type" => "closesubtab"
),


/* ------------------------------------------------------------------------*
 * BANNER SETTINGS
 * ------------------------------------------------------------------------*/   

array(
	"type" => "sub_tab",
	"slug"=>'banner_settings'
),

array(
	"type" => "row",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_headerStyle", "value" => "2")
	)
),

array(
	"type" => "title",
	"title" => esc_html__("标题横幅",'trendyblog-theme'),
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_headerStyle", "value" => "2")
	)
),

array(
	"type" => "checkbox",
	"title" => esc_html__("启用横幅",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_top_banner",
	"std" => "off",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_headerStyle", "value" => "2")
	)
),

array(
	"type" => "textarea",
	"title" => esc_html__("横幅HTML代码",'trendyblog-theme'),
	"sample" => '<a href="http://www.different-themes.com" target="_blank"><img src="'.esc_url(THEME_IMAGE_URL.'no-banner-728x90.jpg').'" alt="" title="" /></a>',
	"id" => $different_themes_managment->themeslug."_top_banner_code",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_headerStyle", "value" => "2")
	)
),

array(
	"type" => "close",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_headerStyle", "value" => "2")
	)
),
/*
array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("Custom HTML Under Main Menu",'trendyblog-theme')
),

array(
	"type" => "textarea",
	"title" => esc_html__("HTML Code",'trendyblog-theme'),
	"sample" => '<span>Custom links here:</span><a href="#">Google Adsense</a><a href="#">Cheap laptops and netbooks</a><a href="#">lpad, Laptops &amp; Books</a><a href="#">Cheapest Cell Phones</a><a href="#">Buy Quality HP laptops</a>',
	"id" => $different_themes_managment->themeslug."_custom_html",
),

array(
	"type" => "close"
),
*/
array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("选择弹出横幅类型",'trendyblog-theme'),
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_banner_type",
	"radio" => array(
		array("title" => "关闭", "value" => "off"),
		array("title" => "图片横幅", "value" => "image"),
		array("title" => "文本或HTML代码横幅", "value" => "text"),
		array("title" => "图片和文本横幅", "value" => "text_image")
	),
	"std" => "off"
),

array(
	"type" => "upload",
	"title" => "添加横幅图像",
	"id" => $different_themes_managment->themeslug."_banner_image",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_banner_type", "value" => "image")
	)
),

array(
	"type" => "textarea",
	"title" => "横幅内容",
	"info" => "您也可以在这里复制一些HTML代码。",
	"id" => $different_themes_managment->themeslug."_banner_text",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_banner_type", "value" => "text")
	)
),

array(
	"type" => "upload",
	"title" => "添加横幅图像",
	"id" => $different_themes_managment->themeslug."_banner_text_image_img",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_banner_type", "value" => "text_image")
	)
),

array(
	"type" => "textarea",
	"title" => "横幅文本",
	"info" => "您只可添加文本。",
	"id" => $different_themes_managment->themeslug."_banner_text_image_txt",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_banner_type", "value" => "text_image")
	)
),

array(
	"type" => "close"
),

array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => "横幅设置",
),

array(
	"type" => "select",
	"title" => "开始时间",
	"id" => $different_themes_managment->themeslug."_banner_start",
	"options"=>array(
		array("slug"=>"0", "name"=>"0 秒"), 
		array("slug"=>"5", "name"=>"5 秒"),
		array("slug"=>"10", "name"=>"10 秒"),
		array("slug"=>"15", "name"=>"15 秒"),
		array("slug"=>"20", "name"=>"20 秒"),
		array("slug"=>"25", "name"=>"25 秒"),
		array("slug"=>"30", "name"=>"30 秒"),
		array("slug"=>"60", "name"=>"1 分钟"),
		array("slug"=>"120", "name"=>"2 分钟"),
		array("slug"=>"180", "name"=>"3 分钟"),

		),
	"std" => "off"
),

array(
	"type" => "select",
	"title" => "关闭时间",
	"id" => $different_themes_managment->themeslug."_banner_close",
	"options"=>array(
		array("slug"=>"0", "name"=>"关闭"), 
		array("slug"=>"5", "name"=>"5 秒"),
		array("slug"=>"10", "name"=>"10 秒"),
		array("slug"=>"15", "name"=>"15 秒"),
		array("slug"=>"20", "name"=>"20 秒"),
		array("slug"=>"25", "name"=>"25 秒"),
		array("slug"=>"30", "name"=>"30 秒"),
		array("slug"=>"60", "name"=>"1 分钟"),
		array("slug"=>"120", "name"=>"2 分钟"),
		array("slug"=>"180", "name"=>"3 分钟"),

		),
	"std" => "off"
),

array(
	"type" => "select",
	"title" => "进入样式",
	"id" => $different_themes_managment->themeslug."_banner_fly_in",
	"options"=>array(
		array("slug"=>"off", "name"=>"关闭"), 
		array("slug"=>"top", "name"=>"上"),
		array("slug"=>"top-left", "name"=>"上左"),
		array("slug"=>"top-right", "name"=>"上右"),
		array("slug"=>"left", "name"=>"左"),
		array("slug"=>"bottom", "name"=>"下"),
		array("slug"=>"bottom-left", "name"=>"下左"),
		array("slug"=>"bottom-right", "name"=>"下右"),
		),
	"std" => "off"
),

array(
	"type" => "select",
	"title" => "退出样式",
	"id" => $different_themes_managment->themeslug."_banner_fly_out",
	"options"=>array(
		array("slug"=>"off", "name"=>"关闭"), 
		array("slug"=>"top", "name"=>"上"),
		array("slug"=>"top-left", "name"=>"上左"),
		array("slug"=>"top-right", "name"=>"上右"),
		array("slug"=>"left", "name"=>"左"),
		array("slug"=>"bottom", "name"=>"下"),
		array("slug"=>"bottom-left", "name"=>"下左"),
		array("slug"=>"bottom-right", "name"=>"下右"),
		),
	"std" => "off"
),

array(
	"type" => "select",
	"title" => "显示横幅后",
	"info" => "可以查看多少次网站，直到弹出窗口再次显示",
	"id" => $different_themes_managment->themeslug."_banner_views",
	"options"=>array(
		array("slug"=>"0", "name"=>"0 点击"), 
		array("slug"=>"1", "name"=>"1 点击"),
		array("slug"=>"2", "name"=>"2 点击"),
		array("slug"=>"2", "name"=>"3 点击"),
		array("slug"=>"4", "name"=>"4 点击"),
		array("slug"=>"5", "name"=>"5 点击"),
		array("slug"=>"10", "name"=>"10 点击"),
		array("slug"=>"20", "name"=>"20 点击"),
		),
	"std" => "0"
),

array(
	"type" => "select",
	"title" => "多久显示一次横幅",
	"id" => $different_themes_managment->themeslug."_banner_timeout",
	"options"=>array(
		array("slug"=>"0", "name"=>"每访问一次"), 
		array("slug"=>"1", "name"=>"1天1次"), 
		array("slug"=>"2", "name"=>"2天1次"),
		array("slug"=>"3", "name"=>"3天1次"),
		array("slug"=>"7", "name"=>"1周1次"),
		array("slug"=>"30", "name"=>"1月1次"),
		array("slug"=>"365", "name"=>"1年1次"),
		),
	"std" => "0"
),

array(
	"type" => "checkbox",
	"title" => "启用背景覆盖:",
	"id" => $different_themes_managment->themeslug."_banner_overlay",
	"std" => "off"
),

array(
	"type" => "close"
),

array(
	"type" => "save",
	"title" => "保存设置"
),

array(
	"type" => "closesubtab"
),

array(
	"type" => "closetab"
)
 
 );


$different_themes_managment->add_options($differentThemes_general_options);
?>