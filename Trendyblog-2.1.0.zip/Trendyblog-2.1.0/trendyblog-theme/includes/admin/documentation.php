<?php
global $different_themes_managment;
$differentThemes_documentation_options= array(
 array(
	"type" => "navigation",
	"name" => "联系信息",
	"slug" => "contact"
),

array(
	"type" => "tab",
	"slug"=>'documentation'
),

array(
	"type" => "sub_navigation",
	"subname"=>array(
		array("slug"=>"documentation", "name"=>"联系信息")
		)
),

/* ------------------------------------------------------------------------*
 * DOCUMENTATION SLIDER SETTINGS
 * ------------------------------------------------------------------------*/

array(
	"type" => "sub_tab",
	"slug"=>'documentation'
),

array(
	"type" => "row"
),

 array(
	"type" => "text",
	"text"=>'<h2>'.THEME_FULL_NAME.' 支持 </h2>
			<p>请注意，包含所有主题自定义设置的说明都包含在文档中。 该文档位于文档文件夹内，或者您可以在此处查看文档示例: <a href="'.esc_url('http://'.THEME_NAME.'different-themes.com/documentation/').'"><strong>http://'.THEME_NAME.'.different-themes.com/documentation/</strong></a></p>
			<h2 style="padding-top:30px;">如果你有任何问题 </h2>
			<p>我们使用我们的联系表格与客户进行交流的速度更快 <a href="http://themeforest.net/user/different-themes?ref=different-themes" target="_blank"><strong>themeforest.net/user/different-themes</strong></a></p>

			<h2 style="padding-top:30px;">主题支持政策</h2>
			<em>如果下列任何条件被违反或不服从，不同主题保留拒绝对主题支持的权利。</em>
			<ul>
				<li>在联系我们之前重新阅读文档。 确保您的问题没有在那里描述。 文档被添加到每个主题中，并且每个主题的描述都包含文档的链接。</li>
				<li>
			<p lang="en-US">我们只支持不同主题开发的主题。</p>
			</li>
				<li>
			<p lang="en-US">主题不适用于商业用途，不包括购买扩展许可证的情况。</p>
			</li>
				<li>
			<p lang="en-US">确保您的服务器支持最新的PHP版本; 确保主题支持特定的WordPress版本。 我们建议始终执行更新，但主题说明中指出的情况除外。</p>
			</li>
				<li>
			<p lang="en-US">关闭所有Wordpress插件后，检查问题是否仍然存在。</p>
			</li>
				<li>使用联系论坛与我们联系 <a href="http://themeforest.net/user/different-themes?ref=different-themes" target="_blank"><strong>themeforest.net/user/different-themes</strong></a></li>
				<li>
			</li>
				<li>指示出现错误的浏览器类型和版本。</li>
				<li>如果有任何视觉问题，建议添加错误出现页面的屏幕截图。</li>
				<li>
			<p lang="en-US">尽量准确详细地描述问题。 如果有必要，请添加一个链接到图像。</p>
			</li>
				<li>
			<p lang="en-US">我们不保证该主题与所有可用插件兼容。 可能会出现插件与主题不兼容的情况，必须关闭。</p>
			</li>
				<li>
			<p lang="en-US">如果主题已被修改，我们不提供支持，即如果任何文件已被修改，并且之后不起作用，则我们不提供支持。 排除单独订单并支付时的情况。</p>
			</li>
				<li>
			<p lang="en-US">对主题的任何补充或修改应作为单独购买形式化。</p>
			</li>
				<li>
			<p lang="en-US">答复应在一个工作日内给出。</p>
			</li>
				<li>不同主题保留修改使用条款的权利，恕不另行通知！</li>
			</ul>
'
),

array(
	"type" => "close"
),

array(
	"type" => "save",
	"title" => "保存设置"
),

array(
	"type" => "closesubtab"
),

array(
	"type" => "closetab"
)
 
 
);

$different_themes_managment->add_options($differentThemes_documentation_options);
 
?>