<?php
global $different_themes_managment;
$differentThemes_slider_options= array(
 array(
	"type" => "navigation",
	"name" => esc_html__("幻灯设置",'trendyblog-theme'),
	"slug" => "sliders"
),

array(
	"type" => "tab",
	"slug"=>'sliders'
),

array(
	"type" => "sub_navigation",
	"subname"=>array(
		array("slug"=>"main_slider", "name"=>esc_html__("主要新闻滑块",'trendyblog-theme')),
		array("slug"=>"breaking_slider", "name"=>esc_html__("最新新闻滑块",'trendyblog-theme')),
		)
),


/* ------------------------------------------------------------------------*
 * MAIN NEWS SLIDER SETTINGS
 * ------------------------------------------------------------------------*/

 array(
	"type" => "sub_tab",
	"slug"=> 'main_slider'
),

array(
	"type" => "row",

),
array(
	"type" => "title",
	"title" => esc_html__("主要新闻滑块设置",'trendyblog-theme')
),

array(
	"type" => "scroller",
	"id" => $different_themes_managment->themeslug."_main_slider_count",
	"title" => esc_html__("主滑块滑块数（仅限小滑块）",'trendyblog-theme'),
	"max" => "100",
	"std" => "8"
),

array(
	"type" => "close"
),

array(
	"type" => "save",
	"title" => esc_html__("保存设置",'trendyblog-theme')
),
   
array(
	"type" => "closesubtab"
),

/* ------------------------------------------------------------------------*
 * BREAKING NEWS SLIDER SETTINGS
 * ------------------------------------------------------------------------*/

 array(
	"type" => "sub_tab",
	"slug"=> 'breaking_slider'
),


array(
	"type" => "row"
),
array(
	"type" => "title",
	"title" => esc_html__("显示最新新闻滑块",'trendyblog-theme')
),

array(
	"type" => "checkbox",
	"title" => __("显示在文章:",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_breaking_news_post",
),
array(
	"type" => "checkbox",
	"title" => __("显示在页面:",'trendyblog-theme'),
	"id"=> $different_themes_managment->themeslug."_breaking_news_page"
),
array(
	"type" => "checkbox",
	"title" => __("显示在博客:",'trendyblog-theme'),
	"id"=> $different_themes_managment->themeslug."_breaking_news_blog"
),
array(
	"type" => "checkbox",
	"title" => __("显示在首页:",'trendyblog-theme'),
	"id"=> $different_themes_managment->themeslug."_breaking_news_home"
),
array(
	"type" => "title",
	"title" => esc_html__("新闻滑块分类",'trendyblog-theme')
),
array(
	"type" => "multiple_select",
	"title" => esc_html__("设置分类",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_breaking_slider",
	"taxonomy" => "category",
),

array(
	"type" => "close"
),

array(
	"type" => "save",
	"title" => esc_html__("保存设置",'trendyblog-theme')
),
   
array(
	"type" => "closesubtab"
),

array(
	"type" => "closetab"
)
 
);

$different_themes_managment->add_options($differentThemes_slider_options);
?>