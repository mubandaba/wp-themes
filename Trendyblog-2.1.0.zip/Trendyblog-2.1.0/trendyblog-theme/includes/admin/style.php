<?php
global $different_themes_managment;
$differentThemes_slider_options= array(
 array(
	"type" => "navigation",
	"name" => esc_html__("样式设置",'trendyblog-theme'),
	"slug" => "custom-styling"
),

array(
	"type" => "tab",
	"slug"=>'custom-styling'
),

array(
	"type" => "sub_navigation",
	"subname"=>array(
		array("slug"=>"font_style", "name"=>esc_html__("字体样式",'trendyblog-theme')),
		array("slug"=>"page_colors", "name"=>esc_html__("页面颜色/样式",'trendyblog-theme')),
		array("slug"=>"page_layout", "name"=>esc_html__("布局",'trendyblog-theme'))
		)
),

/* ------------------------------------------------------------------------*
 * PAGE FONT SETTINGS
 * ------------------------------------------------------------------------*/

 array(
	"type" => "sub_tab",
	"slug"=> 'font_style'
),

array(
	"type" => "row"
),
array(
	"type" => "title",
	"title" => esc_html__("字体",'trendyblog-theme')
),

array(
	"type" => "google_font_select",
	"title" => esc_html__("主体字体:",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_google_font_1",
	"sort" => "alpha",
	"info" => esc_html__("您可以在此预览字体: <a href='http://www.google.com/webfonts' target='_blank'>Google Fonts</a>",'trendyblog-theme'),
	"default_font" => array('font' => "Titillium Web", 'txt' => "(default)")
),
array(
	"type" => "google_font_select",
	"title" => esc_html__("标题
     （标题，菜单链接，dropcap第一个字母，面板字幕）:",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_google_font_2",
	"sort" => "alpha",
	"info" => esc_html__("您可以在此预览字体: <a href='http://www.google.com/webfonts' target='_blank'>Google Fonts</a>",'trendyblog-theme'),
	"default_font" => array('font' => "Titillium Web", 'txt' => "(default)")
),


array(
	"type" => "close"

),
array(
	"type" => "row"
),
array(
	"type" => "title",
	"title" => esc_html__("字体大小",'trendyblog-theme')
),

array(
	"type" => "scroller",
	"title" => esc_html__("主体字体大小，单位:PX (默认 14px):",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_font_size_1",
	"max" => '30',
	"std" => "14"
),

array(
	"type" => "scroller",
	"title" => esc_html__("主菜单字体大小，单位:PX (默认 16px):",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_font_size_2",
	"max" => '30',
	"std" => "16"
),
array(
	"type" => "scroller",
	"title" => esc_html__("主菜单描述字体大小，单位:PX (默认 12px):",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_font_size_3",
	"max" => '30',
	"std" => "12"
),
array(
	"type" => "scroller",
	"title" => esc_html__("主菜单子菜单字体大小，单位:PX (默认 12px):",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_font_size_4",
	"max" => '30',
	"std" => "12"
),



array(
	"type" => "close"

),


array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("字体字符集",'trendyblog-theme'),
),

array(
	"type" => "checkbox",
	"title" => esc_html__("西里尔文扩展 (cyrillic-ext):",'trendyblog-theme'),
	"id"=>$different_themes_managment->themeslug."_font_cyrillic_ex"
),
array(
	"type" => "checkbox",
	"title" => esc_html__("西里尔 (cyrillic):",'trendyblog-theme'),
	"id"=>$different_themes_managment->themeslug."_font_cyrillic"
),
array(
	"type" => "checkbox",
	"title" => esc_html__("希腊扩展 (greek-ext):",'trendyblog-theme'),
	"id"=>$different_themes_managment->themeslug."_font_greek_ex"
),
array(
	"type" => "checkbox",
	"title" => esc_html__("希腊 (greek):",'trendyblog-theme'),
	"id"=>$different_themes_managment->themeslug."_font_greek"
),
array(
	"type" => "checkbox",
	"title" => esc_html__("越南 (vietnamese):",'trendyblog-theme'),
	"id"=>$different_themes_managment->themeslug."_font_vietnamese"
),
array(
	"type" => "checkbox",
	"title" => esc_html__("拉丁语扩展 (latin-ext):",'trendyblog-theme'),
	"id"=>$different_themes_managment->themeslug."_font_latin_ex"
),

array(
	"type" => "close",

),
array(
	"type" => "save",
	"title" => esc_html__("保存设置",'trendyblog-theme')
),
   
array(
	"type" => "closesubtab"
),
/* ------------------------------------------------------------------------*
 * PAGE COLORS
 * ------------------------------------------------------------------------*/

 array(
	"type" => "sub_tab",
	"slug"=> 'page_colors'
),

array(
	"type" => "row"
),
array(
	"type" => "title",
	"title" => esc_html__("默认分类/新闻页面颜色",'trendyblog-theme')
),

array( 
	"type" => "color", 
	"id" => $different_themes_managment->themeslug."_default_cat_color", 
	"title" => esc_html__("颜色:",'trendyblog-theme'),
	"std" => "f85050",
),

array(
	"type" => "close"
),
array(
	"type" => "row"
),
array(
	"type" => "title",
	"title" => esc_html__("颜色",'trendyblog-theme')
),

array( 
	"type" => "color", 
	"id" => $different_themes_managment->themeslug."_color_1", 
	"title" => esc_html__("颜色
     （链接悬停，天气预报图标，天气预报温度，标志跨度，
     dropcap首字母，引号，元日历图标）:",'trendyblog-theme'),
	"std" => "f85050",
),
array( 
	"type" => "color", 
	"id" => $different_themes_managment->themeslug."_color_2", 
	"title" => esc_html__("背景
     （标记，按钮，菜单中的搜索图标，格式，标签悬停，文章格式悬停，
     输入提交，店铺悬停图标，分页当前链接，店铺按钮，
     跨度格式图标，审阅边框，评分结果，转换线，宽滑块
     控制，过滤商店句柄）:",'trendyblog-theme'),
	"std" => "f85050",
),
array( 
	"type" => "color", 
	"id" => $different_themes_managment->themeslug."_color_3", 
	"title" => esc_html__("边境
     （下拉菜单，标签悬停，滑块页面顶部边框）：",'trendyblog-theme'),
	"std" => "f85050",
),
array( 
	"type" => "color", 
	"id" => $different_themes_managment->themeslug."_color_4", 
	"title" => esc_html__("在邮件内容中标题颜色:",'trendyblog-theme'),
	"std" => "222",
),
array( 
	"type" => "color", 
	"id" => $different_themes_managment->themeslug."_color_5", 
	"title" => esc_html__("内容链接颜色:",'trendyblog-theme'),
	"std" => "FC8D8D",
),
array( 
	"type" => "color", 
	"id" => $different_themes_managment->themeslug."_color_6", 
	"title" => esc_html__("折叠背景颜色:",'trendyblog-theme'),
	"std" => "eee",
),
array( 
	"type" => "color", 
	"id" => $different_themes_managment->themeslug."_color_7", 
	"title" => esc_html__("折叠图标背景:",'trendyblog-theme'),
	"std" => "ddd",
),
array( 
	"type" => "color", 
	"id" => $different_themes_managment->themeslug."_color_8", 
	"title" => esc_html__("折叠图标颜色:",'trendyblog-theme'),
	"std" => "999",
),


array(
	"type" => "close"
),

array(
	"type" => "row",

),
array(
	"type" => "title",
	"title" => esc_html__("主体背景（仅块状视图）",'trendyblog-theme')
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_body_bg_type",
	"radio" => array(
		array("title" => esc_html__("图案:",'trendyblog-theme'), "value" => "pattern"),
		array("title" => esc_html__("自定义图像:",'trendyblog-theme'), "value" => "image"),
		array("title" => esc_html__("颜色:",'trendyblog-theme'), "value" => "color"),
	),
	"std" => "pattern"
),

array(
	"type" => "select",
	"title" => esc_html__("图案 ",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_body_pattern",
	"options"=>array(
		array("slug"=>"2", "name"=>esc_html__("纹理 1",'trendyblog-theme')), 
		array("slug"=>"3", "name"=>esc_html__("纹理 2",'trendyblog-theme')), 
		array("slug"=>"4", "name"=>esc_html__("纹理 3",'trendyblog-theme')), 
		array("slug"=>"5", "name"=>esc_html__("纹理 4",'trendyblog-theme')), 
	),
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_body_bg_type", "value" => "pattern")
	)
),

array(
	"type" => "color",
	"title" => esc_html__("主体背景颜色:",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_body_color",
	"std" => "f1f1f1",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_body_bg_type", "value" => "color")
	)
),

array(
	"type" => "upload",
	"title" => esc_html__("主题背景图片:",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_body_image",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_body_bg_type", "value" => "image")
	)
),

array(
	"type" => "input",
	"title" => esc_html__("背景图片网址:",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_body_image_url",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_body_bg_type", "value" => "image")
	)
),
array(
	"type" => "title",
	"title" => esc_html__("图像重复",'trendyblog-theme'),
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_body_bg_type", "value" => "image")
	)
),
array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_body_image_repeat",
	"radio" => array(
		array("title" => esc_html__("重复-x:",'trendyblog-theme'), "value" => "repeat-x"),
		array("title" => esc_html__("重复-Y:",'trendyblog-theme'), "value" => "repeat-y"),
		array("title" => esc_html__("重复-x和y:",'trendyblog-theme'), "value" => "repeat"),
		array("title" => esc_html__("关闭:",'trendyblog-theme'), "value" => "no-repeat"),
	),
	"std" => "no-repeat",
	"protected" => array(
		array("id" => $different_themes_managment->themeslug."_body_bg_type", "value" => "image")
	)
),
array(
	"type" => "close",

),

array(
	"type" => "save",
	"title" => esc_html__("保存设置",'trendyblog-theme'),
),
   
array(
	"type" => "closesubtab"
),
/* ------------------------------------------------------------------------*
 * PAGE LAYOUT
 * ------------------------------------------------------------------------*/

 array(
	"type" => "sub_tab",
	"slug"=> 'page_layout'
),

array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("菜单",'trendyblog-theme'),
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_stickyMenu",
	"radio" => array(
		array("title" => esc_html__("跟随:",'trendyblog-theme'), "value" => "on"),
		array("title" => esc_html__("固定:",'trendyblog-theme'), "value" => "off"),
	),
),

array(
	"type" => "close"
),
array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("顶部样式",'trendyblog-theme'),
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_headerStyle",
	"radio" => array(
		array("title" => esc_html__("Logo+菜单:",'trendyblog-theme'), "value" => "1"),
		array("title" => esc_html__("Logo+横幅+菜单:",'trendyblog-theme'), "value" => "2"),
	),
),

array(
	"type" => "close"
),

array(
	"type" => "row"
),
array(
	"type" => "title",
	"title" => esc_html__("启用响应式",'trendyblog-theme'),
),

array(
	"type" => "checkbox",
	"title" => esc_html__("启用",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_responsive"
),

array(
	"type" => "close"
),
array(
	"type" => "row"
),
array(
	"type" => "title",
	"title" => esc_html__("显示返回顶部按钮",'trendyblog-theme'),
),

array(
	"type" => "checkbox",
	"title" => esc_html__("显示",'trendyblog-theme'),
	"id" => $different_themes_managment->themeslug."_backToTop"
),

array(
	"type" => "close"
),


array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("页面布局",'trendyblog-theme'),
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_page_layout",
	"radio" => array(
		array("title" => esc_html__("块状:",'trendyblog-theme'), "value" => "boxed"),
		array("title" => esc_html__("全宽:",'trendyblog-theme'), "value" => "wide"),
	),
),

array(
	"type" => "close"
),


array(
	"type" => "save",
	"title" => esc_html__("保存设置",'trendyblog-theme')
),
   
array(
	"type" => "closesubtab"
),

array(
	"type" => "closetab"
)
 
);

$different_themes_managment->add_options($differentThemes_slider_options);
?>