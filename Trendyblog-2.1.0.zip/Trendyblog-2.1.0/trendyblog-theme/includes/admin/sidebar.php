<?php
global $different_themes_managment;
$differentThemes_sidebar_options= array(
 array(
	"type" => "navigation",
	"name" => "边栏设置",
	"slug" => "sidebars"
),

array(
	"type" => "tab",
	"slug"=>'sidebar_settings'
),

array(
	"type" => "sub_navigation",
	"subname"=>array(
			array("slug"=>"sidebar", "name"=>esc_html__("边栏",'trendyblog-theme'))
		)
),

/* ------------------------------------------------------------------------*
 * SIDEBAR GENERATOR
 * ------------------------------------------------------------------------*/

 array(
	"type" => "sub_tab",
	"slug"=>'sidebar'
),
array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("默认主侧栏位置",'trendyblog-theme')
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_sidebar_position",
	"radio" => array(
		array("title" => esc_html__("左:",'trendyblog-theme'), "value" => "left"),
		array("title" => esc_html__("右:",'trendyblog-theme'), "value" => "right"),
		array("title" => esc_html__("为每个页面定制:",'trendyblog-theme'), "value" => "custom")
	),
	"std" => "custom"
),
array(
	"type" => "close"
),
/*
array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("Default Second Sidebar Position",'trendyblog-theme')
),

array(
	"type" => "radio",
	"id" => $different_themes_managment->themeslug."_sidebar_position_2",
	"radio" => array(
		array("title" => esc_html__("Left:",'trendyblog-theme'), "value" => "left"),
		array("title" => esc_html__("Right:",'trendyblog-theme'), "value" => "right"),
		array("title" => esc_html__("Custom For Each Page:",'trendyblog-theme'), "value" => "custom")
	),
	"std" => "custom"
),
array(
	"type" => "close"
),
*/
array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("启用固定边栏",'trendyblog-theme'),
),

array(
	"type" => "checkbox",
	"title" => esc_html__("让侧边栏跟随页面下拉",'trendyblog-theme'),
	"id"=>$different_themes_managment->themeslug."_sticky_sidebar"
),
   

array(
	"type" => "close"
), 
array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("添加侧边栏",'trendyblog-theme'),
),

array(
	"type" => "add_text",
	"title" => esc_html__("添加新侧边栏:",'trendyblog-theme'),
	"id" => THEME_NAME."_sidebar_name"
),

array(
	"type" => "close"
),

array(
	"type" => "row"
),

array(
	"type" => "title",
	"title" => esc_html__("侧栏序列",'trendyblog-theme'),
	"info" => esc_html__("要对幻灯片进行排序，只需将它们拖放即可！",'trendyblog-theme')
),

array(
	"type" => "sidebar_order",
	"title" => esc_html__("侧边栏排序",'trendyblog-theme'),
	"id" => THEME_NAME."_sidebar_name"
),
  
array(
	"type" => "close"
),
 
array(
	"type" => "closesubtab"
),

array(
	"type" => "closetab"
)
 
);

$different_themes_managment->add_options($differentThemes_sidebar_options);
?>