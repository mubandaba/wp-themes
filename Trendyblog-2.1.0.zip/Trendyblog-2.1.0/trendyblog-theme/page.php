<?php 

	get_header();
	get_template_part(THEME_INCLUDES."page","single");
	get_footer(); 

?>