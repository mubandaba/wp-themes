<?php
	if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
	get_header();
	get_template_part(THEME_INCLUDES."news");
	get_footer(); 
?>		