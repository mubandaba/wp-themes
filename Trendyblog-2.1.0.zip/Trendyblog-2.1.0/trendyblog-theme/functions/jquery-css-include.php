<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
	add_action( 'wp_enqueue_scripts', 'different_themes_scripts');
	
	function different_themes_scripts() { 
		global $wp_styles,$wp_scripts;
		$slider_enable = df_get_option(THEME_NAME."_slider_enable");
		$responsive = df_get_option(THEME_NAME."_responsive");
		$banner_type = df_get_option ( THEME_NAME."_banner_type" );

		//font settings	
		$_font_cyrillic_ex = df_get_option(THEME_NAME.'_font_cyrillic_ex');	
		$_font_cyrillic = df_get_option(THEME_NAME.'_font_cyrillic');	
		$_font_greek_ex = df_get_option(THEME_NAME.'_font_greek_ex');	
		$_font_greek = df_get_option(THEME_NAME.'_font_greek');	
		$_font_vietnamese = df_get_option(THEME_NAME.'_font_vietnamese');	
		$_font_latin_ex = df_get_option(THEME_NAME.'_font_latin_ex');	

		if($_font_cyrillic_ex=="on") {
			$_font_cyrillic_ex = ",cyrillic-ext";	
		} else {
			$_font_cyrillic_ex = false;
		}
		if($_font_cyrillic=="on") {
			$_font_cyrillic = ",cyrillic";	
		} else {
			$_font_cyrillic = false;
		}
		if($_font_greek_ex=="on") {
			$_font_greek_ex = ",greek-ext";	
		} else {
			$_font_greek_ex = false;
		}
		if($_font_greek=="on") {
			$_font_greek = ",greek";	
		} else {
			$_font_greek = false;
		}
		if($_font_vietnamese=="on") {
			$_font_vietnamese = ",vietnamese";	
		} else {
			$_font_vietnamese = false;
		}
		if($_font_latin_ex=="on") {
			$_font_latin_ex = ",latin-ext";	
		} else {
			$_font_latin_ex = false;
		}

		//include google fonts
		$google_fonts = array();
		for($i=1; $i<=5; $i++) {
			if(df_get_option(THEME_NAME."_google_font_".$i)) {
				$google_fonts[] = df_get_option(THEME_NAME."_google_font_".$i);	
			}
			
		}
		$google_fonts = array_unique($google_fonts);
		$i=1;
		foreach($google_fonts as $google_font) {
			$protocol = is_ssl() ? 'https' : 'http';
			if($google_font && $google_font!="Arial") {
				wp_enqueue_style( 'google-fonts-'.$i, $protocol."://fonts.googleapis.com/css?family=".str_replace(" ", "+", $google_font).":300,300italic,400,400italic,700,700italic&subset=latin".$_font_cyrillic_ex.$_font_cyrillic.$_font_greek_ex.$_font_greek.$_font_vietnamese.$_font_latin_ex);
			}
			$i++;
		}
		


		wp_enqueue_style("normalize", THEME_CSS_URL."normalize.css", Array());
		wp_enqueue_style("font-awesome", THEME_CSS_URL."fontawesome.css", Array());
		wp_enqueue_style("weather", THEME_CSS_URL."weather.css", Array());
		wp_enqueue_style("main-style", THEME_CSS_URL."style.css", Array());

		wp_enqueue_style("responsive-0", THEME_CSS_URL."responsive-0.css", Array(),'1.0', '(max-width:768px)');
		wp_enqueue_style("responsive-768", THEME_CSS_URL."responsive-768.css", Array(),'1.0', '(min-width:769px) and (max-width:992px)');
		wp_enqueue_style("responsive-992", THEME_CSS_URL."responsive-992.css", Array(),'1.0', '(min-width:993px) and (max-width:1200px)');
		wp_enqueue_style("responsive-1200", THEME_CSS_URL."responsive-1200.css", Array(),'1.0', '(min-width:1201px)');
		

		
		
		if($responsive!="on") {
			wp_enqueue_style("no-responsive", THEME_CSS_URL."no-responsive.css", Array(),'1.0');
		}
		//wp_enqueue_style('ie-only-styles', THEME_CSS_URL.'ie-ancient.css');
		//$wp_styles->add_data('ie-only-styles', 'conditional', 'lt IE 8');


 		wp_enqueue_style("style", get_stylesheet_uri(), Array());

 		// js files
		wp_enqueue_script("jquery");
		wp_enqueue_script("jquery-effects-slide");
		wp_enqueue_script("jquery-ui-accordion");
		wp_enqueue_script("jquery-ui-tabs");
		wp_enqueue_script("jquery-ui-spinner");
		wp_enqueue_script("cookies" , THEME_JS_URL."admin/jquery.c00kie.js", Array('jquery'), "1.0", true);
		
		if ($banner_type && $banner_type != "off" ) {
			wp_enqueue_script("banner" , THEME_JS_URL."jquery.floating_popup.1.3.min.js", Array('jquery'), "1.0", true);
		}


		
		wp_enqueue_script("easing" , THEME_JS_URL."easing.min.js", Array('jquery'), '', true);
		wp_enqueue_script("smoothscroll" , THEME_JS_URL."smoothscroll.min.js", Array('jquery'), '', true);

		wp_enqueue_script("magnific" , THEME_JS_URL."magnific.min.js", Array('jquery'), '', true);
		wp_enqueue_script("bxslider" , THEME_JS_URL."bxslider.min.js", Array('jquery'), '', false);
		wp_enqueue_script("fitvids" , THEME_JS_URL."fitvids.min.js", Array('jquery'), '', false);
		wp_enqueue_script("viewportchecker" , THEME_JS_URL."viewportchecker.js", Array('jquery'), '', true);


		wp_enqueue_script("stickysidebar" , THEME_JS_URL."stickysidebar.min.js", Array('jquery'), "", true);
		wp_enqueue_script(THEME_NAME."-scripts" , THEME_JS_URL."init.js", Array('jquery'), "", true);
		if ( is_singular() ) wp_enqueue_script( "comment-reply" );

		wp_enqueue_script("df-scripts" , THEME_JS_URL."scripts.js", Array('jquery'), "1.0", true);
		wp_enqueue_script("scripts-wp" , THEME_JS_URL.THEME_NAME.".js", Array('jquery'), "1.0.0", true);
		

		add_action( 'wp_head', function() {
		   echo '<!--[if lte IE 9]><script src="'.esc_url(THEME_JS_URL.'shiv.min.js').'"></script><![endif]-->';
		} );
		$post_type = get_post_type();
		if($post_type=="gallery") {
			$gallery_id =get_the_ID();
		} else { 
			$gallery_id = false;
		}
		
		wp_localize_script('jquery','df',
			array(
				'THEME_NAME' => THEME_NAME,
				'THEME_FULL_NAME' => THEME_FULL_NAME,
				'adminUrl' => admin_url("admin-ajax.php"),
				'gallery_id' => $gallery_id,
				'galleryCat' => get_query_var('gallery-cat'),
				'imageUrl' => THEME_IMAGE_URL,
				'cssUrl' => THEME_CSS_URL,
				'themeUrl' => THEME_URL,
				'pageurl' => esc_url( home_url( '/' ) )
			)
		);
		
	}
	
	function trendyblog_custom_style() {

		//banner settings
		$banner_type = df_get_option ( THEME_NAME."_banner_type" );

		//bg type
		$bg_type = df_get_option ( THEME_NAME."_body_bg_type" );
		$bg_color = df_get_option ( THEME_NAME."_body_color" );
		$bg_image = df_get_option ( THEME_NAME."_body_image" );
		$bg_image_repeat = df_get_option ( THEME_NAME."_body_image_repeat" );
		$bg_texture = df_get_option ( THEME_NAME."_body_pattern" );
		if(!$bg_texture) $bg_texture = "texture-1";
		

		//colors
		$color_1 = df_get_option(THEME_NAME."_color_1");
		$color_2 = df_get_option(THEME_NAME."_color_2");
		$color_3 = df_get_option(THEME_NAME."_color_3");
		$color_4 = df_get_option(THEME_NAME."_color_4");
		$color_5 = df_get_option(THEME_NAME."_color_5");
		$color_6 = df_get_option(THEME_NAME."_color_6");
		$color_7 = df_get_option(THEME_NAME."_color_7");
		$color_8 = df_get_option(THEME_NAME."_color_8");
		if(!$color_4) $color_4 = "222";
		if(!$color_5) $color_5 = "FC8D8D";
		if(!$color_6) $color_6 = "eee";
		if(!$color_7) $color_7 = "ddd";
		if(!$color_8) $color_8 = "999";


		//fonts
		$google_font_1 = df_get_option(THEME_NAME."_google_font_1");
		$google_font_2 = df_get_option(THEME_NAME."_google_font_2");
		$google_font_3 = df_get_option(THEME_NAME."_google_font_3");
		$google_font_4 = df_get_option(THEME_NAME."_google_font_4");
		
		$font_size_1 = df_get_option(THEME_NAME."_font_size_1");
		if(!$font_size_1) $font_size_1 = 14;		
		$font_size_2 = df_get_option(THEME_NAME."_font_size_2");
		if(!$font_size_2) $font_size_2 = 16;		
		$font_size_3 = df_get_option(THEME_NAME."_font_size_3");
		if(!$font_size_3) $font_size_3 = 12;		
		$font_size_4 = df_get_option(THEME_NAME."_font_size_4");
		if(!$font_size_4) $font_size_4 = 12;


		ob_start();
		?>

			/*------------------------------------------------------------------------------
			    Color
			    (link hover, weather forecast icon, weather forecast temp, logo span,
			    dropcap first letter, quotes, meta calendar icon)
			------------------------------------------------------------------------------*/
			a:hover,
			#header .header_meta .weather_forecast i,
			#header .header_meta .weather_forecast .temp,
			#site_title span,
			.dropcap:first-letter,
			.full_meta span.meta_date:before,
			.full_meta span.meta_comments:before,
			.full_meta span.meta_views:before,
			.full_meta span.meta_author i,
			blockquote p span:first-child,
			blockquote p span:last-child,
			.entry_media span.meta_likes a,
			article.post .entry_content p a,
			.full_meta span.meta_likes:before {
			    color: #<?php echo esc_html($color_1);?>;
			}

			/*------------------------------------------------------------------------------
			    Background
			    (mark, button, search icon in menu, format, tags hover, post format hover,
			    input submit, shop hover icon, pagination current link, shop button,
			    span format icon, review border, rating result, transition line, wide slider
			    controls, filter shop handle)
			------------------------------------------------------------------------------*/
			mark,
			.breaking-news .breaking-title,
			.search_icon_form a,
			.author_box .posts,
			span.format,
			.tagcloud a:hover,
			#footer .tagcloud a:hover,
			.item .item_thumb .thumb_icon a,
			input[type="submit"], 
			.thumb_meta span.category,
			ul.products li.product .item_thumb .thumb_icon a,
			ul.page-numbers li span.current,
			ul.products li.product a.btn:hover,
			.layout_post_1 .item_thumb .thumb_icon a,
			.full_meta span.meta_format,
			.review_footer span,
			.transition_line,
			.layout_post_2 .item_thumb .thumb_icon a,
			.list_posts .post .item_thumb .thumb_icon a,
			.wide_slider .bx-wrapper .bx-controls-direction a:hover,
			.ui-slider-range,
			#gallery_grid .gallery_album .item_thumb .thumb_icon a,
			.wc-proceed-to-checkout,
			.single_add_to_cart_button.btn_red,
			#back_to_top a:hover,
			.layout_post_4 .item_thumb .thumb_icon a {
			    background-color: #<?php echo esc_html($color_2);?>;
			}

			/*------------------------------------------------------------------------------
			    Border
			    (drop down menu, tags hover, slider pager top border)
			------------------------------------------------------------------------------*/
			nav.site_navigation ul.menu ul.sub-menu,
			nav.site_navigation ul.menu > li > .content,
			nav.site_navigation ul.menu > li.has_dt_mega_menu > ul.dt_mega_menu,
			.tagcloud a:hover:before,
			#footer .tagcloud a:hover:before,
			#wide_slider_pager .box.active {
			    border-color: #<?php echo esc_html($color_3);?>;
			}

			/*------------------------------------------------------------------------------
			    Heading colors in post content
			------------------------------------------------------------------------------*/
			.entry_content>h1:not(.page_title):not(.entry-title):not(.entry_title),
			.entry_content>h2,
			.entry_content>h3,
			.entry_content>h4,
			.entry_content>h5,
			.entry_content>h6,
			.entry_content>.row>.col>h1:not(.page_title):not(.entry-title):not(.entry_title),
			.entry_content>.row>.col>h2,
			.entry_content>.row>.col>h3,
			.entry_content>.row>.col>h4,
			.entry_content>.row>.col>h5,
			.entry_content>.row>.col>h6 {
			    color: #<?php echo esc_html($color_4);?>;
			}
			.entry_content .head_title h2 {
				color: #222;
			}

			.entry_content .head_title h2 {
				color: #222;
			}

			/*------------------------------------------------------------------------------
			    Content Link Color
			------------------------------------------------------------------------------*/

			.entry_content a:not(.ui-tabs-anchor):not(.btn):not(.gal-link):not(:hover) {
			    color: #<?php echo esc_html($color_5);?>;
			}

			/*------------------------------------------------------------------------------
			    Accordions background and color
			------------------------------------------------------------------------------*/
			.accordion_content .accordion_content_title {
				background-color: #<?php echo esc_html($color_6);?>;
			}

			/*------------------------------------------------------------------------------
			    Accordion icon background and color
			------------------------------------------------------------------------------*/
			.accordion_content .accordion_content_title:after {
				background-color: #<?php echo esc_html($color_7);?>;
				color: #<?php echo esc_html($color_8);?>;
			}


					/* Background Color/Texture/Image */
					body {
						<?php if($bg_type == "color") { ?>
							background: #<?php echo esc_html($bg_color);?>;
						<?php } else if ($bg_type == "pattern") { ?> 
							background: url(<?php echo esc_url(THEME_IMAGE_URL.$bg_texture.'.png');?>);
						<?php } else if ($bg_type == "image") { ?>
							background-image: url(<?php echo esc_url($bg_image);?>);
							<?php if(!$bg_image_repeat || $bg_image_repeat=="no-repeat") { ?>
								background-attachment: fixed;
								background-size: 100%; 
							<?php } elseif($bg_image_repeat) { ?>
								background-repeat: <?php echo esc_html($bg_image_repeat);?>;
							<?php } ?>
						<?php } else { ?>
							background: #<?php echo esc_html($bg_color);?>;
						<?php } ?>

					}

					<?php
						if ( $banner_type == "image" ) {
						//Image Banner
					?>
							#overlay { width:100%; height:100%; position:fixed;  _position:absolute; top:0; left:0; z-index:1001; background-color:#000000; overflow: hidden;  }
							#popup { display: none; position:absolute; width:auto; height:auto; z-index:1002; color: #000; font-family: Tahoma,sans-serif;font-size: 14px; }
							#baner_close { width: 22px; height: 25px; background: url(<?php echo esc_url(get_template_directory_uri().'/images/close.png');?>) 0 0 repeat; text-indent: -5000px; position: absolute; right: -10px; top: -10px; }
					<?php
						} else if ( $banner_type == "text" ) {
						//Text Banner
					?>
							#overlay { width:100%; height:100%; position:fixed;  _position:absolute; top:0; left:0; z-index:1001; background-color:#000000; overflow: hidden;  }
							#popup { display: none; position:absolute; width:auto; height:auto; max-width:700px; z-index:1002; border: 1px solid #000; background: #e5e5e5 url(<?php echo esc_url(get_template_directory_uri().'/images/dotted-bg-6.png');?>) 0 0 repeat; color: #000; font-family: Tahoma,sans-serif;font-size: 14px; line-height: 24px; border: 1px solid #cccccc; -moz-border-radius: 4px; -webkit-border-radius: 4px; border-radius: 4px; text-shadow: #fff 0 1px 0; }
							#popup center { display: block; padding: 20px 20px 20px 20px; }
							#baner_close { width: 22px; height: 25px; background: url(<?php echo esc_url(get_template_directory_uri().'/images/close.png');?>) 0 0 repeat; text-indent: -5000px; position: absolute; right: -12px; top: -12px; }
					<?php 
						} else if ( $banner_type == "text_image" ) {
						//Image And Text Banner
					?>
							#overlay { width:100%; height:100%; position:fixed;  _position:absolute; top:0; left:0; z-index:1001; background-color:#000000; overflow: hidden;  }
							#popup { display: none; position:absolute; width:auto; z-index:1002; color: #000; font-size: 11px; font-weight: bold; }
							#popup center { padding: 15px 0 0 0; }
							#baner_close { width: 22px; height: 25px; background: url(<?php echo esc_url(get_template_directory_uri().'/images/close.png');?>) 0 0 repeat; text-indent: -5000px; position: absolute; right: -10px; top: -10px; }
					<?php } ?>

		/*------------------------------------------------------------------------------
		    Body
		------------------------------------------------------------------------------*/
		body {
		    font-family: "<?php echo esc_html($google_font_1);?>", sans-serif;
		    font-size: <?php echo intval($font_size_1);?>px;
		}
		/*------------------------------------------------------------------------------
		    Main Menu
		------------------------------------------------------------------------------*/
		nav.site_navigation ul.menu > li > a {
		    font-size: <?php echo intval($font_size_2);?>px;
		}
		nav.site_navigation ul.menu > li > a > div.subtitle {
			font-size: <?php echo intval($font_size_3);?>px;
		}
		nav.site_navigation ul.menu ul.sub-menu {
			font-size: <?php echo intval($font_size_4);?>px;
		}
		/*------------------------------------------------------------------------------
		    Headings
		    (headings, menu links, dropcap first letter, panel subtitle)
		------------------------------------------------------------------------------*/
		h1,
		h2,
		h3,
		h4,
		h5,
		h6,
		nav.site_navigation ul.menu > li > a,
		.dropcap:first-letter,
		.panel_title span {
		    font-family: "<?php echo esc_html($google_font_2);?>", sans-serif
		}


		<?php
	    $custom_css = ob_get_contents();
		ob_end_clean();

	    wp_add_inline_style( 'main-style', $custom_css );

	}

	add_action( 'wp_enqueue_scripts', 'trendyblog_custom_style' );


	//add custom js
	function trendyblog_custom_js() {

		ob_start();
	?>
				//form validation
				function validateName(fld) {
					"use strict";
					var error = "";
							
					if (fld.value === '' || fld.value === 'Nickname' || fld.value === 'Enter Your Name..' || fld.value === 'Your Name..') {
						error = "<?php  echo esc_attr__("You did not enter your first name." , 'trendyblog-theme' );?>";
					} else if ((fld.value.length < 2) || (fld.value.length > 200)) {
						error = "<?php echo esc_attr__( 'First name is the wrong length.' , 'trendyblog-theme' );?>";
					}
					return error;
				}
						
				function validateEmail(fld) {
					"use strict";
					var error="";
					var illegalChars = /^[^@]+@[^@.]+\.[^@]*\w\w$/;
							
					if (fld.value === "") {
						error = "<?php echo esc_attr__( "You did not enter an email address." , 'trendyblog-theme' );?>";
					} else if ( fld.value.match(illegalChars) === null) {
						error = "<?php echo esc_attr__( 'The email address contains illegal characters.' , 'trendyblog-theme' );?>";
					}

					return error;

				}
						
				function valName(text) {
					"use strict";
					var error = "";
							
					if (text === '' || text === 'Nickname' || text === 'Enter Your Name..' || text === 'Your Name..') {
						error = "<?php echo esc_attr__( "You did not enter Your First Name." , 'trendyblog-theme' );?>";
					} else if ((text.length < 2) || (text.length > 50)) {
						error = "<?php echo esc_attr__( 'First Name is the wrong length.' , 'trendyblog-theme' );?>";
					}
					return error;
				}
						
				function valEmail(text) {
					"use strict";
					var error="";
					var illegalChars = /^[^@]+@[^@.]+\.[^@]*\w\w$/;
							
					if (text === "") {
						error = "<?php echo esc_attr__( "You did not enter an email address." , 'trendyblog-theme' );?>";
					} else if ( text.match(illegalChars) === null) {
						error = "<?php echo esc_attr__( 'The email address contains illegal characters.' , 'trendyblog-theme' );?>";
					}

					return error;

				}
						
				function validateMessage(fld) {
					"use strict";
					var error = "";
							
					if (fld.value === '') {
						error = "<?php echo esc_attr__( "You did not enter Your message." , 'trendyblog-theme' );?>";
					} else if (fld.value.length < 3) {
						error = "<?php echo esc_attr__( 'The message is to short.' , 'trendyblog-theme' );?>";
					}

					return error;
				}		

				function validatecheckbox() {
					"use strict";
					var error = "<?php echo esc_attr__( 'Please select at least one checkbox!' , 'trendyblog-theme' );?>";
					return error;
				}
	<?php

   	 	$custom_js = ob_get_contents();
		ob_end_clean();

		wp_add_inline_script( "scripts-wp", $custom_js );
	}

	add_action( 'wp_enqueue_scripts', 'trendyblog_custom_js' );

?>