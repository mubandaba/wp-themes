<?php
global $differentThemes_fields;
$differentThemes_general_options= array(



/* ------------------------------------------------------------------------*
 * HOME SETTINGS
 * ------------------------------------------------------------------------*/   

array(
	"type" => "homepage_blocks",
	"title" => esc_html__("Homepage Blocks:",'trendyblog-theme'),
	"id" => $differentThemes_fields->themeslug."_homepage_blocks",
	"blocks" => array(
		array(
			"title" => esc_html__("Latest,Popular or Category News",'trendyblog-theme'),
			"type" => "homepage_news_block",
			"image" => "icon-article.png",
			"description" => esc_html__("Latest news, category news or popular news post listing, with several layouts",'trendyblog-theme'),
			"options" => array(
				array(
					"type" => "select",
					"title" => esc_html__("Block Style:",'trendyblog-theme'),
					"id" => $differentThemes_fields->themeslug."_style",
					"options"=>array(
						array("slug"=>"1", "name"=>esc_html__("Main Post Left, With Post listing on Right",'trendyblog-theme')), 
						array("slug"=>"2", "name"=>esc_html__("Simple Post Listing",'trendyblog-theme')), 
						array("slug"=>"3", "name"=>esc_html__("Grid View (3 posts in row)",'trendyblog-theme')), 
						array("slug"=>"4", "name"=>esc_html__("Grid View (2 posts in row)",'trendyblog-theme')), 
						array("slug"=>"5", "name"=>esc_html__("Post List Without Images",'trendyblog-theme')), 
						array("slug"=>"6", "name"=>esc_html__("Post List With First Large Image and Other Small",'trendyblog-theme')), 
						array("slug"=>"7", "name"=>esc_html__("Similar To Reviews Style",'trendyblog-theme')), 
						array("slug"=>"8", "name"=>esc_html__("Grid Block With Large Background Image",'trendyblog-theme')), 
						array("slug"=>"9", "name"=>esc_html__("Post List With Large Image And Yitle Above Image",'trendyblog-theme')), 
						array("slug"=>"10", "name"=>esc_html__("Touch Carousel",'trendyblog-theme')), 
					),
					"home" => "yes"
				),	
				array( "type" => "input", "id" => $differentThemes_fields->themeslug."_title", "title" => esc_html__("Title:",'trendyblog-theme'), "home" => "yes" ),
				array( "type" => "scroller", "id" => $differentThemes_fields->themeslug."_count", "title" => esc_html__("Count:",'trendyblog-theme'), "max" => 30, "home" => "yes" ),
				array(
					"type" => "select",
					"title" => esc_html__("Block Type:",'trendyblog-theme'),
					"id" => $differentThemes_fields->themeslug."_type",
					"options"=>array(
						array("slug"=>"1", "name"=>esc_html__("Latest News",'trendyblog-theme')), 
						array("slug"=>"2", "name"=>esc_html__("Popular News",'trendyblog-theme')), 
						array("slug"=>"3", "name"=>esc_html__("Random News",'trendyblog-theme')), 
					),
					"home" => "yes"
				),
				array(
					"type" => "multiple_select",
					"id" => $differentThemes_fields->themeslug."_cat",
					"taxonomy" => "category",
					"title" => esc_html__("Filter by Categories",'trendyblog-theme'),
					"home" => "yes"
				),
				array( "type" => "input", "id" => $differentThemes_fields->themeslug."_offset", "title" => esc_html__("From which post should start the loop (for example 4 ), for default leave it empty, or add 0. (Offset):",'trendyblog-theme'), "home" => "yes" ),


			),
		),

		array(
			"title" => esc_html__("Shop",'trendyblog-theme'),
			"type" => "homepage_news_block_2",
			"image" => "icon-shop.png",
			"description" => esc_html__("Shop Items",'trendyblog-theme'),
			"options" => array(
				array( "type" => "input", "id" => $differentThemes_fields->themeslug."_title", "title" => esc_html__("Title:",'trendyblog-theme'), "home" => "yes" ),
				array( "type" => "scroller", "id" => $differentThemes_fields->themeslug."_count", "title" => esc_html__("Count:",'trendyblog-theme'), "max" => 30, "home" => "yes" ),
				array(
					"type" => "categories",
					"id" => $differentThemes_fields->themeslug."_cat",
					"taxonomy" => "product_cat",
					"title" => esc_html__("Set Category",'trendyblog-theme'),
					"home" => "yes"
				),
				array( "type" => "input", "id" => $differentThemes_fields->themeslug."_offset", "title" => esc_html__("From which post should start the loop (for example 4 ), for default leave it empty, or add 0. (Offset):",'trendyblog-theme'), "home" => "yes" ),
				array(
					"type" => "select",
					"title" => esc_html__("Type:",'trendyblog-theme'),
					"id" => $differentThemes_fields->themeslug."_type",
					"options"=>array(
						array("slug"=>"1", "name"=>esc_html__("Latest",'trendyblog-theme')), 
						array("slug"=>"2", "name"=>esc_html__("Featured",'trendyblog-theme')), 
					),
					"home" => "yes"
				),	
				
			),
		),
		array(
			"title" => esc_html__("Reviews",'trendyblog-theme'),
			"type" => "homepage_news_block_3",
			"image" => "icon-review.png",
			"description" => esc_html__("Latest/Top reviews.",'trendyblog-theme'),
			"options" => array(

				array( "type" => "input", "id" => $differentThemes_fields->themeslug."_title", "title" => esc_html__("Title:",'trendyblog-theme'), "home" => "yes" ),
				array( "type" => "scroller", "id" => $differentThemes_fields->themeslug."_count", "title" => esc_html__("Count:",'trendyblog-theme'), "max" => 30, "home" => "yes" ),
				array(
					"type" => "multiple_select",
					"id" => $differentThemes_fields->themeslug."_cat",
					"taxonomy" => "category",
					"title" => esc_html__("Filter by Categories",'trendyblog-theme'),
					"home" => "yes"
				),
				array( "type" => "input", "id" => $differentThemes_fields->themeslug."_offset", "title" => esc_html__("From which post should start the loop (for example 4 ), for default leave it empty, or add 0. (Offset):",'trendyblog-theme'), "home" => "yes" ),
				array(
					"type" => "select",
					"title" => esc_html__("Type:",'trendyblog-theme'),
					"id" => $differentThemes_fields->themeslug."_type",
					"options"=>array(
						array("slug"=>"latest", "name"=>esc_html__("Latest Reviews",'trendyblog-theme')), 
						array("slug"=>"top", "name"=>esc_html__("Top Reviews",'trendyblog-theme')), 
					),
					"home" => "yes"
				),				

			),
		),
		array(
			"title" => esc_html__("Text Block",'trendyblog-theme'),
			"type" => "text_block",
			"image" => "icon-text.png",
			"description" => esc_html__("Custom Text Block/Shortcodes Block",'trendyblog-theme'),
			"options" => array(
				array( "type" => "textarea", "id" => $differentThemes_fields->themeslug."_text", "title" => esc_html__("Text:",'trendyblog-theme'), "editor" => "yes", "home" => "yes" ),
			),
		),
		array(
			"title" => esc_html__("HTML Code",'trendyblog-theme'),
			"type" => "homepage_html",
			"image" => "icon-html.png",
			"description" => esc_html__("Custom HTML/Shortcodes Block",'trendyblog-theme'),
			"options" => array(
				array( "type" => "textarea", "id" => $differentThemes_fields->themeslug."_html", "title" => esc_html__("Code/Text:",'trendyblog-theme'), "home" => "yes" ),
			),
		),
		array(
			"title" => esc_html__("Banner Block",'trendyblog-theme'),
			"type" => "homepage_banner",
			"image" => "icon-banner.png",
			"description" => esc_html__("Supports HTML,CSS, Javascript and Shortcodes.",'trendyblog-theme'),
			"options" => array(
				array( "type" => "textarea", "id" => $differentThemes_fields->themeslug."_banner", "title" => esc_html__("Code/Text:",'trendyblog-theme'), "home" => "yes","sample" => '<a href="http://themeforest.net/user/different-themes/portfolio?ref=different-themes" target="_blank"><img src="'.esc_url(THEME_IMAGE_URL.'970x140.png').'" alt="Banner"></a>', ),
			),
		),

	)
),


 
 );


$differentThemes_fields->add_options($differentThemes_general_options);
?>