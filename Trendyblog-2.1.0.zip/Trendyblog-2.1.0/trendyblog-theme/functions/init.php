<?php
	
	require_once(THEME_FUNCTIONS_PATH.'breadcrumbs.php');
	require_once(THEME_FUNCTIONS_PATH.'filters.php');
	require_once(THEME_FUNCTIONS_PATH.'register.php');
	require_once(THEME_FUNCTIONS_PATH.'resize.php');
	require_once(THEME_FUNCTIONS_PATH.'thumbs.php');
	require_once(THEME_FUNCTIONS_PATH.'nav.php');
	require_once(THEME_FUNCTIONS_PATH.'homepage-blocks.php');
	
	require_once(THEME_FUNCTIONS_PATH.'other.php');
	
	require_once(THEME_FUNCTIONS_PATH.'jquery-css-include.php');
	require_once(THEME_FUNCTIONS_PATH.'custom-admin-menu.php');
	

	require_once(THEME_FUNCTIONS_PATH.THEME_NAME.'-menu.php');
	require_once(THEME_FUNCTIONS_PATH.'ajax.php');



?>