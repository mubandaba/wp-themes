<?php
remove_action('wp_head', 'feed_links', 2);
remove_action('wp_head', 'feed_links_extra', 3);
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'index_rel_link');
remove_action('wp_head', 'parent_post_rel_link', 10, 0);
remove_action('wp_head', 'start_post_rel_link', 10, 0);
remove_action('wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);
remove_action('wp_head', 'locale_stylesheet');
remove_action('publish_future_post', 'check_and_publish_future_post', 10, 1);
remove_action('wp_head', 'noindex', 1);
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'rel_canonical');
remove_action('wp_footer', 'wp_print_footer_scripts');
remove_action('wp_head', 'wp_shortlink_wp_head', 10, 0);
remove_action('template_redirect', 'wp_shortlink_header', 11, 0);
add_action('wp_dashboard_setup', 'example_remove_dashboard_widgets');
remove_action('welcome_panel', 'wp_welcome_panel');
add_action('admin_init', 'remove_dashboard_meta');
register_nav_menus(array('main' => __('列表导航')));
add_filter('contextual_help', 'wpse50723_remove_help', 999, 3);
add_filter('rest_enabled', '_return_false');
add_filter('rest_jsonp_enabled', '_return_false');
remove_action('wp_head', 'rest_output_link_wp_head', 10);
remove_action('wp_head', 'wp_oembed_add_discovery_links', 10);
add_filter('admin_title', 'wpdx_custom_admin_title', 10, 2);
add_filter('rest_enabled', '_return_false');
add_filter('rest_jsonp_enabled', '_return_false');
remove_action('wp_head', 'rest_output_link_wp_head', 10);
remove_action('wp_head', 'wp_oembed_add_discovery_links', 10);
add_action('init', 'disable_emojis');
add_filter('wp_resource_hints', 'remove_dns_prefetch', 10, 2);
add_filter('style_loader_src', 'wpdaxue_remove_cssjs_ver', 999);
add_filter('script_loader_src', 'wpdaxue_remove_cssjs_ver', 999);
add_action('init', 'disable_embeds_init', 9999);
register_activation_hook(__FILE__, 'disable_embeds_remove_rewrite_rules');
register_deactivation_hook(__FILE__, 'disable_embeds_flush_rewrite_rules');
add_filter('the_content', 'v7v3_seo_wl');
add_filter('the_content', 'imagesalt');
add_filter('admin_footer_text', 'remove_footer_admin');
add_action('admin_head', 'custom_logo');
add_filter('image_size_names_choose', 'ztmao_remove_image_size');
remove_filter('the_content', array(0 => $GLOBALS['wp_embed'], 1 => 'autoembed'), 8);
add_action('init', 'remove_open_sans');
remove_filter('the_content', 'wptexturize');
add_filter('mce_buttons_3', 'enable_more_buttons');
add_filter('tiny_mce_before_init', 'custum_fontfamily');
add_filter('category_description', 'deletehtml');
add_filter('contextual_help', 'Uazoh_remove_help_tabs', 10, 3);
add_filter('pre_get_posts', 'search_filter_page');
add_filter('the_content', 'wd_content');
add_action('load-themes.php', 'no_category_base_refresh_rules');
add_action('created_category', 'no_category_base_refresh_rules');
add_action('edited_category', 'no_category_base_refresh_rules');
add_action('delete_category', 'no_category_base_refresh_rules');
add_action('init', 'no_category_base_permastruct');
add_filter('category_rewrite_rules', 'no_category_base_rewrite_rules');
add_filter('query_vars', 'no_category_base_query_vars');
add_filter('request', 'no_category_base_request');
global $texonomy_slug_keywords;
$texonomy_slug_keywords = 'category';
add_action($texonomy_slug_keywords . '_add_form_fields', 'categorykeywords');
add_action($texonomy_slug_keywords . '_edit_form_fields', 'categorykeywordsedit');
add_action('edit_term', 'categorykeywordssave');
add_action('create_term', 'categorykeywordssave');
add_action('customize_register', 'puma_customize_register');
add_action('customize_register', 'lgurl_customize_register');
add_action('customize_register', 'bt_customize_register');
add_action('customize_register', 'sygjc_customize_register');
add_action('customize_register', 'ms_customize_register');
function example_remove_dashboard_widgets()
{
    global $wp_meta_boxes;
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_quick_press']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_incoming_links']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_plugins']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_recent_comments']);
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_recent_drafts']);
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_primary']);
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_secondary']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_right_now']);
}
function remove_dashboard_meta()
{
    remove_meta_box('dashboard_activity', 'dashboard', 'normal');
}
function wpse50723_remove_help($old_help, $screen_id, $screen)
{
    $screen->remove_help_tabs();
    return $old_help;
}
function wpdx_custom_admin_title($admin_title, $title)
{
    return $title . ' &lsaquo; ' . get_bloginfo('name');
}
function disable_emojis()
{
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('admin_print_scripts', 'print_emoji_detection_script');
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_action('admin_print_styles', 'print_emoji_styles');
    remove_filter('the_content_feed', 'wp_staticize_emoji');
    remove_filter('comment_text_rss', 'wp_staticize_emoji');
    remove_filter('wp_mail', 'wp_staticize_emoji_for_email');
    add_filter('tiny_mce_plugins', 'disable_emojis_tinymce');
}
function disable_emojis_tinymce($plugins)
{
    if (is_array($plugins)) {
        return array_diff($plugins, array(0 => 'wpemoji'));
    }
    return array();
}
function remove_dns_prefetch($hints, $relation_type)
{
    if ('dns-prefetch' === $relation_type) {
        return array_diff(wp_dependencies_unique_hosts(), $hints);
    }
    return $hints;
}
function wpdaxue_remove_cssjs_ver($src)
{
    if (strpos($src, 'ver=')) {
        $src = remove_query_arg('ver', $src);
    }
    return $src;
}
function disable_embeds_init()
{
    global $wp;
    $wp->public_query_vars = array_diff($wp->public_query_vars, array(0 => 'embed'));
    remove_action('rest_api_init', 'wp_oembed_register_route');
    add_filter('embed_oembed_discover', '__return_false');
    remove_filter('oembed_dataparse', 'wp_filter_oembed_result', 10);
    remove_action('wp_head', 'wp_oembed_add_discovery_links');
    remove_action('wp_head', 'wp_oembed_add_host_js');
    add_filter('tiny_mce_plugins', 'disable_embeds_tiny_mce_plugin');
    add_filter('rewrite_rules_array', 'disable_embeds_rewrites');
}
function disable_embeds_tiny_mce_plugin($plugins)
{
    return array_diff($plugins, array(0 => 'wpembed'));
}
function disable_embeds_rewrites($rules)
{
    foreach ($rules as $rule => $rewrite) {
        if (false !== strpos($rewrite, 'embed=true')) {
            unset($rules[$rule]);
        }
    }
    return $rules;
}
function disable_embeds_remove_rewrite_rules()
{
    add_filter('rewrite_rules_array', 'disable_embeds_rewrites');
    flush_rewrite_rules();
}
function disable_embeds_flush_rewrite_rules()
{
    remove_filter('rewrite_rules_array', 'disable_embeds_rewrites');
    flush_rewrite_rules();
}
function v7v3_seo_wl($content)
{
    $regexp = '<a\s[^>]*href=("??)([^" >]*?)\1[^>]*>';
    if (preg_match_all('/' . $regexp . '/siU', $content, $matches, PREG_SET_ORDER)) {
        if (!empty($matches)) {
            $srcUrl = get_option('siteurl');
            $i = 0;
            while ($i < count($matches)) {
                $tag = $matches[$i][0];
                $tag2 = $matches[$i][0];
                $url = $matches[$i][0];
                $noFollow = '';
                $pattern = '/target\s*=\s*"\s*_blank\s*"/';
                preg_match($pattern, $tag2, $match, PREG_OFFSET_CAPTURE);
                if (count($match) < 1) {
                    $noFollow .= ' target="_blank" ';
                }
                $pattern = '/rel\s*=\s*"\s*[n|d]ofollow\s*"/';
                preg_match($pattern, $tag2, $match, PREG_OFFSET_CAPTURE);
                if (count($match) < 1) {
                    $noFollow .= ' rel="nofollow" ';
                }
                $pos = strpos($url, $srcUrl);
                if ($pos === false) {
                    $tag = rtrim($tag, '>');
                    $tag .= $noFollow . '>';
                    $content = str_replace($tag2, $tag, $content);
                }
                $i = $i + 1;
            }
        }
    }
    $content = str_replace(']]>', ']]>', $content);
    return $content;
}
function imagesalt($content)
{
    global $post;
    $pattern = '/<a(.*?)href=(\'|")(.*?).(bmp|gif|jpeg|jpg|png)(\'|")(.*?)>/i';
    $replacement = '<a$1href=$2$3.$4$5 alt="' . $post->post_title . '" title="' . $post->post_title . '"$6>';
    $content = preg_replace($pattern, $replacement, $content);
    return $content;
}
function remove_footer_admin()
{
    echo '感谢选择 <a href="http://wordbook.wpke.net" target="_blank">WordBook</a> 进行内容维护！</p>';
}
function custom_logo()
{
    echo '<style type="text/css">
    #wp-admin-bar-wp-logo { display: none !important; }
    .form-field td img{width: 200px;}
    *{text-shadow:none!important;}
    .ybpjc{}
    .ybpjc h3{margin-top: -10px;background: #f3f2f2;padding: 2px 10px;}
    .jcbox li{padding-bottom:10px;line-height:26px;}
    </style>';
}
function ztmao_remove_image_size($sizes)
{
    unset($sizes['small']);
    unset($sizes['medium']);
    unset($sizes['large']);
    return $sizes;
}
function remove_open_sans()
{
    wp_deregister_style('open-sans');
    wp_register_style('open-sans', false);
    wp_enqueue_style('open-sans', '');
}
function enable_more_buttons($buttons)
{
    $buttons[] = 'del';
    $buttons[] = 'sub';
    $buttons[] = 'sup';
    $buttons[] = 'fontselect';
    $buttons[] = 'fontsizeselect';
    $buttons[] = 'cleanup';
    $buttons[] = 'styleselect';
    $buttons[] = 'wp_page';
    $buttons[] = 'anchor';
    $buttons[] = 'backcolor';
    return $buttons;
}
function custum_fontfamily($initArray)
{
    $initArray['font_formats'] = '微软雅黑=\'微软雅黑\';宋体=\'宋体\';黑体=\'黑体\';仿宋=\'仿宋\';楷体=\'楷体\';隶书=\'隶书\';幼圆=\'幼圆\';';
    return $initArray;
}
function deletehtml($description)
{
    $description = trim($description);
    $description = strip_tags($description, '');
    return $description;
}
function Uazoh_remove_help_tabs($old_help, $screen_id, $screen)
{
    $screen->remove_help_tabs();
    return $old_help;
}
function search_filter_page($query)
{
    if ($query->is_search) {
        $query->set('post_type', 'post');
    }
    return $query;
}
function replace_heading($content)
{
    global $toc_count;
    global $toc;
    $toc_count = $toc_count + 1;
    $toc[] = array('text' => trim(strip_tags($content[3])), 'depth' => $content[1], 'count' => $toc_count);
    return '<h' . $content[1] . ' id="' . $content[3] . '">' . $content[3] . '<a data-anchorjs-icon="" class="anchorjs-link" href="#' . $content[3] . '"></a></h' . $content[1] . '>';
}
function wd_content($content)
{
    $depe = 6;
    global $toc_count;
    global $toc;
    $toc = array();
    $toc_count = 0;
    $regex = '/<h([1-' . $depe . '])(.*?)>(.*?)<\/h\1>/';
    $content = preg_replace_callback($regex, 'replace_heading', $content);
    return $content;
}
function no_category_base_refresh_rules()
{
    global $wp_rewrite;
    $wp_rewrite->flush_rules();
}
function no_category_base_permastruct()
{
    global $wp_rewrite;
    global $wp_version;
    if (version_compare($wp_version, '3.4', '<')) {
        $wp_rewrite->extra_permastructs['category'][0] = '%category%';
    } else {
        $wp_rewrite->extra_permastructs['category']['struct'] = '%category%';
    }
}
function no_category_base_rewrite_rules($category_rewrite)
{
    $category_rewrite = array();
    $categories = get_categories(array('hide_empty' => false));
    foreach ($categories as $category) {
        $category_nicename = $category->slug;
        if ($category->parent == $category->cat_ID) {
            $category->parent = 0;
        } else {
            if (!($category->parent == 0)) {
                $category_nicename = get_category_parents($category->parent, false, '/', true) . $category_nicename;
            }
        }
        $category_rewrite['(' . $category_nicename . ')/(?:feed/)?(feed|rdf|rss|rss2|atom)/?$'] = 'index.php?category_name=$matches[1]&feed=$matches[2]';
        $category_rewrite['(' . $category_nicename . ')/page/?([0-9]{1,})/?$'] = 'index.php?category_name=$matches[1]&paged=$matches[2]';
        $category_rewrite['(' . $category_nicename . ')/?$'] = 'index.php?category_name=$matches[1]';
    }
    global $wp_rewrite;
    $old_category_base = get_option('category_base') ? get_option('category_base') : 'category';
    $old_category_base = trim($old_category_base, '/');
    $category_rewrite[$old_category_base . '/(.*)$'] = 'index.php?category_redirect=$matches[1]';
    return $category_rewrite;
}
function no_category_base_query_vars($public_query_vars)
{
    $public_query_vars[] = 'category_redirect';
    return $public_query_vars;
}
function no_category_base_request($query_vars)
{
    if (isset($query_vars['category_redirect'])) {
        $catlink = trailingslashit(get_option('home')) . user_trailingslashit($query_vars['category_redirect'], 'category');
        status_header(301);
        header('Location: ' . $catlink);
        exit(0);
    }
    return $query_vars;
}
function categorykeywords($taxonomy)
{
    echo '<div>
<label for="tag-keywords">分类关键词</label>
<input type="text" name="tag-keywords" id="tag-keywords" value="" /><br /><span>请在此输入分类关键词,多个之间用英文逗号隔开</span> 
</div>
';
}
function categorykeywordsedit($taxonomy)
{
    echo '<tr class="form-field">
<th scope="row" valign="top"><label for="tag-keywords">关键词</label></th>
<td><input type="text" name="tag-keywords" id="tag-keywords" value="';
    echo get_option('_category_keywords' . $taxonomy->term_id);
    echo '" /><br /><span class="description">请在此输入分类关键词,多个之间用英文逗号隔开</span></td>
</tr> 
';
}
function categorykeywordssave($term_id)
{
    if (isset($_POST['tag-keywords'])) {
        if (isset($_POST['tag-keywords'])) {
            update_option('_category_keywords' . $term_id, $_POST['tag-keywords']);
        }
    }
}
function puma_customize_register($wp_customize)
{
    $wp_customize->add_section('header_logo', array('title' => '网站LOGO', 'priority' => 50));
    $wp_customize->add_setting('header_logo_image', array('default' => '', 'transport' => 'postMessage', 'type' => 'option'));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'header_logo_image', array('label' => '网站LOGO', 'section' => 'header_logo')));
}
function lgurl_customize_register($wp_customize)
{
    $wp_customize->add_section('logourl', array('title' => 'LOGO超链接', 'priority' => 50));
    $wp_customize->add_setting('logourl', array('default' => '', 'transport' => 'postMessage', 'type' => 'option'));
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'logourl', array('label' => 'LOGO超链接', 'section' => 'logourl')));
}
function bt_customize_register($wp_customize)
{
    $wp_customize->add_section('sybiaoti', array('title' => '网站首页标题', 'priority' => 50));
    $wp_customize->add_setting('sybiaoti', array('default' => '', 'transport' => 'postMessage', 'type' => 'option'));
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'sybiaoti', array('label' => '网站首页标题', 'section' => 'sybiaoti')));
}
function sygjc_customize_register($wp_customize)
{
    $wp_customize->add_section('sygjc', array('title' => '网站首页关键词', 'priority' => 50));
    $wp_customize->add_setting('sygjc', array('default' => '', 'transport' => 'postMessage', 'type' => 'option'));
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'sygjc', array('label' => '网站首页关键词', 'section' => 'sygjc')));
}
function ms_customize_register($wp_customize)
{
    $wp_customize->add_section('footbanquan', array('title' => '网站底部版权', 'priority' => 50));
    $wp_customize->add_setting('footbanquan', array('default' => '', 'transport' => 'postMessage', 'type' => 'option'));
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'footbanquan', array('label' => '网站底部版权信息', 'section' => 'footbanquan')));
}