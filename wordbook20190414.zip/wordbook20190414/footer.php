<script src="<?php bloginfo('template_directory'); ?>/js/js.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/wordbook.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/theme.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/bootstrap.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/fontsettings.js"></script>
<?php wp_footer();?>
</body>
</html>