<?php get_header(); ?>
<div class="book-body">
    <div class="body-inner">
		<div class="book-header" role="navigation">
			<div class="pull-right">
                <div class="bdsharebuttonbox">
 
                </div>
            </div>
		    <h1><a href="<?php global $wp; $current_url = home_url(add_query_arg(array(),$wp->request));echo $current_url;?>"><?php single_cat_title(); ?></a></h1>
		</div> 
		<div class="page-wrapper" tabindex="-1" role="main">
			<div class="page-inner">
				<section class="normal markdown-section">
				<h1 id="<?php single_cat_title(); ?>"><?php single_cat_title(); ?><a class="anchorjs-link " href="#<?php single_cat_title(); ?>" data-anchorjs-icon=""></a></h1>
				<p><span class="sa-last-update-time">最后更新于：<?php the_modified_time('Y-m-d H:i:s'); ?></span></p>
				<p><?php echo category_description(); ?> </p>
				<ul>
				<?php while( have_posts() ): the_post(); ?>
					<li><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></li>
				<?php endwhile; ?>
				</ul>
				<div class="posts-nav clearfix">
					<?php echo paginate_links(array(  
					    'prev_next' => 1,  
					    'before_page_number' => '',  
					    'mid_size' => 4,  
					    'prev_text' => __('<'),  
					    'next_text' => __('>'),  
					));  
					?>
				</div>
			</div>
		</div>
        <div class="banquan">
            <?php echo get_option('footbanquan'); ?>
        </div>
    </div>
    <a href="" rel="nofollow" class="navigation navigation-prev" id="shangyige">
        <i class="fa fa-angle-left"></i>
    </a>
    <a href="" rel="nofollow" class="navigation navigation-next" id="xiayige">
        <i class="fa fa-angle-right"></i>
    </a>
</div>
</div>
<?php get_footer(); ?>