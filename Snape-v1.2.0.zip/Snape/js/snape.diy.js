/* Snape Javascript Plus */
