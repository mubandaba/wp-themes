<?php if(pk_is_checked('ad_g_top_c')): ?>
    <div class="puock-text p-block t-md ad-global-top">
        <?php echo pk_get_option('ad_g_top','') ?>
    </div>
<?php endif; ?>