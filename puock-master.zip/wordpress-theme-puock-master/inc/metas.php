<meta name="home-url" content="<?php echo home_url() ?>">
<meta name="vd-comment" content="<?php echo pk_is_checked('vd_comment') ? 'on':'off' ?>">
