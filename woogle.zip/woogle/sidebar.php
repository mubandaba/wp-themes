<table id="sidebar">
  <tbody>
  <tr>
    <td>
    	<h2>Sponsored Links</h2>
		<script type="text/javascript"><!--
        google_ad_client = "pub-1892270211473760";
        google_ad_width = 160;
        google_ad_height = 600;
        google_ad_format = "160x600_as";
        google_ad_type = "text_image";
        google_ad_channel = "4187007573";
        google_color_border = "FFFFFF";
        google_color_bg = "FFFFFF";
        google_color_link = "0007EE";
        google_color_text = "000000";
        google_color_url = "008000";
        //--></script>
        <script type="text/javascript"
        src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
        </script>

		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('sidebar') ) : ?>
        <?php endif; ?>
    </td>
  </tr>
  </tbody>
</table>