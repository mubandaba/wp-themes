<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>

<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />

<title><?php if(is_home() || is_search())  { bloginfo('name'); echo ' &raquo; '; bloginfo('description'); } else { wp_title(''); echo ' &raquo; '; bloginfo('name'); } ?></title>

<link rel="stylesheet" href="<?php bloginfo('stylesheet_url') ?>" type="text/css" media="screen" />

<?php if (!function_exists('automatic_feed_links')) { ?>
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name'); ?> Atom Feed" href="<?php bloginfo('atom_url'); ?>" />
<?php } ?>

<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />

<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
<?php wp_head(); ?>
</head>

<body<?php if (function_exists('body_class')) { echo ' '; body_class(); } ?>>

<div id="header">
    <div id="header_top">
		<ul>
		<li<?php if (!is_page()) echo ' class="current_page_item"' ?>><a href="<?php bloginfo('url') ?>">Home</a></li>
		<?php wp_list_pages('title_li='); ?>
        </ul>
	</div>
    
    <div class="header_top_border header_top_border_left"></div>
    <div class="header_top_border header_top_border_right"></div>

	<p id="header_topright"><?php wp_register(""," | "); ?><?php wp_loginout(); ?></p>
    
    <form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
	<table class="topsearch clr">
		<tbody>
			<tr>
		        <td>
        			<h1>
						<a id="logo" title="Home" href="<?php bloginfo('url') ?>"><img alt="Home" src="<?php bloginfo('template_url') ?>/images/logo.png" /></a>
			        </h1>
                </td>
		        <td class="td_topsearch">
			        <table class="topsearch" style="margin-top: 25px">
                        <tbody>
                            <tr>
                                <td>
                                    <input type="text" value="<?php the_search_query(); ?>" size="41" name="s" id="s" />
									<input type="submit" id="searchsubmit" value="Search" />
                                </td>
                            </tr>
                        </tbody>
                    </table>
					&nbsp;
                </td>
			</tr>
        </tbody>
    </table>
    </form>
</div>

<div id="header_bottom">
	<?php 
	global $wp_query;
	$request = $wp_query->request;
	$posts_per_page = intval(get_query_var('posts_per_page'));
	$paged = intval(get_query_var('paged'));
	$numposts = $wp_query->found_posts;
	$max_page = $wp_query->max_num_pages;
	if(empty($paged) || $paged == 0) {
		$paged = 1;
	}
	?>
    <div>Stats</div>
    <?php if (!is_page() && !is_single()) { ?>
		<p>&nbsp;results <b><?php if (!is_404()) echo (($paged-1)*$posts_per_page)+1; else echo '0'; ?></b> - <b><?php if ($paged*$posts_per_page < $numposts) echo $paged*$posts_per_page; else echo $numposts; ?></b> of about <b><?php echo $numposts ?></b> for <b>
        <?php
		if (is_home()) echo '*';
		if (is_category()) single_cat_title();
		if (is_tag()) single_tag_title();
		if (is_day()) the_time('F jS, Y');
		if (is_month()) the_time('F, Y');
		if (is_year()) the_time('Y');
		if (is_search()) the_search_query();
		?>
        </b>. (<b><?php timer_stop(1); ?></b> seconds)&nbsp;</p>
	<?php } else { ?>
		<p>&nbsp;results <b>1</b> - <b>1</b> of about <b>1</b> for <b><?php the_title(); ?></b>. (<b><?php timer_stop(1); ?></b> seconds)&nbsp;</p>
    <?php } ?>
</div>