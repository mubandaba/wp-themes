<?php

if (function_exists('automatic_feed_links')) automatic_feed_links();

if ( function_exists('register_sidebar') ) {
    register_sidebar( array('name' => 'sidebar', 'before_widget' => '', 'after_widget' => '', 'before_title' => '<h2>', 'after_title' => '</h2>') );
}

//modified version of the_content_rss to remove shortcodes
function woogle_content($more_link_text='(more...)', $stripteaser=0, $more_file='', $cut = 0, $encode_html = 0) {
	$content = get_the_content($more_link_text, $stripteaser, $more_file);
	$content = strip_shortcodes(apply_filters('the_content_rss', $content));
	if ( $cut && !$encode_html )
		$encode_html = 2;
	if ( 1== $encode_html ) {
		$content = wp_specialchars($content);
		$cut = 0;
	} elseif ( 0 == $encode_html ) {
		$content = make_url_footnote($content);
	} elseif ( 2 == $encode_html ) {
		$content = strip_tags($content);
	}
	if ( $cut ) {
		$blah = explode(' ', $content);
		if ( count($blah) > $cut ) {
			$k = $cut;
			$use_dotdotdot = 1;
		} else {
			$k = count($blah);
			$use_dotdotdot = 0;
		}

		/** @todo Check performance, might be faster to use array slice instead. */
		for ( $i=0; $i<$k; $i++ )
			$excerpt .= $blah[$i].' ';
		$excerpt .= ($use_dotdotdot) ? '...' : '';
		$content = $excerpt;
	}
	$content = str_replace(']]>', ']]&gt;', $content);
	echo $content;
}

function custom_comment($comment, $args, $depth) {
       $GLOBALS['comment'] = $comment;
		?>
		<li <?php comment_class(); ?> id="comment-<?php comment_ID() ?>">
	        <?php echo get_avatar( get_comment_author_email(), '32' ); ?>
			<strong class="commentmetadata"><?php comment_author_link() ?></strong> | <small class="commentmetadata"><a href="#comment-<?php comment_ID() ?>" title=""><?php comment_date('d M Y') ?> <?php comment_time() ?></a> <?php edit_comment_link('e','',''); ?></small>
			<?php if ($comment->comment_approved == '0') : ?>
			<em>Your comment is awaiting moderation.</em>
			<?php endif; ?>

			<?php comment_text() ?>
            <small class="replycomment"><?php comment_reply_link(array('reply_text' => 'Reply to this comment', 'depth' => $depth, 'max_depth'=> $args['max_depth'])) ?></small>
       <?php
}
?>