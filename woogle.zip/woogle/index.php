<?php get_header() ?>

<?php get_sidebar() ?>
  
<div class="contentwrapper"> 
    <div>
   		<div class="contentol">
   	        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<div <?php if (function_exists('post_class')) { post_class(); } else { echo 'class="post"'; } ?> id="post-<?php the_ID(); ?>">
				<h1 class="content_header">
                    <a href="<?php the_permalink() ?>" title="<?php the_title() ?>"><?php the_title() ?></a>
                </h1>
	
    			<div class="content">
                   	<?php the_time('d M y - '); woogle_content('',TRUE,'',25); ?>
                    <br />

                    <span class="content_footer">
                    <cite><?php the_permalink() ?> - </cite>
                    <?php the_category(' - ') ?>
                    - <?php comments_popup_link('0 Comments', '1 Comment', '% Comments'); ?>
                    <?php edit_post_link('Edit',' - ',''); ?>
               	    </span>
				</div>
			</div>
	
		<?php endwhile; ?>
		
		<div style="clear:both"></div>
		
		<?php else : ?>
			<p>No standard web pages were found.</p>
            <p>Suggestions:</p>
            <ul>
            <li>* Make sure all words are spelled correctly.</li>
            <li>* Try different keywords.</li>
            <li>* Try more general keywords.</li>
            <li>* Try fewer keywords.</li>
            </ul>
		<?php endif; ?>
		</div>
	</div>
</div>

<br clear="all" />

<?php 
global $wp_query; 
$max_page = $wp_query->max_num_pages; 
$paged = intval(get_query_var('paged')); 
if(empty($paged) || $paged == 0) {
	$paged = 1;
}
if ($max_page != 1) {
?>
<table id="pagenav">
	<tbody>
		<tr valign="top">
            <?php 		
			if ($paged != 1) {
			?>
            <td class="b"><a href="<?php previous_posts() ?>"><span class="csb ch" style="width:44px;margin-left:auto"></span><div style="margin-right:8px">Previous</div></a></td>
            <?php } else { ?>
            <td><span class="csb" style="background-position: -26px 0px; width: 18px"></span></td>
            <?php } ?>
            <td><span class="csb" style="background-position: -44px 0px; width: 16px"></span>1</td>
            <?php if ($max_page > 1) { $count = 2; while ($count < $max_page) { $count++; ?>
            <td><span class="csb" style="background-position: -60px 0px; width: 16px"></span><?php echo $count-1 ?></td>
            <?php }} ?>
            <td><span class="csb ch" style="background-position: -60px 0px; width: 16px"></span><?php echo $max_page ?></td>
            <?php 		
			if ($paged != $max_page) {
			?>
            <td class="b"><a href="<?php next_posts() ?>"><span class="csb ch" style="background-position: -76px 0px; width: 66px; margin-right: 34px"></span>Next</a></td>
            <?php } else { ?>
            <td class="b"><span class="csb" style="background-position: -76px 0pt; width: 42px;"></span></td>
            <?php } ?>
	    </tr>
	</tbody>
</table>
<?php } ?>

<?php get_footer() ?>