<div class="clr"><br /></div>

<div class="bottombar">
	<div id="bottomsearch">
		<form method="get" id="searchform_bottom" action="<?php bloginfo('url'); ?>/">
            <div>				
                <input type="text" value="<?php the_search_query(); ?>" size="41" name="s" />
				<input type="submit" id="searchsubmit_bottom" value="Search" />
            </div>
        </form>
	</div>
    
    <div id="footerpages">
		<ul>
		<li><a href="<?php bloginfo('url') ?>">Home</a></li>
		<?php wp_list_pages('title_li='); ?>
        <li><a href="http://ericulous.com/2009/03/18/wp-theme-woogle-the-google-search-engine-clone">Design: Smashing Wordpress Themes</a></li>
        </ul>
    </div>
</div>

<?php wp_footer(); ?>

</body>
</html>