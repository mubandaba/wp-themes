<?php get_header() ?>

<?php get_sidebar() ?>
  
<div class="contentwrapper"> 
    <div>
   		<div class="contentol">
   	        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<div class="post" id="post-<?php the_ID(); ?>">
				<h1><a href="<?php the_permalink() ?>" title="<?php the_title() ?>"><?php the_title() ?></a></h1>
	
    			<div class="content">
                   	<?php the_content(); ?>
					<?php wp_link_pages(array('before' => '<p><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>

                    <span class="content_footer">
                    <?php edit_post_link('Edit',' - ',''); ?>
               	    </span>
                    
					<?php comments_template(); ?>
				</div>
			</div>

		<?php endwhile; ?>
		
		<div style="clear:both"></div>
		
		<?php else : ?>
			<p>No standard web pages were found.</p>
            <p>Suggestions:</p>
            <ul>
            <li>* Make sure all words are spelled correctly.</li>
            <li>* Try different keywords.</li>
            <li>* Try more general keywords.</li>
            <li>* Try fewer keywords.</li>
            </ul>
		<?php endif; ?>
		</div>
	</div>
</div>

<br clear="all" />

<?php get_footer() ?>