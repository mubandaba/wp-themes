if (!window.qmad){
		qmad=new Object();
		qmad.binit="";
		qmad.bvis="";
		qmad.bhide="";}
		/*******  Menu 0 Add-On Settings *******/
		var a = qmad.qm0 = new Object();

		// Bump Animation Add On
		//a.bump_animation_frames = 5;
		//a.bump_distance = 100;
		//a.bump_main_direction = "top";
    	//.bump_sub_direction = "right";
		//a.bump_auto_switch_main_left_right_directions = true;

		// Item Bullets (CSS - Imageless) Add On
		a.ibcss_apply_to = "parent";
		a.ibcss_main_type = "arrow";
		a.ibcss_main_direction = "down";
		a.ibcss_main_size = 5;
		a.ibcss_main_bg_color = "#000";
		a.ibcss_main_border_color = "#000";
		a.ibcss_main_position_x = -20;
		a.ibcss_main_position_y = -7;
		a.ibcss_main_align_x = "right";
		a.ibcss_main_align_y = "middle";
		a.ibcss_sub_type = "arrow";
		a.ibcss_sub_direction = "right";
		a.ibcss_sub_size = 5;
		a.ibcss_sub_bg_color = "#bbb";
		a.ibcss_sub_border_color = "#FFF";
		a.ibcss_sub_position_x = -16;
		a.ibcss_sub_align_x = "right";
		a.ibcss_sub_align_y = "middle";

		// Rounded Sub Corners Add On
		//a.rcorner_size = -1;
		//a.rcorner_border_color = "#494949";
		//a.rcorner_bg_color = "#494949";
		//a.rcorner_apply_corners = new Array(false,false,true,true);