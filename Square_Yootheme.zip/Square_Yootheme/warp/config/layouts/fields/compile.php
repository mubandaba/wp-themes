<p><a href="#compile" class="uk-button">编译Less文件</a></p>

<p><span class="uk-badge">提示</span> 编译Less文件将会替换所有CSS文件，所有样式将会一次编译完成。</p>

<div id="compilemodal" class="uk-modal">
	<div class="uk-modal-dialog">
		<h1 class="uk-h3">正在编译……</h1>
		<p class="file-name uk-text-muted"></p>
		<div class="uk-progress">
			<div class="uk-progress-bar" style="width: 0%;"></div>
		</div>
		<div class="error-list">

		</div>
		<div>
			<button type="button" class="uk-button uk-button-danger">取消</button>
		</div>
	</div>
</div>
