<?php
define( 'sitemap_xintheme', '' );
require_once( 'class-sitemap-settings.php' );
require_once( 'class-do-sitemap.php' );