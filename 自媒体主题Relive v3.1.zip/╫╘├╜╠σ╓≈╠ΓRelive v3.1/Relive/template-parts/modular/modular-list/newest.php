<?php 
    switch ( $id['modular_style_list_newest'] ) {
        case '1':
			get_template_part( 'template-parts/modular/newest/list-1');
            break;
        case '2':
			get_template_part( 'template-parts/modular/newest/list-2');
            break;
        case '3':
			get_template_part( 'template-parts/modular/newest/list-3');
            break;
        case '4':
			get_template_part( 'template-parts/modular/newest/list-4');
            break;
        case '8':
			get_template_part( 'template-parts/modular/newest/list-8');
            break;
        case '9':
			get_template_part( 'template-parts/modular/newest/list-9');
            break;
        case '10':
			get_template_part( 'template-parts/modular/newest/list-10');
            break;
		case '11':
			get_template_part( 'template-parts/modular/newest/list-11');
            break;
		case '12':
			get_template_part( 'template-parts/modular/newest/list-12');
            break;
    }
?>