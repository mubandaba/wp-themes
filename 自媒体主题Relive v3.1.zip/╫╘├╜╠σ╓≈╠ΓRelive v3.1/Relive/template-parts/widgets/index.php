<?php  
include('widget-hotpost.php');//文章聚合
include('related-posts.php');//相关文章
include('widget-tags.php');//热门标签