=== 自媒体二号WordPress主题 ===

贡献者: 主题巴巴
最低版本要求: WordPress 4.5
最高版本兼容: WordPress 5.0-trunk
版本: 1.0.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: one-column, two-columns, right-sidebar, flexible-header, accessibility-ready, custom-colors, custom-header, custom-menu, custom-logo, editor-style, featured-images, footer-widgets, sticky-post, theme-options, threaded-comments, translation-ready

== 描述 ==

自媒体二号是一款由主题巴巴原创的WordPress主题，适合用于各类博客，资讯网站，自媒体网站和个人站点。

关于更多主题信息请访问：http://www.zhutibaba.com

== 安装 ==

1. 登陆 WordPress 管理员后台（仪表盘），从侧边栏进入 “外观” -> “主题”，点击“添加” -> “上传主题”，选择主题文件“zimeiti-2.zip”，并点击“现在安装”。

2. 安装完成后，点击“启用”。

3. 从侧边栏进入 “外观” -> “自定义”，设置你的主题。

4. 从侧边栏进入 “外观” -> “小工具”，使用你所需的小工具。

== 版权信息 ==

自媒体二号WordPress主题, 版权所有 2018 主题巴巴 zhutibaba.com