<?php 
	get_header(); 
	$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
?>
<section class="container">
	<div class="content-wrap">
	<div class="content">
		<?php 
			if( $paged==1 && _hui('focusslide_s') ){ 
				_moloader('mo_slider', false);
				mo_slider('focusslide');
			} 
		?>
		<?php 
			$pagedtext = ''; 
			if( $paged > 1 ){
				$pagedtext = ' <small>第'.$paged.'页</small>';
			}
		?>
		<?php  
			if( _hui('minicat_home_s') ){
				_moloader('mo_minicat');
			}
		?>
		<?php _the_ads($name='ads_index_01', $class='asb-index asb-index-01') ?>
		<div class="title">
		<?php //以下是首页最新文章上的四个推广栏，请根据自己需要进行修改?>
		<div class="asb asb-indexd asb-indexd-01"><div class="container">
 <ul class="eboxx">
 <li class="eboxx-i eboxx-01"><img src='https://www.wn789.com/wp-content/uploads/2018/01/5-120601154100.gif' />
 <h4><font color="c35bff"><strong> Linode注册送20美元 </strong></font></h4>
 <h4><font color="c35bff"><strong> （活动长期有效） </strong></font></h4>
 <p>KVM架构，日本机房，信用卡认证新用户注册送20美元！</p>
 <a class="btn btn-sm btn-primary" target="_blank" href="https://www.wn789.com/4534.html">点击查看</a>
 </li>
 <li class="eboxx-i eboxx-02"><img src='https://www.wn789.com/wp-content/uploads/2018/01/5-120601154100.gif' />
 <h4><font color="ff5e52"><strong> Vultr注册送28美元 </strong></font></h4>
 <h4><font color="ff5e52"><strong>（1核512M/2.5刀/月）</strong></font></h4>
 <p>限时活动，首次PayPal充值送25美元，支持支付宝！</p>
 <a class="btn btn-sm btn-danger" target="_blank" href="https://www.wn789.com/15713.html">点击查看</a>
 </li>
 <li class="eboxx-i eboxx-03"><img src='https://www.wn789.com/wp-content/uploads/2018/01/5-120601154100.gif' />
 <h4><font color="c35bff"><strong> 阿里云全民云计算 </strong></font></h4>
 <h4><font color="c35bff"><strong> （1核1G/293元/年） </strong></font></h4>
 <p>国内/香港/新加坡云服务器。仅需293元/年,879元/3年</p>
 <a class="btn btn-sm btn-primary" target="_blank" href="https://www.wn789.com/21373.html">点击查看</a>
 </li>
 <li class="eboxx-i eboxx-04"><img src='https://www.wn789.com/wp-content/uploads/2018/01/5-120601154100.gif' />
 <h4><font color="ff5e52"><strong> 腾讯云学生机1核2G内存 </strong></font></h4>
 <h4><font color="ff5e52"><strong>（360元/3年/台）</strong></font></h4>
 <p>点击查看新老用户人人有效通过学生认证方法！</p>
 <a class="btn btn-sm btn-danger" target="_blank" href="https://www.wn789.com/12015.html">点击查看</a>
 </li>
 </li>
 </ul>
</div></div>
<?php //以上是首页最新文章上的四个推广栏，请根据自己需要进行修改?>
			<h3>
				<?php echo _hui('index_list_title') ? _hui('index_list_title') : '最新发布' ?>
				<?php echo $pagedtext ?>
			</h3>
			<?php 
				if( _hui('index_list_title_r') ){
					echo '<div class="more">'._hui('index_list_title_r').'</div>';
				} 
			?>			
		</div>
<?php 
    $pagenums = get_option( 'posts_per_page', 10 );
    $offsetnums = 0;
    $stickyout = 0;
    if( _hui('home_sticky_s') && in_array(_hui('home_sticky_n'), array('1','2','3','4','5')) && $pagenums>_hui('home_sticky_n') ){
        if( $paged <= 1 ){
            $pagenums -= _hui('home_sticky_n');
            $sticky_ids = get_option('sticky_posts'); rsort( $sticky_ids );
            $args = array(
                'post__in'            => $sticky_ids,
                'showposts'           => _hui('home_sticky_n'),
				'cat'                 => 483,
                'ignore_sticky_posts' => 1
            );
            query_posts($args);
            get_template_part( 'excerpt' );
        }else{
            $offsetnums = _hui('home_sticky_n');
        }
        $stickyout = get_option('sticky_posts');
    }


    $args = array(
        'post__not_in'        => array(),
        'ignore_sticky_posts' => 1,
        'showposts'           => $pagenums,
        'paged'               => $paged
    );
    if( $offsetnums ){
        $args['offset'] = $pagenums*($paged-1) - $offsetnums;
    }
    if( _hui('notinhome') ){
        $pool = array();
        foreach (_hui('notinhome') as $key => $value) {
            if( $value ) $pool[] = $key;
        }
        if( $pool ) $args['cat'] = '-'.implode($pool, ',-');
    }
    if( _hui('notinhome_post') ){
        $pool = _hui('notinhome_post');
        $args['post__not_in'] = explode("\n", $pool);
    }
    if( $stickyout ){
        $args['post__not_in'] = array_merge($stickyout, $args['post__not_in']);
    }
    query_posts($args);
    get_template_part( 'excerpt' );
?>
		
		<?php _the_ads($name='ads_index_02', $class='asb-index asb-index-02') ?>
            <a href="https://www.wn789.com/" target="_blank"></a>
	</div>
	</div>
	<?php get_sidebar(); ?>
</section>
<?php get_footer();