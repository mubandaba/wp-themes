<?php get_header(); ?>
<div style="font-size:2em;text-align:center;margin-top:20px;color:rgba(66,133,244,0.9)">没有动漫的未知地方</div>
<?php get_footer(); ?>