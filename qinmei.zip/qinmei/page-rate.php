<?php
if( wp_is_mobile() ) {
	require("page-mobile/page/rate.php");
}
?>