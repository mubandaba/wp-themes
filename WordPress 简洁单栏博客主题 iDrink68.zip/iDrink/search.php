<?php get_header(); ?>
<div class="posts" itemtype="http://schema.org/Article" itemscope="itemscope">
	<header><h1 itemprop="headline"  style="background: #f7f7f7;  padding: 10px 15px;  border-left: 2px solid #147e19;  margin-bottom: 30px;">
		<?php _e("Search"); ?>：<?php the_search_query(); ?>
	</h1></header>
	<?php while ( have_posts() ) : the_post(); ?>
				<?php get_template_part( 'content', get_post_format() ); ?>
	<?php endwhile; ?>
</div>
<?php  if ( $wp_query->max_num_pages > 1 ) : ?>
	<div class="pagination"><?php pagenavi(); ?></div>
<?php endif; ?>
<?php get_footer(); ?>