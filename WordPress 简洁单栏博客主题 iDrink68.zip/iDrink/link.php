<?php 
/*
Template Name:links
*/
get_header(); ?>
<div class="posts" itemtype="http://schema.org/Article" itemscope="itemscope">
	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?> itemscope itemtype="http://schema.org/Article">
	<?php while ( have_posts() ) : the_post(); ?>
		<div <?php post_class() ?> id="post-<?php the_ID(); ?>">
			<header>
				<h1 itemprop="headline"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark" itemprop="url"><?php the_title(); ?></a></h1>
			</header>
			<div class="post-content" itemprop="articleBody"><?php the_content(''); ?>
			<div class="page-links">
			  <ul>
			 <?php
			 $default_ico = get_template_directory_uri().'/images/links_default.png'; 
			 $bookmarks = get_bookmarks('orderby=url'); 
			 ?>
			 <?php if(!empty($bookmarks)): ?>
			 <?php foreach ($bookmarks as $bookmark): ?>
			 
			 <li>
			 <img src="<?php echo $bookmark->link_url ?>/favicon.ico" alt="<?php echo $bookmark->link_name ?>" onerror="javascript:this.src='<?php echo $default_ico; ?>'">
			 <a href="<?php echo $bookmark->link_url ?>" target="_blank"><?php echo $bookmark->link_name ?></a>
                         <span class="linkdsc"><?php echo $bookmark->link_description ?></span>
			 </li>
			 <?php endforeach ?>
			 <?php endif ;?>
			 </ul>
			</div>
			</div>
		</div>
	<?php endwhile; ?>
	</article>
</div>
<?php get_footer(); ?>