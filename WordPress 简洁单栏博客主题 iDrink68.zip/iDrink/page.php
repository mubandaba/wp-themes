<?php get_header(); ?>
<div class="posts" itemtype="http://schema.org/Article" itemscope="itemscope">
	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?> itemscope itemtype="http://schema.org/Article">
	<?php while ( have_posts() ) : the_post(); ?>
		<div <?php post_class() ?> id="post-<?php the_ID(); ?>">
			<header>
				<h1 itemprop="headline"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark" itemprop="url"><?php the_title(); ?></a></h1>
			</header>
			<div class="post-content" itemprop="articleBody"><?php the_content(''); ?></div>
		</div>
	<?php endwhile; ?>
	</article>
</div>
<?php get_footer(); ?>