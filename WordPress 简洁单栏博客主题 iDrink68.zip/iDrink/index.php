<?php get_header(); ?>
	<div class="posts">
		<?php while ( have_posts() ) : the_post(); ?>
			<?php get_template_part( 'content', get_post_format() ); ?>
		<?php endwhile; ?>
	</div>
	<?php  if ( $wp_query->max_num_pages > 1 ) : ?>
		<div class="pagination"><?php pagenavi(); ?></div>
	<?php endif; ?>
<?php get_footer(); ?>