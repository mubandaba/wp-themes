<!DOCTYPE html>
<html itemscope="itemscope" itemtype="http://schema.org/WebPage">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<?php include('seo.php'); ?>
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name'); ?> Atom Feed" href="<?php bloginfo('atom_url'); ?>" />
<link rel="shortcut icon" href="favicon.ico" />
<script type="text/javascript" src="http://libs.baidu.com/jquery/1.7.0/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function () {
$('#opciones').hide();
$('#settings').click(function () {
$('#opciones').slideToggle();
$(this).toggleClass("cerrar");

});
});
</script>
<script type="text/javascript">
$(document).ready(function () {
$('#opciones1').hide();
$('#settings1').click(function () {
$('#opciones1').slideToggle();
$(this).toggleClass("cerrar1");

});
});
</script>
<!--[if lt IE 9]>
<script src="<?php echo get_template_directory_uri(); ?>/html5shiv.min.js" type="text/javascript"></script>
<![endif]-->
<!--[if lte IE 7]><script>window.location.href='http://www.zuifengyun.com/upgrade-your-browser.htm?referrer='+location.href;</script><![endif]-->
<?php wp_head(); ?>
</head>

<body>
<header id="header">
         <nav id="site-navigation" class="main-navigation" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
            <?php wp_nav_menu( array( 'container_class' => 'menu', 'theme_location' => 'header-menu', 'depth' => 1) ); ?>
<div class="menu2">  
<div id="settings">
<span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></div>
<?php wp_nav_menu( array( 'container_id' => 'opciones','theme_location' => 'header-menu' , 'depth' => 1) );?>
</div>       
</nav>
    <div class="header-container">
        <hgroup itemscope itemtype="http://schema.org/WPHeader">
            <h1 class="site-title"><a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('description'); ?>" rel="home"><?php bloginfo('name'); ?></a></h1>
            <h2 class="site-description"><?php bloginfo('description'); ?></h2>
        </hgroup>
        <ul class="social-links">
            <li><a href="http://weibo.com/520huishao" target="_blank" rel="nofollow"><i class="icon-sina-weibo" title="我的微博"></i><span>Weibo</span></a></li>
            <li><a href="http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=ekhNSUhPSkNPSjoLC1QZFRc" target="_blank" rel="nofollow"><i class="icon1-email" title="给我写信"></i><span>Email</span></a></li>
            <li><a href="http://r.qq.com/cgi-bin/reader_switch?u=<?php bloginfo('rss_url'); ?>" target="_blank" rel="nofollow"><i class="icon-feed" title="订阅我"></i><span>Feed</span></a></li>
            <li id="settings1"><a><i class="icon1-search" title="点击搜索" style="cursor: pointer;"></i></a></li><div id="opciones1" style="display: none;"><form id="searchform" method="get" action="<?php bloginfo('home'); ?>">
			<input type="text" value="<?php the_search_query(); ?>" name="s" id="s" size="30" />
			<button type="submit"><?php _e("Search"); ?></button>
		</form></div>  
        </ul>
    </div>
</header>

<div class="wrapper">
	<div class="content">