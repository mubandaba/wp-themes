<article id="post-<?php the_ID(); ?>" <?php post_class(); ?> itemscope itemtype="http://schema.org/Article">
	<header>
		<?php if( is_single() ):?>
			<h2><time class="date updated" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>" itemprop="datePublished" pubdate><?php the_time('Y.m.d'); ?><i class="icon1-category"> <?php the_category(', ') ?></i><i class="icon1-views"><a> <?php post_views(' ', ' °C'); ?></a></i><i class="icon1-count"> <?php comments_popup_link(__('0 留言'), __('1 留言'), __('%  留言')); ?></i></time></h2>
		<?php else: ?>
			<h1 class="entry-title" itemprop="name headline">
				<a href="<?php the_permalink() ?>" rel="bookmark" itemprop="url">
					<time class="date updated" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>" itemprop="datePublished" pubdate><?php the_time('Y.m.d H:i'); ?></time>
				</a>
			</h1>
		<?php endif ;?>
	</header>
	<div class="post-content" itemprop="articleBody"><?php the_content('阅读更多'); ?></div>
	<footer class="post-footer">
         <?php $tags_list = get_the_tag_list( '', __( ', ', 'themememe' ) );if ( $tags_list ) :?><i itemprop="keywords" class="icon1-tags tags"><?php printf( __( '%1$s', 'themememe' ), $tags_list ); ?></i><?php endif; ?>
	</footer>
</article>