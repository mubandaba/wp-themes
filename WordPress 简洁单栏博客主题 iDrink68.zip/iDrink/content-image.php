<article id="post-<?php the_ID(); ?>" <?php post_class(); ?> itemscope itemtype="http://schema.org/Article">
	<header>
		<?php if( is_single() ):?>
			<h2><time class="date updated" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>" itemprop="datePublished" pubdate><?php the_time('Y.m.d'); ?><i class="icon1-category"> <?php the_category(', ') ?></i><i class="icon1-views"><a> <?php post_views(' ', ' °C'); ?></a></i><i class="icon1-count"> <?php comments_popup_link(__('0 留言'), __('1 留言'), __('%  留言')); ?></i></time></h2>
		<?php else: ?>
			<h1 class="entry-title" itemprop="name headline">
				<a href="<?php the_permalink() ?>" rel="bookmark" itemprop="url" title="<?php the_title(); ?>" >
					<time class="date updated" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>" itemprop="datePublished" pubdate><?php the_time('Y.m.d H:i'); ?>&nbsp;&nbsp;<span style="font-family: &quot;Microsoft Yahei&quot;,&quot;微软雅黑&quot;,Tahoma,Arial,Helvetica,STHeiti;  font-size: 12px;"><?php the_title(); ?></span></time>
				</a>
			</h1>
		<?php endif ;?>
	</header>
	<div class="post-content" itemprop="articleBody"><?php the_content('阅读更多'); ?></div>
        <?php if( is_single() ):?>
        <footer class="post-footer" style="text-align: center;">
        <h1 class="entry-title" itemprop="name headline" style="margin-bottom: 0;">
            <?php the_title(); ?>
        </h1>
    </footer>
        <?php endif ;?>
</article>