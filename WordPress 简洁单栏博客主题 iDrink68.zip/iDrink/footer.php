</div>
<div style="display: none;" id="gotop"><a href="javascript:;"><i class="icon-rocket"></i></a></div>
</div>
<footer class="footer clear" role="contentinfo" itemscope itemtype="http://schema.org/WPFooter">
   Copyright © 2012–<?php echo date('Y'); ?> ZUIFENGYUN.COM | Theme by <a href="http://i.zuifengyun.com/theme" target="_blank">HuiShao</a>
    <br><br>
    Powered by Wordpress</a>
</footer>

<?php wp_footer(); ?>

<?php if( is_singular() ){ ?>
	<script type="text/javascript">
	jQuery(document).ready(function($){
		$('textarea').keypress(function(e) {if (e.ctrlKey && e.which == 13 || e.which == 10) {$(this).parent().submit()}});
		$('#comments .comment-body').dblclick(function(){var crl=$('#cancel-comment-reply-link');if($(this).next('#respond').length > 0) {crl.click()}else{$(this).find('.comment-reply-link').click();}return false});
	});
	</script>
<?php } ?>
<script type="text/javascript">
	jQuery(document).ready(function($){
		if($('.post-content a[rel!=link]:has(img)').length > 0){
			$.getScript("<?php bloginfo('template_url'); ?>/slimbox2.min.js");
		};	 
	});
</script>
<!-- 返回顶部 -->
<script type='text/javascript'>
    backTop=function (btnId){
        var btn=document.getElementById(btnId);
        var d=document.documentElement;
        var b=document.body;
        window.onscroll=set;
        btn.onclick=function (){
            btn.style.display="none";
            window.onscroll=null;
            this.timer=setInterval(function(){
                d.scrollTop-=Math.ceil((d.scrollTop+b.scrollTop)*0.1);
                b.scrollTop-=Math.ceil((d.scrollTop+b.scrollTop)*0.1);
                if((d.scrollTop+b.scrollTop)==0) clearInterval(btn.timer,window.onscroll=set);
            },1);
        };
        function set(){btn.style.display=(d.scrollTop+b.scrollTop>100)?'block':"none"}
    };
    backTop('gotop');
</script>
<!-- 返回顶部END -->

</body>
</html>