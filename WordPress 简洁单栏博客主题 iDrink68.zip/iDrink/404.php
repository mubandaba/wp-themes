<?php get_header(); ?>
<div id="nopage" itemtype="http://schema.org/Article" itemscope="itemscope">
	<header><h1 itemprop="headline">404：页面出错或者页面不存在，您可以尝试搜索一下</h1></header>
	<div id="search">
		<form id="searchform" method="get" action="<?php bloginfo('home'); ?>">
			<input type="text" value="<?php the_search_query(); ?>" name="s" id="s" size="30" style="border: 1px solid #94c6e1;" />
			<button type="submit" style="height: 28px;border: 1px solid #94c6e1;border-left: 0;"><?php _e("Search"); ?></button>
		</form>
	</div>
</div>
<?php get_footer(); ?>