<?php get_header(); ?>
<div id="home-bg" class="container">
	<div class="row">
		<div class="col-xs-2 top-bg top-bg-1"></div>
		<div class="col-xs-2 top-bg top-bg-2"></div>
		<div class="col-xs-2 top-bg top-bg-3"></div>
		<div class="col-xs-2 top-bg top-bg-4"></div>
		<div class="col-xs-2 top-bg top-bg-5"></div>
		<div class="col-xs-2 top-bg top-bg-6"></div>
	</div>
</div>
<div class="container">
	<div class="row">
		<?php get_template_part('side-left'); ?>
		<div class="col-md-9 col-lg-8">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<div class="panel panel-default post-list">
				<div class="panel-heading">
					<h2 class="panel-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
				</div>
				<div class="panel-body">				
<?php  echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 260,"...","utf-8"); ?>
				</div>
				<div class="panel-heading">
					<ul class="list-inline">
						<?php the_tags('<li><i class="glyphicon glyphicon-tags"></i>标签：',',','</li>'); ?>
						<li><i class="glyphicon glyphicon-eye-open"></i>浏览：<?php echo getPostViews(get_the_ID()); ?></li>
						<li><i class="glyphicon glyphicon-comment"></i>评论：<?php comments_number('0', '1', '%' );?></li>
					</ul>
				</div>
			</div>
			<?php endwhile; endif; ?>
			<ul id="pager" class="pagination">
				<?php par_pagenavi(9); ?>
			</ul>
		</div>
		<?php get_template_part('side-right'); ?>
	</div>
</div>
<?php get_footer(); ?>