<div id="footer">
	<div class="container">
		Copyright 2011-2014 www.mao01.com allright reserved. 网站设计 <a href="http://www.mao01.com/" title="wordpress企业主题定制">猫猫工作室</a>
	</div>
</div>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php bloginfo('template_directory'); ?>/js/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?php bloginfo('template_directory'); ?>/js/bootstrap.min.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/cat.js"></script>
</body>
</html>