<?php get_header(); ?>
<style>
	#top-bg {margin-bottom: 120px;}
	#logo {top:-130px; padding-top: 123px;}
</style>
<div class="container">
	<div class="row">
		<?php get_template_part('side-left'); ?>
		<div class="col-md-9 col-lg-8">
			<ol class="breadcrumb">
				<li>
					当前位置：
					<a href="<?php bloginfo('url'); ?>">
						首页
					</a>
				</li>
				<li class="active">
					<?php single_cat_title(); ?>
				</li>
			</ol>
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<div class="panel panel-default post-list">
				<div class="panel-heading">
					<h2 class="panel-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
				</div>
				<div class="panel-body">
					<?php the_content(); ?>
				</div>
				<div class="panel-heading">
					<ul class="list-inline">
						<?php the_tags('<li><i class="glyphicon glyphicon-tags"></i>标签：',',','</li>'); ?>
						<li><i class="glyphicon glyphicon-eye-open"></i>浏览：<?php echo getPostViews(get_the_ID()); ?></li>
						<li><i class="glyphicon glyphicon-comment"></i>评论：<?php comments_number('0', '1', '%' );?></li>
					</ul>
				</div>
			</div>
			<?php endwhile; endif; ?>
			<ul id="pager" class="pagination">
				<?php par_pagenavi(9); ?>
			</ul>
		</div>
		<?php get_template_part('side-right'); ?>
	</div>
</div>
<?php get_footer(); ?>