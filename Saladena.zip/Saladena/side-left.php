		<div class="col-lg-2 visible-lg">
			<div data-spy="affix" data-offset-top="450">
				<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('side-left') ) : ?><?php endif; ?>
			</div>
		</div>