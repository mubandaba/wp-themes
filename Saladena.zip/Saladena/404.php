<?php get_header(); ?>
<style>
	#top-bg {margin-bottom: 120px;}
	#logo {top:-130px; padding-top: 123px;}
</style>
<div class="container">
	<div class="jumbotron">
		<h1>
			错误404
		</h1>
		<p>
			这个页面受到喵星人袭击，正在紧急抢修中...
		</p>
		<p>
			<a class="btn btn-danger" role="button" href="<?php bloginfo('url'); ?>">
				返回首页
			</a>
		</p>
	</div>
</div>
<?php get_footer(); ?>