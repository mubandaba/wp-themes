<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/" role="form">
	<div class="input-group">
		<input type="text" name="s" id="searchinput" class="form-control" value="搜索..." onFocus="this.value='';" onBlur="if(this.value==''){this.value='搜索...';}" />
		<span id="searchbtn" class="input-group-addon">1</span>
	</div>
</form>
<div class="c"></div>
