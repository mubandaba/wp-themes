		<div class="col-md-3 col-lg-2 visible-md visible-lg">
			<div data-spy="affix" data-offset-top="450">
				<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('side-right') ) : ?><?php endif; ?>
			</div>
		</div>