<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
	<input type="text" name="s" id="searchinput" value="搜索课程或计划..." onFocus="javascript:search1();" onBlur="javascript:search2();" /> 
	<input type="submit" id="searchbtn" value="" />
</form>
