<div id="footer" class="w960">
	<div id="footin">
		<?php wp_nav_menu( array( 'theme_location' => 'footer-menu','container' => '','menu_class' => 'foot-menu') ); ?>
		<div class="copyright">Copyright <?php the_time('Y'); ?>. <?php bloginfo('name'); ?> 版权所有. All Rights Reserved. Designed by <a href="http://www.mao01.com/">猫猫工作室</a></div>
	</div>
</div>
<?php get_template_part('login'); ?>
</body>
<?php wp_footer(); ?>
</html>