<?php
if( !empty($_POST['ludou_reg1']) ) {
  $error1 = '';
  $sanitized_user_login = sanitize_user( $_POST['user_login'] );

  $user_login = $_POST['user_login'];
	$user_pass = $_POST['user_pass'];
	if ( !user_pass_ok( $user_login, $user_pass )) {
		  $error1 .= '用户名与密码不符，请重新填写。';
	}
  
  if($error1 == '') {
    if (!is_user_logged_in()) {
      $user = get_userdatabylogin($sanitized_user_login);
      $user_id = $user->ID;
  
      // 自动登录
      wp_set_current_user($user_id, $user_login);
      wp_set_auth_cookie($user_id);
      do_action('wp_login', $user_login);
    }
  }
};
?>
<div id="login-bg" <?php if($_POST['ludou_reg1']) { ?>style="display:block;"<?php } ?>></div>
<div id="login" <?php if($_POST['ludou_reg1']) { ?>style="display:block;"<?php } ?>>
	<h2>登陆</h2>
		<form name="loginform" id="loginform" action="<?php echo home_url(add_query_arg(array(),$wp->request)); ?>" method="post">
		<p>
			<input class="input" type="text"  name="user_login" id="regUserAccount" maxLength="30"  value="用户名" onFocus="this.value='';" />
		</p>
		<p>
			<input class="input"  type="text" name="user_pass" id="regPwd"  value="输入密码"  onFocus="this.value='';this.type='password';"/>
		</p>
		<p>
			<a href="<?php bloginfo('url'); ?>/wp-login.php?action=lostpassword">忘记密码</a>
			&nbsp;&nbsp;
			<a href="<?php echo get_option('mao10_sign_in'); ?>">新用户注册</a>
		</p>
		<p>
			<input type="hidden" name="ludou_reg1" value="ok" />
			<input type="submit" class="btn-sign-in" value="登陆" />
		</p>
		</form>
		<?php if(!empty($error1)) { 
		echo '<p class="look">'.$error1.'</p>';
		} ?>							
		<div class="close2"></div>
</div>