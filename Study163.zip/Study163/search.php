<?php get_header(); ?>
<div id="g-doc" class="w960">
	<div class="u-indxtit">
		<p>
			<?php echo '<span>'.$s.' 的搜索结果</span>'; ?>
		</p>
	</div>
	<div id="j-hotP">
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<?php get_template_part('loop'); ?>
	<?php endwhile;?><?php endif; ?>
	</div>
	<div class="pager"><?php par_pagenavi(9);  ?></div>
</div>
<?php get_footer(); ?>