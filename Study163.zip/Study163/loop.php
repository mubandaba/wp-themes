<?php 
		$fmimg = get_post_meta($post->ID, "fmimg_value", true);
		$jiangshi = get_post_meta($post->ID, "jiangshi_value", true);
		$jsimg = get_post_meta($post->ID, "jsimg_value", true);
		$jsjieshao = get_post_meta($post->ID, "jsjieshao_value", true);
?>
<div class="u-cover f-bg f-cb">
			<a target="_self" class="j-hrf" href="<?php the_permalink(); ?>">
				<div class="img">
					<div class="pic">
						<img class="j-imgArea" width="220px" src="<?php echo $fmimg; ?>">
					</div>
					<div class="show">
						<span class="j-imgArea">
							课程详情
						</span>
					</div>
					<div class="tit">
						<h3 class="j-imgArea">
							<?php the_title(); ?>
						</h3>
						<!--div class="continued j-con" style="">
							连载中
						</div-->
					</div>
					<div class="j-thumb">
						<div class="thumb j-info">
							<!--span class="f-cb">
								<span class="mark j-d">
									<div class="u-rating">
										<div class="star on">
										</div>
										<div class="star on">
										</div>
										<div class="star on">
										</div>
										<div class="star on">
										</div>
										<div class="star on">
										</div>
									</div>
								</span>
								<span class="cmt f-fs0 j-d">
									(10份评价)
								</span>
							</span-->
							<div class="c"></div>
							<span class="name f-fs0 f-thide j-d">
								<?php if($jiangshi) echo $jiangshi; else echo '暂无'; ?>
							</span>
							<div class="c"></div>
							<span class="hot f-fs0 j-d">
								<?php echo getPostViews(get_the_ID()); ?>人看过
							</span>
							<div class="btn">
								免费
							</div>
						</div>
					</div>
				</div>
			</a>
			<div class="j-mask mask" style="display: none;">
				<div class="j-del delbtn">
				</div>
			</div>
		</div>