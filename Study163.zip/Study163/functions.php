<?php

//评论过

function wt_get_user_id(){
    global $userdata;
    get_currentuserinfo();
    return $userdata->ID;
}

//分页工具
function par_pagenavi($range = 9){
  // $paged - number of the current page
  global $paged, $wp_query;
  // How much pages do we have?
  if ( !$max_page ) {
  $max_page = $wp_query->max_num_pages;
  }
  // We need the pagination only if there are more than 1 page
  if($max_page > 1){
  if(!$paged){
  $paged = 1;
  }
  echo '';
  // On the first page, don't put the First page link
  if($paged != 1){
  echo "<a href='" . get_pagenum_link(1) . "' class='extend' title='最前一页'>最前一页</a>";
  }
  // To the previous page
  previous_posts_link('上一页');
  // We need the sliding effect only if there are more pages than is the sliding range
  if($max_page > $range){
  // When closer to the beginning
  if($paged < $range){
  for($i = 1; $i <= ($range + 1); $i++){
  if($i==$paged) echo "<a class='current'>$i</a>";
else echo "<a href='" . get_pagenum_link($i) ."'>$i</a>";
  }
  }
  // When closer to the end
  elseif($paged >= ($max_page - ceil(($range/2)))){
  for($i = $max_page - $range; $i <= $max_page; $i++){
  if($i==$paged) echo "<a class='current'>$i</a>";
else echo "<a href='" . get_pagenum_link($i) ."'>$i</a>";
  }
  }
  // Somewhere in the middle
  elseif($paged >= $range && $paged < ($max_page - ceil(($range/2)))){
  for($i = ($paged - ceil($range/2)); $i <= ($paged + ceil(($range/2))); $i++){
  if($i==$paged) echo "<a class='current'>$i</a>";
else echo "<a href='" . get_pagenum_link($i) ."'>$i</a>";
  }
  }
  }
  // Less pages than the range, no sliding effect needed
  else{
  for($i = 1; $i <= $max_page; $i++){
  if($i==$paged) echo "<a class='current'>$i</a>";
else echo "<a href='" . get_pagenum_link($i) ."'>$i</a>";
  }
  }
  // Next page
  next_posts_link('下一页');
  // On the last page, don't put the Last page link
  if($paged != $max_page){
  echo "<a href='" . get_pagenum_link($max_page) . "' class='extend' title='最后一页'>最后一页</a>";
  }
  }
  }

//浏览统计
function getPostViews($postID){
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return "0";
    }
    return $count.'';
}
 
function setPostViews($postID) {
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}


//注册工具栏
if (function_exists('register_sidebar')){
    register_sidebar(array(
		'name' => '侧边栏',
		'id'   => 'sing',
		'before_widget' => '<div class="f-cb f-bg side-box">',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 class="u-ctit">',
		'after_title'   => '</h2>'
	));
	}
	
//热门文章小工具
class My_Widget extends WP_Widget {

	function My_Widget()
	{
		$widget_ops = array('description' => '展示站内点击数最多的文章');
		$control_ops = array('width' => 400, 'height' => 300);
		parent::WP_Widget(false,$name='猫猫热门文章小工具',$widget_ops,$control_ops);  
	}

	function form($instance) { 
		$title = esc_attr($instance['title']);
	?>
	<p><label for="<?php echo $this->get_field_id('title'); ?>"><?php esc_attr_e('标题:'); ?> <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></label></p>

	<?php
    }
	function update($new_instance, $old_instance) { 
		return $new_instance;
	}
	function widget($args, $instance) { 
	extract( $args );
        $title = apply_filters('widget_title', empty($instance['title']) ? __('热门文章') : $instance['title']);
        ?>
                <div class="box">
					<h4 class="mb15"><?php echo $title; ?></h4>
					<?php if (have_posts()) : ?>
											<?php $args=array(
												'showposts'=>'5','orderby'=>'meta_value','meta_key'=>'post_views_count','caller_get_posts' => 1
											);
											$my_query=new WP_Query(
												$args
											); 
											while ($my_query->have_posts()) : $my_query->the_post(); $do_not_duplicate = $post->ID;
											?>
						<dl>
							<dd class="oxheader">
								<div class="oxtouxiang">
									<a href="<?php echo get_author_posts_url(get_the_author_meta( 'ID' )); ?>" title="<?php  echo the_author_meta( 'display_name' ); ?>"><?php echo get_avatar( get_the_author_email(), 50 ); ?></a>
								</div>
								<div class="oxtitle">
									<h5><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
									<a href="<?php echo get_author_posts_url(get_the_author_meta( 'ID' )); ?>"  class="oxauthorname"><?php  echo the_author_meta( 'display_name' ); ?></a>
									<span class="oxtime"><?php the_time('Y-m-d'); ?></span>
								</div>
							</dd>
							<dd class="oxbody">
								<?php the_excerpt(); ?>
							</dd>
							<dd class="oxfooter">
								<div class="postinfo">
									<a href="<?php the_permalink(); ?>"><span class="pinglun">评论(<?php comments_number('0', '1', '%' );?>)</span></a>
									<?php the_tags( '<span class="tags">', ' ', '</span>'); ?>
								</div>
							</dd>
						</dl>
						<div class="c"></div>
					<?php endwhile; endif; ?>
				</div>
        <?php
	}
}
register_widget('My_Widget');

//自定义域
$new_meta_boxes =
array(
	"keywords" => array(
    	"name" => "keywords",
    	"std" => "",
    	"title" => "关键词:"
    ),
    "fmimg" => array(
    	"name" => "fmimg",
    	"std" => "",
    	"title" => "封面图片:"
    ),
    "jiangshi" => array(
    	"name" => "jiangshi",
    	"std" => "",
    	"title" => "讲师:"
    ),
    "jsimg" => array(
    	"name" => "jsimg",
    	"std" => "",
    	"title" => "讲师图片:"
    ),
    "jsjieshao" => array(
    	"name" => "jsjieshao",
    	"std" => "",
    	"title" => "讲师介绍:"
    ),
);

function new_meta_boxes() {
    global $post, $new_meta_boxes;

    foreach($new_meta_boxes as $meta_box) {
        $meta_box_value = get_post_meta($post->ID, $meta_box['name'].'_value', true);

        if($meta_box_value == "")
            $meta_box_value = $meta_box['std'];

        echo'<input type="hidden" name="'.$meta_box['name'].'_noncename" id="'.$meta_box['name'].'_noncename" value="'.wp_create_nonce( plugin_basename(__FILE__) ).'" />';

        // 自定义字段标题
        echo'<h4>'.$meta_box['title'].'</h4>';

        // 自定义字段输入框
        echo '<textarea cols="60" rows="3" name="'.$meta_box['name'].'_value">'.$meta_box_value.'</textarea><br />';
    }
}

function create_meta_box() {
    global $theme_name;

    if ( function_exists('add_meta_box') ) {
        add_meta_box( 'new-meta-boxes', '自定义模块', 'new_meta_boxes', 'post', 'normal', 'high' );
    }
}

function save_postdata( $post_id ) {
    global $post, $new_meta_boxes;

    foreach($new_meta_boxes as $meta_box) {
        if ( !wp_verify_nonce( $_POST[$meta_box['name'].'_noncename'], plugin_basename(__FILE__) ))  {
            return $post_id;
        }

        if ( 'page' == $_POST['post_type'] ) {
            if ( !current_user_can( 'edit_page', $post_id ))
                return $post_id;
        } 
        else {
            if ( !current_user_can( 'edit_post', $post_id ))
                return $post_id;
        }

        $data = $_POST[$meta_box['name'].'_value'];

        if(get_post_meta($post_id, $meta_box['name'].'_value') == "")
            add_post_meta($post_id, $meta_box['name'].'_value', $data, true);
        elseif($data != get_post_meta($post_id, $meta_box['name'].'_value', true))
            update_post_meta($post_id, $meta_box['name'].'_value', $data);
        elseif($data == "")
            delete_post_meta($post_id, $meta_box['name'].'_value', get_post_meta($post_id, $meta_box['name'].'_value', true));
    }
}

add_action('admin_menu', 'create_meta_box');
add_action('save_post', 'save_postdata');


//自定义导航
register_nav_menus(
array(
'header-menu' => __( '头部自定义菜单' ),
//'nav-menu' => __( '导航自定义菜单' ),
'footer-menu' => __( '底部自定义菜单' ),
)
);

//注册控制面板
//require_once(TEMPLATEPATH . '/control.php');

function cleanr_theme_comment($comment, $args, $depth) {
   $GLOBALS['comment'] = $comment; ?>
   <li <?php comment_class(); ?> id="li-comment-<?php comment_ID() ?>">
    
     <div id="comment-<?php comment_ID(); ?>">
     <div class="commenthead">
      <div class="comment-author vcard">
         <?php echo get_avatar($comment,$size='50',$default='' ); ?>

         <?php printf(__('<cite class="fn">%s</cite>'), get_comment_author_link()) ?>
      </div>
      

      <div class="comment-meta commentmetadata"><a href="<?php echo htmlspecialchars( get_comment_link( $comment->comment_ID ) ) ?>"><?php printf(__('%1$s at %2$s'), get_comment_date(),  get_comment_time()) ?></a><?php edit_comment_link(__('(Edit)'),'  ','') ?>
     
     <?php if ($comment->comment_approved == '0') : ?>
         <em><?php _e('...awaiting moderation') ?></em>
         <br />
      <?php endif; ?>
      </div>
      <div class="clear"></div>
     
     </div>
     

	<div class="commentbody">
      <?php comment_text() ?>

      <div class="reply">
         <?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
      </div>
     </div>
     </div>
<?php } ?>