<?php get_header(); ?>
<div id="slider">
	<div class="w960">
		<div id="text">
			<h2>学习是一种态度！</h2>
			<p>随心所欲，随时随地快乐充电。现在加入，感受不一样的学习体验吧。</p>
		</div>
		<a id="startnow" href="javascript:login();">现在加入</a>
	</div>
</div>
<div class="w960">
	<div id="allicon">
		<div id="alliconin">
			<div class="icon">
				<div class="lo"></div>
				<p class="t1">多样内容</p>
				<p class="t2">涵盖多个类别优质课程<br> 持续更新整合公开课内容，统一学习管理</p>
			</div>
			<div class="icon">
				<div class="lo lo1"></div>
				<p class="t1">互动学习</p>
				<p class="t2">视频、图文、测试、实践带来360度交互体验<br> 快乐分享、有问有答，构造最有爱的学习环境</p>
			</div>
			<div class="icon">
				<div class="lo lo2"></div>
				<p class="t1">计划引导</p>
				<p class="t2">多渠道学习内容统筹<br> 实现学习目标的终极监督手段</p>
			</div>
		</div>
	</div>
</div>
<div id="g-doc" class="w960">
	<div class="u-indxtit">
		<p>
			课程精选
		</p>
	</div>
	<div id="j-hotP">
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<?php get_template_part('loop'); ?>
	<?php endwhile;?><?php endif; ?>
	</div>
	<div class="u-more">
		<a href="#"><span>发现更多课程</span></a>
	</div>
	<div id="corp-box" class="m-corp">
		<div class="autolist">
			<div class="u-indxtit">
				<p class="j-txt">
					合作伙伴
				</p>
			</div>
			<div class="list">
				<div class="u-corpitem">
					<a target="_blank" class="link" href="#">
						<img class="img" src="<?php bloginfo('template_directory'); ?>/img/163tech.jpg">
					</a>
				</div>
				<div class="u-corpitem">
					<a target="_blank" class="link" href="#">
						<img class="img" src="<?php bloginfo('template_directory'); ?>/img/163tech.jpg">
					</a>
				</div>
				<div class="u-corpitem">
					<a target="_blank" class="link" href="#">
						<img class="img" src="<?php bloginfo('template_directory'); ?>/img/163tech.jpg">
					</a>
				</div>
				<div class="u-corpitem">
					<a target="_blank" class="link" href="#">
						<img class="img" src="<?php bloginfo('template_directory'); ?>/img/163tech.jpg">
					</a>
				</div>
				<div class="u-corpitem">
					<a target="_blank" class="link" href="#">
						<img class="img" src="<?php bloginfo('template_directory'); ?>/img/163tech.jpg">
					</a>
				</div>
				<div class="u-corpitem">
					<a target="_blank" class="link" href="#">
						<img class="img" src="<?php bloginfo('template_directory'); ?>/img/163tech.jpg">
					</a>
				</div>
				<div class="u-corpitem">
					<a target="_blank" class="link" href="#">
						<img class="img" src="<?php bloginfo('template_directory'); ?>/img/163tech.jpg">
					</a>
				</div>
				<div class="u-corpitem">
					<a target="_blank" class="link" href="#">
						<img class="img" src="<?php bloginfo('template_directory'); ?>/img/163tech.jpg">
					</a>
				</div>
			</div>
		</div>
	</div>
</div>
<?php get_footer(); ?>