<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<title><?php if (is_single() || is_page() || is_archive() || is_search()) { ?><?php wp_title('',true); ?> - <?php } bloginfo('name'); ?><?php if ( is_home() ){ ?> - <?php bloginfo('description'); ?><?php } ?><?php if ( is_paged() ){ ?> - <?php printf( __('Page %1$s of %2$s', ''), intval( get_query_var('paged')), $wp_query->max_num_pages); ?><?php } ?></title>
<?php if (is_home()){ 
			$description     = get_option('mao10_description');
			$keywords = get_option('mao10_keywords');
		} elseif (is_single() || is_page()){    
			$description1 =  $post->post_excerpt ;
			$description2 = mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 200, "…");
			$description = $description1 ? $description1 : $description2;
		
			$keywords = get_post_meta($post->ID, "keywords_value", true);        
		} elseif(is_category()){
			$description     = category_description();
			$current_category = single_cat_title("", false);
			$keywords =  $current_category;
		}
?>
<meta name="keywords" content="<?php echo $keywords ?>" />
<meta name="description" content="<?php echo $description ?>" />
<script src="<?php bloginfo('template_directory'); ?>/js/jquery.min.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/cat.js"></script>
<?php wp_deregister_script('jquery'); ?>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<div id="header">
	<div class="w960">
		<h2 id="logo"><a href="<?php bloginfo('url'); ?>"><img src="<?php bloginfo('template_directory'); ?>/img/logo.png" /></a></h2>
		<?php wp_nav_menu( array( 'theme_location' => 'header-menu','container' => '','menu_class' => 'head-menu') ); ?>
		<?php get_search_form(); ?>
		<a id="signin" href="javascript:login();">注册/登陆</a>
	</div>
	
</div>
<?php if(is_single()) { ?>
<div id="nav">
	<div class="w960">
		<a href="<?php bloginfo('url'); ?>" title="首页">首页</a>&nbsp;»&nbsp;<?php the_category(', '); ?>&nbsp;»&nbsp;<?php the_title(); ?>
	</div>
</div>
<?php } ?>
<?php if(is_archive()) { ?>
<div id="nav">
	<div class="w960">
		<a href="<?php bloginfo('url'); ?>" title="首页">首页</a>&nbsp;»&nbsp;<?php single_cat_title(); ?>
	</div>
</div>
<?php } ?>
<?php if(is_search()) { ?>
<div id="nav">
	<div class="w960">
		<a href="<?php bloginfo('url'); ?>" title="首页">首页</a>&nbsp;»&nbsp;<?php echo '<span>'.$s.' 的搜索结果</span>'; ?>
	</div>
</div>
<?php } ?>