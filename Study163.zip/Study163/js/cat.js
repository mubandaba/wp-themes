function search1(){
	jQuery("#searchinput").css("background-color","#FFFFFF");
	jQuery("#searchinput").val('');
};
function search2(){
	jQuery("#searchinput").css("background-color","#5C5F68");
	var search = jQuery("#searchinput").val();
	if(search=='') {
		jQuery("#searchinput").val('搜索课程或计划...');
	}
};
function login(){
	var scrollTop = $(document).scrollTop();
	jQuery("#login").css({"top":scrollTop+100,"display":"block"});
	jQuery("#login-bg").css({"display":"block"});
};
jQuery(document).ready(function(){
	$("#login-bg").click(function(){
		jQuery("#login").css({"display":"none"});
		jQuery("#login-bg").css({"display":"none"});
		jQuery(".video").css({"display":"none"});
	});
	$(".section").hover(function(){
		jQuery(this).addClass('section-cur');
	},function(){
		jQuery(this).removeClass('section-cur');
	});
});
function video(id){
	var scrollTop = $(document).scrollTop();
	jQuery("#video"+id).css({"top":scrollTop+100,"display":"block"});
	jQuery("#login-bg").css({"display":"block"});
};