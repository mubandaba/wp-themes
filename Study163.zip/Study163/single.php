<?php get_header(); ?>
<div class="w960">
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	<?php setPostViews(get_the_ID()); ?>
	<?php 
		$fmimg = get_post_meta($post->ID, "fmimg_value", true);
		$jiangshi = get_post_meta($post->ID, "jiangshi_value", true);
		$jsimg = get_post_meta($post->ID, "jsimg_value", true);
		$jsjieshao = get_post_meta($post->ID, "jsjieshao_value", true);
	?>
	<div class="g-wrap f-bg" id="j-coursehead">
		<div class="u-courseHead">
			<div class="ov f-pr j-ch">
				<div class="left f-fl j-chimg">
					<img src="<?php echo $fmimg; ?>" width="450" height="250">
				</div>
				<div class="right f-fr j-right">
					<div class="ctarea f-fl j-cht">
						<div class="u-coursetitle f-fl">
							<h2 class="j-info" title="<?php the_title(); ?>">
								<?php the_title(); ?>
							</h2>
							<div class="c"></div>
							<p class="j-info" style="">
								讲师：<?php echo $jiangshi; ?>
							</p>
							<p class="j-info" style="">
								点击：<?php echo getPostViews(get_the_ID()); ?>
							</p>
							<p class="j-info" style="">
								分类：<?php the_category(' , '); ?>
							</p>
							<?php the_tags('<p class="j-info" style="">Tags：',' , ','</p>'); ?>
						</div>
					</div>
					<!--div class="u-shareUI f-fr">
						<a class="j-share share" style="" id="auto-id-Ktsw9Qee">
						</a>
						<div class="j-share f-win box x-hide auto-1367582709146-parent" id="auto-id-dERVO8t6">
							<div class="u-share f-cb" id="j-shareUI">
								分享代码
							</div>
						</div>
						<a class="j-toStore toStore" title="加入收藏" style="" id="auto-id-0btT7s2Q">
						</a>
						<a class="j-info info" title="查看详情" style="display: none;" id="auto-id-X4IU7ggD">
						</a>
					</div-->
				</div>
				<div class="btnarea f-pa j-chbtnarea">
					<a class="learnbtn f-pa f-db j-joinBtn" href="#j-chapter-list">
						<span class="f-db">
							免费
						</span>
					</a>
				</div>
			</div>
		</div>
	</div>
	<div class="g-wrap f-cb">
		<div class="g-mnc f-cb">
			<div class="f-bg" id="j-course-briefintro">
				<div class="m-cbi">
					<h2 class="u-ctit ctit1">
						简介
					</h2>
					<div class="cintrocon j-courseintro">
						<?php the_content(); ?>
					</div>
				</div>
			</div>
			<div class="f-cb f-bg" id="j-chapter-list">
				<h2 class="u-ctit f-thide">
					目录
				</h2>
				<div class="m-chapterList f-pr">
					<div class="chapter">
						<!--div class="chapterhead">
							<span class="f-fl f-thide chaptertitle">
								章节1:
							</span>
							<span class="f-fl f-thide chaptername">
								内容提要
							</span>
						</div-->
						<?php $studys = get_post_meta($post->ID,"mmxx", $single = false); ?>
						<?php foreach( array_reverse($studys) as $study ) { ?>
						<?php 
							$str = $study;
							$arr = explode("|",$str);
							//unset($arr[0]);
							list($name,$time,$video) = $arr;
							$num++;
						?>
						<div class="section" onclick="javascript:video(<?php echo $num; ?>);">
							<span class="f-fl f-thide ks">
								课时<?php echo $num; ?>
							</span>
							<span class="f-fl f-thide ksname">
								<?php echo $name; ?>
							</span>
							<a class="f-fr ksjbtn">
								<span class="f-fr">
									课时预览
								</span>
								<div class="f-fr ksjicon-look">
								</div>
							</a>
							<span class="f-fr ksinfo">
								<span class="f-fr f-thide kstime">
									<?php echo $time; ?>
								</span>
								<span class="f-fr ksinfoicon ksinfoicon-2" title="视频">
									
								</span>
							</span>
						</div>
						<?php } ?>
					</div>
				</div>
			</div>
			<div class="m-forwardPlan f-pr" id="j-forwardPlanBox">
				<div class="h2box f-cb f-bg"><h2 class="u-ctit">
					相关学习计划
				</h2></div>
				<div id="j-forwardPlan" class="forwardPlan">
					<?php
					global $post;
					$cats = wp_get_post_categories($post->ID);
					if ($cats) {
					$args = array(
					        'category__in' => array( $cats[0] ),
					        'post__not_in' => array( $post->ID ),
					        'showposts' => 6,
					        'caller_get_posts' => 1
					    );
					query_posts($args);
					
					if (have_posts()) : 
					    while (have_posts()) : the_post(); update_post_caches($posts); ?>
					<?php get_template_part('loop'); ?>
					<?php endwhile; endif; wp_reset_query(); } ?>
				</div>
			</div>
			<div id="comment" class="f-cb f-bg">
					<?php comments_template(); ?>
			</div>
		</div>
		<div class="g-sda f-fr">
			<div class="f-bg" id="j-course-lectors">
				<div class="m-ti">
					<div class="lectors j-lectors">
						<img width="225" class="j-limg" src="<?php echo $jsimg; ?>">
						<p class="lname j-lname">
							<?php echo $jiangshi; ?>
						</p>
					</div>
					<div class="ltxt j-ltxt f-richEditorText"><?php echo $jsjieshao; ?></div>
				</div>
			</div>
			<?php 	/* Widgetized sidebar, if you have the plugin installed. */
				if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('sing') ) : ?>
			<?php endif; ?>
		</div>
	</div>
	<?php $studys = get_post_meta($post->ID,"mmxx", $single = false); ?>
						<?php foreach( array_reverse($studys) as $study ) { ?>
						<?php 
							$str = $study;
							$arr = explode("|",$str);
							//unset($arr[0]);
							list($name,$time,$video) = $arr;
							$num2++;
						?>
						<div id="video<?php echo $num2; ?>" class="video">
						<embed src="<?php echo $video; ?>" allowFullScreen="true" quality="high" width="480" height="400" align="middle" allowScriptAccess="always" type="application/x-shockwave-flash"></embed>
						</div><?php } ?>
	<?php endwhile;?><?php endif; ?>
</div>
<div class="c"></div>
<?php get_footer(); ?>