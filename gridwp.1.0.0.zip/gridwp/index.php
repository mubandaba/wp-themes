<?php
/**
* The main template file.
*
* This is the most generic template file in a WordPress theme
* and one of the two required files for a theme (the other being style.css).
* It is used to display a page when nothing more specific matches a query.
* E.g., it puts together the home page when no home.php file exists.
*
* @link https://developer.wordpress.org/themes/basics/template-hierarchy/
*
* @package GridWP WordPress Theme
* @copyright Copyright (C) 2018 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

get_header(); ?>

<div class="gridwp-main-wrapper clearfix" id="gridwp-main-wrapper" itemscope="itemscope" itemtype="http://schema.org/Blog" role="main">
<div class="theiaStickySidebar">
<div class="gridwp-main-wrapper-inside clearfix">

<?php gridwp_top_widgets(); ?>

<div class="gridwp-posts-wrapper" id="gridwp-posts-wrapper">

<div class="gridwp-posts">

<?php if ( !(gridwp_get_option('hide_posts_heading')) ) { ?>
<?php if(is_home() && !is_paged()) { ?>
<?php if ( gridwp_get_option('posts_heading') ) : ?>
<h1 class="gridwp-posts-heading"><span><?php echo esc_html( gridwp_get_option('posts_heading') ); ?></span></h1>
<?php else : ?>
<h1 class="gridwp-posts-heading"><span><?php esc_html_e( 'Recent Posts', 'gridwp' ); ?></span></h1>
<?php endif; ?>
<?php } ?>
<?php } ?>

<div class="gridwp-posts-content">

<?php if (have_posts()) : ?>

    <div class="gridwp-posts-container">
    <?php $gridwp_total_posts = $wp_query->post_count; ?>
    <?php $gridwp_post_counter=1; while (have_posts()) : the_post(); ?>

        <?php get_template_part( 'template-parts/content', gridwp_post_style() ); ?>

    <?php $gridwp_post_counter++; endwhile; ?>
    </div>
    <div class="clear"></div>

    <?php gridwp_posts_navigation(); ?>

<?php else : ?>

  <?php get_template_part( 'template-parts/content', 'none' ); ?>

<?php endif; ?>

</div>
</div>

</div><!--/#gridwp-posts-wrapper -->

<?php gridwp_bottom_widgets(); ?>

</div>
</div>
</div><!-- /#gridwp-main-wrapper -->

<?php get_sidebar(); ?>

<?php get_footer(); ?>