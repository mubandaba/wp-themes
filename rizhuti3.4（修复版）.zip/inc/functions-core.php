<?php


/**
 * 日主题，生来被日 
 * @官网        https://rizhuti.com/
 * @Author      Dadong2g
 * @渣男提示    [男人要想技术过“硬”，“薄”取芳心，一个字《日》]
 * @正版提示    [盗版/破解/渣男都不是好渣男]
 * @前戏提示    [日主题是良心主题，感谢您使用日主题进行二次开发或内容创作]
 * @血亏说明    [还请各位破解，盗版大佬，喜欢，感兴趣，自己日就行了。不要糜烂传播新版本，好人一生平台，日你3000遍]
 */


/**
 * [rizhuti_setup theme start]
 * @Author   Dadong2g
 * @DateTime 2019-05-28T11:17:53+0800
 * @return   [type]                   [description]
 */
if (!function_exists('rizhuti_setup')):
    
    function rizhuti_setup()
    {

        add_theme_support('automatic-feed-links');

        add_theme_support('title-tag');

        add_theme_support('post-thumbnails');

        add_image_size('480-384.7', 480, 384, true);

        // 检测是否有qqid字段，没有添加，为qq登陆提供基础
        global $wpdb, $wppay_table_name;
        $var = $wpdb->query("SELECT qqid FROM $wpdb->users");
        if (!$var) {
            $wpdb->query("ALTER TABLE $wpdb->users ADD qqid varchar(100)");
        }
        // 插入订单表
        if ($wpdb->get_var("show tables like '{$wppay_table_name}'") != $wppay_table_name) {
            $wpdb->query("CREATE TABLE `" . $wpdb->prefix . "wppay_order` (
              `id` int(11) NOT NULL AUTO_INCREMENT,
              `user_id` int(11) DEFAULT NULL COMMENT '用户id',
              `post_id` int(11) DEFAULT NULL COMMENT '关联文章id',
              `order_num` varchar(50) DEFAULT NULL COMMENT '本地订单号',
              `order_price` double(10,2) DEFAULT NULL COMMENT '订单价格',
              `order_type` tinyint(3) DEFAULT '0' COMMENT '订单类型；0为止；1文章；2会员',
              `pay_type` tinyint(3) DEFAULT '0' COMMENT '支付类型；0无；1支付宝；2微信',
              `create_time` int(10) DEFAULT NULL COMMENT '创建时间',
              `pay_time` int(10) DEFAULT NULL COMMENT '支付时间',
              `pay_num` varchar(50) DEFAULT NULL COMMENT '支付订单号',
              `status` tinyint(3) DEFAULT '0' COMMENT '状态；0 未支付；1已支付；2失效',
              PRIMARY KEY (`id`)
            ) ENGINE=MyISAM DEFAULT CHARSET=" . DB_CHARSET . " COMMENT='订单数据表';");
        }

        update_option('thumbnail_crop', 1);

        // CREATE PAGES
        $init_pages = array(
            'pages/posts-likes.php' => array('点赞排行', 'likes'),
            'pages/tags.php'        => array('热门标签', 'tags'),
            'pages/sitemap.php'     => array('网站地图', 'sitemap'),
            'pages/login.php'       => array('登录注册', 'login'),
            'pages/user.php'        => array('用户中心', 'user'),
        );

        foreach ($init_pages as $template => $item) {

            $one_page = array(
                'post_title'  => $item[0],
                'post_name'   => $item[1],
                'post_status' => 'publish',
                'post_type'   => 'page',
                'post_author' => 1,
            );

            $one_page_check = get_page_by_title($item[0]);

            if (!isset($one_page_check->ID)) {
                $one_page_id = wp_insert_post($one_page);
                update_post_meta($one_page_id, '_wp_page_template', $template);
            }

        }
    }
endif;
add_action('after_setup_theme', 'rizhuti_setup');

/**
 * [Init_theme 激活主题跳转设置页面]
 * @Author   Dadong2g
 * @DateTime 2019-05-28T11:16:53+0800
 * @param    [type]                   $oldthemename [description]
 */
function Init_theme($oldthemename){
  global $pagenow;
  if ( 'themes.php' == $pagenow && isset( $_GET['activated'] ) ) {
    wp_redirect( admin_url( 'admin.php?page=cs-options#tab=23' ) );
    exit;
  }
}

add_action('after_switch_theme', 'Init_theme');



// ===== remove edit profile link from admin bar and side menu and kill profile page if not an admin
if( !current_user_can('manage_options') ) {
function mytheme_admin_bar_render() {
    global $wp_admin_bar;
    $wp_admin_bar->remove_menu('edit-profile', 'user-actions');
}
add_action( 'wp_before_admin_bar_render', 'mytheme_admin_bar_render' );
 
function stop_access_profile() {
    if(@IS_PROFILE_PAGE === true) {
        wp_die( '此页面权限不足，请使用网站管理员账号登录管理' );
    }
    remove_menu_page( 'profile.php' );
    remove_submenu_page( 'users.php', 'profile.php' );
}
add_action( 'admin_init', 'stop_access_profile' );
}


/**
 * Functions which require the theme options.
 */
require get_template_directory() . '/inc/codestar-framework/codestar-framework.php';


if ( ! function_exists( '_hui' ) ) {
  function _hui( $option = '', $default = null ) {
    $options = get_option(CS_OPTION); // Attention: Set your unique id of the framework
    return ( isset( $options[$option] ) ) ? $options[$option] : $default;
  }
}


if (!function_exists('_hui_img')) {
    function _hui_img($option = '', $default = '')
    {
        $options = get_option(CS_OPTION); // Attention: Set your unique id of the framework
        return ( isset( $options[$option] ) ) ? $options[$option]['url'] : $default;
    }
}

/**
 * 日进去主题的模板标签函数
 */
require_once get_stylesheet_directory() . '/inc/functions-theme.php';
require_once get_stylesheet_directory() . '/oauth/qq/qq-class.php';


/**
 * 
 * 日进去主题的商城订单框架
 */
require_once get_stylesheet_directory() . '/shop/init.php';

