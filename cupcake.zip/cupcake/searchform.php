<form id="searchform" class="searchform" action="<?php bloginfo('url'); ?>" method="get" role="Search">
	<input class="searchBox" id="s" type="text" name="s" placeholder="Search..." ></input>
</form>