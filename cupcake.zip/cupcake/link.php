<?php
	/*
	Template Name: 友情連結
	*/
	get_header();
?>
<?php get_template_part('func/link'); ?>
<?php get_footer(); ?>