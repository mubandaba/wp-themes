			<div class="footer">
				<p class="one">&copy; <a href="<?php bloginfo("url"); ?>" title="&copy; 2014 <?php bloginfo("name"); ?>"><?php bloginfo("name"); ?></a> All rights reserved.</p>
				<p class="two"><a href="#" title="這個網站使用「CupCake」主題" target="_blank">CupCake</a> theme design by <a href="http://tsin.us" title="訪問作者網站" target="_blank">千歲貓</a>, <a href="http://tw.wordpress.org/" title="訪問 WordPress 官方網站" target="_blank">WordPress</a> 驅動</p>
			</div>
		</div>
	</body>
	<?php wp_footer(); ?>
	<?php echo get_option('cupcake_footerCode'); ?>
</html>