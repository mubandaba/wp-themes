<?php if(is_dynamic_sidebar()) dynamic_sidebar('left-sidebar');?>
<?php if(get_option('cupcake_linksTool')) : ?>
<li id="linksCC" class="widget widget_linksCC">
	<div class="titleWrapp">
		<h1 class="title"><?php _e('友情連結', 'cake'); ?></h1>
		<a class="icon" title="<?php _e('這個網站使用 CpuCake 主題', 'cake'); ?>" target="_blank" href="http://tsin.us"></a>
	</div>
	<ul>
		<?php if (function_exists(blogroll)) blogroll();?>
	</ul>
</li>
<?php endif; ?>