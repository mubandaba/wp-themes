/*-----------------------------------------------------------------------------------

 	Popup Window JS by Author of Larryslist theme @tradesouthwest
        Feel free to alter as fit. GPL2 License
 
-----------------------------------------------------------------------------------*/

var popupWindow = null;
function centeredPopup(url,winName,w,h,scroll){
LeftPosition = (screen.width) ? (screen.width-w)/2 : 0;
TopPosition = (screen.height) ? (screen.height-h)/2 : 0;
settings =
'height='+h+',width='+w+',top='+TopPosition+',left='+LeftPosition+',scrollbars='+scroll+',resizable'
popupWindow = window.open(url,winName,settings)
}