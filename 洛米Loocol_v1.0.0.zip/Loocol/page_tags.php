<?php
/*
Template Name: 标签页
*/
?>
<?php get_header(); ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <div class="mainleft">
		<div class="article_container row  box">
			<h1 class="page_title"><?php the_title(); ?></h1>
        	<div class="context">
            	<div class="tagcloud"><?php wp_tag_cloud('smallest=13&largest=13&unit=px&number=0&orderby=count&order=DESC');?></div>
            </div>
		</div>
	<?php endwhile;endif; ?>
  	</div>
	<?php get_sidebar(); ?>	
</div>
<?php get_footer(); ?>