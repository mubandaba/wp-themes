<?php get_header();?>
    <div class="mainleft">
    	<?php if (get_option('loocol_slides') == 'Display'&& $post==$posts[0] && !is_paged()) {include('includes/slides.php');} ?>
    <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('首页幻灯区域') ) :; endif;?>
        <ul id="post_container" class="clearfix">
        <?php $limit = get_option('posts_per_page');$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;?>
        <?php if (get_option( 'sticky_posts' )){ query_posts( array('post__in'=>get_option( 'sticky_posts' ),'ignore_sticky_posts' => 1,'paged'=>$paged))?>
		<?php include('includes/list_post.php');} ?>
        <?php query_posts(array('cat'=>get_option('loocol_leiid'),'post__not_in' => get_option( 'sticky_posts' ),'paged'=>$paged)); ?>
			<?php include('includes/list_post.php'); ?>
    	</ul>
			<div class="clear"></div>
			<?php if (get_option('loocol_scrolladd') == 'Display') { ?>
			<div class="navigation container" id="ajax-load-posts"><?php next_posts_link(__('加载文章'));?></div>
			<?php }else{?>
			<div class="navigation container"><?php pagination(5);?></div>
			<?php }?>
		</div>
		<?php get_sidebar();?>
	</div>
<div class="clear"></div>
<?php get_footer()?>
