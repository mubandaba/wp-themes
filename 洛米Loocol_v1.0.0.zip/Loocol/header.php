<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<meta charset="UTF-8">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type');?>" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<?php include('includes/seo.php');?>
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name');?> RSS Feed" href="<?php bloginfo('rss2_url');?>" />
<link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name');?> Atom Feed" href="<?php bloginfo('atom_url');?>" />
<link rel="shortcut icon" href="<?php echo stripslashes(get_option('loocol_favicon')); ?>" type="image/x-icon" />
<link rel="pingback" href="<?php bloginfo('pingback_url');?>" />
<!--[if lte IE 7]><script>window.location.href='http://7xkipo.com1.z0.glb.clouddn.com/upgrade-your-browser.html?referrer='+location.href;</script><![endif]-->
<?php my_scripts_method; wp_head()?>
<?php flush()?>
<style>
<?php if (get_option('loocol_widemodel') == 'Display') { ?>			
@media only screen and (min-width:1330px) {
.container { max-width: 1312px !important; }
.slider { width: 980px !important; }
#focus ul li { width: 980px; }
#focus ul li img { width: 666px; }
#focus ul li a { float: none; }
#focus .button { width: 980px; }
.slides_entry { display: block !important; margin-top: 10px; font-size: 14.7px; line-height: 1.5em; }
.mainleft{width:980px}
.mainleft .post .article h2{font-size:28px;}
.mainleft .post .article .entry_post{font-size:16px;}
.post .article .info{font-size:14px}
.flex-caption { left: 650px !important; width: 292px; bottom: 0 !important; height: 350px; }
.flex-caption h2 { line-height: 1.5em; margin-bottom: 20px; padding: 10px 0 20px 0; font-size: 18px; font-weight: bold; border-bottom: 1px #fff dashed; }
.flex-caption .btn { display: block !important; margin-top: 30px; width: 55px; }
.flex-caption .btn a { color: #333; }
#focus ul li a img { width: 650px !important; }
.related{height:auto}
.related_box{ width:155px !important}
<?php }?>
</style>
</head>
<body  class="custom-background">
		<div id="head" class="row">
        <?php if (get_option('loocol_toolbar') == 'Display') { ?>			
        	<div class="mainbar row">
                <div class="container">
                        <div id="topbar">
                            <?php if(function_exists('wp_nav_menu')) {
                            wp_nav_menu(array(
                            'theme_location'=>'toolbar',
                            'menu_id'=>'toolbar',
                            'container'=>'ul')
                            );}
                            ?>
                        </div>
                        <div class="web_icons">
                            <ul>
                                <?php if(get_option('loocol_rssurl') == 'Display') { ?>
								<li><a href="<?php bloginfo('rss2_url')?>" target="_blank" class="icon1" title="欢迎订阅<?php bloginfo('name');?>"><i class="fa fa-rss"></i></a></li><?php }?>
                                 <?php if(get_option('loocol_tqqurl')) { ?>
                                <li><a href="<?php echo stripslashes(get_option('loocol_tqqurl')); ?>" target="_blank" class="icon2" title="我的腾讯微博" rel="nofollow"><i class="fa fa-tencent-weibo"></i></a></li><?php } ?>
                                <?php if(get_option('loocol_weibourl')) { ?>
                                <li><a href="<?php echo stripslashes(get_option('loocol_weibourl')); ?>" target="_blank" class="icon3" title="我的新浪微博" rel="nofollow"><i class="fa fa-weibo"></i></a></li><?php }?>
                                <?php if(get_option('loocol_sitemap')) { ?>
                                <li><a href="<?php echo stripslashes(get_option('loocol_sitemap')); ?>" target="_blank" class="icon4" title="站点地图"><i class="fa fa-sitemap"></i></a></li><?php }?>
                            </ul>
                        </div>
                 </div>  
             </div>
             <div class="clear"></div>
         <?php }else{?>              
			<div class="row"></div>
		<?php }?>
				<div class="container">
					<div id="blogname" class="third">
                    	<a href="<?php bloginfo('url');?>/" title="<?php bloginfo('name');?>"><?php if ( is_home() || is_search() || is_category() || is_month() || is_author() || is_archive() ) { ?><h1><?php bloginfo('name');?></h1><?php } ?>
                        <img src="<?php echo stripslashes(get_option('loocol_mylogo')); ?>" alt="<?php bloginfo('name');?>" /></a>
                    </div>
                 	<?php if (get_option('loocol_logoadccode') == true) { ?>
                 	<div class="banner twothird">
                 	<?php echo stripslashes(get_option('loocol_logoadccode')); ?>
					</div>
                	<?php } ?>
                </div>
				<div class="clear"></div>
		</div>
		<div class="container">
			<div class="mainmenu clearfix">
				<div class="topnav">
                    <div class="menu-button"><i class="fa fa-reorder"></i> 网站导航</div>
                    	<?php if(function_exists('wp_nav_menu')) {wp_nav_menu(array('theme_location'=>'nav','container'=>'ul'));}?>
               <?php if (get_option('loocol_menusearch') == 'Display') { ?>     
                <ul class="menu-right">
                    <li class="menu-search">
                    	<a href="#" id="menu-search" title="搜索"><i class="fa fa-search"></i></a>
                    	<div class="menu-search-form ">
							<form action="<?php bloginfo('url');?>" method="get">
                            	<input name="s" type="text" id="search" value="" maxlength="150" placeholder="请输入搜索内容" x-webkit-speech style="width:135px">
                            	<input type="submit" value="搜索" class="button"/>
                            </form>
                        </div>
                    </li>
                </ul> 
                <?php }?>
                 <!-- menus END -->                    
				</div>
			</div>
			<?php if(is_home()){?>
				<?php if (get_option('loocol_gg') == 'Display') { ?>
				<div class="subsidiary box">
					<div class="bulletin fourfifth">
						<i class="fa fa-volume-up"></i> <?php echo get_option('loocol_announce'); ?>
					 </div>
					 <div class="bdshare_small fifth">
					 <?php if (get_option('loocol_bdshare') == 'Display') { ?>
						<!-- Baidu Button BEGIN -->
								<div class="bdsharebuttonbox">
									<a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a>
									<a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a>
									<a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a>
									<a href="#" class="bds_renren" data-cmd="renren" title="分享到人人网"></a>
									<a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a>
									<a href="#" class="bds_huaban" data-cmd="huaban" title="分享到花瓣"></a>
									<a href="#" class="bds_more" data-cmd="more"></a>
								</div>
						<!-- Baidu Button END -->
						<?php }?>
					</div>
				</div>
				<?php } ?>
			<?php }else{?>			
						<?php if (get_option('loocol_breadcrumb') == 'Display') { ?>
							<div class="subsidiary box clearfix">           	
								<div class="bulletin">
									<?php loo_breadcrumbs(); ?>
								 </div>
							</div>
			<?php }}?>			
			<div class="row clear"></div>
		</div>
<div class="container">
		<?php if(is_active_sidebar( 'widget_full' )){ dynamic_sidebar('widget_full');}?>
		<?php if(is_mobile() && get_option('loocol_adphone')){?><div class="adphone"><div class="row"><?php echo stripslashes(get_option('loocol_adphone')); ?></div></div><?php }?>
