<?php get_header();?>
    <div class="mainleft" style="width:100%">
		<div class="article_container row  box">
           <div class="third centered" style="text-align:center; margin:50px auto;">
				<h2><center>&#x65B0;&#x777F;&#x793E;&#x533A;&#x63D0;&#x793A;&#xFF1A;&#x60A8;&#x6253;&#x5F00;&#x7684;&#x9875;&#x9762;&#x672A;&#x80FD;&#x627E;&#x5230;&#x3002;</center></h2>
        		<div class="context">
       			  <center><a href="<?php bloginfo('siteurl');?>" title="返回首页"><img src="<?php bloginfo('template_directory'); ?>/images/404.gif" alt="Error 404 - Not Found" /></a></center>
            	</div>
			</div>
        </div>
	</div>
</div>
</body>
<?php get_footer();?>