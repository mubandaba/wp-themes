	<div id="sidebar">
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('全站侧边栏') ) :; endif;?>
		<?php if(is_home()){?><?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('首页侧边栏') ) :; endif;?><?php }?>
		<?php if(is_single()){?><?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('文章页侧边栏') ) :; endif;?><?php }?>
		<?php if(is_page()){?><?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('页面侧边栏') ) :; endif;?><?php }?>
		<?php if(is_archive() || is_tag() || is_search()){?><?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('分类/标签/搜索页侧边栏') ) :; endif;?><?php }?>
		<div id="sidebar-follow">
			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('全站滚动侧边栏') ) :; endif;?>
		</div>
	</div>
