<?php
	include(dirname(__FILE__).'/index.php');
?>