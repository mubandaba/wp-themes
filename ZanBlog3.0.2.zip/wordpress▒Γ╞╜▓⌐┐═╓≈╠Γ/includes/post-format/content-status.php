<article class="zan-post format-status">
	<div class="data"><?php the_time("Y-n-d") ?></div>
	<?php the_content(); ?>
</article>