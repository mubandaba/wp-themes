=== 博客一号WordPress主题 ===

贡献者: 主题巴巴
最低版本要求: WordPress 4.5
最高版本兼容: WordPress 5.0-trunk
版本: 1.0.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: one-column, two-columns, right-sidebar, flexible-header, accessibility-ready, custom-colors, custom-header, custom-menu, custom-logo, editor-style, featured-images, footer-widgets, sticky-post, theme-options, threaded-comments, translation-ready

== 描述 ==

博客一号是一款由主题巴巴网原创的免费WordPress主题，适合用于各类博客型网站和个人站点。

关于更多主题信息请访问：http://www.zhutibaba.com

== 安装 ==

1. 登陆 WordPress 管理员后台（仪表盘），从侧边栏进入 “外观” -> “主题”，点击“添加” -> “上传主题”，选择主题文件“boke-1.zip”，并点击“现在安装”。

2. 安装完成后，点击“启用”。

3. 从侧边栏进入 “外观” -> “自定义”，设置你的主题。

4. 从侧边栏进入 “外观” -> “小工具”，使用你所需的小工具。

== 版权信息 ==

博客一号WordPress主题, 版权所有 2018 主题巴巴 zhutibaba.com / 海口优页网络科技有限公司

== 更新日志 ==

= 1.0.5 - 2018-07-10 =
* 修复特色图片小于740x414像素时，首页幻灯片显示错误（重要更新！）

= 1.0.4 - 2018-07-09 =
* 修复在某些主机环境下首页出现PHP错误

= 1.0.3 - 2018-07-03 =
* 修复在文章页段落中的图片显示问题

= 1.0.2 - 2018-07-01 =
* 修复首页文章列表分页错误（重要更新）
* 修复评论区域中文描述
* 修复评论导航分页样式
* 修复无内容页面段落缩进
* 修复主题语言文件 /languages/boke-1.pot
* 添加主题巴巴官方网站链接到管理栏

= 1.0.1 - 2018-06-26 =
* 更新小工具中文表述
* 修复首页文章信息向右对齐

= 1.0 - 2018-06-21 =
* 发布主题