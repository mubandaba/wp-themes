主题语言文件说明

主题巴巴所有WordPress主题都可以翻译成多种语言，只需要下载安装以下免费插件，即可通过WordPress后台在线翻译主题：

https://wordpress.org/plugins/loco-translate/
