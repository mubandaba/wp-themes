<?php 
/*
	template name: 文章列表
*/
?>
<?php get_header();?>

<div class="content">
  <div class="container">
    <div class="row">
     
      <div class="col-md-11 ten">
        <div class="part current" id="7" data-title="<?php single_cat_title(); ?>">
          <h2 class=""><strong><?php single_cat_title(); ?></strong></h2>
          <div class="items ">
            <div class="row">
              <?php if(have_posts()): ?>
              <?php while(have_posts()):the_post();  ?>
              <div class="col-xs-12 col-sm-4 col-md-3">
                <div class="item list"> <a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title_attribute(); ?>"> 
                  <h3><?php the_title_attribute(); ?></h3>
                  <p><?php if(has_excerpt()) the_excerpt(); else echo mb_strimwidth(strip_tags($post->post_content),0,50,'...'); ?></p>
                  </a> </div>
              </div>
              <?php endwhile ?>
              <?php endif ?>
            </div>
          </div>
          
          <div class="clear"></div>
<div class="wpagenavi">
        <?php par_pagenavi(9); ?>
      </div>
      
        </div>
      </div>
    </div>
  </div>
</div>
<?php get_footer(); ?>
