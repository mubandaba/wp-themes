<?php get_header();?>
<style>
.f404{text-align: center;margin: 100px 0;}
.f404 h1{font-size: 60px;margin: 40px 0 20px;}
.f404 h2{font-size: 16px;margin-bottom: 20px;}
</style>
<div id="page-content">
  <div class="container">
    <div class="f404">
      <h1>404 . Not Found</h1>
      <h2>沒有找到你要的内容！</h2>
      <p> <a class="btn btn-primary" href="<?php bloginfo('url'); ?>">返回 <?php bloginfo('name'); ?> 首页</a> </p>
    </div>
  </div>
</div>
<?php get_footer(); ?>
