<?php
/* options css */
$header_image = get_header_image();
$bg_image = get_background_image();
$bg_color = get_background_color();
?>

<?php
if( get_theme_option('body_font') == 'Choose a font' || get_theme_option('body_font') == '') { ?>
body, .post-meta { font-family:'Open sans',arial,sans-serif;}
<?php } else { ?>
body, .post-meta { font-family: <?php echo get_theme_option('body_font'); ?> !important; font-weight: <?php echo get_theme_option('body_font_weight'); ?> !important; }
<?php } ?>

<?php
if( get_theme_option('headline_font') == 'Choose a font' || get_theme_option('headline_font') == '') { ?>
h1,h2,h3,h4,h5,h6,#siteinfo h1, #siteinfo div,ul.tabbernav li a,#post-entry div.post-thumb span.post-category a,#post-entry .post-meta,.fbottom,#textpad  {font-family:'Oswald',arial,sans-serif;font-weight:400;}
<?php } else { ?>
h1,h2,h3,h4,h5,h6,#siteinfo h1, #siteinfo div,ul.tabbernav li a,#post-entry div.post-thumb span.post-category a,#post-entry .post-meta,.fbottom,#textpad  {
font-family:  <?php echo get_theme_option('headline_font'); ?> !important; font-weight: <?php echo get_theme_option('headline_font_weight'); ?> !important;}
<?php } ?>

<?php
if( get_theme_option('navigation_font') == 'Choose a font' || get_theme_option('navigation_font') == '') { ?>
#main-navigation, .sf-menu li a { font-family:'Oswald',arial,sans-serif;font-weight:300;}
<?php } else { ?>
#main-navigation, .sf-menu li a { font-family:  <?php echo get_theme_option('navigation_font'); ?> !important; font-weight: <?php echo get_theme_option('navigation_font_weight'); ?> !important;}
<?php } ?>

<?php
$main_color = get_theme_option('main_color');
if( $main_color ) { ?>

#post-entry article span.read-more a,#right-sidebar aside .textwidget a {color: <?php echo $main_color; ?>;}
.sf-menu ul,#post-entry div.post-thumb span.post-category a {color:#fff !important;background: <?php echo $main_color; ?> none;}
.sf-menu ul li a:hover {background: <?php echo dehex($main_color,-10); ?> none;}

#right-sidebar a,#right-sidebar aside.widget a:hover,.content a,#post-related h2 a, #post-related p a, #post-related-inline h2 a {color: <?php echo $main_color; ?>;}

#container .content a:hover {color:<?php echo dehex($main_color,-20); ?> !important;}

<?php } ?>