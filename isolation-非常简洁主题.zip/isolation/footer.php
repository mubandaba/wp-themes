<!--footer start-->
<footer class="site_footer ">
    <div class="uk-background-muted uk-section uk-section-xsmall">

        <div class="uk-container uk-container-small">

            <div class="uk-flex-middle uk-margin-remove-vertical uk-grid" uk-grid="">

                <div class="uk-width-expand@s uk-first-column">

                    <div class="uk-margin uk-text-left@s uk-text-center uk-text-muted uk-text-small">
                        Copyright © 2018 <a href="https://www.wpmee.com/">魏星笔记</a> • THEME BY <a href="https://www.wpmee.com/">WPMEE</a>
                    </div>




                </div>

                <div class="uk-width-expand@s">

                    <div class="uk-margin uk-text-right@s uk-text-center">
                        <a href="#" uk-totop="" uk-scroll="" class="uk-totop uk-icon"></a>
                    </div>

                </div>
            </div>


        </div>




    </div>
</footer>
<!--footer end-->
<?php wp_footer()?>
</body>

</html>