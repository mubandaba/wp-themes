<?php get_header()?>
<?php if (have_posts()):while (have_posts()):the_post()?>
<main id="article-list" class="uk-section" >

    <article class="uk-container uk-container-small uk-position-relative ">
        <h2 class="title uk-h2"><?php the_title_attribute()?></h2>
        <p class="uk-comment-meta ">
            <?php $cat = get_the_category();
            $cat_links= get_category_link($cat[0]->term_id);?>
            <a class="uk-link-muted uk-display-inline-block uk-margin-small-left" href="<?php echo $cat_links?>"><?php echo $cat[0]->cat_name;?></a>
            <span>•</span>
            <?php the_author_posts_link()?>
            <span>•</span>
            <time datetime="2018-08-20T09:22:12+00:00"><?php the_time('Y-m-d')?></time>
        </p>
        <div id="post-content" class="post-content">
            <?php the_content()?>
        </div>

        <?php if (cs_get_option('pay_switcher')=='true'){?>
            <?php include 'pay.php';?>
        <?php }?>

    </article>
<?php endwhile;endif;?>
<?php comments_template()?>
</main>
<?php get_footer()?>