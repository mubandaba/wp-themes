<?php get_header()?>
<!--archive title start-->

<section class="uk-section  uk-padding-remove-bottom  ">
    <div class="uk-container uk-container-small  uk-animation-slide-left-medium">
        <h1 class="uk-h3 "><?php the_archive_title()?></h1>
        <div class="uk-width-1-6">
            <hr class="uk-width-1-2 ">
        </div>
    </div>
</section>

<!--archive title end-->

<!--article list start-->
<main id="article-list" class="uk-section uk-padding-small uk-margin-large-bottom" >
    <div class="uk-container uk-container-small ">

        <div class="list-container" uk-scrollspy="target: > .article-item; cls:uk-animation-slide-bottom-medium; ">
            <?php if (have_posts()):while (have_posts()):the_post()?>
            <article class="article-item uk-margin-small-top uk-margin-small-bottom  uk-scrollspy-inview " uk-scrollspy-class="">
                <div class="uk-grid" uk-grid="">
                    <a class="uk-width-expand uk-first-column" href="<?php the_permalink()?>">
                        <h2 class="article_title uk-h5"><?php the_title_attribute()?></h2>
                    </a>
                    <div class=" article-meta text-right uk-width-expand uk-visible@m">
                        <span class="item uk-text-meta font-size-lower uk-display-inline-block">
                            <time datetime="2018-11-17" class="font-size-lower"><?php the_time('Y-m-d')?></time>
                        </span>
                    </div>
                </div>
                <hr>
            </article>
            <?php endwhile;endif;?>
        </div>
        <?php wpmee_pagenavi()?>
    </div>

</main>
<!--article list end-->
<?php get_footer()?>