<?php get_header()?>
<main id="article-list" class="uk-section" >
<?php if (have_posts()):while (have_posts()):the_post()?>
    <article class="uk-container uk-container-small uk-position-relative ">
        <h2 class="title uk-h2">
            <?php the_title_attribute()?>
        </h2>
        <p class="uk-comment-meta ">
            <?php the_author_posts_link()?>
            <span>•</span>
            <time datetime="2018-08-20T09:22:12+00:00"><?php the_time('Y-m-d')?></time>
        </p>
        <div id="post-content" class="post-content">
            <?php the_content()?>
        </div>

    </article>
<?php endwhile;endif;?>
</main>
<!--article list end-->
<?php get_footer()?>