<?php
# 常量定义[Constants]
# ------------------------------------------------------------------------------
define( 'WPSTORM_THEME_NAME'        , 'isolation'                                          );
define( 'WPSTORM_THEME_NICENAME'    , 'isolation'                                          );
define( 'WPSTORM_THEME_AUTHOR'      , 'WPMEE'                                          );
define( 'WPSTORM_THEME_VERSION'     , '1.0.0'                                          );
define( 'WPSTORM_FRAMEWORK_VERSION' , '1.0.0'                                          );
define( 'WPSTORM_PATH'            , get_template_directory()."/wpstorm/"               );
define( 'WPSTORM_WALKER_PATH'     , get_template_directory()."/wpstorm/walker/"        );
define( 'WPSTORM_WIDGET_PATH'     , get_template_directory()."/wpstorm/widget/"        );
define( 'WPSTORM_ENQUEUE_PATH'    , get_template_directory()."/wpstorm/enqueue/"       );
define( 'WPSTORM_ELEMENT_PATH'    , get_template_directory()."/static/elements/"       );
define( 'WPSTORM_SRC_PATH'        , get_template_directory_uri()."/static/"            );
define( 'WPSTORM_CSS_PATH'        , get_template_directory_uri()."/static/css/"        );
define( 'WPSTORM_JS_PATH'         , get_template_directory_uri()."/static/js/"         );
define( 'WPSTORM_IMG_PATH'        , get_template_directory_uri()."/static/img/"        );
define( 'WPSTORM_PIC_PATH'        , get_template_directory_uri()."/static/picture/"    );

# 引用JS/CSS [enqueue]
# ------------------------------------------------------------------------------
require_once(dirname( __FILE__ ) . '/enqueue/enqueue-js.php'               );
require_once(dirname( __FILE__ ) . '/enqueue/enqueue-css.php'              );
require_once(dirname( __FILE__ ) . '/enqueue/enqueue-other.php'            );


# WORDPRESS设置和自定义 [WordPress Settings and Customizations]
# ------------------------------------------------------------------------------
require_once (dirname( __FILE__ ).'/function/wp-thumbnail.php'             );
require_once (dirname( __FILE__ ).'/function/wp-branding.php'              );
require_once (dirname( __FILE__ ).'/function/wp-breadcrumbs.php'           );
require_once (dirname( __FILE__ ).'/function/wp-page_nav.php'              );
require_once (dirname( __FILE__ ).'/function/wp-regMenu.php'               );
require_once (dirname( __FILE__ ).'/function/wp-remove.php'                );
require_once (dirname( __FILE__ ).'/function/wp-seo.php'                   );
require_once (dirname( __FILE__ ).'/function/wp-views.php'                 );
require_once (dirname( __FILE__ ).'/function/wp-excerpt.php'               );
require_once (dirname( __FILE__ ).'/function/wp-strimwidth.php'            );
require_once (dirname( __FILE__ ).'/function/wp-list-category.php'         );
require_once (dirname( __FILE__ ).'/function/wp-wpstorm.php'               );
require_once (dirname( __FILE__ ).'/function/wp-gavatar.php'               );
require_once (dirname( __FILE__ ).'/function/wp-commentslist.php'          );
require_once (dirname( __FILE__ ).'/function/uk-alert_support.php'         );
require_once (dirname( __FILE__ ).'/function/wp-shortcode.php'             );
require_once( dirname( __FILE__ ).'/function/admin-thumb.php'              );
require_once( dirname( __FILE__ ).'/widget/wp-footwidget.php'              );
require_once( dirname( __FILE__ ).'/function/uk-alert_support.php'         );
require_once( dirname( __FILE__ ).'/function/wp-catthumb.php'              );
//require_once( dirname( __FILE__ ).'/updater/theme-updater.php'             );

# 创建小工具
# ------------------------------------------------------------------------------
require_once ( dirname( __FILE__ ).'/widget/wp-imgwidget.php'              );
require_once ( dirname( __FILE__ ).'/widget/wp-footwidget.php'             );
require_once ( dirname( __FILE__ ).'/widget/wp-lastpostwidget.php'         );


# 分享
# ------------------------------------------------------------------------------
require_once ( dirname( __FILE__ ).'/share/share.php'              );
//require_once ( dirname( __FILE__ ).'/share/custom_share.php'             );

# 引用cs框架 [Include the cs framework ]
# ------------------------------------------------------------------------------
require_once( WPSTORM_PATH. 'setting/cs-framework.php'              );

# 引用cs框架 [Include the cs framework ]
# ------------------------------------------------------------------------------
require_once( WPSTORM_PATH. 'setting/cs-framework.php'              );

# Walker引用
# ------------------------------------------------------------------------------
require_once( dirname( __FILE__ ).'/walker/WordpressUikitMenuWalker.php'   );
require_once( dirname( __FILE__ ).'/walker/wp-mobilewalker.php'            );
require_once( dirname( __FILE__ ).'/walker/wp-footermenu.php'              );

# 去除wordpress前台顶部工具条
# ------------------------------------------------------------------------------
show_admin_bar(false);

# 自定义裁剪特色图像
# ------------------------------------------------------------------------------
add_theme_support( 'post-thumbnails' );
add_image_size( 'post_thumb',    533,  341,   true );
add_image_size( 'down_thumb',    660,  430,   true );
add_image_size( 'hd_post',       435,  435,   true );

# 自定义裁剪特色图像
# ------------------------------------------------------------------------------
remove_filter('comment_text','wpautop',30);

# 注册短代码
# ------------------------------------------------------------------------------
function EyeStormShortcode($atts, $content = null){ // $atts 代表了 shortcode 的各个参数，$content 为标签内的内容

    extract(shortcode_atts(array( // 使用 extract 函数解析标签内的参数
        "title" => '标题' // 给参数赋默认值，下面直接调用 $ 加上参数名输出参数值
    ), $atts));
    // 返回内容
    return '<h3 class="uk-margin-medium uk-margin-remove-top uk-text-left@m uk-text-center uk-h2 uk-scrollspy-inview uk-animation-slide-bottom-medium" uk-scrollspy-class="" style="">'. $title .'</h3><div class="uk-margin uk-width-large@s uk-margin-auto uk-text-left@m uk-text-center uk-scrollspy-inview uk-animation-slide-bottom-medium" uk-scrollspy-class="" style="">'. $content .'</div>';
}

add_shortcode("es", "EyeStormShortcode"); // 注册该 shortcode，以后使用 [msc] 标签调用该 shortcode


