<?php
function ukBackgroundClass($switcher){
if ($switcher =="gray"){
	echo "uk-background-muted";
}}
function uk_src_srcset($img_id){
	$img_src    = wp_get_attachment_image_src($img_id) ;
	$img_srcset = wp_get_attachment_image_srcset($img_id);
	return 'data-src="'.$img_src.'" data-srcset="'.$img_srcset.'" src="'.$img_src.'" srcset="'.$img_srcset.'"';
}
