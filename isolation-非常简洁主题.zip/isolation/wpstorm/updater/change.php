<?php get_header()?>

    <div class="uk-section uk-section-default uk-flex uk-flex-center uk-flex-middle uk-text-center" uk-height-viewport>
        <div>
            <h1 class="uk-heading-primary"><?php echo WPSTORM_THEME_NAME?></h1>
            <p class="uk-h2">坦率的讲这个页面的存在只是为了体现我们的态度，主题尚未激活</p>
            <a class="uk-button uk-button-primary" href="<?php bloginfo('url')?>/wp-admin/themes.php?page=<?php echo WPSTORM_THEME_NICENAME?>-license">去激活</a>
        </div>
    </div>
