<?php

if (!defined('ABSPATH')) {
    die;
} // 不能直接访问网页.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// 主题框架设置
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$settings = array(
    'menu_title' => '主题设置',
    'menu_type' => 'menu', // menu, submenu, options, theme, etc.
    'menu_slug' => 'wpstormtheme' . '-' . wp_get_theme()->display('Name'),
    'menu_position' => 59,
    'ajax_save' => true,
    'show_reset_all' => false,
    'menu_icon' => 'dashicons-hammer',
    'framework_title' => wp_get_theme()->display('Name') . '<small class="oldVer" data-vs="' . WPSTORM_THEME_VERSION . '" style="color:#979797;margin-left:10px">Release ' . WPSTORM_THEME_VERSION . '</small>',
);
// ----------------------------------------
// 小工具设置--------------------------------
// ----------------------------------------
$options[] = array(
    'name'   => 'widget',
    'title'  => '打赏功能',
    'icon'   => 'fa fa-linode',
    'fields' => array(
        array(
            'id'      => 'pay_switcher',
            'type'    => 'switcher',
            'title'   => '开启打赏',
            'default' => false
        ),
        array(
            'id'              => 'pay_group',
            'type'            => 'group',
            'title'           => '打赏功能',
            'button_title'    => '添加',
            'accordion_title' => '添加',
            'dependency'   => array( 'pay_switcher', '==', 'true' ),
            'fields'          => array(
                array(
                    'id'            => 'pay_title',
                    'type'          => 'text',
                    'title'         => '标题',
                ),
                array(
                    'id'            => 'pay_code',
                    'type'          => 'image',
                    'title'         => '收钱码',
                    'add_title'     => '上传',
                ),
            ),
        ),
    )
);
// ----------------------------------------
// 公告设置---------------------------------
// ----------------------------------------
$options[] = array(
    'name'   => 'notice',
    'title'  => '公告设置',
    'icon'   => 'fa fa-bullhorn',
    'fields' => array(
        array(
            'type'    => 'notice',
            'class'   => 'info',
            'content' => '公告栏设置',
        ),
        array(
            'id'      => 'notice_switcher',
            'type'    => 'switcher',
            'title'   => '公告栏开关',
            'default' => false,
        ),
        array(
            'id'           => 'notice_content',
            'type'         => 'wysiwyg',
            'dependency'   => array( 'notice_switcher', '==', 'true' ),
            'title'        => '公告栏内容',
        ),
        array(
            'id'      => 'notice_bgc',
            'class'   => 'horizontal',
            'type'    => 'radio',
            'title'   => '通知栏背景色',
            'dependency'  => array( 'notice_switcher', '==', 'true' ),
            'options'     => array(
                'blue'    => '蓝色',
                'red'     => '红色',
                'orange'  => '橙色',
                'green'   => '绿色',
            ),
            'default'     => 'blue'
        ),

    )
);
// ----------------------------------------
// SEO-------------------------------------
// ----------------------------------------
$options[] = array(
    'name' => 'speed',
    'title' => 'SEO设置',
    'icon' => 'fa fa-magic',
    'fields' => array(
        array(
            'type' => 'notice',
            'class' => 'info',
            'content' => '首页SEO设置',
        ),
        array(
            'id' => 'seo_home_title', // this is must be unique
            'type' => 'text',
            'title' => '首页标题',
            'help' => '关键词使用英文逗号隔开',
        ),

        array(
            'id' => 'seo_home_keywords', // this is must be unique
            'type' => 'text',
            'title' => '首页关键词',
        ),

        array(
            'id' => 'seo_home_desc', // this is must be unique
            'type' => 'textarea',
            'title' => '首页描述',
        ),
    ),
);
// ----------------------------------------
// 自定义代码-------------------------------
// ----------------------------------------
$options[] = array(
    'name' => 'code',
    'title' => '自定义',
    'icon' => 'fa fa-code',
    'fields' => array(

        array(
            'class' => 'info',
            'type' => 'notice',
            'content' => '自定义代码',
        ),

        array(
            'id' => 'code_2_head',
            'type' => 'wysiwyg',
            'title' => '自定义样式css代码',
            'desc' => '显示在网站头部 &lt;head&gt;'

        ),
        array(
            'id' => 'code_2_footer',
            'type' => 'wysiwyg',
            'title' => 'footer自定义代码',
            'desc' => '显示在网站底部'
        ),
    )
);
// ----------------------------------------
// 备份-------------------------------------
// ----------------------------------------
$options[] = array(
    'name' => 'advanced',
    'title' => '备份',
    'icon' => 'fa fa-shield',
    'fields' => array(

        array(
            'type' => 'notice',
            'class' => 'danger',
            'content' => '您可以保存当前的选项，下载一个备份和导入.（此操作会清除网站数据，请谨慎操作）',
        ),

        // 备份
        array(
            'type' => 'backup',
        ),

    )
);

CSFramework::instance($settings, $options);


