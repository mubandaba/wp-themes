<?php
if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
/**
 *
 * CSFramework Shortcode Config
 *
 * @since 1.0
 * @version 1.0
 *
 */
$shortcodes       = array();

$shortcodes[]     = array(
    'name'          => 'group_1',
    'title'         => '短代码',
    'shortcodes'    => array(

        array(
            'name'      => 'recent-posts',
            'title'     => '添加短代码',
            'fields'    => array(
                array(
                    'id'    => 'title',
                    'type'  => 'text',
                    'title' => '标题',
                ),
                array(
                    'id'    => 'content',
                    'type'  => 'textarea',
                    'title' => '内容',
                )
            ),
        ),

    )
);

CSFramework_Shortcode_Manager::instance( $shortcodes );