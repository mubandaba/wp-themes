<?php
class PicWidget extends WP_Widget {
    function __construct() {
        // Instantiate the parent object
        parent::__construct(
        // 小工具ID
            'pic',
            // 小工具名称
            "图片",
            // 小工具选项
            array (
                'description' => "设置侧边栏图片"
            )
        );
    }
    function widget( $args, $instance ) {
        // Widget output
        // kick things off
        $url = $instance[ 'depth' ];
        $link = $instance[ 'link' ];
        $title = $instance['title'];
        extract( $args );
        echo $before_widget;
        ?>
        <div class="el-item uk-card uk-card-default uk-card-hover uk-animation-slide-bottom-medium uk-margin-small-bottom" uk-scrollspy-class>
            <a href="<?php echo $link; ?>" class="el-link uk-position-cover uk-position-z-index uk-margin-remove-adjacent" data-caption></a>
            <img src="<?php echo $url; ?>"  alt="<?php echo $title; ?>" class="wdp-appear">
        </div>
        <?php
    }
    function update( $new_instance, $old_instance ) {
        // Save widget options
        $instance = $old_instance;
        $instance[ 'depth' ] = strip_tags( $new_instance[ 'depth' ] );
        $instance[ 'link' ] = strip_tags( $new_instance[ 'link' ] );
        $instance['title'] = strip_tags($new_instance['title']);
        return $instance;
    }
    function form( $instance ) {
        // Output admin widget options form
        $defaults = array(
            'depth' => '-1'
        );
        $depth = $instance[ 'depth' ];
        $link = $instance[ 'link' ];
        $title = $instance['title'];
        // markup for form
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>">填写图片标题</label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'depth' ); ?>">填写图片地址</label>
            <input class="widefat" type="text" id="<?php echo $this->get_field_id( 'depth' ); ?>" name="<?php echo $this->get_field_name( 'depth' ); ?>" value="<?php echo esc_attr( $depth ); ?>">
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'link' ); ?>">填写图片链接</label>
            <input class="widefat" type="text" id="<?php echo $this->get_field_id( 'link' ); ?>" name="<?php echo $this->get_field_name( 'link' ); ?>" value="<?php echo esc_attr( $link ); ?>">
        </p>
        <?php
    }
}
function register_widgets() {
    register_widget( 'PicWidget' );
}
add_action( 'widgets_init', 'register_widgets' );