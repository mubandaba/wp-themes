<?php
function textarea_title($atts, $content=null, $code="") {
    return ''.$content.'';
}
add_shortcode('textarea_title', 'textarea_title');
function textarea_subtitle($atts, $content=null, $code="") {
    return 'fubiaoti'.$content.'fub';
}
add_shortcode('textarea_subtitle', 'textarea_subtitle');
