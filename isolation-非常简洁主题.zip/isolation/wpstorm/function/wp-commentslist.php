<?php
//评论列表样式
function simple_comment($comment, $args, $depth) {
    $GLOBALS['comment'] = $comment; ?>
    <li id="comment-<?php comment_ID(); ?>" class="uk-margin-small-top">
        <article id="comment-article-<?php comment_ID(); ?>" class="uk-comment">
            <div class="uk-grid-medium  uk-grid" uk-grid="">

                <div class="uk-width-auto uk-first-column uk-overflow-hidden uk-margin-small-top">
                    <?php $avatar_url = get_avatar_url(get_avatar( $comment, 50 )); ?>
                    <img alt="" class="avatar avatar-48 uk-border-circle" height="48" width="48" src="<?php echo $avatar_url?>" srcset="<?php echo $avatar_url?>">
                </div>

                <div class="uk-width-expand uk-padding-small uk-padding-remove-top">
                    <a href="<?php comment_author_url()?>" rel="external nofollow" class="uk-display-block"><?php comment_author()?></a>
                    <div class="uk-background-muted uk-border-rounded uk-display-inline-block uk-padding-small uk-margin-small-top ">
                        <?php comment_text();?>
                        <?php if ( $comment->comment_approved == '0' ) : ?>
                            您的评论正在等待审核中...
                        <?php endif; ?>
                    </div>
                    <p class="uk-comment-meta ">
                        <time datetime="2018-08-20T09:22:12+00:00"><?php echo get_comment_time('Y-m-d H:i'); ?></time>
                        <?php
                        $comment_reply_class = 'uk-link-muted uk-display-inline-block uk-margin-small-left';
                        echo preg_replace( '/comment-reply-link/', 'comment-reply-link ' . $comment_reply_class,
                            get_comment_reply_link(array_merge( $args, array(
                                'reply_text' => '回复',
                                'depth' => $depth,
                                'max_depth' => $args['max_depth']))), 1 );
                        ?>
                    </p>
                </div>

            </div>

        </article>
    </li><!-- #comment-## -->

    <?php
}
?>


