<?php
/**
 * 元素
 * Created by PhpStorm.
 * User: wx
 * Date: 2018/11/20
 * Time: 10:43
 */

function create_item(){
    $labels = array(
        'name'                  => '元素',
        'singular_name'         => '元素',
        'add_new'               => '添加元素',
        'add_new_item'          => '添加新元素',
        'edit_item'             => '编辑元素',
        'new_item'              => '新元素',
        'view_item'             => '查看元素',
        'search_items'          => '搜索元素',
        'not_found'             => '未找到元素',
        'not_found_in_trash'    => '回收站中没有元素',
        'parent_item_colon'     => '',
        'all_items'             => '所有元素',
        'archives'              => '元素存档',
        'insert_into_item'      => '插入至元素',
        'uploaded_to_this_item' => '上传到元素元素',
        'filter_items_list'     => '过滤列表',
        'items_list_navigation' => '列表导航',
        'items_list'            => '元素元素列表',
        'menu_name'             => '元素',
        'name_admin_bar'        => '元素'
    );
    $args = array(
        'labels'               => $labels,
        'description'          => '',
        'public'               => true,
        'hierarchical'         => true,
        'exclude_from_search'  => true,
        'publicly_queryable'   => true,
        'show_ui'              => true,
        'show_in_menu'         => true,
        'show_in_nav_menus'    => true,
        'show_in_admin_bar'    => true,
        'menu_position'        => true,
        'menu_icon'            => 'dashicons-images-alt2',
        'menu_position'        => 10,
        'capability_type'      => 'post',
        'capabilities'         => array(),
        'map_meta_cap'         => null,
        'supports'             => array( 'title'),
        'register_meta_box_cb' => null,
        'taxonomies'           => array(),
        'has_archive'          => false,
        'rewrite'              => false,
        'query_var'            => true,
        'can_export'           => true,
        'delete_with_user'     => null
    );
    register_post_type('item', $args);
}
add_action('init','create_item');

