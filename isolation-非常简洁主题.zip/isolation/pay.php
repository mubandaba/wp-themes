<div id="post-zan" class="uk-section uk-text-center">
    <button class="uk-button uk-button-primary submit" uk-toggle="target: #pay">
        赏
    </button>
</div>
<div id="pay" uk-modal>
    <div class="uk-modal-dialog uk-modal-body">
        <button class="uk-modal-close-outside" type="button" uk-close></button>
        <h2 class="uk-modal-title uk-text-center">打赏</h2>
        <div uk-grid>
            <?php
            if(is_array(cs_get_option('pay_group') )){
            foreach ( cs_get_option('pay_group') as $value ):
                $pc_img_url = wp_get_attachment_image_src( $value['pay_code']);
            ?>
            <div class="uk-card uk-card-default uk-width-expand@s">
                <div class="uk-card-media-top">
                    <img src="<?php echo $pc_img_url[0]?>" alt="">
                </div>
                <div class="uk-card-body uk-padding-small">
                    <h3 class="uk-card-title uk-text-center"><?php echo $value['pay_title']?></h3>
                </div>
            </div>
            <?php endforeach;}?>

        </div>

    </div>
</div>