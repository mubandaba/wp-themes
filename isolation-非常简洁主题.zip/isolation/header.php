<!DOCTYPE html>
<html lang="zh-hans" >
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head()?>
</head>
<body>
<?php wpstorm_alert();?>
<header id="mb-header" class="tm-header-mobile uk-hidden@m">

    <nav class="uk-navbar-container" uk-navbar>

        <div class="uk-navbar-center">
            <a class="uk-navbar-item uk-logo" href="<?php bloginfo('url')?>">
                <h1 class="uk-h3 uk-margin-remove-bottom"><?php bloginfo('name')?></h1>
            </a>
        </div>

        <div class="uk-navbar-right">

            <a class="uk-navbar-toggle" href="#tm-mobile" uk-toggle>
                <div uk-navbar-toggle-icon></div>
            </a>

        </div>

    </nav>

    <div id="tm-mobile" uk-offcanvas mode="push" overlay flip>
        <div class="uk-offcanvas-bar uk-flex">

            <button class="uk-offcanvas-close" type="button" uk-close></button>

            <div class="uk-width-1-1">


                <div class="uk-child-width-1-1" uk-grid>
                    <div>
                        <div class="uk-panel" id="module-0">

                            <ul class="uk-nav uk-nav-default">
                                <?php wp_menu('mobile_main_menu', new  Walker_mobile_menu())?>
                            </ul>

                        </div>
                    </div>
                </div>


            </div>

        </div>
    </div>

</header>
<!--mobile header end-->

<!--pc header start-->
<header id="pc-header" class="tm-header  uk-visible@m uk-background-muted " uk-img="">
    <nav class="uk-animation-slide-top-medium uk-navbar-container uk-container uk-container-small uk-navbar-transparent " uk-navbar="dropbar: true;dropbar-mode: push;" style="z-index: 980;">
        <div class="uk-navbar-left uk-margin-large-right">
            <a href="<?php bloginfo('url')?>" class="uk-navbar-item uk-padding-remove">
                <h1 class="uk-h4 pc-logo uk-margin-remove-bottom"><?php bloginfo('name')?></h1>
            </a>
        </div>

        <div class="uk-navbar-left">

            <ul class="uk-navbar-nav" uk-scrollspy="target: > li; cls:uk-animation-slide-top-medium; ">
                <?php wp_menu_with_walker('main_menu', new  Walker_main_menu())?>
            </ul>

        </div>

        <div class="uk-navbar-right">

            <a class="el-link uk-icon uk-navbar-toggle uk-margin-medium-right uk-margin-small-bottom" href="#modal-full" uk-toggle="">
                <svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <circle fill="none" stroke="#000" stroke-width="1.1" cx="9" cy="9" r="7"></circle>
                    <path fill="none" stroke="#000" stroke-width="1.1" d="M14,14 L18,18 L14,14 Z"></path>
                </svg>
            </a>

        </div>

    </nav>
</header>
<!--pc header end-->

<!--search form start-->
<div id="modal-full" class="uk-modal-full uk-modal" uk-modal>
    <div class="uk-modal-dialog uk-flex uk-flex-center uk-flex-middle" uk-height-viewport>
        <button class="uk-modal-close-full" type="button" uk-close></button>
        <form method="get" action="<?php echo home_url('/'); ?>" class="uk-search uk-search-large">
            <input class="uk-search-input uk-text-center" name="s" type="search" placeholder="搜索..." value="<?php echo get_search_query(); ?>" autofocus>
        </form>
    </div>
</div>
<!--search form end-->