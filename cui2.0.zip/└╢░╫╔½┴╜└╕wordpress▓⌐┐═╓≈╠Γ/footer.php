</section>
<footer class="footer">
  <div class="footer-inner">
    <div class="copyright pull-left">
      <p>
        <?php if( dopt('d_footcode_b') ) echo dopt('d_footcode'); ?>&nbsp;&nbsp;
      </p>
    </div>
    <div class="trackcode pull-right">
      <span>Powered by WordPress · Theme by 翠竹林</span>
      <?php if( dopt('d_track_b') ) echo dopt('d_track'); ?>
    </div>
  </div>
</footer>
<?php 
wp_footer(); 
global $dHasShare; 
if($dHasShare == true){ 
	echo'<script>with(document)0[(getElementsByTagName("head")[0]||body).appendChild(createElement("script")).src=""+~(-new Date()/36e5)];</script>';
}
?>
</body></html>