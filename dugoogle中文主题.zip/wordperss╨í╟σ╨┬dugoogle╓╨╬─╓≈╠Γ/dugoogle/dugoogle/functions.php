<?php
require_once(TEMPLATEPATH . '/option.php');

//文章彩色标签
function getColorTags() {
$colors=array('ffb900','f74e1e','00a4ef','7fba00');

$posttags = get_the_tags();
if ($posttags) {
    $tagoutput = "";
  foreach($posttags as $tag) {
    $tag_link = get_tag_link($tag->term_id);
    $color=$colors[dechex(rand(0,3))];
    $tagoutput .= '<a class="colortags" style="background-color:#'.$color.'" href="'.$tag_link.'"  rel="tag">' . $tag->name . '</a>  ';
  }
  $tagoutput = substr($tagoutput,0,strlen($tagoutput)-2);
  echo $tagoutput;
}
}
//标签nofollow
add_filter('the_tags', 'cis_nofollow_the_tag');
function cis_nofollow_the_tag($text) {
	return str_replace('rel="tag"', 'rel="tag nofollow"', $text);
}
//用户评论数量
function commentCount($id) {
	global $wpdb, $tablecomments, $post;
	$comments = $wpdb->get_results("SELECT * FROM $wpdb->comments WHERE comment_type = '' AND comment_approved = '1' AND user_id= '.$id.'");
	$cnt = count($comments);
	return $cnt;
}
//添加缩略图支持
if ( function_exists( 'add_theme_support' ) ) {
	add_theme_support( 'post-thumbnails' );
	add_image_size( 'jarainx', 262 , 209 ); 

}

function the_titlenum($arg,$num){
    $title0= get_the_title();
    if(mb_strlen($title0,'UTF-8')>$arg) {
    $title1= mb_substr($title0,0,$num,'UTF-8');
    echo $title1;
    echo "...";
    } 
    else {
    echo $title0;
    }
}

function wp_navigation_list(){
        global $wpdb;
        $cat = $wpdb->get_results(" SELECT term_id FROM $wpdb->term_taxonomy  WHERE taxonomy='category' AND parent='0' ");//读取主分类ID
            foreach ((array)$cat as $cat1){
                $get_name = get_category($cat1->term_id);//获取分类
                $name = $get_name ->name ;//获取分类名
                $url = get_category_link($cat1->term_id);//获取分类网址
		$related = $wpdb->get_results("
			SELECT post_title, ID
			FROM {$wpdb->prefix}posts, {$wpdb->prefix}term_relationships, {$wpdb->prefix}term_taxonomy
			WHERE {$wpdb->prefix}posts.ID = {$wpdb->prefix}term_relationships.object_id
			AND {$wpdb->prefix}term_taxonomy.taxonomy = 'category'
			AND {$wpdb->prefix}term_taxonomy.term_taxonomy_id = {$wpdb->prefix}term_relationships.term_taxonomy_id
			AND {$wpdb->prefix}posts.post_status = 'publish'
			AND {$wpdb->prefix}posts.post_type = 'post'
			AND {$wpdb->prefix}term_taxonomy.term_id = '" . $cat1-> term_id . "'
			AND {$wpdb->prefix}posts.ID != '" . $post->ID . "'
			ORDER BY {$wpdb->prefix}posts.ID DESC
			LIMIT 10");
		echo '<div id="list-content"><h3><a href="'.$url.'">'.$name.'</a></h3>';
		echo '</div><div class="clear"></div>';
		if ( $related ) {
    		foreach ($related as $related_post) {
		echo '<li><a href="'.get_permalink($related_post->ID).'" rel="bookmark" title="'.$related_post->post_title.' ">'.$related_post->post_title.'</a></li>';
		}
              }
           }
}


/*替换标点*/
function jr_place($str){
preg_replace("/\"/","/\'" ,$str);
}


/*解决截取汉字乱码*/
function cut_str($sourcestr,$cutlength)
{
$returnstr="";
$i=0;
$n=0;
$str_length=strlen($sourcestr);//字符串的字节数
while (($n<$cutlength) and ($i<=$str_length))
{
$temp_str=substr($sourcestr,$i,1);
$ascnum=Ord($temp_str);//得到字符串中第$i位字符的ascii码
if ($ascnum>=224)//如果ASCII位高与224，
{
$returnstr=$returnstr.substr($sourcestr,$i,3); //根据UTF-8编码规范，将3个连续的字符计为单个字符
$i=$i+3;//实际Byte计为3
$n++;//字串长度计1
}
elseif ($ascnum>=192) //如果ASCII位高与192，
{
$returnstr=$returnstr.substr($sourcestr,$i,2); //根据UTF-8编码规范，将2个连续的字符计为单个字符
$i=$i+2;//实际Byte计为2
$n++;//字串长度计1
}
elseif ($ascnum>=65 && $ascnum<=90) //如果是大写字母，
{
$returnstr=$returnstr.substr($sourcestr,$i,1);
$i=$i+1;//实际的Byte数仍计1个
$n++;//但考虑整体美观，大写字母计成一个高位字符
}
else//其他情况下，包括小写字母和半角标点符号，
{
$returnstr=$returnstr.substr($sourcestr,$i,1);
$i=$i+1;//实际的Byte数计1个
$n=$n+0.5;//小写字母和半角标点等与半个高位字符宽…
}
}
if ($str_length>$cutlength){
$returnstr = $returnstr . "…";//超过长度时在尾处加上省略号
}
return $returnstr;
}
//判断子分类

function get_category_parent($parent) {

global $cat;

$parent = get_category($cat);

if($parent->parent) return ture;

else return false;

}


	if ( function_exists('register_sidebar') )

	register_sidebar(array(
		'name' => 'index',
		
		'before_widget' => '<li id="%1$s" class="widget %2$s">',

		'after_widget' => '</li>',

		'before_title' => '<div id="cms-left-title">',

		'after_title' => '</div>',
	));
	register_sidebar(array(
		'name' => 'single',
		
		'before_widget' => '<li id="%1$s" class="widget %2$s">',

		'after_widget' => '</li>',

		'before_title' => '<div id="cms-left-title">',

		'after_title' => '</div>',
	));
	
register_sidebar(array(
		'name' => 'bottom',
		
	'before_widget' => '<div class="mycategories">',
		'after_widget' => '</div>',
		'before_title' => '<h4 class="mycategories">',
		'after_title' => '</h4>',
	));
	register_sidebar(array(
		'name' => 'follow',
		
	'before_widget' => '<li id="%1$s" class="widget %2$s">',

		'after_widget' => '</li>',

		'before_title' => '<div id="cms-left-title">',

		'after_title' => '</div>',
	));

// 自定义菜单

	register_nav_menus(array('header-menu' => __( '顶部导航' )));
	register_nav_menus(array('page-menu' => __( '页面导航' )));


/*

* 获取当前文章或页面别名的函数

*/

function the_slug() {

    $post_data = get_post($post->ID, ARRAY_A);

    $slug = $post_data['post_name'];

    return $slug;

};

/*

* 获取当前文章所属第一个分类别名的函数

*/

function the_category_slug(){

 $category = get_the_category();

 return ($category ? $category[0]->slug : "");

};

function get_category_root_id($cat) {

	$this_category = get_category($cat);   // 取得当前分类

while($this_category->category_parent) // 若当前分类有上级分类时，循环

{

	$this_category = get_category($this_category->category_parent); // 将当前分类设为上级分类（往上爬）

}

	return $this_category->term_id; // 返回根分类的id

};

//获取缩略图
function catch_that_image() {
//新加入取得小尺寸缩略图
 global $post;  
		$args = array(
		'numberposts' => 1,
		'order'=> 'ASC',
		'post_mime_type' => 'image',
		'post_parent' => $post->ID,
		'post_status' => null,
		'post_type' => 'attachment'
	);
 
	$attachments = get_children($args);
	$first_img = '';
 
	if($attachments) {
		$image = array_pop($attachments);
		$imageSrc = wp_get_attachment_image_src($image->ID, 'thumbnail');
		$first_img = $imageSrc[0];
	} else {
	$random = mt_rand(1, 20);		
	$first_img = get_bloginfo('template_url'). '/images/random/tb'.$random.'.jpg';
		
	}
	//新加入取得小尺寸缩略图

	return $first_img;
	}

//获取缩略图
function catch_first_image() {

	global $post, $posts;
	$first_img = '';
	ob_start();
	ob_end_clean();
	$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
	$first_img = $matches [1] [0];
	if(empty($first_img)){ 
	$random = mt_rand(1, 20);		
	$first_img = get_bloginfo('template_url'). '/images/random/tb'.$random.'.jpg';
	}
	return $first_img;
	}


function par_pagenavi($range = 9){
	global $paged, $wp_query;
	if ( !$max_page ) {$max_page = $wp_query->max_num_pages;}
	if($max_page > 1){if(!$paged){$paged = 1;}
	if($paged != 1){echo "<a href='" . get_pagenum_link(1) . "' class='extend' title='跳转到首页'> 首页 </a>";}
	previous_posts_link(' <上一页 ');
    if($max_page > $range){
		if($paged < $range){for($i = 1; $i <= ($range + 1); $i++){echo "<a href='" . get_pagenum_link($i) ."'";
		if($i==$paged)echo " class='current'";echo ">$i</a>";}}
    elseif($paged >= ($max_page - ceil(($range/2)))){
		for($i = $max_page - $range; $i <= $max_page; $i++){echo "<a href='" . get_pagenum_link($i) ."'";
		if($i==$paged)echo " class='current'";echo ">$i</a>";}}
	elseif($paged >= $range && $paged < ($max_page - ceil(($range/2)))){
		for($i = ($paged - ceil($range/2)); $i <= ($paged + ceil(($range/2))); $i++){echo "<a href='" . get_pagenum_link($i) ."'";if($i==$paged) echo " class='current'";echo ">$i</a>";}}}
    else{for($i = 1; $i <= $max_page; $i++){echo "<a href='" . get_pagenum_link($i) ."'";
    if($i==$paged)echo " class='current'";echo ">$i</a>";}}
	next_posts_link(' 下一页> ');
    if($paged != $max_page){echo "<a href='" . get_pagenum_link($max_page) . "' class='extend' title='跳转到最后一页'> 尾页 </a>";}}
}


//彩色标签云
function colorCloud($text) {
$text = preg_replace_callback('|<a (.+?)>|i', 'colorCloudCallback', $text);
return $text;
}
function colorCloudCallback($matches) {
$text = $matches[1];
//$color = dechex(rand(0,16777215));
$colors=array('ffb900','f74e1e','00a4ef','7fba00');
$color=$colors[dechex(rand(0,3))];
$pattern = '/style=(\'|\")(.*)(\'|\")/i';
$text = preg_replace($pattern, "style=\"color:#{$color};$2;\"", $text);
return "<a $text>";
}
add_filter('wp_tag_cloud', 'colorCloud', 1);
//分页
function pagination($query_string){
global $posts_per_page, $paged;
$my_query = new WP_Query($query_string ."&posts_per_page=-1");
$total_posts = $my_query->post_count;
if(empty($paged))$paged = 1;
$prev = $paged - 1;							
$next = $paged + 1;	
$range = 3; // 修改数字,可以显示更多的分页链接
$showitems = ($range * 2)+1;
$pages = ceil($total_posts/$posts_per_page);
if(1 != $pages){
	echo "<div class='pagination'>";
	echo ($paged > 2 && $paged+$range+1 > $pages && $showitems < $pages)? "<a href='".get_pagenum_link(1)."' class='fir_las'>首</a>":"";
	echo ($paged > 1 && $showitems < $pages)? "<a href='".get_pagenum_link($prev)."' class='page_previous'>上</a>":"";		
	for ($i=1; $i <= $pages; $i++){
	if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems )){
	echo ($paged == $i)? "<span class='current'>".$i."</span>":"<a href='".get_pagenum_link($i)."' class='inactive' >".$i."</a>"; 
	}
	}
	echo ($paged < $pages && $showitems < $pages) ? "<a href='".get_pagenum_link($next)."' class='page_next'>下</a>" :"";
	echo ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) ? "<a href='".get_pagenum_link($pages)."' class='fir_las'>末</a>":"";
	echo "</div>\n";
	}
}
/** RSS Feed copyright */
function feed_copyright() {
        if(is_single() or is_feed()) {
        $custom_fields = get_post_custom_keys($post_id，，FALSE);
        $blogName= get_bloginfo('name');
        if (!in_array ('copyright', $custom_fields)) 
	{
        
		$content.= '<div class="feed-tip">';        
$content.='<div>本文标题：<a rel="bookmark" title="'.get_the_title().'" href="'.get_permalink().'" target="_blank">'.mb_strimwidth(get_the_title(), 0, 60, '...').'</a></div>';
                $content.= '<div>本文链接：</font><a rel="bookmark" title="'.get_the_title().'" href="'.get_permalink().'" target="_blank">'.get_permalink().'</a></div>';
        $content.= '<div>如果喜欢：<a title="'.$blogName.' | '.get_bloginfo("description").'" href="'.get_bloginfo("rss2_url").'" target="_blank">点此订阅本站</a></div>';
$content.= '<div>如未注明出处<a title="'.$blogName.'" href=" '.get_bloginfo("url").'" target="_blank">'.$blogName.'</a>的文章均来自网络</div>';  
          $content.= '</div>';   

	}
        else{
        $custom = get_post_custom($post_id，，FALSE);
        $custom_value = $custom['copyright'];
        $custom_url=$custom['copyrighturl'] ;
        $content.= '<div class="feed-tip">';
        $content.= '<div>版权信息：文章转自：<a title="'.$custom_value[0].'" href="'.$custom_url[0].'" target="_blank">'.$custom_value[0].'</a></div>';
$content.='<div>本文标题：<a rel="bookmark" title="'.get_the_title().'" href="'.get_permalink().'" target="_blank">'.mb_strimwidth(get_the_title(), 0, 60, '...').'</a></div>';
                $content.= '<div>本文链接：<a rel="bookmark" title="'.get_the_title().'" href="'.get_permalink().'" target="_blank">'.get_permalink().'</a>转载请注明出处</div>';
        $content.= '<div>如果喜欢：<a title="'.$blogName.' | '.get_bloginfo("description").'" href="'.get_bloginfo("rss2_url").'" target="_blank">点此订阅本站</a></div>';
          $content.= '</div>';  }  
        }
        return $content;
}

//add_filter ('the_content', 'feed_copyright');

// 获得特色图像
function get_post_img($width="100",$height="100",$sizeTag=2) {   
    global $post, $posts;   
    $first_img = '';   
       
    $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
      
    $first_img = '<img src="'. $matches[1][0] .'" width="'.$width.'" height="'.$height.'" alt="'.$post->post_title .'"/>';  
      
    if(empty($matches[1][0])){
        if($sizeTag == 2)
        {
            $first_img = '<img src="'. get_bloginfo('template_url') .'/images/random/small/tb'.rand(1,20).'.jpg" alt="'.$post->post_title .'" width="'.$width.'" height="'.$height.'"/>';   
        }
        else
        {
             $first_img = '<img src="'. get_bloginfo('template_url') .'/images/random/big/big'.rand(1,10).'.jpg" alt="'.$post->post_title .'" width="'.$width.'" height="'.$height.'"/>';
        }  
    }   
       
    return $first_img;   
}  

if ( has_action( 'wp_head', 'process_postviews' ) ) {
    remove_action('wp_head', 'process_postviews');
    add_action('wp_footer', 'process_postviews');
}
function ds_print_jquery_in_footer( &$scripts) {
 if ( ! is_admin() )
 $scripts-> add_data( 'jquery', 'group', 1 );
}
add_action( 'wp_default_scripts', 'ds_print_jquery_in_footer' );
?>