<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8" />
	<title><?php 
if (is_home()) {
bloginfo('description');
echo(" - ");
bloginfo('name') ;
}
else if (is_single()) {
wp_title('');
echo(" - ");
bloginfo('name');
}
else if (is_tag()){
wp_title('');
echo("图片 - ");
bloginfo('name');
}
else if (is_search()){
the_search_query();
echo(" - ");
bloginfo('name');
}							
else {wp_title(''); echo(" - ");bloginfo('name');} ?></title>
<?php 
$options = get_option('classic_options');
$dis = $options['description'];
$key = $options['keywords'];
if (is_home() || is_page() ){
    $description = $dis;
    $keywords = $key ;
}
elseif (is_category()) {
     $description =  strip_tags(category_description()); 
}
elseif (is_single()){
    if ($post->post_excerpt) {
        $description=$post->post_excerpt;
    } 
	else {
        $description=mb_substr(strip_tags($post->post_content),0,160);
    }
 
    $keywords ="";
    $tags = wp_get_post_tags($post->ID);
    foreach ($tags as $tag ) {
        $keywords = $keywords.$tag->name.",";
    }
}
?>
	<meta name="description" content="<?=$description?>" />
	<meta name="keywords" content="<?=$keywords?>" />
	<meta name="theme" content="www.dugoogle CMS" />
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
	<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/hellometro.js"></script>	
	<script type="text/javascript">window.onerror = function(){return true;}</script>
  <script type="text/javascript">
jQuery(document).ready(function($) {
$('.cat-item li').hover(function() {
$('ul', this).slideDown(300)
},
function() {
$('ul', this).slideUp(300)
})
$("#KinSlideshow").KinSlideshow();
});
</script>
	<?php wp_head(); ?>	
</head>
<body>
<div id="top-index">
<div id="top-logo" class="clearfix">
	<div id="logo" class="alignleft"><a href="<?php bloginfo('url');?>"></a></div>
	<div id="logo-right" class="alignright" >
		<?php $options = get_option('classic_options');echo($options['logoad']); ?>
	</div>
</div>
<div class="clear"></div>
<div class="navdiv width">
<div id="nav">
<div class="topnav">
<?php
if(function_exists('wp_nav_menu')) {
    wp_nav_menu(array('menu' => 'header-menu'));
}
?>
</div>
</div>
<div id="banv">
<div id="location" class="alignleft">
<?php if(is_single() || is_category()  || is_page()) : ?>
		当前位置：<a href="<?php bloginfo('url'); ?>">首页 </a>
		<?php 
			if(!is_page()){
			echo " » ";
			the_category(', ');
			} 
		?>
		<?php 
			if(is_single()){
				echo " » "; 
				echo "正文";
					} 
			if(is_page() ){
				echo " » "; 
				the_title();
					} 
			
		?>
	<?php else: ?>
		» <?php bloginfo('description'); ?> 
	<?php endif; ?>
	</div>
	<div id="hot-nav" class="alignright">
	<div id="rss">
			<form id="searchform" method="get" action="<?php bloginfo('home'); ?>">
				<input type="text" style="color:gray;" class="s-text" value="输入关键词" onFocus="if(this.value=='输入关键词'){this.value=''};this.style.color='black';" onBlur="if(this.value==''||this.value=='输入关键词'){this.value='输入关键词';this.style.color='gray';}"   name="s" id="s" size="15" />
				<input type="submit" class="s-submit" value="" />
		</form>
	  </div> 
		
	</div>
</div>
</div>
</div>
<div class="clear"></div>
<div id="center" >

<div id="page">

<?php if(is_home() ) { ?>
<div id="cms-main" class="clearfix">
<div id="cms-left">
<div id="focus" class="fi02">
<?php $options = get_option('classic_options');echo($options['cmsads1']); ?>
</div>
<div class="clear"></div>
</div>
<!--新加多彩卖盘-->
 <div id="metro">
 <div class="duocai">
<div id="cms-list">
		<div id="sticky-stk">
		<?php
		query_posts(array('orderby' => 'rand', 'post__in' => get_option('sticky_posts'), 'showposts' => 5));
		if (have_posts()) : while ( have_posts() ) : the_post();  ?>
		<div id="sticky-stk-post" class="clearfix">
			<div id="sticky-stk-img">
				<?php 
					$imgurl=catch_that_image();
		 		?>
				<a href="<?php the_permalink();?>"><img src="<? echo $imgurl; ?>" ></a>
			</div>
			<div id="sticky-stk-poc">
			<div id="sticky-stk-title">
				<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_titlenum('15','15'); ?></a>
			</div>
			<div id="sticky-stk-dscp">
				<?php 
					if ($post->post_excerpt) {
       						echo $post->post_excerpt;
   					 } 
					else{
						echo cut_str(strip_tags(apply_filters('the_content', $post->post_content)),30,"…");
					}
				?>
			</div>
			</div>
		</div>
		
		<?php endwhile;endif;wp_reset_query();?>
		</div>
		<div id="indexad" >
<?php $options = get_option('classic_options');echo($options['indexad']); ?>
</div>
            </div>
        </div>
<div class="clear"></div>
<!--新加多彩卖盘-->
 <?php } ?>