<?php get_header(); ?>
<div id="main">
<div class="category-des">
		<div class="category-title">
		所有属于“<?php printf( single_tag_title('', false) ); ?>”的文章
		</div>
		</div>
	<?php if (have_posts()) : $count=1; while (have_posts()) : the_post(); ?>
	<div class="article_b">
		<div class="post-title">
		<h2>
<a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a>
</h2>
</div>
	<div class="infotop">
<span class="info-category-icon"><?php the_category(', ') ?></span>
<span class="info-view-icon">超过<?php if(function_exists(the_views)) { the_views();}?></span>
<span class="info-comment-icon"><?php comments_popup_link ('0条评论','1条评论','%条评论'); ?></span>
</div>
			
	<div class="clear"></div>
<?php if(function_exists('wp_thumbnails_for_homepage')) { wp_thumbnails_for_homepage(); } ?>
		<div id="post" class="expert">
		<?php 
			if ($post->post_excerpt) {
       				echo $post->post_excerpt;
   			 } 
			else{
				echo cut_str(strip_tags(apply_filters('the_content', $post->post_content)),130,"…");
			}
		?>

		
		</div>
	<div class="clear"></div>
			
			<div class="conti">
				<span class="post-date"><?php getColorTags(); ?></span>	
				<span class="post-more"><a href="<?php the_permalink() ?>">阅读全文</a></span>
			</div>
<span class="date_s"><?php echo date('m',get_the_time('U'));?>-<?php the_time('d') ?></span>
	</div>
	
	<?php endwhile; else: ?>
	<div class="post">哦！您要找的日志可能已经更换地址，重新搜索一下吧，或者点击<a title="Home" class="active" href="<?php echo get_option('home'); ?>/">这里</a>回首页看看吧</div>
	<?php endif; ?>
		<div class="clear"></div>
	<div class="navigation"><?php pagination($query_string); ?></div>
</div>    
<?php get_sidebar(); ?>
<?php get_footer(); ?>