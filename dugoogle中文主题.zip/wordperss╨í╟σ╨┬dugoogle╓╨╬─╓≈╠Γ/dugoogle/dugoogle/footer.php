</div>
      <div class="clear"></div>
	   </div>
	   </div>
	  <?php if(is_home()) : ?>
	    	<div id="flinks" class="clearfix">
			<div id="cms-cat-title" class="clearfix">
			友情链接
			</div>
			<ul class="clearfix">
	     		<?php wp_list_bookmarks('title_li=&categorize=0&limit=24'); ?>
				</ul>
	   	</div>
	<?php endif; ?>
	<div id="footer">
	<div id="footer_side">
	<div class="mycategories">
<h4 class="mycategories">热点导航</h4>

			<?php if (has_nav_menu('page-menu')) : ?> 
			<?php wp_nav_menu( array('menu' => 'page-menu' )); else :?>
				<ul>
					<?php wp_list_pages('title_li=&&depth=1'); ?>
				</ul>
			<?php endif; ?>
	
</div>

		<?php if ( ! dynamic_sidebar( 'bottom' ) ) : ?>	
		<!-- #secondary .widget-area -->
<?php endif; ?>

</div>
<div class="clear"></div>
<div class="footer_bottom">

 <?php 
		$options = get_option('classic_options');
		$tongji = $options['tongji'];
		$c = $options['c'];
		echo $c.$tongji;//统计代码
	    ?>
	<?php wp_footer(); ?>
		</div>
	<div id="Copyright">
	<a href="<?php bloginfo('url');?>"><?php bloginfo('name'); ?></a> &copy; 2013 版权所有&nbsp;&nbsp;&nbsp;&nbsp;Powered by WordPress|Theme By <a href="http://www.dugoogle.com/">dugoogle</a>
	</div>
	
</div>

<script type="text/javascript">
(function() {
    var $backToTopTxt = "▲返回顶部", $backToTopEle = $('<div class="backToTop"></div>').appendTo($("body"))
        .text($backToTopTxt).attr("title", $backToTopTxt).click(function() {
            $("html, body").animate({ scrollTop: 0 }, 120);
    }), $backToTopFun = function() {
        var st = $(document).scrollTop(), winh = $(window).height();
        (st > 0)? $backToTopEle.show(): $backToTopEle.hide();
        //IE6下的定位
        if (!window.XMLHttpRequest) {
            $backToTopEle.css("top", st + winh - 166);
        }
    };
    $(window).bind("scroll", $backToTopFun);
    $(function() { $backToTopFun(); });
})();
</script>
 <script>
/* <![CDATA[ */
(new SidebarFollow()).init({
	element: jQuery('#sidebar-follow'),
	distanceToTop: 15	
});
/* ]]> */
</script>
</body>
</html>