<?php get_header(); ?>
<div id="main">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div <?php post_class() ?> id="post-<?php the_ID(); ?>">
<div class="time">
<h2><?php the_title(); ?></h2>
</div>
<div id="singleinfo">
<span class="info-user-icon"><?php the_time('Y-m-d') ?></span>
<span class="info-category-icon"><?php the_category(', ') ?></span>
<span class="info-view-icon">超过<?php if(function_exists(the_views)) { the_views();}?></span>
<span class="info-comment-icon"><?php comments_popup_link ('0条评论','1条评论','%条评论'); ?></span>
</div>
<div class="clear"></div>
 <div id="postnavi">
				<span class="prev">&laquo; 上一篇：<?php next_post_link('%link') ?></span>
				<span class="next">下一篇：<?php previous_post_link('%link') ?> &raquo;</span>
				</div>
<div class="clear"></div>
<div class="context" >
  <div class="ad postcad">
	<?php 
		$options = get_option('classic_options');
		echo($options['postcad']);
 	?>
  </div>
  <?php the_content(); ?>

<?php endwhile;endif; ?>

</div>
<div id="Favorite">
<A href="javascript:window.external.AddFavorite('<?php the_permalink() ?>','<?php the_title(); ?>')" >加入收藏</A>
<a href="<?php bloginfo('url');?>">返回首页</a>
</div>
  <div id="sns">  
<!-- Baidu Button BEGIN -->
<div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare">
<span class="bds_more">分享到：</span>
<a class="bds_tsina">新浪微博</a>
<a class="bds_qzone">QQ空间</a>
<a class="bds_tqq">腾讯微博</a>
<a class="bds_renren">人人网</a>
<a class="bds_t163">网易微博</a>
<a class="bds_tieba">百度贴吧</a>
<a class="shareCount"></a>
</div>
<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=474815" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000);
</script>
<!-- Baidu Button END -->
    </div>
<div>文章标签：<?php getColorTags(); ?></div>
  <div class="clear"></div>  
   <?php echo feed_copyright();?>
  <!--AD--><div class="clear"></div>
<div style="margin:10px auto;text-align:center;">
<div class="ad pingad">
	<?php 
		$options = get_option('classic_options');
		echo($options['pingad']);
 	?>
	</div>
</div>
<!--AD-->
  <div id="wumiiDisplayDiv"></div>
<!-- 相关文章代码开始 -->
<div id="relate">
<div id="tags_related">
<div id="t-relate">相关文章</div>
<ul >
<?php 
  $options = get_option('classic_options');
  $relate = $options['relate'];
  if ($relate !== "tag") :
?>
<?php
$cats = wp_get_post_categories($post->ID);
if ($cats) {
$args = array(
        'category__in' => array( $cats[0] ),
        'post__not_in' => array( $post->ID ),
        'showposts' => 6,
        'caller_get_posts' => 1
    );
query_posts($args);
if (have_posts()) : 
    while (have_posts()) : the_post(); update_post_caches($posts); ?>
<li><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></li>
<?php endwhile; else : ?>
<li>暂无相关文章</li>
<?php endif; wp_reset_query(); } ?>
<?php elseif ($relate == "tag") : ?>
<?php
$post_tags = wp_get_post_tags($post->ID);
if ($post_tags) {
foreach ($post_tags as $tag) 
{
    $tag_list[] .= $tag->term_id;
}
$post_tag = $tag_list[ mt_rand(0, count($tag_list) - 1) ];
$args = array(
        'tag__in' => array($post_tag),
        'category__not_in' => array(NULL),
        'post__not_in' => array($post->ID),
        'showposts' => 6,
        'caller_get_posts' => 1
    );
query_posts($args);
if (have_posts()) : 
    while (have_posts()) : the_post(); update_post_caches($posts); ?>
<li><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></li>
<?php endwhile; else : ?>
    <li>暂无相关文章</li>
<?php endif; wp_reset_query(); } ?>
<?php endif; ?>
<!-- 相关文章代码结束-->
</ul>
</div>
</div>

  <div id="pinglun">
    <?php comments_template(); ?>
  </div>
</div>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>