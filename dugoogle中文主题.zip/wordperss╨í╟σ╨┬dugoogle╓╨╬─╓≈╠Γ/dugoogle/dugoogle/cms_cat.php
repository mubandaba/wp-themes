<div id="main">
	<?php query_posts(array('post__not_in' => get_option('sticky_posts'), 'caller_get_posts' => 1, 'showposts' => 6, )); if (have_posts()) : while (have_posts()) : the_post(); ?>
	<div class="article_b">
		<div class="post-title">
		<h2>
<a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a>
</h2>
</div>
<div class="infotop">
<span class="info-category-icon"><?php the_category(', ') ?></span>
<span class="info-view-icon"><?php if(function_exists(the_views)) { the_views();}?></span>
<span class="info-comment-icon"><?php comments_popup_link ('0条评论','1条评论','%条评论'); ?></span>
</div>
	<div class="clear"></div>
	<?php if(function_exists('wp_thumbnails_for_homepage')) { wp_thumbnails_for_homepage(); } ?>

		<div id="post" class="expert">
		<?php 
			if ($post->post_excerpt) {
       				echo $post->post_excerpt;
   			 } 
			else{
				echo cut_str(strip_tags(apply_filters('the_content', $post->post_content)),130,"…");
			}
		?>
		</div>
	<div class="clear"></div>
		<div class="conti">
				<span class="post-date"><?php getColorTags(); ?></span>	
				<span class="post-more"><a href="<?php the_permalink() ?>">阅读全文</a></span>
			</div>

<span class="date_s"><?php echo date('m',get_the_time('U'));?>-<?php the_time('d') ?></span>
	</div>
	<?php endwhile;endif;wp_reset_query(); ?>
</div>   
	<div class="clear"></div>
<div id="cms_cat" class="clearfix">
	<div id="cms_cat_left" class="alignleft">
	<?php 
		$options = get_option('classic_options');
		$oat= $options['oat'];
		$cat = explode(",",$oat);
		foreach($cat as $cat) :
	?>
	<div class="clearfix" id="cms-cat-c">
	<div id="cms-cat-title" class="clearfix">
		<?php $catname = get_cat_name($cat);?>
		<a href="<?php echo get_category_link($cat); ?>" ><?php echo $catname; ?></a>
	</div>
	<div id="r-post-list"><!--左侧-->
	<?php
			$sticky = get_option( 'sticky_posts' );
			$args = array(
				'cat' => $cat,
				'showposts' =>5,
				'offset'=>6,
				);
			query_posts( $args );
			?>
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				<li>
				<span class="title-left">
				<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_titlenum('15','15'); ?></a>
				</span>
				<div class="clear"></div>
				<div class="stk-dscp">
				<?php 
					if ($post->post_excerpt) {
       						echo cut_str(strip_tags($post->post_excerpt),35,"...");
   					 } 
					else{
						echo cut_str(strip_tags(apply_filters('the_content', $post->post_content)),35,"...");
					}
				?>
			</div>
			</li>
			
			<?php endwhile; endif; wp_reset_query();?>
	</div>
	</div>
	<?php endforeach; ?>
	</div>
	<div id="cms_cat_right" class="alignright">
	<?php 
		$options = get_option('classic_options');
		$roat= $options['roat'];
		$cat = explode(",",$roat);
		foreach($cat as $cat) :
	?>
	<div id="l-post-list"><!-- -->
	<div id="cms-cat-title" class="clearfix">
		<?php $catname = get_cat_name($cat);?>
		<a href="<?php echo get_category_link($cat); ?>" ><?php echo $catname; ?></a>
	</div>
		<?php
		$args = array(
				'cat' => $cat,
				'showposts' => 4,
				'offset'=>6,
				);
		query_posts($args);
		if (have_posts()) : while ( have_posts() ) : the_post();  ?>
		<div id="stk-post" class="clearfix">
			<div id="stk-img">
				<?php if(function_exists('wp_thumbnails_for_homepage')) { wp_thumbnails_for_homepage('width=90&height=80'); } ?>
			</div>
			<div id="stk-poc">
			<div id="stk-title">
				<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_titlenum('15','15'); ?></a>
			</div>
			<div id="stk-dscp">
				<?php 
					if ($post->post_excerpt) {
       						echo cut_str(strip_tags($post->post_excerpt),40,"...");
   					 } 
					else{
						echo cut_str(strip_tags(apply_filters('the_content', $post->post_content)),40,"...");
					}
				?>
			</div>
			</div>
		</div>
		<?php endwhile;endif;wp_reset_query();?>
	</div>
	<?php endforeach; ?>
	</div>
</div>