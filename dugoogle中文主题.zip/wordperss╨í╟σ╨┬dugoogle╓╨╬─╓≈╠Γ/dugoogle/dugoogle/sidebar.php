<div id="v-right">

<?php if(is_home() ) : ?>
	<div id="hot-post">		
		<div id="cms-ads">
			<div class="ad cmsad2"><?php $options = get_option('classic_options');echo($options['cmsads2']); ?></div>
			<div class="ad cmsad3"><?php $options = get_option('classic_options');echo($options['cmsads3']); ?></div>
		</div>

		<div class="clear"></div>
<div id="btns">
				<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('index') ) : ?>
	<?php endif; ?>	
	</div>
		<div class="clear"></div>
<?php endif; ?>


<?php if(is_category()) : ?>	
			<?php

if(get_category_children(get_category_root_id(the_category_ID(false)))!= "" )
{
?>
<div class="widget_categories">
			<div id="cms-left-title">分类导航</div>
			<ul id="widget_categories_li">
		<?php		
echo wp_list_categories("child_of=".get_category_root_id(the_category_ID(false)). "&depth=0&hide_empty=0&title_li=&orderby=id&order=ASC");


?>
			</ul>
			</div>
	
	<?php }
endif; ?>	



<?php if(!is_home()) : ?>
				<div id="btns">
				<?php if(is_tag()) : ?>
			<div id="cms-left-title"><?php printf( single_tag_title('', false) ); ?></div>
			<div id="hao123" class="clearfix">
<script type="text/javascript">
/*度哥网tag*/
var cpro_id = "u1265261";
</script>
<script src="http://cpro.baidustatic.com/cpro/ui/c.js" type="text/javascript"></script>
			<?php
					$tag_description = tag_description();
					if ( ! empty( $tag_description ) )
						echo $tag_description;?>
			</div>
				
			<?php endif; ?>	
			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('single') ) : ?>
	<?php endif; ?>
			<div id="cms-left-title">微导航</div>
			<div id="hao123" class="clearfix">
			<ul id="recommend">
		<?php wp_tag_cloud('smallest=12&largest=14&number=5&format=flat&exclude=27'); ?>	
			</ul>
			</div>
			</div>

<?php endif; ?>


<?php 
		$options = get_option('classic_options');
		$iecho = $options['iecho'];
		if ($iecho == "yes" ) :
?>
	   <li>
		<?php echo $catecho; ?>
	 <h4>关于</h4>
	    <div id="about">
	    <?php 
		$options = get_option('classic_options');
		$about = $options['about'];
		if ($about == ""){
		echo "请在主题选项中设置介绍信息。";
		}
		else{
		echo '<span>'.$about.'</span>';
		}
	    ?>
	   </div>
	    </li> 
<?php endif; ?>	
		<div class="clear"></div>
<?php if(is_home()): ?>
<div id="btns">
	    <li>
<div id="cms-left-title">网友评论</div>
		<ul class="recentcomments" id="recentcomments">
<?php 
$limit_num = '5'; //这里定义显示的评论数量
$my_email = "'" . get_bloginfo ('admin_email') . "'"; //这里是自动检测博主的邮件，实现博主的评论不显示
$rc_comms = $wpdb->get_results("
 SELECT ID, post_title, comment_ID, comment_author, comment_author_email, comment_content
 FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts
 ON ($wpdb->comments.comment_post_ID = $wpdb->posts.ID)
 WHERE comment_approved = '1'
 AND comment_type = ''
 AND post_password = ''
 AND comment_author_email != $my_email
 ORDER BY comment_date_gmt
 DESC LIMIT $limit_num
 ");
$rc_comments = '';
foreach ($rc_comms as $rc_comm) { //get_avatar($rc_comm,$size='50')
$rc_comments .= "<li>". get_avatar($rc_comm,$size='35') ."<span class='zsnos_comment_author'>" . $rc_comm->comment_author . "</span><br/><a href='"
. get_permalink($rc_comm->ID) . "#comment-" . $rc_comm->comment_ID
//. htmlspecialchars(get_comment_link( $rc_comm->comment_ID, array('type' => 'comment'))) // 可取代上一行, 会显示评论分页ID, 但较耗资源
. "' title='on " . $rc_comm->post_title . "'>" . mb_substr(strip_tags($rc_comm->comment_content),0,15)
. "</a></li>\n";
}
$rc_comments = convert_smilies($rc_comments);
echo $rc_comments;
?>
</ul>
	    </li>
		</div>
<?php endif; ?>
			
		<div id="sidebar-follow">
		           <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('follow') ) : ?>
		<?php endif; ?>		
</div>
		
		

</div>