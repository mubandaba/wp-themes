<?php get_header(); ?>
<div id="main">
<?php include (TEMPLATEPATH . '/cms_cat.php'); ?>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>