<div id="btns">
			<div id="cms-left-title">微导航</div>
			<div id="hao123" class="clearfix">
			<ul id="recommend">
				<li>推荐：</li>
				<li><a href="http://www.douban.com/" target="_blank" rel="nofollow" >豆瓣</a></li>
				<li><a href="http://www.fanfou.com/" target="_blank" rel="nofollow" >饭否</a></li>
				<li><a href="http://www.qiushibaike.com/" target="_blank" rel="nofollow" >糗百</a></li>
				<li><a href="http://www.mtime.com/" target="_blank" rel="nofollow" >时光</a></li>
			</ul>
			<ul>
				<li>搜索：</li>
				<li><a href="http://www.baidu.com" target="_blank" rel="nofollow" >百度</a></li>
				<li><a href="http://www.google.com.hk" target="_blank" rel="nofollow" >Google</a></li>
				<li><a href="http://www.so.com" target="_blank" rel="nofollow" >360搜索</a></li>
				<li><a href="http://www.yahoo.com/" target="_blank" rel="nofollow" >雅虎</a></li>
			</ul>
			<ul>
				<li>社交：</li>
				<li><a href="http://www.weibo.com/" target="_blank" rel="nofollow" >新浪微博</a></li>
				<li><a href="http://t.qq.com/" target="_blank" rel="nofollow" >腾讯微博</a></li>
				<li><a href="http://www.renren.com" target="_blank" rel="nofollow" >人人网</a></li>
			</ul>
			<ul>
				<li>购物：</li>
				<li><a href="http://s.click.taobao.com/t_9?p=mm_12588768_0_0&l=http%3A%2F%2Fwww.tmall.com" target="_blank" rel="nofollow" >淘宝商城</a></li>
				<li><a href="http://www.360buy.com/" target="_blank" rel="nofollow" >京东</a></li>
				<li><a href="http://www.dangdang.com/" target="_blank" rel="nofollow" >当当网</a></li>
				<li><a href="http://www.suning.com"  target="_blank" rel="nofollow" >苏宁</a></li>
			</ul>
			<ul>
				<li>视频：</li>
				<li><a href="http://tv.sohu.com/drama/us/" target="_blank" rel="nofollow" >美剧</a></li>
				<li><a href="http://www.funshion.com/movie/" target="_blank" rel="nofollow" >电影</a></li>
				<li><a href="http://zy.youku.com/" target="_blank" rel="nofollow" >综艺</a></li>
				<li><a href="http://www.dugoogle.com/" target="_blank" >相声</a></li>
			</ul>
			<ul>
				<li>邮箱：</li>
				<li><a href="http://www.gmail.com/" target="_blank" rel="nofollow" >Gmail</a></li>
				<li><a href="http://www.126.com/" target="_blank" rel="nofollow" >126邮箱</a></li>
				<li><a href="http://mail.qq.com/" target="_blank" rel="nofollow" >QQ邮箱</a></li>
			</ul>
			<ul>
				<li>听歌：</li>
				<li><a href="http://douban.fm/" target="_blank" rel="nofollow" >豆瓣电台</a></li>
				<li><a href="http://www.songtaste.com/" target="_blank" rel="nofollow" >SongTaste</a></li>
				<li><a href="http://www.yinyuetai.com/" target="_blank" rel="nofollow" >音悦Tai</a></li>
				<?php wp_tag_cloud('smallest=12&largest=18&number=10&format=flat&exclude=27'); ?>
			</ul>
			</div>
		</div>