<?php get_header(); ?>
<div id="main">
<!-- This sets the $curauth variable -->
<?php
if(isset($_GET['author_name'])) :
$curauth = get_userdatabylogin($author_name);
else :
$curauth = get_userdata(intval($author));
endif;
?>
	<div id="res">"<?php echo $curauth->display_name; ?>"的文章</div>
	<?php if (have_posts()) : $count=1; while (have_posts()) : the_post(); ?>
	<div <?php post_class() ?> id="post-<?php the_ID(); ?>" <?php if(is_sticky()) :?>style="border-bottom:5px solid #950000;" class="sticky" <?php endif; ?>>
		<div class="post-title">
<a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></div>
	
			<div id="dscrp">
			<span id="icom">评论：</span><span><?php comments_popup_link('0 条', '1 条', '% 条'); ?></span>
		</div>
	<div class="clear"></div>

		<?php 
			$imgurl=catch_that_image();
			if(!empty($imgurl)):
		 ?>
		<a class="thumbs" href="<?php the_permalink();?>"><img src="<? echo $imgurl; ?>" ></a>
		<?php endif; ?>
		<div id="post" class="expert">
		<?php 
			if ($post->post_excerpt) {
       				echo $post->post_excerpt;
   			 } 
			else{
				echo cut_str(strip_tags(apply_filters('the_content', $post->post_content)),120,"…");
			}
		?>

		
		</div>
	<div class="clear"></div>
			
			<div class="conti">
				<span class="post-date">作者：<?php the_author(); ?> | <?php the_category(', '); ?>  |标签：<?php the_tags('','，',''); ?></span>	
				<span class="post-more"><a href="<?php the_permalink() ?>">阅读全文</a></span>
			</div>
	<div id="dateleft">
		<div id="d-month"><?php the_time('F') ?></div>
		<div id="d-day"><?php the_time('d') ?></div>
	</div>
	</div>
	<?php $count++;if($count == 3):?>
		<div class="ad postlistad">
		<?php 
			$options = get_option('classic_options');
			echo($options['postlistad']);
 		?>
		</div>
	<?php endif; ?>
	<?php endwhile; else: ?>
	<div class="post">哦！您要找的日志可能已经更换地址，重新搜索一下吧，或者点击<a title="Home" class="active" href="<?php echo get_option('home'); ?>/">这里</a>回首页看看吧</div>
	<?php endif; ?>
	<div class="navigation">
		<div class="wp-pagenavi">
			<?php par_pagenavi(); ?>
		</div>
	</div>
</div>    

<?php include (TEMPLATEPATH . '/user_side.php'); ?>
<?php get_footer(); ?>