<div id="v-right">
	<ul>
		<li>
			<ul id="user_detail">
				<span class="user_avatar"><?php $mail=$curauth->user_email; echo get_avatar($mail,'50'); ?></span>
				<li><span calss="left_txt">昵称：</span><span class="right_echo"><?php echo $curauth->display_name; ?></span></li>
				<li><span calss="left_txt">文章：</span><span class="right_echo"><?php echo count_user_posts($curauth->ID) ?>篇
</span></li>
				<li><span calss="left_txt">评论：</span><span class="right_echo"><?php echo commentCount($curauth->ID) ?>条
</span></li>
				<li><span calss="left_txt">网址：</span><span class="right_echo"><?php bloginfo('url');?>/author/<?php echo $curauth->user_login; ?></span></li>
				<li><span calss="left_txt">注册：</span><span class="right_echo"><?php echo $curauth-> user_registered; ?></span></li>

				<div class="user_about">简介：<?php echo $curauth->user_description; ?></div>

			</ul>
		</li>
		<!-- 用户信息 END -->
		<li>
			<div id="cms-left-title"><?php the_author_meta("display_name"); ?>的评论</div>
			<ul>
<?php
$id = $curauth->ID;
global $wpdb;
$sql = "SELECT DISTINCT ID, post_title, post_password, comment_ID, comment_post_ID, comment_author, comment_date_gmt, comment_approved,comment_author_email, comment_type,comment_author_url, SUBSTRING(comment_content,1,25) AS com_excerpt FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID = $wpdb->posts.ID) WHERE comment_approved = '1' AND comment_type = '' AND user_id= $id AND post_password = '' ORDER BY comment_date_gmt DESC LIMIT 10";
$comments = $wpdb->get_results($sql);
$output = $pre_HTML;
foreach ($comments as $comment) {
$output .= "\n<li><a href=\"" . get_permalink($comment->ID) . "#comment-" . $comment->comment_ID . "\" title=\"" . $comment->post_title . " 上的评论\"> ". strip_tags($comment->com_excerpt) ."</a></li>";
}
$output .= $post_HTML;
$output = convert_smilies($output);
echo $output;
?>
			</ul>
		</li>
	</ul>
</div>