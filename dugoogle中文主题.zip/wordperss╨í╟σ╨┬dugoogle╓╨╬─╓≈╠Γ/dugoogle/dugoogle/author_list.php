<?php
/*
Template Name: UserListPage
*/
?>
<?php get_header(); ?>
	<div id="main">
		<div id="s-page" class="clearfix">
		<?php
			$query="SELECT COUNT(comment_ID) AS cnt, comment_author, comment_author_url, comment_author_email FROM (SELECT * FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->posts.ID=$wpdb->comments.comment_post_ID) WHERE comment_date > date_sub( NOW(), INTERVAL 1 YEAR) AND user_id='0' AND comment_author_email != 'XXXX@163.com' AND comment_author_email != 'XXXX@gmail.com' AND post_password='' AND comment_approved='1' AND comment_type='') AS tempcmt GROUP BY comment_author_email ORDER BY cnt DESC LIMIT 180";
			$wall = $wpdb->get_results($query);
			foreach ($wall as $comment)
			{
				if( $comment->comment_author_url )
				$url = $comment->comment_author_url;
				else $url="#";
				$tmp = "<li><a rel='external nofollow' href='".$url."' target='_blank' title='".$comment->comment_author." (".$comment->cnt.")'>".get_avatar($comment->comment_author_email, 60)."</a></li>";
				$output .= $tmp;
			}
			$output = "<div id='reader'>".$output."</div>";
			echo $output ;
?>
	</div>
	</div>
<?php get_sidebar('right'); ?>
<?php get_footer(); ?>