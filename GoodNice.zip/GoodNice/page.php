<?php get_header(); ?>
	 <div class="reg_cent clearfix">
<div class="reg_l left"><?php get_sidebar(); ?></div>
<div class="reg_r right">
<?php include(TEMPLATEPATH . '/inc/mood.php');//引用心情说 ?>
<div class="main">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<h2 class="biaott"><span><?php the_title(); ?></span></h2>
<div class="content"><div class="infos">
<span class="time"><p><?php the_time('Y-m-d H:i') ?></p></span>
<span class="views"><?php post_views('', '阅览'); ?></span>
<span class="comments"><?php comments_popup_link ('0条评','1条评','%条评'); ?></span>
<span class="author"><?php the_author() ?></span>
<span class="edit"><?php edit_post_link('编辑', '', ''); ?></span>
</div></div>
<div class="context">
<?php the_content(); ?>
</div>
<?php endwhile;endif; ?>
</div>

<div class="block_pager">
<?php pagination($query_string); //分页 ?>
<div class="articles">
<?php comments_template(); ?>
</div>
</div>

</div>
</div>
<?php get_footer(); ?>