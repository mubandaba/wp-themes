<div class="sidebar">
<?php include(TEMPLATEPATH . '/inc/stat.php');//站内统计 ?>
<?php if ( dopt('sky_quicker_b' )!=='' ) { ?>
<h4 class="column_ph"><span>博主推荐</span></h4>
<div class="textwidget"><div id="sslider">
<div id="sslider-wrap">
<div id="sslider-main">
<?php echo stripslashes(get_option('sky_quicker')); ?>
</div></div>
<span id="sslider-prev">&lt;</span><span id="sslider-next">&gt;</span>
</div>
<script>
jQuery(function ($) {
var sslider=$("#sslider-wrap"), n=0, l=$("a",sslider).length;
function go() {if(n<0)n=l-1;if(n>l-1)n=0;sslider.stop().animate({"scrollLeft":n*250});};
$("#sslider-next").click(function(){go(n++);});
$("#sslider-prev").click(function(){go(n--);});
var timer = setInterval(function(){$("#sslider-next").trigger("click")},5e3);
sslider.hover(function(){clearInterval(timer)},function(){timer=setInterval(function(){$("#sslider-next").trigger("click")},5e3)})
});
</script></div>
<?php }?>

<?php // if ( is_home()||is_category()||is_single()||is_page() ) { ?>
<?php if( dopt('sky_adpost_01_b')!=='' ) echo '
<h4 class="column_ph"><span>广而告之</span></h4><div class="gads">'.dopt('sky_adpost_01').'</div>'; ?>
<?php // } ?>

<h4 class="column_ph"><span>最新评论</span></h4>
<div class="f_comment">
<ul>
<?php
global $wpdb;
$sql = "SELECT DISTINCT ID, post_title, post_password, comment_ID, comment_post_ID, comment_author, comment_date_gmt, comment_approved, comment_type,comment_author_url,comment_author_email, SUBSTRING(comment_content,1,14) AS com_excerpt FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID = $wpdb->posts.ID) WHERE comment_approved = '1' AND comment_type = '' AND post_password = '' AND user_id='0' ORDER BY comment_date_gmt DESC LIMIT 5";
$comments = $wpdb->get_results($sql);
$output = $pre_HTML;
foreach ($comments as $comment) {
$a= '' . get_option('sky_avatarurl') . '/avatar/'.md5(strtolower($comment->comment_author_email)).'?s=42&d=&r=G';
$output .= "\n<li><a href=\"" . get_permalink($comment->ID) ."#comment-" . $comment->comment_ID . "\"><div class='avatars'><img src='". $a ."'  alt=\"$comment->comment_author\" class='avatar'/></div></a>$comment->comment_author : <span><a href=\"" . get_permalink($comment->ID) ."#comment-" . $comment->comment_ID . "\">回复</a></span>
<br><span>" . strip_tags($comment->com_excerpt)."</span></li>";
}
$output .= $post_HTML;
$output = convert_smilies($output);
echo $output;
?>
</ul>
</div>

<?php if ( !is_home() ) { ?>
<?php if( dopt('sky_adpost_03_b')!=='' ) echo '
<h4 class="column_ph"><span>广而告之</span></h4><div class="gads">'.dopt('sky_adpost_03').'</div>'; ?>
<?php } ?>

<?php if ( is_single() ) { ?>
<?php if( dopt('sky_adpost_02_b')!=='' ) echo '
<h4 class="column_ph"><span>广而告之</span></h4><div class="gads">'.dopt('sky_adpost_02').'</div>'; ?>
<?php } ?>

<?php if ( is_home()&!is_paged() ) { ?>
<h4 class="column_ph"><span>友情链接</span></h4>
<script type="text/javascript">
function LinkScroll(obj){ 
$(obj).find("ul:first").animate({ marginTop:"-25px" },1000,function(){ 
$(this).css({marginTop:"0px"}).find("li:first").appendTo(this);
$(this).css({marginTop:"0px"}).find("li:first").appendTo(this);
$(this).css({marginTop:"0px"}).find("li:first").appendTo(this);}); } 
$(document).ready(function() {var myar = setInterval('LinkScroll("#v-links")', 3600)
$("#v-links").hover(function() { clearInterval(myar); }, 
function() { myar = setInterval('LinkScroll("#v-links")', 3600) });});
</script>
<div id="v-links_box">
<div id="v-links">
<ul class="v-links" style="margin-top: 0px; ">                                                         
<?php wp_list_bookmarks('orderby=link_id&categorize=0&category='.get_option('sky_links').'&title_li='); ?>
</ul>
</div></div>
<?php } ?>

</div>