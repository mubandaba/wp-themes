<?php 
/*
 	template name: 读者排行
*/
get_header();
?>
<?php get_header(); ?>
	 <div class="reg_cent clearfix">
<div class="reg_l left"><?php get_sidebar(); ?></div>
<div class="reg_r right">
<?php include(TEMPLATEPATH . '/inc/mood.php');//引用心情说 ?>
<div class="main">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<h2 class="biaott"><span><?php the_title(); ?></span></h2>
<div class="content"><div class="infos">
<span class="time"><p><?php the_time('Y-m-d H:i') ?></p></span>
<span class="views"><?php post_views('', '阅览'); ?></span>
<span class="comments"><?php comments_popup_link ('0条评','1条评','%条评'); ?></span>
<span class="author"><?php the_author() ?></span>
<span class="edit"><?php edit_post_link('编辑', '', ''); ?></span>
</div></div>
<?php
    $query="SELECT COUNT(comment_ID) AS cnt, comment_author, comment_author_url, comment_author_email FROM (SELECT * FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->posts.ID=$wpdb->comments.comment_post_ID) WHERE comment_date > date_sub( NOW(), INTERVAL 24 MONTH ) AND user_id='0' AND comment_author_email != '742206125@qq.com' AND post_password='' AND comment_approved='1' AND comment_type='') AS tempcmt GROUP BY comment_author_email ORDER BY cnt DESC LIMIT 77";//显示数量
    $wall = $wpdb->get_results($query);
    $maxNum = $wall[0]->cnt;
    foreach ($wall as $comment)
    {
        if( $comment->comment_author_url )
        $url = $comment->comment_author_url;
        else $url="#";
        /*$tmp = "<li><a title=\"$comment->comment_author - $comment->cnt ℃\" target=\"_blank\" rel=\"external nofollow\" href=\"".$comment->comment_author_url."\">
		<img src=http://www.gravatar.com/avatar/".md5(strtolower($comment->comment_author_email))."?s=42&d=&r=G></a></li>";*/
        $tmp = "<li><a title=\"$comment->comment_author - $comment->cnt ℃\" target=\"_blank\" rel=\"external nofollow\" href=\"".$comment->comment_author_url."\">
		<img src=" .get_option('sky_avatarurl'). "/avatar/".md5(strtolower($comment->comment_author_email))."?s=42&d=&r=G></a></li>";
        $output .= $tmp;
     }
    $output = "<div class=\"readerwall\">".$output."<div class=\"clear\" style=\"margin:0 0 200px\"></div></div>";
    echo $output ;
?>
<!-- end 读者墙 -->
</div>

<div class="block_pager">
<?php pagination($query_string); //分页 ?>
<div class="articles">
<?php comments_template(); ?>
</div>
</div>
	<?php endwhile; else: ?>
	<?php endif; ?>
</div>
</div>
<?php get_footer(); ?>