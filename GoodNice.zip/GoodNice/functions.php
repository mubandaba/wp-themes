<?php
/* 
Theme: GoodNice
Name: 天空团G系列主题
Site: http://www.gsky.org
*/
include('option/theme.php');

function dopt($e){
    return stripslashes(get_option($e));
}
    //定义菜单
    if (function_exists('register_nav_menus')){
        register_nav_menus( array(
            'nav' => __('站点导航'),
            'menu' => __('底部菜单')
        ) );
    }

//去除头部冗余代码
remove_action( 'wp_head',   'feed_links_extra', 3 ); // 额外的feed,例如category, tag页
remove_action( 'wp_head',   'wp_generator' ); //隐藏wordpress版本
//移除菜单冗余代码
add_filter('nav_menu_css_class', 'my_css_attributes_filter', 100, 1);
add_filter('nav_menu_item_id', 'my_css_attributes_filter', 100, 1);
add_filter('page_css_class', 'my_css_attributes_filter', 100, 1);
function my_css_attributes_filter($var) {
	return is_array($var) ? array_intersect($var, array('current-menu-item','current-post-ancestor','current-menu-ancestor','current-menu-parent')) : '';
}
//取消标点符号转义
remove_filter('the_content', 'wptexturize');
//取消登录错误提示
add_filter('login_errors', create_function('$a', "return null;"));
//添加特色缩略图支持
if ( function_exists('add_theme_support') )add_theme_support('post-thumbnails');
//隐藏版本更新提示 - 注！
//add_filter('pre_site_transient_update_core', create_function('$a', "return null;"));
//评论贴图
function embed_images($content) {
  $content = preg_replace('/\[img=?\]*(.*?)(\[\/img)?\]/e', '"<img src=\"$1\" alt=\"" . basename("$1") . "\" />"', $content);
  return $content;
}
add_filter('comment_text', 'embed_images');
//自定义登录页面样式
function custom_login_logo() { echo '<link rel="stylesheet" id="wp-admin-css" href="'.get_bloginfo('template_directory').'/admstyle.css" type="text/css" />';}
add_action('login_head', 'custom_login_logo');
//获取缩略图地址
if ( function_exists('add_theme_support') )
 add_theme_support('post-thumbnails');
 function catch_first_image() {
  global $post, $posts;
  $first_img = '';
  ob_start();
  ob_end_clean();
  $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
  $first_img = $matches [1] [0];
  if(empty($first_img)){
		$random = mt_rand(1, 10);
		echo get_bloginfo ( 'stylesheet_directory' );
		//echo '/images/sky_1.jpg';//指定一张图
		echo '/images/random/sky_'.$random.'.jpg';//10张随机图片(图片自备)
  }
  return $first_img;
 }

//分页
function pagination($query_string){
global $posts_per_page, $paged;
$my_query = new WP_Query($query_string ."&posts_per_page=-1");
$total_posts = $my_query->post_count;
if(empty($paged))$paged = 1;
$prev = $paged - 1;							
$next = $paged + 1;	
$range = 3; // 显示分页链接个数
$showitems = ($range * 2)+1;
$pages = ceil($total_posts/$posts_per_page);
if(1 != $pages){
	echo "<div class='pagination'>";
	echo ($paged > 2 && $paged+$range+100 > $pages && $showitems < $pages)? "<a href='".get_pagenum_link(1)."' class='fir_las'>«</a>":"";
	for ($i=1; $i <= $pages; $i++){
	if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems )){
	echo ($paged == $i)? "<span class='current'>".$i."</span>":"<a href='".get_pagenum_link($i)."' class='inactive' >".$i."</a>"; 
	}
	}
	echo ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) ? "<a href='".get_pagenum_link($pages)."' class='fir_las'>»</a>":"";
	echo "</div>\n";
	}
}

//修改评论表情默认路径
function theme_smilies_src ($img_src, $img, $siteurl){
return get_bloginfo('template_directory').'/images/smilies/'.$img;
}
add_filter('smilies_src','theme_smilies_src',1,10); 
//阻止站内文章互相Pingback 
function theme_noself_ping( &$links ) {
  $home = get_option( 'home' );
  foreach ( $links as $l => $link )
  if ( 0 === strpos( $link, $home ) )
  unset($links[$l]);   
}
add_action('pre_ping','theme_noself_ping');
//禁止自动保存修订版
/*function theme_disable_autosave() {
  wp_deregister_script('autosave');
}
add_action('wp_print_scripts','theme_disable_autosave' );
remove_action('pre_post_update','wp_save_post_revision' );*/
//垃圾评论拦截
class anti_spam {
  function anti_spam() {
if ( !current_user_can('level_0') ) {
  add_action('template_redirect', array($this, 'w_tb'), 1);
  add_action('init', array($this, 'gate'), 1);
  add_action('preprocess_comment', array($this, 'sink'), 1);
    }
  }
  function w_tb() {
    if ( is_singular() ) {
      ob_start(create_function('$input','return preg_replace("#textarea(.*?)name=([\"\'])comment([\"\'])(.+)/textarea>#",
      "textarea$1name=$2w$3$4/textarea><textarea name=\"comment\" cols=\"100%\" rows=\"4\" style=\"display:none\"></textarea>",$input);') );
    }
  }
  function gate() {
    if ( !empty($_POST['w']) && empty($_POST['comment']) ) {
      $_POST['comment'] = $_POST['w'];
    } else {
      $request = $_SERVER['REQUEST_URI'];
      $referer = isset($_SERVER['HTTP_REFERER'])         ? $_SERVER['HTTP_REFERER']         : '隐瞒';
      $IP      = isset($_SERVER["HTTP_X_FORWARDED_FOR"]) ? $_SERVER["HTTP_X_FORWARDED_FOR"] . ' (透过代理)' : $_SERVER["REMOTE_ADDR"];
      $way     = isset($_POST['w'])                      ? '手动操作'                       : '未经评论表格';
      $spamcom = isset($_POST['comment'])                ? $_POST['comment']                : null;
      $_POST['spam_confirmed'] = "请求: ". $request. "\n来路: ". $referer. "\nIP: ". $IP. "\n方式: ". $way. "\n內容: ". $spamcom. "\n -- 已备案 --";
    }
  }
  function sink( $comment ) {
    if ( !empty($_POST['spam_confirmed']) ) {
      if ( in_array( $comment['comment_type'], array('pingback', 'trackback') ) ) return $comment;
      //方法一: 直接挡掉, 將 die(); 前面两斜线刪除即可.
      die();
      //方法二: 标记为 spam, 留在资料库检查是否误判.
      //add_filter('pre_comment_approved', create_function('', 'return "spam";'));
      //$comment['comment_content'] = "[ 防火墙提示：此条评论疑似Spam! ]\n". $_POST['spam_confirmed'];
    }
    return $comment;
	  }
	}
	$anti_spam = new anti_spam();
//屏蔽纯英文留言
function scp_comment_post( $incoming_comment ) {
$pattern = '/[一-龥]/u';
if(!preg_match($pattern, $incoming_comment['comment_content'])) {
		exit('<head><meta charset="UTF-8" /></head><p><br><span style="color:#C00;">提交失败：</span>抱歉，程序检测到您可能为Spam，本次提交失败！<br><span style="color:#2AE">解决方案：</span>请输入中文（Chinese）再次尝试！</p><br>');
//die();//直接挡掉，无提示
}
return( $incoming_comment );
}
add_filter('preprocess_comment', 'scp_comment_post');
//提高搜索结果相关性
if(is_search()){ 
add_filter('posts_orderby_request', 'search_orderby_filter');
}
function search_orderby_filter($orderby = ''){
	global $wpdb;
	$keyword = $wpdb->prepare($_REQUEST['s']);
	return "((CASE WHEN {$wpdb->posts}.post_title LIKE '%{$keyword}%' THEN 2 ELSE 0 END) + (CASE WHEN {$wpdb->posts}.post_content LIKE '%{$keyword}%' THEN 1 ELSE 0 END)) DESC, 
{$wpdb->posts}.post_modified DESC, {$wpdb->posts}.ID ASC";
}
//默认编辑器增强
 function enable_more_buttons($buttons) {   
     $buttons[] = 'hr';   
     $buttons[] = 'del';   
     $buttons[] = 'sub';   
     $buttons[] = 'sup';    
     $buttons[] = 'fontselect';   
     $buttons[] = 'fontsizeselect';   
     $buttons[] = 'cleanup';      
     $buttons[] = 'styleselect';   
     $buttons[] = 'wp_page';   
     $buttons[] = 'anchor';   
     $buttons[] = 'backcolor';   
     return $buttons;   
     }   
add_filter("mce_buttons_3", "enable_more_buttons");  

//评论邮件通知
function comment_mail_notify($comment_id) {
$comment = get_comment($comment_id);
$parent_id = $comment->comment_parent ? $comment->comment_parent : '';
$spam_confirmed = $comment->comment_approved;
if (($parent_id != '') && ($spam_confirmed != 'spam')) {
$wp_email = 'no-reply@' . preg_replace('#^www\.#', '', strtolower($_SERVER['SERVER_NAME']));//发件人e-mail地址
$to = trim(get_comment($parent_id)->comment_author_email);
$subject = '你在 [' . get_the_title($comment->comment_post_ID) . '] 的评论有回复啦 by：' . get_option('blogname') . '';
$message = '
<div style="background-color:#fff; border:1px solid #2ae;border-top: 5px solid #2ae;
color:#111;font-size:12px; width:702px; margin:0 auto; margin-top:10px;
font-family:微软雅黑, Arial;">
<div style="background: #eee; width:100%; height:60px; color: #2ae;">
<span style="height:60px; line-height:60px; margin-left:30px; font-size:12px;">
你在<a style="text-decoration:none; color:#c00;font-weight:700;"
href="' . get_option('home') . '">' . get_option('blogname') . '
</a>博客上的评论有新回复啦！</span></div>
<div style="width:90%; margin:0 auto">
<p>你之前在 [' . get_option("blogname") . '] 博客的
《' . get_the_title($comment->comment_post_ID) . '》文章中发表评论:
<p style="background-color: #EEE;border-left: 5px solid #2ae;
padding: 20px;margin: 15px 0;">' . nl2br(get_comment($parent_id)->comment_content) . '</p>
<p>' . trim($comment->comment_author) . ' 给你的回复是:
<p style="background-color: #EEE;border-right: 5px solid #2ae;padding: 20px;
margin: 15px 0;">' . nl2br($comment->comment_content) . '</p>
<p><a style="text-decoration:none; color:#2ae"
href="' . htmlspecialchars(get_comment_link($parent_id)) . '">回复并查看评论</a> | 
访问 <a style="text-decoration:none; color:#2ae"
href="' . get_option('home') . '">' . get_option('blogname') . '</a></p>
<p align=right>——本邮件由系统自动发出, 请勿直接回复 :)</p>
</div>
</div>';
$from = "From: \"" . get_option('blogname') . "\" <$wp_email>";
$headers = "$from\nContent-Type: text/html; charset=" . get_option('blog_charset') . "\n";
wp_mail( $to, $subject, $message, $headers );
//echo 'mail to ', $to, '<br/> ' , $subject, $message; // for testing
}
}
add_action('comment_post', 'comment_mail_notify');

//文章阅读次数统计与调用
function record_visitors(){
if (is_singular()){
global $post;
$post_ID = $post->ID;
if($post_ID){
$post_views = (int)get_post_meta($post_ID, 'views', true);
if(!update_post_meta($post_ID, 'views', ($post_views+1))){
add_post_meta($post_ID, 'views', 1, true);
}}}}
add_action('wp_head', 'record_visitors');
function post_views($before = '(', $after = ')', $echo = 1)
{
global $post;
$post_ID = $post->ID;
$views = (int)get_post_meta($post_ID,'views', true);
if ($echo) echo $before, number_format($views), $after;
else return $views;
}

//自定义头像
add_filter( 'avatar_defaults', 'fb_addgravatar' );
function fb_addgravatar( $avatar_defaults ) {
$myavatar = get_bloginfo('template_directory') . '/images/gravatar.jpg';
  $avatar_defaults[$myavatar] = '自定义头像';
  return $avatar_defaults;
}
//楼层/回复/头像缓存
function gsky_comment($comment, $args, $depth) {
   $GLOBALS['comment'] = $comment;
global $commentcount,$wpdb, $post;
     if(!$commentcount) { //初始化楼层计数器
          $comments = $wpdb->get_results("SELECT * FROM $wpdb->comments WHERE comment_post_ID = $post->ID AND comment_type = '' AND comment_approved = '1' AND !comment_parent");
          $cnt = count($comments);//获取主评论总数量
          $page = get_query_var('cpage');//获取当前评论列表页码
          $cpp=get_option('comments_per_page');//获取每页评论显示数量
         if (ceil($cnt / $cpp) == 1 || ($page > 1 && $page  == ceil($cnt / $cpp))) {
             $commentcount = $cnt + 1;//如果评论只有1页或者是最后一页，初始值为主评论总数
         } else {
             $commentcount = $cpp * $page + 1;
         }
     }
?>
<li <?php comment_class(); ?> id="comment-<?php comment_ID() ?>">
   <div id="div-comment-<?php comment_ID() ?>" class="comment-body">
      <?php $add_below = 'div-comment'; ?>
		<div class="comment-author vcard">
			<?php $f = md5(strtolower($comment->comment_author_email)); ?>
			<?php $avas = get_option('sky_avatarurl'); ?>
			<div class="avatars"><img src='<?php echo $avas ?>/avatar/<?php echo $f ?>?s=42&d=&r=G' alt='' class='avatar' /></div>
                <?php { echo ''; } ?>
					<div class="floor">
					<span style="color:yellowgreen;"><?php
 if(!$parent_id = $comment->comment_parent){
   switch ($commentcount){
     default:printf('#%1$s　', --$commentcount);
   }
 }
 ?></span>
<?php get_author_class($comment->comment_author_email,$comment->user_id)?>　
 <span class="datetime"><?php comment_date('Y-m-d H:i') ?><?php edit_comment_link('[编辑]','&nbsp;','&nbsp;'); ?></span>
<span class="reply"><?php comment_reply_link(array_merge( $args, array('reply_text' => '回复TA', 'add_below' =>$add_below, 'depth' => $depth, 'max_depth' => $args['max_depth']))); ?></span>
</div><span><strong><?php comment_author_link() ?></strong></span><?php comment_links_title($comment->comment_author_email); ?><?php if(user_can($comment->user_id, 1)){echo "<a title='官方人员' class='vip'></a>";}; ?>:</div>
		<?php if ( $comment->comment_approved == '0' ) : ?>
			<span style="color:#C00; font-style:inherit">你提交的内容可能包含敏感词，已加入审核列队...</span>
			<br />			
		<?php endif; ?>
		<?php comment_text() ?>
        
		<div class="clear"></div>
		
  </div>
<?php
}
function gsky_end_comment() {
		echo '</li>';
}

//评论者链接的网址重定向跳转
add_filter('get_comment_author_link', 'add_redirect_comment_link', 5);
add_filter('comment_text', 'add_redirect_comment_link', 99);
function add_redirect_comment_link($text = ''){
$text=str_replace('href="', 'target="_blank" href="'.get_option('home').'/go.php?url=', $text);
$text=str_replace("href='", "target='_blank' href='".get_option('home')."/go.php?url=", $text);
return $text;
}
add_action('init', 'redirect_comment_link');
function redirect_comment_link(){
$redirect = $_GET['url'];
$host = $_SERVER['HTTP_HOST'];
if($redirect){
if(strpos($_SERVER['HTTP_REFERER'],get_option('home')) !== false){
header("Location: $redirect#from:$host");
exit;
}
else {
header("Location: $redirect#from:$host");
exit;} } }

//HTTP响应拆分漏洞   
$redirect = trim(str_replace("\r","",str_replace("\r\n","",strip_tags(str_replace("'","",str_replace("\n", "", str_replace(" ","",str_replace("\t","",trim($redirect))))),""))));

//获取当前网页的完整URL
function curPageURL(){
    $pageURL = 'http';
    if ($_SERVER["HTTPS"] == "on"){$pageURL .= "s";}
    $pageURL .= "://";
    if ($_SERVER["SERVER_PORT"] != "80"){$pageURL .= $_SERVER["SERVER_NAME"] . ":" . $_SERVER["SERVER_PORT"] . $_SERVER["REQUEST_URI"];}
    else{$pageURL .= $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"];}
    return $pageURL;}

//文章关键字自动描文本内链
//连接数量
$match_num_from = 1;  //一篇文章中同一个关键字少于多少不描文本（这个直接填1就好了）
$match_num_to = 2; //一篇文章中同一个关键字最多出现多少次描文本（建议不超过2次）
//连接到WordPress的模块
add_filter('the_content','tag_link',1);
//按长度排序
function tag_sort($a, $b){
	if ( $a->name == $b->name ) return 0;
	return ( strlen($a->name) > strlen($b->name) ) ? -1 : 1;
}
//改变标签关键字
function tag_link($content){
global $match_num_from,$match_num_to;
	 $posttags = get_the_tags();
	 if ($posttags) {
		 usort($posttags, "tag_sort");
		 foreach($posttags as $tag) {
			 $link = get_tag_link($tag->term_id);
			 $keyword = $tag->name;
			 //连接代码
			 $cleankeyword = stripslashes($keyword);
			 $url = "<a href=\"$link\" title=\"".str_replace('%s',addcslashes($cleankeyword, '$'),__('View all posts in %s'))."\"";
			 $url .= ' target="_blank" class="tags"';
			 $url .= ">".addcslashes($cleankeyword, '$')."</a>";
			 $limit = rand($match_num_from,$match_num_to);

			//不连接的 代码
             $content = preg_replace( '|(<a[^>]+>)(.*)('.$ex_word.')(.*)(</a[^>]*>)|U'.$case, '$1$2%&&&&&%$4$5', $content);
			 $content = preg_replace( '|(<img)(.*?)('.$ex_word.')(.*?)(>)|U'.$case, '$1$2%&&&&&%$4$5', $content);

				$cleankeyword = preg_quote($cleankeyword,'\'');

					$regEx = '\'(?!((<.*?)|(<a.*?)))('. $cleankeyword . ')(?!(([^<>]*?)>)|([^>]*?</a>))\'s' . $case;

				$content = preg_replace($regEx,$url,$content,$limit);

	$content = str_replace( '%&&&&&%', stripslashes($ex_word), $content);

		 }
	 }
    return $content;
}
//breadcrumb面包屑导航
function the_breadcrumb() {
	if (!is_home()) {
		echo '<a href="';
		echo get_option('home');
		echo '">';
		echo '首页';
		echo "</a> &gt; ";
		if (is_category() || is_single()) {
			the_category(' & ');
			if (is_single()) {
				echo " &gt; ";
				the_title();
			}
		} elseif (is_page()) {
			echo the_title();
		}
	}
}
//获取访客VIP样式
function get_author_class($comment_author_email,$user_id){
global $wpdb;
$author_count = count($wpdb->get_results(
"SELECT comment_ID as author_count FROM $wpdb->comments WHERE comment_author_email = '$comment_author_email' "));
/*如果不需要管理员显示VIP标签，就把下面一行的“//”去掉*/
//$adminEmail = get_option('admin_email');if($comment_author_email ==$adminEmail) return;
if($author_count>=5 && $author_count<10)
echo '<a class="vip1" title="LV.1"></a>';
else if($author_count>=10 && $author_count<50) 
echo '<a class="vip2" title="LV.2"></a>';
else if($author_count>=50 && $author_count<200)
echo '<a class="vip3" title="LV.3"></a>'; 
else if($author_count>=200 && $author_count<400) 
echo '<a class="vip4" title="LV.4"></a>'; 
else if($author_count>=400 &&$author_count<650) 
echo '<a class="vip5" title="LV.5 闪亮登场"></a>'; 
else if($author_count>=650 && $author_count<1000) 
echo '<a class="vip6" title="LV.6 管理员一样的存在"></a>'; 
else if($author_count>=1000) 
echo '<a class="vip7" title="神一样的人物 V1000+"></a>'; 
}
//认证用户
function comment_links_title($email = ''){
$links=array(
'1'=>'bingoblog@163.com',
'2'=>'f.oy@qq.com',
'3'=>'bigfa@pku.edu.cn',
'4'=>'9385966@qq.com',
'5'=>'wzlps@vip.qq.com',
); //添加你想要设置个性图片的评论者Email，格式参考我写的
if(in_array($email,$links))
echo '<a class="vp" title="认证用户"></a>';
}

//总浏览量
function bigfa_all_view(){
    global $wpdb;
    $count=0;
    $views= $wpdb->get_results("SELECT * FROM $wpdb->postmeta WHERE meta_key='views'"); 
    foreach($views as $key=>$value)
    {
        $meta_value=$value->meta_value;
        if($meta_value!='')
        {
            $count+=(int)$meta_value;
        }
    }
    return $count;
}

///设置结束。

?>