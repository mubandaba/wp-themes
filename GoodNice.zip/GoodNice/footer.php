<div class="link-back2top"><a href="#">Go,TOP!</a></div>
<script type="text/javascript">$(".link-back2top").hide();
$(window).scroll(function() {if ($(this).scrollTop() > 100) {
$(".link-back2top").fadeIn();} else {
$(".link-back2top").fadeOut();}});
$(".link-back2top a").click(function() {
$("body,html").animate({scrollTop: 0},800);return false;});</script>
<div id="footer">
<?php if(function_exists('wp_nav_menu')) { wp_nav_menu(array( 'theme_location' => 'menu','container_class'=>'footermenu') ); } ?>
<div class="search-form">
<form method="get" action="<?php bloginfo('siteurl'); ?>">
<input type="text" value="" name="s" id="s" placeholder="搜索一下" class="txt-field" x-webkit-speech/>
<input class="search-submit" type="submit" value="搜索">
</form>
</div>
<br>
<div class="block">
<div class="block_copyrights"><p>Copyright 2012-2013 <a href="<?php bloginfo('siteurl'); ?>"><?php bloginfo('name'); ?></a>
<?php if( dopt('sky_icps_b')!=='' ) echo ' | '.dopt('sky_icps').''; ?></p></div>
<div class="block_theme">
<p><?php if( dopt('sky_tongji_b')!=='' ) echo ''.dopt('sky_tongji').' | '; ?>Theme 
<a href="http://www.gsky.org/" title="Designer Tokin" target="_blank">Good!Nice</a></p>
</div>
<br>
<div class="block_copyrights"><p>特别鸣谢：<a href="http://www.gsky.org/go.php?url=http://portal.qiniu.com/signup?code=3llwj2oxba79s" target="_blank" title="本站图片托管于 七牛云存储">七牛云存储</a> \ <a href="http://www.gsky.org/go.php?url=http://www.fyvps.com/aff.php?aff=009" target="_blank" title="源自枫叶主机急速驱动">枫叶主机</a></p></div>

<div class="block_theme">
<p>总访问量：<?php echo bigfa_all_view(); ?>次</p>
</div>

</div>
</div>
</div>
</body>
</html>