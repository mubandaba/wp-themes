<?php get_header(); ?>
<div class="reg_cent">
<div class="reg_l left"><?php get_sidebar(); ?></div>
<div class="reg_r right">
<?php include(TEMPLATEPATH . '/inc/mood.php');//引用心情说 ?>
<div class="main">
<?php if ( is_paged() ) { ?>
<script src="<?php bloginfo('template_directory'); ?>/js/func.js"></script>
<?php }?>
<?php $count = 1; ?>
<?php if (have_posts()) : ?>
	<?php while (have_posts()) : the_post(); ?>
<div class="contenting">

<div class="content">
<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" class="general_pic_hover scale initialized">
<div class="pics"><img src="<?php if ( dopt('sky_ximage_b' )!=='' ) { ?><?php bloginfo('template_directory'); ?>/timthumb.php?w=140&h=100&src=<?php } ?><?php echo catch_first_image() ?><?php if( dopt('sky_apiximg_2_b')!=='' ) echo dopt('sky_apiximg_2'); ?>" alt=""></div></a>
<h2 class="title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
<p class="texts"><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 180,"..."); ?></p>
<div class="infos">
<span class="time"><p><?php the_time('Y-m-d H:i') ?></p></span>
<span class="views"><?php post_views('', '阅'); ?></span>
<span class="comments"><?php comments_popup_link ('0评','1评','%评'); ?></span>
<span class="category"><?php the_category(', ') ?></span>
<span class="author"><?php the_author() ?></span>
</div>
</div>
</div>
		<?php endwhile; ?>
		<?php endif; ?>
		<div style="margin:40px 0px;border:1px dotted #ccc;"><?php pagination($query_string); //分页 ?></div>
</div>
		</div>
	    
	</div>
<?php get_footer(); ?>