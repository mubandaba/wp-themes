<script type="text/javascript">
function AutoScroll(obj){ 
$(obj).find("ul:first").animate({ marginTop:"-25px" },500,function(){ 
$(this).css({marginTop:"0px"}).find("li:first").appendTo(this); }); } 
$(document).ready(function() {var myar = setInterval('AutoScroll("#announcement")', 3600)
$("#announcement").hover(function() { clearInterval(myar); }, 
function() { myar = setInterval('AutoScroll("#announcement")', 3600) });});
</script>
<div id="announcement_box">
<div id="announcement">
<ul style="margin-top: 0px; ">
<?php if ( is_single() ) { ?>
<li>当前位置：<?php the_breadcrumb(); ?></li>
<?php } ?>
<?php ////参数设定
$page_ID=stripslashes(get_option('sky_likesay')); //用来作为心情的页面或者文章id
$num=5; //显示心情的条数 ?>
<?php
$announcement = '';
$comments = get_comments("number=$num&post_id=$page_ID");
if ( !empty($comments) ) {
foreach ($comments as $comment) {
$announcement .= '<li>'. convert_smilies($comment->comment_content) . '</li>'; } }
if ( empty($announcement) ) $announcement = '这是第一条心情，你可以登录Wordpress后，打开本页面，书写心情～';
echo $announcement;
?>
<li>无聊了：[ <a href="/random" title="随机为您推荐一篇精彩日志">探索发现</a> ] 一下，精彩文章等着你哦！</li>
</ul>
</div>
</div>