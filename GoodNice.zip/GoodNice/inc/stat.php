<div class="sc_profile_w">
<div class="m_profile m_profile_h clear" id="UIn">
<div class="lc avatar"><img src="http://www.gsky.org/wp-content/themes/GoodNice/images/100.jpg">
<div class="o_000_6 tx_edit_lk"><?php echo get_option('sky_myname'); ?></div>
</div>
<div class="rc">
<ul class="list clear  ">
<?php if ( is_single() ){ ?>
<li class="list_item item_prose stat"><span class="text_count" id="talkNum"><?php post_views('', ''); ?></span><span class="text_atr">阅读</span></li>
<li class="list_item item_prose stat"><span class="text_count" id="talkNum"><?php comments_popup_link('0','1','%') ?></span><span class="text_atr">评论</span></li>
<li class="list_item item_prose stat"><span class="text_count" id="talkNum"><?php the_time('H:i') ?></span><span class="text_atr"><?php the_time('Y-m-d') ?></span></li>
<li class="list_item item_prose stat"><span class="text_count" id="talkNum"><?php echo get_num_queries(); ?></span><span class="text_atr"><?php timer_stop(1); ?></span></li>
<?php }?>
<?php if ( !is_single() ){ ?>
<li class="list_item item_prose stat"><span class="text_count" id="talkNum"><?php $count_posts = wp_count_posts(); echo $published_posts = $count_posts->publish;?></span><span class="text_atr">篇文章</span></li>
<li class="list_item item_prose stat"><span class="text_count" id="talkNum"><?php echo $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->comments");?></span><span class="text_atr">条评论</span></li>
<li class="list_item item_prose stat"><span class="text_count" id="talkNum"><?php echo floor((time()-strtotime(get_option('sky_webed')))/86400); ?></span><span class="text_atr">天耕耘</span></li>
<li class="list_item item_prose stat"><span class="text_count" id="talkNum"><?php echo get_num_queries(); ?></span><span class="text_atr"><?php timer_stop(1); ?></span></li>
<?php }?>
</ul>
</div>
</div>

<div class="sc_setting" id="moduleSet">
<span class="SC_bor left"><b class="SC"></b></span>
<span class="SC_bor right"><b class="SC"></b></span>
<div class="sc_setting_link" style="margin-top:5px;">
<?php if ( !$user_ID ) { ?>
<li><a href="/go.php?url=<?php echo get_option('sky_tqq'); ?>" target="_blank">腾讯微博</a></li>
<li><a href="/go.php?url=<?php echo get_option('sky_weibo'); ?>" target="_blank">新浪微博</a></li>
<li><a href="/go.php?url=<?php echo get_option('sky_mony'); ?>" target="_blank">捐助</a></li>
<li><?php wp_loginout( $_SERVER["REQUEST_URI"]); ?></li>
<?php } else { ?>
<li><?php echo '<a href="'. get_page_link(stripslashes(get_option('sky_likesay'))). '#respond">心情</a>'; ?></li>
<li><a href="<?php bloginfo('siteurl'); ?>/wp-admin/post-new.php" target="_blank">撰写</a></li>
<li><a href="<?php bloginfo('siteurl'); ?>/wp-admin/themes.php" target="_blank">主题</a></li>
<li><a href="<?php bloginfo('siteurl'); ?>/wp-admin/" target="_blank">管理</a></li>
<li><?php wp_loginout( $_SERVER["REQUEST_URI"]); ?></li>
<?php } ?>

</div>
</div>
</div>