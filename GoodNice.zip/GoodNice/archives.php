<?php 
/*
 	template name: 文章归档
*/
get_header();
?>
<?php get_header(); ?>
	 <div class="reg_cent clearfix">
<div class="reg_l left"><?php get_sidebar(); ?></div>
<div class="reg_r right">
<?php include(TEMPLATEPATH . '/inc/mood.php');//引用心情说 ?>
<div class="main">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<h2 class="biaott"><span><?php the_title(); ?></span></h2>
<div class="content"><div class="infos">
<span class="i" style="margin-bottom:5px;"><p>下面是按照月份分类的站内全部文章列表</p></span>
</div></div>
<div class="context">
<div class="archives">
		<?php
$previous_year = $year = 0;
$previous_month = $month = 0;
$ul_open = false;
$myposts = get_posts('numberposts=-1&orderby=post_date&order=DESC');
foreach($myposts as $post) :
setup_postdata($post);
$year = mysql2date('Y', $post->post_date);
$month = mysql2date('n', $post->post_date);
$day = mysql2date('j', $post->post_date);
if($year != $previous_year || $month != $previous_month) :
if($ul_open == true) : 
echo '</table>';
endif;
echo '<h3>'; echo the_time('F Y'); echo '</h3>';
echo '<table>';
$ul_open = true;
endif;
$previous_year = $year; $previous_month = $month;
?>
<tr>
<td width="40" style="text-align:right;"><?php the_time('j'); ?>日</td>
<td width="700"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></td>
<td width="110"><a class="comm" href="<?php comments_link(); ?>" title="查看 <?php the_title(); ?> 的评论"><?php comments_number('0', '1', '%'); ?>人评论</a></td>
<td width="110"><span class="view"><?php post_views('', ''); ?>次浏览</span></td>
</tr>
<?php endforeach; ?>
</table>
</div>
</div>
<?php endwhile;endif; ?>
</div>



</div>
	</div>
<?php get_footer(); ?>