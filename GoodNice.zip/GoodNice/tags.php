<?php 
/*
 	template name: 标签云集
*/
get_header();
?>
<?php get_header(); ?>
	 <div class="reg_cent clearfix">
<div class="reg_l left"><?php get_sidebar(); ?></div>
<div class="reg_r right">
<?php include(TEMPLATEPATH . '/inc/mood.php');//引用心情说 ?>
<div class="main">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<h2 class="biaott"><span><?php the_title(); ?></span></h2>
<div class="content"><div class="infos">
<span class="i" style="margin-bottom:5px;"><p>下面是本站全部的标签，已经整理完毕！</p></span>
</div></div>
	<ul class="tag-clouds">
		<?php $tags_list = get_tags('orderby=count&order=DESC');
		if ($tags_list) { 
			foreach($tags_list as $tag) {
				echo '<li><a class="tag-link" href="'.get_tag_link($tag).'">'. $tag->name .'</a><strong>'. $tag->count .'+</strong><p class="tag-posts">'; 
				$posts = get_posts( "tag_id=". $tag->term_id ."&numberposts=1" );
				if( $posts ){
					foreach( $posts as $post ) {
						setup_postdata( $post );
						echo '<a href="'.get_permalink().'">'.get_the_title().'</a><span style="float: right;">'.get_the_time('Y-m-d').'</span></p>';
					}
				}
				echo '</li>';
			} 
		} 
		?>
	</ul>
<?php endwhile;endif; ?>
</div>

</div>
</div>
<?php get_footer(); ?>