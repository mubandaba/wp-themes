<?php get_header(); ?>
	 <div class="reg_cent clearfix">
<div class="reg_l left"><?php get_sidebar(); ?></div>
<div class="reg_r right">
<?php include(TEMPLATEPATH . '/inc/mood.php');//引用心情说 ?>
<div class="main">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<h2 class="biaott"><span><?php the_title(); ?></span></h2>
<div class="content"><div class="infos">
<span class="time"><p><?php the_time('Y-m-d H:i') ?></p></span>
<span class="views"><?php post_views('', '阅览'); ?></span>
<span class="comments"><?php comments_popup_link ('0条评','1条评','%条评'); ?></span>
<span class="category"><?php the_category(', ') ?></span>
<span class="author"><?php the_author() ?></span>
<span class="edit"><?php edit_post_link('编辑', '', ''); ?></span>
</div></div>
<div class="context">
<?php the_content('Read more...'); ?>
</div>
<?php endwhile;endif; ?>
</div>
<div id="wumiiDisplayDiv" style="padding:0 20px;"></div>
<?php /*<div class="relatebar">	
<ul>
<?php foreach(get_the_category() as $category){$cat = $category->cat_ID;}
query_posts('cat=' . $cat . '&orderby=rand&showposts=5'); //控制相关文章排序为随机，显示相关文章数量
while (have_posts()) : the_post();$thumbnail = wp_get_attachment_image_src(get_post_thumbnail_id(), 'large');?>
	<li class="related_box">
	<div class="r_pic img_5">
	<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" target="_blank">
	<img src="<?php if ( dopt('sky_ximage_b' )!=='' ) { ?><?php bloginfo('template_directory'); ?>/timthumb.php?w=110&h=108&src=<?php } ?><?php echo catch_first_image() ?><?php if( dopt('sky_apiximg_2_b')!=='' ) echo dopt('sky_apiximg_2'); ?>" alt="<?php the_title(); ?>" class="thumbnail">
	</a>
	</div>
	<div class="r_title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" target="_blank"><?php the_title(); ?></a></div>
	</li>
<?php endwhile; wp_reset_query(); ?>
</ul>
</div>*/ ?>
<div class="biaott" style="margin-bottom:5px;"><span style="border-left:4px solid #2c1;">本文声明</span></div>
<div class="authortail content"><div class="infos">
<p><span class="i"> 除非注明，否则文章均为 " <a href="<?php bloginfo('siteurl'); ?>" target="_blank"><?php bloginfo('name');?></a> " 原创，转载时请注明文章出处。</span></p>
<hr>
<p><span class="author">作者信息：<?php the_author() ?> \ <?php the_time('Y-m-d H:i') ?> \ <?php bloginfo('name');?> \ <?php edit_post_link('编辑', '', ''); ?></span></p>
<p><span class="tags">分类标签：<?php the_category(', ') ?><?php the_tags(',', ', ', ''); ?></span></p>
<p><span class="links">本文地址：<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" target="_blank"><?php the_permalink() ?></a></span></p>
</div></div>
<div class="block_pager">
<div class="articles">
<?php comments_template(); ?>
</div>
</div>

</div>
</div>
<?php get_footer(); ?>