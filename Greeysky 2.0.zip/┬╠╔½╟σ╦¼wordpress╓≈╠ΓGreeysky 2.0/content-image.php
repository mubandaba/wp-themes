<?php
/**
 * 云时代出品
 * wwww.Yunsd.net
 */

get_header(); ?>

<?php
/**
 * 云时代出品
 * wwww.Yunsd.net
 */

get_header(); ?>



<div id="content-box">
          





	


	<?php if ( is_single() ) : ?>
		<?php the_content(''); ?>


<?php endif; ?>



</div><!--content-box-->
