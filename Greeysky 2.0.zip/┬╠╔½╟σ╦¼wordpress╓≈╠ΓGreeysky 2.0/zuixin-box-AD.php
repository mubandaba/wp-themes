
<?php if (get_option('Yunsd_ad_zuixin')) { ?>
        	


<div class="zuixin-box-AD">

<?php echo get_option('Yunsd_ad_zuixin'); ?>
<div class="ad-title">Advertisement!</div>



</div>


        <?php } else { ?>
        	 
        <?php } ?>  