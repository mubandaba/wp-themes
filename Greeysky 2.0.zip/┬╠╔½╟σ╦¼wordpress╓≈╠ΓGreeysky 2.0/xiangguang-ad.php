<div class="xiangguang-ad">

 <?php echo get_option('Yunsd_ad_xiangguan'); ?>



</div>