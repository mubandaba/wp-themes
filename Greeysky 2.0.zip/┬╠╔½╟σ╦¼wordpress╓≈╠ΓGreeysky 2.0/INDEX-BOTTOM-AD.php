


<?php if (get_option('Yunsd_ad_980_bottom')) { ?>
        	
    
<div class="INDEX-BOTTOM-AD">
    <?php echo get_option('Yunsd_ad_980_bottom'); ?>
<div class="AD-info"> Advertisement!</div>
</div>

    <?php } else { ?>
        	
        <?php } ?>  