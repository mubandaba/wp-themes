  <div id="suiji-ad1">
 <?php echo get_option('Yunsd_single_suiji2'); ?>
 <div class="suiji-ad-info">Advertisement!</div>
  </div>