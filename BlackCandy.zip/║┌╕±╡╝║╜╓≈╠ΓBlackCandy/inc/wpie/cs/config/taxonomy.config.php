<?php if (!defined('ABSPATH')) {
  die;
} // Cannot access pages directly.

include get_template_directory().'/inc/config/taxonomy.config.php';
