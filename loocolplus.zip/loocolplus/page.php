<?php get_header();?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <div class="mainleft" id="content">
		<div class="article_container row  box">
			<h1 class="page_title"><?php the_title();?></h1>
        <div class="context">
        	<div id="post_content"><?php the_content('Read more...');?></div>
        	   <?php custom_wp_link_pages();?>
         </div>       
	</div>
    <div id="comments_box">
		<?php comments_template();?>
    </div>    
	<?php endwhile;else: ;endif;?>
</div>
<?php get_sidebar();?>
</div>
<?php get_footer();?>