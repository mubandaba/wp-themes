<?php get_header();?>
<?php if (have_posts()) : while (have_posts()) : the_post();?>
    	<div class="mainleft"  id="content">
			<div class="article_container row  box">
				<h1><?php the_title();?></h1>
                    <div class="article_info">
                        <span><i class="fa fa-calendar"></i> <?php the_time('Y-m-d')?></span>
                        <span><i class="fa fa-user-circle"></i> <?php the_author_posts_link(); ?></span> 
                        <span><i class="fa fa-folder"></i> <?php the_category(', ')?></span> 
                        <span><i class="fa fa-eye"></i> <?php setPostViews(get_the_ID());echo getPostViews(get_the_ID());?></span>
                        <?php if(comments_open()){?><span><i class="fa fa-comment"></i> <?php comments_popup_link('0','1','%');?></span><?php }?>
                    </div>
            	<div class="clear"></div>
            <div class="context">
				<div id="post_content"><?php the_content('Read more...');?></div>
				<?php custom_wp_link_pages();?>
               	<div class="clear"></div>
                <?php if(function_exists('the_ratings')) { the_ratings(); } ?>

                <div class="article_tags">
                	<div class="tagcloud">
                    	标签：<?php the_tags('',' ','');?>
                    </div>
                </div>
             </div>
		</div>
    	<?php if (get_option('loocol_adccode')) { ?>
    		<div class="single-ad box row"><?php echo stripslashes(get_option('loocol_adccode')); ?></div>
		<?php } ?>
		<?php if(is_mobile()){?>
			<div class="single-adphone box row"><?php echo stripslashes(get_option('loocol_single_adphone')); ?></div>
		<?php }?>
	<div>
		<ul class="post-navigation row">
			<div class="post-previous twofifth">
				<?php previous_post_link('上一篇 <br> %link', '%title', TRUE); ?>
            </div>
            <div class="post-next twofifth">
				<?php next_post_link('下一篇 <br> %link', '%title', TRUE); ?>
            </div>
        </ul>
	</div>
	<div class="article_container row  box article_related">
    	<div class="related">
		<?php include('config/related.php');?>
       	</div>
	</div>
    	<div class="clear"></div>
	<div id="comments_box">
		<?php comments_template('', true); ?>
    </div>
	<?php endwhile;endif;?>
</div>
	<?php get_sidebar();?>
</div>
<?php get_footer();?>
