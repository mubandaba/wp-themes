<?php get_header();?>
    <div class="mainleft" style="width:100%">
		<div class="article_container row  box">
           <div class="third centered" style="text-align:center; margin:50px auto;">
				<h2><center>很抱歉,您查找的信息已丢失,或者暂时不可用!</center></h2>
        		<div class="context">
       			  <center>E_mail:support@zhujisudi.com</center>
            	</div>
			</div>
        </div>
	</div>
</div>
</body>
<?php get_footer();?>