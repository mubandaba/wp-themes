<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type');?>" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<?php include('config/seo.php');?>
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/orange.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<link rel="shortcut icon" href="<?php echo stripslashes(get_option('loocol_favicon')); ?>" type="image/x-icon" />
<!--[if lte IE 7]><script>window.location.href='http://7xkipo.com1.z0.glb.clouddn.com/upgrade-your-browser.html?referrer='+location.href;</script><![endif]-->
<?php wp_head()?>
<?php flush()?>
<style>		
@media only screen and (min-width:1330px) {
.container { max-width: 1312px !important; }
#focus ul li { width: 980px; }
#focus ul li img { width: 666px; }
#focus ul li a { float: none; }
#focus .button { width: 980px; }
.mainleft{width:980px}
.mainleft .post .article h2{font-size:28px;}
.mainleft .post .article .entry_post{font-size:16px;}
.post .article .info{font-size:14px}
.flex-caption { left: 650px !important; width: 292px; bottom: 0 !important; height: 350px; }
.flex-caption h2 { line-height: 1.5em; margin-bottom: 20px; padding: 10px 0 20px 0; font-size: 18px; font-weight: bold; border-bottom: 1px #fff dashed; }
.flex-caption .btn { display: block !important; margin-top: 30px; width: 55px; }
.flex-caption .btn a { color: #333; }
#focus ul li a img { width: 650px !important; }
.related{height:auto}
.related_box{ width:155px !important}
</style>
</head>
<body  class="custom-background">
		<div id="head" class="row">
				<div class="container">
					<div id="blogname" class="third">
                    	<a href="<?php bloginfo('url');?>/" title="<?php bloginfo('name');?>"><?php if ( is_home() || is_search() || is_category() || is_month() || is_author() || is_archive() ) { ?><h1><?php bloginfo('name');?></h1><?php } ?>
                        <img src="<?php echo stripslashes(get_option('loocol_mylogo')); ?>" alt="<?php bloginfo('name');?>" /></a>
                    </div>
                 	<?php if (get_option('loocol_logoadccode') == true) { ?>
                 	<div class="banner twothird">
                 	<?php echo stripslashes(get_option('loocol_logoadccode')); ?>
					</div>
                	<?php } ?>
                </div>
				<div class="clear"></div>
		</div>
		<div class="container">
			<div class="mainmenu clearfix">
				<div class="topnav">
                    <div class="menu-button"><i class="fa fa-reorder"></i> 网站导航</div>
                    	<?php if(function_exists('wp_nav_menu')) {wp_nav_menu(array('theme_location'=>'nav','container'=>'ul'));}?>
               <?php if (get_option('loocol_menusearch') == 'Display') { ?>     
                <ul class="menu-right">
                    <li class="menu-search">
                    	<a href="#" id="menu-search" title="搜索"><i class="fa fa-search"></i></a>
                    	<div class="menu-search-form ">
							<form action="<?php bloginfo('url');?>" method="get">
                            	<input name="s" type="text" id="search" value="" maxlength="150" placeholder="请输入搜索内容" x-webkit-speech style="width:135px">
                            	<input type="submit" value="搜索" class="button"/>
                            </form>
                        </div>
                    </li>
                </ul> 
                <?php }?>
                 <!-- menus END -->                    
				</div>
			</div>
			<?php if(is_home()){?>
				<?php if (get_option('loocol_gg') == 'Display') { ?>
				<div class="subsidiary box">
					<div class="bulletin fourfifth">
						<i class="fa fa-volume-up"></i> <?php echo get_option('loocol_announce'); ?>
					 </div>
				</div>
				<?php } ?>
			<?php }else{?>			
						<?php if (get_option('loocol_breadcrumb') == 'Display') { ?>
							<div class="subsidiary box clearfix">           	
								<div class="bulletin">
									<?php loo_breadcrumbs(); ?>
								 </div>
							</div>
			<?php }}?>			
			<div class="row clear"></div>
		</div>
<div class="container">
		<?php if(is_active_sidebar( 'widget_full' )){ dynamic_sidebar('widget_full');}?>
		<?php if(is_mobile() && get_option('loocol_adphone')){?><div class="adphone"><div class="row"><?php echo stripslashes(get_option('loocol_adphone')); ?></div></div><?php }?>
