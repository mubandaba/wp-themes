<div class="clear"></div>
<div id="footer">
  <div class="copyright">
  <p> Copyright <?php echo comicpress_copyright();?> <a href="<?php bloginfo('url');?>/"><strong>
    <?php bloginfo('name');?>
    </strong></a>
  </p>
  </div>
</div>
</div>
<!--gototop-->
<div id="tbox">
  <?php if( is_single() || is_page()){?>
  <a id="home" href="<?php bloginfo('url');?>" title="返回首页"><i class="fa fa-home"></i></a>
  <?php } ?>
  <a id="gotop" href="javascript:void(0)" title="返回顶部"><i class="fa fa-chevron-up"></i></a>
</div>
<?php wp_footer(); ?>
</body></html>