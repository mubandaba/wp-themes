<?php get_header();?>
    <div class="mainleft">
	    <ul id="post_container" class="masonry clearfix">
			<?php include('config/list_post.php'); ?>
	    </ul>
	    <?php if (!have_posts()) {?>
			<div class="clear"></div>
			<div class="post article article_c box">
				<h3 class="center">&#x65B0;&#x777F;&#x793E;&#x533A;&#x63D0;&#x793A;&#xFF1A;&#x65E0;&#x6CD5;&#x641C;&#x7D22;&#x5230;&#x4E0E;&#x4E4B;&#x76F8;&#x5339;&#x914D;&#x7684;&#x4FE1;&#x606F;&#x3002;</h3>
			</div>
		<?php }?> 
			<div class="clear"></div>
			<?php if (get_option('loocol_scrolladd') == 'Display') { ?>
			<div class="navigation container" id="ajax-load-posts"><?php next_posts_link(__('LOAD MORE'));?></div>
			<?php }else{?>
			<div class="navigation container"><?php pagination(5);?></div>
			<?php }?>
	</div>
	<?php get_sidebar();?>
</div>
</div>
<div class="clear"></div>
<?php get_footer();?>