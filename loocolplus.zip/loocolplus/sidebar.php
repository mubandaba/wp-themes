	<div id="sidebar">
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('全站侧边栏') ) :; endif;?>
			<div id="sidebar-follow">
			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('全站滚动侧边栏') ) :; endif;?>
			</div>
		<?php if(is_home()){?><?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('首页侧边栏') ) :; endif;?><?php }?>

	</div>
