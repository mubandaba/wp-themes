<?php

wp_no_robots();

if ( !get_option('users_can_register') ) {
	wp_safe_redirect( add_query_arg('registration', 'disabled', tt_url_for('signin')));
	exit();
}

// 引入头部
?>
<head>
<meta charset="UTF-8">
<link rel="dns-prefetch" href="//apps.bdimg.com">
<meta http-equiv="X-UA-Compatible" content="IE=11,IE=10,IE=9,IE=8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<meta name="apple-mobile-web-app-title" content="<?php echo get_bloginfo('name') ?>">
<meta http-equiv="Cache-Control" content="no-siteapp">
<title><?php echo get_bloginfo('name'); ?>-注册</title>
<?php wp_head(); ?>
<link rel="shortcut icon" href="<?php echo home_url() . '/favicon.ico' ?>">
<link rel="stylesheet"  href="<?php echo get_stylesheet_directory_uri() ?>/css/login.css" type="text/css" media="all">
</head>
<body class="is-loadingApp action-page signin" style="background: url(https://api.i-meto.com/bing?new&blur) top/cover no-repeat fixed;">
  	<div class="login-logo"><a href="<?php echo home_url(); ?>"><img style="max-width: 260px;" src="<?php echo _hui('logo_src'); ?>"></a></div>
    <div id="signin" class="um_sign">
    <div class="part registerPart">
    <form name="register" id="register" action="<?php bloginfo('url'); ?>/wp-login.php?action=register" method="post" novalidate="novalidate">
        <h3>注册</h3><p class="status"></p>
        <?php if(_hui('_email_oauth')) echo '<p style="text-align: center;font-size: 13px;">我们将发送一封验证邮件至你的邮箱, 请正确填写以完成账号注册和激活</p>'; ?>
        <p>
            <label class="icon" for="user_name"><i class="fa fa-user"></i></label>
            <input class="input-control" id="user_name" type="text" name="user_name" placeholder="输入英文用户名" required="" aria-required="true">
        </p>
        <p>
            <label class="icon" for="user_email"><i class="fa fa-envelope"></i></label>
            <input class="input-control" id="user_email" type="email" name="user_email" placeholder="输入常用邮箱" required="" aria-required="true">
        </p>
        <p>
            <label class="icon" for="user_pass"><i class="fa fa-lock"></i></label>
            <input class="input-control" id="user_pass" type="password" name="user_pass" placeholder="密码最小长度为6" required="" aria-required="true">
        </p>
        <p>
            <label class="icon" for="user_pass2"><i class="fa fa-retweet"></i></label>
            <input class="input-control" type="password" id="user_pass2" name="user_pass2" placeholder="再次输入密码" required="" aria-required="true">
        </p>
        <p id="captcha_inline">
            <input class="input-control inline" type="text" id="um_captcha" name="um_captcha" placeholder="输入验证码" required>
            <img src="<?php echo THEME_URI.'/template/captcha.php?'.str_replace(' ', '_', microtime()); ?>" class="captcha_img inline" title="点击刷新验证码">
            <input class="submit inline" type="submit" value="注册" name="submit">
        </p>	
        <input type="hidden" id="user_security" name="user_security" value="<?php echo  wp_create_nonce( 'user_security_nonce' );?>"><input type="hidden" name="_wp_http_referer" value="<?php echo $_SERVER['REQUEST_URI']; ?>"> 
        <p class="login-note">已有账号? <a class="login-link" id="go-login" href="<?php echo home_url('/m/signin'); ?>" rel="link">登录</a></p>
	</form>
    </div>
    </div>
    <div class="foot-copyright">Copyright © 2018 <a href="https://www.qyblog.cn">轻语博客</a>|<?php if(get_option('users_can_register')==1){ ?><a href="<?php echo home_url('/m/signup'); ?>">注册</a>|<?php } ?><a href="<?php echo home_url(); ?>">忘记密码？</a></div>
<script>
window.jsui={
    www: '<?php echo home_url() ?>',
    uri: '<?php echo get_stylesheet_directory_uri() ?>',
    ver: '<?php echo THEME_VERSION ?>',
    ajaxpager: '<?php echo _hui("ajaxpager") ?>'
};
</script>
<?php
// 引入页脚
wp_footer();