<?php
//function mo_shop_relates(){
    $tags = get_the_terms($post->ID,'products_tag');
    $tagcount = $tags ? count($tags):0;
    $tagIDs = array();for ($i = 0;$i <$tagcount;$i++) {$tagIDs[] = $tags[$i]->term_id;};
    $args = array('term__in'=>$tagIDs,'post_type'=>'store','post__not_in'=>array($post->ID),'showposts'=>4,'orderby'=>'rand','ignore_sticky_posts'=>1);
    $my_query = new WP_Query($args); 
?>
<div class="related-products">
    <h2><span><?php _e('相关商品', 'um'); ?></span></h2>
    <ul class="products row">
        <?php if( $my_query->have_posts() ){
			while ($my_query->have_posts()) : $my_query->the_post();
			    if ( has_post_thumbnail() ){$large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'large');$imgsrc = $large_image_url[0];}else{$imgsrc = um_catch_first_image();} 
                global $post;
			    $currency = get_post_meta( $post->ID, 'pay_currency', true) ? 'cash' : 'credit';
                $price = get_post_meta($post->ID, 'product_price', true);
			?>
            <li class="col-md-3 col-sm-4 col-xs-6 product">
                <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark">
                    <img src="<?php echo um_timthumb($imgsrc,180,120); ?>" alt="<?php the_title(); ?>">
                    <h3><?php the_title(); ?></h3>
                    <div class="price"><?php if($price == 0){echo '免费';}else{ if($currency=='cash')echo '<em>¥</em>'.sprintf('%0.2f',$price).'<em>(元)</em>'; else echo '<em><i class="fa fa-gift"></i></em>'.sprintf('%0.2f',$price).'<em>(积分)</em>';}?></div>
                </a>
            </li>
        <?php endwhile;} wp_reset_query(); ?>
    </ul>
</div>
<?php// } ?>