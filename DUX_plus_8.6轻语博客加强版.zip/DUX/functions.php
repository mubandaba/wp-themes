<?php
if ( !defined('ABSPATH') ) {exit;}

//禁用古腾堡编辑器
add_filter('use_block_editor_for_post', '__return_false');

/*
*     ----------这里填写授权码-------------
*     授权码在con.qyblog.cn申请自助授权的时候会生成
*     如果忘记授权码请联系QQ:51286909提供授权域名获取授权码
*/

$authorization = "这里填写授权码"; //请填写授权后的授权码


// Require post order
require_once('template/order.php');

// Require theme functions
require get_stylesheet_directory() . '/func/constants.php';
require get_stylesheet_directory() . '/functions-theme.php';
require get_stylesheet_directory() . '/functions-video.php';
require get_stylesheet_directory() . '/fn-shortcode.php';
// Require forum
require get_stylesheet_directory() . '/func/forum.php';
require get_stylesheet_directory() . '/func/forum-sql.php';
require get_stylesheet_directory() . '/func/ajax.php';
// Require topic
require get_stylesheet_directory() . '/func/topic.php';
require get_stylesheet_directory() . '/func/zhuanti-images.php';
// Require bulletin
require get_stylesheet_directory() . '/func/bulletin.php';
// Require avatar
require get_stylesheet_directory() . '/func/first-letter-avatar.php';


/* 改变正文P标签包裹优先级 */
remove_filter( 'the_content', 'wpautop' );
add_filter( 'the_content', 'wpautop' , 12);


//数据库添加QQ号码字段
add_action('wp_insert_comment','inlojv_sql_insert_qq_field',10,2);
function inlojv_sql_insert_qq_field($comment_ID,$commmentdata) {
	$qq = isset($_POST['new_field_qq']) ? $_POST['new_field_qq'] : false;  
	update_comment_meta($comment_ID,'new_field_qq',$qq); // new_field_qq 是表单name值，也是存储在数据库里的字段名字
}
// 后台评论中显示qq字段
add_filter( 'manage_edit-comments_columns', 'add_comments_columns' );
add_action( 'manage_comments_custom_column', 'output_comments_qq_columns', 10, 2 );

function add_comments_columns( $columns ){
    $columns[ 'new_field_qq' ] = __( 'QQ号' );        // 新增列名称
    return $columns;
}
function output_comments_qq_columns( $column_name, $comment_id ){
    switch( $column_name ) {
		case "new_field_qq" :
		 // 这是输出值，可以拿来在前端输出，这里已经在钩子manage_comments_custom_column上输出了
		echo get_comment_meta( $comment_id, 'new_field_qq', true );
		break;
	}
}
//留言板获取QQ头像
add_filter( 'get_avatar', 'inlojv_change_avatar', 10, 3 );


function inlojv_change_avatar($avatar){
	global $comment;
	if( get_comment_meta( $comment->comment_ID, 'new_field_qq', true ) ){
		$qq_number =  get_comment_meta( $comment->comment_ID, 'new_field_qq', true );
		$qqavatar = file_get_contents('http://ptlogin2.qq.com/getface?appid=1006102&imgtype=3&uin='.$qq_number);
		preg_match('/https:(.*?)&t/',$qqavatar,$m); // 匹配 http: 和 &t 之间的字符串
		return '<img src="'.stripslashes($m[1]).'" class="avatar avatar-40 photo" width="40" height="40"  alt="qq_avatar" />';
	}else{
		return $avatar ;
	}	
}

//文章摘要
function _new_get_excerpt($limit = 150, $after = '...') {
	$excerpt = get_the_excerpt();
	if (_new_strlen($excerpt) > $limit) {
		return _str_cut(strip_tags($excerpt), 0, $limit, $after);
	} else {
		return $excerpt;
	}
}

//焦点图新窗口打开
function _focus_target_blank(){
    return _hui('focus_target_blank') ? ' target="_blank"' : '';
}

//禁止文章图片输出宽高
add_filter( 'the_content', 'remove_width_attribute', 10 );
add_filter( 'post_thumbnail_html', 'remove_width_attribute', 10 ); 
add_filter( 'image_send_to_editor', 'remove_width_attribute', 10 ); 
function remove_width_attribute( $html ) { 
    $html = preg_replace( '/(width|height)="\d*"\s/', "", $html ); 
    //$html = preg_replace( '/width="(\d*)"\s+height="(\d*)"\s+class=\"[^\"]*\"/', "", $html );
	//$html = preg_replace( '/  /', "", $html );
    return $html; 
} 


/* 首页布局
/* ----------- */
function the_layout(){
	$layout = 'index-blog';
	if(isset($_GET['layout'])){
		$layout = 'index-'. $_GET['layout'];
	}elseif(_hui('index-s')){
		$layout = _hui('index-s');
	}else{
		$layout = 'index-blog';
	}
	return $layout;
}

//添加灯箱效果
add_filter('the_content', 'fancybox');
function fancybox ($content){
    global $post;
    $pattern = "/<a(.*?)href=('|\")([^>]*).(bmp|gif|jpeg|jpg|png|swf)('|\")(.*?)>(.*?)<\/a>/i";
    $replacement = '<a$1href=$2$3.$4$5 data-fancybox="images"$6>$7</a>';
    $content = preg_replace($pattern, $replacement, $content);
    return $content;
}


//在顶部添加内容
function _login_header() {
    echo '<style type="text/css">
        h1 a { background-image:url('._hui('logo_src').') !important;width: 168px !important;height: 43px !important;-webkit-background-size:168px 43px !important; }
    </style>';
    echo '<link rel="stylesheet" type="text/css" href="'.get_stylesheet_directory_uri().'/css/login.css" />';
    echo "<script type='text/javascript' src='https://apps.bdimg.com/libs/jquery/1.7.2/jquery.min.js'></script>";
    echo "<script type='text/javascript' src='https://cdn.bootcss.com/particles.js/2.0.0/particles.min.js'></script>";
    remove_action('login_head', 'wp_shake_js', 12);
}
add_action('login_head', '_login_header');

function new_excerpt_more($more) {
    global $post;
	$readmore = '...';
	return '<a rel="nofollow" class="more-link" style="text-decoration:none;" href="'. get_permalink($post->ID) . '">'.$readmore.'</a>';
}
add_filter('excerpt_more', 'new_excerpt_more');

//获取CMS布局分类的调用模板
function _get_cms_cat_template ($cat_id) {
    $default = 'catlist_bar_0';
    $key = sprintf('cms_home_cat_style_%d', $cat_id);
    $option = _hui($key, $default);
    if (in_array($option, array('catlist_bar_0', 'catlist_bar_1', 'catlist_bar_2', 'catlist_bar_3', 'catlist_bar_4', 'catlist_bar_5', 'catlist_bar_6'))) {
        return $option;
    }
    return $default;
}

//重命名中文文件名
function upload_media($filename) {
	$parts = explode('.', $filename);
	$filename = array_shift($parts);
	$extension = array_pop($parts);
	foreach ( (array) $parts as $part)
		$filename .= '.' . $part;

	if(preg_match('/[\x{4e00}-\x{9fa5}]+/u', $filename)){ 
		$filename = substr(md5($filename), 0, 8); 
	}
	$filename .= '.' . $extension;
	return $filename ;
}
add_filter('sanitize_file_name', 'upload_media', 5,1);

//在登陆页面添加粒子元素
function _ligin_particle() {
    echo '<div id="particles-js"></div>';
}
add_action('login_header', '_ligin_particle');

//添加滑动解锁验证
function myQaptcha_wp_login() {
		echo '<div id="autologin" name="autologin"></div>';
		$url = get_stylesheet_directory_uri();
		$outer.= '<script type="text/javascript" src="' . $url . '/js/libs/jquery-ui.min.js"></script>'."\n";
		$outer.= '<script type="text/javascript" src="' . $url . '/js/libs/jquery.ui.touch.js"></script>'."\n";
		$outer.= '<script type="text/javascript">var myQaptchaJqueryPage="' . $url . '/template/Qaptcha.php";</script>'."\n";
		$outer.= '<script type="text/javascript" src="' . $url . '/js/libs/myqaptcha.jquery.js"></script>'."\n";
		$outer.= '<script type="text/javascript">var newQapTcha = document.createElement("div");newQapTcha.className="QapTcha";var tagIDComment=document.getElementById("autologin");if(tagIDComment){tagIDComment.parentNode.insertBefore(newQapTcha,tagIDComment);}else{var allTagP = document.getElementsByTagName("p");for(var p=0;p<allTagP.length;p++){var allTagTA = allTagP[p].getElementsByTagName("autologin");if(allTagTA.length>0){allTagP[p].parentNode.insertBefore(newQapTcha,allTagP[p]);}}}jQuery(document).ready(function(){jQuery(\'.QapTcha\').QapTcha({disabledSubmit:true,autoRevert:true});});</script>'."\n";
		echo $outer;
}
add_action('login_form', 'myQaptcha_wp_login' );

//在底部添加内容
function _login_footer(){
    echo '<div class="footer">'; 
    echo       'Copyright © '.date('Y').' All Rights | Author by <a href="http://qyblog.cn" target="_blank">QYBLOG</a>';
    echo '</div>';
    echo "<script type='text/javascript' src='".get_stylesheet_directory_uri()."/js/login.js'></script>";
}
add_filter( 'login_footer', '_login_footer' );
add_filter('login_headerurl', create_function(false,"return get_bloginfo('url');"));
add_filter('login_headertitle', create_function(false,"return get_bloginfo('name');"));

// AJAX change cover
function um_change_cover(){
	$uid = isset($_POST['user'])?(int)$_POST['user']:0;
	if(!$uid) $uid = (int)get_current_user_id();
	if(!$uid) return;
	$cover = $_POST['cover'];
	update_user_meta($uid,'um_cover',$cover);
	echo json_encode(array('success'=>1));
	exit;
}
add_action( 'wp_ajax_author_cover', 'um_change_cover' );
    
/* Curl POST
/* ---------- */
function _curl_post($url,$data){
	$post_data = http_build_query($data);
	$post_url= $url;
	$ch = curl_init();
	curl_setopt( $ch, CURLOPT_POST, 1 );
	curl_setopt ( $ch, CURLOPT_HEADER, 0 );
	curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, 1 );
	curl_setopt( $ch, CURLOPT_URL, $post_url );
	curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
	$return = curl_exec($ch);
	if (curl_errno($ch)) {      
       return '';      
    }
	curl_close($ch);
	return $return;
}

/* 在线API获取IP真实地址
/* ---------------------- */
function convertip_api($ip){
    //$url = 'http://int.dpool.sina.com.cn/iplookup/iplookup.php';
	//$data = array('format'=>'json','ip'=>$ip);
    $url = 'http://wap.ip138.com/ip.asp';
    $data = array('ip' => $ip );
    $location = _curl_post($url,$data);
    preg_match_all("/<b>查询结果：(.*)<\/b>/isU",$location,$result);
    //$location = json_decode($location);
    //if($location===FALSE||(empty($location->country)&&empty($location->province)&&empty($location->city)&&empty($location->district))) return "火星";
    //elseif (empty($location->desc)) return $location->country.$location->province.$location->city=$location->province?'':$location->city.$location->district.$location->isp;
	//else return $location->desc;
    return empty($result[1][0]) ? __('火星','tinection') : $result[1][0];

}

/* 根据设置选择调用方法
/* --------------------- */
function convertip($ip){
    $ipaddr = '';
    //if(ot_get_option('local_ip_datebase')=='on'){
        //$ipaddr = convertip_local($ip);
   // }else{
        $ipaddr = convertip_api($ip);
    //}
    return $ipaddr;
}

/* 获取真实外网IP
/* --------------------------- */

function get_true_ip(){
    static $realIP;
    if (isset($_SERVER)){
        if (isset($_SERVER["HTTP_X_FORWARDED_FOR"])){
            $realIP = explode(',', $_SERVER["HTTP_X_FORWARDED_FOR"]);
            $realIP = $realIP[0];
        } else if (isset($_SERVER["HTTP_CLIENT_IP"])) {
            $realIP = $_SERVER["HTTP_CLIENT_IP"];
        } else {
            $realIP = $_SERVER["REMOTE_ADDR"];
        }
    } else {
        if (getenv("HTTP_X_FORWARDED_FOR")){
            $realIP = getenv("HTTP_X_FORWARDED_FOR");
        } else if (getenv("HTTP_CLIENT_IP")) {
            $realIP = getenv("HTTP_CLIENT_IP");
        } else {
            $realIP = getenv("REMOTE_ADDR");
        }
    }
    $_SERVER['REMOTE_ADDR'] = $realIP;
    return $realIP;
}
add_action( 'init', 'get_true_ip' );

/* WordPress 媒体库只显示用户自己上传的文件 */
//在文章编辑页面的[添加媒体]只显示用户自己上传的文件
function my_upload_media( $wp_query_obj ) {
	global $current_user, $pagenow;
	if( !is_a( $current_user, 'WP_User') )
		return;
	if( 'admin-ajax.php' != $pagenow || $_REQUEST['action'] != 'query-attachments' )
		return;
	if( !current_user_can( 'manage_options' ) && !current_user_can('manage_media_library') )
		$wp_query_obj->set('author', $current_user->ID );
	return;
}
add_action('pre_get_posts','my_upload_media');
 
//在[媒体库]只显示用户上传的文件
function my_media_library( $wp_query ) {
    if ( strpos( $_SERVER[ 'REQUEST_URI' ], '/wp-admin/upload.php' ) !== false ) {
        if ( !current_user_can( 'manage_options' ) && !current_user_can( 'manage_media_library' ) ) {
            global $current_user;
            $wp_query->set( 'author', $current_user->id );
        }
    }
}
add_filter('parse_query', 'my_media_library' );


//图片延时加载
if(_hui("post_loading")) add_filter ('the_content', 'filter_the_content');
function filter_the_content($content) {
		if (is_feed()||is_robots()) return $content;
		return preg_replace_callback('/(<\s*img[^>]+)(src\s*=\s*"[^"]+")([^>]+>)/i', function ($matches) {

		if (!preg_match('/class\s*=\s*"/i', $matches[0])) {
			$class_attr = 'class="" ';
		}
		$replacement = $matches[1] . $class_attr . 'src="' . UM_URI.'/img/post_loading.gif' . '" data-original' . substr($matches[2], 3) . $matches[3];

		// add "lazyload" class to existing class attribute
		$replacement = preg_replace('/class\s*=\s*"/i', 'class="lazyload ', $replacement);

		return $replacement;} , $content);
}

/* 后台注册同时添加验证码
/* ----------------------- */
function add_register_captcha(){
	$captcha = THEME_URI.'/template/captcha.php';
	?>
	<p style="overflow:hidden;">
		<label for="um_captcha">验证码<br>
		<input type="text" name="um_captcha" id="um_captcha" aria-describedby="" class="input" value="" size="20" style="float:left;margin-right:10px;width:175px;">
		<img src="<?php echo $captcha; ?>" class="captcha_img inline" title="点击刷新验证码" onclick="this.src='<?php echo $captcha; ?>';" style="float:right;margin-top: 5px;"></label>
	</p>
	<?php
}
add_action('register_form','add_register_captcha');

function add_register_captcha_verify($sanitized_user_login,$user_email,$errors){
	if(!isset($_POST['um_captcha'])||empty($_POST['um_captcha'])){
		return $errors->add( 'empty_captcha', __( '请填写验证码','um' ) );
	}else{
		$captcha = strtolower(trim($_POST['um_captcha']));
		session_start();
		$session_captcha = strtolower($_SESSION['um_captcha']);
		if($captcha!=$session_captcha){
			return $errors->add( 'wrong_captcha', __( '验证码错误','tinection' ) );
		}
	}
}
add_action('register_post','add_register_captcha_verify',10,3);

//支付方式选择
function payment(){
	$payment = _hui('_alipay_option');
	switch ($payment) {
		case 'alipay':
			echo get_stylesheet_directory_uri().'/alipay/alipayapi.php';
		    break;
		case 'alipay_jk':
			echo get_stylesheet_directory_uri().'/alipay/alipay_jk.php';
		    break;
		case 'yz_qrpay':
		    echo get_stylesheet_directory_uri().'/alipay/yz_qrpay.php';
		    break;
		case 'wechat':
		    echo get_stylesheet_directory_uri().'/wechat/example/wechat.php';
		    break;
		default:
        # code...
        break;
	}
}

//404页面引导
function set404(){
    global $wp_query;
    $wp_query->is_home = false;
    $wp_query->is_404 = true;
    $wp_query->query = array('error'=>'404');
    $wp_query->query_vars['error'] = '404';
}

/* 强制使用伪静态 */
function _force_permalink(){
    if(!get_option('permalink_structure')){
        update_option('permalink_structure', '/%postname%.html');
        // TODO: 添加后台消息提示已更改默认固定链接，并请配置伪静态(伪静态教程等)
    }
}
add_action('load-themes.php', '_force_permalink');

	
/* 获取各种Url*/
function _url_for($key, $arg = null, $relative = false){
    $routes = (array)json_decode(SITE_ROUTES);
    if(array_key_exists($key, $routes)){
        return $relative ? '/' . $routes[$key] : home_url('/' . $routes[$key]);
    }
    // 输入参数$arg为user时获取其ID使用
    $get_uid = function($var){
        if($var instanceof WP_User){
            return $var->ID;
        }else{
            return intval($var);
        }
    };

    $endpoint = null;
    switch ($key){
        case 'manage_user':
            $endpoint = 'management/users/' . intval($arg);
            break;
        case 'manage_order':
            $endpoint = 'management/orders/' . intval($arg);
            break;
        case 'edit_post':
            $endpoint = 'management/editpost/' . absint($arg);
            break;
    }
    if($endpoint){
        return $relative ? '/' . $endpoint : home_url('/' . $endpoint);
    }
    return false;
}

/* 更改默认的登录链接 */
function _filter_default_login_url($login_url, $redirect) {
    $login_url = _url_for('signin');

    if ( !empty($redirect) ) {
        $login_url = add_query_arg('redirect_to', urlencode($redirect), $login_url);
    }

    return $login_url;
}
add_filter('login_url', '_filter_default_login_url', 10, 2);


/* 更改默认的注销链接 */
function _filter_default_logout_url($logout_url, $redirect) {
    $logout_url = _url_for('signout');

    if ( !empty($redirect) ) {
        $logout_url = add_query_arg('redirect_to', urlencode($redirect), $logout_url);
    }

    return $logout_url;
}
add_filter('logout_url', '_filter_default_logout_url', 10, 2);


/* 更改默认的注册链接 */
function _filter_default_register_url() {
    return _url_for('signup');
}
add_filter('register_url', '_filter_default_register_url');


/* 登录/注册/注销等动作页路由(/m) */
function _handle_action_page_rewrite_rules($wp_rewrite){
    if($ps = get_option('permalink_structure')){
        //action (signin|signup|signout|refresh)
        // m->move(action)
        $new_rules['m/([A-Za-z_-]+)$'] = 'index.php?action=$matches[1]';
        $wp_rewrite->rules = $new_rules + $wp_rewrite->rules;
    }
}
add_action('generate_rewrite_rules', '_handle_action_page_rewrite_rules');

/* 为自定义的Action页添加query_var白名单*/
function _add_action_page_query_vars($public_query_vars) {
    if(!is_admin()){
        $public_query_vars[] = 'action'; // 添加参数白名单action，代表是各种动作页
    }
    return $public_query_vars;
}
add_filter('query_vars', '_add_action_page_query_vars');

/* 登录/注册/注销等动作页模板 */
function _handle_action_page_template(){
    $action = strtolower(get_query_var('action'));
    $allowed_actions = (array)json_decode(ALLOWED_M_ACTIONS);
    if($action && in_array($action, array_keys($allowed_actions))){
        global $wp_query;
        $wp_query->is_home = false;
        $wp_query->is_page = true; //将该模板改为页面属性，而非首页
        $template = THEME_TPL . '/actions/tpl.M.' . ucfirst($allowed_actions[$action]) . '.php';
        load_template($template);
        exit;
    }
}
add_action('template_redirect', '_handle_action_page_template', 5);

/* OAuth登录处理页路由(/oauth) */
function handle_oauth_page_rewrite_rules($wp_rewrite){
    if($ps = get_option('permalink_structure')){
        //oauth (qq|weibo|weixin|...)
        $new_rules['oauth/([A-Za-z]+)$'] = 'index.php?oauth=$matches[1]';
        $new_rules['oauth/([A-Za-z]+)/last$'] = 'index.php?oauth=$matches[1]&oauth_last=1';
        $wp_rewrite->rules = $new_rules + $wp_rewrite->rules;
    }
}
add_action('generate_rewrite_rules', 'handle_oauth_page_rewrite_rules');

/* 为自定义的Action页添加query_var白名单 */
function add_oauth_page_query_vars($public_query_vars) {
    if(!is_admin()){
        $public_query_vars[] = 'oauth'; // 添加参数白名单oauth，代表是各种oauth登录处理页
        $public_query_vars[] = 'oauth_last'; // OAuth登录最后一步，整合WP账户，自定义用户名
    }
    return $public_query_vars;
}
add_filter('query_vars', 'add_oauth_page_query_vars');

/* /management主路由处理 */
function redirect_management_main_route(){
    if(preg_match('/^\/management([^\/]*)$/i', $_SERVER['REQUEST_URI'])){
        if(current_user_can('administrator')){
            //$nickname = get_user_meta(get_current_user_id(), 'nickname', true);
            wp_redirect(_url_for('manage_status'), 302);
        }elseif(!is_user_logged_in()) {
            wp_redirect(_url_for('signin'), 302);
            exit;
        }elseif(!current_user_can('edit_users')) {
            wp_die(__('你没有权限访问该页面', 'um'), __('错误: 没有权限', 'um'), 403);
        }else{
            set404();
            return;
        }
        exit;
    }
    if(preg_match('/^\/management\/orders$/i', $_SERVER['REQUEST_URI'])){
        if(current_user_can('administrator')){
            wp_redirect(_url_for('manage_orders'), 302); // /management/orders -> management/orders/all
        }elseif(!is_user_logged_in()) {
            wp_redirect(_url_for('signin'), 302);
            exit;
        }elseif(!current_user_can('edit_users')) {
            wp_die(__('你没有权限访问该页面', 'um'), __('错误: 没有权限', 'um'), 403);
        }else{
            set404();
            return;
        }
        exit;
    }
}
add_action('init', 'redirect_management_main_route'); //the `init` hook is typically used by plugins to initialize. The current user is already authenticated by this time.


/* /management子路由处理 - Rewrite */
function handle_management_child_routes_rewrite($wp_rewrite){
    if(get_option('permalink_structure')){
        // Note: management子路由与孙路由必须字母组成，不区分大小写
        $new_rules['management/([a-zA-Z]+)$'] = 'index.php?manage_child_route=$matches[1]&is_manage_route=1';
        //$new_rules['management/([a-zA-Z]+)/([a-zA-Z]+)$'] = 'index.php?manage_child_route=$matches[1]&manage_grandchild_route=$matches[2]&is_manage_route=1';
        $new_rules['management/orders/([a-zA-Z0-9]+)$'] = 'index.php?manage_child_route=orders&manage_grandchild_route=$matches[1]&is_manage_route=1';
        $new_rules['management/users/([a-zA-Z0-9]+)$'] = 'index.php?manage_child_route=users&manage_grandchild_route=$matches[1]&is_manage_route=1';
        $new_rules['management/editpost/([0-9]{1,})$'] = 'index.php?manage_child_route=editpost&manage_grandchild_route=$matches[1]&is_manage_route=1'; // 编辑文章
        // 分页
        $new_rules['management/([a-zA-Z]+)/page/([0-9]{1,})$'] = 'index.php?manage_child_route=$matches[1]&is_manage_route=1&paged=$matches[2]';
        $new_rules['management/orders/([a-zA-Z]+)/page/([0-9]{1,})$'] = 'index.php?manage_child_route=orders&manage_grandchild_route=$matches[1]&is_manage_route=1&paged=$matches[2]';
        $new_rules['management/users/([a-zA-Z]+)/page/([0-9]{1,})$'] = 'index.php?manage_child_route=users&manage_grandchild_route=$matches[1]&is_manage_route=1&paged=$matches[2]';
        $wp_rewrite->rules = $new_rules + $wp_rewrite->rules;
    }
    return $wp_rewrite;
}
add_filter('generate_rewrite_rules', 'handle_management_child_routes_rewrite');


/* /management子路由处理 - Template */
function handle_manage_child_routes_template(){
    $is_manage_route = strtolower(get_query_var('is_manage_route'));
    $manage_child_route = strtolower(get_query_var('manage_child_route'));
    $manage_grandchild_route = strtolower(get_query_var('manage_grandchild_route'));
    if($is_manage_route && $manage_child_route){
        //非Home
        global $wp_query;
        $wp_query->is_home = false;

        if($wp_query->is_404()) {
            return;
        }

       //未登录的跳转到登录页
        if(!is_user_logged_in()) {
            wp_redirect(_url_for('signin'), 302);
            exit;
        }

        //非管理员403处理
        if(!current_user_can('edit_users')) {
            wp_die(__('你没有权限访问该页面', 'tt'), __('错误: 没有权限', 'tt'), 403);
        }


        $allow_routes = (array)json_decode(ALLOWED_MANAGE_ROUTES);
        $allow_child = array_keys($allow_routes);
        // 非法的子路由处理
        if(!in_array($manage_child_route, $allow_child)){          
           set404();
           return;
        }
        if($manage_child_route === 'editpost' && (!$manage_grandchild_route || !preg_match('/([0-9]{1,})/', $manage_grandchild_route))){
            set404();
            return;
        }

        if($manage_child_route === 'orders' && $manage_grandchild_route){
            if(preg_match('/([0-9]{1,})/', $manage_grandchild_route)){ // 对于orders/8单个订单详情路由，孙路由必须是数字
                $template = THEME_TPL . '/management/tpl.Manage.Order.php';
                load_template($template);
                exit;
            }elseif(in_array($manage_grandchild_route, $allow_routes['orders'])){ // 对于orders/all 指定类型订单列表路由，孙路由是all/cash/credit之中
                $template = THEME_TPL . '/management/tpl.Manage.Orders.php';
                load_template($template);
                exit;
            }
            set404();
            return;
        }
        if($manage_child_route === 'users' && $manage_grandchild_route){
            if(preg_match('/([0-9]{1,})/', $manage_grandchild_route)){ // 对于users/57单个订单详情路由，孙路由必须是数字
                $template = THEME_TPL . '/management/tpl.Manage.User.php';
                load_template($template);
                exit;
            }elseif(in_array($manage_grandchild_route, $allow_routes['users'])){ // 对于users/all 指定类型订单列表路由，孙路由是all/administrator/editor/author/contributor/subscriber之中
                $template = THEME_TPL . '/management/tpl.Manage.Users.php';
                load_template($template);
                exit;
            }
            set404();
            return;
        }
        if($manage_child_route !== 'orders' && $manage_child_route !== 'users' && $manage_child_route !== 'editpost'){
            // 除orders/users外不允许有孙路由
            if($manage_grandchild_route) {
                set404();
                exit;
               // return;
            }
        };
        $template_id = ucfirst($manage_child_route);
        $template = THEME_TPL . '/management/tpl.Manage.' . $template_id . '.php';
        load_template($template);
        exit;
    }
}
add_action('template_redirect', 'handle_manage_child_routes_template', 5);


/* 为自定义的管理页添加query_var白名单 */
function add_manage_page_query_vars($public_query_vars) {
    if(!is_admin()){
        $public_query_vars[] = 'is_manage_route';
        $public_query_vars[] = 'manage_child_route';
        $public_query_vars[] = 'manage_grandchild_route';
    }
    return $public_query_vars;
}
add_filter('query_vars', 'add_manage_page_query_vars');

/* 替换默认的wp_die处理函数 */
function _wp_die_handler($message, $title = '', $args = array()) {
    $defaults = array( 'response' => 500 );
    $r = wp_parse_args($args, $defaults);

    if ( function_exists( 'is_wp_error' ) && is_wp_error( $message ) ) {
        if ( empty( $title ) ) {
            $error_data = $message->get_error_data();
            if ( is_array( $error_data ) && isset( $error_data['title'] ) )
                $title = $error_data['title'];
        }
        $errors = $message->get_error_messages();
        switch ( count( $errors ) ) {
            case 0 :
                $message = '';
                break;
            case 1 :
                $message = "{$errors[0]}";
                break;
            default :
                $message = "<ul>\n\t\t<li>" . join( "</li>\n\t\t<li>", $errors ) . "</li>\n\t</ul>";
                break;
        }
    }

    if ( ! did_action( 'admin_head' ) ) :
        if ( !headers_sent() ) {
            status_header( $r['response'] );
            nocache_headers();
            header( 'Content-Type: text/html; charset=utf-8' );
        }

        if ( empty($title) )
            $title = __('WordPress &rsaquo; Error');

        $text_direction = 'ltr';
        if ( isset($r['text_direction']) && 'rtl' == $r['text_direction'] )
            $text_direction = 'rtl';
        elseif ( function_exists( 'is_rtl' ) && is_rtl() )
            $text_direction = 'rtl';

        // 引入自定义模板
        global $wp_query;
        $wp_query->query_vars['die_title'] = $title;
        $wp_query->query_vars['die_msg'] = $message;
        include_once UM_DIR . '/error.php';
    endif;

    die();
}
function _wp_die_handler_switch(){
    return '_wp_die_handler';
}
add_filter('wp_die_handler', '_wp_die_handler_switch');


//热门推荐点赞
function hui_get_post_like($pid='', $text=''){

    $pid = $pid ? $pid : get_the_ID();
    $uid = get_current_user_id();
    $umlikes = get_post_meta($pid,'um_post_likes',true); 
    $umlikes_array = explode(',',$umlikes);
    $umlikes_count = $umlikes!=0?count($umlikes_array):0; 
  
    $text = $text ? $text : __('赞', 'haoui');
    $event = is_user_logged_in() ? '' : ' user-reg';
    if(is_user_logged_in() && in_array($uid,$umlikes_array)){
       $unlike = 'fa-heart';
       $loveyes = ' love-yes';
    }else{
       $unlike = 'fa-heart-o';
       $loveyes = '';
    } 

    if(!empty($uid) && $uid!=0){
        return '<span class="like-btn'.$event.$loveyes.'" pid="'.$pid.'" uid="'.$uid.'"><i class="fa '.$unlike.'"></i>'.$text.'(<span>'.$umlikes_count.'</span>)&nbsp;</span>';
    }else{
        return '<span class="like-btn'.$event.$loveyes.'"><i class="fa '.$unlike.'"></i>'.$text.'(<span>'.$umlikes_count.'</span>)&nbsp;</span>';
    }
}

/*  生成包含注册信息的激活链接  */
function _generate_registration_activation_link ($username, $email, $password) {
    $base_url = _url_for('activate');

    $data = array(
        'username' => $username,
        'email' =>  $email,
        'password' => $password
    );

    $key = base64_encode(_authdata($data, 'ENCODE', acbqx2, 60*10)); // 10分钟有效期

    $link = add_query_arg('key', $key, $base_url);

    return $link;
}


/*  验证并激活注册信息的链接中包含的key  */
function _activate_registration_from_link($key) {
    if(empty($key)) {
        return new WP_Error( 'invalid_key', __( '注册激活密钥无效.', 'tt' ), array( 'status' => 400 ) );
    }
    $data = _authdata(base64_decode($key), 'DECODE', acbqx2);
    if(!$data || !is_array($data) || !isset($data['username']) || !isset($data['email']) || !isset($data['password'])){
        return new WP_Error( 'invalid_key', __( '注册激活密钥无效.', 'tt' ), array( 'status' => 400 ) );
    }

    // 开始激活(实际上在激活之前用户信息并没有插入到数据库中，为了防止恶意注册)
    $userdata = array(
        'user_login' => $data['username'],
        'user_email' => $data['email'],
        'user_pass' => $data['password']
    );
    $user_id = wp_insert_user($userdata);
    if(is_wp_error($user_id)) {
        return $user_id;
    }

    $result = array(
        'success' => 1,
        'message' => __('激活注册成功', 'tt'),
        'data' => array(
            'username' => $data['username'],
            'email' => $data['email'],
            'id' => $user_id
        )
    );

    // 发送激活成功与注册欢迎信
    $blogname = get_bloginfo('name');
    $ip = $_SERVER['REMOTE_ADDR'];
    // 给注册用户
    //tt_async_mail('', $data['email'], sprintf(__('欢迎加入[%s]', 'tt'), $blogname), array('loginName' => $data['username'], 'password' => $data['password'], 'loginLink' => tt_url_for('signin')), 'register');
    // 给管理员
    //wp_mail('', get_option('admin_email'), sprintf(__('您的站点「%s」有新用户注册 :', 'tt'), $blogname), array('loginName' => $data['username'], 'email' => $data['email'], 'ip' => $_SERVER['REMOTE_ADDR']), 'register-admin');
	$message = '<p>您的站点「'.get_bloginfo('name').'」有新用户注册:</p>'.
    '<div style="background-color:#fefcc9; padding:10px 15px; border:1px solid #f7dfa4; font-size: 12px;line-height:160%;">'.
    '用户名: '.$data['username'].
    '<br>注册邮箱: '.$data['email'].
    '<br>注册时间: '.date("Y-m-d H:i:s").
    '<br>注册IP: ' . $_SERVER['REMOTE_ADDR'] . '&nbsp;['.convertip_api($_SERVER['REMOTE_ADDR']).']</div>';
    um_basic_mail('',get_option('admin_email'),sprintf(__('您的站点「%s」有新用户注册 :', 'tt'), $blogname),$message,sprintf(__('您的站点「%s」有新用户注册', 'tt'), $blogname));

    return $result;
}

/* 加密解密数据  */
function _authdata($data, $operation = 'DECODE', $key = '', $expire = 0) {
    if($operation != 'DECODE'){
        $data = maybe_serialize($data);
    }
    $ckey_length = 4;
    $key = md5($key ? $key : 'null');
    $keya = md5(substr($key, 0, 16));
    $keyb = md5(substr($key, 16, 16));
    $keyc = $ckey_length ? ($operation == 'DECODE' ? substr($data, 0, $ckey_length): substr(md5(microtime()), -$ckey_length)) : '';
    $cryptkey = $keya.md5($keya.$keyc);
    $key_length = strlen($cryptkey);
    $data = $operation == 'DECODE' ? base64_decode(substr($data, $ckey_length)) : sprintf('%010d', $expire ? $expire + time() : 0) . substr(md5($data . $keyb), 0, 16) . $data;
    $string_length = strlen($data);
    $result = '';
    $box = range(0, 255);
    $rndkey = array();
    for($i = 0; $i <= 255; $i++) {
        $rndkey[$i] = ord($cryptkey[$i % $key_length]);
    }
    for($j = $i = 0; $i < 256; $i++) {
        $j = ($j + $box[$i] + $rndkey[$i]) % 256;
        $tmp = $box[$i];
        $box[$i] = $box[$j];
        $box[$j] = $tmp;
    }
    for($a = $j = $i = 0; $i < $string_length; $i++) {
        $a = ($a + 1) % 256;
        $j = ($j + $box[$a]) % 256;
        $tmp = $box[$a];
        $box[$a] = $box[$j];
        $box[$j] = $tmp;
        $result .= chr(ord($data[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
    }
    if($operation == 'DECODE') {
        if((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0) && substr($result, 10, 16) == substr(md5(substr($result, 26) . $keyb), 0, 16)) {
            return maybe_unserialize(substr($result, 26));
        } else {
            return false;
        }
    } else {
        return $keyc . str_replace('=', '', base64_encode($result));
    }
}

//没有E-mail的用户强制跳转到资料页面
function noemail_page(){
    global $current_user;
    $current_id     = $current_user->ID;//登录用户 ID
    $current_email  = $current_user->user_email;
    $scheme         = is_ssl() && !is_admin() ? 'https' : 'http';
    $current_url    = $scheme . '://'.$_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"];//当前页面
    $profile_url    = get_author_posts_url($current_id).'?tab=profile';//跳转到编辑资料页面

    if (is_user_logged_in()){
        if (!$current_email && $current_url!=$profile_url){
            wp_redirect($profile_url.'#pass-form');
            //header('Location:'.$profile_url.'#pass-form');
            exit;
		}
	}
}
add_action( 'wp', 'noemail_page', 3 );
//add_action( 'template_redirect', 'noemail_page');
?>