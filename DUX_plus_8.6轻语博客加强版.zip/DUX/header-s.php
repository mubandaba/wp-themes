<?php 
/*
*  NAME:知更鸟头部
*  URL：http://www.qyblog.cn
*/
?>
<div class="uc-header" id="ucheader">
<?php if( !_hui('topbar_off') ){ ?>
<div class="top-bar">
<div class="bar">
<div class="user-info">
    <?php if( is_user_logged_in() ): global $current_user; ?>
	<?php _moloader('mo_get_user_page', false) ?>
	Hi, <?php echo $current_user->display_name ?>
	<?php if( _hui('user_page_s') ){ ?>
		<a href="<?php echo um_get_user_url('index') ?>"><i class="fa fa-user"></i>进入用户中心</a><a href="<?php echo wp_logout_url(_get_current_page_url()); ?>"><i class="fa fa-power-off"></i>注销登录</a>
	<?php } ?>
	<?php if( is_super_admin() ){ ?>
		<a href="<?php echo _url_for('manage_status'); ?>"><i class="fa fa-th"></i> 站务管理</a>&nbsp;&nbsp;<a target="_blank" href="<?php echo site_url('/wp-admin/') ?>">后台管理</a>
	<?php } ?>
	<?php elseif( _hui('user_page_s') ): ?>
	<?php _moloader('mo_get_user_rp', false) ?>
	<a href="javascript:;" class="user-reg" data-sign="0">Hi, 请登录</a>
	<a href="javascript:;" class="user-reg" data-sign="1">我要注册</a>
	<a href="<?php echo mo_get_user_rp() ?>">找回密码</a>
	<?php endif; ?>
</div>			   
    <div class="site-nav topmenu">
        <ul>
        <?php _the_menu('topmenu') ?>
        <?php if( _hui('guanzhu_b') ){ ?>
		<li class="menusns">
		    <a href="javascript:;"><?php echo _hui('sns_txt') ?> <i class="fa fa-angle-down"></i></a>
			    <ul class="sub-menu">
				<?php if(_hui('wechat')){ echo '<li><a class="sns-wechat" href="javascript:;" title="'._hui('wechat').'" data-src="'._hui('wechat_qr').'">'._hui('wechat').'</a></li>'; } ?>
				<?php for ($i=1; $i < 10; $i++) { 
					if( _hui('sns_tit_'.$i) && _hui('sns_link_'.$i) ){ 
						echo '<li><a target="_blank" rel="external nofollow" href="'._hui('sns_link_'.$i).'">'. _hui('sns_tit_'.$i) .'</a></li>'; 
					}
				  } ?>
			    </ul>
		</li>
        <?php }?>
        </ul>
    </div>
</div>
</div>
<?php } ?>
<div class="wp">
<div class="uc-logo">
<?php _the_logo(); ?>
		<?php  
			$_brand = _hui('brand');
			if( $_brand ){
				$_brand = explode("\n", $_brand);
				echo '<div class="brand">' . $_brand[0] . '<br>' . $_brand[1] . '</div>';
			}
		?>
</div>
<div class="site-nav site-navbar uc-menu">
<ul class="uc-menu-ul" id="header_menu">
    <?php _the_menu('nav') ?>
	<?php if( !is_search() ){ ?>
		<li class="navto-search"><a href="javascript:;" class="search-show active"><i class="fa fa-search"></i></a></li>
	<?php } ?>
    <?php if( is_user_logged_in() ): global $current_user; ?>
		<li class="nav-user dropdown">
            <a href="javascript:void(0)" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <?php echo um_get_avatar(  $current_user->ID , '30' , um_get_avatar_type( $current_user->ID) );  ?>
            </a>
            <ul class="nav-user-menu dropdown-menu">
              	<?php if( is_super_admin() ){ ?>
					<li><a target="_blank" href="<?php echo site_url('/wp-admin/') ?>"><i class="fa fa-tachometer"></i>后台管理</a></li>
                    <li><a href="<?php echo _url_for('manage_status'); ?>"><i class="fa fa-th"></i>站务管理</a></li>
				<?php } ?>
                <li><a href="<?php echo um_get_user_url('post&action=new') ?>"><i class="fa fa-pencil"></i>新建文章</a></li>
                <li><a href="<?php echo um_get_user_url('post') ?>"><i class="fa fa-cube"></i>我的文章</a></li>
                <li><a href="<?php echo um_get_user_url('message') ?>"><i class="fa fa-comments"></i>站内消息</a></li>
                <li><a href="<?php echo um_get_user_url('profile') ?>"><i class="fa fa-cog"></i>个人设置</a></li>
                <li role="separator" class="divider"></li>
                <li><a href="<?php echo wp_logout_url(_get_current_page_url()); ?>"><i class="fa fa-power-off"></i>注销</a></li>
            </ul>
        </li>
	<?php else : ?>
		<li class="login-actions">
            <a href="javascript:;" class="user-reg" data-sign="0"><i class="fa fa-sign-in"></i></a>
        </li>
	<?php endif; ?>
</ul>
</div>
<i class="fa fa-bars m-icon-nav"></i>
</div>
</div>