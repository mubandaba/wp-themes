<h3>Theme Legals</h3>
<p>Please read the Terms of use and the usage license for Fabthemes WordPress themes</p>
<ul>
	<li> <a href="http://www.fabthemes.com/free_license/">Free Theme Usage License Agreement</a></li>
	<li> <a href="http://www.fabthemes.com/commercial_license/">Commercial Theme Usage License Agreement</a></li>
	<li> <a href="http://www.fabthemes.com/terms_of_use/">Terms of Use</a></li>
</ul>
