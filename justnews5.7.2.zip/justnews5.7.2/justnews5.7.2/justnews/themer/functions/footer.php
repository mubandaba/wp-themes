<?php
defined( 'ABSPATH' ) || exit;

add_action('wp_footer', 'wpcom_footer', 1);
if(!function_exists('wpcom_footer')){
    function wpcom_footer(){
        global $options; ?>
        <div class="action"<?php echo isset($options['action_top'])?' style="top:'.$options['action_top'].';"':''?>>
            <?php if(isset($options['contact_text']) && trim($options['contact_text'])){ ?>
                <div class="a-box contact">
                    <div class="a-box-wrap contact-wrap">
                        <h3 class="contact-title"><?php _e('Contact Us', 'wpcom');?></h3>
                        <?php echo wpautop($options['contact_text']);?>
                    </div>
                </div>
            <?php } ?>
            <?php if(isset($options['wechat'])&&$options['wechat']){ ?>
                <div class="a-box wechat">
                    <div class="a-box-wrap wechat-wrap">
                        <img src="<?php echo $options['wechat']?>" alt="QR code">
                    </div>
                </div>
            <?php } ?>
            <?php if(isset($options['share'])&&$options['share']=='1'){ ?>
                <div class="a-box share"></div>
            <?php } ?>
            <div class="a-box gotop" id="j-top" style="display: none;"></div>
        </div>
        <?php if(isset($options['footer_bar_icon']) && !empty($options['footer_bar_icon']) && $options['footer_bar_icon'][0]){ ?>
            <div class="footer-bar">
                <?php $i = 0; foreach($options['footer_bar_icon'] as $fb){
                    $type = isset($options['footer_bar_type'][$i]) && $options['footer_bar_type'][$i]=='1' ? $options['footer_bar_type'][$i] : '0';
                    $bg = isset($options['footer_bar_bg'][$i]) && $options['footer_bar_bg'][$i] ? ' style="background-color: '.WPCOM::color($options['footer_bar_bg'][$i]).';"' : '';
                    $color = isset($options['footer_bar_color'][$i]) && $options['footer_bar_color'][$i] ? ' style="color: '.WPCOM::color($options['footer_bar_color'][$i]).';"' : '';?>
                    <div class="fb-item"<?php echo $bg;?>>
                        <a <?php echo WPCOM::url($options['footer_bar_url'][$i]);?><?php if($type=='1'){ echo ' class="j-footer-bar-icon"';} echo $color;?>>
                            <?php WPCOM::icon($fb, true, 'fb-item-icon');?>
                            <span><?php echo $options['footer_bar_title'][$i];?></span>
                        </a>
                    </div>
                    <?php $i++; } ?>
            </div>
        <?php }
    }
}

add_action('wp_footer', 'wpcom_footer_share_js', 999);
if(!function_exists('wpcom_footer_share_js')){
    function wpcom_footer_share_js(){
        global $options; ?>
        <?php if(isset($options['share'])&&$options['share']=='1' && get_locale()=='zh_CN'){ ?>
            <script>setup_share(1);</script>
        <?php } else if(isset($options['share']) && $options['share']=='1') { ?>
            <script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-542188574c8ebd62"></script>
            <script>setup_share();</script>
        <?php }
    }
}

if(!function_exists('wpcom_footer_class')){
    function wpcom_footer_class($class=''){
        global $options;
        $_class = 'footer';
        if(isset($options['footer_bar_icon']) && !empty($options['footer_bar_icon']) && $options['footer_bar_icon'][0]) $_class .= ' width-footer-bar';
        if($class) $_class .= ' ' . $class;
        return $_class;
    }
}