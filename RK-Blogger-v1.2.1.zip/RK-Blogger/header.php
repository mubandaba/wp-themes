<?php
/**
 * The template for displaying the header
 *
 * @package WordPress
 * @subpackage RK blogger
 * @since Wbolt 1.1.1
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php endif; ?>
	<?php wp_head(); ?>
    <?php /*读取设置favicon图标*/ ?>
    <?php if(wb_opt('favicon')): ?>
<link rel="shortcut icon" href="<?php echo wb_opt('favicon'); ?>" />
    <?php else: ?>
<link rel="shortcut icon" href="<?php echo get_template_directory_uri().'/images/wbolt.ico'; ?>" />
    <?php endif; ?>

    <script>
		<?php
		$js_var = array('home_url'=>home_url(),'theme_url'=>get_template_directory_uri(),'ajax_url'=>admin_url('/admin-ajax.php'),'theme_name' => WB_THEMES_CODE, 'assets_ver'=>WB_ASSETS_VER);
		$js_var['_wp_uid'] = get_current_user_id();
		$js_var['_pid'] = get_the_ID() ? get_the_ID() : 0;
		echo 'var wb_base = '.json_encode($js_var).";\n";
		echo do_shortcode('[wb_opt_value]');
		?>
    </script>
	<?php echo do_shortcode('[wb_custom_header_code]'); ?>
</head>

<body <?php body_class()?>>

<header class="header">
    <div class="inner pw">
        <?php echo (is_front_page() && is_home()) ? '<h1 ' : '<div '; echo 'class="logo">'; ?>
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                    <?php if(wb_opt('logo_url')):
                        echo '<img src="'. wb_opt('logo_url'). '" alt="'.get_bloginfo( 'name' ).'"/>';
                    else:
	                    echo '<img src="'. get_template_directory_uri(). '/images/logo_wb.png" alt="'.get_bloginfo( 'name' ).'"/>';
                    endif; ?>
                </a>
        <?php echo (is_front_page() && is_home()) ? '</h1>' : '</div>'; ?>

        <?php if(wp_is_mobile()): ?>
            <nav class="nav-top-m" id="J_navBar">
	            <?php get_search_form(); ?>
                <?php
                if(has_nav_menu( 'primary' ) ) {
	                wp_nav_menu( array(
		                'theme_location' => 'primary',
		                'menu_class'     => 'nav-m',
		                'menu_id'     => 'J_topNavMb',
		                'container'     => '',
		                'walker' => new Wbolt_Walker_Nav_Menu_m()
	                ) );
                }
                ?>

                <a class="btn-close" id="J_closeNav"><?php echo wbolt_svg_icon('wbsico-close'); ?></a>
            </nav>
            <a class="btn-search-m" id="J_btnSearchMb"><?php echo wbolt_svg_icon('wbsico-search'); ?></a>
            <a class="btn-nav" id="J_btnNavMb"><i><?php _e( '显/隐菜单', 'wbolt' ); ?></i></a>

        <?php else : ?>
            <nav class="nav-top cf" id="J_navBar">
                <?php
                if(has_nav_menu( 'primary' ) ) wp_nav_menu( array(
                    'theme_location' => 'primary',
                    'menu_class'     => 'nav',
                    'menu_id'     => 'J_topNav',
                    'container'     => '',
                    'walker' => new Wbolt_Walker_Nav_Menu()
                ) );
                ?>
            </nav>
	        <?php get_search_form(); ?>
        <?php endif; ?>


    </div>
</header>

<?php if (function_exists('wb_breadcrumbs')) wb_breadcrumbs(); ?>

<div class="container pw<?php if(isset($GLOBALS['container-custom']) && $GLOBALS['container-custom']) echo ' '.$GLOBALS['container-custom']; ?>">