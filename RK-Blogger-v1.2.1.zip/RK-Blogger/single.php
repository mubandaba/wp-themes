<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage RK blogger
 * @since Wbolt 1.0
 */

if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
	wp_enqueue_script( 'comment-reply' );
}

get_header();

setPostViews(get_the_ID());
?>
<div class="main main-detail">
	<?php
	while ( have_posts() ) : the_post();

		get_template_part( 'template-parts/content', 'single' );
		?>

		<?php #tags S ?>
        <section class="panel-inner panel-tags">
            <h3 class="sc-title">标签</h3>
            <div class="tag-items">
				<?php the_tags('','',''); ?>
            </div>
        </section>
		<?php #tags E ?>

		<?php
		    //相关推荐
            if(wb_opt('related_post.switch')):
                if(wb_opt('related_post.display_mode') == 1 && !wp_is_mobile()){
                    echo do_shortcode( '[manual_related_posts mode="img" max=3]' );
                }else{
                    echo do_shortcode( '[manual_related_posts]' );
                }
            endif;
		?>


		<?php dynamic_sidebar( 'sidebar-content-bottom' ); ?>

		<?php
		if ( comments_open() || get_comments_number() ) {
			comments_template();
		}
	endwhile;
	?>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
