<?php


define('WB_THEMES_VER','1.2.1');
define('WB_ASSETS_VER','202003');
define('WB_THEMES_CODE','rk-blogger');