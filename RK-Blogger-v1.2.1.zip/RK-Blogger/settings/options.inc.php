<?php
/**
 * Author: wbolt team
 * Author URI: https://www.wbolt.com
 */

class WBOptions
{
	function __construct()
	{
		add_action('admin_menu', array($this, 'options_page_menu'));
		add_action('admin_init',array($this,'admin_init'),1);

		add_shortcode( 'wb_custom_footer_code', array(__CLASS__,'wb_custom_footer_code_handler'));
		add_shortcode( 'wb_custom_header_code', array(__CLASS__,'wb_custom_header_code_handler'));
		add_shortcode( 'wb_opt_value', array(__CLASS__,'wb_custom_script_opt_handler'));
	}

	function admin_head_post(){
		wp_enqueue_script('wbs-nmjs', get_template_directory_uri() . '/settings/assets/wb_admin.js', array(),WB_THEMES_VER, true);
	}

	public function admin_init(){
		add_action('admin_enqueue_scripts',function($hook) {
			global $wb_settings_page_hook_theme;
			if ( $wb_settings_page_hook_theme != $hook ) {
				return;
			}

			wp_enqueue_style('wbs-style', get_template_directory_uri() . '/settings/assets/wb_setting.css', array(),WB_THEMES_VER);
		},1);

		//setting
		register_setting($this->cnf('opt_key'), $this->cnf('opt'));

		self::load();
	}

	//主题常量配置
	static function cnf($key, $default = null)
	{
		$cnf = array(
			'name' => 'WB',
			'opt' => 'wb_theme_cnf',
			'opt_key' => 'options_xk_themes'
		);
		if (isset($cnf[$key])) return $cnf[$key];
		return $default;
	}

	function options_page_menu()
	{
		global $wb_settings_page_hook_theme;
		$wb_settings_page_hook_theme = add_menu_page(
			'主题设置',
			'主题设置',
			'edit_theme_options',
			'options-wbthemes',
			array($this,'optionsPage'),
			get_template_directory_uri() . '/settings/assets/wbolt_ico.svg'
		);
	}

	//配置页面get_template_directory() . '/settings/wbolt_ico.png'
	function optionsPage()
	{
		global $wpdb;
		$opt = $this->opt('');//get_option($this->cnf('opt'));
		$opt_name = $this->cnf('opt');
		$opt_key = $this->cnf('opt_key') ;
		$name = $this->cnf('name');

		$index_term_id = isset($opt['flID']) && $opt['flID'] ? $opt['flID'] : '';

		$tm_1 = $wpdb->terms;
		$tm_2 = $wpdb->term_taxonomy;
		$sql = "SELECT b.name,b.slug,a.parent,a.term_id FROM $tm_2 a,$tm_1 b WHERE a.term_id=b.term_id AND a.taxonomy='category' order by a.parent";

		$term_name = array();

		$term_list = $wpdb->get_results($sql,ARRAY_A);
		$cate_list = array();
		$term_list2 = array();
		foreach($term_list as $term){
			if(!isset($cate_list[$term['parent']])){
				$cate_list[$term['parent']] = array();
			}
			$cate_list[$term['parent']][] = $term;
			$term_list2[$term['term_id']] = $term;
		}
		if($index_term_id){
			$index_term_id = explode(',',$index_term_id);
			foreach ($index_term_id as $term_id) {
				$term_name[] = $term_list2[$term_id]['name'];
			}
		}
//        print_r($opt);

		include get_template_directory() . '/settings/options.php';
	}

	//配置值
	static function opt($name, $default = false)
	{
		//配置的name
		$option_name = self::cnf('opt');
		static $options = null;
		// Get option settings from database
		if (null == $options) $options = get_option($option_name);

		if(!$name)return $options;

		$ret = $options;
		$ak = explode('.', $name);
		foreach ($ak as $sk) {
			if (isset($ret[$sk])) {
				$ret = $ret[$sk];
			} else {
				return $default;
			}
		}
		return $ret;
	}

	//插入广告位
	static function insertAdBlock($ad_name = '', $box_class = 'adbanner-block'){
		if(!$ad_name) return;

		$ads = self::opt('ads.'.$ad_name);

		if($ads['type'] == 0) return;

		$adHTML = '<div class="'. $box_class .'">';

		if($ads['type'] == 1){
			$adHTML .= $ads['code'];
		}elseif($ads['type'] == 2){
			$adHTML .= '<a href="' . $ads['url'] . '" target="_blank" rel="nofollow"><img class="adbn-img" src="' . $ads['img'] . '"></a>';
		}else{
			return;
		}
		$adHTML .= '</div>';

		return $adHTML;
	}

	public static function wb_custom_footer_code_handler(){
		if(self::opt('ft_code')){
			echo self::opt('ft_code')."\n";
		}

		if(self::opt('stats_code')){
			echo '<div style="display:none;">'. self::opt('stats_code')  . '</div>'."\n";
		}
	}

	public static function wb_custom_header_code_handler(){
		//主题颜色
		$theme_color_var = self::opt('theme_color');
		$custom_vip_url = self::opt('vipicon_url');

		//自定义样式
		$custom_css = self::opt('usr_css','');

		if($theme_color_var){
			$custom_css = ":root{--mainColor:" . $theme_color_var.";--mainColorHover:" . $theme_color_var.";}".$custom_css;
		}

		if($custom_vip_url){
			$custom_css .= ".wbicon.vip,.wbicon.no-vip{background-image: url(" . $custom_vip_url.");}";
		}

		if($custom_css){
			echo sprintf("<style>\n%s\n</style>\n",$custom_css);
		}

		//自定义代码
		$hd_code = self::opt('hd_code');
		if($hd_code){
			echo $hd_code."\n";
		}

		$ads = self::opt('ads',array());

		//google ad
		if($ads)foreach($ads as $r){
			if(is_array($r) && isset($r['type']) && $r['type']==1){

				echo '<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>'."\n";
				break;
			}
		}
	}

	public static function wb_custom_script_opt_handler(){


		//列表自动加载
		if(self::opt('autoload')){
			$mxpage = self::opt('mxpage') ? self::opt('mxpage') : '0';
			echo ' var autoLoadMaxPage = '.$mxpage . ';';
		}
		//默认图片
		if(self::opt('def_img_url')) {
			echo ' var _def_pic_url = "'.self::opt('def_img_url') . '";';
		}

	}

	public static function load(){

		add_action( 'load-themes.php', array(__CLASS__,'check_version'),100 );
		add_action( 'load-update.php', array(__CLASS__,'check_version'),100 );
		add_action( 'load-update-core.php', array(__CLASS__,'check_version'),100 );
		add_action( 'wp_update_themes', array(__CLASS__,'check_version'),100 );

	}

	public static function check_version(){
		global $wp_version;

		$update_themes = get_site_transient( 'update_themes' );

		if ( ! is_object( $update_themes ) ) {
			return;
		}

		$theme = wp_get_theme();
		$tpl = $theme->get_template();

		if(isset($update_themes->response[$tpl])){
			return;
		}


		$doing_cron = wp_doing_cron();

		// Check for update on a different schedule, depending on the page.
		switch ( current_filter() ) {
			case 'upgrader_process_complete':
				$timeout = 0;
				break;
			case 'load-update-core.php':
				$timeout = MINUTE_IN_SECONDS;
				break;
			case 'load-themes.php':
			case 'load-update.php':
				$timeout = HOUR_IN_SECONDS;
				break;
			default:
				if ( $doing_cron ) {
					$timeout = 2 * HOUR_IN_SECONDS;
				} else {
					$timeout = 12 * HOUR_IN_SECONDS;
				}
		}

		$time_not_changed = isset( $update_themes->wb_checked ) && $timeout > ( time() - $update_themes->wb_checked );
		if($time_not_changed){
			return;
		}

		$update_themes->wb_checked = time();
		set_site_transient( 'update_themes', $update_themes );

		if ( $doing_cron ) {
			$timeout = 30;
		} else {
			$timeout = 3 ;
		}

		$options = array(
			'timeout'    => $timeout,
			'user-agent' => 'Wbolt WordPress/' . $wp_version . '; ' . home_url( '/' ),
		);


		$url      = 'https://www.wbolt.com/wb-api/v1/themes/checkver?chk=1&code='.WB_THEMES_CODE.'&ver='.WB_THEMES_VER;


		$raw_response = wp_remote_get( $url, $options );

		if ( is_wp_error( $raw_response ) || 200 != wp_remote_retrieve_response_code( $raw_response ) ) {
			return;
		}

		$new_version = trim(wp_remote_retrieve_body( $raw_response ));
		if(!$new_version || !preg_match('#^\d[0-9\.]+#',$new_version)){
			return;
		}

		$update_themes->response[$tpl] = array(
			'theme'=>$tpl,
			'new_version'=>$new_version,
			'url'=>'https://www.wbolt.com/themes/'.WB_THEMES_CODE.'/',
			'package'=>'https://www.wbolt.com/wb-api/v1/themes/upgrade?p='.WB_THEMES_CODE.'&v=free',
			'requires'=>'4.9.6',
			'requires_php'=>'5.3.5',
		);

		set_site_transient( 'update_themes', $update_themes );

	}

}

new WBOptions();