<?php /**
 * WBolt 主题基本设置
 **/
 ?>

<div class="sc-header">
    <strong>基本设置</strong>
    <span>网站基本设置</span>
</div>

<div class="sc-body">
    <table class="wbs-form-table">
        <tbody>
        <tr>
            <th class="w8em row">Logo</th>
            <td>
                <div id="section-logo_src" class="section section-upload">
                    <div class="wbs-upload-box">
                        <input class="wbs-input upload-input" type="text" name="<?php echo $opt_name; ?>[logo_url]" id="logo" value="<?php _opt('logo_url');?>"/>
                        <button type="button" class="wbs-btn wbs-upload-btn">
			                <?php echo wbolt_svg_icon('sico-upload'); ?>
                            <span>上传</span>
                        </button>
                    </div>

                    <p class="description">（建议Logo图片高度至少68像素（包括上下留白）及不大于204像素，宽度随高度等比例显示）</p>
                </div>
            </td>
        </tr>

        <tr>
            <th class="row">Favicon</th>
            <td>
                <div id="section-favicon_src" class="section section-upload">
                    <div class="wbs-upload-box">
                        <input class="wbs-input upload-input" type="text" name="<?php echo $opt_name; ?>[favicon]" id="favicon" value="<?php _opt('favicon');?>"/>
                        <button type="button" class="wbs-btn wbs-upload-btn">
			                <?php echo wbolt_svg_icon('sico-upload'); ?>
                            <span>上传</span>
                        </button>
                    </div>
                </div>
            </td>
        </tr>

        <tr>
            <th class="row">默认图</th>
            <td>
                <div id="section-defimg_src" class="section section-upload">
                    <div class="wbs-upload-box">
                        <input class="wbs-input upload-input" type="text" name="<?php echo $opt_name; ?>[def_img_url]" id="defImg" value="<?php _opt('def_img_url');?>"/>
                        <button type="button" class="wbs-btn wbs-upload-btn">
			                <?php echo wbolt_svg_icon('sico-upload'); ?>
                            <span>上传</span>
                        </button>
                    </div>
                </div>
            </td>
        </tr>

        <tr>
            <th class="row">主题主色调</th>
            <td>
                <input id="themeColor" class="of-input j-color-picker" name="<?php echo $opt_name; ?>[theme_color]" type="text" value="<?php _opt('theme_color'); ?>">
                <p class="description">设定主题配色</p>
            </td>
        </tr>

        <tr>
            <th class="row">文章编辑器</th>
            <td>
                <input class="wb-switch" type="checkbox" name="<?php echo $opt_name; ?>[gutenberg_switch]" <?php if(wb_opt('gutenberg_switch')) echo ' checked="checked"'; ?> data-value="<?php _opt('gutenberg_switch'); ?>"> <span class="description">默认跟WP版本。激活选项则关闭古腾堡，使用传统编辑器</span>
            </td>
        </tr>

        <tr>
            <th class="row">列表页自动加载</th>
            <td>
                <input class="wb-switch" type="checkbox" name="<?php echo $opt_name; ?>[autoload]" data-target="#J_rangeAutoLoadSetting" <?php if(wb_opt('autoload')) echo ' checked="checked"'; ?> data-value="<?php _opt('autoload'); ?>"> <span class="description">列表下拉自动加载，默认关闭</span>

                <div class="default-hidden-box<?php echo wb_opt('autoload') ? ' active':''; ?> mt" id="J_rangeAutoLoadSetting">
                    <div class="input-range">
                        <input class="field-range" id="J_rangeAutoLoadRange" name="<?php echo $opt_name; ?>[mxpage]" type="hidden" value="<?php _opt('mxpage'); ?>" />
                    </div>
                    <p class="description">设定自动加载页数</p>
                </div>
            </td>
        </tr>

        <tr>
            <th class="row">首页列表展示形式</th>
            <td>
                <div class="selector-bar">
                    <label style="display: none"><input class="wbs-radio" type="radio" name="<?php echo $opt_name; ?>[index_items_display_mode]" value="0" <?php echo wb_opt('index_items_display_mode')==0 ?  'checked' : ''; ?>> 两种形式供用户选择（默认）</label>
                    <label><input class="wbs-radio" type="radio" name="<?php echo $opt_name; ?>[index_items_display_mode]" value="2" <?php echo !wb_opt('index_items_display_mode') || wb_opt('index_items_display_mode')==2?  'checked' : ''; ?>> 卡片形式（默认）</label>
                    <label><input class="wbs-radio" type="radio" name="<?php echo $opt_name; ?>[index_items_display_mode]" value="1" <?php echo wb_opt('index_items_display_mode')==1?  'checked' : ''; ?>> 左边图片右边文字通栏形式</label>
                </div>
            </td>
        </tr>

        <tr>
            <th class="row">列表页展示形式</th>
            <td>
                <div class="selector-bar">
                    <label><input class="wbs-radio" type="radio" name="<?php echo $opt_name; ?>[list_display_mode]" value="0" <?php echo !wb_opt('list_display_mode') || wb_opt('list_display_mode')==0 ?  'checked' : ''; ?>> 两种形式供用户选择（默认）</label>
                    <label><input class="wbs-radio" type="radio" name="<?php echo $opt_name; ?>[list_display_mode]" value="1" <?php echo wb_opt('list_display_mode')==1?  'checked' : ''; ?>> 左边图片右边文字通栏形式</label>
                    <label><input class="wbs-radio" type="radio" name="<?php echo $opt_name; ?>[list_display_mode]" value="2" <?php echo wb_opt('list_display_mode')==2?  'checked' : ''; ?>> 卡片形式</label>
                </div>
            </td>
        </tr>

        </tbody>
    </table>
</div>

<div class="sc-header">
    <strong>页脚版权信息设置</strong>
</div>
<div class="sc-body">
    <table class="wbs-form-table">
    <tbody>
    <tr>
        <th class="row w8em">
            <div class="pt-l">页脚版权信息</div>
        </th>
        <td>
			<?php
			wp_editor( wb_opt('copyright_footer'), 'editor_copyright_footer', array(
					'teeny' => true,
					'textarea_rows' => 5,
					'media_buttons' => false,
					'textarea_name' => $opt_name.'[copyright_footer]')
			);
			?>
        </td>
    </tr>


    <tr>
        <th class="row"></th>
        <td></td>
    </tr>

    <tr>
        <th class="row">页脚图标</th>
        <td>
			<?php
			/*
			 * type: 0为普通url, 1为图片
			 *
			 * **/
			//初始化数据结构
			$socialData = array(
				'weixin' => array(
					'name' => '微信二维码图片',
					'type' => 1,
					'img'=>'',
					'url'=>''
				),
				'email' => array(
					'name' => '邮箱地址 mailto:xxx@xxx.com',
					'type' => 0,
					'img'=>'',
					'url'=>''
				),
				'weibo' => array(
					'name' => '微博',
					'type' => 0,
					'img'=>'',
					'url'=>''
				),
				'qq' => array(
					'name' => 'QQ',
					'type' => 0,
					'img'=>'',
					'url'=>''
				),
				'facebook' => array(
					'name' => 'Facebook',
					'type' => 0,
					'img'=>'',
					'url'=>''
				),
				'twitter' => array(
					'name' => 'Twitter',
					'type' => 0,
					'img'=>'',
					'url'=>''
				),
				'linkedin' => array(
					'name' => 'Linkedin',
					'type' => 0,
					'img'=>'',
					'url'=>''
				),
				'youtube' => array(
					'name' => 'Youtube',
					'type' => 0,
					'img'=>'',
					'url'=>''
				),
				'instagram' => array(
					'name' => 'Instagram',
					'type' => 0,
					'img'=>'',
					'url'=>''
				),
				'pinterest' => array(
					'name' => 'Pinterest',
					'type' => 0,
					'img'=>'',
					'url'=>''
				)
			);
			?>

			<?php foreach ($socialData as $k => $v){

				$item_obj = isset($opt['social']) && isset($opt['social'][$k]) ? $opt['social'][$k] : array('','','');
				$item_name = $opt_name . '[social][' . $k . ']';

				?>
				<?php if($v['type'] == 1): ?>
                    <div class="social-item section-upload">
                        <div class="wbs-upload-box">
                            <input class="wbs-input upload-input" id="<?php echo 'social-'.$k; ?>"  type="text" placeholder="<?php echo isset($v['name']) ? $v['name'] : '';?>" name="<?php echo $item_name;?>[img]" value="<?php echo isset($item_obj['img']) ? $item_obj['img'] : '';?>"/>
                            <button type="button" class="wbs-btn wbs-upload-btn">
								<?php echo wbolt_svg_icon('sico-upload'); ?>
                                <span>上传</span>
                            </button>
                        </div>
                    </div>
                    <input type="hidden" name="<?php echo $item_name;?>[type]" value="1">
                    <input type="hidden" name="<?php echo $item_name;?>[url]" value="<?php echo $item_obj['url'];?>">
				<?php else: ?>
                    <div class="social-item">
                        <input class="wbs-input" id="social-<?php echo 'social-'.$k; ?>" type="text" placeholder="<?php echo isset($v['name']) ? $v['name'] : '';?>" name="<?php echo $item_name;?>[url]" value="<?php echo isset($item_obj['url']) ? $item_obj['url'] : '';?>">
                        <input type="hidden" name="<?php echo $item_name;?>[type]" value="0">
                        <input type="hidden" name="<?php echo $item_name;?>[img]" value="<?php echo isset($item_obj['img'])?$item_obj['img']:'';?>">
                    </div>
				<?php endif; ?>

				<?php
			} ?>

        </td>
    </tr>
    </tbody>
</table>
</div>
