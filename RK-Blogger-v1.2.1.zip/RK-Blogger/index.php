<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 * @package RK_blogger WordPress theme
 * @subpackage RK blogger
 * @since RK blogger 1.1.1
 */

get_header(); ?>

<div class="main">
	<?php if ( have_posts() ) : ?>

    <?php $list_display_mode = wb_opt('index_items_display_mode'); ?>
    <div class="articles-list <?php if($list_display_mode && $list_display_mode < 2) echo ' with-list-mode'; if($list_display_mode == 1) echo ' list-mode-b'; ?>" id="J_postList">
		<?php
		// Start the loop.
		$postIndex = 0;
		$adIndex = rand(3,8);
		$hasListAD = wb_opt('ads.list.type') || wb_opt('ads.list_b.type');

		while ( have_posts() ) : the_post();

			get_template_part( 'template-parts/content', get_post_format() );

			if($hasListAD && $postIndex == $adIndex){
				get_template_part( 'template-parts/content', 'list-ad' );
			}
			$postIndex++;

		endwhile;

		else :
			get_template_part( 'template-parts/content', 'none' );

		endif;
		?>
    </div>

    <div class="loading-bar"></div>
	<?php
	// Previous/next page navigation.
	wbolt_the_posts_pagination();
	?>
</div>
<?php get_sidebar(); ?>

<?php get_footer(); ?>