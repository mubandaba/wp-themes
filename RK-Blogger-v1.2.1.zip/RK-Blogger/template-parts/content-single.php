<?php
/**
 * The template part for displaying single posts
 *
 * @package WordPress
 * @subpackage RK blogger
 * @since Wbolt 1.0
 */
?>

<article>
	<header class="article-header">
		<?php the_title( '<h1 class="title-detail">', '</h1>' ); ?>

        <div class="post-metas">
            <span class="meta-item meta-author">
                <?php echo wbolt_svg_icon('wbsico-author'); ?>
                <em><?php the_author(); ?></em>
            </span>
            <span class="meta-item meta-date">
                <?php echo wbolt_svg_icon('wbsico-time'); ?>
                <em><?php the_time('M d, Y') ?></em>
            </span>
            <span class="meta-item meta-view">
                <?php echo wbolt_svg_icon('wbsico-views'); ?>
            <em><?php echo getPostViews(get_the_ID()); ?></em>
            </span>
            <a class="meta-item meta-comment" href="<?php comments_link(); ?>">
				<?php echo wbolt_svg_icon('wbsico-comment'); ?>
                <em><?php comments_number( '0', '1', '%' ); ?></em>
            </a>
        </div>
	</header>

    <?php #详情页广告位 S ?>
    <?php echo wb_insert_ad_block('detail'); ?>

	<div class="article-detail">
		<?php
			the_content();
		?>
	</div>
</article>
