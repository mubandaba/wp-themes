<?php
/**
 * The template used for displaying page content
 *
 * @package WordPress
 * @subpackage RK blogger
 * @since Wbolt 1.0
 */
?>

<article>
    <header class="header-page">
	    <?php the_title( '<h1 class="title-page">', '</h1>' ); ?>
    </header>

    <div class="article-detail">
		<?php
		the_content();
		?>
    </div>
</article>
