<?php
/**
 * The template part for displaying content
 *
 * @package WordPress
 * @subpackage RK blogger
 * @since Wbolt 1.0
 */

$sp_class ='';
$baseHPC = round((168/300),4);
if(has_post_thumbnail()){
	$img = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()),'post-thumbnail');
	$hpc = $img && $img[1] ? round(($img[2] / $img[1]),4) : $baseHPC;
	$sp_class = $hpc < $baseHPC ? ' spc' : '';
} elseif( wbolt_catch_first_image()){
	$img = wbolt_catch_first_image();
	$hpc = $img['width'] && $img['height'] ? ($img['height'] / $img['width']) :0;
	$sp_class = $hpc < $baseHPC ? ' spc' : '';
}

?>
<article class="post">
    <div class="inner">
        <a class="media-pic<?php echo $sp_class; ?>" href="<?php echo get_permalink(); ?>">
            <?php wbolt_post_thumbnail(); ?>
        </a>
        <div class="post-cate">
	    <?php
	    $cate = get_the_category();
	    foreach($cate as $key => $cateItem){
		    if($key < 4) { ?>
                <a class="cate-tag" href="<?php echo get_category_link($cateItem->cat_ID); ?>"><?php echo $cateItem->cat_name; ?></a>
			    <?php
		    }
	    }
	    ?>
        </div>
        <div class="media-body">
            <?php the_title( sprintf( '<a class="post-title" href="%s">', esc_url( get_permalink() ) ), '</a>' );
            ?>
            <div class="summary">
                <?php
                the_excerpt();
                ?>
            </div>
            <div class="post-metas">
                <span class="meta-item primary">
                    <?php echo wbolt_svg_icon('wbsico-time'); ?>
                    <em><?php the_time('Y.m.d') ?></em>
                </span>
                <span class="meta-item">
                    <?php echo wbolt_svg_icon('wbsico-views'); ?>
                    <em><?php echo getPostViews(get_the_ID()); ?></em>
                </span>
                <a class="meta-item" href="<?php comments_link(); ?>">
                    <?php echo wbolt_svg_icon('wbsico-comment'); ?>
                    <em><?php comments_number( '0', '1', '%' ); ?></em>
                </a>
            </div>
        </div>
    </div>
</article>
