<?php
/**
 * The template part for displaying a ad code
 *
 * @package WordPress
 * @subpackage YK-Pro
 * @since Wbolt 1.0
 */
?>

<?php if(wb_opt('ads.list_b.type') > 0): ?>
<div class="post post-adbanner adb-b">
    <div class="inner">
    <?php echo wb_insert_ad_block('list_b',''); ?>
    </div>
</div>
<?php endif; ?>

<?php if(wb_opt('ads.list.type') > 0): ?>
<div class="post post-adbanner adb-a">
    <div class="inner">
    <?php echo wb_insert_ad_block('list',''); ?>
    </div>
</div>
<?php endif; ?>
