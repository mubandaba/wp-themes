// JavaScript Document 时间 日期
var runDate = new Date(2013, 1, 14, 5, 2, 1);
var ns4up1 = (document.layers) ? 1 : 0;  // browser sniffer

var ie4up1 = (document.all&&(navigator.appVersion.indexOf("MSIE 4") == -1)) ? 1 : 0;

var ns6up1 = (document.getElementById&&!document.all) ? 1 : 0;

function nowclock() {
	if (!ns4up1 && !ie4up1 && !ns6up1) return false;
	var today=new Date();
	//获得年份
	var year=today.getFullYear();
	//获得月份
	var month=today.getMonth()+1;
	//获得日期
	var day=today.getDate();
	//获取星期
	var week=today.getDay();
	switch(week){
		case 0:week="星期日";break;
		case 1:week="星期一";break;
		case 2:week="星期二";break;
		case 3:week="星期三";break;
		case 4:week="星期四";break;
		case 5:week="星期五";break;
		case 6:week="星期六";break;
		}
	//获得小时
	var hours = today.getHours();
	//获得分钟
	var minutes = today.getMinutes();
	if( minutes < 10 ){
		minutes = "0" + minutes;
		}
	//获得秒
	var seconds = today.getSeconds();
	if(seconds<10){
		seconds = "0" + seconds;
	}
	tempDate = today - runDate;
	//runYears = tempDate/1000/60/60/60/24/30/12;
	//runMonths = tempDate/1000/60/60/24/30;
	runDay = Math.floor(tempDate/1000/60/60/24);
	runHours = Math.floor(tempDate/1000/60/60%24);
	runMinutes = Math.floor(tempDate/1000/60%60);
	runSeconds = Math.floor(tempDate/1000%60);

	dispRunDate ="<span>" + runDay + "</span>" + "天" + "<span>" + runHours + "</span>" + "小时" + "<span>" + runMinutes + "</span>" + "分" + "<span>" + runSeconds + "</span>" + "秒";
	dispDate = year + "年" + month + "月" + day+ "日, " + hours + ":" + minutes + ":" + seconds + " " + week 
		+ "<br/><span>本站已运行：<br/>" + dispRunDate + "</span>";

	if (ns4up1) {
		document.layers.datetime.document.write(dispDate);
		document.layers.datetime.document.close();
	} else if (ns6up1){
		document.getElementById("datetime").innerHTML = dispDate;
		
	} else if (ie4up1){
		datetime.innerHTML = dispDate;
	} setTimeout("nowclock()", 1000);
} 


(function() {
	function j(a, b, c) {
		if (a.addEventListener) a.addEventListener(b, c, false);
		else a.attachEvent && a.attachEvent("on" + b, c)
	}
	function f(a) {
		if (typeof window.onload != "function") window.onload = a;
		else {
			var b = window.onload;
			window.onload = function() {
				b();
				a()
			}
		}
	}
	function g() {
		var a = {};
		for (type in {
			Top: "",
			Left: ""
		}) {
			var b = type == "Top" ? "Y": "X";
			if (typeof window["page" + b + "Offset"] != "undefined") a[type.toLowerCase()] = window["page" + b + "Offset"];
			else {
				b = document.documentElement.clientHeight ? document.documentElement: document.body;
				a[type.toLowerCase()] = b["scroll" + type]
			}
		}
		return a
	}
	function k() {
		var a = document.body,
		b;
		if (window.innerHeight) b = window.innerHeight;
		else if (a.parentElement.clientHeight) b = a.parentElement.clientHeight;
		else if (a && a.clientHeight) b = a.clientHeight;
		return b
	}
	function h(a) {
		this.parent = document.body;
		this.createEl(this.parent, a);
		this.size = Math.random() * 5 + 5;
		this.el.style.width = Math.round(this.size) + "px";
		this.el.style.height = Math.round(this.size) + "px";
		this.maxLeft = document.body.offsetWidth - this.size;
		this.maxTop = document.body.offsetHeight - this.size;
		this.left = Math.random() * this.maxLeft;
		this.top = g().top + 1;
		this.angle = 1.4 + 0.2 * Math.random();
		this.minAngle = 1.4;
		this.maxAngle = 1.6;
		this.angleDelta = 0.01 * Math.random();
		this.speed = 2 + Math.random()
	}
	var i = false;
	f(function() {
		i = true
	});
	window.createSnow = function(a, b) {
		if (i) {
			var c = [];
			setInterval(function() {
				b > c.length && Math.random() < b * 0.0025 && c.push(new h(a));
				for (var e = g().top, l = k(), d = c.length - 1; d >= 0; d--) if (c[d]) if (c[d].top < e || c[d].top > e + l) {
					c[d].remove();
					c.splice(d, 1)
				} else {
					c[d].move();
					c[d].draw()
				}
			},
			40);
			j(window, "scroll",
			function() {
				for (var e = c.length - 1; e >= 0; e--) c[e].draw()
			})
		} else f(function() {
			createSnow(a, b)
		})
	};
	h.prototype = {
		createEl: function(a, b) {
			this.el = document.createElement("img");
			this.el.setAttribute("src", b + "snow" + Math.floor(Math.random() * 4) + ".gif");
			this.el.style.position = "absolute";
			this.el.style.display = "block";
			this.el.style.zIndex = "99999";
			this.parent.appendChild(this.el)
		},
		move: function() {
			if (this.angle < this.minAngle || this.angle > this.maxAngle) this.angleDelta = -this.angleDelta;
			this.angle += this.angleDelta;
			this.left += this.speed * Math.cos(this.angle * Math.PI);
			this.top -= this.speed * Math.sin(this.angle * Math.PI);
			if (this.top < 0) this.top = this.maxTop;
			else if (this.top > this.maxTop) this.top = 0;
			if (this.left < 0) this.left = this.maxLeft;
			else if (this.left > this.maxLeft) this.left = 0
		},
		draw: function() {
			this.el.style.top = Math.round(this.top) + "px";
			this.el.style.left = Math.round(this.left) + "px"
		},
		remove: function() {
			this.parent.removeChild(this.el)
		}
	}
})();

	