

<!-- 侧边栏 -->
		<div id="sidebar">
			<div id="side_top"></div>
			<div id="side_center">
				<ul>
					<li>
						<h2>Is Me</h2>
						<div id="meinfo">
							<p><img src="<?php bloginfo('url');?>/wp-content/themes/ilovelove/images/lz-150x150.png" width="60" height="60"/>
								ID：lzan13(正仔)<br/>
								QQ：783485225<br/>
								e-mail:lzan13@sina.com<br/>
								@游戏 @动漫 @科技 @编程<br/>
								个人名言：慢慢来，一步一个脚印！</p>
						</div><!-- me info end -->
					</li>
					<li>
						<h2>站点功能</h2>
						<div id="site_tools">
							<!--<a id="showlogin" href="###">工具</a>
							<a id="showcalendar" href="###">日历</a>-->
							<ul id="login">
								<?php wp_register();?>
								<li><?php wp_loginout();?></li>
								<?php wp_meta();?>
							</ul>
							<!--
							<ul id="calendar">
								<?php get_calendar();?>
							</ul>-->
							<div class="clear-both"></div>
						</div>
					</li>
					<li>
						<h2><?php _e('最近发表');?></h2>
						<ul id="new-posts">
							<?php require('wp-blog-header.php'); ?>
							<?php get_archives('postbypost', 10); ?>
							<div class="clear-both"></div>
						</ul>
					</li>
					<!-- 分类 -->
					<li>
						<h2><?php _e('文章分类');?></h2>
						<ul class="sort_column">
							<?php wp_list_cats('sort_column=name');?>
							<div class="clear-both"></div>
						</ul>
					</li>
					<!-- 归档 -->
					<li class="post_monthly">
						<h2><?php _e('日期归档');?></h2>
						<ul class="sort_column">
							<?php wp_get_archives('type=monthly');?>
							<div class="clear-both"></div>
						</ul>
					</li>
					<li>
						<h2>最新评论</h2>
						<div id="new_comments">
							<?php
								global $wpdb;
								$sql = "SELECT DISTINCT ID, post_title, post_password, comment_ID,
									comment_post_ID, comment_author, comment_author_email, comment_date_gmt, comment_approved,
									comment_type,comment_author_url,
									SUBSTRING(comment_content,1,16) AS com_excerpt
									FROM $wpdb->comments
									LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID =
									$wpdb->posts.ID)
									WHERE comment_approved = '1' AND comment_type = '' AND
									post_password = ''
									ORDER BY comment_date_gmt DESC
									LIMIT 20";
								$comments = $wpdb->get_results($sql);
								$output = $pre_HTML;
								$output .= "<ul>";
								foreach ($comments as $comment) {
									if(strip_tags($comment->comment_author) != "正仔" ){
										$output .= '<li>'.get_avatar($comment, 22);
										$output .='<a href="'.get_permalink($comment->ID).'#comment-'.$comment->comment_ID . 
											'" title="评论来自：' .$comment->post_title . '">'.strip_tags($comment->com_excerpt).'…</a></li>';
									}
								}
								$output .= '<div class="clear-both"></div></ul>';
								$output .= $post_HTML;
								echo $output;
							?> 
						</div><!-- new_comments   end -->
					</li>
					<li>
						<h2>我的标签</h2>
						<div id="my-tags"><?php wp_tag_cloud('smallest=8&largest=22'); ?></div>
					</li>
					
					<!-- 日历 -->
					<!--
					<li id="calendar">
						<h2><?php _e('ri li');?></h2>
						<?php get_calendar();?>
					</li> 
					<div class="side_bottom"></div>-->
				</ul>
				<div class="clear-both"></div>
			</div><!-- side_center end -->
			<div id="side_bottom"></div>
		</div>