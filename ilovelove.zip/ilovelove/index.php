<?php get_header();?>
<div class="go">
	<a title="返回顶部" class="top" href="#gotop"></a>
	<a title="返回底部" class="bottom" href="#gobottom"></a>
</div>
</div>
<!-- 整个外围包装 -->
<div id="wrapper">
	<?php get_sidebar();?>
	<div id="center_box">
		<!-- 头部 -->
		<div id="header">
			
		</div>
		<!-- 中间内容部分，-->
		<div id="container">
			<?php if(have_posts()):?>
				<?php while(have_posts()):?>
					<?php the_post();?>
					<div class="post" id="post-<?php the_ID();?>">
						<div class="entry">
							<div class="index">
								<div class="time">
									<span class="top"><?php the_time('Y'); ?></span>
									<span class="top">read</span>
									<span class="bottom"><?php the_time('m/d'); ?></span>
									<span class="bottom"><?php $post_id = get_the_ID(); echo getPostViews($post_id); ?></span>
								</div>
								<!-- 显示日志标题，-->
								<h2><a href="<?php the_permalink();?>" title="<?php the_title();?>"><?php the_title();?></a></h2>
								<div class="postmetadata">
									<span><?php the_category(',')?>&nbsp;&nbsp;&nbsp;</span>
									<span class="post_tag"><?php _e('');?></span><?php the_tags('','&nbsp;,&nbsp;',''); ?>
									<!--<span><a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>" title="<?php printf( __( 'View all posts by %s', 'zbench' ), get_the_author() ) ?>" rel="author"><?php the_author(); ?></a><span>-->
									
									<?php edit_post_link(__('编辑','MELove'), '[', ']'); ?>
								</div>
							</div>
							
							<?php //thumb_img($post->post_content);?>
							<?php include(TEMPLATEPATH.'/post_thumb.php')?>
							
							<!-- 显示日志内容，the_content()是全部文章，the_excerpt()是文章摘要！ -->
							<div class="post_content">
								<p>
									<div id="thumb">
										<img src="<?php echo $imageUrl;?>">
									</div>
									<?php 
										echo '<span>';
										echo mb_strimwidth(strip_tags(get_the_content()),0,3," ");
										echo '</span>';
										echo mb_strimwidth(strip_tags(get_the_content()),1,300," ").'…';
									/*the_excerpt();the_content(__('Read more...', 'inove'));*/ 
									?>
									<a rel="more-link" href="<?php the_permalink()?>" title="<?php the_title(); ?>">【阅读全文】</a>
								</p>
							</div>
						</div><!-- entry结束 -->
					</div><!-- post结束 -->
				<?php endwhile;?>
				<div class="navigation">
					<!-- 调用上一页下一页方法，-->
					<p><span><?php previous_posts_link('&nbsp;上&nbsp;', 0); ?><span><?php next_posts_link('&nbsp;下&nbsp;', 0); ?></span></p>
				</div>
				<?php else:?>
				<div class="post">
					<h2><?php _e('No Found');?>
				</div>
			<?php endif;?>
			<div class="clear-both"></div>			
		</div><!-- container 结束 -->
	</div><!-- center_box 结束 -->
	<div class="clear-both"></div>
</div>

<?php get_footer();?>