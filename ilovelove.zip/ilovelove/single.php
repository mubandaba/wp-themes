<?php
/*
Template Name: single page
*/
/**
 * The template for displaying single page.
 *
 * @package WordPress
 * @subpackage my-theme
 * @since ilovelove ilovelove 1.0
 */
?>
<?php get_header();?>
<div class="go">
	<a title="返回顶部" class="top" href="#gotop"></a>
	<a title="评论留言" class="feedback" href="#gocomments"></a>
	<a title="返回底部" class="bottom" href="#gobottom"></a>
</div>
<!-- 整个外围包装 -->
<div id="wrapper">
	<?php get_sidebar();?>
	<div id="center_box">
		<!-- 头部 -->
		<div id="header">
			<div id="address">
				<img src="<?php bloginfo('url');?>/wp-content/themes/ilovelove/images/post_home.png" width="18" height="18"/>
				<div>
					<a href="<?php bloginfo('url');?>" title="首页">&nbsp;Melove</a>&nbsp;&gt;&nbsp;
					<?php 
						$categorys = get_the_category(); 
						$category = $categorys[0];
						echo(get_category_parents($category->term_id,true,'&nbsp;&gt;&nbsp;')); 
					?>
					<a href="#"><?php the_title();?></a>
				</div>
			</div>
		</div>
		<!-- 中间内容部分，-->
		<div id="container">
			<?php if(have_posts()):?>
				<?php while(have_posts()):?>
					
					<?php setPostViews(get_the_ID()); ?> <!-- 设置浏览数 -->
					<?php the_post();?>
					<div class="post" id="post-<?php the_ID();?>">
						<!-- 显示日志标题，-->
						<h2><?php the_title();?></h2>
						<div class="bg_title"><img src="<?php bloginfo('url');?>/wp-content/themes/ilovelove/images/title-bg.png"/></div>
						<div class="post_info">
							<img src="<?php bloginfo('url');?>/wp-content/themes/ilovelove/images/post_time.png" width="18" height="18">
							<span><?php the_time('Y年m月d日 H时m分s秒'); ?></span>
							<img src="<?php bloginfo('url');?>/wp-content/themes/ilovelove/images/post_comments.png" width="18" height="18">
							<span><?php comments_number('么有人来扯此文(⊙o⊙)…', '有 1 位蛋友轻轻扯了一下', '有 % 位蛋友轻轻扯了一下' ); ?></span>
							<img src="<?php bloginfo('url');?>/wp-content/themes/ilovelove/images/post_jiangyou.gif" width="18" height="18">
							<span class="look_number">打酱油的有：<?php echo getPostViews(get_the_ID()); ?></span>
						</div>
						<div class="entry">
							<!-- 显示日志内容，-->
							<div class="post_content">
								<?php the_content();?>
								<?php link_pages('<p><strong>Pages:</strong>','</p>','number');?>
							</div>
							
						</div><!-- entry结束 -->
						<div class="postnextorprevious">
							<span class="post-previous"><?php previous_post_link('%link');?></span>
							<span class="post-next"><?php next_post_link('%link');?></span>
							<div class="clear-both"></div>
						</div>
						<p>
						<!-- Baidu Button BEGIN -->
							<div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare">
							<a class="bds_tsina"></a>
							<a class="bds_qzone"></a>
							<a class="bds_tqq"></a>
							<a class="bds_renren"></a>
							<a class="bds_t163"></a>
							<a class="bds_tieba"></a>
							<a class="bds_baidu"></a>
							<a class="bds_douban"></a>
							<a class="bds_tsohu"></a>
							<a class="bds_kaixin001"></a>
							<span class="bds_more"></span>
							<a class="shareCount"></a>
							</div>
							<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=1445537" ></script>
							<script type="text/javascript" id="bdshell_js"></script>
							<script type="text/javascript">
							document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000)
							</script>
						<!-- Baidu Button END -->
						</p>
						<div class="include_meinfo">
							<?php include(TEMPLATEPATH.'/meinfo.php');?>
						</div>
						<div class="comments_template">
							<?php comments_template(); ?>
						</div>
						
					</div>
				<?php endwhile;?>
				<?php else:?>
				<div class="post">
					<h2><?php _e('No Found');?></h2>
				</div>
			<?php endif;?>
		</div><!-- container结束 -->
	</div>
	<div class="clear-both"></div>
</div>

<?php get_footer();?>