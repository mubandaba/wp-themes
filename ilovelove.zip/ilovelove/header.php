<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">

	<title><?php if ( is_home() ) {
         bloginfo('name'); echo " -> "; bloginfo('description');
     } elseif ( is_category() ) {
         single_cat_title(); echo " <- "; bloginfo('name');
     } elseif (is_single() || is_page() ) {
         single_post_title(); echo " <- "; bloginfo('name');
     } elseif (is_search() ) {
         echo "搜索结果"; echo " <- "; bloginfo('name');
     } elseif (is_404() ) {
         echo '呃，错了哦'; echo " <- "; bloginfo('name');
     } else {
         wp_title('什么情况！？',true);
     } ?></title>

	<?php
		if (is_home() || is_page()) {
			// 将以下引号中的内容改成你的主页description
			$description = "Melove - 爱我所爱，得 我爱！分享我所爱的，也许就是你喜欢的！";

			// 将以下引号中的内容改成你的主页keywords
			$keywords = "技术,分享,android,java,Melvoe,爱我所爱,编程";
		}
		elseif (is_single()) {
			$description1 = get_post_meta($post->ID, "description", true);
			$description2 = mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 200, "…");

			// 填写自定义字段description时显示自定义字段的内容，否则使用文章内容前200字作为描述
			$description = $description1 ? $description1 : $description2;
		   
			// 填写自定义字段keywords时显示自定义字段的内容，否则使用文章tags作为关键词
			$keywords = get_post_meta($post->ID, "keywords", true);
			if($keywords == '') {
				$tags = wp_get_post_tags($post->ID);    
				foreach ($tags as $tag ) {        
					$keywords = $keywords . $tag->name . ", ";    
				}
				$keywords = rtrim($keywords, ', ');
			}
		}
		elseif (is_category()) {
			$description = category_description();
			$keywords = single_cat_title('', false);
		}
		elseif (is_tag()){
			$description = tag_description();
			$keywords = single_tag_title('', false);
		}
		$description = trim(strip_tags($description));
		$keywords = trim(strip_tags($keywords));
	?>
	<meta name="description" content="<?php echo $description; ?>" />
	<meta name="keywords" content="<?php echo $keywords; ?>" />

	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
	<meta name="generator" content="WordPress<?php bloginfo('version'); ?>; charset=<?php bloginfo('charset'); ?>" />
	
	<link rel="icon" href="<?php bloginfo('url');?>/favicon.ico" type="image/x-icon" />
	<link rel="shortcut icon" href="<?php bloginfo('url');?>/favicon.ico" type="image/x-icon" />
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
	<link rel="alternate" href="<?php bloginfo('rss2_url'); ?>" type="application/rss+xml" title="RSS 2.0 - 所有文章"/>
	<link rel="alternate" href="<?php bloginfo('comments_rss2_url'); ?>" type="application/rss+xml" title="RSS 2.0 - 所有评论"/>
	<link rel="alternate" href="<?php bloginfo('rss_url'); ?>" type="text/xml"title="RSS .92" />
	<link rel="alternate" href="<?php bloginfo('atom_url'); ?>" type="application/atom+xml" title="Atom 0.3" />
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<!--	<link href="<?php bloginfo('url');?>/wp-content/themes/ilovelove/css/highlight.css" rel="Stylesheet" type="text/css"/>-->

	<link type="text/css" rel="stylesheet" href="css/SyntaxHighlighter.css"></link>  
	<script language="javascript" src="js/shCore.js"></script>  
	<script language="javascript" src="js/shBrushCSharp.js"></script>  
	<script language="javascript" src="js/shBrushXml.js"></script>  
	<script language="javascript">  
		dp.SyntaxHighlighter.ClipboardSwf = '/flash/clipboard.swf';  
		dp.SyntaxHighlighter.HighlightAll('code');  
	</script> 

	<?php wp_get_archives('type=monthly&format=link'); ?>
	<?php //comments_popup_script();//off by default  ?>
	<!-- <?php //wp_head(); ?> -->
	
</head>
<?php flush(); ?><!-- 刷新php缓存，用于提高程序运行效率 -->
<body><a style="position:absolute; top:0px; left:0px;" name="gotop"></a>
	<div id="top">
		<div id="tool">
			<!-- 这是在站长登录后显示在最上边的工具条，不要可注释掉 -->
			<?php wp_footer();?>
		</div><!-- tool  end -->
		<div id="logo">
			<!-- 页面导航 -->
			<div id="nav">
				<ul>
					<li><a href="<?php bloginfo('url');?>">首页</a></li>
					<?php wp_list_pages('exclude=12&title_li=' ); ?>
				</ul>
			</div><!-- nav end -->
			<!--<div id="rundate">
				<p id="datetime">
						<script>
							var runDate = new Date(2013, 1, 14, 5, 2, 1);
							var ns4up1 = (document.layers) ? 1 : 0;  // browser sniffer

							var ie4up1 = (document.all&&(navigator.appVersion.indexOf("MSIE 4") == -1)) ? 1 : 0;

							var ns6up1 = (document.getElementById&&!document.all) ? 1 : 0;

							function nowclock() {
							if (!ns4up1 && !ie4up1 && !ns6up1) return false;
							var today=new Date();
							//获得年份
							var year=today.getFullYear();
							//获得月份
							var month=today.getMonth()+1;
							//获得日期
							var day=today.getDate();
							//获取星期
							var week=today.getDay();
							switch(week){
								case 0:week="星期日";break;
								case 1:week="星期一";break;
								case 2:week="星期二";break;
								case 3:week="星期三";break;
								case 4:week="星期四";break;
								case 5:week="星期五";break;
								case 6:week="星期六";break;
								}
							//获得小时
							var hours = today.getHours();
							//获得分钟
							var minutes = today.getMinutes();
							if( minutes < 10 ){
								minutes = "0" + minutes;
								}
							//获得秒
							var seconds = today.getSeconds();
							if(seconds<10){
								seconds = "0" + seconds;
							}
							tempDate = today - runDate;
							//runYears = tempDate/1000/60/60/60/24/30/12;
							//runMonths = tempDate/1000/60/60/24/30;
							runDay = Math.floor(tempDate/1000/60/60/24);
							runHours = Math.floor(tempDate/1000/60/60%24);
							runMinutes = Math.floor(tempDate/1000/60%60);
							runSeconds = Math.floor(tempDate/1000%60);
							
							dispRunDate ="<span>" + runDay + "</span>" + "天" + "<span>" + runHours + "</span>" + "小时" + "<span>" + runMinutes + "</span>" + "分";
							dispDate = year + "年" + month + "月" + day+ "日, " + hours + ":" + minutes + " " + week 
								+ "<br/><span>本站已运行：" + dispRunDate + "</span>";
							
							if (ns4up1) {
								document.layers.datetime.document.write(dispDate);
								document.layers.datetime.document.close();
							} else if (ns6up1){
								document.getElementById("datetime").innerHTML = dispDate;
								
							} else if (ie4up1){
								datetime.innerHTML = dispDate;
							} setTimeout("nowclock()", 60000);
							} nowclock();
							//
						</script>
						</p>
			</div>-->
			<!-- 搜索框 -->
			<div id="search">
				<?php include(TEMPLATEPATH.'/searchform.php');?>
			</div>
		</div><!-- logo end -->
	</div><!-- top end -->
	
		