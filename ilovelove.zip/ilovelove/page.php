<?php
/*
Template Name: default page
*/
/**
 * The template for displaying default page.
 *
 * @package WordPress
 * @subpackage my-theme
 * @since ilovelove ilovelove 1.0
 */
?>
<?php get_header();?>

<!-- 整个外围包装 -->
<div id="wrapper">
	<?php get_sidebar();?>
	<div id="center_box">
		<!-- 头部 -->
		<div id="header">
			<div id="address">
				<img src="<?php bloginfo('url');?>/wp-content/themes/ilovelove/images/post_home.png" width="18" height="18"/>
				<a href="<?php bloginfo('url');?>" title="首页">&nbsp;Melove</a>&nbsp;&gt;&nbsp;<a href="#"><?php the_title();?></a>
			</div>
		</div>
		<!-- 中间内容部分，-->
		<div id="container">
			<?php if(have_posts()):?>
				<?php while(have_posts()):?>
					<?php the_post();?>
					<div class="post" id="post-<?php the_ID();?>">
						<!-- 显示日志标题，-->
						<h2><?php the_title();?></h2>
						<!--<div class="bg_title"><img src="<?php bloginfo('url');?>/wp-content/themes/my-theme/images/bg_title.png"/></div>-->
						<div class="entry">
							<div class="info">
								<!-- 显示日志内容，-->
								<div class="post_content"><?php the_content();?></div>
							</div>
						</div>
						<div class="comments_template">
							<?php comments_template(); ?>
						</div>
					</div><!-- post结束 -->
				<?php endwhile;?>
				<div class="navigation">
					<!-- 调用上一页下一页方法，-->
					<?php posts_nav_link();?>
				</div>
				<?php else:?>
				<div class="post">
					<h2><?php _e('No Found');?>
				</div>
			<?php endif;?>
		</div><!-- container结束 -->
	</div>
	<div class="clear-both"></div>
</div>

<?php get_footer();?>