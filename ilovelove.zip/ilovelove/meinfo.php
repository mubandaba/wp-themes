<?php
/*
Template Name:me info
*/
/**
 * The template for displaying me info.
 *
 * @package WordPress
 * @subpackage my-theme
 * @since ilovelove ilovelove 1.0
 */
?>
<div class="meinfo">
	<img src="<?php bloginfo('url');?>/wp-content/themes/ilovelove/images/lz-150x150.png" width="60" height="60"/>
	<p> 
		<span>订阅本站：</span><a href="<?php bloginfo('rss2_url'); ?>" target="_blank"><?php bloginfo('name'); ?></a><br/>
		<span>标　　签：</span><?php the_tags('','&nbsp;,&nbsp;',''); ?><?php _e('&nbsp;&nbsp;分类：');?><?php the_category(',')?><br/>
		<span>加载用时：</span><span>加载本页用时：<?php timer_stop(1); ?> s</span><br/>
		<span>发表日期：</span><span><?php the_time('正仔新纪元 Y年m月d日 H时m分s秒') ?></span><br/>
		<span>浏览热度：</span><span>已有 <?php echo getPostViews(get_the_ID()); ?> 基友提着酱油瓶淡定的路过……</span><br/>
		<span>本文地址：</span><span><a rel="more-link" href="<?php the_permalink()?>" title="<?php the_title(); ?>"><?php the_permalink()?></a></span><br/>
		<span>特別注明：</span><span>部分原创-自由转载-不得商用-注名出处：<a href="<?php bloginfo('url'); ?>" target="_blank"><?php bloginfo('name'); ?></a><br/> 
		<span>　　　　　</span><span>部分内容为抄录转载分享，如果有侵犯原作者权益行为请通知我，会及时处理删除！</span>
	</p>
	<div class="clear-both"></div>
</div>