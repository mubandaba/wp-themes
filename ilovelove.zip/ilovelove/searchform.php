<form method="get" id="searchform" action="<?php echo home_url(); ?>">
	<div>
		<label for="s"><!--<?php _e('Keyword(s)','victorianxmas');?>--></label>
		<input 
			id="s" 
			class="text" 
			type="text" 
			placeholder="<?php _e('站内搜索');?>"
			name="s" 
			/>
		<input id="searchsubmit" class="submit" type="submit" name="submit" value="搜索" />
	</div>
</form>