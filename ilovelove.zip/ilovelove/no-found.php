<div class="no-found-msg">
	<img src="<?php bloginfo('url');?>/wp-content/themes/ilovelove/images/no_found_bg.png" />
	
	<p>纳尼！？</p>
	<p>没有找到需要的结果？</p>
	<p>是不是搜索的姿势不对呢？</p>
	<p>换个姿势搜索试试！</p>

	<p>什么！？还是不行！？</p>
	<p>人品的问题吧……</p>
	<div class="clear-both"></div>
</div>