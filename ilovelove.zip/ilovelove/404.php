<?php
/**
 * The template for displaying 404 pages (Not Found).
 *
 * @package WordPress
 * @subpackage I_love_love
 * @since i love love 1.0
 */
?>
<?php get_header();?>
<div class="go">
	<a title="返回顶部" class="top" href="#gotop"></a>
	<a title="返回底部" class="bottom" href="#gobottom"></a>
</div>
</div>
<!-- 整个外围包装 -->
<div id="wrapper">
	<?php get_sidebar();?>
	<div id="center_box">
		<!-- 头部 -->
		<div id="header">
			<!--
			<h1><a href="<?php bloginfo('url');?>"><?php bloginfo('name');?></a></h1>
			<?php bloginfo('description');?> -->
		</div>
		<!-- 中间内容部分，-->
		<div id="container">
			<div class="post">
				<div class="no-found-msg">
					<h2>404公益广告</h2>
					<p>　　本站：<a href="<?php bloginfo('url');?>"><?php bloginfo('name');?></a>已经加入404公益广告，帮助他们回家！如果你是站长有自己的博客，也可以加入到行列中来！让我们一起进行工艺活动！<br/></p>
					<p></p>
					<iframe scrolling='no' frameborder='0' src='http://yibo.iyiyun.com/js/yibo404/key/4477' width='550' height='464' style='display:block;'></iframe>
				</div>
			</div><!-- post结束 -->
		</div><!-- container结束 -->
		
	</div>
	<div class="clear-both"></div>
</div>

<?php get_footer();?>