	<div id="footer">
		<div id="footer-box">
			<div class="about-me">
				<p><img src="<?php bloginfo('url');?>/wp-content/themes/ilovelove/images/lz-150x150.png" width="60" height="60"/>
						ID：lzan13(正仔)<br/>
						QQ：783485225<br/>
						e-mail:lzan13@sina.com<br/>
						@游戏 @动漫 @科技 @编程<br/>
						个人名言：慢慢来，一步一个脚印！</p>
			</div>
			<!-- 友情链接 -->
			<div class="lianjie">
				<h3>其它链接</h3>
				<ul>
					<li><a href="<?php bloginfo('url');?>" target="_black">首页</a></li>
					<li><a href="<?php bloginfo('url');?>/sitemap.html" target="_black">网站地图</a></li>
					<li><a href="http://my.paulhost.com/aff.php?aff=268" target="_black">保罗主机</a></li>
				</ul>
			</div>
			<div class="lianjie">
				<h3>关注我</h3>
				<ul>
					<li><a href="http://t.qq.com/wan213344" target="_black">腾讯微博</a></li>
					<li><a href="http://weibo.com/lzan13" target="_black">新浪微博</a></li>
					<li><a href="http://www.facebook.com/home.php?ref=wizard" target="_black">Facebook</a></li>
					<li><a href="https://plus.google.com/u/0/" target="_black">Google+</a></li>
				</ul>
			</div>
			<div class="lianjie">
				<h3>个人站点</h3>
				<ul>
					<li><a href="http://uncleapps.net.tf" target="_black">大叔的Apps</a></li>
					<li><a href="http://pknote.net" target="_black">口袋笔记</a></li>
				</ul>
			</div>
			<div class="lianjie">
				<h3>other Links</h3>
				<ul>
					<li><p>版权所有&nbsp;&copy;&nbsp;<a href="<?php bloginfo('url');?>" title="<?php bloginfo('name');?>"><?php bloginfo('name');?></a></p></li>
					<!-- 尊重作者，保留出处 来自 Melove 我爱，爱我所爱，得我爱！http://www.melove.net -->
					<li><span>Theme by&nbsp;</span><a href="http://www.melove.net" target="_black">Melove</a></li>
				</ul>
			</div>
			
			<div class="clear-both"></div>
		</div><!-- footer-box 结束 -->
		
	</div>

	
	
	<a style="position:absolute;" name="gobottom"></a>
	<script type="text/javascript" src="<?php bloginfo('url');?>/wp-content/plugins/syntaxhighlighter_3.0.83/scripts/shCore.js"></script>
	<script type="text/javascript" src="<?php bloginfo('url');?>/wp-content/plugins/syntaxhighlighter_3.0.83/scripts/shBrushBash.js"></script>
	<script type="text/javascript" src="<?php bloginfo('url');?>/wp-content/plugins/syntaxhighlighter_3.0.83/scripts/shBrushCpp.js"></script>
	<script type="text/javascript" src="<?php bloginfo('url');?>/wp-content/plugins/syntaxhighlighter_3.0.83/scripts/shBrushCSharp.js"></script>
	<script type="text/javascript" src="<?php bloginfo('url');?>/wp-content/plugins/syntaxhighlighter_3.0.83/scripts/shBrushCss.js"></script>
	<script type="text/javascript" src="<?php bloginfo('url');?>/wp-content/plugins/syntaxhighlighter_3.0.83/scripts/shBrushDelphi.js"></script>
	<script type="text/javascript" src="<?php bloginfo('url');?>/wp-content/plugins/syntaxhighlighter_3.0.83/scripts/shBrushDiff.js"></script>
	<script type="text/javascript" src="<?php bloginfo('url');?>/wp-content/plugins/syntaxhighlighter_3.0.83/scripts/shBrushGroovy.js"></script>
	<script type="text/javascript" src="<?php bloginfo('url');?>/wp-content/plugins/syntaxhighlighter_3.0.83/scripts/shBrushJava.js"></script>
	<script type="text/javascript" src="<?php bloginfo('url');?>/wp-content/plugins/syntaxhighlighter_3.0.83/scripts/shBrushJScript.js"></script>
	<script type="text/javascript" src="<?php bloginfo('url');?>/wp-content/plugins/syntaxhighlighter_3.0.83/scripts/shBrushPhp.js"></script>
	<script type="text/javascript" src="<?php bloginfo('url');?>/wp-content/plugins/syntaxhighlighter_3.0.83/scripts/shBrushPlain.js"></script>
	<script type="text/javascript" src="<?php bloginfo('url');?>/wp-content/plugins/syntaxhighlighter_3.0.83/scripts/shBrushPython.js"></script>
	<script type="text/javascript" src="<?php bloginfo('url');?>/wp-content/plugins/syntaxhighlighter_3.0.83/scripts/shBrushRuby.js"></script>
	<script type="text/javascript" src="<?php bloginfo('url');?>/wp-content/plugins/syntaxhighlighter_3.0.83/scripts/shBrushScala.js"></script>
	<script type="text/javascript" src="<?php bloginfo('url');?>/wp-content/plugins/syntaxhighlighter_3.0.83/scripts/shBrushSql.js"></script>
	<script type="text/javascript" src="<?php bloginfo('url');?>/wp-content/plugins/syntaxhighlighter_3.0.83/scripts/shBrushVb.js"></script>
	<script type="text/javascript" src="<?php bloginfo('url');?>/wp-content/plugins/syntaxhighlighter_3.0.83/scripts/shBrushXml.js"></script>
	<link type="text/css" rel="stylesheet" href="<?php bloginfo('url');?>/wp-content/plugins/syntaxhighlighter_3.0.83/styles/shCore.css"/>
	<link type="text/css" rel="stylesheet" href="<?php bloginfo('url');?>/wp-content/plugins/syntaxhighlighter_3.0.83/styles/shThemeDefault.css"/>
	<script type="text/javascript">
		SyntaxHighlighter.config.clipboardSwf = '<?php bloginfo('url');?>/wp-content/plugins/syntaxhighlighter_3.0.83/scripts/clipboard.swf';
		SyntaxHighlighter.all();
	</script>
	<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=1445537" ></script>
	<script type="text/javascript" id="bdshell_js"></script>
	<script type="text/javascript">
		document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000)
	</script>
	<!-- 加载jQuery库 -->
	<?php 
		$siteurl = get_option('siteurl'); 
		if (substr($siteurl, 0, 16)== 'http://localhost'): ?>
			<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.min.js"></script>
		<?php else: ?>
			<script type="text/javascript" src="http://lib.sinaapp.com/js/jquery/1.9.0/jquery.min.js"></script>
	<?php endif; ?>
	<script type="text/javascript">
		$(".links a").each(function(e){
		$(this).prepend("<img src=http://www.google.com/s2/favicons?domain="+this.href.replace(/^(http:\/\/[^\/]+).*$/, '$1').replace( 'http://', '' )+">");
		});
	</script>

	<script type="text/javascript">
	(function() {
		function j(a, b, c) {
			if (a.addEventListener) a.addEventListener(b, c, false);
			else a.attachEvent && a.attachEvent("on" + b, c)
		}
		function f(a) {
			if (typeof window.onload != "function") window.onload = a;
			else {
				var b = window.onload;
				window.onload = function() {
					b();
					a()
				}
			}
		}
		function g() {
			var a = {};
			for (type in {
				Top: "",
				Left: ""
			}) {
				var b = type == "Top" ? "Y": "X";
				if (typeof window["page" + b + "Offset"] != "undefined") a[type.toLowerCase()] = window["page" + b + "Offset"];
				else {
					b = document.documentElement.clientHeight ? document.documentElement: document.body;
					a[type.toLowerCase()] = b["scroll" + type]
				}
			}
			return a
		}
		function k() {
			var a = document.body,
			b;
			if (window.innerHeight) b = window.innerHeight;
			else if (a.parentElement.clientHeight) b = a.parentElement.clientHeight;
			else if (a && a.clientHeight) b = a.clientHeight;
			return b
		}
		function h(a) {
			this.parent = document.body;
			this.createEl(this.parent, a);
			this.size = Math.random() * 5 + 12;
			this.el.style.width = Math.round(this.size) + "px";
			this.el.style.height = Math.round(this.size) + "px";
			this.maxLeft = document.body.offsetWidth - this.size;
			this.maxTop = document.body.offsetHeight - this.size;
			this.left = Math.random() * this.maxLeft;
			this.top = g().top + 1;
			this.angle = 1.4 + 0.2 * Math.random();
			this.minAngle = 1.4;
			this.maxAngle = 1.6;
			this.angleDelta = 0.01 * Math.random();
			this.speed = 2 + Math.random()
		}
		var i = false;
		f(function() {
			i = true
		});
		window.createSnow = function(a, b) {
			if (i) {
				var c = [];
				setInterval(function() {
					b > c.length && Math.random() < b * 0.0025 && c.push(new h(a));
					for (var e = g().top, l = k(), d = c.length - 1; d >= 0; d--) if (c[d]) if (c[d].top < e || c[d].top > e + l) {
						c[d].remove();
						c.splice(d, 1)
					} else {
						c[d].move();
						c[d].draw()
					}
				},
				20);
				j(window, "scroll",
				function() {
					for (var e = c.length - 1; e >= 0; e--) c[e].draw()
				})
			} else f(function() {
				createSnow(a, b)
			})
		};
		h.prototype = {
			createEl: function(a, b) {
				this.el = document.createElement("img");
				this.el.setAttribute("src", b + "snow" + Math.floor(Math.random() * 10) + ".png");
				this.el.style.position = "absolute";
				this.el.style.display = "block";
				this.el.style.zIndex = "99999";
				this.parent.appendChild(this.el)
			},
			move: function() {
				if (this.angle < this.minAngle || this.angle > this.maxAngle) this.angleDelta = -this.angleDelta;
				this.angle += this.angleDelta;
				this.left += this.speed * Math.cos(this.angle * Math.PI);
				this.top -= this.speed * Math.sin(this.angle * Math.PI);
				if (this.top < 0) this.top = this.maxTop;
				else if (this.top > this.maxTop) this.top = 0;
				if (this.left < 0) this.left = this.maxLeft;
				else if (this.left > this.maxLeft) this.left = 0
			},
			draw: function() {
				this.el.style.top = Math.round(this.top) + "px";
				this.el.style.left = Math.round(this.left) + "px"
			},
			remove: function() {
				this.parent.removeChild(this.el)
			}
		}
	})();
	</script>
	<script type="text/javascript">
		//createSnow('<?php bloginfo('url');?>/wp-content/themes/ilovelove/images/snow/', 35);
	</script>

	<script type="text/javascript">
        	$(function(){
				$('#showcalendar').click(function (event) {
					//取消事件冒泡  
					//event.stopPropagation(); 
					//按钮的toggle,如果div是可见的,点击按钮切换为隐藏的;如果是隐藏的,切换为可见的。  
					$('#login').slideUp('slow');
					$('#calendar').slideDown('slow');
				}); 
				$('#showlogin').click(function (event) {
					//取消事件冒泡  
					//event.stopPropagation(); 
					//按钮的toggle,如果div是可见的,点击按钮切换为隐藏的;如果是隐藏的,切换为可见的。  
					$('#calendar').slideUp('slow');
					$('#login').slideDown('slow');
				}); 
            });
        </script>

</body>
</html>