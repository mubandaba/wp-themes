<?php
     if (isset($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
         die ('Please do not load this page directly. Thanks!');
?>
<h4 id="comment-title">
	<a name="gocomments"></a>
	<?php comments_number('么人鸟我(⊙o⊙)…', '有一会蛋友轻轻的扯了一下！', '已有 % 位蛋友扯了一下O(∩_∩)O~' ); ?>
</h4>
<?php if ( have_comments() ) : ?>
   

    <ul class="comment-list">
        <?php wp_list_comments( array( 'callback' => 'mytheme_comment', 'style' => 'ol' ) ); ?>
    </ul>

    <div class="comments-navigation">
        <div class="alignleft"><?php previous_comments_link() ?></div>
        <div class="alignright"><?php next_comments_link() ?></div>
    </div>
    
<?php else : // no comments so far
    if ('open' == $post->comment_status) :
        // If comments are open, but there are no comments.
    else :
        if ( is_single() ){ echo"<p>此页面评论功能已关闭！</p>"; }
    endif;
endif;


// 留言评论表单 Form
if ('open' == $post->comment_status) : ?>

    <div id="comment-form">
		<h4 id="form-title"><?php comment_form_title( '有空过来扯一下O(∩_∩)O~', '扯一下 %s O(∩_∩)O~' ); ?></h4>
		
		<div class="cancel-comment-reply">
			<small><?php cancel_comment_reply_link(); ?></small>
		</div>
    
		<?php if ( get_option('comment_registration') && !$user_ID ) : ?>
			<p>You must be <a href="<?php echo get_option('siteurl'); ?>/wp-login.php?redirect_to=<?php echo urlencode(get_permalink()); ?>">logged in</a> to post a comment.</p>
		<?php else : ?>
		
			<form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform">

				<?php if ( $user_ID ) : ?>
					<p><label>以</label><a href="<?php echo get_option('siteurl'); ?>/wp-admin/profile.php"><?php echo $user_identity; ?></a> 身份扯一下！
					<a href="<?php echo wp_logout_url(get_permalink()); ?>" title="Log out of this account">退出</a></p>
				<?php else : ?>
					<?php if(($comment_author != "")&&($comment_author != null)):?>
						<p><label>欢　迎:</label><?php echo $comment_author?></p>
					<?php endif;?>
					<p><label for="author">昵　称:</label><input type="text" name="author" id="author" 
					value="<?php echo $comment_author; ?>" size="26" tabindex="1" /><span>*</span>必填</p>
					
						<p><label for="email">邮　箱:</label><input type="text" name="email" id="email" 
					value="<?php echo $comment_author_email; ?>" size="26" tabindex="2" /><span>*</span>必填(<span id="msg">用来显示<a href="#">Gravata</a>头像，不会向别人透漏</span>)</p>
					
						<p><label for="url">网　址:</label><input type="text" name="url" id="url" 
					value="<?php echo $comment_author_url; ?>" size="26" tabindex="3" /><span></span>你自己的网站，可不填</p>
				
				<?php endif; ?>
				<!-- Add this line in your form -->
				
				<p><textarea name="comment" id="comment" cols="70" rows="10" tabindex="4" onkeydown="if(event.ctrlKey&&event.keyCode==13){document.getElementById('submit').click();return false};"></textarea></p>
				<!--验证码-->
				<!--
				<p>
					<label for="code">验证码：</label><input type="text" name="code" id="code" onblur="bj()" size="10" />
					<span id="codeError">输入验证码，不区分大小写！</span>
				</p>
				<div id="code1">
					<div id="code_img"></div><a id="renovate" href="javascript:show(4)">看不清，换一张！</a>
				</div>
				-->
				<p>
					<label for="submit"></label> 
					<input id="submit" name="submit" type="submit"  tabindex="5" value="提交（Ctrl+Enter快捷）" />
					<input id="reset" type="reset" value="重置"  />
					<?php comment_id_fields(); ?>
				</p>
				
				<?php do_action('comment_form',  $post->ID); ?>

			</form>

		<?php endif; // If registration required and not logged in ?>
	</div><!--/comment-form-->

<?php endif; // if you delete this the sky will fall on your head ?>