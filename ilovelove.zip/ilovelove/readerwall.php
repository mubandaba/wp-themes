<?php
/*
Template Name: read wall
*/
/**
 * The template for displaying reader wall.
 *
 * @package WordPress
 * @subpackage my-theme
 * @since melove melove 1.0
 */
?>
<?php get_header();?>
<div class="go">
	<a title="返回顶部" class="top" href="#gotop"></a>
	<a title="评论留言" class="feedback" href="#gobottom"></a>
	<a title="返回底部" class="bottom" href="#gobottom"></a>
</div>
<!-- 整个外围包装 -->
<div id="wrapper">
	<?php get_sidebar();?>
	<div id="center_box">
		<!-- 头部 -->
		<div id="header">
			<div id="address">
				<img src="<?php bloginfo('url');?>/wp-content/themes/ilovelove/images/post_home.png" width="18" height="18"/>
				<a href="<?php bloginfo('url');?>" title="首页">&nbsp;Melove</a>&nbsp;&gt;&nbsp;<a href="#"><?php the_title();?></a>
			</div>
		</div>
		<!-- 中间内容部分，-->
		<div id="container">
			<?php if(have_posts()):?>
				<?php while(have_posts()):?>
					<?php the_post();?>
					<div class="post" id="post-<?php the_ID();?>">
						<!-- 显示日志标题，-->
						<h2><?php the_title();?></h2>
						<!--<div class="bg_title"><img src="<?php bloginfo('url');?>/wp-content/themes/my-theme/images/bg_title.png"/></div>-->
						<div class="entry">
							<!-- 显示日志内容，-->
							<div id="readwall-content"><?php the_content();?></div>
							<!-- start wall -->
							<div class="wall">
								<ul>
									<?php
										$query="SELECT COUNT(comment_ID) AS cnt, comment_author, comment_author_url, comment_author_email FROM (SELECT * FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->posts.ID=$wpdb->comments.comment_post_ID) WHERE comment_date > date_sub( NOW(), INTERVAL 24 MONTH ) AND user_id='0' AND comment_author_email != 'lzan13@sina.com' AND post_password='' AND comment_approved='1' AND comment_type='') AS tempcmt GROUP BY comment_author_email ORDER BY cnt DESC LIMIT 40";
										//大家把管理员的邮箱改成你的,最后的这个39是选取多少个头像，大家可以按照自己的主题进行修改,来适合主题宽度
										$wall = $wpdb->get_results($query);
										foreach ($wall as $comment)
										{
											if( $comment->comment_author_url )
											$url = $comment->comment_author_url;
											else $url="#";
											$tmp = "<li><a href='".$url."' target='_blank' title='".$comment->comment_author." (".$comment->cnt." Comments)'>".get_avatar($comment->comment_author_email, 80)."</a></li>";
											$output .= $tmp;
										 }
										echo $output ;
									?>
								</ul>
							</div>
							<!-- end wall -->
							
						</div>
						<div class="comments_template">
							<?php comments_template(); ?>
						</div>
						
					</div><!-- post结束 -->
				<?php endwhile;?>
				
				<?php else:?>
				<div class="post">
					<h2><?php _e('No Found');?>
				</div>
			<?php endif;?>
		</div><!-- container结束 -->
	</div>
	<div class="clear-both"></div>
</div>

<?php get_footer();?>