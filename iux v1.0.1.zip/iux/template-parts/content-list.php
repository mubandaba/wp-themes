<?php $class = ( $wp_query->current_post + 1 === $wp_query->post_count ) ? 'clear last' : 'clear'; ?>

<div id="post-<?php the_ID(); ?>" <?php post_class( $class ); ?>>	

	<?php if ( (get_theme_mod('loop-featured-on', true) == true) && (strpos($post->post_content,'[gallery') === false) ) { ?>

		<?php if( has_post_thumbnail() ) { ?>
			<a target="_blank" class="thumbnail-link" href="<?php the_permalink(); ?>">
				<div class="thumbnail-wrap">
						<?php 
							the_post_thumbnail('iux_list_thumb'); 
						?>
				</div><!-- .thumbnail-wrap -->
			</a>
		<?php } else { ?>
			<?php iux_custom_thumb(300,193,false); ?>
		<?php } ?>

	<?php } ?>

	<header class="entry-header">
	<?php if ( ( get_theme_mod('loop-category-on', true) == true ) && (!is_category() ) ) : ?>

		<span class="entry-category">
			<?php iux_first_category(); ?>	
		</span><!-- .entry-category -->

	<?php endif; ?>

	<h2 class="entry-title"><a target="_blank" href="<?php the_permalink(); ?>"><?php iux_custom_title(); ?></a></h2>
	</header>
	
	<div class="entry-overview 	<?php if ( strpos($post->post_content,'[gallery') !== false ) { echo 'block-div'; } ?>">

		<?php if ( (get_theme_mod('loop-featured-on', true) == true) && (strpos($post->post_content,'[gallery') !== false) ) { ?>

			<ul class="gallery-list">
			    <?php /* Time to create a new loop that pulls out  the first 3 image attachments for this post */
			    $args = array( 'post_type' => 'attachment', 'numberposts' => 4, 'post_status' => null, 'post_parent' => $post->ID );
			    $attachments = get_posts( $args );
			    if ( $attachments ) {
			        foreach ( $attachments as $attachment ) {
			            $image_attributes = wp_get_attachment_image_src( $attachment->ID, 'iux_list_thumb' );
			            echo '<li class="ht_fixed_grid_1_4"><a class="thumb-link" href="';
			            the_permalink();
			            echo '"><div class="thumbnail-wrap">';
			            echo wp_get_attachment_image( $attachment->ID, 'iux_list_thumb' );
			            echo '</div></a></li>'; 
			        }
			       
			    } ?>
	 		</ul>

		<?php } ?>

		<?php get_template_part( 'template-parts/entry', 'meta' ); ?>

		<?php if ( (strpos($post->post_content,'[gallery') === false) && (get_theme_mod('loop-excerpt-on', true) == true )) : ?>

			<div class="entry-summary">
				<?php the_excerpt(); ?>
			</div><!-- .entry-summary -->

		<?php endif; ?>
			
	</div><!-- .entry-overview -->

</div><!-- #post-<?php the_ID(); ?> -->