<?php
/**
 * The sidebar containing the main widget area.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package iux
 */


?>

<aside id="secondary" class="widget-area sidebar">
	<div class="sidebar__inner">
		<?php dynamic_sidebar( 'sidebar-1' ); ?>
	</div><!-- .sidebar__inner -->
</aside><!-- #secondary -->
