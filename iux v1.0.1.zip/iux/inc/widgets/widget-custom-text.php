<?php
/**
 * Custom Text widget.
 *
 * @package    iux
 * @author     HappyThemes
 * @copyright  Copyright (c) 2017, HappyThemes
 * @license    http://www.gnu.org/licenses/gpl-2.0.html
 * @since      1.0.0
 */
class iux_Custom_Text_Widget extends WP_Widget {

	/**
	 * Sets up the widgets.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {

		// Set up the widget options.
		$widget_options = array(
			'classname'   => 'widget_custom_text custom-text-widget',
			'description' => esc_html__( '显示自定义标题、文本、链接。', 'iux' ),
			'customize_selective_refresh' => true
		);

		// Create the widget.
		parent::__construct(
			'iux-custom-text',                                    // $this->id_base
			esc_html__( '&raquo; 自定义文本链接', 'iux' ), // $this->name
			$widget_options                                     // $this->widget_options
		);

		$this->alt_option_name = 'widget_custom_text';
	}

	/**
	 * Outputs the widget based on the arguments input through the widget controls.
	 *
	 * @since 1.0.0
	 */
	public function widget( $args, $instance ) {
		if ( ! isset( $args['widget_id'] ) ) {
			$args['widget_id'] = $this->id;
		}

		// Set up default value
		$title   = ( ! empty( $instance['title'] ) ) ? $instance['title'] : '';
		$content_title   = ( ! empty( $instance['content_title'] ) ) ? $instance['content_title'] : '';
		$content = ( ! empty( $instance['content'] ) ) ? $instance['content'] : '';
		$link = ( ! empty( $instance['link'] ) ) ? $instance['link'] : '';		

		// Output the theme's $before_widget wrapper.

		echo $args['before_widget'];

			if ( $link ) {
				echo '<a class="widget-link" href="' . $link . '" target="_blank">';
			}

			// If the title not empty, display it.
			if ( $title ) {
				echo $args['before_title'] . apply_filters( 'widget_title', $title, $instance, $this->id_base ) . $args['after_title'];
			}

			// Display the ad banner.
			if ( $content_title ) {
				echo '<h4>' . $content_title . '</h4>';
			}

			// Display the ad banner.
			if ( $content ) {
				echo '<div class="custom-text">' . $content . '</div>';
			}

			if ( $link ) {
				echo '</a>';
			}

		// Close the theme's widget wrapper.
		echo $args['after_widget'];

	}

	/**
	 * Updates the widget control options for the particular instance of the widget.
	 *
	 * @since 1.0.0
	 */
	public function update( $new_instance, $old_instance ) {
		$instance            = $old_instance;
		$instance['title']   = sanitize_text_field( $new_instance['title'] );
		$instance['content_title']   = sanitize_text_field( $new_instance['content_title'] );
		if ( current_user_can( 'unfiltered_html' ) ) {
			$instance['content'] = $new_instance['content'];
		} else {
			$instance['content'] = wp_kses_post( $new_instance['content'] );
		}
		$instance['link']   = sanitize_text_field( $new_instance['link'] );

		return $instance;
	}

	/**
	 * Displays the widget control options in the Widgets admin screen.
	 *
	 * @since 1.0.0
	 */
	public function form( $instance ) {
		$title   = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
		$content_title   = isset( $instance['content_title'] ) ? esc_attr( $instance['content_title'] ) : '';
		$content = isset( $instance['content'] ) ? esc_textarea( $instance['content'] ) : '';
		$link = isset( $instance['link'] ) ? esc_textarea( $instance['link'] ) : '';		
	?>

		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>">
				<?php esc_html_e( '标题', 'iux' ); ?>
			</label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $title; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'content_title' ); ?>">
				<?php esc_html_e( '内容标题', 'iux' ); ?>
			</label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'content_title' ); ?>" name="<?php echo $this->get_field_name( 'content_title' ); ?>" value="<?php echo $content_title; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'content' ); ?>">
				<?php esc_html_e( '文本内容', 'iux' ); ?>
			</label>
			<textarea class="widefat" name="<?php echo $this->get_field_name( 'content' ); ?>" id="<?php echo $this->get_field_id( 'content' ); ?>" cols="30" rows="6"><?php echo $content; ?></textarea>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'link' ); ?>">
				<?php esc_html_e( '链接地址', 'iux' ); ?>
			</label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'link' ); ?>" name="<?php echo $this->get_field_name( 'link' ); ?>" value="<?php echo $link; ?>" placeholder="http://" />
		</p>
	<?php

	}

}
