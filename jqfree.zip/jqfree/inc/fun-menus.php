<?php if ( ! defined( 'ABSPATH' )  ) { die; } // Cannot access directly.

/**
 * 酱茄Free主题由酱茄（www.jiangqie.com）开发的一款免费开源的WordPress主题，专为WordPress博客、资讯、自媒体网站而设计。
 */

register_nav_menus( array(
	'main-menu' => '主菜单',
    // 'right-menu' => '导航右侧菜单',
    // 'footer-menu' => '页脚菜单',
) );