<?php get_header(); ?>
<?php
if ( is_category(array(of_get_option('singlecolumn')))) {
include(TEMPLATEPATH . '/list-news.php');
}
elseif ( is_category(array(of_get_option('doublecolumn')))){
include(TEMPLATEPATH . '/list-blog.php');
}
else {
include(TEMPLATEPATH . '/list-nav.php');
}
?>
<?php get_footer(); ?>
