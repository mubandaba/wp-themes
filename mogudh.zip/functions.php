<?php /*引入options文件*/

// 引入自定义面板
include( 'inc/metabox.php' );

if (!function_exists('optionsframework_init')){
  define('OPTIONS_FRAMEWORK_DIRECTORY', get_template_directory_uri().'/inc/');
  require_once dirname(__FILE__).'/inc/options-framework.php';
}

// 页面标题
function mogu_show_title() {
	add_theme_support('title-tag');
}
add_action('after_setup_theme', 'mogu_show_title');

//去除window._wpemojiSettings
remove_action( 'admin_print_scripts', 'print_emoji_detection_script');
remove_action( 'admin_print_styles', 'print_emoji_styles');

remove_action( 'wp_head', 'print_emoji_detection_script', 7);
remove_action( 'wp_print_styles', 'print_emoji_styles');

// remove_filter( 'the_content_feed', 'wp_staticize_emoji');
remove_filter( 'comment_text_rss', 'wp_staticize_emoji');
remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email');

//禁用REST API/移除wp-json链接
add_filter('rest_enabled', '__return_false');
add_filter('rest_jsonp_enabled', '__return_false');
remove_action( 'wp_head', 'rest_output_link_wp_head', 10 );
remove_action( 'wp_head', 'wp_oembed_add_discovery_links', 10 );
remove_action( 'wp_head', 'wp_resource_hints', 2 );
remove_action( 'wp_head', 'wp_generator' ); 

// 禁止谷歌默认字体
add_filter( 'gettext_with_context', 'wpjam_disable_google_fonts', 888, 4);
function wpjam_disable_google_fonts($translations, $text, $context, $domain ) {
	$google_fonts_contexts = array('Open Sans font: on or off','Lato font: on or off','Source Sans Pro font: on or off','Bitter font: on or off');
	if( $text == 'on' && in_array($context, $google_fonts_contexts ) ){
		$translations = 'off';
	}
	return $translations;
}

/*上传特色图片*/
if ( function_exists( 'add_theme_support' ) ) {
    add_theme_support( 'post-thumbnails', array( 'post', 'page' ) );
}

// Add theme support for Featured Images
add_theme_support('post-thumbnails', array(
'post',
'page',
'custom-post-type-name',
));
register_nav_menus(array(
    'header-menu' => __( 'PC端菜单' ),
    'mb_header-menu' => __( '移动端菜单' ),
    ));

remove_action( 'wp_head', 'wp_enqueue_scripts', 1 );

// 获取子类
function getchild($id)  
{  
  $result = explode('/',get_category_children($id));  
  $childs = array();  
  foreach($result as $i)  
  {  
  if(!empty($i))$childs[] = get_category($i);  
  }  
  return $childs;  
}  

// 修改后台logo
function custom_loginlogo() {
    $first_img = get_template_directory_uri().'/images/logo.png';
    echo '<style type="text/css">.login h1 a {background:url('.$first_img.');width:126px;height:104px;}</style>';
}
add_action('login_head', 'custom_loginlogo');

/*阅读次数*/
function get_post_views ($post_id) {     
    $count_key = 'views';   
    $count = get_post_meta($post_id, $count_key, true);   
  
    if ($count == '') {   
        delete_post_meta($post_id, $count_key);   
        add_post_meta($post_id, $count_key, '0');   
        $count = '0';   
    }   
    echo number_format_i18n($count);   
}   
  
function set_post_views () {    
    global $post;    
    $post_id = $post -> ID;   
    $count_key = 'views';   
    $count = get_post_meta($post_id, $count_key, true);    
    if (is_single() || is_page()) {   
  
        if ($count == '') {   
            delete_post_meta($post_id, $count_key);   
            add_post_meta($post_id, $count_key, '0');   
        } else {   
            update_post_meta($post_id, $count_key, $count + 1);   
        }     
    }     
}   
add_action('get_header', 'set_post_views');  

//屏蔽wordpress后台（仪表盘）顶部logo
function annointed_admin_bar_remove() {
global $wp_admin_bar;
/* Remove their stuff */
$wp_admin_bar->remove_menu('wp-logo');
}
add_action('wp_before_admin_bar_render', 'annointed_admin_bar_remove', 0);

// 后台增加链接
add_filter( 'pre_option_link_manager_enabled', '__return_true' );

// 取消block编辑器
add_filter('use_block_editor_for_post', '__return_false');

/*评论系统*/
function aurelius_comment($comment, $args, $depth)
{
	$GLOBALS['comment'] = $comment; ?>
    <div class="comment clearfix" id="li-comment-<?php comment_ID(); ?>">
        <div class="gravatar">
            <?php if (function_exists('get_avatar') && get_option('show_avatars')) { echo get_avatar($comment, 48); } ?>
        </div>
        <div class="comment-main" id="comment-<?php comment_ID(); ?>">
            <div class="comment-content">
                <span class="comment-reply">
                    <?php comment_reply_link(array_merge( $args, array('reply_text' => '<i class="iconfont">&#xe672;</i>','depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
                </span>
                <?php if ($comment->comment_approved == '0') : ?>
                    <em>你的评论正在审核，稍后会显示出来！</em><br />
                <?php endif; ?>
                <?php comment_text(); ?>
            </div>
            <p class="comment-meta">
                    <?php printf(__('<span class="comment-author">%s</span>'), get_comment_author_link()); ?>
                    <span class="comment-date"><?php echo get_comment_time('Y-m-d H:i'); ?></span>
            </p>
        </div>
    </div>
<?php }


//点赞
add_action('wp_ajax_nopriv_bigfa_like', 'bigfa_like');
add_action('wp_ajax_bigfa_like', 'bigfa_like');
function bigfa_like(){
 global $wpdb,$post;
 $id = $_POST["um_id"];
 $action = $_POST["um_action"];
 if ( $action == 'ding'){
 $bigfa_raters = get_post_meta($id,'bigfa_ding',true);
 $expire = time() + 99999999;
 $domain = ($_SERVER['HTTP_HOST'] != 'localhost') ? $_SERVER['HTTP_HOST'] : false; // make cookies work with localhost
 setcookie('bigfa_ding_'.$id,$id,$expire,'/',$domain,false);
 if (!$bigfa_raters || !is_numeric($bigfa_raters)) {
 update_post_meta($id, 'bigfa_ding', 1);
 }
 else {
 update_post_meta($id, 'bigfa_ding', ($bigfa_raters + 1));
 }
 echo get_post_meta($id,'bigfa_ding',true);
 }
 die;
}

//去除分类标志代码
add_action( 'load-themes.php',  'no_category_base_refresh_rules');
add_action('created_category', 'no_category_base_refresh_rules');
add_action('edited_category', 'no_category_base_refresh_rules');
add_action('delete_category', 'no_category_base_refresh_rules');
function no_category_base_refresh_rules() {
    global $wp_rewrite;
    $wp_rewrite -> flush_rules();
}
// register_deactivation_hook(__FILE__, 'no_category_base_deactivate');
// function no_category_base_deactivate() {
//  remove_filter('category_rewrite_rules', 'no_category_base_rewrite_rules');
//  // We don't want to insert our custom rules again
//  no_category_base_refresh_rules();
// }
// Remove category base
add_action('init', 'no_category_base_permastruct');
function no_category_base_permastruct() {
    global $wp_rewrite, $wp_version;
    if (version_compare($wp_version, '3.4', '<')) {
        // For pre-3.4 support
        $wp_rewrite -> extra_permastructs['category'][0] = '%category%';
    } else {
        $wp_rewrite -> extra_permastructs['category']['struct'] = '%category%';
    }
}
// Add our custom category rewrite rules
add_filter('category_rewrite_rules', 'no_category_base_rewrite_rules');
function no_category_base_rewrite_rules($category_rewrite) {
    //var_dump($category_rewrite); // For Debugging
    $category_rewrite = array();
    $categories = get_categories(array('hide_empty' => false));
    foreach ($categories as $category) {
        $category_nicename = $category -> slug;
        if ($category -> parent == $category -> cat_ID)// recursive recursion
            $category -> parent = 0;
        elseif ($category -> parent != 0)
            $category_nicename = get_category_parents($category -> parent, false, '/', true) . $category_nicename;
        $category_rewrite['(' . $category_nicename . ')/(?:feed/)?(feed|rdf|rss|rss2|atom)/?$'] = 'index.php?category_name=$matches[1]&feed=$matches[2]';
        $category_rewrite['(' . $category_nicename . ')/page/?([0-9]{1,})/?$'] = 'index.php?category_name=$matches[1]&paged=$matches[2]';
        $category_rewrite['(' . $category_nicename . ')/?$'] = 'index.php?category_name=$matches[1]';
    }
    // Redirect support from Old Category Base
    global $wp_rewrite;
    $old_category_base = get_option('category_base') ? get_option('category_base') : 'category';
    $old_category_base = trim($old_category_base, '/');
    $category_rewrite[$old_category_base . '/(.*)$'] = 'index.php?category_redirect=$matches[1]';
    //var_dump($category_rewrite); // For Debugging
    return $category_rewrite;
}
// Add 'category_redirect' query variable
add_filter('query_vars', 'no_category_base_query_vars');
function no_category_base_query_vars($public_query_vars) {
    $public_query_vars[] = 'category_redirect';
    return $public_query_vars;
}
// Redirect if 'category_redirect' is set
add_filter('request', 'no_category_base_request');
function no_category_base_request($query_vars) {
    //print_r($query_vars); // For Debugging
    if (isset($query_vars['category_redirect'])) {
        $catlink = trailingslashit(get_option('home')) . user_trailingslashit($query_vars['category_redirect'], 'category');
        status_header(301);
        header("Location: $catlink");
        exit();
    }
    return $query_vars;
}


// 最新评论
function bg_recent_comments($no_comments = 5, $comment_len = 999, $avatar_size = 48) {
  $comments_query = new WP_Comment_Query();
    $comments = $comments_query->query( array( 'number' => $no_comments ) );
    $comm = '';
    if ( $comments ) : foreach ( $comments as $comment ) :
        $comm .= '<li><div class="fl">' . get_avatar( $comment->comment_author_email, $avatar_size ) . '</div>';
        $comm .= '<div class="ell-2"><span class="author">';
        $comm .= get_comment_author( $comment->comment_ID ) . '</span> - ';
        $comm .= '<span>' . strip_tags( substr( apply_filters( 'get_comment_text', $comment->comment_content ), 0, $comment_len ) ) . '</span></div></li>';
    endforeach; else :
        $comm .= 'No comments.';
    endif;
    echo $comm;
}

?>