<?php
/*
Template Name: Tags
*/
?>
<?php get_header(); ?>
<div class="w970">
<?php while(have_posts()) : the_post(); ?>
	<div class="meta"><h3><?php the_title('',' &raquo;'); ?></h3></div>
	<div id="page_content">
		<div id="tags"><?php wp_tag_cloud('unit=px&smallest=12&largest=24&number=0'); ?></div>
	</div>
<?php endwhile; ?>
</div>
<?php get_footer(); ?>