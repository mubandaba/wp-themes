﻿<div id="footer">
	<div class="w970">
<script type="text/javascript" src="http://js.tongji.linezing.com/1363932/tongji.js"></script><noscript><a href="http://www.linezing.com"><img src="http://img.tongji.linezing.com/1363932/tongji.gif"/></a></noscript>
	&copy;2008-2009 <?php bloginfo('name'); ?> All Rights Reservied<br />
	Powered by <a href="http://wordpress.org/" target="_blank">WordPress</a>. Theme by <a href="http://www.prower.cn">Prower</a>.<a href="http://www.wopus.org" target="_blank" title="Wopus中文博客平台,致力于为中文博客提供动力!">Support By Wopus</a>
	</div>
</div>
<div id="go_top"><em></em><a href="#">返回顶部</a></div>
<?php wp_footer(); ?>
</body>
</html>