<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="http://gmpg.org/xfn/11">
	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
	<title><?php if (is_home () ) { bloginfo('name'); } elseif ( is_category() ) { single_cat_title();
	echo " - "; bloginfo('name'); } elseif (is_single() || is_page() ) { single_post_title(); echo " - "; bloginfo('name'); }
	elseif (is_search() ) { bloginfo('name'); echo "search results:"; echo
	wp_specialchars($s); } else { wp_title('',true); } ?></title>
	<meta name="author" content="prower" />
	<meta name="copyright" content="design by prower" />
	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
	<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<?php wp_get_archives('type=monthly&format=link'); ?>
	<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
	<?php wp_head(); ?>
</head>

<body>
<div id="top">
	<div class="w970">
		<ul>
			<?php wp_list_pages('sort_column=id&depth=1&title_li='); ?>
		</ul>
		<?php bloginfo('description'); ?>
	</div>
</div>
<div id="header">
	<div class="w970">
		<h1><a href="<?php bloginfo('url'); ?>/"><?php bloginfo('name'); ?></a></h1>
		<div id="search">
			<form id="searchform" method="get" action="<?php bloginfo('home'); ?>">
				<input type="text" value="<?php the_search_query(); ?>" name="s" id="s" size="20" />
				<input type="submit" value="搜索" />
			</form>
		</div>
	</div>
</div>
<div id="nav">
	<div class="w970">
		<ul>
			<li <?php if(is_home()){echo 'class="current-cat"';}?>><a title="Home" href="<?php echo get_option('home'); ?>/">首 页</a></li>
			<?php
            if(is_single()){
                $parent = get_the_category();
                $parent = $parent[0];
                $id = $parent->term_id;
            }
            ?>
			<?php wp_list_categories('title_li=&current_category='.$id); ?>
		</ul>
		<div id="rss">
			<a id="rss_icon" title="RSS订阅" href="<?php bloginfo('rss2_url'); ?>"></a>
		</div>
	</div>
</div>