这是一个盒子萌WordPress主题！！！

主题demo https://www.boxmoe.com/

为什么是盒子萌鸽子版？本来是春节的时候已经发布了，但是放了N多次的群友们的鸽子！因为这个是历经了春节“坐月子”和好友打上游戏，复工后因工作繁忙没时间捣鼓，知道现在才陆续完工，所以称之为boxmoe（dove）盒子萌鸽子版，说到了居然有鸽子版！那么就代表了boxmoe主题会有继续其他的版本出来！只是要等待和被放鸽子的心态！！

主题说明：<br>
1.依旧使用bootstrap框架完成！为什么使用BT框架！因为我懒也熟悉；<br>
2.鸽子版加入了PJAX，这也是我首次接触，可能还有BUG，没关系反正我不熟也解决不了；<br>
3.首版文章列表两个布局<br>
4.依旧有会员中心，需要配套erphpdown<br>
5.支持无分类链接，如果你用插件就别开<br>
6.经典编辑器简代码<br>
7.主题傻瓜式设置<br>
8.图标使用FontAwesome<br>
9.支持assets 静态资源（jpg js css 等）CDN或者存放阿里云OSS<br>

FontAwesome使用方法<br>
//使用方式<br>
打开https://d.boxmoe.com/html/FontAwesome.html 复制替换 <br>
<code><i class="fa fa-cloud-download"></i></code>
//fa-cloud-download 按对照表替换成你要的图标名<br>
