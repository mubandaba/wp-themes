<?php get_header(); ?>
      <section class="section section-about" id="about">
        <div class="container">
          <div class="section-head">
            <span>404 not found</span>
            </div>
			<div class="row justify-content-center align-items-center">


<div class="alert alert-warning text-center" role="alert">
    <span class="alert-icon"><i class="fa fa-bell"></i></span>
    <span class="alert-text"><strong>哦豁！</strong> 你访问的页面不存在勒！</span>
</div>

</div>                     
        </div>
      </section>  
<?php get_footer(); ?>
