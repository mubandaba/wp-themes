<article class="format-video">
	<?php the_content(); ?>
</article>