<article class="format-audio">
	<?php the_content(); ?>
</article>