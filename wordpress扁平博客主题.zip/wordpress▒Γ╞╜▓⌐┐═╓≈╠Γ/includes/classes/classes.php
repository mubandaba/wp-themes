<?php
/**
 * ZanBlog 自定义类函数加载
 *
 * @package 	ZanBlog
 * @subpackage  Class
 * @since 		3.0.0
 * @author      YEAHZAN
 */

// 加载主题自定义类
include(CLASSESPATH . 'class-zan-nav-menu.php');