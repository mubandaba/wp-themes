<div id="sidebar" class="sidebar">
<ul>
<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar() ) : else : ?>
		<li class="side_ads">
			<div class="ads">
				<a href="#"><img src="<?php bloginfo('template_url'); ?>/images/bg_ads.gif" alt="Advertising" /></a>
			</div>
		</li>
		<div id="clear"></div>
		<li>
			<h2><?php _e('Categories'); ?></h2>
			<ul>
				<?php wp_list_cats('sort_column=name&hierarchical=0&depth=0'); ?>
			</ul>
			<div class="sidebar_btm"></div>
		</li>
		<li>
			<h2><?php _e('recent posts'); ?></h2>
			<ul>
			<?php
					global $post;
					$recent = get_posts('numberposts=5&orderby=date');
					foreach($recent as $post) : setup_postdata($post);
				?>				
			<li>
				<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
			</li>	
			<?php endforeach; ?>
			</ul>
			<div class="sidebar_btm"></div>
		</li>
		<li>
			<h2><?php _e('Archives'); ?></h2>
			<ul>
			<?php wp_get_archives('type=monthly'); ?>
			</ul>
			<div class="sidebar_btm"></div>
		</li>
<?php endif;?>
</ul>
<div id="clear"></div>
</div>