<?php get_header(); ?>
<div id="contents">
	<div class="container">
          <?php if(have_posts()) : ?><?php while(have_posts()) : the_post(); ?>
         <div class="post">
             <div class="postdata">
				<div class="pleft">
					<div class="pdate">&nbsp;</div>
					<div id="clear"></div>
				</div>
				<div class="pright">
					<h2 class="title">404 Error - Not Found</h2>
					<div id="clear"></div>
				</div>
			</div>
			<div class="post_btm"></div>
		</div>
        <div id="clear"></div>
    </div>
	<?php get_sidebar();?>
	<div id="clear"></div>
</div>
<?php get_footer();?>
<div id="clear"></div>
</div>

</body>
</html>