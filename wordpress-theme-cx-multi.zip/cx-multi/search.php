<?php
/***************************************
## Theme URI: https://www.chenxingweb.com/wordpress-theme-cx-multi.html
## Author: 晨星博客
## Author URI: https://www.chenxingweb.com
## Description: 简洁时尚自适应博客杂志类主题，有问题请加QQ群597157500请求帮助。
## Theme Name: CX-MULTI
## Version: 1.0
****************************************/

get_header();
?>
    <div class="multi-ctop-box">
        <div class="multi-main-box">
            <h1 class="multi-page-title">搜索：<?php echo get_search_query(); ?></h1>
            <div class="taxonomy-description">共找到 <?php global $wp_query; echo $wp_query->found_posts;?> 条记录</div>
        </div>
    </div>

    <div class="multi-postlist-box">
        <main class="multi-main-box">        
            <?php
            // 调用文章列表
            get_template_part( 'template-parts/content/content', 'postlist' );
            ?>
		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_footer();