<?php
/***************************************
## Theme URI: https://www.chenxingweb.com/wordpress-theme-cx-multi.html
## Author: 晨星博客
## Author URI: https://www.chenxingweb.com
## Description: 简洁时尚自适应博客杂志类主题，有问题请加QQ群597157500请求帮助。
## Theme Name: CX-MULTI
## Version: 1.0
****************************************/
?>
<div class="layui-col-md4 layui-ms-type multi-single-sidebar" id="float-sidebar">
    <div class="layui-col-md12 layui-tmargin-15px">
        <?php
        if (is_active_sidebar('sidebar-single')) {
            dynamic_sidebar('sidebar-single');
        } else { ?>
            <div>请到 外观=》小工具 页面设置该模块调用内容。</div>
        <?php } ?>
    </div>
</div>