<?php
/***************************************
## Theme URI: https://www.chenxingweb.com/wordpress-theme-cx-multi.html
## Author: 晨星博客
## Author URI: https://www.chenxingweb.com
## Description: 简洁时尚自适应博客杂志类主题，有问题请加QQ群597157500请求帮助。
## Theme Name: CX-MULTI
## Version: 1.0
****************************************/

if( is_admin() ) {
    require_once plugin_dir_path( __FILE__ ) .'classes/setup.class.php';
    require_once plugin_dir_path( __FILE__ ) .'option/theme-options.php';
    require_once plugin_dir_path( __FILE__ ) .'option/theme-metabox.php';
}
