<?php
/***************************************
## Theme URI: https://www.chenxingweb.com/wordpress-theme-cx-multi.html
## Author: 晨星博客
## Author URI: https://www.chenxingweb.com
## Description: 简洁时尚自适应博客杂志类主题，有问题请加QQ群597157500请求帮助。
## Theme Name: CX-MULTI
## Version: 1.0
****************************************/
 
$prefix_post_opts = '_cxmulti_postopt';
CSF::createMetabox($prefix_post_opts, array(
    'title'     => '文章推荐位设置',
    'post_type' => 'post',
    'data_type' => 'unserialize',
    'context'   => 'side',
    'priority'  => 'low',
));

CSF::createSection($prefix_post_opts, array(
    'fields' => array(
        array(
            'id'      => '_multi_post_position',
            'type'    => 'radio',
            'inline'  => false,
            'options' => array(
                'slide'  => '首页轮播',
                'recom'  => '首页推荐',
                'no'     => '不在推荐位显示'
            ),
            'default' => 'no',
            'desc'    => '把文章推送至预设推荐位上显示！',
        ),

    ),
));
