<?php
/***************************************
## Theme URI: https://www.chenxingweb.com/wordpress-theme-cx-multi.html
## Author: 晨星博客
## Author URI: https://www.chenxingweb.com
## Description: 简洁时尚自适应博客杂志类主题，有问题请加QQ群597157500请求帮助。
## Theme Name: CX-MULTI
## Version: 1.0
****************************************/

get_header();

// 调用幻灯片模块
get_template_part( 'template-parts/content/content', 'slide' );

// 调用热门标签
get_template_part( 'template-parts/content/content', 'indextag' );

// 调用专题模块
get_template_part( 'template-parts/content/content', 'indexzt' );
?>

<div class="multi-postlist-box">
    <div class="multi-main-box">
        <div class="multi-main-title">
            <h2>最新发布</h2>
            <i class="cxthemeicon cxicon-xin1"></i>
        </div>
        
        <?php
        // 调用文章列表
        get_template_part( 'template-parts/content/content', 'postlist' );
        ?>
        
    </div>
</div>

<?php
get_footer();
