<?php
/***************************************
## Theme URI: https://www.chenxingweb.com/wordpress-theme-cx-multi.html
## Author: 晨星博客
## Author URI: https://www.chenxingweb.com
## Description: 简洁时尚自适应博客杂志类主题，有问题请加QQ群597157500请求帮助。
## Theme Name: CX-MULTI
## Version: 1.0
****************************************/

get_header();
?>

<div id="404-page" class="multi-404-area">
    <main class="multi-main-box">

        <div class="error-404 not-found">
            <header class="page-header">
                <h1 class="page-title">有点尴尬诶！该页无法显示。</h1>
            </header><!-- .page-header -->

            <div class="page-content">
                <p>这儿似乎什么都没有，试试搜索？</p>
                <?php get_search_form(); ?>
            </div><!-- .page-content -->
        </div><!-- .error-404 -->

    </main><!-- #main -->
</div><!-- #primary -->

<?php
get_footer();
