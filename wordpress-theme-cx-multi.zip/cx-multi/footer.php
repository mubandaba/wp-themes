<?php
/***************************************
## Theme URI: https://www.chenxingweb.com/wordpress-theme-cx-multi.html
## Author: 晨星博客
## Author URI: https://www.chenxingweb.com
## Description: 简洁时尚自适应博客杂志类主题，有问题请加QQ群597157500请求帮助。
## Theme Name: CX-MULTI
## Version: 1.0
****************************************/
?>

	</div><!-- #content -->

	<footer class="multi-footer">
        <div class="multi-main-box">
            <div class="footer-content-box">
                <div class="aboutus_link">
                     <?php
                     echo strip_tags(wp_nav_menu(
                         [
                            'container'      => false,
                            'echo'           => false,
                            'items_wrap'     => '%3$s',
                            'depth'          => 0,
                            'theme_location' => 'footer',
                         ]
                     ) , '<a>');
                     ?>
                </div>
                <div class="footer-desc">
                    <?php echo cx_option('footer-desc');?>
                </div>
                <div class="footer-email-box">
                    <a href="mailto:<?php echo get_option('admin_email');?>" title="发送邮件给管理员">
                        <i class="cxthemeicon cxicon-youxiang"></i>
                    </a>
                </div>
            </div>            
        </div>
        <div class="footer-copyright">
            <div class="multi-main-box">
                <span><?php echo cx_option('footer-copyright');?></span>
                <span class="multi-right layui-hide-xs">该主题由 <a href="https://www.chenxingweb.com">晨星博客</a> 开发制作</span> 
            </div>
        </div>
	</footer><!-- #colophon -->

</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
