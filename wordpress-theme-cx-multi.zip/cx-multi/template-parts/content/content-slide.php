<?php
/***************************************
## Theme URI: https://www.chenxingweb.com/wordpress-theme-cx-multi.html
## Author: 晨星博客
## Author URI: https://www.chenxingweb.com
## Description: 简洁时尚自适应博客杂志类主题，有问题请加QQ群597157500请求帮助。
## Theme Name: CX-MULTI
## Version: 1.0
****************************************/
?>
<div class="multi-slide-box">
    <div class="multi-slide-man multi-main-box layui-clear">
        <div class="slide-left-box">
            <div class="owl-carousel owl-theme">
            <?php
            // slide
            $slide_query = new WP_Query( [
                'posts_per_page' => cx_option('index-slide-num',3),
                'meta_query'     => [
                    [
                        'key'    => '_multi_post_position',
                        'value'  => 'slide',
                    ]
                ]
            ] );
            
            // The Loop
            if ( $slide_query->have_posts() ):
                while ( $slide_query->have_posts() ): $slide_query->the_post();
                    cx_template_html( 'slide','<div class="item">', '</div>');
                endwhile;
            else:
                ?>
                <div class="item">
                    <div class="slide-post-archive">
                        <a href="https://www.chenxingweb.com/">
                            <div class="scale-thumb-box">
                                <div class="post-thumb-box" style="background-image: url(<?php echo get_theme_file_uri('images/image-def.jpg');?>);">
                                    <span class="overlay"></span>
                                </div>
                            </div>
                            <div class="post-meta-box">
                                <h3>默认幻灯片调用</h3>
                                <p>在您还未设置幻灯片时系统会自动显示一个默认幻灯片用来占位，当您设置幻灯片内容后，会自动显示您设置的内容...</p>
                            </div>
                        </a>
                    </div>
                </div>
                <?php
            endif;
            wp_reset_postdata();   
            ?>
            </div>
        </div>
        <div class="slide-right-box">
            <div class="slide-right-postlist">
            <?php
            // slide
            $rslide_query = new WP_Query( [
                'posts_per_page' => 4,
                'meta_query'     => [
                    [
                        'key'    => '_multi_post_position',
                        'value'  => 'recom',
                    ]
                ]
            ] );
            
            // The Loop
            if ( $rslide_query->have_posts() ):
                while ( $rslide_query->have_posts() ): $rslide_query->the_post();
                    cx_template_html( 'rslide','<div class="item">', '</div>');
                endwhile;
            else:
                ?>
                <div class="item">
                    <div class="rslide-post-archive transform-scale">
                        <a href="https://www.chenxingweb.com/">
                            <div class="scale-thumb-box">
                                <div class="post-thumb-box" style="background-image: url(<?php echo get_theme_file_uri('images/image-def.jpg');?>);">
                                    <span class="overlay"></span>
                                </div>
                            </div>
                            <div class="post-meta-box">
                                <h3>默认首页推荐文章，设置内容源后，自动切换显示位您设置的内容..</h3>
                            </div>
                        </a>
                    </div>
                </div>
                <?php
            endif;
            wp_reset_postdata();   
            ?>
            </div>
        </div>
    </div>
</div>