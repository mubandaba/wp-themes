<?php
/***************************************
## Theme URI: https://www.chenxingweb.com/wordpress-theme-cx-multi.html
## Author: 晨星博客
## Author URI: https://www.chenxingweb.com
## Description: 简洁时尚自适应博客杂志类主题，有问题请加QQ群597157500请求帮助。
## Theme Name: CX-MULTI
## Version: 1.0
****************************************/
?>
<?php
if( !cx_switcher('index-zt') ) return;
$_zt_data = cx_option('index-zt-data');
if( empty($_zt_data) || !is_array($_zt_data) ) return;
?>
<div class="multi-indexzt-box">
    <div class="multi-main-box">
        <ul class="indexzt-list layui-clear">
            <?php
            foreach ($_zt_data as $ztdata) {
                if( empty($ztdata['opt-show']) ) continue;
                ?>
                 <li>
                    <div class="zt-archive transform-scale">
                        <a href="<?php echo $ztdata['opt-url'];?>">
                            <div class="scale-thumb-box">
                                <div class="post-thumb-box" style="background-image: url(<?php echo $ztdata['opt-images'];?>);">
                                    <!-- <span class="overlay"></span> -->
                                    <!--
                                    <div class="zt-title">
                                        <span><?php echo $ztdata['opt-text'];?></span>
                                    </div>
                                    -->
                                </div>
                            </div>
                        </a>
                    </div>
                </li>
                <?php
            }
            ?>
        </ul>
    </div>
</div>