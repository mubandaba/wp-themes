<?php
/***************************************
## Theme URI: https://www.chenxingweb.com/wordpress-theme-cx-multi.html
## Author: 晨星博客
## Author URI: https://www.chenxingweb.com
## Description: 简洁时尚自适应博客杂志类主题，有问题请加QQ群597157500请求帮助。
## Theme Name: CX-MULTI
## Version: 1.0
****************************************/
?>
<?php
if (have_posts()):
    echo '<ul class="multi-postlist layui-clear">';
    while (have_posts()): the_post();
        cx_template_html( '','<li>', '</li>');
    endwhile;
    echo '</ul>';

    /** 分页代码调用 **/
	$argspage = array(
		'prev_text'          =>'<i class="cxthemeicon cxicon-chevron-left"></i>',
		'next_text'          =>'<i class="cxthemeicon cxicon-chevron-right"></i>',
		'mid_size'           => 1,
		'before_page_number' => '<span class="meta-nav screen-reader-text">第 </span>',
		'after_page_number'  => '<span class="meta-nav screen-reader-text"> 页</span>',
	);
	the_posts_pagination($argspage);
else:
    get_template_part('template-parts/content/content', 'none');
endif;