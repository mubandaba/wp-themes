<?php
/***************************************
## Theme URI: https://www.chenxingweb.com/wordpress-theme-cx-multi.html
## Author: 晨星博客
## Author URI: https://www.chenxingweb.com
## Description: 简洁时尚自适应博客杂志类主题，有问题请加QQ群597157500请求帮助。
## Theme Name: CX-MULTI
## Version: 1.0
****************************************/
?>
<div class="multi-indexmenu-box">
    <div class="multi-main-box">
        <h2>热门标签：</h2>
        <?php 
        wp_tag_cloud([
            'number' => 15,
            'format' => 'list'
        ]);
        ?>
        <div class="indexmenu-right-more">
            最近更新<span class="num"><?php echo cx_update_postnum();?></span>篇帖子
        </div>
    </div>
</div>