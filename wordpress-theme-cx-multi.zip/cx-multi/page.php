<?php
/***************************************
## Theme URI: https://www.chenxingweb.com/wordpress-theme-cx-multi.html
## Author: 晨星博客
## Author URI: https://www.chenxingweb.com
## Description: 简洁时尚自适应博客杂志类主题，有问题请加QQ群597157500请求帮助。
## Theme Name: CX-MULTI
## Version: 1.0
****************************************/

get_header();
?>
<div class="multi-single-header layui-clear">
    <div class="multi-main-box">
        <div class="layui-col-md12">
            <div class="multi-breadcrimb-box">
                <i class="iconfont layui-extend-location" style="font-weight: 600;"></i> 当前位置：
                <span class="layui-breadcrumb">
                    <a href="<?php echo home_url();?>">首页</a>
                    <a href="<?php the_permalink();?>"><cite>正文</cite></a>
                </span>
            </div>
        </div>
    </div>
</div>

<div id="single-page" class="multi-content-area">
    <main class="multi-main-box">
        <div class="layui-row multi-content-main">
            <div class="layui-col-md12 layui-tmargin-15px multi-single-content">
                <?php
                // Start the Loop.
                while (have_posts()) : the_post();
                ?>

                <div class="layui-col-md12 multi-single-header">
                    <?php the_title('<h1>', '</h1>');?>
                    <div class="multi-single-meta layui-clear">
                        <div class="multi-left">
                            <i class="cxthemeicon cxicon-tubiao39" style="font-weight: 600;"></i>
                            <time datetime="<?php the_time('Y-m-d H:i:s');?>"><?php the_date('Y/m/d');?></time>
                        </div>
                    </div>
                    <!-- .entry-meta -->
                </div>
                <div class="layui-col-md12">
                    <div class="multi-single-main">
                        <article id="post-<?php the_ID(); ?>" class="post-countent-data layui-text">
                            <?php the_content();?>
                        </article>
                    </div>
                </div><!-- col.md12 -->

                <?php
                endwhile; // End the loop.
                ?>

            </div>

        </div>

    </main><!-- #main -->

</div><!-- #primary -->

<?php
get_footer();
