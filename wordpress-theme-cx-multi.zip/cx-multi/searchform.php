<?php
/***************************************
## Theme URI: https://www.chenxingweb.com/wordpress-theme-cx-multi.html
## Author: 晨星博客
## Author URI: https://www.chenxingweb.com
## Description: 简洁时尚自适应博客杂志类主题，有问题请加QQ群597157500请求帮助。
## Theme Name: CX-MULTI
## Version: 1.0
****************************************/
?>
<form role="search" method="get" class="layui-form" action="<?php echo home_url();?>">
    <div class="search-input">
        <input type="text" placeholder="请输入搜索关键词..." class="layui-input" value="" autocomplete="off" name="s" required="">
        <button class="btn" type="submit" id="searchsubmit"><i class="cxthemeicon cxicon-Search"></i></button>
    </div>
</form>