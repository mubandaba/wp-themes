<?php
/***************************************
## Theme URI: https://www.chenxingweb.com/wordpress-theme-cx-multi.html
## Author: 晨星博客
## Author URI: https://www.chenxingweb.com
## Description: 简洁时尚自适应博客杂志类主题，有问题请加QQ群597157500请求帮助。
## Theme Name: CX-MULTI
## Version: 1.0
****************************************/

get_header();
?>
    <div class="multi-ctop-box">
        <div class="multi-main-box">
            <?php
                the_archive_title( '<h1 class="multi-page-title">', '</h1>' );
                the_archive_description( '<div class="taxonomy-description">', '</div>' );
            ?>
        </div>
    </div>
    <?php if( is_category() ): ?>
    <div class="multi-indexmenu-box">
        <div class="multi-main-box">
            <h2>热门标签：</h2>
            <?php 
            cx_rand_tags();
            ?>
            <div class="indexmenu-right-more">
                栏目最近更新
                <span class="num">
                <?php 
                $term = get_queried_object();
                echo cx_update_postnum('',$term->term_id);
                ?>
                </span>篇帖子
            </div>
        </div>
    </div>
    <?php endif;?>

    <div class="multi-postlist-box">
        <main class="multi-main-box">     
            <?php
            // 调用文章列表
            get_template_part( 'template-parts/content/content', 'postlist' );
            ?>
        </main>
    </div>

<?php
get_footer();