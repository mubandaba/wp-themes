<?php 
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header(); ?>


<?php 
$categories= get_categories(array(
  'taxonomy'     => 'favorites',
  'meta_key'     => '_term_order',
  'orderby'      => 'meta_value_num',
  'order'        => 'desc',
  'hide_empty'   => 0,
  )
); 
include( 'templates/header-nav.php' );
?>
<div class="main-content">
    
<?php include( 'templates/header-banner.php' ); ?>

    <?php
    if(io_get_option('is_search')){include('search-tool.php'); }
    else{?>
    <div class="no-search"></div>
    <?php } ?>
    <h4 class="text-gray"><i class="icon-io-tag" style="margin-right: 27px;" id="<?php single_cat_title() ?>"></i><?php single_cat_title() ?></h4>
    <div class="row">  
		<?php if ( have_posts() ) : ?>
		<?php while ( have_posts() ) : the_post(); 
		$link_url = get_post_meta($post->ID, '_sites_link', true); 
        $default_ico = get_template_directory_uri() .'/images/favicon.png';
		if(current_user_can('level_10') || get_post_meta($post->ID, '_visible', true)!="true"):
		?>
			<div class="xe-card <?php echo io_get_option('columns') ?> <?php echo get_post_meta($post->ID, '_wechat_qr', true)? 'wechat':''?>">
            <?php include( 'templates/site-card.php' ); ?>
        	</div>
    	<?php endif; endwhile; endif;?>
    </div> 
    <br /> 

	<div class="posts-nav">
	    <?php echo paginate_links(array(
	        'prev_next'          => 0,
	        'before_page_number' => '',
	        'mid_size'           => 2,
	    ));?>
	</div>

<?php get_footer(); ?>
