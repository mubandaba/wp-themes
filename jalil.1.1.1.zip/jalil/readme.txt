=== jalil ===
Theme Name: Jalil
Theme URI: http://wpthemespace.com/product/jalil-wordpress-blog-theme
Author URI: http://thenextlevel.com.au
Author: jewel1994
Description: Which is a unique feature and user competitive feature. Using any kind of personal portfolio, resume , business , onepage Websites.
Version: 1.1.1
Text Domain: jalil
Tags: custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Copyright License ==
Be 100% GPL and/or 100% GPL-compatible licensed.
Declare copyright and license explicitly. Use the license and license uri header slugs to style.css.
Declare licenses of any resources included such as fonts or images.
All code and design should be your own or legally yours. Cloning of designs is not acceptable.
Any copyright statements on the front end should display the user's copyright, not the theme author's copyright.

Jalil WordPress Theme, Copyright 2018 jewel1994
Jalil is distributed under the terms of the GNU GPL

This theme is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.


== Description ==
Jalil is a smart WordPress blog theme.
Jalil is an awsome WordPress blog theme. Jalil WordPress theme support custom header, feature image, unlimited color changing options, custom background, 5 different color theme look,different logo position, footer widget, font Awesome icons. So you can enjoy your bloging with WordPress Jalil theme.

== Credits ==

All the theme files, scripts and images are licensed under GPLv2 license
Jalil theme uses:
* Based on Underscores https://underscores.me/, (C) 2012-2017 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css https://necolas.github.io/normalize.css/, (C)2012-2016 Nicolas Gallagher and Jonathan Neal, [MIT](https://opensource.org/licenses/MIT)
* Font Awesome 4.7.0 by @davegandy - http://fontawesome.io - @fontawesome
	License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)
* SlickNav  v1.0.10 by @Josh Cope, http://slicknav.io/ 
  Copyright 2016, SlickNav, License,[MIT](https://opensource.org/licenses/MIT)
* modernizr 3.5.0 , https://modernizr.com 
  Copyright 2009-2018, modernizr, License,[MIT](https://opensource.org/licenses/MIT)
* x blog by @Noor alam, https://wordpress.org/themes/x-blog/
  Copyright 2018, Noor alam, License,[GPLv2 or later](http://www.gnu.org/licenses/gpl-2.0.html)
  
=== Image Creadits ==

* Header image: CC0 by cocoparisienne  via Pixabay (https://pixabay.com/en/children-play-rock-swing-leisure-1639420/)

* Sticky post image: CC0 by adamkontor via Pixabay (https://pixabay.com/en/young-woman-woman-sea-ocean-1745173/)

== Brand Icons ==

* All brand icons are trademarks of their respective owners.
* The use of these trademarks does not indicate endorsement of the trademark holder by Font Awesome, nor vice versa.



== Theme Features ==

* Responsive design
* WordPress Theme Customizer support
* SEO friendly
* Header Image
* infinite drop-down Menu
* Featured post section on home page
* Cross-browser compatibility
* Threaded Comments
* Gravatar
* Font Awesome icons
* Mobile Menu



== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Jalil includes support for Infinite Scroll in Jetpack.
You may also use any other plugins.

== Changelog ==

= 1.0.10=
Reduce header logo font size
Menu chlid hover backgound color remove 
Add theme uri

= 1.1.0=
Remove all unnecessary css code
Remove header search icon
Add New background color both header and footer
Add New color in post heading title , author name , category
Change site title color, menu hover background color, copyright text color 

= 1.1.1=
Add Instagram icon in the footer  

= 1.0.0 =
*Released version
