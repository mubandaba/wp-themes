<?php get_header();?>

<div class="content clear column" style="background-color: #fff;">


      <div class="fast"><?php if (function_exists('get_breadcrumbs')){get_breadcrumbs(); } ?></div>
	  
	  <section class="main clear">

        <div class="articles fl" style="width:1100px">

<div class="recent-article">
	<div class="mod-tit">
	<h2 class="tit">最近更新</h2>
	</div>
	<ul class="mod-article-list" style="margin-top:10px;">
	  <?php while(have_posts()) : the_post(); ?>
	  <?php if(!is_sticky()){?>
<li id="post-<?php the_ID(); ?>" class="post-home"style="width:203px;">
	<div class="post-thumbnail">
					<a class="img" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" target="_blank"><img  src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&w=302&h=420&zc=1"width="201" height="280" /></a>
			</div>
	<div class="post-title">
		<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" target="_blank"><?php the_title(); ?></a><span></span>	</div>
<div class="fields">
                                     <span><i class="view icon"></i><?php post_views(' ', ' 次'); ?></span>
                                     <span style="float:right;"><i class="time icon"></i><?php the_time('Y/m/d'); ?></span>
                                 </div>
<span class="num">共<?php echo get_post_images_number().'张图片' ?></span>
</li>
		<?php } endwhile;?>
	</ul>
	
	
  </div>
<div style="clear:both;"></div>
	 <div class="pages">
        <ul class="page-list"><?php par_pagenavi(9); ?></ul>    
		
	</div>
        </div>	
		
      </section>
<?php get_template_part( 'inc/jpmt' ); ?>
    </div>
<?php get_footer(); ?>