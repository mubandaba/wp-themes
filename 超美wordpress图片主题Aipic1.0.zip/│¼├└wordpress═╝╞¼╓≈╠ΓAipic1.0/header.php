<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php bloginfo( 'charset' );?>" />
<title><?php wp_title( '|', true, 'right' ); ?></title>
<?php wp_head() ?>
<link href="<?php bloginfo( 'stylesheet_url' ); ?>?ver=1.0" type="text/css" rel="stylesheet" />

<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/jquery-1.10.2.min.js?ver=1.0"></script>
<?php if (is_home()) {?>
<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/hdp.js?ver=1.0"></script>
<?php }?>
<?php if (is_single()) {?>
<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/hb.js?ver=1.0"></script>
<?php }?>
<script type="text/javascript" src="http://a.aimm-img.com/js/jquery.lazyload.js?ver=1.0"></script>
<script type="text/javascript">
$(function() {
$("img").lazyload({
effect : "fadeIn"
});
});
</script>
</head>
<body>
<div class="header">
    <div class="top">
        <h1 class="logo"><a href="<?php bloginfo( 'url' ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"><img class="logo" src="<?php bloginfo('template_url');?>/images/logo.png" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" /></a></h1> 
        <div class="social-icons">
		

<?php if ( is_user_logged_in() ) {
global $current_user;
get_currentuserinfo(); 
$avatar = get_avatar( $current_user->user_email, 80);
?>
<a href="/wp-admin/" target="_blank" class="huiyuan deng"><?php echo $current_user->display_name;?></a>
<a href="<?php echo wp_logout_url( get_bloginfo('url') ); ?>" title="退出" class="huiyuan zhuce"><?php _e('退出');?></a>
<?php }else{?>
<a href="<?php bloginfo('url'); ?>/wp-login.php" target="_blank" class="huiyuan deng" title="登录">登录</a>
<a href="<?php bloginfo('url'); ?>/wp-login.php?action=register" target="_blank" class="huiyuan zhuce" title="注册">注册</a>
<?php }?>
        </div>
       <div class="search-block">
		<form action="<?php echo get_option('home'); ?>" id="searchform">			   
                <input class="search-button" type="submit" value="" onclick="query_submit()">	
                <input type="text" id="keyword" name="s" value="Search..." onkeydown="if(event.keyCode==13)query_submit();" onfocus="if (this.value == 'Search...') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Search...';}">               
           </form>
        </div>
    </div>
    <div class="main-nav">
        <div class="main-menu">
<?php if(function_exists('wp_nav_menu')) {wp_nav_menu(array('theme_location'=>'main','menu_id'=>'menu', 'menu_class'=>'menu','container'=>'ul'));}?>							
        </div>
        <div class="main-menu-bg"></div>
	</div>
</div>