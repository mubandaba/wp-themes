    <div class="slider-container" id="slide" style="width: 100%; height: 480px;">
  <div id="_slide" class="slider-wrap">
    <ul id="slide_list">
	  
		<?php 
		$args = array(
    'posts_per_page' => 5,      // 显示多少条
    'orderby' => 'date',         // 时间排序
    'order' => 'desc',           // 降序（递减，由大到小）    
    'ignore_sticky_posts' => 1	,
    'meta_query' => array(
        array(
            'key' => '_id_radio',     // 你的使用的自定义字段1
            'value' => 'hdp'  // 自定义字段1对应的值
        )
    )
);query_posts($args);?>
 <?php if ( have_posts() ) : ?>
		  <?php while ( have_posts() ) : the_post(); ?>
		  <li bosszone="Jdt"> <a href="<?php the_permalink(); ?>" class="pic"> <img src="<?php echo get_post_meta($post->ID, "_id_upload",true);?>" width="1100" height="390" border="0">
        <p class="st_ty"><?php the_title(); ?></p>
        </a>
        <div class="slide_Bg"></div>
      </li>
<?php endwhile; ?>
</ul>
  </div>
  <a href="javascript:void(0);" class="slider-btn slider-btn-l" id="sliderL" bosszone="photoPre"></a>
  <a href="javascript:void(0);" class="slider-btn slider-btn-r" id="sliderR" bosszone="photoNext"></a>
  <ul id="focus_dot">
    <li class="current"></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
  </ul>
</div>
<?php endif; wp_reset_query(); ?>
  
