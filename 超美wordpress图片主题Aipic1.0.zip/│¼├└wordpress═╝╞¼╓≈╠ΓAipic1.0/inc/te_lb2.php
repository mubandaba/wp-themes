				<li id="post-<?php the_ID(); ?>" class="post-home2">
	<div class="post-thumbnail">
					<a class="img" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" target="_blank"><img src="http://a.rosimm.wang/images/grey.gif" data-original="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&w=375&h=562&zc=1"width="258" height="375" /></a>
			</div>
	<div class="post-title">
		<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" target="_blank"><?php the_title(); ?></a><span></span>	</div>
<div class="fields">
                                     <span><i class="view icon"></i><?php post_views(' ', ' '); ?></span>
                                     <span style="float:right;"><i class="time icon"></i><?php the_time('Y/m/d'); ?></span>
                                 </div>
<span class="num">共<?php echo get_post_images_number().'张图片' ?></span>
</li>