<?php get_header(); ?>
<?php get_template_part( 'inc/slider' ); ?>
<div class="content clear column index">

    <section class="main clear">	
	
    <div class="articles left fl">
        <div class="recent-article" id="id_4">
			<div class="mod-tit">
				<h2 class="tit">最新图集</h2><a href="#" class="more">更多美女图集<span class="icon-shape"></span></a>
			</div>
			<ul class="mod-article-list">
<?php $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$args = array(
    'showposts' => -1,
    'paged' => $paged
);
query_posts($args); ?>
			<?php while(have_posts()) : the_post(); ?>
				<?php if(!is_sticky()){?>
<?php get_template_part( 'inc/te_lb' ); ?>
			<?php } endwhile;?>
<div style="clear:both;"></div>
			</ul>
<?php get_template_part( 'inc/jpmt' ); ?>
</section>
</div>

<?php get_footer(); ?>