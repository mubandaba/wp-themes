<?php get_header();?>
<?php
        $current_category=get_the_category();//获取当前文章所属分类ID
        $prev_post = get_previous_post($current_category,'');//与当前文章同分类的上一篇文章
        $next_post = get_next_post($current_category,'');//与当前文章同分类的下一篇文章
    ?>

 <!--以下为之前数据-->
<div class="content article column" style="background-color: #fff;">

	<div class="fast"><i class="icon-home"></i><?php if (function_exists('get_breadcrumbs')){get_breadcrumbs(); } ?></div>
	<?php while( have_posts() ): the_post(); $p_id = get_the_ID(); ?>
	<!--开始-->
<div class="main"> 

 
  <!--图片特效内容开始-->
  <div class="piccontext">
  <div class="post-data">
            <a href="javascript:void(0)"><span class="post-views post-span"><i class="view icon"></i>阅读</span><small id="hits"><?php post_views(' ', ' '); ?></small></a>
			<a href="javascript:;" id="likeData" data-action="ding" data-id="<?php the_ID(); ?>" class="favorite<?php if(isset($_COOKIE['bigfa_ding_'.$post->ID])) echo ' done';?>"><span class="post-comments"><i class="like icon"></i>喜欢</span> <small  class="count"><?php if( get_post_meta($post->ID,'bigfa_ding',true) ){ echo get_post_meta($post->ID,'bigfa_ding',true); } else {echo '0'; }?></small>
        </a>
        </div>
    <h2> <?php the_title(); ?><span class="picshowtxt_left"><span>1</span>/<i><?php echo get_post_images_number().'' ?></i></span></h2>
    <div class="source">
      <div class="source_left">
	  <div class="bdsharebuttonbox"style="height:30px;">
<a href="#" class="bds tsina" data-cmd="tsina" title="分享到新浪微博">新浪微博</a>
<a href="#" class="bds tqq" data-cmd="tqq" title="分享到腾讯微博">腾讯微博</a>
<a href="#" class="bds weixin" data-cmd="weixin" title="分享到微信">微信</a>
<a href="#" class="bds sqq" data-cmd="sqq" title="分享到QQ好友">QQ好友</a>
<a href="#" class="bds qq" data-cmd="qzone" title="分享到QQ空间">QQ空间</a>
</div>	
	</div>
      <div class="source_right">
        <div class="support"> 支持<img src="http://localhost/123/images/jiantou1.jpg" />键翻阅图片 </div>
		<span>|</span><?php $category = get_the_category();if($category[0]){echo '<a class="cate icon" href="'.get_category_link($category[0]->term_id ).'">'.$category[0]->cat_name.'</a>';} ?>
		
        <span>|</span><a href="javascript:;" class="list icon">全部图片</a> </div>
      <div class="source_right1">
	  <?php $category = get_the_category();if($category[0]){echo '<a class="cate icon" href="'.get_category_link($category[0]->term_id ).'">'.$category[0]->cat_name.'</a>';} ?>

        <span>|</span>
	  <a href="javascript:;" class="cont icon gaoqing">幻灯片浏览</a> </div>
    </div>  </div>
	  <div class="piccontext"style="width:1050px;padding-left:50px;">
      <!--列表展示-->
    <div class="piclistshow">
	<ul>
     <?php the_content(); ?>
	 </ul>
    </div>
	   <!--列表展示end-->
  </div>
</div>
<!--结束-->
	
			
		<?php endwhile; ?>

<div class="recent-article"style="margin-top:20px;">
			<div class="mod-tit">
				<h2 class="tit">猜你喜欢</h2><a href="#" class="more">更多相关图集<span class="icon-shape"></span></a>
			</div>
			<ul class="xg">
<?php get_template_part( 'inc/xg' ); ?>			</ul>
		</div>
    </div>
<?php get_footer(); ?>