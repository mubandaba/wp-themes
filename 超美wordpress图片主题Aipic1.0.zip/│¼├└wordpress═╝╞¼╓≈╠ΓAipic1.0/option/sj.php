<?php

$data=array(
	'tab-1'=>array('type'=>'tab1'),
	
	'ad1_kg'=>array('title'=>'显示首页广告位','value'=>array('显示'=>'true'),'type'=>'checkbox'),
        'ad1'=>array('title'=>'首页广告位','type'=>'textarea','width'=>'500px','height'=>'100px','tips'=>'输入侧栏广而告之html代码'),
        'ad3_kg'=>array('title'=>'显示分类页广告位','value'=>array('显示'=>'true'),'type'=>'checkbox'),
        'ad7'=>array('title'=>'分类页广告位','type'=>'textarea','width'=>'500px','height'=>'100px','tips'=>'输入侧栏广而告之html代码'),
	'ad5_kg'=>array('title'=>'显示预览页广告位','value'=>array('显示'=>'true'),'type'=>'checkbox'),
        'ad9'=>array('title'=>'预览页广告位','type'=>'textarea','width'=>'500px','height'=>'100px','tips'=>'输入侧栏广而告之html代码'),
        'ad21_kg'=>array('title'=>'显示预览页广告位','value'=>array('显示'=>'true'),'type'=>'checkbox'),
        'ad15'=>array('title'=>'预览页广告位','type'=>'textarea','width'=>'500px','height'=>'100px','tips'=>'输入侧栏广而告之html代码'),
	
	
	
	
	'tab-2'=>array('type'=>'tab2'),
	
	'xlwb'=>array('title'=>'网站统计','type'=>'textarea','width'=>'500px','height'=>'50px','tips'=>'输入网站统计代码'),
	'qqqh'=>array('title'=>'ICP备案号','type'=>'textarea','width'=>'200px','height'=>'25px','tips'=>'输入icp备案号'),	
	'foot-1'=>array('title'=>'底部版权','type'=>'textarea','width'=>'500px','height'=>'100px','tips'=>'输入底部版权文本、统计代码等html代码'),
	'foot-2'=>array('title'=>'其它代码','type'=>'textarea','width'=>'500px','height'=>'100px','tips'=>'输入分享、浮动客服等js代码'),

       'tab-3'=>array('type'=>'tab3'),
       'ad1_k'=>array('title'=>'主题显示模式','value'=>array('普通列表'=>'true','cms列表(启用此项下面的项目才能生效，并且分类不可少于4个)'=>'open'),'type'=>'checkbox'),
        'list'=>$args=array('title'=>'首页区域1显示内容','type'=>'cat'),
        'list1'=>$args=array('title'=>'首页区域2显示内容','type'=>'cat'),
        'list2'=>$args=array('title'=>'首页区域3显示内容','type'=>'cat'),
        'list3'=>$args=array('title'=>'首页区域4显示内容','type'=>'cat'),
);