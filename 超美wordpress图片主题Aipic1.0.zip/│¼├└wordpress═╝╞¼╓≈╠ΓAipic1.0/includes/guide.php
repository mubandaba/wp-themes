<?php
add_action('admin_menu', 't_guide');
function t_guide() {
	add_menu_page('爱牛主题NO.14使用说明', '主题指南', 6, 'user_guide', 't_guide_options');
}
function t_guide_options() {
?>
<div class="wrap">
	<div class="opwrap" style="line-height: 90%; margin:10px auto; width:95%; padding:5px 20px;" >
		<div id="wrapr">
			<div class="headsection">
				<h3 style="clear:both; padding:2px 10px; color:#444; font-size:18px;">爱牛主题使用说明</h3>
			</div>
			<div class="gblock" style="padding:0 10px;" >
				<p style="color:#ff0000; font-size:16px;">版权声明：您可以使用和修改本主题！如需更多功能请联系QQ：735901574 使用中有任何问题都可以反馈给我，我尽力解决。</p>
				<p style="clear:both; padding: 0 10px; color:#444; font-size:14px;"><font style="font-size:20px;"color=#ff0000><strong> &hearts; </strong></font><font color=#000>支持主题设计者：<a href="http://www.ainiu88.com" target="_blank"> 奋斗族丶小牛 </a>，演示站：<font color=#21759b><strong>http://www.rosimm.wang</strong></font>    点击此处查看最新版：<a href="http://www.rosimm.wang/aipic" target="_blank"> 点击查看更新</a></p>
			</div>
			<div class="gblock">
				<p><iframe src="http://www.rosimm.wang/" width="100%" height="800" frameborder="0"></iframe></p>
			</div>
		</div>
	</div>
</div>
<?php }; ?>