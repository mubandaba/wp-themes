<?php
/*****Meta Box********/
$ashu_meta = array();
$meta_conf = array('title' => '文章显示位置选择', 'id'=>'seobox', 'page'=>array('page','post'), 'context'=>'normal', 'priority'=>'low', 'callback'=>'');

$ashu_meta[] = array(
  'name'    => 'radio',
  'id'      => '_id_radio',
  'desc'    => '注意：选择幻灯片时必须设置4个以上才能正常显示。并且上传幻灯片图像。',
  'std'     => '',
  'buttons' => array(
  'hdp'      => '幻灯片（设置3个以上生效）',
	'qx'      => '取消设置',
  ),
  'type'    => 'radio'
);

$ashu_meta[] = array(
  'name'    => '是否显示下载按钮（高级版功能）',
  'id'      => 'demo_url',
  'desc'    => '显示下载按钮时请输入图集的下载地址',
  'std'     => '',
  'buttons' => array(
  'hdp'      => '显示',
  ),
  'type'    => 'checkbox'
);

$ashu_meta[] = array(
  'name' => '下载链接',
  'id'   => 'demo_url2',
  'desc' => '可以是百度网盘、360网盘、或者普通链接',
  'std'  => '',
  'size' => array(50,1),
  'type' => 'textarea'
);

$ashu_meta[] = array(
  'name' => '网盘密码',
  'id'   => 'demo_url3',
  'desc' => '在独立下载页面中显示',
  'std'  => '',
  'size' => array(30,1),
  'type' => 'textarea'
);

$ashu_meta[] = array(
  'name' => '幻灯片图像上传',
  'id'   => '_id_upload',
  'desc' => '不选择“幻灯片”时不用设置',
  'std'  => '',
  'button_text' => 'Upload',
  'size' => 80,
  'type' => 'upload'
);

$ashu_meta[] = array(
  'name' => '图集描述',
  'id'   => '_id_textarea',
  'desc' => '显示在图集预览页面（高级版功能）',
  'std'  => '',
  'size' => array(80,5),
  'type' => 'textarea'
);

$new_box = new ashu_meta_box($ashu_meta, $meta_conf);
?>