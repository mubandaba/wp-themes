    <footer>
		<div class="footer-inner content clear">
			<div class="footer-part">
				<p>Copyright © 2015 <?php bloginfo('name')?> All Rights Reserved   <?php echo stripslashes( get_option( 'qqqh' ) ); ?>  |  <?php echo stripslashes( get_option( 'xlwb' ) ); ?><a href="http://www.rosimm.wang/sitemap.html" style="color:#CC5252">网站地图</a></p>
			</div>
<p style="width:1100px;color:#69C743;float:left"><?php echo stripslashes( get_option( 'foot-1' ) ); ?></p>
<div><?php echo stripslashes( get_option( 'foot-2' ) ); ?></div>
      </div>
	</footer>
</div>

 
<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/hbby.js?ver=1.0"></script>
<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/cnxh.js?ver=1.0"></script>

</body>
</html>