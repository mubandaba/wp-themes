<?php

/*
 * ------------------------------------------------------------------------------
 * WordPress添加自定义菜单
 * ------------------------------------------------------------------------------
 */

register_nav_menus(
	array(
		'head-nav' => __( '顶部菜单' ),
		'page-nav' => __( '页面菜单' ),
	)
); 



/*
 * ------------------------------------------------------------------------------
 * WordPress分类描述删除p标签
 * ------------------------------------------------------------------------------
 */

function deletehtml($description) {
	$description = trim($description);
	$description = strip_tags($description,'');
	return ($description);
}
add_filter('category_description', 'deletehtml');


/*
 * ------------------------------------------------------------------------------
 * WordPress获取子分类
 * ------------------------------------------------------------------------------
 */

function get_category_root_id($cat) {  
	$this_category = get_category($cat); // 取得当前分类  
	while($this_category->category_parent) // 若当前分类有上级分类时，循环  
	{  
		$this_category = get_category($this_category->category_parent); // 将当前分类设为上级分类往上爬  
	}  
	return $this_category->term_id; // 返回根分类的id号  
}  
//获取子分类的父分类
function get_category_cat() { 
	$catID = get_query_var('cat'); // 当前分类ID
	$thisCat = get_category($catID);
	$parentCat = get_category($thisCat->parent);
	// 输出父分类的链接
	echo get_category_link($parentCat->term_id);
}


/*
 * ------------------------------------------------------------------------------
 * WordPress获取指定分类及其子分类下的文章数目
 * ------------------------------------------------------------------------------
 */

function wt_get_category_count($input = '') {
	global $wpdb;

	if($input == '') {
		$category = get_the_category();
		return $category[0]->category_count;
	}
	elseif(is_numeric($input)) {
		$SQL = "SELECT $wpdb->term_taxonomy.count FROM $wpdb->terms, $wpdb->term_taxonomy WHERE $wpdb->terms.term_id=$wpdb->term_taxonomy.term_id AND $wpdb->term_taxonomy.term_id=$input";
		return $wpdb->get_var($SQL);
	}
	else {
		$SQL = "SELECT $wpdb->term_taxonomy.count FROM $wpdb->terms, $wpdb->term_taxonomy WHERE $wpdb->terms.term_id=$wpdb->term_taxonomy.term_id AND $wpdb->terms.slug='$input'";
		return $wpdb->get_var($SQL);
	}
}


/*
 * ------------------------------------------------------------------------------
 * WordPress分页
 * ------------------------------------------------------------------------------
 */

function fenye(){
	$args = array(
		'prev_next'          => 0,
		'format'       => '?paged=%#%',
		'before_page_number' => '',
		'mid_size'           => 2,
		'current' => max( 1, get_query_var('paged') ),
		'prev_next'    => True,
		'prev_text'    => __('上一页'),
		'next_text'    => __('下一页'),

	);
	$page_arr=paginate_links($args); 
	if ($page_arr) {
		echo $page_arr;
	}else{

	}
}


/*
 * ------------------------------------------------------------------------------
 * 使子分类的category页面渲染父category页面的模板
 * ------------------------------------------------------------------------------
 */
add_filter('category_template', 'f_category_template');
function f_category_template($template){
	$category = get_queried_object();
	if($category->parent !='0'){
		while($category->parent !='0'){
			$category = get_category($category->parent);
		}
	}
	
	$templates = array();
 
	if ( $category ) {
		$templates[] = "category-{$category->slug}.php";
		$templates[] = "category-{$category->term_id}.php";
	}
	$templates[] = 'category.php';
	return locate_template( $templates );
}



