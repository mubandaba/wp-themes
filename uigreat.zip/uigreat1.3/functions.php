<?php


/*
* ------------------------------------------------------------------------------
* 加载后台框架
* ------------------------------------------------------------------------------
*/
include(TEMPLATEPATH . '/inc/codestar-framework/codestar-framework.php');



require_once(dirname(__FILE__) . '/inc/functions/enqueue.php');
require_once(dirname(__FILE__) . '/inc/functions/optimization.php');
require_once(dirname(__FILE__) . '/inc/functions/article.php');
require_once(dirname(__FILE__) . '/inc/functions/category.php');
require_once(dirname(__FILE__) . '/inc/functions/user.php');
require_once(dirname(__FILE__) . '/inc/functions/other.php');
require_once(dirname(__FILE__) . '/inc/functions/login-options.php');
require_once(dirname(__FILE__) . '/inc/functions/comment.php');

