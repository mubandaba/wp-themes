<?php
/**
Theme Name: Uazoh_2
Theme URI: http://www.uazoh.com
Author: 赵和邹设计工作室
Author URI: http://www.uazoh.com
Description: Uazoh第2个主题，采用全屏宽度，HTML5+CSS3+JQUERY结构，结构及文字采用相对长度单位em进行定义。
Version: 1.0
 */
if ( post_password_required() )
	return;
?>

<article class="is-post is-post-excerpt comments">
<?php if ( have_comments() ) : ?>
<header>
	<h2 class="comments-title"><?php comments_popup_link( '<span class="leave-reply">来第一个评论吧</span>','1 个评论', '% 个评论'); ?></h2>
</header>
		<ul class="commentlist">
			<?php wp_list_comments( array( 'callback' => 'uazohtwo_comment' ) ); ?>
		</ul><!-- .commentlist -->

		<?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) : ?>
		<nav id="comment-nav-below" class="navigation" role="navigation">
			<h1 class="assistive-text section-heading"><?php _e( 'Comment navigation', '' ); ?></h1>
			<div class="nav-previous"><?php previous_comments_link( __( '&larr; Older Comments', '' ) ); ?></div>
			<div class="nav-next"><?php next_comments_link( __( 'Newer Comments &rarr;', '' ) ); ?></div>
		</nav>
		<?php endif; ?>

		<?php if ( ! comments_open() && get_comments_number() ) : ?>
		<p class="nocomments"><?php _e( 'Comments are closed.' , '' ); ?></p>
		<?php endif; ?>

<?php endif; ?>
<?php comment_form(); ?>

</article>