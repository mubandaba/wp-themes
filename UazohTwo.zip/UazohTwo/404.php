<?php
/**
Theme Name: Uazoh_2
Theme URI: http://www.uazoh.com
Author: 赵和邹设计工作室
Author URI: http://www.uazoh.com
Description: Uazoh第2个主题，采用全屏宽度，HTML5+CSS3+JQUERY结构，结构及文字采用相对长度单位em进行定义。
Version: 1.0
 */

get_header(); ?>

<div id="content" class="equalHeights">
	<div id="content-inner">

			<article class="is-post is-post-excerpt">
				<header>
					<h2>对不起，页面找不回来了</h2>
				</header>
				<div class="info">
					<span class="data">404</span>
				</div>
				<div class="baby_mod">
    <div class="bd">
    	<div class="title_sub"><h3>但我们可以一起寻找失踪宝贝</h3></div>
    	<div class="baby_data" id="baby_data"></div>
    </div>
    <div class="ft">
        <div class="bt_box">
        	<div class="api404">公益404接入地址：<a href="http://www.qq.com/404/" target="_blank" rel="nofollow">http://www.qq.com/404/</a></div>
            <div class="api404">失踪儿童信息来自<a href="http://bbs.baobeihuijia.com/" target="_blank" rel="nofollow">宝贝回家寻子网</a></div>
        </div>
    </div>
</div>
			</article>
		</div>
	</div>
<script type="text/javascript" charset="utf-8" src="http://qzonestyle.gtimg.cn/qzone_v6/lostchild/data.js"></script>
<script type="text/javascript" charset="utf-8"  src="http://mat1.gtimg.com/www/austin/xr/babygh_v1.0.2.js"></script>

<?php get_footer(); ?>