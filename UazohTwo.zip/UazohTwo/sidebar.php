<?php
/**
Theme Name: Uazoh_2
Theme URI: http://www.uazoh.com
Author: 赵和邹设计工作室
Author URI: http://www.uazoh.com
Description: Uazoh第2个主题，采用全屏宽度，HTML5+CSS3+JQUERY结构，结构及文字采用相对长度单位em进行定义。
Version: 1.0
 */
?>
<!-- Search -->
<section class="is-search">
<form method="get" id="searchform" action="<?php echo $_SERVER['PHP_SELF']; ?>">
<input type="text" class="text" name="s" id="s" placeholder="找呀找呀找朋友" /><input type="submit" class="submit" value=" " />
</form>
</section>
<!-- social -->	
<section class="social pull-center">
<ul>
	<li><a class="sinaweibo" title="新浪微博" target="_blank" href="<?php echo get_option('mytheme_sinaweibo'); ?>"> 新浪微博 </a></li>
	<li><a class="tencentweibo" title="腾讯微博" target="_blank" href="<?php echo get_option('mytheme_tencentweibo'); ?>"> 腾讯微博 </a></li>
	<li><a class="weixin" onmouseover="onMouseover()" onmouseout="onMouseout()" title="微信" href="javascript:void(0)"> 微信 </a></li>
	<li><a class="email" title="Email" target="_blank" href="mailto:<?php echo get_option('mytheme_email'); ?>"> Email </a></li>
	<li><a class="feed" title="RSS订阅" target="_blank" href="<?php echo get_bloginfo('rss2_url'); ?>"> RSS订阅 </a></li>
</ul>
<div class="clear"></div>
<div class="weixin-detail" id="weixin_detail" style="display: none;">
<div class="weixin-qr"></div>
<span>微信扫一扫!</span>
</div>
</section>
<!-- 其他侧边栏 -->	
<?php dynamic_sidebar( 'sidebar-1' ); ?>
