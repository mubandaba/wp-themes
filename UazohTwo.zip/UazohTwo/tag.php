<?php
/**
Theme Name: Uazoh_2
Theme URI: http://www.uazoh.com
Author: 赵和邹设计工作室
Author URI: http://www.uazoh.com
Description: Uazoh第2个主题，采用全屏宽度，HTML5+CSS3+JQUERY结构，结构及文字采用相对长度单位em进行定义。
Version: 1.0
 */
get_header(); ?>

	<div id="content" class="equalHeights">
	<div id="content-inner">
<?php if ( have_posts() ) : ?>
<?php while ( have_posts() ) : the_post(); ?>
			<article class="is-post is-post-excerpt">
				<header>
					<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
					<span class="byline">作者：<?php the_author(); ?><?php the_tags('  |  标签： ', ' , ' , ''); ?></span>
				</header>
				<div class="info">
					<span class="data"><?php printf( __( '%s', 'uazohtwo' ), '<span>' . single_tag_title( '', false ) . '</span>' ); ?></span>
				</div>
				<?php if (has_post_thumbnail()){?>
				<a href="<?php the_permalink() ?>" class="image image-full" title="<?php the_title(); ?>"><img src="<?php echo PostThumbURL(); ?>" alt="<?php the_title(); ?>" /></a>
				<?php }else if (catch_that_image()) {?>
				<a href="<?php the_permalink() ?>" class="image image-full" title="<?php the_title(); ?>"><img src="<?php echo catch_that_image(); ?>" alt="<?php the_title(); ?>" /></a>
				<?php } ?>
				<p>
				<?php if ( is_home() || is_category() || is_archive() ) {
							the_excerpt();
						} else {
							the_content();
						} ?>
				</p>
				<p id="post_<?php the_ID(); ?>"> </p>
			</article>
			<?php endwhile; else : ?>
			<?php endif; ?>
<article class="is-post is-post-excerpt margintop">
<div class="info">
<span class="f_linkspan">友情链接</span>
</div>
<p class="paddingt bortop">
<?php   
$footerargs = array(   
    'echo' => true,   
    'container' => false,   
    'sort_column' => 'menu_order',   
    'menu_id'=>'footer_nav_id',   
    'depth'=>1,   
    'menu_class'=>'f_link',   
    'theme_location' => 'link-menu', 
);   
wp_nav_menu($footerargs); 
?> 
</p>
</article>

	</div>
	<span id="bottom">&nbsp;</span>
</div>
<?php get_footer(); ?>