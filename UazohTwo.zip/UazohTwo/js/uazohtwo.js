/*
Theme Name: Uazoh_2
Theme URI: http://www.uazoh.com
Author: 赵和邹设计工作室
Author URI: http://www.uazoh.com
Description: Uazoh第2个主题，采用全屏宽度，HTML5+CSS3+JQUERY结构，结构及文字采用相对长度单位em进行定义。
Version: 1.0
*/
//返回顶部
$(window).scroll(function(a){
	var y=$(this).scrollTop();
	if(y>=500){
		if(
		$('#ui-scrolltop').is(':hidden')
			)
		$('#ui-scrolltop').fadeIn(600)
		}else{
			if(
			$('#ui-scrolltop').is(':visible')
			)
			$('#ui-scrolltop').fadeOut(400)
			}
	if(y<=499){
		if(
		$('#ui-scrollbottom').is(':hidden')
			)
		$('#ui-scrollbottom').fadeIn(600)
		}else{
			if(
			$('#ui-scrollbottom').is(':visible')
			)
			$('#ui-scrollbottom').fadeOut(400)
			}
});

//social

function onMouseover() {
        var obj = document.getElementById("weixin_detail");
        obj.style.display = "block"
}
function onMouseout() {
        var obj = document.getElementById("weixin_detail");
        obj.style.display = "none"
} 

//等高

(function($){$.fn.equalHeights=function(){var maxHeight=0,$this=$(this);$this.each(function(){var height=$(this).innerHeight();if(height>maxHeight){maxHeight=height}});return $this.height(maxHeight)};var target=$('[data-heights="equal"]').attr('data-targets'),init='[data-heights="equal"] '+target;$(init).equalHeights()})(jQuery);

$(function(){ $('.equalHeights').equalHeights(); });