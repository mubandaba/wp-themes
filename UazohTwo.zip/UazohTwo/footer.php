<?php
/**
Theme Name: Uazoh_2
Theme URI: http://www.uazoh.com
Author: 赵和邹设计工作室
Author URI: http://www.uazoh.com
Description: Uazoh第2个主题，采用全屏宽度，HTML5+CSS3+JQUERY结构，结构及文字采用相对长度单位em进行定义。
Version: 1.0
 */
?>
<div id="sidebar" class="equalHeights">

	<!-- Logo -->
		<div id="logo">
			<h1><?php bloginfo( 'name' ); ?></h1>
		</div>

	<!-- 菜单 -->
		<nav id="nav_menu_list">
			<?php   $menuargs = array(  'echo' => true,  'container' => false, 'show_home'   => true, 'sort_column' => 'menu_order',  'menu_id'=>'nav',  'depth'=>1,   'menu_class'=>'nav',  'theme_location' => 'primary', );  wp_nav_menu($menuargs); ?> 
		</nav>
		<?php get_sidebar(); ?>
	<!-- Copyright -->
		<div id="copyright">
			<p>
				&copy; <SCRIPT type=text/javascript>document.write(new Date().getFullYear());</SCRIPT> <?php bloginfo('name'); ?><br />
				Powered by <a target="_blank" href="http://wordpress.org/" title="WordPress主页" rel="external nofollow">WordPress</a><br />
				THEme by <a href="http://www.uazoh.com" target="_blank">Uazoh</a><br />
				 <a href="http://www.miitbeian.gov.cn/" target="_blank" title="<?php echo get_option('mytheme_icpbeian'); ?>" rel="nofollow"><?php echo get_option('mytheme_icpbeian'); ?></a><br />
			</p>
		</div>
		<?php echo get_option('mytheme_analytics_after'); ?>
		</div>
</div>
			<!-- Wrapper END -->
<a rel="nofollow" href="#top" id="ui-scrolltop" title="返回顶部" style="display:none;">返回顶部</a>
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery-1.9.1.min.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/uazohtwo.js"></script>

	</body>
</html>