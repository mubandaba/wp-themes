<?php

//页面内部关键词
add_filter('the_content', 'replace_text_wps');
add_filter('the_excerpt', 'replace_text_wps');
function replace_text_wps($text){
	$replace = array(
	'主页' => '<a href="http://www.uazoh.com" title="主页" rel="nofollow">主页</a>',
	'wordpress' => '<a href="http://wordpress.org" title="wordpress" rel="nofollow">wordpress</a>',
	'百度' => '<a href="http://www.baidu.com" title="百度" rel="nofollow">百度</a>',
	'微信' => '<a onmouseover="onMouseover()" onmouseout="onMouseout()" title="微信" href="#" >微信</a>',
	'微博' => '<a href="http://t.qq.com/kazegt" title="微博" rel="nofollow">微博</a>',
	//'QQ' => '<a target="_blank" href="http://sighttp.qq.com/authd?IDKEY=23798c7dfcb4ca52f78f5739ee6403414b4cad0b6027fbd4" title="QQ" rel="nofollow">QQ</a>',
	);
	$text = str_replace(array_keys($replace), $replace, $text);
	return $text;
}

//整体注册
register_nav_menus(   //菜单
    array(   
        'primary' => '主导航菜单',
        'link-menu' => '友情链接菜单',   
    )   
); 
add_theme_support( 'post-thumbnails' );//文章特色图片
add_editor_style();
add_theme_support( 'automatic-feed-links' );
add_theme_support( 'post-formats', array( 'aside', 'image', 'link', 'quote', 'status' ) );
update_option('image_default_link_type', 'file');//图片默认连接到媒体文件(原始链接)

//wp_head()参数冗余删减
remove_action( 'wp_head', 'wlwmanifest_link' );   
remove_action( 'wp_head', 'index_rel_link' );   
remove_action( 'wp_head', 'parent_post_rel_link', 10, 0 );   
remove_action( 'wp_head', 'start_post_rel_link', 10, 0 );   
remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0 );   
remove_action( 'wp_head', 'wp_generator' );   
remove_action( 'wp_head', 'wp_shortlink_wp_head', 10, 0 );   
remove_action( 'template_redirect', 'wp_shortlink_header', 11, 0 );  
//remove_action( 'wp_head', 'locale_stylesheet' );   
//remove_action( 'publish_future_post', 'check_and_publish_future_post', 10, 1 );   
//remove_action( 'wp_head', 'noindex', 1 );   
//remove_action( 'wp_head', 'wp_print_styles', 8 );   
//remove_action( 'wp_head', 'wp_print_head_scripts', 9 );   
//remove_action( 'wp_head', 'wp_enqueue_scripts', 1 );   
//remove_action( 'wp_head', 'feed_links', 2 );   
//remove_action( 'wp_head', 'feed_links_extra', 3 );   
//remove_action( 'wp_head', 'rsd_link' );  
//remove_action( 'wp_head', 'rel_canonical' );   
//remove_action( 'wp_footer', 'wp_print_footer_scripts' );    

add_filter('preprocess_comment', 'commentpass');

//自定义标题内容
function uazohtwo_wp_title( $title, $sep ) {
	global $paged, $page;
	if ( is_feed() )
		return $title;
	$title .= get_bloginfo( 'name' );
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) )
		$title = "$title $sep $site_description";
	if ( $paged >= 2 || $page >= 2 )
		$title = "$title $sep " . sprintf( __( '第%s页', 'uazohone' ), max( $paged, $page ) );
	return $title;
}
add_filter( 'wp_title', 'uazohtwo_wp_title', 10, 2 );

//添加后台定义字段
add_action('admin_menu', 'mytheme_page');
function mytheme_page (){
	if ( count($_POST) > 0 && isset($_POST['mytheme_settings']) ){
		$options = array ('keywords','description','analytics_before','analytics_after','icpbeian','email','sinaweibo','tencentweibo');
		foreach ( $options as $opt ){
			delete_option ( 'mytheme_'.$opt, $_POST[$opt] );
			add_option ( 'mytheme_'.$opt, $_POST[$opt] );	
		}
	}
add_theme_page(__('SEO设置'), __('SEO设置'), 'edit_themes', basename(__FILE__), 'mytheme_settings');
}
function mytheme_settings(){?>
<div class="wrap">
<h2>SEO设置</h2>
<form method="post" action="">
<p class="submit">
<input type="submit" name="Submit" class="button-primary" value="保存设置" />
<input type="hidden" name="mytheme_settings" value="save" style="display:none;" />
</p>
<p>
<h3><strong>备案信息</strong></h3>
<textarea name="icpbeian" id="icpbeian" rows="3" cols="100"><?php echo get_option('mytheme_icpbeian'); ?></textarea><br />
</p>
<p>
<h3><strong>网站关键词（Meta Keywords）</strong></h3>
<textarea name="keywords" id="keywords" rows="3" cols="100"><?php echo get_option('mytheme_keywords'); ?></textarea><br />
</p><p>
中间用半角逗号隔开。<br />
</p><p>
<h3><strong>网站描述（Meta Description）</strong></h3>
<textarea name="description" id="description" rows="3" cols="100"><?php echo get_option('mytheme_description'); ?></textarea><br />
</p><p>
针对搜索引擎设置的网页描述。<br />
</p><p>
<h3><strong>异步统计代码添加</strong></h3>
<textarea name="analytics_before" id="analytics_before" rows="5" cols="100"><?php echo stripslashes(get_option('mytheme_analytics_before')); ?></textarea>
</p><p>
<h3><strong>统计代码添加</strong></h3>
<textarea name="analytics_after" id="analytics_after" rows="5" cols="100"><?php echo stripslashes(get_option('mytheme_analytics_after')); ?></textarea>
</p>
 <p>
<h3><strong>email</strong></h3>
<textarea name="email" id="email" rows="2" cols="100"><?php echo get_option('mytheme_email'); ?></textarea>
<br />
</p>
 <p>
<h3><strong>新浪微博</strong></h3>
<textarea name="sinaweibo" id="sinaweibo" rows="2" cols="100"><?php echo get_option('mytheme_sinaweibo'); ?></textarea>
<br />
</p>
 <p>
<h3><strong>腾讯微博</strong></h3>
<textarea name="tencentweibo" id="tencentweibo" rows="2" cols="100"><?php echo get_option('mytheme_tencentweibo'); ?></textarea>
<br />
</p>
<p class="submit">
<input type="submit" name="Submit" class="button-primary" value="保存设置" />
<input type="hidden" name="mytheme_settings" value="save" style="display:none;" />
</p>
<?php }

// 禁止全英文评论
function commentpass( $incoming_comment ) {
    $pattern = '/[一-龥]/u';
    if(!preg_match($pattern, $incoming_comment['comment_content'])) {
        wp_die( "您的评论中必须包含汉字!" );
    }
    return( $incoming_comment );
}

//分页代码
if ( ! function_exists( 'uazohtwo_content_nav' ) ) :
function uazohtwo_content_nav($query_string){   
global $posts_per_page, $paged;   
$my_query = new WP_Query($query_string ."&posts_per_page=-1");   
$total_posts = $my_query->post_count;   
if(empty($paged))$paged = 1;   
$prev = $paged - 1;   
$next = $paged + 1;   
$range = 2;   
$showitems = ($range * 2)+1;   
$pages = ceil($total_posts/$posts_per_page);   
if(1 != $pages){   
echo "<div class='pager'>";   
echo ($paged > 2 && $paged+$range+1 > $pages && $showitems < $pages)? "<a href='".get_pagenum_link(1)."' class='button'>最前</a>":"";   
echo ($paged > 1 && $showitems < $pages)? "<a href='".get_pagenum_link($prev)."' class='button'>上一页</a>":"";   
echo "<div class='pages'>";
for ($i=1; $i <= $pages; $i++){   
if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems )){   
echo ($paged == $i)? "<a href='#' class='active'>".$i."</a>":"<a href='".get_pagenum_link($i)."'>".$i."</a>";   
}}
echo "</div>";
echo ($paged < $pages && $showitems < $pages) ? "<a href='".get_pagenum_link($next)."' class='button'>下一页</a>" :"";   
echo ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) ? "<a href='".get_pagenum_link($pages)."' class='button'>最后</a>":"";   
echo "</div>\n";   
}}endif;

//获取查看数
function getPostViews($postID){
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return "0";
    }
    return $count;
}
function setPostViews($postID) {
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}

//获取文章特色图片
function PostThumbURL() {
    global $post, $posts;
    $thumbnail = '';
    ob_start();the_post_thumbnail();$toparse=ob_get_contents();ob_end_clean();
    preg_match_all('/src=("[^"]*")/i', $toparse, $img_src); $thumbnail = str_replace("\"", "", $img_src[1][0]);
    return $thumbnail;
	set_post_thumbnail_size( 300,270, true ); 
}
//获取文章首张图片
function catch_that_image() {
  global $post, $posts;
  $first_img = '';
  ob_start();
  ob_end_clean();
  $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
  $first_img = $matches [1] [0];
  if(empty($first_img)){ //设置默认图片，在文中没有图片是显示
        $first_img = "/wp-content/themes/uazohtwo/css/images/theme01.png";
  }
  return $first_img;
  set_post_thumbnail_size( 300,270, true ); 
}

//截取摘要
function custom_excerpt_length( $length ) {
	return 230;
}
add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );
function new_excerpt_more( $more ) {
	return '<a class="read-more" href="'. get_permalink( get_the_ID() ) . '">[ 更多... ]</a>';
}
add_filter('excerpt_more', 'new_excerpt_more');

//侧边栏 
function uazohtwo_widgets_init() {
	register_sidebar( array(
		'name' =>'侧边栏',
		'id' => 'sidebar-1',
		'description' => '请把部件拖拽过来',
		'before_widget' => '<section id="%1$s" class="%2$s is-text-style1">',
		'after_widget' => '</section>',
		'before_title' => '<header><h2>',
		'after_title' => '</h2></header>',
	) );
}
add_action( 'widgets_init', 'uazohtwo_widgets_init' );

//禁用评论内的HTML
function plc_comment_post( $incoming_comment ) {
	$incoming_comment['comment_content'] = htmlspecialchars($incoming_comment['comment_content']);
	$incoming_comment['comment_content'] = str_replace( "'", '&apos;', $incoming_comment['comment_content'] );
	return( $incoming_comment );
}

function plc_comment_display( $comment_to_display ) {
	$comment_to_display = str_replace( '&apos;', "'", $comment_to_display );
	return $comment_to_display;
}
add_filter('preprocess_comment', 'plc_comment_post', '', 1);
add_filter('comment_text', 'plc_comment_display', '', 1);
add_filter('comment_text_rss', 'plc_comment_display', '', 1);
add_filter('comment_excerpt', 'plc_comment_display', '', 1);

//评论重整和
if ( ! function_exists( 'uazohtwo_comment' ) ) :
function uazohtwo_comment( $comment, $args, $depth ) {
	$GLOBALS['comment'] = $comment;
	switch ( $comment->comment_type ) :
		case 'pingback' :
		case 'trackback' :

	?>
<li class="comment reply_to row">
<div class="commentnums">pingback</div>
<div class="span1">
<?php echo get_avatar( $comment, 60 );
	printf( '</div><div class="borderbottom"><div class="span5"><div class="name">%1$s %2$s',
		get_comment_author_link(),

		( $comment->user_id === $post->post_author ) ? '<span> ' . ''. '</span>' : ''
	);
	comment_reply_link( array_merge( $args, array( 'reply_text' => '回复', 'after' => ' ', 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) );
	edit_comment_link( '编辑', '', '' );
	printf( '</div>');
	
	printf( '<div class="date">%3$s</div></div></div><div class="clear"></div>',
		esc_url( get_comment_link( $comment->comment_ID ) ),
		get_comment_time( 'c' ),

		sprintf( '%1$s  %2$s', get_comment_date(), get_comment_time() )
	);
?>

<?php if ( '0' == $comment->comment_approved ) : ?>
<div class="response sh">你的评论正在等待审核。</div>
<?php endif; ?>
<div class="response"><?php comment_text(); ?></div>

<?php break;default : global $post;?>
<li class="comment row" id="comment-<?php comment_ID(); ?>">
<div class="commentnums"><?php comment_ID(); ?></div>
<div class="span1">
<?php echo get_avatar( $comment, 60 );
	printf( '</div><div class="borderbottom"><div class="span5"><div class="name">%1$s %2$s',
		get_comment_author_link(),

		( $comment->user_id === $post->post_author ) ? '<span> ' . ''. '</span>' : ''
	);
	comment_reply_link( array_merge( $args, array( 'reply_text' => '回复', 'after' => ' ', 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) );
	edit_comment_link( '编辑', '', '' );
	printf( '</div>');
	
	printf( '<div class="date">%3$s</div></div></div><div class="clear"></div>',
		esc_url( get_comment_link( $comment->comment_ID ) ),
		get_comment_time( 'c' ),

		sprintf( '%1$s  %2$s', get_comment_date(), get_comment_time() )
	);
?>

<?php if ( '0' == $comment->comment_approved ) : ?>
<div class="response sh">你的评论正在等待审核。</div>
<?php endif; ?>
<div class="response"><?php comment_text(); ?></div>

<?php break;endswitch;}endif;