<?php
/**
Theme Name: Uazoh_2
Theme URI: http://www.uazoh.com
Author: 赵和邹设计工作室
Author URI: http://www.uazoh.com
Description: Uazoh第2个主题，采用全屏宽度，HTML5+CSS3+JQUERY结构，结构及文字采用相对长度单位em进行定义。
Version: 1.0
 */
?>

	<article class="is-post is-post-excerpt">
				<header>
					<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
					<span class="byline">作者：<?php the_author(); ?><?php the_tags('  |  标签： ', ' , ' , ''); ?></span>
				</header>
				<div class="info">
					<span class="date"><span class="month"><?php the_time('M') ?><small>月</small></span> <span class="day"><?php the_time('d') ?></span><span class="year"><?php the_time('Y') ?></span></span>
					<ul class="stats">
						<li><?php comments_popup_link('0', '1 ', '% ', 'link-icon24 link-icon24-1'); ?></li>
						<li><a href="#" class="link-icon24 link-icon24-2"><?php setPostViews(get_the_ID()); echo getPostViews(get_the_ID()); ?>
</a></li>
						<li><a href="mailto:<?php  echo the_author_meta( 'user_email' ); ?>" class="link-icon24 link-icon24-4">me</a></li>
					</ul>
				</div>
				<?php if (has_post_thumbnail()){?>
				<a href="<?php the_permalink() ?>" class="image image-full" title="<?php the_title(); ?>"><img src="<?php echo PostThumbURL(); ?>" alt="<?php the_title(); ?>" /></a>
				<?php }else if (catch_that_image()) {?>
				<a href="<?php the_permalink() ?>" class="image image-full" title="<?php the_title(); ?>"><img src="<?php echo catch_that_image(); ?>" alt="<?php the_title(); ?>" /></a>
				<?php } ?>
				<p>
				<?php if ( is_home() || is_category() || is_archive() ) {
							the_excerpt();
						} else {
							the_content();
						} ?>
				</p>
				<p id="post_<?php the_ID(); ?>"> </p>
			</article>
	

