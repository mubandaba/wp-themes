<?php
/**
Theme Name: Uazoh_2
Theme URI: http://www.uazoh.com
Author: 赵和邹设计工作室
Author URI: http://www.uazoh.com
Description: Uazoh第2个主题，采用全屏宽度，HTML5+CSS3+JQUERY结构，结构及文字采用相对长度单位em进行定义。
Version: 1.0
 */

get_header(); ?>

<div id="content" class="equalHeights">
	<div id="content-inner">
		<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			<article class="is-post is-post-excerpt">
				<header>
					<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
					<span class="byline">作者：<?php the_author(); ?>  |  <?php the_tags('标签： ', ' , ' , ''); ?></span>
				</header>
				<div class="info">
					<span class="data"><?php printf( '搜索 %s', '<span class="day">' . get_search_query() . '</span>' ); ?></span>
				</div>
				<?php if (has_post_thumbnail()){?>
				<a href="<?php the_permalink() ?>" class="image image-full" title="<?php the_title(); ?>"><img src="<?php echo PostThumbURL(); ?>" alt="<?php the_title(); ?>" /></a>
				<?php }else if (catch_that_image()) {?>
				<a href="<?php the_permalink() ?>" class="image image-full" title="<?php the_title(); ?>"><img src="<?php echo catch_that_image(); ?>" alt="<?php the_title(); ?>" /></a>
				<?php } ?>
				<p>
				<?php the_excerpt(); ?>
				</p>
				<p id="post_<?php the_ID(); ?>"> </p>
			</article>
			<?php endwhile; else : ?>
			<article class="is-post is-post-excerpt">
				<header>
					<?php printf( '搜索 %s', '<span class="day">' . get_search_query() . '</span>' ); ?>。对不起，没有搜索到您要找的内容</a>
				</header>
				<div class="baby_mod">
    <div class="bd">
    	<div class="title_sub"><h3>但我们可以一起寻找失踪宝贝</h3></div>
    	<div class="baby_data" id="baby_data"></div>
    </div>
    <div class="ft">
        <div class="bt_box">
        	<div class="api404">公益404接入地址：<a href="http://www.qq.com/404/" target="_blank" rel="nofollow">http://www.qq.com/404/</a></div>
            <div class="api404">失踪儿童信息来自<a href="http://bbs.baobeihuijia.com/" target="_blank" rel="nofollow">宝贝回家寻子网</a></div>
        </div>
    </div>
</div>
<script type="text/javascript" charset="utf-8" src="http://qzonestyle.gtimg.cn/qzone_v6/lostchild/data.js"></script>
<script type="text/javascript" charset="utf-8"  src="http://mat1.gtimg.com/www/austin/xr/babygh_v1.0.2.js"></script></article>
			<?php endif; ?>
<article class="is-post is-post-excerpt margintop">
<div class="info">
<span class="f_linkspan">友情链接</span>
</div>
<p class="paddingt bortop">
<?php   
$footerargs = array(   
    'echo' => true,   
    'container' => false,   
    'sort_column' => 'menu_order',   
    'menu_id'=>'footer_nav_id',   
    'depth'=>1,   
    'menu_class'=>'f_link',   
    'theme_location' => 'link-menu', 
);   
wp_nav_menu($footerargs); 
?> 
</p>
</article>

	</div>
	<span id="bottom">&nbsp;</span>
</div>
<?php get_footer(); ?>