<?php
/**
Theme Name: Uazoh_2
Theme URI: http://www.uazoh.com
Author: 赵和邹设计工作室
Author URI: http://www.uazoh.com
Description: Uazoh第2个主题，采用全屏宽度，HTML5+CSS3+JQUERY结构，结构及文字采用相对长度单位em进行定义。
Version: 1.0
 */
?>
<!DOCTYPE HTML>
<html>
<head>
<title>
<?php if ( is_home() ) {
        bloginfo('name'); echo " - "; bloginfo('description');
    } elseif ( is_category() ) {
        single_cat_title(); echo " - "; bloginfo('name');
    } elseif (is_single() || is_page() ) {
        single_post_title();
    } elseif (is_search() ) {
        echo "搜索结果"; echo " - "; bloginfo('name');
    } elseif (is_404() ) {
        echo '页面未找到!';
    } else {
        wp_title('',true);
    } ?>
</title>
<meta http-equiv="content-type" content="text/html; charset=<?php bloginfo( 'charset' ); ?>" />
<?php
//判断是否为首页
if (is_home()) {
$description =  get_option('mytheme_keywords');
$keywords =  get_option('mytheme_description');
//判断是否为文章页
} else if (is_single()) {
if ($post->post_excerpt) {$description = $post->post_excerpt;} else {
$description = mb_strimwidth(strip_tags(apply_filters('the_content',$post->post_content)),0,120);//截取的字数
}$keywords = '';$tags = wp_get_post_tags($post->ID);foreach ($tags as $tag ) {$keywords = $keywords . $tag->name . ',';}
//判断是否为分类页
} else if (is_category()) {$description = category_description();}
?>
<meta name="description" content="<?php echo $description; ?>”" />
<meta name="keywords" content="<?php echo $keywords; ?>”" />
<?php wp_head(); ?>
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/style.css" />
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<link rel="alternate" type="application/rss+xml" title="RSS 2.0 - 所有文章" href="<?php echo get_bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="application/rss+xml" title="RSS 2.0 - 所有评论" href="<?php bloginfo('comments_rss2_url'); ?>" />
<!--[if lte IE 9]><link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/ie9.css" /><![endif]-->
<!--[if lte IE 8]><script src="<?php echo get_template_directory_uri(); ?>/js/html5shiv.js"></script><link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/ie8.css" /><![endif]-->
<!--[if lte IE 7]><link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/ie7.css" /><![endif]-->
<?php echo get_option('mytheme_analytics_before'); ?>
</head>
<body class="left-sidebar"  id="top">
<a rel="nofollow" href="#bottom" id="ui-scrollbottom" title="返回顶部">返回顶部</a>
		<!-- Wrapper -->
			<div id="wrapper">

				