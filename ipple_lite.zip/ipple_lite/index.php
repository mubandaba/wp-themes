<?php get_header(); ?>

        <div id="content">
        	<div id="content-main">
                <div class="content-main-top">
                </div><!--/content-main-top -->
                <div class="content-main-body">
				<?php if (have_posts()) : ?>
				  <?php while (have_posts()) : the_post(); ?>
                    <div class="post" id="post-<?php the_ID(); ?>">
		 			  <div class="date"><span><?php the_time('M') ?></span> <?php the_time('d') ?></div><!--/date -->
                      <h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(''); ?></a></h2><!--/h2 post title -->
                      <div class="postdata">分类：<?php the_category(', ') ?> | <?php comments_popup_link('给我留言', '给我留言(1 条留言)', '给我留言(% 条留言)'); ?> | <?php if(function_exists('readers')) { readers(点击量,次); } ?><!-- 如果使用了 Readers_Post 插件，这里会输出文章的浏览量 --><?php if(function_exists('the_views')) { the_views('次浏览', true); } ?><!-- 如果使用了 WP-Postviews 插件，这里会输出文章的浏览量 --><?php edit_post_link('Edit', '', ''); ?></div><!--/postdata -->
                      <div class="entry">
						<?php the_content(__('(阅读更多精彩内容...)')); ?>
                      </div><!--/entry -->
                    </div><!--/post -->
				  <?php endwhile; ?>
                         <div id="pageNav">
                            <?php if(function_exists('fvcity_pagenavi')) { fvcity_pagenavi(); } ?>
                         </div>
						<?php else : ?>
                        <h2>Not Found</h2>
                        <br>
                            <p>Sorry, but you are looking for something that isn't here.</p>
						<?php endif;?>
                </div><!--/content-main-body -->
                <div class="content-main-btm"></div>
                
                <div id="part-area"><!-- 底部标签云模块 -->
                    <div class="part-area-top"></div>
                    <div class="part-area-title">
                    <h3>标签云</h3>
                    </div>
                    <div class="part-area-body">
                        <div class="part-area-body-content">
                            <div class="tag-area"><?php wp_tag_cloud('number=200'); ?><!-- number 用于控制标签的数量 --></div>
                        </div>
                    </div>
                    <div class="part-area-btm"></div>
                </div>
            </div><!--/content -->
            
<?php get_sidebar(); ?>
<?php get_footer(); ?>