<?php
/*
Template Name: Links Page Template PAGE
*/
?>
<?php get_header(); ?>

        <div id="content">
        	<div id="content-main">
                <div class="content-main-top">
                </div>
                <div class="content-main-body">
                <?php if (have_posts()) : ?>
					<?php while (have_posts()) : the_post(); ?>
                    <div class="single-post" id="post-<?php the_ID(); ?>">
		 			 <div class="date"><span><?php the_time('M') ?></span> <?php the_time('d') ?></div>
                      <h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to 
            <?php the_title(); ?>"><?php the_title(''); ?></a></h2>
                    <div class="postdata"><?php if(function_exists('readers')) { readers(点击量,次); } ?><!-- 如果使用了 Readers_Post 插件，这里会输出文章的浏览量 --><?php if(function_exists('the_views')) { the_views('次浏览', true); } ?><!-- 如果使用了 WP-Postviews 插件，这里会输出文章的浏览量 --><?php edit_post_link('Edit', '', ''); ?><?php comments_popup_link('给我留言', '给我留言(1 条留言)', '给我留言(% 条留言)'); ?></div>
                   <div class="link-entry">
                   <?php wp_list_bookmarks('categorize=1&category_orderby=id&before=<li>&after=</li>&show_images=0&show_description=1&orderby=name&title_before=<h3>&title_after=</h3>'); ?>
                    </div><!--/entry -->
                    <div class="comments-template">
                        <?php comments_template(); ?>
                    </div>
                   </div>
						<?php endwhile; ?>
   			<?php else : ?>
                <h2>Not Found</h2>
                <br><br>
                    <p>Sorry, but you are looking for something that isn't here.</p>
				<?php endif;?>
                </div>
                <div class="content-main-btm"></div>
            </div>
            
<?php get_sidebar(); ?>
<?php get_footer(); ?>