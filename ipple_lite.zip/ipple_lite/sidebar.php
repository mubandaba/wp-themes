            </div>
    </div>
    <div id="rightcol">
        <div id="righttop">
            <a href="<?php bloginfo('rss2_url'); ?>"><div class="righttop-top"></div></a>
            <div class="righttop-body">
                <script src="<?php bloginfo('stylesheet_directory'); ?>/TabbedPanels.js" type="text/javascript"></script>
                <div id="tab-content">
                <div id="TabbedPanels1" class="TabbedPanels">
                  <ul class="TabbedPanelsTabGroup">
                    <li class="TabbedPanelsTab" tabindex="0">关于本站</li>
                    <li class="TabbedPanelsTab" tabindex="0">最新留言</li>
                    <li class="TabbedPanelsTab" tabindex="0">热评日志</li>
                    <li class="TabbedPanelsTab" tabindex="0">备用TAB</li>
                  </ul>
                  <div class="TabbedPanelsContentGroup">
                    <div class="TabbedPanelsContent">在 “sidebar.php” 文件里搜索 “TabbedPanelsContent” 这个DIV标签后，即可编辑此处文字或添加你需要的代码，如果是图片的话宽度请控制在 312px 以内。</div>
                    <div class="TabbedPanelsContent"><?php if(function_exists('get_recent_comments_only')) { get_recent_comments_only($no_comments = 10); } ?><!-- 如果使用了 WP中文箱 插件，这里会输出不含 pingback/trackback 的最新评论 --></div>
                    <div class="TabbedPanelsContent"><?php if(function_exists('get_mostcommented')) { get_mostcommented($limit = 10); } ?><!-- 如果使用了 WP中文箱 插件，这里会输出10篇评论最多的日志标题 --></div>
                    <div class="TabbedPanelsContent">这里是备用的 TAB 内容区域，如果用不着可以在 “sidebar.php” 里将这个“DIV 容器”和上面的 “备用TAB” DIV 容器一并删除</div>
                </div>
                </div>
                </div>
                <script type="text/javascript">
                <!--
                var TabbedPanels1 = new Spry.Widget.TabbedPanels("TabbedPanels1");
                //-->
                </script>
            <div id="other-info">
                <div class="info-title">非TAB切换区域的“标题”</div>
                <div class="info-body">
                在 “sidebar.php” 文件里搜索 “info-body” 这个DIV标签后，即可编辑此处文字或添加你需要的代码，如果是添加图片的话宽度请控制在 322px 以内。
                </div>
           </div>
         </div>       
            <div class="righttop-btm">
            </div>
        </div>

        <div id="rightbtm">
            <div class="sidebar-left">
                <div class="left-top"></div>
                <div class="left-body">
                    <div id="cc"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/CC_SRS.gif" title="Some Rights Reserved" alt="CC" align="right" /><a href="<?php bloginfo('url');?>" target="_blank">本站</a>采用<a href="http://creativecommons.org/licenses/by-nc-sa/2.5/deed.zh" target="_blank">创作共享版权协议2.5</a>，欢迎任何非商业应用的转载，但须注明出自“<a href="<?php bloginfo('url');?>" target="_blank"><?php bloginfo('name');?></a>”，保留原始链接和文章作者。</div>
                    在 “sidebar.php” 文件里编辑此处文字或添加你需要的代码，如果是添加图片的话宽度请控制在 149px 以内。如果你不需要这整个模块，请一并删除 class="left-top" class="left-body" class="left-btm" 这三个DIV容器。
                </div>
                <div class="left-btm"></div>
                
            <div id="sidebar">
                <div class="sidebar-top"></div>
                <div class="sidebar-title">
                </div>
                <div class="sidebar-left-list">
                    <h3><?php _e('最新日志'); ?></h3>
                        <ul>
                            <?php get_recent_posts($no_comments = 10); ?><!-- 此处是 WP中文箱中最新日志调用函数，修改后面的数字可以控制输出条数 -->
                        </ul>
                    <h3><?php _e('日志归档'); ?></h3>
                        <ul>
							<?php wp_get_archives('type=monthly'); ?><!-- 此处是WP默认输输出归档列表的函数 -->
                        </ul>
                    <h3><?php _e('模块标题'); ?></h3>
                        <ul>
                        	Ipple utral 暂不支持侧边栏的 widgets，在 “sidebar.php” 文件里编辑此处文字或添加你需要的代码，如果是添加图片的话宽度请控制在 149px 以内。<br>
                            您可以根据 sidebar 模块的格式添加新的内容模块：<br>
                        &lt;h3&gt;&lt;?php _e('添加标题'); ?&gt;&lt;/h3&gt;<br>
                        &lt;ul&gt;<br>
                        这里输出内容<br>
                        &lt;/ul&gt;
                        </ul>
              </div>
                <div class="sidebar-btm"></div>
             </div>
           </div>
           
            <div class="sidebar-right">
            <div class="right-top">
                <h1><a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a><div class="description"><?php bloginfo('description'); ?></div></h1>
                <div id="cal">
                    <?php get_calendar(); ?><!-- 此处是WP默认输出日历的函数 -->
                </div>
            </div>
            <div class="right-top-btm"></div>
                      
            <div id="sidebar">
                <div class="sidebar-top"></div>
                <div class="sidebar-title">
                </div>
                <div class="sidebar-body">
                    <h3><?php _e('友情链接'); ?></h3>
                        <ul>
                            <?php get_links(-1, '<li>', '</li>',0,0, 'rand', 0, 0, 10, 0); ?><!-- 此处是WP默认输出随机友情链接的函数，修改第9个参数可以控制输出条数 -->
                        </ul>
                    <h3><?php _e('文章分类'); ?></h3>
                        <ul>
							<?php wp_list_cats('sort_column=name'); ?><!-- 此处是WP默认输出分类列表的函数 -->
                        </ul>
                    
    				<div class="sidebar-right-content">
                    <h3><?php _e('模块标题'); ?></h3>
                        <ul>
                        	Ipple utral 暂不支持侧边栏的 widgets，在 “sidebar.php” 文件里编辑此处文字或添加你需要的代码，如果是添加图片的话宽度请控制在 149px 以内。<br>
                            您可以根据 sidebar 模块的格式添加新的内容模块：<br>
                        &lt;h3&gt;&lt;?php _e('添加标题'); ?&gt;&lt;/h3&gt;<br>
                        &lt;ul&gt;<br>
                        这里输出内容<br>
                        &lt;/ul&gt;
                        </ul>
                    </div>
                    <h3><?php _e('其它'); ?></h3>
                        <ul>
                            <?php wp_register(); ?>
                            <li><?php wp_loginout(); ?></li>
                            <?php wp_meta(); ?>
                        </ul>
                </div>
                <div class="sidebar-btm"></div>
            </div>
           </div>
        </div>
    </div>
