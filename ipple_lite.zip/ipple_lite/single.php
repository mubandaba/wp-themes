<?php get_header(); ?>

        <div id="content">
        	<div id="content-main">
                <div class="content-main-top">
                </div>
                <div class="content-main-body">
					<?php if (have_posts()) : ?>
                        <?php while (have_posts()) : the_post(); ?>
                    <div class="single-post" id="post-<?php the_ID(); ?>">
		 			 <div class="date"><span><?php the_time('M') ?></span> <?php the_time('d') ?></div>
                      <h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to 
            <?php the_title(); ?>"><?php the_title(''); ?></a></h2>
                    <div class="postdata">分类：<?php the_category(', ') ?> | <?php if(function_exists('readers')) { readers(点击量,次); } ?><!-- 如果使用了 Readers_Post 插件，这里会输出文章的浏览量 --><?php if(function_exists('the_views')) { the_views('次浏览', true); } ?><!-- 如果使用了 WP-Postviews 插件，这里会输出文章的浏览量 --> | <a href="#respond">给我留言</a><?php edit_post_link('Edit', '', ''); ?></div>
                   <div class="entry">
					<?php the_content(); ?>
                   <div class="post-nav"> 
                      <span class="previous"><?php previous_post_link('%link') ?></span> 
                      <span class="next"><?php next_post_link('%link') ?></span>
                   </div>
                   <div id="post-info">
                        <li>标签&nbsp;:&nbsp;</font><?php the_tags('', ' , ' , ''); ?></li>
                        <li>原文链接&nbsp;:&nbsp;</font><a href="<?php the_permalink() ?>"><?php the_permalink() ?></a></li>
                        <li>转载原创文章请注明&nbsp;:&nbsp;</font><a href="<?php bloginfo('url');?>" target="_blank"><?php bloginfo('name');?></a></li>
                        <li><?php include (TEMPLATEPATH . '/bookmark.php'); ?></li>
                    </div>                  
                    </div><!--/entry -->
                    <div class="comments-template">
                        <?php comments_template(); ?>
                    </div>
                   </div>
						<?php endwhile; ?>
    			<?php else : ?>
                <h2>Not Found</h2>
                <br><br>
                    <p>Sorry, but you are looking for something that isn't here.</p>
				<?php endif;?>
                </div>
                <div class="content-main-btm"></div>
                
                <div id="part-area"><!-- 底部标签云模块 -->
                    <div class="part-area-top"></div>
                    <div class="part-area-title">
                    <h3>标签云</h3>
                    </div>
                    <div class="part-area-body">
                        <div class="part-area-body-content">
                            <div class="tag-area"><?php wp_tag_cloud('number=200'); ?><!-- number 用于控制标签的数量 --></div>
                        </div>
                    </div>
                    <div class="part-area-btm"></div>
                </div>
            </div>
            
<?php get_sidebar(); ?>
<?php get_footer(); ?>