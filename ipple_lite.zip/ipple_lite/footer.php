    <div id="footer">
    <div class="footer-top">Copyright © 2006-2008 <a href="<?php bloginfo('url');?>" target="_blank"><?php bloginfo('name');?></a> some rights reserved. <a href="http://zeuscn.net/themes/" target="_blank">Ipple Lite</a> designed by <a href="http://zeuscn.net" target="_blank">zEUS.</a></div>
    <div class="footer-btm">页面载入信息: <?php echo get_num_queries(); ?> queries. <?php timer_stop(1); ?> seconds.&nbsp;|&nbsp;<a href="http://www.miibeian.gov.cn" rel="nofollow" target="_blank" />鄂ICP备XXXXXXXX号</a>&nbsp;|&nbsp;<a href="#top">返回顶部</a></div>
    </div>
  </div>
</body>
</html>