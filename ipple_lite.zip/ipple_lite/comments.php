<?php // Do not delete these lines
if ('comments.php' == basename($_SERVER['SCRIPT_FILENAME'])) die ('Please do not load this page directly. Thanks!');
if (!empty($post->post_password)) { // if there's a password
	if ($_COOKIE['wp-postpass_' . COOKIEHASH] != $post->post_password) {  // and it doesn't match the cookie
?>

<h2><?php _e('密码保护'); ?></h2>
<p><?php _e('请输入密码后查看评论。'); ?></p>

<?php return;
	}
}

	/* This variable is for alternating comment background */

$oddcomment = 'alt';

?>

<!-- You can start editing here. -->

<?php if ($comments) : ?>
	<h3 id="comments">&nbsp;&#8220;<?php the_title(); ?>&#8221;<?php comments_number('无人沙发？！', '才1条评论', '才%条评论' );?></h3>

<ol class="commentlist">
<?php foreach ($comments as $comment) : ?>
<?php $comment_type = get_comment_type(); ?>
<?php if($comment_type == 'comment') { ?>
<?php
    $isByAuthor = false;
    // 这里用ID来检查评论的作者是否是blog的主人
    // 一般情况下blog主人只一人时，不用修改下面id后面的0.
    // CSS中的相关控制是comment-entry-onwer
    if($comment->user_id != 0)
    {
        $isByAuthor = true;
    }
    if ('comment-entry-alt' == $oddcomment && $isByAuthor == true)
    {
        $oddcomment = 'comment-entry-owner';
    }
    if ('comment-entry-alt' != $oddcomment && $isByAuthor == true)
    {
        $oddcomment = 'comment-entry-owner';
    }
    elseif ('comment-entry-alt' == $oddcomment && $isByAuthor == false)
    {
        $oddcomment = 'comment-entry';
    }
    else
    {
        $oddcomment = 'comment-entry-alt';
    }
   
    ?>

	<li class="<?php echo $oddcomment; ?>" id="comment-<?php comment_ID() ?>">
<?php 
	if ( !empty( $comment->comment_author_email ) ) {
	$md5 = md5( $comment->comment_author_email );
	$default = urlencode( 'http://www.yourwebsite.com/image/you.png' );
	echo "<img style='float: right; margin-left: 10px; width: 50px; height: 50px; border: 1px solid #ececec;' src='http://www.gravatar.com/avatar.php?gravatar_id=$md5&amp;size=50&amp;default=http://zeuscn.net/logo/noimage.jpg' alt='gravatar' />";
}
?>

<div class="commentmetadata">
<a href="#comment-<?php comment_ID() ?>" title=""><?php _e('公元'); ?><?php comment_date('Y年Fj日') ?><?php _e('的'); ?><?php comment_time() ?></a>，<?php _e('传说中的'); ?> <strong><?php comment_author_link() ?></strong> <?php _e('在这里留下了惊世骇俗的一笔：'); ?> <?php edit_comment_link('Edit Comment','',''); ?>
 		<?php if ($comment->comment_approved == '0') : ?>
		<em><?php _e('您的评论正在等待审核...'); ?></em>
 		<?php endif; ?>
</div>

<?php comment_text() ?>
<div align="right"><?php if (function_exists('quote_comment')) { quote_comment(); } ?></div>
	</li>

<?php /* Changes every other comment to a different class */
	if ('alt' == $oddcomment) $oddcomment = '';
	else $oddcomment = 'alt';
?>
<?php } else { $trackback = true; } ?>
<?php endforeach; /* end for each comment */ ?>

	</ol>
    
<ol class="commentlist">
<?php if ($trackback == true) { ?>
<h3>反向链接/文章引用</h3>
<div id="trackbacks">
<?php foreach ($comments as $comment) : ?>
<?php $comment_type = get_comment_type(); ?>
<?php if($comment_type != 'comment') { ?>
<li><?php comment_author_link() ?></li>
<?php } ?>
<?php endforeach; ?>
</div>
<?php } ?>
</ol>

<?php else : // this is displayed if there are no comments so far ?>

<?php if ('open' == $post->comment_status) : ?>
	<!-- If comments are open, but there are no comments. -->
	<?php else : // comments are closed ?>

	<!-- If comments are closed. -->
<p class="nocomments">评论已经关闭...</p>

	<?php endif; ?>
<?php endif; ?>


<?php if ('open' == $post->comment_status) : ?>

		<h3 id="respond">发表留言</h3>

<?php if ( get_option('comment_registration') && !$user_ID ) : ?>
<p>您必须<a href="<?php echo get_option('siteurl'); ?>/wp-login.php?redirect_to=<?php the_permalink(); ?>"> 登录 </a>后才能发表留言。</p>

<?php else : ?>

<form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform">
<?php if ( $user_ID ) : ?>

<p><a href="<?php echo get_option('siteurl'); ?>/wp-admin/profile.php"><?php echo $user_identity; ?></a> 已登录。 <a href="<?php echo get_option('siteurl'); ?>/wp-login.php?action=logout" title="Log out of this account">注销 &raquo;</a></p>

<?php else : ?>

<p><input type="text" name="author" id="author" value="<?php echo $comment_author; ?>" size="40" tabindex="1" />
<label for="author">姓名 <?php if ($req) echo "（必填）"; ?></label></p>

<p><input type="text" name="email" id="email" value="<?php echo $comment_author_email; ?>" size="40" tabindex="2" />
<label for="email">邮箱（不会被公开） <?php if ($req) echo "（必填）"; ?></label></p>

<p><input type="text" name="url" id="url" value="<?php echo $comment_author_url; ?>" size="40" tabindex="3" />
<label for="url">网址（选填）</label></p>
<?php 
/****** Math Comment Spam Protection Plugin ******/
if ( function_exists('math_comment_spam_protection') ) { 
	$mcsp_info = math_comment_spam_protection();
?> 	<p><input type="text" name="mcspvalue" id="mcspvalue" value="" size="22" tabindex="4" />
	<label for="mcspvalue">脑筋急转弯：<?php echo $mcsp_info['operand1'] . ' + ' . $mcsp_info['operand2'] . '' ?>=? <?php if ($req) echo "（必填）"; ?></label>
	<input type="hidden" name="mcspinfo" value="<?php echo $mcsp_info['result']; ?>" />
</p>
<?php } // if function_exists... ?>

<?php endif; ?>

<!--<p><strong>XHTML:</strong> <?php _e('You can use these tags&#58;'); ?> <?php echo allowed_tags(); ?></p>-->

<p><textarea name="comment" id="comment" cols="105" rows="10" tabindex="4"></textarea></p>

<p><input name="submit" type="submit" id="submit" tabindex="5" value="提交评论" />
<input type="hidden" name="comment_post_ID" value="<?php echo $id; ?>" />
</p>

<?php do_action('comment_form', $post->ID); ?>

</form>

<?php endif; // If registration required and not logged in ?>

<?php endif; // if you delete this the sky will fall on your head ?>