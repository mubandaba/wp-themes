<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" /> <!-- leave this for stats please -->
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title><?php wp_title(''); if (is_search()) { ?> Search for <?php echo $s; } if ( !(is_404()) and (is_search()) or (is_single()) or (is_page()) or (function_exists('is_tag') and is_tag()) or (is_archive()) ) { ?> at <?php } ?> <?php bloginfo('name'); ?></title>     
    <link href="<?php bloginfo('stylesheet_directory'); ?>/style.css" rel="stylesheet" type="text/css" />
	<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
	<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	    
    <!--[if IE 7]>
    <link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/ie7.css" type="text/css" />
    <![endif]-->

	<?php wp_get_archives('type=monthly&format=link'); ?>
	<?php //comments_popup_script(); // off by default ?>
 	<?php wp_head(); ?>   
    <META name="keywords" content="" />
<a name="top"></a>
</head>
<body>
  <div id="wrap">
    <div id="nav"><!-- 博客导航栏，导航链接建议不超过6个 -->
        <ul>
          <li class="page_item <?php if ( is_home() ) { ?>current_page_item<?php } ?>"><a href="<?php echo get_settings('home'); ?>/" title="HOME">博客首页</a></li>
		  <?php wp_list_pages('sort_column=menu_order&depth=1&title_li=');?>
    	</ul>
        <div id="search">
        	<?php include (TEMPLATEPATH . '/searchform.php'); ?>        
        </div>
    </div>
    <div id="leftcol">
    	<div class="guide">
        	<div class="guide_wrap">
            	<div class="guide_home"><a href="<?php echo get_settings('home'); ?>/"></a></div>
                <div class="guide_content">您可以在这里编辑一句名言，或使用JS输出一条简明的微博客信息。</div>
            </div>
        </div>
