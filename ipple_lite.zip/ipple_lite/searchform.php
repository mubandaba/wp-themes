        <form method="get" class="searchform" action="<?php bloginfo('home'); ?>/">
        <input type="text" value="站内搜索" name="s" class="s" onfocus="if (this.value == '站内搜索') {this.value = '';}" onblur="if (this.value == '') {this.value = '站内搜索';}"/>
        <input type="submit" class="submit" value="GO" /></form>