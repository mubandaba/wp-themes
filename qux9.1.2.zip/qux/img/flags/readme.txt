flag icons - famfamfam.com

Free for any use. If you use these flags in your software or
on your website, an email with a link or a screenshot would be nice. :)

- Thanks to Christian Cook for splitting it all up into separate images

Contact: mjames@gmail.com