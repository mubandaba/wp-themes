<?php /**
 * WP Filters File
 *
 * @category WordPress
 * @package  Canary
 * @author   Linesh Jose <lineshjos@gmail.com>
 * @license  http://www.gnu.org/copyleft/gpl.html GNU General Public License
 * @link     https://linesh.com/projects/canary/
 *
 */

// Page nvaigation template  ----------->
add_filter('navigation_markup_template',function(){
	return $template = '
    <nav class="navigation %1$s" role="navigation">
        <h2 class="screen-reader-text">%2$s</h2>
        <div class="nav-links">%3$s
			<div class="clear"></div>
		</div>
    </nav>';
});


// Adding body class --------------->
add_filter( 'body_class', function ( $classes ) {
		if ( get_background_image() ) { // Adds a class of custom-background-image to sites with a custom background image.
			$classes[] = 'custom-background-image';
		}
		if ( is_multi_author() ) { // Adds a class of group-blog to sites with more than 1 published author.
			$classes[] = 'group-blog';
		}
		if ( ! is_active_sidebar( 'sidebar-1' ) ) {// Adds a class of no-sidebar to sites without active sidebar.
			$classes[] = 'no-sidebar';
		}
		if ( ! is_singular() ) {// Adds a class of hfeed to non-singular pages.
			$classes[] = 'hfeed';
		}
		return $classes;
	} );
	

// Add a `screen-reader-text` class to the search form's submit button. --------------->
add_filter( 'get_search_form', function ( $html ) {
		return str_replace( 'class="search-submit"', 'class="search-submit screen-reader-text"', $html );
	});
	

// Excerpt more --------------->
add_filter( 'excerpt_more', function( $more ) {
		if(! is_admin()){
			 /* translators: %s: Name of current post */
			$link = sprintf( '<span class="clear"></span><a href="%1$s" class="more-link read-more" rel="bookmark">%2$s</a>',esc_url( get_permalink( get_the_ID() ) ),sprintf( esc_html__( 'Continue Reading %s', 'canary' ), '<span class="screen-reader-text">'.get_the_title( get_the_ID() ).'</span><i class="fa fa-arrow-right"></i>' ));
			return '&hellip; ' . $link;
		}
	});
	

// Archive title ----------------------->
add_filter('get_the_archive_title',function($title )
{
		$rss='';
		if (is_search()){
			$title = '<span>'. esc_html__( 'Searching for:','canary' ).'</span><strong>"'.get_search_query().'"</strong>' ;
			
		}elseif ( is_category() ) {
			$title = '<strong>'.single_cat_title( '', false ).'</strong><span>'. esc_html__( 'Category','canary' ).'</span>' ;
			$rss=get_category_feed_link(get_query_var('cat'));
			
		} elseif ( is_tag() ) {
			$title = '<strong>'.single_tag_title( '', false ).'</strong><span>'. esc_html__( 'Tag Archive','canary' ).'</span>' ;
			$rss=get_tag_feed_link(get_query_var('tag_id')); 
			
		} elseif ( is_author() ) {
			$title = '<strong class="vcard">' . get_the_author() . '</strong><span>'. esc_html__( 'Author','canary' ).'</span>' ;
			$rss= get_author_feed_link(get_the_author_meta('ID'));
			
		} elseif ( is_year() ) {
			$title = '<strong>' .get_the_date( __( 'Y', 'canary' ) )  . '</strong><span>'. esc_html__( 'Yearly Archives','canary' ).'</span>' ;
			
		} elseif ( is_month() ) {
			$title = '<strong>' .get_the_date( __( 'F Y', 'canary' ) )  . '</strong><span>'. esc_html__( 'Monthly Archives ','canary' ).'</span>' ;
			
		} elseif ( is_day() ) {
			$title = '<strong>' .get_the_date( __( 'F j, Y', 'canary' ) )  . '</strong><span>'. esc_html__( 'Daily Archives','canary' ).'</span>' ;
			
		} elseif ( is_post_type_archive() ) {
			$title = '<strong>' .post_type_archive_title( '', false )  . '</strong>' ;
			$rss=get_post_type_archive_feed_link(get_query_var('post_type'));
			
		} elseif ( is_tax() ) {
			$tax = get_taxonomy( get_queried_object()->taxonomy );
			$term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );
			$title = '<strong>'.single_term_title('', false ).'</strong><span>'.$tax->labels->singular_name.'</span>' ;
			$rss=get_term_feed_link($term->term_id, get_query_var( 'taxonomy' ));
			
		 } else {
			$title ='<strong>'.esc_html__( 'All Posts' ,'canary').'</strong> <span>'.esc_html__( 'Blog Archives:' ,'canary').'</span>';
			$rss=get_bloginfo('rss2_url');
		}
		
		if($title && $rss){
			$title=$title.'<a href="'.$rss.'" title="'.esc_attr(__('Subscribe this','canary')).'" class="subscribe" rel="noopener noreferrer" target="_blank"><i class="fa fa-rss"></i><srong class="">'.esc_html__('Subscribe','canary').'</srong></a>	';
		}
		return $title;
	});	


// add the filter for search widget title ....
add_filter( 'widget_title', function( $instance_title, $instance,$this_id_base ) { 
    if($this_id_base=='search'){
    	$instance_title = ! empty( $instance['title'] ) ? $instance['title'] :__('Search','canary');
    }  
    return $instance_title; 
} , 10, 3 ); 
?>