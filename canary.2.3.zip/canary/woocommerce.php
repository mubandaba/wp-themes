<?php /** 
 * Canary single page file
 *
 * @category WordPress
 * @package  Canary
 * @author   Linesh Jose <lineshjos@gmail.com>
 * @license  http://www.gnu.org/copyleft/gpl.html GNU General Public License
 * @link     https://linesh.com/projects/canary/
 *
 */
get_header(); 
?>
<main id="main" class="site-main  single-page full-width woocommerce-page " role="main">
  <?php 
 	if ( have_posts() ) {
			woocommerce_content();
	}else {
		get_template_part( 'content', 'none' );
	};
  ?>
</main>
<?php get_footer(); ?>