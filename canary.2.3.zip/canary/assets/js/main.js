// JavaScript Document
(function( $ ){
	$.fn.reset_all = function() {
		if($(window).width()>900){
			$('#site-navigation').show().addClass('closed');
			$('#masthead .site-header-menu .menu-toggle').removeClass('open');	
		}else{
			if( $('#site-navigation').hasClass('closed') ){
				$('#site-navigation').hide();
			}
		}
		$('#wp-custom-header').height( $('#masthead').height());
	};

	$(document).ready(function(e)
	{
		$('body').reset_all();
		$('#masthead .site-header-menu .menu-toggle').bind('click',function(){
			if( $(this).hasClass('open') ){
				$('#site-navigation').slideUp(300).addClass('closed')
				$(this).removeClass('open');
			}else{
				$('#site-navigation').slideDown(300).removeClass('closed');
				$(this).addClass('open');
			}
			return false;
		});
		$('#search-toggle').bind('click',function(){
			if($(window).width()<425 && !$('#masthead .search-form').hasClass('float')){
				$('#masthead .search-form').addClass('float');
				$('#masthead .search-field').focus();
			}else{
				$('#masthead .search-form').removeClass('float');
			}
		});

			

	

	$( "body" ).on( "click", "#_customize-input-display_header_text", function() {
  		//alert(1);
	});


	});
	$(window).resize(function(){
		$('body').reset_all();
	});

})( jQuery );