    <footer class="site-footer u-textAlignCenter container">
        <?php do_action('puma_credit');?>
    </footer>
</div>
<div class="back-to-top u-hide" onclick="backToTop();"><span class="icon-circle-up"></span></div>
<?php // You can add your analystic code to the following hide tag and won't display.?>
<div class="u-hide"></div>
<?php wp_footer();?>
</body>
</html>