<?php get_header();?>
	<main class="main-content container">
	<div class="page404">
        <b>404</b>
        <p>没找到任何内容，返回<a href="<?php echo home_url();?>">首页</a></p>
	</div>
	</main>
<?php get_footer();?>