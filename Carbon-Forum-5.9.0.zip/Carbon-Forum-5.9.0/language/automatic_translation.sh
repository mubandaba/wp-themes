#cd ../library
#composer install
php auto_translate.php