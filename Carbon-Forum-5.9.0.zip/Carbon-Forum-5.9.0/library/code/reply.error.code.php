<?php
return array(
    'Default' => 102000,
    'Content_Empty' => 102001,
    'Too_Long' => 102002,
    'Posting_Too_Often' => 102003,
    'Topic_Has_Been_Locked' => 102004,
    'Prohibited_Content' => 102005,
);