<?php
return array(
	'Default' => 103000,
	'Title_Empty' => 103001,
	'Too_Long' => 103002,
	'Tags_Empty' => 103003,
	'Posting_Too_Often' => 103004,
	'Prohibited_Content' => 103005,
	'Prohibited_New_Topic' => 103006,
);