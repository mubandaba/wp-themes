<?php
if (!defined('InternalAccess')) exit('error: 403 Access Denied');
Redirect();