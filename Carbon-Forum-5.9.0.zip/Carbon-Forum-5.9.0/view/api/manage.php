<?php
if (!defined('InternalAccess')) exit('{"Status": 0, "ErrorCode": "403", "ErrorMessage": "403"}');
?>{
	"Status": 1,
	"Message": "<?php echo $Message;?>"
}