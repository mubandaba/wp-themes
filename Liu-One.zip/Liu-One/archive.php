<?php
/**
 * Generated on 2019/9/6 15:17:51
 *
 * @package   Liu-One
 * @version   v2.0
 * @author    WPTU爱好者
 * @Email     2774251932@qq.com
 * @site      https://www.wptu.cn
 * @copyright Copyright (c) 2016-2020 by WPTU爱好者
 * @link      https://www.wptu.cn/wptu.html
 *
**/
?>
<?php get_header();?>
<div id="page-content">
<div class="jumbotrons pc"> 
    <div class="shadow"> 
    </div> 
    <img src="<?php echo post_thumbnail_src(); ?>" width="984" height="800" /> 
    <div class="container fl-title"> 
     <h2 class="work-title wow zoomIn" style="visibility: visible; animation-name: zoomIn;"><?php single_cat_title(); ?></h2>
     <p class="wow zoomIn widget-one" style="visibility: visible; animation-name: zoomIn;"><?php echo category_description(); ?></p> 
    </div> 
   </div> 

	<div class="container">
		<div class="row">
		
		 <div class="fl"> 
      <div class="fl_title"> 
       <ul class="nav-list"> 
        <li><?php single_cat_title(); ?></li> 
       </ul> 
       <div class="filter-tag"> 
        <div class="fl_list"> 
         <i class="icon-volume-up-2"></i>&nbsp;当前分类共发布
         <em style="color: #EF1616;font-weight: bold;padding-right: 3px;padding-left: 3px;"><?php global $wp_query;$cat_ID = get_query_var('cat'); echo get_category($cat_ID)->count;?></em> 条资讯&nbsp;&nbsp; 
        </div> 
       </div> 
      </div> 
      <?php dimox_breadcrumbs(); ?> 
     </div> 
	 

			<?php if(have_posts()) : ?>
				<div class="article col-xs-12 col-sm-8 col-md-8">
					<div class="ajax-load-box posts-con">
						<?php while ( have_posts() ) : the_post(); 
							include( TEMPLATEPATH.'/includes/excerpt.php' );endwhile; ?>
					</div>
					<div class="clearfix"></div>
					<?php if( itliu('itliu_ajax_posts',true) ) { ?>
							<div id="ajax-load-posts">
								<?php echo fa_load_postlist_button();?>
							</div>
							<?php  } else {
								the_posts_pagination( array(
									'prev_text'          =>'上页',
									'next_text'          =>'下页',
									'screen_reader_text' =>'',
									'mid_size' => 1,
								) ); 
							} ?>
				</div>
				<?php get_sidebar(); ?>
				<?php else: ?>			
					<div class="blog-emtry">
						<i class="icon-frown"></i>
						<p><?php echo '该栏目暂无内容'; ?></p>
					</div>
				<?php  endif; ?>
					
			
		</div>
		
	</div>
</div>
<?php get_footer(); ?>