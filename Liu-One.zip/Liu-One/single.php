<?php
/**
 * Generated on 2019/9/6 15:17:51
 *
 * @package   Liu-One
 * @version   v2.0
 * @author    WPTU爱好者
 * @Email     2774251932@qq.com
 * @site      https://www.wptu.cn
 * @copyright Copyright (c) 2016-2020 by WPTU爱好者
 * @link      https://www.wptu.cn/wptu.html
 *
**/
?>
<?php 
	get_header(); 
?>
<div id="page-content">
<div class="jumbotron pc"> 
   <div id="container">
    <div class="rainbow">
     <div class="red"></div>
     <div class="orange"></div>
     <div class="yellow"></div>
     <div class="green"></div> 
     <div class="cyan"></div>
     <div class="blue"></div>
     <div class="purple"></div>
    </div>
   </div> 
   <div class="shadow"> 
   </div> 
   <img src="<?php echo post_thumbnail_src(); ?>" class="banner_pic" width="984" height="800" /> 
   <div class="container"> 
    <?php global $post;$author_id=$post->post_author;
        $nickname = get_the_author_meta( 'nickname',  $author_id);
        $user_email = get_the_author_meta( 'user_email',  $author_id);
	?>
    <p class="post-meta-dt widget-one wow bounceInRight"> <span class="postauthor"><?php echo get_avatar( $user_email, '30' );?></span> <span><?php echo $nickname ?></span> ｜ <span><?php echo itliu_level() ?></span> </p>
    <div class="share-meta hidden-xs widget-two wow bounceInRight"> 
     <ul class="action-share bdsharebuttonbox" aria-labelledby="social"> 
      <li><a target="_blank" class="bds_tsina icon-weibo" data-cmd="tsina" title="分享到新浪微博"></a></li> 
      <li><div class="link" onmouseover="MM_over(this)" onmouseout="MM_out(this)" alt="手机扫一扫"><i class="icon-wechat" alt="手机扫一扫"></i> <div id="box"> <img src="http://qr.liantu.com/api.php?&w=150&text=<?php the_permalink(); ?>" class="imgd"></div> </div> </li> 
      <li><a target="_blank" rel="nofollow" class="bds_tqq icon-tencent-weibo" data-cmd="tqq" title="分享到腾讯微博"></a></li> 
      <li><a target="_blank" rel="nofollow" class="bds_qzone icon-qq-1" data-cmd="qzone" title="分享到QQ空间"></a></li> 
      <li><a target="_blank" rel="nofollow" class="bds_renren icon-renren-1" data-cmd="renren" title="分享到人人网"></a></li> 
     </ul> 
    </div> 
    <p></p> 
    <h2 class="work-title wow bounceInDown" style="visibility: visible; animation-name: bounceInDown;"><?php the_title(); ?></h2> 
   </div> 
  </div> 
  <script> function MM_over(mmObj) { var mSubObj = mmObj.getElementsByTagName("div")[0]; mSubObj.style.display = "block"; mSubObj.style.backgroundColor = "#FFF"; } function MM_out(mmObj) { var mSubObj = mmObj.getElementsByTagName("div")[0]; mSubObj.style.display = "none"; } </script>



	<div class="container">
		<div class="row">
		
		<div class="fl"> 
      <div class="filter-mbx"> 
       <span class="author-info"> 
	   <span class="icon-edit-2"><?php edit_post_link('[编辑]'); ?></span>
	   <span class="timeago"><i class="icon-clock-alt"></i><?php echo timeago( get_gmt_from_date(get_the_time('Y-m-d G:i:s')) ); ?></span> 
	   <span class="timeago"><i class="icon-list"></i><?php $category = get_the_category();if($category[0]){echo '<a href="'.get_category_link($category[0]->term_id ).'">'.$category[0]->cat_name.'</a>';}?></span> 
	   <?php if(has_tag()){?><span class="post-tagsimg"><i class="icon-tags-1"></i><?php the_tags('#','',''); ?></span><?php } ?>
	  </span> 
       <div class="category"> 
	   <span class="count"><i class="icon-eye-4"></i><?php post_views('',''); ?></span>
        <span class="count" ><i class="icon-commenting-o"></i><a href="#SOHUCS" id="changyan_count_unit" title="评论"></a></span> 
		<script type="text/javascript" src="https://assets.changyan.sohu.com/upload/plugins/plugins.count.js"></script>
        <a href="javascript:;" data-action="ding" data-id="<?php the_ID(); ?>" id="Addlike" class="action btn-likes like<?php if(isset($_COOKIE['itliu_ding_'.$post->ID])) echo ' current';?>" title="喜欢">
		<span class="count"><i class="icon-thumbs-up"></i><?php if( get_post_meta($post->ID,'itliu_ding',true) ){ echo get_post_meta($post->ID,'itliu_ding',true); } else {echo '0';}?></span> 
        </a>
	   </div> 
      </div> 
      <?php dimox_breadcrumbs(); ?> 
     </div> 
         <div class="article col-xs-12 col-sm-8 col-md-8">
		        <?php $prev_post = get_previous_post(); if (!empty( $prev_post )): ?>
                        <span id="nav_prev">
							<a href="<?php echo get_permalink( $prev_post->ID ); ?>" title="上一篇：<?php echo $prev_post->post_title; ?>">
								<i class="icon-left-open">
								</i>
								<div class="si">
									<div class="si-img" style="background-image: url(<?php $prev_img = get_post_thumbnail_url($prev_post->ID); echo !empty( $prev_img ) ? $prev_img : itliu('itliu_p_n_bgp'); ?>);max-width: 90px;height: 57px;background-size: contain;">
									</div>
									<div class="si-txt">
										<?php echo $prev_post->post_title; ?>
									</div>
								</div>
							</a>
						</span>
				<?php endif; ?>
				<?php $next_post = get_next_post(); if (!empty( $next_post )): ?>
						<span id="nav_next">
							<a href="<?php echo get_permalink( $next_post->ID ); ?>" title="下一篇：<?php echo $next_post->post_title; ?>">
								<i class="icon-right-open">
								</i>
								<div class="si">
									<div class="si-img" style="background-image: url(<?php $next_img = get_post_thumbnail_url($next_post->ID); echo !empty( $next_img ) ? $next_img : itliu('itliu_p_n_bgp'); ?>);max-width: 90px;height: 57px;background-size: contain;">
									</div>
									<div class="si-txt">
										<?php echo $next_post->post_title; ?>
									</div>
								</div>
							</a>
						</span>
				<?php endif; ?>
				
				
				
				<?php if(!wp_is_mobile()): echo single_pc_top_ad_pic();endif; if(wp_is_mobile()): echo single_mini_top_ad_pic(); endif; ?>
				<?php 
					if(have_posts()): while(have_posts()):the_post();  
						$cc_value = get_post_meta($post->ID,"cc_value",true );
						$title = '<h1 class="title">'.get_the_title().'</h1>';
				?>
				<div class="post">
					<div class="post-title">
						<?php echo $title; ?>
					</div>
					<div class="post_icon">
							<span  class="postauthor"><?php echo get_avatar( get_the_author_meta('email'), '' ); ?><a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ) ?>"><?php echo get_the_author() ?></a></span> 
							<?php if( $cc_value == 1 ) { ?>
								<span class="postoriginal"><i class="icon-cc-1"></i><?php echo itliu('itliu_custom_cc');?></span>
							<?php } ?>
							<span  class="postcat"><i class=" icon-list-2"></i> <?php $category = get_the_category();if($category[0]){echo '<a href="'.get_category_link($category[0]->term_id ).'">'.$category[0]->cat_name.'</a>';}?></span>
							<span class="postclock"><i class="icon-clock-1"></i> <?php echo timeago( get_gmt_from_date(get_the_time('Y-m-d G:i:s')) ); ?></span>
							<a href="javascript:;" data-action="ding" data-id="<?php the_ID(); ?>" id="Addlike" class="action btn-likes like<?php if(isset($_COOKIE['itliu_ding_'.$post->ID])) echo ' current';?>" title="喜欢">
		                    <span class="likes"><i class="icon-thumbs-up"></i><?php if( get_post_meta($post->ID,'itliu_ding',true) ){ echo get_post_meta($post->ID,'itliu_ding',true); } else {echo '0';}?></span> 
                            </a>
							<span class="posteye"><i class="icon-eye-4"></i> <?php post_views('',''); ?></span>
							<span class="postcomment"><i class="icon-comment-4"></i> <a href="#respond" title="评论"><?php comments_popup_link( __( '0' ) , __( '1'), __( '%') ); ?></a></span>
							<span class="icon-edit-2"><?php edit_post_link('[编辑]'); ?></span>
					</div>
					<div class="post-content">
						<?php if(has_excerpt()): ?>
							<p class="post-abstract"><span class="abstract-tit">摘要：</span><?php echo get_the_excerpt(); ?></p>
						<?php endif;?>
						<?php 
							the_content();
							itliu_link_pages('before=<div class="page-links">&after=&next_or_number=next&previouspagelink=上一页&nextpagelink=');
							itliu_link_pages('before=&after= ');
							itliu_link_pages('before=&after=</div>&next_or_number=next&previouspagelink=&nextpagelink=下一页');
						?>
					</div>
					<?php cc_notice(); ?>
					<div class="post-options  clearfix">
							<?php if(itliu('itliu_post_like',true)) { ?>
							<a href="javascript:;" data-action="ding" data-id="<?php the_ID(); ?>" id="Addlike" class="action btn-likes like<?php if(isset($_COOKIE['itliu_ding_'.$post->ID])) echo ' current';?>" title="喜欢">
								<span class="icon s-like"><i class="icon-heart"></i><i class="icon-thumbs-up"></i> 赞 </span>
								(<span class="count num"><?php if( get_post_meta($post->ID,'itliu_ding',true) ){ echo get_post_meta($post->ID,'itliu_ding',true); } else {echo '0';}?></span>)
							</a>
							<?php } ?>
							<?php if(itliu('itliu_reward')) { ?>
								<div class="su-dropdown paydropdown">
						            <a href="javascript:;" class="pay-author" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true"><i class=" icon-dollar"></i><span>打赏</span></a>
						            <div class="su-dropbox <?php if( itliu('itliu_alireward') && itliu('itliu_wxreward') ){ echo 'pay-allqr'; } ?>" aria-labelledby="pay-qr">
						                <ul>
											<?php if(itliu('itliu_alireward') or get_the_author_meta( 'alipay' )) { ?>
												<li class="alipay"><img alt="打赏" src="<?php if ( get_the_author_meta( 'alipay' ) ){echo get_the_author_meta( 'alipay' );}else{echo itliu('itliu_alireward') ;}?>"><b>支付宝扫一扫</b></li>
											<?php } ?>
											<?php if(itliu('itliu_wxreward') or get_the_author_meta( 'wxpay' )) { ?>
												<li class="weixinpay"><img alt="打赏" src="<?php if ( get_the_author_meta( 'wxpay' ) ){echo get_the_author_meta( 'wxpay' );}else{echo itliu('itliu_wxreward') ;}?>"><b>微信扫一扫</b></li>
											<?php } ?>	
										</ul>
						            </div>
						        </div>
						    <?php } ?>
							
					</div>
					<?php if(!wp_is_mobile()): echo single_pc_ad_pic(); endif; if(wp_is_mobile()): echo single_mini_ad_pic(); endif;?>
					<?php if(itliu('nextprevposts',true)) { ?>
						<div class="next-prev-posts clearfix">
							
							<?php 	
								$next_class = '';
								$prev_class = '';
								$prev_post = get_previous_post(false,'');
								$next_post = get_next_post(false,'');

								if ( empty( $prev_post ) ) : 
									$next_class = 'style="width:100%;"';
								endif;

								if(empty( $next_post )): 
									$prev_class = 'style="width:100%;"';
								endif;
								
								if ( !empty( $prev_post ) ) : ?>
									<div class="prev-post" <?php echo $prev_class; ?>>
										<a href="<?php echo get_permalink( $prev_post->ID ); ?>" title="<?php echo $prev_post->post_title; ?>" <?php if( get_post_meta($post->ID,"blank_value",true)) { echo 'target="_blank"';}?> class="prev has-background" style="background-image: url(<?php $prev_img = get_post_thumbnail_url($prev_post->ID); echo !empty( $prev_img ) ? $prev_img : itliu('itliu_p_n_bgp'); ?>)" alt="<?php echo $prev_post->post_title; ?>">	
											<span>上一篇</span><h4><?php echo $prev_post->post_title; ?></h4>
										</a> 
									</div> 
								<?php endif;

								if(!empty( $next_post )): ?>
									<div class="next-post" <?php echo $next_class; ?>>
										<a href="<?php echo get_permalink( $next_post->ID ); ?>" title="<?php echo $next_post->post_title; ?>" <?php if( get_post_meta($post->ID,"blank_value",true)) { echo 'target="_blank"';}?> class="next has-background" style=" background-image: url(<?php $next_img = get_post_thumbnail_url($next_post->ID); echo !empty( $next_img ) ? $next_img : itliu('itliu_p_n_bgp'); ?>)" alt="<?php echo $next_post->post_title; ?>">	
											<span>下一篇</span><h4><?php echo $next_post->post_title; ?></h4>
										</a> 
									</div> 
								<?php endif;?>
						
						</div>
					<?php } ?>	 
				</div>
				<?php if(itliu('related-post',true)) {  include get_template_directory() . '/includes/relatepost.php'; }?>
				<?php if (itliu('itliu_sohucy_comments', false)){ ?>	
				<div id="pinglun">
				<?php include get_template_directory() . '/includes/sohucs.php';?>
				</div>
                <?php } ?>
				<div class="clear"></div>
				<?php if (comments_open()) comments_template( '', true ); endwhile;  endif; ?>	
			</div>	
			<?php get_sidebar(); ?>
		</div>
	</div>
</div>
<!--侧边分享 --> 
  <div class="article-left-btn-group"> 
   <ul class="action-share bdsharebuttonbox" aria-labelledby="social"> 
    <li><a class="bds_tsina icons icons-article icons-article-wb" data-cmd="tsina" title="分享到新浪微博"></a></li> 
    <li><a class="bds_weixin icons icons-article icons-article-pyq" data-cmd="weixin" title="分享到微信"></a> </li> 
    <li><a class="bds_sqq  icon-qq icons-article " data-cmd="sqq" title="分享到腾讯QQ" ></a> </li> 
    <li><a class="bds_qzone icons icons-article icons-article-qzone" data-cmd="qzone" title="分享QQ空间"></a> </li> 
    <li><a href="<?php if (itliu('itliu_sohucy_comments', false)){ echo '#related-posts';}else{ echo '#respond'; }?>"> <i class="icons icons-article icons-article-pl">评论</i></a> </li> 
   </ul> 
  </div> 
  <!--侧边分享 --> 
<?php 
	get_footer();
?>
