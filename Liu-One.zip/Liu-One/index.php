<?php
/**
 * Generated on 2019/9/6 15:17:51
 *
 * @package   Liu-One
 * @version   v2.0
 * @author    WPTU爱好者
 * @Email     2774251932@qq.com
 * @site      https://www.wptu.cn
 * @copyright Copyright (c) 2016-2020 by WPTU爱好者
 * @link      https://www.wptu.cn/wptu.html
 *
**/
?>
<?php get_header();?>
<div id="page-content">
	<?php 
	if( itliu('itliu_home_slide') == true){ 
		include( get_template_directory().'/includes/topslide.php' ); 
	}    
	?>
	<div class="page-navs"> 
		<?php if ( function_exists( 'wp_nav_menu' ) && has_nav_menu('bianlan-nav') ) { 
			wp_nav_menu(
				array(	
					'theme_location'   => 'bianlan-nav',
					'sort_column'	   => 'menu_order',
					'fallback_cb' => 'cmp_nav_fallback',
					'container' => false, 
					'menu_id' =>'page-nav',
					'menu_class' =>'nav-lists',
					) 
			); 
		}?>
    </div>
	
		<div class="main-content">
			<div class="container">
				<div class="row">
					<div class="article col-xs-12 col-sm-8 col-md-8">
					<?php if(itliu('itliu_index_custom_cat_tab_id')) { 
						$count_posts = wp_count_posts();
						$published_posts = $count_posts->publish;
						$new_post_total = ceil($published_posts / get_option('posts_per_page'));
					?>
						<div class="post-nav">
							<span class="new-post current" data-paged="1" data-action="fa_load_postlist" data-home="true" data-total="<?php echo $new_post_total;?>">最新文章</span>
							<?php
								$str = itliu('itliu_index_custom_cat_tab_id');
								$cat_arr = explode(",",$str);
								for ($i=0; $i < count($cat_arr); $i++) {
									$thisCat = get_category($cat_arr[$i]);
									$total = ceil($thisCat->count / get_option('posts_per_page')); 
									echo '<span class="cat-post" data-category="'.$thisCat->cat_ID.'" data-paged="1" data-action="fa_load_postlist" data-total="'.$total.'">'.$thisCat->cat_name.'</span>';
								}
							?>
							<ul class="h-soup cl"> <li class="open">一周更新 <em><?php echo get_week_post_count();?></em> 条资讯</li></ul>
						</div>
					<?php } ?>
					<?php
						$args = array(
							'ignore_sticky_posts'=> 1,
							'paged' => $paged
						);
						if( itliu('notinhome') ){
							$pool = array();
							foreach (itliu('notinhome') as $key => $value) {
								if( $value ) $pool[] = $key;
							}
							$args['cat'] = '-'.implode($pool, ',-');
						}		
						query_posts($args);
						if ( have_posts() ) : ?>
							<div class="ajax-load-box posts-con">
								<?php while ( have_posts() ) : the_post(); 
									include( get_template_directory().'/includes/excerpt.php' );endwhile; ?>
							</div>
							<div class="clearfix"></div>
							<?php if( itliu('itliu_ajax_posts',true) ) { ?>
								<div id="ajax-load-posts">
									<?php echo fa_load_postlist_button();?>
								</div>
								
								<?php  }else {
									the_posts_pagination( array(
										'prev_text'=>'上页',
										'next_text'=>'下页',
										'screen_reader_text' =>'',
										'mid_size' => 1,
									) ); } ?>
								<?php 	else :
								get_template_part( 'content', 'none' );

						endif;?>
					</div>
					<?php get_sidebar(); ?>
				</div>
			</div>
		</div>
	
</div>
<?php get_footer(); ?>