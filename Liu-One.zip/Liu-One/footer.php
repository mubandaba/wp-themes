<?php
/**
 * Generated on 2019/9/6 15:17:51
 *
 * @package   Liu-One
 * @version   v2.0
 * @author    WPTU爱好者
 * @Email     2774251932@qq.com
 * @site      https://www.wptu.cn
 * @copyright Copyright (c) 2016-2020 by WPTU爱好者
 * @link      https://www.wptu.cn/wptu.html
 *
**/
?>
<div class="clearfix"></div>
<footer class="footer">
 <div id="footer-count"> 
   <div class="container"> 
    <div class="count_num widget-one wow bounceInRight"> 
     <div style=" margin-left: -30px; ">
      文章总数
     </div> 
     <div>
      <?php $count_posts = wp_count_posts(); echo $published_posts = $count_posts->publish;?>+
     </div> 
    </div> 
    <div class="count_num widget-two wow bounceInRight"> 
     <div style=" margin-left: -20px; ">
      标签总数
     </div> 
     <div>
      <?php echo $count_tags = wp_count_terms('post_tag'); ?>+
     </div> 
    </div> 
    <div class="count_num widget-three wow bounceInRight"> 
     <div style=" margin-left: -40px; ">
      评论总数
     </div> 
     <div>
      <?php echo $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->comments");?>+
     </div> 
    </div> 
    <div class="count_num widget-four wow bounceInRight"> 
     <div style=" margin-left: -10px; ">
      运营天数
     </div> 
     <div>
	 <?php $jztimes = itliu('itliu_jztimes')?>
      <?php echo floor((time()-strtotime("$jztimes"))/86400); ?>+
     </div> 
    </div> 
   </div> 
  </div> 
<?php if(!wp_is_mobile()&&(int)itliu('footer-widgets')>0) { ?>
		<div id="footer-widgets">
        <div class="container">
		<div class="row">
			<?php
			$total = 3;
			if ( itliu( 'footer-widgets' ) != '' ) {			
				$total = itliu( 'footer-widgets' );
				if( $total == 1) $class = 'col-xs-12';
				if( $total == 2) $class = 'col-md-6 col-xs-12';
				if( $total == 3) $class = 'col-md-4 col-xs-12';
				if( $total == 4) $class = 'col-md-3 col-xs-12';
			}
			if ( (  is_active_sidebar( 'footer-1' ) || is_active_sidebar( 'footer-2' ) || is_active_sidebar( 'footer-3' ) || is_active_sidebar( 'footer-4' ) ) && $total > 0 ) { ?>
				<?php $i = 0; while ( $i < $total ) { $i++; ?>
					<?php if ( is_active_sidebar( 'footer-' . $i ) ) { ?>
		
				<div class="footer-widgets-<?php echo $i; ?> <?php echo $class; ?> <?php if ( $i == $total ) { echo 'last'; } ?>">
					<?php dynamic_sidebar( 'footer-' . $i ); ?>
				</div>
					<?php } ?>
				<?php } ?>
			<?php } ?>
		</div>
		</div>
		</div>
	    <?php } ?>
<div id="footer-copyright">
	<div class="container">
	     <div class="copyright">Copyright © <?php echo intval(date('Y')); ?> <a class="site-link" href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>" rel="home"><?php bloginfo('name'); ?></a> <?php if( itliu('itliu_beian') ) { ?> <a href="http://www.miitbeian.gov.cn" rel="external nofollow" target="_blank"><?php echo itliu('itliu_beian'); ?></a><?php } ?> <?php if( itliu('itliu_statistics_code') ) { ?><?php echo itliu('itliu_statistics_code'); ?><?php } ?> Powered By WordPress · Theme By <a href="https://www.wptu.cn" target="_blank" rel="nofollow">itliu</a> 
		</div>
		<div class="social-footer">
			<?php if(itliu('itliu_social_weibo')){?>
				<a class="weiboii" href="<?php echo itliu('itliu_social_weibo') ;  ?>" target="_blank"><i class="icon-weibo"></i></a>
			<?php } ?>
			<?php if(itliu('itliu_social_qqweibo')){?>
				<a class="ttweiboii" href="<?php echo itliu('itliu_social_qqweibo') ;  ?>" target="_blank" rel="nofollow" title="腾讯微博"><i class="icon-tencent-weibo"></i></a>
			<?php } ?>
			<?php if(itliu('itliu_social_email')){?>
				<a class="mailii" href="http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=<?php echo itliu('itliu_social_email');?>"target="_blank"><i class="icon-mail-2"></i></a>
			<?php } ?>
			<?php if(itliu('itliu_social_qq')){?>
				<a class="qqii" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo itliu('itliu_social_qq');  ?>&site=qq&menu=yes" target="_blank"><i class="icon-qq"></i></a>
			<?php } ?>
			<?php if(itliu('itliu_social_weixin')){?>
				<a id="tooltip-f-weixin" class="wxii" href="javascript:void(0);"><i class="icon-wechat"></i></a>
			<?php } ?>
		</div>
		
	</div>
</div>
</footer>
<div class="side-buttons" id="side-buttons"> 
   <div class="side-buttons-box sb-comment "> 
    <a href="/" rel="nofollow"><i class="sb-icon icon-commenting-o" title="我要留言"></i></a> 
   </div> 
   <div class="side-buttons-box sb-top"> 
    <a href="#"><i class="icon-up-open" title="返回顶部"></i></a> 
   </div> 
   </div>

<div class="search-form">
	<form method="get" action="<?php bloginfo('url'); ?>" role="search">       
		<div class="search-form-inner">
			<div class="search-form-box">
				 <input class="form-search" type="text" name="s" placeholder="键入搜索关键词">
				 <button type="submit" id="btn-search"><i class="icon-search"></i> </button>
				 
			</div>
			<?php
				$keyword = itliu('itliu_custom_searchkey');
				if( ! empty( $keyword ) ) :
					$key = explode(',',$keyword);

			?>
			<div class="search-commend">
				<h4>大家都在搜</h4>
				<ul>
					<?php
						for ($i=0; $i < count($key); $i++) { 
							echo '<li><a href="'.get_option('home').'/?s='.$key[$i].'">'.$key[$i].'</a></li>';
						}
					?>
				</ul>
			</div>
			<?php endif; ?>
		</div>                
	</form> 
	<div class="close-search">
		<span class="close-top"></span>
			<span class="close-bottom"></span>
    </div>
</div>
<div class="f-weixin-dropdown">
	<div class="tooltip-weixin-inner">
		<h3>关注我们的公众号</h3>
		<div class="qcode"> 
			<img src="<?php echo itliu('itliu_social_weixin') ; ?>" width="160" height="160" alt="微信公众号">
		</div>
	</div>
	<div class="close-weixin">
		<span class="close-top"></span>
			<span class="close-bottom"></span>
    </div>
</div>      
<?php wp_footer();?>
</body>
</html>