/**
 * Generated on 2019/09/06 15:29:33
 *
 * @package   Liu-One
 * @version   v2.0
 * @author    WPTU爱好者
 * @Email     2774251932@qq.com
 * @site      https://www.wptu.cn
 * @copyright Copyright (c) 2016-2020 by WPTU爱好者
 * @link      https://www.wptu.cn/wptu.html
 *
**/
jQuery(document)[["ready"]](function(e){function o(o,a){var s=(e(".uploaded-file"),e(this));i=a,o[["preventDefault"]](),n?n[["open"]]():(n=wp[["media"]][["frames"]][["optionsframework_upload"]]=wp[["media"]]({title:s[["data"]]("choose"),button:{text:s[["data"]]("update"),close:!1}}),n[["on"]]("select",function(){var o=n[["state"]]()[["get"]]("selection")[["first"]]();n[["close"]](),i[["find"]](".upload")[["val"]](o[["attributes"]][["url"]]),"image"==o[["attributes"]][["type"]]&&i[["find"]](".screenshot")[["empty"]]()[["hide"]]()[["append"]]('<img src="'+o[["attributes"]][["url"]]+'"><a class="remove-image">Remove</a>')[["slideDown"]]("fast"),i[["find"]](".upload-button")[["unbind"]]()[["addClass"]]("remove-file")[["removeClass"]]("upload-button")[["val"]](optionsframework_l10n[["remove"]]),i[["find"]](".of-background-properties")[["slideDown"]](),i[["find"]](".remove-image, .remove-file")[["on"]]("click",function(){t(e(this)[["parents"]](".section"))})})),n[["open"]]()}function t(t){t[["find"]](".remove-image")[["hide"]](),t[["find"]](".upload")[["val"]](""),t[["find"]](".of-background-properties")[["hide"]](),t[["find"]](".screenshot")[["slideUp"]](),t[["find"]](".remove-file")[["unbind"]]()[["addClass"]]("upload-button")[["removeClass"]]("remove-file")[["val"]](optionsframework_l10n[["upload"]]),e(".section-upload .upload-notice")[["length"]]>0&&e(".upload-button")[["remove"]](),t[["find"]](".upload-button")[["on"]]("click",function(t){o(t,e(this)[["parents"]](".section"))})}var n,i;e(".remove-image, .remove-file")[["on"]]("click",function(){t(e(this)[["parents"]](".section"))}),e(".upload-button")[["click"]](function(t){o(t,e(this)[["parents"]](".section"))})});