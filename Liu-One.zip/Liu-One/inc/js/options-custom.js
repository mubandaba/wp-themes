/**
 * Generated on 2019/09/06 15:29:33
 *
 * @package   Liu-One
 * @version   v2.0
 * @author    WPTU爱好者
 * @Email     2774251932@qq.com
 * @site      https://www.wptu.cn
 * @copyright Copyright (c) 2016-2020 by WPTU爱好者
 * @link      https://www.wptu.cn/wptu.html
 *
**/
jQuery(document)[["ready"]](function(a){function i(){var i=a(".group"),e=a(".nav-tab-wrapper a"),o="";i[["hide"]](),"undefined"!=typeof localStorage&&(o=localStorage[["getItem"]]("active_tab")),""!=o&&a(o)[["length"]]?(a(o)[["fadeIn"]](),a(o+"-tab")[["addClass"]]("nav-tab-active")):(a(".group:first")[["fadeIn"]](),a(".nav-tab-wrapper a:first")[["addClass"]]("nav-tab-active")),e[["click"]](function(o){o[["preventDefault"]](),e[["removeClass"]]("nav-tab-active"),a(this)[["addClass"]]("nav-tab-active")[["blur"]](),"undefined"!=typeof localStorage&&localStorage[["setItem"]]("active_tab",a(this)[["attr"]]("href"));var r=a(this)[["attr"]]("href");i[["hide"]](),a(r)[["fadeIn"]]()})}a(".of-color")[["wpColorPicker"]](),a(".of-radio-img-img")[["click"]](function(){a(this)[["parent"]]()[["parent"]]()[["find"]](".of-radio-img-img")[["removeClass"]]("of-radio-img-selected"),a(this)[["addClass"]]("of-radio-img-selected")}),a(".of-radio-img-label")[["hide"]](),a(".of-radio-img-img")[["show"]](),a(".of-radio-img-radio")[["hide"]](),a(".nav-tab-wrapper")[["length"]]>0&&i(),a(".optionsframework-radio-img-img")[["click"]](function(){a(this)[["parent"]]()[["parent"]]()[["find"]](".optionsframework-radio-img-img")[["removeClass"]]("optionsframework-radio-img-selected"),a(this)[["addClass"]]("optionsframework-radio-img-selected")}),a(".optionsframework-radio-img-label")[["hide"]](),a(".optionsframework-radio-img-img")[["show"]](),a(".optionsframework-radio-img-radio")[["hide"]]()});