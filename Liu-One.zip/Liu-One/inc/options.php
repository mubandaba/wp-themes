<?php
/**
 * Generated on 2019/9/6 15:17:51
 *
 * @package   Liu-One
 * @version   v2.0
 * @author    WPTU爱好者
 * @Email     2774251932@qq.com
 * @site      https://www.wptu.cn
 * @copyright Copyright (c) 2016-2020 by WPTU爱好者
 * @link      https://www.wptu.cn/wptu.html
 *
**/
?>
<?php
function optionsframework_option_name() {
	$themename = wp_get_theme();
	$themename = preg_replace("/\W/", "_", strtolower($themename) );
	$optionsframework_settings = get_option( 'optionsframework' );
	$optionsframework_settings['id'] = $themename;
	update_option( 'optionsframework', $optionsframework_settings );
}
function optionsframework_options() {

// 将所有页面（pages）加入数组
	$options_pages = array();
	$options_pages_obj = get_pages('sort_column=post_parent,menu_order');
	$options_pages[''] = '选择页面：';
	foreach ($options_pages_obj as $page) {
		$options_pages[$page->ID] = $page->post_title;
	}
	$options_categories = array();
	$options_categories_obj = get_categories();
	foreach ($options_categories_obj as $category) {
		$options_categories[$category->cat_ID] = $category->cat_name;
	}

	$topslide_array = array(		
		'DESC' => __('默认排序'),
		'date' => __('时间排序'),
		'rand' => __('随机排序')
	);
	$avatar_array = array(		
		'one' => 'WP默认',
		'two' => 'V2EX',		
	);

	$index3_array = array(		
		'one' => '显示分类',
		'two' => '显示顶置文章',
		'three' => '关闭',	
	);


    $options_links = array();
    $options_links_obj = get_terms( 'link_category' );
    foreach ($options_links_obj as $link) {
        $options_links[$link->term_id] = $link->name;
    }

	$imagepath =  get_template_directory_uri() . '/img/themestyle/';

	$options = array();
	
	/*****基本设置*****/
	$options[] = array(
		'name' => __('基本设置'),
		'type' => 'heading');
	
	$options[] = array(
		'name' => __('PC端顶部Logo'),
		'desc' => __('上传一个尺寸为宽220px，高50px的图片，或者直接输入图片地址'),
		'id' => 'itliu_logo',
		'type' => 'upload');

	$options[] = array(
		'name' => __('后台登陆Logo'),
		'desc' => __('请上传一个尺寸为280*84的Logo文件或是输入文件URL'),
		'id' => 'itliu_login_logo',
		'type' => 'upload');

	$options[] = array(
		'name' => __('后台登陆背景图数量'),
		'desc' => __('输入想要显示的数量，最大3'),
		'id' => 'itliu_login_bgp_num',
		"class" => "mini",
		"std"  => 1,
		'type' => 'text');

	$options[] = array(
		'name' => __('后台登陆背景图1'),
		'desc' => __('请上传大尺寸的背景图片文件或是输入文件URL'),
		'id' => 'itliu_login_bgp_1',
		'type' => 'upload');

	$options[] = array(
		'name' => __('后台登陆背景图2'),
		'desc' => __('请上传大尺寸的背景图片文件或是输入文件URL'),
		'id' => 'itliu_login_bgp_2',
		'type' => 'upload');

	$options[] = array(
		'name' => __('后台登陆背景图3'),
		'desc' => __('请上传大尺寸的背景图片文件或是输入文件URL'),
		'id' => 'itliu_login_bgp_3',
		'type' => 'upload');

	$options[] = array(
		'name' => __('作者小工具背景图'),
		'desc' => __('请上传一个作者背景图片或是输入图片URL'),
		'id' => 'itliu_author_bgp',
		'type' => 'upload');

	$options[] = array(
		'name' => __('网站Favicon地址'),
		'desc' => __('输入Favicon文件URL,或者直接替换主题img文件夹中的Favicon文件。制作Favicon文件请自行百度'),
		'id' => 'itliu_favicon',
		'type' => 'upload');

	$options[] = array(
		'name' => __('文章页上下篇背景图'),
		'desc' => __('请上传一个文章页上一篇和下一篇默认的背景图片或是输入图片URL'),
		'id' => 'itliu_p_n_bgp',
		'type' => 'upload');
		
	$options[] = array(
		'name' => "底部边栏小工具列数",
		'desc' => "请选择合适列数开启底部边栏推荐数量：3",
		'id' => "footer-widgets",
		'std' => "0",
		'type' => "images",
		'options' => array(
			'0' => $imagepath . 'layout-off.png',
			'1' => $imagepath . 'footer-widgets-1.png',
			'2' => $imagepath . 'footer-widgets-2.png',
			'3' => $imagepath . 'footer-widgets-3.png',
			'4' => $imagepath . 'footer-widgets-4.png'
		)
	);

	$options[] = array(
		'name' => __('网站统计代码'),
		'desc' => sprintf( __( '如百度统计、CNZZ、Google Analytics，不填则不显示' ) ),
		'id' => 'itliu_statistics_code',
		'type' => 'textarea');
		
	$options[] = array(
	'name' => __('自定义Header代码'),
	'desc' => __('如果有任何想添加在头部的代码，可以写在这里。例如一些调用JS的代码、css代码等。'),
	'id' => 'headcode',
	'std' => '',
	'type' => 'textarea');
	
	$options[] = array(
	'name' => __('自定义底部footer代码'),
	'desc' => __('如果有任何想添加在底部的代码，可以写在这里。例如一些调用JS的代码等。'),
	'id' => 'footcode',
	'std' => '',
	'type' => 'textarea');

		
	$options[] = array(
		'name' => __('网站备案号'),
		'desc' => __('在显示网站底部，没有备案号可不填。不填则不显示'),
		'id' => 'itliu_beian',
		"class" => "mini",
		'type' => 'text');
		
	$options[] = array(
		'name' => __('建站日期'),
		'desc' => __('必须以2008-8-18这种形式填写'),
		'id' => 'itliu_jztimes',
		"class" => "mini",
		'type' => 'text');
		
	/*****SEO优化*****/
	$options[] = array(
		'name' => __('SEO'),
		'type' => 'heading');

	$options[] = array(
		'name' => __('主题自带SEO设置'),
		'id' => 'itliu_dis_seo',
		'std' => true,
		'desc' => __('关闭之后，请自行安装SEO插件，下方填写的连接符，描述和关键词将无效。'),
		'type' => 'checkbox');
	
	$options[] = array(
		'name' => __('网站标题连接符'),
		'desc' => __('一经选择，切勿更改，对SEO不友好，一般为“-”或“_”'),
		'id' => 'page_sign',
		'std' => '-',
		'class' => 'mini',
		'type' => 'text');

	$options[] = array(
		'name' => __('网站描述'),
		'desc' => __('SEO设置，输入您的网站描述，一般不超过200字符'),
		'id' => 'itliu_description',
		'type' => 'textarea');

	$options[] = array(
		'name' => __('网站关键词'),
		'desc' => sprintf( __( 'SEO设置，输入您的网站关键词，以英文逗号(,)隔开。' ) ),
		'id' => 'itliu_keywords',
		'type' => 'textarea');
	
	$options[] = array(
		'name' => __('启动面包屑导航(Breadcrumb)'),
		'id' => 'itliu_breadcrumbs',
		'std' => false,
		'desc' => __('显示在文章页面及分类列表页面中'),
		'type' => 'checkbox');

	$options[] = array(
		'name' => __('文章外链自动添加nofollow属性'),
		'id' => 'itliu_autonofollow',
		'std' => false,
		'desc' => __('防止外链分散了网站内页的权重'),
		'type' => 'checkbox');

	$options[] = array(
		'name' => __('文章tag关键词自动描文本'),
		'id' => 'itliu_keywordlink',
		'std' => false,
		'desc' => __('自动描文本,优化seo'),
		'type' => 'checkbox');

	$options[] = array(
		'name' => __('自动给文章图片添加Alt信息'),
		'id' => 'friendly',
		'std' => true,
		'desc' => __(''),
		'type' => 'checkbox');

		/*****网站加速/优化设置*****/
	$options[] = array(
		'name' => __('网站优化'),
		'type' => 'heading');

	$options[] = array(
		'name' => __('网站导航智能显示'),
		'id' => 'itliu_head_fixed',
		'std' => true,
		'desc' => __('默认开启，关闭之后导航将固定在顶部'),
		'type' => 'checkbox');
		
	$options[] = array(
		'name' => __('首页自定义分类TAB-显示的分类'),
		'desc' => __('填上分类id即可，多个分类用英文符号“,”隔开,必须开启文章列表AJAX加载按钮才生效'),
		'id' => 'itliu_index_custom_cat_tab_id',
		"class" => "mini",
		'type' => 'text');	

	$options[] = array(
		'name' => __('不显示指定分类中的文章（从首页最新文章模块中）'),
		'desc' => __('在分类前打扣即不显示该分类的文章。'),
		'id' => 'notinhome',
		'options' => $options_categories,
		'type' => 'multicheck');

	$options[] = array(
    	'name' => '预定义搜索关键词',
    	'desc' => '按照如下格式填写预定的搜索关键词：每个关键词用英文逗号隔开',
    	'id' => 'itliu_custom_searchkey',
    	'type' => 'text');

	$options[] = array(
		'name' => __('文章列表AJAX加载文章'),
		'id' => 'itliu_ajax_posts',
		'std' => true,
		'type' => 'checkbox');
		
	$options[] = array(
		'name' => __('文章列表使用TimThumb进行截取缩略图'),
		'id' => 'itliu_timthumb',
		'std' => true,
		'type' => 'checkbox');

	$options[] = array(
		'name' => __('设置文章默认缩略图'),
		'id' => 'itliu_post_thumbnail',
		'desc' => __('当文章无图或者没有指定特色图像的时候，默认显示该张图片作为文章缩略图'),
		'std' => '',
		'type' => 'upload');

	
	$options[] = array(
		'name' => __('图片延迟加载'),
		'id' => 'itliu_timthumb_lazyload',
		'std' => true,
		'desc' => __(''),
		'type' => 'checkbox');	
		
	$options[] = array(
		'name' => __('延迟加载默认图片-小图'),
		'desc' => __('请上传一个尺寸为240*160的图片文件或是输入文件URL'),
		'id' => 'default_thumbnail',
		'type' => 'upload');
		
	$options[] = array(
		'name' => __('延迟加载默认图片-大图'),
		'desc' => __('请上传一个尺寸为760*300的图片文件或是输入文件URL'),
		'id' => 'default_thumbnail_700',
		'type' => 'upload');

	$options[] = array(
		'name' => __('文章列表特效'),
		'id' => 'itliu_wow_single_list',
		'std' => true,
		'desc' => __('开启则加特效，Duang~'),
		'type' => 'checkbox');
	
	$options[] = array(
		'name' => __('文章页图片fancybox暗箱功能'),
		'id' => 'itliu_fancybox',
		'std' => false,
		'desc' => __('打开后，文章中如带【有图片链接的图片】，点击都将是弹窗显示。'),
		'type' => 'checkbox');	

	$options[] = array(
		'name' => __('默认头像'),
		'id' => 'new_avatar_pic',
        'std' => get_template_directory_uri() . '/img/avatar.png',
		'type' => 'upload');	
	
	$options[] = array(
		'name' => __('Gravatar 头像调用渠道'),
		'desc' => __('默认使用【V2EX】'),
		'id' => 'itliu_get_avatar',
		'std' => 'two',
		'type' => 'radio',	
		'options' => $avatar_array);	
		
	$options[] = array(
		'name' => __('关闭WP评论系统'),
		'id' => 'itliu_close_comments',
		'std' => false,
		'desc' => __('开启后全站评论将被关闭'),
		'type' => 'checkbox');
		
	$options[] = array(
		'name' => __('搜狐畅言系统'),
		'id' => 'itliu_sohucy_comments',
		'std' => false,
		'desc' => __('请配合上面选项使用'),
		'type' => 'checkbox');
		
	$options[] = array(
		'name' => __('文章页每段文字首行缩进2个字符'),
		'id' => 'itliu_text_indent',
		'std' => false,
		'desc' => __(''),
		'type' => 'checkbox');
		
	$options[] = array(
		'name' => __('根据上传时间重命名上传的图片文件'),
		'id' => 'itliu_upload_filter',
		'std' => true,
		'desc' => __('', 'options_framework_theme）'),
		'type' => 'checkbox');

	$options[] = array(
		'name' => __('文章评论中禁止含有链接的评论（防垃圾评论机制）'),
		'id' => 'itliu_comment_no_html',
		'std' => true,
		'desc' => __('', 'options_framework_theme）'),
		'type' => 'checkbox');

	$options[] = array(
		'name' => __('文章评论中禁止全英文评论（防垃圾评论机制）'),
		'id' => 'itliu_some_chinese',
		'std' => true,
		'desc' => __('', 'options_framework_theme）'),
		'type' => 'checkbox');

	$options[] = array(
		'name' => __('禁用所有文章类型的修订版本'),
		'id' => 'revisions_to_keep',
		'std' => true,
		'desc' => __('', 'options_framework_theme）'),
		'type' => 'checkbox');

	$options[] = array(
		'name' => __('删除 wp_head 中无关紧要的代码'),
		'id' => 'itliu_wphead',
		'std' => true,
		'desc' => __(''),
		'type' => 'checkbox');


    /*******首页幻灯片设置*******/
	$options[] = array(
		'name' => __('首页幻灯片'),
		'type' => 'heading');

	$options[] = array(
		'name' => __('首页幻灯开关'),
		'desc' => __('开启'),
		'id' => 'itliu_home_slide',
		'std' => true,
		'type' => 'checkbox');


	$options[] = array(
		'name' => __('幻灯片显示文章数量'),
		'desc' => __('首页幻灯片显示文章的数量，默认4篇，不要超过6篇'),
		'id' => 'itliu_slide_number',
		'std' => '4',
		"class" => "mini",
		'type' => 'text');

	$options[] = array(
		'name' => __('显示指定分类的文章'),
		'desc' => __('首页幻灯片轮播指定分类中的文章，填上分类id即可，多个分类用英文符号“,”隔开（例如：1,2），不可留空。'),
		'id' => 'itliu_slide_fenlei',
		"class" => "mini",
		'type' => 'text');

	$options[] = array(
		'name' => __('显示文章信息（标题、作者信息、摘文等）'),
		'id' => 'itliu_slide_info',
		'std' => true,
		'type' => 'checkbox');


	$options[] = array(
		'name' => __('显示文章顺序'),
		'desc' => __(''),
		'id' => 'itliu_slide_order',
		'std' => 'DESC',
		'type' => 'radio',
		'options' => $topslide_array);

	$options[] = array(
		'name' => __('首页幻灯片【手动添加图片版】', 'options_framework_theme'),
		'id' => 'itliu_slide2',
		'std' => false,
		'desc' => __('展示在首页，此功能具有优先权，选择后，则幻灯会展示手动设置的图片幻灯,并且只支持样式为Slide2和Slide3和Slide4','options_framework_theme'),
		'type' => 'checkbox');
		
	$options[] = array(
		'name' => __('图片1', 'options_framework_theme'),
		'desc' => __('请上传一个尺寸为740*350的图片文件或是输入文件URL', 'options_framework_theme'),
		'id' => 'itliu_slide_img_1',
		'type' => 'upload');
		
	$options[] = array(
		'name' => __('图片1跳转链接', 'options_framework_theme'),
		'desc' => __('填写图片的跳转链接，链接前记得加上“http://”', 'options_framework_theme'),
		'id' => 'itliu_slide_url_1',
		'type' => 'text');
		
	$options[] = array(
		'name' => __('图片1文字说明', 'options_framework_theme'),
		'desc' => __('', 'options_framework_theme'),
		'id' => 'itliu_slide_title_1',
		'type' => 'text');
	
		
	$options[] = array(
		'name' => __('图片2', 'options_framework_theme'),
		'desc' => __('请上传一个尺寸为740*350的图片文件或是输入文件URL', 'options_framework_theme'),
		'id' => 'itliu_slide_img_2',
		'type' => 'upload');
		
	$options[] = array(
		'name' => __('图片2跳转链接', 'options_framework_theme'),
		'desc' => __('填写图片的跳转链接，链接前记得加上“http://”', 'options_framework_theme'),
		'id' => 'itliu_slide_url_2',
		'type' => 'text');
		
	$options[] = array(
		'name' => __('图片2文字说明', 'options_framework_theme'),
		'desc' => __('', 'options_framework_theme'),
		'id' => 'itliu_slide_title_2',
		'type' => 'text');
		
	$options[] = array(
		'name' => __('图片3', 'options_framework_theme'),
		'desc' => __('请上传一个尺寸为740*350的图片文件或是输入文件URL', 'options_framework_theme'),
		'id' => 'itliu_slide_img_3',
		'type' => 'upload');
		
	$options[] = array(
		'name' => __('图片3跳转链接', 'options_framework_theme'),
		'desc' => __('填写图片的跳转链接，链接前记得加上“http://”', 'options_framework_theme'),
		'id' => 'itliu_slide_url_3',
		'type' => 'text');
		
	$options[] = array(
		'name' => __('图片3文字说明', 'options_framework_theme'),
		'desc' => __('', 'options_framework_theme'),
		'id' => 'itliu_slide_title_3',
		'type' => 'text');
		
	$options[] = array(
		'name' => __('图片4', 'options_framework_theme'),
		'desc' => __('请上传一个尺寸为740*350的图片文件或是输入文件URL', 'options_framework_theme'),
		'id' => 'itliu_slide_img_4',
		'type' => 'upload');
		
	$options[] = array(
		'name' => __('图片4跳转链接', 'options_framework_theme'),
		'desc' => __('填写图片的跳转链接，链接前记得加上“http://”', 'options_framework_theme'),
		'id' => 'itliu_slide_url_4',
		'type' => 'text');
		
	$options[] = array(
		'name' => __('图片4文字说明', 'options_framework_theme'),
		'desc' => __('', 'options_framework_theme'),
		'id' => 'itliu_slide_title_4',
		'type' => 'text');
		
	$options[] = array(
		'name' => __('图片5', 'options_framework_theme'),
		'desc' => __('请上传一个尺寸为740*350的图片文件或是输入文件URL', 'options_framework_theme'),
		'id' => 'itliu_slide_img_5',
		'type' => 'upload');
		
	$options[] = array(
		'name' => __('图片5跳转链接', 'options_framework_theme'),
		'desc' => __('填写图片的跳转链接，链接前记得加上“http://”', 'options_framework_theme'),
		'id' => 'itliu_slide_url_5',
		'type' => 'text');
		
	$options[] = array(
		'name' => __('图片5文字说明', 'options_framework_theme'),
		'desc' => __('', 'options_framework_theme'),
		'id' => 'itliu_slide_title_5',
		'type' => 'text');
		
	$options[] = array(
		'name' => __('图片6', 'options_framework_theme'),
		'desc' => __('请上传一个尺寸为740*350的图片文件或是输入文件URL', 'options_framework_theme'),
		'id' => 'itliu_slide_img_6',
		'type' => 'upload');
		
	$options[] = array(
		'name' => __('图片6跳转链接', 'options_framework_theme'),
		'desc' => __('填写图片的跳转链接，链接前记得加上“http://”', 'options_framework_theme'),
		'id' => 'itliu_slide_url_6',
		'type' => 'text');
		
	$options[] = array(
		'name' => __('图片6文字说明', 'options_framework_theme'),
		'desc' => __('', 'options_framework_theme'),
		'id' => 'itliu_slide_title_6',
		'type' => 'text');		


	/*******文章页优化设置*******/
	$options[] = array(
		'name' => __('文章页优化'),
		'type' => 'heading');


    $options[] = array(
    	'name' => '原创标识文字',
    	'desc' => '自定义原创标识文字',
    	'std' => '原创文章',
    	"class" => "mini",
    	'id' => 'itliu_custom_cc',
    	'type' => 'text');


	$options[] = array(
		'name' => __('文章页显示作者信息'),
		'desc' => __('默认开启。开启后，作者信息将展示在右侧栏第一位'),
		'id' => 'itliu_post_author_box',
		'std' => true,
		'type' => 'checkbox');

	$options[] = array(
		'name' => __('管理员的称号'),
		'desc' => __('设置管理员的称号，默认为 【官方】'),
		'id' => 'itliu_site_admin_name',
		'std' => '官方',
		"class" => "mini",
		'type' => 'text');	

	$options[] = array(
		'name' => __('文章启动点赞功能'),
		'id' => 'itliu_post_like',
		'std' => true,
		'desc' => __('免插件文章点赞功能'),
		'type' => 'checkbox');	

	$options[] = array(
		'name' => __('显示百度分享'),
		'id' => 'itliu_baidushare',
		'std' => true,
		'desc' => __('默认开启', 'options_framework_theme）'),
		'type' => 'checkbox');


	$options[] = array(
		'name' => __('文章页显示上下文图文链接'),
		'desc' => __('默认开启。'),
		'id' => 'nextprevposts',
		'std' => true,
		'type' => 'checkbox');

	$options[] = array(
		'name' => __('文章页显示相关文章模块'),
		'desc' => __('默认开启。'),
		'id' => 'related-post',
		'std' => true,
		'type' => 'checkbox');

	$options[] = array(
    	'name' => '文章页显示相关文章模块-显示文章数量',
    	'desc' => '默认6篇，请填写3的倍数',
    	'std' => '6',
    	'id' => 'related-post-num',
    	"class" => "mini",
    	'type' => 'text');

	$options[] = array(
		'name' => __('文章页打赏功能'),
		'desc' => __('默认关闭。开启后请在下方上传二维码图片。'),
		'id' => 'itliu_reward',
		'std' => false,
		'type' => 'checkbox');

	$options[] = array(
		'name' => __('支付宝打赏【默认】二维码上传'),
		'desc' => __('请先开启打赏功能，【不填写则不显示支付宝】，请上传一个尺寸为200*200的图片文件或是输入文件URL。如需每个用户都单独显示各自的支付二维码，请到【后台】-【用户】-【个人资料】中上传。'),
		'id' => 'itliu_alireward',
		'type' => 'upload');

	$options[] = array(
		'name' => __('微信打赏【默认】二维码上传'),
		'desc' => __('请先开启打赏功能，【不填写则不显示微信】，请上传一个尺寸为200*200的图片文件或是输入文件URL。如需每个用户都单独显示各自的支付二维码，请到【后台】-【用户】-【个人资料】中上传。'),
		'id' => 'itliu_wxreward',
		'type' => 'upload');

		/*******页面设置*******/
	$options[] = array(
		'name' => __('页面设置'),
		'type' => 'heading');
	
	$options[] = array(
		'name' => __('投稿页面可选分类'),
		'desc' => __('填写投稿页面可以选择的分类ID，用英文逗号隔开'),
		'id' => 'contribute_cat_id',
		'class' => 'mini',
		'type' => 'text');

	$options[] = array( 
		"name" => "选择投稿页面",
		"desc" => "选择投稿页面，如果没有请在页面中新建，模板选择投稿",
		"id" => "contribute_page_id",
		"type" => "select",
		"class" => "mini", //mini, tiny, small
		"options" => $options_pages);

	$options[] = array(
		'name' => __('投稿文章发布通知内容'),
		'desc' => __('自定义投稿文章发布后通知的邮件内容'),
		'id' => 'contribute_no_content',
		'class' => 'mini',
		'type' => 'editor');

	$options[] = array(
		'name' => __('友情链接-页面模版-顶部背景图'),
		'desc' => __('找一个流弊的图片替换吧，图片宽度一定要大，一定要逼格！不填则使用默认图片'),
		'id' => 'links_banner_pic',
		'type' => 'upload');

	$options[] = array(
		'name' => __('热门标签-页面模版-顶部背景图'),
		'desc' => __('找一个流弊的图片替换吧，图片宽度一定要大，一定要逼格！不填则使用默认图片'),
		'id' => 'tags_banner_pic',
		'type' => 'upload');

	$options[] = array(
		'name' => __('热门文章列表-页面模版-顶部背景图'),
		'desc' => __('找一个流弊的图片替换吧，图片宽度一定要大，一定要逼格！不填则使用默认图片'),
		'id' => 'like_banner_pic',
		'type' => 'upload');

	$options[] = array(
		'name' => __('归档页面-页面模版-顶部背景图'),
		'desc' => __('找一个流弊的图片替换吧，图片宽度一定要大，一定要逼格！不填则使用默认图片'),
		'id' => 'archives_banner_pic',
		'type' => 'upload');

	$options[] = array(
		'name' => __('网址导航页面-页面模版-顶部背景图'),
		'desc' => __('找一个流弊的图片替换吧，图片宽度一定要大，一定要逼格！不填则使用默认图片'),
		'id' => 'pagenav_banner_pic',
		'type' => 'upload');

	$options[] = array(
		'name' => __('投稿页面-页面模版-顶部背景图'),
		'desc' => __('找一个流弊的图片替换吧，图片宽度一定要大，一定要逼格！不填则使用默认图片'),
		'id' => 'pagecon_banner_pic',
		'type' => 'upload');

	/****侧栏随动*****/
	$options[] = array(
		'name' => __('侧栏悬停'),
		'type' => 'heading');

	$options[] = array(
		'name' => __('侧栏随动').__('首页'),
		'id' => 'sideroll_index_s',
		'std' => false,
		'desc' => __('开启后，默认为小工具最后一个栏目随动'),
		'type' => 'checkbox');

	$options[] = array(
		'name' => __('侧栏随动').__('分类|标签|搜索页'),
		'id' => 'sideroll_list_s',
		'std' => false,
		'desc' => __('开启后，默认为小工具最后一个栏目随动'),
		'type' => 'checkbox');

	$options[] = array(
		'name' => __('侧栏随动').__('文章页'),
		'id' => 'sideroll_post_s',
		'std' => false,
		'desc' => __('开启后，默认为小工具最后一个栏目随动'),
		'type' => 'checkbox');

	$options[] = array(
		'name' => __('侧栏随动').__('页面'),
		'id' => 'sideroll_page_s',
		'std' => false,
		'desc' => __('开启后，默认为小工具最后一个栏目随动'),
		'type' => 'checkbox');

	/*******社交链接设置*******/
	$options[] = array(
		'name' => __('社交工具'),
		'type' => 'heading' );
		
	$options[] = array(
		'name' => __('新浪微博链接'),
		'desc' => __('直接输入您的新浪微博链接，别忘了开头带 http:// ，将出现在底栏。'),
		'id' => 'itliu_social_weibo',
		'type' => 'text');	
		
	$options[] = array(
		'name' => __('腾讯微博'),
		'desc' => __('直接输入您的腾讯微博链接，别忘了开头带 http://，将出现在底栏。'),
		'id' => 'itliu_social_qqweibo',
		'type' => 'text');	
		
	$options[] = array(
		'name' => __('QQ邮箱'),
		'desc' => __('直接输入QQ邮箱即可，将出现在底栏。'),
		'id' => 'itliu_social_email',
		'type' => 'text');	
		
	$options[] = array(
		'name' => __('QQ'),
		'desc' => __('直接输入QQ号即可，将出现在底栏。'),
		'id' => 'itliu_social_qq',
		'type' => 'text');	
		
	$options[] = array(
		'name' => __('微信图片'),
		'desc' => __('请上传一个尺寸为长宽160px图片文件或是输入文件URL，将出现在底栏和侧栏社交小工具中（需先启用）'),
		'id' => 'itliu_social_weixin',
		'type' => 'upload');
			
	/*******广告设置	*******/
	$options[] = array(
		'name' => __('广告设置'),
		'type' => 'heading' );
	
	$options[] = array(
		'name' => __('文章列表中广告模块'),
		'id' => 'itliu_ad_posts_pc',
		'std' => false,
		'desc' => __('展示于文章列表的1个宽度为747.88px的广告位，有极高的点击率'),
		'type' => 'checkbox');
		
	$options[] = array(
		'name' => __('展示于第几篇文章后？'),
		'desc' => __('自定义显示位置，例如输入7，则此图片出现于第七篇文章之后。'),
		'id' => 'itliu_ad_posts_pc_num',
		"class" => "mini",
		'std' => '3',
		'type' => 'text');
		
	$options[] = array(
		'name' => __('文章列表中广告模块-广告代码'),
		'desc' => __('图片宽度为760px'),
		'id' => 'itliu_ad_posts_pc_url',
	    'type' => 'textarea');	
	
	$options[] = array(
		'name' => __('文章标题上方广告模块'),
		'id' => 'itliu_single_top_ad_content_pc',
		'std' => false,
		'desc' => __('展示于文章列表的1个宽度为760px的广告位，有极高的点击率'),
		'type' => 'checkbox');
	
	$options[] = array(
		'name' => __('文章标题上方广告模块-广告代码'),
		'desc' => __('图片宽度为760px'),
		'id' => 'itliu_single_top_ad_content_pc_url',
		'type' => 'textarea');		

	$options[] = array(
		'name' => __('文章下方广告模块'),
		'id' => 'itliu_ad_content_pc',
		'std' => false,
		'desc' => __('展示于文章列表的1个宽度为760px的广告位，有极高的点击率'),
		'type' => 'checkbox');
	
	$options[] = array(
		'name' => __('文章下方广告模块-广告代码'),
		'desc' => __('图片宽度为760px'),
		'id' => 'itliu_ad_content_pc_url',
		'type' => 'textarea');		

	$options[] = array(
		'name' => __('【移动端文章列表】广告模块'),
		'desc' => __('展示于文章列表，有极高的点击率。'),
		'id' => 'itliu_ad_posts_m',
		'std' => false,
		'type' => 'checkbox');
		
	$options[] = array(
		'name' => __('展示于第几篇文章后？'),
		'desc' => __('自定义显示位置，例如输入7，则此图片出现于第七篇文章之后。'),
		'id' => 'itliu_ad_posts_m_num',
		"class" => "mini",
		'type' => 'text');
		
	$options[] = array(
		'name' => __('广告代码'),
		'desc' => sprintf( __( '广告图片宽度为480px，图片高度自行决定。' ) ),
		'id' => 'itliu_ad_posts_m_url',
		"std" => '<a href="跳转链接" title="广告标题"><img src="图片链接" alt="图片描述"></a>',
		'type' => 'textarea');	

	$options[] = array(
		'name' => __('移动端文章标题上方广告模块'),
		'id' => 'itliu_top_ad_content_mini',
		'std' => false,
		'desc' => __('展示于文章列表的1个宽度为760px的广告位，有极高的点击率'),
		'type' => 'checkbox');
	
	$options[] = array(
		'name' => __('文章标题上方广告模块-广告代码'),
		'desc' => __('图片宽度为760px'),
		'id' => 'itliu_top_ad_content_mini_url',
		'type' => 'textarea');		

	$options[] = array(
		'name' => __('移动端文章下方广告模块'),
		'id' => 'itliu_ad_content_mini',
		'std' => false,
		'desc' => __('展示于文章列表的1个宽度为760px的广告位，有极高的点击率'),
		'type' => 'checkbox');
	
	$options[] = array(
		'name' => __('文章下方广告模块-广告代码'),
		'desc' => __('图片宽度为480px，图片高度自行决定。'),
		'id' => 'itliu_ad_content_mini_url',
		'type' => 'textarea');	
		
	/*******高级设置	*******/
	$options[] = array(
		'name' => __('高级设置'),
		'type' => 'heading' );	
		
	$options[] = array(
		'name' => __('代码压缩'),
		'id' => 'itliu_html_compression',
		'std' => false,
		'desc' => __('压缩前端代码，加快速度'),
		'type' => 'checkbox');
	
	return $options;
}