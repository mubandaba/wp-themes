/**
 * Generated on 2019/09/06 15:29:33
 *
 * @package   Liu-One
 * @version   v2.0
 * @author    WPTU爱好者
 * @Email     2774251932@qq.com
 * @site      https://www.wptu.cn
 * @copyright Copyright (c) 2016-2020 by WPTU爱好者
 * @link      https://www.wptu.cn/wptu.html
 *
**/
window[["_bd_share_main"]][["F"]][["module"]]("component/partners",function(n,a){a[["partners"]]={evernotecn:{name:"印象笔记"},h163:{name:"网易热"},mshare:{name:"一键分享"},qzone:{name:"QQ空间"},tsina:{name:"新浪微博"},renren:{name:"人人网"},tqq:{name:"腾讯微博"},bdxc:{name:"百度相册"},kaixin001:{name:"开心网"},tqf:{name:"腾讯朋友"},tieba:{name:"百度贴吧"},douban:{name:"豆瓣网"},bdhome:{name:"百度新首页"},sqq:{name:"QQ好友"},thx:{name:"和讯微博"},bdysc:{name:"百度云收藏"},meilishuo:{name:"美丽说"},mogujie:{name:"蘑菇街"},diandian:{name:"点点网"},huaban:{name:"花瓣"},duitang:{name:"堆糖"},hx:{name:"和讯"},fx:{name:"飞信"},youdao:{name:"有道云笔记"},sdo:{name:"麦库记事"},qingbiji:{name:"轻笔记"},people:{name:"人民微博"},xinhua:{name:"新华微博"},mail:{name:"邮件分享"},isohu:{name:"我的搜狐"},yaolan:{name:"摇篮空间"},wealink:{name:"若邻网"},ty:{name:"天涯社区"},fbook:{name:"Facebook"},twi:{name:"Twitter"},linkedin:{name:"linkedin"},copy:{name:"复制网址"},print:{name:"打印"},ibaidu:{name:"百度中心"},weixin:{name:"微信"},iguba:{name:"股吧"}},a[["partnerSort"]]=["mshare","qzone","tsina","bdysc","weixin","renren","tqq","bdxc","kaixin001","tqf","tieba","douban","bdhome","sqq","thx","ibaidu","meilishuo","mogujie","diandian","huaban","duitang","hx","fx","youdao","sdo","qingbiji","people","xinhua","mail","isohu","yaolan","wealink","ty","iguba","fbook","twi","linkedin","h163","evernotecn","copy","print"]});