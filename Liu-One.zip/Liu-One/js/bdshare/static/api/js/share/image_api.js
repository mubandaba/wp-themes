/**
 * Generated on 2019/09/06 15:29:33
 *
 * @package   Liu-One
 * @version   v2.0
 * @author    WPTU爱好者
 * @Email     2774251932@qq.com
 * @site      https://www.wptu.cn
 * @copyright Copyright (c) 2016-2020 by WPTU爱好者
 * @link      https://www.wptu.cn/wptu.html
 *
**/
window[["_bd_share_main"]][["F"]][["module"]]("share/image_api",function(e,i,a){var n=(e("base/tangram")[["T"]],e("base/class")[["Class"]]),t=(e("component/comm_tools"),e("share/api_base"));i[["Api"]]=n[["create"]](function(e){var i=this;i[["_init"]]=function(){var e=i[["getView"]]();e[["render"]](),e[["init"]](),e[["on"]]("moreover",function(){e[["_keepBarVisible"]]()})},i[["_processAction"]]=function(a){var n=i[["getView"]]();return e[["bdPic"]]=n[["_getImageSrc"]](),{data:{type:"imgshare"}}},i[["_distory"]]=function(){}},t[["ApiBase"]])});