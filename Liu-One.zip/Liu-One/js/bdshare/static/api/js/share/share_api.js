/**
 * Generated on 2019/09/06 15:29:33
 *
 * @package   Liu-One
 * @version   v2.0
 * @author    WPTU爱好者
 * @Email     2774251932@qq.com
 * @site      https://www.wptu.cn
 * @copyright Copyright (c) 2016-2020 by WPTU爱好者
 * @link      https://www.wptu.cn/wptu.html
 *
**/
window[["_bd_share_main"]][["F"]][["module"]]("share/share_api",function(n,a,t){var e=(n("base/tangram")[["T"]],n("base/class")[["Class"]]),i=n("component/comm_tools"),o=n("share/api_base");a[["Api"]]=e[["create"]](function(n){function a(a){window[["_bd_share_main"]][["F"]][["use"]]("trans/data",function(t){t[["get"]]({type:"share_count",url:n[["bdUrl"]]||i[["getPageUrl"]](),callback:function(n,t){var e={count:n,display:t};a&&a(e)}})})}var t=this,e={count:0,clicked:!1};t[["_init"]]=function(){var n=t[["getView"]]();n[["render"]](),n[["on"]]("getsharecount",function(){a(function(a){e[["count"]]=a[["count"]],n[["setNumber"]](a[["count"]],a[["display"]])})}),n[["init"]]()},t[["_processAction"]]=function(n){return{data:{type:"share"}}}},o[["ApiBase"]])});