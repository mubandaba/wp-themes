/**
 * Generated on 2019/09/06 15:29:33
 *
 * @package   Liu-One
 * @version   v2.0
 * @author    WPTU爱好者
 * @Email     2774251932@qq.com
 * @site      https://www.wptu.cn
 * @copyright Copyright (c) 2016-2020 by WPTU爱好者
 * @link      https://www.wptu.cn/wptu.html
 *
**/
jQuery(document)[["ready"]](function(){jQuery("inputitliutabox_upload_bottom")[["click"]](function(){return custom_editor=!0,targetfield=jQuery(this)[["prev"]]("input"),tb_show("","media-upload.php?type=image&amp;TB_iframe=true"),window[["original_send_to_editor"]]=window[["send_to_editor"]],window[["send_to_editor"]]=function(t){custom_editor?(imgurl=jQuery("img",t)[["attr"]]("src"),jQuery(targetfield)[["val"]](imgurl)[["focus"]](),custom_editor=!1,tb_remove()):window[["original_send_to_editor"]](t)},!1}),jQuery("inputitliutabox_upload_input")[["each"]](function(){jQuery(this)[["bind"]]("change focus blur",function(){$select="#"+jQuery(this)[["attr"]]("name")+"_img",$value=jQuery(this)[["val"]](),t='<img src ="'+$value+'" />';var t=jQuery($select)[["html"]]("")[["append"]](t)[["find"]]("img");window[["setTimeout"]](function(){parseInt(t[["attr"]]("width"))<20&&jQuery($select)[["html"]]("")},500)})})});