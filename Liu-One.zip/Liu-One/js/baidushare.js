/**
 * Generated on 2019/09/06 15:29:33
 *
 * @package   Liu-One
 * @version   v2.0
 * @author    WPTU爱好者
 * @Email     2774251932@qq.com
 * @site      https://www.wptu.cn
 * @copyright Copyright (c) 2016-2020 by WPTU爱好者
 * @link      https://www.wptu.cn/wptu.html
 *
**/
+function($){with(window[["_bd_share_config"]]={common:{bdText:"",bdMini:"2",bdMiniList:!1,bdPic:"",bdStyle:"0"},share:[{bdCustomStyle:itliu_url[["url_theme"]]+"/includes/css/share.css"}]},document)(0)[(getElementsByTagName("head")[0]||body)[["appendChild"]](createElement("script"))[["src"]]=itliu_url[["url_theme"]]+"/js/bdshare/static/api/js/share.js?cdnversion="+~(-new Date/36e5)]}(jQuery);