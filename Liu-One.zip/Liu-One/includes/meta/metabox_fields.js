/**
 * Generated on 2019/09/06 15:29:33
 *
 * @package   Liu-One
 * @version   v2.0
 * @author    WPTU爱好者
 * @Email     2774251932@qq.com
 * @site      https://www.wptu.cn
 * @copyright Copyright (c) 2016-2020 by WPTU爱好者
 * @link      https://www.wptu.cn/wptu.html
 *
**/
jQuery(document)[["ready"]](function(){var e,t;jQuery(".dami_upload_button")[["live"]]("click",function(i){return t=jQuery(this)[["attr"]]("id"),i[["preventDefault"]](),e?void e[["open"]]():(e=wpitliudia({title:"上传图片",button:{text:"上传"},multiple:!1}),e[["on"]]("select",function(){attachment=e[["state"]]()[["get"]]("selection")[["first"]]()[["toJSON"]](),jQuery("input[name="+t+"]")[["val"]](attachment[["url"]])[["trigger"]]("change")}),void e[["open"]]())}),jQuery(".damiwp_url_input")[["each"]](function(){jQuery(this)[["bind"]]("change focus blur",function(){$select="#"+jQuery(this)[["attr"]]("name")+"_div",$value=jQuery(this)[["val"]](),e='<img src ="'+$value+'" />';var e=jQuery($select)[["html"]]("")[["append"]](e)[["find"]]("img");window[["setTimeout"]](function(){parseInt(e[["attr"]]("width"))<20&&jQuery($select)[["html"]]("")},500)})}),jQuery(".tab-head li")[["click"]](function(e){var t=jQuery(this)[["index"]]();jQuery(".tab-head li")[["removeClass"]]("cur"),jQuery(this)[["addClass"]]("cur"),jQuery(".tab-body .dami_metabox")[["hide"]](),jQuery(".tab-body div.dami_metabox:eq("+t+")")[["fadeIn"]]()})});