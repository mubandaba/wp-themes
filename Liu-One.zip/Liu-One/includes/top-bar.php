<?php
/**
 * Generated on 2019/9/6 15:17:51
 *
 * @package   Liu-One
 * @version   v2.0
 * @author    WPTU爱好者
 * @Email     2774251932@qq.com
 * @site      https://www.wptu.cn
 * @copyright Copyright (c) 2016-2020 by WPTU爱好者
 * @link      https://www.wptu.cn/wptu.html
 *
**/
?>
<div class="topbar"> 
    <div class="container">
     <div class="topbar-user"> 
<?php      global $user_identity;
	if ($user_identity) { ?>
	<div class="user-my">
				    <?php _e( 'Hi！', 'itliu' ); ?><?php echo $user_identity; ?>，<?php _e( '您好！', 'itliu' ); ?>
					<?php if (current_user_can('manage_options')) { ?>
					<a href="<?php echo admin_url();?>" target="_blank"><i class="fa fa-cog"></i><?php _e( '管理站点', 'itliu' ); ?></a>
					<?php } ?>
					<a href="/" target="_blank"><i class="fa fa-user"></i><?php _e( '用户中心', 'itliu' );?></a>
					
					<a href="<?php echo wp_logout_url('index.php'); ?>"><i class="fa fa-power-off"></i><?php _e( '登出', 'itliu' ); ?></a>
				</div>
				<?php } else { ?>
				
				<div class="nav-login">
			 	<?php if ( is_user_logged_in()){ ?>
				<?php } else { ?>
				<a href="/wp-login.php" title="Login"><i class="icon-user"></i><?php _e( '登录', 'itliu' ); ?></a>
				<a href="/wp-login.php?action=register" target="_blank"><i class="icon-login"></i><?php _e( '注册', 'itliu' ); ?></a>
				<?php } ?>
				</div>
				<?php }  ?>
				
				
     </div> 
     <div class="topbar-nav"> 
       <?php if ( function_exists( 'wp_nav_menu' ) && has_nav_menu('dingbu-nav') ) { 
			wp_nav_menu(
				array(	
					'theme_location'   => 'dingbu-nav',
					'sort_column'	   => 'menu_order',
					'fallback_cb' => 'cmp_nav_fallback',
					'container' => false, 
					'menu_id' =>'dingbu-nav',
					'menu_class' =>'',
					) 
			); 
		}?>
     </div>
    </div> 
</div>