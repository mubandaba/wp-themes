<?php
/**
 * Generated on 2019/9/6 15:17:51
 *
 * @package   Liu-One
 * @version   v2.0
 * @author    WPTU爱好者
 * @Email     2774251932@qq.com
 * @site      https://www.wptu.cn
 * @copyright Copyright (c) 2016-2020 by WPTU爱好者
 * @link      https://www.wptu.cn/wptu.html
 *
**/
?>
<?php if( itliu('itliu_ad_posts_pc') && !wp_is_mobile()){  ?>
	<?php
		$num = itliu('itliu_ad_posts_pc_num',3);
		if ($wp_query->current_post == $num) : ?>
			<div class="ajax-load-con content posts-cjtz">
				<?php echo itliu('itliu_ad_posts_pc_url'); ?>
			</div>
		<?php endif; ?>
<?php } ?>
<?php if( itliu('itliu_ad_posts_m') && wp_is_mobile() ){  ?>
	<?php
		$num = itliu('itliu_ad_posts_m_num');
		if ($wp_query->current_post == $num) : ?>
			<div class="ajax-load-con content posts-cjtz-min">
				<?php echo itliu('itliu_ad_posts_m_url'); ?>
			</div>
		<?php endif; ?>
<?php } ?>
<?php 
if ( has_post_format( 'image' )) { //多图 ?>
<div class="ajax-load-con content posts-images <?php echo $GLOBALS['wow_single_list']; ?>">
	<div class="content-box posts-image-box">
		<div class="posts-default-title">
			<?php the_tags('<div class="post-entry-categories">','','</div>');?>
			<h2><?php echo itliu_post_state_date()?><a href="<?php the_permalink(); ?>" title="<?php the_title();?>" <?php if( get_post_meta($post->ID,"blank_value",true)) { echo 'target="_blank"';}?>><?php the_title();?></a></h2>
		</div>
		<div class="post-images-item">

			<ul <?php if( get_post_meta($post->ID,"img2_value",true) && wp_is_mobile() ){ echo 'class="images-style-two"'; }?> >
				<?php echo itliu_get_thumbnail();?>	
            </ul>

		</div>
		<div class="posts-default-content">
			
			<div class="posts-text"><?php echo wp_trim_words( get_the_excerpt(), 100); ?></div>
			<div class="posts-default-info">
			<?php itliu_entry_meta();?>
			</div>
		</div>
	</div>
</div>
<?php } else if ( has_post_format( 'gallery' )) { //大图 ?>
<div class="ajax-load-con content posts-default wow bounceInUp">
	<div class="content-box">	
		<div class="posts-default-img">
			<a href="<?php the_permalink(); ?>" title="<?php the_title();?>" <?php if( get_post_meta($post->ID,"blank_value",true)) { echo 'target="_blank"';}?>>
				<div class="overlay"></div>	
				<?php if( itliu('itliu_timthumb') && itliu('itliu_timthumb_lazyload',true) ) { ?>
					<img class="lazy thumbnail" data-original="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=300&w=764&zc=1" src="<?php echo constant("THUMB_BIG_DEFAULT");?>" alt="<?php the_title(); ?>" />	
				<?php }
				if ( itliu('itliu_timthumb') && !itliu('itliu_timthumb_lazyload',true) ) {	?>
					<img class="thumbnail" src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=300&w=764&zc=1" alt="<?php the_title(); ?>" />
				<?php } if( itliu('itliu_timthumb_lazyload',true) && !itliu('itliu_timthumb') ){ ?>
					<img src="<?php echo constant("THUMB_BIG_DEFAULT");?>" data-original="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" class="lazy thumbnail" />
				<?php } ?>
				<?php if( !itliu('itliu_timthumb_lazyload',true) && !itliu('itliu_timthumb')){ ?>
					<img src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" class="thumbnail" />
				<?php } ?>
			</a> 
		</div>
		<div class="posts-default-box">
			<div class="posts-default-title">
				<h2><?php echo itliu_post_state_date()?><a href="<?php the_permalink(); ?>" title="<?php the_title();?>" <?php if( get_post_meta($post->ID,"blank_value",true)) { echo 'target="_blank"';}?>><?php the_title();?></a></h2>
			</div>
			<div class="posts-default-content">
				
				<div class="posts-text"><?php echo wp_trim_words(get_the_excerpt(), 100 );?></div>
				<div class="posts-default-info">
				<?php itliu_entry_meta();?>
				</div>
			</div>
		</div>
	</div>
</div>

<?php } else{ //标准 ?>



<div class="ajax-load-con content wow bounceInUp">
	<div class="content-box posts-gallery-box">
		<div class="posts-gallery-img">
		  <span class="cat-title"><?php $category = get_the_category();if($category[0]){echo $category[0]->cat_name;}?></span>
			<a href="<?php the_permalink(); ?>" title="<?php the_title();?>" <?php if( get_post_meta($post->ID,"blank_value",true)) { echo 'target="_blank"';}?>>	
				<?php if( itliu('itliu_timthumb') && itliu('itliu_timthumb_lazyload',true) ) { ?>
					<img class="lazy thumbnail" data-original="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=173.98&w=231.98&zc=1" src="<?php echo constant("THUMB_SMALL_DEFAULT");?>" alt="<?php the_title(); ?>" />	
				<?php }
				if ( itliu('itliu_timthumb') && !itliu('itliu_timthumb_lazyload',true) ) {	?>
					<img class="thumbnail" src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=173.98&w=231.98&zc=1" alt="<?php the_title(); ?>" />
				<?php } if( itliu('itliu_timthumb_lazyload',true) && !itliu('itliu_timthumb') ){ ?>
					<img src="<?php echo constant("THUMB_SMALL_DEFAULT");?>" data-original="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" class="lazy thumbnail" />
				<?php } ?>
				<?php if( !itliu('itliu_timthumb_lazyload',true) && !itliu('itliu_timthumb')){ ?>
					<img src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" class="thumbnail" />
				<?php } ?>
				<div class="zoomOverlay"></div>
			</a> 
		</div>
		<div class="posts-gallery-content">
			<h2><?php echo itliu_post_state_date()?><a href="<?php the_permalink(); ?>" title="<?php the_title();?>" <?php if(get_post_meta($post->ID,"blank_value",true)) { echo 'target="_blank"';}?>><?php the_title();?></a></h2>
			
			<div class="posts-gallery-text">
			<?php echo wp_trim_words(get_the_excerpt(), 100 ) ;?>
			</div>
			<div class="posts-default-info">
			<?php itliu_entry_meta();?>
			</div>
			
		</div>
	</div>
</div>
<?php } ?>
