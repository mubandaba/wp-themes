<?php
/**
 * Generated on 2019/9/6 15:17:51
 *
 * @package   Liu-One
 * @version   v2.0
 * @author    WPTU爱好者
 * @Email     2774251932@qq.com
 * @site      https://www.wptu.cn
 * @copyright Copyright (c) 2016-2020 by WPTU爱好者
 * @link      https://www.wptu.cn/wptu.html
 *
**/
?>
<?php  
include('widget-comment.php');
include('widget-tags.php');
include('widget-ad.php');
include('widget-hotpost.php');
include('widget-postlist.php');
include('widget-mostviews.php');
include('widget-social.php');
include('widget-links.php');
include('widget-posts.php');
?>