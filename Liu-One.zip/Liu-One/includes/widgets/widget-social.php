<?php
/**
 * Generated on 2019/9/6 15:17:51
 *
 * @package   Liu-One
 * @version   v2.0
 * @author    WPTU爱好者
 * @Email     2774251932@qq.com
 * @site      https://www.wptu.cn
 * @copyright Copyright (c) 2016-2020 by WPTU爱好者
 * @link      https://www.wptu.cn/wptu.html
 *
**/
?>
<?php  

add_action('widgets_init', create_function('', 'return register_widget("itliu_social");'));
class itliu_social extends WP_Widget {
	function __construct() {
		$widget_ops = array( 'classname' => 'itliu_social', 'description' => '集成社交网站链接入口' );
		parent::__construct('itliu_social', '关注我们 ', $widget_ops);
	}
    function widget($args, $instance) {
        extract( $args );

		$qq = $instance['qq'];
		$sinaweibo = $instance['sinaweibo'];
		$mail = $instance['mail'];
		$weixin = $instance['weixin'];
		$tencent = $instance['tencent'];
		$facebook = $instance['facebook'];
		$twitter = $instance['twitter'];
		$qzone = $instance['qzone'];
		
		echo $before_widget;
		echo $after_title; 
        echo itliu_widget_social($sinaweibo,$facebook,$tencent,$twitter,$qq,$mail,$weixin,$qzone);
        echo $after_widget;	
    }

	function form($instance) {
		$instance['sinaweibo'] = ! empty( $instance['sinaweibo'] ) ? esc_attr( $instance['sinaweibo'] ) : '';
		$instance['facebook'] = ! empty( $instance['facebook'] ) ? esc_attr( $instance['facebook'] ) : '';
		$instance['tencent'] = ! empty( $instance['tencent'] ) ? esc_attr( $instance['tencent'] ) : '';
		$instance['twitter'] = ! empty( $instance['twitter'] ) ? esc_attr( $instance['twitter'] ) : '';
		$instance['qq'] = ! empty( $instance['qq'] ) ? esc_attr( $instance['qq'] ) : '';
		$instance['mail'] = ! empty( $instance['mail'] ) ? esc_attr( $instance['mail'] ) : '';
		$instance['weixin'] = ! empty( $instance['weixin'] ) ? esc_attr( $instance['weixin'] ) : '';
		$instance['qzone'] = ! empty( $instance['qzone'] ) ? esc_attr( $instance['qzone'] ) : '';
		
?>

<p>
	<label> 微博链接（链接以http://开头）：
		<input id="<?php echo $this->get_field_id('sinaweibo'); ?>" name="<?php echo $this->get_field_name('sinaweibo'); ?>" type="text" value="<?php echo $instance['sinaweibo']; ?>" class="widefat" />
	</label>
</p>
<p>
	<label>  QQ微博链接（链接以http://开头）：
		<input id="<?php echo $this->get_field_id('tencent'); ?>" name="<?php echo $this->get_field_name('tencent'); ?>" type="text" value="<?php echo $instance['tencent']; ?>" class="widefat" />
	</label>
</p>

<p>
	<label>  QQ客服号：
		<input id="<?php echo $this->get_field_id('qq'); ?>" name="<?php echo $this->get_field_name('qq'); ?>" type="text" value="<?php echo $instance['qq']; ?>" class="widefat" />
	</label>
</p>
<p>
	<label>  QQ邮箱地址（只填账号）：
		<input id="<?php echo $this->get_field_id('mail'); ?>" name="<?php echo $this->get_field_name('mail'); ?>" type="text" value="<?php echo $instance['mail']; ?>" class="widefat" />
	</label>
</p>
<p>
	<label>  微信公众号ID（微信二维码请到【主题选项】里设置）：
		<input id="<?php echo $this->get_field_id('weixin'); ?>" name="<?php echo $this->get_field_name('weixin'); ?>" type="text" value="<?php echo $instance['weixin']; ?>" class="widefat" />
	</label>
</p>
<p>
	<label>  脸谱链接（链接以http://开头）：
		<input id="<?php echo $this->get_field_id('facebook'); ?>" name="<?php echo $this->get_field_name('facebook'); ?>" type="text" value="<?php echo $instance['facebook']; ?>" class="widefat" />
	</label>
</p>
<p>
	<label>  推特链接（链接以http://开头）：
		<input id="<?php echo $this->get_field_id('twitter'); ?>" name="<?php echo $this->get_field_name('twitter'); ?>" type="text" value="<?php echo $instance['twitter']; ?>" class="widefat" />
	</label>
</p>
<p>
	<label>  QQ空间链接（链接以http://开头）：
		<input id="<?php echo $this->get_field_id('qzone'); ?>" name="<?php echo $this->get_field_name('qzone'); ?>" type="text" value="<?php echo $instance['qzone']; ?>" class="widefat" />
	</label>
</p>

<?php
	}
}

function itliu_widget_social($sinaweibo,$facebook,$tencent,$twitter,$qq,$mail,$weixin,$qzone){ 
?>
	<div class="social wow bounceInUp">
		    <?php if( $sinaweibo ) { ?>
				<a class="weibo shake" href="<?php echo $sinaweibo ?>" target="_blank" data-original-title="关注新浪微博" title="关注新浪微博" rel="external nofollow"><i class="icon-weibo"></i></a>
			<?php } ?>

			<?php if( $tencent ) { ?>
			<a class="tx-weibo shake-hard" href="<?php echo $tencent ?>" target="_blank" data-original-title="关注腾讯微博" title="关注腾讯微博" rel="external nofollow"><i class="icon-tencent-weibo"></i></a>
			<?php } ?>

			<?php if( $qq ) { ?>
			 <a class="tx-qq shake-horizontal" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $qq ?>&site=qq&menu=yes" target="_blank" title="客服QQ号" data-original-title="客服QQ号"><i class="icon-qq"></i></a>
           <?php } ?>

			<?php if( $mail ) { ?>
			 <a class="tx-mail shake-vertical" href="http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=<?php echo $mail ?>" target="_blank" title="客服QQ邮箱" data-original-title="客服QQ邮箱"><i class="icon-mail-3"></i></a>
           <?php } ?>

			<?php if( $weixin ) { ?>
			<a id="tooltip-s-weixin" class="weixin weibo" href="javascript:void(0);" title="微信公众号" data-original-title="微信公众号"><i class="icon-wechat"></i>
             </a>
			<?php } ?>
			
			<?php if( $twitter ) { ?>
			<a class="twitter shake-chunk" href="<?php echo $twitter ?>" target="_blank" data-original-title="关注推特" title="关注推特" rel="external nofollow"><i class="icon-twitter-2"></i></a>
			<?php } ?>
			
			<?php if( $facebook ) { ?>
			<a class="facebook shake-slow" href="<?php echo $facebook ?>" target="_blank" data-original-title="关注脸谱" title="关注脸谱" rel="external nofollow"><i class="icon-facebook-official"></i></a>
			<?php } ?>
			
			<?php if( $qzone ) { ?>
			<a class="qzone shake-opacity" href="<?php echo $qzone ?>" target="_blank" data-original-title="关注QQ空间" title="关注QQ空间" rel="external nofollow"><i class="icon-qq-1"></i></a>
			<?php } ?>
	</div>
<?php }?>
