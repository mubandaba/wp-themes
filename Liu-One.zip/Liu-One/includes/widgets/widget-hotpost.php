<?php
/**
 * Generated on 2019/9/6 15:17:51
 *
 * @package   Liu-One
 * @version   v2.0
 * @author    WPTU爱好者
 * @Email     2774251932@qq.com
 * @site      https://www.wptu.cn
 * @copyright Copyright (c) 2016-2020 by WPTU爱好者
 * @link      https://www.wptu.cn/wptu.html
 *
**/
?>
<?php
//切换标签插件
//widget itliu_hotpost

add_action('widgets_init', create_function('', 'return register_widget("itliu_hotpost");'));
class itliu_hotpost extends WP_Widget {
    function __construct() {
    	$widget_ops = array( 'description' => '默认显示30天内，评论数最多的图文列表');
    	parent::__construct('itliu_hotpost', '热门图文 ', $widget_ops);
    }
    function widget($args, $instance) {
        extract( $args );

		$limit = $instance['limit'];
		$time = $instance['time'];
		$cat = $instance['cat'];
		$title = apply_filters('widget_name', $instance['title']);
		echo $before_widget;
		echo $before_title.$title.$after_title; 
        echo itliu_widget_hotpost($limit,$cat,$time);
        echo $after_widget;	
    }

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['limit'] = strip_tags($new_instance['limit']);
		$instance['time'] = strip_tags($new_instance['time']);
		$instance['cat'] = strip_tags($new_instance['cat']);
		return $instance;
	}
	function form($instance) {
		$instance = wp_parse_args( (array) $instance, array( 
			'title' => '热门图文',
			'limit' => '5',
			'time' => '3 month ago',
			) 
		);
		$title = strip_tags($instance['title']);
		$limit = strip_tags($instance['limit']);		
		$instance['cat'] = ! empty( $instance['cat'] ) ? esc_attr( $instance['cat'] ) : '';

?>
<p>
	<label> 显示标题：（例如：热门文章）
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $instance['title']; ?>" />
	</label>
</p>

<p>
	<label>
		显示某个时间段：
		
		<input class="widefat" id="<?php echo $this->get_field_id('time'); ?>" name="<?php echo $this->get_field_name('time'); ?>" type="text" value="<?php echo $instance['time']; ?>" />
		<p>填写格式：（注意空格）</p>
		<p>1周内：1 week ago</p>
		<p>1月内：1 month ago</p>
		<p>1年内：1 year ago</p>
		
	</label>
</p>
<p>
	<label> 显示文章数目：
		<input class="widefat" id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="number" value="<?php echo $instance['limit']; ?>" />
	</label>
</p>
<p>
	<label>
		分类限制：
		<a style="font-weight:bold;color:#f60;text-decoration:none;" href="javascript:;" title="格式：1,2 &nbsp;表限制ID为1,2分类的文章&#13;格式：-1,-2 &nbsp;表排除分类ID为1,2的文章&#13;也可直接写1或者-1；注意逗号须是英文的">？</a>
		<input style="width:100%;" id="<?php echo $this->get_field_id('cat'); ?>" name="<?php echo $this->get_field_name('cat'); ?>" type="text" value="<?php echo $instance['cat']; ?>" size="24" />
	</label>
</p>
<p><?php show_category() ?><br/><br/></p>
<?php
	}
}

function itliu_widget_hotpost($limit,$cat,$time){ 
?>
	<ul class="widget_hot_post">
     	<?php 
        $args = array(
            'post_type'         => 'post',
            'post_status'       => 'publish',
            'posts_per_page'    => $limit,
            'orderby'           => 'comment_count',
            'order'             => 'DESC',
			'cat'              => $cat,
			'ignore_sticky_posts' => 1,
			'date_query' => array(
				array(
				'after' => $time,
				),
			),
			'tax_query' => array( array( 
				'taxonomy' => 'post_format',
				'field' => 'slug',
				'terms' => array(
					//请根据需要保留要排除的文章形式
					'post-format-aside',
					
					),
				'operator' => 'NOT IN',
				) ),

        );
		$hot_posts = new WP_Query( $args );
		if ( !$hot_posts->have_posts() ) :?>
		<p>暂无文章</p>
		<?php else:
		while ( $hot_posts->have_posts() ) :$hot_posts->the_post(); ?>
			<li>
				<a href="<?php the_permalink(); ?>"	title="<?php the_title(); ?>">
					<?php if( itliu('itliu_timthumb') && itliu('itliu_timthumb_lazyload',true) ) { ?>
						<img class="lazy thumbnail" data-original="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=175&w=315.98&zc=1" src="<?php echo constant("THUMB_SMALL_DEFAULT");?>" alt="<?php the_title(); ?>" />	
					<?php }
					if ( itliu('itliu_timthumb') && !itliu('itliu_timthumb_lazyload',true) ) {	?>
						<img class="thumbnail" src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=175&w=315.98&zc=1" alt="<?php the_title(); ?>" />
					<?php } if( itliu('itliu_timthumb_lazyload',true) && !itliu('itliu_timthumb') ){ ?>
						<img src="<?php echo constant("THUMB_SMALL_DEFAULT");?>" data-original="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" class="lazy thumbnail" />
					<?php } ?>
					<?php if( !itliu('itliu_timthumb_lazyload',true) && !itliu('itliu_timthumb')){ ?>
						<img src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" class="thumbnail" />
					<?php } ?> 					
				
					
					
				</a>
			</li>
		<?php endwhile; endif; ?>
	</ul>	
<?php }?>
