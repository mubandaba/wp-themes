<?php
/**
 * Generated on 2019/9/6 15:17:51
 *
 * @package   Liu-One
 * @version   v2.0
 * @author    WPTU爱好者
 * @Email     2774251932@qq.com
 * @site      https://www.wptu.cn
 * @copyright Copyright (c) 2016-2020 by WPTU爱好者
 * @link      https://www.wptu.cn/wptu.html
 *
**/
?>
<?php
add_action('widgets_init', create_function('', 'return register_widget("itliu_posts");'));
class itliu_posts extends WP_Widget{

    function __construct(){
        $widget_ops = array(
        	
        	'classname' => 'itliu_posts',
            'name'        => '文章聚合',
            'description'=>'文章聚合'
        );
        parent::__construct( false, false, $widget_ops );
    }

    function widget($args, $instance){
        extract($args);
        $result = '';
        $number = (!empty($instance['number'])) ? intval($instance['number']) : 10;
        ?>
        <aside class="widget itliu_posts_tab">
            <ul id="tabul" class="nav nav-tabs">
                <li class="active"><a href="#newest" data-toggle="tab"> 最新文章</a></li>
                <li><a href="#hot" data-toggle="tab"> 热点文章</a></li>
                <li><a href="#rand" data-toggle="tab">随机文章</a></li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane active" id="newest">
                    <ul>
                        <?php $myposts = get_posts('numberposts='.$number.' & offset=0'); $i = 0; foreach($myposts as $post) : $i++; ?>
                            <li><span class="li-icon"><?php echo $i ?></span><a href="<?php echo get_permalink($post->ID); ?>" rel="bookmark" title="<?php echo $post->post_title;?>"><?php echo strip_tags($post->post_title) ?>
                            </a></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="tab-pane" id="hot">
                    <ul>
                        <?php if(function_exists('itliu_comm_posts')) itliu_comm_posts(90, $number); ?>
                    </ul>
                </div>
                <div class="tab-pane" id="rand">
                    <ul>
                        <?php $myposts = get_posts('numberposts='.$number.' & offset=0 & orderby=rand');$i = 0; foreach($myposts as $post) : $i++;?>
                            <li><span class="li-icon"><?php echo $i ?></span><a href="<?php echo get_permalink($post->ID); ?>" rel="bookmark" title="<?php echo $post->post_title;?>"><?php echo strip_tags($post->post_title) ?>
                            </a></li>
                       <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </aside>
        <?php
    }
    function update($new_instance, $old_instance){
        if (!isset($new_instance['submit'])) {
            return false;
        }
        $instance = $old_instance;
        $instance['number'] = intval($new_instance['number']);
        return $instance;
    }

    function form($instance){
        global $wpdb;
        $instance = wp_parse_args((array) $instance, array('number'=>'10'));
        $number = intval($instance['number']);
        ?>

        <p>
            <label for='<?php echo $this->get_field_id("number");?>'>每项展示数量：<input type='text' name='<?php echo $this->get_field_name("number");?>' id='<?php echo $this->get_field_id("number");?>' value="<?php echo $number;?>"/></label>
        </p>
        <input type="hidden" id="<?php echo $this->get_field_id('submit'); ?>" name="<?php echo $this->get_field_name('submit'); ?>" value="1" />
        <?php
    }
}