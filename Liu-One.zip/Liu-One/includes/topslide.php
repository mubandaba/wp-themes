<?php
/**
 * Generated on 2019/9/6 15:17:51
 *
 * @package   Liu-One
 * @version   v2.0
 * @author    WPTU爱好者
 * @Email     2774251932@qq.com
 * @site      https://www.wptu.cn
 * @copyright Copyright (c) 2016-2020 by WPTU爱好者
 * @link      https://www.wptu.cn/wptu.html
 *
**/
?>
<div class="top-content">
	<div class="container">
		<div class="row">
			<div class="owl-carousel top-slide">
				<?php
				if( itliu('itliu_slide2',false) ): 
					for ($i=1; $i < itliu('itliu_slide_number') + 1; $i++) { ?>
							<div class="item">	
								<a href="<?php echo itliu('itliu_slide_url_'.$i);?>" title="<?php echo itliu('itliu_slide_title_'.$i);?>">
									<div class="slider-content"  style="background-image: url(<?php echo itliu('itliu_slide_img_'.$i); ?>);">
										<?php if(itliu('itliu_slide_info',true)){ ?>
										<div class="slider-content-box"> 
											<div class="slider-content-item">
												<div class="slider-title">
													<h2><?php echo itliu('itliu_slide_title_'.$i);?></h2>
									            </div>
								           	</div>
							           	</div>
										<?php } ?>
									</div>
								</a>

							</div>
					<?php }
				?>
				<?php else: ?>
					<?php 
						$numpost = itliu('itliu_slide_number');
						$args = array( 
						'showposts' => $numpost,
						'ignore_sticky_posts' => 1,	
						'meta_query' => array(
							array(
								'key' => 'lunbo_value', 
								'value' => '1'  
								)));
						query_posts($args);
						if (have_posts()) : 
							while (have_posts()) : the_post();?>
								<div class="item">	
									<a href="<?php the_permalink(); ?>" title="<?php the_title();?>">
										<div class="slider-content" style="background-image: url(<?php if (get_post_meta($post->ID,"postthumb_value",true ) ){ echo get_post_meta($post->ID,"postthumb_value",true); } elseif( itliu('itliu_timthumb') ){ echo get_template_directory_uri().'/timthumb.php?src='.post_thumbnail_src().'&h=500&w=1120'; } else { echo post_thumbnail_src(); } ?>); ">
										<?php if(itliu('itliu_slide_info',true)){ ?>
											<div class="slider-content-item">
												<div class="slider-cat clearfix"><?php $category = get_the_category();if($category[0]){ echo $category[0]->cat_name;}?></div>  
												<h2><?php the_title();?></h2>
								           	</div>
										<?php } ?>
										</div>
									</a>

								</div>
						<?php 
							endwhile; 
						else:  
							$categories = explode(",",itliu( 'itliu_slide_fenlei' ));
							$order = itliu('itliu_slide_order');
							$num = itliu('itliu_slide_number');
							$args = array(
								'ignore_sticky_posts'=> 1,
								'paged' => $paged,
								'orderby'=> $order,//date DESC rand
								'posts_per_page' =>  $num,
								'cat' => $categories , 
								'tax_query' => array( array( 
									'taxonomy' => 'post_format',
									'field' => 'slug',
									'terms' => array(
										//请根据需要保留要排除的文章形式
										'post-format-aside',
										'post-format-link'
										),
									'operator' => 'NOT IN',
								) ),
							);
							query_posts($args);			
							while (have_posts()) : the_post();?>
							<div class="item">	
								<a href="<?php the_permalink(); ?>" title="<?php the_title();?>">
									<div class="slider-content" style="background-image: url(<?php if( itliu('itliu_timthumb') ){ echo get_template_directory_uri().'/timthumb.php?src='.post_thumbnail_src().'&h=500&w=1120'; } else { echo post_thumbnail_src(); } ?>); ">
										<?php if(itliu('itliu_slide_info',true)){ ?>
										<div class="slider-content-item">
											<div class="slider-cat clearfix"><?php $category = get_the_category();if($category[0]){echo $category[0]->cat_name;}?></div>  
											<h2><?php the_title();?></h2>
							           	</div>
										<?php } ?>
									</div>
								</a>
							</div>
					<?php endwhile; wp_reset_query(); endif; ?>
				<?php endif; ?>
			</div>
			<?php
				if(!wp_is_mobile()):
			?>
				<div class="top-singles">
					<?php
						$args = array( 
						'showposts' => 2,
						'ignore_sticky_posts' => 1,	
						'meta_query' => array(
							array(
								'key' => 'lunbo_silde_value', 
								'value' => '1'  
								)));
						$query = new WP_query( $args );
						if( $query->have_posts() ):
							while( $query->have_posts() ): $query->the_post();
					?>
							<div class="single-item">
								<div class="image" style="background-image:url(<?php if (get_post_meta($post->ID,"postthumb_silde_value",true ) ){ echo get_post_meta($post->ID,"postthumb_silde_value",true); } elseif( itliu('itliu_timthumb') ){ echo get_template_directory_uri().'/timthumb.php?src='.post_thumbnail_src().'&h=200&w=370'; } else { echo post_thumbnail_src(); } ?>)">
									<a href="<?php the_permalink();?>">
										<div class="overlay"></div>
										<div class="title"><span><?php $category = get_the_category();if($category[0]){echo $category[0]->cat_name;}?></span><h3><?php the_title();?></h3></div>
									</a>
								</div>
							</div>
					<?php endwhile; wp_reset_query(); endif;?>
				</div>
				
			<?php endif; ?>
		</div>
	</div>
</div>

