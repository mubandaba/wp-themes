<?php
/**
 * Generated on 2019/9/6 15:17:51
 *
 * @package   Liu-One
 * @version   v2.0
 * @author    WPTU爱好者
 * @Email     2774251932@qq.com
 * @site      https://www.wptu.cn
 * @copyright Copyright (c) 2016-2020 by WPTU爱好者
 * @link      https://www.wptu.cn/wptu.html
 *
**/
?>
<?php
add_filter('the_content', 'fancybox');
function fancybox ($content)  
{ global $post;  
$pattern = "/<a(.*?)href=('|\")([^>]*).(bmp|gif|jpeg|jpg|png|swf)('|\")(.*?)>(.*?)<\/a>/i";  
$replacement = '<a$1href=$2$3.$4$5 rel="box" class="fancybox"$6>$7</a>';  
$content = preg_replace($pattern, $replacement, $content);  
return $content;  
} 
?>