<?php
/**
 * Generated on 2019/9/6 15:17:51
 *
 * @package   Liu-One
 * @version   v2.0
 * @author    WPTU爱好者
 * @Email     2774251932@qq.com
 * @site      https://www.wptu.cn
 * @copyright Copyright (c) 2016-2020 by WPTU爱好者
 * @link      https://www.wptu.cn/wptu.html
 *
**/
?>
<?php
function fa_make_post_section(){
    global $post;

    if( itliu('itliu_wow_single_list',true) ){
        $GLOBALS['wow_single_list'] = 'wow bounceInUp';
    }

    $target='';
    $image='';
    $excerpt='';
    $excerpt2='';
    $cate='';
    $post_section ='';
    $post_html = '';
    $category = get_the_category();
    if(get_post_meta($post->ID,"blank_value",true)) { $target='target="_blank"';}
    $excerpt = wp_trim_words(get_the_excerpt(), 100 );
    $excerpt2 = wp_trim_words(get_the_excerpt(), 100 );
    if($category[0]){
        $cate='<a href="'.get_category_link($category[0]->term_id ).'">'.$category[0]->cat_name.'</a>';
    }

    if( get_post_meta($post->ID,'itliu_ding',true) ){ $ding_num = get_post_meta($post->ID,'itliu_ding',true); } else { $ding_num =  '0';}
    $posttags = get_the_tags();
	if ($posttags){
		$tags = $posttags[0]->name;
	}
    $comments = get_post($post->ID)->comment_count;
	
   
        $post_html .= '<div class="post-author"><div class="avatar">'. get_avatar( get_the_author_meta('ID') ).'</div><span>'. get_the_author() .'</span></div>'; 
    if(has_tag()){
        $post_html .= '<div class="tags"><i class="icon-tags-1"></i>'.$tags.'</div>';
	}	
        $post_html .= '<div class="times"><i class="icon-clock-1"></i>'.timeago( get_gmt_from_date(get_the_time('Y-m-d G:i:s')) ).'</div>';
    
        $post_html .= '<a href="javascript:;" data-action="ding" data-id="'.get_the_ID().'" id="Addlike" class="action btn-likes like">
		<div class="likes"><i class="icon-thumbs-up"></i>'.$ding_num.'</div></a>';
	if (get_comments_number()==0) {	
		$post_html .= '<div class="comments"><a href="'.get_permalink().'/#respond"><i class="icon-commenting-o"></i> 沙发</a></div>';
    } else {
		$post_html .= '<div class="comments"><a href="'.get_permalink().'/#respond"><i class="icon-commenting-o"></i>'.$comments.'</a></div>';
	}

    if( has_post_format( 'gallery' ) ){

        if( itliu('itliu_timthumb') && itliu('itliu_timthumb_lazyload',true) ) { 
            $image ='<img class="lazy thumbnail" data-original="'. get_template_directory_uri() .'/timthumb.php?src='.post_thumbnail_src().'&h=300&w=764&zc=1" src="'.constant("THUMB_BIG_DEFAULT").'" alt="'. get_the_title().'" />';   
        }
        if ( itliu('itliu_timthumb') && !itliu('itliu_timthumb_lazyload',true) ) {

            $image ='<img class="thumbnail" src="'.get_template_directory_uri().'/timthumb.php?src='.post_thumbnail_src().'&h=300&w=764&zc=1" alt="' . get_the_title() . '" />';

        } if( itliu('itliu_timthumb_lazyload',true) && !itliu('itliu_timthumb') ){
           $image ='<img src="'.constant("THUMB_BIG_DEFAULT").'" data-original="'.post_thumbnail_src().'" alt="'. get_the_title().'" class="lazy thumbnail" />';
        } 
        if( !itliu('itliu_timthumb_lazyload',true) && !itliu('itliu_timthumb')){
            $image ='<img src="'.post_thumbnail_src().'" alt="'. get_the_title().'" class="thumbnail" />';
        }

        $post_section .='<li class="ajax-load-con content posts-default '.$GLOBALS['wow_single_list'].'"><div class="content-box">
                            <div class="posts-default-img">
                                <a href="' . get_permalink() . '" title="'.get_the_title().'" '.$target.'>
                                    <div class="overlay"></div>     
                                    '.$image.'
                                </a> 
                            </div>';

        $post_section .='<div class="posts-default-box"><div class="posts-default-title">';

        
        $post_section .='<h2>'.itliu_post_state_date().'<a href="' . get_permalink() . '" title="' . get_the_title() . '" '.$target.'>'.get_the_title().'</a></h2></div><div class="posts-default-content">
                        <div class="posts-text">'.$excerpt.'</div>
                        <div class="posts-default-info">
                            <ul>
                                '.$post_html.'
                            </ul>
                        </div>
                    </div>
                </div>
            </li>
        ';
    }
    else if ( has_post_format( 'image' )) { //多图 
        $post_section .= '<li class="ajax-load-con content '.$GLOBALS['wow_single_list'].'"><div class="content-box posts-image-box"><div class="posts-default-title">';
        
            $posttags = get_the_tags();
            if ($posttags) {
                $post_section .='<div class="post-entry-categories">';
                foreach($posttags as $tag) {
                    $post_section .= '<a href="'.get_tag_link($tag->term_id).'" rel="tag">' .$tag->name .'</a>'; 
                }
                $post_section .='</div>';
            }
        
        if(itliu('images-style-two')){ $style2 = 'class="images-style-two"'; } else { $style2 = ''; }
        $post_section .= '<h2>'.itliu_post_state_date().'<a href="' . get_permalink() . '" title="' . get_the_title() . '" '.$target.'>'.get_the_title().'</a></h2></div>
                <div class="post-images-item"><ul '.$style2.'>'.itliu_get_thumbnail().'</ul></div><div class="posts-default-content"><div class="posts-text">'.$excerpt.'</div>
                        <div class="posts-default-info">
                            <ul>
                                '.$post_html.'
                            </ul>
                        </div>
                    </div>
                </div>
            </li>';
     }
    
   else{
        
		
		if( itliu('itliu_timthumb') && itliu('itliu_timthumb_lazyload',true) ) { 
            $image ='<img class="lazy thumbnail" data-original="'. get_template_directory_uri() .'/timthumb.php?src='.post_thumbnail_src().'&h=173.98&w=231.98&zc=1" src="'.constant("THUMB_SMALL_DEFAULT").'" alt="'. get_the_title().'" />';   
        }
        if ( itliu('itliu_timthumb') && !itliu('itliu_timthumb_lazyload',true) ) {

            $image ='<img class="thumbnail" src="'.get_template_directory_uri().'/timthumb.php?src='.post_thumbnail_src().'&h=173.98&w=231.98&zc=1" alt="' . get_the_title() . '" />';

        } if( itliu('itliu_timthumb_lazyload',true) && !itliu('itliu_timthumb') ){
           $image ='<img src="'.constant("THUMB_SMALL_DEFAULT").'" data-original="'.post_thumbnail_src().'" alt="'. get_the_title().'" class="lazy thumbnail" />';
        } 
        if( !itliu('itliu_timthumb_lazyload',true) && !itliu('itliu_timthumb')){
            $image ='<img src="'.post_thumbnail_src().'" alt="'. get_the_title().'" class="thumbnail" />';
        }

        $post_section ='
            <li class="ajax-load-con content '.$GLOBALS['wow_single_list'].'">
                <div class="content-box posts-gallery-box">
                    <div class="posts-gallery-img">
                        <a href="'.get_permalink().'" title="'.get_the_title().'" '.$target.'>  
                            '.$image.'
                        </a> 
                    </div>
                    <div class="posts-gallery-content">
                        <h2 class="posts-gallery-title">'.itliu_post_state_date().'<a href="' . get_permalink() . '" title="' . get_the_title() . '" '.$target.'>'.get_the_title().'</a></h2>  
                       <div class="posts-gallery-text">'.$excerpt2.'</div>
                        <div class="posts-default-info posts-gallery-info">
                            '.$post_html.'
                        </div>
                    </div>
                </div>
            </li>
        ';
   }

   return $post_section;
}

add_action('wp_ajax_nopriv_fa_load_postlist', 'fa_load_postlist_callback');
add_action('wp_ajax_fa_load_postlist', 'fa_load_postlist_callback');
function fa_load_postlist_callback(){
    $postlist = '';
    $home = !empty($_POST["home"]) ? $_POST["home"] : false;
    $paged = !empty($_POST["paged"]) ? $_POST["paged"] : null;
    $total = !empty($_POST["total"]) ? $_POST["total"] : null;
    $category = !empty($_POST["category"]) ? $_POST["category"] : null;
    $author = !empty($_POST["author"]) ? $_POST["author"] : null;
    $tag = !empty($_POST["tag"]) ? $_POST["tag"] : null;
    $search = !empty($_POST["search"]) ? $_POST["search"] : null;
    $year = !empty($_POST["year"]) ? $_POST["year"] : null;
    $month = !empty($_POST["month"]) ? $_POST["month"] : null;
    $day = !empty($_POST["day"]) ? $_POST["day"] : null;
    $query_args = array(
        "posts_per_page" => get_option('posts_per_page'),
        "cat" => $category,
        "tag" => $tag,
        "author" => $author,
        "post_status" => "publish",
        "post_type" => "post",
        "paged" => $paged,
        "s" => $search,
        "year" => $year,
        "monthnum" => $month,
        "day" => $day,
        "ignore_sticky_posts" => 1
    );
    $notinhome = itliu('notinhome');
    if( !empty ( $notinhome ) && $home ){
        $pool = array();
        foreach (itliu('notinhome') as $key => $value) {
            if( $value ) $pool[] = $key;
        }
        $query_args['cat'] = '-'.implode($pool, ',-');
    }
    else{
        $query_args['cat'] = $category;
    }
    $the_query = new WP_Query( $query_args );
    while ( $the_query->have_posts() ){
        $the_query->the_post();
        $postlist .= fa_make_post_section();
    }
    $code = $postlist ? 200 : 500;
    wp_reset_postdata();
    $next = ( $total > $paged )  ? ( $paged + 1 ) : '' ;
    echo json_encode(array('code'=>$code,'postlist'=>$postlist,'next'=> $next,'test'=>$home ));
    die;
}

function fa_load_postlist_button(){
    global $wp_query;
    if (2 > $GLOBALS["wp_query"]->max_num_pages) {
        return;
    } else {
        $button = '<button id="fa-loadmore" class="button button-more" data-wow-delay="0.3s"';
        if (is_home()) $button .= ' data-home="true"';
        if (is_category()) $button .= ' data-category="' . get_query_var('cat') . '"';

        if (is_author()) $button .=  ' data-author="' . get_query_var('author') . '"';

        if (is_tag()) $button .=  ' data-tag="' . get_query_var('tag') . '"';

        if (is_search()) $button .=  ' data-search="' . get_query_var('s') . '"';

        if (is_date() ) $button .=  ' data-year="' . get_query_var('year') . '" data-month="' . get_query_var('monthnum') . '" data-day="' . get_query_var('day') . '"';

        $button .= ' data-paged="2" data-action="fa_load_postlist" data-total="' . $GLOBALS["wp_query"]->max_num_pages . '">加载更多</button>';

        return $button;
    }
}


