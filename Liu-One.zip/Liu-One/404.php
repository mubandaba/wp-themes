<?php
/**
 * Generated on 2019/9/6 15:17:51
 *
 * @package   Liu-One
 * @version   v2.0
 * @author    WPTU爱好者
 * @Email     2774251932@qq.com
 * @site      https://www.wptu.cn
 * @copyright Copyright (c) 2016-2020 by WPTU爱好者
 * @link      https://www.wptu.cn/wptu.html
 *
**/
?>
<?php get_header();?>
<div id="page-content">
	<div class="container">
		<div class="box404">
			<div class="page404-title">
				<h4>404</h4>
				<h5>抱歉，没有你要找的文章...</h5>
			</div>
			<div class="buttons">
				<div class="pull2-left">
					<a title="Back" home"="" href="<?php bloginfo('url'); ?>" class="btn btn-primary">返回首页</a>
				</div>
			</div>
		</div>
	</div>
</div>

<?php get_footer(); ?>